
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tiket extends CI_Controller {

function __construct(){
		parent::__construct();
        $this->load->model("M_tiket");
         $this->load->model("M_pengunjung");
        $this->load->model("M_pesan");
        $this->load->library('form_validation');
        $this->load->helper(array('form'));
	}
   public function add($id_show)
	{
    $data['tiket'] = $this->M_tiket->getnamashow($id_show);
    $data['id_show'] = $id_show;
	$this->load->view('admin/tiket/form_tiket', $data);//memanggil form tambah di menu show
	}
    public function tiket_list($id){
        $data["tiket"] = $this->M_tiket->getByIdshow($id);
        $data["show"] = $this->M_tiket->getnamashow($id);
        $data["bank"] = $this->M_tiket->bank();
        $this->load->view('tiket/lihat_jenis', $data);
        //load view dengan memanggil data array multidimensi
    }
    public function pilih_tiket($id,$id_jenis){
        $data["tiket"] = $this->M_tiket->getByIdjenis($id_jenis);
        $data["show"] = $this->M_tiket->getnamashow($id);
        $data["bank"] = $this->M_tiket->bank();
        $this->load->view('tiket/pesan_tiket', $data);
        //load view dengan memanggil data array multidimensi
    }
    public function upload_bukti($kode_unik){
        $data["pesanan"] = $this->M_pesan->cari_pesanan($kode_unik);
        /*$tanggalp = $this->M_pesan->getTanggal();*/
        $pow = $this->M_pesan->cari_pesanan($kode_unik);
         foreach($pow->result_array() as $row){
             $tanggalp = $row['tanggal_pesan'];
         }

        /*$tp = date("2020-02-19 h:i");// database store*/

        $now = date("y-m-d h:i");
        $tglex = date('Y-m-d h:i', strtotime('+1 days', strtotime($tanggalp))); //db store

        echo "tanggal pemesanan : ".$tanggalp."<br>";
        echo "Tanggal expired :".$tglex."<br>"; 
        echo "tanggal sekarang : ".$now."<br>";//print tanggal

        //halaman pembayaran
        $tanggalsek = strtotime($now);
        $tanggalexp = strtotime($tglex);
        if($tanggalsek > $tanggalexp){
        $this->session->set_flashdata('success', '<?php echo "tanggal pemesanan : ".$tanggalp."<br>"; ?>');

        redirect('show/index') ;        
        }else {
        $this->load->view('pemesanan/bukti',$data);
        }
    }

    public function kirim_bukti()
    {
       
            $this->M_pesan->simpan_bukti();//memanggil fungsi untuk insert database show di M_model
            $this->session->set_flashdata('success', 'Berhasil disimpan');
        
        redirect('Show');
    }


    public function add_all(){
        global $kode;
        $kodebayar = $kode;
        $this->add_pengunjung();
        $post = $this->input->post();
        $data["nama"] = $this->M_tiket->atasnama();
        //$data["pemesanan"] = $this->M_pesan->getPesan();
        $data["datu"] = $post["total_bayar"];
        $data["dati"] = $post["jumlah_pesanan"];
        $data["kodebayar"] = $kode;
   
        redirect("show");
    }
    public function auto_email($id)
        {  
        $pow = $this->M_pesan->getjo($id);
         foreach($pow->result_array() as $row){
             $nama = $row['nama'];
             $totalbayar = $row['totalbayar'];
             $email = $row['email'];
         }
        $url = base_url("asset/image/kontent/");
        $to = $email;
        $subject = "Pembayaran Tiket Tour Musikologi".$nama;
        $message = "
        <html>
        <head>
        <title>Pembayaran Tiket Tour Musikologi".$nama."</title>
        </head>
        <body>
        <p>
        <h3>Pembayaran Tiket Tour Musikologi</h3><br><br>
        <img src='".$url."logo-musik.png' width='300' height='100'>
        <h3>Total Pembayaran: Rp.".$totalbayar."</h3>
        <b>Hai,".$nama."</b><br>
        Gunakan ATM/iBanking/mBanking/SMS Banking/setor tunai/E-wallet untuk transfer ke rekening Musikologi:<br>
        (rekening sesuai pilihan dia waktu beli)
        Hanya berlaku 1x24 Jam. Lebih dari itu isi ulang form pembelian di 
        <a href='http://musikologifest.com/index.php/show/beli'>disini</a>
        <br>
        Jika setelah melakukan pembayaran kamu belum dapat tiket silahkan upload bukti transfer 
        <a href='http://musikologifest.com/index.php/tiket/upload_bukti/".$id."'>disini</a>.
        Pastikan yang diupload bukti transfer,<br>
        bukan pap chat uwu kamu dengan kekasih:(
        Mohon untuk tidak memberikan bukti atau konfirmasi pembayaran ke siapapun, selain untuk Musikologi.
        </p>
        </body>
        </html>
        ";
        echo $nama;
        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: <initiketnya@musikologifest.com>' . "\r\n";
        //$headers .= 'Cc: myboss@example.com' . "\r\n";

        mail($to,$subject,$message,$headers);
    }

    public function add_pengunjung(){
        global $kode;
        $post = $this->input->post();
        $nama = $post["nama"];
        $no_identitas = $post["no_identitas"];
        $no_hp = $post["no_hp"];
        $email = $post["email"];
       $this->M_pengunjung->save_pengunjung();//memanggil fungsi untuk insert database show di M_model

        $id_tiket = $post["id_tiket"];
        $jumlah_pesanan = $post["jumlah_pesanan"];
        $totalbayar = $post["total_bayar"];
        $status_pemesanan = "1";
        $data["idn"] = $this->M_pengunjung->getBynik($no_identitas);
        $idpengunjung = $data["idn"]->id_pengunjung;
        
        $pow = $this->M_pesan->getmax();
         foreach($pow->result_array() as $row){
			 $max =$row['maxKode'];
		 }
            $j = $max + 1;
            $char = "PM";
            $kode= $char.$j;
         $jubo = $this->M_pesan->save($idpengunjung, $kode);
         if($jubo){
            echo $kode;
         }
             $this->auto_email($kode);
       
       
        
    }
    public function call_noidn($no_identitas){
      
    }
        public function add_tiket()
    {
        $post = $this->input->post();
        $id_show = $post["id_show"];
        $validation = $this->form_validation;//valiasi awal 
        $validation->set_rules($this->M_tiket->rules());//memanggil model M_show dengan fungsi rules
        if ($validation->run()) {
            
            $this->session->set_flashdata('success', 'Berhasil disimpan');
        }
            $this->M_tiket->save();//memanggil fungsi untuk insert database show di M_model
        redirect('tiket/tiket_list/'.$id_show);//jika semua script diatas yang ada di fungsi ini maka diarahkan ke controller show dengan funhgsi show_;ist
    }
     public function edit($id = null)
    {
        $product = $this->M_tiket;
        $validation = $this->form_validation;
        $validation->set_rules($product->rules());
         $data["product"] = $product->getById($id);
        $this->load->view("admin/tiket/edit_form", $data);
    }
     public function edit_act()
    {
         $post = $this->input->post();
        $id_show = $post["id_show"];
         //fungsi untuk query edit
        $validation = $this->form_validation;
        $validation->set_rules($this->M_tiket->rules());
        if ($validation->run()) {
            
            $this->session->set_flashdata('success', 'Berhasil disimpan');
        }
         $this->M_tiket->update();
         redirect('tiket/tiket_list/'.$id_show);
    }
         public function delete($id=null, $id_show)
    {
        $id_show1 = $id_show;
         //delete
        if (!isset($id)) show_404();
        if ($this->M_tiket->delete($id)) {
            redirect(site_url('tiket/tiket_list/'.$id_show1));
        }
    }
  
}


