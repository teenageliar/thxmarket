<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MUSIKOLOGI FESTIVAL 2020</title>
<link rel="icon" href="<?php echo base_url()?>asset/image/logo-musik.png" />
<link href="<?php echo base_url()?>asset/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url()?>asset/css/style.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>asset/js/jqueryui/jquery-ui.min.css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>asset/other/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>asset/engine0/style.css" />
<script src="<?php echo base_url()?>asset/js2/jquery-1.12.3.min.js"></script>
<script src="<?php echo base_url()?>asset/js2/jqueryui/jquery-ui.min.js"></script>
<script src="<?php echo base_url()?>asset/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>asset/js/add.js"></script>
<script src="<?php echo base_url()?>asset/js2/jqueryui/external/jquery/jquery.js"></script>
<script src="<?php echo base_url()?>asset/js2/jqueryui/jquery-ui.js"></script>
<script src="<?php echo base_url()?>asset/js/ayas.min.js"></script>
<script src="<?php echo base_url()?>asset/js2/jquery-1.12.3.min.js"></script>
<script src="<?php echo base_url()?>asset/js2/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>asset/js2/add.js"></script>
<script src="<?php echo base_url()?>asset/js2/jquery-1.12.3.min.js"></script>
<script src="<?php echo base_url()?>asset/js2/jqueryui/external/jquery/jquery.js"></script>
<script src="<?php echo base_url()?>asset/js2/jqueryui/jquery-ui.js"></script>
<script src="<?php echo base_url()?>asset/js/ayas.min.js"></script>
<link href="<?php echo base_url()?>asset/8/ninja-slider.css" rel="stylesheet" type="text/css" />
<script src="<?php echo base_url()?>asset/8/ninja-slider.js" type="text/javascript"></script>
<script type="<?php echo base_url()?>asset/text/javascript" src="engine0/jquery.js"></script>
</head>
<body>
	<div id="header">
    	<span style="position:absolute; cursor:pointer;" onclick="openNav()"><img src="<?php echo base_url()?>asset/image/kontent/menu.png" width="30" height="30"></span>
    	<div id="mySidenav" class="sidenav">
          <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
           <a href="<?php echo base_url()?>index.php/show/"> MUSIKOLOGI </a>
          <a href="<?php echo base_url()?>index.php/show/beli" > BELI TIKET TOUR</a>
          <a href="<?php echo base_url()?>index.php/show/tentang" > TENTANG KAMI</a>
          <a href="<?php echo base_url()?>index.php/show/vol1" > MUSIKOLOGI VOL 1</a>
            <a href="<?php echo base_url()?>index.php/show/vol2"> MUSIKOLOGI VOL 2</a>
            <a href="<?php echo base_url()?>index.php/show/gal"> GALLERY</a>
            <a href="<?php echo base_url()?>index.php/show/hub"> HUBUNGI KAMI </a>
        </div>
        <div class="logo">
            <div class="col-lg-5" style="float: right;">
        	   <img src="<?php echo base_url()?>asset/image/kontent/logo-musik.png" class="img img-responsive float-right">
            </div>
        </div>
    </div>