<div class="localP6">
                     <div class="col-lg-12 centered" style="margin: auto;">
                        <br /><br />
                        <div class="gallery">
                            <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/business-layout-selena-gomez-revival-tour-jakarta-20167301.map.jpg" onclick="lightbox(0)" style="width:auto;" class="abaout3 img img-responsive"  />
                            </div>
                            <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/5031790.jpeg" onclick="lightbox(1)" style="width:auto;" class="abaout3 img img-responsive" />
                            </div>
                            <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/business-layout-selena-gomez-revival-tour-jakarta-20167301.map.jpg" onclick="lightbox(0)" style="width:auto;" class="abaout3 img img-responsive"  />
                            </div>
                            <div class="col-lg-3">
                                <img src="i<?php echo base_url()?>asset/mage/kontent/5031790.jpeg" onclick="lightbox(1)" style="width:auto;" class="abaout3 img img-responsive" />
                            </div>
                                 <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/business-layout-selena-gomez-revival-tour-jakarta-20167301.map.jpg" onclick="lightbox(0)" style="width:auto;" class="abaout3 img img-responsive"  />
                            </div>
                            <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/5031790.jpeg" onclick="lightbox(1)" style="width:auto;" class="abaout3 img img-responsive" />
                            </div>
                            <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/business-layout-selena-gomez-revival-tour-jakarta-20167301.map.jpg" onclick="lightbox(0)" style="width:auto;" class="abaout3 img img-responsive"  />
                            </div>
                            <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/5031790.jpeg" onclick="lightbox(1)" style="width:auto;" class="abaout3 img img-responsive" />
                            </div>
                        </div>
                        </div>
            </div>

       <div style="display:none;">
        <div id="ninja-slider">
            <div class="slider-inner">
                <ul>
                    <li>
                        <a class="ns-img" href="<?php echo base_url()?>asset/image/kontent/business-layout-selena-gomez-revival-tour-jakarta-20167301.map.jpg"></a>
                        <div class="caption">
                            <h3>Map Stage</h3>
                        </div>
                    </li>
                    <li>
                        <a class="ns-img" href="<?php echo base_url()?>asset/image/kontent/5031790.jpeg"></a>
                        <div class="caption">
                            <h3>Another Banner</h3>
                        </div>
                    </li>
                    </ul>
                <div id="fsBtn" class="fs-icon" title="Expand/Close"></div>
            </div>
        </div>
    </div>
         