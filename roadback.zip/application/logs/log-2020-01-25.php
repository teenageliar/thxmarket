<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-25 09:05:49 --> Config Class Initialized
INFO - 2020-01-25 09:05:49 --> Hooks Class Initialized
DEBUG - 2020-01-25 09:05:49 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:05:49 --> Utf8 Class Initialized
INFO - 2020-01-25 09:05:49 --> URI Class Initialized
DEBUG - 2020-01-25 09:05:49 --> No URI present. Default controller set.
INFO - 2020-01-25 09:05:50 --> Router Class Initialized
INFO - 2020-01-25 09:05:50 --> Output Class Initialized
INFO - 2020-01-25 09:05:50 --> Security Class Initialized
DEBUG - 2020-01-25 09:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:05:50 --> Input Class Initialized
INFO - 2020-01-25 09:05:50 --> Language Class Initialized
INFO - 2020-01-25 09:05:50 --> Loader Class Initialized
INFO - 2020-01-25 09:05:51 --> Helper loaded: url_helper
INFO - 2020-01-25 09:05:51 --> Database Driver Class Initialized
DEBUG - 2020-01-25 09:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-25 09:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-25 09:05:52 --> Controller Class Initialized
INFO - 2020-01-25 09:05:52 --> Model "M_login" initialized
INFO - 2020-01-25 09:05:52 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2020-01-25 09:05:52 --> Final output sent to browser
DEBUG - 2020-01-25 09:05:52 --> Total execution time: 3.6558
INFO - 2020-01-25 09:05:57 --> Config Class Initialized
INFO - 2020-01-25 09:05:57 --> Hooks Class Initialized
DEBUG - 2020-01-25 09:05:57 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:05:57 --> Utf8 Class Initialized
INFO - 2020-01-25 09:05:57 --> URI Class Initialized
INFO - 2020-01-25 09:05:57 --> Router Class Initialized
INFO - 2020-01-25 09:05:57 --> Output Class Initialized
INFO - 2020-01-25 09:05:57 --> Security Class Initialized
DEBUG - 2020-01-25 09:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:05:57 --> Input Class Initialized
INFO - 2020-01-25 09:05:57 --> Language Class Initialized
INFO - 2020-01-25 09:05:57 --> Loader Class Initialized
INFO - 2020-01-25 09:05:57 --> Helper loaded: url_helper
INFO - 2020-01-25 09:05:57 --> Database Driver Class Initialized
DEBUG - 2020-01-25 09:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-25 09:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-25 09:05:57 --> Controller Class Initialized
INFO - 2020-01-25 09:05:58 --> Model "M_login" initialized
INFO - 2020-01-25 09:05:58 --> Config Class Initialized
INFO - 2020-01-25 09:05:58 --> Hooks Class Initialized
DEBUG - 2020-01-25 09:05:58 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:05:58 --> Utf8 Class Initialized
INFO - 2020-01-25 09:05:58 --> URI Class Initialized
INFO - 2020-01-25 09:05:58 --> Router Class Initialized
INFO - 2020-01-25 09:05:58 --> Output Class Initialized
INFO - 2020-01-25 09:05:58 --> Security Class Initialized
DEBUG - 2020-01-25 09:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:05:58 --> Input Class Initialized
INFO - 2020-01-25 09:05:58 --> Language Class Initialized
INFO - 2020-01-25 09:05:58 --> Loader Class Initialized
INFO - 2020-01-25 09:05:58 --> Helper loaded: url_helper
INFO - 2020-01-25 09:05:58 --> Database Driver Class Initialized
DEBUG - 2020-01-25 09:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-25 09:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-25 09:05:58 --> Controller Class Initialized
INFO - 2020-01-25 09:05:58 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-25 09:05:58 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2020-01-25 09:05:59 --> Final output sent to browser
DEBUG - 2020-01-25 09:05:59 --> Total execution time: 0.8875
INFO - 2020-01-25 09:05:59 --> Config Class Initialized
INFO - 2020-01-25 09:05:59 --> Config Class Initialized
INFO - 2020-01-25 09:05:59 --> Hooks Class Initialized
INFO - 2020-01-25 09:05:59 --> Hooks Class Initialized
DEBUG - 2020-01-25 09:05:59 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:05:59 --> Utf8 Class Initialized
DEBUG - 2020-01-25 09:05:59 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:05:59 --> Utf8 Class Initialized
INFO - 2020-01-25 09:05:59 --> URI Class Initialized
INFO - 2020-01-25 09:05:59 --> URI Class Initialized
INFO - 2020-01-25 09:05:59 --> Router Class Initialized
INFO - 2020-01-25 09:05:59 --> Router Class Initialized
INFO - 2020-01-25 09:05:59 --> Output Class Initialized
INFO - 2020-01-25 09:05:59 --> Security Class Initialized
INFO - 2020-01-25 09:05:59 --> Output Class Initialized
DEBUG - 2020-01-25 09:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:05:59 --> Security Class Initialized
INFO - 2020-01-25 09:05:59 --> Input Class Initialized
DEBUG - 2020-01-25 09:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:05:59 --> Input Class Initialized
INFO - 2020-01-25 09:05:59 --> Language Class Initialized
INFO - 2020-01-25 09:05:59 --> Language Class Initialized
ERROR - 2020-01-25 09:05:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-25 09:05:59 --> 404 Page Not Found: Assets/js
INFO - 2020-01-25 09:05:59 --> Config Class Initialized
INFO - 2020-01-25 09:05:59 --> Hooks Class Initialized
DEBUG - 2020-01-25 09:05:59 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:05:59 --> Utf8 Class Initialized
INFO - 2020-01-25 09:05:59 --> URI Class Initialized
INFO - 2020-01-25 09:05:59 --> Router Class Initialized
INFO - 2020-01-25 09:05:59 --> Output Class Initialized
INFO - 2020-01-25 09:05:59 --> Security Class Initialized
DEBUG - 2020-01-25 09:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:05:59 --> Input Class Initialized
INFO - 2020-01-25 09:05:59 --> Language Class Initialized
ERROR - 2020-01-25 09:05:59 --> 404 Page Not Found: Assets/js
INFO - 2020-01-25 09:06:02 --> Config Class Initialized
INFO - 2020-01-25 09:06:03 --> Hooks Class Initialized
DEBUG - 2020-01-25 09:06:03 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:06:03 --> Utf8 Class Initialized
INFO - 2020-01-25 09:06:03 --> URI Class Initialized
INFO - 2020-01-25 09:06:03 --> Router Class Initialized
INFO - 2020-01-25 09:06:03 --> Output Class Initialized
INFO - 2020-01-25 09:06:03 --> Security Class Initialized
DEBUG - 2020-01-25 09:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:06:03 --> Input Class Initialized
INFO - 2020-01-25 09:06:03 --> Language Class Initialized
INFO - 2020-01-25 09:06:03 --> Loader Class Initialized
INFO - 2020-01-25 09:06:03 --> Helper loaded: url_helper
INFO - 2020-01-25 09:06:03 --> Database Driver Class Initialized
DEBUG - 2020-01-25 09:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-25 09:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-25 09:06:03 --> Controller Class Initialized
INFO - 2020-01-25 09:06:03 --> Model "M_login" initialized
INFO - 2020-01-25 09:06:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-25 09:06:04 --> Pagination Class Initialized
INFO - 2020-01-25 09:06:04 --> Model "M_show" initialized
INFO - 2020-01-25 09:06:04 --> Helper loaded: form_helper
INFO - 2020-01-25 09:06:04 --> Form Validation Class Initialized
INFO - 2020-01-25 09:06:05 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-25 09:06:05 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-25 09:06:05 --> Final output sent to browser
DEBUG - 2020-01-25 09:06:05 --> Total execution time: 2.1492
INFO - 2020-01-25 09:06:05 --> Config Class Initialized
INFO - 2020-01-25 09:06:05 --> Config Class Initialized
INFO - 2020-01-25 09:06:05 --> Hooks Class Initialized
INFO - 2020-01-25 09:06:05 --> Hooks Class Initialized
DEBUG - 2020-01-25 09:06:05 --> UTF-8 Support Enabled
DEBUG - 2020-01-25 09:06:05 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:06:05 --> Utf8 Class Initialized
INFO - 2020-01-25 09:06:05 --> Utf8 Class Initialized
INFO - 2020-01-25 09:06:05 --> URI Class Initialized
INFO - 2020-01-25 09:06:05 --> URI Class Initialized
INFO - 2020-01-25 09:06:05 --> Router Class Initialized
INFO - 2020-01-25 09:06:05 --> Router Class Initialized
INFO - 2020-01-25 09:06:05 --> Output Class Initialized
INFO - 2020-01-25 09:06:05 --> Output Class Initialized
INFO - 2020-01-25 09:06:05 --> Security Class Initialized
INFO - 2020-01-25 09:06:05 --> Security Class Initialized
DEBUG - 2020-01-25 09:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-25 09:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:06:05 --> Input Class Initialized
INFO - 2020-01-25 09:06:05 --> Input Class Initialized
INFO - 2020-01-25 09:06:05 --> Language Class Initialized
INFO - 2020-01-25 09:06:05 --> Language Class Initialized
ERROR - 2020-01-25 09:06:05 --> 404 Page Not Found: Show/assets
ERROR - 2020-01-25 09:06:05 --> 404 Page Not Found: Show/assets
INFO - 2020-01-25 09:06:13 --> Config Class Initialized
INFO - 2020-01-25 09:06:13 --> Hooks Class Initialized
DEBUG - 2020-01-25 09:06:13 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:06:13 --> Utf8 Class Initialized
INFO - 2020-01-25 09:06:13 --> URI Class Initialized
INFO - 2020-01-25 09:06:13 --> Router Class Initialized
INFO - 2020-01-25 09:06:13 --> Output Class Initialized
INFO - 2020-01-25 09:06:13 --> Security Class Initialized
DEBUG - 2020-01-25 09:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:06:13 --> Input Class Initialized
INFO - 2020-01-25 09:06:13 --> Language Class Initialized
INFO - 2020-01-25 09:06:14 --> Loader Class Initialized
INFO - 2020-01-25 09:06:14 --> Helper loaded: url_helper
INFO - 2020-01-25 09:06:14 --> Database Driver Class Initialized
DEBUG - 2020-01-25 09:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-25 09:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-25 09:06:14 --> Controller Class Initialized
INFO - 2020-01-25 09:06:14 --> Model "M_login" initialized
INFO - 2020-01-25 09:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-25 09:06:14 --> Pagination Class Initialized
INFO - 2020-01-25 09:06:14 --> Model "M_show" initialized
INFO - 2020-01-25 09:06:14 --> Helper loaded: form_helper
INFO - 2020-01-25 09:06:14 --> Form Validation Class Initialized
INFO - 2020-01-25 09:06:14 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-25 09:06:14 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-25 09:06:14 --> Final output sent to browser
DEBUG - 2020-01-25 09:06:14 --> Total execution time: 1.3029
INFO - 2020-01-25 09:06:14 --> Config Class Initialized
INFO - 2020-01-25 09:06:14 --> Config Class Initialized
INFO - 2020-01-25 09:06:14 --> Hooks Class Initialized
INFO - 2020-01-25 09:06:14 --> Hooks Class Initialized
DEBUG - 2020-01-25 09:06:14 --> UTF-8 Support Enabled
DEBUG - 2020-01-25 09:06:14 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:06:15 --> Utf8 Class Initialized
INFO - 2020-01-25 09:06:15 --> Utf8 Class Initialized
INFO - 2020-01-25 09:06:15 --> URI Class Initialized
INFO - 2020-01-25 09:06:15 --> URI Class Initialized
INFO - 2020-01-25 09:06:15 --> Router Class Initialized
INFO - 2020-01-25 09:06:15 --> Router Class Initialized
INFO - 2020-01-25 09:06:15 --> Output Class Initialized
INFO - 2020-01-25 09:06:15 --> Output Class Initialized
INFO - 2020-01-25 09:06:15 --> Security Class Initialized
INFO - 2020-01-25 09:06:15 --> Security Class Initialized
DEBUG - 2020-01-25 09:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-25 09:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:06:15 --> Input Class Initialized
INFO - 2020-01-25 09:06:15 --> Input Class Initialized
INFO - 2020-01-25 09:06:15 --> Language Class Initialized
INFO - 2020-01-25 09:06:15 --> Language Class Initialized
ERROR - 2020-01-25 09:06:15 --> 404 Page Not Found: Show/assets
ERROR - 2020-01-25 09:06:15 --> 404 Page Not Found: Show/assets
INFO - 2020-01-25 09:06:18 --> Config Class Initialized
INFO - 2020-01-25 09:06:18 --> Hooks Class Initialized
DEBUG - 2020-01-25 09:06:18 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:06:18 --> Utf8 Class Initialized
INFO - 2020-01-25 09:06:18 --> URI Class Initialized
INFO - 2020-01-25 09:06:18 --> Router Class Initialized
INFO - 2020-01-25 09:06:18 --> Output Class Initialized
INFO - 2020-01-25 09:06:18 --> Security Class Initialized
DEBUG - 2020-01-25 09:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:06:18 --> Input Class Initialized
INFO - 2020-01-25 09:06:18 --> Language Class Initialized
INFO - 2020-01-25 09:06:19 --> Loader Class Initialized
INFO - 2020-01-25 09:06:19 --> Helper loaded: url_helper
INFO - 2020-01-25 09:06:19 --> Database Driver Class Initialized
DEBUG - 2020-01-25 09:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-25 09:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-25 09:06:19 --> Controller Class Initialized
INFO - 2020-01-25 09:06:19 --> Model "M_login" initialized
INFO - 2020-01-25 09:06:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-25 09:06:19 --> Pagination Class Initialized
INFO - 2020-01-25 09:06:19 --> Model "M_pesan" initialized
INFO - 2020-01-25 09:06:19 --> Helper loaded: form_helper
INFO - 2020-01-25 09:06:19 --> Form Validation Class Initialized
INFO - 2020-01-25 09:06:19 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-25 09:06:20 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2020-01-25 09:06:20 --> Final output sent to browser
DEBUG - 2020-01-25 09:06:20 --> Total execution time: 1.8110
INFO - 2020-01-25 09:06:20 --> Config Class Initialized
INFO - 2020-01-25 09:06:20 --> Config Class Initialized
INFO - 2020-01-25 09:06:20 --> Hooks Class Initialized
INFO - 2020-01-25 09:06:20 --> Hooks Class Initialized
DEBUG - 2020-01-25 09:06:20 --> UTF-8 Support Enabled
DEBUG - 2020-01-25 09:06:20 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:06:20 --> Utf8 Class Initialized
INFO - 2020-01-25 09:06:20 --> Utf8 Class Initialized
INFO - 2020-01-25 09:06:20 --> URI Class Initialized
INFO - 2020-01-25 09:06:20 --> URI Class Initialized
INFO - 2020-01-25 09:06:20 --> Router Class Initialized
INFO - 2020-01-25 09:06:20 --> Router Class Initialized
INFO - 2020-01-25 09:06:20 --> Output Class Initialized
INFO - 2020-01-25 09:06:20 --> Output Class Initialized
INFO - 2020-01-25 09:06:20 --> Security Class Initialized
INFO - 2020-01-25 09:06:20 --> Security Class Initialized
DEBUG - 2020-01-25 09:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-25 09:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:06:20 --> Input Class Initialized
INFO - 2020-01-25 09:06:20 --> Input Class Initialized
INFO - 2020-01-25 09:06:20 --> Language Class Initialized
INFO - 2020-01-25 09:06:20 --> Language Class Initialized
ERROR - 2020-01-25 09:06:20 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2020-01-25 09:06:20 --> 404 Page Not Found: Pemesanan/assets
INFO - 2020-01-25 09:06:24 --> Config Class Initialized
INFO - 2020-01-25 09:06:24 --> Hooks Class Initialized
DEBUG - 2020-01-25 09:06:24 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:06:24 --> Utf8 Class Initialized
INFO - 2020-01-25 09:06:24 --> URI Class Initialized
INFO - 2020-01-25 09:06:24 --> Router Class Initialized
INFO - 2020-01-25 09:06:24 --> Output Class Initialized
INFO - 2020-01-25 09:06:24 --> Security Class Initialized
DEBUG - 2020-01-25 09:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:06:24 --> Input Class Initialized
INFO - 2020-01-25 09:06:24 --> Language Class Initialized
INFO - 2020-01-25 09:06:24 --> Loader Class Initialized
INFO - 2020-01-25 09:06:24 --> Helper loaded: url_helper
INFO - 2020-01-25 09:06:24 --> Database Driver Class Initialized
DEBUG - 2020-01-25 09:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-25 09:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-25 09:06:24 --> Controller Class Initialized
INFO - 2020-01-25 09:06:24 --> Model "M_login" initialized
INFO - 2020-01-25 09:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-25 09:06:24 --> Pagination Class Initialized
INFO - 2020-01-25 09:06:25 --> Model "M_pesan" initialized
INFO - 2020-01-25 09:06:25 --> Helper loaded: form_helper
INFO - 2020-01-25 09:06:25 --> Form Validation Class Initialized
INFO - 2020-01-25 09:06:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-25 09:06:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2020-01-25 09:06:25 --> Final output sent to browser
DEBUG - 2020-01-25 09:06:25 --> Total execution time: 0.8640
INFO - 2020-01-25 09:06:25 --> Config Class Initialized
INFO - 2020-01-25 09:06:25 --> Config Class Initialized
INFO - 2020-01-25 09:06:25 --> Hooks Class Initialized
INFO - 2020-01-25 09:06:25 --> Hooks Class Initialized
DEBUG - 2020-01-25 09:06:25 --> UTF-8 Support Enabled
DEBUG - 2020-01-25 09:06:25 --> UTF-8 Support Enabled
INFO - 2020-01-25 09:06:25 --> Utf8 Class Initialized
INFO - 2020-01-25 09:06:25 --> Utf8 Class Initialized
INFO - 2020-01-25 09:06:25 --> URI Class Initialized
INFO - 2020-01-25 09:06:25 --> URI Class Initialized
INFO - 2020-01-25 09:06:25 --> Router Class Initialized
INFO - 2020-01-25 09:06:25 --> Router Class Initialized
INFO - 2020-01-25 09:06:25 --> Output Class Initialized
INFO - 2020-01-25 09:06:25 --> Output Class Initialized
INFO - 2020-01-25 09:06:25 --> Security Class Initialized
INFO - 2020-01-25 09:06:25 --> Security Class Initialized
DEBUG - 2020-01-25 09:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-25 09:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-25 09:06:25 --> Input Class Initialized
INFO - 2020-01-25 09:06:25 --> Input Class Initialized
INFO - 2020-01-25 09:06:25 --> Language Class Initialized
INFO - 2020-01-25 09:06:25 --> Language Class Initialized
ERROR - 2020-01-25 09:06:25 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2020-01-25 09:06:25 --> 404 Page Not Found: Pemesanan/assets
