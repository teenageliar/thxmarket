<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-13 03:54:08 --> Config Class Initialized
INFO - 2020-02-13 03:54:08 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:54:08 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:54:08 --> Utf8 Class Initialized
INFO - 2020-02-13 03:54:08 --> URI Class Initialized
INFO - 2020-02-13 03:54:08 --> Router Class Initialized
INFO - 2020-02-13 03:54:08 --> Output Class Initialized
INFO - 2020-02-13 03:54:08 --> Security Class Initialized
DEBUG - 2020-02-13 03:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:54:08 --> Input Class Initialized
INFO - 2020-02-13 03:54:08 --> Language Class Initialized
INFO - 2020-02-13 03:54:09 --> Loader Class Initialized
INFO - 2020-02-13 03:54:09 --> Helper loaded: url_helper
INFO - 2020-02-13 03:54:09 --> Helper loaded: string_helper
INFO - 2020-02-13 03:54:09 --> Database Driver Class Initialized
DEBUG - 2020-02-13 03:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 03:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:54:09 --> Controller Class Initialized
INFO - 2020-02-13 03:54:10 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:54:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:54:10 --> Model "M_pesan" initialized
INFO - 2020-02-13 03:54:10 --> Helper loaded: form_helper
INFO - 2020-02-13 03:54:10 --> Form Validation Class Initialized
INFO - 2020-02-13 03:54:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 03:54:10 --> Final output sent to browser
DEBUG - 2020-02-13 03:54:11 --> Total execution time: 2.9861
INFO - 2020-02-13 03:54:11 --> Config Class Initialized
INFO - 2020-02-13 03:54:11 --> Config Class Initialized
INFO - 2020-02-13 03:54:11 --> Hooks Class Initialized
INFO - 2020-02-13 03:54:11 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:54:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:54:11 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:54:11 --> Utf8 Class Initialized
INFO - 2020-02-13 03:54:11 --> Utf8 Class Initialized
INFO - 2020-02-13 03:54:12 --> URI Class Initialized
INFO - 2020-02-13 03:54:12 --> URI Class Initialized
INFO - 2020-02-13 03:54:12 --> Router Class Initialized
INFO - 2020-02-13 03:54:12 --> Router Class Initialized
INFO - 2020-02-13 03:54:12 --> Output Class Initialized
INFO - 2020-02-13 03:54:12 --> Output Class Initialized
INFO - 2020-02-13 03:54:12 --> Security Class Initialized
INFO - 2020-02-13 03:54:12 --> Security Class Initialized
DEBUG - 2020-02-13 03:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:54:12 --> Input Class Initialized
INFO - 2020-02-13 03:54:12 --> Input Class Initialized
INFO - 2020-02-13 03:54:12 --> Language Class Initialized
INFO - 2020-02-13 03:54:12 --> Language Class Initialized
INFO - 2020-02-13 03:54:12 --> Loader Class Initialized
INFO - 2020-02-13 03:54:12 --> Loader Class Initialized
INFO - 2020-02-13 03:54:12 --> Helper loaded: url_helper
INFO - 2020-02-13 03:54:12 --> Helper loaded: url_helper
INFO - 2020-02-13 03:54:12 --> Helper loaded: string_helper
INFO - 2020-02-13 03:54:12 --> Helper loaded: string_helper
INFO - 2020-02-13 03:54:12 --> Database Driver Class Initialized
INFO - 2020-02-13 03:54:12 --> Database Driver Class Initialized
DEBUG - 2020-02-13 03:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 03:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 03:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:54:12 --> Controller Class Initialized
INFO - 2020-02-13 03:54:12 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:54:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:54:12 --> Model "M_pesan" initialized
INFO - 2020-02-13 03:54:12 --> Helper loaded: form_helper
INFO - 2020-02-13 03:54:12 --> Form Validation Class Initialized
ERROR - 2020-02-13 03:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 03:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 03:54:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 03:54:12 --> Final output sent to browser
DEBUG - 2020-02-13 03:54:12 --> Total execution time: 1.1249
INFO - 2020-02-13 03:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:54:13 --> Controller Class Initialized
INFO - 2020-02-13 03:54:13 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:54:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:54:13 --> Model "M_pesan" initialized
INFO - 2020-02-13 03:54:13 --> Helper loaded: form_helper
INFO - 2020-02-13 03:54:13 --> Form Validation Class Initialized
ERROR - 2020-02-13 03:54:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 03:54:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 03:54:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 03:54:13 --> Final output sent to browser
DEBUG - 2020-02-13 03:54:13 --> Total execution time: 1.3887
INFO - 2020-02-13 03:55:39 --> Config Class Initialized
INFO - 2020-02-13 03:55:40 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:55:40 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:40 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:40 --> URI Class Initialized
INFO - 2020-02-13 03:55:40 --> Router Class Initialized
INFO - 2020-02-13 03:55:40 --> Output Class Initialized
INFO - 2020-02-13 03:55:40 --> Security Class Initialized
DEBUG - 2020-02-13 03:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:40 --> Input Class Initialized
INFO - 2020-02-13 03:55:40 --> Language Class Initialized
INFO - 2020-02-13 03:55:40 --> Loader Class Initialized
INFO - 2020-02-13 03:55:40 --> Helper loaded: url_helper
INFO - 2020-02-13 03:55:40 --> Helper loaded: string_helper
INFO - 2020-02-13 03:55:40 --> Database Driver Class Initialized
DEBUG - 2020-02-13 03:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 03:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:55:40 --> Controller Class Initialized
INFO - 2020-02-13 03:55:40 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:55:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:55:40 --> Model "M_pesan" initialized
INFO - 2020-02-13 03:55:40 --> Helper loaded: form_helper
INFO - 2020-02-13 03:55:40 --> Form Validation Class Initialized
INFO - 2020-02-13 03:55:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 03:55:40 --> Final output sent to browser
DEBUG - 2020-02-13 03:55:40 --> Total execution time: 0.5840
INFO - 2020-02-13 03:55:40 --> Config Class Initialized
INFO - 2020-02-13 03:55:40 --> Config Class Initialized
INFO - 2020-02-13 03:55:40 --> Config Class Initialized
INFO - 2020-02-13 03:55:40 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:40 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:40 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:40 --> Config Class Initialized
INFO - 2020-02-13 03:55:40 --> Config Class Initialized
INFO - 2020-02-13 03:55:40 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:40 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:55:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:55:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:55:40 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:40 --> Config Class Initialized
INFO - 2020-02-13 03:55:40 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:40 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:40 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:40 --> Utf8 Class Initialized
DEBUG - 2020-02-13 03:55:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:55:40 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:40 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:40 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:40 --> URI Class Initialized
INFO - 2020-02-13 03:55:40 --> URI Class Initialized
DEBUG - 2020-02-13 03:55:40 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:40 --> URI Class Initialized
INFO - 2020-02-13 03:55:40 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:40 --> URI Class Initialized
INFO - 2020-02-13 03:55:40 --> Router Class Initialized
INFO - 2020-02-13 03:55:40 --> Router Class Initialized
INFO - 2020-02-13 03:55:40 --> Router Class Initialized
INFO - 2020-02-13 03:55:40 --> URI Class Initialized
INFO - 2020-02-13 03:55:40 --> Router Class Initialized
INFO - 2020-02-13 03:55:40 --> Output Class Initialized
INFO - 2020-02-13 03:55:40 --> URI Class Initialized
INFO - 2020-02-13 03:55:40 --> Router Class Initialized
INFO - 2020-02-13 03:55:40 --> Output Class Initialized
INFO - 2020-02-13 03:55:40 --> Output Class Initialized
INFO - 2020-02-13 03:55:40 --> Security Class Initialized
INFO - 2020-02-13 03:55:40 --> Security Class Initialized
INFO - 2020-02-13 03:55:40 --> Security Class Initialized
INFO - 2020-02-13 03:55:40 --> Output Class Initialized
INFO - 2020-02-13 03:55:40 --> Output Class Initialized
INFO - 2020-02-13 03:55:40 --> Router Class Initialized
INFO - 2020-02-13 03:55:40 --> Security Class Initialized
DEBUG - 2020-02-13 03:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:40 --> Security Class Initialized
INFO - 2020-02-13 03:55:40 --> Output Class Initialized
DEBUG - 2020-02-13 03:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:40 --> Input Class Initialized
INFO - 2020-02-13 03:55:40 --> Input Class Initialized
INFO - 2020-02-13 03:55:40 --> Input Class Initialized
DEBUG - 2020-02-13 03:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:40 --> Security Class Initialized
INFO - 2020-02-13 03:55:40 --> Input Class Initialized
INFO - 2020-02-13 03:55:40 --> Input Class Initialized
INFO - 2020-02-13 03:55:40 --> Language Class Initialized
INFO - 2020-02-13 03:55:40 --> Language Class Initialized
INFO - 2020-02-13 03:55:40 --> Language Class Initialized
DEBUG - 2020-02-13 03:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:40 --> Input Class Initialized
INFO - 2020-02-13 03:55:40 --> Language Class Initialized
ERROR - 2020-02-13 03:55:40 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 03:55:40 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 03:55:40 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 03:55:40 --> Language Class Initialized
INFO - 2020-02-13 03:55:40 --> Language Class Initialized
ERROR - 2020-02-13 03:55:40 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 03:55:40 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 03:55:40 --> Loader Class Initialized
INFO - 2020-02-13 03:55:40 --> Config Class Initialized
INFO - 2020-02-13 03:55:40 --> Helper loaded: url_helper
INFO - 2020-02-13 03:55:41 --> Config Class Initialized
INFO - 2020-02-13 03:55:41 --> Config Class Initialized
INFO - 2020-02-13 03:55:41 --> Config Class Initialized
INFO - 2020-02-13 03:55:41 --> Config Class Initialized
INFO - 2020-02-13 03:55:41 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:41 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:41 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:41 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:41 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:41 --> Helper loaded: string_helper
DEBUG - 2020-02-13 03:55:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:55:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:55:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:55:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:55:41 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:41 --> Database Driver Class Initialized
INFO - 2020-02-13 03:55:41 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:41 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:41 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:41 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:41 --> Utf8 Class Initialized
DEBUG - 2020-02-13 03:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 03:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:55:41 --> URI Class Initialized
INFO - 2020-02-13 03:55:41 --> URI Class Initialized
INFO - 2020-02-13 03:55:41 --> URI Class Initialized
INFO - 2020-02-13 03:55:41 --> URI Class Initialized
INFO - 2020-02-13 03:55:41 --> URI Class Initialized
INFO - 2020-02-13 03:55:41 --> Router Class Initialized
INFO - 2020-02-13 03:55:41 --> Router Class Initialized
INFO - 2020-02-13 03:55:41 --> Router Class Initialized
INFO - 2020-02-13 03:55:41 --> Controller Class Initialized
INFO - 2020-02-13 03:55:41 --> Router Class Initialized
INFO - 2020-02-13 03:55:41 --> Router Class Initialized
INFO - 2020-02-13 03:55:41 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:55:41 --> Output Class Initialized
INFO - 2020-02-13 03:55:41 --> Output Class Initialized
INFO - 2020-02-13 03:55:41 --> Output Class Initialized
INFO - 2020-02-13 03:55:41 --> Output Class Initialized
INFO - 2020-02-13 03:55:41 --> Output Class Initialized
INFO - 2020-02-13 03:55:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:55:41 --> Security Class Initialized
INFO - 2020-02-13 03:55:41 --> Security Class Initialized
INFO - 2020-02-13 03:55:41 --> Security Class Initialized
INFO - 2020-02-13 03:55:41 --> Security Class Initialized
INFO - 2020-02-13 03:55:41 --> Security Class Initialized
DEBUG - 2020-02-13 03:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:41 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 03:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:41 --> Input Class Initialized
INFO - 2020-02-13 03:55:41 --> Input Class Initialized
INFO - 2020-02-13 03:55:41 --> Input Class Initialized
INFO - 2020-02-13 03:55:41 --> Input Class Initialized
INFO - 2020-02-13 03:55:41 --> Input Class Initialized
INFO - 2020-02-13 03:55:41 --> Helper loaded: form_helper
INFO - 2020-02-13 03:55:41 --> Language Class Initialized
INFO - 2020-02-13 03:55:41 --> Language Class Initialized
INFO - 2020-02-13 03:55:41 --> Language Class Initialized
INFO - 2020-02-13 03:55:41 --> Language Class Initialized
INFO - 2020-02-13 03:55:41 --> Language Class Initialized
INFO - 2020-02-13 03:55:41 --> Form Validation Class Initialized
ERROR - 2020-02-13 03:55:41 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 03:55:41 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 03:55:41 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-13 03:55:41 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 03:55:41 --> Loader Class Initialized
ERROR - 2020-02-13 03:55:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 03:55:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 03:55:41 --> Helper loaded: url_helper
INFO - 2020-02-13 03:55:41 --> Config Class Initialized
INFO - 2020-02-13 03:55:41 --> Config Class Initialized
INFO - 2020-02-13 03:55:41 --> Config Class Initialized
INFO - 2020-02-13 03:55:41 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:41 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:41 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 03:55:41 --> Helper loaded: string_helper
INFO - 2020-02-13 03:55:41 --> Final output sent to browser
DEBUG - 2020-02-13 03:55:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:55:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:55:41 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:41 --> Database Driver Class Initialized
INFO - 2020-02-13 03:55:41 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:41 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:41 --> Utf8 Class Initialized
DEBUG - 2020-02-13 03:55:41 --> Total execution time: 0.6209
DEBUG - 2020-02-13 03:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 03:55:41 --> URI Class Initialized
INFO - 2020-02-13 03:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:55:41 --> URI Class Initialized
INFO - 2020-02-13 03:55:41 --> URI Class Initialized
INFO - 2020-02-13 03:55:41 --> Controller Class Initialized
INFO - 2020-02-13 03:55:41 --> Router Class Initialized
INFO - 2020-02-13 03:55:41 --> Router Class Initialized
INFO - 2020-02-13 03:55:41 --> Router Class Initialized
INFO - 2020-02-13 03:55:41 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:55:41 --> Output Class Initialized
INFO - 2020-02-13 03:55:41 --> Output Class Initialized
INFO - 2020-02-13 03:55:41 --> Output Class Initialized
INFO - 2020-02-13 03:55:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:55:41 --> Security Class Initialized
INFO - 2020-02-13 03:55:41 --> Security Class Initialized
INFO - 2020-02-13 03:55:41 --> Security Class Initialized
INFO - 2020-02-13 03:55:41 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 03:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:41 --> Input Class Initialized
INFO - 2020-02-13 03:55:41 --> Input Class Initialized
INFO - 2020-02-13 03:55:41 --> Input Class Initialized
INFO - 2020-02-13 03:55:41 --> Helper loaded: form_helper
INFO - 2020-02-13 03:55:41 --> Form Validation Class Initialized
INFO - 2020-02-13 03:55:41 --> Language Class Initialized
INFO - 2020-02-13 03:55:41 --> Language Class Initialized
INFO - 2020-02-13 03:55:41 --> Language Class Initialized
ERROR - 2020-02-13 03:55:41 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 03:55:41 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 03:55:41 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 03:55:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 03:55:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 03:55:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 03:55:41 --> Config Class Initialized
INFO - 2020-02-13 03:55:41 --> Hooks Class Initialized
INFO - 2020-02-13 03:55:41 --> Final output sent to browser
DEBUG - 2020-02-13 03:55:41 --> Total execution time: 0.5985
DEBUG - 2020-02-13 03:55:41 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:41 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:41 --> URI Class Initialized
INFO - 2020-02-13 03:55:41 --> Router Class Initialized
INFO - 2020-02-13 03:55:41 --> Output Class Initialized
INFO - 2020-02-13 03:55:41 --> Security Class Initialized
DEBUG - 2020-02-13 03:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:41 --> Input Class Initialized
INFO - 2020-02-13 03:55:41 --> Language Class Initialized
ERROR - 2020-02-13 03:55:41 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 03:55:41 --> Config Class Initialized
INFO - 2020-02-13 03:55:41 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:55:41 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:41 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:41 --> URI Class Initialized
INFO - 2020-02-13 03:55:41 --> Router Class Initialized
INFO - 2020-02-13 03:55:41 --> Output Class Initialized
INFO - 2020-02-13 03:55:41 --> Security Class Initialized
DEBUG - 2020-02-13 03:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:41 --> Input Class Initialized
INFO - 2020-02-13 03:55:42 --> Language Class Initialized
ERROR - 2020-02-13 03:55:42 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 03:55:42 --> Config Class Initialized
INFO - 2020-02-13 03:55:42 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:55:42 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:42 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:42 --> URI Class Initialized
INFO - 2020-02-13 03:55:42 --> Router Class Initialized
INFO - 2020-02-13 03:55:42 --> Output Class Initialized
INFO - 2020-02-13 03:55:42 --> Security Class Initialized
DEBUG - 2020-02-13 03:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:42 --> Input Class Initialized
INFO - 2020-02-13 03:55:42 --> Language Class Initialized
ERROR - 2020-02-13 03:55:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 03:55:42 --> Config Class Initialized
INFO - 2020-02-13 03:55:42 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:55:42 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:42 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:42 --> URI Class Initialized
INFO - 2020-02-13 03:55:42 --> Router Class Initialized
INFO - 2020-02-13 03:55:42 --> Output Class Initialized
INFO - 2020-02-13 03:55:42 --> Security Class Initialized
DEBUG - 2020-02-13 03:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:42 --> Input Class Initialized
INFO - 2020-02-13 03:55:42 --> Language Class Initialized
ERROR - 2020-02-13 03:55:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 03:55:42 --> Config Class Initialized
INFO - 2020-02-13 03:55:42 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:55:42 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:42 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:42 --> URI Class Initialized
INFO - 2020-02-13 03:55:42 --> Router Class Initialized
INFO - 2020-02-13 03:55:42 --> Output Class Initialized
INFO - 2020-02-13 03:55:42 --> Security Class Initialized
DEBUG - 2020-02-13 03:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:42 --> Input Class Initialized
INFO - 2020-02-13 03:55:42 --> Language Class Initialized
ERROR - 2020-02-13 03:55:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 03:55:42 --> Config Class Initialized
INFO - 2020-02-13 03:55:42 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:55:42 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:42 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:42 --> URI Class Initialized
INFO - 2020-02-13 03:55:42 --> Router Class Initialized
INFO - 2020-02-13 03:55:42 --> Output Class Initialized
INFO - 2020-02-13 03:55:42 --> Security Class Initialized
DEBUG - 2020-02-13 03:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:43 --> Input Class Initialized
INFO - 2020-02-13 03:55:43 --> Language Class Initialized
ERROR - 2020-02-13 03:55:43 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 03:55:43 --> Config Class Initialized
INFO - 2020-02-13 03:55:43 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:55:43 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:43 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:43 --> URI Class Initialized
INFO - 2020-02-13 03:55:43 --> Router Class Initialized
INFO - 2020-02-13 03:55:43 --> Output Class Initialized
INFO - 2020-02-13 03:55:43 --> Security Class Initialized
DEBUG - 2020-02-13 03:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:43 --> Input Class Initialized
INFO - 2020-02-13 03:55:43 --> Language Class Initialized
ERROR - 2020-02-13 03:55:43 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 03:55:43 --> Config Class Initialized
INFO - 2020-02-13 03:55:43 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:55:43 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:43 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:43 --> URI Class Initialized
INFO - 2020-02-13 03:55:43 --> Router Class Initialized
INFO - 2020-02-13 03:55:43 --> Output Class Initialized
INFO - 2020-02-13 03:55:43 --> Security Class Initialized
DEBUG - 2020-02-13 03:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:43 --> Input Class Initialized
INFO - 2020-02-13 03:55:43 --> Language Class Initialized
ERROR - 2020-02-13 03:55:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 03:55:43 --> Config Class Initialized
INFO - 2020-02-13 03:55:43 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:55:43 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:55:43 --> Utf8 Class Initialized
INFO - 2020-02-13 03:55:43 --> URI Class Initialized
INFO - 2020-02-13 03:55:43 --> Router Class Initialized
INFO - 2020-02-13 03:55:43 --> Output Class Initialized
INFO - 2020-02-13 03:55:43 --> Security Class Initialized
DEBUG - 2020-02-13 03:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:55:43 --> Input Class Initialized
INFO - 2020-02-13 03:55:43 --> Language Class Initialized
ERROR - 2020-02-13 03:55:43 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 03:57:06 --> Config Class Initialized
INFO - 2020-02-13 03:57:06 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:57:06 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:57:06 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:06 --> URI Class Initialized
INFO - 2020-02-13 03:57:06 --> Router Class Initialized
INFO - 2020-02-13 03:57:06 --> Output Class Initialized
INFO - 2020-02-13 03:57:06 --> Security Class Initialized
DEBUG - 2020-02-13 03:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:07 --> Input Class Initialized
INFO - 2020-02-13 03:57:07 --> Language Class Initialized
INFO - 2020-02-13 03:57:07 --> Loader Class Initialized
INFO - 2020-02-13 03:57:07 --> Helper loaded: url_helper
INFO - 2020-02-13 03:57:07 --> Helper loaded: string_helper
INFO - 2020-02-13 03:57:07 --> Database Driver Class Initialized
DEBUG - 2020-02-13 03:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 03:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:57:07 --> Controller Class Initialized
INFO - 2020-02-13 03:57:07 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:57:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:57:07 --> Model "M_pesan" initialized
INFO - 2020-02-13 03:57:07 --> Helper loaded: form_helper
INFO - 2020-02-13 03:57:08 --> Form Validation Class Initialized
INFO - 2020-02-13 03:57:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 03:57:08 --> Final output sent to browser
DEBUG - 2020-02-13 03:57:08 --> Total execution time: 1.9289
INFO - 2020-02-13 03:57:08 --> Config Class Initialized
INFO - 2020-02-13 03:57:08 --> Config Class Initialized
INFO - 2020-02-13 03:57:08 --> Config Class Initialized
INFO - 2020-02-13 03:57:08 --> Hooks Class Initialized
INFO - 2020-02-13 03:57:08 --> Hooks Class Initialized
INFO - 2020-02-13 03:57:08 --> Hooks Class Initialized
INFO - 2020-02-13 03:57:08 --> Config Class Initialized
INFO - 2020-02-13 03:57:08 --> Config Class Initialized
INFO - 2020-02-13 03:57:08 --> Config Class Initialized
INFO - 2020-02-13 03:57:08 --> Hooks Class Initialized
INFO - 2020-02-13 03:57:08 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:57:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:57:08 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:57:08 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:57:08 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:57:08 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:08 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:08 --> Utf8 Class Initialized
DEBUG - 2020-02-13 03:57:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:57:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:57:08 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:57:08 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:08 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:08 --> URI Class Initialized
INFO - 2020-02-13 03:57:08 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:08 --> URI Class Initialized
INFO - 2020-02-13 03:57:08 --> URI Class Initialized
INFO - 2020-02-13 03:57:08 --> URI Class Initialized
INFO - 2020-02-13 03:57:08 --> Router Class Initialized
INFO - 2020-02-13 03:57:08 --> Router Class Initialized
INFO - 2020-02-13 03:57:08 --> URI Class Initialized
INFO - 2020-02-13 03:57:08 --> URI Class Initialized
INFO - 2020-02-13 03:57:08 --> Router Class Initialized
INFO - 2020-02-13 03:57:08 --> Router Class Initialized
INFO - 2020-02-13 03:57:08 --> Output Class Initialized
INFO - 2020-02-13 03:57:08 --> Router Class Initialized
INFO - 2020-02-13 03:57:08 --> Router Class Initialized
INFO - 2020-02-13 03:57:08 --> Output Class Initialized
INFO - 2020-02-13 03:57:08 --> Output Class Initialized
INFO - 2020-02-13 03:57:08 --> Security Class Initialized
INFO - 2020-02-13 03:57:08 --> Output Class Initialized
INFO - 2020-02-13 03:57:08 --> Output Class Initialized
INFO - 2020-02-13 03:57:08 --> Security Class Initialized
INFO - 2020-02-13 03:57:08 --> Security Class Initialized
INFO - 2020-02-13 03:57:08 --> Output Class Initialized
DEBUG - 2020-02-13 03:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:08 --> Security Class Initialized
DEBUG - 2020-02-13 03:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:08 --> Security Class Initialized
INFO - 2020-02-13 03:57:08 --> Security Class Initialized
INFO - 2020-02-13 03:57:08 --> Input Class Initialized
INFO - 2020-02-13 03:57:08 --> Input Class Initialized
INFO - 2020-02-13 03:57:08 --> Input Class Initialized
DEBUG - 2020-02-13 03:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:08 --> Input Class Initialized
INFO - 2020-02-13 03:57:08 --> Input Class Initialized
INFO - 2020-02-13 03:57:08 --> Input Class Initialized
INFO - 2020-02-13 03:57:08 --> Language Class Initialized
INFO - 2020-02-13 03:57:08 --> Language Class Initialized
INFO - 2020-02-13 03:57:08 --> Language Class Initialized
INFO - 2020-02-13 03:57:08 --> Language Class Initialized
INFO - 2020-02-13 03:57:08 --> Language Class Initialized
INFO - 2020-02-13 03:57:08 --> Language Class Initialized
INFO - 2020-02-13 03:57:08 --> Loader Class Initialized
INFO - 2020-02-13 03:57:08 --> Loader Class Initialized
ERROR - 2020-02-13 03:57:08 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 03:57:08 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-13 03:57:08 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 03:57:08 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 03:57:08 --> Helper loaded: url_helper
INFO - 2020-02-13 03:57:08 --> Helper loaded: url_helper
INFO - 2020-02-13 03:57:08 --> Config Class Initialized
INFO - 2020-02-13 03:57:08 --> Helper loaded: string_helper
INFO - 2020-02-13 03:57:08 --> Helper loaded: string_helper
INFO - 2020-02-13 03:57:08 --> Config Class Initialized
INFO - 2020-02-13 03:57:08 --> Config Class Initialized
INFO - 2020-02-13 03:57:08 --> Config Class Initialized
INFO - 2020-02-13 03:57:08 --> Hooks Class Initialized
INFO - 2020-02-13 03:57:08 --> Hooks Class Initialized
INFO - 2020-02-13 03:57:08 --> Hooks Class Initialized
INFO - 2020-02-13 03:57:08 --> Hooks Class Initialized
INFO - 2020-02-13 03:57:08 --> Database Driver Class Initialized
INFO - 2020-02-13 03:57:08 --> Database Driver Class Initialized
DEBUG - 2020-02-13 03:57:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:57:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:57:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:57:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 03:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 03:57:08 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:08 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:08 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:57:08 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:08 --> Controller Class Initialized
INFO - 2020-02-13 03:57:08 --> URI Class Initialized
INFO - 2020-02-13 03:57:08 --> URI Class Initialized
INFO - 2020-02-13 03:57:08 --> URI Class Initialized
INFO - 2020-02-13 03:57:08 --> URI Class Initialized
INFO - 2020-02-13 03:57:08 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:57:08 --> Router Class Initialized
INFO - 2020-02-13 03:57:08 --> Router Class Initialized
INFO - 2020-02-13 03:57:08 --> Router Class Initialized
INFO - 2020-02-13 03:57:08 --> Router Class Initialized
INFO - 2020-02-13 03:57:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:57:09 --> Output Class Initialized
INFO - 2020-02-13 03:57:09 --> Output Class Initialized
INFO - 2020-02-13 03:57:09 --> Output Class Initialized
INFO - 2020-02-13 03:57:09 --> Output Class Initialized
INFO - 2020-02-13 03:57:09 --> Security Class Initialized
INFO - 2020-02-13 03:57:09 --> Security Class Initialized
INFO - 2020-02-13 03:57:09 --> Security Class Initialized
INFO - 2020-02-13 03:57:09 --> Security Class Initialized
INFO - 2020-02-13 03:57:09 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 03:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:09 --> Helper loaded: form_helper
INFO - 2020-02-13 03:57:09 --> Input Class Initialized
INFO - 2020-02-13 03:57:09 --> Input Class Initialized
INFO - 2020-02-13 03:57:09 --> Form Validation Class Initialized
INFO - 2020-02-13 03:57:09 --> Input Class Initialized
INFO - 2020-02-13 03:57:09 --> Input Class Initialized
INFO - 2020-02-13 03:57:09 --> Language Class Initialized
INFO - 2020-02-13 03:57:09 --> Language Class Initialized
INFO - 2020-02-13 03:57:09 --> Language Class Initialized
INFO - 2020-02-13 03:57:09 --> Language Class Initialized
ERROR - 2020-02-13 03:57:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 03:57:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 03:57:09 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 03:57:09 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 03:57:09 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 03:57:09 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 03:57:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 03:57:09 --> Config Class Initialized
INFO - 2020-02-13 03:57:09 --> Config Class Initialized
INFO - 2020-02-13 03:57:09 --> Config Class Initialized
INFO - 2020-02-13 03:57:09 --> Config Class Initialized
INFO - 2020-02-13 03:57:09 --> Hooks Class Initialized
INFO - 2020-02-13 03:57:09 --> Hooks Class Initialized
INFO - 2020-02-13 03:57:09 --> Hooks Class Initialized
INFO - 2020-02-13 03:57:09 --> Final output sent to browser
INFO - 2020-02-13 03:57:09 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:57:09 --> Total execution time: 0.8880
DEBUG - 2020-02-13 03:57:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:57:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:57:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:57:09 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:57:09 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:09 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:09 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:09 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:57:09 --> Controller Class Initialized
INFO - 2020-02-13 03:57:09 --> URI Class Initialized
INFO - 2020-02-13 03:57:09 --> URI Class Initialized
INFO - 2020-02-13 03:57:09 --> URI Class Initialized
INFO - 2020-02-13 03:57:09 --> URI Class Initialized
INFO - 2020-02-13 03:57:09 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:57:09 --> Router Class Initialized
INFO - 2020-02-13 03:57:09 --> Router Class Initialized
INFO - 2020-02-13 03:57:09 --> Router Class Initialized
INFO - 2020-02-13 03:57:09 --> Router Class Initialized
INFO - 2020-02-13 03:57:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:57:09 --> Output Class Initialized
INFO - 2020-02-13 03:57:09 --> Output Class Initialized
INFO - 2020-02-13 03:57:09 --> Output Class Initialized
INFO - 2020-02-13 03:57:09 --> Output Class Initialized
INFO - 2020-02-13 03:57:09 --> Security Class Initialized
INFO - 2020-02-13 03:57:09 --> Security Class Initialized
INFO - 2020-02-13 03:57:09 --> Model "M_pesan" initialized
INFO - 2020-02-13 03:57:09 --> Security Class Initialized
INFO - 2020-02-13 03:57:09 --> Security Class Initialized
DEBUG - 2020-02-13 03:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:09 --> Helper loaded: form_helper
DEBUG - 2020-02-13 03:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:09 --> Form Validation Class Initialized
INFO - 2020-02-13 03:57:09 --> Input Class Initialized
INFO - 2020-02-13 03:57:09 --> Input Class Initialized
INFO - 2020-02-13 03:57:09 --> Input Class Initialized
INFO - 2020-02-13 03:57:09 --> Input Class Initialized
INFO - 2020-02-13 03:57:09 --> Language Class Initialized
INFO - 2020-02-13 03:57:09 --> Language Class Initialized
INFO - 2020-02-13 03:57:09 --> Language Class Initialized
INFO - 2020-02-13 03:57:09 --> Language Class Initialized
ERROR - 2020-02-13 03:57:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 03:57:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 03:57:09 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 03:57:09 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 03:57:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 03:57:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 03:57:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 03:57:09 --> Final output sent to browser
INFO - 2020-02-13 03:57:09 --> Config Class Initialized
DEBUG - 2020-02-13 03:57:09 --> Total execution time: 1.2153
INFO - 2020-02-13 03:57:09 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:57:09 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:57:09 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:09 --> URI Class Initialized
INFO - 2020-02-13 03:57:09 --> Router Class Initialized
INFO - 2020-02-13 03:57:09 --> Output Class Initialized
INFO - 2020-02-13 03:57:09 --> Security Class Initialized
DEBUG - 2020-02-13 03:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:10 --> Input Class Initialized
INFO - 2020-02-13 03:57:10 --> Language Class Initialized
ERROR - 2020-02-13 03:57:10 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 03:57:10 --> Config Class Initialized
INFO - 2020-02-13 03:57:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:57:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:57:10 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:10 --> URI Class Initialized
INFO - 2020-02-13 03:57:10 --> Router Class Initialized
INFO - 2020-02-13 03:57:10 --> Output Class Initialized
INFO - 2020-02-13 03:57:10 --> Security Class Initialized
DEBUG - 2020-02-13 03:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:10 --> Input Class Initialized
INFO - 2020-02-13 03:57:10 --> Language Class Initialized
ERROR - 2020-02-13 03:57:10 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 03:57:10 --> Config Class Initialized
INFO - 2020-02-13 03:57:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:57:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:57:10 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:10 --> URI Class Initialized
INFO - 2020-02-13 03:57:10 --> Router Class Initialized
INFO - 2020-02-13 03:57:10 --> Output Class Initialized
INFO - 2020-02-13 03:57:10 --> Security Class Initialized
DEBUG - 2020-02-13 03:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:10 --> Input Class Initialized
INFO - 2020-02-13 03:57:10 --> Language Class Initialized
ERROR - 2020-02-13 03:57:10 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 03:57:10 --> Config Class Initialized
INFO - 2020-02-13 03:57:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:57:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:57:10 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:10 --> URI Class Initialized
INFO - 2020-02-13 03:57:10 --> Router Class Initialized
INFO - 2020-02-13 03:57:10 --> Output Class Initialized
INFO - 2020-02-13 03:57:10 --> Security Class Initialized
DEBUG - 2020-02-13 03:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:10 --> Input Class Initialized
INFO - 2020-02-13 03:57:10 --> Language Class Initialized
ERROR - 2020-02-13 03:57:10 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 03:57:10 --> Config Class Initialized
INFO - 2020-02-13 03:57:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:57:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:57:10 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:11 --> URI Class Initialized
INFO - 2020-02-13 03:57:11 --> Router Class Initialized
INFO - 2020-02-13 03:57:11 --> Output Class Initialized
INFO - 2020-02-13 03:57:11 --> Security Class Initialized
DEBUG - 2020-02-13 03:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:11 --> Input Class Initialized
INFO - 2020-02-13 03:57:11 --> Language Class Initialized
ERROR - 2020-02-13 03:57:11 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 03:57:11 --> Config Class Initialized
INFO - 2020-02-13 03:57:11 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:57:11 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:57:11 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:11 --> URI Class Initialized
INFO - 2020-02-13 03:57:11 --> Router Class Initialized
INFO - 2020-02-13 03:57:11 --> Output Class Initialized
INFO - 2020-02-13 03:57:11 --> Security Class Initialized
DEBUG - 2020-02-13 03:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:11 --> Input Class Initialized
INFO - 2020-02-13 03:57:11 --> Language Class Initialized
ERROR - 2020-02-13 03:57:11 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 03:57:11 --> Config Class Initialized
INFO - 2020-02-13 03:57:11 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:57:11 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:57:11 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:11 --> URI Class Initialized
INFO - 2020-02-13 03:57:11 --> Router Class Initialized
INFO - 2020-02-13 03:57:11 --> Output Class Initialized
INFO - 2020-02-13 03:57:11 --> Security Class Initialized
DEBUG - 2020-02-13 03:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:11 --> Input Class Initialized
INFO - 2020-02-13 03:57:11 --> Language Class Initialized
ERROR - 2020-02-13 03:57:11 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 03:57:11 --> Config Class Initialized
INFO - 2020-02-13 03:57:11 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:57:11 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:57:11 --> Utf8 Class Initialized
INFO - 2020-02-13 03:57:11 --> URI Class Initialized
INFO - 2020-02-13 03:57:11 --> Router Class Initialized
INFO - 2020-02-13 03:57:11 --> Output Class Initialized
INFO - 2020-02-13 03:57:11 --> Security Class Initialized
DEBUG - 2020-02-13 03:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:57:11 --> Input Class Initialized
INFO - 2020-02-13 03:57:11 --> Language Class Initialized
ERROR - 2020-02-13 03:57:11 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 03:58:09 --> Config Class Initialized
INFO - 2020-02-13 03:58:09 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:58:09 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:58:09 --> Utf8 Class Initialized
INFO - 2020-02-13 03:58:09 --> URI Class Initialized
INFO - 2020-02-13 03:58:09 --> Router Class Initialized
INFO - 2020-02-13 03:58:09 --> Output Class Initialized
INFO - 2020-02-13 03:58:09 --> Security Class Initialized
DEBUG - 2020-02-13 03:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:58:09 --> Input Class Initialized
INFO - 2020-02-13 03:58:09 --> Language Class Initialized
INFO - 2020-02-13 03:58:09 --> Loader Class Initialized
INFO - 2020-02-13 03:58:09 --> Helper loaded: url_helper
INFO - 2020-02-13 03:58:09 --> Helper loaded: string_helper
INFO - 2020-02-13 03:58:09 --> Database Driver Class Initialized
DEBUG - 2020-02-13 03:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 03:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:58:09 --> Controller Class Initialized
INFO - 2020-02-13 03:58:09 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:58:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:58:09 --> Model "M_pesan" initialized
INFO - 2020-02-13 03:58:09 --> Helper loaded: form_helper
INFO - 2020-02-13 03:58:09 --> Form Validation Class Initialized
INFO - 2020-02-13 03:58:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 03:58:10 --> Final output sent to browser
DEBUG - 2020-02-13 03:58:10 --> Total execution time: 0.5359
INFO - 2020-02-13 03:58:25 --> Config Class Initialized
INFO - 2020-02-13 03:58:25 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:58:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:58:25 --> Utf8 Class Initialized
INFO - 2020-02-13 03:58:25 --> URI Class Initialized
INFO - 2020-02-13 03:58:25 --> Router Class Initialized
INFO - 2020-02-13 03:58:25 --> Output Class Initialized
INFO - 2020-02-13 03:58:25 --> Security Class Initialized
DEBUG - 2020-02-13 03:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:58:25 --> Input Class Initialized
INFO - 2020-02-13 03:58:25 --> Language Class Initialized
INFO - 2020-02-13 03:58:25 --> Loader Class Initialized
INFO - 2020-02-13 03:58:25 --> Helper loaded: url_helper
INFO - 2020-02-13 03:58:25 --> Helper loaded: string_helper
INFO - 2020-02-13 03:58:25 --> Database Driver Class Initialized
DEBUG - 2020-02-13 03:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 03:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:58:25 --> Controller Class Initialized
INFO - 2020-02-13 03:58:25 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:58:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:58:25 --> Model "M_pesan" initialized
INFO - 2020-02-13 03:58:25 --> Helper loaded: form_helper
INFO - 2020-02-13 03:58:25 --> Form Validation Class Initialized
INFO - 2020-02-13 03:58:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 03:58:26 --> Final output sent to browser
DEBUG - 2020-02-13 03:58:26 --> Total execution time: 0.5888
INFO - 2020-02-13 03:58:59 --> Config Class Initialized
INFO - 2020-02-13 03:58:59 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:58:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:58:59 --> Utf8 Class Initialized
INFO - 2020-02-13 03:58:59 --> URI Class Initialized
INFO - 2020-02-13 03:58:59 --> Router Class Initialized
INFO - 2020-02-13 03:58:59 --> Output Class Initialized
INFO - 2020-02-13 03:58:59 --> Security Class Initialized
DEBUG - 2020-02-13 03:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:58:59 --> Input Class Initialized
INFO - 2020-02-13 03:58:59 --> Language Class Initialized
INFO - 2020-02-13 03:58:59 --> Loader Class Initialized
INFO - 2020-02-13 03:58:59 --> Helper loaded: url_helper
INFO - 2020-02-13 03:58:59 --> Helper loaded: string_helper
INFO - 2020-02-13 03:58:59 --> Database Driver Class Initialized
DEBUG - 2020-02-13 03:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 03:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:58:59 --> Controller Class Initialized
INFO - 2020-02-13 03:58:59 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:58:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:58:59 --> Model "M_pesan" initialized
INFO - 2020-02-13 03:58:59 --> Helper loaded: form_helper
INFO - 2020-02-13 03:59:00 --> Form Validation Class Initialized
INFO - 2020-02-13 03:59:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 03:59:00 --> Final output sent to browser
DEBUG - 2020-02-13 03:59:00 --> Total execution time: 0.6819
INFO - 2020-02-13 03:59:00 --> Config Class Initialized
INFO - 2020-02-13 03:59:00 --> Config Class Initialized
INFO - 2020-02-13 03:59:00 --> Config Class Initialized
INFO - 2020-02-13 03:59:00 --> Config Class Initialized
INFO - 2020-02-13 03:59:00 --> Hooks Class Initialized
INFO - 2020-02-13 03:59:00 --> Hooks Class Initialized
INFO - 2020-02-13 03:59:00 --> Hooks Class Initialized
INFO - 2020-02-13 03:59:00 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:59:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:59:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:59:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:59:00 --> UTF-8 Support Enabled
INFO - 2020-02-13 03:59:00 --> Utf8 Class Initialized
INFO - 2020-02-13 03:59:00 --> Utf8 Class Initialized
INFO - 2020-02-13 03:59:00 --> Utf8 Class Initialized
INFO - 2020-02-13 03:59:00 --> Utf8 Class Initialized
INFO - 2020-02-13 03:59:00 --> URI Class Initialized
INFO - 2020-02-13 03:59:00 --> URI Class Initialized
INFO - 2020-02-13 03:59:00 --> URI Class Initialized
INFO - 2020-02-13 03:59:00 --> URI Class Initialized
INFO - 2020-02-13 03:59:00 --> Router Class Initialized
INFO - 2020-02-13 03:59:00 --> Router Class Initialized
INFO - 2020-02-13 03:59:00 --> Router Class Initialized
INFO - 2020-02-13 03:59:00 --> Router Class Initialized
INFO - 2020-02-13 03:59:00 --> Output Class Initialized
INFO - 2020-02-13 03:59:00 --> Output Class Initialized
INFO - 2020-02-13 03:59:00 --> Output Class Initialized
INFO - 2020-02-13 03:59:00 --> Output Class Initialized
INFO - 2020-02-13 03:59:00 --> Security Class Initialized
INFO - 2020-02-13 03:59:00 --> Security Class Initialized
INFO - 2020-02-13 03:59:00 --> Security Class Initialized
INFO - 2020-02-13 03:59:00 --> Security Class Initialized
DEBUG - 2020-02-13 03:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 03:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 03:59:00 --> Input Class Initialized
INFO - 2020-02-13 03:59:00 --> Input Class Initialized
INFO - 2020-02-13 03:59:00 --> Input Class Initialized
INFO - 2020-02-13 03:59:00 --> Input Class Initialized
INFO - 2020-02-13 03:59:00 --> Language Class Initialized
INFO - 2020-02-13 03:59:00 --> Language Class Initialized
INFO - 2020-02-13 03:59:00 --> Language Class Initialized
INFO - 2020-02-13 03:59:00 --> Language Class Initialized
ERROR - 2020-02-13 03:59:00 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 03:59:00 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 03:59:00 --> Loader Class Initialized
INFO - 2020-02-13 03:59:00 --> Loader Class Initialized
INFO - 2020-02-13 03:59:00 --> Helper loaded: url_helper
INFO - 2020-02-13 03:59:00 --> Helper loaded: url_helper
INFO - 2020-02-13 03:59:00 --> Helper loaded: string_helper
INFO - 2020-02-13 03:59:00 --> Helper loaded: string_helper
INFO - 2020-02-13 03:59:00 --> Database Driver Class Initialized
INFO - 2020-02-13 03:59:00 --> Database Driver Class Initialized
DEBUG - 2020-02-13 03:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 03:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 03:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:59:00 --> Controller Class Initialized
INFO - 2020-02-13 03:59:00 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:59:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:59:01 --> Model "M_pesan" initialized
INFO - 2020-02-13 03:59:01 --> Helper loaded: form_helper
INFO - 2020-02-13 03:59:01 --> Form Validation Class Initialized
ERROR - 2020-02-13 03:59:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 03:59:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 03:59:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 03:59:01 --> Final output sent to browser
DEBUG - 2020-02-13 03:59:01 --> Total execution time: 0.6773
INFO - 2020-02-13 03:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 03:59:01 --> Controller Class Initialized
INFO - 2020-02-13 03:59:01 --> Model "M_tiket" initialized
INFO - 2020-02-13 03:59:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 03:59:01 --> Model "M_pesan" initialized
INFO - 2020-02-13 03:59:01 --> Helper loaded: form_helper
INFO - 2020-02-13 03:59:01 --> Form Validation Class Initialized
ERROR - 2020-02-13 03:59:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 03:59:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 03:59:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 03:59:01 --> Final output sent to browser
DEBUG - 2020-02-13 03:59:01 --> Total execution time: 0.9103
INFO - 2020-02-13 04:01:10 --> Config Class Initialized
INFO - 2020-02-13 04:01:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:01:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:01:10 --> Utf8 Class Initialized
INFO - 2020-02-13 04:01:10 --> URI Class Initialized
INFO - 2020-02-13 04:01:10 --> Router Class Initialized
INFO - 2020-02-13 04:01:10 --> Output Class Initialized
INFO - 2020-02-13 04:01:10 --> Security Class Initialized
DEBUG - 2020-02-13 04:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:01:10 --> Input Class Initialized
INFO - 2020-02-13 04:01:10 --> Language Class Initialized
INFO - 2020-02-13 04:01:10 --> Loader Class Initialized
INFO - 2020-02-13 04:01:10 --> Helper loaded: url_helper
INFO - 2020-02-13 04:01:10 --> Helper loaded: string_helper
INFO - 2020-02-13 04:01:10 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:01:10 --> Controller Class Initialized
INFO - 2020-02-13 04:01:10 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:01:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:01:11 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:01:11 --> Helper loaded: form_helper
INFO - 2020-02-13 04:01:11 --> Form Validation Class Initialized
INFO - 2020-02-13 04:01:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 04:01:11 --> Final output sent to browser
DEBUG - 2020-02-13 04:01:11 --> Total execution time: 0.5635
INFO - 2020-02-13 04:01:41 --> Config Class Initialized
INFO - 2020-02-13 04:01:41 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:01:41 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:01:41 --> Utf8 Class Initialized
INFO - 2020-02-13 04:01:42 --> URI Class Initialized
INFO - 2020-02-13 04:01:42 --> Router Class Initialized
INFO - 2020-02-13 04:01:42 --> Output Class Initialized
INFO - 2020-02-13 04:01:42 --> Security Class Initialized
DEBUG - 2020-02-13 04:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:01:42 --> Input Class Initialized
INFO - 2020-02-13 04:01:42 --> Language Class Initialized
INFO - 2020-02-13 04:01:42 --> Loader Class Initialized
INFO - 2020-02-13 04:01:42 --> Helper loaded: url_helper
INFO - 2020-02-13 04:01:42 --> Helper loaded: string_helper
INFO - 2020-02-13 04:01:42 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:01:42 --> Controller Class Initialized
INFO - 2020-02-13 04:01:42 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:01:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:01:42 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:01:42 --> Helper loaded: form_helper
INFO - 2020-02-13 04:01:42 --> Form Validation Class Initialized
INFO - 2020-02-13 04:01:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:01:42 --> Final output sent to browser
DEBUG - 2020-02-13 04:01:42 --> Total execution time: 0.6295
INFO - 2020-02-13 04:01:42 --> Config Class Initialized
INFO - 2020-02-13 04:01:42 --> Hooks Class Initialized
INFO - 2020-02-13 04:01:42 --> Config Class Initialized
INFO - 2020-02-13 04:01:42 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:01:42 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:01:42 --> Utf8 Class Initialized
DEBUG - 2020-02-13 04:01:42 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:01:42 --> Utf8 Class Initialized
INFO - 2020-02-13 04:01:42 --> URI Class Initialized
INFO - 2020-02-13 04:01:42 --> URI Class Initialized
INFO - 2020-02-13 04:01:42 --> Router Class Initialized
INFO - 2020-02-13 04:01:42 --> Router Class Initialized
INFO - 2020-02-13 04:01:42 --> Output Class Initialized
INFO - 2020-02-13 04:01:42 --> Security Class Initialized
INFO - 2020-02-13 04:01:42 --> Output Class Initialized
DEBUG - 2020-02-13 04:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:01:42 --> Security Class Initialized
INFO - 2020-02-13 04:01:42 --> Input Class Initialized
DEBUG - 2020-02-13 04:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:01:42 --> Input Class Initialized
INFO - 2020-02-13 04:01:42 --> Language Class Initialized
INFO - 2020-02-13 04:01:42 --> Language Class Initialized
INFO - 2020-02-13 04:01:42 --> Loader Class Initialized
INFO - 2020-02-13 04:01:42 --> Loader Class Initialized
INFO - 2020-02-13 04:01:42 --> Helper loaded: url_helper
INFO - 2020-02-13 04:01:42 --> Helper loaded: url_helper
INFO - 2020-02-13 04:01:42 --> Helper loaded: string_helper
INFO - 2020-02-13 04:01:43 --> Helper loaded: string_helper
INFO - 2020-02-13 04:01:43 --> Database Driver Class Initialized
INFO - 2020-02-13 04:01:43 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:01:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 04:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:01:43 --> Controller Class Initialized
INFO - 2020-02-13 04:01:43 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:01:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:01:43 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:01:43 --> Helper loaded: form_helper
INFO - 2020-02-13 04:01:43 --> Form Validation Class Initialized
ERROR - 2020-02-13 04:01:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 04:01:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 04:01:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:01:43 --> Final output sent to browser
DEBUG - 2020-02-13 04:01:43 --> Total execution time: 0.8313
INFO - 2020-02-13 04:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:01:43 --> Controller Class Initialized
INFO - 2020-02-13 04:01:43 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:01:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:01:43 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:01:43 --> Helper loaded: form_helper
INFO - 2020-02-13 04:01:43 --> Form Validation Class Initialized
ERROR - 2020-02-13 04:01:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 04:01:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 04:01:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:01:43 --> Final output sent to browser
DEBUG - 2020-02-13 04:01:43 --> Total execution time: 1.2431
INFO - 2020-02-13 04:01:46 --> Config Class Initialized
INFO - 2020-02-13 04:01:46 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:01:46 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:01:46 --> Utf8 Class Initialized
INFO - 2020-02-13 04:01:46 --> URI Class Initialized
INFO - 2020-02-13 04:01:47 --> Router Class Initialized
INFO - 2020-02-13 04:01:47 --> Output Class Initialized
INFO - 2020-02-13 04:01:47 --> Security Class Initialized
DEBUG - 2020-02-13 04:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:01:47 --> Input Class Initialized
INFO - 2020-02-13 04:01:47 --> Language Class Initialized
INFO - 2020-02-13 04:01:47 --> Loader Class Initialized
INFO - 2020-02-13 04:01:47 --> Helper loaded: url_helper
INFO - 2020-02-13 04:01:47 --> Helper loaded: string_helper
INFO - 2020-02-13 04:01:47 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:01:47 --> Controller Class Initialized
INFO - 2020-02-13 04:01:47 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:01:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:01:47 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:01:47 --> Helper loaded: form_helper
INFO - 2020-02-13 04:01:47 --> Form Validation Class Initialized
INFO - 2020-02-13 04:01:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:01:47 --> Final output sent to browser
DEBUG - 2020-02-13 04:01:47 --> Total execution time: 0.6078
INFO - 2020-02-13 04:01:47 --> Config Class Initialized
INFO - 2020-02-13 04:01:47 --> Config Class Initialized
INFO - 2020-02-13 04:01:47 --> Hooks Class Initialized
INFO - 2020-02-13 04:01:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:01:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:01:47 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:01:47 --> Utf8 Class Initialized
INFO - 2020-02-13 04:01:47 --> Utf8 Class Initialized
INFO - 2020-02-13 04:01:47 --> URI Class Initialized
INFO - 2020-02-13 04:01:47 --> URI Class Initialized
INFO - 2020-02-13 04:01:47 --> Router Class Initialized
INFO - 2020-02-13 04:01:47 --> Router Class Initialized
INFO - 2020-02-13 04:01:47 --> Output Class Initialized
INFO - 2020-02-13 04:01:47 --> Output Class Initialized
INFO - 2020-02-13 04:01:47 --> Security Class Initialized
INFO - 2020-02-13 04:01:47 --> Security Class Initialized
DEBUG - 2020-02-13 04:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:01:47 --> Input Class Initialized
INFO - 2020-02-13 04:01:47 --> Input Class Initialized
INFO - 2020-02-13 04:01:47 --> Language Class Initialized
INFO - 2020-02-13 04:01:47 --> Language Class Initialized
INFO - 2020-02-13 04:01:47 --> Loader Class Initialized
INFO - 2020-02-13 04:01:47 --> Loader Class Initialized
INFO - 2020-02-13 04:01:47 --> Helper loaded: url_helper
INFO - 2020-02-13 04:01:47 --> Helper loaded: url_helper
INFO - 2020-02-13 04:01:47 --> Helper loaded: string_helper
INFO - 2020-02-13 04:01:47 --> Helper loaded: string_helper
INFO - 2020-02-13 04:01:48 --> Database Driver Class Initialized
INFO - 2020-02-13 04:01:48 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 04:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:01:48 --> Controller Class Initialized
INFO - 2020-02-13 04:01:48 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:01:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:01:48 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:01:48 --> Helper loaded: form_helper
INFO - 2020-02-13 04:01:48 --> Form Validation Class Initialized
ERROR - 2020-02-13 04:01:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 04:01:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 04:01:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:01:48 --> Final output sent to browser
DEBUG - 2020-02-13 04:01:48 --> Total execution time: 0.7734
INFO - 2020-02-13 04:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:01:48 --> Controller Class Initialized
INFO - 2020-02-13 04:01:48 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:01:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:01:48 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:01:48 --> Helper loaded: form_helper
INFO - 2020-02-13 04:01:48 --> Form Validation Class Initialized
ERROR - 2020-02-13 04:01:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 04:01:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 04:01:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:01:48 --> Final output sent to browser
DEBUG - 2020-02-13 04:01:48 --> Total execution time: 1.1686
INFO - 2020-02-13 04:01:54 --> Config Class Initialized
INFO - 2020-02-13 04:01:54 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:01:54 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:01:54 --> Utf8 Class Initialized
INFO - 2020-02-13 04:01:54 --> URI Class Initialized
INFO - 2020-02-13 04:01:54 --> Router Class Initialized
INFO - 2020-02-13 04:01:54 --> Output Class Initialized
INFO - 2020-02-13 04:01:54 --> Security Class Initialized
DEBUG - 2020-02-13 04:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:01:54 --> Input Class Initialized
INFO - 2020-02-13 04:01:54 --> Language Class Initialized
INFO - 2020-02-13 04:01:54 --> Loader Class Initialized
INFO - 2020-02-13 04:01:54 --> Helper loaded: url_helper
INFO - 2020-02-13 04:01:54 --> Helper loaded: string_helper
INFO - 2020-02-13 04:01:54 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:01:54 --> Controller Class Initialized
INFO - 2020-02-13 04:01:54 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:01:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:01:54 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:01:54 --> Helper loaded: form_helper
INFO - 2020-02-13 04:01:54 --> Form Validation Class Initialized
INFO - 2020-02-13 04:01:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 04:01:54 --> Final output sent to browser
DEBUG - 2020-02-13 04:01:54 --> Total execution time: 0.5764
INFO - 2020-02-13 04:01:57 --> Config Class Initialized
INFO - 2020-02-13 04:01:57 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:01:57 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:01:57 --> Utf8 Class Initialized
INFO - 2020-02-13 04:01:57 --> URI Class Initialized
INFO - 2020-02-13 04:01:57 --> Router Class Initialized
INFO - 2020-02-13 04:01:58 --> Output Class Initialized
INFO - 2020-02-13 04:01:58 --> Security Class Initialized
DEBUG - 2020-02-13 04:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:01:58 --> Input Class Initialized
INFO - 2020-02-13 04:01:58 --> Language Class Initialized
INFO - 2020-02-13 04:01:58 --> Loader Class Initialized
INFO - 2020-02-13 04:01:58 --> Helper loaded: url_helper
INFO - 2020-02-13 04:01:58 --> Helper loaded: string_helper
INFO - 2020-02-13 04:01:58 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:01:58 --> Controller Class Initialized
INFO - 2020-02-13 04:01:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 04:01:58 --> Pagination Class Initialized
INFO - 2020-02-13 04:01:58 --> Model "M_show" initialized
INFO - 2020-02-13 04:01:58 --> Helper loaded: form_helper
INFO - 2020-02-13 04:01:58 --> Form Validation Class Initialized
INFO - 2020-02-13 04:01:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 04:01:58 --> Final output sent to browser
DEBUG - 2020-02-13 04:01:58 --> Total execution time: 1.3189
INFO - 2020-02-13 04:01:59 --> Config Class Initialized
INFO - 2020-02-13 04:01:59 --> Hooks Class Initialized
INFO - 2020-02-13 04:01:59 --> Config Class Initialized
INFO - 2020-02-13 04:01:59 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:01:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:01:59 --> Utf8 Class Initialized
DEBUG - 2020-02-13 04:01:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:01:59 --> Utf8 Class Initialized
INFO - 2020-02-13 04:01:59 --> URI Class Initialized
INFO - 2020-02-13 04:01:59 --> URI Class Initialized
INFO - 2020-02-13 04:01:59 --> Router Class Initialized
INFO - 2020-02-13 04:01:59 --> Router Class Initialized
INFO - 2020-02-13 04:01:59 --> Output Class Initialized
INFO - 2020-02-13 04:01:59 --> Security Class Initialized
INFO - 2020-02-13 04:01:59 --> Output Class Initialized
DEBUG - 2020-02-13 04:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:01:59 --> Security Class Initialized
INFO - 2020-02-13 04:01:59 --> Input Class Initialized
DEBUG - 2020-02-13 04:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:01:59 --> Input Class Initialized
INFO - 2020-02-13 04:01:59 --> Language Class Initialized
INFO - 2020-02-13 04:01:59 --> Language Class Initialized
ERROR - 2020-02-13 04:01:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-13 04:01:59 --> 404 Page Not Found: Assets/js
INFO - 2020-02-13 04:01:59 --> Config Class Initialized
INFO - 2020-02-13 04:01:59 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:01:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:01:59 --> Utf8 Class Initialized
INFO - 2020-02-13 04:01:59 --> URI Class Initialized
INFO - 2020-02-13 04:01:59 --> Router Class Initialized
INFO - 2020-02-13 04:01:59 --> Output Class Initialized
INFO - 2020-02-13 04:01:59 --> Security Class Initialized
DEBUG - 2020-02-13 04:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:01:59 --> Input Class Initialized
INFO - 2020-02-13 04:01:59 --> Language Class Initialized
ERROR - 2020-02-13 04:01:59 --> 404 Page Not Found: Assets/js
INFO - 2020-02-13 04:01:59 --> Config Class Initialized
INFO - 2020-02-13 04:01:59 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:01:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:01:59 --> Utf8 Class Initialized
INFO - 2020-02-13 04:01:59 --> URI Class Initialized
INFO - 2020-02-13 04:01:59 --> Router Class Initialized
INFO - 2020-02-13 04:01:59 --> Output Class Initialized
INFO - 2020-02-13 04:01:59 --> Security Class Initialized
DEBUG - 2020-02-13 04:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:00 --> Input Class Initialized
INFO - 2020-02-13 04:02:00 --> Language Class Initialized
ERROR - 2020-02-13 04:02:00 --> 404 Page Not Found: Assets/js
INFO - 2020-02-13 04:02:44 --> Config Class Initialized
INFO - 2020-02-13 04:02:44 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:02:44 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:44 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:44 --> URI Class Initialized
INFO - 2020-02-13 04:02:44 --> Router Class Initialized
INFO - 2020-02-13 04:02:44 --> Output Class Initialized
INFO - 2020-02-13 04:02:44 --> Security Class Initialized
DEBUG - 2020-02-13 04:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:44 --> Input Class Initialized
INFO - 2020-02-13 04:02:44 --> Language Class Initialized
INFO - 2020-02-13 04:02:44 --> Loader Class Initialized
INFO - 2020-02-13 04:02:44 --> Helper loaded: url_helper
INFO - 2020-02-13 04:02:44 --> Helper loaded: string_helper
INFO - 2020-02-13 04:02:44 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:02:45 --> Controller Class Initialized
INFO - 2020-02-13 04:02:45 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:02:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:02:45 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:02:45 --> Helper loaded: form_helper
INFO - 2020-02-13 04:02:45 --> Form Validation Class Initialized
INFO - 2020-02-13 04:02:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:02:45 --> Final output sent to browser
DEBUG - 2020-02-13 04:02:45 --> Total execution time: 0.8547
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:45 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:45 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:45 --> Utf8 Class Initialized
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:45 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:45 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:45 --> URI Class Initialized
INFO - 2020-02-13 04:02:45 --> URI Class Initialized
INFO - 2020-02-13 04:02:45 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:45 --> URI Class Initialized
INFO - 2020-02-13 04:02:45 --> URI Class Initialized
INFO - 2020-02-13 04:02:45 --> URI Class Initialized
INFO - 2020-02-13 04:02:45 --> URI Class Initialized
INFO - 2020-02-13 04:02:45 --> Router Class Initialized
INFO - 2020-02-13 04:02:45 --> Router Class Initialized
INFO - 2020-02-13 04:02:45 --> Router Class Initialized
INFO - 2020-02-13 04:02:45 --> Router Class Initialized
INFO - 2020-02-13 04:02:45 --> Router Class Initialized
INFO - 2020-02-13 04:02:45 --> Output Class Initialized
INFO - 2020-02-13 04:02:45 --> Output Class Initialized
INFO - 2020-02-13 04:02:45 --> Router Class Initialized
INFO - 2020-02-13 04:02:45 --> Output Class Initialized
INFO - 2020-02-13 04:02:45 --> Output Class Initialized
INFO - 2020-02-13 04:02:45 --> Output Class Initialized
INFO - 2020-02-13 04:02:45 --> Security Class Initialized
INFO - 2020-02-13 04:02:45 --> Output Class Initialized
INFO - 2020-02-13 04:02:45 --> Security Class Initialized
INFO - 2020-02-13 04:02:45 --> Security Class Initialized
DEBUG - 2020-02-13 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:45 --> Security Class Initialized
INFO - 2020-02-13 04:02:45 --> Security Class Initialized
INFO - 2020-02-13 04:02:45 --> Security Class Initialized
DEBUG - 2020-02-13 04:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:45 --> Input Class Initialized
INFO - 2020-02-13 04:02:45 --> Input Class Initialized
INFO - 2020-02-13 04:02:45 --> Input Class Initialized
DEBUG - 2020-02-13 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:45 --> Input Class Initialized
INFO - 2020-02-13 04:02:45 --> Input Class Initialized
INFO - 2020-02-13 04:02:45 --> Input Class Initialized
INFO - 2020-02-13 04:02:45 --> Language Class Initialized
INFO - 2020-02-13 04:02:45 --> Language Class Initialized
INFO - 2020-02-13 04:02:45 --> Language Class Initialized
INFO - 2020-02-13 04:02:45 --> Language Class Initialized
ERROR - 2020-02-13 04:02:45 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 04:02:45 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 04:02:45 --> Language Class Initialized
INFO - 2020-02-13 04:02:45 --> Language Class Initialized
INFO - 2020-02-13 04:02:45 --> Loader Class Initialized
ERROR - 2020-02-13 04:02:45 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 04:02:45 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 04:02:45 --> Helper loaded: url_helper
INFO - 2020-02-13 04:02:45 --> Loader Class Initialized
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:45 --> Helper loaded: string_helper
INFO - 2020-02-13 04:02:45 --> Helper loaded: url_helper
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:45 --> Helper loaded: string_helper
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:45 --> Database Driver Class Initialized
INFO - 2020-02-13 04:02:45 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:45 --> Utf8 Class Initialized
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:02:45 --> Database Driver Class Initialized
INFO - 2020-02-13 04:02:45 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:02:45 --> URI Class Initialized
INFO - 2020-02-13 04:02:45 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:45 --> URI Class Initialized
DEBUG - 2020-02-13 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:02:45 --> Controller Class Initialized
INFO - 2020-02-13 04:02:45 --> URI Class Initialized
INFO - 2020-02-13 04:02:45 --> Router Class Initialized
INFO - 2020-02-13 04:02:45 --> URI Class Initialized
INFO - 2020-02-13 04:02:45 --> Router Class Initialized
INFO - 2020-02-13 04:02:45 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:02:45 --> Router Class Initialized
INFO - 2020-02-13 04:02:45 --> Output Class Initialized
INFO - 2020-02-13 04:02:45 --> Router Class Initialized
INFO - 2020-02-13 04:02:45 --> Output Class Initialized
INFO - 2020-02-13 04:02:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:02:45 --> Security Class Initialized
INFO - 2020-02-13 04:02:45 --> Output Class Initialized
INFO - 2020-02-13 04:02:45 --> Output Class Initialized
INFO - 2020-02-13 04:02:45 --> Security Class Initialized
INFO - 2020-02-13 04:02:45 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:45 --> Security Class Initialized
INFO - 2020-02-13 04:02:45 --> Security Class Initialized
INFO - 2020-02-13 04:02:45 --> Input Class Initialized
INFO - 2020-02-13 04:02:45 --> Input Class Initialized
DEBUG - 2020-02-13 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:45 --> Helper loaded: form_helper
INFO - 2020-02-13 04:02:45 --> Input Class Initialized
INFO - 2020-02-13 04:02:45 --> Input Class Initialized
INFO - 2020-02-13 04:02:45 --> Form Validation Class Initialized
INFO - 2020-02-13 04:02:45 --> Language Class Initialized
INFO - 2020-02-13 04:02:45 --> Language Class Initialized
INFO - 2020-02-13 04:02:45 --> Language Class Initialized
INFO - 2020-02-13 04:02:45 --> Language Class Initialized
ERROR - 2020-02-13 04:02:45 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 04:02:45 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 04:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 04:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 04:02:45 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 04:02:45 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Config Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:45 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:45 --> Final output sent to browser
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:45 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:45 --> Utf8 Class Initialized
DEBUG - 2020-02-13 04:02:45 --> Total execution time: 0.6596
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:02:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:02:46 --> URI Class Initialized
INFO - 2020-02-13 04:02:46 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:46 --> URI Class Initialized
INFO - 2020-02-13 04:02:46 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:46 --> Controller Class Initialized
INFO - 2020-02-13 04:02:46 --> URI Class Initialized
INFO - 2020-02-13 04:02:46 --> Router Class Initialized
INFO - 2020-02-13 04:02:46 --> URI Class Initialized
INFO - 2020-02-13 04:02:46 --> Router Class Initialized
INFO - 2020-02-13 04:02:46 --> Router Class Initialized
INFO - 2020-02-13 04:02:46 --> Output Class Initialized
INFO - 2020-02-13 04:02:46 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:02:46 --> Output Class Initialized
INFO - 2020-02-13 04:02:46 --> Router Class Initialized
INFO - 2020-02-13 04:02:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:02:46 --> Security Class Initialized
INFO - 2020-02-13 04:02:46 --> Output Class Initialized
INFO - 2020-02-13 04:02:46 --> Output Class Initialized
INFO - 2020-02-13 04:02:46 --> Security Class Initialized
INFO - 2020-02-13 04:02:46 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 04:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:46 --> Security Class Initialized
INFO - 2020-02-13 04:02:46 --> Security Class Initialized
DEBUG - 2020-02-13 04:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:46 --> Input Class Initialized
INFO - 2020-02-13 04:02:46 --> Input Class Initialized
DEBUG - 2020-02-13 04:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:46 --> Helper loaded: form_helper
INFO - 2020-02-13 04:02:46 --> Form Validation Class Initialized
INFO - 2020-02-13 04:02:46 --> Input Class Initialized
INFO - 2020-02-13 04:02:46 --> Language Class Initialized
INFO - 2020-02-13 04:02:46 --> Input Class Initialized
INFO - 2020-02-13 04:02:46 --> Language Class Initialized
INFO - 2020-02-13 04:02:46 --> Language Class Initialized
ERROR - 2020-02-13 04:02:46 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 04:02:46 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 04:02:46 --> Language Class Initialized
ERROR - 2020-02-13 04:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 04:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 04:02:46 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 04:02:46 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 04:02:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:02:46 --> Config Class Initialized
INFO - 2020-02-13 04:02:46 --> Hooks Class Initialized
INFO - 2020-02-13 04:02:46 --> Final output sent to browser
DEBUG - 2020-02-13 04:02:46 --> Total execution time: 0.9552
DEBUG - 2020-02-13 04:02:46 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:46 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:46 --> URI Class Initialized
INFO - 2020-02-13 04:02:46 --> Router Class Initialized
INFO - 2020-02-13 04:02:46 --> Output Class Initialized
INFO - 2020-02-13 04:02:46 --> Security Class Initialized
DEBUG - 2020-02-13 04:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:46 --> Input Class Initialized
INFO - 2020-02-13 04:02:46 --> Language Class Initialized
ERROR - 2020-02-13 04:02:46 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 04:02:46 --> Config Class Initialized
INFO - 2020-02-13 04:02:46 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:02:46 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:46 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:46 --> URI Class Initialized
INFO - 2020-02-13 04:02:46 --> Router Class Initialized
INFO - 2020-02-13 04:02:46 --> Output Class Initialized
INFO - 2020-02-13 04:02:46 --> Security Class Initialized
DEBUG - 2020-02-13 04:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:46 --> Input Class Initialized
INFO - 2020-02-13 04:02:46 --> Language Class Initialized
ERROR - 2020-02-13 04:02:46 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 04:02:46 --> Config Class Initialized
INFO - 2020-02-13 04:02:46 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:02:46 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:46 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:46 --> URI Class Initialized
INFO - 2020-02-13 04:02:46 --> Router Class Initialized
INFO - 2020-02-13 04:02:46 --> Output Class Initialized
INFO - 2020-02-13 04:02:46 --> Security Class Initialized
DEBUG - 2020-02-13 04:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:46 --> Input Class Initialized
INFO - 2020-02-13 04:02:47 --> Language Class Initialized
ERROR - 2020-02-13 04:02:47 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 04:02:47 --> Config Class Initialized
INFO - 2020-02-13 04:02:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:02:47 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:47 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:47 --> URI Class Initialized
INFO - 2020-02-13 04:02:47 --> Router Class Initialized
INFO - 2020-02-13 04:02:47 --> Output Class Initialized
INFO - 2020-02-13 04:02:47 --> Security Class Initialized
DEBUG - 2020-02-13 04:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:47 --> Input Class Initialized
INFO - 2020-02-13 04:02:47 --> Language Class Initialized
ERROR - 2020-02-13 04:02:47 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 04:02:47 --> Config Class Initialized
INFO - 2020-02-13 04:02:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:02:47 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:47 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:47 --> URI Class Initialized
INFO - 2020-02-13 04:02:47 --> Router Class Initialized
INFO - 2020-02-13 04:02:47 --> Output Class Initialized
INFO - 2020-02-13 04:02:47 --> Security Class Initialized
DEBUG - 2020-02-13 04:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:47 --> Input Class Initialized
INFO - 2020-02-13 04:02:47 --> Language Class Initialized
ERROR - 2020-02-13 04:02:47 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 04:02:47 --> Config Class Initialized
INFO - 2020-02-13 04:02:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:02:47 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:47 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:47 --> URI Class Initialized
INFO - 2020-02-13 04:02:47 --> Router Class Initialized
INFO - 2020-02-13 04:02:47 --> Output Class Initialized
INFO - 2020-02-13 04:02:47 --> Security Class Initialized
DEBUG - 2020-02-13 04:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:47 --> Input Class Initialized
INFO - 2020-02-13 04:02:47 --> Language Class Initialized
ERROR - 2020-02-13 04:02:47 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 04:02:47 --> Config Class Initialized
INFO - 2020-02-13 04:02:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:02:48 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:48 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:48 --> URI Class Initialized
INFO - 2020-02-13 04:02:48 --> Router Class Initialized
INFO - 2020-02-13 04:02:48 --> Output Class Initialized
INFO - 2020-02-13 04:02:48 --> Security Class Initialized
DEBUG - 2020-02-13 04:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:48 --> Input Class Initialized
INFO - 2020-02-13 04:02:48 --> Language Class Initialized
ERROR - 2020-02-13 04:02:48 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 04:02:48 --> Config Class Initialized
INFO - 2020-02-13 04:02:48 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:02:48 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:48 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:48 --> URI Class Initialized
INFO - 2020-02-13 04:02:48 --> Router Class Initialized
INFO - 2020-02-13 04:02:48 --> Output Class Initialized
INFO - 2020-02-13 04:02:48 --> Security Class Initialized
DEBUG - 2020-02-13 04:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:48 --> Input Class Initialized
INFO - 2020-02-13 04:02:48 --> Language Class Initialized
ERROR - 2020-02-13 04:02:48 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 04:02:48 --> Config Class Initialized
INFO - 2020-02-13 04:02:48 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:02:48 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:02:48 --> Utf8 Class Initialized
INFO - 2020-02-13 04:02:48 --> URI Class Initialized
INFO - 2020-02-13 04:02:48 --> Router Class Initialized
INFO - 2020-02-13 04:02:48 --> Output Class Initialized
INFO - 2020-02-13 04:02:48 --> Security Class Initialized
DEBUG - 2020-02-13 04:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:02:48 --> Input Class Initialized
INFO - 2020-02-13 04:02:48 --> Language Class Initialized
ERROR - 2020-02-13 04:02:48 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 04:03:16 --> Config Class Initialized
INFO - 2020-02-13 04:03:16 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:03:16 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:03:17 --> Utf8 Class Initialized
INFO - 2020-02-13 04:03:17 --> URI Class Initialized
INFO - 2020-02-13 04:03:17 --> Router Class Initialized
INFO - 2020-02-13 04:03:17 --> Output Class Initialized
INFO - 2020-02-13 04:03:17 --> Security Class Initialized
DEBUG - 2020-02-13 04:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:03:17 --> Input Class Initialized
INFO - 2020-02-13 04:03:17 --> Language Class Initialized
INFO - 2020-02-13 04:03:17 --> Loader Class Initialized
INFO - 2020-02-13 04:03:17 --> Helper loaded: url_helper
INFO - 2020-02-13 04:03:17 --> Helper loaded: string_helper
INFO - 2020-02-13 04:03:17 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:03:17 --> Controller Class Initialized
INFO - 2020-02-13 04:03:18 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:03:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:03:18 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:03:18 --> Helper loaded: form_helper
INFO - 2020-02-13 04:03:18 --> Form Validation Class Initialized
INFO - 2020-02-13 04:03:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 04:03:18 --> Final output sent to browser
DEBUG - 2020-02-13 04:03:18 --> Total execution time: 1.6668
INFO - 2020-02-13 04:03:57 --> Config Class Initialized
INFO - 2020-02-13 04:03:57 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:03:57 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:03:57 --> Utf8 Class Initialized
INFO - 2020-02-13 04:03:57 --> URI Class Initialized
INFO - 2020-02-13 04:03:57 --> Router Class Initialized
INFO - 2020-02-13 04:03:58 --> Output Class Initialized
INFO - 2020-02-13 04:03:58 --> Security Class Initialized
DEBUG - 2020-02-13 04:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:03:58 --> Input Class Initialized
INFO - 2020-02-13 04:03:58 --> Language Class Initialized
INFO - 2020-02-13 04:03:58 --> Loader Class Initialized
INFO - 2020-02-13 04:03:58 --> Helper loaded: url_helper
INFO - 2020-02-13 04:03:58 --> Helper loaded: string_helper
INFO - 2020-02-13 04:03:58 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:03:58 --> Controller Class Initialized
INFO - 2020-02-13 04:03:58 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:03:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:03:58 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:03:58 --> Helper loaded: form_helper
INFO - 2020-02-13 04:03:58 --> Form Validation Class Initialized
INFO - 2020-02-13 04:03:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 04:03:58 --> Final output sent to browser
DEBUG - 2020-02-13 04:03:58 --> Total execution time: 0.9578
INFO - 2020-02-13 04:07:10 --> Config Class Initialized
INFO - 2020-02-13 04:07:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:07:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:07:10 --> Utf8 Class Initialized
INFO - 2020-02-13 04:07:10 --> URI Class Initialized
INFO - 2020-02-13 04:07:10 --> Router Class Initialized
INFO - 2020-02-13 04:07:10 --> Output Class Initialized
INFO - 2020-02-13 04:07:11 --> Security Class Initialized
DEBUG - 2020-02-13 04:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:07:11 --> Input Class Initialized
INFO - 2020-02-13 04:07:11 --> Language Class Initialized
INFO - 2020-02-13 04:07:11 --> Loader Class Initialized
INFO - 2020-02-13 04:07:11 --> Helper loaded: url_helper
INFO - 2020-02-13 04:07:11 --> Helper loaded: string_helper
INFO - 2020-02-13 04:07:11 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:07:11 --> Controller Class Initialized
INFO - 2020-02-13 04:07:11 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:07:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:07:11 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:07:11 --> Helper loaded: form_helper
INFO - 2020-02-13 04:07:11 --> Form Validation Class Initialized
INFO - 2020-02-13 04:07:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 04:07:11 --> Final output sent to browser
DEBUG - 2020-02-13 04:07:11 --> Total execution time: 0.6071
INFO - 2020-02-13 04:09:04 --> Config Class Initialized
INFO - 2020-02-13 04:09:04 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:09:04 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:09:04 --> Utf8 Class Initialized
INFO - 2020-02-13 04:09:04 --> URI Class Initialized
INFO - 2020-02-13 04:09:05 --> Router Class Initialized
INFO - 2020-02-13 04:09:05 --> Output Class Initialized
INFO - 2020-02-13 04:09:05 --> Security Class Initialized
DEBUG - 2020-02-13 04:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:09:05 --> Input Class Initialized
INFO - 2020-02-13 04:09:05 --> Language Class Initialized
INFO - 2020-02-13 04:09:05 --> Loader Class Initialized
INFO - 2020-02-13 04:09:05 --> Helper loaded: url_helper
INFO - 2020-02-13 04:09:05 --> Helper loaded: string_helper
INFO - 2020-02-13 04:09:05 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:09:06 --> Controller Class Initialized
INFO - 2020-02-13 04:09:06 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:09:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:09:06 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:09:06 --> Helper loaded: form_helper
INFO - 2020-02-13 04:09:06 --> Form Validation Class Initialized
INFO - 2020-02-13 04:09:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:09:06 --> Final output sent to browser
DEBUG - 2020-02-13 04:09:06 --> Total execution time: 2.1077
INFO - 2020-02-13 04:09:07 --> Config Class Initialized
INFO - 2020-02-13 04:09:07 --> Config Class Initialized
INFO - 2020-02-13 04:09:07 --> Config Class Initialized
INFO - 2020-02-13 04:09:07 --> Hooks Class Initialized
INFO - 2020-02-13 04:09:07 --> Hooks Class Initialized
INFO - 2020-02-13 04:09:07 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:09:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:09:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:09:07 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:09:07 --> Utf8 Class Initialized
INFO - 2020-02-13 04:09:07 --> Utf8 Class Initialized
INFO - 2020-02-13 04:09:07 --> Utf8 Class Initialized
INFO - 2020-02-13 04:09:07 --> URI Class Initialized
INFO - 2020-02-13 04:09:07 --> URI Class Initialized
INFO - 2020-02-13 04:09:07 --> URI Class Initialized
INFO - 2020-02-13 04:09:07 --> Router Class Initialized
INFO - 2020-02-13 04:09:07 --> Router Class Initialized
INFO - 2020-02-13 04:09:07 --> Router Class Initialized
INFO - 2020-02-13 04:09:07 --> Output Class Initialized
INFO - 2020-02-13 04:09:07 --> Output Class Initialized
INFO - 2020-02-13 04:09:07 --> Output Class Initialized
INFO - 2020-02-13 04:09:07 --> Security Class Initialized
INFO - 2020-02-13 04:09:07 --> Security Class Initialized
INFO - 2020-02-13 04:09:07 --> Security Class Initialized
DEBUG - 2020-02-13 04:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:09:07 --> Input Class Initialized
INFO - 2020-02-13 04:09:07 --> Input Class Initialized
INFO - 2020-02-13 04:09:07 --> Input Class Initialized
INFO - 2020-02-13 04:09:07 --> Language Class Initialized
INFO - 2020-02-13 04:09:07 --> Language Class Initialized
INFO - 2020-02-13 04:09:07 --> Language Class Initialized
ERROR - 2020-02-13 04:09:07 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 04:09:07 --> Loader Class Initialized
INFO - 2020-02-13 04:09:07 --> Loader Class Initialized
INFO - 2020-02-13 04:09:07 --> Helper loaded: url_helper
INFO - 2020-02-13 04:09:07 --> Helper loaded: url_helper
INFO - 2020-02-13 04:09:07 --> Helper loaded: string_helper
INFO - 2020-02-13 04:09:07 --> Helper loaded: string_helper
INFO - 2020-02-13 04:09:07 --> Database Driver Class Initialized
INFO - 2020-02-13 04:09:07 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 04:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:09:07 --> Controller Class Initialized
INFO - 2020-02-13 04:09:07 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:09:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:09:07 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:09:07 --> Helper loaded: form_helper
INFO - 2020-02-13 04:09:07 --> Form Validation Class Initialized
ERROR - 2020-02-13 04:09:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 04:09:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 04:09:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:09:07 --> Final output sent to browser
DEBUG - 2020-02-13 04:09:07 --> Total execution time: 0.8408
INFO - 2020-02-13 04:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:09:08 --> Controller Class Initialized
INFO - 2020-02-13 04:09:08 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:09:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:09:08 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:09:08 --> Helper loaded: form_helper
INFO - 2020-02-13 04:09:08 --> Form Validation Class Initialized
ERROR - 2020-02-13 04:09:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 04:09:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 04:09:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:09:08 --> Final output sent to browser
DEBUG - 2020-02-13 04:09:08 --> Total execution time: 1.1539
INFO - 2020-02-13 04:09:13 --> Config Class Initialized
INFO - 2020-02-13 04:09:13 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:09:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:09:13 --> Utf8 Class Initialized
INFO - 2020-02-13 04:09:13 --> URI Class Initialized
INFO - 2020-02-13 04:09:13 --> Router Class Initialized
INFO - 2020-02-13 04:09:13 --> Output Class Initialized
INFO - 2020-02-13 04:09:13 --> Security Class Initialized
DEBUG - 2020-02-13 04:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:09:13 --> Input Class Initialized
INFO - 2020-02-13 04:09:13 --> Language Class Initialized
INFO - 2020-02-13 04:09:13 --> Loader Class Initialized
INFO - 2020-02-13 04:09:13 --> Helper loaded: url_helper
INFO - 2020-02-13 04:09:13 --> Helper loaded: string_helper
INFO - 2020-02-13 04:09:13 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:09:13 --> Controller Class Initialized
INFO - 2020-02-13 04:09:13 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:09:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:09:13 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:09:13 --> Helper loaded: form_helper
INFO - 2020-02-13 04:09:13 --> Form Validation Class Initialized
INFO - 2020-02-13 04:09:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 04:09:13 --> Final output sent to browser
DEBUG - 2020-02-13 04:09:13 --> Total execution time: 0.9070
INFO - 2020-02-13 04:09:44 --> Config Class Initialized
INFO - 2020-02-13 04:09:44 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:09:44 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:09:44 --> Utf8 Class Initialized
INFO - 2020-02-13 04:09:44 --> URI Class Initialized
INFO - 2020-02-13 04:09:44 --> Router Class Initialized
INFO - 2020-02-13 04:09:44 --> Output Class Initialized
INFO - 2020-02-13 04:09:44 --> Security Class Initialized
DEBUG - 2020-02-13 04:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:09:44 --> Input Class Initialized
INFO - 2020-02-13 04:09:44 --> Language Class Initialized
INFO - 2020-02-13 04:09:44 --> Loader Class Initialized
INFO - 2020-02-13 04:09:44 --> Helper loaded: url_helper
INFO - 2020-02-13 04:09:44 --> Helper loaded: string_helper
INFO - 2020-02-13 04:09:45 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:09:45 --> Controller Class Initialized
INFO - 2020-02-13 04:09:45 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:09:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:09:45 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:09:45 --> Helper loaded: form_helper
INFO - 2020-02-13 04:09:45 --> Form Validation Class Initialized
INFO - 2020-02-13 04:09:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 04:09:45 --> Final output sent to browser
DEBUG - 2020-02-13 04:09:45 --> Total execution time: 1.4068
INFO - 2020-02-13 04:09:55 --> Config Class Initialized
INFO - 2020-02-13 04:09:55 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:09:55 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:09:55 --> Utf8 Class Initialized
INFO - 2020-02-13 04:09:55 --> URI Class Initialized
INFO - 2020-02-13 04:09:55 --> Router Class Initialized
INFO - 2020-02-13 04:09:55 --> Output Class Initialized
INFO - 2020-02-13 04:09:55 --> Security Class Initialized
DEBUG - 2020-02-13 04:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:09:55 --> Input Class Initialized
INFO - 2020-02-13 04:09:55 --> Language Class Initialized
INFO - 2020-02-13 04:09:55 --> Loader Class Initialized
INFO - 2020-02-13 04:09:55 --> Helper loaded: url_helper
INFO - 2020-02-13 04:09:55 --> Helper loaded: string_helper
INFO - 2020-02-13 04:09:55 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:09:55 --> Controller Class Initialized
INFO - 2020-02-13 04:09:56 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:09:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:09:56 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:09:56 --> Helper loaded: form_helper
INFO - 2020-02-13 04:09:56 --> Form Validation Class Initialized
INFO - 2020-02-13 04:09:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 04:09:56 --> Final output sent to browser
DEBUG - 2020-02-13 04:09:56 --> Total execution time: 0.6389
INFO - 2020-02-13 04:10:35 --> Config Class Initialized
INFO - 2020-02-13 04:10:35 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:10:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:10:35 --> Utf8 Class Initialized
INFO - 2020-02-13 04:10:35 --> URI Class Initialized
INFO - 2020-02-13 04:10:35 --> Router Class Initialized
INFO - 2020-02-13 04:10:35 --> Output Class Initialized
INFO - 2020-02-13 04:10:36 --> Security Class Initialized
DEBUG - 2020-02-13 04:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:10:36 --> Input Class Initialized
INFO - 2020-02-13 04:10:36 --> Language Class Initialized
INFO - 2020-02-13 04:10:36 --> Loader Class Initialized
INFO - 2020-02-13 04:10:36 --> Helper loaded: url_helper
INFO - 2020-02-13 04:10:36 --> Helper loaded: string_helper
INFO - 2020-02-13 04:10:36 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:10:36 --> Controller Class Initialized
INFO - 2020-02-13 04:10:36 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:10:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:10:36 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:10:36 --> Helper loaded: form_helper
INFO - 2020-02-13 04:10:37 --> Form Validation Class Initialized
ERROR - 2020-02-13 04:10:37 --> Severity: error --> Exception: syntax error, unexpected '$atasnama' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\roadshow\application\views\Pemesanan\form_bukti.php 21
INFO - 2020-02-13 04:11:14 --> Config Class Initialized
INFO - 2020-02-13 04:11:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:11:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:11:14 --> Utf8 Class Initialized
INFO - 2020-02-13 04:11:14 --> URI Class Initialized
INFO - 2020-02-13 04:11:14 --> Router Class Initialized
INFO - 2020-02-13 04:11:14 --> Output Class Initialized
INFO - 2020-02-13 04:11:14 --> Security Class Initialized
DEBUG - 2020-02-13 04:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:11:14 --> Input Class Initialized
INFO - 2020-02-13 04:11:14 --> Language Class Initialized
INFO - 2020-02-13 04:11:14 --> Loader Class Initialized
INFO - 2020-02-13 04:11:14 --> Helper loaded: url_helper
INFO - 2020-02-13 04:11:14 --> Helper loaded: string_helper
INFO - 2020-02-13 04:11:15 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:11:15 --> Controller Class Initialized
INFO - 2020-02-13 04:11:15 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:11:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:11:15 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:11:15 --> Helper loaded: form_helper
INFO - 2020-02-13 04:11:15 --> Form Validation Class Initialized
INFO - 2020-02-13 04:11:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 04:11:15 --> Final output sent to browser
DEBUG - 2020-02-13 04:11:15 --> Total execution time: 0.8133
INFO - 2020-02-13 04:11:29 --> Config Class Initialized
INFO - 2020-02-13 04:11:29 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:11:29 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:11:29 --> Utf8 Class Initialized
INFO - 2020-02-13 04:11:29 --> URI Class Initialized
INFO - 2020-02-13 04:11:30 --> Router Class Initialized
INFO - 2020-02-13 04:11:30 --> Output Class Initialized
INFO - 2020-02-13 04:11:30 --> Security Class Initialized
DEBUG - 2020-02-13 04:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:11:30 --> Input Class Initialized
INFO - 2020-02-13 04:11:30 --> Language Class Initialized
INFO - 2020-02-13 04:11:30 --> Loader Class Initialized
INFO - 2020-02-13 04:11:30 --> Helper loaded: url_helper
INFO - 2020-02-13 04:11:30 --> Helper loaded: string_helper
INFO - 2020-02-13 04:11:30 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:11:30 --> Controller Class Initialized
INFO - 2020-02-13 04:11:30 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:11:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:11:30 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:11:30 --> Helper loaded: form_helper
INFO - 2020-02-13 04:11:30 --> Form Validation Class Initialized
INFO - 2020-02-13 04:11:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 04:11:30 --> Final output sent to browser
DEBUG - 2020-02-13 04:11:30 --> Total execution time: 0.5839
INFO - 2020-02-13 04:11:48 --> Config Class Initialized
INFO - 2020-02-13 04:11:48 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:11:48 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:11:48 --> Utf8 Class Initialized
INFO - 2020-02-13 04:11:48 --> URI Class Initialized
INFO - 2020-02-13 04:11:48 --> Router Class Initialized
INFO - 2020-02-13 04:11:48 --> Output Class Initialized
INFO - 2020-02-13 04:11:48 --> Security Class Initialized
DEBUG - 2020-02-13 04:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:11:48 --> Input Class Initialized
INFO - 2020-02-13 04:11:48 --> Language Class Initialized
INFO - 2020-02-13 04:11:48 --> Loader Class Initialized
INFO - 2020-02-13 04:11:48 --> Helper loaded: url_helper
INFO - 2020-02-13 04:11:48 --> Helper loaded: string_helper
INFO - 2020-02-13 04:11:48 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:11:48 --> Controller Class Initialized
INFO - 2020-02-13 04:11:48 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:11:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:11:48 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:11:48 --> Helper loaded: form_helper
INFO - 2020-02-13 04:11:48 --> Form Validation Class Initialized
INFO - 2020-02-13 04:11:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 04:11:48 --> Final output sent to browser
DEBUG - 2020-02-13 04:11:48 --> Total execution time: 0.5697
INFO - 2020-02-13 04:13:44 --> Config Class Initialized
INFO - 2020-02-13 04:13:44 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:13:44 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:13:44 --> Utf8 Class Initialized
INFO - 2020-02-13 04:13:44 --> URI Class Initialized
INFO - 2020-02-13 04:13:44 --> Router Class Initialized
INFO - 2020-02-13 04:13:44 --> Output Class Initialized
INFO - 2020-02-13 04:13:44 --> Security Class Initialized
DEBUG - 2020-02-13 04:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:13:44 --> Input Class Initialized
INFO - 2020-02-13 04:13:44 --> Language Class Initialized
INFO - 2020-02-13 04:13:44 --> Loader Class Initialized
INFO - 2020-02-13 04:13:44 --> Helper loaded: url_helper
INFO - 2020-02-13 04:13:44 --> Helper loaded: string_helper
INFO - 2020-02-13 04:13:44 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:13:44 --> Controller Class Initialized
INFO - 2020-02-13 04:13:44 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:13:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:13:45 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:13:45 --> Helper loaded: form_helper
INFO - 2020-02-13 04:13:45 --> Form Validation Class Initialized
INFO - 2020-02-13 04:13:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 04:13:45 --> Final output sent to browser
DEBUG - 2020-02-13 04:13:45 --> Total execution time: 0.5739
INFO - 2020-02-13 04:17:49 --> Config Class Initialized
INFO - 2020-02-13 04:17:49 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:17:49 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:17:49 --> Utf8 Class Initialized
INFO - 2020-02-13 04:17:49 --> URI Class Initialized
DEBUG - 2020-02-13 04:17:49 --> No URI present. Default controller set.
INFO - 2020-02-13 04:17:49 --> Router Class Initialized
INFO - 2020-02-13 04:17:49 --> Output Class Initialized
INFO - 2020-02-13 04:17:49 --> Security Class Initialized
DEBUG - 2020-02-13 04:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:17:49 --> Input Class Initialized
INFO - 2020-02-13 04:17:49 --> Language Class Initialized
INFO - 2020-02-13 04:17:49 --> Loader Class Initialized
INFO - 2020-02-13 04:17:49 --> Helper loaded: url_helper
INFO - 2020-02-13 04:17:49 --> Helper loaded: string_helper
INFO - 2020-02-13 04:17:49 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:17:50 --> Controller Class Initialized
INFO - 2020-02-13 04:17:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 04:17:50 --> Pagination Class Initialized
INFO - 2020-02-13 04:17:50 --> Model "M_show" initialized
INFO - 2020-02-13 04:17:50 --> Helper loaded: form_helper
INFO - 2020-02-13 04:17:50 --> Form Validation Class Initialized
INFO - 2020-02-13 04:17:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 04:17:50 --> Final output sent to browser
INFO - 2020-02-13 04:17:50 --> Config Class Initialized
INFO - 2020-02-13 04:17:50 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:17:50 --> Total execution time: 1.0250
DEBUG - 2020-02-13 04:17:50 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:17:50 --> Utf8 Class Initialized
INFO - 2020-02-13 04:17:50 --> URI Class Initialized
DEBUG - 2020-02-13 04:17:50 --> No URI present. Default controller set.
INFO - 2020-02-13 04:17:50 --> Router Class Initialized
INFO - 2020-02-13 04:17:50 --> Output Class Initialized
INFO - 2020-02-13 04:17:50 --> Security Class Initialized
DEBUG - 2020-02-13 04:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:17:51 --> Input Class Initialized
INFO - 2020-02-13 04:17:51 --> Language Class Initialized
INFO - 2020-02-13 04:17:51 --> Loader Class Initialized
INFO - 2020-02-13 04:17:51 --> Helper loaded: url_helper
INFO - 2020-02-13 04:17:51 --> Helper loaded: string_helper
INFO - 2020-02-13 04:17:51 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:17:51 --> Controller Class Initialized
INFO - 2020-02-13 04:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 04:17:51 --> Pagination Class Initialized
INFO - 2020-02-13 04:17:51 --> Model "M_show" initialized
INFO - 2020-02-13 04:17:51 --> Helper loaded: form_helper
INFO - 2020-02-13 04:17:51 --> Form Validation Class Initialized
INFO - 2020-02-13 04:17:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 04:17:51 --> Final output sent to browser
DEBUG - 2020-02-13 04:17:51 --> Total execution time: 0.9648
INFO - 2020-02-13 04:18:04 --> Config Class Initialized
INFO - 2020-02-13 04:18:04 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:18:04 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:04 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:04 --> URI Class Initialized
INFO - 2020-02-13 04:18:04 --> Router Class Initialized
INFO - 2020-02-13 04:18:04 --> Output Class Initialized
INFO - 2020-02-13 04:18:04 --> Security Class Initialized
DEBUG - 2020-02-13 04:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:04 --> Input Class Initialized
INFO - 2020-02-13 04:18:04 --> Language Class Initialized
INFO - 2020-02-13 04:18:04 --> Loader Class Initialized
INFO - 2020-02-13 04:18:04 --> Helper loaded: url_helper
INFO - 2020-02-13 04:18:04 --> Helper loaded: string_helper
INFO - 2020-02-13 04:18:04 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:18:04 --> Controller Class Initialized
INFO - 2020-02-13 04:18:04 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:18:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:18:05 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:18:05 --> Helper loaded: form_helper
INFO - 2020-02-13 04:18:05 --> Form Validation Class Initialized
INFO - 2020-02-13 04:18:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:18:05 --> Final output sent to browser
DEBUG - 2020-02-13 04:18:05 --> Total execution time: 0.7319
INFO - 2020-02-13 04:18:05 --> Config Class Initialized
INFO - 2020-02-13 04:18:05 --> Config Class Initialized
INFO - 2020-02-13 04:18:05 --> Config Class Initialized
INFO - 2020-02-13 04:18:05 --> Hooks Class Initialized
INFO - 2020-02-13 04:18:05 --> Hooks Class Initialized
INFO - 2020-02-13 04:18:05 --> Hooks Class Initialized
INFO - 2020-02-13 04:18:05 --> Config Class Initialized
INFO - 2020-02-13 04:18:05 --> Config Class Initialized
INFO - 2020-02-13 04:18:05 --> Config Class Initialized
INFO - 2020-02-13 04:18:05 --> Hooks Class Initialized
INFO - 2020-02-13 04:18:05 --> Hooks Class Initialized
INFO - 2020-02-13 04:18:05 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:18:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:18:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:18:05 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:05 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:05 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:05 --> Utf8 Class Initialized
DEBUG - 2020-02-13 04:18:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:18:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:18:05 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:05 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:05 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:05 --> URI Class Initialized
INFO - 2020-02-13 04:18:05 --> URI Class Initialized
INFO - 2020-02-13 04:18:05 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:05 --> URI Class Initialized
INFO - 2020-02-13 04:18:05 --> URI Class Initialized
INFO - 2020-02-13 04:18:05 --> Router Class Initialized
INFO - 2020-02-13 04:18:05 --> Router Class Initialized
INFO - 2020-02-13 04:18:05 --> Router Class Initialized
INFO - 2020-02-13 04:18:05 --> URI Class Initialized
INFO - 2020-02-13 04:18:05 --> URI Class Initialized
INFO - 2020-02-13 04:18:05 --> Router Class Initialized
INFO - 2020-02-13 04:18:05 --> Router Class Initialized
INFO - 2020-02-13 04:18:05 --> Output Class Initialized
INFO - 2020-02-13 04:18:05 --> Output Class Initialized
INFO - 2020-02-13 04:18:05 --> Router Class Initialized
INFO - 2020-02-13 04:18:05 --> Output Class Initialized
INFO - 2020-02-13 04:18:05 --> Security Class Initialized
INFO - 2020-02-13 04:18:05 --> Output Class Initialized
INFO - 2020-02-13 04:18:05 --> Security Class Initialized
INFO - 2020-02-13 04:18:05 --> Output Class Initialized
INFO - 2020-02-13 04:18:05 --> Security Class Initialized
INFO - 2020-02-13 04:18:05 --> Output Class Initialized
DEBUG - 2020-02-13 04:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:05 --> Security Class Initialized
INFO - 2020-02-13 04:18:05 --> Security Class Initialized
DEBUG - 2020-02-13 04:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:05 --> Security Class Initialized
INFO - 2020-02-13 04:18:05 --> Input Class Initialized
INFO - 2020-02-13 04:18:05 --> Input Class Initialized
INFO - 2020-02-13 04:18:05 --> Input Class Initialized
DEBUG - 2020-02-13 04:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:05 --> Input Class Initialized
INFO - 2020-02-13 04:18:05 --> Input Class Initialized
INFO - 2020-02-13 04:18:05 --> Input Class Initialized
INFO - 2020-02-13 04:18:05 --> Language Class Initialized
INFO - 2020-02-13 04:18:05 --> Language Class Initialized
INFO - 2020-02-13 04:18:05 --> Language Class Initialized
INFO - 2020-02-13 04:18:05 --> Language Class Initialized
ERROR - 2020-02-13 04:18:05 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 04:18:05 --> Language Class Initialized
INFO - 2020-02-13 04:18:05 --> Language Class Initialized
ERROR - 2020-02-13 04:18:05 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 04:18:05 --> Loader Class Initialized
ERROR - 2020-02-13 04:18:05 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 04:18:05 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 04:18:05 --> Helper loaded: url_helper
INFO - 2020-02-13 04:18:05 --> Loader Class Initialized
INFO - 2020-02-13 04:18:05 --> Config Class Initialized
INFO - 2020-02-13 04:18:05 --> Config Class Initialized
INFO - 2020-02-13 04:18:05 --> Hooks Class Initialized
INFO - 2020-02-13 04:18:05 --> Hooks Class Initialized
INFO - 2020-02-13 04:18:05 --> Helper loaded: string_helper
INFO - 2020-02-13 04:18:05 --> Helper loaded: url_helper
INFO - 2020-02-13 04:18:05 --> Config Class Initialized
INFO - 2020-02-13 04:18:05 --> Config Class Initialized
INFO - 2020-02-13 04:18:05 --> Hooks Class Initialized
INFO - 2020-02-13 04:18:05 --> Helper loaded: string_helper
INFO - 2020-02-13 04:18:05 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:18:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:18:05 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:05 --> Database Driver Class Initialized
INFO - 2020-02-13 04:18:05 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:05 --> Utf8 Class Initialized
DEBUG - 2020-02-13 04:18:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:18:05 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:05 --> Database Driver Class Initialized
DEBUG - 2020-02-13 04:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:18:05 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:18:05 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:05 --> URI Class Initialized
INFO - 2020-02-13 04:18:05 --> URI Class Initialized
DEBUG - 2020-02-13 04:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 04:18:05 --> Controller Class Initialized
INFO - 2020-02-13 04:18:05 --> URI Class Initialized
INFO - 2020-02-13 04:18:05 --> Router Class Initialized
INFO - 2020-02-13 04:18:05 --> Router Class Initialized
INFO - 2020-02-13 04:18:05 --> URI Class Initialized
INFO - 2020-02-13 04:18:05 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:18:05 --> Router Class Initialized
INFO - 2020-02-13 04:18:05 --> Output Class Initialized
INFO - 2020-02-13 04:18:05 --> Router Class Initialized
INFO - 2020-02-13 04:18:05 --> Output Class Initialized
INFO - 2020-02-13 04:18:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:18:05 --> Security Class Initialized
INFO - 2020-02-13 04:18:05 --> Security Class Initialized
INFO - 2020-02-13 04:18:05 --> Output Class Initialized
INFO - 2020-02-13 04:18:05 --> Output Class Initialized
INFO - 2020-02-13 04:18:05 --> Model "M_pesan" initialized
INFO - 2020-02-13 04:18:05 --> Security Class Initialized
DEBUG - 2020-02-13 04:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:05 --> Security Class Initialized
INFO - 2020-02-13 04:18:05 --> Input Class Initialized
INFO - 2020-02-13 04:18:05 --> Input Class Initialized
DEBUG - 2020-02-13 04:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:05 --> Helper loaded: form_helper
INFO - 2020-02-13 04:18:06 --> Input Class Initialized
INFO - 2020-02-13 04:18:06 --> Form Validation Class Initialized
INFO - 2020-02-13 04:18:06 --> Input Class Initialized
INFO - 2020-02-13 04:18:06 --> Language Class Initialized
INFO - 2020-02-13 04:18:06 --> Language Class Initialized
INFO - 2020-02-13 04:18:06 --> Language Class Initialized
ERROR - 2020-02-13 04:18:06 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 04:18:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 04:18:06 --> Language Class Initialized
ERROR - 2020-02-13 04:18:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 04:18:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 04:18:06 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 04:18:06 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 04:18:06 --> Config Class Initialized
INFO - 2020-02-13 04:18:06 --> Config Class Initialized
INFO - 2020-02-13 04:18:06 --> Hooks Class Initialized
INFO - 2020-02-13 04:18:06 --> Hooks Class Initialized
INFO - 2020-02-13 04:18:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:18:06 --> Config Class Initialized
INFO - 2020-02-13 04:18:06 --> Config Class Initialized
INFO - 2020-02-13 04:18:06 --> Hooks Class Initialized
INFO - 2020-02-13 04:18:06 --> Hooks Class Initialized
INFO - 2020-02-13 04:18:06 --> Final output sent to browser
DEBUG - 2020-02-13 04:18:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:18:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:18:06 --> Total execution time: 0.9295
INFO - 2020-02-13 04:18:06 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:06 --> Utf8 Class Initialized
DEBUG - 2020-02-13 04:18:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 04:18:06 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:06 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:06 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 04:18:06 --> URI Class Initialized
INFO - 2020-02-13 04:18:06 --> URI Class Initialized
INFO - 2020-02-13 04:18:06 --> Controller Class Initialized
INFO - 2020-02-13 04:18:06 --> URI Class Initialized
INFO - 2020-02-13 04:18:06 --> Router Class Initialized
INFO - 2020-02-13 04:18:06 --> URI Class Initialized
INFO - 2020-02-13 04:18:06 --> Router Class Initialized
INFO - 2020-02-13 04:18:06 --> Router Class Initialized
INFO - 2020-02-13 04:18:06 --> Output Class Initialized
INFO - 2020-02-13 04:18:06 --> Output Class Initialized
INFO - 2020-02-13 04:18:06 --> Model "M_tiket" initialized
INFO - 2020-02-13 04:18:06 --> Router Class Initialized
INFO - 2020-02-13 04:18:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 04:18:06 --> Security Class Initialized
INFO - 2020-02-13 04:18:06 --> Security Class Initialized
INFO - 2020-02-13 04:18:06 --> Output Class Initialized
INFO - 2020-02-13 04:18:06 --> Output Class Initialized
INFO - 2020-02-13 04:18:06 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 04:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:06 --> Security Class Initialized
INFO - 2020-02-13 04:18:06 --> Security Class Initialized
DEBUG - 2020-02-13 04:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:06 --> Input Class Initialized
INFO - 2020-02-13 04:18:06 --> Input Class Initialized
DEBUG - 2020-02-13 04:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 04:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:06 --> Helper loaded: form_helper
INFO - 2020-02-13 04:18:06 --> Input Class Initialized
INFO - 2020-02-13 04:18:06 --> Form Validation Class Initialized
INFO - 2020-02-13 04:18:06 --> Input Class Initialized
INFO - 2020-02-13 04:18:06 --> Language Class Initialized
INFO - 2020-02-13 04:18:06 --> Language Class Initialized
INFO - 2020-02-13 04:18:06 --> Language Class Initialized
ERROR - 2020-02-13 04:18:06 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 04:18:06 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 04:18:06 --> Language Class Initialized
ERROR - 2020-02-13 04:18:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 04:18:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 04:18:06 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 04:18:06 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 04:18:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 04:18:06 --> Config Class Initialized
INFO - 2020-02-13 04:18:06 --> Hooks Class Initialized
INFO - 2020-02-13 04:18:06 --> Final output sent to browser
DEBUG - 2020-02-13 04:18:06 --> Total execution time: 1.1911
DEBUG - 2020-02-13 04:18:06 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:06 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:06 --> URI Class Initialized
INFO - 2020-02-13 04:18:06 --> Router Class Initialized
INFO - 2020-02-13 04:18:06 --> Output Class Initialized
INFO - 2020-02-13 04:18:06 --> Security Class Initialized
DEBUG - 2020-02-13 04:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:06 --> Input Class Initialized
INFO - 2020-02-13 04:18:06 --> Language Class Initialized
ERROR - 2020-02-13 04:18:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 04:18:06 --> Config Class Initialized
INFO - 2020-02-13 04:18:06 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:18:06 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:06 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:06 --> URI Class Initialized
INFO - 2020-02-13 04:18:06 --> Router Class Initialized
INFO - 2020-02-13 04:18:07 --> Output Class Initialized
INFO - 2020-02-13 04:18:07 --> Security Class Initialized
DEBUG - 2020-02-13 04:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:07 --> Input Class Initialized
INFO - 2020-02-13 04:18:07 --> Language Class Initialized
ERROR - 2020-02-13 04:18:07 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 04:18:07 --> Config Class Initialized
INFO - 2020-02-13 04:18:07 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:18:07 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:07 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:07 --> URI Class Initialized
INFO - 2020-02-13 04:18:07 --> Router Class Initialized
INFO - 2020-02-13 04:18:07 --> Output Class Initialized
INFO - 2020-02-13 04:18:07 --> Security Class Initialized
DEBUG - 2020-02-13 04:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:07 --> Input Class Initialized
INFO - 2020-02-13 04:18:07 --> Language Class Initialized
ERROR - 2020-02-13 04:18:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 04:18:07 --> Config Class Initialized
INFO - 2020-02-13 04:18:07 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:18:07 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:07 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:07 --> URI Class Initialized
INFO - 2020-02-13 04:18:07 --> Router Class Initialized
INFO - 2020-02-13 04:18:07 --> Output Class Initialized
INFO - 2020-02-13 04:18:07 --> Security Class Initialized
DEBUG - 2020-02-13 04:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:07 --> Input Class Initialized
INFO - 2020-02-13 04:18:08 --> Language Class Initialized
ERROR - 2020-02-13 04:18:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 04:18:08 --> Config Class Initialized
INFO - 2020-02-13 04:18:08 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:18:08 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:08 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:08 --> URI Class Initialized
INFO - 2020-02-13 04:18:08 --> Router Class Initialized
INFO - 2020-02-13 04:18:08 --> Output Class Initialized
INFO - 2020-02-13 04:18:08 --> Security Class Initialized
DEBUG - 2020-02-13 04:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:08 --> Input Class Initialized
INFO - 2020-02-13 04:18:08 --> Language Class Initialized
ERROR - 2020-02-13 04:18:08 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 04:18:08 --> Config Class Initialized
INFO - 2020-02-13 04:18:08 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:18:08 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:08 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:08 --> URI Class Initialized
INFO - 2020-02-13 04:18:08 --> Router Class Initialized
INFO - 2020-02-13 04:18:08 --> Output Class Initialized
INFO - 2020-02-13 04:18:08 --> Security Class Initialized
DEBUG - 2020-02-13 04:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:08 --> Input Class Initialized
INFO - 2020-02-13 04:18:08 --> Language Class Initialized
ERROR - 2020-02-13 04:18:08 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 04:18:08 --> Config Class Initialized
INFO - 2020-02-13 04:18:08 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:18:09 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:09 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:09 --> URI Class Initialized
INFO - 2020-02-13 04:18:09 --> Router Class Initialized
INFO - 2020-02-13 04:18:09 --> Output Class Initialized
INFO - 2020-02-13 04:18:09 --> Security Class Initialized
DEBUG - 2020-02-13 04:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:09 --> Input Class Initialized
INFO - 2020-02-13 04:18:09 --> Language Class Initialized
ERROR - 2020-02-13 04:18:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 04:18:09 --> Config Class Initialized
INFO - 2020-02-13 04:18:09 --> Hooks Class Initialized
DEBUG - 2020-02-13 04:18:09 --> UTF-8 Support Enabled
INFO - 2020-02-13 04:18:09 --> Utf8 Class Initialized
INFO - 2020-02-13 04:18:09 --> URI Class Initialized
INFO - 2020-02-13 04:18:09 --> Router Class Initialized
INFO - 2020-02-13 04:18:09 --> Output Class Initialized
INFO - 2020-02-13 04:18:09 --> Security Class Initialized
DEBUG - 2020-02-13 04:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 04:18:09 --> Input Class Initialized
INFO - 2020-02-13 04:18:09 --> Language Class Initialized
ERROR - 2020-02-13 04:18:09 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 06:28:54 --> Config Class Initialized
INFO - 2020-02-13 06:28:55 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:28:55 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:28:55 --> Utf8 Class Initialized
INFO - 2020-02-13 06:28:55 --> URI Class Initialized
DEBUG - 2020-02-13 06:28:55 --> No URI present. Default controller set.
INFO - 2020-02-13 06:28:55 --> Router Class Initialized
INFO - 2020-02-13 06:28:55 --> Output Class Initialized
INFO - 2020-02-13 06:28:55 --> Security Class Initialized
DEBUG - 2020-02-13 06:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:28:55 --> Input Class Initialized
INFO - 2020-02-13 06:28:55 --> Language Class Initialized
INFO - 2020-02-13 06:28:56 --> Loader Class Initialized
INFO - 2020-02-13 06:28:56 --> Helper loaded: url_helper
INFO - 2020-02-13 06:28:56 --> Helper loaded: string_helper
INFO - 2020-02-13 06:28:56 --> Database Driver Class Initialized
DEBUG - 2020-02-13 06:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 06:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 06:28:57 --> Controller Class Initialized
INFO - 2020-02-13 06:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 06:28:57 --> Pagination Class Initialized
INFO - 2020-02-13 06:28:57 --> Model "M_show" initialized
INFO - 2020-02-13 06:28:57 --> Helper loaded: form_helper
INFO - 2020-02-13 06:28:57 --> Form Validation Class Initialized
INFO - 2020-02-13 06:28:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 06:28:57 --> Final output sent to browser
DEBUG - 2020-02-13 06:28:57 --> Total execution time: 3.3816
INFO - 2020-02-13 06:29:01 --> Config Class Initialized
INFO - 2020-02-13 06:29:01 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:29:01 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:29:01 --> Utf8 Class Initialized
INFO - 2020-02-13 06:29:01 --> URI Class Initialized
INFO - 2020-02-13 06:29:01 --> Router Class Initialized
INFO - 2020-02-13 06:29:01 --> Output Class Initialized
INFO - 2020-02-13 06:29:01 --> Security Class Initialized
DEBUG - 2020-02-13 06:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:29:02 --> Input Class Initialized
INFO - 2020-02-13 06:29:02 --> Language Class Initialized
INFO - 2020-02-13 06:29:02 --> Loader Class Initialized
INFO - 2020-02-13 06:29:02 --> Helper loaded: url_helper
INFO - 2020-02-13 06:29:02 --> Helper loaded: string_helper
INFO - 2020-02-13 06:29:02 --> Database Driver Class Initialized
DEBUG - 2020-02-13 06:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 06:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 06:29:02 --> Controller Class Initialized
INFO - 2020-02-13 06:29:02 --> Model "M_tiket" initialized
INFO - 2020-02-13 06:29:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 06:29:03 --> Model "M_pesan" initialized
INFO - 2020-02-13 06:29:03 --> Helper loaded: form_helper
INFO - 2020-02-13 06:29:03 --> Form Validation Class Initialized
ERROR - 2020-02-13 06:29:03 --> Severity: Notice --> Undefined variable: totalbayar C:\xampp\htdocs\roadshow\application\views\Pemesanan\bukti_nanti.php 18
ERROR - 2020-02-13 06:29:03 --> Severity: Notice --> Undefined variable: norek C:\xampp\htdocs\roadshow\application\views\Pemesanan\bukti_nanti.php 21
ERROR - 2020-02-13 06:29:03 --> Severity: Notice --> Undefined variable: atasnama C:\xampp\htdocs\roadshow\application\views\Pemesanan\bukti_nanti.php 22
INFO - 2020-02-13 06:29:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/bukti_nanti.php
INFO - 2020-02-13 06:29:03 --> Final output sent to browser
DEBUG - 2020-02-13 06:29:04 --> Total execution time: 3.0030
INFO - 2020-02-13 06:30:19 --> Config Class Initialized
INFO - 2020-02-13 06:30:19 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:30:19 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:30:19 --> Utf8 Class Initialized
INFO - 2020-02-13 06:30:19 --> URI Class Initialized
INFO - 2020-02-13 06:30:20 --> Router Class Initialized
INFO - 2020-02-13 06:30:20 --> Output Class Initialized
INFO - 2020-02-13 06:30:20 --> Security Class Initialized
DEBUG - 2020-02-13 06:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:30:20 --> Input Class Initialized
INFO - 2020-02-13 06:30:20 --> Language Class Initialized
INFO - 2020-02-13 06:30:20 --> Loader Class Initialized
INFO - 2020-02-13 06:30:20 --> Helper loaded: url_helper
INFO - 2020-02-13 06:30:20 --> Helper loaded: string_helper
INFO - 2020-02-13 06:30:20 --> Database Driver Class Initialized
DEBUG - 2020-02-13 06:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 06:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 06:30:20 --> Controller Class Initialized
INFO - 2020-02-13 06:30:20 --> Model "M_tiket" initialized
INFO - 2020-02-13 06:30:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 06:30:20 --> Model "M_pesan" initialized
INFO - 2020-02-13 06:30:20 --> Helper loaded: form_helper
INFO - 2020-02-13 06:30:20 --> Form Validation Class Initialized
INFO - 2020-02-13 06:30:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/bukti_nanti.php
INFO - 2020-02-13 06:30:20 --> Final output sent to browser
DEBUG - 2020-02-13 06:30:20 --> Total execution time: 0.6810
INFO - 2020-02-13 06:33:13 --> Config Class Initialized
INFO - 2020-02-13 06:33:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:33:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:14 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:14 --> URI Class Initialized
DEBUG - 2020-02-13 06:33:14 --> No URI present. Default controller set.
INFO - 2020-02-13 06:33:14 --> Router Class Initialized
INFO - 2020-02-13 06:33:14 --> Output Class Initialized
INFO - 2020-02-13 06:33:14 --> Security Class Initialized
DEBUG - 2020-02-13 06:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:14 --> Input Class Initialized
INFO - 2020-02-13 06:33:14 --> Language Class Initialized
INFO - 2020-02-13 06:33:14 --> Loader Class Initialized
INFO - 2020-02-13 06:33:14 --> Helper loaded: url_helper
INFO - 2020-02-13 06:33:14 --> Helper loaded: string_helper
INFO - 2020-02-13 06:33:14 --> Database Driver Class Initialized
DEBUG - 2020-02-13 06:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 06:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 06:33:14 --> Controller Class Initialized
INFO - 2020-02-13 06:33:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 06:33:14 --> Pagination Class Initialized
INFO - 2020-02-13 06:33:14 --> Model "M_show" initialized
INFO - 2020-02-13 06:33:14 --> Helper loaded: form_helper
INFO - 2020-02-13 06:33:14 --> Form Validation Class Initialized
INFO - 2020-02-13 06:33:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 06:33:14 --> Final output sent to browser
DEBUG - 2020-02-13 06:33:14 --> Total execution time: 1.4993
INFO - 2020-02-13 06:33:18 --> Config Class Initialized
INFO - 2020-02-13 06:33:19 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:33:19 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:19 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:19 --> URI Class Initialized
INFO - 2020-02-13 06:33:19 --> Router Class Initialized
INFO - 2020-02-13 06:33:19 --> Output Class Initialized
INFO - 2020-02-13 06:33:19 --> Security Class Initialized
DEBUG - 2020-02-13 06:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:19 --> Input Class Initialized
INFO - 2020-02-13 06:33:19 --> Language Class Initialized
INFO - 2020-02-13 06:33:19 --> Loader Class Initialized
INFO - 2020-02-13 06:33:19 --> Helper loaded: url_helper
INFO - 2020-02-13 06:33:19 --> Helper loaded: string_helper
INFO - 2020-02-13 06:33:19 --> Database Driver Class Initialized
DEBUG - 2020-02-13 06:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 06:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 06:33:19 --> Controller Class Initialized
INFO - 2020-02-13 06:33:19 --> Model "M_tiket" initialized
INFO - 2020-02-13 06:33:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 06:33:19 --> Model "M_pesan" initialized
INFO - 2020-02-13 06:33:19 --> Helper loaded: form_helper
INFO - 2020-02-13 06:33:19 --> Form Validation Class Initialized
INFO - 2020-02-13 06:33:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 06:33:19 --> Final output sent to browser
DEBUG - 2020-02-13 06:33:19 --> Total execution time: 1.1934
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:20 --> Utf8 Class Initialized
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:20 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:20 --> URI Class Initialized
INFO - 2020-02-13 06:33:20 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:20 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:20 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:20 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:20 --> URI Class Initialized
INFO - 2020-02-13 06:33:20 --> URI Class Initialized
INFO - 2020-02-13 06:33:20 --> URI Class Initialized
INFO - 2020-02-13 06:33:20 --> URI Class Initialized
INFO - 2020-02-13 06:33:20 --> URI Class Initialized
INFO - 2020-02-13 06:33:20 --> Router Class Initialized
INFO - 2020-02-13 06:33:20 --> Router Class Initialized
INFO - 2020-02-13 06:33:20 --> Router Class Initialized
INFO - 2020-02-13 06:33:20 --> Router Class Initialized
INFO - 2020-02-13 06:33:20 --> Output Class Initialized
INFO - 2020-02-13 06:33:20 --> Router Class Initialized
INFO - 2020-02-13 06:33:20 --> Router Class Initialized
INFO - 2020-02-13 06:33:20 --> Output Class Initialized
INFO - 2020-02-13 06:33:20 --> Output Class Initialized
INFO - 2020-02-13 06:33:20 --> Output Class Initialized
INFO - 2020-02-13 06:33:20 --> Security Class Initialized
INFO - 2020-02-13 06:33:20 --> Output Class Initialized
INFO - 2020-02-13 06:33:20 --> Output Class Initialized
INFO - 2020-02-13 06:33:20 --> Security Class Initialized
INFO - 2020-02-13 06:33:20 --> Security Class Initialized
INFO - 2020-02-13 06:33:20 --> Security Class Initialized
INFO - 2020-02-13 06:33:20 --> Security Class Initialized
INFO - 2020-02-13 06:33:20 --> Security Class Initialized
DEBUG - 2020-02-13 06:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:20 --> Input Class Initialized
DEBUG - 2020-02-13 06:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 06:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 06:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 06:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 06:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:20 --> Input Class Initialized
INFO - 2020-02-13 06:33:20 --> Input Class Initialized
INFO - 2020-02-13 06:33:20 --> Input Class Initialized
INFO - 2020-02-13 06:33:20 --> Input Class Initialized
INFO - 2020-02-13 06:33:20 --> Input Class Initialized
INFO - 2020-02-13 06:33:20 --> Language Class Initialized
INFO - 2020-02-13 06:33:20 --> Language Class Initialized
INFO - 2020-02-13 06:33:20 --> Language Class Initialized
INFO - 2020-02-13 06:33:20 --> Language Class Initialized
INFO - 2020-02-13 06:33:20 --> Language Class Initialized
INFO - 2020-02-13 06:33:20 --> Language Class Initialized
ERROR - 2020-02-13 06:33:20 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-13 06:33:20 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 06:33:20 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 06:33:20 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 06:33:20 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-13 06:33:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:20 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:20 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:20 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:20 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:20 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:20 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:20 --> URI Class Initialized
INFO - 2020-02-13 06:33:20 --> URI Class Initialized
INFO - 2020-02-13 06:33:20 --> URI Class Initialized
INFO - 2020-02-13 06:33:20 --> URI Class Initialized
INFO - 2020-02-13 06:33:20 --> URI Class Initialized
INFO - 2020-02-13 06:33:20 --> URI Class Initialized
INFO - 2020-02-13 06:33:20 --> Router Class Initialized
INFO - 2020-02-13 06:33:20 --> Router Class Initialized
INFO - 2020-02-13 06:33:20 --> Router Class Initialized
INFO - 2020-02-13 06:33:20 --> Router Class Initialized
INFO - 2020-02-13 06:33:20 --> Router Class Initialized
INFO - 2020-02-13 06:33:20 --> Router Class Initialized
INFO - 2020-02-13 06:33:20 --> Output Class Initialized
INFO - 2020-02-13 06:33:20 --> Output Class Initialized
INFO - 2020-02-13 06:33:20 --> Output Class Initialized
INFO - 2020-02-13 06:33:20 --> Output Class Initialized
INFO - 2020-02-13 06:33:20 --> Output Class Initialized
INFO - 2020-02-13 06:33:20 --> Output Class Initialized
INFO - 2020-02-13 06:33:20 --> Security Class Initialized
INFO - 2020-02-13 06:33:20 --> Security Class Initialized
INFO - 2020-02-13 06:33:20 --> Security Class Initialized
INFO - 2020-02-13 06:33:20 --> Security Class Initialized
INFO - 2020-02-13 06:33:20 --> Security Class Initialized
INFO - 2020-02-13 06:33:20 --> Security Class Initialized
DEBUG - 2020-02-13 06:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 06:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 06:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 06:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 06:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 06:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:20 --> Input Class Initialized
INFO - 2020-02-13 06:33:20 --> Input Class Initialized
INFO - 2020-02-13 06:33:20 --> Input Class Initialized
INFO - 2020-02-13 06:33:20 --> Input Class Initialized
INFO - 2020-02-13 06:33:20 --> Input Class Initialized
INFO - 2020-02-13 06:33:20 --> Input Class Initialized
INFO - 2020-02-13 06:33:20 --> Language Class Initialized
INFO - 2020-02-13 06:33:20 --> Language Class Initialized
INFO - 2020-02-13 06:33:20 --> Language Class Initialized
INFO - 2020-02-13 06:33:20 --> Language Class Initialized
INFO - 2020-02-13 06:33:20 --> Language Class Initialized
INFO - 2020-02-13 06:33:20 --> Language Class Initialized
ERROR - 2020-02-13 06:33:20 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 06:33:20 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 06:33:20 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 06:33:20 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 06:33:20 --> Loader Class Initialized
INFO - 2020-02-13 06:33:20 --> Loader Class Initialized
INFO - 2020-02-13 06:33:20 --> Helper loaded: url_helper
INFO - 2020-02-13 06:33:20 --> Helper loaded: url_helper
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Config Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:20 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:20 --> Helper loaded: string_helper
INFO - 2020-02-13 06:33:20 --> Helper loaded: string_helper
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 06:33:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:20 --> Database Driver Class Initialized
INFO - 2020-02-13 06:33:20 --> Database Driver Class Initialized
INFO - 2020-02-13 06:33:21 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:21 --> Utf8 Class Initialized
DEBUG - 2020-02-13 06:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 06:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 06:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 06:33:21 --> URI Class Initialized
INFO - 2020-02-13 06:33:21 --> URI Class Initialized
INFO - 2020-02-13 06:33:21 --> Controller Class Initialized
INFO - 2020-02-13 06:33:21 --> Router Class Initialized
INFO - 2020-02-13 06:33:21 --> Router Class Initialized
INFO - 2020-02-13 06:33:21 --> Model "M_tiket" initialized
INFO - 2020-02-13 06:33:21 --> Output Class Initialized
INFO - 2020-02-13 06:33:21 --> Output Class Initialized
INFO - 2020-02-13 06:33:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 06:33:21 --> Security Class Initialized
INFO - 2020-02-13 06:33:21 --> Security Class Initialized
INFO - 2020-02-13 06:33:21 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 06:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:21 --> Input Class Initialized
DEBUG - 2020-02-13 06:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:21 --> Helper loaded: form_helper
INFO - 2020-02-13 06:33:21 --> Form Validation Class Initialized
INFO - 2020-02-13 06:33:21 --> Input Class Initialized
INFO - 2020-02-13 06:33:21 --> Language Class Initialized
INFO - 2020-02-13 06:33:21 --> Language Class Initialized
ERROR - 2020-02-13 06:33:21 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 06:33:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 06:33:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 06:33:21 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 06:33:21 --> Config Class Initialized
INFO - 2020-02-13 06:33:21 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 06:33:21 --> Final output sent to browser
DEBUG - 2020-02-13 06:33:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:21 --> Utf8 Class Initialized
DEBUG - 2020-02-13 06:33:21 --> Total execution time: 1.0699
INFO - 2020-02-13 06:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 06:33:21 --> URI Class Initialized
INFO - 2020-02-13 06:33:21 --> Controller Class Initialized
INFO - 2020-02-13 06:33:21 --> Router Class Initialized
INFO - 2020-02-13 06:33:21 --> Model "M_tiket" initialized
INFO - 2020-02-13 06:33:21 --> Output Class Initialized
INFO - 2020-02-13 06:33:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 06:33:21 --> Security Class Initialized
DEBUG - 2020-02-13 06:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:21 --> Model "M_pesan" initialized
INFO - 2020-02-13 06:33:21 --> Input Class Initialized
INFO - 2020-02-13 06:33:21 --> Helper loaded: form_helper
INFO - 2020-02-13 06:33:21 --> Form Validation Class Initialized
INFO - 2020-02-13 06:33:21 --> Language Class Initialized
ERROR - 2020-02-13 06:33:21 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 06:33:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 06:33:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 06:33:22 --> Config Class Initialized
INFO - 2020-02-13 06:33:22 --> Hooks Class Initialized
INFO - 2020-02-13 06:33:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 06:33:22 --> Final output sent to browser
DEBUG - 2020-02-13 06:33:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:22 --> Utf8 Class Initialized
DEBUG - 2020-02-13 06:33:22 --> Total execution time: 1.5855
INFO - 2020-02-13 06:33:22 --> URI Class Initialized
INFO - 2020-02-13 06:33:22 --> Router Class Initialized
INFO - 2020-02-13 06:33:22 --> Output Class Initialized
INFO - 2020-02-13 06:33:22 --> Security Class Initialized
DEBUG - 2020-02-13 06:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:22 --> Input Class Initialized
INFO - 2020-02-13 06:33:22 --> Language Class Initialized
ERROR - 2020-02-13 06:33:22 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 06:33:22 --> Config Class Initialized
INFO - 2020-02-13 06:33:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:33:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:22 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:22 --> URI Class Initialized
INFO - 2020-02-13 06:33:22 --> Router Class Initialized
INFO - 2020-02-13 06:33:22 --> Output Class Initialized
INFO - 2020-02-13 06:33:22 --> Security Class Initialized
DEBUG - 2020-02-13 06:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:23 --> Input Class Initialized
INFO - 2020-02-13 06:33:23 --> Language Class Initialized
ERROR - 2020-02-13 06:33:23 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 06:33:23 --> Config Class Initialized
INFO - 2020-02-13 06:33:23 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:33:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:23 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:23 --> URI Class Initialized
INFO - 2020-02-13 06:33:23 --> Router Class Initialized
INFO - 2020-02-13 06:33:23 --> Output Class Initialized
INFO - 2020-02-13 06:33:23 --> Security Class Initialized
DEBUG - 2020-02-13 06:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:23 --> Input Class Initialized
INFO - 2020-02-13 06:33:23 --> Language Class Initialized
ERROR - 2020-02-13 06:33:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 06:33:23 --> Config Class Initialized
INFO - 2020-02-13 06:33:23 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:33:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:23 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:23 --> URI Class Initialized
INFO - 2020-02-13 06:33:23 --> Router Class Initialized
INFO - 2020-02-13 06:33:24 --> Output Class Initialized
INFO - 2020-02-13 06:33:24 --> Security Class Initialized
DEBUG - 2020-02-13 06:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:24 --> Input Class Initialized
INFO - 2020-02-13 06:33:24 --> Language Class Initialized
ERROR - 2020-02-13 06:33:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 06:33:24 --> Config Class Initialized
INFO - 2020-02-13 06:33:24 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:33:24 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:24 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:24 --> URI Class Initialized
INFO - 2020-02-13 06:33:24 --> Router Class Initialized
INFO - 2020-02-13 06:33:24 --> Output Class Initialized
INFO - 2020-02-13 06:33:24 --> Security Class Initialized
DEBUG - 2020-02-13 06:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:24 --> Input Class Initialized
INFO - 2020-02-13 06:33:24 --> Language Class Initialized
ERROR - 2020-02-13 06:33:24 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 06:33:24 --> Config Class Initialized
INFO - 2020-02-13 06:33:24 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:33:24 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:24 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:24 --> URI Class Initialized
INFO - 2020-02-13 06:33:24 --> Router Class Initialized
INFO - 2020-02-13 06:33:24 --> Output Class Initialized
INFO - 2020-02-13 06:33:24 --> Security Class Initialized
DEBUG - 2020-02-13 06:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:24 --> Input Class Initialized
INFO - 2020-02-13 06:33:24 --> Language Class Initialized
ERROR - 2020-02-13 06:33:24 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 06:33:24 --> Config Class Initialized
INFO - 2020-02-13 06:33:25 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:33:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:25 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:25 --> URI Class Initialized
INFO - 2020-02-13 06:33:25 --> Router Class Initialized
INFO - 2020-02-13 06:33:25 --> Output Class Initialized
INFO - 2020-02-13 06:33:25 --> Security Class Initialized
DEBUG - 2020-02-13 06:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:25 --> Input Class Initialized
INFO - 2020-02-13 06:33:25 --> Language Class Initialized
ERROR - 2020-02-13 06:33:25 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 06:33:25 --> Config Class Initialized
INFO - 2020-02-13 06:33:25 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:33:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 06:33:25 --> Utf8 Class Initialized
INFO - 2020-02-13 06:33:25 --> URI Class Initialized
INFO - 2020-02-13 06:33:25 --> Router Class Initialized
INFO - 2020-02-13 06:33:25 --> Output Class Initialized
INFO - 2020-02-13 06:33:25 --> Security Class Initialized
DEBUG - 2020-02-13 06:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 06:33:25 --> Input Class Initialized
INFO - 2020-02-13 06:33:25 --> Language Class Initialized
ERROR - 2020-02-13 06:33:25 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 10:39:04 --> Config Class Initialized
INFO - 2020-02-13 10:39:05 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:39:05 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:39:05 --> Utf8 Class Initialized
INFO - 2020-02-13 10:39:05 --> URI Class Initialized
INFO - 2020-02-13 10:39:05 --> Router Class Initialized
INFO - 2020-02-13 10:39:05 --> Output Class Initialized
INFO - 2020-02-13 10:39:05 --> Security Class Initialized
DEBUG - 2020-02-13 10:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:39:05 --> Input Class Initialized
INFO - 2020-02-13 10:39:05 --> Language Class Initialized
INFO - 2020-02-13 10:39:05 --> Loader Class Initialized
INFO - 2020-02-13 10:39:05 --> Helper loaded: url_helper
INFO - 2020-02-13 10:39:05 --> Helper loaded: string_helper
INFO - 2020-02-13 10:39:06 --> Database Driver Class Initialized
DEBUG - 2020-02-13 10:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:39:06 --> Controller Class Initialized
INFO - 2020-02-13 10:39:06 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:39:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:39:06 --> Model "M_pesan" initialized
INFO - 2020-02-13 10:39:06 --> Helper loaded: form_helper
INFO - 2020-02-13 10:39:06 --> Form Validation Class Initialized
INFO - 2020-02-13 10:39:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 10:39:07 --> Final output sent to browser
DEBUG - 2020-02-13 10:39:07 --> Total execution time: 2.4836
INFO - 2020-02-13 10:39:42 --> Config Class Initialized
INFO - 2020-02-13 10:39:43 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:39:43 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:39:43 --> Utf8 Class Initialized
INFO - 2020-02-13 10:39:43 --> URI Class Initialized
INFO - 2020-02-13 10:39:43 --> Router Class Initialized
INFO - 2020-02-13 10:39:43 --> Output Class Initialized
INFO - 2020-02-13 10:39:43 --> Security Class Initialized
DEBUG - 2020-02-13 10:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:39:43 --> Input Class Initialized
INFO - 2020-02-13 10:39:43 --> Language Class Initialized
INFO - 2020-02-13 10:39:43 --> Loader Class Initialized
INFO - 2020-02-13 10:39:43 --> Helper loaded: url_helper
INFO - 2020-02-13 10:39:43 --> Helper loaded: string_helper
INFO - 2020-02-13 10:39:43 --> Database Driver Class Initialized
DEBUG - 2020-02-13 10:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:39:43 --> Controller Class Initialized
INFO - 2020-02-13 10:39:43 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:39:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:39:43 --> Model "M_pesan" initialized
INFO - 2020-02-13 10:39:43 --> Helper loaded: form_helper
INFO - 2020-02-13 10:39:43 --> Form Validation Class Initialized
INFO - 2020-02-13 10:39:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 10:39:43 --> Final output sent to browser
DEBUG - 2020-02-13 10:39:43 --> Total execution time: 0.8001
INFO - 2020-02-13 10:41:24 --> Config Class Initialized
INFO - 2020-02-13 10:41:24 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:41:24 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:41:24 --> Utf8 Class Initialized
INFO - 2020-02-13 10:41:24 --> URI Class Initialized
INFO - 2020-02-13 10:41:24 --> Router Class Initialized
INFO - 2020-02-13 10:41:24 --> Output Class Initialized
INFO - 2020-02-13 10:41:24 --> Security Class Initialized
DEBUG - 2020-02-13 10:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:41:24 --> Input Class Initialized
INFO - 2020-02-13 10:41:24 --> Language Class Initialized
INFO - 2020-02-13 10:41:24 --> Loader Class Initialized
INFO - 2020-02-13 10:41:24 --> Helper loaded: url_helper
INFO - 2020-02-13 10:41:24 --> Helper loaded: string_helper
INFO - 2020-02-13 10:41:24 --> Database Driver Class Initialized
DEBUG - 2020-02-13 10:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:41:24 --> Controller Class Initialized
INFO - 2020-02-13 10:41:24 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:41:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:41:24 --> Model "M_pesan" initialized
INFO - 2020-02-13 10:41:24 --> Helper loaded: form_helper
INFO - 2020-02-13 10:41:24 --> Form Validation Class Initialized
INFO - 2020-02-13 10:41:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 10:41:25 --> Final output sent to browser
DEBUG - 2020-02-13 10:41:25 --> Total execution time: 0.5804
INFO - 2020-02-13 10:41:25 --> Config Class Initialized
INFO - 2020-02-13 10:41:25 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:41:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:41:25 --> Config Class Initialized
INFO - 2020-02-13 10:41:25 --> Hooks Class Initialized
INFO - 2020-02-13 10:41:25 --> Utf8 Class Initialized
INFO - 2020-02-13 10:41:25 --> Config Class Initialized
INFO - 2020-02-13 10:41:25 --> Hooks Class Initialized
INFO - 2020-02-13 10:41:25 --> URI Class Initialized
DEBUG - 2020-02-13 10:41:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:41:25 --> Utf8 Class Initialized
INFO - 2020-02-13 10:41:25 --> Router Class Initialized
DEBUG - 2020-02-13 10:41:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:41:25 --> Utf8 Class Initialized
INFO - 2020-02-13 10:41:25 --> URI Class Initialized
INFO - 2020-02-13 10:41:25 --> Output Class Initialized
INFO - 2020-02-13 10:41:25 --> URI Class Initialized
INFO - 2020-02-13 10:41:25 --> Security Class Initialized
INFO - 2020-02-13 10:41:25 --> Router Class Initialized
DEBUG - 2020-02-13 10:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:41:25 --> Router Class Initialized
INFO - 2020-02-13 10:41:25 --> Output Class Initialized
INFO - 2020-02-13 10:41:25 --> Input Class Initialized
INFO - 2020-02-13 10:41:25 --> Security Class Initialized
INFO - 2020-02-13 10:41:25 --> Output Class Initialized
INFO - 2020-02-13 10:41:25 --> Language Class Initialized
DEBUG - 2020-02-13 10:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:41:25 --> Security Class Initialized
INFO - 2020-02-13 10:41:25 --> Input Class Initialized
DEBUG - 2020-02-13 10:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:41:25 --> Input Class Initialized
INFO - 2020-02-13 10:41:25 --> Language Class Initialized
ERROR - 2020-02-13 10:41:25 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 10:41:25 --> Language Class Initialized
INFO - 2020-02-13 10:41:25 --> Loader Class Initialized
INFO - 2020-02-13 10:41:25 --> Helper loaded: url_helper
INFO - 2020-02-13 10:41:25 --> Loader Class Initialized
INFO - 2020-02-13 10:41:25 --> Helper loaded: string_helper
INFO - 2020-02-13 10:41:25 --> Helper loaded: url_helper
INFO - 2020-02-13 10:41:25 --> Helper loaded: string_helper
INFO - 2020-02-13 10:41:26 --> Database Driver Class Initialized
DEBUG - 2020-02-13 10:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:41:26 --> Database Driver Class Initialized
INFO - 2020-02-13 10:41:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 10:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:41:26 --> Controller Class Initialized
INFO - 2020-02-13 10:41:26 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:41:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:41:26 --> Model "M_pesan" initialized
INFO - 2020-02-13 10:41:26 --> Helper loaded: form_helper
INFO - 2020-02-13 10:41:26 --> Form Validation Class Initialized
ERROR - 2020-02-13 10:41:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 10:41:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 10:41:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 10:41:26 --> Final output sent to browser
DEBUG - 2020-02-13 10:41:26 --> Total execution time: 0.8435
INFO - 2020-02-13 10:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:41:26 --> Controller Class Initialized
INFO - 2020-02-13 10:41:26 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:41:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:41:26 --> Model "M_pesan" initialized
INFO - 2020-02-13 10:41:26 --> Helper loaded: form_helper
INFO - 2020-02-13 10:41:26 --> Form Validation Class Initialized
ERROR - 2020-02-13 10:41:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 10:41:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 10:41:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 10:41:26 --> Final output sent to browser
DEBUG - 2020-02-13 10:41:26 --> Total execution time: 1.0106
INFO - 2020-02-13 10:41:28 --> Config Class Initialized
INFO - 2020-02-13 10:41:29 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:41:29 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:41:29 --> Utf8 Class Initialized
INFO - 2020-02-13 10:41:29 --> URI Class Initialized
INFO - 2020-02-13 10:41:29 --> Router Class Initialized
INFO - 2020-02-13 10:41:29 --> Output Class Initialized
INFO - 2020-02-13 10:41:29 --> Security Class Initialized
DEBUG - 2020-02-13 10:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:41:29 --> Input Class Initialized
INFO - 2020-02-13 10:41:29 --> Language Class Initialized
INFO - 2020-02-13 10:41:29 --> Loader Class Initialized
INFO - 2020-02-13 10:41:29 --> Helper loaded: url_helper
INFO - 2020-02-13 10:41:29 --> Helper loaded: string_helper
INFO - 2020-02-13 10:41:29 --> Database Driver Class Initialized
DEBUG - 2020-02-13 10:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:41:29 --> Controller Class Initialized
INFO - 2020-02-13 10:41:29 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:41:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:41:29 --> Model "M_pesan" initialized
INFO - 2020-02-13 10:41:29 --> Helper loaded: form_helper
INFO - 2020-02-13 10:41:29 --> Form Validation Class Initialized
INFO - 2020-02-13 10:41:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 10:41:29 --> Final output sent to browser
DEBUG - 2020-02-13 10:41:29 --> Total execution time: 0.6373
INFO - 2020-02-13 10:41:34 --> Config Class Initialized
INFO - 2020-02-13 10:41:34 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:41:34 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:41:34 --> Utf8 Class Initialized
INFO - 2020-02-13 10:41:34 --> URI Class Initialized
INFO - 2020-02-13 10:41:34 --> Router Class Initialized
INFO - 2020-02-13 10:41:34 --> Output Class Initialized
INFO - 2020-02-13 10:41:34 --> Security Class Initialized
DEBUG - 2020-02-13 10:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:41:34 --> Input Class Initialized
INFO - 2020-02-13 10:41:34 --> Language Class Initialized
INFO - 2020-02-13 10:41:35 --> Loader Class Initialized
INFO - 2020-02-13 10:41:35 --> Helper loaded: url_helper
INFO - 2020-02-13 10:41:35 --> Helper loaded: string_helper
INFO - 2020-02-13 10:41:35 --> Database Driver Class Initialized
DEBUG - 2020-02-13 10:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:41:35 --> Controller Class Initialized
INFO - 2020-02-13 10:41:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 10:41:35 --> Pagination Class Initialized
INFO - 2020-02-13 10:41:35 --> Model "M_show" initialized
INFO - 2020-02-13 10:41:35 --> Helper loaded: form_helper
INFO - 2020-02-13 10:41:35 --> Form Validation Class Initialized
INFO - 2020-02-13 10:41:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 10:41:35 --> Final output sent to browser
DEBUG - 2020-02-13 10:41:35 --> Total execution time: 0.6631
INFO - 2020-02-13 10:41:35 --> Config Class Initialized
INFO - 2020-02-13 10:41:35 --> Config Class Initialized
INFO - 2020-02-13 10:41:35 --> Hooks Class Initialized
INFO - 2020-02-13 10:41:35 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:41:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:41:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:41:35 --> Utf8 Class Initialized
INFO - 2020-02-13 10:41:35 --> Utf8 Class Initialized
INFO - 2020-02-13 10:41:35 --> URI Class Initialized
INFO - 2020-02-13 10:41:35 --> URI Class Initialized
INFO - 2020-02-13 10:41:35 --> Router Class Initialized
INFO - 2020-02-13 10:41:35 --> Router Class Initialized
INFO - 2020-02-13 10:41:35 --> Output Class Initialized
INFO - 2020-02-13 10:41:35 --> Output Class Initialized
INFO - 2020-02-13 10:41:35 --> Security Class Initialized
INFO - 2020-02-13 10:41:35 --> Security Class Initialized
DEBUG - 2020-02-13 10:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 10:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:41:35 --> Input Class Initialized
INFO - 2020-02-13 10:41:35 --> Input Class Initialized
INFO - 2020-02-13 10:41:36 --> Language Class Initialized
INFO - 2020-02-13 10:41:36 --> Language Class Initialized
ERROR - 2020-02-13 10:41:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-13 10:41:36 --> 404 Page Not Found: Assets/js
INFO - 2020-02-13 10:41:36 --> Config Class Initialized
INFO - 2020-02-13 10:41:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:41:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:41:36 --> Utf8 Class Initialized
INFO - 2020-02-13 10:41:36 --> URI Class Initialized
INFO - 2020-02-13 10:41:36 --> Router Class Initialized
INFO - 2020-02-13 10:41:36 --> Output Class Initialized
INFO - 2020-02-13 10:41:36 --> Security Class Initialized
DEBUG - 2020-02-13 10:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:41:36 --> Input Class Initialized
INFO - 2020-02-13 10:41:36 --> Language Class Initialized
ERROR - 2020-02-13 10:41:36 --> 404 Page Not Found: Assets/js
INFO - 2020-02-13 10:41:38 --> Config Class Initialized
INFO - 2020-02-13 10:41:38 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:41:38 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:41:38 --> Utf8 Class Initialized
INFO - 2020-02-13 10:41:38 --> URI Class Initialized
INFO - 2020-02-13 10:41:38 --> Router Class Initialized
INFO - 2020-02-13 10:41:38 --> Output Class Initialized
INFO - 2020-02-13 10:41:38 --> Security Class Initialized
DEBUG - 2020-02-13 10:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:41:38 --> Input Class Initialized
INFO - 2020-02-13 10:41:38 --> Language Class Initialized
INFO - 2020-02-13 10:41:38 --> Loader Class Initialized
INFO - 2020-02-13 10:41:38 --> Helper loaded: url_helper
INFO - 2020-02-13 10:41:38 --> Helper loaded: string_helper
INFO - 2020-02-13 10:41:38 --> Database Driver Class Initialized
DEBUG - 2020-02-13 10:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:41:38 --> Controller Class Initialized
INFO - 2020-02-13 10:41:38 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:41:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:41:38 --> Model "M_pesan" initialized
INFO - 2020-02-13 10:41:38 --> Helper loaded: form_helper
INFO - 2020-02-13 10:41:38 --> Form Validation Class Initialized
INFO - 2020-02-13 10:41:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/bukti_nanti.php
INFO - 2020-02-13 10:41:38 --> Final output sent to browser
DEBUG - 2020-02-13 10:41:38 --> Total execution time: 0.4708
INFO - 2020-02-13 10:52:08 --> Config Class Initialized
INFO - 2020-02-13 10:52:08 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:09 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:09 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:09 --> URI Class Initialized
INFO - 2020-02-13 10:52:09 --> Router Class Initialized
INFO - 2020-02-13 10:52:09 --> Output Class Initialized
INFO - 2020-02-13 10:52:09 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:09 --> Input Class Initialized
INFO - 2020-02-13 10:52:09 --> Language Class Initialized
INFO - 2020-02-13 10:52:09 --> Loader Class Initialized
INFO - 2020-02-13 10:52:09 --> Helper loaded: url_helper
INFO - 2020-02-13 10:52:09 --> Helper loaded: string_helper
INFO - 2020-02-13 10:52:09 --> Database Driver Class Initialized
DEBUG - 2020-02-13 10:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:52:09 --> Controller Class Initialized
INFO - 2020-02-13 10:52:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 10:52:09 --> Pagination Class Initialized
INFO - 2020-02-13 10:52:09 --> Model "M_show" initialized
INFO - 2020-02-13 10:52:09 --> Helper loaded: form_helper
INFO - 2020-02-13 10:52:09 --> Form Validation Class Initialized
INFO - 2020-02-13 10:52:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 10:52:09 --> Final output sent to browser
DEBUG - 2020-02-13 10:52:09 --> Total execution time: 0.9333
INFO - 2020-02-13 10:52:12 --> Config Class Initialized
INFO - 2020-02-13 10:52:12 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:12 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:12 --> URI Class Initialized
INFO - 2020-02-13 10:52:12 --> Router Class Initialized
INFO - 2020-02-13 10:52:12 --> Output Class Initialized
INFO - 2020-02-13 10:52:12 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:12 --> Input Class Initialized
INFO - 2020-02-13 10:52:12 --> Language Class Initialized
INFO - 2020-02-13 10:52:12 --> Loader Class Initialized
INFO - 2020-02-13 10:52:12 --> Helper loaded: url_helper
INFO - 2020-02-13 10:52:12 --> Helper loaded: string_helper
INFO - 2020-02-13 10:52:12 --> Database Driver Class Initialized
DEBUG - 2020-02-13 10:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:52:12 --> Controller Class Initialized
INFO - 2020-02-13 10:52:12 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:52:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:52:12 --> Model "M_pesan" initialized
INFO - 2020-02-13 10:52:12 --> Helper loaded: form_helper
INFO - 2020-02-13 10:52:12 --> Form Validation Class Initialized
INFO - 2020-02-13 10:52:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 10:52:12 --> Final output sent to browser
DEBUG - 2020-02-13 10:52:12 --> Total execution time: 0.4983
INFO - 2020-02-13 10:52:12 --> Config Class Initialized
INFO - 2020-02-13 10:52:12 --> Config Class Initialized
INFO - 2020-02-13 10:52:12 --> Config Class Initialized
INFO - 2020-02-13 10:52:12 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:12 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:12 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:12 --> Config Class Initialized
INFO - 2020-02-13 10:52:12 --> Config Class Initialized
INFO - 2020-02-13 10:52:12 --> Config Class Initialized
INFO - 2020-02-13 10:52:12 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:12 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:12 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:12 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:12 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:12 --> Utf8 Class Initialized
DEBUG - 2020-02-13 10:52:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:12 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:12 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:12 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:12 --> URI Class Initialized
INFO - 2020-02-13 10:52:12 --> URI Class Initialized
INFO - 2020-02-13 10:52:12 --> URI Class Initialized
INFO - 2020-02-13 10:52:12 --> URI Class Initialized
INFO - 2020-02-13 10:52:12 --> Router Class Initialized
INFO - 2020-02-13 10:52:12 --> Router Class Initialized
INFO - 2020-02-13 10:52:12 --> Router Class Initialized
INFO - 2020-02-13 10:52:12 --> URI Class Initialized
INFO - 2020-02-13 10:52:12 --> URI Class Initialized
INFO - 2020-02-13 10:52:12 --> Router Class Initialized
INFO - 2020-02-13 10:52:12 --> Router Class Initialized
INFO - 2020-02-13 10:52:12 --> Output Class Initialized
INFO - 2020-02-13 10:52:12 --> Output Class Initialized
INFO - 2020-02-13 10:52:12 --> Output Class Initialized
INFO - 2020-02-13 10:52:12 --> Router Class Initialized
INFO - 2020-02-13 10:52:12 --> Security Class Initialized
INFO - 2020-02-13 10:52:12 --> Output Class Initialized
INFO - 2020-02-13 10:52:12 --> Output Class Initialized
INFO - 2020-02-13 10:52:12 --> Security Class Initialized
INFO - 2020-02-13 10:52:12 --> Security Class Initialized
INFO - 2020-02-13 10:52:12 --> Output Class Initialized
INFO - 2020-02-13 10:52:12 --> Security Class Initialized
INFO - 2020-02-13 10:52:12 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 10:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 10:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:12 --> Security Class Initialized
INFO - 2020-02-13 10:52:12 --> Input Class Initialized
INFO - 2020-02-13 10:52:12 --> Input Class Initialized
DEBUG - 2020-02-13 10:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 10:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:12 --> Input Class Initialized
DEBUG - 2020-02-13 10:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:12 --> Input Class Initialized
INFO - 2020-02-13 10:52:12 --> Input Class Initialized
INFO - 2020-02-13 10:52:12 --> Language Class Initialized
INFO - 2020-02-13 10:52:12 --> Language Class Initialized
INFO - 2020-02-13 10:52:12 --> Language Class Initialized
INFO - 2020-02-13 10:52:12 --> Input Class Initialized
INFO - 2020-02-13 10:52:12 --> Language Class Initialized
INFO - 2020-02-13 10:52:12 --> Language Class Initialized
INFO - 2020-02-13 10:52:12 --> Language Class Initialized
INFO - 2020-02-13 10:52:12 --> Loader Class Initialized
INFO - 2020-02-13 10:52:12 --> Loader Class Initialized
ERROR - 2020-02-13 10:52:12 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 10:52:12 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 10:52:12 --> Helper loaded: url_helper
ERROR - 2020-02-13 10:52:12 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-13 10:52:12 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 10:52:12 --> Helper loaded: url_helper
INFO - 2020-02-13 10:52:12 --> Config Class Initialized
INFO - 2020-02-13 10:52:12 --> Helper loaded: string_helper
INFO - 2020-02-13 10:52:12 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:12 --> Helper loaded: string_helper
INFO - 2020-02-13 10:52:12 --> Config Class Initialized
INFO - 2020-02-13 10:52:12 --> Config Class Initialized
INFO - 2020-02-13 10:52:12 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:12 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:12 --> Config Class Initialized
DEBUG - 2020-02-13 10:52:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:12 --> Database Driver Class Initialized
INFO - 2020-02-13 10:52:12 --> Database Driver Class Initialized
INFO - 2020-02-13 10:52:12 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:12 --> Utf8 Class Initialized
DEBUG - 2020-02-13 10:52:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 10:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 10:52:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:12 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:52:12 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:12 --> URI Class Initialized
DEBUG - 2020-02-13 10:52:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:13 --> Controller Class Initialized
INFO - 2020-02-13 10:52:13 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:13 --> URI Class Initialized
INFO - 2020-02-13 10:52:13 --> URI Class Initialized
INFO - 2020-02-13 10:52:13 --> Router Class Initialized
INFO - 2020-02-13 10:52:13 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:52:13 --> URI Class Initialized
INFO - 2020-02-13 10:52:13 --> Router Class Initialized
INFO - 2020-02-13 10:52:13 --> Router Class Initialized
INFO - 2020-02-13 10:52:13 --> Output Class Initialized
INFO - 2020-02-13 10:52:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:52:13 --> Router Class Initialized
INFO - 2020-02-13 10:52:13 --> Output Class Initialized
INFO - 2020-02-13 10:52:13 --> Output Class Initialized
INFO - 2020-02-13 10:52:13 --> Security Class Initialized
INFO - 2020-02-13 10:52:13 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 10:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:13 --> Security Class Initialized
INFO - 2020-02-13 10:52:13 --> Security Class Initialized
INFO - 2020-02-13 10:52:13 --> Output Class Initialized
INFO - 2020-02-13 10:52:13 --> Input Class Initialized
DEBUG - 2020-02-13 10:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 10:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:13 --> Security Class Initialized
INFO - 2020-02-13 10:52:13 --> Helper loaded: form_helper
INFO - 2020-02-13 10:52:13 --> Form Validation Class Initialized
INFO - 2020-02-13 10:52:13 --> Input Class Initialized
INFO - 2020-02-13 10:52:13 --> Input Class Initialized
INFO - 2020-02-13 10:52:13 --> Language Class Initialized
DEBUG - 2020-02-13 10:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:13 --> Input Class Initialized
INFO - 2020-02-13 10:52:13 --> Language Class Initialized
INFO - 2020-02-13 10:52:13 --> Language Class Initialized
ERROR - 2020-02-13 10:52:13 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 10:52:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-13 10:52:13 --> Language Class Initialized
ERROR - 2020-02-13 10:52:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 10:52:13 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 10:52:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 10:52:13 --> Config Class Initialized
INFO - 2020-02-13 10:52:13 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 10:52:13 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 10:52:13 --> Config Class Initialized
INFO - 2020-02-13 10:52:13 --> Config Class Initialized
INFO - 2020-02-13 10:52:13 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:13 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:13 --> Final output sent to browser
DEBUG - 2020-02-13 10:52:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:13 --> Config Class Initialized
INFO - 2020-02-13 10:52:13 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:13 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:13 --> Total execution time: 0.6170
DEBUG - 2020-02-13 10:52:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:13 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:13 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:52:13 --> URI Class Initialized
DEBUG - 2020-02-13 10:52:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:13 --> Controller Class Initialized
INFO - 2020-02-13 10:52:13 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:13 --> URI Class Initialized
INFO - 2020-02-13 10:52:13 --> URI Class Initialized
INFO - 2020-02-13 10:52:13 --> Router Class Initialized
INFO - 2020-02-13 10:52:13 --> URI Class Initialized
INFO - 2020-02-13 10:52:13 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:52:13 --> Router Class Initialized
INFO - 2020-02-13 10:52:13 --> Output Class Initialized
INFO - 2020-02-13 10:52:13 --> Router Class Initialized
INFO - 2020-02-13 10:52:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:52:13 --> Security Class Initialized
INFO - 2020-02-13 10:52:13 --> Router Class Initialized
INFO - 2020-02-13 10:52:13 --> Output Class Initialized
INFO - 2020-02-13 10:52:13 --> Output Class Initialized
DEBUG - 2020-02-13 10:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:13 --> Security Class Initialized
INFO - 2020-02-13 10:52:13 --> Output Class Initialized
INFO - 2020-02-13 10:52:13 --> Security Class Initialized
INFO - 2020-02-13 10:52:13 --> Model "M_pesan" initialized
INFO - 2020-02-13 10:52:13 --> Input Class Initialized
INFO - 2020-02-13 10:52:13 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 10:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:13 --> Helper loaded: form_helper
INFO - 2020-02-13 10:52:13 --> Input Class Initialized
INFO - 2020-02-13 10:52:13 --> Input Class Initialized
INFO - 2020-02-13 10:52:13 --> Form Validation Class Initialized
INFO - 2020-02-13 10:52:13 --> Language Class Initialized
DEBUG - 2020-02-13 10:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:13 --> Language Class Initialized
INFO - 2020-02-13 10:52:13 --> Input Class Initialized
ERROR - 2020-02-13 10:52:13 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 10:52:13 --> Language Class Initialized
ERROR - 2020-02-13 10:52:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 10:52:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 10:52:13 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 10:52:13 --> Language Class Initialized
ERROR - 2020-02-13 10:52:13 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 10:52:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 10:52:13 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 10:52:13 --> Final output sent to browser
INFO - 2020-02-13 10:52:13 --> Config Class Initialized
INFO - 2020-02-13 10:52:13 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:13 --> Total execution time: 0.8398
DEBUG - 2020-02-13 10:52:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:13 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:13 --> URI Class Initialized
INFO - 2020-02-13 10:52:13 --> Router Class Initialized
INFO - 2020-02-13 10:52:13 --> Output Class Initialized
INFO - 2020-02-13 10:52:13 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:13 --> Input Class Initialized
INFO - 2020-02-13 10:52:13 --> Language Class Initialized
ERROR - 2020-02-13 10:52:13 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 10:52:13 --> Config Class Initialized
INFO - 2020-02-13 10:52:13 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:13 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:13 --> URI Class Initialized
INFO - 2020-02-13 10:52:13 --> Router Class Initialized
INFO - 2020-02-13 10:52:13 --> Output Class Initialized
INFO - 2020-02-13 10:52:13 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:13 --> Input Class Initialized
INFO - 2020-02-13 10:52:13 --> Language Class Initialized
ERROR - 2020-02-13 10:52:13 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 10:52:13 --> Config Class Initialized
INFO - 2020-02-13 10:52:13 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:14 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:14 --> URI Class Initialized
INFO - 2020-02-13 10:52:14 --> Router Class Initialized
INFO - 2020-02-13 10:52:14 --> Output Class Initialized
INFO - 2020-02-13 10:52:14 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:14 --> Input Class Initialized
INFO - 2020-02-13 10:52:14 --> Language Class Initialized
ERROR - 2020-02-13 10:52:14 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 10:52:14 --> Config Class Initialized
INFO - 2020-02-13 10:52:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:14 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:14 --> URI Class Initialized
INFO - 2020-02-13 10:52:14 --> Router Class Initialized
INFO - 2020-02-13 10:52:14 --> Output Class Initialized
INFO - 2020-02-13 10:52:14 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:14 --> Input Class Initialized
INFO - 2020-02-13 10:52:14 --> Language Class Initialized
ERROR - 2020-02-13 10:52:14 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 10:52:14 --> Config Class Initialized
INFO - 2020-02-13 10:52:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:14 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:14 --> URI Class Initialized
INFO - 2020-02-13 10:52:14 --> Router Class Initialized
INFO - 2020-02-13 10:52:14 --> Output Class Initialized
INFO - 2020-02-13 10:52:14 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:14 --> Input Class Initialized
INFO - 2020-02-13 10:52:14 --> Language Class Initialized
ERROR - 2020-02-13 10:52:14 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 10:52:14 --> Config Class Initialized
INFO - 2020-02-13 10:52:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:14 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:14 --> URI Class Initialized
INFO - 2020-02-13 10:52:14 --> Router Class Initialized
INFO - 2020-02-13 10:52:14 --> Output Class Initialized
INFO - 2020-02-13 10:52:14 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:14 --> Input Class Initialized
INFO - 2020-02-13 10:52:14 --> Language Class Initialized
ERROR - 2020-02-13 10:52:14 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 10:52:14 --> Config Class Initialized
INFO - 2020-02-13 10:52:15 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:15 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:15 --> URI Class Initialized
INFO - 2020-02-13 10:52:15 --> Router Class Initialized
INFO - 2020-02-13 10:52:15 --> Output Class Initialized
INFO - 2020-02-13 10:52:15 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:15 --> Input Class Initialized
INFO - 2020-02-13 10:52:15 --> Language Class Initialized
ERROR - 2020-02-13 10:52:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 10:52:15 --> Config Class Initialized
INFO - 2020-02-13 10:52:15 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:15 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:15 --> URI Class Initialized
INFO - 2020-02-13 10:52:15 --> Router Class Initialized
INFO - 2020-02-13 10:52:15 --> Output Class Initialized
INFO - 2020-02-13 10:52:15 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:15 --> Input Class Initialized
INFO - 2020-02-13 10:52:15 --> Language Class Initialized
ERROR - 2020-02-13 10:52:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 10:52:15 --> Config Class Initialized
INFO - 2020-02-13 10:52:15 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:15 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:15 --> URI Class Initialized
INFO - 2020-02-13 10:52:15 --> Router Class Initialized
INFO - 2020-02-13 10:52:15 --> Output Class Initialized
INFO - 2020-02-13 10:52:15 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:15 --> Input Class Initialized
INFO - 2020-02-13 10:52:15 --> Language Class Initialized
ERROR - 2020-02-13 10:52:15 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 10:52:26 --> Config Class Initialized
INFO - 2020-02-13 10:52:26 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:26 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:26 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:26 --> URI Class Initialized
INFO - 2020-02-13 10:52:26 --> Router Class Initialized
INFO - 2020-02-13 10:52:26 --> Output Class Initialized
INFO - 2020-02-13 10:52:26 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:26 --> Input Class Initialized
INFO - 2020-02-13 10:52:26 --> Language Class Initialized
INFO - 2020-02-13 10:52:26 --> Loader Class Initialized
INFO - 2020-02-13 10:52:26 --> Helper loaded: url_helper
INFO - 2020-02-13 10:52:26 --> Helper loaded: string_helper
INFO - 2020-02-13 10:52:26 --> Database Driver Class Initialized
DEBUG - 2020-02-13 10:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:52:26 --> Controller Class Initialized
INFO - 2020-02-13 10:52:26 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:52:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:52:26 --> Model "M_pesan" initialized
INFO - 2020-02-13 10:52:26 --> Helper loaded: form_helper
INFO - 2020-02-13 10:52:26 --> Form Validation Class Initialized
INFO - 2020-02-13 10:52:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 10:52:26 --> Final output sent to browser
INFO - 2020-02-13 10:52:26 --> Config Class Initialized
INFO - 2020-02-13 10:52:26 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:26 --> Total execution time: 0.5027
INFO - 2020-02-13 10:52:26 --> Config Class Initialized
INFO - 2020-02-13 10:52:26 --> Config Class Initialized
INFO - 2020-02-13 10:52:26 --> Config Class Initialized
INFO - 2020-02-13 10:52:26 --> Config Class Initialized
INFO - 2020-02-13 10:52:26 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:26 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:26 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:26 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:26 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:26 --> Config Class Initialized
INFO - 2020-02-13 10:52:26 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:26 --> Utf8 Class Initialized
DEBUG - 2020-02-13 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:26 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
DEBUG - 2020-02-13 10:52:27 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
INFO - 2020-02-13 10:52:27 --> Loader Class Initialized
INFO - 2020-02-13 10:52:27 --> Helper loaded: url_helper
ERROR - 2020-02-13 10:52:27 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 10:52:27 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 10:52:27 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
INFO - 2020-02-13 10:52:27 --> Loader Class Initialized
INFO - 2020-02-13 10:52:27 --> Helper loaded: string_helper
INFO - 2020-02-13 10:52:27 --> Helper loaded: url_helper
ERROR - 2020-02-13 10:52:27 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 10:52:27 --> Config Class Initialized
INFO - 2020-02-13 10:52:27 --> Config Class Initialized
INFO - 2020-02-13 10:52:27 --> Config Class Initialized
INFO - 2020-02-13 10:52:27 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:27 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:27 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:27 --> Helper loaded: string_helper
INFO - 2020-02-13 10:52:27 --> Database Driver Class Initialized
INFO - 2020-02-13 10:52:27 --> Config Class Initialized
INFO - 2020-02-13 10:52:27 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:52:27 --> Database Driver Class Initialized
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
DEBUG - 2020-02-13 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:27 --> Controller Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Model "M_pesan" initialized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:27 --> Helper loaded: form_helper
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
INFO - 2020-02-13 10:52:27 --> Form Validation Class Initialized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
ERROR - 2020-02-13 10:52:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
ERROR - 2020-02-13 10:52:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 10:52:27 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 10:52:27 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 10:52:27 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 10:52:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 10:52:27 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 10:52:27 --> Config Class Initialized
INFO - 2020-02-13 10:52:27 --> Config Class Initialized
INFO - 2020-02-13 10:52:27 --> Config Class Initialized
INFO - 2020-02-13 10:52:27 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:27 --> Final output sent to browser
INFO - 2020-02-13 10:52:27 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:27 --> Hooks Class Initialized
INFO - 2020-02-13 10:52:27 --> Config Class Initialized
INFO - 2020-02-13 10:52:27 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:27 --> Total execution time: 0.6023
DEBUG - 2020-02-13 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 10:52:27 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 10:52:27 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:27 --> Controller Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Model "M_pesan" initialized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:27 --> Helper loaded: form_helper
INFO - 2020-02-13 10:52:27 --> Form Validation Class Initialized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
ERROR - 2020-02-13 10:52:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
ERROR - 2020-02-13 10:52:27 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 10:52:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 10:52:27 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 10:52:27 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 10:52:27 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 10:52:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 10:52:27 --> Final output sent to browser
INFO - 2020-02-13 10:52:27 --> Config Class Initialized
INFO - 2020-02-13 10:52:27 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:27 --> Total execution time: 0.8445
DEBUG - 2020-02-13 10:52:27 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:27 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:27 --> URI Class Initialized
INFO - 2020-02-13 10:52:27 --> Router Class Initialized
INFO - 2020-02-13 10:52:27 --> Output Class Initialized
INFO - 2020-02-13 10:52:27 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:27 --> Input Class Initialized
INFO - 2020-02-13 10:52:27 --> Language Class Initialized
ERROR - 2020-02-13 10:52:27 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 10:52:28 --> Config Class Initialized
INFO - 2020-02-13 10:52:28 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:28 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:28 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:28 --> URI Class Initialized
INFO - 2020-02-13 10:52:28 --> Router Class Initialized
INFO - 2020-02-13 10:52:28 --> Output Class Initialized
INFO - 2020-02-13 10:52:28 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:28 --> Input Class Initialized
INFO - 2020-02-13 10:52:28 --> Language Class Initialized
ERROR - 2020-02-13 10:52:28 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 10:52:28 --> Config Class Initialized
INFO - 2020-02-13 10:52:28 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:28 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:28 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:28 --> URI Class Initialized
INFO - 2020-02-13 10:52:28 --> Router Class Initialized
INFO - 2020-02-13 10:52:28 --> Output Class Initialized
INFO - 2020-02-13 10:52:28 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:28 --> Input Class Initialized
INFO - 2020-02-13 10:52:28 --> Language Class Initialized
ERROR - 2020-02-13 10:52:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 10:52:28 --> Config Class Initialized
INFO - 2020-02-13 10:52:28 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:28 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:28 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:28 --> URI Class Initialized
INFO - 2020-02-13 10:52:28 --> Router Class Initialized
INFO - 2020-02-13 10:52:28 --> Output Class Initialized
INFO - 2020-02-13 10:52:28 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:28 --> Input Class Initialized
INFO - 2020-02-13 10:52:28 --> Language Class Initialized
ERROR - 2020-02-13 10:52:28 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 10:52:28 --> Config Class Initialized
INFO - 2020-02-13 10:52:28 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:28 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:28 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:28 --> URI Class Initialized
INFO - 2020-02-13 10:52:28 --> Router Class Initialized
INFO - 2020-02-13 10:52:28 --> Output Class Initialized
INFO - 2020-02-13 10:52:28 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:28 --> Input Class Initialized
INFO - 2020-02-13 10:52:28 --> Language Class Initialized
ERROR - 2020-02-13 10:52:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 10:52:29 --> Config Class Initialized
INFO - 2020-02-13 10:52:29 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:29 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:29 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:29 --> URI Class Initialized
INFO - 2020-02-13 10:52:29 --> Router Class Initialized
INFO - 2020-02-13 10:52:29 --> Output Class Initialized
INFO - 2020-02-13 10:52:29 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:29 --> Input Class Initialized
INFO - 2020-02-13 10:52:29 --> Language Class Initialized
ERROR - 2020-02-13 10:52:29 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 10:52:29 --> Config Class Initialized
INFO - 2020-02-13 10:52:29 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:29 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:29 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:29 --> URI Class Initialized
INFO - 2020-02-13 10:52:29 --> Router Class Initialized
INFO - 2020-02-13 10:52:29 --> Output Class Initialized
INFO - 2020-02-13 10:52:29 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:29 --> Input Class Initialized
INFO - 2020-02-13 10:52:29 --> Language Class Initialized
ERROR - 2020-02-13 10:52:29 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 10:52:29 --> Config Class Initialized
INFO - 2020-02-13 10:52:29 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:29 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:29 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:29 --> URI Class Initialized
INFO - 2020-02-13 10:52:29 --> Router Class Initialized
INFO - 2020-02-13 10:52:29 --> Output Class Initialized
INFO - 2020-02-13 10:52:29 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:29 --> Input Class Initialized
INFO - 2020-02-13 10:52:29 --> Language Class Initialized
ERROR - 2020-02-13 10:52:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 10:52:29 --> Config Class Initialized
INFO - 2020-02-13 10:52:29 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:52:29 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:52:29 --> Utf8 Class Initialized
INFO - 2020-02-13 10:52:29 --> URI Class Initialized
INFO - 2020-02-13 10:52:29 --> Router Class Initialized
INFO - 2020-02-13 10:52:29 --> Output Class Initialized
INFO - 2020-02-13 10:52:29 --> Security Class Initialized
DEBUG - 2020-02-13 10:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:52:29 --> Input Class Initialized
INFO - 2020-02-13 10:52:29 --> Language Class Initialized
ERROR - 2020-02-13 10:52:29 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 10:53:46 --> Config Class Initialized
INFO - 2020-02-13 10:53:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 10:53:47 --> UTF-8 Support Enabled
INFO - 2020-02-13 10:53:47 --> Utf8 Class Initialized
INFO - 2020-02-13 10:53:47 --> URI Class Initialized
INFO - 2020-02-13 10:53:47 --> Router Class Initialized
INFO - 2020-02-13 10:53:47 --> Output Class Initialized
INFO - 2020-02-13 10:53:47 --> Security Class Initialized
DEBUG - 2020-02-13 10:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 10:53:47 --> Input Class Initialized
INFO - 2020-02-13 10:53:47 --> Language Class Initialized
INFO - 2020-02-13 10:53:47 --> Loader Class Initialized
INFO - 2020-02-13 10:53:47 --> Helper loaded: url_helper
INFO - 2020-02-13 10:53:47 --> Helper loaded: string_helper
INFO - 2020-02-13 10:53:47 --> Database Driver Class Initialized
DEBUG - 2020-02-13 10:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 10:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 10:53:47 --> Controller Class Initialized
INFO - 2020-02-13 10:53:47 --> Model "M_tiket" initialized
INFO - 2020-02-13 10:53:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 10:53:47 --> Model "M_pesan" initialized
INFO - 2020-02-13 10:53:47 --> Helper loaded: form_helper
INFO - 2020-02-13 10:53:47 --> Form Validation Class Initialized
INFO - 2020-02-13 10:53:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 10:53:47 --> Final output sent to browser
DEBUG - 2020-02-13 10:53:47 --> Total execution time: 1.0455
INFO - 2020-02-13 11:08:03 --> Config Class Initialized
INFO - 2020-02-13 11:08:03 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:08:03 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:08:03 --> Utf8 Class Initialized
INFO - 2020-02-13 11:08:03 --> URI Class Initialized
INFO - 2020-02-13 11:08:03 --> Router Class Initialized
INFO - 2020-02-13 11:08:03 --> Output Class Initialized
INFO - 2020-02-13 11:08:03 --> Security Class Initialized
DEBUG - 2020-02-13 11:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:08:03 --> Input Class Initialized
INFO - 2020-02-13 11:08:03 --> Language Class Initialized
INFO - 2020-02-13 11:08:03 --> Loader Class Initialized
INFO - 2020-02-13 11:08:03 --> Helper loaded: url_helper
INFO - 2020-02-13 11:08:03 --> Helper loaded: string_helper
INFO - 2020-02-13 11:08:03 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:08:03 --> Controller Class Initialized
INFO - 2020-02-13 11:08:03 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:08:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:08:03 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:08:03 --> Helper loaded: form_helper
INFO - 2020-02-13 11:08:03 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:08:03 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 54
ERROR - 2020-02-13 11:08:03 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 55
ERROR - 2020-02-13 11:08:03 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 56
ERROR - 2020-02-13 11:08:03 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 57
ERROR - 2020-02-13 11:08:03 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 81
ERROR - 2020-02-13 11:08:03 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 82
ERROR - 2020-02-13 11:08:03 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 83
ERROR - 2020-02-13 11:08:03 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 84
ERROR - 2020-02-13 11:08:03 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pengunjung` (`nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2020-02-13 11:08:03 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-13 11:08:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow\system\core\Common.php 570
INFO - 2020-02-13 11:08:22 --> Config Class Initialized
INFO - 2020-02-13 11:08:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:08:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:08:22 --> Utf8 Class Initialized
INFO - 2020-02-13 11:08:22 --> URI Class Initialized
INFO - 2020-02-13 11:08:22 --> Router Class Initialized
INFO - 2020-02-13 11:08:22 --> Output Class Initialized
INFO - 2020-02-13 11:08:22 --> Security Class Initialized
DEBUG - 2020-02-13 11:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:08:22 --> Input Class Initialized
INFO - 2020-02-13 11:08:22 --> Language Class Initialized
INFO - 2020-02-13 11:08:22 --> Loader Class Initialized
INFO - 2020-02-13 11:08:23 --> Helper loaded: url_helper
INFO - 2020-02-13 11:08:23 --> Helper loaded: string_helper
INFO - 2020-02-13 11:08:23 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:08:23 --> Controller Class Initialized
INFO - 2020-02-13 11:08:23 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:08:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:08:23 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:08:23 --> Helper loaded: form_helper
INFO - 2020-02-13 11:08:23 --> Form Validation Class Initialized
INFO - 2020-02-13 11:08:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:08:23 --> Final output sent to browser
DEBUG - 2020-02-13 11:08:23 --> Total execution time: 0.5067
INFO - 2020-02-13 11:08:23 --> Config Class Initialized
INFO - 2020-02-13 11:08:23 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:08:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:08:23 --> Utf8 Class Initialized
INFO - 2020-02-13 11:08:23 --> URI Class Initialized
INFO - 2020-02-13 11:08:23 --> Router Class Initialized
INFO - 2020-02-13 11:08:23 --> Output Class Initialized
INFO - 2020-02-13 11:08:23 --> Security Class Initialized
DEBUG - 2020-02-13 11:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:08:23 --> Input Class Initialized
INFO - 2020-02-13 11:08:23 --> Language Class Initialized
ERROR - 2020-02-13 11:08:23 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 11:08:26 --> Config Class Initialized
INFO - 2020-02-13 11:08:26 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:08:26 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:08:26 --> Utf8 Class Initialized
INFO - 2020-02-13 11:08:26 --> URI Class Initialized
INFO - 2020-02-13 11:08:26 --> Router Class Initialized
INFO - 2020-02-13 11:08:26 --> Output Class Initialized
INFO - 2020-02-13 11:08:26 --> Security Class Initialized
DEBUG - 2020-02-13 11:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:08:26 --> Input Class Initialized
INFO - 2020-02-13 11:08:26 --> Language Class Initialized
INFO - 2020-02-13 11:08:26 --> Loader Class Initialized
INFO - 2020-02-13 11:08:26 --> Helper loaded: url_helper
INFO - 2020-02-13 11:08:26 --> Helper loaded: string_helper
INFO - 2020-02-13 11:08:26 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:08:26 --> Controller Class Initialized
INFO - 2020-02-13 11:08:26 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:08:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:08:26 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:08:26 --> Helper loaded: form_helper
INFO - 2020-02-13 11:08:26 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:08:27 --> Query error: Unknown column 'total_bayar' in 'where clause' - Invalid query: SELECT *
FROM `pemesanan`
WHERE `total_bayar` = '200000'
INFO - 2020-02-13 11:08:27 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 11:22:15 --> Config Class Initialized
INFO - 2020-02-13 11:22:15 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:22:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:15 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:15 --> URI Class Initialized
DEBUG - 2020-02-13 11:22:15 --> No URI present. Default controller set.
INFO - 2020-02-13 11:22:16 --> Router Class Initialized
INFO - 2020-02-13 11:22:16 --> Output Class Initialized
INFO - 2020-02-13 11:22:16 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:16 --> Input Class Initialized
INFO - 2020-02-13 11:22:16 --> Language Class Initialized
INFO - 2020-02-13 11:22:16 --> Loader Class Initialized
INFO - 2020-02-13 11:22:16 --> Helper loaded: url_helper
INFO - 2020-02-13 11:22:16 --> Helper loaded: string_helper
INFO - 2020-02-13 11:22:16 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:22:16 --> Controller Class Initialized
INFO - 2020-02-13 11:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 11:22:16 --> Pagination Class Initialized
INFO - 2020-02-13 11:22:16 --> Model "M_show" initialized
INFO - 2020-02-13 11:22:16 --> Helper loaded: form_helper
INFO - 2020-02-13 11:22:16 --> Form Validation Class Initialized
INFO - 2020-02-13 11:22:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 11:22:16 --> Final output sent to browser
DEBUG - 2020-02-13 11:22:16 --> Total execution time: 0.9475
INFO - 2020-02-13 11:22:19 --> Config Class Initialized
INFO - 2020-02-13 11:22:19 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:22:19 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:19 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:19 --> URI Class Initialized
INFO - 2020-02-13 11:22:19 --> Router Class Initialized
INFO - 2020-02-13 11:22:19 --> Output Class Initialized
INFO - 2020-02-13 11:22:19 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:19 --> Input Class Initialized
INFO - 2020-02-13 11:22:19 --> Language Class Initialized
INFO - 2020-02-13 11:22:19 --> Loader Class Initialized
INFO - 2020-02-13 11:22:19 --> Helper loaded: url_helper
INFO - 2020-02-13 11:22:19 --> Helper loaded: string_helper
INFO - 2020-02-13 11:22:19 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:22:19 --> Controller Class Initialized
INFO - 2020-02-13 11:22:19 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:22:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:22:19 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:22:19 --> Helper loaded: form_helper
INFO - 2020-02-13 11:22:19 --> Form Validation Class Initialized
INFO - 2020-02-13 11:22:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:22:20 --> Final output sent to browser
DEBUG - 2020-02-13 11:22:20 --> Total execution time: 0.5488
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
ERROR - 2020-02-13 11:22:20 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-13 11:22:20 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 11:22:20 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 11:22:20 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 11:22:20 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 11:22:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
ERROR - 2020-02-13 11:22:20 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 11:22:20 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 11:22:20 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 11:22:20 --> Loader Class Initialized
INFO - 2020-02-13 11:22:20 --> Loader Class Initialized
INFO - 2020-02-13 11:22:20 --> Helper loaded: url_helper
ERROR - 2020-02-13 11:22:20 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 11:22:20 --> Helper loaded: url_helper
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:20 --> Helper loaded: string_helper
INFO - 2020-02-13 11:22:20 --> Helper loaded: string_helper
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:22:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:20 --> Database Driver Class Initialized
INFO - 2020-02-13 11:22:20 --> Database Driver Class Initialized
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:20 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 11:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> URI Class Initialized
INFO - 2020-02-13 11:22:20 --> Controller Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Router Class Initialized
INFO - 2020-02-13 11:22:20 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Output Class Initialized
INFO - 2020-02-13 11:22:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
INFO - 2020-02-13 11:22:20 --> Security Class Initialized
INFO - 2020-02-13 11:22:20 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
INFO - 2020-02-13 11:22:20 --> Input Class Initialized
INFO - 2020-02-13 11:22:20 --> Helper loaded: form_helper
INFO - 2020-02-13 11:22:20 --> Form Validation Class Initialized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
INFO - 2020-02-13 11:22:20 --> Language Class Initialized
ERROR - 2020-02-13 11:22:20 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 11:22:20 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 11:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 11:22:20 --> Config Class Initialized
INFO - 2020-02-13 11:22:20 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:22:21 --> Final output sent to browser
DEBUG - 2020-02-13 11:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:22:21 --> Total execution time: 0.5977
INFO - 2020-02-13 11:22:21 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:22:21 --> URI Class Initialized
INFO - 2020-02-13 11:22:21 --> Controller Class Initialized
INFO - 2020-02-13 11:22:21 --> Router Class Initialized
INFO - 2020-02-13 11:22:21 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:22:21 --> Output Class Initialized
INFO - 2020-02-13 11:22:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:22:21 --> Security Class Initialized
INFO - 2020-02-13 11:22:21 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 11:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:21 --> Input Class Initialized
INFO - 2020-02-13 11:22:21 --> Helper loaded: form_helper
INFO - 2020-02-13 11:22:21 --> Form Validation Class Initialized
INFO - 2020-02-13 11:22:21 --> Language Class Initialized
ERROR - 2020-02-13 11:22:21 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 11:22:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:22:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 11:22:21 --> Config Class Initialized
INFO - 2020-02-13 11:22:21 --> Hooks Class Initialized
INFO - 2020-02-13 11:22:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:22:21 --> Final output sent to browser
DEBUG - 2020-02-13 11:22:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:21 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:22:21 --> Total execution time: 0.8557
INFO - 2020-02-13 11:22:21 --> URI Class Initialized
INFO - 2020-02-13 11:22:21 --> Router Class Initialized
INFO - 2020-02-13 11:22:21 --> Output Class Initialized
INFO - 2020-02-13 11:22:21 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:21 --> Input Class Initialized
INFO - 2020-02-13 11:22:21 --> Language Class Initialized
ERROR - 2020-02-13 11:22:21 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 11:22:21 --> Config Class Initialized
INFO - 2020-02-13 11:22:21 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:22:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:21 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:21 --> URI Class Initialized
INFO - 2020-02-13 11:22:21 --> Router Class Initialized
INFO - 2020-02-13 11:22:21 --> Output Class Initialized
INFO - 2020-02-13 11:22:21 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:21 --> Input Class Initialized
INFO - 2020-02-13 11:22:21 --> Language Class Initialized
ERROR - 2020-02-13 11:22:21 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 11:22:21 --> Config Class Initialized
INFO - 2020-02-13 11:22:21 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:22:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:21 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:21 --> URI Class Initialized
INFO - 2020-02-13 11:22:21 --> Router Class Initialized
INFO - 2020-02-13 11:22:21 --> Output Class Initialized
INFO - 2020-02-13 11:22:21 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:22 --> Input Class Initialized
INFO - 2020-02-13 11:22:22 --> Language Class Initialized
ERROR - 2020-02-13 11:22:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 11:22:22 --> Config Class Initialized
INFO - 2020-02-13 11:22:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:22:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:22 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:22 --> URI Class Initialized
INFO - 2020-02-13 11:22:22 --> Router Class Initialized
INFO - 2020-02-13 11:22:22 --> Output Class Initialized
INFO - 2020-02-13 11:22:22 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:22 --> Input Class Initialized
INFO - 2020-02-13 11:22:22 --> Language Class Initialized
ERROR - 2020-02-13 11:22:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 11:22:22 --> Config Class Initialized
INFO - 2020-02-13 11:22:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:22:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:22 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:22 --> URI Class Initialized
INFO - 2020-02-13 11:22:22 --> Router Class Initialized
INFO - 2020-02-13 11:22:22 --> Output Class Initialized
INFO - 2020-02-13 11:22:22 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:22 --> Input Class Initialized
INFO - 2020-02-13 11:22:22 --> Language Class Initialized
ERROR - 2020-02-13 11:22:22 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 11:22:22 --> Config Class Initialized
INFO - 2020-02-13 11:22:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:22:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:22 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:22 --> URI Class Initialized
INFO - 2020-02-13 11:22:22 --> Router Class Initialized
INFO - 2020-02-13 11:22:22 --> Output Class Initialized
INFO - 2020-02-13 11:22:22 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:22 --> Input Class Initialized
INFO - 2020-02-13 11:22:22 --> Language Class Initialized
ERROR - 2020-02-13 11:22:22 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 11:22:22 --> Config Class Initialized
INFO - 2020-02-13 11:22:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:22:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:23 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:23 --> URI Class Initialized
INFO - 2020-02-13 11:22:23 --> Router Class Initialized
INFO - 2020-02-13 11:22:23 --> Output Class Initialized
INFO - 2020-02-13 11:22:23 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:23 --> Input Class Initialized
INFO - 2020-02-13 11:22:23 --> Language Class Initialized
ERROR - 2020-02-13 11:22:23 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 11:22:23 --> Config Class Initialized
INFO - 2020-02-13 11:22:23 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:22:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:23 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:23 --> URI Class Initialized
INFO - 2020-02-13 11:22:23 --> Router Class Initialized
INFO - 2020-02-13 11:22:23 --> Output Class Initialized
INFO - 2020-02-13 11:22:23 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:23 --> Input Class Initialized
INFO - 2020-02-13 11:22:23 --> Language Class Initialized
ERROR - 2020-02-13 11:22:23 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 11:22:43 --> Config Class Initialized
INFO - 2020-02-13 11:22:43 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:22:43 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:43 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:43 --> URI Class Initialized
INFO - 2020-02-13 11:22:43 --> Router Class Initialized
INFO - 2020-02-13 11:22:43 --> Output Class Initialized
INFO - 2020-02-13 11:22:43 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:43 --> Input Class Initialized
INFO - 2020-02-13 11:22:43 --> Language Class Initialized
INFO - 2020-02-13 11:22:43 --> Loader Class Initialized
INFO - 2020-02-13 11:22:43 --> Helper loaded: url_helper
INFO - 2020-02-13 11:22:43 --> Helper loaded: string_helper
INFO - 2020-02-13 11:22:43 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:22:43 --> Controller Class Initialized
INFO - 2020-02-13 11:22:43 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:22:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:22:43 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:22:43 --> Helper loaded: form_helper
INFO - 2020-02-13 11:22:43 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:22:43 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
INFO - 2020-02-13 11:22:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 11:22:44 --> Final output sent to browser
DEBUG - 2020-02-13 11:22:44 --> Total execution time: 0.7276
INFO - 2020-02-13 11:22:56 --> Config Class Initialized
INFO - 2020-02-13 11:22:56 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:22:56 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:22:56 --> Utf8 Class Initialized
INFO - 2020-02-13 11:22:56 --> URI Class Initialized
INFO - 2020-02-13 11:22:56 --> Router Class Initialized
INFO - 2020-02-13 11:22:56 --> Output Class Initialized
INFO - 2020-02-13 11:22:57 --> Security Class Initialized
DEBUG - 2020-02-13 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:22:57 --> Input Class Initialized
INFO - 2020-02-13 11:22:57 --> Language Class Initialized
INFO - 2020-02-13 11:22:57 --> Loader Class Initialized
INFO - 2020-02-13 11:22:57 --> Helper loaded: url_helper
INFO - 2020-02-13 11:22:57 --> Helper loaded: string_helper
INFO - 2020-02-13 11:22:57 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:22:57 --> Controller Class Initialized
INFO - 2020-02-13 11:22:57 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:22:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:22:57 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:22:57 --> Helper loaded: form_helper
INFO - 2020-02-13 11:22:57 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:22:57 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
INFO - 2020-02-13 11:22:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 11:22:57 --> Final output sent to browser
DEBUG - 2020-02-13 11:22:57 --> Total execution time: 0.8442
INFO - 2020-02-13 11:24:19 --> Config Class Initialized
INFO - 2020-02-13 11:24:19 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:24:19 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:24:19 --> Utf8 Class Initialized
INFO - 2020-02-13 11:24:19 --> URI Class Initialized
INFO - 2020-02-13 11:24:19 --> Router Class Initialized
INFO - 2020-02-13 11:24:19 --> Output Class Initialized
INFO - 2020-02-13 11:24:19 --> Security Class Initialized
DEBUG - 2020-02-13 11:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:24:19 --> Input Class Initialized
INFO - 2020-02-13 11:24:19 --> Language Class Initialized
INFO - 2020-02-13 11:24:19 --> Loader Class Initialized
INFO - 2020-02-13 11:24:19 --> Helper loaded: url_helper
INFO - 2020-02-13 11:24:19 --> Helper loaded: string_helper
INFO - 2020-02-13 11:24:19 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:24:19 --> Controller Class Initialized
INFO - 2020-02-13 11:24:19 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:24:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:24:19 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:24:19 --> Helper loaded: form_helper
INFO - 2020-02-13 11:24:19 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:24:20 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
ERROR - 2020-02-13 11:24:20 --> Severity: Notice --> Undefined property: stdClass::$id_pemesanan C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 5
INFO - 2020-02-13 11:24:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 11:24:20 --> Final output sent to browser
DEBUG - 2020-02-13 11:24:20 --> Total execution time: 0.7571
INFO - 2020-02-13 11:24:25 --> Config Class Initialized
INFO - 2020-02-13 11:24:25 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:24:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:24:25 --> Utf8 Class Initialized
INFO - 2020-02-13 11:24:25 --> URI Class Initialized
INFO - 2020-02-13 11:24:25 --> Router Class Initialized
INFO - 2020-02-13 11:24:25 --> Output Class Initialized
INFO - 2020-02-13 11:24:25 --> Security Class Initialized
DEBUG - 2020-02-13 11:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:24:25 --> Input Class Initialized
INFO - 2020-02-13 11:24:25 --> Language Class Initialized
INFO - 2020-02-13 11:24:25 --> Loader Class Initialized
INFO - 2020-02-13 11:24:26 --> Helper loaded: url_helper
INFO - 2020-02-13 11:24:26 --> Helper loaded: string_helper
INFO - 2020-02-13 11:24:26 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:24:26 --> Controller Class Initialized
INFO - 2020-02-13 11:24:26 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:24:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:24:26 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:24:26 --> Helper loaded: form_helper
INFO - 2020-02-13 11:24:26 --> Form Validation Class Initialized
INFO - 2020-02-13 11:24:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:24:26 --> Final output sent to browser
DEBUG - 2020-02-13 11:24:26 --> Total execution time: 0.5403
INFO - 2020-02-13 11:24:31 --> Config Class Initialized
INFO - 2020-02-13 11:24:31 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:24:31 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:24:31 --> Utf8 Class Initialized
INFO - 2020-02-13 11:24:31 --> URI Class Initialized
INFO - 2020-02-13 11:24:31 --> Router Class Initialized
INFO - 2020-02-13 11:24:31 --> Output Class Initialized
INFO - 2020-02-13 11:24:31 --> Security Class Initialized
DEBUG - 2020-02-13 11:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:24:31 --> Input Class Initialized
INFO - 2020-02-13 11:24:31 --> Language Class Initialized
INFO - 2020-02-13 11:24:31 --> Loader Class Initialized
INFO - 2020-02-13 11:24:31 --> Helper loaded: url_helper
INFO - 2020-02-13 11:24:31 --> Helper loaded: string_helper
INFO - 2020-02-13 11:24:31 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:24:31 --> Controller Class Initialized
INFO - 2020-02-13 11:24:31 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:24:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:24:31 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:24:31 --> Helper loaded: form_helper
INFO - 2020-02-13 11:24:31 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:24:31 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
ERROR - 2020-02-13 11:24:31 --> Severity: Notice --> Undefined property: stdClass::$id_pemesanan C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 5
INFO - 2020-02-13 11:24:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 11:24:31 --> Final output sent to browser
DEBUG - 2020-02-13 11:24:31 --> Total execution time: 0.6934
INFO - 2020-02-13 11:25:57 --> Config Class Initialized
INFO - 2020-02-13 11:25:57 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:25:57 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:25:57 --> Utf8 Class Initialized
INFO - 2020-02-13 11:25:57 --> URI Class Initialized
INFO - 2020-02-13 11:25:57 --> Router Class Initialized
INFO - 2020-02-13 11:25:57 --> Output Class Initialized
INFO - 2020-02-13 11:25:57 --> Security Class Initialized
DEBUG - 2020-02-13 11:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:25:57 --> Input Class Initialized
INFO - 2020-02-13 11:25:57 --> Language Class Initialized
INFO - 2020-02-13 11:25:57 --> Loader Class Initialized
INFO - 2020-02-13 11:25:57 --> Helper loaded: url_helper
INFO - 2020-02-13 11:25:57 --> Helper loaded: string_helper
INFO - 2020-02-13 11:25:58 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:25:58 --> Controller Class Initialized
INFO - 2020-02-13 11:25:58 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:25:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:25:58 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:25:58 --> Helper loaded: form_helper
INFO - 2020-02-13 11:25:58 --> Form Validation Class Initialized
INFO - 2020-02-13 11:25:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 11:25:58 --> Final output sent to browser
DEBUG - 2020-02-13 11:25:58 --> Total execution time: 0.6859
INFO - 2020-02-13 11:35:09 --> Config Class Initialized
INFO - 2020-02-13 11:35:09 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:35:09 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:35:09 --> Utf8 Class Initialized
INFO - 2020-02-13 11:35:10 --> URI Class Initialized
DEBUG - 2020-02-13 11:35:10 --> No URI present. Default controller set.
INFO - 2020-02-13 11:35:10 --> Router Class Initialized
INFO - 2020-02-13 11:35:10 --> Output Class Initialized
INFO - 2020-02-13 11:35:10 --> Security Class Initialized
DEBUG - 2020-02-13 11:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:35:10 --> Input Class Initialized
INFO - 2020-02-13 11:35:10 --> Language Class Initialized
INFO - 2020-02-13 11:35:10 --> Loader Class Initialized
INFO - 2020-02-13 11:35:10 --> Helper loaded: url_helper
INFO - 2020-02-13 11:35:10 --> Helper loaded: string_helper
INFO - 2020-02-13 11:35:10 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:35:10 --> Controller Class Initialized
INFO - 2020-02-13 11:35:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 11:35:10 --> Pagination Class Initialized
INFO - 2020-02-13 11:35:10 --> Model "M_show" initialized
INFO - 2020-02-13 11:35:10 --> Helper loaded: form_helper
INFO - 2020-02-13 11:35:10 --> Form Validation Class Initialized
INFO - 2020-02-13 11:35:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 11:35:10 --> Final output sent to browser
INFO - 2020-02-13 11:35:10 --> Config Class Initialized
INFO - 2020-02-13 11:35:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:35:10 --> Total execution time: 0.8908
DEBUG - 2020-02-13 11:35:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:35:10 --> Utf8 Class Initialized
INFO - 2020-02-13 11:35:10 --> URI Class Initialized
DEBUG - 2020-02-13 11:35:10 --> No URI present. Default controller set.
INFO - 2020-02-13 11:35:10 --> Router Class Initialized
INFO - 2020-02-13 11:35:10 --> Output Class Initialized
INFO - 2020-02-13 11:35:10 --> Security Class Initialized
DEBUG - 2020-02-13 11:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:35:10 --> Input Class Initialized
INFO - 2020-02-13 11:35:10 --> Language Class Initialized
INFO - 2020-02-13 11:35:10 --> Loader Class Initialized
INFO - 2020-02-13 11:35:10 --> Helper loaded: url_helper
INFO - 2020-02-13 11:35:10 --> Helper loaded: string_helper
INFO - 2020-02-13 11:35:10 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:35:10 --> Controller Class Initialized
INFO - 2020-02-13 11:35:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 11:35:10 --> Pagination Class Initialized
INFO - 2020-02-13 11:35:11 --> Model "M_show" initialized
INFO - 2020-02-13 11:35:11 --> Helper loaded: form_helper
INFO - 2020-02-13 11:35:11 --> Form Validation Class Initialized
INFO - 2020-02-13 11:35:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 11:35:11 --> Final output sent to browser
DEBUG - 2020-02-13 11:35:11 --> Total execution time: 0.6414
INFO - 2020-02-13 11:36:12 --> Config Class Initialized
INFO - 2020-02-13 11:36:12 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:36:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:12 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:12 --> URI Class Initialized
INFO - 2020-02-13 11:36:12 --> Router Class Initialized
INFO - 2020-02-13 11:36:12 --> Output Class Initialized
INFO - 2020-02-13 11:36:12 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:12 --> Input Class Initialized
INFO - 2020-02-13 11:36:12 --> Language Class Initialized
INFO - 2020-02-13 11:36:12 --> Loader Class Initialized
INFO - 2020-02-13 11:36:12 --> Helper loaded: url_helper
INFO - 2020-02-13 11:36:12 --> Helper loaded: string_helper
INFO - 2020-02-13 11:36:12 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:36:12 --> Controller Class Initialized
INFO - 2020-02-13 11:36:12 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:36:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:36:12 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:36:12 --> Helper loaded: form_helper
INFO - 2020-02-13 11:36:12 --> Form Validation Class Initialized
INFO - 2020-02-13 11:36:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:36:12 --> Final output sent to browser
DEBUG - 2020-02-13 11:36:12 --> Total execution time: 0.5499
INFO - 2020-02-13 11:36:12 --> Config Class Initialized
INFO - 2020-02-13 11:36:12 --> Config Class Initialized
INFO - 2020-02-13 11:36:12 --> Config Class Initialized
INFO - 2020-02-13 11:36:12 --> Config Class Initialized
INFO - 2020-02-13 11:36:12 --> Config Class Initialized
INFO - 2020-02-13 11:36:12 --> Hooks Class Initialized
INFO - 2020-02-13 11:36:12 --> Hooks Class Initialized
INFO - 2020-02-13 11:36:12 --> Hooks Class Initialized
INFO - 2020-02-13 11:36:12 --> Hooks Class Initialized
INFO - 2020-02-13 11:36:12 --> Hooks Class Initialized
INFO - 2020-02-13 11:36:12 --> Config Class Initialized
INFO - 2020-02-13 11:36:12 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:36:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:12 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:12 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:12 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:12 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:12 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:36:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:12 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
ERROR - 2020-02-13 11:36:13 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 11:36:13 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 11:36:13 --> Loader Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
ERROR - 2020-02-13 11:36:13 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 11:36:13 --> Loader Class Initialized
INFO - 2020-02-13 11:36:13 --> Helper loaded: url_helper
INFO - 2020-02-13 11:36:13 --> Helper loaded: url_helper
ERROR - 2020-02-13 11:36:13 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 11:36:13 --> Config Class Initialized
INFO - 2020-02-13 11:36:13 --> Config Class Initialized
INFO - 2020-02-13 11:36:13 --> Config Class Initialized
INFO - 2020-02-13 11:36:13 --> Hooks Class Initialized
INFO - 2020-02-13 11:36:13 --> Hooks Class Initialized
INFO - 2020-02-13 11:36:13 --> Helper loaded: string_helper
INFO - 2020-02-13 11:36:13 --> Hooks Class Initialized
INFO - 2020-02-13 11:36:13 --> Helper loaded: string_helper
INFO - 2020-02-13 11:36:13 --> Config Class Initialized
INFO - 2020-02-13 11:36:13 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:36:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:13 --> Database Driver Class Initialized
INFO - 2020-02-13 11:36:13 --> Database Driver Class Initialized
INFO - 2020-02-13 11:36:13 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:13 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:13 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 11:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:36:13 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> Controller Class Initialized
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
INFO - 2020-02-13 11:36:13 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:13 --> Helper loaded: form_helper
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
INFO - 2020-02-13 11:36:13 --> Form Validation Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
ERROR - 2020-02-13 11:36:13 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 11:36:13 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 11:36:13 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 11:36:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:36:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 11:36:13 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 11:36:13 --> Config Class Initialized
INFO - 2020-02-13 11:36:13 --> Config Class Initialized
INFO - 2020-02-13 11:36:13 --> Config Class Initialized
INFO - 2020-02-13 11:36:13 --> Hooks Class Initialized
INFO - 2020-02-13 11:36:13 --> Hooks Class Initialized
INFO - 2020-02-13 11:36:13 --> Hooks Class Initialized
INFO - 2020-02-13 11:36:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:36:13 --> Config Class Initialized
INFO - 2020-02-13 11:36:13 --> Hooks Class Initialized
INFO - 2020-02-13 11:36:13 --> Final output sent to browser
DEBUG - 2020-02-13 11:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:36:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:13 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:13 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:13 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:36:13 --> Total execution time: 0.6702
DEBUG - 2020-02-13 11:36:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> Controller Class Initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
INFO - 2020-02-13 11:36:13 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:13 --> Helper loaded: form_helper
INFO - 2020-02-13 11:36:13 --> Form Validation Class Initialized
INFO - 2020-02-13 11:36:13 --> Input Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
INFO - 2020-02-13 11:36:13 --> Language Class Initialized
ERROR - 2020-02-13 11:36:13 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 11:36:13 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 11:36:13 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 11:36:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:36:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 11:36:13 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 11:36:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:36:13 --> Config Class Initialized
INFO - 2020-02-13 11:36:13 --> Hooks Class Initialized
INFO - 2020-02-13 11:36:13 --> Final output sent to browser
DEBUG - 2020-02-13 11:36:13 --> Total execution time: 0.9736
DEBUG - 2020-02-13 11:36:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:13 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:13 --> URI Class Initialized
INFO - 2020-02-13 11:36:13 --> Router Class Initialized
INFO - 2020-02-13 11:36:13 --> Output Class Initialized
INFO - 2020-02-13 11:36:13 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:14 --> Input Class Initialized
INFO - 2020-02-13 11:36:14 --> Language Class Initialized
ERROR - 2020-02-13 11:36:14 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 11:36:14 --> Config Class Initialized
INFO - 2020-02-13 11:36:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:36:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:14 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:14 --> URI Class Initialized
INFO - 2020-02-13 11:36:14 --> Router Class Initialized
INFO - 2020-02-13 11:36:14 --> Output Class Initialized
INFO - 2020-02-13 11:36:14 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:14 --> Input Class Initialized
INFO - 2020-02-13 11:36:14 --> Language Class Initialized
ERROR - 2020-02-13 11:36:14 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 11:36:14 --> Config Class Initialized
INFO - 2020-02-13 11:36:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:36:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:14 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:14 --> URI Class Initialized
INFO - 2020-02-13 11:36:14 --> Router Class Initialized
INFO - 2020-02-13 11:36:14 --> Output Class Initialized
INFO - 2020-02-13 11:36:14 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:14 --> Input Class Initialized
INFO - 2020-02-13 11:36:14 --> Language Class Initialized
ERROR - 2020-02-13 11:36:14 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 11:36:14 --> Config Class Initialized
INFO - 2020-02-13 11:36:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:36:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:14 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:14 --> URI Class Initialized
INFO - 2020-02-13 11:36:14 --> Router Class Initialized
INFO - 2020-02-13 11:36:14 --> Output Class Initialized
INFO - 2020-02-13 11:36:14 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:14 --> Input Class Initialized
INFO - 2020-02-13 11:36:14 --> Language Class Initialized
ERROR - 2020-02-13 11:36:14 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 11:36:14 --> Config Class Initialized
INFO - 2020-02-13 11:36:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:36:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:15 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:15 --> URI Class Initialized
INFO - 2020-02-13 11:36:15 --> Router Class Initialized
INFO - 2020-02-13 11:36:15 --> Output Class Initialized
INFO - 2020-02-13 11:36:15 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:15 --> Input Class Initialized
INFO - 2020-02-13 11:36:15 --> Language Class Initialized
ERROR - 2020-02-13 11:36:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 11:36:15 --> Config Class Initialized
INFO - 2020-02-13 11:36:15 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:36:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:15 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:15 --> URI Class Initialized
INFO - 2020-02-13 11:36:15 --> Router Class Initialized
INFO - 2020-02-13 11:36:15 --> Output Class Initialized
INFO - 2020-02-13 11:36:15 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:15 --> Input Class Initialized
INFO - 2020-02-13 11:36:15 --> Language Class Initialized
ERROR - 2020-02-13 11:36:15 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 11:36:15 --> Config Class Initialized
INFO - 2020-02-13 11:36:15 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:36:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:15 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:15 --> URI Class Initialized
INFO - 2020-02-13 11:36:15 --> Router Class Initialized
INFO - 2020-02-13 11:36:15 --> Output Class Initialized
INFO - 2020-02-13 11:36:15 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:15 --> Input Class Initialized
INFO - 2020-02-13 11:36:15 --> Language Class Initialized
ERROR - 2020-02-13 11:36:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 11:36:15 --> Config Class Initialized
INFO - 2020-02-13 11:36:15 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:36:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:15 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:15 --> URI Class Initialized
INFO - 2020-02-13 11:36:15 --> Router Class Initialized
INFO - 2020-02-13 11:36:15 --> Output Class Initialized
INFO - 2020-02-13 11:36:15 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:15 --> Input Class Initialized
INFO - 2020-02-13 11:36:15 --> Language Class Initialized
ERROR - 2020-02-13 11:36:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 11:36:16 --> Config Class Initialized
INFO - 2020-02-13 11:36:16 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:36:16 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:16 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:16 --> URI Class Initialized
INFO - 2020-02-13 11:36:16 --> Router Class Initialized
INFO - 2020-02-13 11:36:16 --> Output Class Initialized
INFO - 2020-02-13 11:36:16 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:16 --> Input Class Initialized
INFO - 2020-02-13 11:36:16 --> Language Class Initialized
ERROR - 2020-02-13 11:36:16 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 11:36:29 --> Config Class Initialized
INFO - 2020-02-13 11:36:29 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:36:29 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:36:29 --> Utf8 Class Initialized
INFO - 2020-02-13 11:36:29 --> URI Class Initialized
INFO - 2020-02-13 11:36:29 --> Router Class Initialized
INFO - 2020-02-13 11:36:29 --> Output Class Initialized
INFO - 2020-02-13 11:36:29 --> Security Class Initialized
DEBUG - 2020-02-13 11:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:36:29 --> Input Class Initialized
INFO - 2020-02-13 11:36:29 --> Language Class Initialized
INFO - 2020-02-13 11:36:29 --> Loader Class Initialized
INFO - 2020-02-13 11:36:29 --> Helper loaded: url_helper
INFO - 2020-02-13 11:36:29 --> Helper loaded: string_helper
INFO - 2020-02-13 11:36:29 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:36:29 --> Controller Class Initialized
INFO - 2020-02-13 11:36:29 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:36:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:36:29 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:36:29 --> Helper loaded: form_helper
INFO - 2020-02-13 11:36:29 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:36:29 --> Severity: Notice --> Undefined index: total_bayar2 C:\xampp\htdocs\roadshow\application\models\M_tiket.php 81
INFO - 2020-02-13 11:36:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 11:36:29 --> Final output sent to browser
DEBUG - 2020-02-13 11:36:29 --> Total execution time: 0.7092
INFO - 2020-02-13 11:43:16 --> Config Class Initialized
INFO - 2020-02-13 11:43:16 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:43:16 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:16 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:16 --> URI Class Initialized
DEBUG - 2020-02-13 11:43:16 --> No URI present. Default controller set.
INFO - 2020-02-13 11:43:16 --> Router Class Initialized
INFO - 2020-02-13 11:43:16 --> Output Class Initialized
INFO - 2020-02-13 11:43:16 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:16 --> Input Class Initialized
INFO - 2020-02-13 11:43:16 --> Language Class Initialized
INFO - 2020-02-13 11:43:16 --> Loader Class Initialized
INFO - 2020-02-13 11:43:16 --> Helper loaded: url_helper
INFO - 2020-02-13 11:43:16 --> Helper loaded: string_helper
INFO - 2020-02-13 11:43:16 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:43:16 --> Controller Class Initialized
INFO - 2020-02-13 11:43:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 11:43:16 --> Pagination Class Initialized
INFO - 2020-02-13 11:43:17 --> Model "M_show" initialized
INFO - 2020-02-13 11:43:17 --> Helper loaded: form_helper
INFO - 2020-02-13 11:43:17 --> Form Validation Class Initialized
INFO - 2020-02-13 11:43:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 11:43:17 --> Final output sent to browser
INFO - 2020-02-13 11:43:17 --> Config Class Initialized
INFO - 2020-02-13 11:43:17 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:43:17 --> Total execution time: 0.6631
DEBUG - 2020-02-13 11:43:17 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:17 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:17 --> URI Class Initialized
DEBUG - 2020-02-13 11:43:17 --> No URI present. Default controller set.
INFO - 2020-02-13 11:43:17 --> Router Class Initialized
INFO - 2020-02-13 11:43:17 --> Output Class Initialized
INFO - 2020-02-13 11:43:17 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:17 --> Input Class Initialized
INFO - 2020-02-13 11:43:17 --> Language Class Initialized
INFO - 2020-02-13 11:43:17 --> Loader Class Initialized
INFO - 2020-02-13 11:43:17 --> Helper loaded: url_helper
INFO - 2020-02-13 11:43:17 --> Helper loaded: string_helper
INFO - 2020-02-13 11:43:17 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:43:17 --> Controller Class Initialized
INFO - 2020-02-13 11:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 11:43:17 --> Pagination Class Initialized
INFO - 2020-02-13 11:43:17 --> Model "M_show" initialized
INFO - 2020-02-13 11:43:17 --> Helper loaded: form_helper
INFO - 2020-02-13 11:43:17 --> Form Validation Class Initialized
INFO - 2020-02-13 11:43:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 11:43:17 --> Final output sent to browser
DEBUG - 2020-02-13 11:43:17 --> Total execution time: 0.6386
INFO - 2020-02-13 11:43:47 --> Config Class Initialized
INFO - 2020-02-13 11:43:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:43:47 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:47 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:47 --> URI Class Initialized
INFO - 2020-02-13 11:43:47 --> Router Class Initialized
INFO - 2020-02-13 11:43:47 --> Output Class Initialized
INFO - 2020-02-13 11:43:47 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:47 --> Input Class Initialized
INFO - 2020-02-13 11:43:48 --> Language Class Initialized
INFO - 2020-02-13 11:43:48 --> Loader Class Initialized
INFO - 2020-02-13 11:43:48 --> Helper loaded: url_helper
INFO - 2020-02-13 11:43:48 --> Helper loaded: string_helper
INFO - 2020-02-13 11:43:48 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:43:48 --> Controller Class Initialized
INFO - 2020-02-13 11:43:48 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:43:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:43:48 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:43:48 --> Helper loaded: form_helper
INFO - 2020-02-13 11:43:48 --> Form Validation Class Initialized
INFO - 2020-02-13 11:43:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:43:48 --> Final output sent to browser
DEBUG - 2020-02-13 11:43:48 --> Total execution time: 0.5538
INFO - 2020-02-13 11:43:48 --> Config Class Initialized
INFO - 2020-02-13 11:43:48 --> Config Class Initialized
INFO - 2020-02-13 11:43:48 --> Config Class Initialized
INFO - 2020-02-13 11:43:48 --> Config Class Initialized
INFO - 2020-02-13 11:43:48 --> Hooks Class Initialized
INFO - 2020-02-13 11:43:48 --> Hooks Class Initialized
INFO - 2020-02-13 11:43:48 --> Hooks Class Initialized
INFO - 2020-02-13 11:43:48 --> Hooks Class Initialized
INFO - 2020-02-13 11:43:48 --> Config Class Initialized
INFO - 2020-02-13 11:43:48 --> Config Class Initialized
INFO - 2020-02-13 11:43:48 --> Hooks Class Initialized
INFO - 2020-02-13 11:43:48 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:43:48 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:48 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:48 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:48 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:48 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:43:48 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:48 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:48 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:48 --> URI Class Initialized
INFO - 2020-02-13 11:43:48 --> URI Class Initialized
INFO - 2020-02-13 11:43:48 --> URI Class Initialized
INFO - 2020-02-13 11:43:48 --> URI Class Initialized
INFO - 2020-02-13 11:43:48 --> URI Class Initialized
INFO - 2020-02-13 11:43:48 --> URI Class Initialized
INFO - 2020-02-13 11:43:48 --> Router Class Initialized
INFO - 2020-02-13 11:43:48 --> Router Class Initialized
INFO - 2020-02-13 11:43:48 --> Router Class Initialized
INFO - 2020-02-13 11:43:48 --> Router Class Initialized
INFO - 2020-02-13 11:43:48 --> Router Class Initialized
INFO - 2020-02-13 11:43:48 --> Output Class Initialized
INFO - 2020-02-13 11:43:48 --> Output Class Initialized
INFO - 2020-02-13 11:43:48 --> Router Class Initialized
INFO - 2020-02-13 11:43:48 --> Output Class Initialized
INFO - 2020-02-13 11:43:48 --> Output Class Initialized
INFO - 2020-02-13 11:43:48 --> Security Class Initialized
INFO - 2020-02-13 11:43:48 --> Security Class Initialized
INFO - 2020-02-13 11:43:48 --> Output Class Initialized
INFO - 2020-02-13 11:43:48 --> Security Class Initialized
INFO - 2020-02-13 11:43:48 --> Output Class Initialized
INFO - 2020-02-13 11:43:48 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:48 --> Security Class Initialized
INFO - 2020-02-13 11:43:48 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:48 --> Input Class Initialized
INFO - 2020-02-13 11:43:48 --> Input Class Initialized
INFO - 2020-02-13 11:43:48 --> Input Class Initialized
INFO - 2020-02-13 11:43:48 --> Input Class Initialized
DEBUG - 2020-02-13 11:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:48 --> Input Class Initialized
INFO - 2020-02-13 11:43:48 --> Input Class Initialized
INFO - 2020-02-13 11:43:48 --> Language Class Initialized
INFO - 2020-02-13 11:43:48 --> Language Class Initialized
INFO - 2020-02-13 11:43:48 --> Language Class Initialized
INFO - 2020-02-13 11:43:48 --> Language Class Initialized
INFO - 2020-02-13 11:43:48 --> Language Class Initialized
INFO - 2020-02-13 11:43:48 --> Language Class Initialized
ERROR - 2020-02-13 11:43:48 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 11:43:48 --> Loader Class Initialized
INFO - 2020-02-13 11:43:48 --> Loader Class Initialized
ERROR - 2020-02-13 11:43:48 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 11:43:48 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 11:43:48 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 11:43:48 --> Helper loaded: url_helper
INFO - 2020-02-13 11:43:48 --> Helper loaded: url_helper
INFO - 2020-02-13 11:43:48 --> Config Class Initialized
INFO - 2020-02-13 11:43:48 --> Config Class Initialized
INFO - 2020-02-13 11:43:48 --> Hooks Class Initialized
INFO - 2020-02-13 11:43:48 --> Hooks Class Initialized
INFO - 2020-02-13 11:43:48 --> Helper loaded: string_helper
INFO - 2020-02-13 11:43:48 --> Helper loaded: string_helper
INFO - 2020-02-13 11:43:48 --> Config Class Initialized
INFO - 2020-02-13 11:43:48 --> Config Class Initialized
INFO - 2020-02-13 11:43:48 --> Hooks Class Initialized
INFO - 2020-02-13 11:43:48 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:43:48 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:48 --> Database Driver Class Initialized
INFO - 2020-02-13 11:43:48 --> Database Driver Class Initialized
INFO - 2020-02-13 11:43:48 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:48 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 11:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:43:48 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:48 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:43:48 --> URI Class Initialized
INFO - 2020-02-13 11:43:48 --> URI Class Initialized
INFO - 2020-02-13 11:43:48 --> Controller Class Initialized
INFO - 2020-02-13 11:43:48 --> URI Class Initialized
INFO - 2020-02-13 11:43:48 --> URI Class Initialized
INFO - 2020-02-13 11:43:48 --> Router Class Initialized
INFO - 2020-02-13 11:43:48 --> Router Class Initialized
INFO - 2020-02-13 11:43:48 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:43:48 --> Router Class Initialized
INFO - 2020-02-13 11:43:48 --> Router Class Initialized
INFO - 2020-02-13 11:43:48 --> Output Class Initialized
INFO - 2020-02-13 11:43:48 --> Output Class Initialized
INFO - 2020-02-13 11:43:48 --> Security Class Initialized
INFO - 2020-02-13 11:43:48 --> Security Class Initialized
INFO - 2020-02-13 11:43:48 --> Output Class Initialized
INFO - 2020-02-13 11:43:48 --> Output Class Initialized
INFO - 2020-02-13 11:43:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:43:48 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 11:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:48 --> Security Class Initialized
INFO - 2020-02-13 11:43:48 --> Security Class Initialized
INFO - 2020-02-13 11:43:48 --> Input Class Initialized
INFO - 2020-02-13 11:43:48 --> Input Class Initialized
DEBUG - 2020-02-13 11:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:48 --> Helper loaded: form_helper
INFO - 2020-02-13 11:43:48 --> Form Validation Class Initialized
INFO - 2020-02-13 11:43:48 --> Input Class Initialized
INFO - 2020-02-13 11:43:48 --> Input Class Initialized
INFO - 2020-02-13 11:43:48 --> Language Class Initialized
INFO - 2020-02-13 11:43:48 --> Language Class Initialized
INFO - 2020-02-13 11:43:48 --> Language Class Initialized
INFO - 2020-02-13 11:43:48 --> Language Class Initialized
ERROR - 2020-02-13 11:43:48 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 11:43:48 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 11:43:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:43:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 11:43:49 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-13 11:43:49 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 11:43:49 --> Config Class Initialized
INFO - 2020-02-13 11:43:49 --> Config Class Initialized
INFO - 2020-02-13 11:43:49 --> Hooks Class Initialized
INFO - 2020-02-13 11:43:49 --> Hooks Class Initialized
INFO - 2020-02-13 11:43:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:43:49 --> Config Class Initialized
INFO - 2020-02-13 11:43:49 --> Config Class Initialized
INFO - 2020-02-13 11:43:49 --> Hooks Class Initialized
INFO - 2020-02-13 11:43:49 --> Hooks Class Initialized
INFO - 2020-02-13 11:43:49 --> Final output sent to browser
DEBUG - 2020-02-13 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:43:49 --> Total execution time: 0.6888
INFO - 2020-02-13 11:43:49 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:49 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:43:49 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:49 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:49 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:43:49 --> URI Class Initialized
INFO - 2020-02-13 11:43:49 --> URI Class Initialized
INFO - 2020-02-13 11:43:49 --> Controller Class Initialized
INFO - 2020-02-13 11:43:49 --> URI Class Initialized
INFO - 2020-02-13 11:43:49 --> Router Class Initialized
INFO - 2020-02-13 11:43:49 --> URI Class Initialized
INFO - 2020-02-13 11:43:49 --> Router Class Initialized
INFO - 2020-02-13 11:43:49 --> Router Class Initialized
INFO - 2020-02-13 11:43:49 --> Router Class Initialized
INFO - 2020-02-13 11:43:49 --> Output Class Initialized
INFO - 2020-02-13 11:43:49 --> Output Class Initialized
INFO - 2020-02-13 11:43:49 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:43:49 --> Security Class Initialized
INFO - 2020-02-13 11:43:49 --> Security Class Initialized
INFO - 2020-02-13 11:43:49 --> Output Class Initialized
INFO - 2020-02-13 11:43:49 --> Output Class Initialized
INFO - 2020-02-13 11:43:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:43:49 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 11:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:49 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:49 --> Security Class Initialized
INFO - 2020-02-13 11:43:49 --> Input Class Initialized
INFO - 2020-02-13 11:43:49 --> Input Class Initialized
DEBUG - 2020-02-13 11:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:49 --> Helper loaded: form_helper
INFO - 2020-02-13 11:43:49 --> Input Class Initialized
INFO - 2020-02-13 11:43:49 --> Form Validation Class Initialized
INFO - 2020-02-13 11:43:49 --> Input Class Initialized
INFO - 2020-02-13 11:43:49 --> Language Class Initialized
INFO - 2020-02-13 11:43:49 --> Language Class Initialized
INFO - 2020-02-13 11:43:49 --> Language Class Initialized
INFO - 2020-02-13 11:43:49 --> Language Class Initialized
ERROR - 2020-02-13 11:43:49 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 11:43:49 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 11:43:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:43:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 11:43:49 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 11:43:49 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 11:43:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:43:49 --> Config Class Initialized
INFO - 2020-02-13 11:43:49 --> Hooks Class Initialized
INFO - 2020-02-13 11:43:49 --> Final output sent to browser
DEBUG - 2020-02-13 11:43:49 --> Total execution time: 0.9822
DEBUG - 2020-02-13 11:43:49 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:49 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:49 --> URI Class Initialized
INFO - 2020-02-13 11:43:49 --> Router Class Initialized
INFO - 2020-02-13 11:43:49 --> Output Class Initialized
INFO - 2020-02-13 11:43:49 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:49 --> Input Class Initialized
INFO - 2020-02-13 11:43:49 --> Language Class Initialized
ERROR - 2020-02-13 11:43:49 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 11:43:49 --> Config Class Initialized
INFO - 2020-02-13 11:43:49 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:43:49 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:49 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:49 --> URI Class Initialized
INFO - 2020-02-13 11:43:49 --> Router Class Initialized
INFO - 2020-02-13 11:43:49 --> Output Class Initialized
INFO - 2020-02-13 11:43:49 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:49 --> Input Class Initialized
INFO - 2020-02-13 11:43:49 --> Language Class Initialized
ERROR - 2020-02-13 11:43:49 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 11:43:49 --> Config Class Initialized
INFO - 2020-02-13 11:43:49 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:43:49 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:49 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:50 --> URI Class Initialized
INFO - 2020-02-13 11:43:50 --> Router Class Initialized
INFO - 2020-02-13 11:43:50 --> Output Class Initialized
INFO - 2020-02-13 11:43:50 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:50 --> Input Class Initialized
INFO - 2020-02-13 11:43:50 --> Language Class Initialized
ERROR - 2020-02-13 11:43:50 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 11:43:50 --> Config Class Initialized
INFO - 2020-02-13 11:43:50 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:43:50 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:50 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:50 --> URI Class Initialized
INFO - 2020-02-13 11:43:50 --> Router Class Initialized
INFO - 2020-02-13 11:43:50 --> Output Class Initialized
INFO - 2020-02-13 11:43:50 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:50 --> Input Class Initialized
INFO - 2020-02-13 11:43:50 --> Language Class Initialized
ERROR - 2020-02-13 11:43:50 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 11:43:50 --> Config Class Initialized
INFO - 2020-02-13 11:43:50 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:43:50 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:50 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:50 --> URI Class Initialized
INFO - 2020-02-13 11:43:50 --> Router Class Initialized
INFO - 2020-02-13 11:43:50 --> Output Class Initialized
INFO - 2020-02-13 11:43:50 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:50 --> Input Class Initialized
INFO - 2020-02-13 11:43:50 --> Language Class Initialized
ERROR - 2020-02-13 11:43:50 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 11:43:50 --> Config Class Initialized
INFO - 2020-02-13 11:43:50 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:43:50 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:50 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:50 --> URI Class Initialized
INFO - 2020-02-13 11:43:50 --> Router Class Initialized
INFO - 2020-02-13 11:43:50 --> Output Class Initialized
INFO - 2020-02-13 11:43:50 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:51 --> Input Class Initialized
INFO - 2020-02-13 11:43:51 --> Language Class Initialized
ERROR - 2020-02-13 11:43:51 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 11:43:51 --> Config Class Initialized
INFO - 2020-02-13 11:43:51 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:43:51 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:51 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:51 --> URI Class Initialized
INFO - 2020-02-13 11:43:51 --> Router Class Initialized
INFO - 2020-02-13 11:43:51 --> Output Class Initialized
INFO - 2020-02-13 11:43:51 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:51 --> Input Class Initialized
INFO - 2020-02-13 11:43:51 --> Language Class Initialized
ERROR - 2020-02-13 11:43:51 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 11:43:51 --> Config Class Initialized
INFO - 2020-02-13 11:43:51 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:43:51 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:43:51 --> Utf8 Class Initialized
INFO - 2020-02-13 11:43:51 --> URI Class Initialized
INFO - 2020-02-13 11:43:51 --> Router Class Initialized
INFO - 2020-02-13 11:43:51 --> Output Class Initialized
INFO - 2020-02-13 11:43:51 --> Security Class Initialized
DEBUG - 2020-02-13 11:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:43:51 --> Input Class Initialized
INFO - 2020-02-13 11:43:51 --> Language Class Initialized
ERROR - 2020-02-13 11:43:51 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 11:44:10 --> Config Class Initialized
INFO - 2020-02-13 11:44:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:44:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:44:10 --> Utf8 Class Initialized
INFO - 2020-02-13 11:44:10 --> URI Class Initialized
INFO - 2020-02-13 11:44:10 --> Router Class Initialized
INFO - 2020-02-13 11:44:10 --> Output Class Initialized
INFO - 2020-02-13 11:44:10 --> Security Class Initialized
DEBUG - 2020-02-13 11:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:44:10 --> Input Class Initialized
INFO - 2020-02-13 11:44:10 --> Language Class Initialized
INFO - 2020-02-13 11:44:10 --> Loader Class Initialized
INFO - 2020-02-13 11:44:10 --> Helper loaded: url_helper
INFO - 2020-02-13 11:44:10 --> Helper loaded: string_helper
INFO - 2020-02-13 11:44:10 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:44:10 --> Controller Class Initialized
INFO - 2020-02-13 11:44:10 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:44:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:44:10 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:44:10 --> Helper loaded: form_helper
INFO - 2020-02-13 11:44:10 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:44:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 67
ERROR - 2020-02-13 11:44:11 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('33', '200000', '1', '2', NULL)
INFO - 2020-02-13 11:44:11 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 11:44:18 --> Config Class Initialized
INFO - 2020-02-13 11:44:18 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:44:18 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:44:18 --> Utf8 Class Initialized
INFO - 2020-02-13 11:44:18 --> URI Class Initialized
INFO - 2020-02-13 11:44:18 --> Router Class Initialized
INFO - 2020-02-13 11:44:18 --> Output Class Initialized
INFO - 2020-02-13 11:44:18 --> Security Class Initialized
DEBUG - 2020-02-13 11:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:44:18 --> Input Class Initialized
INFO - 2020-02-13 11:44:18 --> Language Class Initialized
INFO - 2020-02-13 11:44:18 --> Loader Class Initialized
INFO - 2020-02-13 11:44:18 --> Helper loaded: url_helper
INFO - 2020-02-13 11:44:18 --> Helper loaded: string_helper
INFO - 2020-02-13 11:44:18 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:44:19 --> Controller Class Initialized
INFO - 2020-02-13 11:44:19 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:44:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:44:19 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:44:19 --> Helper loaded: form_helper
INFO - 2020-02-13 11:44:19 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:44:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 67
ERROR - 2020-02-13 11:44:19 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('33', '200000', '1', '2', NULL)
INFO - 2020-02-13 11:44:19 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 11:46:49 --> Config Class Initialized
INFO - 2020-02-13 11:46:49 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:46:49 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:46:49 --> Utf8 Class Initialized
INFO - 2020-02-13 11:46:49 --> URI Class Initialized
INFO - 2020-02-13 11:46:49 --> Router Class Initialized
INFO - 2020-02-13 11:46:49 --> Output Class Initialized
INFO - 2020-02-13 11:46:49 --> Security Class Initialized
DEBUG - 2020-02-13 11:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:46:49 --> Input Class Initialized
INFO - 2020-02-13 11:46:49 --> Language Class Initialized
INFO - 2020-02-13 11:46:49 --> Loader Class Initialized
INFO - 2020-02-13 11:46:49 --> Helper loaded: url_helper
INFO - 2020-02-13 11:46:49 --> Helper loaded: string_helper
INFO - 2020-02-13 11:46:49 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:46:49 --> Controller Class Initialized
INFO - 2020-02-13 11:46:49 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:46:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:46:49 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:46:49 --> Helper loaded: form_helper
INFO - 2020-02-13 11:46:49 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:46:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 67
ERROR - 2020-02-13 11:46:50 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('33', '200000', '1', '2', NULL)
INFO - 2020-02-13 11:46:50 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 11:46:54 --> Config Class Initialized
INFO - 2020-02-13 11:46:54 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:46:54 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:46:54 --> Utf8 Class Initialized
INFO - 2020-02-13 11:46:54 --> URI Class Initialized
INFO - 2020-02-13 11:46:54 --> Router Class Initialized
INFO - 2020-02-13 11:46:54 --> Output Class Initialized
INFO - 2020-02-13 11:46:54 --> Security Class Initialized
DEBUG - 2020-02-13 11:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:46:54 --> Input Class Initialized
INFO - 2020-02-13 11:46:54 --> Language Class Initialized
INFO - 2020-02-13 11:46:54 --> Loader Class Initialized
INFO - 2020-02-13 11:46:54 --> Helper loaded: url_helper
INFO - 2020-02-13 11:46:54 --> Helper loaded: string_helper
INFO - 2020-02-13 11:46:54 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:46:54 --> Controller Class Initialized
INFO - 2020-02-13 11:46:54 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:46:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:46:54 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:46:55 --> Helper loaded: form_helper
INFO - 2020-02-13 11:46:55 --> Form Validation Class Initialized
INFO - 2020-02-13 11:46:55 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:46:55 --> Final output sent to browser
DEBUG - 2020-02-13 11:46:55 --> Total execution time: 0.5589
INFO - 2020-02-13 11:46:59 --> Config Class Initialized
INFO - 2020-02-13 11:46:59 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:46:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:46:59 --> Utf8 Class Initialized
INFO - 2020-02-13 11:46:59 --> URI Class Initialized
INFO - 2020-02-13 11:46:59 --> Router Class Initialized
INFO - 2020-02-13 11:46:59 --> Output Class Initialized
INFO - 2020-02-13 11:46:59 --> Security Class Initialized
DEBUG - 2020-02-13 11:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:46:59 --> Input Class Initialized
INFO - 2020-02-13 11:46:59 --> Language Class Initialized
INFO - 2020-02-13 11:46:59 --> Loader Class Initialized
INFO - 2020-02-13 11:46:59 --> Helper loaded: url_helper
INFO - 2020-02-13 11:46:59 --> Helper loaded: string_helper
INFO - 2020-02-13 11:46:59 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:46:59 --> Controller Class Initialized
INFO - 2020-02-13 11:46:59 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:46:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:46:59 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:46:59 --> Helper loaded: form_helper
INFO - 2020-02-13 11:46:59 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:46:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 67
ERROR - 2020-02-13 11:46:59 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('33', '200000', '1', '2', NULL)
INFO - 2020-02-13 11:46:59 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 11:47:59 --> Config Class Initialized
INFO - 2020-02-13 11:47:59 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:47:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:47:59 --> Utf8 Class Initialized
INFO - 2020-02-13 11:47:59 --> URI Class Initialized
INFO - 2020-02-13 11:47:59 --> Router Class Initialized
INFO - 2020-02-13 11:47:59 --> Output Class Initialized
INFO - 2020-02-13 11:47:59 --> Security Class Initialized
DEBUG - 2020-02-13 11:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:47:59 --> Input Class Initialized
INFO - 2020-02-13 11:47:59 --> Language Class Initialized
INFO - 2020-02-13 11:47:59 --> Loader Class Initialized
INFO - 2020-02-13 11:47:59 --> Helper loaded: url_helper
INFO - 2020-02-13 11:47:59 --> Helper loaded: string_helper
INFO - 2020-02-13 11:47:59 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:47:59 --> Controller Class Initialized
INFO - 2020-02-13 11:47:59 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:47:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:47:59 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:47:59 --> Helper loaded: form_helper
INFO - 2020-02-13 11:47:59 --> Form Validation Class Initialized
INFO - 2020-02-13 11:48:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:48:00 --> Final output sent to browser
DEBUG - 2020-02-13 11:48:00 --> Total execution time: 0.5961
INFO - 2020-02-13 11:48:00 --> Config Class Initialized
INFO - 2020-02-13 11:48:00 --> Config Class Initialized
INFO - 2020-02-13 11:48:00 --> Hooks Class Initialized
INFO - 2020-02-13 11:48:00 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:48:00 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:48:00 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:48:00 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:48:00 --> Utf8 Class Initialized
INFO - 2020-02-13 11:48:00 --> URI Class Initialized
INFO - 2020-02-13 11:48:00 --> URI Class Initialized
INFO - 2020-02-13 11:48:00 --> Router Class Initialized
INFO - 2020-02-13 11:48:00 --> Router Class Initialized
INFO - 2020-02-13 11:48:00 --> Output Class Initialized
INFO - 2020-02-13 11:48:00 --> Output Class Initialized
INFO - 2020-02-13 11:48:00 --> Security Class Initialized
INFO - 2020-02-13 11:48:00 --> Security Class Initialized
DEBUG - 2020-02-13 11:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:48:00 --> Input Class Initialized
INFO - 2020-02-13 11:48:00 --> Input Class Initialized
INFO - 2020-02-13 11:48:00 --> Language Class Initialized
INFO - 2020-02-13 11:48:00 --> Language Class Initialized
INFO - 2020-02-13 11:48:00 --> Loader Class Initialized
INFO - 2020-02-13 11:48:00 --> Loader Class Initialized
INFO - 2020-02-13 11:48:00 --> Helper loaded: url_helper
INFO - 2020-02-13 11:48:00 --> Helper loaded: url_helper
INFO - 2020-02-13 11:48:00 --> Helper loaded: string_helper
INFO - 2020-02-13 11:48:00 --> Helper loaded: string_helper
INFO - 2020-02-13 11:48:00 --> Database Driver Class Initialized
INFO - 2020-02-13 11:48:00 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 11:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:48:00 --> Controller Class Initialized
INFO - 2020-02-13 11:48:00 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:48:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:48:00 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:48:00 --> Helper loaded: form_helper
INFO - 2020-02-13 11:48:00 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:48:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:48:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 11:48:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:48:00 --> Final output sent to browser
DEBUG - 2020-02-13 11:48:00 --> Total execution time: 0.7771
INFO - 2020-02-13 11:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:48:01 --> Controller Class Initialized
INFO - 2020-02-13 11:48:01 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:48:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:48:01 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:48:01 --> Helper loaded: form_helper
INFO - 2020-02-13 11:48:01 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:48:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:48:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 11:48:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:48:01 --> Final output sent to browser
DEBUG - 2020-02-13 11:48:01 --> Total execution time: 1.1052
INFO - 2020-02-13 11:48:02 --> Config Class Initialized
INFO - 2020-02-13 11:48:02 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:48:02 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:48:02 --> Utf8 Class Initialized
INFO - 2020-02-13 11:48:02 --> URI Class Initialized
INFO - 2020-02-13 11:48:03 --> Router Class Initialized
INFO - 2020-02-13 11:48:03 --> Output Class Initialized
INFO - 2020-02-13 11:48:03 --> Security Class Initialized
DEBUG - 2020-02-13 11:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:48:03 --> Input Class Initialized
INFO - 2020-02-13 11:48:03 --> Language Class Initialized
INFO - 2020-02-13 11:48:03 --> Loader Class Initialized
INFO - 2020-02-13 11:48:03 --> Helper loaded: url_helper
INFO - 2020-02-13 11:48:03 --> Helper loaded: string_helper
INFO - 2020-02-13 11:48:03 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:48:03 --> Controller Class Initialized
INFO - 2020-02-13 11:48:03 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:48:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:48:03 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:48:03 --> Helper loaded: form_helper
INFO - 2020-02-13 11:48:03 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:48:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 63
ERROR - 2020-02-13 11:48:03 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('33', '200000', '1', '2', NULL)
INFO - 2020-02-13 11:48:03 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 11:49:22 --> Config Class Initialized
INFO - 2020-02-13 11:49:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:22 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:22 --> URI Class Initialized
INFO - 2020-02-13 11:49:22 --> Router Class Initialized
INFO - 2020-02-13 11:49:22 --> Output Class Initialized
INFO - 2020-02-13 11:49:22 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:22 --> Input Class Initialized
INFO - 2020-02-13 11:49:22 --> Language Class Initialized
INFO - 2020-02-13 11:49:22 --> Loader Class Initialized
INFO - 2020-02-13 11:49:22 --> Helper loaded: url_helper
INFO - 2020-02-13 11:49:22 --> Helper loaded: string_helper
INFO - 2020-02-13 11:49:22 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:49:22 --> Controller Class Initialized
INFO - 2020-02-13 11:49:22 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:49:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:49:22 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:49:22 --> Helper loaded: form_helper
INFO - 2020-02-13 11:49:22 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:49:22 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 48
ERROR - 2020-02-13 11:49:22 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 49
ERROR - 2020-02-13 11:49:22 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 50
ERROR - 2020-02-13 11:49:22 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 51
ERROR - 2020-02-13 11:49:22 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 81
ERROR - 2020-02-13 11:49:22 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 82
ERROR - 2020-02-13 11:49:22 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 83
ERROR - 2020-02-13 11:49:22 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 84
ERROR - 2020-02-13 11:49:22 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pengunjung` (`nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2020-02-13 11:49:22 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-13 11:49:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow\system\core\Common.php 570
INFO - 2020-02-13 11:49:29 --> Config Class Initialized
INFO - 2020-02-13 11:49:29 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:29 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:30 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:30 --> URI Class Initialized
DEBUG - 2020-02-13 11:49:30 --> No URI present. Default controller set.
INFO - 2020-02-13 11:49:30 --> Router Class Initialized
INFO - 2020-02-13 11:49:30 --> Output Class Initialized
INFO - 2020-02-13 11:49:30 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:30 --> Input Class Initialized
INFO - 2020-02-13 11:49:30 --> Language Class Initialized
INFO - 2020-02-13 11:49:30 --> Loader Class Initialized
INFO - 2020-02-13 11:49:30 --> Helper loaded: url_helper
INFO - 2020-02-13 11:49:30 --> Helper loaded: string_helper
INFO - 2020-02-13 11:49:30 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:49:30 --> Controller Class Initialized
INFO - 2020-02-13 11:49:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 11:49:30 --> Pagination Class Initialized
INFO - 2020-02-13 11:49:30 --> Model "M_show" initialized
INFO - 2020-02-13 11:49:30 --> Helper loaded: form_helper
INFO - 2020-02-13 11:49:30 --> Form Validation Class Initialized
INFO - 2020-02-13 11:49:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 11:49:30 --> Final output sent to browser
INFO - 2020-02-13 11:49:30 --> Config Class Initialized
INFO - 2020-02-13 11:49:30 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:30 --> Total execution time: 0.6505
DEBUG - 2020-02-13 11:49:30 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:30 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:30 --> URI Class Initialized
DEBUG - 2020-02-13 11:49:30 --> No URI present. Default controller set.
INFO - 2020-02-13 11:49:30 --> Router Class Initialized
INFO - 2020-02-13 11:49:30 --> Output Class Initialized
INFO - 2020-02-13 11:49:30 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:30 --> Input Class Initialized
INFO - 2020-02-13 11:49:30 --> Language Class Initialized
INFO - 2020-02-13 11:49:30 --> Loader Class Initialized
INFO - 2020-02-13 11:49:30 --> Helper loaded: url_helper
INFO - 2020-02-13 11:49:30 --> Helper loaded: string_helper
INFO - 2020-02-13 11:49:30 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:49:31 --> Controller Class Initialized
INFO - 2020-02-13 11:49:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 11:49:31 --> Pagination Class Initialized
INFO - 2020-02-13 11:49:31 --> Model "M_show" initialized
INFO - 2020-02-13 11:49:31 --> Helper loaded: form_helper
INFO - 2020-02-13 11:49:31 --> Form Validation Class Initialized
INFO - 2020-02-13 11:49:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 11:49:31 --> Final output sent to browser
DEBUG - 2020-02-13 11:49:31 --> Total execution time: 0.6794
INFO - 2020-02-13 11:49:34 --> Config Class Initialized
INFO - 2020-02-13 11:49:34 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:34 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:34 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:34 --> URI Class Initialized
INFO - 2020-02-13 11:49:34 --> Router Class Initialized
INFO - 2020-02-13 11:49:34 --> Output Class Initialized
INFO - 2020-02-13 11:49:34 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:34 --> Input Class Initialized
INFO - 2020-02-13 11:49:34 --> Language Class Initialized
INFO - 2020-02-13 11:49:34 --> Loader Class Initialized
INFO - 2020-02-13 11:49:34 --> Helper loaded: url_helper
INFO - 2020-02-13 11:49:34 --> Helper loaded: string_helper
INFO - 2020-02-13 11:49:34 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:49:34 --> Controller Class Initialized
INFO - 2020-02-13 11:49:34 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:49:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:49:34 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:49:34 --> Helper loaded: form_helper
INFO - 2020-02-13 11:49:34 --> Form Validation Class Initialized
INFO - 2020-02-13 11:49:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:49:34 --> Final output sent to browser
DEBUG - 2020-02-13 11:49:34 --> Total execution time: 0.5733
INFO - 2020-02-13 11:49:34 --> Config Class Initialized
INFO - 2020-02-13 11:49:34 --> Config Class Initialized
INFO - 2020-02-13 11:49:34 --> Config Class Initialized
INFO - 2020-02-13 11:49:34 --> Config Class Initialized
INFO - 2020-02-13 11:49:34 --> Config Class Initialized
INFO - 2020-02-13 11:49:34 --> Hooks Class Initialized
INFO - 2020-02-13 11:49:34 --> Hooks Class Initialized
INFO - 2020-02-13 11:49:34 --> Hooks Class Initialized
INFO - 2020-02-13 11:49:34 --> Hooks Class Initialized
INFO - 2020-02-13 11:49:34 --> Hooks Class Initialized
INFO - 2020-02-13 11:49:34 --> Config Class Initialized
INFO - 2020-02-13 11:49:34 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:49:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:49:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:49:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:49:34 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:34 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:34 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:34 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:34 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:34 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:49:34 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:34 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:34 --> URI Class Initialized
INFO - 2020-02-13 11:49:34 --> URI Class Initialized
INFO - 2020-02-13 11:49:34 --> URI Class Initialized
INFO - 2020-02-13 11:49:34 --> URI Class Initialized
INFO - 2020-02-13 11:49:34 --> URI Class Initialized
INFO - 2020-02-13 11:49:34 --> Router Class Initialized
INFO - 2020-02-13 11:49:34 --> Router Class Initialized
INFO - 2020-02-13 11:49:34 --> URI Class Initialized
INFO - 2020-02-13 11:49:34 --> Router Class Initialized
INFO - 2020-02-13 11:49:34 --> Router Class Initialized
INFO - 2020-02-13 11:49:34 --> Router Class Initialized
INFO - 2020-02-13 11:49:34 --> Router Class Initialized
INFO - 2020-02-13 11:49:34 --> Output Class Initialized
INFO - 2020-02-13 11:49:34 --> Output Class Initialized
INFO - 2020-02-13 11:49:34 --> Output Class Initialized
INFO - 2020-02-13 11:49:34 --> Output Class Initialized
INFO - 2020-02-13 11:49:34 --> Output Class Initialized
INFO - 2020-02-13 11:49:34 --> Security Class Initialized
INFO - 2020-02-13 11:49:34 --> Security Class Initialized
INFO - 2020-02-13 11:49:34 --> Output Class Initialized
INFO - 2020-02-13 11:49:34 --> Security Class Initialized
INFO - 2020-02-13 11:49:34 --> Security Class Initialized
INFO - 2020-02-13 11:49:34 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:34 --> Security Class Initialized
INFO - 2020-02-13 11:49:34 --> Input Class Initialized
INFO - 2020-02-13 11:49:34 --> Input Class Initialized
INFO - 2020-02-13 11:49:34 --> Input Class Initialized
INFO - 2020-02-13 11:49:34 --> Input Class Initialized
INFO - 2020-02-13 11:49:34 --> Input Class Initialized
DEBUG - 2020-02-13 11:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:34 --> Input Class Initialized
INFO - 2020-02-13 11:49:34 --> Language Class Initialized
INFO - 2020-02-13 11:49:34 --> Language Class Initialized
INFO - 2020-02-13 11:49:34 --> Language Class Initialized
INFO - 2020-02-13 11:49:34 --> Language Class Initialized
INFO - 2020-02-13 11:49:34 --> Language Class Initialized
INFO - 2020-02-13 11:49:35 --> Language Class Initialized
ERROR - 2020-02-13 11:49:35 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 11:49:35 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 11:49:35 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 11:49:35 --> Loader Class Initialized
INFO - 2020-02-13 11:49:35 --> Loader Class Initialized
INFO - 2020-02-13 11:49:35 --> Helper loaded: url_helper
ERROR - 2020-02-13 11:49:35 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 11:49:35 --> Helper loaded: url_helper
INFO - 2020-02-13 11:49:35 --> Config Class Initialized
INFO - 2020-02-13 11:49:35 --> Config Class Initialized
INFO - 2020-02-13 11:49:35 --> Config Class Initialized
INFO - 2020-02-13 11:49:35 --> Hooks Class Initialized
INFO - 2020-02-13 11:49:35 --> Hooks Class Initialized
INFO - 2020-02-13 11:49:35 --> Hooks Class Initialized
INFO - 2020-02-13 11:49:35 --> Helper loaded: string_helper
INFO - 2020-02-13 11:49:35 --> Helper loaded: string_helper
INFO - 2020-02-13 11:49:35 --> Config Class Initialized
INFO - 2020-02-13 11:49:35 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:49:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:35 --> Database Driver Class Initialized
INFO - 2020-02-13 11:49:35 --> Database Driver Class Initialized
INFO - 2020-02-13 11:49:35 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:35 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:35 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 11:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:49:35 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:49:35 --> URI Class Initialized
INFO - 2020-02-13 11:49:35 --> URI Class Initialized
INFO - 2020-02-13 11:49:35 --> URI Class Initialized
INFO - 2020-02-13 11:49:35 --> Controller Class Initialized
INFO - 2020-02-13 11:49:35 --> URI Class Initialized
INFO - 2020-02-13 11:49:35 --> Router Class Initialized
INFO - 2020-02-13 11:49:35 --> Router Class Initialized
INFO - 2020-02-13 11:49:35 --> Router Class Initialized
INFO - 2020-02-13 11:49:35 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:49:35 --> Output Class Initialized
INFO - 2020-02-13 11:49:35 --> Output Class Initialized
INFO - 2020-02-13 11:49:35 --> Output Class Initialized
INFO - 2020-02-13 11:49:35 --> Router Class Initialized
INFO - 2020-02-13 11:49:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:49:35 --> Security Class Initialized
INFO - 2020-02-13 11:49:35 --> Output Class Initialized
INFO - 2020-02-13 11:49:35 --> Security Class Initialized
INFO - 2020-02-13 11:49:35 --> Security Class Initialized
INFO - 2020-02-13 11:49:35 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 11:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:35 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:35 --> Input Class Initialized
INFO - 2020-02-13 11:49:35 --> Input Class Initialized
INFO - 2020-02-13 11:49:35 --> Input Class Initialized
DEBUG - 2020-02-13 11:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:35 --> Helper loaded: form_helper
INFO - 2020-02-13 11:49:35 --> Form Validation Class Initialized
INFO - 2020-02-13 11:49:35 --> Input Class Initialized
INFO - 2020-02-13 11:49:35 --> Language Class Initialized
INFO - 2020-02-13 11:49:35 --> Language Class Initialized
INFO - 2020-02-13 11:49:35 --> Language Class Initialized
INFO - 2020-02-13 11:49:35 --> Language Class Initialized
ERROR - 2020-02-13 11:49:35 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 11:49:35 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 11:49:35 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 11:49:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:49:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 11:49:35 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 11:49:35 --> Config Class Initialized
INFO - 2020-02-13 11:49:35 --> Config Class Initialized
INFO - 2020-02-13 11:49:35 --> Config Class Initialized
INFO - 2020-02-13 11:49:35 --> Hooks Class Initialized
INFO - 2020-02-13 11:49:35 --> Hooks Class Initialized
INFO - 2020-02-13 11:49:35 --> Hooks Class Initialized
INFO - 2020-02-13 11:49:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:49:35 --> Config Class Initialized
INFO - 2020-02-13 11:49:35 --> Hooks Class Initialized
INFO - 2020-02-13 11:49:35 --> Final output sent to browser
DEBUG - 2020-02-13 11:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:49:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:35 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:35 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:35 --> Utf8 Class Initialized
DEBUG - 2020-02-13 11:49:35 --> Total execution time: 0.7214
DEBUG - 2020-02-13 11:49:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:35 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:35 --> URI Class Initialized
INFO - 2020-02-13 11:49:35 --> URI Class Initialized
INFO - 2020-02-13 11:49:35 --> URI Class Initialized
INFO - 2020-02-13 11:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:49:35 --> Controller Class Initialized
INFO - 2020-02-13 11:49:35 --> URI Class Initialized
INFO - 2020-02-13 11:49:35 --> Router Class Initialized
INFO - 2020-02-13 11:49:35 --> Router Class Initialized
INFO - 2020-02-13 11:49:35 --> Router Class Initialized
INFO - 2020-02-13 11:49:35 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:49:35 --> Router Class Initialized
INFO - 2020-02-13 11:49:35 --> Output Class Initialized
INFO - 2020-02-13 11:49:35 --> Output Class Initialized
INFO - 2020-02-13 11:49:35 --> Output Class Initialized
INFO - 2020-02-13 11:49:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:49:35 --> Security Class Initialized
INFO - 2020-02-13 11:49:35 --> Security Class Initialized
INFO - 2020-02-13 11:49:35 --> Output Class Initialized
INFO - 2020-02-13 11:49:35 --> Security Class Initialized
INFO - 2020-02-13 11:49:35 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 11:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:35 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:35 --> Input Class Initialized
INFO - 2020-02-13 11:49:35 --> Input Class Initialized
INFO - 2020-02-13 11:49:35 --> Input Class Initialized
DEBUG - 2020-02-13 11:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:35 --> Helper loaded: form_helper
INFO - 2020-02-13 11:49:35 --> Form Validation Class Initialized
INFO - 2020-02-13 11:49:35 --> Language Class Initialized
INFO - 2020-02-13 11:49:35 --> Input Class Initialized
INFO - 2020-02-13 11:49:35 --> Language Class Initialized
INFO - 2020-02-13 11:49:35 --> Language Class Initialized
INFO - 2020-02-13 11:49:35 --> Language Class Initialized
ERROR - 2020-02-13 11:49:35 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 11:49:35 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 11:49:35 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 11:49:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:49:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 11:49:35 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 11:49:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:49:35 --> Config Class Initialized
INFO - 2020-02-13 11:49:35 --> Hooks Class Initialized
INFO - 2020-02-13 11:49:35 --> Final output sent to browser
DEBUG - 2020-02-13 11:49:35 --> Total execution time: 1.0236
DEBUG - 2020-02-13 11:49:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:35 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:35 --> URI Class Initialized
INFO - 2020-02-13 11:49:35 --> Router Class Initialized
INFO - 2020-02-13 11:49:35 --> Output Class Initialized
INFO - 2020-02-13 11:49:35 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:35 --> Input Class Initialized
INFO - 2020-02-13 11:49:35 --> Language Class Initialized
ERROR - 2020-02-13 11:49:35 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 11:49:35 --> Config Class Initialized
INFO - 2020-02-13 11:49:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:36 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:36 --> URI Class Initialized
INFO - 2020-02-13 11:49:36 --> Router Class Initialized
INFO - 2020-02-13 11:49:36 --> Output Class Initialized
INFO - 2020-02-13 11:49:36 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:36 --> Input Class Initialized
INFO - 2020-02-13 11:49:36 --> Language Class Initialized
ERROR - 2020-02-13 11:49:36 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 11:49:36 --> Config Class Initialized
INFO - 2020-02-13 11:49:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:36 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:36 --> URI Class Initialized
INFO - 2020-02-13 11:49:36 --> Router Class Initialized
INFO - 2020-02-13 11:49:36 --> Output Class Initialized
INFO - 2020-02-13 11:49:36 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:36 --> Input Class Initialized
INFO - 2020-02-13 11:49:36 --> Language Class Initialized
ERROR - 2020-02-13 11:49:36 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 11:49:36 --> Config Class Initialized
INFO - 2020-02-13 11:49:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:36 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:36 --> URI Class Initialized
INFO - 2020-02-13 11:49:36 --> Router Class Initialized
INFO - 2020-02-13 11:49:36 --> Output Class Initialized
INFO - 2020-02-13 11:49:36 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:36 --> Input Class Initialized
INFO - 2020-02-13 11:49:36 --> Language Class Initialized
ERROR - 2020-02-13 11:49:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 11:49:36 --> Config Class Initialized
INFO - 2020-02-13 11:49:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:36 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:36 --> URI Class Initialized
INFO - 2020-02-13 11:49:36 --> Router Class Initialized
INFO - 2020-02-13 11:49:36 --> Output Class Initialized
INFO - 2020-02-13 11:49:36 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:37 --> Input Class Initialized
INFO - 2020-02-13 11:49:37 --> Language Class Initialized
ERROR - 2020-02-13 11:49:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 11:49:37 --> Config Class Initialized
INFO - 2020-02-13 11:49:37 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:37 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:37 --> URI Class Initialized
INFO - 2020-02-13 11:49:37 --> Router Class Initialized
INFO - 2020-02-13 11:49:37 --> Output Class Initialized
INFO - 2020-02-13 11:49:37 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:37 --> Input Class Initialized
INFO - 2020-02-13 11:49:37 --> Language Class Initialized
ERROR - 2020-02-13 11:49:37 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 11:49:37 --> Config Class Initialized
INFO - 2020-02-13 11:49:37 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:37 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:37 --> URI Class Initialized
INFO - 2020-02-13 11:49:37 --> Router Class Initialized
INFO - 2020-02-13 11:49:37 --> Output Class Initialized
INFO - 2020-02-13 11:49:37 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:37 --> Input Class Initialized
INFO - 2020-02-13 11:49:37 --> Language Class Initialized
ERROR - 2020-02-13 11:49:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 11:49:37 --> Config Class Initialized
INFO - 2020-02-13 11:49:37 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:37 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:37 --> URI Class Initialized
INFO - 2020-02-13 11:49:37 --> Router Class Initialized
INFO - 2020-02-13 11:49:37 --> Output Class Initialized
INFO - 2020-02-13 11:49:37 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:37 --> Input Class Initialized
INFO - 2020-02-13 11:49:37 --> Language Class Initialized
ERROR - 2020-02-13 11:49:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 11:49:38 --> Config Class Initialized
INFO - 2020-02-13 11:49:38 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:38 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:38 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:38 --> URI Class Initialized
INFO - 2020-02-13 11:49:38 --> Router Class Initialized
INFO - 2020-02-13 11:49:38 --> Output Class Initialized
INFO - 2020-02-13 11:49:38 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:38 --> Input Class Initialized
INFO - 2020-02-13 11:49:38 --> Language Class Initialized
ERROR - 2020-02-13 11:49:38 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 11:49:49 --> Config Class Initialized
INFO - 2020-02-13 11:49:49 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:49:49 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:49:49 --> Utf8 Class Initialized
INFO - 2020-02-13 11:49:49 --> URI Class Initialized
INFO - 2020-02-13 11:49:49 --> Router Class Initialized
INFO - 2020-02-13 11:49:49 --> Output Class Initialized
INFO - 2020-02-13 11:49:49 --> Security Class Initialized
DEBUG - 2020-02-13 11:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:49:49 --> Input Class Initialized
INFO - 2020-02-13 11:49:49 --> Language Class Initialized
INFO - 2020-02-13 11:49:49 --> Loader Class Initialized
INFO - 2020-02-13 11:49:49 --> Helper loaded: url_helper
INFO - 2020-02-13 11:49:49 --> Helper loaded: string_helper
INFO - 2020-02-13 11:49:49 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:49:50 --> Controller Class Initialized
INFO - 2020-02-13 11:49:50 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:49:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:49:50 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:49:50 --> Helper loaded: form_helper
INFO - 2020-02-13 11:49:50 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:49:50 --> Severity: Notice --> Undefined variable: idpesan C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
ERROR - 2020-02-13 11:49:50 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
INFO - 2020-02-13 11:51:34 --> Config Class Initialized
INFO - 2020-02-13 11:51:34 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:51:34 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:51:34 --> Utf8 Class Initialized
INFO - 2020-02-13 11:51:34 --> URI Class Initialized
INFO - 2020-02-13 11:51:34 --> Router Class Initialized
INFO - 2020-02-13 11:51:34 --> Output Class Initialized
INFO - 2020-02-13 11:51:34 --> Security Class Initialized
DEBUG - 2020-02-13 11:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:51:34 --> Input Class Initialized
INFO - 2020-02-13 11:51:34 --> Language Class Initialized
INFO - 2020-02-13 11:51:34 --> Loader Class Initialized
INFO - 2020-02-13 11:51:34 --> Helper loaded: url_helper
INFO - 2020-02-13 11:51:34 --> Helper loaded: string_helper
INFO - 2020-02-13 11:51:34 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:51:34 --> Controller Class Initialized
INFO - 2020-02-13 11:51:34 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:51:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:51:34 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:51:34 --> Helper loaded: form_helper
INFO - 2020-02-13 11:51:34 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:51:34 --> Severity: Notice --> Undefined variable: idpesan C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
ERROR - 2020-02-13 11:51:35 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
INFO - 2020-02-13 11:51:39 --> Config Class Initialized
INFO - 2020-02-13 11:51:39 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:51:39 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:51:39 --> Utf8 Class Initialized
INFO - 2020-02-13 11:51:39 --> URI Class Initialized
INFO - 2020-02-13 11:51:39 --> Router Class Initialized
INFO - 2020-02-13 11:51:39 --> Output Class Initialized
INFO - 2020-02-13 11:51:39 --> Security Class Initialized
DEBUG - 2020-02-13 11:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:51:39 --> Input Class Initialized
INFO - 2020-02-13 11:51:39 --> Language Class Initialized
INFO - 2020-02-13 11:51:39 --> Loader Class Initialized
INFO - 2020-02-13 11:51:39 --> Helper loaded: url_helper
INFO - 2020-02-13 11:51:39 --> Helper loaded: string_helper
INFO - 2020-02-13 11:51:39 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:51:39 --> Controller Class Initialized
INFO - 2020-02-13 11:51:39 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:51:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:51:39 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:51:39 --> Helper loaded: form_helper
INFO - 2020-02-13 11:51:39 --> Form Validation Class Initialized
INFO - 2020-02-13 11:51:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:51:39 --> Final output sent to browser
DEBUG - 2020-02-13 11:51:40 --> Total execution time: 0.6166
INFO - 2020-02-13 11:51:43 --> Config Class Initialized
INFO - 2020-02-13 11:51:43 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:51:44 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:51:44 --> Utf8 Class Initialized
INFO - 2020-02-13 11:51:44 --> URI Class Initialized
INFO - 2020-02-13 11:51:44 --> Router Class Initialized
INFO - 2020-02-13 11:51:44 --> Output Class Initialized
INFO - 2020-02-13 11:51:44 --> Security Class Initialized
DEBUG - 2020-02-13 11:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:51:44 --> Input Class Initialized
INFO - 2020-02-13 11:51:44 --> Language Class Initialized
INFO - 2020-02-13 11:51:44 --> Loader Class Initialized
INFO - 2020-02-13 11:51:44 --> Helper loaded: url_helper
INFO - 2020-02-13 11:51:44 --> Helper loaded: string_helper
INFO - 2020-02-13 11:51:44 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:51:44 --> Controller Class Initialized
INFO - 2020-02-13 11:51:44 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:51:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:51:44 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:51:44 --> Helper loaded: form_helper
INFO - 2020-02-13 11:51:44 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:51:44 --> Severity: Notice --> Undefined variable: idpesan C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
ERROR - 2020-02-13 11:51:44 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
INFO - 2020-02-13 11:52:13 --> Config Class Initialized
INFO - 2020-02-13 11:52:13 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:52:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:52:13 --> Utf8 Class Initialized
INFO - 2020-02-13 11:52:14 --> URI Class Initialized
INFO - 2020-02-13 11:52:14 --> Router Class Initialized
INFO - 2020-02-13 11:52:14 --> Output Class Initialized
INFO - 2020-02-13 11:52:14 --> Security Class Initialized
DEBUG - 2020-02-13 11:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:52:14 --> Input Class Initialized
INFO - 2020-02-13 11:52:14 --> Language Class Initialized
INFO - 2020-02-13 11:52:14 --> Loader Class Initialized
INFO - 2020-02-13 11:52:14 --> Helper loaded: url_helper
INFO - 2020-02-13 11:52:14 --> Helper loaded: string_helper
INFO - 2020-02-13 11:52:14 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:52:14 --> Controller Class Initialized
INFO - 2020-02-13 11:52:14 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:52:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:52:14 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:52:14 --> Helper loaded: form_helper
INFO - 2020-02-13 11:52:14 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:52:14 --> Severity: Notice --> Undefined variable: idpesan C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
ERROR - 2020-02-13 11:52:14 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
INFO - 2020-02-13 11:52:56 --> Config Class Initialized
INFO - 2020-02-13 11:52:56 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:52:56 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:52:56 --> Utf8 Class Initialized
INFO - 2020-02-13 11:52:56 --> URI Class Initialized
INFO - 2020-02-13 11:52:56 --> Router Class Initialized
INFO - 2020-02-13 11:52:56 --> Output Class Initialized
INFO - 2020-02-13 11:52:56 --> Security Class Initialized
DEBUG - 2020-02-13 11:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:52:56 --> Input Class Initialized
INFO - 2020-02-13 11:52:56 --> Language Class Initialized
INFO - 2020-02-13 11:52:56 --> Loader Class Initialized
INFO - 2020-02-13 11:52:56 --> Helper loaded: url_helper
INFO - 2020-02-13 11:52:56 --> Helper loaded: string_helper
INFO - 2020-02-13 11:52:57 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:52:57 --> Controller Class Initialized
INFO - 2020-02-13 11:52:57 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:52:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:52:57 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:52:57 --> Helper loaded: form_helper
INFO - 2020-02-13 11:52:57 --> Form Validation Class Initialized
INFO - 2020-02-13 11:52:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:52:57 --> Final output sent to browser
INFO - 2020-02-13 11:52:57 --> Config Class Initialized
DEBUG - 2020-02-13 11:52:57 --> Total execution time: 0.5945
INFO - 2020-02-13 11:52:57 --> Config Class Initialized
INFO - 2020-02-13 11:52:57 --> Hooks Class Initialized
INFO - 2020-02-13 11:52:57 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:52:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:52:57 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:52:57 --> Utf8 Class Initialized
INFO - 2020-02-13 11:52:57 --> Utf8 Class Initialized
INFO - 2020-02-13 11:52:57 --> URI Class Initialized
INFO - 2020-02-13 11:52:57 --> URI Class Initialized
INFO - 2020-02-13 11:52:57 --> Router Class Initialized
INFO - 2020-02-13 11:52:57 --> Router Class Initialized
INFO - 2020-02-13 11:52:57 --> Output Class Initialized
INFO - 2020-02-13 11:52:57 --> Output Class Initialized
INFO - 2020-02-13 11:52:57 --> Security Class Initialized
INFO - 2020-02-13 11:52:57 --> Security Class Initialized
DEBUG - 2020-02-13 11:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:52:57 --> Input Class Initialized
INFO - 2020-02-13 11:52:57 --> Input Class Initialized
INFO - 2020-02-13 11:52:57 --> Language Class Initialized
INFO - 2020-02-13 11:52:57 --> Language Class Initialized
INFO - 2020-02-13 11:52:57 --> Loader Class Initialized
INFO - 2020-02-13 11:52:57 --> Loader Class Initialized
INFO - 2020-02-13 11:52:57 --> Helper loaded: url_helper
INFO - 2020-02-13 11:52:57 --> Helper loaded: url_helper
INFO - 2020-02-13 11:52:57 --> Helper loaded: string_helper
INFO - 2020-02-13 11:52:57 --> Helper loaded: string_helper
INFO - 2020-02-13 11:52:57 --> Database Driver Class Initialized
INFO - 2020-02-13 11:52:57 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 11:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:52:57 --> Controller Class Initialized
INFO - 2020-02-13 11:52:57 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:52:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:52:57 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:52:57 --> Helper loaded: form_helper
INFO - 2020-02-13 11:52:57 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:52:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:52:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 11:52:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:52:58 --> Final output sent to browser
DEBUG - 2020-02-13 11:52:58 --> Total execution time: 0.7336
INFO - 2020-02-13 11:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:52:58 --> Controller Class Initialized
INFO - 2020-02-13 11:52:58 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:52:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:52:58 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:52:58 --> Helper loaded: form_helper
INFO - 2020-02-13 11:52:58 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:52:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:52:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 11:52:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:52:58 --> Final output sent to browser
DEBUG - 2020-02-13 11:52:58 --> Total execution time: 0.9756
INFO - 2020-02-13 11:53:00 --> Config Class Initialized
INFO - 2020-02-13 11:53:00 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:53:00 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:53:00 --> Utf8 Class Initialized
INFO - 2020-02-13 11:53:00 --> URI Class Initialized
INFO - 2020-02-13 11:53:00 --> Router Class Initialized
INFO - 2020-02-13 11:53:00 --> Output Class Initialized
INFO - 2020-02-13 11:53:00 --> Security Class Initialized
DEBUG - 2020-02-13 11:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:53:00 --> Input Class Initialized
INFO - 2020-02-13 11:53:00 --> Language Class Initialized
INFO - 2020-02-13 11:53:00 --> Loader Class Initialized
INFO - 2020-02-13 11:53:00 --> Helper loaded: url_helper
INFO - 2020-02-13 11:53:00 --> Helper loaded: string_helper
INFO - 2020-02-13 11:53:00 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:53:00 --> Controller Class Initialized
INFO - 2020-02-13 11:53:00 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:53:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:53:00 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:53:00 --> Helper loaded: form_helper
INFO - 2020-02-13 11:53:00 --> Form Validation Class Initialized
INFO - 2020-02-13 11:53:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 11:53:00 --> Final output sent to browser
DEBUG - 2020-02-13 11:53:00 --> Total execution time: 0.6924
INFO - 2020-02-13 11:58:55 --> Config Class Initialized
INFO - 2020-02-13 11:58:55 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:58:55 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:58:55 --> Utf8 Class Initialized
INFO - 2020-02-13 11:58:55 --> URI Class Initialized
INFO - 2020-02-13 11:58:55 --> Router Class Initialized
INFO - 2020-02-13 11:58:55 --> Output Class Initialized
INFO - 2020-02-13 11:58:55 --> Security Class Initialized
DEBUG - 2020-02-13 11:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:58:55 --> Input Class Initialized
INFO - 2020-02-13 11:58:55 --> Language Class Initialized
INFO - 2020-02-13 11:58:55 --> Loader Class Initialized
INFO - 2020-02-13 11:58:55 --> Helper loaded: url_helper
INFO - 2020-02-13 11:58:55 --> Helper loaded: string_helper
INFO - 2020-02-13 11:58:55 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:58:56 --> Controller Class Initialized
INFO - 2020-02-13 11:58:56 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:58:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:58:56 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:58:56 --> Helper loaded: form_helper
INFO - 2020-02-13 11:58:56 --> Form Validation Class Initialized
INFO - 2020-02-13 11:58:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:58:56 --> Final output sent to browser
DEBUG - 2020-02-13 11:58:56 --> Total execution time: 0.7273
INFO - 2020-02-13 11:58:56 --> Config Class Initialized
INFO - 2020-02-13 11:58:56 --> Config Class Initialized
INFO - 2020-02-13 11:58:56 --> Hooks Class Initialized
INFO - 2020-02-13 11:58:56 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:58:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 11:58:56 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:58:56 --> Utf8 Class Initialized
INFO - 2020-02-13 11:58:56 --> Utf8 Class Initialized
INFO - 2020-02-13 11:58:56 --> URI Class Initialized
INFO - 2020-02-13 11:58:56 --> URI Class Initialized
INFO - 2020-02-13 11:58:56 --> Router Class Initialized
INFO - 2020-02-13 11:58:56 --> Router Class Initialized
INFO - 2020-02-13 11:58:56 --> Output Class Initialized
INFO - 2020-02-13 11:58:56 --> Output Class Initialized
INFO - 2020-02-13 11:58:56 --> Security Class Initialized
INFO - 2020-02-13 11:58:56 --> Security Class Initialized
DEBUG - 2020-02-13 11:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 11:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:58:56 --> Input Class Initialized
INFO - 2020-02-13 11:58:56 --> Input Class Initialized
INFO - 2020-02-13 11:58:56 --> Language Class Initialized
INFO - 2020-02-13 11:58:56 --> Language Class Initialized
INFO - 2020-02-13 11:58:56 --> Loader Class Initialized
INFO - 2020-02-13 11:58:56 --> Loader Class Initialized
INFO - 2020-02-13 11:58:56 --> Helper loaded: url_helper
INFO - 2020-02-13 11:58:56 --> Helper loaded: url_helper
INFO - 2020-02-13 11:58:56 --> Helper loaded: string_helper
INFO - 2020-02-13 11:58:56 --> Helper loaded: string_helper
INFO - 2020-02-13 11:58:56 --> Database Driver Class Initialized
INFO - 2020-02-13 11:58:56 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 11:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:58:56 --> Controller Class Initialized
INFO - 2020-02-13 11:58:57 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:58:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:58:57 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:58:57 --> Helper loaded: form_helper
INFO - 2020-02-13 11:58:57 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:58:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:58:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 11:58:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:58:57 --> Final output sent to browser
DEBUG - 2020-02-13 11:58:57 --> Total execution time: 0.7838
INFO - 2020-02-13 11:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:58:57 --> Controller Class Initialized
INFO - 2020-02-13 11:58:57 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:58:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:58:57 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:58:57 --> Helper loaded: form_helper
INFO - 2020-02-13 11:58:57 --> Form Validation Class Initialized
ERROR - 2020-02-13 11:58:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 11:58:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 11:58:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 11:58:57 --> Final output sent to browser
DEBUG - 2020-02-13 11:58:57 --> Total execution time: 1.0942
INFO - 2020-02-13 11:59:04 --> Config Class Initialized
INFO - 2020-02-13 11:59:04 --> Hooks Class Initialized
DEBUG - 2020-02-13 11:59:04 --> UTF-8 Support Enabled
INFO - 2020-02-13 11:59:04 --> Utf8 Class Initialized
INFO - 2020-02-13 11:59:04 --> URI Class Initialized
INFO - 2020-02-13 11:59:04 --> Router Class Initialized
INFO - 2020-02-13 11:59:04 --> Output Class Initialized
INFO - 2020-02-13 11:59:04 --> Security Class Initialized
DEBUG - 2020-02-13 11:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 11:59:04 --> Input Class Initialized
INFO - 2020-02-13 11:59:04 --> Language Class Initialized
INFO - 2020-02-13 11:59:04 --> Loader Class Initialized
INFO - 2020-02-13 11:59:04 --> Helper loaded: url_helper
INFO - 2020-02-13 11:59:04 --> Helper loaded: string_helper
INFO - 2020-02-13 11:59:04 --> Database Driver Class Initialized
DEBUG - 2020-02-13 11:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 11:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 11:59:05 --> Controller Class Initialized
INFO - 2020-02-13 11:59:05 --> Model "M_tiket" initialized
INFO - 2020-02-13 11:59:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 11:59:05 --> Model "M_pesan" initialized
INFO - 2020-02-13 11:59:05 --> Helper loaded: form_helper
INFO - 2020-02-13 11:59:05 --> Form Validation Class Initialized
INFO - 2020-02-13 11:59:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 11:59:05 --> Final output sent to browser
DEBUG - 2020-02-13 11:59:05 --> Total execution time: 0.6791
INFO - 2020-02-13 12:02:23 --> Config Class Initialized
INFO - 2020-02-13 12:02:23 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:02:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:02:23 --> Utf8 Class Initialized
INFO - 2020-02-13 12:02:24 --> URI Class Initialized
INFO - 2020-02-13 12:02:24 --> Router Class Initialized
INFO - 2020-02-13 12:02:24 --> Output Class Initialized
INFO - 2020-02-13 12:02:24 --> Security Class Initialized
DEBUG - 2020-02-13 12:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:02:24 --> Input Class Initialized
INFO - 2020-02-13 12:02:24 --> Language Class Initialized
INFO - 2020-02-13 12:02:24 --> Loader Class Initialized
INFO - 2020-02-13 12:02:24 --> Helper loaded: url_helper
INFO - 2020-02-13 12:02:24 --> Helper loaded: string_helper
INFO - 2020-02-13 12:02:24 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:02:24 --> Controller Class Initialized
INFO - 2020-02-13 12:02:24 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:02:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:02:24 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:02:24 --> Helper loaded: form_helper
INFO - 2020-02-13 12:02:24 --> Form Validation Class Initialized
INFO - 2020-02-13 12:02:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:02:24 --> Final output sent to browser
INFO - 2020-02-13 12:02:24 --> Config Class Initialized
INFO - 2020-02-13 12:02:24 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:02:24 --> Total execution time: 0.5926
INFO - 2020-02-13 12:02:24 --> Config Class Initialized
INFO - 2020-02-13 12:02:24 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:02:24 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:02:24 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:02:24 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:02:24 --> Utf8 Class Initialized
INFO - 2020-02-13 12:02:24 --> URI Class Initialized
INFO - 2020-02-13 12:02:24 --> URI Class Initialized
INFO - 2020-02-13 12:02:24 --> Router Class Initialized
INFO - 2020-02-13 12:02:24 --> Router Class Initialized
INFO - 2020-02-13 12:02:24 --> Output Class Initialized
INFO - 2020-02-13 12:02:24 --> Security Class Initialized
INFO - 2020-02-13 12:02:24 --> Output Class Initialized
DEBUG - 2020-02-13 12:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:02:24 --> Security Class Initialized
INFO - 2020-02-13 12:02:24 --> Input Class Initialized
DEBUG - 2020-02-13 12:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:02:24 --> Input Class Initialized
INFO - 2020-02-13 12:02:24 --> Language Class Initialized
INFO - 2020-02-13 12:02:24 --> Language Class Initialized
INFO - 2020-02-13 12:02:24 --> Loader Class Initialized
INFO - 2020-02-13 12:02:25 --> Helper loaded: url_helper
INFO - 2020-02-13 12:02:25 --> Loader Class Initialized
INFO - 2020-02-13 12:02:25 --> Helper loaded: string_helper
INFO - 2020-02-13 12:02:25 --> Helper loaded: url_helper
INFO - 2020-02-13 12:02:25 --> Helper loaded: string_helper
INFO - 2020-02-13 12:02:25 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:02:25 --> Database Driver Class Initialized
INFO - 2020-02-13 12:02:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 12:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:02:25 --> Controller Class Initialized
INFO - 2020-02-13 12:02:25 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:02:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:02:25 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:02:25 --> Helper loaded: form_helper
INFO - 2020-02-13 12:02:25 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:02:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:02:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:02:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:02:25 --> Final output sent to browser
DEBUG - 2020-02-13 12:02:25 --> Total execution time: 0.7774
INFO - 2020-02-13 12:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:02:25 --> Controller Class Initialized
INFO - 2020-02-13 12:02:25 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:02:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:02:25 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:02:25 --> Helper loaded: form_helper
INFO - 2020-02-13 12:02:25 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:02:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:02:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:02:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:02:25 --> Final output sent to browser
DEBUG - 2020-02-13 12:02:25 --> Total execution time: 1.0198
INFO - 2020-02-13 12:02:58 --> Config Class Initialized
INFO - 2020-02-13 12:02:58 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:02:58 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:02:58 --> Utf8 Class Initialized
INFO - 2020-02-13 12:02:58 --> URI Class Initialized
INFO - 2020-02-13 12:02:58 --> Router Class Initialized
INFO - 2020-02-13 12:02:58 --> Output Class Initialized
INFO - 2020-02-13 12:02:58 --> Security Class Initialized
DEBUG - 2020-02-13 12:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:02:58 --> Input Class Initialized
INFO - 2020-02-13 12:02:58 --> Language Class Initialized
INFO - 2020-02-13 12:02:58 --> Loader Class Initialized
INFO - 2020-02-13 12:02:58 --> Helper loaded: url_helper
INFO - 2020-02-13 12:02:58 --> Helper loaded: string_helper
INFO - 2020-02-13 12:02:58 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:02:58 --> Controller Class Initialized
INFO - 2020-02-13 12:02:58 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:02:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:02:58 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:02:58 --> Helper loaded: form_helper
INFO - 2020-02-13 12:02:58 --> Form Validation Class Initialized
INFO - 2020-02-13 12:02:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 12:02:58 --> Final output sent to browser
DEBUG - 2020-02-13 12:02:58 --> Total execution time: 0.7880
INFO - 2020-02-13 12:03:16 --> Config Class Initialized
INFO - 2020-02-13 12:03:16 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:03:16 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:03:16 --> Utf8 Class Initialized
INFO - 2020-02-13 12:03:16 --> URI Class Initialized
INFO - 2020-02-13 12:03:17 --> Router Class Initialized
INFO - 2020-02-13 12:03:17 --> Output Class Initialized
INFO - 2020-02-13 12:03:17 --> Security Class Initialized
DEBUG - 2020-02-13 12:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:03:17 --> Input Class Initialized
INFO - 2020-02-13 12:03:17 --> Language Class Initialized
INFO - 2020-02-13 12:03:17 --> Loader Class Initialized
INFO - 2020-02-13 12:03:17 --> Helper loaded: url_helper
INFO - 2020-02-13 12:03:17 --> Helper loaded: string_helper
INFO - 2020-02-13 12:03:17 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:03:17 --> Controller Class Initialized
INFO - 2020-02-13 12:03:17 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:03:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:03:17 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:03:17 --> Helper loaded: form_helper
INFO - 2020-02-13 12:03:17 --> Form Validation Class Initialized
INFO - 2020-02-13 12:03:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:03:17 --> Final output sent to browser
INFO - 2020-02-13 12:03:17 --> Config Class Initialized
INFO - 2020-02-13 12:03:17 --> Config Class Initialized
INFO - 2020-02-13 12:03:17 --> Hooks Class Initialized
INFO - 2020-02-13 12:03:17 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:03:17 --> Total execution time: 0.6253
DEBUG - 2020-02-13 12:03:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:03:17 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:03:17 --> Utf8 Class Initialized
INFO - 2020-02-13 12:03:17 --> Utf8 Class Initialized
INFO - 2020-02-13 12:03:17 --> URI Class Initialized
INFO - 2020-02-13 12:03:17 --> URI Class Initialized
INFO - 2020-02-13 12:03:17 --> Router Class Initialized
INFO - 2020-02-13 12:03:17 --> Router Class Initialized
INFO - 2020-02-13 12:03:17 --> Output Class Initialized
INFO - 2020-02-13 12:03:17 --> Output Class Initialized
INFO - 2020-02-13 12:03:17 --> Security Class Initialized
INFO - 2020-02-13 12:03:17 --> Security Class Initialized
DEBUG - 2020-02-13 12:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:03:17 --> Input Class Initialized
INFO - 2020-02-13 12:03:17 --> Input Class Initialized
INFO - 2020-02-13 12:03:17 --> Language Class Initialized
INFO - 2020-02-13 12:03:17 --> Language Class Initialized
INFO - 2020-02-13 12:03:17 --> Loader Class Initialized
INFO - 2020-02-13 12:03:17 --> Loader Class Initialized
INFO - 2020-02-13 12:03:17 --> Helper loaded: url_helper
INFO - 2020-02-13 12:03:17 --> Helper loaded: url_helper
INFO - 2020-02-13 12:03:18 --> Helper loaded: string_helper
INFO - 2020-02-13 12:03:18 --> Helper loaded: string_helper
INFO - 2020-02-13 12:03:18 --> Database Driver Class Initialized
INFO - 2020-02-13 12:03:18 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 12:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:03:18 --> Controller Class Initialized
INFO - 2020-02-13 12:03:18 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:03:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:03:18 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:03:18 --> Helper loaded: form_helper
INFO - 2020-02-13 12:03:18 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:03:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:03:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:03:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:03:18 --> Final output sent to browser
DEBUG - 2020-02-13 12:03:18 --> Total execution time: 0.7438
INFO - 2020-02-13 12:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:03:18 --> Controller Class Initialized
INFO - 2020-02-13 12:03:18 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:03:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:03:18 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:03:18 --> Helper loaded: form_helper
INFO - 2020-02-13 12:03:18 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:03:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:03:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:03:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:03:18 --> Final output sent to browser
DEBUG - 2020-02-13 12:03:18 --> Total execution time: 1.0644
INFO - 2020-02-13 12:03:21 --> Config Class Initialized
INFO - 2020-02-13 12:03:21 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:03:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:03:21 --> Utf8 Class Initialized
INFO - 2020-02-13 12:03:21 --> URI Class Initialized
INFO - 2020-02-13 12:03:21 --> Router Class Initialized
INFO - 2020-02-13 12:03:21 --> Output Class Initialized
INFO - 2020-02-13 12:03:21 --> Security Class Initialized
DEBUG - 2020-02-13 12:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:03:21 --> Input Class Initialized
INFO - 2020-02-13 12:03:21 --> Language Class Initialized
INFO - 2020-02-13 12:03:21 --> Loader Class Initialized
INFO - 2020-02-13 12:03:21 --> Helper loaded: url_helper
INFO - 2020-02-13 12:03:21 --> Helper loaded: string_helper
INFO - 2020-02-13 12:03:21 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:03:21 --> Controller Class Initialized
INFO - 2020-02-13 12:03:21 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:03:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:03:21 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:03:21 --> Helper loaded: form_helper
INFO - 2020-02-13 12:03:21 --> Form Validation Class Initialized
INFO - 2020-02-13 12:03:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 12:03:22 --> Final output sent to browser
DEBUG - 2020-02-13 12:03:22 --> Total execution time: 0.7680
INFO - 2020-02-13 12:04:35 --> Config Class Initialized
INFO - 2020-02-13 12:04:35 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:04:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:35 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:35 --> URI Class Initialized
DEBUG - 2020-02-13 12:04:35 --> No URI present. Default controller set.
INFO - 2020-02-13 12:04:35 --> Router Class Initialized
INFO - 2020-02-13 12:04:35 --> Output Class Initialized
INFO - 2020-02-13 12:04:35 --> Security Class Initialized
DEBUG - 2020-02-13 12:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:36 --> Input Class Initialized
INFO - 2020-02-13 12:04:36 --> Language Class Initialized
INFO - 2020-02-13 12:04:36 --> Loader Class Initialized
INFO - 2020-02-13 12:04:36 --> Helper loaded: url_helper
INFO - 2020-02-13 12:04:36 --> Helper loaded: string_helper
INFO - 2020-02-13 12:04:36 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:04:36 --> Controller Class Initialized
INFO - 2020-02-13 12:04:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 12:04:36 --> Pagination Class Initialized
INFO - 2020-02-13 12:04:36 --> Model "M_show" initialized
INFO - 2020-02-13 12:04:36 --> Helper loaded: form_helper
INFO - 2020-02-13 12:04:36 --> Form Validation Class Initialized
INFO - 2020-02-13 12:04:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 12:04:36 --> Final output sent to browser
INFO - 2020-02-13 12:04:36 --> Config Class Initialized
INFO - 2020-02-13 12:04:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:04:36 --> Total execution time: 0.7261
DEBUG - 2020-02-13 12:04:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:36 --> URI Class Initialized
DEBUG - 2020-02-13 12:04:36 --> No URI present. Default controller set.
INFO - 2020-02-13 12:04:36 --> Router Class Initialized
INFO - 2020-02-13 12:04:36 --> Output Class Initialized
INFO - 2020-02-13 12:04:36 --> Security Class Initialized
DEBUG - 2020-02-13 12:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:36 --> Input Class Initialized
INFO - 2020-02-13 12:04:36 --> Language Class Initialized
INFO - 2020-02-13 12:04:36 --> Loader Class Initialized
INFO - 2020-02-13 12:04:36 --> Helper loaded: url_helper
INFO - 2020-02-13 12:04:36 --> Helper loaded: string_helper
INFO - 2020-02-13 12:04:36 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:04:36 --> Controller Class Initialized
INFO - 2020-02-13 12:04:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 12:04:37 --> Pagination Class Initialized
INFO - 2020-02-13 12:04:37 --> Model "M_show" initialized
INFO - 2020-02-13 12:04:37 --> Helper loaded: form_helper
INFO - 2020-02-13 12:04:37 --> Form Validation Class Initialized
INFO - 2020-02-13 12:04:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 12:04:37 --> Final output sent to browser
DEBUG - 2020-02-13 12:04:37 --> Total execution time: 0.7028
INFO - 2020-02-13 12:04:42 --> Config Class Initialized
INFO - 2020-02-13 12:04:42 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:04:42 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:42 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:42 --> URI Class Initialized
INFO - 2020-02-13 12:04:42 --> Router Class Initialized
INFO - 2020-02-13 12:04:42 --> Output Class Initialized
INFO - 2020-02-13 12:04:42 --> Security Class Initialized
DEBUG - 2020-02-13 12:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:42 --> Input Class Initialized
INFO - 2020-02-13 12:04:42 --> Language Class Initialized
INFO - 2020-02-13 12:04:42 --> Loader Class Initialized
INFO - 2020-02-13 12:04:42 --> Helper loaded: url_helper
INFO - 2020-02-13 12:04:42 --> Helper loaded: string_helper
INFO - 2020-02-13 12:04:42 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:04:42 --> Controller Class Initialized
INFO - 2020-02-13 12:04:42 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:04:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:04:42 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:04:42 --> Helper loaded: form_helper
INFO - 2020-02-13 12:04:42 --> Form Validation Class Initialized
INFO - 2020-02-13 12:04:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:04:42 --> Final output sent to browser
INFO - 2020-02-13 12:04:42 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:04:43 --> Total execution time: 0.6868
INFO - 2020-02-13 12:04:43 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:43 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
INFO - 2020-02-13 12:04:43 --> Loader Class Initialized
ERROR - 2020-02-13 12:04:43 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 12:04:43 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 12:04:43 --> Helper loaded: url_helper
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
ERROR - 2020-02-13 12:04:43 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 12:04:43 --> Loader Class Initialized
INFO - 2020-02-13 12:04:43 --> Helper loaded: string_helper
INFO - 2020-02-13 12:04:43 --> Helper loaded: url_helper
ERROR - 2020-02-13 12:04:43 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 12:04:43 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
INFO - 2020-02-13 12:04:43 --> Helper loaded: string_helper
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:43 --> Database Driver Class Initialized
INFO - 2020-02-13 12:04:43 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:04:43 --> Database Driver Class Initialized
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:43 --> Controller Class Initialized
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
INFO - 2020-02-13 12:04:43 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:43 --> Helper loaded: form_helper
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
INFO - 2020-02-13 12:04:43 --> Form Validation Class Initialized
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
ERROR - 2020-02-13 12:04:43 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
ERROR - 2020-02-13 12:04:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:04:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 12:04:43 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 12:04:43 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-13 12:04:43 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 12:04:43 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
INFO - 2020-02-13 12:04:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:04:43 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Config Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
INFO - 2020-02-13 12:04:43 --> Hooks Class Initialized
INFO - 2020-02-13 12:04:43 --> Final output sent to browser
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:04:43 --> Total execution time: 0.7588
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:04:43 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:43 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
INFO - 2020-02-13 12:04:43 --> Controller Class Initialized
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
INFO - 2020-02-13 12:04:43 --> URI Class Initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> Router Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
INFO - 2020-02-13 12:04:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
INFO - 2020-02-13 12:04:43 --> Output Class Initialized
INFO - 2020-02-13 12:04:43 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:43 --> Security Class Initialized
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:43 --> Helper loaded: form_helper
INFO - 2020-02-13 12:04:43 --> Form Validation Class Initialized
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
INFO - 2020-02-13 12:04:43 --> Input Class Initialized
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
INFO - 2020-02-13 12:04:43 --> Language Class Initialized
ERROR - 2020-02-13 12:04:43 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 12:04:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:04:44 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 12:04:44 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 12:04:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 12:04:44 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 12:04:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:04:44 --> Config Class Initialized
INFO - 2020-02-13 12:04:44 --> Hooks Class Initialized
INFO - 2020-02-13 12:04:44 --> Final output sent to browser
DEBUG - 2020-02-13 12:04:44 --> Total execution time: 1.0945
DEBUG - 2020-02-13 12:04:44 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:44 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:44 --> URI Class Initialized
INFO - 2020-02-13 12:04:44 --> Router Class Initialized
INFO - 2020-02-13 12:04:44 --> Output Class Initialized
INFO - 2020-02-13 12:04:44 --> Security Class Initialized
DEBUG - 2020-02-13 12:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:44 --> Input Class Initialized
INFO - 2020-02-13 12:04:44 --> Language Class Initialized
ERROR - 2020-02-13 12:04:44 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 12:04:44 --> Config Class Initialized
INFO - 2020-02-13 12:04:44 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:04:44 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:44 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:44 --> URI Class Initialized
INFO - 2020-02-13 12:04:44 --> Router Class Initialized
INFO - 2020-02-13 12:04:44 --> Output Class Initialized
INFO - 2020-02-13 12:04:44 --> Security Class Initialized
DEBUG - 2020-02-13 12:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:44 --> Input Class Initialized
INFO - 2020-02-13 12:04:44 --> Language Class Initialized
ERROR - 2020-02-13 12:04:44 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 12:04:44 --> Config Class Initialized
INFO - 2020-02-13 12:04:44 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:04:44 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:44 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:44 --> URI Class Initialized
INFO - 2020-02-13 12:04:44 --> Router Class Initialized
INFO - 2020-02-13 12:04:44 --> Output Class Initialized
INFO - 2020-02-13 12:04:44 --> Security Class Initialized
DEBUG - 2020-02-13 12:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:44 --> Input Class Initialized
INFO - 2020-02-13 12:04:45 --> Language Class Initialized
ERROR - 2020-02-13 12:04:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:04:45 --> Config Class Initialized
INFO - 2020-02-13 12:04:45 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:04:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:45 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:45 --> URI Class Initialized
INFO - 2020-02-13 12:04:45 --> Router Class Initialized
INFO - 2020-02-13 12:04:45 --> Output Class Initialized
INFO - 2020-02-13 12:04:45 --> Security Class Initialized
DEBUG - 2020-02-13 12:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:45 --> Input Class Initialized
INFO - 2020-02-13 12:04:45 --> Language Class Initialized
ERROR - 2020-02-13 12:04:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:04:45 --> Config Class Initialized
INFO - 2020-02-13 12:04:45 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:04:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:45 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:45 --> URI Class Initialized
INFO - 2020-02-13 12:04:45 --> Router Class Initialized
INFO - 2020-02-13 12:04:45 --> Output Class Initialized
INFO - 2020-02-13 12:04:45 --> Security Class Initialized
DEBUG - 2020-02-13 12:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:45 --> Input Class Initialized
INFO - 2020-02-13 12:04:45 --> Language Class Initialized
ERROR - 2020-02-13 12:04:45 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 12:04:45 --> Config Class Initialized
INFO - 2020-02-13 12:04:45 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:04:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:45 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:45 --> URI Class Initialized
INFO - 2020-02-13 12:04:45 --> Router Class Initialized
INFO - 2020-02-13 12:04:45 --> Output Class Initialized
INFO - 2020-02-13 12:04:45 --> Security Class Initialized
DEBUG - 2020-02-13 12:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:45 --> Input Class Initialized
INFO - 2020-02-13 12:04:45 --> Language Class Initialized
ERROR - 2020-02-13 12:04:46 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 12:04:46 --> Config Class Initialized
INFO - 2020-02-13 12:04:46 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:04:46 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:46 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:46 --> URI Class Initialized
INFO - 2020-02-13 12:04:46 --> Router Class Initialized
INFO - 2020-02-13 12:04:46 --> Output Class Initialized
INFO - 2020-02-13 12:04:46 --> Security Class Initialized
DEBUG - 2020-02-13 12:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:46 --> Input Class Initialized
INFO - 2020-02-13 12:04:46 --> Language Class Initialized
ERROR - 2020-02-13 12:04:46 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 12:04:46 --> Config Class Initialized
INFO - 2020-02-13 12:04:46 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:04:46 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:04:46 --> Utf8 Class Initialized
INFO - 2020-02-13 12:04:46 --> URI Class Initialized
INFO - 2020-02-13 12:04:46 --> Router Class Initialized
INFO - 2020-02-13 12:04:46 --> Output Class Initialized
INFO - 2020-02-13 12:04:46 --> Security Class Initialized
DEBUG - 2020-02-13 12:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:04:46 --> Input Class Initialized
INFO - 2020-02-13 12:04:46 --> Language Class Initialized
ERROR - 2020-02-13 12:04:46 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 12:05:12 --> Config Class Initialized
INFO - 2020-02-13 12:05:12 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:05:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:05:12 --> Utf8 Class Initialized
INFO - 2020-02-13 12:05:12 --> URI Class Initialized
INFO - 2020-02-13 12:05:12 --> Router Class Initialized
INFO - 2020-02-13 12:05:12 --> Output Class Initialized
INFO - 2020-02-13 12:05:12 --> Security Class Initialized
DEBUG - 2020-02-13 12:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:05:12 --> Input Class Initialized
INFO - 2020-02-13 12:05:12 --> Language Class Initialized
INFO - 2020-02-13 12:05:12 --> Loader Class Initialized
INFO - 2020-02-13 12:05:12 --> Helper loaded: url_helper
INFO - 2020-02-13 12:05:12 --> Helper loaded: string_helper
INFO - 2020-02-13 12:05:12 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:05:12 --> Controller Class Initialized
INFO - 2020-02-13 12:05:12 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:05:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:05:12 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:05:12 --> Helper loaded: form_helper
INFO - 2020-02-13 12:05:12 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 66
ERROR - 2020-02-13 12:05:12 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('34', 120910, '1', '1', NULL)
INFO - 2020-02-13 12:05:12 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 12:07:38 --> Config Class Initialized
INFO - 2020-02-13 12:07:38 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:07:38 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:07:38 --> Utf8 Class Initialized
INFO - 2020-02-13 12:07:38 --> URI Class Initialized
INFO - 2020-02-13 12:07:38 --> Router Class Initialized
INFO - 2020-02-13 12:07:38 --> Output Class Initialized
INFO - 2020-02-13 12:07:38 --> Security Class Initialized
DEBUG - 2020-02-13 12:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:07:38 --> Input Class Initialized
INFO - 2020-02-13 12:07:39 --> Language Class Initialized
INFO - 2020-02-13 12:07:39 --> Loader Class Initialized
INFO - 2020-02-13 12:07:39 --> Helper loaded: url_helper
INFO - 2020-02-13 12:07:39 --> Helper loaded: string_helper
INFO - 2020-02-13 12:07:39 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:07:39 --> Controller Class Initialized
INFO - 2020-02-13 12:07:39 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:07:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:07:39 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:07:39 --> Helper loaded: form_helper
INFO - 2020-02-13 12:07:39 --> Form Validation Class Initialized
INFO - 2020-02-13 12:07:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:07:39 --> Final output sent to browser
INFO - 2020-02-13 12:07:39 --> Config Class Initialized
INFO - 2020-02-13 12:07:39 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:07:39 --> Total execution time: 0.6476
DEBUG - 2020-02-13 12:07:39 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:07:39 --> Utf8 Class Initialized
INFO - 2020-02-13 12:07:39 --> URI Class Initialized
INFO - 2020-02-13 12:07:39 --> Router Class Initialized
INFO - 2020-02-13 12:07:39 --> Output Class Initialized
INFO - 2020-02-13 12:07:39 --> Security Class Initialized
DEBUG - 2020-02-13 12:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:07:39 --> Input Class Initialized
INFO - 2020-02-13 12:07:39 --> Language Class Initialized
ERROR - 2020-02-13 12:07:39 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 12:07:44 --> Config Class Initialized
INFO - 2020-02-13 12:07:44 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:07:44 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:07:44 --> Utf8 Class Initialized
INFO - 2020-02-13 12:07:44 --> URI Class Initialized
INFO - 2020-02-13 12:07:44 --> Router Class Initialized
INFO - 2020-02-13 12:07:44 --> Output Class Initialized
INFO - 2020-02-13 12:07:44 --> Security Class Initialized
DEBUG - 2020-02-13 12:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:07:44 --> Input Class Initialized
INFO - 2020-02-13 12:07:44 --> Language Class Initialized
INFO - 2020-02-13 12:07:44 --> Loader Class Initialized
INFO - 2020-02-13 12:07:45 --> Helper loaded: url_helper
INFO - 2020-02-13 12:07:45 --> Helper loaded: string_helper
INFO - 2020-02-13 12:07:45 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:07:45 --> Controller Class Initialized
INFO - 2020-02-13 12:07:45 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:07:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:07:45 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:07:45 --> Helper loaded: form_helper
INFO - 2020-02-13 12:07:45 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 62
ERROR - 2020-02-13 12:07:45 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('34', 240685, '1', '2', NULL)
INFO - 2020-02-13 12:07:45 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 12:08:18 --> Config Class Initialized
INFO - 2020-02-13 12:08:18 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:08:18 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:08:18 --> Utf8 Class Initialized
INFO - 2020-02-13 12:08:18 --> URI Class Initialized
INFO - 2020-02-13 12:08:18 --> Router Class Initialized
INFO - 2020-02-13 12:08:18 --> Output Class Initialized
INFO - 2020-02-13 12:08:18 --> Security Class Initialized
DEBUG - 2020-02-13 12:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:08:19 --> Input Class Initialized
INFO - 2020-02-13 12:08:19 --> Language Class Initialized
INFO - 2020-02-13 12:08:19 --> Loader Class Initialized
INFO - 2020-02-13 12:08:19 --> Helper loaded: url_helper
INFO - 2020-02-13 12:08:19 --> Helper loaded: string_helper
INFO - 2020-02-13 12:08:19 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:08:19 --> Controller Class Initialized
INFO - 2020-02-13 12:08:19 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:08:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:08:19 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:08:19 --> Helper loaded: form_helper
INFO - 2020-02-13 12:08:19 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:08:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 60
ERROR - 2020-02-13 12:08:19 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('34', 240413, '1', '2', NULL)
INFO - 2020-02-13 12:08:19 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 12:13:25 --> Config Class Initialized
INFO - 2020-02-13 12:13:25 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:13:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:13:25 --> Utf8 Class Initialized
INFO - 2020-02-13 12:13:25 --> URI Class Initialized
INFO - 2020-02-13 12:13:25 --> Router Class Initialized
INFO - 2020-02-13 12:13:25 --> Output Class Initialized
INFO - 2020-02-13 12:13:25 --> Security Class Initialized
DEBUG - 2020-02-13 12:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:13:25 --> Input Class Initialized
INFO - 2020-02-13 12:13:25 --> Language Class Initialized
INFO - 2020-02-13 12:13:25 --> Loader Class Initialized
INFO - 2020-02-13 12:13:25 --> Helper loaded: url_helper
INFO - 2020-02-13 12:13:25 --> Helper loaded: string_helper
INFO - 2020-02-13 12:13:25 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:13:25 --> Controller Class Initialized
INFO - 2020-02-13 12:13:25 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:13:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:13:25 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:13:25 --> Helper loaded: form_helper
INFO - 2020-02-13 12:13:26 --> Form Validation Class Initialized
INFO - 2020-02-13 12:13:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:13:26 --> Final output sent to browser
INFO - 2020-02-13 12:13:26 --> Config Class Initialized
INFO - 2020-02-13 12:13:26 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:13:26 --> Total execution time: 0.6482
INFO - 2020-02-13 12:13:26 --> Config Class Initialized
INFO - 2020-02-13 12:13:26 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:13:26 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:13:26 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:13:26 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:13:26 --> Utf8 Class Initialized
INFO - 2020-02-13 12:13:26 --> URI Class Initialized
INFO - 2020-02-13 12:13:26 --> URI Class Initialized
INFO - 2020-02-13 12:13:26 --> Router Class Initialized
INFO - 2020-02-13 12:13:26 --> Router Class Initialized
INFO - 2020-02-13 12:13:26 --> Output Class Initialized
INFO - 2020-02-13 12:13:26 --> Security Class Initialized
INFO - 2020-02-13 12:13:26 --> Output Class Initialized
INFO - 2020-02-13 12:13:26 --> Security Class Initialized
DEBUG - 2020-02-13 12:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:13:26 --> Input Class Initialized
DEBUG - 2020-02-13 12:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:13:26 --> Input Class Initialized
INFO - 2020-02-13 12:13:26 --> Language Class Initialized
INFO - 2020-02-13 12:13:26 --> Language Class Initialized
INFO - 2020-02-13 12:13:26 --> Loader Class Initialized
INFO - 2020-02-13 12:13:26 --> Helper loaded: url_helper
INFO - 2020-02-13 12:13:26 --> Loader Class Initialized
INFO - 2020-02-13 12:13:26 --> Helper loaded: string_helper
INFO - 2020-02-13 12:13:26 --> Helper loaded: url_helper
INFO - 2020-02-13 12:13:26 --> Helper loaded: string_helper
INFO - 2020-02-13 12:13:26 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:13:26 --> Database Driver Class Initialized
INFO - 2020-02-13 12:13:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 12:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:13:26 --> Controller Class Initialized
INFO - 2020-02-13 12:13:26 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:13:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:13:26 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:13:26 --> Helper loaded: form_helper
INFO - 2020-02-13 12:13:26 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:13:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:13:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:13:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:13:26 --> Final output sent to browser
DEBUG - 2020-02-13 12:13:26 --> Total execution time: 0.7951
INFO - 2020-02-13 12:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:13:26 --> Controller Class Initialized
INFO - 2020-02-13 12:13:27 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:13:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:13:27 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:13:27 --> Helper loaded: form_helper
INFO - 2020-02-13 12:13:27 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:13:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:13:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:13:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:13:27 --> Final output sent to browser
DEBUG - 2020-02-13 12:13:27 --> Total execution time: 1.0281
INFO - 2020-02-13 12:15:33 --> Config Class Initialized
INFO - 2020-02-13 12:15:33 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:15:33 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:15:33 --> Utf8 Class Initialized
INFO - 2020-02-13 12:15:33 --> URI Class Initialized
INFO - 2020-02-13 12:15:33 --> Router Class Initialized
INFO - 2020-02-13 12:15:33 --> Output Class Initialized
INFO - 2020-02-13 12:15:33 --> Security Class Initialized
DEBUG - 2020-02-13 12:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:15:34 --> Input Class Initialized
INFO - 2020-02-13 12:15:34 --> Language Class Initialized
INFO - 2020-02-13 12:15:34 --> Loader Class Initialized
INFO - 2020-02-13 12:15:34 --> Helper loaded: url_helper
INFO - 2020-02-13 12:15:34 --> Helper loaded: string_helper
INFO - 2020-02-13 12:15:34 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:15:34 --> Controller Class Initialized
INFO - 2020-02-13 12:15:34 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:15:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:15:34 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:15:34 --> Helper loaded: form_helper
INFO - 2020-02-13 12:15:34 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:15:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 60
ERROR - 2020-02-13 12:15:34 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('34', 240726, '1', '2', NULL)
INFO - 2020-02-13 12:15:34 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 12:17:51 --> Config Class Initialized
INFO - 2020-02-13 12:17:51 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:17:51 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:17:51 --> Utf8 Class Initialized
INFO - 2020-02-13 12:17:51 --> URI Class Initialized
INFO - 2020-02-13 12:17:51 --> Router Class Initialized
INFO - 2020-02-13 12:17:51 --> Output Class Initialized
INFO - 2020-02-13 12:17:51 --> Security Class Initialized
DEBUG - 2020-02-13 12:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:17:51 --> Input Class Initialized
INFO - 2020-02-13 12:17:51 --> Language Class Initialized
INFO - 2020-02-13 12:17:51 --> Loader Class Initialized
INFO - 2020-02-13 12:17:51 --> Helper loaded: url_helper
INFO - 2020-02-13 12:17:51 --> Helper loaded: string_helper
INFO - 2020-02-13 12:17:51 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:17:51 --> Controller Class Initialized
INFO - 2020-02-13 12:17:51 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:17:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:17:51 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:17:51 --> Helper loaded: form_helper
INFO - 2020-02-13 12:17:51 --> Form Validation Class Initialized
INFO - 2020-02-13 12:17:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:17:51 --> Final output sent to browser
INFO - 2020-02-13 12:17:51 --> Config Class Initialized
INFO - 2020-02-13 12:17:51 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:17:51 --> Total execution time: 0.6507
INFO - 2020-02-13 12:17:51 --> Config Class Initialized
INFO - 2020-02-13 12:17:51 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:17:52 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:17:52 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:17:52 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:17:52 --> Utf8 Class Initialized
INFO - 2020-02-13 12:17:52 --> URI Class Initialized
INFO - 2020-02-13 12:17:52 --> Router Class Initialized
INFO - 2020-02-13 12:17:52 --> URI Class Initialized
INFO - 2020-02-13 12:17:52 --> Router Class Initialized
INFO - 2020-02-13 12:17:52 --> Output Class Initialized
INFO - 2020-02-13 12:17:52 --> Security Class Initialized
INFO - 2020-02-13 12:17:52 --> Output Class Initialized
INFO - 2020-02-13 12:17:52 --> Security Class Initialized
DEBUG - 2020-02-13 12:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:17:52 --> Input Class Initialized
DEBUG - 2020-02-13 12:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:17:52 --> Input Class Initialized
INFO - 2020-02-13 12:17:52 --> Language Class Initialized
INFO - 2020-02-13 12:17:52 --> Language Class Initialized
INFO - 2020-02-13 12:17:52 --> Loader Class Initialized
INFO - 2020-02-13 12:17:52 --> Helper loaded: url_helper
INFO - 2020-02-13 12:17:52 --> Loader Class Initialized
INFO - 2020-02-13 12:17:52 --> Helper loaded: string_helper
INFO - 2020-02-13 12:17:52 --> Helper loaded: url_helper
INFO - 2020-02-13 12:17:52 --> Helper loaded: string_helper
INFO - 2020-02-13 12:17:52 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:17:52 --> Database Driver Class Initialized
INFO - 2020-02-13 12:17:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 12:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:17:52 --> Controller Class Initialized
INFO - 2020-02-13 12:17:52 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:17:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:17:52 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:17:52 --> Helper loaded: form_helper
INFO - 2020-02-13 12:17:52 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:17:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:17:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:17:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:17:52 --> Final output sent to browser
DEBUG - 2020-02-13 12:17:52 --> Total execution time: 0.7633
INFO - 2020-02-13 12:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:17:52 --> Controller Class Initialized
INFO - 2020-02-13 12:17:52 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:17:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:17:52 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:17:52 --> Helper loaded: form_helper
INFO - 2020-02-13 12:17:52 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:17:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:17:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:17:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:17:52 --> Final output sent to browser
DEBUG - 2020-02-13 12:17:52 --> Total execution time: 1.0032
INFO - 2020-02-13 12:17:55 --> Config Class Initialized
INFO - 2020-02-13 12:17:55 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:17:55 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:17:55 --> Utf8 Class Initialized
INFO - 2020-02-13 12:17:55 --> URI Class Initialized
INFO - 2020-02-13 12:17:55 --> Router Class Initialized
INFO - 2020-02-13 12:17:55 --> Output Class Initialized
INFO - 2020-02-13 12:17:55 --> Security Class Initialized
DEBUG - 2020-02-13 12:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:17:55 --> Input Class Initialized
INFO - 2020-02-13 12:17:55 --> Language Class Initialized
INFO - 2020-02-13 12:17:55 --> Loader Class Initialized
INFO - 2020-02-13 12:17:55 --> Helper loaded: url_helper
INFO - 2020-02-13 12:17:55 --> Helper loaded: string_helper
INFO - 2020-02-13 12:17:55 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:17:55 --> Controller Class Initialized
INFO - 2020-02-13 12:17:55 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:17:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:17:55 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:17:55 --> Helper loaded: form_helper
INFO - 2020-02-13 12:17:55 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:17:55 --> Severity: Notice --> Undefined variable: idpesan C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
ERROR - 2020-02-13 12:17:55 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
INFO - 2020-02-13 12:18:02 --> Config Class Initialized
INFO - 2020-02-13 12:18:02 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:18:02 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:18:02 --> Utf8 Class Initialized
INFO - 2020-02-13 12:18:02 --> URI Class Initialized
INFO - 2020-02-13 12:18:02 --> Router Class Initialized
INFO - 2020-02-13 12:18:03 --> Output Class Initialized
INFO - 2020-02-13 12:18:03 --> Security Class Initialized
DEBUG - 2020-02-13 12:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:18:03 --> Input Class Initialized
INFO - 2020-02-13 12:18:03 --> Language Class Initialized
INFO - 2020-02-13 12:18:03 --> Loader Class Initialized
INFO - 2020-02-13 12:18:03 --> Helper loaded: url_helper
INFO - 2020-02-13 12:18:03 --> Helper loaded: string_helper
INFO - 2020-02-13 12:18:03 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:18:03 --> Controller Class Initialized
INFO - 2020-02-13 12:18:03 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:18:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:18:03 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:18:03 --> Helper loaded: form_helper
INFO - 2020-02-13 12:18:03 --> Form Validation Class Initialized
INFO - 2020-02-13 12:18:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:18:03 --> Final output sent to browser
INFO - 2020-02-13 12:18:03 --> Config Class Initialized
INFO - 2020-02-13 12:18:03 --> Config Class Initialized
INFO - 2020-02-13 12:18:03 --> Hooks Class Initialized
INFO - 2020-02-13 12:18:03 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:18:03 --> Total execution time: 0.6683
DEBUG - 2020-02-13 12:18:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:18:03 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:18:03 --> Utf8 Class Initialized
INFO - 2020-02-13 12:18:03 --> Utf8 Class Initialized
INFO - 2020-02-13 12:18:03 --> URI Class Initialized
INFO - 2020-02-13 12:18:03 --> URI Class Initialized
INFO - 2020-02-13 12:18:03 --> Router Class Initialized
INFO - 2020-02-13 12:18:03 --> Output Class Initialized
INFO - 2020-02-13 12:18:03 --> Router Class Initialized
INFO - 2020-02-13 12:18:03 --> Security Class Initialized
INFO - 2020-02-13 12:18:03 --> Output Class Initialized
DEBUG - 2020-02-13 12:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:18:03 --> Security Class Initialized
INFO - 2020-02-13 12:18:03 --> Input Class Initialized
DEBUG - 2020-02-13 12:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:18:03 --> Input Class Initialized
INFO - 2020-02-13 12:18:03 --> Language Class Initialized
INFO - 2020-02-13 12:18:04 --> Language Class Initialized
INFO - 2020-02-13 12:18:04 --> Loader Class Initialized
INFO - 2020-02-13 12:18:04 --> Helper loaded: url_helper
INFO - 2020-02-13 12:18:04 --> Loader Class Initialized
INFO - 2020-02-13 12:18:04 --> Helper loaded: string_helper
INFO - 2020-02-13 12:18:04 --> Helper loaded: url_helper
INFO - 2020-02-13 12:18:04 --> Helper loaded: string_helper
INFO - 2020-02-13 12:18:04 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:18:04 --> Database Driver Class Initialized
INFO - 2020-02-13 12:18:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 12:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:18:04 --> Controller Class Initialized
INFO - 2020-02-13 12:18:04 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:18:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:18:04 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:18:04 --> Helper loaded: form_helper
INFO - 2020-02-13 12:18:04 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:18:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:18:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:18:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:18:04 --> Final output sent to browser
DEBUG - 2020-02-13 12:18:04 --> Total execution time: 0.8095
INFO - 2020-02-13 12:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:18:04 --> Controller Class Initialized
INFO - 2020-02-13 12:18:04 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:18:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:18:04 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:18:04 --> Helper loaded: form_helper
INFO - 2020-02-13 12:18:04 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:18:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:18:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:18:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:18:04 --> Final output sent to browser
DEBUG - 2020-02-13 12:18:04 --> Total execution time: 1.1485
INFO - 2020-02-13 12:18:25 --> Config Class Initialized
INFO - 2020-02-13 12:18:25 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:18:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:18:25 --> Utf8 Class Initialized
INFO - 2020-02-13 12:18:25 --> URI Class Initialized
DEBUG - 2020-02-13 12:18:25 --> No URI present. Default controller set.
INFO - 2020-02-13 12:18:25 --> Router Class Initialized
INFO - 2020-02-13 12:18:25 --> Output Class Initialized
INFO - 2020-02-13 12:18:25 --> Security Class Initialized
DEBUG - 2020-02-13 12:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:18:25 --> Input Class Initialized
INFO - 2020-02-13 12:18:25 --> Language Class Initialized
INFO - 2020-02-13 12:18:25 --> Loader Class Initialized
INFO - 2020-02-13 12:18:25 --> Helper loaded: url_helper
INFO - 2020-02-13 12:18:25 --> Helper loaded: string_helper
INFO - 2020-02-13 12:18:25 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:18:25 --> Controller Class Initialized
INFO - 2020-02-13 12:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 12:18:25 --> Pagination Class Initialized
INFO - 2020-02-13 12:18:25 --> Model "M_show" initialized
INFO - 2020-02-13 12:18:25 --> Helper loaded: form_helper
INFO - 2020-02-13 12:18:25 --> Form Validation Class Initialized
INFO - 2020-02-13 12:18:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 12:18:25 --> Final output sent to browser
DEBUG - 2020-02-13 12:18:25 --> Total execution time: 0.6920
INFO - 2020-02-13 12:18:27 --> Config Class Initialized
INFO - 2020-02-13 12:18:27 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:18:27 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:18:27 --> Utf8 Class Initialized
INFO - 2020-02-13 12:18:27 --> URI Class Initialized
INFO - 2020-02-13 12:18:27 --> Router Class Initialized
INFO - 2020-02-13 12:18:27 --> Output Class Initialized
INFO - 2020-02-13 12:18:27 --> Security Class Initialized
DEBUG - 2020-02-13 12:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:18:27 --> Input Class Initialized
INFO - 2020-02-13 12:18:27 --> Language Class Initialized
INFO - 2020-02-13 12:18:27 --> Loader Class Initialized
INFO - 2020-02-13 12:18:27 --> Helper loaded: url_helper
INFO - 2020-02-13 12:18:27 --> Helper loaded: string_helper
INFO - 2020-02-13 12:18:27 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:18:27 --> Controller Class Initialized
INFO - 2020-02-13 12:18:27 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:18:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:18:27 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:18:27 --> Helper loaded: form_helper
INFO - 2020-02-13 12:18:27 --> Form Validation Class Initialized
INFO - 2020-02-13 12:18:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:18:27 --> Final output sent to browser
DEBUG - 2020-02-13 12:18:27 --> Total execution time: 0.6843
INFO - 2020-02-13 12:18:30 --> Config Class Initialized
INFO - 2020-02-13 12:18:30 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:18:30 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:18:30 --> Utf8 Class Initialized
INFO - 2020-02-13 12:18:30 --> URI Class Initialized
INFO - 2020-02-13 12:18:30 --> Router Class Initialized
INFO - 2020-02-13 12:18:30 --> Output Class Initialized
INFO - 2020-02-13 12:18:30 --> Security Class Initialized
DEBUG - 2020-02-13 12:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:18:30 --> Input Class Initialized
INFO - 2020-02-13 12:18:30 --> Language Class Initialized
INFO - 2020-02-13 12:18:30 --> Loader Class Initialized
INFO - 2020-02-13 12:18:30 --> Helper loaded: url_helper
INFO - 2020-02-13 12:18:30 --> Helper loaded: string_helper
INFO - 2020-02-13 12:18:30 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:18:30 --> Controller Class Initialized
INFO - 2020-02-13 12:18:30 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:18:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:18:30 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:18:30 --> Helper loaded: form_helper
INFO - 2020-02-13 12:18:30 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:18:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 59
ERROR - 2020-02-13 12:18:30 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('34', 240268, '1', '2', NULL)
INFO - 2020-02-13 12:18:30 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 12:19:49 --> Config Class Initialized
INFO - 2020-02-13 12:19:49 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:19:49 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:19:49 --> Utf8 Class Initialized
INFO - 2020-02-13 12:19:49 --> URI Class Initialized
INFO - 2020-02-13 12:19:49 --> Router Class Initialized
INFO - 2020-02-13 12:19:49 --> Output Class Initialized
INFO - 2020-02-13 12:19:49 --> Security Class Initialized
DEBUG - 2020-02-13 12:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:19:49 --> Input Class Initialized
INFO - 2020-02-13 12:19:49 --> Language Class Initialized
INFO - 2020-02-13 12:19:49 --> Loader Class Initialized
INFO - 2020-02-13 12:19:49 --> Helper loaded: url_helper
INFO - 2020-02-13 12:19:49 --> Helper loaded: string_helper
INFO - 2020-02-13 12:19:49 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:19:49 --> Controller Class Initialized
INFO - 2020-02-13 12:19:49 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:19:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:19:49 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:19:49 --> Helper loaded: form_helper
INFO - 2020-02-13 12:19:49 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:19:49 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 48
ERROR - 2020-02-13 12:19:49 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 49
ERROR - 2020-02-13 12:19:49 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 50
ERROR - 2020-02-13 12:19:49 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 51
ERROR - 2020-02-13 12:19:49 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 81
ERROR - 2020-02-13 12:19:49 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 82
ERROR - 2020-02-13 12:19:49 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 83
ERROR - 2020-02-13 12:19:49 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 84
ERROR - 2020-02-13 12:19:49 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pengunjung` (`nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2020-02-13 12:19:49 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-13 12:19:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow\system\core\Common.php 570
INFO - 2020-02-13 12:23:01 --> Config Class Initialized
INFO - 2020-02-13 12:23:01 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:01 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:02 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:02 --> URI Class Initialized
INFO - 2020-02-13 12:23:02 --> Router Class Initialized
INFO - 2020-02-13 12:23:02 --> Output Class Initialized
INFO - 2020-02-13 12:23:02 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:02 --> Input Class Initialized
INFO - 2020-02-13 12:23:02 --> Language Class Initialized
ERROR - 2020-02-13 12:23:02 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE), expecting ',' or ')' C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
INFO - 2020-02-13 12:23:07 --> Config Class Initialized
INFO - 2020-02-13 12:23:07 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:07 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:07 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:07 --> URI Class Initialized
DEBUG - 2020-02-13 12:23:07 --> No URI present. Default controller set.
INFO - 2020-02-13 12:23:07 --> Router Class Initialized
INFO - 2020-02-13 12:23:07 --> Output Class Initialized
INFO - 2020-02-13 12:23:07 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:07 --> Input Class Initialized
INFO - 2020-02-13 12:23:07 --> Language Class Initialized
INFO - 2020-02-13 12:23:07 --> Loader Class Initialized
INFO - 2020-02-13 12:23:07 --> Helper loaded: url_helper
INFO - 2020-02-13 12:23:07 --> Helper loaded: string_helper
INFO - 2020-02-13 12:23:07 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:23:07 --> Controller Class Initialized
INFO - 2020-02-13 12:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 12:23:07 --> Pagination Class Initialized
INFO - 2020-02-13 12:23:07 --> Model "M_show" initialized
INFO - 2020-02-13 12:23:07 --> Helper loaded: form_helper
INFO - 2020-02-13 12:23:07 --> Form Validation Class Initialized
INFO - 2020-02-13 12:23:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 12:23:07 --> Final output sent to browser
DEBUG - 2020-02-13 12:23:07 --> Total execution time: 0.6972
INFO - 2020-02-13 12:23:09 --> Config Class Initialized
INFO - 2020-02-13 12:23:09 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:09 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:09 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:09 --> URI Class Initialized
INFO - 2020-02-13 12:23:09 --> Router Class Initialized
INFO - 2020-02-13 12:23:09 --> Output Class Initialized
INFO - 2020-02-13 12:23:09 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:10 --> Input Class Initialized
INFO - 2020-02-13 12:23:10 --> Language Class Initialized
ERROR - 2020-02-13 12:23:10 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE), expecting ',' or ')' C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
INFO - 2020-02-13 12:23:33 --> Config Class Initialized
INFO - 2020-02-13 12:23:33 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:33 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:33 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:33 --> URI Class Initialized
INFO - 2020-02-13 12:23:33 --> Router Class Initialized
INFO - 2020-02-13 12:23:33 --> Output Class Initialized
INFO - 2020-02-13 12:23:33 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:33 --> Input Class Initialized
INFO - 2020-02-13 12:23:34 --> Language Class Initialized
INFO - 2020-02-13 12:23:34 --> Loader Class Initialized
INFO - 2020-02-13 12:23:34 --> Helper loaded: url_helper
INFO - 2020-02-13 12:23:34 --> Helper loaded: string_helper
INFO - 2020-02-13 12:23:34 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:23:34 --> Controller Class Initialized
INFO - 2020-02-13 12:23:34 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:23:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:23:34 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:23:34 --> Helper loaded: form_helper
INFO - 2020-02-13 12:23:34 --> Form Validation Class Initialized
INFO - 2020-02-13 12:23:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:23:34 --> Final output sent to browser
INFO - 2020-02-13 12:23:34 --> Config Class Initialized
INFO - 2020-02-13 12:23:34 --> Config Class Initialized
INFO - 2020-02-13 12:23:34 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:34 --> Total execution time: 0.6422
INFO - 2020-02-13 12:23:34 --> Config Class Initialized
INFO - 2020-02-13 12:23:34 --> Hooks Class Initialized
INFO - 2020-02-13 12:23:34 --> Config Class Initialized
INFO - 2020-02-13 12:23:34 --> Config Class Initialized
INFO - 2020-02-13 12:23:34 --> Hooks Class Initialized
INFO - 2020-02-13 12:23:34 --> Hooks Class Initialized
INFO - 2020-02-13 12:23:34 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:23:34 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:34 --> Config Class Initialized
INFO - 2020-02-13 12:23:34 --> Hooks Class Initialized
INFO - 2020-02-13 12:23:34 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:34 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:23:34 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:34 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:34 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:34 --> URI Class Initialized
INFO - 2020-02-13 12:23:34 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:34 --> URI Class Initialized
DEBUG - 2020-02-13 12:23:34 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:34 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:34 --> URI Class Initialized
INFO - 2020-02-13 12:23:34 --> Router Class Initialized
INFO - 2020-02-13 12:23:34 --> URI Class Initialized
INFO - 2020-02-13 12:23:34 --> URI Class Initialized
INFO - 2020-02-13 12:23:34 --> Router Class Initialized
INFO - 2020-02-13 12:23:34 --> URI Class Initialized
INFO - 2020-02-13 12:23:34 --> Router Class Initialized
INFO - 2020-02-13 12:23:34 --> Router Class Initialized
INFO - 2020-02-13 12:23:34 --> Output Class Initialized
INFO - 2020-02-13 12:23:34 --> Output Class Initialized
INFO - 2020-02-13 12:23:34 --> Router Class Initialized
INFO - 2020-02-13 12:23:34 --> Security Class Initialized
INFO - 2020-02-13 12:23:34 --> Output Class Initialized
INFO - 2020-02-13 12:23:34 --> Output Class Initialized
INFO - 2020-02-13 12:23:34 --> Output Class Initialized
INFO - 2020-02-13 12:23:34 --> Router Class Initialized
INFO - 2020-02-13 12:23:34 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:34 --> Security Class Initialized
INFO - 2020-02-13 12:23:34 --> Security Class Initialized
INFO - 2020-02-13 12:23:34 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:34 --> Output Class Initialized
INFO - 2020-02-13 12:23:34 --> Input Class Initialized
INFO - 2020-02-13 12:23:34 --> Input Class Initialized
DEBUG - 2020-02-13 12:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:34 --> Security Class Initialized
INFO - 2020-02-13 12:23:34 --> Input Class Initialized
INFO - 2020-02-13 12:23:34 --> Language Class Initialized
INFO - 2020-02-13 12:23:34 --> Input Class Initialized
INFO - 2020-02-13 12:23:34 --> Input Class Initialized
INFO - 2020-02-13 12:23:34 --> Language Class Initialized
DEBUG - 2020-02-13 12:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:34 --> Input Class Initialized
INFO - 2020-02-13 12:23:34 --> Language Class Initialized
INFO - 2020-02-13 12:23:34 --> Language Class Initialized
INFO - 2020-02-13 12:23:34 --> Language Class Initialized
INFO - 2020-02-13 12:23:34 --> Loader Class Initialized
INFO - 2020-02-13 12:23:34 --> Loader Class Initialized
INFO - 2020-02-13 12:23:34 --> Language Class Initialized
INFO - 2020-02-13 12:23:34 --> Helper loaded: url_helper
INFO - 2020-02-13 12:23:34 --> Helper loaded: url_helper
ERROR - 2020-02-13 12:23:34 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 12:23:34 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 12:23:34 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 12:23:34 --> Helper loaded: string_helper
INFO - 2020-02-13 12:23:34 --> Helper loaded: string_helper
ERROR - 2020-02-13 12:23:34 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 12:23:35 --> Config Class Initialized
INFO - 2020-02-13 12:23:35 --> Config Class Initialized
INFO - 2020-02-13 12:23:35 --> Config Class Initialized
INFO - 2020-02-13 12:23:35 --> Hooks Class Initialized
INFO - 2020-02-13 12:23:35 --> Hooks Class Initialized
INFO - 2020-02-13 12:23:35 --> Hooks Class Initialized
INFO - 2020-02-13 12:23:35 --> Database Driver Class Initialized
INFO - 2020-02-13 12:23:35 --> Database Driver Class Initialized
INFO - 2020-02-13 12:23:35 --> Config Class Initialized
INFO - 2020-02-13 12:23:35 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:23:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:23:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 12:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:23:35 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:35 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:23:35 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:23:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:35 --> Controller Class Initialized
INFO - 2020-02-13 12:23:35 --> URI Class Initialized
INFO - 2020-02-13 12:23:35 --> URI Class Initialized
INFO - 2020-02-13 12:23:35 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:35 --> URI Class Initialized
INFO - 2020-02-13 12:23:35 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:23:35 --> URI Class Initialized
INFO - 2020-02-13 12:23:35 --> Router Class Initialized
INFO - 2020-02-13 12:23:35 --> Router Class Initialized
INFO - 2020-02-13 12:23:35 --> Router Class Initialized
INFO - 2020-02-13 12:23:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:23:35 --> Output Class Initialized
INFO - 2020-02-13 12:23:35 --> Output Class Initialized
INFO - 2020-02-13 12:23:35 --> Output Class Initialized
INFO - 2020-02-13 12:23:35 --> Router Class Initialized
INFO - 2020-02-13 12:23:35 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:23:35 --> Security Class Initialized
INFO - 2020-02-13 12:23:35 --> Security Class Initialized
INFO - 2020-02-13 12:23:35 --> Security Class Initialized
INFO - 2020-02-13 12:23:35 --> Output Class Initialized
DEBUG - 2020-02-13 12:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:35 --> Security Class Initialized
INFO - 2020-02-13 12:23:35 --> Helper loaded: form_helper
INFO - 2020-02-13 12:23:35 --> Form Validation Class Initialized
INFO - 2020-02-13 12:23:35 --> Input Class Initialized
INFO - 2020-02-13 12:23:35 --> Input Class Initialized
INFO - 2020-02-13 12:23:35 --> Input Class Initialized
DEBUG - 2020-02-13 12:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:35 --> Input Class Initialized
INFO - 2020-02-13 12:23:35 --> Language Class Initialized
INFO - 2020-02-13 12:23:35 --> Language Class Initialized
INFO - 2020-02-13 12:23:35 --> Language Class Initialized
ERROR - 2020-02-13 12:23:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:23:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:23:35 --> Language Class Initialized
ERROR - 2020-02-13 12:23:35 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 12:23:35 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 12:23:35 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 12:23:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 12:23:35 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 12:23:35 --> Config Class Initialized
INFO - 2020-02-13 12:23:35 --> Config Class Initialized
INFO - 2020-02-13 12:23:35 --> Config Class Initialized
INFO - 2020-02-13 12:23:35 --> Hooks Class Initialized
INFO - 2020-02-13 12:23:35 --> Hooks Class Initialized
INFO - 2020-02-13 12:23:35 --> Hooks Class Initialized
INFO - 2020-02-13 12:23:35 --> Final output sent to browser
INFO - 2020-02-13 12:23:35 --> Config Class Initialized
INFO - 2020-02-13 12:23:35 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:35 --> Total execution time: 0.8988
DEBUG - 2020-02-13 12:23:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:23:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:23:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:35 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:35 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:23:35 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:23:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:35 --> Controller Class Initialized
INFO - 2020-02-13 12:23:35 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:35 --> URI Class Initialized
INFO - 2020-02-13 12:23:35 --> URI Class Initialized
INFO - 2020-02-13 12:23:35 --> URI Class Initialized
INFO - 2020-02-13 12:23:35 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:23:35 --> Router Class Initialized
INFO - 2020-02-13 12:23:35 --> Router Class Initialized
INFO - 2020-02-13 12:23:35 --> Router Class Initialized
INFO - 2020-02-13 12:23:35 --> URI Class Initialized
INFO - 2020-02-13 12:23:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:23:35 --> Router Class Initialized
INFO - 2020-02-13 12:23:35 --> Output Class Initialized
INFO - 2020-02-13 12:23:35 --> Output Class Initialized
INFO - 2020-02-13 12:23:35 --> Output Class Initialized
INFO - 2020-02-13 12:23:35 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:23:35 --> Security Class Initialized
INFO - 2020-02-13 12:23:35 --> Security Class Initialized
INFO - 2020-02-13 12:23:35 --> Output Class Initialized
INFO - 2020-02-13 12:23:35 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:35 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:35 --> Helper loaded: form_helper
INFO - 2020-02-13 12:23:35 --> Input Class Initialized
INFO - 2020-02-13 12:23:35 --> Input Class Initialized
INFO - 2020-02-13 12:23:35 --> Input Class Initialized
INFO - 2020-02-13 12:23:35 --> Form Validation Class Initialized
DEBUG - 2020-02-13 12:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:35 --> Input Class Initialized
INFO - 2020-02-13 12:23:35 --> Language Class Initialized
INFO - 2020-02-13 12:23:35 --> Language Class Initialized
INFO - 2020-02-13 12:23:35 --> Language Class Initialized
ERROR - 2020-02-13 12:23:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-13 12:23:35 --> Language Class Initialized
ERROR - 2020-02-13 12:23:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 12:23:35 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 12:23:35 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 12:23:35 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 12:23:35 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 12:23:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:23:35 --> Final output sent to browser
INFO - 2020-02-13 12:23:35 --> Config Class Initialized
INFO - 2020-02-13 12:23:35 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:35 --> Total execution time: 1.2175
DEBUG - 2020-02-13 12:23:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:35 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:35 --> URI Class Initialized
INFO - 2020-02-13 12:23:35 --> Router Class Initialized
INFO - 2020-02-13 12:23:35 --> Output Class Initialized
INFO - 2020-02-13 12:23:35 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:35 --> Input Class Initialized
INFO - 2020-02-13 12:23:35 --> Language Class Initialized
ERROR - 2020-02-13 12:23:35 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 12:23:36 --> Config Class Initialized
INFO - 2020-02-13 12:23:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:36 --> URI Class Initialized
INFO - 2020-02-13 12:23:36 --> Router Class Initialized
INFO - 2020-02-13 12:23:36 --> Output Class Initialized
INFO - 2020-02-13 12:23:36 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:36 --> Input Class Initialized
INFO - 2020-02-13 12:23:36 --> Language Class Initialized
ERROR - 2020-02-13 12:23:36 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 12:23:36 --> Config Class Initialized
INFO - 2020-02-13 12:23:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:36 --> URI Class Initialized
INFO - 2020-02-13 12:23:36 --> Router Class Initialized
INFO - 2020-02-13 12:23:36 --> Output Class Initialized
INFO - 2020-02-13 12:23:36 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:36 --> Input Class Initialized
INFO - 2020-02-13 12:23:36 --> Language Class Initialized
ERROR - 2020-02-13 12:23:36 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 12:23:36 --> Config Class Initialized
INFO - 2020-02-13 12:23:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:36 --> URI Class Initialized
INFO - 2020-02-13 12:23:36 --> Router Class Initialized
INFO - 2020-02-13 12:23:36 --> Output Class Initialized
INFO - 2020-02-13 12:23:36 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:36 --> Input Class Initialized
INFO - 2020-02-13 12:23:37 --> Language Class Initialized
ERROR - 2020-02-13 12:23:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:23:37 --> Config Class Initialized
INFO - 2020-02-13 12:23:37 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:37 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:37 --> URI Class Initialized
INFO - 2020-02-13 12:23:37 --> Router Class Initialized
INFO - 2020-02-13 12:23:37 --> Output Class Initialized
INFO - 2020-02-13 12:23:37 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:37 --> Input Class Initialized
INFO - 2020-02-13 12:23:37 --> Language Class Initialized
ERROR - 2020-02-13 12:23:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:23:37 --> Config Class Initialized
INFO - 2020-02-13 12:23:37 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:37 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:37 --> URI Class Initialized
INFO - 2020-02-13 12:23:37 --> Router Class Initialized
INFO - 2020-02-13 12:23:37 --> Output Class Initialized
INFO - 2020-02-13 12:23:37 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:37 --> Input Class Initialized
INFO - 2020-02-13 12:23:37 --> Language Class Initialized
ERROR - 2020-02-13 12:23:37 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 12:23:37 --> Config Class Initialized
INFO - 2020-02-13 12:23:37 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:37 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:37 --> URI Class Initialized
INFO - 2020-02-13 12:23:37 --> Router Class Initialized
INFO - 2020-02-13 12:23:37 --> Output Class Initialized
INFO - 2020-02-13 12:23:37 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:37 --> Input Class Initialized
INFO - 2020-02-13 12:23:37 --> Language Class Initialized
ERROR - 2020-02-13 12:23:38 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 12:23:38 --> Config Class Initialized
INFO - 2020-02-13 12:23:38 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:38 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:38 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:38 --> URI Class Initialized
INFO - 2020-02-13 12:23:38 --> Router Class Initialized
INFO - 2020-02-13 12:23:38 --> Output Class Initialized
INFO - 2020-02-13 12:23:38 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:38 --> Input Class Initialized
INFO - 2020-02-13 12:23:38 --> Language Class Initialized
ERROR - 2020-02-13 12:23:38 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 12:23:38 --> Config Class Initialized
INFO - 2020-02-13 12:23:38 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:38 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:38 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:38 --> URI Class Initialized
INFO - 2020-02-13 12:23:38 --> Router Class Initialized
INFO - 2020-02-13 12:23:38 --> Output Class Initialized
INFO - 2020-02-13 12:23:38 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:38 --> Input Class Initialized
INFO - 2020-02-13 12:23:38 --> Language Class Initialized
ERROR - 2020-02-13 12:23:38 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 12:23:59 --> Config Class Initialized
INFO - 2020-02-13 12:23:59 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:23:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:23:59 --> Utf8 Class Initialized
INFO - 2020-02-13 12:23:59 --> URI Class Initialized
INFO - 2020-02-13 12:23:59 --> Router Class Initialized
INFO - 2020-02-13 12:23:59 --> Output Class Initialized
INFO - 2020-02-13 12:23:59 --> Security Class Initialized
DEBUG - 2020-02-13 12:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:23:59 --> Input Class Initialized
INFO - 2020-02-13 12:23:59 --> Language Class Initialized
INFO - 2020-02-13 12:23:59 --> Loader Class Initialized
INFO - 2020-02-13 12:23:59 --> Helper loaded: url_helper
INFO - 2020-02-13 12:23:59 --> Helper loaded: string_helper
INFO - 2020-02-13 12:24:00 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:24:00 --> Controller Class Initialized
INFO - 2020-02-13 12:24:00 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:24:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:24:00 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:24:00 --> Helper loaded: form_helper
INFO - 2020-02-13 12:24:00 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:24:00 --> Severity: Notice --> Undefined variable: idpesan C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
ERROR - 2020-02-13 12:24:00 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
INFO - 2020-02-13 12:26:30 --> Config Class Initialized
INFO - 2020-02-13 12:26:31 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:26:31 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:31 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:31 --> URI Class Initialized
DEBUG - 2020-02-13 12:26:31 --> No URI present. Default controller set.
INFO - 2020-02-13 12:26:31 --> Router Class Initialized
INFO - 2020-02-13 12:26:31 --> Output Class Initialized
INFO - 2020-02-13 12:26:31 --> Security Class Initialized
DEBUG - 2020-02-13 12:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:31 --> Input Class Initialized
INFO - 2020-02-13 12:26:31 --> Language Class Initialized
INFO - 2020-02-13 12:26:31 --> Loader Class Initialized
INFO - 2020-02-13 12:26:31 --> Helper loaded: url_helper
INFO - 2020-02-13 12:26:31 --> Helper loaded: string_helper
INFO - 2020-02-13 12:26:31 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:26:31 --> Controller Class Initialized
INFO - 2020-02-13 12:26:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 12:26:31 --> Pagination Class Initialized
INFO - 2020-02-13 12:26:31 --> Model "M_show" initialized
INFO - 2020-02-13 12:26:31 --> Helper loaded: form_helper
INFO - 2020-02-13 12:26:31 --> Form Validation Class Initialized
INFO - 2020-02-13 12:26:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 12:26:31 --> Final output sent to browser
DEBUG - 2020-02-13 12:26:31 --> Total execution time: 0.9329
INFO - 2020-02-13 12:26:32 --> Config Class Initialized
INFO - 2020-02-13 12:26:32 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:26:32 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:32 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:32 --> URI Class Initialized
DEBUG - 2020-02-13 12:26:32 --> No URI present. Default controller set.
INFO - 2020-02-13 12:26:32 --> Router Class Initialized
INFO - 2020-02-13 12:26:32 --> Output Class Initialized
INFO - 2020-02-13 12:26:32 --> Security Class Initialized
DEBUG - 2020-02-13 12:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:32 --> Input Class Initialized
INFO - 2020-02-13 12:26:32 --> Language Class Initialized
INFO - 2020-02-13 12:26:32 --> Loader Class Initialized
INFO - 2020-02-13 12:26:32 --> Helper loaded: url_helper
INFO - 2020-02-13 12:26:32 --> Helper loaded: string_helper
INFO - 2020-02-13 12:26:32 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:26:32 --> Controller Class Initialized
INFO - 2020-02-13 12:26:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 12:26:32 --> Pagination Class Initialized
INFO - 2020-02-13 12:26:32 --> Model "M_show" initialized
INFO - 2020-02-13 12:26:32 --> Helper loaded: form_helper
INFO - 2020-02-13 12:26:32 --> Form Validation Class Initialized
INFO - 2020-02-13 12:26:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 12:26:32 --> Final output sent to browser
DEBUG - 2020-02-13 12:26:32 --> Total execution time: 0.7199
INFO - 2020-02-13 12:26:35 --> Config Class Initialized
INFO - 2020-02-13 12:26:35 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:26:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:35 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:35 --> URI Class Initialized
INFO - 2020-02-13 12:26:35 --> Router Class Initialized
INFO - 2020-02-13 12:26:35 --> Output Class Initialized
INFO - 2020-02-13 12:26:35 --> Security Class Initialized
DEBUG - 2020-02-13 12:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:35 --> Input Class Initialized
INFO - 2020-02-13 12:26:35 --> Language Class Initialized
INFO - 2020-02-13 12:26:35 --> Loader Class Initialized
INFO - 2020-02-13 12:26:35 --> Helper loaded: url_helper
INFO - 2020-02-13 12:26:36 --> Helper loaded: string_helper
INFO - 2020-02-13 12:26:36 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:26:36 --> Controller Class Initialized
INFO - 2020-02-13 12:26:36 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:26:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:26:36 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:26:36 --> Helper loaded: form_helper
INFO - 2020-02-13 12:26:36 --> Form Validation Class Initialized
INFO - 2020-02-13 12:26:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:26:36 --> Final output sent to browser
INFO - 2020-02-13 12:26:36 --> Config Class Initialized
INFO - 2020-02-13 12:26:36 --> Config Class Initialized
INFO - 2020-02-13 12:26:36 --> Config Class Initialized
INFO - 2020-02-13 12:26:36 --> Config Class Initialized
INFO - 2020-02-13 12:26:36 --> Hooks Class Initialized
INFO - 2020-02-13 12:26:36 --> Hooks Class Initialized
INFO - 2020-02-13 12:26:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:26:36 --> Total execution time: 0.6959
INFO - 2020-02-13 12:26:36 --> Hooks Class Initialized
INFO - 2020-02-13 12:26:36 --> Config Class Initialized
INFO - 2020-02-13 12:26:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:26:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:26:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:26:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:26:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:36 --> Config Class Initialized
INFO - 2020-02-13 12:26:36 --> Hooks Class Initialized
INFO - 2020-02-13 12:26:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:36 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:26:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:36 --> URI Class Initialized
INFO - 2020-02-13 12:26:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:36 --> URI Class Initialized
INFO - 2020-02-13 12:26:36 --> URI Class Initialized
DEBUG - 2020-02-13 12:26:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:36 --> URI Class Initialized
INFO - 2020-02-13 12:26:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:36 --> Router Class Initialized
INFO - 2020-02-13 12:26:36 --> Router Class Initialized
INFO - 2020-02-13 12:26:36 --> URI Class Initialized
INFO - 2020-02-13 12:26:36 --> Router Class Initialized
INFO - 2020-02-13 12:26:36 --> Router Class Initialized
INFO - 2020-02-13 12:26:36 --> Router Class Initialized
INFO - 2020-02-13 12:26:36 --> Output Class Initialized
INFO - 2020-02-13 12:26:36 --> Output Class Initialized
INFO - 2020-02-13 12:26:36 --> URI Class Initialized
INFO - 2020-02-13 12:26:36 --> Output Class Initialized
INFO - 2020-02-13 12:26:36 --> Output Class Initialized
INFO - 2020-02-13 12:26:36 --> Router Class Initialized
INFO - 2020-02-13 12:26:36 --> Security Class Initialized
INFO - 2020-02-13 12:26:36 --> Output Class Initialized
INFO - 2020-02-13 12:26:36 --> Security Class Initialized
INFO - 2020-02-13 12:26:36 --> Security Class Initialized
INFO - 2020-02-13 12:26:36 --> Security Class Initialized
DEBUG - 2020-02-13 12:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:36 --> Security Class Initialized
INFO - 2020-02-13 12:26:36 --> Output Class Initialized
DEBUG - 2020-02-13 12:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:36 --> Input Class Initialized
INFO - 2020-02-13 12:26:36 --> Input Class Initialized
INFO - 2020-02-13 12:26:36 --> Input Class Initialized
INFO - 2020-02-13 12:26:36 --> Input Class Initialized
DEBUG - 2020-02-13 12:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:36 --> Security Class Initialized
INFO - 2020-02-13 12:26:36 --> Input Class Initialized
INFO - 2020-02-13 12:26:36 --> Language Class Initialized
INFO - 2020-02-13 12:26:36 --> Language Class Initialized
DEBUG - 2020-02-13 12:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:36 --> Language Class Initialized
INFO - 2020-02-13 12:26:36 --> Language Class Initialized
INFO - 2020-02-13 12:26:36 --> Input Class Initialized
ERROR - 2020-02-13 12:26:36 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 12:26:36 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 12:26:36 --> Language Class Initialized
INFO - 2020-02-13 12:26:36 --> Loader Class Initialized
INFO - 2020-02-13 12:26:36 --> Loader Class Initialized
INFO - 2020-02-13 12:26:36 --> Language Class Initialized
INFO - 2020-02-13 12:26:36 --> Helper loaded: url_helper
INFO - 2020-02-13 12:26:36 --> Helper loaded: url_helper
ERROR - 2020-02-13 12:26:36 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 12:26:36 --> Config Class Initialized
INFO - 2020-02-13 12:26:36 --> Config Class Initialized
INFO - 2020-02-13 12:26:36 --> Hooks Class Initialized
INFO - 2020-02-13 12:26:36 --> Hooks Class Initialized
ERROR - 2020-02-13 12:26:36 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 12:26:36 --> Helper loaded: string_helper
INFO - 2020-02-13 12:26:36 --> Helper loaded: string_helper
INFO - 2020-02-13 12:26:36 --> Config Class Initialized
INFO - 2020-02-13 12:26:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:26:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:26:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:36 --> Database Driver Class Initialized
INFO - 2020-02-13 12:26:36 --> Database Driver Class Initialized
INFO - 2020-02-13 12:26:36 --> Config Class Initialized
INFO - 2020-02-13 12:26:36 --> Hooks Class Initialized
INFO - 2020-02-13 12:26:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:36 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:26:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 12:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:26:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:36 --> URI Class Initialized
INFO - 2020-02-13 12:26:36 --> URI Class Initialized
INFO - 2020-02-13 12:26:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 12:26:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:36 --> Controller Class Initialized
INFO - 2020-02-13 12:26:36 --> URI Class Initialized
INFO - 2020-02-13 12:26:36 --> Router Class Initialized
INFO - 2020-02-13 12:26:36 --> Router Class Initialized
INFO - 2020-02-13 12:26:37 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:26:37 --> URI Class Initialized
INFO - 2020-02-13 12:26:37 --> Output Class Initialized
INFO - 2020-02-13 12:26:37 --> Router Class Initialized
INFO - 2020-02-13 12:26:37 --> Output Class Initialized
INFO - 2020-02-13 12:26:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:26:37 --> Security Class Initialized
INFO - 2020-02-13 12:26:37 --> Security Class Initialized
INFO - 2020-02-13 12:26:37 --> Output Class Initialized
INFO - 2020-02-13 12:26:37 --> Router Class Initialized
INFO - 2020-02-13 12:26:37 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 12:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:37 --> Output Class Initialized
INFO - 2020-02-13 12:26:37 --> Security Class Initialized
INFO - 2020-02-13 12:26:37 --> Input Class Initialized
DEBUG - 2020-02-13 12:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:37 --> Input Class Initialized
INFO - 2020-02-13 12:26:37 --> Security Class Initialized
INFO - 2020-02-13 12:26:37 --> Helper loaded: form_helper
INFO - 2020-02-13 12:26:37 --> Input Class Initialized
INFO - 2020-02-13 12:26:37 --> Form Validation Class Initialized
INFO - 2020-02-13 12:26:37 --> Language Class Initialized
DEBUG - 2020-02-13 12:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:37 --> Language Class Initialized
INFO - 2020-02-13 12:26:37 --> Input Class Initialized
INFO - 2020-02-13 12:26:37 --> Language Class Initialized
ERROR - 2020-02-13 12:26:37 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 12:26:37 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 12:26:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-13 12:26:37 --> Language Class Initialized
ERROR - 2020-02-13 12:26:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 12:26:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:26:37 --> Config Class Initialized
INFO - 2020-02-13 12:26:37 --> Config Class Initialized
INFO - 2020-02-13 12:26:37 --> Hooks Class Initialized
INFO - 2020-02-13 12:26:37 --> Hooks Class Initialized
INFO - 2020-02-13 12:26:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 12:26:37 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 12:26:37 --> Config Class Initialized
INFO - 2020-02-13 12:26:37 --> Hooks Class Initialized
INFO - 2020-02-13 12:26:37 --> Final output sent to browser
DEBUG - 2020-02-13 12:26:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:26:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:37 --> Config Class Initialized
INFO - 2020-02-13 12:26:37 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:37 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:26:37 --> Total execution time: 0.8416
INFO - 2020-02-13 12:26:37 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:26:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:37 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:26:37 --> URI Class Initialized
INFO - 2020-02-13 12:26:37 --> URI Class Initialized
DEBUG - 2020-02-13 12:26:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:37 --> Controller Class Initialized
INFO - 2020-02-13 12:26:37 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:37 --> URI Class Initialized
INFO - 2020-02-13 12:26:37 --> Router Class Initialized
INFO - 2020-02-13 12:26:37 --> Router Class Initialized
INFO - 2020-02-13 12:26:37 --> Router Class Initialized
INFO - 2020-02-13 12:26:37 --> Output Class Initialized
INFO - 2020-02-13 12:26:37 --> URI Class Initialized
INFO - 2020-02-13 12:26:37 --> Output Class Initialized
INFO - 2020-02-13 12:26:37 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:26:37 --> Security Class Initialized
INFO - 2020-02-13 12:26:37 --> Security Class Initialized
INFO - 2020-02-13 12:26:37 --> Router Class Initialized
INFO - 2020-02-13 12:26:37 --> Output Class Initialized
INFO - 2020-02-13 12:26:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:26:37 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 12:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:37 --> Output Class Initialized
INFO - 2020-02-13 12:26:37 --> Security Class Initialized
INFO - 2020-02-13 12:26:37 --> Input Class Initialized
INFO - 2020-02-13 12:26:37 --> Input Class Initialized
INFO - 2020-02-13 12:26:37 --> Security Class Initialized
DEBUG - 2020-02-13 12:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:37 --> Helper loaded: form_helper
INFO - 2020-02-13 12:26:37 --> Form Validation Class Initialized
INFO - 2020-02-13 12:26:37 --> Language Class Initialized
INFO - 2020-02-13 12:26:37 --> Input Class Initialized
INFO - 2020-02-13 12:26:37 --> Language Class Initialized
DEBUG - 2020-02-13 12:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:37 --> Input Class Initialized
INFO - 2020-02-13 12:26:37 --> Language Class Initialized
ERROR - 2020-02-13 12:26:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 12:26:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 12:26:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:26:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:26:37 --> Language Class Initialized
ERROR - 2020-02-13 12:26:37 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 12:26:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 12:26:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:26:37 --> Final output sent to browser
INFO - 2020-02-13 12:26:37 --> Config Class Initialized
INFO - 2020-02-13 12:26:37 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:26:37 --> Total execution time: 1.1999
DEBUG - 2020-02-13 12:26:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:37 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:37 --> URI Class Initialized
INFO - 2020-02-13 12:26:37 --> Router Class Initialized
INFO - 2020-02-13 12:26:37 --> Output Class Initialized
INFO - 2020-02-13 12:26:37 --> Security Class Initialized
DEBUG - 2020-02-13 12:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:37 --> Input Class Initialized
INFO - 2020-02-13 12:26:37 --> Language Class Initialized
ERROR - 2020-02-13 12:26:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:26:37 --> Config Class Initialized
INFO - 2020-02-13 12:26:37 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:26:38 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:38 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:38 --> URI Class Initialized
INFO - 2020-02-13 12:26:38 --> Router Class Initialized
INFO - 2020-02-13 12:26:38 --> Output Class Initialized
INFO - 2020-02-13 12:26:38 --> Security Class Initialized
DEBUG - 2020-02-13 12:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:38 --> Input Class Initialized
INFO - 2020-02-13 12:26:38 --> Language Class Initialized
ERROR - 2020-02-13 12:26:38 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 12:26:38 --> Config Class Initialized
INFO - 2020-02-13 12:26:38 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:26:38 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:38 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:38 --> URI Class Initialized
INFO - 2020-02-13 12:26:38 --> Router Class Initialized
INFO - 2020-02-13 12:26:38 --> Output Class Initialized
INFO - 2020-02-13 12:26:38 --> Security Class Initialized
DEBUG - 2020-02-13 12:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:38 --> Input Class Initialized
INFO - 2020-02-13 12:26:38 --> Language Class Initialized
ERROR - 2020-02-13 12:26:38 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 12:26:38 --> Config Class Initialized
INFO - 2020-02-13 12:26:38 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:26:38 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:38 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:38 --> URI Class Initialized
INFO - 2020-02-13 12:26:38 --> Router Class Initialized
INFO - 2020-02-13 12:26:38 --> Output Class Initialized
INFO - 2020-02-13 12:26:38 --> Security Class Initialized
DEBUG - 2020-02-13 12:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:38 --> Input Class Initialized
INFO - 2020-02-13 12:26:38 --> Language Class Initialized
ERROR - 2020-02-13 12:26:38 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 12:26:39 --> Config Class Initialized
INFO - 2020-02-13 12:26:39 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:26:39 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:39 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:39 --> URI Class Initialized
INFO - 2020-02-13 12:26:39 --> Router Class Initialized
INFO - 2020-02-13 12:26:39 --> Output Class Initialized
INFO - 2020-02-13 12:26:39 --> Security Class Initialized
DEBUG - 2020-02-13 12:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:39 --> Input Class Initialized
INFO - 2020-02-13 12:26:39 --> Language Class Initialized
ERROR - 2020-02-13 12:26:39 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 12:26:59 --> Config Class Initialized
INFO - 2020-02-13 12:26:59 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:26:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:26:59 --> Utf8 Class Initialized
INFO - 2020-02-13 12:26:59 --> URI Class Initialized
INFO - 2020-02-13 12:26:59 --> Router Class Initialized
INFO - 2020-02-13 12:26:59 --> Output Class Initialized
INFO - 2020-02-13 12:26:59 --> Security Class Initialized
DEBUG - 2020-02-13 12:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:26:59 --> Input Class Initialized
INFO - 2020-02-13 12:26:59 --> Language Class Initialized
INFO - 2020-02-13 12:26:59 --> Loader Class Initialized
INFO - 2020-02-13 12:26:59 --> Helper loaded: url_helper
INFO - 2020-02-13 12:26:59 --> Helper loaded: string_helper
INFO - 2020-02-13 12:26:59 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:26:59 --> Controller Class Initialized
INFO - 2020-02-13 12:26:59 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:26:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:27:00 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:27:00 --> Helper loaded: form_helper
INFO - 2020-02-13 12:27:00 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:27:00 --> Severity: Notice --> Undefined variable: idpesan C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
ERROR - 2020-02-13 12:27:00 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
INFO - 2020-02-13 12:28:59 --> Config Class Initialized
INFO - 2020-02-13 12:28:59 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:28:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:28:59 --> Utf8 Class Initialized
INFO - 2020-02-13 12:28:59 --> URI Class Initialized
INFO - 2020-02-13 12:28:59 --> Router Class Initialized
INFO - 2020-02-13 12:28:59 --> Output Class Initialized
INFO - 2020-02-13 12:28:59 --> Security Class Initialized
DEBUG - 2020-02-13 12:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:28:59 --> Input Class Initialized
INFO - 2020-02-13 12:28:59 --> Language Class Initialized
INFO - 2020-02-13 12:28:59 --> Loader Class Initialized
INFO - 2020-02-13 12:28:59 --> Helper loaded: url_helper
INFO - 2020-02-13 12:28:59 --> Helper loaded: string_helper
INFO - 2020-02-13 12:28:59 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:28:59 --> Controller Class Initialized
INFO - 2020-02-13 12:28:59 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:28:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:28:59 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:28:59 --> Helper loaded: form_helper
INFO - 2020-02-13 12:28:59 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:29:00 --> Severity: Notice --> Undefined variable: idpesan C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
ERROR - 2020-02-13 12:29:00 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
INFO - 2020-02-13 12:29:12 --> Config Class Initialized
INFO - 2020-02-13 12:29:12 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:29:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:29:12 --> Utf8 Class Initialized
INFO - 2020-02-13 12:29:12 --> URI Class Initialized
INFO - 2020-02-13 12:29:12 --> Router Class Initialized
INFO - 2020-02-13 12:29:12 --> Output Class Initialized
INFO - 2020-02-13 12:29:12 --> Security Class Initialized
DEBUG - 2020-02-13 12:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:29:12 --> Input Class Initialized
INFO - 2020-02-13 12:29:12 --> Language Class Initialized
INFO - 2020-02-13 12:29:12 --> Loader Class Initialized
INFO - 2020-02-13 12:29:12 --> Helper loaded: url_helper
INFO - 2020-02-13 12:29:12 --> Helper loaded: string_helper
INFO - 2020-02-13 12:29:12 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:29:12 --> Controller Class Initialized
INFO - 2020-02-13 12:29:12 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:29:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:29:12 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:29:12 --> Helper loaded: form_helper
INFO - 2020-02-13 12:29:12 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:29:12 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 47
ERROR - 2020-02-13 12:29:12 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 48
ERROR - 2020-02-13 12:29:12 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 49
ERROR - 2020-02-13 12:29:12 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 50
ERROR - 2020-02-13 12:29:12 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 81
ERROR - 2020-02-13 12:29:12 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 82
ERROR - 2020-02-13 12:29:12 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 83
ERROR - 2020-02-13 12:29:12 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 84
ERROR - 2020-02-13 12:29:12 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pengunjung` (`nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2020-02-13 12:29:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-13 12:29:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow\system\core\Common.php 570
INFO - 2020-02-13 12:29:33 --> Config Class Initialized
INFO - 2020-02-13 12:29:33 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:29:33 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:29:33 --> Utf8 Class Initialized
INFO - 2020-02-13 12:29:33 --> URI Class Initialized
INFO - 2020-02-13 12:29:33 --> Router Class Initialized
INFO - 2020-02-13 12:29:33 --> Output Class Initialized
INFO - 2020-02-13 12:29:33 --> Security Class Initialized
DEBUG - 2020-02-13 12:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:29:33 --> Input Class Initialized
INFO - 2020-02-13 12:29:33 --> Language Class Initialized
INFO - 2020-02-13 12:29:33 --> Loader Class Initialized
INFO - 2020-02-13 12:29:33 --> Helper loaded: url_helper
INFO - 2020-02-13 12:29:33 --> Helper loaded: string_helper
INFO - 2020-02-13 12:29:33 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:29:33 --> Controller Class Initialized
INFO - 2020-02-13 12:29:33 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:29:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:29:33 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:29:33 --> Helper loaded: form_helper
INFO - 2020-02-13 12:29:33 --> Form Validation Class Initialized
INFO - 2020-02-13 12:29:33 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:29:33 --> Final output sent to browser
INFO - 2020-02-13 12:29:33 --> Config Class Initialized
DEBUG - 2020-02-13 12:29:33 --> Total execution time: 0.7000
INFO - 2020-02-13 12:29:33 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:29:34 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:29:34 --> Utf8 Class Initialized
INFO - 2020-02-13 12:29:34 --> URI Class Initialized
INFO - 2020-02-13 12:29:34 --> Router Class Initialized
INFO - 2020-02-13 12:29:34 --> Output Class Initialized
INFO - 2020-02-13 12:29:34 --> Security Class Initialized
DEBUG - 2020-02-13 12:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:29:34 --> Input Class Initialized
INFO - 2020-02-13 12:29:34 --> Language Class Initialized
ERROR - 2020-02-13 12:29:34 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 12:30:35 --> Config Class Initialized
INFO - 2020-02-13 12:30:35 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:35 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:35 --> URI Class Initialized
INFO - 2020-02-13 12:30:35 --> Router Class Initialized
INFO - 2020-02-13 12:30:35 --> Output Class Initialized
INFO - 2020-02-13 12:30:35 --> Security Class Initialized
DEBUG - 2020-02-13 12:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:35 --> Input Class Initialized
INFO - 2020-02-13 12:30:35 --> Language Class Initialized
INFO - 2020-02-13 12:30:35 --> Loader Class Initialized
INFO - 2020-02-13 12:30:35 --> Helper loaded: url_helper
INFO - 2020-02-13 12:30:35 --> Helper loaded: string_helper
INFO - 2020-02-13 12:30:35 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:30:36 --> Controller Class Initialized
INFO - 2020-02-13 12:30:36 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:30:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:30:36 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:30:36 --> Helper loaded: form_helper
INFO - 2020-02-13 12:30:36 --> Form Validation Class Initialized
INFO - 2020-02-13 12:30:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:30:36 --> Final output sent to browser
INFO - 2020-02-13 12:30:36 --> Config Class Initialized
INFO - 2020-02-13 12:30:36 --> Config Class Initialized
INFO - 2020-02-13 12:30:36 --> Config Class Initialized
INFO - 2020-02-13 12:30:36 --> Config Class Initialized
INFO - 2020-02-13 12:30:36 --> Hooks Class Initialized
INFO - 2020-02-13 12:30:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:36 --> Total execution time: 0.6480
INFO - 2020-02-13 12:30:36 --> Config Class Initialized
INFO - 2020-02-13 12:30:36 --> Hooks Class Initialized
INFO - 2020-02-13 12:30:36 --> Hooks Class Initialized
INFO - 2020-02-13 12:30:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:30:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:30:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:36 --> Config Class Initialized
INFO - 2020-02-13 12:30:36 --> Hooks Class Initialized
INFO - 2020-02-13 12:30:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:36 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:30:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:30:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:36 --> URI Class Initialized
INFO - 2020-02-13 12:30:36 --> URI Class Initialized
INFO - 2020-02-13 12:30:36 --> URI Class Initialized
DEBUG - 2020-02-13 12:30:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:36 --> Router Class Initialized
INFO - 2020-02-13 12:30:36 --> Router Class Initialized
INFO - 2020-02-13 12:30:36 --> Router Class Initialized
INFO - 2020-02-13 12:30:36 --> URI Class Initialized
INFO - 2020-02-13 12:30:36 --> URI Class Initialized
INFO - 2020-02-13 12:30:36 --> URI Class Initialized
INFO - 2020-02-13 12:30:36 --> Router Class Initialized
INFO - 2020-02-13 12:30:36 --> Output Class Initialized
INFO - 2020-02-13 12:30:36 --> Output Class Initialized
INFO - 2020-02-13 12:30:36 --> Output Class Initialized
INFO - 2020-02-13 12:30:36 --> Router Class Initialized
INFO - 2020-02-13 12:30:36 --> Security Class Initialized
INFO - 2020-02-13 12:30:36 --> Security Class Initialized
INFO - 2020-02-13 12:30:36 --> Security Class Initialized
INFO - 2020-02-13 12:30:36 --> Router Class Initialized
INFO - 2020-02-13 12:30:36 --> Output Class Initialized
INFO - 2020-02-13 12:30:36 --> Output Class Initialized
DEBUG - 2020-02-13 12:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:36 --> Security Class Initialized
INFO - 2020-02-13 12:30:36 --> Output Class Initialized
DEBUG - 2020-02-13 12:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:36 --> Security Class Initialized
INFO - 2020-02-13 12:30:36 --> Input Class Initialized
INFO - 2020-02-13 12:30:36 --> Input Class Initialized
INFO - 2020-02-13 12:30:36 --> Input Class Initialized
DEBUG - 2020-02-13 12:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:36 --> Security Class Initialized
DEBUG - 2020-02-13 12:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:36 --> Language Class Initialized
INFO - 2020-02-13 12:30:36 --> Input Class Initialized
DEBUG - 2020-02-13 12:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:36 --> Language Class Initialized
INFO - 2020-02-13 12:30:36 --> Input Class Initialized
INFO - 2020-02-13 12:30:36 --> Language Class Initialized
INFO - 2020-02-13 12:30:36 --> Input Class Initialized
INFO - 2020-02-13 12:30:36 --> Language Class Initialized
INFO - 2020-02-13 12:30:36 --> Language Class Initialized
ERROR - 2020-02-13 12:30:36 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 12:30:36 --> Loader Class Initialized
INFO - 2020-02-13 12:30:36 --> Loader Class Initialized
INFO - 2020-02-13 12:30:36 --> Language Class Initialized
ERROR - 2020-02-13 12:30:36 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 12:30:36 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 12:30:36 --> Helper loaded: url_helper
INFO - 2020-02-13 12:30:36 --> Helper loaded: url_helper
INFO - 2020-02-13 12:30:36 --> Config Class Initialized
INFO - 2020-02-13 12:30:36 --> Hooks Class Initialized
INFO - 2020-02-13 12:30:36 --> Helper loaded: string_helper
ERROR - 2020-02-13 12:30:36 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 12:30:36 --> Helper loaded: string_helper
INFO - 2020-02-13 12:30:36 --> Config Class Initialized
INFO - 2020-02-13 12:30:36 --> Config Class Initialized
INFO - 2020-02-13 12:30:36 --> Hooks Class Initialized
INFO - 2020-02-13 12:30:36 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:36 --> Database Driver Class Initialized
INFO - 2020-02-13 12:30:36 --> Database Driver Class Initialized
INFO - 2020-02-13 12:30:36 --> Config Class Initialized
INFO - 2020-02-13 12:30:36 --> Hooks Class Initialized
INFO - 2020-02-13 12:30:36 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:30:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:30:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 12:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:30:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:30:36 --> URI Class Initialized
DEBUG - 2020-02-13 12:30:36 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:36 --> Controller Class Initialized
INFO - 2020-02-13 12:30:36 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:36 --> URI Class Initialized
INFO - 2020-02-13 12:30:36 --> URI Class Initialized
INFO - 2020-02-13 12:30:36 --> Router Class Initialized
INFO - 2020-02-13 12:30:36 --> URI Class Initialized
INFO - 2020-02-13 12:30:36 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:30:36 --> Router Class Initialized
INFO - 2020-02-13 12:30:36 --> Output Class Initialized
INFO - 2020-02-13 12:30:36 --> Router Class Initialized
INFO - 2020-02-13 12:30:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:30:36 --> Security Class Initialized
INFO - 2020-02-13 12:30:36 --> Router Class Initialized
INFO - 2020-02-13 12:30:36 --> Output Class Initialized
INFO - 2020-02-13 12:30:36 --> Output Class Initialized
INFO - 2020-02-13 12:30:36 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 12:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:36 --> Security Class Initialized
INFO - 2020-02-13 12:30:36 --> Output Class Initialized
INFO - 2020-02-13 12:30:36 --> Security Class Initialized
INFO - 2020-02-13 12:30:36 --> Input Class Initialized
DEBUG - 2020-02-13 12:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:36 --> Security Class Initialized
DEBUG - 2020-02-13 12:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:36 --> Helper loaded: form_helper
INFO - 2020-02-13 12:30:36 --> Form Validation Class Initialized
INFO - 2020-02-13 12:30:36 --> Input Class Initialized
INFO - 2020-02-13 12:30:36 --> Input Class Initialized
INFO - 2020-02-13 12:30:36 --> Language Class Initialized
DEBUG - 2020-02-13 12:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:36 --> Input Class Initialized
INFO - 2020-02-13 12:30:36 --> Language Class Initialized
INFO - 2020-02-13 12:30:36 --> Language Class Initialized
ERROR - 2020-02-13 12:30:36 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 12:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:30:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:30:37 --> Language Class Initialized
ERROR - 2020-02-13 12:30:37 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 12:30:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:30:37 --> Config Class Initialized
INFO - 2020-02-13 12:30:37 --> Hooks Class Initialized
INFO - 2020-02-13 12:30:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 12:30:37 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 12:30:37 --> Config Class Initialized
INFO - 2020-02-13 12:30:37 --> Config Class Initialized
INFO - 2020-02-13 12:30:37 --> Hooks Class Initialized
INFO - 2020-02-13 12:30:37 --> Hooks Class Initialized
INFO - 2020-02-13 12:30:37 --> Final output sent to browser
DEBUG - 2020-02-13 12:30:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:37 --> Config Class Initialized
INFO - 2020-02-13 12:30:37 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:37 --> Total execution time: 0.7824
INFO - 2020-02-13 12:30:37 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:30:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:30:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:37 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:30:37 --> URI Class Initialized
INFO - 2020-02-13 12:30:37 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:30:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:37 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:37 --> Controller Class Initialized
INFO - 2020-02-13 12:30:37 --> URI Class Initialized
INFO - 2020-02-13 12:30:37 --> URI Class Initialized
INFO - 2020-02-13 12:30:37 --> Router Class Initialized
INFO - 2020-02-13 12:30:37 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:30:37 --> Router Class Initialized
INFO - 2020-02-13 12:30:37 --> Output Class Initialized
INFO - 2020-02-13 12:30:37 --> Router Class Initialized
INFO - 2020-02-13 12:30:37 --> URI Class Initialized
INFO - 2020-02-13 12:30:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:30:37 --> Router Class Initialized
INFO - 2020-02-13 12:30:37 --> Output Class Initialized
INFO - 2020-02-13 12:30:37 --> Output Class Initialized
INFO - 2020-02-13 12:30:37 --> Security Class Initialized
INFO - 2020-02-13 12:30:37 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 12:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:37 --> Security Class Initialized
INFO - 2020-02-13 12:30:37 --> Security Class Initialized
INFO - 2020-02-13 12:30:37 --> Output Class Initialized
INFO - 2020-02-13 12:30:37 --> Input Class Initialized
DEBUG - 2020-02-13 12:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:37 --> Security Class Initialized
INFO - 2020-02-13 12:30:37 --> Helper loaded: form_helper
INFO - 2020-02-13 12:30:37 --> Form Validation Class Initialized
INFO - 2020-02-13 12:30:37 --> Input Class Initialized
INFO - 2020-02-13 12:30:37 --> Input Class Initialized
INFO - 2020-02-13 12:30:37 --> Language Class Initialized
DEBUG - 2020-02-13 12:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:37 --> Input Class Initialized
INFO - 2020-02-13 12:30:37 --> Language Class Initialized
INFO - 2020-02-13 12:30:37 --> Language Class Initialized
ERROR - 2020-02-13 12:30:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 12:30:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:30:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:30:37 --> Language Class Initialized
ERROR - 2020-02-13 12:30:37 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 12:30:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 12:30:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 12:30:37 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 12:30:37 --> Final output sent to browser
INFO - 2020-02-13 12:30:37 --> Config Class Initialized
INFO - 2020-02-13 12:30:37 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:37 --> Total execution time: 1.1376
DEBUG - 2020-02-13 12:30:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:37 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:37 --> URI Class Initialized
INFO - 2020-02-13 12:30:37 --> Router Class Initialized
INFO - 2020-02-13 12:30:37 --> Output Class Initialized
INFO - 2020-02-13 12:30:37 --> Security Class Initialized
DEBUG - 2020-02-13 12:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:37 --> Input Class Initialized
INFO - 2020-02-13 12:30:37 --> Language Class Initialized
ERROR - 2020-02-13 12:30:37 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 12:30:37 --> Config Class Initialized
INFO - 2020-02-13 12:30:37 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:37 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:37 --> URI Class Initialized
INFO - 2020-02-13 12:30:37 --> Router Class Initialized
INFO - 2020-02-13 12:30:37 --> Output Class Initialized
INFO - 2020-02-13 12:30:37 --> Security Class Initialized
DEBUG - 2020-02-13 12:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:37 --> Input Class Initialized
INFO - 2020-02-13 12:30:38 --> Language Class Initialized
ERROR - 2020-02-13 12:30:38 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 12:30:38 --> Config Class Initialized
INFO - 2020-02-13 12:30:38 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:38 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:38 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:38 --> URI Class Initialized
INFO - 2020-02-13 12:30:38 --> Router Class Initialized
INFO - 2020-02-13 12:30:38 --> Output Class Initialized
INFO - 2020-02-13 12:30:38 --> Security Class Initialized
DEBUG - 2020-02-13 12:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:38 --> Input Class Initialized
INFO - 2020-02-13 12:30:38 --> Language Class Initialized
ERROR - 2020-02-13 12:30:38 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:30:38 --> Config Class Initialized
INFO - 2020-02-13 12:30:38 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:38 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:38 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:38 --> URI Class Initialized
INFO - 2020-02-13 12:30:38 --> Router Class Initialized
INFO - 2020-02-13 12:30:38 --> Output Class Initialized
INFO - 2020-02-13 12:30:38 --> Security Class Initialized
DEBUG - 2020-02-13 12:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:38 --> Input Class Initialized
INFO - 2020-02-13 12:30:38 --> Language Class Initialized
ERROR - 2020-02-13 12:30:38 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:30:38 --> Config Class Initialized
INFO - 2020-02-13 12:30:38 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:38 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:38 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:38 --> URI Class Initialized
INFO - 2020-02-13 12:30:38 --> Router Class Initialized
INFO - 2020-02-13 12:30:38 --> Output Class Initialized
INFO - 2020-02-13 12:30:38 --> Security Class Initialized
DEBUG - 2020-02-13 12:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:38 --> Input Class Initialized
INFO - 2020-02-13 12:30:39 --> Language Class Initialized
ERROR - 2020-02-13 12:30:39 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 12:30:39 --> Config Class Initialized
INFO - 2020-02-13 12:30:39 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:39 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:39 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:39 --> URI Class Initialized
INFO - 2020-02-13 12:30:39 --> Router Class Initialized
INFO - 2020-02-13 12:30:39 --> Output Class Initialized
INFO - 2020-02-13 12:30:39 --> Security Class Initialized
DEBUG - 2020-02-13 12:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:39 --> Input Class Initialized
INFO - 2020-02-13 12:30:39 --> Language Class Initialized
ERROR - 2020-02-13 12:30:39 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 12:30:39 --> Config Class Initialized
INFO - 2020-02-13 12:30:39 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:39 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:39 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:39 --> URI Class Initialized
INFO - 2020-02-13 12:30:39 --> Router Class Initialized
INFO - 2020-02-13 12:30:39 --> Output Class Initialized
INFO - 2020-02-13 12:30:39 --> Security Class Initialized
DEBUG - 2020-02-13 12:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:39 --> Input Class Initialized
INFO - 2020-02-13 12:30:39 --> Language Class Initialized
ERROR - 2020-02-13 12:30:39 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 12:30:39 --> Config Class Initialized
INFO - 2020-02-13 12:30:39 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:39 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:39 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:39 --> URI Class Initialized
INFO - 2020-02-13 12:30:39 --> Router Class Initialized
INFO - 2020-02-13 12:30:39 --> Output Class Initialized
INFO - 2020-02-13 12:30:39 --> Security Class Initialized
DEBUG - 2020-02-13 12:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:40 --> Input Class Initialized
INFO - 2020-02-13 12:30:40 --> Language Class Initialized
ERROR - 2020-02-13 12:30:40 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 12:30:50 --> Config Class Initialized
INFO - 2020-02-13 12:30:50 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:30:50 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:30:50 --> Utf8 Class Initialized
INFO - 2020-02-13 12:30:50 --> URI Class Initialized
INFO - 2020-02-13 12:30:50 --> Router Class Initialized
INFO - 2020-02-13 12:30:50 --> Output Class Initialized
INFO - 2020-02-13 12:30:50 --> Security Class Initialized
DEBUG - 2020-02-13 12:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:30:50 --> Input Class Initialized
INFO - 2020-02-13 12:30:50 --> Language Class Initialized
INFO - 2020-02-13 12:30:50 --> Loader Class Initialized
INFO - 2020-02-13 12:30:50 --> Helper loaded: url_helper
INFO - 2020-02-13 12:30:50 --> Helper loaded: string_helper
INFO - 2020-02-13 12:30:50 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:30:50 --> Controller Class Initialized
INFO - 2020-02-13 12:30:50 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:30:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:30:50 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:30:50 --> Helper loaded: form_helper
INFO - 2020-02-13 12:30:50 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:30:50 --> Severity: Notice --> Undefined variable: idpesan C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
ERROR - 2020-02-13 12:30:50 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
INFO - 2020-02-13 12:31:14 --> Config Class Initialized
INFO - 2020-02-13 12:31:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:31:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:31:14 --> Utf8 Class Initialized
INFO - 2020-02-13 12:31:14 --> URI Class Initialized
INFO - 2020-02-13 12:31:14 --> Router Class Initialized
INFO - 2020-02-13 12:31:14 --> Output Class Initialized
INFO - 2020-02-13 12:31:14 --> Security Class Initialized
DEBUG - 2020-02-13 12:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:31:14 --> Input Class Initialized
INFO - 2020-02-13 12:31:14 --> Language Class Initialized
INFO - 2020-02-13 12:31:14 --> Loader Class Initialized
INFO - 2020-02-13 12:31:14 --> Helper loaded: url_helper
INFO - 2020-02-13 12:31:14 --> Helper loaded: string_helper
INFO - 2020-02-13 12:31:14 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:31:14 --> Controller Class Initialized
INFO - 2020-02-13 12:31:14 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:31:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:31:14 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:31:14 --> Helper loaded: form_helper
INFO - 2020-02-13 12:31:14 --> Form Validation Class Initialized
INFO - 2020-02-13 12:31:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 12:31:14 --> Final output sent to browser
DEBUG - 2020-02-13 12:31:14 --> Total execution time: 0.7964
INFO - 2020-02-13 12:31:45 --> Config Class Initialized
INFO - 2020-02-13 12:31:45 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:31:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:31:45 --> Utf8 Class Initialized
INFO - 2020-02-13 12:31:45 --> URI Class Initialized
INFO - 2020-02-13 12:31:45 --> Router Class Initialized
INFO - 2020-02-13 12:31:45 --> Output Class Initialized
INFO - 2020-02-13 12:31:45 --> Security Class Initialized
DEBUG - 2020-02-13 12:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:31:45 --> Input Class Initialized
INFO - 2020-02-13 12:31:45 --> Language Class Initialized
INFO - 2020-02-13 12:31:45 --> Loader Class Initialized
INFO - 2020-02-13 12:31:45 --> Helper loaded: url_helper
INFO - 2020-02-13 12:31:45 --> Helper loaded: string_helper
INFO - 2020-02-13 12:31:45 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:31:45 --> Controller Class Initialized
INFO - 2020-02-13 12:31:45 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:31:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:31:45 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:31:45 --> Helper loaded: form_helper
INFO - 2020-02-13 12:31:46 --> Form Validation Class Initialized
INFO - 2020-02-13 12:31:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:31:46 --> Final output sent to browser
INFO - 2020-02-13 12:31:46 --> Config Class Initialized
INFO - 2020-02-13 12:31:46 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:31:46 --> Total execution time: 0.6711
INFO - 2020-02-13 12:31:46 --> Config Class Initialized
INFO - 2020-02-13 12:31:46 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:31:46 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:31:46 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:31:46 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:31:46 --> Utf8 Class Initialized
INFO - 2020-02-13 12:31:46 --> URI Class Initialized
INFO - 2020-02-13 12:31:46 --> URI Class Initialized
INFO - 2020-02-13 12:31:46 --> Router Class Initialized
INFO - 2020-02-13 12:31:46 --> Router Class Initialized
INFO - 2020-02-13 12:31:46 --> Output Class Initialized
INFO - 2020-02-13 12:31:46 --> Security Class Initialized
INFO - 2020-02-13 12:31:46 --> Output Class Initialized
DEBUG - 2020-02-13 12:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:31:46 --> Security Class Initialized
INFO - 2020-02-13 12:31:46 --> Input Class Initialized
DEBUG - 2020-02-13 12:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:31:46 --> Input Class Initialized
INFO - 2020-02-13 12:31:46 --> Language Class Initialized
INFO - 2020-02-13 12:31:46 --> Language Class Initialized
ERROR - 2020-02-13 12:31:46 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 12:31:46 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 12:32:12 --> Config Class Initialized
INFO - 2020-02-13 12:32:12 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:32:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:32:12 --> Utf8 Class Initialized
INFO - 2020-02-13 12:32:12 --> URI Class Initialized
INFO - 2020-02-13 12:32:12 --> Router Class Initialized
INFO - 2020-02-13 12:32:12 --> Output Class Initialized
INFO - 2020-02-13 12:32:12 --> Security Class Initialized
DEBUG - 2020-02-13 12:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:32:12 --> Input Class Initialized
INFO - 2020-02-13 12:32:12 --> Language Class Initialized
INFO - 2020-02-13 12:32:12 --> Loader Class Initialized
INFO - 2020-02-13 12:32:12 --> Helper loaded: url_helper
INFO - 2020-02-13 12:32:12 --> Helper loaded: string_helper
INFO - 2020-02-13 12:32:12 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:32:12 --> Controller Class Initialized
INFO - 2020-02-13 12:32:12 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:32:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:32:12 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:32:12 --> Helper loaded: form_helper
INFO - 2020-02-13 12:32:12 --> Form Validation Class Initialized
INFO - 2020-02-13 12:32:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 12:32:13 --> Final output sent to browser
DEBUG - 2020-02-13 12:32:13 --> Total execution time: 0.9107
INFO - 2020-02-13 12:34:10 --> Config Class Initialized
INFO - 2020-02-13 12:34:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:10 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:10 --> URI Class Initialized
INFO - 2020-02-13 12:34:10 --> Router Class Initialized
INFO - 2020-02-13 12:34:10 --> Output Class Initialized
INFO - 2020-02-13 12:34:10 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:10 --> Input Class Initialized
INFO - 2020-02-13 12:34:11 --> Language Class Initialized
INFO - 2020-02-13 12:34:11 --> Loader Class Initialized
INFO - 2020-02-13 12:34:11 --> Helper loaded: url_helper
INFO - 2020-02-13 12:34:11 --> Helper loaded: string_helper
INFO - 2020-02-13 12:34:11 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:34:11 --> Controller Class Initialized
INFO - 2020-02-13 12:34:11 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:34:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:34:11 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:34:11 --> Helper loaded: form_helper
INFO - 2020-02-13 12:34:11 --> Form Validation Class Initialized
INFO - 2020-02-13 12:34:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:34:11 --> Final output sent to browser
INFO - 2020-02-13 12:34:11 --> Config Class Initialized
INFO - 2020-02-13 12:34:11 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:11 --> Total execution time: 0.7147
INFO - 2020-02-13 12:34:11 --> Config Class Initialized
INFO - 2020-02-13 12:34:11 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:11 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:11 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:34:11 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:11 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:11 --> URI Class Initialized
INFO - 2020-02-13 12:34:11 --> URI Class Initialized
INFO - 2020-02-13 12:34:11 --> Router Class Initialized
INFO - 2020-02-13 12:34:11 --> Router Class Initialized
INFO - 2020-02-13 12:34:11 --> Output Class Initialized
INFO - 2020-02-13 12:34:11 --> Security Class Initialized
INFO - 2020-02-13 12:34:11 --> Output Class Initialized
DEBUG - 2020-02-13 12:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:11 --> Security Class Initialized
INFO - 2020-02-13 12:34:11 --> Input Class Initialized
DEBUG - 2020-02-13 12:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:11 --> Input Class Initialized
INFO - 2020-02-13 12:34:11 --> Language Class Initialized
INFO - 2020-02-13 12:34:11 --> Language Class Initialized
INFO - 2020-02-13 12:34:11 --> Loader Class Initialized
INFO - 2020-02-13 12:34:11 --> Helper loaded: url_helper
INFO - 2020-02-13 12:34:11 --> Loader Class Initialized
INFO - 2020-02-13 12:34:11 --> Helper loaded: string_helper
INFO - 2020-02-13 12:34:11 --> Helper loaded: url_helper
INFO - 2020-02-13 12:34:11 --> Helper loaded: string_helper
INFO - 2020-02-13 12:34:12 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:34:12 --> Database Driver Class Initialized
INFO - 2020-02-13 12:34:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 12:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:34:12 --> Controller Class Initialized
INFO - 2020-02-13 12:34:12 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:34:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:34:12 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:34:12 --> Helper loaded: form_helper
INFO - 2020-02-13 12:34:12 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:34:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:34:12 --> Final output sent to browser
DEBUG - 2020-02-13 12:34:12 --> Total execution time: 0.8203
INFO - 2020-02-13 12:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:34:12 --> Controller Class Initialized
INFO - 2020-02-13 12:34:12 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:34:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:34:12 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:34:12 --> Helper loaded: form_helper
INFO - 2020-02-13 12:34:12 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:34:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:34:12 --> Final output sent to browser
DEBUG - 2020-02-13 12:34:12 --> Total execution time: 1.1098
INFO - 2020-02-13 12:34:19 --> Config Class Initialized
INFO - 2020-02-13 12:34:19 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:19 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:19 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:19 --> URI Class Initialized
INFO - 2020-02-13 12:34:19 --> Router Class Initialized
INFO - 2020-02-13 12:34:19 --> Output Class Initialized
INFO - 2020-02-13 12:34:19 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:19 --> Input Class Initialized
INFO - 2020-02-13 12:34:19 --> Language Class Initialized
INFO - 2020-02-13 12:34:19 --> Loader Class Initialized
INFO - 2020-02-13 12:34:19 --> Helper loaded: url_helper
INFO - 2020-02-13 12:34:19 --> Helper loaded: string_helper
INFO - 2020-02-13 12:34:19 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:34:19 --> Controller Class Initialized
INFO - 2020-02-13 12:34:20 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:34:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:34:20 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:34:20 --> Helper loaded: form_helper
INFO - 2020-02-13 12:34:20 --> Form Validation Class Initialized
INFO - 2020-02-13 12:34:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:34:20 --> Final output sent to browser
INFO - 2020-02-13 12:34:20 --> Config Class Initialized
INFO - 2020-02-13 12:34:20 --> Config Class Initialized
INFO - 2020-02-13 12:34:20 --> Config Class Initialized
INFO - 2020-02-13 12:34:20 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:20 --> Total execution time: 0.7204
INFO - 2020-02-13 12:34:20 --> Hooks Class Initialized
INFO - 2020-02-13 12:34:20 --> Config Class Initialized
INFO - 2020-02-13 12:34:20 --> Config Class Initialized
INFO - 2020-02-13 12:34:20 --> Hooks Class Initialized
INFO - 2020-02-13 12:34:20 --> Hooks Class Initialized
INFO - 2020-02-13 12:34:20 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:34:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:20 --> Config Class Initialized
INFO - 2020-02-13 12:34:20 --> Hooks Class Initialized
INFO - 2020-02-13 12:34:20 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:20 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:34:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:20 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:20 --> URI Class Initialized
INFO - 2020-02-13 12:34:20 --> URI Class Initialized
INFO - 2020-02-13 12:34:20 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:20 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:34:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:20 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:20 --> URI Class Initialized
INFO - 2020-02-13 12:34:20 --> URI Class Initialized
INFO - 2020-02-13 12:34:20 --> URI Class Initialized
INFO - 2020-02-13 12:34:20 --> Router Class Initialized
INFO - 2020-02-13 12:34:20 --> Router Class Initialized
INFO - 2020-02-13 12:34:20 --> Router Class Initialized
INFO - 2020-02-13 12:34:20 --> Router Class Initialized
INFO - 2020-02-13 12:34:20 --> Router Class Initialized
INFO - 2020-02-13 12:34:20 --> URI Class Initialized
INFO - 2020-02-13 12:34:20 --> Output Class Initialized
INFO - 2020-02-13 12:34:20 --> Output Class Initialized
INFO - 2020-02-13 12:34:20 --> Security Class Initialized
INFO - 2020-02-13 12:34:20 --> Router Class Initialized
INFO - 2020-02-13 12:34:20 --> Security Class Initialized
INFO - 2020-02-13 12:34:20 --> Output Class Initialized
INFO - 2020-02-13 12:34:20 --> Output Class Initialized
INFO - 2020-02-13 12:34:20 --> Output Class Initialized
DEBUG - 2020-02-13 12:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:20 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:20 --> Output Class Initialized
INFO - 2020-02-13 12:34:20 --> Security Class Initialized
INFO - 2020-02-13 12:34:20 --> Security Class Initialized
INFO - 2020-02-13 12:34:20 --> Input Class Initialized
INFO - 2020-02-13 12:34:20 --> Input Class Initialized
DEBUG - 2020-02-13 12:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:20 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:20 --> Input Class Initialized
INFO - 2020-02-13 12:34:20 --> Input Class Initialized
INFO - 2020-02-13 12:34:20 --> Language Class Initialized
INFO - 2020-02-13 12:34:20 --> Input Class Initialized
INFO - 2020-02-13 12:34:20 --> Language Class Initialized
DEBUG - 2020-02-13 12:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:20 --> Input Class Initialized
INFO - 2020-02-13 12:34:20 --> Language Class Initialized
INFO - 2020-02-13 12:34:20 --> Language Class Initialized
ERROR - 2020-02-13 12:34:20 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 12:34:20 --> Language Class Initialized
INFO - 2020-02-13 12:34:20 --> Loader Class Initialized
INFO - 2020-02-13 12:34:20 --> Language Class Initialized
ERROR - 2020-02-13 12:34:20 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 12:34:20 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 12:34:20 --> Helper loaded: url_helper
INFO - 2020-02-13 12:34:20 --> Loader Class Initialized
INFO - 2020-02-13 12:34:20 --> Config Class Initialized
INFO - 2020-02-13 12:34:20 --> Hooks Class Initialized
INFO - 2020-02-13 12:34:20 --> Helper loaded: string_helper
ERROR - 2020-02-13 12:34:20 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 12:34:20 --> Helper loaded: url_helper
INFO - 2020-02-13 12:34:20 --> Config Class Initialized
INFO - 2020-02-13 12:34:20 --> Config Class Initialized
INFO - 2020-02-13 12:34:20 --> Hooks Class Initialized
INFO - 2020-02-13 12:34:20 --> Hooks Class Initialized
INFO - 2020-02-13 12:34:20 --> Helper loaded: string_helper
DEBUG - 2020-02-13 12:34:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:20 --> Database Driver Class Initialized
INFO - 2020-02-13 12:34:20 --> Config Class Initialized
INFO - 2020-02-13 12:34:20 --> Hooks Class Initialized
INFO - 2020-02-13 12:34:20 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:34:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:20 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:34:20 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:34:20 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:20 --> URI Class Initialized
DEBUG - 2020-02-13 12:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:34:20 --> URI Class Initialized
INFO - 2020-02-13 12:34:20 --> URI Class Initialized
INFO - 2020-02-13 12:34:20 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:20 --> Controller Class Initialized
INFO - 2020-02-13 12:34:20 --> Router Class Initialized
INFO - 2020-02-13 12:34:20 --> URI Class Initialized
INFO - 2020-02-13 12:34:20 --> Router Class Initialized
INFO - 2020-02-13 12:34:20 --> Output Class Initialized
INFO - 2020-02-13 12:34:20 --> Router Class Initialized
INFO - 2020-02-13 12:34:20 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:34:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:34:20 --> Security Class Initialized
INFO - 2020-02-13 12:34:20 --> Router Class Initialized
INFO - 2020-02-13 12:34:20 --> Output Class Initialized
INFO - 2020-02-13 12:34:20 --> Output Class Initialized
INFO - 2020-02-13 12:34:20 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:34:20 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:20 --> Security Class Initialized
INFO - 2020-02-13 12:34:20 --> Output Class Initialized
INFO - 2020-02-13 12:34:20 --> Input Class Initialized
DEBUG - 2020-02-13 12:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:20 --> Security Class Initialized
INFO - 2020-02-13 12:34:20 --> Helper loaded: form_helper
INFO - 2020-02-13 12:34:20 --> Input Class Initialized
INFO - 2020-02-13 12:34:20 --> Input Class Initialized
INFO - 2020-02-13 12:34:20 --> Form Validation Class Initialized
INFO - 2020-02-13 12:34:20 --> Language Class Initialized
DEBUG - 2020-02-13 12:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:20 --> Input Class Initialized
INFO - 2020-02-13 12:34:20 --> Language Class Initialized
INFO - 2020-02-13 12:34:20 --> Language Class Initialized
ERROR - 2020-02-13 12:34:20 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 12:34:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-13 12:34:21 --> Language Class Initialized
ERROR - 2020-02-13 12:34:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 12:34:21 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 12:34:21 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:34:21 --> Config Class Initialized
INFO - 2020-02-13 12:34:21 --> Hooks Class Initialized
ERROR - 2020-02-13 12:34:21 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 12:34:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:34:21 --> Config Class Initialized
INFO - 2020-02-13 12:34:21 --> Config Class Initialized
INFO - 2020-02-13 12:34:21 --> Hooks Class Initialized
INFO - 2020-02-13 12:34:21 --> Hooks Class Initialized
INFO - 2020-02-13 12:34:21 --> Final output sent to browser
DEBUG - 2020-02-13 12:34:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:21 --> Config Class Initialized
INFO - 2020-02-13 12:34:21 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:21 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:21 --> Total execution time: 0.8525
DEBUG - 2020-02-13 12:34:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:34:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:21 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:34:21 --> URI Class Initialized
INFO - 2020-02-13 12:34:21 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:34:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:21 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:21 --> Controller Class Initialized
INFO - 2020-02-13 12:34:21 --> URI Class Initialized
INFO - 2020-02-13 12:34:21 --> URI Class Initialized
INFO - 2020-02-13 12:34:21 --> Router Class Initialized
INFO - 2020-02-13 12:34:21 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:34:21 --> URI Class Initialized
INFO - 2020-02-13 12:34:21 --> Router Class Initialized
INFO - 2020-02-13 12:34:21 --> Output Class Initialized
INFO - 2020-02-13 12:34:21 --> Router Class Initialized
INFO - 2020-02-13 12:34:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:34:21 --> Router Class Initialized
INFO - 2020-02-13 12:34:21 --> Security Class Initialized
INFO - 2020-02-13 12:34:21 --> Output Class Initialized
INFO - 2020-02-13 12:34:21 --> Output Class Initialized
INFO - 2020-02-13 12:34:21 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:34:21 --> Security Class Initialized
INFO - 2020-02-13 12:34:21 --> Security Class Initialized
INFO - 2020-02-13 12:34:21 --> Output Class Initialized
DEBUG - 2020-02-13 12:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:21 --> Input Class Initialized
INFO - 2020-02-13 12:34:21 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:21 --> Helper loaded: form_helper
INFO - 2020-02-13 12:34:21 --> Form Validation Class Initialized
INFO - 2020-02-13 12:34:21 --> Input Class Initialized
INFO - 2020-02-13 12:34:21 --> Input Class Initialized
INFO - 2020-02-13 12:34:21 --> Language Class Initialized
DEBUG - 2020-02-13 12:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:21 --> Input Class Initialized
INFO - 2020-02-13 12:34:21 --> Language Class Initialized
INFO - 2020-02-13 12:34:21 --> Language Class Initialized
ERROR - 2020-02-13 12:34:21 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 12:34:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:34:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 12:34:21 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 12:34:21 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 12:34:21 --> Language Class Initialized
INFO - 2020-02-13 12:34:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 12:34:21 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 12:34:21 --> Final output sent to browser
INFO - 2020-02-13 12:34:21 --> Config Class Initialized
DEBUG - 2020-02-13 12:34:21 --> Total execution time: 1.2147
INFO - 2020-02-13 12:34:21 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:21 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:21 --> URI Class Initialized
INFO - 2020-02-13 12:34:21 --> Router Class Initialized
INFO - 2020-02-13 12:34:21 --> Output Class Initialized
INFO - 2020-02-13 12:34:21 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:21 --> Input Class Initialized
INFO - 2020-02-13 12:34:21 --> Language Class Initialized
ERROR - 2020-02-13 12:34:21 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 12:34:21 --> Config Class Initialized
INFO - 2020-02-13 12:34:21 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:21 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:21 --> URI Class Initialized
INFO - 2020-02-13 12:34:21 --> Router Class Initialized
INFO - 2020-02-13 12:34:21 --> Output Class Initialized
INFO - 2020-02-13 12:34:22 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:22 --> Input Class Initialized
INFO - 2020-02-13 12:34:22 --> Language Class Initialized
ERROR - 2020-02-13 12:34:22 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 12:34:22 --> Config Class Initialized
INFO - 2020-02-13 12:34:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:22 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:22 --> URI Class Initialized
INFO - 2020-02-13 12:34:22 --> Router Class Initialized
INFO - 2020-02-13 12:34:22 --> Output Class Initialized
INFO - 2020-02-13 12:34:22 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:22 --> Input Class Initialized
INFO - 2020-02-13 12:34:22 --> Language Class Initialized
ERROR - 2020-02-13 12:34:22 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 12:34:22 --> Config Class Initialized
INFO - 2020-02-13 12:34:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:22 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:22 --> URI Class Initialized
INFO - 2020-02-13 12:34:22 --> Router Class Initialized
INFO - 2020-02-13 12:34:22 --> Output Class Initialized
INFO - 2020-02-13 12:34:22 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:22 --> Input Class Initialized
INFO - 2020-02-13 12:34:22 --> Language Class Initialized
ERROR - 2020-02-13 12:34:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:34:22 --> Config Class Initialized
INFO - 2020-02-13 12:34:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:22 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:22 --> URI Class Initialized
INFO - 2020-02-13 12:34:23 --> Router Class Initialized
INFO - 2020-02-13 12:34:23 --> Output Class Initialized
INFO - 2020-02-13 12:34:23 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:23 --> Input Class Initialized
INFO - 2020-02-13 12:34:23 --> Language Class Initialized
ERROR - 2020-02-13 12:34:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:34:23 --> Config Class Initialized
INFO - 2020-02-13 12:34:23 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:23 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:23 --> URI Class Initialized
INFO - 2020-02-13 12:34:23 --> Router Class Initialized
INFO - 2020-02-13 12:34:23 --> Output Class Initialized
INFO - 2020-02-13 12:34:23 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:23 --> Input Class Initialized
INFO - 2020-02-13 12:34:23 --> Language Class Initialized
ERROR - 2020-02-13 12:34:23 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 12:34:23 --> Config Class Initialized
INFO - 2020-02-13 12:34:23 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:23 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:23 --> URI Class Initialized
INFO - 2020-02-13 12:34:23 --> Router Class Initialized
INFO - 2020-02-13 12:34:23 --> Output Class Initialized
INFO - 2020-02-13 12:34:23 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:23 --> Input Class Initialized
INFO - 2020-02-13 12:34:23 --> Language Class Initialized
ERROR - 2020-02-13 12:34:23 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 12:34:23 --> Config Class Initialized
INFO - 2020-02-13 12:34:23 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:23 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:24 --> URI Class Initialized
INFO - 2020-02-13 12:34:24 --> Router Class Initialized
INFO - 2020-02-13 12:34:24 --> Output Class Initialized
INFO - 2020-02-13 12:34:24 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:24 --> Input Class Initialized
INFO - 2020-02-13 12:34:24 --> Language Class Initialized
ERROR - 2020-02-13 12:34:24 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 12:34:24 --> Config Class Initialized
INFO - 2020-02-13 12:34:24 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:24 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:24 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:24 --> URI Class Initialized
INFO - 2020-02-13 12:34:24 --> Router Class Initialized
INFO - 2020-02-13 12:34:24 --> Output Class Initialized
INFO - 2020-02-13 12:34:24 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:24 --> Input Class Initialized
INFO - 2020-02-13 12:34:24 --> Language Class Initialized
ERROR - 2020-02-13 12:34:24 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 12:34:49 --> Config Class Initialized
INFO - 2020-02-13 12:34:49 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:34:49 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:34:49 --> Utf8 Class Initialized
INFO - 2020-02-13 12:34:49 --> URI Class Initialized
INFO - 2020-02-13 12:34:49 --> Router Class Initialized
INFO - 2020-02-13 12:34:49 --> Output Class Initialized
INFO - 2020-02-13 12:34:49 --> Security Class Initialized
DEBUG - 2020-02-13 12:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:34:49 --> Input Class Initialized
INFO - 2020-02-13 12:34:49 --> Language Class Initialized
INFO - 2020-02-13 12:34:49 --> Loader Class Initialized
INFO - 2020-02-13 12:34:49 --> Helper loaded: url_helper
INFO - 2020-02-13 12:34:49 --> Helper loaded: string_helper
INFO - 2020-02-13 12:34:49 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:34:50 --> Controller Class Initialized
INFO - 2020-02-13 12:34:50 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:34:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:34:50 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:34:50 --> Helper loaded: form_helper
INFO - 2020-02-13 12:34:50 --> Form Validation Class Initialized
INFO - 2020-02-13 12:34:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 12:34:50 --> Final output sent to browser
DEBUG - 2020-02-13 12:34:50 --> Total execution time: 0.8454
INFO - 2020-02-13 12:36:01 --> Config Class Initialized
INFO - 2020-02-13 12:36:01 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:36:01 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:01 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:01 --> URI Class Initialized
INFO - 2020-02-13 12:36:01 --> Router Class Initialized
INFO - 2020-02-13 12:36:01 --> Output Class Initialized
INFO - 2020-02-13 12:36:01 --> Security Class Initialized
DEBUG - 2020-02-13 12:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:01 --> Input Class Initialized
INFO - 2020-02-13 12:36:01 --> Language Class Initialized
INFO - 2020-02-13 12:36:01 --> Loader Class Initialized
INFO - 2020-02-13 12:36:01 --> Helper loaded: url_helper
INFO - 2020-02-13 12:36:01 --> Helper loaded: string_helper
INFO - 2020-02-13 12:36:01 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:36:01 --> Controller Class Initialized
INFO - 2020-02-13 12:36:02 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:36:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:36:02 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:36:02 --> Helper loaded: form_helper
INFO - 2020-02-13 12:36:02 --> Form Validation Class Initialized
INFO - 2020-02-13 12:36:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:36:02 --> Final output sent to browser
DEBUG - 2020-02-13 12:36:02 --> Total execution time: 0.7336
INFO - 2020-02-13 12:36:02 --> Config Class Initialized
INFO - 2020-02-13 12:36:02 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:36:02 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:02 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:02 --> URI Class Initialized
INFO - 2020-02-13 12:36:02 --> Router Class Initialized
INFO - 2020-02-13 12:36:02 --> Output Class Initialized
INFO - 2020-02-13 12:36:02 --> Security Class Initialized
DEBUG - 2020-02-13 12:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:02 --> Input Class Initialized
INFO - 2020-02-13 12:36:02 --> Language Class Initialized
ERROR - 2020-02-13 12:36:02 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 12:36:04 --> Config Class Initialized
INFO - 2020-02-13 12:36:04 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:36:04 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:04 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:04 --> URI Class Initialized
INFO - 2020-02-13 12:36:04 --> Router Class Initialized
INFO - 2020-02-13 12:36:04 --> Output Class Initialized
INFO - 2020-02-13 12:36:04 --> Security Class Initialized
DEBUG - 2020-02-13 12:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:04 --> Input Class Initialized
INFO - 2020-02-13 12:36:04 --> Language Class Initialized
INFO - 2020-02-13 12:36:04 --> Loader Class Initialized
INFO - 2020-02-13 12:36:04 --> Helper loaded: url_helper
INFO - 2020-02-13 12:36:04 --> Helper loaded: string_helper
INFO - 2020-02-13 12:36:04 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:36:04 --> Controller Class Initialized
INFO - 2020-02-13 12:36:04 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:36:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:36:04 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:36:04 --> Helper loaded: form_helper
INFO - 2020-02-13 12:36:04 --> Form Validation Class Initialized
INFO - 2020-02-13 12:36:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:36:04 --> Final output sent to browser
INFO - 2020-02-13 12:36:04 --> Config Class Initialized
INFO - 2020-02-13 12:36:04 --> Config Class Initialized
INFO - 2020-02-13 12:36:04 --> Config Class Initialized
INFO - 2020-02-13 12:36:04 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:36:04 --> Total execution time: 0.6876
INFO - 2020-02-13 12:36:04 --> Hooks Class Initialized
INFO - 2020-02-13 12:36:04 --> Hooks Class Initialized
INFO - 2020-02-13 12:36:04 --> Config Class Initialized
INFO - 2020-02-13 12:36:04 --> Config Class Initialized
INFO - 2020-02-13 12:36:04 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:36:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:36:04 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:04 --> Hooks Class Initialized
INFO - 2020-02-13 12:36:04 --> Config Class Initialized
DEBUG - 2020-02-13 12:36:04 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:04 --> Hooks Class Initialized
INFO - 2020-02-13 12:36:04 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:04 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:04 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:36:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:36:04 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:04 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:04 --> URI Class Initialized
INFO - 2020-02-13 12:36:04 --> URI Class Initialized
INFO - 2020-02-13 12:36:04 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:04 --> URI Class Initialized
DEBUG - 2020-02-13 12:36:04 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:05 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
INFO - 2020-02-13 12:36:05 --> URI Class Initialized
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
INFO - 2020-02-13 12:36:05 --> URI Class Initialized
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
INFO - 2020-02-13 12:36:05 --> URI Class Initialized
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
ERROR - 2020-02-13 12:36:05 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 12:36:05 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-13 12:36:05 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
ERROR - 2020-02-13 12:36:05 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 12:36:05 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 12:36:05 --> Config Class Initialized
INFO - 2020-02-13 12:36:05 --> Config Class Initialized
INFO - 2020-02-13 12:36:05 --> Config Class Initialized
INFO - 2020-02-13 12:36:05 --> Hooks Class Initialized
INFO - 2020-02-13 12:36:05 --> Hooks Class Initialized
INFO - 2020-02-13 12:36:05 --> Hooks Class Initialized
ERROR - 2020-02-13 12:36:05 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:36:05 --> Config Class Initialized
INFO - 2020-02-13 12:36:05 --> Config Class Initialized
INFO - 2020-02-13 12:36:05 --> Hooks Class Initialized
INFO - 2020-02-13 12:36:05 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:36:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:36:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:36:05 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:05 --> Config Class Initialized
INFO - 2020-02-13 12:36:05 --> Hooks Class Initialized
INFO - 2020-02-13 12:36:05 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:05 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:05 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:36:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:36:05 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:05 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:05 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:05 --> URI Class Initialized
INFO - 2020-02-13 12:36:05 --> URI Class Initialized
INFO - 2020-02-13 12:36:05 --> URI Class Initialized
DEBUG - 2020-02-13 12:36:05 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:05 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:05 --> URI Class Initialized
INFO - 2020-02-13 12:36:05 --> URI Class Initialized
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
INFO - 2020-02-13 12:36:05 --> URI Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
ERROR - 2020-02-13 12:36:05 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-13 12:36:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 12:36:05 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
ERROR - 2020-02-13 12:36:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 12:36:05 --> Loader Class Initialized
INFO - 2020-02-13 12:36:05 --> Config Class Initialized
INFO - 2020-02-13 12:36:05 --> Config Class Initialized
INFO - 2020-02-13 12:36:05 --> Hooks Class Initialized
INFO - 2020-02-13 12:36:05 --> Hooks Class Initialized
INFO - 2020-02-13 12:36:05 --> Helper loaded: url_helper
INFO - 2020-02-13 12:36:05 --> Loader Class Initialized
INFO - 2020-02-13 12:36:05 --> Helper loaded: string_helper
INFO - 2020-02-13 12:36:05 --> Helper loaded: url_helper
DEBUG - 2020-02-13 12:36:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:36:05 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:05 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:05 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:05 --> Helper loaded: string_helper
INFO - 2020-02-13 12:36:05 --> Database Driver Class Initialized
INFO - 2020-02-13 12:36:05 --> URI Class Initialized
INFO - 2020-02-13 12:36:05 --> URI Class Initialized
DEBUG - 2020-02-13 12:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:36:05 --> Database Driver Class Initialized
INFO - 2020-02-13 12:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
INFO - 2020-02-13 12:36:05 --> Router Class Initialized
DEBUG - 2020-02-13 12:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:36:05 --> Controller Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
INFO - 2020-02-13 12:36:05 --> Output Class Initialized
INFO - 2020-02-13 12:36:05 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
INFO - 2020-02-13 12:36:05 --> Security Class Initialized
INFO - 2020-02-13 12:36:05 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
INFO - 2020-02-13 12:36:05 --> Input Class Initialized
INFO - 2020-02-13 12:36:05 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
INFO - 2020-02-13 12:36:05 --> Language Class Initialized
INFO - 2020-02-13 12:36:05 --> Helper loaded: form_helper
INFO - 2020-02-13 12:36:05 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:36:05 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-13 12:36:05 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 12:36:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-13 12:36:06 --> Config Class Initialized
INFO - 2020-02-13 12:36:06 --> Hooks Class Initialized
ERROR - 2020-02-13 12:36:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:36:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-13 12:36:06 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:06 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:06 --> Final output sent to browser
DEBUG - 2020-02-13 12:36:06 --> Total execution time: 0.8124
INFO - 2020-02-13 12:36:06 --> URI Class Initialized
INFO - 2020-02-13 12:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:36:06 --> Router Class Initialized
INFO - 2020-02-13 12:36:06 --> Controller Class Initialized
INFO - 2020-02-13 12:36:06 --> Output Class Initialized
INFO - 2020-02-13 12:36:06 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:36:06 --> Security Class Initialized
INFO - 2020-02-13 12:36:06 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-13 12:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:06 --> Input Class Initialized
INFO - 2020-02-13 12:36:06 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:36:06 --> Language Class Initialized
INFO - 2020-02-13 12:36:06 --> Helper loaded: form_helper
INFO - 2020-02-13 12:36:06 --> Form Validation Class Initialized
ERROR - 2020-02-13 12:36:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 12:36:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-13 12:36:06 --> Config Class Initialized
INFO - 2020-02-13 12:36:06 --> Hooks Class Initialized
ERROR - 2020-02-13 12:36:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:36:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-13 12:36:06 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:06 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:06 --> Final output sent to browser
DEBUG - 2020-02-13 12:36:06 --> Total execution time: 1.1185
INFO - 2020-02-13 12:36:06 --> URI Class Initialized
INFO - 2020-02-13 12:36:06 --> Router Class Initialized
INFO - 2020-02-13 12:36:06 --> Output Class Initialized
INFO - 2020-02-13 12:36:06 --> Security Class Initialized
DEBUG - 2020-02-13 12:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:06 --> Input Class Initialized
INFO - 2020-02-13 12:36:06 --> Language Class Initialized
ERROR - 2020-02-13 12:36:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:36:06 --> Config Class Initialized
INFO - 2020-02-13 12:36:06 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:36:06 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:06 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:06 --> URI Class Initialized
INFO - 2020-02-13 12:36:06 --> Router Class Initialized
INFO - 2020-02-13 12:36:06 --> Output Class Initialized
INFO - 2020-02-13 12:36:06 --> Security Class Initialized
DEBUG - 2020-02-13 12:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:06 --> Input Class Initialized
INFO - 2020-02-13 12:36:07 --> Language Class Initialized
ERROR - 2020-02-13 12:36:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:36:07 --> Config Class Initialized
INFO - 2020-02-13 12:36:07 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:36:07 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:07 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:07 --> URI Class Initialized
INFO - 2020-02-13 12:36:07 --> Router Class Initialized
INFO - 2020-02-13 12:36:07 --> Output Class Initialized
INFO - 2020-02-13 12:36:07 --> Security Class Initialized
DEBUG - 2020-02-13 12:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:07 --> Input Class Initialized
INFO - 2020-02-13 12:36:07 --> Language Class Initialized
ERROR - 2020-02-13 12:36:07 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 12:36:07 --> Config Class Initialized
INFO - 2020-02-13 12:36:07 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:36:07 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:07 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:07 --> URI Class Initialized
INFO - 2020-02-13 12:36:07 --> Router Class Initialized
INFO - 2020-02-13 12:36:07 --> Output Class Initialized
INFO - 2020-02-13 12:36:07 --> Security Class Initialized
DEBUG - 2020-02-13 12:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:07 --> Input Class Initialized
INFO - 2020-02-13 12:36:07 --> Language Class Initialized
ERROR - 2020-02-13 12:36:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 12:36:07 --> Config Class Initialized
INFO - 2020-02-13 12:36:07 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:36:07 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:07 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:07 --> URI Class Initialized
INFO - 2020-02-13 12:36:07 --> Router Class Initialized
INFO - 2020-02-13 12:36:07 --> Output Class Initialized
INFO - 2020-02-13 12:36:08 --> Security Class Initialized
DEBUG - 2020-02-13 12:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:08 --> Input Class Initialized
INFO - 2020-02-13 12:36:08 --> Language Class Initialized
ERROR - 2020-02-13 12:36:08 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 12:36:08 --> Config Class Initialized
INFO - 2020-02-13 12:36:08 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:36:08 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:08 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:08 --> URI Class Initialized
INFO - 2020-02-13 12:36:08 --> Router Class Initialized
INFO - 2020-02-13 12:36:08 --> Output Class Initialized
INFO - 2020-02-13 12:36:08 --> Security Class Initialized
DEBUG - 2020-02-13 12:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:08 --> Input Class Initialized
INFO - 2020-02-13 12:36:08 --> Language Class Initialized
ERROR - 2020-02-13 12:36:08 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 12:36:29 --> Config Class Initialized
INFO - 2020-02-13 12:36:29 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:36:29 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:36:29 --> Utf8 Class Initialized
INFO - 2020-02-13 12:36:29 --> URI Class Initialized
INFO - 2020-02-13 12:36:29 --> Router Class Initialized
INFO - 2020-02-13 12:36:29 --> Output Class Initialized
INFO - 2020-02-13 12:36:29 --> Security Class Initialized
DEBUG - 2020-02-13 12:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:36:29 --> Input Class Initialized
INFO - 2020-02-13 12:36:29 --> Language Class Initialized
INFO - 2020-02-13 12:36:29 --> Loader Class Initialized
INFO - 2020-02-13 12:36:29 --> Helper loaded: url_helper
INFO - 2020-02-13 12:36:29 --> Helper loaded: string_helper
INFO - 2020-02-13 12:36:29 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:36:29 --> Controller Class Initialized
INFO - 2020-02-13 12:36:29 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:36:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:36:29 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:36:29 --> Helper loaded: form_helper
INFO - 2020-02-13 12:36:29 --> Form Validation Class Initialized
INFO - 2020-02-13 12:36:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 12:36:29 --> Final output sent to browser
DEBUG - 2020-02-13 12:36:30 --> Total execution time: 0.8992
INFO - 2020-02-13 12:38:05 --> Config Class Initialized
INFO - 2020-02-13 12:38:05 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:05 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:05 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:05 --> URI Class Initialized
INFO - 2020-02-13 12:38:05 --> Router Class Initialized
INFO - 2020-02-13 12:38:05 --> Output Class Initialized
INFO - 2020-02-13 12:38:05 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:05 --> Input Class Initialized
INFO - 2020-02-13 12:38:05 --> Language Class Initialized
INFO - 2020-02-13 12:38:05 --> Loader Class Initialized
INFO - 2020-02-13 12:38:05 --> Helper loaded: url_helper
INFO - 2020-02-13 12:38:05 --> Helper loaded: string_helper
INFO - 2020-02-13 12:38:05 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:38:05 --> Controller Class Initialized
INFO - 2020-02-13 12:38:05 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:38:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:38:05 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:38:06 --> Helper loaded: form_helper
INFO - 2020-02-13 12:38:06 --> Form Validation Class Initialized
INFO - 2020-02-13 12:38:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:38:06 --> Final output sent to browser
INFO - 2020-02-13 12:38:06 --> Config Class Initialized
INFO - 2020-02-13 12:38:06 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:06 --> Total execution time: 0.7473
DEBUG - 2020-02-13 12:38:06 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:06 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:06 --> URI Class Initialized
INFO - 2020-02-13 12:38:06 --> Router Class Initialized
INFO - 2020-02-13 12:38:06 --> Output Class Initialized
INFO - 2020-02-13 12:38:06 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:06 --> Input Class Initialized
INFO - 2020-02-13 12:38:06 --> Language Class Initialized
ERROR - 2020-02-13 12:38:06 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 12:38:07 --> Config Class Initialized
INFO - 2020-02-13 12:38:07 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:07 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:07 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:07 --> URI Class Initialized
INFO - 2020-02-13 12:38:07 --> Router Class Initialized
INFO - 2020-02-13 12:38:07 --> Output Class Initialized
INFO - 2020-02-13 12:38:07 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:07 --> Input Class Initialized
INFO - 2020-02-13 12:38:07 --> Language Class Initialized
INFO - 2020-02-13 12:38:07 --> Loader Class Initialized
INFO - 2020-02-13 12:38:07 --> Helper loaded: url_helper
INFO - 2020-02-13 12:38:08 --> Helper loaded: string_helper
INFO - 2020-02-13 12:38:08 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:38:08 --> Controller Class Initialized
INFO - 2020-02-13 12:38:08 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:38:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:38:08 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:38:08 --> Helper loaded: form_helper
INFO - 2020-02-13 12:38:08 --> Form Validation Class Initialized
INFO - 2020-02-13 12:38:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 12:38:08 --> Final output sent to browser
INFO - 2020-02-13 12:38:08 --> Config Class Initialized
INFO - 2020-02-13 12:38:08 --> Config Class Initialized
INFO - 2020-02-13 12:38:08 --> Config Class Initialized
INFO - 2020-02-13 12:38:08 --> Config Class Initialized
DEBUG - 2020-02-13 12:38:08 --> Total execution time: 0.6987
INFO - 2020-02-13 12:38:08 --> Hooks Class Initialized
INFO - 2020-02-13 12:38:08 --> Hooks Class Initialized
INFO - 2020-02-13 12:38:08 --> Hooks Class Initialized
INFO - 2020-02-13 12:38:08 --> Hooks Class Initialized
INFO - 2020-02-13 12:38:08 --> Config Class Initialized
INFO - 2020-02-13 12:38:08 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:38:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:38:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:38:08 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:08 --> Config Class Initialized
INFO - 2020-02-13 12:38:08 --> Hooks Class Initialized
INFO - 2020-02-13 12:38:08 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:08 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:08 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:08 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:38:08 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:08 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:08 --> URI Class Initialized
INFO - 2020-02-13 12:38:08 --> URI Class Initialized
DEBUG - 2020-02-13 12:38:08 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:08 --> URI Class Initialized
INFO - 2020-02-13 12:38:08 --> URI Class Initialized
INFO - 2020-02-13 12:38:08 --> Router Class Initialized
INFO - 2020-02-13 12:38:08 --> Router Class Initialized
INFO - 2020-02-13 12:38:08 --> Router Class Initialized
INFO - 2020-02-13 12:38:08 --> Router Class Initialized
INFO - 2020-02-13 12:38:08 --> URI Class Initialized
INFO - 2020-02-13 12:38:08 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:08 --> URI Class Initialized
INFO - 2020-02-13 12:38:08 --> Router Class Initialized
INFO - 2020-02-13 12:38:08 --> Output Class Initialized
INFO - 2020-02-13 12:38:08 --> Output Class Initialized
INFO - 2020-02-13 12:38:08 --> Output Class Initialized
INFO - 2020-02-13 12:38:08 --> Output Class Initialized
INFO - 2020-02-13 12:38:08 --> Security Class Initialized
INFO - 2020-02-13 12:38:08 --> Security Class Initialized
INFO - 2020-02-13 12:38:08 --> Security Class Initialized
INFO - 2020-02-13 12:38:08 --> Router Class Initialized
INFO - 2020-02-13 12:38:08 --> Security Class Initialized
INFO - 2020-02-13 12:38:08 --> Output Class Initialized
DEBUG - 2020-02-13 12:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:08 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:08 --> Output Class Initialized
DEBUG - 2020-02-13 12:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:08 --> Input Class Initialized
INFO - 2020-02-13 12:38:08 --> Input Class Initialized
INFO - 2020-02-13 12:38:08 --> Input Class Initialized
INFO - 2020-02-13 12:38:08 --> Input Class Initialized
INFO - 2020-02-13 12:38:08 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:08 --> Input Class Initialized
INFO - 2020-02-13 12:38:08 --> Language Class Initialized
INFO - 2020-02-13 12:38:08 --> Language Class Initialized
DEBUG - 2020-02-13 12:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:08 --> Language Class Initialized
INFO - 2020-02-13 12:38:08 --> Language Class Initialized
INFO - 2020-02-13 12:38:08 --> Input Class Initialized
INFO - 2020-02-13 12:38:08 --> Language Class Initialized
ERROR - 2020-02-13 12:38:08 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 12:38:08 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 12:38:08 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 12:38:08 --> Loader Class Initialized
INFO - 2020-02-13 12:38:08 --> Helper loaded: url_helper
INFO - 2020-02-13 12:38:08 --> Language Class Initialized
INFO - 2020-02-13 12:38:08 --> Loader Class Initialized
INFO - 2020-02-13 12:38:08 --> Config Class Initialized
INFO - 2020-02-13 12:38:08 --> Config Class Initialized
INFO - 2020-02-13 12:38:08 --> Config Class Initialized
INFO - 2020-02-13 12:38:08 --> Hooks Class Initialized
INFO - 2020-02-13 12:38:08 --> Hooks Class Initialized
INFO - 2020-02-13 12:38:08 --> Hooks Class Initialized
INFO - 2020-02-13 12:38:08 --> Helper loaded: string_helper
ERROR - 2020-02-13 12:38:08 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 12:38:08 --> Helper loaded: url_helper
DEBUG - 2020-02-13 12:38:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:38:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:38:08 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:08 --> Helper loaded: string_helper
INFO - 2020-02-13 12:38:08 --> Database Driver Class Initialized
INFO - 2020-02-13 12:38:08 --> Config Class Initialized
INFO - 2020-02-13 12:38:08 --> Hooks Class Initialized
INFO - 2020-02-13 12:38:08 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:08 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:08 --> Utf8 Class Initialized
DEBUG - 2020-02-13 12:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:38:08 --> Database Driver Class Initialized
INFO - 2020-02-13 12:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:38:08 --> URI Class Initialized
INFO - 2020-02-13 12:38:08 --> URI Class Initialized
INFO - 2020-02-13 12:38:08 --> URI Class Initialized
DEBUG - 2020-02-13 12:38:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:38:08 --> Controller Class Initialized
INFO - 2020-02-13 12:38:08 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:08 --> Router Class Initialized
INFO - 2020-02-13 12:38:08 --> Router Class Initialized
INFO - 2020-02-13 12:38:08 --> Router Class Initialized
INFO - 2020-02-13 12:38:08 --> URI Class Initialized
INFO - 2020-02-13 12:38:08 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:38:08 --> Output Class Initialized
INFO - 2020-02-13 12:38:08 --> Output Class Initialized
INFO - 2020-02-13 12:38:08 --> Output Class Initialized
INFO - 2020-02-13 12:38:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:38:09 --> Security Class Initialized
INFO - 2020-02-13 12:38:09 --> Security Class Initialized
INFO - 2020-02-13 12:38:09 --> Router Class Initialized
INFO - 2020-02-13 12:38:09 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:09 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:38:09 --> Output Class Initialized
INFO - 2020-02-13 12:38:09 --> Input Class Initialized
INFO - 2020-02-13 12:38:09 --> Input Class Initialized
INFO - 2020-02-13 12:38:09 --> Input Class Initialized
INFO - 2020-02-13 12:38:09 --> Security Class Initialized
INFO - 2020-02-13 12:38:09 --> Helper loaded: form_helper
INFO - 2020-02-13 12:38:09 --> Language Class Initialized
INFO - 2020-02-13 12:38:09 --> Language Class Initialized
INFO - 2020-02-13 12:38:09 --> Language Class Initialized
DEBUG - 2020-02-13 12:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:09 --> Form Validation Class Initialized
INFO - 2020-02-13 12:38:09 --> Input Class Initialized
ERROR - 2020-02-13 12:38:09 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 12:38:09 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 12:38:09 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 12:38:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:38:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:38:09 --> Language Class Initialized
INFO - 2020-02-13 12:38:09 --> Config Class Initialized
INFO - 2020-02-13 12:38:09 --> Config Class Initialized
INFO - 2020-02-13 12:38:09 --> Config Class Initialized
INFO - 2020-02-13 12:38:09 --> Hooks Class Initialized
INFO - 2020-02-13 12:38:09 --> Hooks Class Initialized
INFO - 2020-02-13 12:38:09 --> Hooks Class Initialized
INFO - 2020-02-13 12:38:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 12:38:09 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 12:38:09 --> Final output sent to browser
DEBUG - 2020-02-13 12:38:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:38:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 12:38:09 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:09 --> Config Class Initialized
INFO - 2020-02-13 12:38:09 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:09 --> Total execution time: 0.8538
INFO - 2020-02-13 12:38:09 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:09 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:09 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:38:09 --> URI Class Initialized
INFO - 2020-02-13 12:38:09 --> URI Class Initialized
INFO - 2020-02-13 12:38:09 --> URI Class Initialized
DEBUG - 2020-02-13 12:38:09 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:09 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:09 --> Controller Class Initialized
INFO - 2020-02-13 12:38:09 --> Router Class Initialized
INFO - 2020-02-13 12:38:09 --> Router Class Initialized
INFO - 2020-02-13 12:38:09 --> Router Class Initialized
INFO - 2020-02-13 12:38:09 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:38:09 --> URI Class Initialized
INFO - 2020-02-13 12:38:09 --> Output Class Initialized
INFO - 2020-02-13 12:38:09 --> Output Class Initialized
INFO - 2020-02-13 12:38:09 --> Output Class Initialized
INFO - 2020-02-13 12:38:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:38:09 --> Security Class Initialized
INFO - 2020-02-13 12:38:09 --> Security Class Initialized
INFO - 2020-02-13 12:38:09 --> Router Class Initialized
INFO - 2020-02-13 12:38:09 --> Security Class Initialized
INFO - 2020-02-13 12:38:09 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 12:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 12:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:09 --> Output Class Initialized
DEBUG - 2020-02-13 12:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:09 --> Input Class Initialized
INFO - 2020-02-13 12:38:09 --> Input Class Initialized
INFO - 2020-02-13 12:38:09 --> Input Class Initialized
INFO - 2020-02-13 12:38:09 --> Security Class Initialized
INFO - 2020-02-13 12:38:09 --> Helper loaded: form_helper
INFO - 2020-02-13 12:38:09 --> Form Validation Class Initialized
INFO - 2020-02-13 12:38:09 --> Language Class Initialized
INFO - 2020-02-13 12:38:09 --> Language Class Initialized
INFO - 2020-02-13 12:38:09 --> Language Class Initialized
DEBUG - 2020-02-13 12:38:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-13 12:38:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 12:38:09 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 12:38:09 --> Input Class Initialized
ERROR - 2020-02-13 12:38:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 12:38:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 12:38:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 12:38:09 --> Language Class Initialized
INFO - 2020-02-13 12:38:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 12:38:09 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 12:38:09 --> Final output sent to browser
INFO - 2020-02-13 12:38:09 --> Config Class Initialized
INFO - 2020-02-13 12:38:09 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:09 --> Total execution time: 1.2076
DEBUG - 2020-02-13 12:38:09 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:09 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:09 --> URI Class Initialized
INFO - 2020-02-13 12:38:09 --> Router Class Initialized
INFO - 2020-02-13 12:38:09 --> Output Class Initialized
INFO - 2020-02-13 12:38:09 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:09 --> Input Class Initialized
INFO - 2020-02-13 12:38:09 --> Language Class Initialized
ERROR - 2020-02-13 12:38:09 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 12:38:10 --> Config Class Initialized
INFO - 2020-02-13 12:38:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:10 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:10 --> URI Class Initialized
INFO - 2020-02-13 12:38:10 --> Router Class Initialized
INFO - 2020-02-13 12:38:10 --> Output Class Initialized
INFO - 2020-02-13 12:38:10 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:10 --> Input Class Initialized
INFO - 2020-02-13 12:38:10 --> Language Class Initialized
ERROR - 2020-02-13 12:38:10 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 12:38:10 --> Config Class Initialized
INFO - 2020-02-13 12:38:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:10 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:10 --> URI Class Initialized
INFO - 2020-02-13 12:38:10 --> Router Class Initialized
INFO - 2020-02-13 12:38:10 --> Output Class Initialized
INFO - 2020-02-13 12:38:10 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:10 --> Input Class Initialized
INFO - 2020-02-13 12:38:10 --> Language Class Initialized
ERROR - 2020-02-13 12:38:10 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:38:10 --> Config Class Initialized
INFO - 2020-02-13 12:38:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:10 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:10 --> URI Class Initialized
INFO - 2020-02-13 12:38:10 --> Router Class Initialized
INFO - 2020-02-13 12:38:10 --> Output Class Initialized
INFO - 2020-02-13 12:38:11 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:11 --> Input Class Initialized
INFO - 2020-02-13 12:38:11 --> Language Class Initialized
ERROR - 2020-02-13 12:38:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 12:38:11 --> Config Class Initialized
INFO - 2020-02-13 12:38:11 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:11 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:11 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:11 --> URI Class Initialized
INFO - 2020-02-13 12:38:11 --> Router Class Initialized
INFO - 2020-02-13 12:38:11 --> Output Class Initialized
INFO - 2020-02-13 12:38:11 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:11 --> Input Class Initialized
INFO - 2020-02-13 12:38:11 --> Language Class Initialized
ERROR - 2020-02-13 12:38:11 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 12:38:11 --> Config Class Initialized
INFO - 2020-02-13 12:38:11 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:11 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:11 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:11 --> URI Class Initialized
INFO - 2020-02-13 12:38:11 --> Router Class Initialized
INFO - 2020-02-13 12:38:11 --> Output Class Initialized
INFO - 2020-02-13 12:38:11 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:11 --> Input Class Initialized
INFO - 2020-02-13 12:38:11 --> Language Class Initialized
ERROR - 2020-02-13 12:38:11 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 12:38:11 --> Config Class Initialized
INFO - 2020-02-13 12:38:11 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:11 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:11 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:12 --> URI Class Initialized
INFO - 2020-02-13 12:38:12 --> Router Class Initialized
INFO - 2020-02-13 12:38:12 --> Output Class Initialized
INFO - 2020-02-13 12:38:12 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:12 --> Input Class Initialized
INFO - 2020-02-13 12:38:12 --> Language Class Initialized
ERROR - 2020-02-13 12:38:12 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 12:38:12 --> Config Class Initialized
INFO - 2020-02-13 12:38:12 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:12 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:12 --> URI Class Initialized
INFO - 2020-02-13 12:38:12 --> Router Class Initialized
INFO - 2020-02-13 12:38:12 --> Output Class Initialized
INFO - 2020-02-13 12:38:12 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:12 --> Input Class Initialized
INFO - 2020-02-13 12:38:12 --> Language Class Initialized
ERROR - 2020-02-13 12:38:12 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 12:38:37 --> Config Class Initialized
INFO - 2020-02-13 12:38:37 --> Hooks Class Initialized
DEBUG - 2020-02-13 12:38:37 --> UTF-8 Support Enabled
INFO - 2020-02-13 12:38:37 --> Utf8 Class Initialized
INFO - 2020-02-13 12:38:37 --> URI Class Initialized
INFO - 2020-02-13 12:38:37 --> Router Class Initialized
INFO - 2020-02-13 12:38:37 --> Output Class Initialized
INFO - 2020-02-13 12:38:37 --> Security Class Initialized
DEBUG - 2020-02-13 12:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 12:38:37 --> Input Class Initialized
INFO - 2020-02-13 12:38:37 --> Language Class Initialized
INFO - 2020-02-13 12:38:37 --> Loader Class Initialized
INFO - 2020-02-13 12:38:37 --> Helper loaded: url_helper
INFO - 2020-02-13 12:38:37 --> Helper loaded: string_helper
INFO - 2020-02-13 12:38:37 --> Database Driver Class Initialized
DEBUG - 2020-02-13 12:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 12:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 12:38:37 --> Controller Class Initialized
INFO - 2020-02-13 12:38:37 --> Model "M_tiket" initialized
INFO - 2020-02-13 12:38:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 12:38:38 --> Model "M_pesan" initialized
INFO - 2020-02-13 12:38:38 --> Helper loaded: form_helper
INFO - 2020-02-13 12:38:38 --> Form Validation Class Initialized
INFO - 2020-02-13 12:38:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 12:38:38 --> Final output sent to browser
DEBUG - 2020-02-13 12:38:38 --> Total execution time: 0.8922
INFO - 2020-02-13 13:16:09 --> Config Class Initialized
INFO - 2020-02-13 13:16:09 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:16:09 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:09 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:09 --> URI Class Initialized
DEBUG - 2020-02-13 13:16:09 --> No URI present. Default controller set.
INFO - 2020-02-13 13:16:10 --> Router Class Initialized
INFO - 2020-02-13 13:16:10 --> Output Class Initialized
INFO - 2020-02-13 13:16:10 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:10 --> Input Class Initialized
INFO - 2020-02-13 13:16:10 --> Language Class Initialized
INFO - 2020-02-13 13:16:10 --> Loader Class Initialized
INFO - 2020-02-13 13:16:10 --> Helper loaded: url_helper
INFO - 2020-02-13 13:16:10 --> Helper loaded: string_helper
INFO - 2020-02-13 13:16:10 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:16:10 --> Controller Class Initialized
INFO - 2020-02-13 13:16:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 13:16:10 --> Pagination Class Initialized
INFO - 2020-02-13 13:16:10 --> Model "M_show" initialized
INFO - 2020-02-13 13:16:10 --> Helper loaded: form_helper
INFO - 2020-02-13 13:16:10 --> Form Validation Class Initialized
INFO - 2020-02-13 13:16:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 13:16:10 --> Final output sent to browser
INFO - 2020-02-13 13:16:10 --> Config Class Initialized
INFO - 2020-02-13 13:16:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:16:10 --> Total execution time: 1.1886
DEBUG - 2020-02-13 13:16:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:10 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:10 --> URI Class Initialized
DEBUG - 2020-02-13 13:16:10 --> No URI present. Default controller set.
INFO - 2020-02-13 13:16:10 --> Router Class Initialized
INFO - 2020-02-13 13:16:10 --> Output Class Initialized
INFO - 2020-02-13 13:16:11 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:11 --> Input Class Initialized
INFO - 2020-02-13 13:16:11 --> Language Class Initialized
INFO - 2020-02-13 13:16:11 --> Loader Class Initialized
INFO - 2020-02-13 13:16:11 --> Helper loaded: url_helper
INFO - 2020-02-13 13:16:11 --> Helper loaded: string_helper
INFO - 2020-02-13 13:16:11 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:16:11 --> Controller Class Initialized
INFO - 2020-02-13 13:16:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-13 13:16:11 --> Pagination Class Initialized
INFO - 2020-02-13 13:16:11 --> Model "M_show" initialized
INFO - 2020-02-13 13:16:11 --> Helper loaded: form_helper
INFO - 2020-02-13 13:16:11 --> Form Validation Class Initialized
INFO - 2020-02-13 13:16:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-13 13:16:11 --> Final output sent to browser
DEBUG - 2020-02-13 13:16:11 --> Total execution time: 0.8445
INFO - 2020-02-13 13:16:13 --> Config Class Initialized
INFO - 2020-02-13 13:16:13 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:16:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:14 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:14 --> URI Class Initialized
INFO - 2020-02-13 13:16:14 --> Router Class Initialized
INFO - 2020-02-13 13:16:14 --> Output Class Initialized
INFO - 2020-02-13 13:16:14 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:14 --> Input Class Initialized
INFO - 2020-02-13 13:16:14 --> Language Class Initialized
INFO - 2020-02-13 13:16:14 --> Loader Class Initialized
INFO - 2020-02-13 13:16:14 --> Helper loaded: url_helper
INFO - 2020-02-13 13:16:14 --> Helper loaded: string_helper
INFO - 2020-02-13 13:16:14 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:16:14 --> Controller Class Initialized
INFO - 2020-02-13 13:16:14 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:16:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:16:14 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:16:14 --> Helper loaded: form_helper
INFO - 2020-02-13 13:16:14 --> Form Validation Class Initialized
INFO - 2020-02-13 13:16:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:16:14 --> Final output sent to browser
INFO - 2020-02-13 13:16:14 --> Config Class Initialized
INFO - 2020-02-13 13:16:14 --> Config Class Initialized
INFO - 2020-02-13 13:16:14 --> Config Class Initialized
INFO - 2020-02-13 13:16:14 --> Config Class Initialized
INFO - 2020-02-13 13:16:14 --> Hooks Class Initialized
INFO - 2020-02-13 13:16:14 --> Hooks Class Initialized
INFO - 2020-02-13 13:16:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:16:14 --> Total execution time: 0.7321
INFO - 2020-02-13 13:16:14 --> Hooks Class Initialized
INFO - 2020-02-13 13:16:14 --> Config Class Initialized
DEBUG - 2020-02-13 13:16:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:16:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:16:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:16:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:14 --> Hooks Class Initialized
INFO - 2020-02-13 13:16:14 --> Config Class Initialized
INFO - 2020-02-13 13:16:14 --> Hooks Class Initialized
INFO - 2020-02-13 13:16:14 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:14 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:14 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:14 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:16:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:14 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:14 --> URI Class Initialized
INFO - 2020-02-13 13:16:14 --> URI Class Initialized
INFO - 2020-02-13 13:16:14 --> URI Class Initialized
INFO - 2020-02-13 13:16:14 --> URI Class Initialized
DEBUG - 2020-02-13 13:16:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:14 --> URI Class Initialized
INFO - 2020-02-13 13:16:14 --> Router Class Initialized
INFO - 2020-02-13 13:16:14 --> Router Class Initialized
INFO - 2020-02-13 13:16:14 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:14 --> Router Class Initialized
INFO - 2020-02-13 13:16:14 --> Router Class Initialized
INFO - 2020-02-13 13:16:14 --> URI Class Initialized
INFO - 2020-02-13 13:16:14 --> Router Class Initialized
INFO - 2020-02-13 13:16:14 --> Output Class Initialized
INFO - 2020-02-13 13:16:14 --> Output Class Initialized
INFO - 2020-02-13 13:16:14 --> Output Class Initialized
INFO - 2020-02-13 13:16:14 --> Output Class Initialized
INFO - 2020-02-13 13:16:14 --> Security Class Initialized
INFO - 2020-02-13 13:16:14 --> Security Class Initialized
INFO - 2020-02-13 13:16:14 --> Output Class Initialized
INFO - 2020-02-13 13:16:14 --> Security Class Initialized
INFO - 2020-02-13 13:16:14 --> Router Class Initialized
INFO - 2020-02-13 13:16:14 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:15 --> Output Class Initialized
INFO - 2020-02-13 13:16:15 --> Security Class Initialized
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:15 --> Security Class Initialized
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
ERROR - 2020-02-13 13:16:15 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-13 13:16:15 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 13:16:15 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 13:16:15 --> Loader Class Initialized
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
ERROR - 2020-02-13 13:16:15 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 13:16:15 --> Helper loaded: url_helper
INFO - 2020-02-13 13:16:15 --> Config Class Initialized
INFO - 2020-02-13 13:16:15 --> Config Class Initialized
INFO - 2020-02-13 13:16:15 --> Config Class Initialized
INFO - 2020-02-13 13:16:15 --> Hooks Class Initialized
INFO - 2020-02-13 13:16:15 --> Hooks Class Initialized
INFO - 2020-02-13 13:16:15 --> Hooks Class Initialized
INFO - 2020-02-13 13:16:15 --> Helper loaded: string_helper
ERROR - 2020-02-13 13:16:15 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 13:16:15 --> Config Class Initialized
INFO - 2020-02-13 13:16:15 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:15 --> Database Driver Class Initialized
INFO - 2020-02-13 13:16:15 --> Config Class Initialized
INFO - 2020-02-13 13:16:15 --> Hooks Class Initialized
INFO - 2020-02-13 13:16:15 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:15 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:15 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:16:15 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:16:15 --> URI Class Initialized
DEBUG - 2020-02-13 13:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:15 --> URI Class Initialized
INFO - 2020-02-13 13:16:15 --> URI Class Initialized
INFO - 2020-02-13 13:16:15 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:15 --> Controller Class Initialized
INFO - 2020-02-13 13:16:15 --> Router Class Initialized
INFO - 2020-02-13 13:16:15 --> Router Class Initialized
INFO - 2020-02-13 13:16:15 --> Router Class Initialized
INFO - 2020-02-13 13:16:15 --> URI Class Initialized
INFO - 2020-02-13 13:16:15 --> Router Class Initialized
INFO - 2020-02-13 13:16:15 --> Output Class Initialized
INFO - 2020-02-13 13:16:15 --> Output Class Initialized
INFO - 2020-02-13 13:16:15 --> URI Class Initialized
INFO - 2020-02-13 13:16:15 --> Output Class Initialized
INFO - 2020-02-13 13:16:15 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:16:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:16:15 --> Security Class Initialized
INFO - 2020-02-13 13:16:15 --> Router Class Initialized
INFO - 2020-02-13 13:16:15 --> Security Class Initialized
INFO - 2020-02-13 13:16:15 --> Output Class Initialized
INFO - 2020-02-13 13:16:15 --> Security Class Initialized
INFO - 2020-02-13 13:16:15 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:15 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:15 --> Output Class Initialized
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
INFO - 2020-02-13 13:16:15 --> Security Class Initialized
INFO - 2020-02-13 13:16:15 --> Helper loaded: form_helper
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
INFO - 2020-02-13 13:16:15 --> Form Validation Class Initialized
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
ERROR - 2020-02-13 13:16:15 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 13:16:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:16:15 --> Loader Class Initialized
ERROR - 2020-02-13 13:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
ERROR - 2020-02-13 13:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 13:16:15 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 13:16:15 --> Helper loaded: url_helper
INFO - 2020-02-13 13:16:15 --> Config Class Initialized
INFO - 2020-02-13 13:16:15 --> Config Class Initialized
INFO - 2020-02-13 13:16:15 --> Hooks Class Initialized
INFO - 2020-02-13 13:16:15 --> Hooks Class Initialized
INFO - 2020-02-13 13:16:15 --> Helper loaded: string_helper
ERROR - 2020-02-13 13:16:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 13:16:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:16:15 --> Config Class Initialized
INFO - 2020-02-13 13:16:15 --> Hooks Class Initialized
INFO - 2020-02-13 13:16:15 --> Final output sent to browser
DEBUG - 2020-02-13 13:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:15 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:16:15 --> Total execution time: 0.9004
INFO - 2020-02-13 13:16:15 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:15 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:16:15 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:16:15 --> URI Class Initialized
INFO - 2020-02-13 13:16:15 --> URI Class Initialized
INFO - 2020-02-13 13:16:15 --> Controller Class Initialized
INFO - 2020-02-13 13:16:15 --> URI Class Initialized
INFO - 2020-02-13 13:16:15 --> Router Class Initialized
INFO - 2020-02-13 13:16:15 --> Router Class Initialized
INFO - 2020-02-13 13:16:15 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:16:15 --> Router Class Initialized
INFO - 2020-02-13 13:16:15 --> Output Class Initialized
INFO - 2020-02-13 13:16:15 --> Output Class Initialized
INFO - 2020-02-13 13:16:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:16:15 --> Security Class Initialized
INFO - 2020-02-13 13:16:15 --> Security Class Initialized
INFO - 2020-02-13 13:16:15 --> Output Class Initialized
INFO - 2020-02-13 13:16:15 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:15 --> Security Class Initialized
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
DEBUG - 2020-02-13 13:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:15 --> Helper loaded: form_helper
INFO - 2020-02-13 13:16:15 --> Input Class Initialized
INFO - 2020-02-13 13:16:15 --> Form Validation Class Initialized
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
INFO - 2020-02-13 13:16:15 --> Language Class Initialized
ERROR - 2020-02-13 13:16:15 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 13:16:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 13:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 13:16:15 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 13:16:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:16:16 --> Config Class Initialized
INFO - 2020-02-13 13:16:16 --> Hooks Class Initialized
INFO - 2020-02-13 13:16:16 --> Final output sent to browser
DEBUG - 2020-02-13 13:16:16 --> Total execution time: 0.8890
DEBUG - 2020-02-13 13:16:16 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:16 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:16 --> URI Class Initialized
INFO - 2020-02-13 13:16:16 --> Router Class Initialized
INFO - 2020-02-13 13:16:16 --> Output Class Initialized
INFO - 2020-02-13 13:16:16 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:16 --> Input Class Initialized
INFO - 2020-02-13 13:16:16 --> Language Class Initialized
ERROR - 2020-02-13 13:16:16 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 13:16:16 --> Config Class Initialized
INFO - 2020-02-13 13:16:16 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:16:16 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:16 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:16 --> URI Class Initialized
INFO - 2020-02-13 13:16:16 --> Router Class Initialized
INFO - 2020-02-13 13:16:16 --> Output Class Initialized
INFO - 2020-02-13 13:16:16 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:16 --> Input Class Initialized
INFO - 2020-02-13 13:16:16 --> Language Class Initialized
ERROR - 2020-02-13 13:16:16 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 13:16:16 --> Config Class Initialized
INFO - 2020-02-13 13:16:16 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:16:16 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:16 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:16 --> URI Class Initialized
INFO - 2020-02-13 13:16:16 --> Router Class Initialized
INFO - 2020-02-13 13:16:16 --> Output Class Initialized
INFO - 2020-02-13 13:16:16 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:17 --> Input Class Initialized
INFO - 2020-02-13 13:16:17 --> Language Class Initialized
ERROR - 2020-02-13 13:16:17 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:16:17 --> Config Class Initialized
INFO - 2020-02-13 13:16:17 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:16:17 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:17 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:17 --> URI Class Initialized
INFO - 2020-02-13 13:16:17 --> Router Class Initialized
INFO - 2020-02-13 13:16:17 --> Output Class Initialized
INFO - 2020-02-13 13:16:17 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:17 --> Input Class Initialized
INFO - 2020-02-13 13:16:17 --> Language Class Initialized
ERROR - 2020-02-13 13:16:17 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:16:17 --> Config Class Initialized
INFO - 2020-02-13 13:16:17 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:16:17 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:17 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:17 --> URI Class Initialized
INFO - 2020-02-13 13:16:17 --> Router Class Initialized
INFO - 2020-02-13 13:16:17 --> Output Class Initialized
INFO - 2020-02-13 13:16:17 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:17 --> Input Class Initialized
INFO - 2020-02-13 13:16:17 --> Language Class Initialized
ERROR - 2020-02-13 13:16:17 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 13:16:17 --> Config Class Initialized
INFO - 2020-02-13 13:16:17 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:16:17 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:17 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:18 --> URI Class Initialized
INFO - 2020-02-13 13:16:18 --> Router Class Initialized
INFO - 2020-02-13 13:16:18 --> Output Class Initialized
INFO - 2020-02-13 13:16:18 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:18 --> Input Class Initialized
INFO - 2020-02-13 13:16:18 --> Language Class Initialized
ERROR - 2020-02-13 13:16:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 13:16:18 --> Config Class Initialized
INFO - 2020-02-13 13:16:18 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:16:18 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:18 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:18 --> URI Class Initialized
INFO - 2020-02-13 13:16:18 --> Router Class Initialized
INFO - 2020-02-13 13:16:18 --> Output Class Initialized
INFO - 2020-02-13 13:16:18 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:18 --> Input Class Initialized
INFO - 2020-02-13 13:16:18 --> Language Class Initialized
ERROR - 2020-02-13 13:16:18 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 13:16:18 --> Config Class Initialized
INFO - 2020-02-13 13:16:18 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:16:18 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:18 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:18 --> URI Class Initialized
INFO - 2020-02-13 13:16:18 --> Router Class Initialized
INFO - 2020-02-13 13:16:18 --> Output Class Initialized
INFO - 2020-02-13 13:16:18 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:18 --> Input Class Initialized
INFO - 2020-02-13 13:16:18 --> Language Class Initialized
ERROR - 2020-02-13 13:16:18 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 13:16:35 --> Config Class Initialized
INFO - 2020-02-13 13:16:35 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:16:35 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:16:35 --> Utf8 Class Initialized
INFO - 2020-02-13 13:16:35 --> URI Class Initialized
INFO - 2020-02-13 13:16:35 --> Router Class Initialized
INFO - 2020-02-13 13:16:35 --> Output Class Initialized
INFO - 2020-02-13 13:16:35 --> Security Class Initialized
DEBUG - 2020-02-13 13:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:16:35 --> Input Class Initialized
INFO - 2020-02-13 13:16:35 --> Language Class Initialized
INFO - 2020-02-13 13:16:35 --> Loader Class Initialized
INFO - 2020-02-13 13:16:35 --> Helper loaded: url_helper
INFO - 2020-02-13 13:16:35 --> Helper loaded: string_helper
INFO - 2020-02-13 13:16:35 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:16:35 --> Controller Class Initialized
INFO - 2020-02-13 13:16:35 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:16:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:16:35 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:16:35 --> Helper loaded: form_helper
INFO - 2020-02-13 13:16:35 --> Form Validation Class Initialized
INFO - 2020-02-13 13:16:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 13:16:36 --> Final output sent to browser
DEBUG - 2020-02-13 13:16:36 --> Total execution time: 0.9248
INFO - 2020-02-13 13:19:47 --> Config Class Initialized
INFO - 2020-02-13 13:19:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:47 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:47 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:47 --> URI Class Initialized
INFO - 2020-02-13 13:19:47 --> Router Class Initialized
INFO - 2020-02-13 13:19:47 --> Output Class Initialized
INFO - 2020-02-13 13:19:47 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:47 --> Input Class Initialized
INFO - 2020-02-13 13:19:47 --> Language Class Initialized
INFO - 2020-02-13 13:19:47 --> Loader Class Initialized
INFO - 2020-02-13 13:19:47 --> Helper loaded: url_helper
INFO - 2020-02-13 13:19:47 --> Helper loaded: string_helper
INFO - 2020-02-13 13:19:47 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:19:47 --> Controller Class Initialized
INFO - 2020-02-13 13:19:47 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:19:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:19:47 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:19:48 --> Helper loaded: form_helper
INFO - 2020-02-13 13:19:48 --> Form Validation Class Initialized
INFO - 2020-02-13 13:19:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:19:48 --> Final output sent to browser
INFO - 2020-02-13 13:19:48 --> Config Class Initialized
INFO - 2020-02-13 13:19:48 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:48 --> Total execution time: 0.7665
DEBUG - 2020-02-13 13:19:48 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:48 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:48 --> URI Class Initialized
INFO - 2020-02-13 13:19:48 --> Router Class Initialized
INFO - 2020-02-13 13:19:48 --> Output Class Initialized
INFO - 2020-02-13 13:19:48 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:48 --> Input Class Initialized
INFO - 2020-02-13 13:19:48 --> Language Class Initialized
ERROR - 2020-02-13 13:19:48 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 13:19:54 --> Config Class Initialized
INFO - 2020-02-13 13:19:54 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:54 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:54 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:54 --> URI Class Initialized
INFO - 2020-02-13 13:19:54 --> Router Class Initialized
INFO - 2020-02-13 13:19:54 --> Output Class Initialized
INFO - 2020-02-13 13:19:54 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:54 --> Input Class Initialized
INFO - 2020-02-13 13:19:54 --> Language Class Initialized
INFO - 2020-02-13 13:19:54 --> Loader Class Initialized
INFO - 2020-02-13 13:19:54 --> Helper loaded: url_helper
INFO - 2020-02-13 13:19:54 --> Helper loaded: string_helper
INFO - 2020-02-13 13:19:54 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:19:54 --> Controller Class Initialized
INFO - 2020-02-13 13:19:54 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:19:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:19:54 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:19:54 --> Helper loaded: form_helper
INFO - 2020-02-13 13:19:54 --> Form Validation Class Initialized
INFO - 2020-02-13 13:19:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:19:54 --> Final output sent to browser
INFO - 2020-02-13 13:19:54 --> Config Class Initialized
INFO - 2020-02-13 13:19:54 --> Config Class Initialized
INFO - 2020-02-13 13:19:54 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:54 --> Total execution time: 0.7241
INFO - 2020-02-13 13:19:54 --> Config Class Initialized
INFO - 2020-02-13 13:19:54 --> Config Class Initialized
INFO - 2020-02-13 13:19:54 --> Hooks Class Initialized
INFO - 2020-02-13 13:19:54 --> Config Class Initialized
INFO - 2020-02-13 13:19:54 --> Hooks Class Initialized
INFO - 2020-02-13 13:19:54 --> Hooks Class Initialized
INFO - 2020-02-13 13:19:54 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:19:54 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:54 --> Config Class Initialized
INFO - 2020-02-13 13:19:54 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:54 --> Hooks Class Initialized
INFO - 2020-02-13 13:19:54 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:19:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:19:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:19:54 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:55 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:55 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:19:55 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:55 --> Input Class Initialized
INFO - 2020-02-13 13:19:55 --> Language Class Initialized
DEBUG - 2020-02-13 13:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
INFO - 2020-02-13 13:19:55 --> Input Class Initialized
DEBUG - 2020-02-13 13:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:55 --> Input Class Initialized
INFO - 2020-02-13 13:19:55 --> Input Class Initialized
INFO - 2020-02-13 13:19:55 --> Input Class Initialized
INFO - 2020-02-13 13:19:55 --> Language Class Initialized
DEBUG - 2020-02-13 13:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:55 --> Loader Class Initialized
INFO - 2020-02-13 13:19:55 --> Input Class Initialized
INFO - 2020-02-13 13:19:55 --> Language Class Initialized
INFO - 2020-02-13 13:19:55 --> Language Class Initialized
INFO - 2020-02-13 13:19:55 --> Language Class Initialized
INFO - 2020-02-13 13:19:55 --> Helper loaded: url_helper
INFO - 2020-02-13 13:19:55 --> Loader Class Initialized
INFO - 2020-02-13 13:19:55 --> Language Class Initialized
ERROR - 2020-02-13 13:19:55 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 13:19:55 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 13:19:55 --> Helper loaded: string_helper
INFO - 2020-02-13 13:19:55 --> Helper loaded: url_helper
ERROR - 2020-02-13 13:19:55 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 13:19:55 --> Helper loaded: string_helper
ERROR - 2020-02-13 13:19:55 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 13:19:55 --> Database Driver Class Initialized
INFO - 2020-02-13 13:19:55 --> Config Class Initialized
INFO - 2020-02-13 13:19:55 --> Config Class Initialized
INFO - 2020-02-13 13:19:55 --> Config Class Initialized
INFO - 2020-02-13 13:19:55 --> Hooks Class Initialized
INFO - 2020-02-13 13:19:55 --> Hooks Class Initialized
INFO - 2020-02-13 13:19:55 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:19:55 --> Database Driver Class Initialized
INFO - 2020-02-13 13:19:55 --> Config Class Initialized
INFO - 2020-02-13 13:19:55 --> Hooks Class Initialized
INFO - 2020-02-13 13:19:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 13:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:19:55 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:55 --> Controller Class Initialized
INFO - 2020-02-13 13:19:55 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:55 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:19:55 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:55 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:19:55 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Helper loaded: form_helper
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
INFO - 2020-02-13 13:19:55 --> Form Validation Class Initialized
DEBUG - 2020-02-13 13:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:55 --> Input Class Initialized
INFO - 2020-02-13 13:19:55 --> Input Class Initialized
INFO - 2020-02-13 13:19:55 --> Input Class Initialized
DEBUG - 2020-02-13 13:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-13 13:19:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-13 13:19:55 --> Input Class Initialized
INFO - 2020-02-13 13:19:55 --> Language Class Initialized
INFO - 2020-02-13 13:19:55 --> Language Class Initialized
INFO - 2020-02-13 13:19:55 --> Language Class Initialized
ERROR - 2020-02-13 13:19:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:19:55 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:19:55 --> Language Class Initialized
ERROR - 2020-02-13 13:19:55 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 13:19:55 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 13:19:55 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:19:55 --> Final output sent to browser
ERROR - 2020-02-13 13:19:55 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 13:19:55 --> Config Class Initialized
INFO - 2020-02-13 13:19:55 --> Config Class Initialized
INFO - 2020-02-13 13:19:55 --> Config Class Initialized
INFO - 2020-02-13 13:19:55 --> Hooks Class Initialized
INFO - 2020-02-13 13:19:55 --> Hooks Class Initialized
INFO - 2020-02-13 13:19:55 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:55 --> Total execution time: 0.8519
INFO - 2020-02-13 13:19:55 --> Config Class Initialized
INFO - 2020-02-13 13:19:55 --> Hooks Class Initialized
INFO - 2020-02-13 13:19:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 13:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:19:55 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:55 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:55 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:55 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:55 --> Controller Class Initialized
DEBUG - 2020-02-13 13:19:55 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:55 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:19:55 --> URI Class Initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:19:55 --> Router Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
INFO - 2020-02-13 13:19:55 --> Output Class Initialized
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
INFO - 2020-02-13 13:19:55 --> Helper loaded: form_helper
INFO - 2020-02-13 13:19:55 --> Form Validation Class Initialized
INFO - 2020-02-13 13:19:55 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:56 --> Input Class Initialized
INFO - 2020-02-13 13:19:56 --> Input Class Initialized
INFO - 2020-02-13 13:19:56 --> Input Class Initialized
DEBUG - 2020-02-13 13:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-13 13:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-13 13:19:56 --> Input Class Initialized
ERROR - 2020-02-13 13:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:19:56 --> Language Class Initialized
INFO - 2020-02-13 13:19:56 --> Language Class Initialized
INFO - 2020-02-13 13:19:56 --> Language Class Initialized
INFO - 2020-02-13 13:19:56 --> Language Class Initialized
ERROR - 2020-02-13 13:19:56 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 13:19:56 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 13:19:56 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 13:19:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:19:56 --> Final output sent to browser
ERROR - 2020-02-13 13:19:56 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-13 13:19:56 --> Total execution time: 1.2443
INFO - 2020-02-13 13:19:56 --> Config Class Initialized
INFO - 2020-02-13 13:19:56 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:56 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:56 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:56 --> URI Class Initialized
INFO - 2020-02-13 13:19:56 --> Router Class Initialized
INFO - 2020-02-13 13:19:56 --> Output Class Initialized
INFO - 2020-02-13 13:19:56 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:56 --> Input Class Initialized
INFO - 2020-02-13 13:19:56 --> Language Class Initialized
ERROR - 2020-02-13 13:19:56 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 13:19:56 --> Config Class Initialized
INFO - 2020-02-13 13:19:56 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:56 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:56 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:56 --> URI Class Initialized
INFO - 2020-02-13 13:19:56 --> Router Class Initialized
INFO - 2020-02-13 13:19:56 --> Output Class Initialized
INFO - 2020-02-13 13:19:56 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:56 --> Input Class Initialized
INFO - 2020-02-13 13:19:56 --> Language Class Initialized
ERROR - 2020-02-13 13:19:56 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 13:19:57 --> Config Class Initialized
INFO - 2020-02-13 13:19:57 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:57 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:57 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:57 --> URI Class Initialized
INFO - 2020-02-13 13:19:57 --> Router Class Initialized
INFO - 2020-02-13 13:19:57 --> Output Class Initialized
INFO - 2020-02-13 13:19:57 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:57 --> Input Class Initialized
INFO - 2020-02-13 13:19:57 --> Language Class Initialized
ERROR - 2020-02-13 13:19:57 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 13:19:57 --> Config Class Initialized
INFO - 2020-02-13 13:19:57 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:57 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:57 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:57 --> URI Class Initialized
INFO - 2020-02-13 13:19:57 --> Router Class Initialized
INFO - 2020-02-13 13:19:57 --> Output Class Initialized
INFO - 2020-02-13 13:19:57 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:57 --> Input Class Initialized
INFO - 2020-02-13 13:19:57 --> Language Class Initialized
ERROR - 2020-02-13 13:19:57 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:19:57 --> Config Class Initialized
INFO - 2020-02-13 13:19:57 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:57 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:57 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:57 --> URI Class Initialized
INFO - 2020-02-13 13:19:57 --> Router Class Initialized
INFO - 2020-02-13 13:19:57 --> Output Class Initialized
INFO - 2020-02-13 13:19:57 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:58 --> Input Class Initialized
INFO - 2020-02-13 13:19:58 --> Language Class Initialized
ERROR - 2020-02-13 13:19:58 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:19:58 --> Config Class Initialized
INFO - 2020-02-13 13:19:58 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:58 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:58 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:58 --> URI Class Initialized
INFO - 2020-02-13 13:19:58 --> Router Class Initialized
INFO - 2020-02-13 13:19:58 --> Output Class Initialized
INFO - 2020-02-13 13:19:58 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:58 --> Input Class Initialized
INFO - 2020-02-13 13:19:58 --> Language Class Initialized
ERROR - 2020-02-13 13:19:58 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 13:19:58 --> Config Class Initialized
INFO - 2020-02-13 13:19:58 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:58 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:58 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:58 --> URI Class Initialized
INFO - 2020-02-13 13:19:58 --> Router Class Initialized
INFO - 2020-02-13 13:19:58 --> Output Class Initialized
INFO - 2020-02-13 13:19:58 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:58 --> Input Class Initialized
INFO - 2020-02-13 13:19:58 --> Language Class Initialized
ERROR - 2020-02-13 13:19:58 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 13:19:58 --> Config Class Initialized
INFO - 2020-02-13 13:19:58 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:58 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:59 --> URI Class Initialized
INFO - 2020-02-13 13:19:59 --> Router Class Initialized
INFO - 2020-02-13 13:19:59 --> Output Class Initialized
INFO - 2020-02-13 13:19:59 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:59 --> Input Class Initialized
INFO - 2020-02-13 13:19:59 --> Language Class Initialized
ERROR - 2020-02-13 13:19:59 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 13:19:59 --> Config Class Initialized
INFO - 2020-02-13 13:19:59 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:19:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:19:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:19:59 --> URI Class Initialized
INFO - 2020-02-13 13:19:59 --> Router Class Initialized
INFO - 2020-02-13 13:19:59 --> Output Class Initialized
INFO - 2020-02-13 13:19:59 --> Security Class Initialized
DEBUG - 2020-02-13 13:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:19:59 --> Input Class Initialized
INFO - 2020-02-13 13:19:59 --> Language Class Initialized
ERROR - 2020-02-13 13:19:59 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 13:20:21 --> Config Class Initialized
INFO - 2020-02-13 13:20:21 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:20:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:20:21 --> Utf8 Class Initialized
INFO - 2020-02-13 13:20:21 --> URI Class Initialized
INFO - 2020-02-13 13:20:21 --> Router Class Initialized
INFO - 2020-02-13 13:20:21 --> Output Class Initialized
INFO - 2020-02-13 13:20:21 --> Security Class Initialized
DEBUG - 2020-02-13 13:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:20:21 --> Input Class Initialized
INFO - 2020-02-13 13:20:21 --> Language Class Initialized
INFO - 2020-02-13 13:20:21 --> Loader Class Initialized
INFO - 2020-02-13 13:20:21 --> Helper loaded: url_helper
INFO - 2020-02-13 13:20:21 --> Helper loaded: string_helper
INFO - 2020-02-13 13:20:21 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:20:21 --> Controller Class Initialized
INFO - 2020-02-13 13:20:21 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:20:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:20:21 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:20:21 --> Helper loaded: form_helper
INFO - 2020-02-13 13:20:21 --> Form Validation Class Initialized
INFO - 2020-02-13 13:20:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 13:20:22 --> Final output sent to browser
DEBUG - 2020-02-13 13:20:22 --> Total execution time: 0.8913
INFO - 2020-02-13 13:21:41 --> Config Class Initialized
INFO - 2020-02-13 13:21:41 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:41 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:41 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:41 --> URI Class Initialized
INFO - 2020-02-13 13:21:41 --> Router Class Initialized
INFO - 2020-02-13 13:21:41 --> Output Class Initialized
INFO - 2020-02-13 13:21:42 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:42 --> Input Class Initialized
INFO - 2020-02-13 13:21:42 --> Language Class Initialized
INFO - 2020-02-13 13:21:42 --> Loader Class Initialized
INFO - 2020-02-13 13:21:42 --> Helper loaded: url_helper
INFO - 2020-02-13 13:21:42 --> Helper loaded: string_helper
INFO - 2020-02-13 13:21:42 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:21:42 --> Controller Class Initialized
INFO - 2020-02-13 13:21:42 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:21:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:21:42 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:21:42 --> Helper loaded: form_helper
INFO - 2020-02-13 13:21:42 --> Form Validation Class Initialized
INFO - 2020-02-13 13:21:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:21:42 --> Final output sent to browser
DEBUG - 2020-02-13 13:21:42 --> Total execution time: 0.7996
INFO - 2020-02-13 13:21:44 --> Config Class Initialized
INFO - 2020-02-13 13:21:44 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:44 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:44 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:44 --> URI Class Initialized
INFO - 2020-02-13 13:21:44 --> Router Class Initialized
INFO - 2020-02-13 13:21:44 --> Output Class Initialized
INFO - 2020-02-13 13:21:44 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:44 --> Input Class Initialized
INFO - 2020-02-13 13:21:44 --> Language Class Initialized
INFO - 2020-02-13 13:21:44 --> Loader Class Initialized
INFO - 2020-02-13 13:21:44 --> Helper loaded: url_helper
INFO - 2020-02-13 13:21:45 --> Helper loaded: string_helper
INFO - 2020-02-13 13:21:45 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:21:45 --> Controller Class Initialized
INFO - 2020-02-13 13:21:45 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:21:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:21:45 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:21:45 --> Helper loaded: form_helper
INFO - 2020-02-13 13:21:45 --> Form Validation Class Initialized
INFO - 2020-02-13 13:21:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:21:45 --> Final output sent to browser
INFO - 2020-02-13 13:21:45 --> Config Class Initialized
INFO - 2020-02-13 13:21:45 --> Config Class Initialized
INFO - 2020-02-13 13:21:45 --> Config Class Initialized
INFO - 2020-02-13 13:21:45 --> Config Class Initialized
INFO - 2020-02-13 13:21:45 --> Hooks Class Initialized
INFO - 2020-02-13 13:21:45 --> Hooks Class Initialized
INFO - 2020-02-13 13:21:45 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:45 --> Total execution time: 0.7440
INFO - 2020-02-13 13:21:45 --> Config Class Initialized
INFO - 2020-02-13 13:21:45 --> Hooks Class Initialized
INFO - 2020-02-13 13:21:45 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:21:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:21:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:45 --> Config Class Initialized
INFO - 2020-02-13 13:21:45 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:45 --> Hooks Class Initialized
INFO - 2020-02-13 13:21:45 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:45 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:21:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:21:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:45 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:45 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:45 --> URI Class Initialized
INFO - 2020-02-13 13:21:45 --> URI Class Initialized
INFO - 2020-02-13 13:21:45 --> URI Class Initialized
DEBUG - 2020-02-13 13:21:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:45 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:45 --> URI Class Initialized
INFO - 2020-02-13 13:21:45 --> URI Class Initialized
INFO - 2020-02-13 13:21:45 --> Router Class Initialized
INFO - 2020-02-13 13:21:45 --> Router Class Initialized
INFO - 2020-02-13 13:21:45 --> Router Class Initialized
INFO - 2020-02-13 13:21:45 --> URI Class Initialized
INFO - 2020-02-13 13:21:45 --> Router Class Initialized
INFO - 2020-02-13 13:21:45 --> Output Class Initialized
INFO - 2020-02-13 13:21:45 --> Output Class Initialized
INFO - 2020-02-13 13:21:45 --> Router Class Initialized
INFO - 2020-02-13 13:21:45 --> Output Class Initialized
INFO - 2020-02-13 13:21:45 --> Security Class Initialized
INFO - 2020-02-13 13:21:45 --> Security Class Initialized
INFO - 2020-02-13 13:21:45 --> Router Class Initialized
INFO - 2020-02-13 13:21:45 --> Output Class Initialized
INFO - 2020-02-13 13:21:45 --> Security Class Initialized
INFO - 2020-02-13 13:21:45 --> Output Class Initialized
DEBUG - 2020-02-13 13:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:45 --> Security Class Initialized
INFO - 2020-02-13 13:21:45 --> Output Class Initialized
DEBUG - 2020-02-13 13:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:45 --> Security Class Initialized
INFO - 2020-02-13 13:21:45 --> Input Class Initialized
INFO - 2020-02-13 13:21:45 --> Input Class Initialized
DEBUG - 2020-02-13 13:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:45 --> Input Class Initialized
INFO - 2020-02-13 13:21:45 --> Security Class Initialized
INFO - 2020-02-13 13:21:45 --> Input Class Initialized
INFO - 2020-02-13 13:21:45 --> Input Class Initialized
INFO - 2020-02-13 13:21:45 --> Language Class Initialized
INFO - 2020-02-13 13:21:45 --> Language Class Initialized
DEBUG - 2020-02-13 13:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:45 --> Language Class Initialized
INFO - 2020-02-13 13:21:45 --> Input Class Initialized
INFO - 2020-02-13 13:21:45 --> Language Class Initialized
ERROR - 2020-02-13 13:21:45 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 13:21:45 --> Language Class Initialized
INFO - 2020-02-13 13:21:45 --> Loader Class Initialized
INFO - 2020-02-13 13:21:45 --> Loader Class Initialized
INFO - 2020-02-13 13:21:45 --> Language Class Initialized
ERROR - 2020-02-13 13:21:45 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 13:21:45 --> Helper loaded: url_helper
INFO - 2020-02-13 13:21:45 --> Helper loaded: url_helper
ERROR - 2020-02-13 13:21:45 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 13:21:45 --> Config Class Initialized
INFO - 2020-02-13 13:21:45 --> Hooks Class Initialized
INFO - 2020-02-13 13:21:45 --> Helper loaded: string_helper
INFO - 2020-02-13 13:21:45 --> Helper loaded: string_helper
ERROR - 2020-02-13 13:21:45 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 13:21:45 --> Config Class Initialized
INFO - 2020-02-13 13:21:45 --> Config Class Initialized
INFO - 2020-02-13 13:21:45 --> Hooks Class Initialized
INFO - 2020-02-13 13:21:45 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:45 --> Database Driver Class Initialized
INFO - 2020-02-13 13:21:45 --> Database Driver Class Initialized
INFO - 2020-02-13 13:21:45 --> Config Class Initialized
INFO - 2020-02-13 13:21:45 --> Hooks Class Initialized
INFO - 2020-02-13 13:21:45 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:21:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:21:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 13:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:21:45 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:45 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:21:45 --> URI Class Initialized
DEBUG - 2020-02-13 13:21:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:45 --> Controller Class Initialized
INFO - 2020-02-13 13:21:45 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:45 --> URI Class Initialized
INFO - 2020-02-13 13:21:45 --> URI Class Initialized
INFO - 2020-02-13 13:21:45 --> Router Class Initialized
INFO - 2020-02-13 13:21:46 --> URI Class Initialized
INFO - 2020-02-13 13:21:46 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:21:46 --> Router Class Initialized
INFO - 2020-02-13 13:21:46 --> Output Class Initialized
INFO - 2020-02-13 13:21:46 --> Router Class Initialized
INFO - 2020-02-13 13:21:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:21:46 --> Router Class Initialized
INFO - 2020-02-13 13:21:46 --> Security Class Initialized
INFO - 2020-02-13 13:21:46 --> Output Class Initialized
INFO - 2020-02-13 13:21:46 --> Output Class Initialized
INFO - 2020-02-13 13:21:46 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:46 --> Output Class Initialized
INFO - 2020-02-13 13:21:46 --> Security Class Initialized
INFO - 2020-02-13 13:21:46 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:21:46 --> Input Class Initialized
DEBUG - 2020-02-13 13:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:46 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:46 --> Helper loaded: form_helper
INFO - 2020-02-13 13:21:46 --> Form Validation Class Initialized
INFO - 2020-02-13 13:21:46 --> Input Class Initialized
INFO - 2020-02-13 13:21:46 --> Input Class Initialized
INFO - 2020-02-13 13:21:46 --> Language Class Initialized
DEBUG - 2020-02-13 13:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:46 --> Input Class Initialized
INFO - 2020-02-13 13:21:46 --> Language Class Initialized
INFO - 2020-02-13 13:21:46 --> Language Class Initialized
ERROR - 2020-02-13 13:21:46 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 13:21:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:21:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:21:46 --> Language Class Initialized
ERROR - 2020-02-13 13:21:46 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 13:21:46 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:21:46 --> Config Class Initialized
INFO - 2020-02-13 13:21:46 --> Hooks Class Initialized
INFO - 2020-02-13 13:21:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 13:21:46 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 13:21:46 --> Config Class Initialized
INFO - 2020-02-13 13:21:46 --> Config Class Initialized
INFO - 2020-02-13 13:21:46 --> Hooks Class Initialized
INFO - 2020-02-13 13:21:46 --> Hooks Class Initialized
INFO - 2020-02-13 13:21:46 --> Final output sent to browser
DEBUG - 2020-02-13 13:21:46 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:46 --> Config Class Initialized
INFO - 2020-02-13 13:21:46 --> Hooks Class Initialized
INFO - 2020-02-13 13:21:46 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:21:46 --> Total execution time: 0.8558
DEBUG - 2020-02-13 13:21:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:21:46 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:46 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:21:46 --> URI Class Initialized
INFO - 2020-02-13 13:21:46 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:21:46 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:46 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:46 --> Controller Class Initialized
INFO - 2020-02-13 13:21:46 --> URI Class Initialized
INFO - 2020-02-13 13:21:46 --> URI Class Initialized
INFO - 2020-02-13 13:21:46 --> Router Class Initialized
INFO - 2020-02-13 13:21:46 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:21:46 --> URI Class Initialized
INFO - 2020-02-13 13:21:46 --> Router Class Initialized
INFO - 2020-02-13 13:21:46 --> Output Class Initialized
INFO - 2020-02-13 13:21:46 --> Router Class Initialized
INFO - 2020-02-13 13:21:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:21:46 --> Router Class Initialized
INFO - 2020-02-13 13:21:46 --> Output Class Initialized
INFO - 2020-02-13 13:21:46 --> Output Class Initialized
INFO - 2020-02-13 13:21:46 --> Security Class Initialized
INFO - 2020-02-13 13:21:46 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 13:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:46 --> Security Class Initialized
INFO - 2020-02-13 13:21:46 --> Security Class Initialized
INFO - 2020-02-13 13:21:46 --> Output Class Initialized
INFO - 2020-02-13 13:21:46 --> Input Class Initialized
DEBUG - 2020-02-13 13:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:46 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:46 --> Helper loaded: form_helper
INFO - 2020-02-13 13:21:46 --> Input Class Initialized
INFO - 2020-02-13 13:21:46 --> Input Class Initialized
INFO - 2020-02-13 13:21:46 --> Form Validation Class Initialized
INFO - 2020-02-13 13:21:46 --> Language Class Initialized
DEBUG - 2020-02-13 13:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:46 --> Input Class Initialized
INFO - 2020-02-13 13:21:46 --> Language Class Initialized
INFO - 2020-02-13 13:21:46 --> Language Class Initialized
ERROR - 2020-02-13 13:21:46 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 13:21:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:21:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 13:21:46 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 13:21:46 --> Language Class Initialized
ERROR - 2020-02-13 13:21:46 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 13:21:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 13:21:46 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 13:21:46 --> Final output sent to browser
INFO - 2020-02-13 13:21:46 --> Config Class Initialized
DEBUG - 2020-02-13 13:21:46 --> Total execution time: 1.2479
INFO - 2020-02-13 13:21:46 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:46 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:46 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:46 --> URI Class Initialized
INFO - 2020-02-13 13:21:46 --> Router Class Initialized
INFO - 2020-02-13 13:21:46 --> Output Class Initialized
INFO - 2020-02-13 13:21:46 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:46 --> Input Class Initialized
INFO - 2020-02-13 13:21:46 --> Language Class Initialized
ERROR - 2020-02-13 13:21:46 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 13:21:47 --> Config Class Initialized
INFO - 2020-02-13 13:21:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:47 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:47 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:47 --> URI Class Initialized
INFO - 2020-02-13 13:21:47 --> Router Class Initialized
INFO - 2020-02-13 13:21:47 --> Output Class Initialized
INFO - 2020-02-13 13:21:47 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:47 --> Input Class Initialized
INFO - 2020-02-13 13:21:47 --> Language Class Initialized
ERROR - 2020-02-13 13:21:47 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 13:21:47 --> Config Class Initialized
INFO - 2020-02-13 13:21:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:47 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:47 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:47 --> URI Class Initialized
INFO - 2020-02-13 13:21:47 --> Router Class Initialized
INFO - 2020-02-13 13:21:47 --> Output Class Initialized
INFO - 2020-02-13 13:21:47 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:47 --> Input Class Initialized
INFO - 2020-02-13 13:21:47 --> Language Class Initialized
ERROR - 2020-02-13 13:21:47 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 13:21:47 --> Config Class Initialized
INFO - 2020-02-13 13:21:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:47 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:47 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:47 --> URI Class Initialized
INFO - 2020-02-13 13:21:47 --> Router Class Initialized
INFO - 2020-02-13 13:21:48 --> Output Class Initialized
INFO - 2020-02-13 13:21:48 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:48 --> Input Class Initialized
INFO - 2020-02-13 13:21:48 --> Language Class Initialized
ERROR - 2020-02-13 13:21:48 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:21:48 --> Config Class Initialized
INFO - 2020-02-13 13:21:48 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:48 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:48 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:48 --> URI Class Initialized
INFO - 2020-02-13 13:21:48 --> Router Class Initialized
INFO - 2020-02-13 13:21:48 --> Output Class Initialized
INFO - 2020-02-13 13:21:48 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:48 --> Input Class Initialized
INFO - 2020-02-13 13:21:48 --> Language Class Initialized
ERROR - 2020-02-13 13:21:48 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:21:48 --> Config Class Initialized
INFO - 2020-02-13 13:21:48 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:48 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:48 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:48 --> URI Class Initialized
INFO - 2020-02-13 13:21:48 --> Router Class Initialized
INFO - 2020-02-13 13:21:48 --> Output Class Initialized
INFO - 2020-02-13 13:21:48 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:48 --> Input Class Initialized
INFO - 2020-02-13 13:21:48 --> Language Class Initialized
ERROR - 2020-02-13 13:21:48 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 13:21:48 --> Config Class Initialized
INFO - 2020-02-13 13:21:48 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:49 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:49 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:49 --> URI Class Initialized
INFO - 2020-02-13 13:21:49 --> Router Class Initialized
INFO - 2020-02-13 13:21:49 --> Output Class Initialized
INFO - 2020-02-13 13:21:49 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:49 --> Input Class Initialized
INFO - 2020-02-13 13:21:49 --> Language Class Initialized
ERROR - 2020-02-13 13:21:49 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 13:21:49 --> Config Class Initialized
INFO - 2020-02-13 13:21:49 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:49 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:49 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:49 --> URI Class Initialized
INFO - 2020-02-13 13:21:49 --> Router Class Initialized
INFO - 2020-02-13 13:21:49 --> Output Class Initialized
INFO - 2020-02-13 13:21:49 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:49 --> Input Class Initialized
INFO - 2020-02-13 13:21:49 --> Language Class Initialized
ERROR - 2020-02-13 13:21:49 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 13:21:49 --> Config Class Initialized
INFO - 2020-02-13 13:21:49 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:21:49 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:21:49 --> Utf8 Class Initialized
INFO - 2020-02-13 13:21:49 --> URI Class Initialized
INFO - 2020-02-13 13:21:49 --> Router Class Initialized
INFO - 2020-02-13 13:21:49 --> Output Class Initialized
INFO - 2020-02-13 13:21:49 --> Security Class Initialized
DEBUG - 2020-02-13 13:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:21:49 --> Input Class Initialized
INFO - 2020-02-13 13:21:49 --> Language Class Initialized
ERROR - 2020-02-13 13:21:50 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 13:22:11 --> Config Class Initialized
INFO - 2020-02-13 13:22:11 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:22:11 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:22:11 --> Utf8 Class Initialized
INFO - 2020-02-13 13:22:11 --> URI Class Initialized
INFO - 2020-02-13 13:22:11 --> Router Class Initialized
INFO - 2020-02-13 13:22:11 --> Output Class Initialized
INFO - 2020-02-13 13:22:11 --> Security Class Initialized
DEBUG - 2020-02-13 13:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:22:11 --> Input Class Initialized
INFO - 2020-02-13 13:22:11 --> Language Class Initialized
INFO - 2020-02-13 13:22:11 --> Loader Class Initialized
INFO - 2020-02-13 13:22:11 --> Helper loaded: url_helper
INFO - 2020-02-13 13:22:11 --> Helper loaded: string_helper
INFO - 2020-02-13 13:22:11 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:22:11 --> Controller Class Initialized
INFO - 2020-02-13 13:22:12 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:22:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:22:12 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:22:12 --> Helper loaded: form_helper
INFO - 2020-02-13 13:22:12 --> Form Validation Class Initialized
INFO - 2020-02-13 13:22:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 13:22:12 --> Final output sent to browser
DEBUG - 2020-02-13 13:22:12 --> Total execution time: 0.9097
INFO - 2020-02-13 13:26:45 --> Config Class Initialized
INFO - 2020-02-13 13:26:45 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:26:45 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:26:45 --> Utf8 Class Initialized
INFO - 2020-02-13 13:26:45 --> URI Class Initialized
INFO - 2020-02-13 13:26:45 --> Router Class Initialized
INFO - 2020-02-13 13:26:45 --> Output Class Initialized
INFO - 2020-02-13 13:26:45 --> Security Class Initialized
DEBUG - 2020-02-13 13:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:26:45 --> Input Class Initialized
INFO - 2020-02-13 13:26:45 --> Language Class Initialized
INFO - 2020-02-13 13:26:45 --> Loader Class Initialized
INFO - 2020-02-13 13:26:45 --> Helper loaded: url_helper
INFO - 2020-02-13 13:26:45 --> Helper loaded: string_helper
INFO - 2020-02-13 13:26:45 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:26:45 --> Controller Class Initialized
INFO - 2020-02-13 13:26:45 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:26:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:26:45 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:26:46 --> Helper loaded: form_helper
INFO - 2020-02-13 13:26:46 --> Form Validation Class Initialized
INFO - 2020-02-13 13:26:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:26:46 --> Final output sent to browser
DEBUG - 2020-02-13 13:26:46 --> Total execution time: 0.7784
INFO - 2020-02-13 13:26:46 --> Config Class Initialized
INFO - 2020-02-13 13:26:46 --> Config Class Initialized
INFO - 2020-02-13 13:26:46 --> Hooks Class Initialized
INFO - 2020-02-13 13:26:46 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:26:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:26:46 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:26:46 --> Utf8 Class Initialized
INFO - 2020-02-13 13:26:46 --> Utf8 Class Initialized
INFO - 2020-02-13 13:26:46 --> URI Class Initialized
INFO - 2020-02-13 13:26:46 --> URI Class Initialized
INFO - 2020-02-13 13:26:46 --> Router Class Initialized
INFO - 2020-02-13 13:26:46 --> Router Class Initialized
INFO - 2020-02-13 13:26:46 --> Output Class Initialized
INFO - 2020-02-13 13:26:46 --> Output Class Initialized
INFO - 2020-02-13 13:26:46 --> Security Class Initialized
INFO - 2020-02-13 13:26:46 --> Security Class Initialized
DEBUG - 2020-02-13 13:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:26:46 --> Input Class Initialized
INFO - 2020-02-13 13:26:46 --> Input Class Initialized
INFO - 2020-02-13 13:26:46 --> Language Class Initialized
INFO - 2020-02-13 13:26:46 --> Language Class Initialized
INFO - 2020-02-13 13:26:46 --> Loader Class Initialized
INFO - 2020-02-13 13:26:46 --> Loader Class Initialized
INFO - 2020-02-13 13:26:46 --> Helper loaded: url_helper
INFO - 2020-02-13 13:26:46 --> Helper loaded: url_helper
INFO - 2020-02-13 13:26:46 --> Helper loaded: string_helper
INFO - 2020-02-13 13:26:46 --> Helper loaded: string_helper
INFO - 2020-02-13 13:26:46 --> Database Driver Class Initialized
INFO - 2020-02-13 13:26:46 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 13:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:26:46 --> Controller Class Initialized
INFO - 2020-02-13 13:26:46 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:26:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:26:47 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:26:47 --> Helper loaded: form_helper
INFO - 2020-02-13 13:26:47 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:26:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:26:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:26:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:26:47 --> Final output sent to browser
DEBUG - 2020-02-13 13:26:47 --> Total execution time: 0.9367
INFO - 2020-02-13 13:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:26:47 --> Controller Class Initialized
INFO - 2020-02-13 13:26:47 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:26:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:26:47 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:26:47 --> Helper loaded: form_helper
INFO - 2020-02-13 13:26:47 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:26:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:26:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:26:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:26:47 --> Final output sent to browser
DEBUG - 2020-02-13 13:26:47 --> Total execution time: 1.3165
INFO - 2020-02-13 13:30:58 --> Config Class Initialized
INFO - 2020-02-13 13:30:58 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:30:58 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:30:58 --> Utf8 Class Initialized
INFO - 2020-02-13 13:30:58 --> URI Class Initialized
INFO - 2020-02-13 13:30:58 --> Router Class Initialized
INFO - 2020-02-13 13:30:58 --> Output Class Initialized
INFO - 2020-02-13 13:30:58 --> Security Class Initialized
DEBUG - 2020-02-13 13:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:30:58 --> Input Class Initialized
INFO - 2020-02-13 13:30:58 --> Language Class Initialized
INFO - 2020-02-13 13:30:58 --> Loader Class Initialized
INFO - 2020-02-13 13:30:58 --> Helper loaded: url_helper
INFO - 2020-02-13 13:30:58 --> Helper loaded: string_helper
INFO - 2020-02-13 13:30:58 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:30:58 --> Controller Class Initialized
INFO - 2020-02-13 13:30:58 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:30:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:30:58 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:30:58 --> Helper loaded: form_helper
INFO - 2020-02-13 13:30:58 --> Form Validation Class Initialized
INFO - 2020-02-13 13:30:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:30:58 --> Final output sent to browser
INFO - 2020-02-13 13:30:58 --> Config Class Initialized
INFO - 2020-02-13 13:30:58 --> Config Class Initialized
INFO - 2020-02-13 13:30:58 --> Config Class Initialized
INFO - 2020-02-13 13:30:58 --> Hooks Class Initialized
INFO - 2020-02-13 13:30:58 --> Config Class Initialized
INFO - 2020-02-13 13:30:58 --> Hooks Class Initialized
INFO - 2020-02-13 13:30:58 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:30:58 --> Total execution time: 0.8048
INFO - 2020-02-13 13:30:58 --> Config Class Initialized
INFO - 2020-02-13 13:30:58 --> Hooks Class Initialized
INFO - 2020-02-13 13:30:58 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:30:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:30:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:30:59 --> Config Class Initialized
DEBUG - 2020-02-13 13:30:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:30:59 --> Hooks Class Initialized
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:30:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:30:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
DEBUG - 2020-02-13 13:30:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
INFO - 2020-02-13 13:30:59 --> Router Class Initialized
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:30:59 --> Router Class Initialized
INFO - 2020-02-13 13:30:59 --> Router Class Initialized
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
INFO - 2020-02-13 13:30:59 --> Router Class Initialized
INFO - 2020-02-13 13:30:59 --> Output Class Initialized
INFO - 2020-02-13 13:30:59 --> Output Class Initialized
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
INFO - 2020-02-13 13:30:59 --> Router Class Initialized
INFO - 2020-02-13 13:30:59 --> Output Class Initialized
INFO - 2020-02-13 13:30:59 --> Security Class Initialized
INFO - 2020-02-13 13:30:59 --> Security Class Initialized
INFO - 2020-02-13 13:30:59 --> Output Class Initialized
INFO - 2020-02-13 13:30:59 --> Router Class Initialized
INFO - 2020-02-13 13:30:59 --> Security Class Initialized
INFO - 2020-02-13 13:30:59 --> Output Class Initialized
DEBUG - 2020-02-13 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:30:59 --> Security Class Initialized
DEBUG - 2020-02-13 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:30:59 --> Security Class Initialized
DEBUG - 2020-02-13 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:30:59 --> Output Class Initialized
INFO - 2020-02-13 13:30:59 --> Input Class Initialized
INFO - 2020-02-13 13:30:59 --> Input Class Initialized
INFO - 2020-02-13 13:30:59 --> Input Class Initialized
INFO - 2020-02-13 13:30:59 --> Security Class Initialized
DEBUG - 2020-02-13 13:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:30:59 --> Input Class Initialized
INFO - 2020-02-13 13:30:59 --> Input Class Initialized
INFO - 2020-02-13 13:30:59 --> Language Class Initialized
DEBUG - 2020-02-13 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:30:59 --> Language Class Initialized
INFO - 2020-02-13 13:30:59 --> Language Class Initialized
INFO - 2020-02-13 13:30:59 --> Input Class Initialized
ERROR - 2020-02-13 13:30:59 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 13:30:59 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 13:30:59 --> Language Class Initialized
INFO - 2020-02-13 13:30:59 --> Language Class Initialized
ERROR - 2020-02-13 13:30:59 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 13:30:59 --> Language Class Initialized
ERROR - 2020-02-13 13:30:59 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 13:30:59 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 13:30:59 --> Config Class Initialized
INFO - 2020-02-13 13:30:59 --> Config Class Initialized
INFO - 2020-02-13 13:30:59 --> Config Class Initialized
INFO - 2020-02-13 13:30:59 --> Hooks Class Initialized
INFO - 2020-02-13 13:30:59 --> Hooks Class Initialized
INFO - 2020-02-13 13:30:59 --> Hooks Class Initialized
ERROR - 2020-02-13 13:30:59 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:30:59 --> Config Class Initialized
INFO - 2020-02-13 13:30:59 --> Config Class Initialized
INFO - 2020-02-13 13:30:59 --> Hooks Class Initialized
INFO - 2020-02-13 13:30:59 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:30:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:30:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:30:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:30:59 --> Config Class Initialized
INFO - 2020-02-13 13:30:59 --> Hooks Class Initialized
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:30:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:30:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
DEBUG - 2020-02-13 13:30:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
INFO - 2020-02-13 13:30:59 --> Router Class Initialized
INFO - 2020-02-13 13:30:59 --> Router Class Initialized
INFO - 2020-02-13 13:30:59 --> Router Class Initialized
INFO - 2020-02-13 13:30:59 --> Output Class Initialized
INFO - 2020-02-13 13:30:59 --> Output Class Initialized
INFO - 2020-02-13 13:30:59 --> Router Class Initialized
INFO - 2020-02-13 13:30:59 --> Router Class Initialized
INFO - 2020-02-13 13:30:59 --> Output Class Initialized
INFO - 2020-02-13 13:30:59 --> Security Class Initialized
INFO - 2020-02-13 13:30:59 --> Security Class Initialized
INFO - 2020-02-13 13:30:59 --> Output Class Initialized
INFO - 2020-02-13 13:30:59 --> Output Class Initialized
INFO - 2020-02-13 13:30:59 --> Security Class Initialized
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
DEBUG - 2020-02-13 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:30:59 --> Security Class Initialized
DEBUG - 2020-02-13 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:30:59 --> Security Class Initialized
INFO - 2020-02-13 13:30:59 --> Router Class Initialized
DEBUG - 2020-02-13 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:30:59 --> Input Class Initialized
INFO - 2020-02-13 13:30:59 --> Input Class Initialized
INFO - 2020-02-13 13:30:59 --> Input Class Initialized
DEBUG - 2020-02-13 13:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:30:59 --> Output Class Initialized
INFO - 2020-02-13 13:30:59 --> Input Class Initialized
INFO - 2020-02-13 13:30:59 --> Language Class Initialized
INFO - 2020-02-13 13:30:59 --> Language Class Initialized
INFO - 2020-02-13 13:30:59 --> Input Class Initialized
INFO - 2020-02-13 13:30:59 --> Language Class Initialized
INFO - 2020-02-13 13:30:59 --> Security Class Initialized
INFO - 2020-02-13 13:30:59 --> Language Class Initialized
ERROR - 2020-02-13 13:30:59 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:30:59 --> Language Class Initialized
INFO - 2020-02-13 13:30:59 --> Loader Class Initialized
INFO - 2020-02-13 13:30:59 --> Loader Class Initialized
DEBUG - 2020-02-13 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:30:59 --> Input Class Initialized
ERROR - 2020-02-13 13:30:59 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 13:30:59 --> Helper loaded: url_helper
INFO - 2020-02-13 13:30:59 --> Language Class Initialized
INFO - 2020-02-13 13:30:59 --> Helper loaded: url_helper
ERROR - 2020-02-13 13:30:59 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 13:30:59 --> Config Class Initialized
INFO - 2020-02-13 13:30:59 --> Hooks Class Initialized
INFO - 2020-02-13 13:30:59 --> Helper loaded: string_helper
ERROR - 2020-02-13 13:30:59 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 13:30:59 --> Helper loaded: string_helper
INFO - 2020-02-13 13:30:59 --> Config Class Initialized
INFO - 2020-02-13 13:30:59 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:30:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:30:59 --> Database Driver Class Initialized
INFO - 2020-02-13 13:30:59 --> Database Driver Class Initialized
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:30:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 13:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:30:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
INFO - 2020-02-13 13:30:59 --> Controller Class Initialized
INFO - 2020-02-13 13:30:59 --> URI Class Initialized
INFO - 2020-02-13 13:30:59 --> Router Class Initialized
INFO - 2020-02-13 13:31:00 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:31:00 --> Router Class Initialized
INFO - 2020-02-13 13:31:00 --> Output Class Initialized
INFO - 2020-02-13 13:31:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:31:00 --> Security Class Initialized
INFO - 2020-02-13 13:31:00 --> Output Class Initialized
INFO - 2020-02-13 13:31:00 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 13:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:31:00 --> Security Class Initialized
INFO - 2020-02-13 13:31:00 --> Input Class Initialized
DEBUG - 2020-02-13 13:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:31:00 --> Helper loaded: form_helper
INFO - 2020-02-13 13:31:00 --> Form Validation Class Initialized
INFO - 2020-02-13 13:31:00 --> Input Class Initialized
INFO - 2020-02-13 13:31:00 --> Language Class Initialized
INFO - 2020-02-13 13:31:00 --> Language Class Initialized
ERROR - 2020-02-13 13:31:00 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 13:31:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:31:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 13:31:00 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 13:31:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:31:00 --> Config Class Initialized
INFO - 2020-02-13 13:31:00 --> Hooks Class Initialized
INFO - 2020-02-13 13:31:00 --> Final output sent to browser
DEBUG - 2020-02-13 13:31:00 --> Total execution time: 0.9324
DEBUG - 2020-02-13 13:31:00 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:31:00 --> Utf8 Class Initialized
INFO - 2020-02-13 13:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:31:00 --> Controller Class Initialized
INFO - 2020-02-13 13:31:00 --> URI Class Initialized
INFO - 2020-02-13 13:31:00 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:31:00 --> Router Class Initialized
INFO - 2020-02-13 13:31:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:31:00 --> Output Class Initialized
INFO - 2020-02-13 13:31:00 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:31:00 --> Security Class Initialized
DEBUG - 2020-02-13 13:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:31:00 --> Helper loaded: form_helper
INFO - 2020-02-13 13:31:00 --> Input Class Initialized
INFO - 2020-02-13 13:31:00 --> Form Validation Class Initialized
INFO - 2020-02-13 13:31:00 --> Language Class Initialized
ERROR - 2020-02-13 13:31:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:31:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 13:31:00 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 13:31:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:31:00 --> Config Class Initialized
INFO - 2020-02-13 13:31:00 --> Hooks Class Initialized
INFO - 2020-02-13 13:31:00 --> Final output sent to browser
DEBUG - 2020-02-13 13:31:00 --> Total execution time: 1.3258
DEBUG - 2020-02-13 13:31:00 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:31:00 --> Utf8 Class Initialized
INFO - 2020-02-13 13:31:00 --> URI Class Initialized
INFO - 2020-02-13 13:31:00 --> Router Class Initialized
INFO - 2020-02-13 13:31:00 --> Output Class Initialized
INFO - 2020-02-13 13:31:00 --> Security Class Initialized
DEBUG - 2020-02-13 13:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:31:00 --> Input Class Initialized
INFO - 2020-02-13 13:31:00 --> Language Class Initialized
ERROR - 2020-02-13 13:31:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 13:31:01 --> Config Class Initialized
INFO - 2020-02-13 13:31:01 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:31:01 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:31:01 --> Utf8 Class Initialized
INFO - 2020-02-13 13:31:01 --> URI Class Initialized
INFO - 2020-02-13 13:31:01 --> Router Class Initialized
INFO - 2020-02-13 13:31:01 --> Output Class Initialized
INFO - 2020-02-13 13:31:01 --> Security Class Initialized
DEBUG - 2020-02-13 13:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:31:01 --> Input Class Initialized
INFO - 2020-02-13 13:31:01 --> Language Class Initialized
ERROR - 2020-02-13 13:31:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:31:01 --> Config Class Initialized
INFO - 2020-02-13 13:31:01 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:31:01 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:31:01 --> Utf8 Class Initialized
INFO - 2020-02-13 13:31:01 --> URI Class Initialized
INFO - 2020-02-13 13:31:01 --> Router Class Initialized
INFO - 2020-02-13 13:31:01 --> Output Class Initialized
INFO - 2020-02-13 13:31:01 --> Security Class Initialized
DEBUG - 2020-02-13 13:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:31:01 --> Input Class Initialized
INFO - 2020-02-13 13:31:01 --> Language Class Initialized
ERROR - 2020-02-13 13:31:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:31:01 --> Config Class Initialized
INFO - 2020-02-13 13:31:01 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:31:01 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:31:01 --> Utf8 Class Initialized
INFO - 2020-02-13 13:31:01 --> URI Class Initialized
INFO - 2020-02-13 13:31:02 --> Router Class Initialized
INFO - 2020-02-13 13:31:02 --> Output Class Initialized
INFO - 2020-02-13 13:31:02 --> Security Class Initialized
DEBUG - 2020-02-13 13:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:31:02 --> Input Class Initialized
INFO - 2020-02-13 13:31:02 --> Language Class Initialized
ERROR - 2020-02-13 13:31:02 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 13:31:02 --> Config Class Initialized
INFO - 2020-02-13 13:31:02 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:31:02 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:31:02 --> Utf8 Class Initialized
INFO - 2020-02-13 13:31:02 --> URI Class Initialized
INFO - 2020-02-13 13:31:02 --> Router Class Initialized
INFO - 2020-02-13 13:31:02 --> Output Class Initialized
INFO - 2020-02-13 13:31:02 --> Security Class Initialized
DEBUG - 2020-02-13 13:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:31:02 --> Input Class Initialized
INFO - 2020-02-13 13:31:02 --> Language Class Initialized
ERROR - 2020-02-13 13:31:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 13:31:02 --> Config Class Initialized
INFO - 2020-02-13 13:31:02 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:31:02 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:31:02 --> Utf8 Class Initialized
INFO - 2020-02-13 13:31:02 --> URI Class Initialized
INFO - 2020-02-13 13:31:02 --> Router Class Initialized
INFO - 2020-02-13 13:31:02 --> Output Class Initialized
INFO - 2020-02-13 13:31:02 --> Security Class Initialized
DEBUG - 2020-02-13 13:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:31:02 --> Input Class Initialized
INFO - 2020-02-13 13:31:02 --> Language Class Initialized
ERROR - 2020-02-13 13:31:02 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 13:31:03 --> Config Class Initialized
INFO - 2020-02-13 13:31:03 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:31:03 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:31:03 --> Utf8 Class Initialized
INFO - 2020-02-13 13:31:03 --> URI Class Initialized
INFO - 2020-02-13 13:31:03 --> Router Class Initialized
INFO - 2020-02-13 13:31:03 --> Output Class Initialized
INFO - 2020-02-13 13:31:03 --> Security Class Initialized
DEBUG - 2020-02-13 13:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:31:03 --> Input Class Initialized
INFO - 2020-02-13 13:31:03 --> Language Class Initialized
ERROR - 2020-02-13 13:31:03 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 13:31:31 --> Config Class Initialized
INFO - 2020-02-13 13:31:31 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:31:31 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:31:31 --> Utf8 Class Initialized
INFO - 2020-02-13 13:31:31 --> URI Class Initialized
INFO - 2020-02-13 13:31:31 --> Router Class Initialized
INFO - 2020-02-13 13:31:31 --> Output Class Initialized
INFO - 2020-02-13 13:31:31 --> Security Class Initialized
DEBUG - 2020-02-13 13:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:31:31 --> Input Class Initialized
INFO - 2020-02-13 13:31:31 --> Language Class Initialized
INFO - 2020-02-13 13:31:31 --> Loader Class Initialized
INFO - 2020-02-13 13:31:31 --> Helper loaded: url_helper
INFO - 2020-02-13 13:31:31 --> Helper loaded: string_helper
INFO - 2020-02-13 13:31:31 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:31:31 --> Controller Class Initialized
INFO - 2020-02-13 13:31:32 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:31:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:31:32 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:31:32 --> Helper loaded: form_helper
INFO - 2020-02-13 13:31:32 --> Form Validation Class Initialized
INFO - 2020-02-13 13:31:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 13:31:32 --> Final output sent to browser
DEBUG - 2020-02-13 13:31:32 --> Total execution time: 0.9653
INFO - 2020-02-13 13:37:46 --> Config Class Initialized
INFO - 2020-02-13 13:37:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:37:47 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:37:47 --> Utf8 Class Initialized
INFO - 2020-02-13 13:37:47 --> URI Class Initialized
INFO - 2020-02-13 13:37:47 --> Router Class Initialized
INFO - 2020-02-13 13:37:47 --> Output Class Initialized
INFO - 2020-02-13 13:37:47 --> Security Class Initialized
DEBUG - 2020-02-13 13:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:37:47 --> Input Class Initialized
INFO - 2020-02-13 13:37:47 --> Language Class Initialized
INFO - 2020-02-13 13:37:47 --> Loader Class Initialized
INFO - 2020-02-13 13:37:47 --> Helper loaded: url_helper
INFO - 2020-02-13 13:37:47 --> Helper loaded: string_helper
INFO - 2020-02-13 13:37:47 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:37:47 --> Controller Class Initialized
INFO - 2020-02-13 13:37:47 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:37:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:37:47 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:37:47 --> Helper loaded: form_helper
INFO - 2020-02-13 13:37:47 --> Form Validation Class Initialized
INFO - 2020-02-13 13:37:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:37:47 --> Final output sent to browser
INFO - 2020-02-13 13:37:47 --> Config Class Initialized
DEBUG - 2020-02-13 13:37:48 --> Total execution time: 1.2580
INFO - 2020-02-13 13:37:48 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:37:48 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:37:48 --> Utf8 Class Initialized
INFO - 2020-02-13 13:37:48 --> URI Class Initialized
INFO - 2020-02-13 13:37:48 --> Router Class Initialized
INFO - 2020-02-13 13:37:48 --> Output Class Initialized
INFO - 2020-02-13 13:37:48 --> Security Class Initialized
DEBUG - 2020-02-13 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:37:48 --> Input Class Initialized
INFO - 2020-02-13 13:37:48 --> Language Class Initialized
ERROR - 2020-02-13 13:37:48 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 13:38:00 --> Config Class Initialized
INFO - 2020-02-13 13:38:00 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:38:00 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:38:00 --> Utf8 Class Initialized
INFO - 2020-02-13 13:38:00 --> URI Class Initialized
INFO - 2020-02-13 13:38:00 --> Router Class Initialized
INFO - 2020-02-13 13:38:00 --> Output Class Initialized
INFO - 2020-02-13 13:38:00 --> Security Class Initialized
DEBUG - 2020-02-13 13:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:38:00 --> Input Class Initialized
INFO - 2020-02-13 13:38:00 --> Language Class Initialized
INFO - 2020-02-13 13:38:00 --> Loader Class Initialized
INFO - 2020-02-13 13:38:00 --> Helper loaded: url_helper
INFO - 2020-02-13 13:38:00 --> Helper loaded: string_helper
INFO - 2020-02-13 13:38:00 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:38:01 --> Controller Class Initialized
INFO - 2020-02-13 13:38:01 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:38:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:38:01 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:38:01 --> Helper loaded: form_helper
INFO - 2020-02-13 13:38:01 --> Form Validation Class Initialized
INFO - 2020-02-13 13:38:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 13:38:01 --> Final output sent to browser
DEBUG - 2020-02-13 13:38:01 --> Total execution time: 1.1463
INFO - 2020-02-13 13:39:16 --> Config Class Initialized
INFO - 2020-02-13 13:39:16 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:39:16 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:39:16 --> Utf8 Class Initialized
INFO - 2020-02-13 13:39:16 --> URI Class Initialized
INFO - 2020-02-13 13:39:16 --> Router Class Initialized
INFO - 2020-02-13 13:39:16 --> Output Class Initialized
INFO - 2020-02-13 13:39:16 --> Security Class Initialized
DEBUG - 2020-02-13 13:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:39:16 --> Input Class Initialized
INFO - 2020-02-13 13:39:16 --> Language Class Initialized
INFO - 2020-02-13 13:39:16 --> Loader Class Initialized
INFO - 2020-02-13 13:39:17 --> Helper loaded: url_helper
INFO - 2020-02-13 13:39:17 --> Helper loaded: string_helper
INFO - 2020-02-13 13:39:17 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:39:17 --> Controller Class Initialized
INFO - 2020-02-13 13:39:17 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:39:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:39:17 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:39:17 --> Helper loaded: form_helper
INFO - 2020-02-13 13:39:17 --> Form Validation Class Initialized
INFO - 2020-02-13 13:39:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:39:17 --> Final output sent to browser
INFO - 2020-02-13 13:39:17 --> Config Class Initialized
INFO - 2020-02-13 13:39:17 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:39:17 --> Total execution time: 0.7977
INFO - 2020-02-13 13:39:17 --> Config Class Initialized
INFO - 2020-02-13 13:39:17 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:39:17 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:39:17 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:39:17 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:39:17 --> Utf8 Class Initialized
INFO - 2020-02-13 13:39:17 --> URI Class Initialized
INFO - 2020-02-13 13:39:17 --> URI Class Initialized
INFO - 2020-02-13 13:39:17 --> Router Class Initialized
INFO - 2020-02-13 13:39:17 --> Router Class Initialized
INFO - 2020-02-13 13:39:17 --> Output Class Initialized
INFO - 2020-02-13 13:39:17 --> Output Class Initialized
INFO - 2020-02-13 13:39:17 --> Security Class Initialized
DEBUG - 2020-02-13 13:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:39:17 --> Security Class Initialized
INFO - 2020-02-13 13:39:17 --> Input Class Initialized
DEBUG - 2020-02-13 13:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:39:17 --> Input Class Initialized
INFO - 2020-02-13 13:39:17 --> Language Class Initialized
INFO - 2020-02-13 13:39:17 --> Language Class Initialized
INFO - 2020-02-13 13:39:17 --> Loader Class Initialized
INFO - 2020-02-13 13:39:17 --> Helper loaded: url_helper
INFO - 2020-02-13 13:39:17 --> Loader Class Initialized
INFO - 2020-02-13 13:39:18 --> Helper loaded: string_helper
INFO - 2020-02-13 13:39:18 --> Helper loaded: url_helper
INFO - 2020-02-13 13:39:18 --> Helper loaded: string_helper
INFO - 2020-02-13 13:39:18 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:39:18 --> Database Driver Class Initialized
INFO - 2020-02-13 13:39:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 13:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:39:18 --> Controller Class Initialized
INFO - 2020-02-13 13:39:18 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:39:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:39:18 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:39:18 --> Helper loaded: form_helper
INFO - 2020-02-13 13:39:18 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:39:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:39:18 --> Final output sent to browser
DEBUG - 2020-02-13 13:39:18 --> Total execution time: 0.9201
INFO - 2020-02-13 13:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:39:18 --> Controller Class Initialized
INFO - 2020-02-13 13:39:18 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:39:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:39:18 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:39:18 --> Helper loaded: form_helper
INFO - 2020-02-13 13:39:18 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:39:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:39:18 --> Final output sent to browser
DEBUG - 2020-02-13 13:39:18 --> Total execution time: 1.2715
INFO - 2020-02-13 13:39:21 --> Config Class Initialized
INFO - 2020-02-13 13:39:21 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:39:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:39:21 --> Utf8 Class Initialized
INFO - 2020-02-13 13:39:21 --> URI Class Initialized
INFO - 2020-02-13 13:39:21 --> Router Class Initialized
INFO - 2020-02-13 13:39:21 --> Output Class Initialized
INFO - 2020-02-13 13:39:21 --> Security Class Initialized
DEBUG - 2020-02-13 13:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:39:22 --> Input Class Initialized
INFO - 2020-02-13 13:39:22 --> Language Class Initialized
INFO - 2020-02-13 13:39:22 --> Loader Class Initialized
INFO - 2020-02-13 13:39:22 --> Helper loaded: url_helper
INFO - 2020-02-13 13:39:22 --> Helper loaded: string_helper
INFO - 2020-02-13 13:39:22 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:39:22 --> Controller Class Initialized
INFO - 2020-02-13 13:39:22 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:39:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:39:22 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:39:22 --> Helper loaded: form_helper
INFO - 2020-02-13 13:39:22 --> Form Validation Class Initialized
INFO - 2020-02-13 13:39:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 13:39:22 --> Final output sent to browser
DEBUG - 2020-02-13 13:39:22 --> Total execution time: 0.9360
INFO - 2020-02-13 13:43:01 --> Config Class Initialized
INFO - 2020-02-13 13:43:01 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:43:01 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:43:01 --> Utf8 Class Initialized
INFO - 2020-02-13 13:43:01 --> URI Class Initialized
INFO - 2020-02-13 13:43:01 --> Router Class Initialized
INFO - 2020-02-13 13:43:01 --> Output Class Initialized
INFO - 2020-02-13 13:43:01 --> Security Class Initialized
DEBUG - 2020-02-13 13:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:43:01 --> Input Class Initialized
INFO - 2020-02-13 13:43:01 --> Language Class Initialized
INFO - 2020-02-13 13:43:01 --> Loader Class Initialized
INFO - 2020-02-13 13:43:01 --> Helper loaded: url_helper
INFO - 2020-02-13 13:43:01 --> Helper loaded: string_helper
INFO - 2020-02-13 13:43:01 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:43:01 --> Controller Class Initialized
INFO - 2020-02-13 13:43:01 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:43:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:43:01 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:43:01 --> Helper loaded: form_helper
INFO - 2020-02-13 13:43:01 --> Form Validation Class Initialized
INFO - 2020-02-13 13:43:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:43:01 --> Final output sent to browser
INFO - 2020-02-13 13:43:02 --> Config Class Initialized
INFO - 2020-02-13 13:43:02 --> Config Class Initialized
INFO - 2020-02-13 13:43:02 --> Hooks Class Initialized
INFO - 2020-02-13 13:43:02 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:43:02 --> Total execution time: 0.9103
DEBUG - 2020-02-13 13:43:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:43:02 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:43:02 --> Utf8 Class Initialized
INFO - 2020-02-13 13:43:02 --> Utf8 Class Initialized
INFO - 2020-02-13 13:43:02 --> URI Class Initialized
INFO - 2020-02-13 13:43:02 --> URI Class Initialized
INFO - 2020-02-13 13:43:02 --> Router Class Initialized
INFO - 2020-02-13 13:43:02 --> Router Class Initialized
INFO - 2020-02-13 13:43:02 --> Output Class Initialized
INFO - 2020-02-13 13:43:02 --> Output Class Initialized
INFO - 2020-02-13 13:43:02 --> Security Class Initialized
INFO - 2020-02-13 13:43:02 --> Security Class Initialized
DEBUG - 2020-02-13 13:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:43:02 --> Input Class Initialized
INFO - 2020-02-13 13:43:02 --> Input Class Initialized
INFO - 2020-02-13 13:43:02 --> Language Class Initialized
INFO - 2020-02-13 13:43:02 --> Language Class Initialized
INFO - 2020-02-13 13:43:02 --> Loader Class Initialized
INFO - 2020-02-13 13:43:02 --> Loader Class Initialized
INFO - 2020-02-13 13:43:02 --> Helper loaded: url_helper
INFO - 2020-02-13 13:43:02 --> Helper loaded: url_helper
INFO - 2020-02-13 13:43:02 --> Helper loaded: string_helper
INFO - 2020-02-13 13:43:02 --> Helper loaded: string_helper
INFO - 2020-02-13 13:43:02 --> Database Driver Class Initialized
INFO - 2020-02-13 13:43:02 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 13:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:43:02 --> Controller Class Initialized
INFO - 2020-02-13 13:43:02 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:43:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:43:02 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:43:02 --> Helper loaded: form_helper
INFO - 2020-02-13 13:43:02 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:43:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:43:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:43:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:43:03 --> Final output sent to browser
DEBUG - 2020-02-13 13:43:03 --> Total execution time: 0.9739
INFO - 2020-02-13 13:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:43:03 --> Controller Class Initialized
INFO - 2020-02-13 13:43:03 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:43:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:43:03 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:43:03 --> Helper loaded: form_helper
INFO - 2020-02-13 13:43:03 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:43:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:43:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:43:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:43:03 --> Final output sent to browser
DEBUG - 2020-02-13 13:43:03 --> Total execution time: 1.3811
INFO - 2020-02-13 13:43:07 --> Config Class Initialized
INFO - 2020-02-13 13:43:07 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:43:07 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:43:07 --> Utf8 Class Initialized
INFO - 2020-02-13 13:43:07 --> URI Class Initialized
INFO - 2020-02-13 13:43:07 --> Router Class Initialized
INFO - 2020-02-13 13:43:07 --> Output Class Initialized
INFO - 2020-02-13 13:43:07 --> Security Class Initialized
DEBUG - 2020-02-13 13:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:43:07 --> Input Class Initialized
INFO - 2020-02-13 13:43:07 --> Language Class Initialized
INFO - 2020-02-13 13:43:07 --> Loader Class Initialized
INFO - 2020-02-13 13:43:07 --> Helper loaded: url_helper
INFO - 2020-02-13 13:43:07 --> Helper loaded: string_helper
INFO - 2020-02-13 13:43:07 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:43:07 --> Controller Class Initialized
INFO - 2020-02-13 13:43:07 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:43:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:43:07 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:43:07 --> Helper loaded: form_helper
INFO - 2020-02-13 13:43:07 --> Form Validation Class Initialized
INFO - 2020-02-13 13:43:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 13:43:08 --> Final output sent to browser
DEBUG - 2020-02-13 13:43:08 --> Total execution time: 0.9631
INFO - 2020-02-13 13:44:28 --> Config Class Initialized
INFO - 2020-02-13 13:44:28 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:44:28 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:44:28 --> Utf8 Class Initialized
INFO - 2020-02-13 13:44:28 --> URI Class Initialized
INFO - 2020-02-13 13:44:28 --> Router Class Initialized
INFO - 2020-02-13 13:44:28 --> Output Class Initialized
INFO - 2020-02-13 13:44:28 --> Security Class Initialized
DEBUG - 2020-02-13 13:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:44:28 --> Input Class Initialized
INFO - 2020-02-13 13:44:28 --> Language Class Initialized
INFO - 2020-02-13 13:44:28 --> Loader Class Initialized
INFO - 2020-02-13 13:44:28 --> Helper loaded: url_helper
INFO - 2020-02-13 13:44:28 --> Helper loaded: string_helper
INFO - 2020-02-13 13:44:28 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:44:28 --> Controller Class Initialized
INFO - 2020-02-13 13:44:28 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:44:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:44:29 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:44:29 --> Helper loaded: form_helper
INFO - 2020-02-13 13:44:29 --> Form Validation Class Initialized
INFO - 2020-02-13 13:44:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:44:29 --> Final output sent to browser
INFO - 2020-02-13 13:44:29 --> Config Class Initialized
INFO - 2020-02-13 13:44:29 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:44:29 --> Total execution time: 0.9525
INFO - 2020-02-13 13:44:29 --> Config Class Initialized
INFO - 2020-02-13 13:44:29 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:44:29 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:44:29 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:44:29 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:44:29 --> Utf8 Class Initialized
INFO - 2020-02-13 13:44:29 --> URI Class Initialized
INFO - 2020-02-13 13:44:29 --> URI Class Initialized
INFO - 2020-02-13 13:44:29 --> Router Class Initialized
INFO - 2020-02-13 13:44:29 --> Output Class Initialized
INFO - 2020-02-13 13:44:29 --> Router Class Initialized
INFO - 2020-02-13 13:44:29 --> Security Class Initialized
INFO - 2020-02-13 13:44:29 --> Output Class Initialized
DEBUG - 2020-02-13 13:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:44:29 --> Security Class Initialized
INFO - 2020-02-13 13:44:29 --> Input Class Initialized
DEBUG - 2020-02-13 13:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:44:29 --> Input Class Initialized
INFO - 2020-02-13 13:44:29 --> Language Class Initialized
INFO - 2020-02-13 13:44:29 --> Language Class Initialized
INFO - 2020-02-13 13:44:29 --> Loader Class Initialized
INFO - 2020-02-13 13:44:29 --> Helper loaded: url_helper
INFO - 2020-02-13 13:44:29 --> Loader Class Initialized
INFO - 2020-02-13 13:44:29 --> Helper loaded: string_helper
INFO - 2020-02-13 13:44:29 --> Helper loaded: url_helper
INFO - 2020-02-13 13:44:29 --> Helper loaded: string_helper
INFO - 2020-02-13 13:44:29 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:44:29 --> Database Driver Class Initialized
INFO - 2020-02-13 13:44:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 13:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:44:29 --> Controller Class Initialized
INFO - 2020-02-13 13:44:29 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:44:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:44:29 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:44:30 --> Helper loaded: form_helper
INFO - 2020-02-13 13:44:30 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:44:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:44:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:44:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:44:30 --> Final output sent to browser
DEBUG - 2020-02-13 13:44:30 --> Total execution time: 0.9479
INFO - 2020-02-13 13:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:44:30 --> Controller Class Initialized
INFO - 2020-02-13 13:44:30 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:44:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:44:30 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:44:30 --> Helper loaded: form_helper
INFO - 2020-02-13 13:44:30 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:44:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:44:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:44:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:44:30 --> Final output sent to browser
DEBUG - 2020-02-13 13:44:30 --> Total execution time: 1.3102
INFO - 2020-02-13 13:44:34 --> Config Class Initialized
INFO - 2020-02-13 13:44:34 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:44:34 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:44:34 --> Utf8 Class Initialized
INFO - 2020-02-13 13:44:34 --> URI Class Initialized
INFO - 2020-02-13 13:44:34 --> Router Class Initialized
INFO - 2020-02-13 13:44:34 --> Output Class Initialized
INFO - 2020-02-13 13:44:34 --> Security Class Initialized
DEBUG - 2020-02-13 13:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:44:34 --> Input Class Initialized
INFO - 2020-02-13 13:44:34 --> Language Class Initialized
INFO - 2020-02-13 13:44:34 --> Loader Class Initialized
INFO - 2020-02-13 13:44:34 --> Helper loaded: url_helper
INFO - 2020-02-13 13:44:34 --> Helper loaded: string_helper
INFO - 2020-02-13 13:44:34 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:44:34 --> Controller Class Initialized
INFO - 2020-02-13 13:44:34 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:44:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:44:34 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:44:34 --> Helper loaded: form_helper
INFO - 2020-02-13 13:44:35 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:44:35 --> Severity: Notice --> Undefined variable: unik C:\xampp\htdocs\roadshow\application\models\M_pesan.php 67
INFO - 2020-02-13 13:44:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 13:44:35 --> Final output sent to browser
DEBUG - 2020-02-13 13:44:35 --> Total execution time: 0.9867
INFO - 2020-02-13 13:45:09 --> Config Class Initialized
INFO - 2020-02-13 13:45:09 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:45:09 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:45:09 --> Utf8 Class Initialized
INFO - 2020-02-13 13:45:09 --> URI Class Initialized
INFO - 2020-02-13 13:45:09 --> Router Class Initialized
INFO - 2020-02-13 13:45:09 --> Output Class Initialized
INFO - 2020-02-13 13:45:09 --> Security Class Initialized
DEBUG - 2020-02-13 13:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:45:09 --> Input Class Initialized
INFO - 2020-02-13 13:45:09 --> Language Class Initialized
INFO - 2020-02-13 13:45:09 --> Loader Class Initialized
INFO - 2020-02-13 13:45:09 --> Helper loaded: url_helper
INFO - 2020-02-13 13:45:09 --> Helper loaded: string_helper
INFO - 2020-02-13 13:45:09 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:45:09 --> Controller Class Initialized
INFO - 2020-02-13 13:45:09 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:45:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:45:09 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:45:10 --> Helper loaded: form_helper
INFO - 2020-02-13 13:45:10 --> Form Validation Class Initialized
INFO - 2020-02-13 13:45:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 13:45:10 --> Final output sent to browser
DEBUG - 2020-02-13 13:45:10 --> Total execution time: 1.0109
INFO - 2020-02-13 13:47:06 --> Config Class Initialized
INFO - 2020-02-13 13:47:06 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:06 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:06 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:07 --> URI Class Initialized
INFO - 2020-02-13 13:47:07 --> Router Class Initialized
INFO - 2020-02-13 13:47:07 --> Output Class Initialized
INFO - 2020-02-13 13:47:07 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:07 --> Input Class Initialized
INFO - 2020-02-13 13:47:07 --> Language Class Initialized
INFO - 2020-02-13 13:47:07 --> Loader Class Initialized
INFO - 2020-02-13 13:47:07 --> Helper loaded: url_helper
INFO - 2020-02-13 13:47:07 --> Helper loaded: string_helper
INFO - 2020-02-13 13:47:07 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:47:07 --> Controller Class Initialized
INFO - 2020-02-13 13:47:07 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:47:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:47:07 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:47:07 --> Helper loaded: form_helper
INFO - 2020-02-13 13:47:07 --> Form Validation Class Initialized
INFO - 2020-02-13 13:47:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:47:07 --> Final output sent to browser
INFO - 2020-02-13 13:47:07 --> Config Class Initialized
INFO - 2020-02-13 13:47:07 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:07 --> Total execution time: 1.2355
INFO - 2020-02-13 13:47:07 --> Config Class Initialized
INFO - 2020-02-13 13:47:07 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:07 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:08 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:47:08 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:08 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:08 --> URI Class Initialized
INFO - 2020-02-13 13:47:08 --> URI Class Initialized
INFO - 2020-02-13 13:47:08 --> Router Class Initialized
INFO - 2020-02-13 13:47:08 --> Router Class Initialized
INFO - 2020-02-13 13:47:08 --> Output Class Initialized
INFO - 2020-02-13 13:47:08 --> Security Class Initialized
INFO - 2020-02-13 13:47:08 --> Output Class Initialized
DEBUG - 2020-02-13 13:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:08 --> Security Class Initialized
INFO - 2020-02-13 13:47:08 --> Input Class Initialized
DEBUG - 2020-02-13 13:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:08 --> Input Class Initialized
INFO - 2020-02-13 13:47:08 --> Language Class Initialized
INFO - 2020-02-13 13:47:08 --> Language Class Initialized
INFO - 2020-02-13 13:47:08 --> Loader Class Initialized
INFO - 2020-02-13 13:47:08 --> Helper loaded: url_helper
INFO - 2020-02-13 13:47:08 --> Loader Class Initialized
INFO - 2020-02-13 13:47:08 --> Helper loaded: string_helper
INFO - 2020-02-13 13:47:08 --> Helper loaded: url_helper
INFO - 2020-02-13 13:47:08 --> Helper loaded: string_helper
INFO - 2020-02-13 13:47:08 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:47:08 --> Database Driver Class Initialized
INFO - 2020-02-13 13:47:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 13:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:47:08 --> Controller Class Initialized
INFO - 2020-02-13 13:47:08 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:47:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:47:08 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:47:08 --> Helper loaded: form_helper
INFO - 2020-02-13 13:47:08 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:47:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:47:08 --> Final output sent to browser
DEBUG - 2020-02-13 13:47:08 --> Total execution time: 0.9554
INFO - 2020-02-13 13:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:47:08 --> Controller Class Initialized
INFO - 2020-02-13 13:47:08 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:47:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:47:09 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:47:09 --> Helper loaded: form_helper
INFO - 2020-02-13 13:47:09 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:47:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:47:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:47:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:47:09 --> Final output sent to browser
DEBUG - 2020-02-13 13:47:09 --> Total execution time: 1.3100
INFO - 2020-02-13 13:47:11 --> Config Class Initialized
INFO - 2020-02-13 13:47:11 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:11 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:11 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:11 --> URI Class Initialized
INFO - 2020-02-13 13:47:11 --> Router Class Initialized
INFO - 2020-02-13 13:47:11 --> Output Class Initialized
INFO - 2020-02-13 13:47:11 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:11 --> Input Class Initialized
INFO - 2020-02-13 13:47:11 --> Language Class Initialized
INFO - 2020-02-13 13:47:11 --> Loader Class Initialized
INFO - 2020-02-13 13:47:11 --> Helper loaded: url_helper
INFO - 2020-02-13 13:47:12 --> Helper loaded: string_helper
INFO - 2020-02-13 13:47:12 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:47:12 --> Controller Class Initialized
INFO - 2020-02-13 13:47:12 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:47:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:47:12 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:47:12 --> Helper loaded: form_helper
INFO - 2020-02-13 13:47:12 --> Form Validation Class Initialized
INFO - 2020-02-13 13:47:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:47:12 --> Final output sent to browser
INFO - 2020-02-13 13:47:12 --> Config Class Initialized
INFO - 2020-02-13 13:47:12 --> Config Class Initialized
INFO - 2020-02-13 13:47:12 --> Config Class Initialized
INFO - 2020-02-13 13:47:12 --> Config Class Initialized
INFO - 2020-02-13 13:47:12 --> Hooks Class Initialized
INFO - 2020-02-13 13:47:12 --> Hooks Class Initialized
INFO - 2020-02-13 13:47:12 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:12 --> Total execution time: 0.8377
INFO - 2020-02-13 13:47:12 --> Hooks Class Initialized
INFO - 2020-02-13 13:47:12 --> Config Class Initialized
INFO - 2020-02-13 13:47:12 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:47:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:12 --> Config Class Initialized
INFO - 2020-02-13 13:47:12 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:12 --> Hooks Class Initialized
INFO - 2020-02-13 13:47:12 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:12 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:12 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:47:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:12 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:12 --> URI Class Initialized
INFO - 2020-02-13 13:47:12 --> URI Class Initialized
INFO - 2020-02-13 13:47:12 --> URI Class Initialized
INFO - 2020-02-13 13:47:12 --> URI Class Initialized
DEBUG - 2020-02-13 13:47:12 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:12 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:12 --> Router Class Initialized
INFO - 2020-02-13 13:47:12 --> Router Class Initialized
INFO - 2020-02-13 13:47:12 --> URI Class Initialized
INFO - 2020-02-13 13:47:12 --> Router Class Initialized
INFO - 2020-02-13 13:47:12 --> Router Class Initialized
INFO - 2020-02-13 13:47:12 --> URI Class Initialized
INFO - 2020-02-13 13:47:12 --> Router Class Initialized
INFO - 2020-02-13 13:47:12 --> Output Class Initialized
INFO - 2020-02-13 13:47:12 --> Output Class Initialized
INFO - 2020-02-13 13:47:12 --> Output Class Initialized
INFO - 2020-02-13 13:47:12 --> Output Class Initialized
INFO - 2020-02-13 13:47:12 --> Security Class Initialized
INFO - 2020-02-13 13:47:12 --> Security Class Initialized
INFO - 2020-02-13 13:47:12 --> Security Class Initialized
INFO - 2020-02-13 13:47:12 --> Output Class Initialized
INFO - 2020-02-13 13:47:12 --> Router Class Initialized
INFO - 2020-02-13 13:47:12 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:12 --> Security Class Initialized
INFO - 2020-02-13 13:47:12 --> Output Class Initialized
DEBUG - 2020-02-13 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:12 --> Input Class Initialized
INFO - 2020-02-13 13:47:12 --> Input Class Initialized
INFO - 2020-02-13 13:47:12 --> Input Class Initialized
INFO - 2020-02-13 13:47:12 --> Input Class Initialized
DEBUG - 2020-02-13 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:12 --> Security Class Initialized
INFO - 2020-02-13 13:47:12 --> Input Class Initialized
INFO - 2020-02-13 13:47:12 --> Language Class Initialized
INFO - 2020-02-13 13:47:12 --> Language Class Initialized
DEBUG - 2020-02-13 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:12 --> Language Class Initialized
INFO - 2020-02-13 13:47:12 --> Language Class Initialized
INFO - 2020-02-13 13:47:12 --> Input Class Initialized
ERROR - 2020-02-13 13:47:12 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 13:47:12 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-13 13:47:12 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 13:47:12 --> Language Class Initialized
INFO - 2020-02-13 13:47:12 --> Loader Class Initialized
INFO - 2020-02-13 13:47:12 --> Language Class Initialized
ERROR - 2020-02-13 13:47:12 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 13:47:12 --> Loader Class Initialized
INFO - 2020-02-13 13:47:12 --> Helper loaded: url_helper
INFO - 2020-02-13 13:47:12 --> Config Class Initialized
INFO - 2020-02-13 13:47:12 --> Config Class Initialized
INFO - 2020-02-13 13:47:12 --> Config Class Initialized
INFO - 2020-02-13 13:47:13 --> Hooks Class Initialized
INFO - 2020-02-13 13:47:13 --> Hooks Class Initialized
INFO - 2020-02-13 13:47:13 --> Hooks Class Initialized
INFO - 2020-02-13 13:47:13 --> Helper loaded: string_helper
INFO - 2020-02-13 13:47:13 --> Helper loaded: url_helper
INFO - 2020-02-13 13:47:13 --> Config Class Initialized
INFO - 2020-02-13 13:47:13 --> Hooks Class Initialized
INFO - 2020-02-13 13:47:13 --> Helper loaded: string_helper
DEBUG - 2020-02-13 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:13 --> Database Driver Class Initialized
INFO - 2020-02-13 13:47:13 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:13 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:13 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:47:13 --> Database Driver Class Initialized
INFO - 2020-02-13 13:47:13 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:47:13 --> URI Class Initialized
INFO - 2020-02-13 13:47:13 --> URI Class Initialized
INFO - 2020-02-13 13:47:13 --> URI Class Initialized
DEBUG - 2020-02-13 13:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:47:13 --> Controller Class Initialized
INFO - 2020-02-13 13:47:13 --> Router Class Initialized
INFO - 2020-02-13 13:47:13 --> Router Class Initialized
INFO - 2020-02-13 13:47:13 --> Router Class Initialized
INFO - 2020-02-13 13:47:13 --> URI Class Initialized
INFO - 2020-02-13 13:47:13 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:47:13 --> Router Class Initialized
INFO - 2020-02-13 13:47:13 --> Output Class Initialized
INFO - 2020-02-13 13:47:13 --> Output Class Initialized
INFO - 2020-02-13 13:47:13 --> Output Class Initialized
INFO - 2020-02-13 13:47:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:47:13 --> Security Class Initialized
INFO - 2020-02-13 13:47:13 --> Output Class Initialized
INFO - 2020-02-13 13:47:13 --> Security Class Initialized
INFO - 2020-02-13 13:47:13 --> Security Class Initialized
INFO - 2020-02-13 13:47:13 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:13 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:13 --> Input Class Initialized
INFO - 2020-02-13 13:47:13 --> Input Class Initialized
INFO - 2020-02-13 13:47:13 --> Input Class Initialized
DEBUG - 2020-02-13 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:13 --> Helper loaded: form_helper
INFO - 2020-02-13 13:47:13 --> Input Class Initialized
INFO - 2020-02-13 13:47:13 --> Form Validation Class Initialized
INFO - 2020-02-13 13:47:13 --> Language Class Initialized
INFO - 2020-02-13 13:47:13 --> Language Class Initialized
INFO - 2020-02-13 13:47:13 --> Language Class Initialized
INFO - 2020-02-13 13:47:13 --> Language Class Initialized
ERROR - 2020-02-13 13:47:13 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 13:47:13 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 13:47:13 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 13:47:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:47:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 13:47:13 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 13:47:13 --> Config Class Initialized
INFO - 2020-02-13 13:47:13 --> Config Class Initialized
INFO - 2020-02-13 13:47:13 --> Config Class Initialized
INFO - 2020-02-13 13:47:13 --> Hooks Class Initialized
INFO - 2020-02-13 13:47:13 --> Hooks Class Initialized
INFO - 2020-02-13 13:47:13 --> Hooks Class Initialized
INFO - 2020-02-13 13:47:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:47:13 --> Config Class Initialized
INFO - 2020-02-13 13:47:13 --> Hooks Class Initialized
INFO - 2020-02-13 13:47:13 --> Final output sent to browser
DEBUG - 2020-02-13 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:13 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:13 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:47:13 --> Total execution time: 1.0220
INFO - 2020-02-13 13:47:13 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:13 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:47:13 --> URI Class Initialized
INFO - 2020-02-13 13:47:13 --> URI Class Initialized
INFO - 2020-02-13 13:47:13 --> URI Class Initialized
INFO - 2020-02-13 13:47:13 --> URI Class Initialized
INFO - 2020-02-13 13:47:13 --> Controller Class Initialized
INFO - 2020-02-13 13:47:13 --> Router Class Initialized
INFO - 2020-02-13 13:47:13 --> Router Class Initialized
INFO - 2020-02-13 13:47:13 --> Router Class Initialized
INFO - 2020-02-13 13:47:13 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:47:13 --> Router Class Initialized
INFO - 2020-02-13 13:47:13 --> Output Class Initialized
INFO - 2020-02-13 13:47:13 --> Output Class Initialized
INFO - 2020-02-13 13:47:13 --> Output Class Initialized
INFO - 2020-02-13 13:47:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:47:13 --> Security Class Initialized
INFO - 2020-02-13 13:47:13 --> Security Class Initialized
INFO - 2020-02-13 13:47:13 --> Output Class Initialized
INFO - 2020-02-13 13:47:13 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:13 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:47:13 --> Security Class Initialized
INFO - 2020-02-13 13:47:13 --> Input Class Initialized
INFO - 2020-02-13 13:47:13 --> Input Class Initialized
INFO - 2020-02-13 13:47:13 --> Input Class Initialized
DEBUG - 2020-02-13 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:13 --> Helper loaded: form_helper
INFO - 2020-02-13 13:47:13 --> Input Class Initialized
INFO - 2020-02-13 13:47:13 --> Form Validation Class Initialized
INFO - 2020-02-13 13:47:13 --> Language Class Initialized
INFO - 2020-02-13 13:47:13 --> Language Class Initialized
INFO - 2020-02-13 13:47:13 --> Language Class Initialized
INFO - 2020-02-13 13:47:13 --> Language Class Initialized
ERROR - 2020-02-13 13:47:13 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-13 13:47:13 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 13:47:13 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 13:47:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:47:13 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 13:47:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:47:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:47:13 --> Config Class Initialized
INFO - 2020-02-13 13:47:13 --> Hooks Class Initialized
INFO - 2020-02-13 13:47:13 --> Final output sent to browser
DEBUG - 2020-02-13 13:47:13 --> Total execution time: 1.4021
DEBUG - 2020-02-13 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:14 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:14 --> URI Class Initialized
INFO - 2020-02-13 13:47:14 --> Router Class Initialized
INFO - 2020-02-13 13:47:14 --> Output Class Initialized
INFO - 2020-02-13 13:47:14 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:14 --> Input Class Initialized
INFO - 2020-02-13 13:47:14 --> Language Class Initialized
ERROR - 2020-02-13 13:47:14 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 13:47:14 --> Config Class Initialized
INFO - 2020-02-13 13:47:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:14 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:14 --> URI Class Initialized
INFO - 2020-02-13 13:47:14 --> Router Class Initialized
INFO - 2020-02-13 13:47:14 --> Output Class Initialized
INFO - 2020-02-13 13:47:14 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:14 --> Input Class Initialized
INFO - 2020-02-13 13:47:14 --> Language Class Initialized
ERROR - 2020-02-13 13:47:14 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 13:47:14 --> Config Class Initialized
INFO - 2020-02-13 13:47:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:14 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:14 --> URI Class Initialized
INFO - 2020-02-13 13:47:14 --> Router Class Initialized
INFO - 2020-02-13 13:47:15 --> Output Class Initialized
INFO - 2020-02-13 13:47:15 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:15 --> Input Class Initialized
INFO - 2020-02-13 13:47:15 --> Language Class Initialized
ERROR - 2020-02-13 13:47:15 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 13:47:15 --> Config Class Initialized
INFO - 2020-02-13 13:47:15 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:15 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:15 --> URI Class Initialized
INFO - 2020-02-13 13:47:15 --> Router Class Initialized
INFO - 2020-02-13 13:47:15 --> Output Class Initialized
INFO - 2020-02-13 13:47:15 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:15 --> Input Class Initialized
INFO - 2020-02-13 13:47:15 --> Language Class Initialized
ERROR - 2020-02-13 13:47:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:47:15 --> Config Class Initialized
INFO - 2020-02-13 13:47:15 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:15 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:15 --> URI Class Initialized
INFO - 2020-02-13 13:47:15 --> Router Class Initialized
INFO - 2020-02-13 13:47:15 --> Output Class Initialized
INFO - 2020-02-13 13:47:15 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:15 --> Input Class Initialized
INFO - 2020-02-13 13:47:15 --> Language Class Initialized
ERROR - 2020-02-13 13:47:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:47:16 --> Config Class Initialized
INFO - 2020-02-13 13:47:16 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:16 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:16 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:16 --> URI Class Initialized
INFO - 2020-02-13 13:47:16 --> Router Class Initialized
INFO - 2020-02-13 13:47:16 --> Output Class Initialized
INFO - 2020-02-13 13:47:16 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:16 --> Input Class Initialized
INFO - 2020-02-13 13:47:16 --> Language Class Initialized
ERROR - 2020-02-13 13:47:16 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 13:47:16 --> Config Class Initialized
INFO - 2020-02-13 13:47:16 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:16 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:16 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:16 --> URI Class Initialized
INFO - 2020-02-13 13:47:16 --> Router Class Initialized
INFO - 2020-02-13 13:47:16 --> Output Class Initialized
INFO - 2020-02-13 13:47:16 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:16 --> Input Class Initialized
INFO - 2020-02-13 13:47:16 --> Language Class Initialized
ERROR - 2020-02-13 13:47:16 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 13:47:16 --> Config Class Initialized
INFO - 2020-02-13 13:47:16 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:16 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:16 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:17 --> URI Class Initialized
INFO - 2020-02-13 13:47:17 --> Router Class Initialized
INFO - 2020-02-13 13:47:17 --> Output Class Initialized
INFO - 2020-02-13 13:47:17 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:17 --> Input Class Initialized
INFO - 2020-02-13 13:47:17 --> Language Class Initialized
ERROR - 2020-02-13 13:47:17 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 13:47:17 --> Config Class Initialized
INFO - 2020-02-13 13:47:17 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:17 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:17 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:17 --> URI Class Initialized
INFO - 2020-02-13 13:47:17 --> Router Class Initialized
INFO - 2020-02-13 13:47:17 --> Output Class Initialized
INFO - 2020-02-13 13:47:17 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:17 --> Input Class Initialized
INFO - 2020-02-13 13:47:17 --> Language Class Initialized
ERROR - 2020-02-13 13:47:17 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 13:47:34 --> Config Class Initialized
INFO - 2020-02-13 13:47:34 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:47:34 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:47:35 --> Utf8 Class Initialized
INFO - 2020-02-13 13:47:35 --> URI Class Initialized
INFO - 2020-02-13 13:47:35 --> Router Class Initialized
INFO - 2020-02-13 13:47:35 --> Output Class Initialized
INFO - 2020-02-13 13:47:35 --> Security Class Initialized
DEBUG - 2020-02-13 13:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:47:35 --> Input Class Initialized
INFO - 2020-02-13 13:47:35 --> Language Class Initialized
INFO - 2020-02-13 13:47:35 --> Loader Class Initialized
INFO - 2020-02-13 13:47:35 --> Helper loaded: url_helper
INFO - 2020-02-13 13:47:35 --> Helper loaded: string_helper
INFO - 2020-02-13 13:47:35 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:47:35 --> Controller Class Initialized
INFO - 2020-02-13 13:47:35 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:47:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:47:35 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:47:35 --> Helper loaded: form_helper
INFO - 2020-02-13 13:47:35 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:47:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 63
ERROR - 2020-02-13 13:47:35 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('33', '200000', '1', '2', NULL)
INFO - 2020-02-13 13:47:35 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 13:48:15 --> Config Class Initialized
INFO - 2020-02-13 13:48:15 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:15 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:15 --> URI Class Initialized
INFO - 2020-02-13 13:48:15 --> Router Class Initialized
INFO - 2020-02-13 13:48:15 --> Output Class Initialized
INFO - 2020-02-13 13:48:15 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:15 --> Input Class Initialized
INFO - 2020-02-13 13:48:15 --> Language Class Initialized
INFO - 2020-02-13 13:48:15 --> Loader Class Initialized
INFO - 2020-02-13 13:48:15 --> Helper loaded: url_helper
INFO - 2020-02-13 13:48:15 --> Helper loaded: string_helper
INFO - 2020-02-13 13:48:15 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:48:15 --> Controller Class Initialized
INFO - 2020-02-13 13:48:15 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:48:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:48:16 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:48:16 --> Helper loaded: form_helper
INFO - 2020-02-13 13:48:16 --> Form Validation Class Initialized
INFO - 2020-02-13 13:48:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:48:16 --> Final output sent to browser
DEBUG - 2020-02-13 13:48:16 --> Total execution time: 0.8419
INFO - 2020-02-13 13:48:20 --> Config Class Initialized
INFO - 2020-02-13 13:48:20 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:20 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:20 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:20 --> URI Class Initialized
INFO - 2020-02-13 13:48:20 --> Router Class Initialized
INFO - 2020-02-13 13:48:20 --> Output Class Initialized
INFO - 2020-02-13 13:48:20 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:20 --> Input Class Initialized
INFO - 2020-02-13 13:48:20 --> Language Class Initialized
INFO - 2020-02-13 13:48:20 --> Loader Class Initialized
INFO - 2020-02-13 13:48:20 --> Helper loaded: url_helper
INFO - 2020-02-13 13:48:20 --> Helper loaded: string_helper
INFO - 2020-02-13 13:48:20 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:48:20 --> Controller Class Initialized
INFO - 2020-02-13 13:48:20 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:48:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:48:20 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:48:21 --> Helper loaded: form_helper
INFO - 2020-02-13 13:48:21 --> Form Validation Class Initialized
INFO - 2020-02-13 13:48:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:48:21 --> Final output sent to browser
INFO - 2020-02-13 13:48:21 --> Config Class Initialized
INFO - 2020-02-13 13:48:21 --> Config Class Initialized
INFO - 2020-02-13 13:48:21 --> Config Class Initialized
INFO - 2020-02-13 13:48:21 --> Config Class Initialized
INFO - 2020-02-13 13:48:21 --> Hooks Class Initialized
INFO - 2020-02-13 13:48:21 --> Hooks Class Initialized
INFO - 2020-02-13 13:48:21 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:21 --> Total execution time: 0.8081
INFO - 2020-02-13 13:48:21 --> Config Class Initialized
INFO - 2020-02-13 13:48:21 --> Hooks Class Initialized
INFO - 2020-02-13 13:48:21 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:48:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:48:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:48:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:21 --> Config Class Initialized
INFO - 2020-02-13 13:48:21 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:21 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:21 --> Hooks Class Initialized
INFO - 2020-02-13 13:48:21 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:21 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:48:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:21 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:21 --> URI Class Initialized
INFO - 2020-02-13 13:48:21 --> URI Class Initialized
DEBUG - 2020-02-13 13:48:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:21 --> URI Class Initialized
INFO - 2020-02-13 13:48:21 --> URI Class Initialized
INFO - 2020-02-13 13:48:21 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:21 --> Router Class Initialized
INFO - 2020-02-13 13:48:21 --> Router Class Initialized
INFO - 2020-02-13 13:48:21 --> Router Class Initialized
INFO - 2020-02-13 13:48:21 --> URI Class Initialized
INFO - 2020-02-13 13:48:21 --> Router Class Initialized
INFO - 2020-02-13 13:48:21 --> URI Class Initialized
INFO - 2020-02-13 13:48:21 --> Output Class Initialized
INFO - 2020-02-13 13:48:21 --> Output Class Initialized
INFO - 2020-02-13 13:48:21 --> Output Class Initialized
INFO - 2020-02-13 13:48:21 --> Output Class Initialized
INFO - 2020-02-13 13:48:21 --> Router Class Initialized
INFO - 2020-02-13 13:48:21 --> Security Class Initialized
INFO - 2020-02-13 13:48:21 --> Security Class Initialized
INFO - 2020-02-13 13:48:21 --> Security Class Initialized
INFO - 2020-02-13 13:48:21 --> Output Class Initialized
INFO - 2020-02-13 13:48:21 --> Security Class Initialized
INFO - 2020-02-13 13:48:21 --> Router Class Initialized
DEBUG - 2020-02-13 13:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:21 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:21 --> Output Class Initialized
DEBUG - 2020-02-13 13:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:21 --> Input Class Initialized
INFO - 2020-02-13 13:48:21 --> Input Class Initialized
INFO - 2020-02-13 13:48:21 --> Input Class Initialized
INFO - 2020-02-13 13:48:21 --> Input Class Initialized
INFO - 2020-02-13 13:48:21 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:21 --> Language Class Initialized
INFO - 2020-02-13 13:48:21 --> Language Class Initialized
INFO - 2020-02-13 13:48:21 --> Language Class Initialized
INFO - 2020-02-13 13:48:21 --> Input Class Initialized
DEBUG - 2020-02-13 13:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:21 --> Language Class Initialized
INFO - 2020-02-13 13:48:21 --> Input Class Initialized
INFO - 2020-02-13 13:48:21 --> Language Class Initialized
ERROR - 2020-02-13 13:48:21 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 13:48:21 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 13:48:21 --> Loader Class Initialized
INFO - 2020-02-13 13:48:21 --> Loader Class Initialized
INFO - 2020-02-13 13:48:21 --> Language Class Initialized
ERROR - 2020-02-13 13:48:21 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 13:48:21 --> Helper loaded: url_helper
INFO - 2020-02-13 13:48:21 --> Helper loaded: url_helper
INFO - 2020-02-13 13:48:21 --> Config Class Initialized
INFO - 2020-02-13 13:48:21 --> Config Class Initialized
INFO - 2020-02-13 13:48:21 --> Hooks Class Initialized
INFO - 2020-02-13 13:48:21 --> Hooks Class Initialized
ERROR - 2020-02-13 13:48:21 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 13:48:21 --> Helper loaded: string_helper
INFO - 2020-02-13 13:48:21 --> Helper loaded: string_helper
INFO - 2020-02-13 13:48:21 --> Config Class Initialized
INFO - 2020-02-13 13:48:21 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:48:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:21 --> Database Driver Class Initialized
INFO - 2020-02-13 13:48:21 --> Database Driver Class Initialized
INFO - 2020-02-13 13:48:21 --> Config Class Initialized
INFO - 2020-02-13 13:48:21 --> Hooks Class Initialized
INFO - 2020-02-13 13:48:21 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:21 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:48:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 13:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:48:21 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:48:21 --> URI Class Initialized
DEBUG - 2020-02-13 13:48:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:21 --> URI Class Initialized
INFO - 2020-02-13 13:48:21 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:21 --> Controller Class Initialized
INFO - 2020-02-13 13:48:21 --> URI Class Initialized
INFO - 2020-02-13 13:48:21 --> Router Class Initialized
INFO - 2020-02-13 13:48:21 --> Router Class Initialized
INFO - 2020-02-13 13:48:21 --> URI Class Initialized
INFO - 2020-02-13 13:48:21 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:48:21 --> Output Class Initialized
INFO - 2020-02-13 13:48:21 --> Router Class Initialized
INFO - 2020-02-13 13:48:21 --> Output Class Initialized
INFO - 2020-02-13 13:48:21 --> Security Class Initialized
INFO - 2020-02-13 13:48:21 --> Output Class Initialized
INFO - 2020-02-13 13:48:21 --> Security Class Initialized
INFO - 2020-02-13 13:48:21 --> Router Class Initialized
INFO - 2020-02-13 13:48:21 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-13 13:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:21 --> Security Class Initialized
INFO - 2020-02-13 13:48:21 --> Output Class Initialized
INFO - 2020-02-13 13:48:21 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:48:21 --> Input Class Initialized
INFO - 2020-02-13 13:48:21 --> Input Class Initialized
INFO - 2020-02-13 13:48:21 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:21 --> Helper loaded: form_helper
INFO - 2020-02-13 13:48:21 --> Input Class Initialized
INFO - 2020-02-13 13:48:21 --> Language Class Initialized
INFO - 2020-02-13 13:48:21 --> Form Validation Class Initialized
INFO - 2020-02-13 13:48:21 --> Language Class Initialized
DEBUG - 2020-02-13 13:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:21 --> Input Class Initialized
INFO - 2020-02-13 13:48:21 --> Language Class Initialized
ERROR - 2020-02-13 13:48:21 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 13:48:21 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-13 13:48:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-13 13:48:22 --> Language Class Initialized
ERROR - 2020-02-13 13:48:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-13 13:48:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:48:22 --> Config Class Initialized
INFO - 2020-02-13 13:48:22 --> Config Class Initialized
INFO - 2020-02-13 13:48:22 --> Hooks Class Initialized
INFO - 2020-02-13 13:48:22 --> Hooks Class Initialized
INFO - 2020-02-13 13:48:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 13:48:22 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 13:48:22 --> Config Class Initialized
INFO - 2020-02-13 13:48:22 --> Hooks Class Initialized
INFO - 2020-02-13 13:48:22 --> Final output sent to browser
DEBUG - 2020-02-13 13:48:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:48:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:22 --> Config Class Initialized
INFO - 2020-02-13 13:48:22 --> Hooks Class Initialized
INFO - 2020-02-13 13:48:22 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:22 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:48:22 --> Total execution time: 0.9259
DEBUG - 2020-02-13 13:48:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:48:22 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:22 --> URI Class Initialized
DEBUG - 2020-02-13 13:48:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:22 --> URI Class Initialized
INFO - 2020-02-13 13:48:22 --> Controller Class Initialized
INFO - 2020-02-13 13:48:22 --> URI Class Initialized
INFO - 2020-02-13 13:48:22 --> Router Class Initialized
INFO - 2020-02-13 13:48:22 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:22 --> Router Class Initialized
INFO - 2020-02-13 13:48:22 --> URI Class Initialized
INFO - 2020-02-13 13:48:22 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:48:22 --> Router Class Initialized
INFO - 2020-02-13 13:48:22 --> Output Class Initialized
INFO - 2020-02-13 13:48:22 --> Output Class Initialized
INFO - 2020-02-13 13:48:22 --> Security Class Initialized
INFO - 2020-02-13 13:48:22 --> Security Class Initialized
INFO - 2020-02-13 13:48:22 --> Router Class Initialized
INFO - 2020-02-13 13:48:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:48:22 --> Output Class Initialized
INFO - 2020-02-13 13:48:22 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 13:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:22 --> Security Class Initialized
INFO - 2020-02-13 13:48:22 --> Output Class Initialized
DEBUG - 2020-02-13 13:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:22 --> Input Class Initialized
DEBUG - 2020-02-13 13:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:22 --> Security Class Initialized
INFO - 2020-02-13 13:48:22 --> Input Class Initialized
INFO - 2020-02-13 13:48:22 --> Helper loaded: form_helper
INFO - 2020-02-13 13:48:22 --> Input Class Initialized
INFO - 2020-02-13 13:48:22 --> Form Validation Class Initialized
INFO - 2020-02-13 13:48:22 --> Language Class Initialized
INFO - 2020-02-13 13:48:22 --> Language Class Initialized
DEBUG - 2020-02-13 13:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:22 --> Input Class Initialized
ERROR - 2020-02-13 13:48:22 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 13:48:22 --> Language Class Initialized
ERROR - 2020-02-13 13:48:22 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-13 13:48:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:48:22 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 13:48:22 --> Language Class Initialized
ERROR - 2020-02-13 13:48:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:48:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-13 13:48:22 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 13:48:22 --> Final output sent to browser
INFO - 2020-02-13 13:48:22 --> Config Class Initialized
DEBUG - 2020-02-13 13:48:22 --> Total execution time: 1.3739
INFO - 2020-02-13 13:48:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:22 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:22 --> URI Class Initialized
INFO - 2020-02-13 13:48:22 --> Router Class Initialized
INFO - 2020-02-13 13:48:22 --> Output Class Initialized
INFO - 2020-02-13 13:48:22 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:22 --> Input Class Initialized
INFO - 2020-02-13 13:48:22 --> Language Class Initialized
ERROR - 2020-02-13 13:48:22 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-13 13:48:22 --> Config Class Initialized
INFO - 2020-02-13 13:48:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:23 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:23 --> URI Class Initialized
INFO - 2020-02-13 13:48:23 --> Router Class Initialized
INFO - 2020-02-13 13:48:23 --> Output Class Initialized
INFO - 2020-02-13 13:48:23 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:23 --> Input Class Initialized
INFO - 2020-02-13 13:48:23 --> Language Class Initialized
ERROR - 2020-02-13 13:48:23 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 13:48:23 --> Config Class Initialized
INFO - 2020-02-13 13:48:23 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:23 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:23 --> URI Class Initialized
INFO - 2020-02-13 13:48:23 --> Router Class Initialized
INFO - 2020-02-13 13:48:23 --> Output Class Initialized
INFO - 2020-02-13 13:48:23 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:23 --> Input Class Initialized
INFO - 2020-02-13 13:48:23 --> Language Class Initialized
ERROR - 2020-02-13 13:48:23 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 13:48:23 --> Config Class Initialized
INFO - 2020-02-13 13:48:23 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:23 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:23 --> URI Class Initialized
INFO - 2020-02-13 13:48:23 --> Router Class Initialized
INFO - 2020-02-13 13:48:23 --> Output Class Initialized
INFO - 2020-02-13 13:48:23 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:24 --> Input Class Initialized
INFO - 2020-02-13 13:48:24 --> Language Class Initialized
ERROR - 2020-02-13 13:48:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:48:24 --> Config Class Initialized
INFO - 2020-02-13 13:48:24 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:24 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:24 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:24 --> URI Class Initialized
INFO - 2020-02-13 13:48:24 --> Router Class Initialized
INFO - 2020-02-13 13:48:24 --> Output Class Initialized
INFO - 2020-02-13 13:48:24 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:24 --> Input Class Initialized
INFO - 2020-02-13 13:48:24 --> Language Class Initialized
ERROR - 2020-02-13 13:48:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 13:48:24 --> Config Class Initialized
INFO - 2020-02-13 13:48:24 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:24 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:24 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:24 --> URI Class Initialized
INFO - 2020-02-13 13:48:24 --> Router Class Initialized
INFO - 2020-02-13 13:48:24 --> Output Class Initialized
INFO - 2020-02-13 13:48:24 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:24 --> Input Class Initialized
INFO - 2020-02-13 13:48:24 --> Language Class Initialized
ERROR - 2020-02-13 13:48:24 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 13:48:24 --> Config Class Initialized
INFO - 2020-02-13 13:48:24 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:25 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:25 --> URI Class Initialized
INFO - 2020-02-13 13:48:25 --> Router Class Initialized
INFO - 2020-02-13 13:48:25 --> Output Class Initialized
INFO - 2020-02-13 13:48:25 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:25 --> Input Class Initialized
INFO - 2020-02-13 13:48:25 --> Language Class Initialized
ERROR - 2020-02-13 13:48:25 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 13:48:25 --> Config Class Initialized
INFO - 2020-02-13 13:48:25 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:25 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:25 --> URI Class Initialized
INFO - 2020-02-13 13:48:25 --> Router Class Initialized
INFO - 2020-02-13 13:48:25 --> Output Class Initialized
INFO - 2020-02-13 13:48:25 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:25 --> Input Class Initialized
INFO - 2020-02-13 13:48:25 --> Language Class Initialized
ERROR - 2020-02-13 13:48:25 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 13:48:25 --> Config Class Initialized
INFO - 2020-02-13 13:48:25 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:25 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:25 --> URI Class Initialized
INFO - 2020-02-13 13:48:25 --> Router Class Initialized
INFO - 2020-02-13 13:48:25 --> Output Class Initialized
INFO - 2020-02-13 13:48:25 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:26 --> Input Class Initialized
INFO - 2020-02-13 13:48:26 --> Language Class Initialized
ERROR - 2020-02-13 13:48:26 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 13:48:48 --> Config Class Initialized
INFO - 2020-02-13 13:48:48 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:48:48 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:48:48 --> Utf8 Class Initialized
INFO - 2020-02-13 13:48:48 --> URI Class Initialized
INFO - 2020-02-13 13:48:48 --> Router Class Initialized
INFO - 2020-02-13 13:48:48 --> Output Class Initialized
INFO - 2020-02-13 13:48:48 --> Security Class Initialized
DEBUG - 2020-02-13 13:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:48:48 --> Input Class Initialized
INFO - 2020-02-13 13:48:48 --> Language Class Initialized
INFO - 2020-02-13 13:48:48 --> Loader Class Initialized
INFO - 2020-02-13 13:48:48 --> Helper loaded: url_helper
INFO - 2020-02-13 13:48:48 --> Helper loaded: string_helper
INFO - 2020-02-13 13:48:48 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:48:48 --> Controller Class Initialized
INFO - 2020-02-13 13:48:48 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:48:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:48:48 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:48:48 --> Helper loaded: form_helper
INFO - 2020-02-13 13:48:48 --> Form Validation Class Initialized
INFO - 2020-02-13 13:48:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 13:48:49 --> Final output sent to browser
DEBUG - 2020-02-13 13:48:49 --> Total execution time: 0.9482
INFO - 2020-02-13 13:50:29 --> Config Class Initialized
INFO - 2020-02-13 13:50:29 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:50:30 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:50:30 --> Utf8 Class Initialized
INFO - 2020-02-13 13:50:30 --> URI Class Initialized
INFO - 2020-02-13 13:50:30 --> Router Class Initialized
INFO - 2020-02-13 13:50:30 --> Output Class Initialized
INFO - 2020-02-13 13:50:30 --> Security Class Initialized
DEBUG - 2020-02-13 13:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:50:30 --> Input Class Initialized
INFO - 2020-02-13 13:50:30 --> Language Class Initialized
INFO - 2020-02-13 13:50:30 --> Loader Class Initialized
INFO - 2020-02-13 13:50:30 --> Helper loaded: url_helper
INFO - 2020-02-13 13:50:30 --> Helper loaded: string_helper
INFO - 2020-02-13 13:50:30 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:50:30 --> Controller Class Initialized
INFO - 2020-02-13 13:50:30 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:50:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:50:30 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:50:30 --> Helper loaded: form_helper
INFO - 2020-02-13 13:50:30 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:50:30 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-13 13:50:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-13 13:50:30 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\models\M_pesan.php 60
ERROR - 2020-02-13 13:50:30 --> Severity: Notice --> Undefined index: jumlah_pesanan C:\xampp\htdocs\roadshow\application\models\M_pesan.php 62
ERROR - 2020-02-13 13:50:30 --> Query error: Column 'id_tiket' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES (NULL, '100725', '1', NULL, NULL)
INFO - 2020-02-13 13:50:30 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 13:50:57 --> Config Class Initialized
INFO - 2020-02-13 13:50:57 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:50:57 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:50:57 --> Utf8 Class Initialized
INFO - 2020-02-13 13:50:58 --> URI Class Initialized
INFO - 2020-02-13 13:50:58 --> Router Class Initialized
INFO - 2020-02-13 13:50:58 --> Output Class Initialized
INFO - 2020-02-13 13:50:58 --> Security Class Initialized
DEBUG - 2020-02-13 13:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:50:58 --> Input Class Initialized
INFO - 2020-02-13 13:50:58 --> Language Class Initialized
INFO - 2020-02-13 13:50:58 --> Loader Class Initialized
INFO - 2020-02-13 13:50:58 --> Helper loaded: url_helper
INFO - 2020-02-13 13:50:58 --> Helper loaded: string_helper
INFO - 2020-02-13 13:50:58 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:50:58 --> Controller Class Initialized
INFO - 2020-02-13 13:50:58 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:50:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:50:58 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:50:58 --> Helper loaded: form_helper
INFO - 2020-02-13 13:50:58 --> Form Validation Class Initialized
INFO - 2020-02-13 13:50:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:50:58 --> Final output sent to browser
INFO - 2020-02-13 13:50:58 --> Config Class Initialized
INFO - 2020-02-13 13:50:58 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:50:58 --> Total execution time: 0.9387
INFO - 2020-02-13 13:50:58 --> Config Class Initialized
INFO - 2020-02-13 13:50:58 --> Config Class Initialized
INFO - 2020-02-13 13:50:58 --> Hooks Class Initialized
INFO - 2020-02-13 13:50:58 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:50:58 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:50:59 --> Utf8 Class Initialized
DEBUG - 2020-02-13 13:50:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 13:50:59 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:50:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:50:59 --> Utf8 Class Initialized
INFO - 2020-02-13 13:50:59 --> URI Class Initialized
INFO - 2020-02-13 13:50:59 --> URI Class Initialized
INFO - 2020-02-13 13:50:59 --> URI Class Initialized
INFO - 2020-02-13 13:50:59 --> Router Class Initialized
INFO - 2020-02-13 13:50:59 --> Output Class Initialized
INFO - 2020-02-13 13:50:59 --> Router Class Initialized
INFO - 2020-02-13 13:50:59 --> Router Class Initialized
INFO - 2020-02-13 13:50:59 --> Security Class Initialized
INFO - 2020-02-13 13:50:59 --> Output Class Initialized
INFO - 2020-02-13 13:50:59 --> Output Class Initialized
DEBUG - 2020-02-13 13:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:50:59 --> Security Class Initialized
INFO - 2020-02-13 13:50:59 --> Security Class Initialized
INFO - 2020-02-13 13:50:59 --> Input Class Initialized
DEBUG - 2020-02-13 13:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 13:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:50:59 --> Input Class Initialized
INFO - 2020-02-13 13:50:59 --> Input Class Initialized
INFO - 2020-02-13 13:50:59 --> Language Class Initialized
INFO - 2020-02-13 13:50:59 --> Language Class Initialized
INFO - 2020-02-13 13:50:59 --> Language Class Initialized
ERROR - 2020-02-13 13:50:59 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 13:50:59 --> Loader Class Initialized
INFO - 2020-02-13 13:50:59 --> Loader Class Initialized
INFO - 2020-02-13 13:50:59 --> Helper loaded: url_helper
INFO - 2020-02-13 13:50:59 --> Helper loaded: url_helper
INFO - 2020-02-13 13:50:59 --> Helper loaded: string_helper
INFO - 2020-02-13 13:50:59 --> Helper loaded: string_helper
INFO - 2020-02-13 13:50:59 --> Database Driver Class Initialized
INFO - 2020-02-13 13:50:59 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 13:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:50:59 --> Controller Class Initialized
INFO - 2020-02-13 13:50:59 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:50:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:50:59 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:50:59 --> Helper loaded: form_helper
INFO - 2020-02-13 13:50:59 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:50:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:50:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:50:59 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:50:59 --> Final output sent to browser
DEBUG - 2020-02-13 13:50:59 --> Total execution time: 1.0498
INFO - 2020-02-13 13:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:51:00 --> Controller Class Initialized
INFO - 2020-02-13 13:51:00 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:51:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:51:00 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:51:00 --> Helper loaded: form_helper
INFO - 2020-02-13 13:51:00 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:51:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 13:51:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 13:51:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 13:51:00 --> Final output sent to browser
DEBUG - 2020-02-13 13:51:00 --> Total execution time: 1.4841
INFO - 2020-02-13 13:51:03 --> Config Class Initialized
INFO - 2020-02-13 13:51:03 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:51:03 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:51:03 --> Utf8 Class Initialized
INFO - 2020-02-13 13:51:04 --> URI Class Initialized
INFO - 2020-02-13 13:51:04 --> Router Class Initialized
INFO - 2020-02-13 13:51:04 --> Output Class Initialized
INFO - 2020-02-13 13:51:04 --> Security Class Initialized
DEBUG - 2020-02-13 13:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:51:04 --> Input Class Initialized
INFO - 2020-02-13 13:51:04 --> Language Class Initialized
INFO - 2020-02-13 13:51:04 --> Loader Class Initialized
INFO - 2020-02-13 13:51:04 --> Helper loaded: url_helper
INFO - 2020-02-13 13:51:04 --> Helper loaded: string_helper
INFO - 2020-02-13 13:51:04 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:51:04 --> Controller Class Initialized
INFO - 2020-02-13 13:51:04 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:51:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:51:04 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:51:04 --> Helper loaded: form_helper
INFO - 2020-02-13 13:51:04 --> Form Validation Class Initialized
INFO - 2020-02-13 13:51:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 13:51:04 --> Final output sent to browser
DEBUG - 2020-02-13 13:51:04 --> Total execution time: 0.9377
INFO - 2020-02-13 13:51:10 --> Config Class Initialized
INFO - 2020-02-13 13:51:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:51:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:51:10 --> Utf8 Class Initialized
INFO - 2020-02-13 13:51:10 --> URI Class Initialized
INFO - 2020-02-13 13:51:10 --> Router Class Initialized
INFO - 2020-02-13 13:51:11 --> Output Class Initialized
INFO - 2020-02-13 13:51:11 --> Security Class Initialized
DEBUG - 2020-02-13 13:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:51:11 --> Input Class Initialized
INFO - 2020-02-13 13:51:11 --> Language Class Initialized
INFO - 2020-02-13 13:51:11 --> Loader Class Initialized
INFO - 2020-02-13 13:51:11 --> Helper loaded: url_helper
INFO - 2020-02-13 13:51:11 --> Helper loaded: string_helper
INFO - 2020-02-13 13:51:11 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:51:11 --> Controller Class Initialized
INFO - 2020-02-13 13:51:11 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:51:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:51:11 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:51:11 --> Helper loaded: form_helper
INFO - 2020-02-13 13:51:11 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:51:11 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-13 13:51:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-13 13:51:11 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\models\M_pesan.php 60
ERROR - 2020-02-13 13:51:11 --> Severity: Notice --> Undefined index: jumlah_pesanan C:\xampp\htdocs\roadshow\application\models\M_pesan.php 62
ERROR - 2020-02-13 13:51:11 --> Query error: Column 'id_tiket' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES (NULL, '100120', '1', NULL, NULL)
INFO - 2020-02-13 13:51:11 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 13:51:52 --> Config Class Initialized
INFO - 2020-02-13 13:51:52 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:51:52 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:51:52 --> Utf8 Class Initialized
INFO - 2020-02-13 13:51:52 --> URI Class Initialized
INFO - 2020-02-13 13:51:52 --> Router Class Initialized
INFO - 2020-02-13 13:51:52 --> Output Class Initialized
INFO - 2020-02-13 13:51:52 --> Security Class Initialized
DEBUG - 2020-02-13 13:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:51:52 --> Input Class Initialized
INFO - 2020-02-13 13:51:52 --> Language Class Initialized
INFO - 2020-02-13 13:51:52 --> Loader Class Initialized
INFO - 2020-02-13 13:51:52 --> Helper loaded: url_helper
INFO - 2020-02-13 13:51:52 --> Helper loaded: string_helper
INFO - 2020-02-13 13:51:52 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:51:52 --> Controller Class Initialized
INFO - 2020-02-13 13:51:52 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:51:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:51:53 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:51:53 --> Helper loaded: form_helper
INFO - 2020-02-13 13:51:53 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:51:53 --> Severity: Notice --> Undefined variable: idpengunjung C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-13 13:51:53 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\models\M_pesan.php 60
ERROR - 2020-02-13 13:51:53 --> Severity: Notice --> Undefined index: jumlah_pesanan C:\xampp\htdocs\roadshow\application\models\M_pesan.php 62
ERROR - 2020-02-13 13:51:53 --> Query error: Column 'id_tiket' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES (NULL, '100120', '1', NULL, NULL)
INFO - 2020-02-13 13:51:53 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 13:54:05 --> Config Class Initialized
INFO - 2020-02-13 13:54:05 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:54:05 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:54:05 --> Utf8 Class Initialized
INFO - 2020-02-13 13:54:05 --> URI Class Initialized
INFO - 2020-02-13 13:54:05 --> Router Class Initialized
INFO - 2020-02-13 13:54:05 --> Output Class Initialized
INFO - 2020-02-13 13:54:05 --> Security Class Initialized
DEBUG - 2020-02-13 13:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:54:05 --> Input Class Initialized
INFO - 2020-02-13 13:54:05 --> Language Class Initialized
INFO - 2020-02-13 13:54:05 --> Loader Class Initialized
INFO - 2020-02-13 13:54:05 --> Helper loaded: url_helper
INFO - 2020-02-13 13:54:05 --> Helper loaded: string_helper
INFO - 2020-02-13 13:54:05 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:54:06 --> Controller Class Initialized
INFO - 2020-02-13 13:54:06 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:54:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:54:06 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:54:06 --> Helper loaded: form_helper
INFO - 2020-02-13 13:54:06 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:54:06 --> Severity: Notice --> Undefined variable: idpengunjung C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-13 13:54:06 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\models\M_pesan.php 60
ERROR - 2020-02-13 13:54:06 --> Severity: Notice --> Undefined index: jumlah_pesanan C:\xampp\htdocs\roadshow\application\models\M_pesan.php 62
ERROR - 2020-02-13 13:54:06 --> Query error: Column 'id_tiket' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES (NULL, '100120', '1', NULL, NULL)
INFO - 2020-02-13 13:54:06 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 13:56:00 --> Config Class Initialized
INFO - 2020-02-13 13:56:01 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:56:01 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:56:01 --> Utf8 Class Initialized
INFO - 2020-02-13 13:56:01 --> URI Class Initialized
INFO - 2020-02-13 13:56:01 --> Router Class Initialized
INFO - 2020-02-13 13:56:01 --> Output Class Initialized
INFO - 2020-02-13 13:56:01 --> Security Class Initialized
DEBUG - 2020-02-13 13:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:56:01 --> Input Class Initialized
INFO - 2020-02-13 13:56:01 --> Language Class Initialized
INFO - 2020-02-13 13:56:01 --> Loader Class Initialized
INFO - 2020-02-13 13:56:01 --> Helper loaded: url_helper
INFO - 2020-02-13 13:56:01 --> Helper loaded: string_helper
INFO - 2020-02-13 13:56:01 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:56:01 --> Controller Class Initialized
INFO - 2020-02-13 13:56:01 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:56:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:56:01 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:56:01 --> Helper loaded: form_helper
INFO - 2020-02-13 13:56:01 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:56:02 --> Severity: Notice --> Undefined variable: idpengunjung C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-13 13:56:02 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\models\M_pesan.php 60
ERROR - 2020-02-13 13:56:02 --> Severity: Notice --> Undefined index: jumlah_pesanan C:\xampp\htdocs\roadshow\application\models\M_pesan.php 62
ERROR - 2020-02-13 13:56:02 --> Query error: Column 'id_tiket' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES (NULL, '100120', '1', NULL, NULL)
INFO - 2020-02-13 13:56:02 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-13 13:56:17 --> Config Class Initialized
INFO - 2020-02-13 13:56:17 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:56:17 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:56:17 --> Utf8 Class Initialized
INFO - 2020-02-13 13:56:17 --> URI Class Initialized
INFO - 2020-02-13 13:56:17 --> Router Class Initialized
INFO - 2020-02-13 13:56:18 --> Output Class Initialized
INFO - 2020-02-13 13:56:18 --> Security Class Initialized
DEBUG - 2020-02-13 13:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:56:18 --> Input Class Initialized
INFO - 2020-02-13 13:56:18 --> Language Class Initialized
INFO - 2020-02-13 13:56:18 --> Loader Class Initialized
INFO - 2020-02-13 13:56:18 --> Helper loaded: url_helper
INFO - 2020-02-13 13:56:18 --> Helper loaded: string_helper
INFO - 2020-02-13 13:56:18 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:56:18 --> Controller Class Initialized
INFO - 2020-02-13 13:56:18 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:56:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:56:18 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:56:18 --> Helper loaded: form_helper
INFO - 2020-02-13 13:56:18 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:56:18 --> Severity: Notice --> Undefined index: bank C:\xampp\htdocs\roadshow\application\models\M_tiket.php 74
ERROR - 2020-02-13 13:56:18 --> Severity: Notice --> Undefined index: jumlah_pesanan C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-13 13:56:18 --> Severity: Notice --> Undefined variable: totalbayar C:\xampp\htdocs\roadshow\application\views\Pemesanan\form_bukti.php 18
ERROR - 2020-02-13 13:56:18 --> Severity: Notice --> Undefined variable: norek C:\xampp\htdocs\roadshow\application\views\Pemesanan\form_bukti.php 21
ERROR - 2020-02-13 13:56:18 --> Severity: Notice --> Undefined variable: atasnama C:\xampp\htdocs\roadshow\application\views\Pemesanan\form_bukti.php 22
INFO - 2020-02-13 13:56:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 13:56:18 --> Final output sent to browser
DEBUG - 2020-02-13 13:56:18 --> Total execution time: 1.0491
INFO - 2020-02-13 13:57:31 --> Config Class Initialized
INFO - 2020-02-13 13:57:31 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:57:31 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:57:31 --> Utf8 Class Initialized
INFO - 2020-02-13 13:57:32 --> URI Class Initialized
INFO - 2020-02-13 13:57:32 --> Router Class Initialized
INFO - 2020-02-13 13:57:32 --> Output Class Initialized
INFO - 2020-02-13 13:57:32 --> Security Class Initialized
DEBUG - 2020-02-13 13:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:57:32 --> Input Class Initialized
INFO - 2020-02-13 13:57:32 --> Language Class Initialized
INFO - 2020-02-13 13:57:32 --> Loader Class Initialized
INFO - 2020-02-13 13:57:32 --> Helper loaded: url_helper
INFO - 2020-02-13 13:57:32 --> Helper loaded: string_helper
INFO - 2020-02-13 13:57:32 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:57:32 --> Controller Class Initialized
INFO - 2020-02-13 13:57:32 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:57:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:57:32 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:57:32 --> Helper loaded: form_helper
INFO - 2020-02-13 13:57:32 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:57:32 --> Severity: Notice --> Undefined index: bank C:\xampp\htdocs\roadshow\application\models\M_tiket.php 74
ERROR - 2020-02-13 13:57:32 --> Severity: Notice --> Undefined index: jumlah_pesanan C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
INFO - 2020-02-13 13:57:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 13:57:32 --> Final output sent to browser
DEBUG - 2020-02-13 13:57:32 --> Total execution time: 0.8938
INFO - 2020-02-13 13:58:04 --> Config Class Initialized
INFO - 2020-02-13 13:58:04 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:58:04 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:58:04 --> Utf8 Class Initialized
INFO - 2020-02-13 13:58:04 --> URI Class Initialized
INFO - 2020-02-13 13:58:04 --> Router Class Initialized
INFO - 2020-02-13 13:58:04 --> Output Class Initialized
INFO - 2020-02-13 13:58:04 --> Security Class Initialized
DEBUG - 2020-02-13 13:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:58:05 --> Input Class Initialized
INFO - 2020-02-13 13:58:05 --> Language Class Initialized
INFO - 2020-02-13 13:58:05 --> Loader Class Initialized
INFO - 2020-02-13 13:58:05 --> Helper loaded: url_helper
INFO - 2020-02-13 13:58:05 --> Helper loaded: string_helper
INFO - 2020-02-13 13:58:05 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:58:05 --> Controller Class Initialized
INFO - 2020-02-13 13:58:05 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:58:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:58:05 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:58:05 --> Helper loaded: form_helper
INFO - 2020-02-13 13:58:05 --> Form Validation Class Initialized
ERROR - 2020-02-13 13:58:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
INFO - 2020-02-13 13:58:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 13:58:05 --> Final output sent to browser
DEBUG - 2020-02-13 13:58:05 --> Total execution time: 0.8434
INFO - 2020-02-13 13:58:16 --> Config Class Initialized
INFO - 2020-02-13 13:58:16 --> Hooks Class Initialized
DEBUG - 2020-02-13 13:58:17 --> UTF-8 Support Enabled
INFO - 2020-02-13 13:58:17 --> Utf8 Class Initialized
INFO - 2020-02-13 13:58:17 --> URI Class Initialized
INFO - 2020-02-13 13:58:17 --> Router Class Initialized
INFO - 2020-02-13 13:58:17 --> Output Class Initialized
INFO - 2020-02-13 13:58:17 --> Security Class Initialized
DEBUG - 2020-02-13 13:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 13:58:17 --> Input Class Initialized
INFO - 2020-02-13 13:58:17 --> Language Class Initialized
INFO - 2020-02-13 13:58:17 --> Loader Class Initialized
INFO - 2020-02-13 13:58:17 --> Helper loaded: url_helper
INFO - 2020-02-13 13:58:17 --> Helper loaded: string_helper
INFO - 2020-02-13 13:58:17 --> Database Driver Class Initialized
DEBUG - 2020-02-13 13:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 13:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 13:58:17 --> Controller Class Initialized
INFO - 2020-02-13 13:58:17 --> Model "M_tiket" initialized
INFO - 2020-02-13 13:58:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 13:58:17 --> Model "M_pesan" initialized
INFO - 2020-02-13 13:58:17 --> Helper loaded: form_helper
INFO - 2020-02-13 13:58:17 --> Form Validation Class Initialized
INFO - 2020-02-13 13:58:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 13:58:17 --> Final output sent to browser
DEBUG - 2020-02-13 13:58:17 --> Total execution time: 0.8183
INFO - 2020-02-13 14:01:53 --> Config Class Initialized
INFO - 2020-02-13 14:01:53 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:01:53 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:01:53 --> Utf8 Class Initialized
INFO - 2020-02-13 14:01:53 --> URI Class Initialized
INFO - 2020-02-13 14:01:53 --> Router Class Initialized
INFO - 2020-02-13 14:01:53 --> Output Class Initialized
INFO - 2020-02-13 14:01:53 --> Security Class Initialized
DEBUG - 2020-02-13 14:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:01:53 --> Input Class Initialized
INFO - 2020-02-13 14:01:53 --> Language Class Initialized
INFO - 2020-02-13 14:01:53 --> Loader Class Initialized
INFO - 2020-02-13 14:01:53 --> Helper loaded: url_helper
INFO - 2020-02-13 14:01:53 --> Helper loaded: string_helper
INFO - 2020-02-13 14:01:53 --> Database Driver Class Initialized
DEBUG - 2020-02-13 14:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:01:53 --> Controller Class Initialized
INFO - 2020-02-13 14:01:53 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:01:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:01:54 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:01:54 --> Helper loaded: form_helper
INFO - 2020-02-13 14:01:54 --> Form Validation Class Initialized
ERROR - 2020-02-13 14:01:54 --> Severity: Notice --> Undefined index: jumlah_pesanan C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 30
INFO - 2020-02-13 14:01:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 14:01:54 --> Final output sent to browser
DEBUG - 2020-02-13 14:01:54 --> Total execution time: 0.8699
INFO - 2020-02-13 14:02:47 --> Config Class Initialized
INFO - 2020-02-13 14:02:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:02:47 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:02:47 --> Utf8 Class Initialized
INFO - 2020-02-13 14:02:47 --> URI Class Initialized
INFO - 2020-02-13 14:02:47 --> Router Class Initialized
INFO - 2020-02-13 14:02:47 --> Output Class Initialized
INFO - 2020-02-13 14:02:47 --> Security Class Initialized
DEBUG - 2020-02-13 14:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:02:47 --> Input Class Initialized
INFO - 2020-02-13 14:02:47 --> Language Class Initialized
INFO - 2020-02-13 14:02:47 --> Loader Class Initialized
INFO - 2020-02-13 14:02:47 --> Helper loaded: url_helper
INFO - 2020-02-13 14:02:47 --> Helper loaded: string_helper
INFO - 2020-02-13 14:02:47 --> Database Driver Class Initialized
DEBUG - 2020-02-13 14:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:02:48 --> Controller Class Initialized
INFO - 2020-02-13 14:02:48 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:02:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:02:48 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:02:48 --> Helper loaded: form_helper
INFO - 2020-02-13 14:02:48 --> Form Validation Class Initialized
INFO - 2020-02-13 14:02:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 14:02:48 --> Final output sent to browser
DEBUG - 2020-02-13 14:02:48 --> Total execution time: 1.6544
INFO - 2020-02-13 14:06:14 --> Config Class Initialized
INFO - 2020-02-13 14:06:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:06:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:06:14 --> Utf8 Class Initialized
INFO - 2020-02-13 14:06:14 --> URI Class Initialized
INFO - 2020-02-13 14:06:14 --> Router Class Initialized
INFO - 2020-02-13 14:06:15 --> Output Class Initialized
INFO - 2020-02-13 14:06:15 --> Security Class Initialized
DEBUG - 2020-02-13 14:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:06:15 --> Input Class Initialized
INFO - 2020-02-13 14:06:15 --> Language Class Initialized
INFO - 2020-02-13 14:06:15 --> Loader Class Initialized
INFO - 2020-02-13 14:06:15 --> Helper loaded: url_helper
INFO - 2020-02-13 14:06:15 --> Helper loaded: string_helper
INFO - 2020-02-13 14:06:15 --> Database Driver Class Initialized
DEBUG - 2020-02-13 14:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:06:15 --> Controller Class Initialized
INFO - 2020-02-13 14:06:15 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:06:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:06:15 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:06:15 --> Helper loaded: form_helper
INFO - 2020-02-13 14:06:15 --> Form Validation Class Initialized
ERROR - 2020-02-13 14:06:15 --> Severity: Notice --> Undefined index: bank C:\xampp\htdocs\roadshow\application\models\M_tiket.php 74
INFO - 2020-02-13 14:06:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 14:06:15 --> Final output sent to browser
DEBUG - 2020-02-13 14:06:15 --> Total execution time: 1.2156
INFO - 2020-02-13 14:08:12 --> Config Class Initialized
INFO - 2020-02-13 14:08:13 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:08:13 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:13 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:13 --> URI Class Initialized
INFO - 2020-02-13 14:08:13 --> Router Class Initialized
INFO - 2020-02-13 14:08:13 --> Output Class Initialized
INFO - 2020-02-13 14:08:14 --> Security Class Initialized
DEBUG - 2020-02-13 14:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:14 --> Input Class Initialized
INFO - 2020-02-13 14:08:14 --> Language Class Initialized
INFO - 2020-02-13 14:08:14 --> Loader Class Initialized
INFO - 2020-02-13 14:08:14 --> Helper loaded: url_helper
INFO - 2020-02-13 14:08:14 --> Helper loaded: string_helper
INFO - 2020-02-13 14:08:14 --> Database Driver Class Initialized
DEBUG - 2020-02-13 14:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:08:15 --> Controller Class Initialized
INFO - 2020-02-13 14:08:15 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:08:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:08:15 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:08:15 --> Helper loaded: form_helper
INFO - 2020-02-13 14:08:15 --> Form Validation Class Initialized
INFO - 2020-02-13 14:08:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 14:08:15 --> Final output sent to browser
DEBUG - 2020-02-13 14:08:15 --> Total execution time: 2.6024
INFO - 2020-02-13 14:08:15 --> Config Class Initialized
INFO - 2020-02-13 14:08:15 --> Hooks Class Initialized
INFO - 2020-02-13 14:08:15 --> Config Class Initialized
INFO - 2020-02-13 14:08:15 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:08:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:15 --> Utf8 Class Initialized
DEBUG - 2020-02-13 14:08:15 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:15 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:15 --> URI Class Initialized
INFO - 2020-02-13 14:08:15 --> URI Class Initialized
INFO - 2020-02-13 14:08:15 --> Router Class Initialized
INFO - 2020-02-13 14:08:15 --> Router Class Initialized
INFO - 2020-02-13 14:08:15 --> Output Class Initialized
INFO - 2020-02-13 14:08:15 --> Security Class Initialized
INFO - 2020-02-13 14:08:15 --> Output Class Initialized
DEBUG - 2020-02-13 14:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:15 --> Security Class Initialized
INFO - 2020-02-13 14:08:15 --> Input Class Initialized
DEBUG - 2020-02-13 14:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:16 --> Input Class Initialized
INFO - 2020-02-13 14:08:16 --> Language Class Initialized
INFO - 2020-02-13 14:08:16 --> Language Class Initialized
INFO - 2020-02-13 14:08:16 --> Loader Class Initialized
INFO - 2020-02-13 14:08:16 --> Helper loaded: url_helper
INFO - 2020-02-13 14:08:16 --> Loader Class Initialized
INFO - 2020-02-13 14:08:16 --> Helper loaded: string_helper
INFO - 2020-02-13 14:08:16 --> Helper loaded: url_helper
INFO - 2020-02-13 14:08:16 --> Helper loaded: string_helper
INFO - 2020-02-13 14:08:16 --> Database Driver Class Initialized
DEBUG - 2020-02-13 14:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:08:16 --> Database Driver Class Initialized
INFO - 2020-02-13 14:08:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-13 14:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:08:16 --> Controller Class Initialized
INFO - 2020-02-13 14:08:16 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:08:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:08:17 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:08:17 --> Helper loaded: form_helper
INFO - 2020-02-13 14:08:17 --> Form Validation Class Initialized
ERROR - 2020-02-13 14:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 14:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 14:08:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 14:08:17 --> Final output sent to browser
DEBUG - 2020-02-13 14:08:17 --> Total execution time: 2.0969
INFO - 2020-02-13 14:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:08:17 --> Controller Class Initialized
INFO - 2020-02-13 14:08:17 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:08:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:08:18 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:08:18 --> Helper loaded: form_helper
INFO - 2020-02-13 14:08:18 --> Form Validation Class Initialized
ERROR - 2020-02-13 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 14:08:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 14:08:18 --> Final output sent to browser
DEBUG - 2020-02-13 14:08:18 --> Total execution time: 3.2277
INFO - 2020-02-13 14:08:21 --> Config Class Initialized
INFO - 2020-02-13 14:08:21 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:08:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:21 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:21 --> URI Class Initialized
INFO - 2020-02-13 14:08:21 --> Router Class Initialized
INFO - 2020-02-13 14:08:21 --> Output Class Initialized
INFO - 2020-02-13 14:08:21 --> Security Class Initialized
DEBUG - 2020-02-13 14:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:21 --> Input Class Initialized
INFO - 2020-02-13 14:08:21 --> Language Class Initialized
INFO - 2020-02-13 14:08:21 --> Loader Class Initialized
INFO - 2020-02-13 14:08:21 --> Helper loaded: url_helper
INFO - 2020-02-13 14:08:21 --> Helper loaded: string_helper
INFO - 2020-02-13 14:08:21 --> Database Driver Class Initialized
DEBUG - 2020-02-13 14:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:08:22 --> Controller Class Initialized
INFO - 2020-02-13 14:08:22 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:08:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:08:22 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:08:22 --> Helper loaded: form_helper
INFO - 2020-02-13 14:08:22 --> Form Validation Class Initialized
INFO - 2020-02-13 14:08:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 14:08:22 --> Final output sent to browser
INFO - 2020-02-13 14:08:22 --> Config Class Initialized
INFO - 2020-02-13 14:08:22 --> Config Class Initialized
INFO - 2020-02-13 14:08:22 --> Config Class Initialized
INFO - 2020-02-13 14:08:22 --> Config Class Initialized
INFO - 2020-02-13 14:08:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:08:22 --> Total execution time: 1.2949
INFO - 2020-02-13 14:08:22 --> Hooks Class Initialized
INFO - 2020-02-13 14:08:22 --> Hooks Class Initialized
INFO - 2020-02-13 14:08:22 --> Hooks Class Initialized
INFO - 2020-02-13 14:08:22 --> Config Class Initialized
DEBUG - 2020-02-13 14:08:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 14:08:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:22 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:08:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 14:08:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:22 --> Config Class Initialized
INFO - 2020-02-13 14:08:22 --> Hooks Class Initialized
INFO - 2020-02-13 14:08:22 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:22 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:22 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:22 --> Utf8 Class Initialized
DEBUG - 2020-02-13 14:08:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:22 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:22 --> URI Class Initialized
INFO - 2020-02-13 14:08:22 --> URI Class Initialized
INFO - 2020-02-13 14:08:22 --> URI Class Initialized
INFO - 2020-02-13 14:08:22 --> URI Class Initialized
DEBUG - 2020-02-13 14:08:22 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:22 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:22 --> Router Class Initialized
INFO - 2020-02-13 14:08:22 --> Router Class Initialized
INFO - 2020-02-13 14:08:22 --> Router Class Initialized
INFO - 2020-02-13 14:08:22 --> Router Class Initialized
INFO - 2020-02-13 14:08:22 --> URI Class Initialized
INFO - 2020-02-13 14:08:22 --> URI Class Initialized
INFO - 2020-02-13 14:08:22 --> Output Class Initialized
INFO - 2020-02-13 14:08:22 --> Output Class Initialized
INFO - 2020-02-13 14:08:22 --> Router Class Initialized
INFO - 2020-02-13 14:08:22 --> Output Class Initialized
INFO - 2020-02-13 14:08:22 --> Output Class Initialized
INFO - 2020-02-13 14:08:22 --> Security Class Initialized
INFO - 2020-02-13 14:08:22 --> Security Class Initialized
INFO - 2020-02-13 14:08:22 --> Security Class Initialized
INFO - 2020-02-13 14:08:22 --> Security Class Initialized
INFO - 2020-02-13 14:08:22 --> Output Class Initialized
INFO - 2020-02-13 14:08:22 --> Router Class Initialized
DEBUG - 2020-02-13 14:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:22 --> Output Class Initialized
DEBUG - 2020-02-13 14:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 14:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 14:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:22 --> Security Class Initialized
INFO - 2020-02-13 14:08:22 --> Input Class Initialized
INFO - 2020-02-13 14:08:22 --> Input Class Initialized
INFO - 2020-02-13 14:08:22 --> Input Class Initialized
INFO - 2020-02-13 14:08:22 --> Input Class Initialized
INFO - 2020-02-13 14:08:22 --> Security Class Initialized
DEBUG - 2020-02-13 14:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:23 --> Input Class Initialized
INFO - 2020-02-13 14:08:23 --> Language Class Initialized
INFO - 2020-02-13 14:08:23 --> Language Class Initialized
DEBUG - 2020-02-13 14:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:23 --> Language Class Initialized
INFO - 2020-02-13 14:08:23 --> Language Class Initialized
INFO - 2020-02-13 14:08:23 --> Language Class Initialized
ERROR - 2020-02-13 14:08:23 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-13 14:08:23 --> Input Class Initialized
ERROR - 2020-02-13 14:08:23 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 14:08:23 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-13 14:08:23 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 14:08:23 --> Language Class Initialized
ERROR - 2020-02-13 14:08:23 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 14:08:23 --> Config Class Initialized
INFO - 2020-02-13 14:08:23 --> Config Class Initialized
INFO - 2020-02-13 14:08:23 --> Config Class Initialized
INFO - 2020-02-13 14:08:23 --> Config Class Initialized
INFO - 2020-02-13 14:08:23 --> Hooks Class Initialized
INFO - 2020-02-13 14:08:23 --> Hooks Class Initialized
INFO - 2020-02-13 14:08:23 --> Hooks Class Initialized
INFO - 2020-02-13 14:08:23 --> Hooks Class Initialized
ERROR - 2020-02-13 14:08:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 14:08:23 --> Config Class Initialized
INFO - 2020-02-13 14:08:23 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:08:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 14:08:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 14:08:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 14:08:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:23 --> Config Class Initialized
INFO - 2020-02-13 14:08:23 --> Hooks Class Initialized
INFO - 2020-02-13 14:08:23 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:23 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:23 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:23 --> Utf8 Class Initialized
DEBUG - 2020-02-13 14:08:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:23 --> URI Class Initialized
DEBUG - 2020-02-13 14:08:23 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:23 --> URI Class Initialized
INFO - 2020-02-13 14:08:23 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:23 --> URI Class Initialized
INFO - 2020-02-13 14:08:23 --> URI Class Initialized
INFO - 2020-02-13 14:08:23 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:23 --> Router Class Initialized
INFO - 2020-02-13 14:08:23 --> Router Class Initialized
INFO - 2020-02-13 14:08:23 --> URI Class Initialized
INFO - 2020-02-13 14:08:23 --> Router Class Initialized
INFO - 2020-02-13 14:08:23 --> Router Class Initialized
INFO - 2020-02-13 14:08:23 --> URI Class Initialized
INFO - 2020-02-13 14:08:23 --> Output Class Initialized
INFO - 2020-02-13 14:08:23 --> Router Class Initialized
INFO - 2020-02-13 14:08:23 --> Output Class Initialized
INFO - 2020-02-13 14:08:23 --> Output Class Initialized
INFO - 2020-02-13 14:08:23 --> Output Class Initialized
INFO - 2020-02-13 14:08:23 --> Security Class Initialized
INFO - 2020-02-13 14:08:23 --> Security Class Initialized
INFO - 2020-02-13 14:08:23 --> Security Class Initialized
INFO - 2020-02-13 14:08:23 --> Security Class Initialized
INFO - 2020-02-13 14:08:23 --> Output Class Initialized
INFO - 2020-02-13 14:08:23 --> Router Class Initialized
INFO - 2020-02-13 14:08:23 --> Security Class Initialized
DEBUG - 2020-02-13 14:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:23 --> Output Class Initialized
DEBUG - 2020-02-13 14:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 14:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 14:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:23 --> Input Class Initialized
INFO - 2020-02-13 14:08:23 --> Input Class Initialized
INFO - 2020-02-13 14:08:23 --> Input Class Initialized
INFO - 2020-02-13 14:08:23 --> Input Class Initialized
DEBUG - 2020-02-13 14:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:23 --> Security Class Initialized
INFO - 2020-02-13 14:08:23 --> Input Class Initialized
INFO - 2020-02-13 14:08:23 --> Language Class Initialized
INFO - 2020-02-13 14:08:23 --> Language Class Initialized
INFO - 2020-02-13 14:08:23 --> Language Class Initialized
INFO - 2020-02-13 14:08:23 --> Language Class Initialized
DEBUG - 2020-02-13 14:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:23 --> Input Class Initialized
INFO - 2020-02-13 14:08:23 --> Language Class Initialized
ERROR - 2020-02-13 14:08:23 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-13 14:08:23 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 14:08:23 --> Loader Class Initialized
INFO - 2020-02-13 14:08:23 --> Loader Class Initialized
ERROR - 2020-02-13 14:08:23 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 14:08:23 --> Helper loaded: url_helper
INFO - 2020-02-13 14:08:23 --> Helper loaded: url_helper
INFO - 2020-02-13 14:08:23 --> Language Class Initialized
INFO - 2020-02-13 14:08:24 --> Config Class Initialized
INFO - 2020-02-13 14:08:24 --> Config Class Initialized
INFO - 2020-02-13 14:08:24 --> Hooks Class Initialized
INFO - 2020-02-13 14:08:24 --> Hooks Class Initialized
INFO - 2020-02-13 14:08:24 --> Helper loaded: string_helper
INFO - 2020-02-13 14:08:24 --> Helper loaded: string_helper
ERROR - 2020-02-13 14:08:24 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-13 14:08:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 14:08:24 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:24 --> Database Driver Class Initialized
INFO - 2020-02-13 14:08:24 --> Database Driver Class Initialized
INFO - 2020-02-13 14:08:24 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:24 --> Utf8 Class Initialized
DEBUG - 2020-02-13 14:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 14:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:08:24 --> URI Class Initialized
INFO - 2020-02-13 14:08:24 --> URI Class Initialized
INFO - 2020-02-13 14:08:24 --> Controller Class Initialized
INFO - 2020-02-13 14:08:24 --> Router Class Initialized
INFO - 2020-02-13 14:08:24 --> Router Class Initialized
INFO - 2020-02-13 14:08:24 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:08:24 --> Output Class Initialized
INFO - 2020-02-13 14:08:24 --> Output Class Initialized
INFO - 2020-02-13 14:08:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:08:24 --> Security Class Initialized
INFO - 2020-02-13 14:08:24 --> Security Class Initialized
INFO - 2020-02-13 14:08:24 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 14:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 14:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:24 --> Input Class Initialized
INFO - 2020-02-13 14:08:24 --> Input Class Initialized
INFO - 2020-02-13 14:08:24 --> Helper loaded: form_helper
INFO - 2020-02-13 14:08:24 --> Form Validation Class Initialized
INFO - 2020-02-13 14:08:24 --> Language Class Initialized
INFO - 2020-02-13 14:08:24 --> Language Class Initialized
ERROR - 2020-02-13 14:08:24 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-13 14:08:24 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-13 14:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 14:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 14:08:24 --> Config Class Initialized
INFO - 2020-02-13 14:08:24 --> Hooks Class Initialized
INFO - 2020-02-13 14:08:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 14:08:24 --> Final output sent to browser
DEBUG - 2020-02-13 14:08:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 14:08:24 --> Total execution time: 1.2698
INFO - 2020-02-13 14:08:24 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:08:24 --> URI Class Initialized
INFO - 2020-02-13 14:08:24 --> Controller Class Initialized
INFO - 2020-02-13 14:08:24 --> Router Class Initialized
INFO - 2020-02-13 14:08:24 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:08:24 --> Output Class Initialized
INFO - 2020-02-13 14:08:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:08:24 --> Security Class Initialized
INFO - 2020-02-13 14:08:24 --> Model "M_pesan" initialized
DEBUG - 2020-02-13 14:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:24 --> Input Class Initialized
INFO - 2020-02-13 14:08:24 --> Helper loaded: form_helper
INFO - 2020-02-13 14:08:25 --> Form Validation Class Initialized
INFO - 2020-02-13 14:08:25 --> Language Class Initialized
ERROR - 2020-02-13 14:08:25 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-13 14:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 14:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 14:08:25 --> Config Class Initialized
INFO - 2020-02-13 14:08:25 --> Hooks Class Initialized
INFO - 2020-02-13 14:08:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 14:08:25 --> Final output sent to browser
DEBUG - 2020-02-13 14:08:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:25 --> Utf8 Class Initialized
DEBUG - 2020-02-13 14:08:25 --> Total execution time: 1.8661
INFO - 2020-02-13 14:08:25 --> URI Class Initialized
INFO - 2020-02-13 14:08:25 --> Router Class Initialized
INFO - 2020-02-13 14:08:25 --> Output Class Initialized
INFO - 2020-02-13 14:08:25 --> Security Class Initialized
DEBUG - 2020-02-13 14:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:25 --> Input Class Initialized
INFO - 2020-02-13 14:08:25 --> Language Class Initialized
ERROR - 2020-02-13 14:08:25 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-13 14:08:25 --> Config Class Initialized
INFO - 2020-02-13 14:08:25 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:08:25 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:25 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:25 --> URI Class Initialized
INFO - 2020-02-13 14:08:25 --> Router Class Initialized
INFO - 2020-02-13 14:08:25 --> Output Class Initialized
INFO - 2020-02-13 14:08:26 --> Security Class Initialized
DEBUG - 2020-02-13 14:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:26 --> Input Class Initialized
INFO - 2020-02-13 14:08:26 --> Language Class Initialized
ERROR - 2020-02-13 14:08:26 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-13 14:08:26 --> Config Class Initialized
INFO - 2020-02-13 14:08:26 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:08:26 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:26 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:26 --> URI Class Initialized
INFO - 2020-02-13 14:08:26 --> Router Class Initialized
INFO - 2020-02-13 14:08:26 --> Output Class Initialized
INFO - 2020-02-13 14:08:26 --> Security Class Initialized
DEBUG - 2020-02-13 14:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:26 --> Input Class Initialized
INFO - 2020-02-13 14:08:26 --> Language Class Initialized
ERROR - 2020-02-13 14:08:26 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 14:08:26 --> Config Class Initialized
INFO - 2020-02-13 14:08:26 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:08:26 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:26 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:27 --> URI Class Initialized
INFO - 2020-02-13 14:08:27 --> Router Class Initialized
INFO - 2020-02-13 14:08:27 --> Output Class Initialized
INFO - 2020-02-13 14:08:27 --> Security Class Initialized
DEBUG - 2020-02-13 14:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:27 --> Input Class Initialized
INFO - 2020-02-13 14:08:27 --> Language Class Initialized
ERROR - 2020-02-13 14:08:27 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-13 14:08:27 --> Config Class Initialized
INFO - 2020-02-13 14:08:27 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:08:27 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:27 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:27 --> URI Class Initialized
INFO - 2020-02-13 14:08:27 --> Router Class Initialized
INFO - 2020-02-13 14:08:27 --> Output Class Initialized
INFO - 2020-02-13 14:08:27 --> Security Class Initialized
DEBUG - 2020-02-13 14:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:27 --> Input Class Initialized
INFO - 2020-02-13 14:08:27 --> Language Class Initialized
ERROR - 2020-02-13 14:08:27 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 14:08:27 --> Config Class Initialized
INFO - 2020-02-13 14:08:28 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:08:28 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:28 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:28 --> URI Class Initialized
INFO - 2020-02-13 14:08:28 --> Router Class Initialized
INFO - 2020-02-13 14:08:28 --> Output Class Initialized
INFO - 2020-02-13 14:08:28 --> Security Class Initialized
DEBUG - 2020-02-13 14:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:28 --> Input Class Initialized
INFO - 2020-02-13 14:08:28 --> Language Class Initialized
ERROR - 2020-02-13 14:08:28 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-13 14:08:28 --> Config Class Initialized
INFO - 2020-02-13 14:08:28 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:08:28 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:28 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:28 --> URI Class Initialized
INFO - 2020-02-13 14:08:28 --> Router Class Initialized
INFO - 2020-02-13 14:08:28 --> Output Class Initialized
INFO - 2020-02-13 14:08:28 --> Security Class Initialized
DEBUG - 2020-02-13 14:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:28 --> Input Class Initialized
INFO - 2020-02-13 14:08:28 --> Language Class Initialized
ERROR - 2020-02-13 14:08:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-13 14:08:29 --> Config Class Initialized
INFO - 2020-02-13 14:08:29 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:08:29 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:08:29 --> Utf8 Class Initialized
INFO - 2020-02-13 14:08:29 --> URI Class Initialized
INFO - 2020-02-13 14:08:29 --> Router Class Initialized
INFO - 2020-02-13 14:08:29 --> Output Class Initialized
INFO - 2020-02-13 14:08:29 --> Security Class Initialized
DEBUG - 2020-02-13 14:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:08:29 --> Input Class Initialized
INFO - 2020-02-13 14:08:29 --> Language Class Initialized
ERROR - 2020-02-13 14:08:29 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-13 14:09:14 --> Config Class Initialized
INFO - 2020-02-13 14:09:14 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:09:14 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:09:14 --> Utf8 Class Initialized
INFO - 2020-02-13 14:09:14 --> URI Class Initialized
INFO - 2020-02-13 14:09:14 --> Router Class Initialized
INFO - 2020-02-13 14:09:14 --> Output Class Initialized
INFO - 2020-02-13 14:09:14 --> Security Class Initialized
DEBUG - 2020-02-13 14:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:09:14 --> Input Class Initialized
INFO - 2020-02-13 14:09:14 --> Language Class Initialized
INFO - 2020-02-13 14:09:14 --> Loader Class Initialized
INFO - 2020-02-13 14:09:14 --> Helper loaded: url_helper
INFO - 2020-02-13 14:09:14 --> Helper loaded: string_helper
INFO - 2020-02-13 14:09:14 --> Database Driver Class Initialized
DEBUG - 2020-02-13 14:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:09:15 --> Controller Class Initialized
INFO - 2020-02-13 14:09:15 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:09:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:09:15 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:09:15 --> Helper loaded: form_helper
INFO - 2020-02-13 14:09:15 --> Form Validation Class Initialized
INFO - 2020-02-13 14:09:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-13 14:09:15 --> Final output sent to browser
DEBUG - 2020-02-13 14:09:15 --> Total execution time: 1.4030
INFO - 2020-02-13 14:09:21 --> Config Class Initialized
INFO - 2020-02-13 14:09:21 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:09:21 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:09:21 --> Utf8 Class Initialized
INFO - 2020-02-13 14:09:21 --> URI Class Initialized
INFO - 2020-02-13 14:09:21 --> Router Class Initialized
INFO - 2020-02-13 14:09:21 --> Output Class Initialized
INFO - 2020-02-13 14:09:21 --> Security Class Initialized
DEBUG - 2020-02-13 14:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:09:21 --> Input Class Initialized
INFO - 2020-02-13 14:09:21 --> Language Class Initialized
INFO - 2020-02-13 14:09:21 --> Loader Class Initialized
INFO - 2020-02-13 14:09:21 --> Helper loaded: url_helper
INFO - 2020-02-13 14:09:21 --> Helper loaded: string_helper
INFO - 2020-02-13 14:09:21 --> Database Driver Class Initialized
DEBUG - 2020-02-13 14:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:09:22 --> Controller Class Initialized
INFO - 2020-02-13 14:09:22 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:09:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:09:22 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:09:22 --> Helper loaded: form_helper
INFO - 2020-02-13 14:09:22 --> Form Validation Class Initialized
ERROR - 2020-02-13 14:09:22 --> Severity: Notice --> Undefined index: bank C:\xampp\htdocs\roadshow\application\models\M_tiket.php 74
INFO - 2020-02-13 14:09:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 14:09:22 --> Final output sent to browser
DEBUG - 2020-02-13 14:09:22 --> Total execution time: 1.3581
INFO - 2020-02-13 14:12:48 --> Config Class Initialized
INFO - 2020-02-13 14:12:48 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:12:48 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:12:48 --> Utf8 Class Initialized
INFO - 2020-02-13 14:12:48 --> URI Class Initialized
INFO - 2020-02-13 14:12:48 --> Router Class Initialized
INFO - 2020-02-13 14:12:48 --> Output Class Initialized
INFO - 2020-02-13 14:12:48 --> Security Class Initialized
DEBUG - 2020-02-13 14:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:12:48 --> Input Class Initialized
INFO - 2020-02-13 14:12:48 --> Language Class Initialized
INFO - 2020-02-13 14:12:48 --> Loader Class Initialized
INFO - 2020-02-13 14:12:49 --> Helper loaded: url_helper
INFO - 2020-02-13 14:12:49 --> Helper loaded: string_helper
INFO - 2020-02-13 14:12:49 --> Database Driver Class Initialized
DEBUG - 2020-02-13 14:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:12:49 --> Controller Class Initialized
INFO - 2020-02-13 14:12:49 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:12:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:12:49 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:12:49 --> Helper loaded: form_helper
INFO - 2020-02-13 14:12:49 --> Form Validation Class Initialized
ERROR - 2020-02-13 14:12:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\roadshow\application\views\Pemesanan\form_bukti.php 21
ERROR - 2020-02-13 14:12:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\form_bukti.php 21
ERROR - 2020-02-13 14:12:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\roadshow\application\views\Pemesanan\form_bukti.php 22
ERROR - 2020-02-13 14:12:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\form_bukti.php 22
INFO - 2020-02-13 14:12:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 14:12:49 --> Final output sent to browser
DEBUG - 2020-02-13 14:12:49 --> Total execution time: 1.2857
INFO - 2020-02-13 14:13:04 --> Config Class Initialized
INFO - 2020-02-13 14:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:13:04 --> Utf8 Class Initialized
INFO - 2020-02-13 14:13:04 --> URI Class Initialized
INFO - 2020-02-13 14:13:04 --> Router Class Initialized
INFO - 2020-02-13 14:13:04 --> Output Class Initialized
INFO - 2020-02-13 14:13:04 --> Security Class Initialized
DEBUG - 2020-02-13 14:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:13:05 --> Input Class Initialized
INFO - 2020-02-13 14:13:05 --> Language Class Initialized
INFO - 2020-02-13 14:13:05 --> Loader Class Initialized
INFO - 2020-02-13 14:13:05 --> Helper loaded: url_helper
INFO - 2020-02-13 14:13:05 --> Helper loaded: string_helper
INFO - 2020-02-13 14:13:05 --> Database Driver Class Initialized
DEBUG - 2020-02-13 14:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:13:05 --> Controller Class Initialized
INFO - 2020-02-13 14:13:05 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:13:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:13:05 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:13:05 --> Helper loaded: form_helper
INFO - 2020-02-13 14:13:05 --> Form Validation Class Initialized
INFO - 2020-02-13 14:13:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-13 14:13:05 --> Final output sent to browser
DEBUG - 2020-02-13 14:13:05 --> Total execution time: 1.0897
INFO - 2020-02-13 14:31:08 --> Config Class Initialized
INFO - 2020-02-13 14:31:08 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:31:08 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:31:08 --> Utf8 Class Initialized
INFO - 2020-02-13 14:31:08 --> URI Class Initialized
INFO - 2020-02-13 14:31:08 --> Router Class Initialized
INFO - 2020-02-13 14:31:09 --> Output Class Initialized
INFO - 2020-02-13 14:31:09 --> Security Class Initialized
DEBUG - 2020-02-13 14:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:31:09 --> Input Class Initialized
INFO - 2020-02-13 14:31:09 --> Language Class Initialized
INFO - 2020-02-13 14:31:09 --> Loader Class Initialized
INFO - 2020-02-13 14:31:09 --> Helper loaded: url_helper
INFO - 2020-02-13 14:31:09 --> Helper loaded: string_helper
INFO - 2020-02-13 14:31:09 --> Database Driver Class Initialized
DEBUG - 2020-02-13 14:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:31:09 --> Controller Class Initialized
INFO - 2020-02-13 14:31:09 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:31:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:31:09 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:31:09 --> Helper loaded: form_helper
INFO - 2020-02-13 14:31:10 --> Form Validation Class Initialized
INFO - 2020-02-13 14:31:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 14:31:10 --> Final output sent to browser
INFO - 2020-02-13 14:31:10 --> Config Class Initialized
INFO - 2020-02-13 14:31:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:31:10 --> Total execution time: 1.9143
INFO - 2020-02-13 14:31:10 --> Config Class Initialized
INFO - 2020-02-13 14:31:10 --> Config Class Initialized
INFO - 2020-02-13 14:31:10 --> Config Class Initialized
INFO - 2020-02-13 14:31:10 --> Hooks Class Initialized
INFO - 2020-02-13 14:31:10 --> Hooks Class Initialized
INFO - 2020-02-13 14:31:10 --> Hooks Class Initialized
DEBUG - 2020-02-13 14:31:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:31:10 --> Utf8 Class Initialized
DEBUG - 2020-02-13 14:31:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 14:31:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 14:31:10 --> UTF-8 Support Enabled
INFO - 2020-02-13 14:31:10 --> Utf8 Class Initialized
INFO - 2020-02-13 14:31:10 --> Utf8 Class Initialized
INFO - 2020-02-13 14:31:10 --> Utf8 Class Initialized
INFO - 2020-02-13 14:31:10 --> URI Class Initialized
INFO - 2020-02-13 14:31:10 --> URI Class Initialized
INFO - 2020-02-13 14:31:10 --> URI Class Initialized
INFO - 2020-02-13 14:31:10 --> URI Class Initialized
INFO - 2020-02-13 14:31:10 --> Router Class Initialized
INFO - 2020-02-13 14:31:10 --> Router Class Initialized
INFO - 2020-02-13 14:31:10 --> Router Class Initialized
INFO - 2020-02-13 14:31:10 --> Router Class Initialized
INFO - 2020-02-13 14:31:10 --> Output Class Initialized
INFO - 2020-02-13 14:31:10 --> Security Class Initialized
INFO - 2020-02-13 14:31:10 --> Output Class Initialized
INFO - 2020-02-13 14:31:10 --> Output Class Initialized
INFO - 2020-02-13 14:31:10 --> Output Class Initialized
DEBUG - 2020-02-13 14:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:31:10 --> Security Class Initialized
INFO - 2020-02-13 14:31:10 --> Security Class Initialized
INFO - 2020-02-13 14:31:10 --> Security Class Initialized
INFO - 2020-02-13 14:31:10 --> Input Class Initialized
DEBUG - 2020-02-13 14:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 14:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-13 14:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-13 14:31:10 --> Input Class Initialized
INFO - 2020-02-13 14:31:10 --> Input Class Initialized
INFO - 2020-02-13 14:31:10 --> Input Class Initialized
INFO - 2020-02-13 14:31:10 --> Language Class Initialized
INFO - 2020-02-13 14:31:10 --> Language Class Initialized
ERROR - 2020-02-13 14:31:10 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-13 14:31:10 --> Language Class Initialized
INFO - 2020-02-13 14:31:10 --> Language Class Initialized
INFO - 2020-02-13 14:31:10 --> Loader Class Initialized
INFO - 2020-02-13 14:31:10 --> Loader Class Initialized
INFO - 2020-02-13 14:31:10 --> Helper loaded: url_helper
ERROR - 2020-02-13 14:31:10 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-13 14:31:10 --> Helper loaded: url_helper
INFO - 2020-02-13 14:31:11 --> Helper loaded: string_helper
INFO - 2020-02-13 14:31:11 --> Helper loaded: string_helper
INFO - 2020-02-13 14:31:11 --> Database Driver Class Initialized
INFO - 2020-02-13 14:31:11 --> Database Driver Class Initialized
DEBUG - 2020-02-13 14:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-13 14:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-13 14:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:31:11 --> Controller Class Initialized
INFO - 2020-02-13 14:31:11 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:31:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:31:11 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:31:11 --> Helper loaded: form_helper
INFO - 2020-02-13 14:31:11 --> Form Validation Class Initialized
ERROR - 2020-02-13 14:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 14:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 14:31:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 14:31:11 --> Final output sent to browser
DEBUG - 2020-02-13 14:31:11 --> Total execution time: 1.3295
INFO - 2020-02-13 14:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-13 14:31:11 --> Controller Class Initialized
INFO - 2020-02-13 14:31:11 --> Model "M_tiket" initialized
INFO - 2020-02-13 14:31:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-13 14:31:11 --> Model "M_pesan" initialized
INFO - 2020-02-13 14:31:11 --> Helper loaded: form_helper
INFO - 2020-02-13 14:31:12 --> Form Validation Class Initialized
ERROR - 2020-02-13 14:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-13 14:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-13 14:31:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-13 14:31:12 --> Final output sent to browser
DEBUG - 2020-02-13 14:31:12 --> Total execution time: 1.8650
