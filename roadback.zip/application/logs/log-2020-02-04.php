<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-04 05:14:56 --> Config Class Initialized
INFO - 2020-02-04 05:14:56 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:14:56 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:14:56 --> Utf8 Class Initialized
INFO - 2020-02-04 05:14:56 --> URI Class Initialized
DEBUG - 2020-02-04 05:14:56 --> No URI present. Default controller set.
INFO - 2020-02-04 05:14:56 --> Router Class Initialized
INFO - 2020-02-04 05:14:56 --> Output Class Initialized
INFO - 2020-02-04 05:14:56 --> Security Class Initialized
DEBUG - 2020-02-04 05:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:14:56 --> Input Class Initialized
INFO - 2020-02-04 05:14:56 --> Language Class Initialized
INFO - 2020-02-04 05:14:57 --> Loader Class Initialized
INFO - 2020-02-04 05:14:57 --> Helper loaded: url_helper
INFO - 2020-02-04 05:14:57 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:14:57 --> Controller Class Initialized
INFO - 2020-02-04 05:14:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 05:14:57 --> Pagination Class Initialized
INFO - 2020-02-04 05:14:57 --> Model "M_show" initialized
INFO - 2020-02-04 05:14:57 --> Helper loaded: form_helper
INFO - 2020-02-04 05:14:57 --> Form Validation Class Initialized
INFO - 2020-02-04 05:14:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 05:14:58 --> Final output sent to browser
DEBUG - 2020-02-04 05:14:58 --> Total execution time: 1.8392
INFO - 2020-02-04 05:14:58 --> Config Class Initialized
INFO - 2020-02-04 05:14:58 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:14:58 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:14:58 --> Utf8 Class Initialized
INFO - 2020-02-04 05:14:58 --> URI Class Initialized
DEBUG - 2020-02-04 05:14:58 --> No URI present. Default controller set.
INFO - 2020-02-04 05:14:58 --> Router Class Initialized
INFO - 2020-02-04 05:14:58 --> Output Class Initialized
INFO - 2020-02-04 05:14:58 --> Security Class Initialized
DEBUG - 2020-02-04 05:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:14:58 --> Input Class Initialized
INFO - 2020-02-04 05:14:58 --> Language Class Initialized
INFO - 2020-02-04 05:14:58 --> Loader Class Initialized
INFO - 2020-02-04 05:14:58 --> Helper loaded: url_helper
INFO - 2020-02-04 05:14:58 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:14:58 --> Controller Class Initialized
INFO - 2020-02-04 05:14:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 05:14:58 --> Pagination Class Initialized
INFO - 2020-02-04 05:14:58 --> Model "M_show" initialized
INFO - 2020-02-04 05:14:58 --> Helper loaded: form_helper
INFO - 2020-02-04 05:14:58 --> Form Validation Class Initialized
INFO - 2020-02-04 05:14:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 05:14:58 --> Final output sent to browser
DEBUG - 2020-02-04 05:14:58 --> Total execution time: 0.4672
INFO - 2020-02-04 05:15:05 --> Config Class Initialized
INFO - 2020-02-04 05:15:05 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:06 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:06 --> URI Class Initialized
INFO - 2020-02-04 05:15:06 --> Router Class Initialized
INFO - 2020-02-04 05:15:06 --> Output Class Initialized
INFO - 2020-02-04 05:15:06 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:06 --> Input Class Initialized
INFO - 2020-02-04 05:15:06 --> Language Class Initialized
INFO - 2020-02-04 05:15:06 --> Loader Class Initialized
INFO - 2020-02-04 05:15:06 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:06 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:06 --> Controller Class Initialized
INFO - 2020-02-04 05:15:06 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:15:06 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:06 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:15:06 --> Final output sent to browser
DEBUG - 2020-02-04 05:15:06 --> Total execution time: 0.8279
INFO - 2020-02-04 05:15:06 --> Config Class Initialized
INFO - 2020-02-04 05:15:06 --> Config Class Initialized
INFO - 2020-02-04 05:15:06 --> Config Class Initialized
INFO - 2020-02-04 05:15:06 --> Config Class Initialized
INFO - 2020-02-04 05:15:06 --> Config Class Initialized
INFO - 2020-02-04 05:15:06 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:06 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:06 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:06 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:06 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:06 --> Config Class Initialized
DEBUG - 2020-02-04 05:15:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:07 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:07 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:07 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:07 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:07 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:07 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:15:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:07 --> URI Class Initialized
INFO - 2020-02-04 05:15:07 --> URI Class Initialized
INFO - 2020-02-04 05:15:07 --> URI Class Initialized
INFO - 2020-02-04 05:15:07 --> URI Class Initialized
INFO - 2020-02-04 05:15:07 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:07 --> URI Class Initialized
INFO - 2020-02-04 05:15:07 --> Router Class Initialized
INFO - 2020-02-04 05:15:07 --> URI Class Initialized
INFO - 2020-02-04 05:15:07 --> Router Class Initialized
INFO - 2020-02-04 05:15:07 --> Router Class Initialized
INFO - 2020-02-04 05:15:07 --> Router Class Initialized
INFO - 2020-02-04 05:15:07 --> Router Class Initialized
INFO - 2020-02-04 05:15:07 --> Output Class Initialized
INFO - 2020-02-04 05:15:07 --> Router Class Initialized
INFO - 2020-02-04 05:15:07 --> Output Class Initialized
INFO - 2020-02-04 05:15:07 --> Output Class Initialized
INFO - 2020-02-04 05:15:07 --> Output Class Initialized
INFO - 2020-02-04 05:15:07 --> Security Class Initialized
INFO - 2020-02-04 05:15:07 --> Output Class Initialized
DEBUG - 2020-02-04 05:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:07 --> Security Class Initialized
INFO - 2020-02-04 05:15:07 --> Security Class Initialized
INFO - 2020-02-04 05:15:07 --> Security Class Initialized
INFO - 2020-02-04 05:15:07 --> Security Class Initialized
INFO - 2020-02-04 05:15:07 --> Output Class Initialized
INFO - 2020-02-04 05:15:07 --> Input Class Initialized
DEBUG - 2020-02-04 05:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:07 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:07 --> Input Class Initialized
INFO - 2020-02-04 05:15:07 --> Input Class Initialized
INFO - 2020-02-04 05:15:07 --> Input Class Initialized
INFO - 2020-02-04 05:15:07 --> Input Class Initialized
INFO - 2020-02-04 05:15:07 --> Language Class Initialized
DEBUG - 2020-02-04 05:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:07 --> Language Class Initialized
INFO - 2020-02-04 05:15:07 --> Language Class Initialized
INFO - 2020-02-04 05:15:07 --> Language Class Initialized
INFO - 2020-02-04 05:15:07 --> Language Class Initialized
INFO - 2020-02-04 05:15:07 --> Loader Class Initialized
INFO - 2020-02-04 05:15:07 --> Input Class Initialized
INFO - 2020-02-04 05:15:07 --> Language Class Initialized
INFO - 2020-02-04 05:15:07 --> Loader Class Initialized
INFO - 2020-02-04 05:15:07 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:07 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:07 --> Database Driver Class Initialized
ERROR - 2020-02-04 05:15:07 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-04 05:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-02-04 05:15:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:15:07 --> Database Driver Class Initialized
ERROR - 2020-02-04 05:15:07 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 05:15:07 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:15:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 05:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:15:07 --> Controller Class Initialized
INFO - 2020-02-04 05:15:07 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:15:07 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:07 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:07 --> Config Class Initialized
INFO - 2020-02-04 05:15:07 --> Config Class Initialized
INFO - 2020-02-04 05:15:07 --> Config Class Initialized
INFO - 2020-02-04 05:15:07 --> Config Class Initialized
ERROR - 2020-02-04 05:15:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:15:07 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:07 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:07 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:07 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:07 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:07 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:07 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:07 --> Utf8 Class Initialized
ERROR - 2020-02-04 05:15:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:15:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:15:07 --> URI Class Initialized
INFO - 2020-02-04 05:15:07 --> URI Class Initialized
INFO - 2020-02-04 05:15:07 --> URI Class Initialized
INFO - 2020-02-04 05:15:07 --> URI Class Initialized
INFO - 2020-02-04 05:15:07 --> Final output sent to browser
INFO - 2020-02-04 05:15:07 --> Router Class Initialized
INFO - 2020-02-04 05:15:07 --> Router Class Initialized
INFO - 2020-02-04 05:15:07 --> Router Class Initialized
INFO - 2020-02-04 05:15:07 --> Router Class Initialized
DEBUG - 2020-02-04 05:15:07 --> Total execution time: 0.8821
INFO - 2020-02-04 05:15:07 --> Output Class Initialized
INFO - 2020-02-04 05:15:07 --> Output Class Initialized
INFO - 2020-02-04 05:15:07 --> Output Class Initialized
INFO - 2020-02-04 05:15:07 --> Output Class Initialized
INFO - 2020-02-04 05:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:07 --> Security Class Initialized
INFO - 2020-02-04 05:15:07 --> Security Class Initialized
INFO - 2020-02-04 05:15:07 --> Security Class Initialized
INFO - 2020-02-04 05:15:07 --> Security Class Initialized
INFO - 2020-02-04 05:15:07 --> Config Class Initialized
INFO - 2020-02-04 05:15:07 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:07 --> Controller Class Initialized
DEBUG - 2020-02-04 05:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:08 --> Input Class Initialized
INFO - 2020-02-04 05:15:08 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:15:08 --> Input Class Initialized
INFO - 2020-02-04 05:15:08 --> Input Class Initialized
INFO - 2020-02-04 05:15:08 --> Input Class Initialized
DEBUG - 2020-02-04 05:15:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:08 --> Language Class Initialized
INFO - 2020-02-04 05:15:08 --> Language Class Initialized
INFO - 2020-02-04 05:15:08 --> Language Class Initialized
INFO - 2020-02-04 05:15:08 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:08 --> Language Class Initialized
INFO - 2020-02-04 05:15:08 --> Helper loaded: form_helper
ERROR - 2020-02-04 05:15:08 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-04 05:15:08 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-04 05:15:08 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:15:08 --> URI Class Initialized
INFO - 2020-02-04 05:15:08 --> Form Validation Class Initialized
ERROR - 2020-02-04 05:15:08 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:15:08 --> Router Class Initialized
ERROR - 2020-02-04 05:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:15:08 --> Config Class Initialized
INFO - 2020-02-04 05:15:08 --> Config Class Initialized
INFO - 2020-02-04 05:15:08 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:08 --> Hooks Class Initialized
ERROR - 2020-02-04 05:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:15:08 --> Output Class Initialized
INFO - 2020-02-04 05:15:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:15:08 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:08 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:08 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:08 --> Final output sent to browser
DEBUG - 2020-02-04 05:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:08 --> Total execution time: 1.3377
INFO - 2020-02-04 05:15:08 --> Input Class Initialized
INFO - 2020-02-04 05:15:08 --> URI Class Initialized
INFO - 2020-02-04 05:15:08 --> URI Class Initialized
INFO - 2020-02-04 05:15:08 --> Language Class Initialized
INFO - 2020-02-04 05:15:08 --> Router Class Initialized
INFO - 2020-02-04 05:15:08 --> Router Class Initialized
ERROR - 2020-02-04 05:15:08 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 05:15:08 --> Output Class Initialized
INFO - 2020-02-04 05:15:08 --> Output Class Initialized
INFO - 2020-02-04 05:15:08 --> Security Class Initialized
INFO - 2020-02-04 05:15:08 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:08 --> Config Class Initialized
INFO - 2020-02-04 05:15:08 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:08 --> Input Class Initialized
INFO - 2020-02-04 05:15:08 --> Input Class Initialized
INFO - 2020-02-04 05:15:08 --> Language Class Initialized
INFO - 2020-02-04 05:15:08 --> Language Class Initialized
DEBUG - 2020-02-04 05:15:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:08 --> Utf8 Class Initialized
ERROR - 2020-02-04 05:15:08 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 05:15:08 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:15:08 --> URI Class Initialized
INFO - 2020-02-04 05:15:08 --> Router Class Initialized
INFO - 2020-02-04 05:15:08 --> Output Class Initialized
INFO - 2020-02-04 05:15:08 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:08 --> Input Class Initialized
INFO - 2020-02-04 05:15:08 --> Language Class Initialized
ERROR - 2020-02-04 05:15:08 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:15:09 --> Config Class Initialized
INFO - 2020-02-04 05:15:09 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:09 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:09 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:09 --> URI Class Initialized
INFO - 2020-02-04 05:15:09 --> Router Class Initialized
INFO - 2020-02-04 05:15:09 --> Output Class Initialized
INFO - 2020-02-04 05:15:09 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:09 --> Input Class Initialized
INFO - 2020-02-04 05:15:09 --> Language Class Initialized
ERROR - 2020-02-04 05:15:09 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:15:09 --> Config Class Initialized
INFO - 2020-02-04 05:15:09 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:10 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:10 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:10 --> URI Class Initialized
INFO - 2020-02-04 05:15:10 --> Router Class Initialized
INFO - 2020-02-04 05:15:10 --> Output Class Initialized
INFO - 2020-02-04 05:15:10 --> Config Class Initialized
INFO - 2020-02-04 05:15:10 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:10 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:10 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:10 --> Input Class Initialized
INFO - 2020-02-04 05:15:10 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:10 --> Language Class Initialized
INFO - 2020-02-04 05:15:10 --> URI Class Initialized
ERROR - 2020-02-04 05:15:10 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-04 05:15:10 --> No URI present. Default controller set.
INFO - 2020-02-04 05:15:10 --> Router Class Initialized
INFO - 2020-02-04 05:15:10 --> Config Class Initialized
INFO - 2020-02-04 05:15:10 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:10 --> Output Class Initialized
INFO - 2020-02-04 05:15:10 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:10 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:10 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:10 --> Input Class Initialized
INFO - 2020-02-04 05:15:10 --> URI Class Initialized
INFO - 2020-02-04 05:15:10 --> Language Class Initialized
INFO - 2020-02-04 05:15:10 --> Router Class Initialized
INFO - 2020-02-04 05:15:10 --> Output Class Initialized
INFO - 2020-02-04 05:15:10 --> Loader Class Initialized
INFO - 2020-02-04 05:15:10 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:10 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:10 --> Database Driver Class Initialized
INFO - 2020-02-04 05:15:10 --> Input Class Initialized
DEBUG - 2020-02-04 05:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:10 --> Language Class Initialized
INFO - 2020-02-04 05:15:10 --> Controller Class Initialized
ERROR - 2020-02-04 05:15:10 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 05:15:10 --> Config Class Initialized
INFO - 2020-02-04 05:15:10 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:10 --> Pagination Class Initialized
INFO - 2020-02-04 05:15:10 --> Model "M_show" initialized
DEBUG - 2020-02-04 05:15:10 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:11 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:11 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:11 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:11 --> URI Class Initialized
INFO - 2020-02-04 05:15:11 --> Router Class Initialized
INFO - 2020-02-04 05:15:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 05:15:11 --> Final output sent to browser
INFO - 2020-02-04 05:15:11 --> Output Class Initialized
DEBUG - 2020-02-04 05:15:11 --> Total execution time: 1.0086
INFO - 2020-02-04 05:15:11 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:11 --> Input Class Initialized
INFO - 2020-02-04 05:15:11 --> Language Class Initialized
ERROR - 2020-02-04 05:15:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:15:13 --> Config Class Initialized
INFO - 2020-02-04 05:15:13 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:13 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:13 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:13 --> URI Class Initialized
INFO - 2020-02-04 05:15:13 --> Router Class Initialized
INFO - 2020-02-04 05:15:13 --> Output Class Initialized
INFO - 2020-02-04 05:15:13 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:13 --> Input Class Initialized
INFO - 2020-02-04 05:15:13 --> Language Class Initialized
INFO - 2020-02-04 05:15:13 --> Loader Class Initialized
INFO - 2020-02-04 05:15:14 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:14 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:14 --> Controller Class Initialized
INFO - 2020-02-04 05:15:14 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:15:14 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:14 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:15:14 --> Final output sent to browser
DEBUG - 2020-02-04 05:15:14 --> Total execution time: 0.8651
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
INFO - 2020-02-04 05:15:14 --> Output Class Initialized
INFO - 2020-02-04 05:15:14 --> Output Class Initialized
INFO - 2020-02-04 05:15:14 --> Output Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
INFO - 2020-02-04 05:15:14 --> Output Class Initialized
INFO - 2020-02-04 05:15:14 --> Security Class Initialized
INFO - 2020-02-04 05:15:14 --> Security Class Initialized
INFO - 2020-02-04 05:15:14 --> Output Class Initialized
INFO - 2020-02-04 05:15:14 --> Output Class Initialized
INFO - 2020-02-04 05:15:14 --> Security Class Initialized
INFO - 2020-02-04 05:15:14 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:14 --> Security Class Initialized
INFO - 2020-02-04 05:15:14 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:14 --> Input Class Initialized
INFO - 2020-02-04 05:15:14 --> Input Class Initialized
INFO - 2020-02-04 05:15:14 --> Input Class Initialized
INFO - 2020-02-04 05:15:14 --> Input Class Initialized
DEBUG - 2020-02-04 05:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:14 --> Input Class Initialized
INFO - 2020-02-04 05:15:14 --> Input Class Initialized
INFO - 2020-02-04 05:15:14 --> Language Class Initialized
INFO - 2020-02-04 05:15:14 --> Language Class Initialized
INFO - 2020-02-04 05:15:14 --> Language Class Initialized
INFO - 2020-02-04 05:15:14 --> Language Class Initialized
INFO - 2020-02-04 05:15:14 --> Language Class Initialized
INFO - 2020-02-04 05:15:14 --> Language Class Initialized
ERROR - 2020-02-04 05:15:14 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:15:14 --> Loader Class Initialized
ERROR - 2020-02-04 05:15:14 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:15:14 --> Loader Class Initialized
ERROR - 2020-02-04 05:15:14 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 05:15:14 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 05:15:14 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:14 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:14 --> Database Driver Class Initialized
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Database Driver Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 05:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:14 --> Controller Class Initialized
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
INFO - 2020-02-04 05:15:14 --> Output Class Initialized
INFO - 2020-02-04 05:15:14 --> Output Class Initialized
INFO - 2020-02-04 05:15:14 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:14 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:14 --> Output Class Initialized
INFO - 2020-02-04 05:15:14 --> Output Class Initialized
INFO - 2020-02-04 05:15:14 --> Security Class Initialized
INFO - 2020-02-04 05:15:14 --> Security Class Initialized
INFO - 2020-02-04 05:15:14 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:14 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 05:15:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:15:14 --> Input Class Initialized
INFO - 2020-02-04 05:15:14 --> Input Class Initialized
ERROR - 2020-02-04 05:15:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-04 05:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:14 --> Input Class Initialized
INFO - 2020-02-04 05:15:14 --> Input Class Initialized
INFO - 2020-02-04 05:15:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:15:14 --> Language Class Initialized
INFO - 2020-02-04 05:15:14 --> Language Class Initialized
INFO - 2020-02-04 05:15:14 --> Final output sent to browser
INFO - 2020-02-04 05:15:14 --> Language Class Initialized
INFO - 2020-02-04 05:15:14 --> Language Class Initialized
ERROR - 2020-02-04 05:15:14 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 05:15:14 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-04 05:15:14 --> Total execution time: 0.5104
ERROR - 2020-02-04 05:15:14 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-04 05:15:14 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Config Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:14 --> Controller Class Initialized
INFO - 2020-02-04 05:15:14 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:14 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:14 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> URI Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
INFO - 2020-02-04 05:15:14 --> Router Class Initialized
ERROR - 2020-02-04 05:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 05:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:15:15 --> Output Class Initialized
INFO - 2020-02-04 05:15:15 --> Output Class Initialized
INFO - 2020-02-04 05:15:15 --> Output Class Initialized
INFO - 2020-02-04 05:15:15 --> Output Class Initialized
INFO - 2020-02-04 05:15:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:15:15 --> Security Class Initialized
INFO - 2020-02-04 05:15:15 --> Security Class Initialized
INFO - 2020-02-04 05:15:15 --> Security Class Initialized
INFO - 2020-02-04 05:15:15 --> Security Class Initialized
INFO - 2020-02-04 05:15:15 --> Final output sent to browser
DEBUG - 2020-02-04 05:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:15 --> Input Class Initialized
INFO - 2020-02-04 05:15:15 --> Input Class Initialized
INFO - 2020-02-04 05:15:15 --> Input Class Initialized
DEBUG - 2020-02-04 05:15:15 --> Total execution time: 0.7456
INFO - 2020-02-04 05:15:15 --> Input Class Initialized
INFO - 2020-02-04 05:15:15 --> Language Class Initialized
INFO - 2020-02-04 05:15:15 --> Language Class Initialized
INFO - 2020-02-04 05:15:15 --> Language Class Initialized
INFO - 2020-02-04 05:15:15 --> Language Class Initialized
ERROR - 2020-02-04 05:15:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 05:15:15 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 05:15:15 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 05:15:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:15:15 --> Config Class Initialized
INFO - 2020-02-04 05:15:15 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:15 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:15 --> URI Class Initialized
INFO - 2020-02-04 05:15:15 --> Router Class Initialized
INFO - 2020-02-04 05:15:15 --> Output Class Initialized
INFO - 2020-02-04 05:15:15 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:15 --> Input Class Initialized
INFO - 2020-02-04 05:15:15 --> Language Class Initialized
ERROR - 2020-02-04 05:15:15 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:15:15 --> Config Class Initialized
INFO - 2020-02-04 05:15:15 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:15 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:15 --> URI Class Initialized
INFO - 2020-02-04 05:15:15 --> Router Class Initialized
INFO - 2020-02-04 05:15:15 --> Output Class Initialized
INFO - 2020-02-04 05:15:15 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:15 --> Input Class Initialized
INFO - 2020-02-04 05:15:15 --> Language Class Initialized
ERROR - 2020-02-04 05:15:15 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:15:15 --> Config Class Initialized
INFO - 2020-02-04 05:15:15 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:15 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:15 --> URI Class Initialized
INFO - 2020-02-04 05:15:15 --> Router Class Initialized
INFO - 2020-02-04 05:15:15 --> Output Class Initialized
INFO - 2020-02-04 05:15:15 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:15 --> Input Class Initialized
INFO - 2020-02-04 05:15:15 --> Language Class Initialized
ERROR - 2020-02-04 05:15:15 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:15:15 --> Config Class Initialized
INFO - 2020-02-04 05:15:15 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:15 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:15 --> URI Class Initialized
INFO - 2020-02-04 05:15:15 --> Router Class Initialized
INFO - 2020-02-04 05:15:15 --> Output Class Initialized
INFO - 2020-02-04 05:15:15 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:16 --> Input Class Initialized
INFO - 2020-02-04 05:15:16 --> Language Class Initialized
ERROR - 2020-02-04 05:15:16 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:15:16 --> Config Class Initialized
INFO - 2020-02-04 05:15:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:16 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:16 --> URI Class Initialized
INFO - 2020-02-04 05:15:16 --> Router Class Initialized
INFO - 2020-02-04 05:15:16 --> Output Class Initialized
INFO - 2020-02-04 05:15:16 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:16 --> Input Class Initialized
INFO - 2020-02-04 05:15:16 --> Language Class Initialized
ERROR - 2020-02-04 05:15:16 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:15:16 --> Config Class Initialized
INFO - 2020-02-04 05:15:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:16 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:16 --> URI Class Initialized
INFO - 2020-02-04 05:15:16 --> Router Class Initialized
INFO - 2020-02-04 05:15:16 --> Output Class Initialized
INFO - 2020-02-04 05:15:16 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:16 --> Input Class Initialized
INFO - 2020-02-04 05:15:16 --> Language Class Initialized
ERROR - 2020-02-04 05:15:16 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:15:16 --> Config Class Initialized
INFO - 2020-02-04 05:15:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:16 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:16 --> URI Class Initialized
INFO - 2020-02-04 05:15:16 --> Router Class Initialized
INFO - 2020-02-04 05:15:16 --> Output Class Initialized
INFO - 2020-02-04 05:15:16 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:16 --> Input Class Initialized
INFO - 2020-02-04 05:15:16 --> Language Class Initialized
ERROR - 2020-02-04 05:15:16 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:15:16 --> Config Class Initialized
INFO - 2020-02-04 05:15:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:16 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:16 --> URI Class Initialized
INFO - 2020-02-04 05:15:16 --> Router Class Initialized
INFO - 2020-02-04 05:15:16 --> Output Class Initialized
INFO - 2020-02-04 05:15:16 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:17 --> Input Class Initialized
INFO - 2020-02-04 05:15:17 --> Language Class Initialized
ERROR - 2020-02-04 05:15:17 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:15:17 --> Config Class Initialized
INFO - 2020-02-04 05:15:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:17 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:17 --> URI Class Initialized
INFO - 2020-02-04 05:15:17 --> Router Class Initialized
INFO - 2020-02-04 05:15:17 --> Output Class Initialized
INFO - 2020-02-04 05:15:17 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:17 --> Input Class Initialized
INFO - 2020-02-04 05:15:17 --> Language Class Initialized
ERROR - 2020-02-04 05:15:17 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:15:18 --> Config Class Initialized
INFO - 2020-02-04 05:15:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:18 --> URI Class Initialized
DEBUG - 2020-02-04 05:15:18 --> No URI present. Default controller set.
INFO - 2020-02-04 05:15:18 --> Router Class Initialized
INFO - 2020-02-04 05:15:18 --> Output Class Initialized
INFO - 2020-02-04 05:15:18 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:19 --> Input Class Initialized
INFO - 2020-02-04 05:15:19 --> Language Class Initialized
INFO - 2020-02-04 05:15:19 --> Loader Class Initialized
INFO - 2020-02-04 05:15:19 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:19 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:19 --> Controller Class Initialized
INFO - 2020-02-04 05:15:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 05:15:19 --> Pagination Class Initialized
INFO - 2020-02-04 05:15:19 --> Model "M_show" initialized
INFO - 2020-02-04 05:15:19 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:19 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 05:15:19 --> Final output sent to browser
DEBUG - 2020-02-04 05:15:19 --> Total execution time: 1.1824
INFO - 2020-02-04 05:15:21 --> Config Class Initialized
INFO - 2020-02-04 05:15:21 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:21 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:21 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:21 --> URI Class Initialized
INFO - 2020-02-04 05:15:21 --> Router Class Initialized
INFO - 2020-02-04 05:15:21 --> Output Class Initialized
INFO - 2020-02-04 05:15:22 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:22 --> Input Class Initialized
INFO - 2020-02-04 05:15:22 --> Language Class Initialized
INFO - 2020-02-04 05:15:22 --> Loader Class Initialized
INFO - 2020-02-04 05:15:22 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:22 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:22 --> Controller Class Initialized
INFO - 2020-02-04 05:15:22 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:15:22 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:22 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:15:22 --> Final output sent to browser
DEBUG - 2020-02-04 05:15:22 --> Total execution time: 0.9328
INFO - 2020-02-04 05:15:22 --> Config Class Initialized
INFO - 2020-02-04 05:15:22 --> Config Class Initialized
INFO - 2020-02-04 05:15:22 --> Config Class Initialized
INFO - 2020-02-04 05:15:22 --> Config Class Initialized
INFO - 2020-02-04 05:15:22 --> Config Class Initialized
INFO - 2020-02-04 05:15:22 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:22 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:22 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:22 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:22 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:22 --> Config Class Initialized
INFO - 2020-02-04 05:15:22 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:22 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:22 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:22 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:22 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:22 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:22 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:15:22 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:22 --> URI Class Initialized
INFO - 2020-02-04 05:15:22 --> URI Class Initialized
INFO - 2020-02-04 05:15:22 --> URI Class Initialized
INFO - 2020-02-04 05:15:22 --> URI Class Initialized
INFO - 2020-02-04 05:15:22 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:22 --> URI Class Initialized
INFO - 2020-02-04 05:15:22 --> URI Class Initialized
INFO - 2020-02-04 05:15:22 --> Router Class Initialized
INFO - 2020-02-04 05:15:22 --> Router Class Initialized
INFO - 2020-02-04 05:15:22 --> Router Class Initialized
INFO - 2020-02-04 05:15:22 --> Router Class Initialized
INFO - 2020-02-04 05:15:22 --> Router Class Initialized
INFO - 2020-02-04 05:15:22 --> Router Class Initialized
INFO - 2020-02-04 05:15:22 --> Output Class Initialized
INFO - 2020-02-04 05:15:22 --> Output Class Initialized
INFO - 2020-02-04 05:15:22 --> Output Class Initialized
INFO - 2020-02-04 05:15:22 --> Output Class Initialized
INFO - 2020-02-04 05:15:22 --> Output Class Initialized
INFO - 2020-02-04 05:15:22 --> Security Class Initialized
INFO - 2020-02-04 05:15:22 --> Security Class Initialized
INFO - 2020-02-04 05:15:22 --> Security Class Initialized
INFO - 2020-02-04 05:15:22 --> Security Class Initialized
INFO - 2020-02-04 05:15:22 --> Output Class Initialized
INFO - 2020-02-04 05:15:22 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:22 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:22 --> Input Class Initialized
INFO - 2020-02-04 05:15:22 --> Input Class Initialized
INFO - 2020-02-04 05:15:22 --> Input Class Initialized
INFO - 2020-02-04 05:15:22 --> Input Class Initialized
INFO - 2020-02-04 05:15:22 --> Input Class Initialized
DEBUG - 2020-02-04 05:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:22 --> Input Class Initialized
INFO - 2020-02-04 05:15:22 --> Language Class Initialized
INFO - 2020-02-04 05:15:22 --> Language Class Initialized
INFO - 2020-02-04 05:15:22 --> Language Class Initialized
INFO - 2020-02-04 05:15:22 --> Language Class Initialized
INFO - 2020-02-04 05:15:22 --> Language Class Initialized
INFO - 2020-02-04 05:15:22 --> Language Class Initialized
ERROR - 2020-02-04 05:15:22 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 05:15:22 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 05:15:22 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:15:22 --> Loader Class Initialized
INFO - 2020-02-04 05:15:22 --> Loader Class Initialized
ERROR - 2020-02-04 05:15:22 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:15:22 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:22 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:22 --> Config Class Initialized
INFO - 2020-02-04 05:15:22 --> Config Class Initialized
INFO - 2020-02-04 05:15:22 --> Config Class Initialized
INFO - 2020-02-04 05:15:22 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:22 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:22 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:22 --> Database Driver Class Initialized
INFO - 2020-02-04 05:15:22 --> Database Driver Class Initialized
INFO - 2020-02-04 05:15:22 --> Config Class Initialized
INFO - 2020-02-04 05:15:22 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 05:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 05:15:22 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:22 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:22 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:22 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 05:15:22 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:22 --> Controller Class Initialized
INFO - 2020-02-04 05:15:22 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:22 --> URI Class Initialized
INFO - 2020-02-04 05:15:22 --> URI Class Initialized
INFO - 2020-02-04 05:15:22 --> URI Class Initialized
INFO - 2020-02-04 05:15:23 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:15:23 --> URI Class Initialized
INFO - 2020-02-04 05:15:23 --> Router Class Initialized
INFO - 2020-02-04 05:15:23 --> Router Class Initialized
INFO - 2020-02-04 05:15:23 --> Router Class Initialized
INFO - 2020-02-04 05:15:23 --> Router Class Initialized
INFO - 2020-02-04 05:15:23 --> Output Class Initialized
INFO - 2020-02-04 05:15:23 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:23 --> Output Class Initialized
INFO - 2020-02-04 05:15:23 --> Output Class Initialized
INFO - 2020-02-04 05:15:23 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:23 --> Security Class Initialized
INFO - 2020-02-04 05:15:23 --> Security Class Initialized
INFO - 2020-02-04 05:15:23 --> Security Class Initialized
INFO - 2020-02-04 05:15:23 --> Output Class Initialized
DEBUG - 2020-02-04 05:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 05:15:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:15:23 --> Security Class Initialized
INFO - 2020-02-04 05:15:23 --> Input Class Initialized
INFO - 2020-02-04 05:15:23 --> Input Class Initialized
ERROR - 2020-02-04 05:15:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:15:23 --> Input Class Initialized
DEBUG - 2020-02-04 05:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:23 --> Input Class Initialized
INFO - 2020-02-04 05:15:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:15:23 --> Language Class Initialized
INFO - 2020-02-04 05:15:23 --> Language Class Initialized
INFO - 2020-02-04 05:15:23 --> Language Class Initialized
INFO - 2020-02-04 05:15:23 --> Final output sent to browser
INFO - 2020-02-04 05:15:23 --> Language Class Initialized
ERROR - 2020-02-04 05:15:23 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 05:15:23 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 05:15:23 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-04 05:15:23 --> Total execution time: 0.5569
ERROR - 2020-02-04 05:15:23 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:15:23 --> Config Class Initialized
INFO - 2020-02-04 05:15:23 --> Config Class Initialized
INFO - 2020-02-04 05:15:23 --> Config Class Initialized
INFO - 2020-02-04 05:15:23 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:23 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:23 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:23 --> Config Class Initialized
INFO - 2020-02-04 05:15:23 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:23 --> Controller Class Initialized
DEBUG - 2020-02-04 05:15:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:23 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:23 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:23 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:23 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:23 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:15:23 --> URI Class Initialized
DEBUG - 2020-02-04 05:15:23 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:23 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:23 --> URI Class Initialized
INFO - 2020-02-04 05:15:23 --> URI Class Initialized
INFO - 2020-02-04 05:15:23 --> Router Class Initialized
INFO - 2020-02-04 05:15:23 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:23 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:23 --> URI Class Initialized
INFO - 2020-02-04 05:15:23 --> Router Class Initialized
INFO - 2020-02-04 05:15:23 --> Output Class Initialized
INFO - 2020-02-04 05:15:23 --> Router Class Initialized
INFO - 2020-02-04 05:15:23 --> Router Class Initialized
ERROR - 2020-02-04 05:15:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 05:15:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:15:23 --> Security Class Initialized
INFO - 2020-02-04 05:15:23 --> Output Class Initialized
INFO - 2020-02-04 05:15:23 --> Output Class Initialized
INFO - 2020-02-04 05:15:23 --> Output Class Initialized
INFO - 2020-02-04 05:15:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:15:23 --> Security Class Initialized
INFO - 2020-02-04 05:15:23 --> Security Class Initialized
INFO - 2020-02-04 05:15:23 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:23 --> Final output sent to browser
INFO - 2020-02-04 05:15:23 --> Input Class Initialized
DEBUG - 2020-02-04 05:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:23 --> Input Class Initialized
INFO - 2020-02-04 05:15:23 --> Input Class Initialized
INFO - 2020-02-04 05:15:23 --> Input Class Initialized
DEBUG - 2020-02-04 05:15:23 --> Total execution time: 0.9351
INFO - 2020-02-04 05:15:23 --> Language Class Initialized
INFO - 2020-02-04 05:15:23 --> Language Class Initialized
INFO - 2020-02-04 05:15:23 --> Language Class Initialized
INFO - 2020-02-04 05:15:23 --> Language Class Initialized
ERROR - 2020-02-04 05:15:23 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-04 05:15:23 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 05:15:23 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 05:15:23 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:15:23 --> Config Class Initialized
INFO - 2020-02-04 05:15:23 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:23 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:23 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:23 --> URI Class Initialized
INFO - 2020-02-04 05:15:23 --> Router Class Initialized
INFO - 2020-02-04 05:15:23 --> Output Class Initialized
INFO - 2020-02-04 05:15:23 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:23 --> Input Class Initialized
INFO - 2020-02-04 05:15:23 --> Language Class Initialized
ERROR - 2020-02-04 05:15:23 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:15:24 --> Config Class Initialized
INFO - 2020-02-04 05:15:24 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:24 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:24 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:24 --> URI Class Initialized
INFO - 2020-02-04 05:15:24 --> Router Class Initialized
INFO - 2020-02-04 05:15:24 --> Output Class Initialized
INFO - 2020-02-04 05:15:24 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:24 --> Input Class Initialized
INFO - 2020-02-04 05:15:24 --> Language Class Initialized
ERROR - 2020-02-04 05:15:24 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:15:24 --> Config Class Initialized
INFO - 2020-02-04 05:15:24 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:24 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:24 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:24 --> URI Class Initialized
INFO - 2020-02-04 05:15:24 --> Router Class Initialized
INFO - 2020-02-04 05:15:24 --> Output Class Initialized
INFO - 2020-02-04 05:15:24 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:24 --> Input Class Initialized
INFO - 2020-02-04 05:15:24 --> Language Class Initialized
ERROR - 2020-02-04 05:15:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:15:24 --> Config Class Initialized
INFO - 2020-02-04 05:15:24 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:24 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:24 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:24 --> URI Class Initialized
INFO - 2020-02-04 05:15:24 --> Router Class Initialized
INFO - 2020-02-04 05:15:24 --> Output Class Initialized
INFO - 2020-02-04 05:15:24 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:24 --> Input Class Initialized
INFO - 2020-02-04 05:15:24 --> Language Class Initialized
ERROR - 2020-02-04 05:15:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:15:24 --> Config Class Initialized
INFO - 2020-02-04 05:15:24 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:24 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:24 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:24 --> URI Class Initialized
INFO - 2020-02-04 05:15:24 --> Config Class Initialized
INFO - 2020-02-04 05:15:24 --> Router Class Initialized
INFO - 2020-02-04 05:15:24 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:24 --> Output Class Initialized
INFO - 2020-02-04 05:15:24 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:25 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:25 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:25 --> Input Class Initialized
INFO - 2020-02-04 05:15:25 --> URI Class Initialized
INFO - 2020-02-04 05:15:25 --> Language Class Initialized
DEBUG - 2020-02-04 05:15:25 --> No URI present. Default controller set.
INFO - 2020-02-04 05:15:25 --> Router Class Initialized
ERROR - 2020-02-04 05:15:25 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:15:25 --> Output Class Initialized
INFO - 2020-02-04 05:15:25 --> Config Class Initialized
INFO - 2020-02-04 05:15:25 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:25 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:25 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:25 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:25 --> Input Class Initialized
INFO - 2020-02-04 05:15:25 --> Language Class Initialized
INFO - 2020-02-04 05:15:25 --> URI Class Initialized
INFO - 2020-02-04 05:15:25 --> Router Class Initialized
INFO - 2020-02-04 05:15:25 --> Loader Class Initialized
INFO - 2020-02-04 05:15:25 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:25 --> Output Class Initialized
INFO - 2020-02-04 05:15:25 --> Security Class Initialized
INFO - 2020-02-04 05:15:25 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:15:25 --> Input Class Initialized
INFO - 2020-02-04 05:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:25 --> Controller Class Initialized
INFO - 2020-02-04 05:15:25 --> Language Class Initialized
ERROR - 2020-02-04 05:15:25 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 05:15:25 --> Pagination Class Initialized
INFO - 2020-02-04 05:15:25 --> Config Class Initialized
INFO - 2020-02-04 05:15:25 --> Model "M_show" initialized
INFO - 2020-02-04 05:15:25 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:25 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:25 --> Form Validation Class Initialized
DEBUG - 2020-02-04 05:15:25 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:25 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 05:15:25 --> Final output sent to browser
INFO - 2020-02-04 05:15:25 --> URI Class Initialized
DEBUG - 2020-02-04 05:15:25 --> Total execution time: 0.4913
INFO - 2020-02-04 05:15:25 --> Router Class Initialized
INFO - 2020-02-04 05:15:25 --> Output Class Initialized
INFO - 2020-02-04 05:15:25 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:25 --> Input Class Initialized
INFO - 2020-02-04 05:15:25 --> Language Class Initialized
ERROR - 2020-02-04 05:15:25 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:15:27 --> Config Class Initialized
INFO - 2020-02-04 05:15:27 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:28 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:28 --> URI Class Initialized
INFO - 2020-02-04 05:15:28 --> Router Class Initialized
INFO - 2020-02-04 05:15:28 --> Output Class Initialized
INFO - 2020-02-04 05:15:28 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:28 --> Input Class Initialized
INFO - 2020-02-04 05:15:28 --> Language Class Initialized
INFO - 2020-02-04 05:15:28 --> Loader Class Initialized
INFO - 2020-02-04 05:15:28 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:28 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:28 --> Controller Class Initialized
INFO - 2020-02-04 05:15:28 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:15:28 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:28 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:15:28 --> Final output sent to browser
DEBUG - 2020-02-04 05:15:28 --> Total execution time: 0.9661
INFO - 2020-02-04 05:15:28 --> Config Class Initialized
INFO - 2020-02-04 05:15:28 --> Config Class Initialized
INFO - 2020-02-04 05:15:28 --> Config Class Initialized
INFO - 2020-02-04 05:15:28 --> Config Class Initialized
INFO - 2020-02-04 05:15:28 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:28 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:28 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:28 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:28 --> Config Class Initialized
INFO - 2020-02-04 05:15:28 --> Config Class Initialized
INFO - 2020-02-04 05:15:28 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:28 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:28 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:28 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:28 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:28 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:29 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:29 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
ERROR - 2020-02-04 05:15:29 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 05:15:29 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 05:15:29 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 05:15:29 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
ERROR - 2020-02-04 05:15:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 05:15:29 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:15:29 --> Config Class Initialized
INFO - 2020-02-04 05:15:29 --> Config Class Initialized
INFO - 2020-02-04 05:15:29 --> Config Class Initialized
INFO - 2020-02-04 05:15:29 --> Config Class Initialized
INFO - 2020-02-04 05:15:29 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:29 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:29 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:29 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:29 --> Config Class Initialized
INFO - 2020-02-04 05:15:29 --> Config Class Initialized
INFO - 2020-02-04 05:15:29 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:29 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:29 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:29 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:29 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:29 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:29 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:15:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:29 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:29 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:29 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
ERROR - 2020-02-04 05:15:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:15:29 --> Loader Class Initialized
ERROR - 2020-02-04 05:15:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:15:29 --> Loader Class Initialized
ERROR - 2020-02-04 05:15:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:15:29 --> Helper loaded: url_helper
ERROR - 2020-02-04 05:15:29 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:15:29 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:29 --> Config Class Initialized
INFO - 2020-02-04 05:15:29 --> Config Class Initialized
INFO - 2020-02-04 05:15:29 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:29 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:29 --> Database Driver Class Initialized
INFO - 2020-02-04 05:15:29 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:15:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 05:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:15:29 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:29 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:29 --> Controller Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
INFO - 2020-02-04 05:15:29 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:29 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 05:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
ERROR - 2020-02-04 05:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:15:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
INFO - 2020-02-04 05:15:29 --> Language Class Initialized
INFO - 2020-02-04 05:15:29 --> Final output sent to browser
ERROR - 2020-02-04 05:15:29 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 05:15:29 --> 404 Page Not Found: Bower_components/jquery-i18next
DEBUG - 2020-02-04 05:15:29 --> Total execution time: 0.5451
INFO - 2020-02-04 05:15:29 --> Config Class Initialized
INFO - 2020-02-04 05:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:29 --> Controller Class Initialized
INFO - 2020-02-04 05:15:29 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:29 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 05:15:29 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:29 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:29 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:29 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:29 --> URI Class Initialized
INFO - 2020-02-04 05:15:29 --> Router Class Initialized
ERROR - 2020-02-04 05:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 05:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:15:29 --> Output Class Initialized
INFO - 2020-02-04 05:15:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:15:29 --> Security Class Initialized
INFO - 2020-02-04 05:15:29 --> Final output sent to browser
DEBUG - 2020-02-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:29 --> Input Class Initialized
DEBUG - 2020-02-04 05:15:29 --> Total execution time: 0.7451
INFO - 2020-02-04 05:15:30 --> Language Class Initialized
ERROR - 2020-02-04 05:15:30 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:15:30 --> Config Class Initialized
INFO - 2020-02-04 05:15:30 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:30 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:30 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:30 --> URI Class Initialized
INFO - 2020-02-04 05:15:30 --> Router Class Initialized
INFO - 2020-02-04 05:15:30 --> Output Class Initialized
INFO - 2020-02-04 05:15:30 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:30 --> Input Class Initialized
INFO - 2020-02-04 05:15:30 --> Language Class Initialized
ERROR - 2020-02-04 05:15:30 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:15:30 --> Config Class Initialized
INFO - 2020-02-04 05:15:30 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:30 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:30 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:30 --> URI Class Initialized
INFO - 2020-02-04 05:15:30 --> Router Class Initialized
INFO - 2020-02-04 05:15:30 --> Output Class Initialized
INFO - 2020-02-04 05:15:30 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:30 --> Input Class Initialized
INFO - 2020-02-04 05:15:30 --> Language Class Initialized
ERROR - 2020-02-04 05:15:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:15:30 --> Config Class Initialized
INFO - 2020-02-04 05:15:30 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:30 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:30 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:30 --> URI Class Initialized
INFO - 2020-02-04 05:15:30 --> Router Class Initialized
INFO - 2020-02-04 05:15:30 --> Output Class Initialized
INFO - 2020-02-04 05:15:30 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:30 --> Input Class Initialized
INFO - 2020-02-04 05:15:30 --> Language Class Initialized
ERROR - 2020-02-04 05:15:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:15:30 --> Config Class Initialized
INFO - 2020-02-04 05:15:30 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:30 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:30 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:30 --> URI Class Initialized
INFO - 2020-02-04 05:15:31 --> Router Class Initialized
INFO - 2020-02-04 05:15:31 --> Output Class Initialized
INFO - 2020-02-04 05:15:31 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:31 --> Input Class Initialized
INFO - 2020-02-04 05:15:31 --> Language Class Initialized
ERROR - 2020-02-04 05:15:31 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:15:31 --> Config Class Initialized
INFO - 2020-02-04 05:15:31 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:31 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:31 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:31 --> URI Class Initialized
INFO - 2020-02-04 05:15:31 --> Router Class Initialized
INFO - 2020-02-04 05:15:31 --> Output Class Initialized
INFO - 2020-02-04 05:15:31 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:31 --> Input Class Initialized
INFO - 2020-02-04 05:15:31 --> Language Class Initialized
ERROR - 2020-02-04 05:15:31 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:15:31 --> Config Class Initialized
INFO - 2020-02-04 05:15:31 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:31 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:31 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:31 --> URI Class Initialized
INFO - 2020-02-04 05:15:31 --> Router Class Initialized
INFO - 2020-02-04 05:15:31 --> Output Class Initialized
INFO - 2020-02-04 05:15:31 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:31 --> Input Class Initialized
INFO - 2020-02-04 05:15:31 --> Language Class Initialized
ERROR - 2020-02-04 05:15:31 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:15:31 --> Config Class Initialized
INFO - 2020-02-04 05:15:31 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:31 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:31 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:31 --> URI Class Initialized
INFO - 2020-02-04 05:15:31 --> Router Class Initialized
INFO - 2020-02-04 05:15:31 --> Output Class Initialized
INFO - 2020-02-04 05:15:31 --> Config Class Initialized
INFO - 2020-02-04 05:15:31 --> Hooks Class Initialized
INFO - 2020-02-04 05:15:31 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:15:31 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:31 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:31 --> Input Class Initialized
INFO - 2020-02-04 05:15:31 --> Language Class Initialized
INFO - 2020-02-04 05:15:31 --> URI Class Initialized
ERROR - 2020-02-04 05:15:31 --> 404 Page Not Found: Bower_components/jquery-i18next
DEBUG - 2020-02-04 05:15:31 --> No URI present. Default controller set.
INFO - 2020-02-04 05:15:31 --> Router Class Initialized
INFO - 2020-02-04 05:15:31 --> Output Class Initialized
INFO - 2020-02-04 05:15:32 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:32 --> Input Class Initialized
INFO - 2020-02-04 05:15:32 --> Language Class Initialized
INFO - 2020-02-04 05:15:32 --> Loader Class Initialized
INFO - 2020-02-04 05:15:32 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:32 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:32 --> Controller Class Initialized
INFO - 2020-02-04 05:15:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 05:15:32 --> Pagination Class Initialized
INFO - 2020-02-04 05:15:32 --> Model "M_show" initialized
INFO - 2020-02-04 05:15:32 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:32 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 05:15:32 --> Final output sent to browser
DEBUG - 2020-02-04 05:15:32 --> Total execution time: 0.5767
INFO - 2020-02-04 05:15:41 --> Config Class Initialized
INFO - 2020-02-04 05:15:46 --> Config Class Initialized
INFO - 2020-02-04 05:15:46 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:46 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:46 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:46 --> URI Class Initialized
INFO - 2020-02-04 05:15:46 --> Router Class Initialized
INFO - 2020-02-04 05:15:46 --> Output Class Initialized
INFO - 2020-02-04 05:15:46 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:46 --> Input Class Initialized
INFO - 2020-02-04 05:15:46 --> Language Class Initialized
INFO - 2020-02-04 05:15:46 --> Loader Class Initialized
INFO - 2020-02-04 05:15:46 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:46 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:47 --> Controller Class Initialized
INFO - 2020-02-04 05:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 05:15:47 --> Pagination Class Initialized
INFO - 2020-02-04 05:15:47 --> Model "M_show" initialized
INFO - 2020-02-04 05:15:47 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:47 --> Form Validation Class Initialized
ERROR - 2020-02-04 05:15:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\roadshow\application\models\M_show.php 115
ERROR - 2020-02-04 05:15:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\roadshow\application\models\M_show.php 116
INFO - 2020-02-04 05:15:47 --> Config Class Initialized
INFO - 2020-02-04 05:15:47 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:47 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:47 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:47 --> URI Class Initialized
INFO - 2020-02-04 05:15:47 --> Router Class Initialized
INFO - 2020-02-04 05:15:47 --> Output Class Initialized
INFO - 2020-02-04 05:15:47 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:47 --> Input Class Initialized
INFO - 2020-02-04 05:15:47 --> Language Class Initialized
ERROR - 2020-02-04 05:15:47 --> 404 Page Not Found: Show/show_list
INFO - 2020-02-04 05:15:58 --> Config Class Initialized
INFO - 2020-02-04 05:15:58 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:15:58 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:15:58 --> Utf8 Class Initialized
INFO - 2020-02-04 05:15:58 --> URI Class Initialized
DEBUG - 2020-02-04 05:15:58 --> No URI present. Default controller set.
INFO - 2020-02-04 05:15:58 --> Router Class Initialized
INFO - 2020-02-04 05:15:58 --> Output Class Initialized
INFO - 2020-02-04 05:15:58 --> Security Class Initialized
DEBUG - 2020-02-04 05:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:15:58 --> Input Class Initialized
INFO - 2020-02-04 05:15:58 --> Language Class Initialized
INFO - 2020-02-04 05:15:58 --> Loader Class Initialized
INFO - 2020-02-04 05:15:58 --> Helper loaded: url_helper
INFO - 2020-02-04 05:15:58 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:15:58 --> Controller Class Initialized
INFO - 2020-02-04 05:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 05:15:58 --> Pagination Class Initialized
INFO - 2020-02-04 05:15:58 --> Model "M_show" initialized
INFO - 2020-02-04 05:15:58 --> Helper loaded: form_helper
INFO - 2020-02-04 05:15:58 --> Form Validation Class Initialized
INFO - 2020-02-04 05:15:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 05:15:58 --> Final output sent to browser
DEBUG - 2020-02-04 05:15:58 --> Total execution time: 0.5281
INFO - 2020-02-04 05:16:01 --> Config Class Initialized
INFO - 2020-02-04 05:16:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:16:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:02 --> URI Class Initialized
INFO - 2020-02-04 05:16:02 --> Router Class Initialized
INFO - 2020-02-04 05:16:02 --> Output Class Initialized
INFO - 2020-02-04 05:16:02 --> Security Class Initialized
DEBUG - 2020-02-04 05:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:02 --> Input Class Initialized
INFO - 2020-02-04 05:16:02 --> Language Class Initialized
INFO - 2020-02-04 05:16:02 --> Loader Class Initialized
INFO - 2020-02-04 05:16:02 --> Helper loaded: url_helper
INFO - 2020-02-04 05:16:02 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:16:02 --> Controller Class Initialized
INFO - 2020-02-04 05:16:02 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:16:02 --> Helper loaded: form_helper
INFO - 2020-02-04 05:16:02 --> Form Validation Class Initialized
INFO - 2020-02-04 05:16:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:16:02 --> Final output sent to browser
INFO - 2020-02-04 05:16:02 --> Config Class Initialized
INFO - 2020-02-04 05:16:02 --> Config Class Initialized
INFO - 2020-02-04 05:16:02 --> Config Class Initialized
INFO - 2020-02-04 05:16:02 --> Config Class Initialized
INFO - 2020-02-04 05:16:02 --> Hooks Class Initialized
INFO - 2020-02-04 05:16:02 --> Hooks Class Initialized
INFO - 2020-02-04 05:16:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:16:02 --> Total execution time: 0.9163
INFO - 2020-02-04 05:16:02 --> Config Class Initialized
INFO - 2020-02-04 05:16:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:16:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:16:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:16:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:16:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:02 --> Config Class Initialized
INFO - 2020-02-04 05:16:02 --> Hooks Class Initialized
INFO - 2020-02-04 05:16:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:02 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:16:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:02 --> URI Class Initialized
INFO - 2020-02-04 05:16:02 --> URI Class Initialized
INFO - 2020-02-04 05:16:02 --> URI Class Initialized
DEBUG - 2020-02-04 05:16:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:02 --> URI Class Initialized
INFO - 2020-02-04 05:16:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
INFO - 2020-02-04 05:16:03 --> URI Class Initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
INFO - 2020-02-04 05:16:03 --> URI Class Initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
ERROR - 2020-02-04 05:16:03 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 05:16:03 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 05:16:03 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 05:16:03 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
ERROR - 2020-02-04 05:16:03 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:16:03 --> Config Class Initialized
INFO - 2020-02-04 05:16:03 --> Config Class Initialized
INFO - 2020-02-04 05:16:03 --> Config Class Initialized
INFO - 2020-02-04 05:16:03 --> Config Class Initialized
INFO - 2020-02-04 05:16:03 --> Hooks Class Initialized
INFO - 2020-02-04 05:16:03 --> Hooks Class Initialized
INFO - 2020-02-04 05:16:03 --> Hooks Class Initialized
INFO - 2020-02-04 05:16:03 --> Hooks Class Initialized
ERROR - 2020-02-04 05:16:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:16:03 --> Config Class Initialized
INFO - 2020-02-04 05:16:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:16:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:16:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:16:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:03 --> Config Class Initialized
DEBUG - 2020-02-04 05:16:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:16:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:03 --> URI Class Initialized
INFO - 2020-02-04 05:16:03 --> URI Class Initialized
INFO - 2020-02-04 05:16:03 --> URI Class Initialized
INFO - 2020-02-04 05:16:03 --> URI Class Initialized
DEBUG - 2020-02-04 05:16:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:03 --> URI Class Initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
INFO - 2020-02-04 05:16:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
INFO - 2020-02-04 05:16:03 --> URI Class Initialized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
ERROR - 2020-02-04 05:16:03 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-04 05:16:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:16:03 --> Loader Class Initialized
INFO - 2020-02-04 05:16:03 --> Loader Class Initialized
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
INFO - 2020-02-04 05:16:03 --> Helper loaded: url_helper
INFO - 2020-02-04 05:16:03 --> Helper loaded: url_helper
ERROR - 2020-02-04 05:16:03 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:16:03 --> Config Class Initialized
INFO - 2020-02-04 05:16:03 --> Config Class Initialized
INFO - 2020-02-04 05:16:03 --> Hooks Class Initialized
INFO - 2020-02-04 05:16:03 --> Hooks Class Initialized
ERROR - 2020-02-04 05:16:03 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:16:03 --> Database Driver Class Initialized
INFO - 2020-02-04 05:16:03 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:16:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:16:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 05:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:16:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:16:03 --> Controller Class Initialized
INFO - 2020-02-04 05:16:03 --> URI Class Initialized
INFO - 2020-02-04 05:16:03 --> URI Class Initialized
INFO - 2020-02-04 05:16:03 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
INFO - 2020-02-04 05:16:03 --> Router Class Initialized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
INFO - 2020-02-04 05:16:03 --> Output Class Initialized
INFO - 2020-02-04 05:16:03 --> Helper loaded: form_helper
INFO - 2020-02-04 05:16:03 --> Form Validation Class Initialized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
INFO - 2020-02-04 05:16:03 --> Security Class Initialized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:16:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 05:16:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
ERROR - 2020-02-04 05:16:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:16:03 --> Input Class Initialized
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
INFO - 2020-02-04 05:16:03 --> Language Class Initialized
INFO - 2020-02-04 05:16:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:16:03 --> Final output sent to browser
ERROR - 2020-02-04 05:16:03 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 05:16:03 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-04 05:16:04 --> Total execution time: 0.7615
INFO - 2020-02-04 05:16:04 --> Config Class Initialized
INFO - 2020-02-04 05:16:04 --> Hooks Class Initialized
INFO - 2020-02-04 05:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:16:04 --> Controller Class Initialized
DEBUG - 2020-02-04 05:16:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:04 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:16:04 --> URI Class Initialized
INFO - 2020-02-04 05:16:04 --> Helper loaded: form_helper
INFO - 2020-02-04 05:16:04 --> Form Validation Class Initialized
INFO - 2020-02-04 05:16:04 --> Router Class Initialized
INFO - 2020-02-04 05:16:04 --> Output Class Initialized
ERROR - 2020-02-04 05:16:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 05:16:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:16:04 --> Security Class Initialized
INFO - 2020-02-04 05:16:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-04 05:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:04 --> Input Class Initialized
INFO - 2020-02-04 05:16:04 --> Final output sent to browser
DEBUG - 2020-02-04 05:16:04 --> Total execution time: 1.1052
INFO - 2020-02-04 05:16:04 --> Language Class Initialized
ERROR - 2020-02-04 05:16:04 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:16:04 --> Config Class Initialized
INFO - 2020-02-04 05:16:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:16:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:04 --> URI Class Initialized
INFO - 2020-02-04 05:16:04 --> Router Class Initialized
INFO - 2020-02-04 05:16:04 --> Output Class Initialized
INFO - 2020-02-04 05:16:04 --> Security Class Initialized
DEBUG - 2020-02-04 05:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:04 --> Input Class Initialized
INFO - 2020-02-04 05:16:04 --> Language Class Initialized
ERROR - 2020-02-04 05:16:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:16:04 --> Config Class Initialized
INFO - 2020-02-04 05:16:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:16:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:04 --> URI Class Initialized
INFO - 2020-02-04 05:16:04 --> Router Class Initialized
INFO - 2020-02-04 05:16:04 --> Output Class Initialized
INFO - 2020-02-04 05:16:04 --> Security Class Initialized
DEBUG - 2020-02-04 05:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:04 --> Input Class Initialized
INFO - 2020-02-04 05:16:04 --> Language Class Initialized
ERROR - 2020-02-04 05:16:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:16:04 --> Config Class Initialized
INFO - 2020-02-04 05:16:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:16:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:05 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:05 --> URI Class Initialized
INFO - 2020-02-04 05:16:05 --> Router Class Initialized
INFO - 2020-02-04 05:16:05 --> Output Class Initialized
INFO - 2020-02-04 05:16:05 --> Security Class Initialized
DEBUG - 2020-02-04 05:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:05 --> Input Class Initialized
INFO - 2020-02-04 05:16:05 --> Language Class Initialized
ERROR - 2020-02-04 05:16:05 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:16:05 --> Config Class Initialized
INFO - 2020-02-04 05:16:05 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:16:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:05 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:05 --> URI Class Initialized
INFO - 2020-02-04 05:16:05 --> Router Class Initialized
INFO - 2020-02-04 05:16:05 --> Output Class Initialized
INFO - 2020-02-04 05:16:05 --> Security Class Initialized
DEBUG - 2020-02-04 05:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:05 --> Input Class Initialized
INFO - 2020-02-04 05:16:05 --> Language Class Initialized
ERROR - 2020-02-04 05:16:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:16:05 --> Config Class Initialized
INFO - 2020-02-04 05:16:05 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:16:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:05 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:05 --> URI Class Initialized
INFO - 2020-02-04 05:16:05 --> Router Class Initialized
INFO - 2020-02-04 05:16:05 --> Output Class Initialized
INFO - 2020-02-04 05:16:05 --> Security Class Initialized
DEBUG - 2020-02-04 05:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:05 --> Input Class Initialized
INFO - 2020-02-04 05:16:05 --> Language Class Initialized
ERROR - 2020-02-04 05:16:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:16:05 --> Config Class Initialized
INFO - 2020-02-04 05:16:05 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:16:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:16:05 --> Utf8 Class Initialized
INFO - 2020-02-04 05:16:05 --> URI Class Initialized
INFO - 2020-02-04 05:16:05 --> Router Class Initialized
INFO - 2020-02-04 05:16:05 --> Output Class Initialized
INFO - 2020-02-04 05:16:05 --> Security Class Initialized
DEBUG - 2020-02-04 05:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:16:06 --> Input Class Initialized
INFO - 2020-02-04 05:16:06 --> Language Class Initialized
ERROR - 2020-02-04 05:16:06 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:20:00 --> Config Class Initialized
INFO - 2020-02-04 05:20:00 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:00 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:00 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:00 --> URI Class Initialized
INFO - 2020-02-04 05:20:00 --> Router Class Initialized
INFO - 2020-02-04 05:20:00 --> Output Class Initialized
INFO - 2020-02-04 05:20:00 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:00 --> Input Class Initialized
INFO - 2020-02-04 05:20:00 --> Language Class Initialized
INFO - 2020-02-04 05:20:00 --> Loader Class Initialized
INFO - 2020-02-04 05:20:00 --> Helper loaded: url_helper
INFO - 2020-02-04 05:20:00 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:20:00 --> Controller Class Initialized
INFO - 2020-02-04 05:20:01 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:20:01 --> Helper loaded: form_helper
INFO - 2020-02-04 05:20:01 --> Form Validation Class Initialized
INFO - 2020-02-04 05:20:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:20:01 --> Final output sent to browser
DEBUG - 2020-02-04 05:20:01 --> Total execution time: 0.5843
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
INFO - 2020-02-04 05:20:01 --> Output Class Initialized
INFO - 2020-02-04 05:20:01 --> Output Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
INFO - 2020-02-04 05:20:01 --> Output Class Initialized
INFO - 2020-02-04 05:20:01 --> Security Class Initialized
INFO - 2020-02-04 05:20:01 --> Output Class Initialized
INFO - 2020-02-04 05:20:01 --> Output Class Initialized
INFO - 2020-02-04 05:20:01 --> Security Class Initialized
INFO - 2020-02-04 05:20:01 --> Output Class Initialized
INFO - 2020-02-04 05:20:01 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:01 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:01 --> Security Class Initialized
INFO - 2020-02-04 05:20:01 --> Security Class Initialized
INFO - 2020-02-04 05:20:01 --> Input Class Initialized
INFO - 2020-02-04 05:20:01 --> Input Class Initialized
INFO - 2020-02-04 05:20:01 --> Input Class Initialized
DEBUG - 2020-02-04 05:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:01 --> Input Class Initialized
INFO - 2020-02-04 05:20:01 --> Input Class Initialized
INFO - 2020-02-04 05:20:01 --> Input Class Initialized
INFO - 2020-02-04 05:20:01 --> Language Class Initialized
INFO - 2020-02-04 05:20:01 --> Language Class Initialized
INFO - 2020-02-04 05:20:01 --> Language Class Initialized
INFO - 2020-02-04 05:20:01 --> Language Class Initialized
INFO - 2020-02-04 05:20:01 --> Language Class Initialized
INFO - 2020-02-04 05:20:01 --> Language Class Initialized
ERROR - 2020-02-04 05:20:01 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 05:20:01 --> Loader Class Initialized
INFO - 2020-02-04 05:20:01 --> Loader Class Initialized
ERROR - 2020-02-04 05:20:01 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:20:01 --> Helper loaded: url_helper
INFO - 2020-02-04 05:20:01 --> Helper loaded: url_helper
ERROR - 2020-02-04 05:20:01 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 05:20:01 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Database Driver Class Initialized
INFO - 2020-02-04 05:20:01 --> Database Driver Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 05:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:20:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:01 --> Controller Class Initialized
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
INFO - 2020-02-04 05:20:01 --> Output Class Initialized
INFO - 2020-02-04 05:20:01 --> Helper loaded: form_helper
INFO - 2020-02-04 05:20:01 --> Form Validation Class Initialized
INFO - 2020-02-04 05:20:01 --> Output Class Initialized
INFO - 2020-02-04 05:20:01 --> Output Class Initialized
INFO - 2020-02-04 05:20:01 --> Output Class Initialized
INFO - 2020-02-04 05:20:01 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:01 --> Security Class Initialized
INFO - 2020-02-04 05:20:01 --> Security Class Initialized
INFO - 2020-02-04 05:20:01 --> Security Class Initialized
ERROR - 2020-02-04 05:20:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:20:01 --> Input Class Initialized
ERROR - 2020-02-04 05:20:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-04 05:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:01 --> Input Class Initialized
INFO - 2020-02-04 05:20:01 --> Input Class Initialized
INFO - 2020-02-04 05:20:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:20:01 --> Input Class Initialized
INFO - 2020-02-04 05:20:01 --> Language Class Initialized
INFO - 2020-02-04 05:20:01 --> Final output sent to browser
INFO - 2020-02-04 05:20:01 --> Language Class Initialized
INFO - 2020-02-04 05:20:01 --> Language Class Initialized
ERROR - 2020-02-04 05:20:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:20:01 --> Language Class Initialized
DEBUG - 2020-02-04 05:20:01 --> Total execution time: 0.6039
ERROR - 2020-02-04 05:20:01 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-04 05:20:01 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 05:20:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Config Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:01 --> Controller Class Initialized
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:01 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:01 --> Helper loaded: form_helper
INFO - 2020-02-04 05:20:01 --> Form Validation Class Initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> URI Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
INFO - 2020-02-04 05:20:01 --> Router Class Initialized
ERROR - 2020-02-04 05:20:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:20:01 --> Output Class Initialized
ERROR - 2020-02-04 05:20:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:20:02 --> Output Class Initialized
INFO - 2020-02-04 05:20:02 --> Output Class Initialized
INFO - 2020-02-04 05:20:02 --> Security Class Initialized
INFO - 2020-02-04 05:20:02 --> Output Class Initialized
INFO - 2020-02-04 05:20:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:20:02 --> Security Class Initialized
INFO - 2020-02-04 05:20:02 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:02 --> Security Class Initialized
INFO - 2020-02-04 05:20:02 --> Input Class Initialized
INFO - 2020-02-04 05:20:02 --> Final output sent to browser
DEBUG - 2020-02-04 05:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:02 --> Input Class Initialized
DEBUG - 2020-02-04 05:20:02 --> Total execution time: 0.8737
INFO - 2020-02-04 05:20:02 --> Input Class Initialized
INFO - 2020-02-04 05:20:02 --> Input Class Initialized
INFO - 2020-02-04 05:20:02 --> Language Class Initialized
INFO - 2020-02-04 05:20:02 --> Language Class Initialized
ERROR - 2020-02-04 05:20:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:20:02 --> Language Class Initialized
INFO - 2020-02-04 05:20:02 --> Language Class Initialized
ERROR - 2020-02-04 05:20:02 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 05:20:02 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 05:20:02 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:20:02 --> Config Class Initialized
INFO - 2020-02-04 05:20:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:02 --> URI Class Initialized
INFO - 2020-02-04 05:20:02 --> Router Class Initialized
INFO - 2020-02-04 05:20:02 --> Output Class Initialized
INFO - 2020-02-04 05:20:02 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:02 --> Input Class Initialized
INFO - 2020-02-04 05:20:02 --> Language Class Initialized
ERROR - 2020-02-04 05:20:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:20:02 --> Config Class Initialized
INFO - 2020-02-04 05:20:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:02 --> URI Class Initialized
INFO - 2020-02-04 05:20:02 --> Router Class Initialized
INFO - 2020-02-04 05:20:02 --> Output Class Initialized
INFO - 2020-02-04 05:20:02 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:02 --> Input Class Initialized
INFO - 2020-02-04 05:20:02 --> Language Class Initialized
ERROR - 2020-02-04 05:20:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:20:02 --> Config Class Initialized
INFO - 2020-02-04 05:20:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:02 --> URI Class Initialized
INFO - 2020-02-04 05:20:02 --> Router Class Initialized
INFO - 2020-02-04 05:20:02 --> Output Class Initialized
INFO - 2020-02-04 05:20:02 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:02 --> Input Class Initialized
INFO - 2020-02-04 05:20:02 --> Language Class Initialized
ERROR - 2020-02-04 05:20:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:20:03 --> Config Class Initialized
INFO - 2020-02-04 05:20:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:03 --> URI Class Initialized
INFO - 2020-02-04 05:20:03 --> Router Class Initialized
INFO - 2020-02-04 05:20:03 --> Output Class Initialized
INFO - 2020-02-04 05:20:03 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:03 --> Input Class Initialized
INFO - 2020-02-04 05:20:03 --> Language Class Initialized
ERROR - 2020-02-04 05:20:03 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:20:03 --> Config Class Initialized
INFO - 2020-02-04 05:20:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:03 --> URI Class Initialized
INFO - 2020-02-04 05:20:03 --> Router Class Initialized
INFO - 2020-02-04 05:20:03 --> Output Class Initialized
INFO - 2020-02-04 05:20:03 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:03 --> Input Class Initialized
INFO - 2020-02-04 05:20:03 --> Language Class Initialized
ERROR - 2020-02-04 05:20:03 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:20:03 --> Config Class Initialized
INFO - 2020-02-04 05:20:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:03 --> URI Class Initialized
INFO - 2020-02-04 05:20:03 --> Router Class Initialized
INFO - 2020-02-04 05:20:03 --> Output Class Initialized
INFO - 2020-02-04 05:20:03 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:03 --> Input Class Initialized
INFO - 2020-02-04 05:20:03 --> Language Class Initialized
ERROR - 2020-02-04 05:20:03 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:20:03 --> Config Class Initialized
INFO - 2020-02-04 05:20:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:03 --> URI Class Initialized
INFO - 2020-02-04 05:20:04 --> Router Class Initialized
INFO - 2020-02-04 05:20:04 --> Output Class Initialized
INFO - 2020-02-04 05:20:04 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:04 --> Input Class Initialized
INFO - 2020-02-04 05:20:04 --> Language Class Initialized
ERROR - 2020-02-04 05:20:04 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:20:16 --> Config Class Initialized
INFO - 2020-02-04 05:20:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:16 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:17 --> URI Class Initialized
INFO - 2020-02-04 05:20:17 --> Router Class Initialized
INFO - 2020-02-04 05:20:17 --> Output Class Initialized
INFO - 2020-02-04 05:20:17 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:17 --> Input Class Initialized
INFO - 2020-02-04 05:20:17 --> Language Class Initialized
INFO - 2020-02-04 05:20:17 --> Loader Class Initialized
INFO - 2020-02-04 05:20:17 --> Helper loaded: url_helper
INFO - 2020-02-04 05:20:17 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:20:17 --> Controller Class Initialized
INFO - 2020-02-04 05:20:17 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:20:17 --> Helper loaded: form_helper
INFO - 2020-02-04 05:20:17 --> Form Validation Class Initialized
INFO - 2020-02-04 05:20:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:20:17 --> Final output sent to browser
DEBUG - 2020-02-04 05:20:17 --> Total execution time: 1.1385
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
ERROR - 2020-02-04 05:20:18 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 05:20:18 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 05:20:18 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 05:20:18 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 05:20:18 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 05:20:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
INFO - 2020-02-04 05:20:18 --> Loader Class Initialized
INFO - 2020-02-04 05:20:18 --> Helper loaded: url_helper
ERROR - 2020-02-04 05:20:18 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 05:20:18 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 05:20:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-04 05:20:18 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:20:18 --> Loader Class Initialized
INFO - 2020-02-04 05:20:18 --> Helper loaded: url_helper
INFO - 2020-02-04 05:20:18 --> Database Driver Class Initialized
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Config Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:20:18 --> Database Driver Class Initialized
INFO - 2020-02-04 05:20:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:20:18 --> Controller Class Initialized
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:20:18 --> URI Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> Router Class Initialized
INFO - 2020-02-04 05:20:18 --> Helper loaded: form_helper
INFO - 2020-02-04 05:20:18 --> Form Validation Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
INFO - 2020-02-04 05:20:18 --> Output Class Initialized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
INFO - 2020-02-04 05:20:18 --> Security Class Initialized
ERROR - 2020-02-04 05:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 05:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
INFO - 2020-02-04 05:20:18 --> Input Class Initialized
INFO - 2020-02-04 05:20:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:20:18 --> Final output sent to browser
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
INFO - 2020-02-04 05:20:18 --> Language Class Initialized
DEBUG - 2020-02-04 05:20:18 --> Total execution time: 0.6140
ERROR - 2020-02-04 05:20:19 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 05:20:19 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:20:19 --> Config Class Initialized
INFO - 2020-02-04 05:20:19 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:19 --> Controller Class Initialized
INFO - 2020-02-04 05:20:19 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 05:20:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:19 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:19 --> Helper loaded: form_helper
INFO - 2020-02-04 05:20:19 --> Form Validation Class Initialized
INFO - 2020-02-04 05:20:19 --> URI Class Initialized
INFO - 2020-02-04 05:20:19 --> Router Class Initialized
ERROR - 2020-02-04 05:20:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 05:20:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:20:19 --> Output Class Initialized
INFO - 2020-02-04 05:20:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:20:19 --> Security Class Initialized
INFO - 2020-02-04 05:20:19 --> Final output sent to browser
DEBUG - 2020-02-04 05:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:19 --> Input Class Initialized
DEBUG - 2020-02-04 05:20:19 --> Total execution time: 0.7886
INFO - 2020-02-04 05:20:19 --> Language Class Initialized
ERROR - 2020-02-04 05:20:19 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:20:19 --> Config Class Initialized
INFO - 2020-02-04 05:20:19 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:19 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:19 --> URI Class Initialized
INFO - 2020-02-04 05:20:19 --> Router Class Initialized
INFO - 2020-02-04 05:20:19 --> Output Class Initialized
INFO - 2020-02-04 05:20:19 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:19 --> Input Class Initialized
INFO - 2020-02-04 05:20:19 --> Language Class Initialized
ERROR - 2020-02-04 05:20:19 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:20:19 --> Config Class Initialized
INFO - 2020-02-04 05:20:19 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:19 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:19 --> URI Class Initialized
INFO - 2020-02-04 05:20:19 --> Router Class Initialized
INFO - 2020-02-04 05:20:19 --> Output Class Initialized
INFO - 2020-02-04 05:20:19 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:19 --> Input Class Initialized
INFO - 2020-02-04 05:20:19 --> Language Class Initialized
ERROR - 2020-02-04 05:20:19 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:20:19 --> Config Class Initialized
INFO - 2020-02-04 05:20:19 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:20 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:20 --> URI Class Initialized
INFO - 2020-02-04 05:20:20 --> Router Class Initialized
INFO - 2020-02-04 05:20:20 --> Output Class Initialized
INFO - 2020-02-04 05:20:20 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:20 --> Input Class Initialized
INFO - 2020-02-04 05:20:20 --> Language Class Initialized
ERROR - 2020-02-04 05:20:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:20:20 --> Config Class Initialized
INFO - 2020-02-04 05:20:20 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:20 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:20 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:20 --> URI Class Initialized
INFO - 2020-02-04 05:20:20 --> Router Class Initialized
INFO - 2020-02-04 05:20:20 --> Output Class Initialized
INFO - 2020-02-04 05:20:20 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:20 --> Input Class Initialized
INFO - 2020-02-04 05:20:20 --> Language Class Initialized
ERROR - 2020-02-04 05:20:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:20:20 --> Config Class Initialized
INFO - 2020-02-04 05:20:20 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:20 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:20 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:20 --> URI Class Initialized
INFO - 2020-02-04 05:20:20 --> Router Class Initialized
INFO - 2020-02-04 05:20:20 --> Output Class Initialized
INFO - 2020-02-04 05:20:20 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:20 --> Input Class Initialized
INFO - 2020-02-04 05:20:20 --> Language Class Initialized
ERROR - 2020-02-04 05:20:20 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:20:20 --> Config Class Initialized
INFO - 2020-02-04 05:20:20 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:20 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:20 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:20 --> URI Class Initialized
INFO - 2020-02-04 05:20:20 --> Router Class Initialized
INFO - 2020-02-04 05:20:20 --> Output Class Initialized
INFO - 2020-02-04 05:20:21 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:21 --> Input Class Initialized
INFO - 2020-02-04 05:20:21 --> Language Class Initialized
ERROR - 2020-02-04 05:20:21 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:20:21 --> Config Class Initialized
INFO - 2020-02-04 05:20:21 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:21 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:21 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:21 --> URI Class Initialized
INFO - 2020-02-04 05:20:21 --> Router Class Initialized
INFO - 2020-02-04 05:20:21 --> Output Class Initialized
INFO - 2020-02-04 05:20:21 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:21 --> Input Class Initialized
INFO - 2020-02-04 05:20:21 --> Language Class Initialized
ERROR - 2020-02-04 05:20:21 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:20:21 --> Config Class Initialized
INFO - 2020-02-04 05:20:21 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:21 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:21 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:21 --> URI Class Initialized
INFO - 2020-02-04 05:20:21 --> Router Class Initialized
INFO - 2020-02-04 05:20:21 --> Output Class Initialized
INFO - 2020-02-04 05:20:21 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:21 --> Input Class Initialized
INFO - 2020-02-04 05:20:21 --> Language Class Initialized
ERROR - 2020-02-04 05:20:21 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:20:37 --> Config Class Initialized
INFO - 2020-02-04 05:20:37 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:37 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:37 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:37 --> URI Class Initialized
INFO - 2020-02-04 05:20:38 --> Router Class Initialized
INFO - 2020-02-04 05:20:38 --> Output Class Initialized
INFO - 2020-02-04 05:20:38 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:38 --> Input Class Initialized
INFO - 2020-02-04 05:20:38 --> Language Class Initialized
INFO - 2020-02-04 05:20:38 --> Loader Class Initialized
INFO - 2020-02-04 05:20:38 --> Helper loaded: url_helper
INFO - 2020-02-04 05:20:38 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:20:38 --> Controller Class Initialized
INFO - 2020-02-04 05:20:38 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:20:38 --> Helper loaded: form_helper
INFO - 2020-02-04 05:20:38 --> Form Validation Class Initialized
INFO - 2020-02-04 05:20:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:20:38 --> Final output sent to browser
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:39 --> Total execution time: 1.3216
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
INFO - 2020-02-04 05:20:39 --> Output Class Initialized
INFO - 2020-02-04 05:20:39 --> Output Class Initialized
INFO - 2020-02-04 05:20:39 --> Output Class Initialized
INFO - 2020-02-04 05:20:39 --> Output Class Initialized
INFO - 2020-02-04 05:20:39 --> Security Class Initialized
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
INFO - 2020-02-04 05:20:39 --> Security Class Initialized
INFO - 2020-02-04 05:20:39 --> Security Class Initialized
INFO - 2020-02-04 05:20:39 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:39 --> Output Class Initialized
INFO - 2020-02-04 05:20:39 --> Output Class Initialized
DEBUG - 2020-02-04 05:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:39 --> Input Class Initialized
INFO - 2020-02-04 05:20:39 --> Input Class Initialized
INFO - 2020-02-04 05:20:39 --> Security Class Initialized
INFO - 2020-02-04 05:20:39 --> Input Class Initialized
INFO - 2020-02-04 05:20:39 --> Security Class Initialized
INFO - 2020-02-04 05:20:39 --> Input Class Initialized
INFO - 2020-02-04 05:20:39 --> Language Class Initialized
INFO - 2020-02-04 05:20:39 --> Language Class Initialized
INFO - 2020-02-04 05:20:39 --> Language Class Initialized
DEBUG - 2020-02-04 05:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:39 --> Language Class Initialized
DEBUG - 2020-02-04 05:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:39 --> Loader Class Initialized
INFO - 2020-02-04 05:20:39 --> Input Class Initialized
ERROR - 2020-02-04 05:20:39 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 05:20:39 --> Helper loaded: url_helper
ERROR - 2020-02-04 05:20:39 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 05:20:39 --> Input Class Initialized
INFO - 2020-02-04 05:20:39 --> Loader Class Initialized
INFO - 2020-02-04 05:20:39 --> Language Class Initialized
INFO - 2020-02-04 05:20:39 --> Helper loaded: url_helper
INFO - 2020-02-04 05:20:39 --> Database Driver Class Initialized
INFO - 2020-02-04 05:20:39 --> Language Class Initialized
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
ERROR - 2020-02-04 05:20:39 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 05:20:39 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-04 05:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:20:39 --> Database Driver Class Initialized
INFO - 2020-02-04 05:20:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> Controller Class Initialized
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:39 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
INFO - 2020-02-04 05:20:39 --> Helper loaded: form_helper
INFO - 2020-02-04 05:20:39 --> Form Validation Class Initialized
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
INFO - 2020-02-04 05:20:39 --> Output Class Initialized
INFO - 2020-02-04 05:20:39 --> Output Class Initialized
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
INFO - 2020-02-04 05:20:39 --> Security Class Initialized
INFO - 2020-02-04 05:20:39 --> Security Class Initialized
ERROR - 2020-02-04 05:20:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 05:20:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-04 05:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:39 --> Output Class Initialized
INFO - 2020-02-04 05:20:39 --> Output Class Initialized
INFO - 2020-02-04 05:20:39 --> Input Class Initialized
INFO - 2020-02-04 05:20:39 --> Input Class Initialized
INFO - 2020-02-04 05:20:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:20:39 --> Security Class Initialized
INFO - 2020-02-04 05:20:39 --> Security Class Initialized
INFO - 2020-02-04 05:20:39 --> Final output sent to browser
INFO - 2020-02-04 05:20:39 --> Language Class Initialized
DEBUG - 2020-02-04 05:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:39 --> Language Class Initialized
DEBUG - 2020-02-04 05:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:39 --> Input Class Initialized
ERROR - 2020-02-04 05:20:39 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:20:39 --> Input Class Initialized
DEBUG - 2020-02-04 05:20:39 --> Total execution time: 0.6612
ERROR - 2020-02-04 05:20:39 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:20:39 --> Language Class Initialized
INFO - 2020-02-04 05:20:39 --> Language Class Initialized
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:39 --> Controller Class Initialized
ERROR - 2020-02-04 05:20:39 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-04 05:20:39 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:39 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:20:39 --> Config Class Initialized
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> Hooks Class Initialized
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> Helper loaded: form_helper
INFO - 2020-02-04 05:20:39 --> Form Validation Class Initialized
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
DEBUG - 2020-02-04 05:20:39 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
ERROR - 2020-02-04 05:20:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 05:20:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:20:39 --> URI Class Initialized
INFO - 2020-02-04 05:20:39 --> Output Class Initialized
INFO - 2020-02-04 05:20:39 --> Output Class Initialized
INFO - 2020-02-04 05:20:39 --> Output Class Initialized
INFO - 2020-02-04 05:20:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:20:39 --> Router Class Initialized
INFO - 2020-02-04 05:20:39 --> Security Class Initialized
INFO - 2020-02-04 05:20:39 --> Security Class Initialized
INFO - 2020-02-04 05:20:39 --> Security Class Initialized
INFO - 2020-02-04 05:20:40 --> Final output sent to browser
DEBUG - 2020-02-04 05:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:40 --> Output Class Initialized
DEBUG - 2020-02-04 05:20:40 --> Total execution time: 0.9797
INFO - 2020-02-04 05:20:40 --> Input Class Initialized
INFO - 2020-02-04 05:20:40 --> Input Class Initialized
INFO - 2020-02-04 05:20:40 --> Input Class Initialized
INFO - 2020-02-04 05:20:40 --> Security Class Initialized
INFO - 2020-02-04 05:20:40 --> Language Class Initialized
INFO - 2020-02-04 05:20:40 --> Language Class Initialized
DEBUG - 2020-02-04 05:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:40 --> Language Class Initialized
INFO - 2020-02-04 05:20:40 --> Input Class Initialized
ERROR - 2020-02-04 05:20:40 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 05:20:40 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 05:20:40 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:20:40 --> Language Class Initialized
ERROR - 2020-02-04 05:20:40 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 05:20:40 --> Config Class Initialized
INFO - 2020-02-04 05:20:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:40 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:40 --> URI Class Initialized
INFO - 2020-02-04 05:20:40 --> Router Class Initialized
INFO - 2020-02-04 05:20:40 --> Output Class Initialized
INFO - 2020-02-04 05:20:40 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:40 --> Input Class Initialized
INFO - 2020-02-04 05:20:40 --> Language Class Initialized
ERROR - 2020-02-04 05:20:40 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:20:40 --> Config Class Initialized
INFO - 2020-02-04 05:20:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:40 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:40 --> URI Class Initialized
INFO - 2020-02-04 05:20:40 --> Router Class Initialized
INFO - 2020-02-04 05:20:40 --> Output Class Initialized
INFO - 2020-02-04 05:20:40 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:40 --> Input Class Initialized
INFO - 2020-02-04 05:20:40 --> Language Class Initialized
ERROR - 2020-02-04 05:20:40 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:20:40 --> Config Class Initialized
INFO - 2020-02-04 05:20:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:40 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:40 --> URI Class Initialized
INFO - 2020-02-04 05:20:40 --> Router Class Initialized
INFO - 2020-02-04 05:20:40 --> Output Class Initialized
INFO - 2020-02-04 05:20:41 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:41 --> Input Class Initialized
INFO - 2020-02-04 05:20:41 --> Language Class Initialized
ERROR - 2020-02-04 05:20:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:20:41 --> Config Class Initialized
INFO - 2020-02-04 05:20:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:41 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:41 --> URI Class Initialized
INFO - 2020-02-04 05:20:41 --> Router Class Initialized
INFO - 2020-02-04 05:20:41 --> Output Class Initialized
INFO - 2020-02-04 05:20:41 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:41 --> Input Class Initialized
INFO - 2020-02-04 05:20:41 --> Language Class Initialized
ERROR - 2020-02-04 05:20:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:20:41 --> Config Class Initialized
INFO - 2020-02-04 05:20:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:41 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:41 --> URI Class Initialized
INFO - 2020-02-04 05:20:41 --> Router Class Initialized
INFO - 2020-02-04 05:20:41 --> Output Class Initialized
INFO - 2020-02-04 05:20:41 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:41 --> Input Class Initialized
INFO - 2020-02-04 05:20:41 --> Language Class Initialized
ERROR - 2020-02-04 05:20:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:20:41 --> Config Class Initialized
INFO - 2020-02-04 05:20:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:41 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:41 --> URI Class Initialized
INFO - 2020-02-04 05:20:41 --> Router Class Initialized
INFO - 2020-02-04 05:20:41 --> Output Class Initialized
INFO - 2020-02-04 05:20:41 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:41 --> Input Class Initialized
INFO - 2020-02-04 05:20:41 --> Language Class Initialized
ERROR - 2020-02-04 05:20:41 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:20:42 --> Config Class Initialized
INFO - 2020-02-04 05:20:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:42 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:42 --> URI Class Initialized
INFO - 2020-02-04 05:20:42 --> Router Class Initialized
INFO - 2020-02-04 05:20:42 --> Output Class Initialized
INFO - 2020-02-04 05:20:42 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:42 --> Input Class Initialized
INFO - 2020-02-04 05:20:42 --> Language Class Initialized
ERROR - 2020-02-04 05:20:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:20:42 --> Config Class Initialized
INFO - 2020-02-04 05:20:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:42 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:42 --> URI Class Initialized
INFO - 2020-02-04 05:20:42 --> Router Class Initialized
INFO - 2020-02-04 05:20:42 --> Output Class Initialized
INFO - 2020-02-04 05:20:42 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:42 --> Input Class Initialized
INFO - 2020-02-04 05:20:42 --> Language Class Initialized
ERROR - 2020-02-04 05:20:42 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:20:42 --> Config Class Initialized
INFO - 2020-02-04 05:20:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:20:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:20:42 --> Utf8 Class Initialized
INFO - 2020-02-04 05:20:42 --> URI Class Initialized
INFO - 2020-02-04 05:20:42 --> Router Class Initialized
INFO - 2020-02-04 05:20:42 --> Output Class Initialized
INFO - 2020-02-04 05:20:42 --> Security Class Initialized
DEBUG - 2020-02-04 05:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:20:42 --> Input Class Initialized
INFO - 2020-02-04 05:20:42 --> Language Class Initialized
ERROR - 2020-02-04 05:20:42 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:23:33 --> Config Class Initialized
INFO - 2020-02-04 05:23:33 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:23:33 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:23:33 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:33 --> URI Class Initialized
INFO - 2020-02-04 05:23:33 --> Router Class Initialized
INFO - 2020-02-04 05:23:33 --> Output Class Initialized
INFO - 2020-02-04 05:23:33 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:33 --> Input Class Initialized
INFO - 2020-02-04 05:23:33 --> Language Class Initialized
INFO - 2020-02-04 05:23:33 --> Loader Class Initialized
INFO - 2020-02-04 05:23:33 --> Helper loaded: url_helper
INFO - 2020-02-04 05:23:33 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:23:33 --> Controller Class Initialized
INFO - 2020-02-04 05:23:33 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:23:33 --> Helper loaded: form_helper
INFO - 2020-02-04 05:23:33 --> Form Validation Class Initialized
INFO - 2020-02-04 05:23:33 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:23:33 --> Final output sent to browser
DEBUG - 2020-02-04 05:23:33 --> Total execution time: 0.6744
INFO - 2020-02-04 05:23:33 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
INFO - 2020-02-04 05:23:34 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
ERROR - 2020-02-04 05:23:34 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 05:23:34 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 05:23:34 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 05:23:34 --> Loader Class Initialized
ERROR - 2020-02-04 05:23:34 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:23:34 --> Helper loaded: url_helper
ERROR - 2020-02-04 05:23:34 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:23:34 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
INFO - 2020-02-04 05:23:34 --> Database Driver Class Initialized
INFO - 2020-02-04 05:23:34 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:23:34 --> Controller Class Initialized
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> Helper loaded: form_helper
INFO - 2020-02-04 05:23:34 --> Form Validation Class Initialized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 05:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
ERROR - 2020-02-04 05:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
INFO - 2020-02-04 05:23:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
INFO - 2020-02-04 05:23:34 --> Final output sent to browser
ERROR - 2020-02-04 05:23:34 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 05:23:34 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
ERROR - 2020-02-04 05:23:34 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
DEBUG - 2020-02-04 05:23:34 --> Total execution time: 0.6329
ERROR - 2020-02-04 05:23:34 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-04 05:23:34 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:23:34 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Config Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
INFO - 2020-02-04 05:23:34 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:23:34 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:34 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> URI Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> Router Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Output Class Initialized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
INFO - 2020-02-04 05:23:34 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
INFO - 2020-02-04 05:23:34 --> Input Class Initialized
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
INFO - 2020-02-04 05:23:34 --> Language Class Initialized
ERROR - 2020-02-04 05:23:34 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 05:23:34 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 05:23:34 --> Loader Class Initialized
INFO - 2020-02-04 05:23:34 --> Helper loaded: url_helper
INFO - 2020-02-04 05:23:35 --> Config Class Initialized
INFO - 2020-02-04 05:23:35 --> Hooks Class Initialized
INFO - 2020-02-04 05:23:35 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:23:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:23:35 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:23:35 --> Controller Class Initialized
INFO - 2020-02-04 05:23:35 --> URI Class Initialized
INFO - 2020-02-04 05:23:35 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:23:35 --> Router Class Initialized
INFO - 2020-02-04 05:23:35 --> Output Class Initialized
INFO - 2020-02-04 05:23:35 --> Helper loaded: form_helper
INFO - 2020-02-04 05:23:35 --> Form Validation Class Initialized
INFO - 2020-02-04 05:23:35 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 05:23:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:23:35 --> Input Class Initialized
ERROR - 2020-02-04 05:23:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:23:35 --> Language Class Initialized
INFO - 2020-02-04 05:23:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:23:35 --> Final output sent to browser
ERROR - 2020-02-04 05:23:35 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-04 05:23:35 --> Total execution time: 0.5618
INFO - 2020-02-04 05:23:35 --> Config Class Initialized
INFO - 2020-02-04 05:23:35 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:23:35 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:23:35 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:35 --> URI Class Initialized
INFO - 2020-02-04 05:23:35 --> Router Class Initialized
INFO - 2020-02-04 05:23:35 --> Output Class Initialized
INFO - 2020-02-04 05:23:35 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:35 --> Input Class Initialized
INFO - 2020-02-04 05:23:35 --> Language Class Initialized
ERROR - 2020-02-04 05:23:35 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:23:35 --> Config Class Initialized
INFO - 2020-02-04 05:23:35 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:23:35 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:23:35 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:35 --> URI Class Initialized
INFO - 2020-02-04 05:23:35 --> Router Class Initialized
INFO - 2020-02-04 05:23:35 --> Output Class Initialized
INFO - 2020-02-04 05:23:35 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:35 --> Input Class Initialized
INFO - 2020-02-04 05:23:35 --> Language Class Initialized
ERROR - 2020-02-04 05:23:35 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:23:35 --> Config Class Initialized
INFO - 2020-02-04 05:23:35 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:23:35 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:23:35 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:35 --> URI Class Initialized
INFO - 2020-02-04 05:23:35 --> Router Class Initialized
INFO - 2020-02-04 05:23:36 --> Output Class Initialized
INFO - 2020-02-04 05:23:36 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:36 --> Input Class Initialized
INFO - 2020-02-04 05:23:36 --> Language Class Initialized
ERROR - 2020-02-04 05:23:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:23:36 --> Config Class Initialized
INFO - 2020-02-04 05:23:36 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:23:36 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:23:36 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:36 --> URI Class Initialized
INFO - 2020-02-04 05:23:36 --> Router Class Initialized
INFO - 2020-02-04 05:23:36 --> Output Class Initialized
INFO - 2020-02-04 05:23:36 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:36 --> Input Class Initialized
INFO - 2020-02-04 05:23:36 --> Language Class Initialized
ERROR - 2020-02-04 05:23:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:23:36 --> Config Class Initialized
INFO - 2020-02-04 05:23:36 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:23:36 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:23:36 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:36 --> URI Class Initialized
INFO - 2020-02-04 05:23:36 --> Router Class Initialized
INFO - 2020-02-04 05:23:36 --> Output Class Initialized
INFO - 2020-02-04 05:23:36 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:36 --> Input Class Initialized
INFO - 2020-02-04 05:23:36 --> Language Class Initialized
ERROR - 2020-02-04 05:23:36 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:23:36 --> Config Class Initialized
INFO - 2020-02-04 05:23:36 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:23:36 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:23:36 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:36 --> URI Class Initialized
INFO - 2020-02-04 05:23:36 --> Router Class Initialized
INFO - 2020-02-04 05:23:36 --> Output Class Initialized
INFO - 2020-02-04 05:23:36 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:36 --> Input Class Initialized
INFO - 2020-02-04 05:23:36 --> Language Class Initialized
ERROR - 2020-02-04 05:23:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:23:37 --> Config Class Initialized
INFO - 2020-02-04 05:23:37 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:23:37 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:23:37 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:37 --> URI Class Initialized
INFO - 2020-02-04 05:23:37 --> Router Class Initialized
INFO - 2020-02-04 05:23:37 --> Output Class Initialized
INFO - 2020-02-04 05:23:37 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:37 --> Input Class Initialized
INFO - 2020-02-04 05:23:37 --> Language Class Initialized
ERROR - 2020-02-04 05:23:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:23:37 --> Config Class Initialized
INFO - 2020-02-04 05:23:37 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:23:37 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:23:37 --> Utf8 Class Initialized
INFO - 2020-02-04 05:23:38 --> URI Class Initialized
INFO - 2020-02-04 05:23:38 --> Router Class Initialized
INFO - 2020-02-04 05:23:38 --> Output Class Initialized
INFO - 2020-02-04 05:23:38 --> Security Class Initialized
DEBUG - 2020-02-04 05:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:23:38 --> Input Class Initialized
INFO - 2020-02-04 05:23:38 --> Language Class Initialized
ERROR - 2020-02-04 05:23:38 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:25:49 --> Config Class Initialized
INFO - 2020-02-04 05:25:49 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:25:49 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:25:50 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:50 --> URI Class Initialized
INFO - 2020-02-04 05:25:50 --> Router Class Initialized
INFO - 2020-02-04 05:25:50 --> Output Class Initialized
INFO - 2020-02-04 05:25:50 --> Security Class Initialized
DEBUG - 2020-02-04 05:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:50 --> Input Class Initialized
INFO - 2020-02-04 05:25:50 --> Language Class Initialized
INFO - 2020-02-04 05:25:50 --> Loader Class Initialized
INFO - 2020-02-04 05:25:50 --> Helper loaded: url_helper
INFO - 2020-02-04 05:25:50 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:25:51 --> Controller Class Initialized
INFO - 2020-02-04 05:25:51 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:25:51 --> Helper loaded: form_helper
INFO - 2020-02-04 05:25:51 --> Form Validation Class Initialized
INFO - 2020-02-04 05:25:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:25:51 --> Final output sent to browser
INFO - 2020-02-04 05:25:51 --> Config Class Initialized
INFO - 2020-02-04 05:25:51 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:25:51 --> Total execution time: 1.7519
INFO - 2020-02-04 05:25:51 --> Config Class Initialized
INFO - 2020-02-04 05:25:51 --> Config Class Initialized
INFO - 2020-02-04 05:25:51 --> Config Class Initialized
INFO - 2020-02-04 05:25:51 --> Config Class Initialized
INFO - 2020-02-04 05:25:51 --> Hooks Class Initialized
INFO - 2020-02-04 05:25:51 --> Hooks Class Initialized
INFO - 2020-02-04 05:25:51 --> Hooks Class Initialized
INFO - 2020-02-04 05:25:51 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:25:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:25:51 --> Config Class Initialized
INFO - 2020-02-04 05:25:51 --> Hooks Class Initialized
INFO - 2020-02-04 05:25:51 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:25:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:25:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:25:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:25:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:25:51 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:51 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:51 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:51 --> URI Class Initialized
INFO - 2020-02-04 05:25:51 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:25:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:25:51 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:51 --> URI Class Initialized
INFO - 2020-02-04 05:25:51 --> URI Class Initialized
INFO - 2020-02-04 05:25:51 --> URI Class Initialized
INFO - 2020-02-04 05:25:51 --> URI Class Initialized
INFO - 2020-02-04 05:25:51 --> Router Class Initialized
INFO - 2020-02-04 05:25:51 --> URI Class Initialized
INFO - 2020-02-04 05:25:51 --> Router Class Initialized
INFO - 2020-02-04 05:25:51 --> Router Class Initialized
INFO - 2020-02-04 05:25:51 --> Output Class Initialized
INFO - 2020-02-04 05:25:51 --> Router Class Initialized
INFO - 2020-02-04 05:25:51 --> Router Class Initialized
INFO - 2020-02-04 05:25:51 --> Router Class Initialized
INFO - 2020-02-04 05:25:51 --> Security Class Initialized
INFO - 2020-02-04 05:25:51 --> Output Class Initialized
INFO - 2020-02-04 05:25:51 --> Output Class Initialized
INFO - 2020-02-04 05:25:51 --> Output Class Initialized
INFO - 2020-02-04 05:25:51 --> Output Class Initialized
DEBUG - 2020-02-04 05:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:51 --> Output Class Initialized
INFO - 2020-02-04 05:25:51 --> Security Class Initialized
INFO - 2020-02-04 05:25:51 --> Security Class Initialized
INFO - 2020-02-04 05:25:51 --> Security Class Initialized
INFO - 2020-02-04 05:25:51 --> Security Class Initialized
DEBUG - 2020-02-04 05:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:51 --> Input Class Initialized
DEBUG - 2020-02-04 05:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:51 --> Security Class Initialized
INFO - 2020-02-04 05:25:51 --> Input Class Initialized
INFO - 2020-02-04 05:25:51 --> Input Class Initialized
INFO - 2020-02-04 05:25:51 --> Input Class Initialized
INFO - 2020-02-04 05:25:51 --> Input Class Initialized
INFO - 2020-02-04 05:25:51 --> Language Class Initialized
DEBUG - 2020-02-04 05:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:51 --> Input Class Initialized
INFO - 2020-02-04 05:25:51 --> Language Class Initialized
INFO - 2020-02-04 05:25:51 --> Language Class Initialized
INFO - 2020-02-04 05:25:51 --> Language Class Initialized
INFO - 2020-02-04 05:25:51 --> Language Class Initialized
INFO - 2020-02-04 05:25:51 --> Loader Class Initialized
ERROR - 2020-02-04 05:25:52 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 05:25:52 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 05:25:52 --> Helper loaded: url_helper
INFO - 2020-02-04 05:25:52 --> Language Class Initialized
INFO - 2020-02-04 05:25:52 --> Loader Class Initialized
ERROR - 2020-02-04 05:25:52 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:25:52 --> Helper loaded: url_helper
ERROR - 2020-02-04 05:25:52 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:25:52 --> Database Driver Class Initialized
INFO - 2020-02-04 05:25:52 --> Config Class Initialized
INFO - 2020-02-04 05:25:52 --> Config Class Initialized
INFO - 2020-02-04 05:25:52 --> Config Class Initialized
INFO - 2020-02-04 05:25:52 --> Hooks Class Initialized
INFO - 2020-02-04 05:25:52 --> Hooks Class Initialized
INFO - 2020-02-04 05:25:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:25:52 --> Config Class Initialized
INFO - 2020-02-04 05:25:52 --> Database Driver Class Initialized
INFO - 2020-02-04 05:25:52 --> Hooks Class Initialized
INFO - 2020-02-04 05:25:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:25:52 --> Controller Class Initialized
INFO - 2020-02-04 05:25:52 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:52 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:52 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:25:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:25:52 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:52 --> URI Class Initialized
INFO - 2020-02-04 05:25:52 --> URI Class Initialized
INFO - 2020-02-04 05:25:52 --> URI Class Initialized
INFO - 2020-02-04 05:25:52 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:25:52 --> URI Class Initialized
INFO - 2020-02-04 05:25:52 --> Router Class Initialized
INFO - 2020-02-04 05:25:52 --> Helper loaded: form_helper
INFO - 2020-02-04 05:25:52 --> Router Class Initialized
INFO - 2020-02-04 05:25:52 --> Router Class Initialized
INFO - 2020-02-04 05:25:52 --> Form Validation Class Initialized
INFO - 2020-02-04 05:25:52 --> Router Class Initialized
INFO - 2020-02-04 05:25:52 --> Output Class Initialized
INFO - 2020-02-04 05:25:52 --> Output Class Initialized
INFO - 2020-02-04 05:25:52 --> Output Class Initialized
INFO - 2020-02-04 05:25:52 --> Security Class Initialized
INFO - 2020-02-04 05:25:52 --> Output Class Initialized
INFO - 2020-02-04 05:25:52 --> Security Class Initialized
INFO - 2020-02-04 05:25:52 --> Security Class Initialized
ERROR - 2020-02-04 05:25:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
DEBUG - 2020-02-04 05:25:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 05:25:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-04 05:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:52 --> Security Class Initialized
DEBUG - 2020-02-04 05:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:52 --> Input Class Initialized
INFO - 2020-02-04 05:25:52 --> Input Class Initialized
INFO - 2020-02-04 05:25:52 --> Input Class Initialized
INFO - 2020-02-04 05:25:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-04 05:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:52 --> Final output sent to browser
INFO - 2020-02-04 05:25:52 --> Input Class Initialized
INFO - 2020-02-04 05:25:52 --> Language Class Initialized
INFO - 2020-02-04 05:25:52 --> Language Class Initialized
INFO - 2020-02-04 05:25:52 --> Language Class Initialized
DEBUG - 2020-02-04 05:25:52 --> Total execution time: 0.6843
INFO - 2020-02-04 05:25:52 --> Language Class Initialized
ERROR - 2020-02-04 05:25:52 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 05:25:52 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 05:25:52 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 05:25:52 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:25:52 --> Config Class Initialized
INFO - 2020-02-04 05:25:52 --> Config Class Initialized
INFO - 2020-02-04 05:25:52 --> Config Class Initialized
INFO - 2020-02-04 05:25:52 --> Config Class Initialized
INFO - 2020-02-04 05:25:52 --> Hooks Class Initialized
INFO - 2020-02-04 05:25:52 --> Hooks Class Initialized
INFO - 2020-02-04 05:25:52 --> Hooks Class Initialized
INFO - 2020-02-04 05:25:52 --> Controller Class Initialized
INFO - 2020-02-04 05:25:52 --> Hooks Class Initialized
INFO - 2020-02-04 05:25:52 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:25:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:25:52 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:52 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:52 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:52 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:52 --> Helper loaded: form_helper
INFO - 2020-02-04 05:25:52 --> Form Validation Class Initialized
INFO - 2020-02-04 05:25:52 --> URI Class Initialized
INFO - 2020-02-04 05:25:52 --> URI Class Initialized
INFO - 2020-02-04 05:25:52 --> URI Class Initialized
INFO - 2020-02-04 05:25:52 --> URI Class Initialized
INFO - 2020-02-04 05:25:52 --> Router Class Initialized
INFO - 2020-02-04 05:25:52 --> Router Class Initialized
INFO - 2020-02-04 05:25:52 --> Router Class Initialized
INFO - 2020-02-04 05:25:52 --> Router Class Initialized
ERROR - 2020-02-04 05:25:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 05:25:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:25:52 --> Output Class Initialized
INFO - 2020-02-04 05:25:52 --> Output Class Initialized
INFO - 2020-02-04 05:25:52 --> Output Class Initialized
INFO - 2020-02-04 05:25:52 --> Output Class Initialized
INFO - 2020-02-04 05:25:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:25:52 --> Security Class Initialized
INFO - 2020-02-04 05:25:52 --> Security Class Initialized
INFO - 2020-02-04 05:25:52 --> Security Class Initialized
INFO - 2020-02-04 05:25:52 --> Security Class Initialized
INFO - 2020-02-04 05:25:52 --> Final output sent to browser
DEBUG - 2020-02-04 05:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:52 --> Input Class Initialized
INFO - 2020-02-04 05:25:52 --> Input Class Initialized
DEBUG - 2020-02-04 05:25:52 --> Total execution time: 0.9669
INFO - 2020-02-04 05:25:52 --> Input Class Initialized
INFO - 2020-02-04 05:25:52 --> Input Class Initialized
INFO - 2020-02-04 05:25:52 --> Language Class Initialized
INFO - 2020-02-04 05:25:52 --> Language Class Initialized
INFO - 2020-02-04 05:25:52 --> Language Class Initialized
INFO - 2020-02-04 05:25:52 --> Language Class Initialized
ERROR - 2020-02-04 05:25:52 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 05:25:52 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-04 05:25:52 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 05:25:52 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:25:52 --> Config Class Initialized
INFO - 2020-02-04 05:25:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:25:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:25:52 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:52 --> URI Class Initialized
INFO - 2020-02-04 05:25:52 --> Router Class Initialized
INFO - 2020-02-04 05:25:52 --> Output Class Initialized
INFO - 2020-02-04 05:25:52 --> Security Class Initialized
DEBUG - 2020-02-04 05:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:53 --> Input Class Initialized
INFO - 2020-02-04 05:25:53 --> Language Class Initialized
ERROR - 2020-02-04 05:25:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:25:53 --> Config Class Initialized
INFO - 2020-02-04 05:25:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:25:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:25:53 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:53 --> URI Class Initialized
INFO - 2020-02-04 05:25:53 --> Router Class Initialized
INFO - 2020-02-04 05:25:53 --> Output Class Initialized
INFO - 2020-02-04 05:25:53 --> Security Class Initialized
DEBUG - 2020-02-04 05:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:53 --> Input Class Initialized
INFO - 2020-02-04 05:25:53 --> Language Class Initialized
ERROR - 2020-02-04 05:25:53 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:25:53 --> Config Class Initialized
INFO - 2020-02-04 05:25:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:25:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:25:53 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:53 --> URI Class Initialized
INFO - 2020-02-04 05:25:53 --> Router Class Initialized
INFO - 2020-02-04 05:25:53 --> Output Class Initialized
INFO - 2020-02-04 05:25:53 --> Security Class Initialized
DEBUG - 2020-02-04 05:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:53 --> Input Class Initialized
INFO - 2020-02-04 05:25:53 --> Language Class Initialized
ERROR - 2020-02-04 05:25:53 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:25:53 --> Config Class Initialized
INFO - 2020-02-04 05:25:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:25:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:25:53 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:53 --> URI Class Initialized
INFO - 2020-02-04 05:25:53 --> Router Class Initialized
INFO - 2020-02-04 05:25:53 --> Output Class Initialized
INFO - 2020-02-04 05:25:53 --> Security Class Initialized
DEBUG - 2020-02-04 05:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:53 --> Input Class Initialized
INFO - 2020-02-04 05:25:53 --> Language Class Initialized
ERROR - 2020-02-04 05:25:54 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:25:54 --> Config Class Initialized
INFO - 2020-02-04 05:25:54 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:25:54 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:25:54 --> Utf8 Class Initialized
INFO - 2020-02-04 05:25:54 --> URI Class Initialized
INFO - 2020-02-04 05:25:54 --> Router Class Initialized
INFO - 2020-02-04 05:25:54 --> Output Class Initialized
INFO - 2020-02-04 05:25:54 --> Security Class Initialized
DEBUG - 2020-02-04 05:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:25:54 --> Input Class Initialized
INFO - 2020-02-04 05:25:54 --> Language Class Initialized
ERROR - 2020-02-04 05:25:54 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:28:39 --> Config Class Initialized
INFO - 2020-02-04 05:28:39 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:28:39 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:39 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:39 --> URI Class Initialized
INFO - 2020-02-04 05:28:39 --> Router Class Initialized
INFO - 2020-02-04 05:28:40 --> Output Class Initialized
INFO - 2020-02-04 05:28:40 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:40 --> Input Class Initialized
INFO - 2020-02-04 05:28:40 --> Language Class Initialized
INFO - 2020-02-04 05:28:40 --> Loader Class Initialized
INFO - 2020-02-04 05:28:40 --> Helper loaded: url_helper
INFO - 2020-02-04 05:28:40 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:28:40 --> Controller Class Initialized
INFO - 2020-02-04 05:28:41 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:28:41 --> Helper loaded: form_helper
INFO - 2020-02-04 05:28:41 --> Form Validation Class Initialized
INFO - 2020-02-04 05:28:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:28:41 --> Final output sent to browser
INFO - 2020-02-04 05:28:41 --> Config Class Initialized
INFO - 2020-02-04 05:28:41 --> Config Class Initialized
INFO - 2020-02-04 05:28:41 --> Config Class Initialized
INFO - 2020-02-04 05:28:41 --> Config Class Initialized
INFO - 2020-02-04 05:28:41 --> Config Class Initialized
INFO - 2020-02-04 05:28:41 --> Hooks Class Initialized
INFO - 2020-02-04 05:28:41 --> Hooks Class Initialized
INFO - 2020-02-04 05:28:41 --> Hooks Class Initialized
INFO - 2020-02-04 05:28:41 --> Hooks Class Initialized
INFO - 2020-02-04 05:28:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:28:41 --> Total execution time: 1.6515
DEBUG - 2020-02-04 05:28:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:41 --> Config Class Initialized
DEBUG - 2020-02-04 05:28:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:28:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:28:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:41 --> Hooks Class Initialized
INFO - 2020-02-04 05:28:41 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:41 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:41 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:41 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:28:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:41 --> URI Class Initialized
INFO - 2020-02-04 05:28:41 --> URI Class Initialized
INFO - 2020-02-04 05:28:41 --> URI Class Initialized
INFO - 2020-02-04 05:28:41 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:28:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:41 --> URI Class Initialized
INFO - 2020-02-04 05:28:41 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:41 --> URI Class Initialized
INFO - 2020-02-04 05:28:41 --> Router Class Initialized
INFO - 2020-02-04 05:28:41 --> Router Class Initialized
INFO - 2020-02-04 05:28:41 --> Router Class Initialized
INFO - 2020-02-04 05:28:41 --> Router Class Initialized
INFO - 2020-02-04 05:28:41 --> URI Class Initialized
INFO - 2020-02-04 05:28:41 --> Router Class Initialized
INFO - 2020-02-04 05:28:41 --> Output Class Initialized
INFO - 2020-02-04 05:28:41 --> Output Class Initialized
INFO - 2020-02-04 05:28:41 --> Output Class Initialized
INFO - 2020-02-04 05:28:41 --> Output Class Initialized
INFO - 2020-02-04 05:28:41 --> Router Class Initialized
INFO - 2020-02-04 05:28:41 --> Output Class Initialized
INFO - 2020-02-04 05:28:41 --> Security Class Initialized
INFO - 2020-02-04 05:28:41 --> Security Class Initialized
INFO - 2020-02-04 05:28:41 --> Security Class Initialized
INFO - 2020-02-04 05:28:41 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:41 --> Security Class Initialized
INFO - 2020-02-04 05:28:41 --> Output Class Initialized
INFO - 2020-02-04 05:28:41 --> Input Class Initialized
INFO - 2020-02-04 05:28:41 --> Input Class Initialized
INFO - 2020-02-04 05:28:41 --> Input Class Initialized
INFO - 2020-02-04 05:28:41 --> Input Class Initialized
INFO - 2020-02-04 05:28:41 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:41 --> Input Class Initialized
INFO - 2020-02-04 05:28:41 --> Language Class Initialized
DEBUG - 2020-02-04 05:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:41 --> Language Class Initialized
INFO - 2020-02-04 05:28:41 --> Language Class Initialized
INFO - 2020-02-04 05:28:41 --> Language Class Initialized
INFO - 2020-02-04 05:28:41 --> Input Class Initialized
INFO - 2020-02-04 05:28:41 --> Language Class Initialized
ERROR - 2020-02-04 05:28:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 05:28:41 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 05:28:41 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 05:28:41 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 05:28:41 --> Language Class Initialized
ERROR - 2020-02-04 05:28:41 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 05:28:41 --> Config Class Initialized
INFO - 2020-02-04 05:28:41 --> Config Class Initialized
INFO - 2020-02-04 05:28:41 --> Config Class Initialized
INFO - 2020-02-04 05:28:41 --> Config Class Initialized
INFO - 2020-02-04 05:28:41 --> Hooks Class Initialized
INFO - 2020-02-04 05:28:41 --> Hooks Class Initialized
INFO - 2020-02-04 05:28:41 --> Hooks Class Initialized
INFO - 2020-02-04 05:28:41 --> Hooks Class Initialized
INFO - 2020-02-04 05:28:41 --> Loader Class Initialized
INFO - 2020-02-04 05:28:41 --> Config Class Initialized
INFO - 2020-02-04 05:28:41 --> Hooks Class Initialized
INFO - 2020-02-04 05:28:41 --> Helper loaded: url_helper
DEBUG - 2020-02-04 05:28:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:28:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:28:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:28:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:41 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:41 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:41 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:41 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:28:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:41 --> Database Driver Class Initialized
INFO - 2020-02-04 05:28:41 --> URI Class Initialized
INFO - 2020-02-04 05:28:41 --> URI Class Initialized
INFO - 2020-02-04 05:28:41 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:41 --> URI Class Initialized
INFO - 2020-02-04 05:28:41 --> URI Class Initialized
DEBUG - 2020-02-04 05:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:28:41 --> URI Class Initialized
INFO - 2020-02-04 05:28:41 --> Router Class Initialized
INFO - 2020-02-04 05:28:41 --> Router Class Initialized
INFO - 2020-02-04 05:28:41 --> Router Class Initialized
INFO - 2020-02-04 05:28:41 --> Router Class Initialized
INFO - 2020-02-04 05:28:41 --> Controller Class Initialized
INFO - 2020-02-04 05:28:41 --> Output Class Initialized
INFO - 2020-02-04 05:28:41 --> Router Class Initialized
INFO - 2020-02-04 05:28:41 --> Output Class Initialized
INFO - 2020-02-04 05:28:41 --> Output Class Initialized
INFO - 2020-02-04 05:28:41 --> Output Class Initialized
INFO - 2020-02-04 05:28:41 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:28:41 --> Security Class Initialized
INFO - 2020-02-04 05:28:41 --> Security Class Initialized
INFO - 2020-02-04 05:28:41 --> Output Class Initialized
INFO - 2020-02-04 05:28:41 --> Security Class Initialized
INFO - 2020-02-04 05:28:41 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:41 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:41 --> Helper loaded: form_helper
DEBUG - 2020-02-04 05:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:41 --> Form Validation Class Initialized
INFO - 2020-02-04 05:28:41 --> Input Class Initialized
INFO - 2020-02-04 05:28:41 --> Input Class Initialized
INFO - 2020-02-04 05:28:41 --> Input Class Initialized
INFO - 2020-02-04 05:28:41 --> Input Class Initialized
DEBUG - 2020-02-04 05:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:41 --> Input Class Initialized
INFO - 2020-02-04 05:28:41 --> Language Class Initialized
INFO - 2020-02-04 05:28:41 --> Language Class Initialized
INFO - 2020-02-04 05:28:41 --> Language Class Initialized
INFO - 2020-02-04 05:28:42 --> Language Class Initialized
ERROR - 2020-02-04 05:28:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 05:28:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-04 05:28:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:28:42 --> Language Class Initialized
ERROR - 2020-02-04 05:28:42 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:28:42 --> Loader Class Initialized
ERROR - 2020-02-04 05:28:42 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 05:28:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:28:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:28:42 --> Helper loaded: url_helper
INFO - 2020-02-04 05:28:42 --> Config Class Initialized
INFO - 2020-02-04 05:28:42 --> Config Class Initialized
INFO - 2020-02-04 05:28:42 --> Config Class Initialized
INFO - 2020-02-04 05:28:42 --> Hooks Class Initialized
INFO - 2020-02-04 05:28:42 --> Hooks Class Initialized
INFO - 2020-02-04 05:28:42 --> Hooks Class Initialized
INFO - 2020-02-04 05:28:42 --> Final output sent to browser
INFO - 2020-02-04 05:28:42 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:28:42 --> Total execution time: 0.6900
DEBUG - 2020-02-04 05:28:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:28:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:28:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:28:42 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:42 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:42 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:28:42 --> Controller Class Initialized
INFO - 2020-02-04 05:28:42 --> URI Class Initialized
INFO - 2020-02-04 05:28:42 --> URI Class Initialized
INFO - 2020-02-04 05:28:42 --> URI Class Initialized
INFO - 2020-02-04 05:28:42 --> Router Class Initialized
INFO - 2020-02-04 05:28:42 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:28:42 --> Router Class Initialized
INFO - 2020-02-04 05:28:42 --> Router Class Initialized
INFO - 2020-02-04 05:28:42 --> Output Class Initialized
INFO - 2020-02-04 05:28:42 --> Output Class Initialized
INFO - 2020-02-04 05:28:42 --> Output Class Initialized
INFO - 2020-02-04 05:28:42 --> Helper loaded: form_helper
INFO - 2020-02-04 05:28:42 --> Form Validation Class Initialized
INFO - 2020-02-04 05:28:42 --> Security Class Initialized
INFO - 2020-02-04 05:28:42 --> Security Class Initialized
INFO - 2020-02-04 05:28:42 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:28:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 05:28:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:28:42 --> Input Class Initialized
INFO - 2020-02-04 05:28:42 --> Input Class Initialized
INFO - 2020-02-04 05:28:42 --> Input Class Initialized
ERROR - 2020-02-04 05:28:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:28:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:28:42 --> Language Class Initialized
INFO - 2020-02-04 05:28:42 --> Language Class Initialized
INFO - 2020-02-04 05:28:42 --> Language Class Initialized
INFO - 2020-02-04 05:28:42 --> Final output sent to browser
ERROR - 2020-02-04 05:28:42 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 05:28:42 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 05:28:42 --> 404 Page Not Found: Bower_components/jquery-i18next
DEBUG - 2020-02-04 05:28:42 --> Total execution time: 0.6743
INFO - 2020-02-04 05:28:42 --> Config Class Initialized
INFO - 2020-02-04 05:28:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:28:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:42 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:42 --> URI Class Initialized
INFO - 2020-02-04 05:28:42 --> Router Class Initialized
INFO - 2020-02-04 05:28:42 --> Output Class Initialized
INFO - 2020-02-04 05:28:42 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:42 --> Input Class Initialized
INFO - 2020-02-04 05:28:42 --> Language Class Initialized
ERROR - 2020-02-04 05:28:42 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:28:42 --> Config Class Initialized
INFO - 2020-02-04 05:28:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:28:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:42 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:42 --> URI Class Initialized
INFO - 2020-02-04 05:28:42 --> Router Class Initialized
INFO - 2020-02-04 05:28:42 --> Output Class Initialized
INFO - 2020-02-04 05:28:42 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:42 --> Input Class Initialized
INFO - 2020-02-04 05:28:43 --> Language Class Initialized
ERROR - 2020-02-04 05:28:43 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:28:43 --> Config Class Initialized
INFO - 2020-02-04 05:28:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:28:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:43 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:43 --> URI Class Initialized
INFO - 2020-02-04 05:28:43 --> Router Class Initialized
INFO - 2020-02-04 05:28:43 --> Output Class Initialized
INFO - 2020-02-04 05:28:43 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:43 --> Input Class Initialized
INFO - 2020-02-04 05:28:43 --> Language Class Initialized
ERROR - 2020-02-04 05:28:43 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:28:43 --> Config Class Initialized
INFO - 2020-02-04 05:28:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:28:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:43 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:43 --> URI Class Initialized
INFO - 2020-02-04 05:28:43 --> Router Class Initialized
INFO - 2020-02-04 05:28:43 --> Output Class Initialized
INFO - 2020-02-04 05:28:43 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:43 --> Input Class Initialized
INFO - 2020-02-04 05:28:43 --> Language Class Initialized
ERROR - 2020-02-04 05:28:43 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:28:43 --> Config Class Initialized
INFO - 2020-02-04 05:28:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:28:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:43 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:43 --> URI Class Initialized
INFO - 2020-02-04 05:28:43 --> Router Class Initialized
INFO - 2020-02-04 05:28:43 --> Output Class Initialized
INFO - 2020-02-04 05:28:44 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:44 --> Input Class Initialized
INFO - 2020-02-04 05:28:44 --> Language Class Initialized
ERROR - 2020-02-04 05:28:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:28:44 --> Config Class Initialized
INFO - 2020-02-04 05:28:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:28:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:44 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:44 --> URI Class Initialized
INFO - 2020-02-04 05:28:44 --> Router Class Initialized
INFO - 2020-02-04 05:28:44 --> Output Class Initialized
INFO - 2020-02-04 05:28:44 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:44 --> Input Class Initialized
INFO - 2020-02-04 05:28:44 --> Language Class Initialized
ERROR - 2020-02-04 05:28:44 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:28:44 --> Config Class Initialized
INFO - 2020-02-04 05:28:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:28:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:44 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:44 --> URI Class Initialized
INFO - 2020-02-04 05:28:44 --> Router Class Initialized
INFO - 2020-02-04 05:28:44 --> Output Class Initialized
INFO - 2020-02-04 05:28:44 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:44 --> Input Class Initialized
INFO - 2020-02-04 05:28:44 --> Language Class Initialized
ERROR - 2020-02-04 05:28:44 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:28:44 --> Config Class Initialized
INFO - 2020-02-04 05:28:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:28:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:45 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:45 --> URI Class Initialized
INFO - 2020-02-04 05:28:45 --> Router Class Initialized
INFO - 2020-02-04 05:28:45 --> Output Class Initialized
INFO - 2020-02-04 05:28:45 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:45 --> Input Class Initialized
INFO - 2020-02-04 05:28:45 --> Language Class Initialized
ERROR - 2020-02-04 05:28:45 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:28:45 --> Config Class Initialized
INFO - 2020-02-04 05:28:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:28:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:45 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:45 --> URI Class Initialized
INFO - 2020-02-04 05:28:45 --> Router Class Initialized
INFO - 2020-02-04 05:28:45 --> Output Class Initialized
INFO - 2020-02-04 05:28:45 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:45 --> Input Class Initialized
INFO - 2020-02-04 05:28:45 --> Language Class Initialized
ERROR - 2020-02-04 05:28:45 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:28:58 --> Config Class Initialized
INFO - 2020-02-04 05:28:59 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:28:59 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:28:59 --> Utf8 Class Initialized
INFO - 2020-02-04 05:28:59 --> URI Class Initialized
INFO - 2020-02-04 05:28:59 --> Router Class Initialized
INFO - 2020-02-04 05:28:59 --> Output Class Initialized
INFO - 2020-02-04 05:28:59 --> Security Class Initialized
DEBUG - 2020-02-04 05:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:28:59 --> Input Class Initialized
INFO - 2020-02-04 05:29:00 --> Language Class Initialized
INFO - 2020-02-04 05:29:00 --> Loader Class Initialized
INFO - 2020-02-04 05:29:00 --> Helper loaded: url_helper
INFO - 2020-02-04 05:29:00 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:29:00 --> Controller Class Initialized
INFO - 2020-02-04 05:29:00 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:29:00 --> Helper loaded: form_helper
INFO - 2020-02-04 05:29:00 --> Form Validation Class Initialized
INFO - 2020-02-04 05:29:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:29:00 --> Final output sent to browser
DEBUG - 2020-02-04 05:29:00 --> Total execution time: 1.5378
INFO - 2020-02-04 05:29:00 --> Config Class Initialized
INFO - 2020-02-04 05:29:00 --> Config Class Initialized
INFO - 2020-02-04 05:29:00 --> Config Class Initialized
INFO - 2020-02-04 05:29:00 --> Config Class Initialized
INFO - 2020-02-04 05:29:00 --> Hooks Class Initialized
INFO - 2020-02-04 05:29:00 --> Hooks Class Initialized
INFO - 2020-02-04 05:29:00 --> Hooks Class Initialized
INFO - 2020-02-04 05:29:00 --> Hooks Class Initialized
INFO - 2020-02-04 05:29:00 --> Config Class Initialized
INFO - 2020-02-04 05:29:00 --> Config Class Initialized
INFO - 2020-02-04 05:29:00 --> Hooks Class Initialized
INFO - 2020-02-04 05:29:00 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:29:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:29:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:29:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:29:00 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:29:00 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:00 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:00 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:00 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:29:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:29:00 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:29:00 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:00 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:00 --> URI Class Initialized
INFO - 2020-02-04 05:29:00 --> URI Class Initialized
INFO - 2020-02-04 05:29:00 --> URI Class Initialized
INFO - 2020-02-04 05:29:00 --> URI Class Initialized
INFO - 2020-02-04 05:29:00 --> URI Class Initialized
INFO - 2020-02-04 05:29:00 --> Router Class Initialized
INFO - 2020-02-04 05:29:00 --> Router Class Initialized
INFO - 2020-02-04 05:29:00 --> URI Class Initialized
INFO - 2020-02-04 05:29:00 --> Router Class Initialized
INFO - 2020-02-04 05:29:00 --> Router Class Initialized
INFO - 2020-02-04 05:29:00 --> Router Class Initialized
INFO - 2020-02-04 05:29:00 --> Output Class Initialized
INFO - 2020-02-04 05:29:00 --> Output Class Initialized
INFO - 2020-02-04 05:29:00 --> Output Class Initialized
INFO - 2020-02-04 05:29:00 --> Router Class Initialized
INFO - 2020-02-04 05:29:00 --> Output Class Initialized
INFO - 2020-02-04 05:29:00 --> Security Class Initialized
INFO - 2020-02-04 05:29:00 --> Output Class Initialized
INFO - 2020-02-04 05:29:00 --> Output Class Initialized
INFO - 2020-02-04 05:29:00 --> Security Class Initialized
INFO - 2020-02-04 05:29:00 --> Security Class Initialized
INFO - 2020-02-04 05:29:00 --> Security Class Initialized
DEBUG - 2020-02-04 05:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:00 --> Security Class Initialized
INFO - 2020-02-04 05:29:00 --> Security Class Initialized
DEBUG - 2020-02-04 05:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:00 --> Input Class Initialized
INFO - 2020-02-04 05:29:00 --> Input Class Initialized
INFO - 2020-02-04 05:29:00 --> Input Class Initialized
INFO - 2020-02-04 05:29:00 --> Input Class Initialized
DEBUG - 2020-02-04 05:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:00 --> Language Class Initialized
INFO - 2020-02-04 05:29:00 --> Language Class Initialized
INFO - 2020-02-04 05:29:00 --> Language Class Initialized
INFO - 2020-02-04 05:29:00 --> Language Class Initialized
INFO - 2020-02-04 05:29:00 --> Input Class Initialized
INFO - 2020-02-04 05:29:00 --> Input Class Initialized
INFO - 2020-02-04 05:29:00 --> Language Class Initialized
INFO - 2020-02-04 05:29:00 --> Language Class Initialized
ERROR - 2020-02-04 05:29:00 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 05:29:00 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 05:29:00 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:29:00 --> Loader Class Initialized
ERROR - 2020-02-04 05:29:00 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:29:00 --> Helper loaded: url_helper
ERROR - 2020-02-04 05:29:00 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:29:00 --> Config Class Initialized
INFO - 2020-02-04 05:29:00 --> Config Class Initialized
INFO - 2020-02-04 05:29:00 --> Config Class Initialized
INFO - 2020-02-04 05:29:00 --> Hooks Class Initialized
INFO - 2020-02-04 05:29:00 --> Hooks Class Initialized
INFO - 2020-02-04 05:29:00 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:29:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:29:01 --> Database Driver Class Initialized
INFO - 2020-02-04 05:29:01 --> Config Class Initialized
INFO - 2020-02-04 05:29:01 --> Config Class Initialized
INFO - 2020-02-04 05:29:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:29:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:29:01 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:29:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:29:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:01 --> URI Class Initialized
DEBUG - 2020-02-04 05:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:29:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:29:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:01 --> Controller Class Initialized
INFO - 2020-02-04 05:29:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:01 --> URI Class Initialized
INFO - 2020-02-04 05:29:01 --> URI Class Initialized
INFO - 2020-02-04 05:29:01 --> Router Class Initialized
INFO - 2020-02-04 05:29:01 --> URI Class Initialized
INFO - 2020-02-04 05:29:01 --> Router Class Initialized
INFO - 2020-02-04 05:29:01 --> Router Class Initialized
INFO - 2020-02-04 05:29:01 --> Output Class Initialized
INFO - 2020-02-04 05:29:01 --> URI Class Initialized
INFO - 2020-02-04 05:29:01 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:29:01 --> Router Class Initialized
INFO - 2020-02-04 05:29:01 --> Router Class Initialized
INFO - 2020-02-04 05:29:01 --> Output Class Initialized
INFO - 2020-02-04 05:29:01 --> Security Class Initialized
INFO - 2020-02-04 05:29:01 --> Helper loaded: form_helper
INFO - 2020-02-04 05:29:01 --> Output Class Initialized
DEBUG - 2020-02-04 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:01 --> Security Class Initialized
INFO - 2020-02-04 05:29:01 --> Security Class Initialized
INFO - 2020-02-04 05:29:01 --> Output Class Initialized
INFO - 2020-02-04 05:29:01 --> Form Validation Class Initialized
INFO - 2020-02-04 05:29:01 --> Output Class Initialized
INFO - 2020-02-04 05:29:01 --> Input Class Initialized
DEBUG - 2020-02-04 05:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:01 --> Security Class Initialized
INFO - 2020-02-04 05:29:01 --> Security Class Initialized
ERROR - 2020-02-04 05:29:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:29:01 --> Input Class Initialized
INFO - 2020-02-04 05:29:01 --> Input Class Initialized
ERROR - 2020-02-04 05:29:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:29:01 --> Language Class Initialized
DEBUG - 2020-02-04 05:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:01 --> Input Class Initialized
INFO - 2020-02-04 05:29:01 --> Input Class Initialized
INFO - 2020-02-04 05:29:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-04 05:29:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:29:01 --> Language Class Initialized
INFO - 2020-02-04 05:29:01 --> Language Class Initialized
INFO - 2020-02-04 05:29:01 --> Final output sent to browser
INFO - 2020-02-04 05:29:01 --> Language Class Initialized
INFO - 2020-02-04 05:29:01 --> Language Class Initialized
ERROR - 2020-02-04 05:29:01 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-04 05:29:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:29:01 --> Config Class Initialized
INFO - 2020-02-04 05:29:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:29:01 --> Total execution time: 0.6965
ERROR - 2020-02-04 05:29:01 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 05:29:01 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:29:01 --> Config Class Initialized
INFO - 2020-02-04 05:29:01 --> Config Class Initialized
INFO - 2020-02-04 05:29:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:29:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:29:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:29:01 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:29:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:29:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:01 --> URI Class Initialized
INFO - 2020-02-04 05:29:01 --> URI Class Initialized
INFO - 2020-02-04 05:29:01 --> URI Class Initialized
INFO - 2020-02-04 05:29:01 --> Router Class Initialized
INFO - 2020-02-04 05:29:01 --> Router Class Initialized
INFO - 2020-02-04 05:29:01 --> Output Class Initialized
INFO - 2020-02-04 05:29:01 --> Router Class Initialized
INFO - 2020-02-04 05:29:01 --> Security Class Initialized
INFO - 2020-02-04 05:29:01 --> Output Class Initialized
INFO - 2020-02-04 05:29:01 --> Output Class Initialized
DEBUG - 2020-02-04 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:01 --> Security Class Initialized
INFO - 2020-02-04 05:29:01 --> Security Class Initialized
INFO - 2020-02-04 05:29:01 --> Input Class Initialized
DEBUG - 2020-02-04 05:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:01 --> Input Class Initialized
INFO - 2020-02-04 05:29:01 --> Input Class Initialized
INFO - 2020-02-04 05:29:01 --> Language Class Initialized
INFO - 2020-02-04 05:29:01 --> Language Class Initialized
INFO - 2020-02-04 05:29:01 --> Language Class Initialized
ERROR - 2020-02-04 05:29:01 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 05:29:01 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:29:01 --> Loader Class Initialized
INFO - 2020-02-04 05:29:01 --> Helper loaded: url_helper
INFO - 2020-02-04 05:29:01 --> Config Class Initialized
INFO - 2020-02-04 05:29:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:29:01 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:29:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:29:01 --> Controller Class Initialized
INFO - 2020-02-04 05:29:01 --> URI Class Initialized
INFO - 2020-02-04 05:29:01 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:29:01 --> Router Class Initialized
INFO - 2020-02-04 05:29:01 --> Output Class Initialized
INFO - 2020-02-04 05:29:01 --> Helper loaded: form_helper
INFO - 2020-02-04 05:29:01 --> Form Validation Class Initialized
INFO - 2020-02-04 05:29:01 --> Security Class Initialized
DEBUG - 2020-02-04 05:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 05:29:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:29:01 --> Input Class Initialized
ERROR - 2020-02-04 05:29:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:29:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:29:01 --> Language Class Initialized
INFO - 2020-02-04 05:29:01 --> Final output sent to browser
ERROR - 2020-02-04 05:29:01 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-04 05:29:02 --> Total execution time: 0.6349
INFO - 2020-02-04 05:29:02 --> Config Class Initialized
INFO - 2020-02-04 05:29:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:29:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:29:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:02 --> URI Class Initialized
INFO - 2020-02-04 05:29:02 --> Router Class Initialized
INFO - 2020-02-04 05:29:02 --> Output Class Initialized
INFO - 2020-02-04 05:29:02 --> Security Class Initialized
DEBUG - 2020-02-04 05:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:02 --> Input Class Initialized
INFO - 2020-02-04 05:29:02 --> Language Class Initialized
ERROR - 2020-02-04 05:29:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:29:02 --> Config Class Initialized
INFO - 2020-02-04 05:29:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:29:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:29:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:02 --> URI Class Initialized
INFO - 2020-02-04 05:29:02 --> Router Class Initialized
INFO - 2020-02-04 05:29:02 --> Output Class Initialized
INFO - 2020-02-04 05:29:02 --> Security Class Initialized
DEBUG - 2020-02-04 05:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:02 --> Input Class Initialized
INFO - 2020-02-04 05:29:02 --> Language Class Initialized
ERROR - 2020-02-04 05:29:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:29:02 --> Config Class Initialized
INFO - 2020-02-04 05:29:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:29:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:29:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:02 --> URI Class Initialized
INFO - 2020-02-04 05:29:02 --> Router Class Initialized
INFO - 2020-02-04 05:29:02 --> Output Class Initialized
INFO - 2020-02-04 05:29:02 --> Security Class Initialized
DEBUG - 2020-02-04 05:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:02 --> Input Class Initialized
INFO - 2020-02-04 05:29:02 --> Language Class Initialized
ERROR - 2020-02-04 05:29:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:29:02 --> Config Class Initialized
INFO - 2020-02-04 05:29:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:29:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:29:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:03 --> URI Class Initialized
INFO - 2020-02-04 05:29:03 --> Router Class Initialized
INFO - 2020-02-04 05:29:03 --> Output Class Initialized
INFO - 2020-02-04 05:29:03 --> Security Class Initialized
DEBUG - 2020-02-04 05:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:03 --> Input Class Initialized
INFO - 2020-02-04 05:29:03 --> Language Class Initialized
ERROR - 2020-02-04 05:29:03 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:29:03 --> Config Class Initialized
INFO - 2020-02-04 05:29:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:29:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:29:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:03 --> URI Class Initialized
INFO - 2020-02-04 05:29:03 --> Router Class Initialized
INFO - 2020-02-04 05:29:03 --> Output Class Initialized
INFO - 2020-02-04 05:29:03 --> Security Class Initialized
DEBUG - 2020-02-04 05:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:03 --> Input Class Initialized
INFO - 2020-02-04 05:29:03 --> Language Class Initialized
ERROR - 2020-02-04 05:29:03 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:29:03 --> Config Class Initialized
INFO - 2020-02-04 05:29:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:29:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:29:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:03 --> URI Class Initialized
INFO - 2020-02-04 05:29:03 --> Router Class Initialized
INFO - 2020-02-04 05:29:03 --> Output Class Initialized
INFO - 2020-02-04 05:29:03 --> Security Class Initialized
DEBUG - 2020-02-04 05:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:04 --> Input Class Initialized
INFO - 2020-02-04 05:29:04 --> Language Class Initialized
ERROR - 2020-02-04 05:29:04 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:29:04 --> Config Class Initialized
INFO - 2020-02-04 05:29:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:29:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:29:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:29:04 --> URI Class Initialized
INFO - 2020-02-04 05:29:04 --> Router Class Initialized
INFO - 2020-02-04 05:29:04 --> Output Class Initialized
INFO - 2020-02-04 05:29:04 --> Security Class Initialized
DEBUG - 2020-02-04 05:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:29:04 --> Input Class Initialized
INFO - 2020-02-04 05:29:04 --> Language Class Initialized
ERROR - 2020-02-04 05:29:04 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:30:46 --> Config Class Initialized
INFO - 2020-02-04 05:30:46 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:30:46 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:46 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:46 --> URI Class Initialized
INFO - 2020-02-04 05:30:46 --> Router Class Initialized
INFO - 2020-02-04 05:30:46 --> Output Class Initialized
INFO - 2020-02-04 05:30:46 --> Security Class Initialized
DEBUG - 2020-02-04 05:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:46 --> Input Class Initialized
INFO - 2020-02-04 05:30:46 --> Language Class Initialized
INFO - 2020-02-04 05:30:46 --> Loader Class Initialized
INFO - 2020-02-04 05:30:46 --> Helper loaded: url_helper
INFO - 2020-02-04 05:30:46 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:30:46 --> Controller Class Initialized
INFO - 2020-02-04 05:30:46 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:30:46 --> Helper loaded: form_helper
INFO - 2020-02-04 05:30:46 --> Form Validation Class Initialized
INFO - 2020-02-04 05:30:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:30:47 --> Final output sent to browser
DEBUG - 2020-02-04 05:30:47 --> Total execution time: 1.1485
INFO - 2020-02-04 05:30:47 --> Config Class Initialized
INFO - 2020-02-04 05:30:47 --> Config Class Initialized
INFO - 2020-02-04 05:30:47 --> Config Class Initialized
INFO - 2020-02-04 05:30:47 --> Config Class Initialized
INFO - 2020-02-04 05:30:47 --> Hooks Class Initialized
INFO - 2020-02-04 05:30:47 --> Hooks Class Initialized
INFO - 2020-02-04 05:30:47 --> Hooks Class Initialized
INFO - 2020-02-04 05:30:47 --> Config Class Initialized
INFO - 2020-02-04 05:30:47 --> Hooks Class Initialized
INFO - 2020-02-04 05:30:47 --> Config Class Initialized
INFO - 2020-02-04 05:30:47 --> Hooks Class Initialized
INFO - 2020-02-04 05:30:47 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:30:47 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:47 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:47 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:47 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:47 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:30:47 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:47 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:47 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:47 --> URI Class Initialized
INFO - 2020-02-04 05:30:47 --> URI Class Initialized
INFO - 2020-02-04 05:30:47 --> URI Class Initialized
INFO - 2020-02-04 05:30:47 --> URI Class Initialized
INFO - 2020-02-04 05:30:47 --> URI Class Initialized
INFO - 2020-02-04 05:30:47 --> Router Class Initialized
INFO - 2020-02-04 05:30:47 --> URI Class Initialized
INFO - 2020-02-04 05:30:47 --> Router Class Initialized
INFO - 2020-02-04 05:30:47 --> Router Class Initialized
INFO - 2020-02-04 05:30:47 --> Output Class Initialized
INFO - 2020-02-04 05:30:47 --> Router Class Initialized
INFO - 2020-02-04 05:30:47 --> Router Class Initialized
INFO - 2020-02-04 05:30:47 --> Output Class Initialized
INFO - 2020-02-04 05:30:47 --> Output Class Initialized
INFO - 2020-02-04 05:30:47 --> Security Class Initialized
INFO - 2020-02-04 05:30:47 --> Output Class Initialized
INFO - 2020-02-04 05:30:47 --> Router Class Initialized
INFO - 2020-02-04 05:30:47 --> Output Class Initialized
INFO - 2020-02-04 05:30:47 --> Security Class Initialized
INFO - 2020-02-04 05:30:47 --> Security Class Initialized
INFO - 2020-02-04 05:30:47 --> Security Class Initialized
INFO - 2020-02-04 05:30:47 --> Output Class Initialized
INFO - 2020-02-04 05:30:47 --> Security Class Initialized
DEBUG - 2020-02-04 05:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:47 --> Input Class Initialized
DEBUG - 2020-02-04 05:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:47 --> Security Class Initialized
INFO - 2020-02-04 05:30:47 --> Input Class Initialized
INFO - 2020-02-04 05:30:47 --> Input Class Initialized
INFO - 2020-02-04 05:30:47 --> Input Class Initialized
INFO - 2020-02-04 05:30:47 --> Input Class Initialized
DEBUG - 2020-02-04 05:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:47 --> Language Class Initialized
INFO - 2020-02-04 05:30:47 --> Input Class Initialized
INFO - 2020-02-04 05:30:47 --> Language Class Initialized
INFO - 2020-02-04 05:30:47 --> Language Class Initialized
INFO - 2020-02-04 05:30:47 --> Language Class Initialized
INFO - 2020-02-04 05:30:47 --> Language Class Initialized
INFO - 2020-02-04 05:30:47 --> Loader Class Initialized
INFO - 2020-02-04 05:30:47 --> Helper loaded: url_helper
INFO - 2020-02-04 05:30:47 --> Language Class Initialized
ERROR - 2020-02-04 05:30:47 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 05:30:47 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 05:30:47 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 05:30:47 --> Loader Class Initialized
ERROR - 2020-02-04 05:30:47 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:30:47 --> Helper loaded: url_helper
INFO - 2020-02-04 05:30:47 --> Config Class Initialized
INFO - 2020-02-04 05:30:47 --> Database Driver Class Initialized
INFO - 2020-02-04 05:30:47 --> Config Class Initialized
INFO - 2020-02-04 05:30:47 --> Config Class Initialized
INFO - 2020-02-04 05:30:47 --> Hooks Class Initialized
INFO - 2020-02-04 05:30:47 --> Hooks Class Initialized
INFO - 2020-02-04 05:30:47 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:30:47 --> Database Driver Class Initialized
INFO - 2020-02-04 05:30:47 --> Config Class Initialized
INFO - 2020-02-04 05:30:47 --> Hooks Class Initialized
INFO - 2020-02-04 05:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:30:47 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:30:47 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:47 --> Controller Class Initialized
INFO - 2020-02-04 05:30:47 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:47 --> URI Class Initialized
DEBUG - 2020-02-04 05:30:47 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:47 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:47 --> URI Class Initialized
INFO - 2020-02-04 05:30:47 --> Router Class Initialized
INFO - 2020-02-04 05:30:47 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:30:47 --> URI Class Initialized
INFO - 2020-02-04 05:30:47 --> URI Class Initialized
INFO - 2020-02-04 05:30:47 --> Router Class Initialized
INFO - 2020-02-04 05:30:47 --> Output Class Initialized
INFO - 2020-02-04 05:30:47 --> Router Class Initialized
INFO - 2020-02-04 05:30:47 --> Helper loaded: form_helper
INFO - 2020-02-04 05:30:47 --> Form Validation Class Initialized
INFO - 2020-02-04 05:30:47 --> Security Class Initialized
INFO - 2020-02-04 05:30:47 --> Router Class Initialized
INFO - 2020-02-04 05:30:47 --> Output Class Initialized
INFO - 2020-02-04 05:30:47 --> Output Class Initialized
DEBUG - 2020-02-04 05:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:47 --> Output Class Initialized
INFO - 2020-02-04 05:30:47 --> Security Class Initialized
ERROR - 2020-02-04 05:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:30:47 --> Security Class Initialized
INFO - 2020-02-04 05:30:47 --> Input Class Initialized
ERROR - 2020-02-04 05:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-04 05:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:47 --> Security Class Initialized
DEBUG - 2020-02-04 05:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:47 --> Input Class Initialized
INFO - 2020-02-04 05:30:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:30:47 --> Input Class Initialized
INFO - 2020-02-04 05:30:47 --> Language Class Initialized
DEBUG - 2020-02-04 05:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:47 --> Input Class Initialized
INFO - 2020-02-04 05:30:47 --> Final output sent to browser
INFO - 2020-02-04 05:30:47 --> Language Class Initialized
INFO - 2020-02-04 05:30:47 --> Language Class Initialized
ERROR - 2020-02-04 05:30:47 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-04 05:30:47 --> Total execution time: 0.7113
INFO - 2020-02-04 05:30:47 --> Language Class Initialized
ERROR - 2020-02-04 05:30:47 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 05:30:47 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:30:48 --> Config Class Initialized
INFO - 2020-02-04 05:30:48 --> Hooks Class Initialized
INFO - 2020-02-04 05:30:48 --> Session: Class initialized using 'files' driver.
ERROR - 2020-02-04 05:30:48 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:30:48 --> Config Class Initialized
INFO - 2020-02-04 05:30:48 --> Config Class Initialized
INFO - 2020-02-04 05:30:48 --> Config Class Initialized
INFO - 2020-02-04 05:30:48 --> Hooks Class Initialized
INFO - 2020-02-04 05:30:48 --> Hooks Class Initialized
INFO - 2020-02-04 05:30:48 --> Hooks Class Initialized
INFO - 2020-02-04 05:30:48 --> Controller Class Initialized
DEBUG - 2020-02-04 05:30:48 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:48 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:48 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 05:30:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:30:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:30:48 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:48 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:48 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:48 --> URI Class Initialized
INFO - 2020-02-04 05:30:48 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:48 --> Helper loaded: form_helper
INFO - 2020-02-04 05:30:48 --> Form Validation Class Initialized
INFO - 2020-02-04 05:30:48 --> URI Class Initialized
INFO - 2020-02-04 05:30:48 --> URI Class Initialized
INFO - 2020-02-04 05:30:48 --> Router Class Initialized
INFO - 2020-02-04 05:30:48 --> URI Class Initialized
INFO - 2020-02-04 05:30:48 --> Router Class Initialized
INFO - 2020-02-04 05:30:48 --> Router Class Initialized
INFO - 2020-02-04 05:30:48 --> Output Class Initialized
ERROR - 2020-02-04 05:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:30:48 --> Router Class Initialized
ERROR - 2020-02-04 05:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:30:48 --> Security Class Initialized
INFO - 2020-02-04 05:30:48 --> Output Class Initialized
INFO - 2020-02-04 05:30:48 --> Output Class Initialized
INFO - 2020-02-04 05:30:48 --> Output Class Initialized
INFO - 2020-02-04 05:30:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:30:48 --> Security Class Initialized
DEBUG - 2020-02-04 05:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:48 --> Security Class Initialized
INFO - 2020-02-04 05:30:48 --> Security Class Initialized
INFO - 2020-02-04 05:30:48 --> Input Class Initialized
INFO - 2020-02-04 05:30:48 --> Final output sent to browser
DEBUG - 2020-02-04 05:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:48 --> Input Class Initialized
INFO - 2020-02-04 05:30:48 --> Input Class Initialized
DEBUG - 2020-02-04 05:30:48 --> Total execution time: 0.9857
INFO - 2020-02-04 05:30:48 --> Input Class Initialized
INFO - 2020-02-04 05:30:48 --> Language Class Initialized
INFO - 2020-02-04 05:30:48 --> Language Class Initialized
INFO - 2020-02-04 05:30:48 --> Language Class Initialized
INFO - 2020-02-04 05:30:48 --> Language Class Initialized
ERROR - 2020-02-04 05:30:48 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-04 05:30:48 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 05:30:48 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 05:30:48 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 05:30:48 --> Config Class Initialized
INFO - 2020-02-04 05:30:48 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:30:48 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:48 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:48 --> URI Class Initialized
INFO - 2020-02-04 05:30:48 --> Router Class Initialized
INFO - 2020-02-04 05:30:48 --> Output Class Initialized
INFO - 2020-02-04 05:30:48 --> Security Class Initialized
DEBUG - 2020-02-04 05:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:48 --> Input Class Initialized
INFO - 2020-02-04 05:30:48 --> Language Class Initialized
ERROR - 2020-02-04 05:30:48 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:30:48 --> Config Class Initialized
INFO - 2020-02-04 05:30:48 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:30:48 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:48 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:48 --> URI Class Initialized
INFO - 2020-02-04 05:30:48 --> Router Class Initialized
INFO - 2020-02-04 05:30:48 --> Output Class Initialized
INFO - 2020-02-04 05:30:48 --> Security Class Initialized
DEBUG - 2020-02-04 05:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:48 --> Input Class Initialized
INFO - 2020-02-04 05:30:48 --> Language Class Initialized
ERROR - 2020-02-04 05:30:48 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:30:49 --> Config Class Initialized
INFO - 2020-02-04 05:30:49 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:30:49 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:49 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:49 --> URI Class Initialized
INFO - 2020-02-04 05:30:49 --> Router Class Initialized
INFO - 2020-02-04 05:30:49 --> Output Class Initialized
INFO - 2020-02-04 05:30:49 --> Security Class Initialized
DEBUG - 2020-02-04 05:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:49 --> Input Class Initialized
INFO - 2020-02-04 05:30:49 --> Language Class Initialized
ERROR - 2020-02-04 05:30:49 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:30:49 --> Config Class Initialized
INFO - 2020-02-04 05:30:49 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:30:49 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:49 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:49 --> URI Class Initialized
INFO - 2020-02-04 05:30:49 --> Router Class Initialized
INFO - 2020-02-04 05:30:49 --> Output Class Initialized
INFO - 2020-02-04 05:30:49 --> Security Class Initialized
DEBUG - 2020-02-04 05:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:49 --> Input Class Initialized
INFO - 2020-02-04 05:30:49 --> Language Class Initialized
ERROR - 2020-02-04 05:30:49 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:30:49 --> Config Class Initialized
INFO - 2020-02-04 05:30:49 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:30:49 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:49 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:49 --> URI Class Initialized
INFO - 2020-02-04 05:30:49 --> Router Class Initialized
INFO - 2020-02-04 05:30:49 --> Output Class Initialized
INFO - 2020-02-04 05:30:49 --> Security Class Initialized
DEBUG - 2020-02-04 05:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:49 --> Input Class Initialized
INFO - 2020-02-04 05:30:49 --> Language Class Initialized
ERROR - 2020-02-04 05:30:49 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:30:50 --> Config Class Initialized
INFO - 2020-02-04 05:30:50 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:30:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:50 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:50 --> URI Class Initialized
INFO - 2020-02-04 05:30:50 --> Router Class Initialized
INFO - 2020-02-04 05:30:50 --> Output Class Initialized
INFO - 2020-02-04 05:30:50 --> Security Class Initialized
DEBUG - 2020-02-04 05:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:50 --> Input Class Initialized
INFO - 2020-02-04 05:30:50 --> Language Class Initialized
ERROR - 2020-02-04 05:30:50 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:30:50 --> Config Class Initialized
INFO - 2020-02-04 05:30:50 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:30:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:50 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:50 --> URI Class Initialized
INFO - 2020-02-04 05:30:50 --> Router Class Initialized
INFO - 2020-02-04 05:30:50 --> Output Class Initialized
INFO - 2020-02-04 05:30:50 --> Security Class Initialized
DEBUG - 2020-02-04 05:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:50 --> Input Class Initialized
INFO - 2020-02-04 05:30:50 --> Language Class Initialized
ERROR - 2020-02-04 05:30:50 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:30:50 --> Config Class Initialized
INFO - 2020-02-04 05:30:50 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:30:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:50 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:50 --> URI Class Initialized
INFO - 2020-02-04 05:30:50 --> Router Class Initialized
INFO - 2020-02-04 05:30:50 --> Output Class Initialized
INFO - 2020-02-04 05:30:50 --> Security Class Initialized
DEBUG - 2020-02-04 05:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:50 --> Input Class Initialized
INFO - 2020-02-04 05:30:50 --> Language Class Initialized
ERROR - 2020-02-04 05:30:50 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:30:50 --> Config Class Initialized
INFO - 2020-02-04 05:30:51 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:30:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:30:51 --> Utf8 Class Initialized
INFO - 2020-02-04 05:30:51 --> URI Class Initialized
INFO - 2020-02-04 05:30:51 --> Router Class Initialized
INFO - 2020-02-04 05:30:51 --> Output Class Initialized
INFO - 2020-02-04 05:30:51 --> Security Class Initialized
DEBUG - 2020-02-04 05:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:30:51 --> Input Class Initialized
INFO - 2020-02-04 05:30:51 --> Language Class Initialized
ERROR - 2020-02-04 05:30:51 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:31:56 --> Config Class Initialized
INFO - 2020-02-04 05:31:56 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:31:56 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:31:57 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:57 --> URI Class Initialized
INFO - 2020-02-04 05:31:57 --> Router Class Initialized
INFO - 2020-02-04 05:31:57 --> Output Class Initialized
INFO - 2020-02-04 05:31:57 --> Security Class Initialized
DEBUG - 2020-02-04 05:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:57 --> Input Class Initialized
INFO - 2020-02-04 05:31:57 --> Language Class Initialized
INFO - 2020-02-04 05:31:57 --> Loader Class Initialized
INFO - 2020-02-04 05:31:57 --> Helper loaded: url_helper
INFO - 2020-02-04 05:31:57 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:31:57 --> Controller Class Initialized
INFO - 2020-02-04 05:31:57 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:31:57 --> Helper loaded: form_helper
INFO - 2020-02-04 05:31:57 --> Form Validation Class Initialized
INFO - 2020-02-04 05:31:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:31:57 --> Final output sent to browser
INFO - 2020-02-04 05:31:57 --> Config Class Initialized
INFO - 2020-02-04 05:31:57 --> Config Class Initialized
INFO - 2020-02-04 05:31:57 --> Config Class Initialized
INFO - 2020-02-04 05:31:57 --> Hooks Class Initialized
INFO - 2020-02-04 05:31:57 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:31:57 --> Total execution time: 0.5987
INFO - 2020-02-04 05:31:57 --> Hooks Class Initialized
INFO - 2020-02-04 05:31:57 --> Config Class Initialized
INFO - 2020-02-04 05:31:57 --> Config Class Initialized
INFO - 2020-02-04 05:31:57 --> Hooks Class Initialized
INFO - 2020-02-04 05:31:57 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:31:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:31:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:31:57 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:31:57 --> Config Class Initialized
INFO - 2020-02-04 05:31:57 --> Hooks Class Initialized
INFO - 2020-02-04 05:31:57 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:57 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:57 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:31:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:31:57 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:31:57 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:57 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:57 --> URI Class Initialized
DEBUG - 2020-02-04 05:31:57 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:31:57 --> URI Class Initialized
INFO - 2020-02-04 05:31:57 --> URI Class Initialized
INFO - 2020-02-04 05:31:57 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:57 --> URI Class Initialized
INFO - 2020-02-04 05:31:57 --> URI Class Initialized
INFO - 2020-02-04 05:31:57 --> Router Class Initialized
INFO - 2020-02-04 05:31:57 --> Router Class Initialized
INFO - 2020-02-04 05:31:57 --> Router Class Initialized
INFO - 2020-02-04 05:31:57 --> URI Class Initialized
INFO - 2020-02-04 05:31:57 --> Output Class Initialized
INFO - 2020-02-04 05:31:57 --> Router Class Initialized
INFO - 2020-02-04 05:31:57 --> Output Class Initialized
INFO - 2020-02-04 05:31:57 --> Router Class Initialized
INFO - 2020-02-04 05:31:57 --> Output Class Initialized
INFO - 2020-02-04 05:31:57 --> Output Class Initialized
INFO - 2020-02-04 05:31:57 --> Output Class Initialized
INFO - 2020-02-04 05:31:57 --> Security Class Initialized
INFO - 2020-02-04 05:31:57 --> Security Class Initialized
INFO - 2020-02-04 05:31:57 --> Router Class Initialized
INFO - 2020-02-04 05:31:57 --> Security Class Initialized
DEBUG - 2020-02-04 05:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:57 --> Output Class Initialized
INFO - 2020-02-04 05:31:57 --> Security Class Initialized
INFO - 2020-02-04 05:31:57 --> Security Class Initialized
DEBUG - 2020-02-04 05:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:57 --> Input Class Initialized
INFO - 2020-02-04 05:31:57 --> Input Class Initialized
INFO - 2020-02-04 05:31:57 --> Input Class Initialized
DEBUG - 2020-02-04 05:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:57 --> Security Class Initialized
DEBUG - 2020-02-04 05:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:57 --> Input Class Initialized
INFO - 2020-02-04 05:31:57 --> Language Class Initialized
INFO - 2020-02-04 05:31:57 --> Language Class Initialized
INFO - 2020-02-04 05:31:57 --> Input Class Initialized
INFO - 2020-02-04 05:31:57 --> Language Class Initialized
DEBUG - 2020-02-04 05:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:57 --> Input Class Initialized
INFO - 2020-02-04 05:31:57 --> Language Class Initialized
INFO - 2020-02-04 05:31:57 --> Language Class Initialized
ERROR - 2020-02-04 05:31:57 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 05:31:57 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 05:31:57 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 05:31:57 --> Language Class Initialized
ERROR - 2020-02-04 05:31:57 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 05:31:57 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 05:31:57 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:31:58 --> Config Class Initialized
INFO - 2020-02-04 05:31:58 --> Config Class Initialized
INFO - 2020-02-04 05:31:58 --> Config Class Initialized
INFO - 2020-02-04 05:31:58 --> Hooks Class Initialized
INFO - 2020-02-04 05:31:58 --> Hooks Class Initialized
INFO - 2020-02-04 05:31:58 --> Hooks Class Initialized
INFO - 2020-02-04 05:31:58 --> Config Class Initialized
INFO - 2020-02-04 05:31:58 --> Config Class Initialized
INFO - 2020-02-04 05:31:58 --> Config Class Initialized
INFO - 2020-02-04 05:31:58 --> Hooks Class Initialized
INFO - 2020-02-04 05:31:58 --> Hooks Class Initialized
INFO - 2020-02-04 05:31:58 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:31:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:31:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:31:58 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:31:58 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:58 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:31:58 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:31:58 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:31:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:31:58 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:31:58 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:58 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:58 --> URI Class Initialized
INFO - 2020-02-04 05:31:58 --> URI Class Initialized
INFO - 2020-02-04 05:31:58 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:58 --> URI Class Initialized
INFO - 2020-02-04 05:31:58 --> URI Class Initialized
INFO - 2020-02-04 05:31:58 --> URI Class Initialized
INFO - 2020-02-04 05:31:58 --> Router Class Initialized
INFO - 2020-02-04 05:31:58 --> Router Class Initialized
INFO - 2020-02-04 05:31:58 --> URI Class Initialized
INFO - 2020-02-04 05:31:58 --> Router Class Initialized
INFO - 2020-02-04 05:31:58 --> Router Class Initialized
INFO - 2020-02-04 05:31:58 --> Output Class Initialized
INFO - 2020-02-04 05:31:58 --> Router Class Initialized
INFO - 2020-02-04 05:31:58 --> Output Class Initialized
INFO - 2020-02-04 05:31:58 --> Router Class Initialized
INFO - 2020-02-04 05:31:58 --> Output Class Initialized
INFO - 2020-02-04 05:31:58 --> Security Class Initialized
INFO - 2020-02-04 05:31:58 --> Security Class Initialized
INFO - 2020-02-04 05:31:58 --> Security Class Initialized
INFO - 2020-02-04 05:31:58 --> Output Class Initialized
INFO - 2020-02-04 05:31:58 --> Output Class Initialized
INFO - 2020-02-04 05:31:58 --> Output Class Initialized
DEBUG - 2020-02-04 05:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:58 --> Security Class Initialized
INFO - 2020-02-04 05:31:58 --> Security Class Initialized
INFO - 2020-02-04 05:31:58 --> Security Class Initialized
DEBUG - 2020-02-04 05:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:58 --> Input Class Initialized
INFO - 2020-02-04 05:31:58 --> Input Class Initialized
DEBUG - 2020-02-04 05:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:58 --> Input Class Initialized
INFO - 2020-02-04 05:31:58 --> Input Class Initialized
INFO - 2020-02-04 05:31:58 --> Input Class Initialized
INFO - 2020-02-04 05:31:58 --> Language Class Initialized
INFO - 2020-02-04 05:31:58 --> Input Class Initialized
INFO - 2020-02-04 05:31:58 --> Language Class Initialized
INFO - 2020-02-04 05:31:58 --> Language Class Initialized
INFO - 2020-02-04 05:31:58 --> Language Class Initialized
ERROR - 2020-02-04 05:31:58 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:31:58 --> Loader Class Initialized
INFO - 2020-02-04 05:31:58 --> Loader Class Initialized
INFO - 2020-02-04 05:31:58 --> Language Class Initialized
INFO - 2020-02-04 05:31:58 --> Language Class Initialized
ERROR - 2020-02-04 05:31:58 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:31:58 --> Helper loaded: url_helper
ERROR - 2020-02-04 05:31:58 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:31:58 --> Helper loaded: url_helper
ERROR - 2020-02-04 05:31:58 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:31:58 --> Config Class Initialized
INFO - 2020-02-04 05:31:58 --> Hooks Class Initialized
INFO - 2020-02-04 05:31:58 --> Database Driver Class Initialized
INFO - 2020-02-04 05:31:58 --> Database Driver Class Initialized
INFO - 2020-02-04 05:31:58 --> Config Class Initialized
INFO - 2020-02-04 05:31:58 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:31:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 05:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:31:58 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 05:31:58 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:31:58 --> Controller Class Initialized
INFO - 2020-02-04 05:31:58 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:58 --> URI Class Initialized
INFO - 2020-02-04 05:31:58 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:31:58 --> Router Class Initialized
INFO - 2020-02-04 05:31:58 --> URI Class Initialized
INFO - 2020-02-04 05:31:58 --> Router Class Initialized
INFO - 2020-02-04 05:31:58 --> Output Class Initialized
INFO - 2020-02-04 05:31:58 --> Helper loaded: form_helper
INFO - 2020-02-04 05:31:58 --> Form Validation Class Initialized
INFO - 2020-02-04 05:31:58 --> Security Class Initialized
INFO - 2020-02-04 05:31:58 --> Output Class Initialized
DEBUG - 2020-02-04 05:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:58 --> Security Class Initialized
ERROR - 2020-02-04 05:31:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:31:58 --> Input Class Initialized
ERROR - 2020-02-04 05:31:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-04 05:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:58 --> Input Class Initialized
INFO - 2020-02-04 05:31:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:31:58 --> Language Class Initialized
INFO - 2020-02-04 05:31:58 --> Final output sent to browser
ERROR - 2020-02-04 05:31:58 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:31:58 --> Language Class Initialized
DEBUG - 2020-02-04 05:31:58 --> Total execution time: 0.7213
ERROR - 2020-02-04 05:31:58 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 05:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:31:58 --> Config Class Initialized
INFO - 2020-02-04 05:31:58 --> Hooks Class Initialized
INFO - 2020-02-04 05:31:58 --> Controller Class Initialized
INFO - 2020-02-04 05:31:58 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 05:31:58 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:31:58 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:58 --> Helper loaded: form_helper
INFO - 2020-02-04 05:31:58 --> Form Validation Class Initialized
INFO - 2020-02-04 05:31:58 --> URI Class Initialized
INFO - 2020-02-04 05:31:58 --> Router Class Initialized
ERROR - 2020-02-04 05:31:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 05:31:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:31:58 --> Output Class Initialized
INFO - 2020-02-04 05:31:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:31:58 --> Security Class Initialized
INFO - 2020-02-04 05:31:58 --> Final output sent to browser
DEBUG - 2020-02-04 05:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:59 --> Input Class Initialized
DEBUG - 2020-02-04 05:31:59 --> Total execution time: 1.0001
INFO - 2020-02-04 05:31:59 --> Language Class Initialized
ERROR - 2020-02-04 05:31:59 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:31:59 --> Config Class Initialized
INFO - 2020-02-04 05:31:59 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:31:59 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:31:59 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:59 --> URI Class Initialized
INFO - 2020-02-04 05:31:59 --> Router Class Initialized
INFO - 2020-02-04 05:31:59 --> Output Class Initialized
INFO - 2020-02-04 05:31:59 --> Security Class Initialized
DEBUG - 2020-02-04 05:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:59 --> Input Class Initialized
INFO - 2020-02-04 05:31:59 --> Language Class Initialized
ERROR - 2020-02-04 05:31:59 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:31:59 --> Config Class Initialized
INFO - 2020-02-04 05:31:59 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:31:59 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:31:59 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:59 --> URI Class Initialized
INFO - 2020-02-04 05:31:59 --> Router Class Initialized
INFO - 2020-02-04 05:31:59 --> Output Class Initialized
INFO - 2020-02-04 05:31:59 --> Security Class Initialized
DEBUG - 2020-02-04 05:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:31:59 --> Input Class Initialized
INFO - 2020-02-04 05:31:59 --> Language Class Initialized
ERROR - 2020-02-04 05:31:59 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:31:59 --> Config Class Initialized
INFO - 2020-02-04 05:31:59 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:31:59 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:31:59 --> Utf8 Class Initialized
INFO - 2020-02-04 05:31:59 --> URI Class Initialized
INFO - 2020-02-04 05:31:59 --> Router Class Initialized
INFO - 2020-02-04 05:32:00 --> Output Class Initialized
INFO - 2020-02-04 05:32:00 --> Security Class Initialized
DEBUG - 2020-02-04 05:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:32:00 --> Input Class Initialized
INFO - 2020-02-04 05:32:00 --> Language Class Initialized
ERROR - 2020-02-04 05:32:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:32:00 --> Config Class Initialized
INFO - 2020-02-04 05:32:00 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:32:00 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:32:00 --> Utf8 Class Initialized
INFO - 2020-02-04 05:32:00 --> URI Class Initialized
INFO - 2020-02-04 05:32:00 --> Router Class Initialized
INFO - 2020-02-04 05:32:00 --> Output Class Initialized
INFO - 2020-02-04 05:32:00 --> Security Class Initialized
DEBUG - 2020-02-04 05:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:32:00 --> Input Class Initialized
INFO - 2020-02-04 05:32:00 --> Language Class Initialized
ERROR - 2020-02-04 05:32:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:32:00 --> Config Class Initialized
INFO - 2020-02-04 05:32:00 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:32:00 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:32:00 --> Utf8 Class Initialized
INFO - 2020-02-04 05:32:00 --> URI Class Initialized
INFO - 2020-02-04 05:32:00 --> Router Class Initialized
INFO - 2020-02-04 05:32:00 --> Output Class Initialized
INFO - 2020-02-04 05:32:00 --> Security Class Initialized
DEBUG - 2020-02-04 05:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:32:00 --> Input Class Initialized
INFO - 2020-02-04 05:32:00 --> Language Class Initialized
ERROR - 2020-02-04 05:32:00 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:32:00 --> Config Class Initialized
INFO - 2020-02-04 05:32:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:32:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:32:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:32:01 --> URI Class Initialized
INFO - 2020-02-04 05:32:01 --> Router Class Initialized
INFO - 2020-02-04 05:32:01 --> Output Class Initialized
INFO - 2020-02-04 05:32:01 --> Security Class Initialized
DEBUG - 2020-02-04 05:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:32:01 --> Input Class Initialized
INFO - 2020-02-04 05:32:01 --> Language Class Initialized
ERROR - 2020-02-04 05:32:01 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:32:01 --> Config Class Initialized
INFO - 2020-02-04 05:32:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:32:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:32:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:32:01 --> URI Class Initialized
INFO - 2020-02-04 05:32:01 --> Router Class Initialized
INFO - 2020-02-04 05:32:01 --> Output Class Initialized
INFO - 2020-02-04 05:32:01 --> Security Class Initialized
DEBUG - 2020-02-04 05:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:32:01 --> Input Class Initialized
INFO - 2020-02-04 05:32:01 --> Language Class Initialized
ERROR - 2020-02-04 05:32:01 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:32:01 --> Config Class Initialized
INFO - 2020-02-04 05:32:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:32:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:32:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:32:01 --> URI Class Initialized
INFO - 2020-02-04 05:32:01 --> Router Class Initialized
INFO - 2020-02-04 05:32:01 --> Output Class Initialized
INFO - 2020-02-04 05:32:01 --> Security Class Initialized
DEBUG - 2020-02-04 05:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:32:01 --> Input Class Initialized
INFO - 2020-02-04 05:32:01 --> Language Class Initialized
ERROR - 2020-02-04 05:32:01 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:34:04 --> Config Class Initialized
INFO - 2020-02-04 05:34:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:34:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:34:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:04 --> URI Class Initialized
INFO - 2020-02-04 05:34:04 --> Router Class Initialized
INFO - 2020-02-04 05:34:04 --> Output Class Initialized
INFO - 2020-02-04 05:34:04 --> Security Class Initialized
DEBUG - 2020-02-04 05:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:04 --> Input Class Initialized
INFO - 2020-02-04 05:34:04 --> Language Class Initialized
INFO - 2020-02-04 05:34:04 --> Loader Class Initialized
INFO - 2020-02-04 05:34:04 --> Helper loaded: url_helper
INFO - 2020-02-04 05:34:04 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:34:04 --> Controller Class Initialized
INFO - 2020-02-04 05:34:04 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:34:04 --> Helper loaded: form_helper
INFO - 2020-02-04 05:34:04 --> Form Validation Class Initialized
INFO - 2020-02-04 05:34:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:34:04 --> Final output sent to browser
DEBUG - 2020-02-04 05:34:04 --> Total execution time: 0.6732
INFO - 2020-02-04 05:34:04 --> Config Class Initialized
INFO - 2020-02-04 05:34:04 --> Config Class Initialized
INFO - 2020-02-04 05:34:04 --> Config Class Initialized
INFO - 2020-02-04 05:34:04 --> Config Class Initialized
INFO - 2020-02-04 05:34:04 --> Hooks Class Initialized
INFO - 2020-02-04 05:34:04 --> Hooks Class Initialized
INFO - 2020-02-04 05:34:04 --> Hooks Class Initialized
INFO - 2020-02-04 05:34:04 --> Hooks Class Initialized
INFO - 2020-02-04 05:34:04 --> Config Class Initialized
INFO - 2020-02-04 05:34:04 --> Config Class Initialized
INFO - 2020-02-04 05:34:04 --> Hooks Class Initialized
INFO - 2020-02-04 05:34:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:34:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:34:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:34:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:34:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:34:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:04 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:34:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:34:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:34:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:04 --> URI Class Initialized
INFO - 2020-02-04 05:34:04 --> URI Class Initialized
INFO - 2020-02-04 05:34:04 --> URI Class Initialized
INFO - 2020-02-04 05:34:04 --> URI Class Initialized
INFO - 2020-02-04 05:34:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:05 --> URI Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
INFO - 2020-02-04 05:34:05 --> URI Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:05 --> Input Class Initialized
INFO - 2020-02-04 05:34:05 --> Input Class Initialized
INFO - 2020-02-04 05:34:05 --> Input Class Initialized
INFO - 2020-02-04 05:34:05 --> Input Class Initialized
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:05 --> Input Class Initialized
INFO - 2020-02-04 05:34:05 --> Language Class Initialized
INFO - 2020-02-04 05:34:05 --> Input Class Initialized
INFO - 2020-02-04 05:34:05 --> Language Class Initialized
INFO - 2020-02-04 05:34:05 --> Language Class Initialized
INFO - 2020-02-04 05:34:05 --> Language Class Initialized
INFO - 2020-02-04 05:34:05 --> Language Class Initialized
ERROR - 2020-02-04 05:34:05 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 05:34:05 --> Language Class Initialized
INFO - 2020-02-04 05:34:05 --> Loader Class Initialized
ERROR - 2020-02-04 05:34:05 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 05:34:05 --> Loader Class Initialized
INFO - 2020-02-04 05:34:05 --> Helper loaded: url_helper
ERROR - 2020-02-04 05:34:05 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 05:34:05 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:34:05 --> Helper loaded: url_helper
INFO - 2020-02-04 05:34:05 --> Config Class Initialized
INFO - 2020-02-04 05:34:05 --> Config Class Initialized
INFO - 2020-02-04 05:34:05 --> Hooks Class Initialized
INFO - 2020-02-04 05:34:05 --> Hooks Class Initialized
INFO - 2020-02-04 05:34:05 --> Database Driver Class Initialized
INFO - 2020-02-04 05:34:05 --> Database Driver Class Initialized
INFO - 2020-02-04 05:34:05 --> Config Class Initialized
INFO - 2020-02-04 05:34:05 --> Config Class Initialized
INFO - 2020-02-04 05:34:05 --> Hooks Class Initialized
INFO - 2020-02-04 05:34:05 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:34:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:34:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 05:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:34:05 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:34:05 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:34:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:34:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:34:05 --> Controller Class Initialized
INFO - 2020-02-04 05:34:05 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:05 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:05 --> URI Class Initialized
INFO - 2020-02-04 05:34:05 --> URI Class Initialized
INFO - 2020-02-04 05:34:05 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:34:05 --> URI Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
INFO - 2020-02-04 05:34:05 --> URI Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
INFO - 2020-02-04 05:34:05 --> Helper loaded: form_helper
INFO - 2020-02-04 05:34:05 --> Form Validation Class Initialized
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 05:34:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:34:05 --> Input Class Initialized
INFO - 2020-02-04 05:34:05 --> Input Class Initialized
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 05:34:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:34:05 --> Input Class Initialized
INFO - 2020-02-04 05:34:05 --> Language Class Initialized
INFO - 2020-02-04 05:34:05 --> Language Class Initialized
INFO - 2020-02-04 05:34:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:34:05 --> Input Class Initialized
INFO - 2020-02-04 05:34:05 --> Final output sent to browser
INFO - 2020-02-04 05:34:05 --> Language Class Initialized
ERROR - 2020-02-04 05:34:05 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:34:05 --> Language Class Initialized
ERROR - 2020-02-04 05:34:05 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-04 05:34:05 --> Total execution time: 0.7665
ERROR - 2020-02-04 05:34:05 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 05:34:05 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:34:05 --> Config Class Initialized
INFO - 2020-02-04 05:34:05 --> Config Class Initialized
INFO - 2020-02-04 05:34:05 --> Hooks Class Initialized
INFO - 2020-02-04 05:34:05 --> Hooks Class Initialized
INFO - 2020-02-04 05:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:34:05 --> Config Class Initialized
INFO - 2020-02-04 05:34:05 --> Config Class Initialized
INFO - 2020-02-04 05:34:05 --> Hooks Class Initialized
INFO - 2020-02-04 05:34:05 --> Hooks Class Initialized
INFO - 2020-02-04 05:34:05 --> Controller Class Initialized
DEBUG - 2020-02-04 05:34:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:34:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:34:05 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:05 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:05 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 05:34:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:34:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:34:05 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:05 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:05 --> URI Class Initialized
INFO - 2020-02-04 05:34:05 --> URI Class Initialized
INFO - 2020-02-04 05:34:05 --> Helper loaded: form_helper
INFO - 2020-02-04 05:34:05 --> Form Validation Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
INFO - 2020-02-04 05:34:05 --> URI Class Initialized
INFO - 2020-02-04 05:34:05 --> URI Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
INFO - 2020-02-04 05:34:05 --> Router Class Initialized
ERROR - 2020-02-04 05:34:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 05:34:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
INFO - 2020-02-04 05:34:05 --> Output Class Initialized
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
INFO - 2020-02-04 05:34:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
INFO - 2020-02-04 05:34:05 --> Security Class Initialized
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:05 --> Input Class Initialized
INFO - 2020-02-04 05:34:05 --> Input Class Initialized
INFO - 2020-02-04 05:34:05 --> Final output sent to browser
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:06 --> Input Class Initialized
INFO - 2020-02-04 05:34:06 --> Input Class Initialized
INFO - 2020-02-04 05:34:06 --> Language Class Initialized
INFO - 2020-02-04 05:34:06 --> Language Class Initialized
DEBUG - 2020-02-04 05:34:06 --> Total execution time: 1.1136
INFO - 2020-02-04 05:34:06 --> Language Class Initialized
ERROR - 2020-02-04 05:34:06 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 05:34:06 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:34:06 --> Language Class Initialized
ERROR - 2020-02-04 05:34:06 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 05:34:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:34:06 --> Config Class Initialized
INFO - 2020-02-04 05:34:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:34:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:34:06 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:06 --> URI Class Initialized
INFO - 2020-02-04 05:34:06 --> Router Class Initialized
INFO - 2020-02-04 05:34:06 --> Output Class Initialized
INFO - 2020-02-04 05:34:06 --> Security Class Initialized
DEBUG - 2020-02-04 05:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:06 --> Input Class Initialized
INFO - 2020-02-04 05:34:06 --> Language Class Initialized
ERROR - 2020-02-04 05:34:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:34:06 --> Config Class Initialized
INFO - 2020-02-04 05:34:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:34:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:34:06 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:06 --> URI Class Initialized
INFO - 2020-02-04 05:34:06 --> Router Class Initialized
INFO - 2020-02-04 05:34:06 --> Output Class Initialized
INFO - 2020-02-04 05:34:06 --> Security Class Initialized
DEBUG - 2020-02-04 05:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:06 --> Input Class Initialized
INFO - 2020-02-04 05:34:06 --> Language Class Initialized
ERROR - 2020-02-04 05:34:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:34:06 --> Config Class Initialized
INFO - 2020-02-04 05:34:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:34:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:34:06 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:07 --> URI Class Initialized
INFO - 2020-02-04 05:34:07 --> Router Class Initialized
INFO - 2020-02-04 05:34:07 --> Output Class Initialized
INFO - 2020-02-04 05:34:07 --> Security Class Initialized
DEBUG - 2020-02-04 05:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:07 --> Input Class Initialized
INFO - 2020-02-04 05:34:07 --> Language Class Initialized
ERROR - 2020-02-04 05:34:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:34:07 --> Config Class Initialized
INFO - 2020-02-04 05:34:07 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:34:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:34:07 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:07 --> URI Class Initialized
INFO - 2020-02-04 05:34:07 --> Router Class Initialized
INFO - 2020-02-04 05:34:07 --> Output Class Initialized
INFO - 2020-02-04 05:34:07 --> Security Class Initialized
DEBUG - 2020-02-04 05:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:07 --> Input Class Initialized
INFO - 2020-02-04 05:34:07 --> Language Class Initialized
ERROR - 2020-02-04 05:34:07 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:34:07 --> Config Class Initialized
INFO - 2020-02-04 05:34:07 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:34:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:34:07 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:07 --> URI Class Initialized
INFO - 2020-02-04 05:34:07 --> Router Class Initialized
INFO - 2020-02-04 05:34:07 --> Output Class Initialized
INFO - 2020-02-04 05:34:07 --> Security Class Initialized
DEBUG - 2020-02-04 05:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:07 --> Input Class Initialized
INFO - 2020-02-04 05:34:07 --> Language Class Initialized
ERROR - 2020-02-04 05:34:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:34:08 --> Config Class Initialized
INFO - 2020-02-04 05:34:08 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:34:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:34:08 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:08 --> URI Class Initialized
INFO - 2020-02-04 05:34:08 --> Router Class Initialized
INFO - 2020-02-04 05:34:08 --> Output Class Initialized
INFO - 2020-02-04 05:34:08 --> Security Class Initialized
DEBUG - 2020-02-04 05:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:08 --> Input Class Initialized
INFO - 2020-02-04 05:34:08 --> Language Class Initialized
ERROR - 2020-02-04 05:34:08 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:34:08 --> Config Class Initialized
INFO - 2020-02-04 05:34:08 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:34:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:34:08 --> Utf8 Class Initialized
INFO - 2020-02-04 05:34:08 --> URI Class Initialized
INFO - 2020-02-04 05:34:08 --> Router Class Initialized
INFO - 2020-02-04 05:34:08 --> Output Class Initialized
INFO - 2020-02-04 05:34:08 --> Security Class Initialized
DEBUG - 2020-02-04 05:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:34:08 --> Input Class Initialized
INFO - 2020-02-04 05:34:08 --> Language Class Initialized
ERROR - 2020-02-04 05:34:08 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:35:00 --> Config Class Initialized
INFO - 2020-02-04 05:35:00 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:00 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:00 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:00 --> URI Class Initialized
INFO - 2020-02-04 05:35:00 --> Router Class Initialized
INFO - 2020-02-04 05:35:00 --> Output Class Initialized
INFO - 2020-02-04 05:35:00 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:00 --> Input Class Initialized
INFO - 2020-02-04 05:35:00 --> Language Class Initialized
INFO - 2020-02-04 05:35:00 --> Loader Class Initialized
INFO - 2020-02-04 05:35:00 --> Helper loaded: url_helper
INFO - 2020-02-04 05:35:00 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:35:00 --> Controller Class Initialized
INFO - 2020-02-04 05:35:00 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:35:00 --> Helper loaded: form_helper
INFO - 2020-02-04 05:35:01 --> Form Validation Class Initialized
INFO - 2020-02-04 05:35:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:35:01 --> Final output sent to browser
INFO - 2020-02-04 05:35:01 --> Config Class Initialized
INFO - 2020-02-04 05:35:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:01 --> Total execution time: 0.6397
INFO - 2020-02-04 05:35:01 --> Config Class Initialized
INFO - 2020-02-04 05:35:01 --> Config Class Initialized
INFO - 2020-02-04 05:35:01 --> Config Class Initialized
INFO - 2020-02-04 05:35:01 --> Config Class Initialized
INFO - 2020-02-04 05:35:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:35:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:35:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:35:01 --> Config Class Initialized
INFO - 2020-02-04 05:35:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:01 --> URI Class Initialized
DEBUG - 2020-02-04 05:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:01 --> URI Class Initialized
INFO - 2020-02-04 05:35:01 --> URI Class Initialized
INFO - 2020-02-04 05:35:01 --> URI Class Initialized
INFO - 2020-02-04 05:35:01 --> Router Class Initialized
INFO - 2020-02-04 05:35:01 --> URI Class Initialized
INFO - 2020-02-04 05:35:01 --> Router Class Initialized
INFO - 2020-02-04 05:35:01 --> Router Class Initialized
INFO - 2020-02-04 05:35:01 --> Router Class Initialized
INFO - 2020-02-04 05:35:01 --> Output Class Initialized
INFO - 2020-02-04 05:35:01 --> URI Class Initialized
INFO - 2020-02-04 05:35:01 --> Router Class Initialized
INFO - 2020-02-04 05:35:01 --> Router Class Initialized
INFO - 2020-02-04 05:35:01 --> Output Class Initialized
INFO - 2020-02-04 05:35:01 --> Output Class Initialized
INFO - 2020-02-04 05:35:01 --> Output Class Initialized
INFO - 2020-02-04 05:35:01 --> Security Class Initialized
INFO - 2020-02-04 05:35:01 --> Output Class Initialized
INFO - 2020-02-04 05:35:01 --> Security Class Initialized
INFO - 2020-02-04 05:35:01 --> Security Class Initialized
INFO - 2020-02-04 05:35:01 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:01 --> Security Class Initialized
INFO - 2020-02-04 05:35:01 --> Output Class Initialized
DEBUG - 2020-02-04 05:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:01 --> Input Class Initialized
DEBUG - 2020-02-04 05:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:01 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:01 --> Input Class Initialized
INFO - 2020-02-04 05:35:01 --> Input Class Initialized
INFO - 2020-02-04 05:35:01 --> Input Class Initialized
INFO - 2020-02-04 05:35:01 --> Input Class Initialized
DEBUG - 2020-02-04 05:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:01 --> Language Class Initialized
INFO - 2020-02-04 05:35:01 --> Input Class Initialized
INFO - 2020-02-04 05:35:01 --> Language Class Initialized
INFO - 2020-02-04 05:35:01 --> Language Class Initialized
INFO - 2020-02-04 05:35:01 --> Language Class Initialized
INFO - 2020-02-04 05:35:01 --> Language Class Initialized
ERROR - 2020-02-04 05:35:01 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:35:01 --> Language Class Initialized
ERROR - 2020-02-04 05:35:01 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 05:35:01 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 05:35:01 --> Loader Class Initialized
INFO - 2020-02-04 05:35:01 --> Loader Class Initialized
INFO - 2020-02-04 05:35:01 --> Config Class Initialized
INFO - 2020-02-04 05:35:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:35:01 --> Helper loaded: url_helper
ERROR - 2020-02-04 05:35:01 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:35:01 --> Helper loaded: url_helper
INFO - 2020-02-04 05:35:01 --> Config Class Initialized
INFO - 2020-02-04 05:35:01 --> Config Class Initialized
INFO - 2020-02-04 05:35:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:35:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:01 --> Database Driver Class Initialized
INFO - 2020-02-04 05:35:01 --> Database Driver Class Initialized
INFO - 2020-02-04 05:35:01 --> Config Class Initialized
INFO - 2020-02-04 05:35:01 --> Hooks Class Initialized
INFO - 2020-02-04 05:35:01 --> Utf8 Class Initialized
DEBUG - 2020-02-04 05:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 05:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:35:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:35:01 --> URI Class Initialized
DEBUG - 2020-02-04 05:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:01 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:01 --> Controller Class Initialized
INFO - 2020-02-04 05:35:01 --> URI Class Initialized
INFO - 2020-02-04 05:35:01 --> URI Class Initialized
INFO - 2020-02-04 05:35:01 --> Router Class Initialized
INFO - 2020-02-04 05:35:01 --> URI Class Initialized
INFO - 2020-02-04 05:35:01 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:35:01 --> Router Class Initialized
INFO - 2020-02-04 05:35:01 --> Output Class Initialized
INFO - 2020-02-04 05:35:01 --> Router Class Initialized
INFO - 2020-02-04 05:35:01 --> Security Class Initialized
INFO - 2020-02-04 05:35:01 --> Output Class Initialized
INFO - 2020-02-04 05:35:01 --> Output Class Initialized
INFO - 2020-02-04 05:35:01 --> Router Class Initialized
INFO - 2020-02-04 05:35:01 --> Helper loaded: form_helper
INFO - 2020-02-04 05:35:01 --> Form Validation Class Initialized
DEBUG - 2020-02-04 05:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:01 --> Output Class Initialized
INFO - 2020-02-04 05:35:01 --> Security Class Initialized
INFO - 2020-02-04 05:35:01 --> Security Class Initialized
INFO - 2020-02-04 05:35:01 --> Input Class Initialized
DEBUG - 2020-02-04 05:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:01 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 05:35:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 05:35:01 --> Input Class Initialized
INFO - 2020-02-04 05:35:01 --> Input Class Initialized
ERROR - 2020-02-04 05:35:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:35:01 --> Language Class Initialized
DEBUG - 2020-02-04 05:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:01 --> Input Class Initialized
INFO - 2020-02-04 05:35:01 --> Language Class Initialized
INFO - 2020-02-04 05:35:01 --> Language Class Initialized
INFO - 2020-02-04 05:35:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-04 05:35:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:35:01 --> Final output sent to browser
ERROR - 2020-02-04 05:35:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:35:01 --> Language Class Initialized
ERROR - 2020-02-04 05:35:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:35:01 --> Config Class Initialized
DEBUG - 2020-02-04 05:35:01 --> Total execution time: 0.7269
INFO - 2020-02-04 05:35:01 --> Hooks Class Initialized
ERROR - 2020-02-04 05:35:01 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:35:01 --> Config Class Initialized
INFO - 2020-02-04 05:35:02 --> Hooks Class Initialized
INFO - 2020-02-04 05:35:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 05:35:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:02 --> Config Class Initialized
INFO - 2020-02-04 05:35:02 --> Config Class Initialized
INFO - 2020-02-04 05:35:02 --> Hooks Class Initialized
INFO - 2020-02-04 05:35:02 --> Hooks Class Initialized
INFO - 2020-02-04 05:35:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:02 --> Controller Class Initialized
DEBUG - 2020-02-04 05:35:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:02 --> Model "M_tiket" initialized
INFO - 2020-02-04 05:35:02 --> URI Class Initialized
DEBUG - 2020-02-04 05:35:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 05:35:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:02 --> URI Class Initialized
INFO - 2020-02-04 05:35:02 --> Router Class Initialized
INFO - 2020-02-04 05:35:02 --> Helper loaded: form_helper
INFO - 2020-02-04 05:35:02 --> Form Validation Class Initialized
INFO - 2020-02-04 05:35:02 --> URI Class Initialized
INFO - 2020-02-04 05:35:02 --> Router Class Initialized
INFO - 2020-02-04 05:35:02 --> Output Class Initialized
INFO - 2020-02-04 05:35:02 --> URI Class Initialized
INFO - 2020-02-04 05:35:02 --> Output Class Initialized
INFO - 2020-02-04 05:35:02 --> Router Class Initialized
INFO - 2020-02-04 05:35:02 --> Router Class Initialized
INFO - 2020-02-04 05:35:02 --> Security Class Initialized
ERROR - 2020-02-04 05:35:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 05:35:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 05:35:02 --> Output Class Initialized
INFO - 2020-02-04 05:35:02 --> Output Class Initialized
INFO - 2020-02-04 05:35:02 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 05:35:02 --> Input Class Initialized
DEBUG - 2020-02-04 05:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:02 --> Security Class Initialized
INFO - 2020-02-04 05:35:02 --> Security Class Initialized
INFO - 2020-02-04 05:35:02 --> Input Class Initialized
INFO - 2020-02-04 05:35:02 --> Final output sent to browser
INFO - 2020-02-04 05:35:02 --> Language Class Initialized
DEBUG - 2020-02-04 05:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 05:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:02 --> Input Class Initialized
INFO - 2020-02-04 05:35:02 --> Input Class Initialized
DEBUG - 2020-02-04 05:35:02 --> Total execution time: 1.0795
INFO - 2020-02-04 05:35:02 --> Language Class Initialized
ERROR - 2020-02-04 05:35:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:35:02 --> Language Class Initialized
ERROR - 2020-02-04 05:35:02 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:35:02 --> Language Class Initialized
ERROR - 2020-02-04 05:35:02 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 05:35:02 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 05:35:02 --> Config Class Initialized
INFO - 2020-02-04 05:35:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:02 --> URI Class Initialized
INFO - 2020-02-04 05:35:02 --> Router Class Initialized
INFO - 2020-02-04 05:35:02 --> Output Class Initialized
INFO - 2020-02-04 05:35:02 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:02 --> Input Class Initialized
INFO - 2020-02-04 05:35:02 --> Language Class Initialized
ERROR - 2020-02-04 05:35:02 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 05:35:02 --> Config Class Initialized
INFO - 2020-02-04 05:35:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:02 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:02 --> URI Class Initialized
INFO - 2020-02-04 05:35:02 --> Router Class Initialized
INFO - 2020-02-04 05:35:02 --> Output Class Initialized
INFO - 2020-02-04 05:35:02 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:03 --> Input Class Initialized
INFO - 2020-02-04 05:35:03 --> Language Class Initialized
ERROR - 2020-02-04 05:35:03 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 05:35:03 --> Config Class Initialized
INFO - 2020-02-04 05:35:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:03 --> URI Class Initialized
INFO - 2020-02-04 05:35:03 --> Router Class Initialized
INFO - 2020-02-04 05:35:03 --> Output Class Initialized
INFO - 2020-02-04 05:35:03 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:03 --> Input Class Initialized
INFO - 2020-02-04 05:35:03 --> Language Class Initialized
ERROR - 2020-02-04 05:35:03 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 05:35:03 --> Config Class Initialized
INFO - 2020-02-04 05:35:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:03 --> URI Class Initialized
INFO - 2020-02-04 05:35:03 --> Router Class Initialized
INFO - 2020-02-04 05:35:03 --> Output Class Initialized
INFO - 2020-02-04 05:35:03 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:03 --> Input Class Initialized
INFO - 2020-02-04 05:35:03 --> Language Class Initialized
ERROR - 2020-02-04 05:35:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:35:03 --> Config Class Initialized
INFO - 2020-02-04 05:35:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:03 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:03 --> URI Class Initialized
INFO - 2020-02-04 05:35:03 --> Router Class Initialized
INFO - 2020-02-04 05:35:03 --> Output Class Initialized
INFO - 2020-02-04 05:35:04 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:04 --> Input Class Initialized
INFO - 2020-02-04 05:35:04 --> Language Class Initialized
ERROR - 2020-02-04 05:35:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 05:35:04 --> Config Class Initialized
INFO - 2020-02-04 05:35:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:04 --> URI Class Initialized
INFO - 2020-02-04 05:35:04 --> Router Class Initialized
INFO - 2020-02-04 05:35:04 --> Output Class Initialized
INFO - 2020-02-04 05:35:04 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:04 --> Input Class Initialized
INFO - 2020-02-04 05:35:04 --> Language Class Initialized
ERROR - 2020-02-04 05:35:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 05:35:04 --> Config Class Initialized
INFO - 2020-02-04 05:35:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:04 --> URI Class Initialized
INFO - 2020-02-04 05:35:04 --> Router Class Initialized
INFO - 2020-02-04 05:35:04 --> Output Class Initialized
INFO - 2020-02-04 05:35:04 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:04 --> Input Class Initialized
INFO - 2020-02-04 05:35:04 --> Language Class Initialized
ERROR - 2020-02-04 05:35:04 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 05:35:04 --> Config Class Initialized
INFO - 2020-02-04 05:35:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:04 --> URI Class Initialized
INFO - 2020-02-04 05:35:05 --> Router Class Initialized
INFO - 2020-02-04 05:35:05 --> Output Class Initialized
INFO - 2020-02-04 05:35:05 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:05 --> Input Class Initialized
INFO - 2020-02-04 05:35:05 --> Language Class Initialized
ERROR - 2020-02-04 05:35:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 05:35:05 --> Config Class Initialized
INFO - 2020-02-04 05:35:05 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:35:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:35:05 --> Utf8 Class Initialized
INFO - 2020-02-04 05:35:05 --> URI Class Initialized
INFO - 2020-02-04 05:35:05 --> Router Class Initialized
INFO - 2020-02-04 05:35:05 --> Output Class Initialized
INFO - 2020-02-04 05:35:05 --> Security Class Initialized
DEBUG - 2020-02-04 05:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:35:05 --> Input Class Initialized
INFO - 2020-02-04 05:35:05 --> Language Class Initialized
ERROR - 2020-02-04 05:35:05 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 09:34:33 --> Config Class Initialized
INFO - 2020-02-04 09:34:33 --> Hooks Class Initialized
DEBUG - 2020-02-04 09:34:33 --> UTF-8 Support Enabled
INFO - 2020-02-04 09:34:33 --> Utf8 Class Initialized
INFO - 2020-02-04 09:34:33 --> URI Class Initialized
DEBUG - 2020-02-04 09:34:33 --> No URI present. Default controller set.
INFO - 2020-02-04 09:34:34 --> Router Class Initialized
INFO - 2020-02-04 09:34:34 --> Output Class Initialized
INFO - 2020-02-04 09:34:34 --> Security Class Initialized
DEBUG - 2020-02-04 09:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 09:34:34 --> Input Class Initialized
INFO - 2020-02-04 09:34:34 --> Language Class Initialized
INFO - 2020-02-04 09:34:34 --> Loader Class Initialized
INFO - 2020-02-04 09:34:34 --> Helper loaded: url_helper
INFO - 2020-02-04 09:34:34 --> Database Driver Class Initialized
DEBUG - 2020-02-04 09:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 09:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 09:34:34 --> Controller Class Initialized
INFO - 2020-02-04 09:34:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 09:34:34 --> Pagination Class Initialized
INFO - 2020-02-04 09:34:34 --> Model "M_show" initialized
INFO - 2020-02-04 09:34:34 --> Helper loaded: form_helper
INFO - 2020-02-04 09:34:34 --> Form Validation Class Initialized
INFO - 2020-02-04 09:34:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 09:34:34 --> Final output sent to browser
DEBUG - 2020-02-04 09:34:34 --> Total execution time: 1.0876
INFO - 2020-02-04 09:35:57 --> Config Class Initialized
INFO - 2020-02-04 09:35:57 --> Hooks Class Initialized
DEBUG - 2020-02-04 09:35:57 --> UTF-8 Support Enabled
INFO - 2020-02-04 09:35:57 --> Utf8 Class Initialized
INFO - 2020-02-04 09:35:57 --> URI Class Initialized
DEBUG - 2020-02-04 09:35:57 --> No URI present. Default controller set.
INFO - 2020-02-04 09:35:57 --> Router Class Initialized
INFO - 2020-02-04 09:35:57 --> Output Class Initialized
INFO - 2020-02-04 09:35:57 --> Security Class Initialized
DEBUG - 2020-02-04 09:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 09:35:57 --> Input Class Initialized
INFO - 2020-02-04 09:35:57 --> Language Class Initialized
INFO - 2020-02-04 09:35:57 --> Loader Class Initialized
INFO - 2020-02-04 09:35:57 --> Helper loaded: url_helper
INFO - 2020-02-04 09:35:57 --> Database Driver Class Initialized
DEBUG - 2020-02-04 09:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 09:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 09:35:57 --> Controller Class Initialized
INFO - 2020-02-04 09:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 09:35:57 --> Pagination Class Initialized
INFO - 2020-02-04 09:35:57 --> Model "M_show" initialized
INFO - 2020-02-04 09:35:57 --> Helper loaded: form_helper
INFO - 2020-02-04 09:35:57 --> Form Validation Class Initialized
INFO - 2020-02-04 09:35:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 09:35:57 --> Final output sent to browser
DEBUG - 2020-02-04 09:35:57 --> Total execution time: 0.5243
INFO - 2020-02-04 09:35:58 --> Config Class Initialized
INFO - 2020-02-04 09:35:58 --> Hooks Class Initialized
DEBUG - 2020-02-04 09:35:58 --> UTF-8 Support Enabled
INFO - 2020-02-04 09:35:58 --> Utf8 Class Initialized
INFO - 2020-02-04 09:35:58 --> URI Class Initialized
DEBUG - 2020-02-04 09:35:58 --> No URI present. Default controller set.
INFO - 2020-02-04 09:35:58 --> Router Class Initialized
INFO - 2020-02-04 09:35:58 --> Output Class Initialized
INFO - 2020-02-04 09:35:58 --> Security Class Initialized
DEBUG - 2020-02-04 09:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 09:35:58 --> Input Class Initialized
INFO - 2020-02-04 09:35:58 --> Language Class Initialized
INFO - 2020-02-04 09:35:58 --> Loader Class Initialized
INFO - 2020-02-04 09:35:58 --> Helper loaded: url_helper
INFO - 2020-02-04 09:35:58 --> Database Driver Class Initialized
DEBUG - 2020-02-04 09:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 09:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 09:35:58 --> Controller Class Initialized
INFO - 2020-02-04 09:35:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 09:35:58 --> Pagination Class Initialized
INFO - 2020-02-04 09:35:58 --> Model "M_show" initialized
INFO - 2020-02-04 09:35:58 --> Helper loaded: form_helper
INFO - 2020-02-04 09:35:58 --> Form Validation Class Initialized
INFO - 2020-02-04 09:35:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 09:35:58 --> Final output sent to browser
DEBUG - 2020-02-04 09:35:58 --> Total execution time: 0.5299
INFO - 2020-02-04 09:37:06 --> Config Class Initialized
INFO - 2020-02-04 09:37:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 09:37:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 09:37:06 --> Utf8 Class Initialized
INFO - 2020-02-04 09:37:06 --> URI Class Initialized
DEBUG - 2020-02-04 09:37:06 --> No URI present. Default controller set.
INFO - 2020-02-04 09:37:06 --> Router Class Initialized
INFO - 2020-02-04 09:37:06 --> Output Class Initialized
INFO - 2020-02-04 09:37:06 --> Security Class Initialized
DEBUG - 2020-02-04 09:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 09:37:06 --> Input Class Initialized
INFO - 2020-02-04 09:37:06 --> Language Class Initialized
INFO - 2020-02-04 09:37:06 --> Loader Class Initialized
INFO - 2020-02-04 09:37:06 --> Helper loaded: url_helper
INFO - 2020-02-04 09:37:06 --> Database Driver Class Initialized
DEBUG - 2020-02-04 09:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 09:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 09:37:06 --> Controller Class Initialized
INFO - 2020-02-04 09:37:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 09:37:06 --> Pagination Class Initialized
INFO - 2020-02-04 09:37:06 --> Model "M_show" initialized
INFO - 2020-02-04 09:37:06 --> Helper loaded: form_helper
INFO - 2020-02-04 09:37:06 --> Form Validation Class Initialized
INFO - 2020-02-04 09:37:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 09:37:06 --> Final output sent to browser
DEBUG - 2020-02-04 09:37:06 --> Total execution time: 0.5304
INFO - 2020-02-04 09:37:07 --> Config Class Initialized
INFO - 2020-02-04 09:37:07 --> Hooks Class Initialized
DEBUG - 2020-02-04 09:37:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 09:37:07 --> Utf8 Class Initialized
INFO - 2020-02-04 09:37:07 --> URI Class Initialized
DEBUG - 2020-02-04 09:37:07 --> No URI present. Default controller set.
INFO - 2020-02-04 09:37:07 --> Router Class Initialized
INFO - 2020-02-04 09:37:07 --> Output Class Initialized
INFO - 2020-02-04 09:37:07 --> Security Class Initialized
DEBUG - 2020-02-04 09:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 09:37:07 --> Input Class Initialized
INFO - 2020-02-04 09:37:07 --> Language Class Initialized
INFO - 2020-02-04 09:37:07 --> Loader Class Initialized
INFO - 2020-02-04 09:37:07 --> Helper loaded: url_helper
INFO - 2020-02-04 09:37:07 --> Database Driver Class Initialized
DEBUG - 2020-02-04 09:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 09:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 09:37:07 --> Controller Class Initialized
INFO - 2020-02-04 09:37:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 09:37:07 --> Pagination Class Initialized
INFO - 2020-02-04 09:37:07 --> Model "M_show" initialized
INFO - 2020-02-04 09:37:07 --> Helper loaded: form_helper
INFO - 2020-02-04 09:37:07 --> Form Validation Class Initialized
INFO - 2020-02-04 09:37:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 09:37:07 --> Final output sent to browser
DEBUG - 2020-02-04 09:37:07 --> Total execution time: 0.5563
INFO - 2020-02-04 10:49:52 --> Config Class Initialized
INFO - 2020-02-04 10:49:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 10:49:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:52 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:52 --> URI Class Initialized
INFO - 2020-02-04 10:49:52 --> Router Class Initialized
INFO - 2020-02-04 10:49:52 --> Output Class Initialized
INFO - 2020-02-04 10:49:52 --> Security Class Initialized
DEBUG - 2020-02-04 10:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 10:49:52 --> Input Class Initialized
INFO - 2020-02-04 10:49:52 --> Language Class Initialized
INFO - 2020-02-04 10:49:52 --> Loader Class Initialized
INFO - 2020-02-04 10:49:52 --> Helper loaded: url_helper
INFO - 2020-02-04 10:49:52 --> Database Driver Class Initialized
DEBUG - 2020-02-04 10:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 10:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 10:49:52 --> Controller Class Initialized
INFO - 2020-02-04 10:49:52 --> Model "M_tiket" initialized
INFO - 2020-02-04 10:49:52 --> Helper loaded: form_helper
INFO - 2020-02-04 10:49:52 --> Form Validation Class Initialized
INFO - 2020-02-04 10:49:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 10:49:52 --> Final output sent to browser
DEBUG - 2020-02-04 10:49:52 --> Total execution time: 0.7099
INFO - 2020-02-04 10:49:52 --> Config Class Initialized
INFO - 2020-02-04 10:49:52 --> Config Class Initialized
INFO - 2020-02-04 10:49:52 --> Config Class Initialized
INFO - 2020-02-04 10:49:52 --> Config Class Initialized
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
INFO - 2020-02-04 10:49:53 --> Config Class Initialized
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
INFO - 2020-02-04 10:49:53 --> Config Class Initialized
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
INFO - 2020-02-04 10:49:53 --> Language Class Initialized
INFO - 2020-02-04 10:49:53 --> Language Class Initialized
INFO - 2020-02-04 10:49:53 --> Language Class Initialized
INFO - 2020-02-04 10:49:53 --> Language Class Initialized
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
INFO - 2020-02-04 10:49:53 --> Language Class Initialized
INFO - 2020-02-04 10:49:53 --> Language Class Initialized
ERROR - 2020-02-04 10:49:53 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 10:49:53 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 10:49:53 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 10:49:53 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 10:49:53 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 10:49:53 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 10:49:53 --> Config Class Initialized
INFO - 2020-02-04 10:49:53 --> Config Class Initialized
INFO - 2020-02-04 10:49:53 --> Config Class Initialized
INFO - 2020-02-04 10:49:53 --> Config Class Initialized
INFO - 2020-02-04 10:49:53 --> Config Class Initialized
INFO - 2020-02-04 10:49:53 --> Config Class Initialized
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
INFO - 2020-02-04 10:49:53 --> Language Class Initialized
INFO - 2020-02-04 10:49:53 --> Language Class Initialized
INFO - 2020-02-04 10:49:53 --> Language Class Initialized
INFO - 2020-02-04 10:49:53 --> Language Class Initialized
INFO - 2020-02-04 10:49:53 --> Language Class Initialized
INFO - 2020-02-04 10:49:53 --> Language Class Initialized
ERROR - 2020-02-04 10:49:53 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-04 10:49:53 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 10:49:53 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 10:49:53 --> Loader Class Initialized
INFO - 2020-02-04 10:49:53 --> Loader Class Initialized
ERROR - 2020-02-04 10:49:53 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 10:49:53 --> Helper loaded: url_helper
INFO - 2020-02-04 10:49:53 --> Helper loaded: url_helper
INFO - 2020-02-04 10:49:53 --> Database Driver Class Initialized
INFO - 2020-02-04 10:49:53 --> Database Driver Class Initialized
INFO - 2020-02-04 10:49:53 --> Config Class Initialized
INFO - 2020-02-04 10:49:53 --> Config Class Initialized
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
INFO - 2020-02-04 10:49:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 10:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 10:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 10:49:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 10:49:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:53 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:53 --> Controller Class Initialized
INFO - 2020-02-04 10:49:53 --> Model "M_tiket" initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> URI Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> Router Class Initialized
INFO - 2020-02-04 10:49:53 --> Helper loaded: form_helper
INFO - 2020-02-04 10:49:53 --> Form Validation Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Output Class Initialized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
INFO - 2020-02-04 10:49:53 --> Security Class Initialized
ERROR - 2020-02-04 10:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 10:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
INFO - 2020-02-04 10:49:53 --> Input Class Initialized
INFO - 2020-02-04 10:49:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 10:49:54 --> Final output sent to browser
INFO - 2020-02-04 10:49:54 --> Language Class Initialized
INFO - 2020-02-04 10:49:54 --> Language Class Initialized
DEBUG - 2020-02-04 10:49:54 --> Total execution time: 0.5616
ERROR - 2020-02-04 10:49:54 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 10:49:54 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 10:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 10:49:54 --> Config Class Initialized
INFO - 2020-02-04 10:49:54 --> Hooks Class Initialized
INFO - 2020-02-04 10:49:54 --> Controller Class Initialized
INFO - 2020-02-04 10:49:54 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 10:49:54 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:54 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:54 --> Helper loaded: form_helper
INFO - 2020-02-04 10:49:54 --> Form Validation Class Initialized
INFO - 2020-02-04 10:49:54 --> URI Class Initialized
INFO - 2020-02-04 10:49:54 --> Router Class Initialized
ERROR - 2020-02-04 10:49:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 10:49:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 10:49:54 --> Output Class Initialized
INFO - 2020-02-04 10:49:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 10:49:54 --> Security Class Initialized
INFO - 2020-02-04 10:49:54 --> Final output sent to browser
DEBUG - 2020-02-04 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 10:49:54 --> Total execution time: 0.7763
INFO - 2020-02-04 10:49:54 --> Input Class Initialized
INFO - 2020-02-04 10:49:54 --> Language Class Initialized
ERROR - 2020-02-04 10:49:54 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 10:49:54 --> Config Class Initialized
INFO - 2020-02-04 10:49:54 --> Hooks Class Initialized
DEBUG - 2020-02-04 10:49:54 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:54 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:54 --> URI Class Initialized
INFO - 2020-02-04 10:49:54 --> Router Class Initialized
INFO - 2020-02-04 10:49:54 --> Output Class Initialized
INFO - 2020-02-04 10:49:54 --> Security Class Initialized
DEBUG - 2020-02-04 10:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 10:49:54 --> Input Class Initialized
INFO - 2020-02-04 10:49:54 --> Language Class Initialized
ERROR - 2020-02-04 10:49:54 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 10:49:54 --> Config Class Initialized
INFO - 2020-02-04 10:49:54 --> Hooks Class Initialized
DEBUG - 2020-02-04 10:49:54 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:54 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:54 --> URI Class Initialized
INFO - 2020-02-04 10:49:54 --> Router Class Initialized
INFO - 2020-02-04 10:49:54 --> Output Class Initialized
INFO - 2020-02-04 10:49:54 --> Security Class Initialized
DEBUG - 2020-02-04 10:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 10:49:54 --> Input Class Initialized
INFO - 2020-02-04 10:49:54 --> Language Class Initialized
ERROR - 2020-02-04 10:49:54 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 10:49:54 --> Config Class Initialized
INFO - 2020-02-04 10:49:54 --> Hooks Class Initialized
DEBUG - 2020-02-04 10:49:54 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:54 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:54 --> URI Class Initialized
INFO - 2020-02-04 10:49:54 --> Router Class Initialized
INFO - 2020-02-04 10:49:54 --> Output Class Initialized
INFO - 2020-02-04 10:49:55 --> Security Class Initialized
DEBUG - 2020-02-04 10:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 10:49:55 --> Input Class Initialized
INFO - 2020-02-04 10:49:55 --> Language Class Initialized
ERROR - 2020-02-04 10:49:55 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 10:49:55 --> Config Class Initialized
INFO - 2020-02-04 10:49:55 --> Hooks Class Initialized
DEBUG - 2020-02-04 10:49:55 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:55 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:55 --> URI Class Initialized
INFO - 2020-02-04 10:49:55 --> Router Class Initialized
INFO - 2020-02-04 10:49:55 --> Output Class Initialized
INFO - 2020-02-04 10:49:55 --> Security Class Initialized
DEBUG - 2020-02-04 10:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 10:49:55 --> Input Class Initialized
INFO - 2020-02-04 10:49:55 --> Language Class Initialized
ERROR - 2020-02-04 10:49:55 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 10:49:55 --> Config Class Initialized
INFO - 2020-02-04 10:49:55 --> Hooks Class Initialized
DEBUG - 2020-02-04 10:49:55 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:55 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:55 --> URI Class Initialized
INFO - 2020-02-04 10:49:55 --> Router Class Initialized
INFO - 2020-02-04 10:49:55 --> Output Class Initialized
INFO - 2020-02-04 10:49:55 --> Security Class Initialized
DEBUG - 2020-02-04 10:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 10:49:55 --> Input Class Initialized
INFO - 2020-02-04 10:49:55 --> Language Class Initialized
ERROR - 2020-02-04 10:49:55 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 10:49:55 --> Config Class Initialized
INFO - 2020-02-04 10:49:55 --> Hooks Class Initialized
DEBUG - 2020-02-04 10:49:55 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:55 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:55 --> URI Class Initialized
INFO - 2020-02-04 10:49:55 --> Router Class Initialized
INFO - 2020-02-04 10:49:55 --> Output Class Initialized
INFO - 2020-02-04 10:49:55 --> Security Class Initialized
DEBUG - 2020-02-04 10:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 10:49:55 --> Input Class Initialized
INFO - 2020-02-04 10:49:55 --> Language Class Initialized
ERROR - 2020-02-04 10:49:55 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 10:49:55 --> Config Class Initialized
INFO - 2020-02-04 10:49:56 --> Hooks Class Initialized
DEBUG - 2020-02-04 10:49:56 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:56 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:56 --> URI Class Initialized
INFO - 2020-02-04 10:49:56 --> Router Class Initialized
INFO - 2020-02-04 10:49:56 --> Output Class Initialized
INFO - 2020-02-04 10:49:56 --> Security Class Initialized
DEBUG - 2020-02-04 10:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 10:49:56 --> Input Class Initialized
INFO - 2020-02-04 10:49:56 --> Language Class Initialized
ERROR - 2020-02-04 10:49:56 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 10:49:56 --> Config Class Initialized
INFO - 2020-02-04 10:49:56 --> Hooks Class Initialized
DEBUG - 2020-02-04 10:49:56 --> UTF-8 Support Enabled
INFO - 2020-02-04 10:49:56 --> Utf8 Class Initialized
INFO - 2020-02-04 10:49:56 --> URI Class Initialized
INFO - 2020-02-04 10:49:56 --> Router Class Initialized
INFO - 2020-02-04 10:49:56 --> Output Class Initialized
INFO - 2020-02-04 10:49:56 --> Security Class Initialized
DEBUG - 2020-02-04 10:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 10:49:56 --> Input Class Initialized
INFO - 2020-02-04 10:49:56 --> Language Class Initialized
ERROR - 2020-02-04 10:49:56 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 12:12:51 --> Config Class Initialized
INFO - 2020-02-04 12:12:51 --> Hooks Class Initialized
DEBUG - 2020-02-04 12:12:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:51 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:51 --> URI Class Initialized
INFO - 2020-02-04 12:12:51 --> Router Class Initialized
INFO - 2020-02-04 12:12:51 --> Output Class Initialized
INFO - 2020-02-04 12:12:51 --> Security Class Initialized
DEBUG - 2020-02-04 12:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:51 --> Input Class Initialized
INFO - 2020-02-04 12:12:51 --> Language Class Initialized
INFO - 2020-02-04 12:12:51 --> Loader Class Initialized
INFO - 2020-02-04 12:12:51 --> Helper loaded: url_helper
INFO - 2020-02-04 12:12:51 --> Database Driver Class Initialized
DEBUG - 2020-02-04 12:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 12:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 12:12:52 --> Controller Class Initialized
INFO - 2020-02-04 12:12:52 --> Model "M_tiket" initialized
INFO - 2020-02-04 12:12:52 --> Helper loaded: form_helper
INFO - 2020-02-04 12:12:52 --> Form Validation Class Initialized
INFO - 2020-02-04 12:12:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 12:12:52 --> Final output sent to browser
DEBUG - 2020-02-04 12:12:52 --> Total execution time: 0.6604
INFO - 2020-02-04 12:12:52 --> Config Class Initialized
INFO - 2020-02-04 12:12:52 --> Config Class Initialized
INFO - 2020-02-04 12:12:52 --> Config Class Initialized
INFO - 2020-02-04 12:12:52 --> Config Class Initialized
INFO - 2020-02-04 12:12:52 --> Config Class Initialized
INFO - 2020-02-04 12:12:52 --> Hooks Class Initialized
INFO - 2020-02-04 12:12:52 --> Hooks Class Initialized
INFO - 2020-02-04 12:12:52 --> Hooks Class Initialized
INFO - 2020-02-04 12:12:52 --> Hooks Class Initialized
INFO - 2020-02-04 12:12:52 --> Config Class Initialized
INFO - 2020-02-04 12:12:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 12:12:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 12:12:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:52 --> Utf8 Class Initialized
DEBUG - 2020-02-04 12:12:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:52 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:52 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:52 --> Utf8 Class Initialized
DEBUG - 2020-02-04 12:12:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:52 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:52 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:52 --> URI Class Initialized
INFO - 2020-02-04 12:12:52 --> URI Class Initialized
INFO - 2020-02-04 12:12:52 --> URI Class Initialized
INFO - 2020-02-04 12:12:52 --> URI Class Initialized
INFO - 2020-02-04 12:12:52 --> URI Class Initialized
INFO - 2020-02-04 12:12:52 --> Router Class Initialized
INFO - 2020-02-04 12:12:52 --> Router Class Initialized
INFO - 2020-02-04 12:12:52 --> URI Class Initialized
INFO - 2020-02-04 12:12:52 --> Router Class Initialized
INFO - 2020-02-04 12:12:52 --> Router Class Initialized
INFO - 2020-02-04 12:12:52 --> Output Class Initialized
INFO - 2020-02-04 12:12:52 --> Output Class Initialized
INFO - 2020-02-04 12:12:52 --> Output Class Initialized
INFO - 2020-02-04 12:12:52 --> Router Class Initialized
INFO - 2020-02-04 12:12:52 --> Output Class Initialized
INFO - 2020-02-04 12:12:52 --> Router Class Initialized
INFO - 2020-02-04 12:12:52 --> Security Class Initialized
INFO - 2020-02-04 12:12:52 --> Security Class Initialized
INFO - 2020-02-04 12:12:52 --> Output Class Initialized
INFO - 2020-02-04 12:12:52 --> Security Class Initialized
INFO - 2020-02-04 12:12:52 --> Security Class Initialized
INFO - 2020-02-04 12:12:52 --> Output Class Initialized
DEBUG - 2020-02-04 12:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:52 --> Security Class Initialized
DEBUG - 2020-02-04 12:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 12:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:52 --> Security Class Initialized
DEBUG - 2020-02-04 12:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:52 --> Input Class Initialized
INFO - 2020-02-04 12:12:52 --> Input Class Initialized
INFO - 2020-02-04 12:12:52 --> Input Class Initialized
INFO - 2020-02-04 12:12:52 --> Input Class Initialized
DEBUG - 2020-02-04 12:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 12:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:52 --> Input Class Initialized
INFO - 2020-02-04 12:12:52 --> Language Class Initialized
INFO - 2020-02-04 12:12:52 --> Language Class Initialized
INFO - 2020-02-04 12:12:52 --> Input Class Initialized
INFO - 2020-02-04 12:12:52 --> Language Class Initialized
INFO - 2020-02-04 12:12:52 --> Language Class Initialized
ERROR - 2020-02-04 12:12:52 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 12:12:52 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 12:12:52 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 12:12:52 --> Language Class Initialized
ERROR - 2020-02-04 12:12:52 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 12:12:52 --> Language Class Initialized
ERROR - 2020-02-04 12:12:52 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 12:12:52 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 12:12:52 --> Config Class Initialized
INFO - 2020-02-04 12:12:52 --> Config Class Initialized
INFO - 2020-02-04 12:12:52 --> Config Class Initialized
INFO - 2020-02-04 12:12:52 --> Hooks Class Initialized
INFO - 2020-02-04 12:12:52 --> Hooks Class Initialized
INFO - 2020-02-04 12:12:52 --> Config Class Initialized
INFO - 2020-02-04 12:12:52 --> Hooks Class Initialized
INFO - 2020-02-04 12:12:52 --> Config Class Initialized
INFO - 2020-02-04 12:12:52 --> Config Class Initialized
INFO - 2020-02-04 12:12:52 --> Hooks Class Initialized
INFO - 2020-02-04 12:12:52 --> Hooks Class Initialized
INFO - 2020-02-04 12:12:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 12:12:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:52 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:52 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:52 --> Utf8 Class Initialized
DEBUG - 2020-02-04 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 12:12:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:52 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:52 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:52 --> URI Class Initialized
INFO - 2020-02-04 12:12:52 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:52 --> URI Class Initialized
INFO - 2020-02-04 12:12:52 --> URI Class Initialized
INFO - 2020-02-04 12:12:52 --> URI Class Initialized
INFO - 2020-02-04 12:12:52 --> Router Class Initialized
INFO - 2020-02-04 12:12:52 --> Router Class Initialized
INFO - 2020-02-04 12:12:52 --> URI Class Initialized
INFO - 2020-02-04 12:12:52 --> Router Class Initialized
INFO - 2020-02-04 12:12:52 --> URI Class Initialized
INFO - 2020-02-04 12:12:52 --> Router Class Initialized
INFO - 2020-02-04 12:12:52 --> Output Class Initialized
INFO - 2020-02-04 12:12:52 --> Output Class Initialized
INFO - 2020-02-04 12:12:52 --> Output Class Initialized
INFO - 2020-02-04 12:12:52 --> Router Class Initialized
INFO - 2020-02-04 12:12:52 --> Router Class Initialized
INFO - 2020-02-04 12:12:52 --> Output Class Initialized
INFO - 2020-02-04 12:12:52 --> Output Class Initialized
INFO - 2020-02-04 12:12:52 --> Security Class Initialized
INFO - 2020-02-04 12:12:52 --> Output Class Initialized
INFO - 2020-02-04 12:12:52 --> Security Class Initialized
INFO - 2020-02-04 12:12:52 --> Security Class Initialized
DEBUG - 2020-02-04 12:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:52 --> Security Class Initialized
INFO - 2020-02-04 12:12:52 --> Security Class Initialized
INFO - 2020-02-04 12:12:52 --> Security Class Initialized
DEBUG - 2020-02-04 12:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 12:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:52 --> Input Class Initialized
INFO - 2020-02-04 12:12:52 --> Input Class Initialized
INFO - 2020-02-04 12:12:52 --> Input Class Initialized
DEBUG - 2020-02-04 12:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 12:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 12:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:52 --> Input Class Initialized
INFO - 2020-02-04 12:12:52 --> Input Class Initialized
INFO - 2020-02-04 12:12:52 --> Language Class Initialized
INFO - 2020-02-04 12:12:52 --> Input Class Initialized
INFO - 2020-02-04 12:12:52 --> Language Class Initialized
INFO - 2020-02-04 12:12:52 --> Language Class Initialized
INFO - 2020-02-04 12:12:52 --> Language Class Initialized
INFO - 2020-02-04 12:12:52 --> Language Class Initialized
INFO - 2020-02-04 12:12:52 --> Language Class Initialized
ERROR - 2020-02-04 12:12:52 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 12:12:52 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 12:12:52 --> Loader Class Initialized
INFO - 2020-02-04 12:12:53 --> Helper loaded: url_helper
ERROR - 2020-02-04 12:12:53 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 12:12:53 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 12:12:53 --> Loader Class Initialized
INFO - 2020-02-04 12:12:53 --> Config Class Initialized
INFO - 2020-02-04 12:12:53 --> Config Class Initialized
INFO - 2020-02-04 12:12:53 --> Hooks Class Initialized
INFO - 2020-02-04 12:12:53 --> Hooks Class Initialized
INFO - 2020-02-04 12:12:53 --> Helper loaded: url_helper
INFO - 2020-02-04 12:12:53 --> Database Driver Class Initialized
DEBUG - 2020-02-04 12:12:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 12:12:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:53 --> Database Driver Class Initialized
DEBUG - 2020-02-04 12:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 12:12:53 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:53 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 12:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 12:12:53 --> Controller Class Initialized
INFO - 2020-02-04 12:12:53 --> URI Class Initialized
INFO - 2020-02-04 12:12:53 --> URI Class Initialized
INFO - 2020-02-04 12:12:53 --> Model "M_tiket" initialized
INFO - 2020-02-04 12:12:53 --> Router Class Initialized
INFO - 2020-02-04 12:12:53 --> Router Class Initialized
INFO - 2020-02-04 12:12:53 --> Output Class Initialized
INFO - 2020-02-04 12:12:53 --> Output Class Initialized
INFO - 2020-02-04 12:12:53 --> Helper loaded: form_helper
INFO - 2020-02-04 12:12:53 --> Form Validation Class Initialized
INFO - 2020-02-04 12:12:53 --> Security Class Initialized
INFO - 2020-02-04 12:12:53 --> Security Class Initialized
DEBUG - 2020-02-04 12:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 12:12:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 12:12:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 12:12:53 --> Input Class Initialized
INFO - 2020-02-04 12:12:53 --> Input Class Initialized
ERROR - 2020-02-04 12:12:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 12:12:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 12:12:53 --> Language Class Initialized
INFO - 2020-02-04 12:12:53 --> Language Class Initialized
INFO - 2020-02-04 12:12:53 --> Final output sent to browser
ERROR - 2020-02-04 12:12:53 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 12:12:53 --> 404 Page Not Found: Bower_components/jquery-i18next
DEBUG - 2020-02-04 12:12:53 --> Total execution time: 0.6062
INFO - 2020-02-04 12:12:53 --> Config Class Initialized
INFO - 2020-02-04 12:12:53 --> Hooks Class Initialized
INFO - 2020-02-04 12:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 12:12:53 --> Controller Class Initialized
DEBUG - 2020-02-04 12:12:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:53 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:53 --> Model "M_tiket" initialized
INFO - 2020-02-04 12:12:53 --> URI Class Initialized
INFO - 2020-02-04 12:12:53 --> Helper loaded: form_helper
INFO - 2020-02-04 12:12:53 --> Form Validation Class Initialized
INFO - 2020-02-04 12:12:53 --> Router Class Initialized
INFO - 2020-02-04 12:12:53 --> Output Class Initialized
ERROR - 2020-02-04 12:12:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 12:12:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 12:12:53 --> Security Class Initialized
INFO - 2020-02-04 12:12:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-04 12:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:53 --> Input Class Initialized
INFO - 2020-02-04 12:12:53 --> Final output sent to browser
DEBUG - 2020-02-04 12:12:53 --> Total execution time: 0.8501
INFO - 2020-02-04 12:12:53 --> Language Class Initialized
ERROR - 2020-02-04 12:12:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 12:12:53 --> Config Class Initialized
INFO - 2020-02-04 12:12:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 12:12:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:53 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:53 --> URI Class Initialized
INFO - 2020-02-04 12:12:53 --> Router Class Initialized
INFO - 2020-02-04 12:12:53 --> Output Class Initialized
INFO - 2020-02-04 12:12:53 --> Security Class Initialized
DEBUG - 2020-02-04 12:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:53 --> Input Class Initialized
INFO - 2020-02-04 12:12:53 --> Language Class Initialized
ERROR - 2020-02-04 12:12:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 12:12:53 --> Config Class Initialized
INFO - 2020-02-04 12:12:54 --> Hooks Class Initialized
DEBUG - 2020-02-04 12:12:54 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:54 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:54 --> URI Class Initialized
INFO - 2020-02-04 12:12:54 --> Router Class Initialized
INFO - 2020-02-04 12:12:54 --> Output Class Initialized
INFO - 2020-02-04 12:12:54 --> Security Class Initialized
DEBUG - 2020-02-04 12:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:54 --> Input Class Initialized
INFO - 2020-02-04 12:12:54 --> Language Class Initialized
ERROR - 2020-02-04 12:12:54 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 12:12:54 --> Config Class Initialized
INFO - 2020-02-04 12:12:54 --> Hooks Class Initialized
DEBUG - 2020-02-04 12:12:54 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:54 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:54 --> URI Class Initialized
INFO - 2020-02-04 12:12:54 --> Router Class Initialized
INFO - 2020-02-04 12:12:54 --> Output Class Initialized
INFO - 2020-02-04 12:12:54 --> Security Class Initialized
DEBUG - 2020-02-04 12:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:54 --> Input Class Initialized
INFO - 2020-02-04 12:12:54 --> Language Class Initialized
ERROR - 2020-02-04 12:12:54 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 12:12:54 --> Config Class Initialized
INFO - 2020-02-04 12:12:54 --> Hooks Class Initialized
DEBUG - 2020-02-04 12:12:54 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:54 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:54 --> URI Class Initialized
INFO - 2020-02-04 12:12:54 --> Router Class Initialized
INFO - 2020-02-04 12:12:54 --> Output Class Initialized
INFO - 2020-02-04 12:12:54 --> Security Class Initialized
DEBUG - 2020-02-04 12:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:54 --> Input Class Initialized
INFO - 2020-02-04 12:12:54 --> Language Class Initialized
ERROR - 2020-02-04 12:12:54 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 12:12:54 --> Config Class Initialized
INFO - 2020-02-04 12:12:54 --> Hooks Class Initialized
DEBUG - 2020-02-04 12:12:55 --> UTF-8 Support Enabled
INFO - 2020-02-04 12:12:55 --> Utf8 Class Initialized
INFO - 2020-02-04 12:12:55 --> URI Class Initialized
INFO - 2020-02-04 12:12:55 --> Router Class Initialized
INFO - 2020-02-04 12:12:55 --> Output Class Initialized
INFO - 2020-02-04 12:12:55 --> Security Class Initialized
DEBUG - 2020-02-04 12:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 12:12:55 --> Input Class Initialized
INFO - 2020-02-04 12:12:55 --> Language Class Initialized
ERROR - 2020-02-04 12:12:55 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:02:25 --> Config Class Initialized
INFO - 2020-02-04 15:02:25 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:25 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:25 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:25 --> URI Class Initialized
INFO - 2020-02-04 15:02:25 --> Router Class Initialized
INFO - 2020-02-04 15:02:25 --> Output Class Initialized
INFO - 2020-02-04 15:02:25 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:25 --> Input Class Initialized
INFO - 2020-02-04 15:02:25 --> Language Class Initialized
INFO - 2020-02-04 15:02:25 --> Loader Class Initialized
INFO - 2020-02-04 15:02:25 --> Helper loaded: url_helper
INFO - 2020-02-04 15:02:25 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:02:26 --> Controller Class Initialized
INFO - 2020-02-04 15:02:26 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:02:26 --> Helper loaded: form_helper
INFO - 2020-02-04 15:02:26 --> Form Validation Class Initialized
INFO - 2020-02-04 15:02:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:02:26 --> Final output sent to browser
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:26 --> Total execution time: 0.6660
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
DEBUG - 2020-02-04 15:02:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:02:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:26 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:26 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:26 --> URI Class Initialized
DEBUG - 2020-02-04 15:02:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:26 --> URI Class Initialized
DEBUG - 2020-02-04 15:02:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:02:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:26 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:26 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:26 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:26 --> Router Class Initialized
INFO - 2020-02-04 15:02:26 --> Router Class Initialized
DEBUG - 2020-02-04 15:02:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:26 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:26 --> URI Class Initialized
INFO - 2020-02-04 15:02:26 --> Output Class Initialized
INFO - 2020-02-04 15:02:26 --> Output Class Initialized
INFO - 2020-02-04 15:02:26 --> URI Class Initialized
INFO - 2020-02-04 15:02:26 --> URI Class Initialized
INFO - 2020-02-04 15:02:26 --> Router Class Initialized
INFO - 2020-02-04 15:02:26 --> Security Class Initialized
INFO - 2020-02-04 15:02:26 --> Router Class Initialized
INFO - 2020-02-04 15:02:26 --> URI Class Initialized
INFO - 2020-02-04 15:02:26 --> Security Class Initialized
INFO - 2020-02-04 15:02:26 --> Router Class Initialized
DEBUG - 2020-02-04 15:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:26 --> Router Class Initialized
INFO - 2020-02-04 15:02:26 --> Output Class Initialized
INFO - 2020-02-04 15:02:26 --> Output Class Initialized
DEBUG - 2020-02-04 15:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:26 --> Output Class Initialized
INFO - 2020-02-04 15:02:26 --> Input Class Initialized
INFO - 2020-02-04 15:02:26 --> Input Class Initialized
INFO - 2020-02-04 15:02:26 --> Security Class Initialized
INFO - 2020-02-04 15:02:26 --> Security Class Initialized
INFO - 2020-02-04 15:02:26 --> Output Class Initialized
INFO - 2020-02-04 15:02:26 --> Security Class Initialized
INFO - 2020-02-04 15:02:26 --> Language Class Initialized
INFO - 2020-02-04 15:02:26 --> Language Class Initialized
DEBUG - 2020-02-04 15:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:26 --> Security Class Initialized
INFO - 2020-02-04 15:02:26 --> Input Class Initialized
INFO - 2020-02-04 15:02:26 --> Input Class Initialized
INFO - 2020-02-04 15:02:26 --> Input Class Initialized
DEBUG - 2020-02-04 15:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:26 --> Loader Class Initialized
INFO - 2020-02-04 15:02:26 --> Loader Class Initialized
INFO - 2020-02-04 15:02:26 --> Input Class Initialized
INFO - 2020-02-04 15:02:26 --> Language Class Initialized
INFO - 2020-02-04 15:02:26 --> Language Class Initialized
INFO - 2020-02-04 15:02:26 --> Helper loaded: url_helper
INFO - 2020-02-04 15:02:26 --> Helper loaded: url_helper
INFO - 2020-02-04 15:02:26 --> Language Class Initialized
ERROR - 2020-02-04 15:02:26 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:02:26 --> Language Class Initialized
ERROR - 2020-02-04 15:02:26 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 15:02:26 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 15:02:26 --> Database Driver Class Initialized
INFO - 2020-02-04 15:02:26 --> Database Driver Class Initialized
ERROR - 2020-02-04 15:02:26 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-04 15:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
DEBUG - 2020-02-04 15:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
INFO - 2020-02-04 15:02:26 --> Controller Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:02:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:02:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:26 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:26 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:26 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:26 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 15:02:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:26 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:26 --> URI Class Initialized
INFO - 2020-02-04 15:02:26 --> URI Class Initialized
INFO - 2020-02-04 15:02:26 --> URI Class Initialized
INFO - 2020-02-04 15:02:26 --> Helper loaded: form_helper
INFO - 2020-02-04 15:02:26 --> URI Class Initialized
INFO - 2020-02-04 15:02:26 --> Router Class Initialized
INFO - 2020-02-04 15:02:26 --> Form Validation Class Initialized
INFO - 2020-02-04 15:02:26 --> Router Class Initialized
INFO - 2020-02-04 15:02:26 --> Router Class Initialized
INFO - 2020-02-04 15:02:26 --> Output Class Initialized
INFO - 2020-02-04 15:02:26 --> Output Class Initialized
INFO - 2020-02-04 15:02:26 --> Router Class Initialized
INFO - 2020-02-04 15:02:26 --> Output Class Initialized
ERROR - 2020-02-04 15:02:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:02:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:02:26 --> Security Class Initialized
INFO - 2020-02-04 15:02:26 --> Output Class Initialized
INFO - 2020-02-04 15:02:26 --> Security Class Initialized
INFO - 2020-02-04 15:02:26 --> Security Class Initialized
INFO - 2020-02-04 15:02:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-04 15:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:26 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:26 --> Input Class Initialized
INFO - 2020-02-04 15:02:26 --> Final output sent to browser
INFO - 2020-02-04 15:02:26 --> Input Class Initialized
INFO - 2020-02-04 15:02:26 --> Input Class Initialized
DEBUG - 2020-02-04 15:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:02:26 --> Total execution time: 0.6743
INFO - 2020-02-04 15:02:26 --> Input Class Initialized
INFO - 2020-02-04 15:02:26 --> Language Class Initialized
INFO - 2020-02-04 15:02:26 --> Language Class Initialized
INFO - 2020-02-04 15:02:26 --> Language Class Initialized
INFO - 2020-02-04 15:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:02:26 --> Language Class Initialized
ERROR - 2020-02-04 15:02:26 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 15:02:26 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 15:02:26 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:26 --> Controller Class Initialized
ERROR - 2020-02-04 15:02:26 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
INFO - 2020-02-04 15:02:26 --> Config Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:26 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:26 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 15:02:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:27 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:02:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:02:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:02:27 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:27 --> Helper loaded: form_helper
INFO - 2020-02-04 15:02:27 --> Form Validation Class Initialized
INFO - 2020-02-04 15:02:27 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:27 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:27 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:27 --> URI Class Initialized
INFO - 2020-02-04 15:02:27 --> URI Class Initialized
INFO - 2020-02-04 15:02:27 --> URI Class Initialized
INFO - 2020-02-04 15:02:27 --> URI Class Initialized
INFO - 2020-02-04 15:02:27 --> Router Class Initialized
ERROR - 2020-02-04 15:02:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:02:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:02:27 --> Router Class Initialized
INFO - 2020-02-04 15:02:27 --> Output Class Initialized
INFO - 2020-02-04 15:02:27 --> Router Class Initialized
INFO - 2020-02-04 15:02:27 --> Router Class Initialized
INFO - 2020-02-04 15:02:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:02:27 --> Output Class Initialized
INFO - 2020-02-04 15:02:27 --> Output Class Initialized
INFO - 2020-02-04 15:02:27 --> Output Class Initialized
INFO - 2020-02-04 15:02:27 --> Security Class Initialized
INFO - 2020-02-04 15:02:27 --> Final output sent to browser
INFO - 2020-02-04 15:02:27 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:27 --> Security Class Initialized
INFO - 2020-02-04 15:02:27 --> Security Class Initialized
INFO - 2020-02-04 15:02:27 --> Input Class Initialized
DEBUG - 2020-02-04 15:02:27 --> Total execution time: 0.9483
DEBUG - 2020-02-04 15:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:27 --> Input Class Initialized
INFO - 2020-02-04 15:02:27 --> Input Class Initialized
INFO - 2020-02-04 15:02:27 --> Input Class Initialized
INFO - 2020-02-04 15:02:27 --> Language Class Initialized
INFO - 2020-02-04 15:02:27 --> Language Class Initialized
INFO - 2020-02-04 15:02:27 --> Language Class Initialized
ERROR - 2020-02-04 15:02:27 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:02:27 --> Language Class Initialized
ERROR - 2020-02-04 15:02:27 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 15:02:27 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 15:02:27 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:02:27 --> Config Class Initialized
INFO - 2020-02-04 15:02:27 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:27 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:27 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:27 --> URI Class Initialized
INFO - 2020-02-04 15:02:27 --> Router Class Initialized
INFO - 2020-02-04 15:02:27 --> Output Class Initialized
INFO - 2020-02-04 15:02:27 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:27 --> Input Class Initialized
INFO - 2020-02-04 15:02:27 --> Language Class Initialized
ERROR - 2020-02-04 15:02:27 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:02:27 --> Config Class Initialized
INFO - 2020-02-04 15:02:27 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:27 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:27 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:27 --> URI Class Initialized
INFO - 2020-02-04 15:02:27 --> Router Class Initialized
INFO - 2020-02-04 15:02:27 --> Output Class Initialized
INFO - 2020-02-04 15:02:27 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:27 --> Input Class Initialized
INFO - 2020-02-04 15:02:27 --> Language Class Initialized
ERROR - 2020-02-04 15:02:27 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:02:27 --> Config Class Initialized
INFO - 2020-02-04 15:02:27 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:27 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:28 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:28 --> URI Class Initialized
INFO - 2020-02-04 15:02:28 --> Router Class Initialized
INFO - 2020-02-04 15:02:28 --> Output Class Initialized
INFO - 2020-02-04 15:02:28 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:28 --> Input Class Initialized
INFO - 2020-02-04 15:02:28 --> Language Class Initialized
ERROR - 2020-02-04 15:02:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:02:28 --> Config Class Initialized
INFO - 2020-02-04 15:02:28 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:28 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:28 --> URI Class Initialized
INFO - 2020-02-04 15:02:28 --> Router Class Initialized
INFO - 2020-02-04 15:02:28 --> Output Class Initialized
INFO - 2020-02-04 15:02:28 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:28 --> Input Class Initialized
INFO - 2020-02-04 15:02:28 --> Language Class Initialized
ERROR - 2020-02-04 15:02:28 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:02:28 --> Config Class Initialized
INFO - 2020-02-04 15:02:28 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:28 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:28 --> URI Class Initialized
INFO - 2020-02-04 15:02:28 --> Router Class Initialized
INFO - 2020-02-04 15:02:28 --> Output Class Initialized
INFO - 2020-02-04 15:02:28 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:28 --> Input Class Initialized
INFO - 2020-02-04 15:02:28 --> Language Class Initialized
ERROR - 2020-02-04 15:02:28 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:02:28 --> Config Class Initialized
INFO - 2020-02-04 15:02:28 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:28 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:28 --> URI Class Initialized
INFO - 2020-02-04 15:02:28 --> Router Class Initialized
INFO - 2020-02-04 15:02:28 --> Output Class Initialized
INFO - 2020-02-04 15:02:28 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:29 --> Input Class Initialized
INFO - 2020-02-04 15:02:29 --> Language Class Initialized
ERROR - 2020-02-04 15:02:29 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:02:29 --> Config Class Initialized
INFO - 2020-02-04 15:02:29 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:29 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:29 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:29 --> URI Class Initialized
INFO - 2020-02-04 15:02:29 --> Router Class Initialized
INFO - 2020-02-04 15:02:29 --> Output Class Initialized
INFO - 2020-02-04 15:02:29 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:29 --> Input Class Initialized
INFO - 2020-02-04 15:02:29 --> Language Class Initialized
ERROR - 2020-02-04 15:02:29 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:02:29 --> Config Class Initialized
INFO - 2020-02-04 15:02:29 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:29 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:29 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:29 --> URI Class Initialized
INFO - 2020-02-04 15:02:29 --> Router Class Initialized
INFO - 2020-02-04 15:02:29 --> Output Class Initialized
INFO - 2020-02-04 15:02:29 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:29 --> Input Class Initialized
INFO - 2020-02-04 15:02:29 --> Language Class Initialized
ERROR - 2020-02-04 15:02:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:02:29 --> Config Class Initialized
INFO - 2020-02-04 15:02:29 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:29 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:29 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:29 --> URI Class Initialized
INFO - 2020-02-04 15:02:29 --> Router Class Initialized
INFO - 2020-02-04 15:02:29 --> Output Class Initialized
INFO - 2020-02-04 15:02:29 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:29 --> Input Class Initialized
INFO - 2020-02-04 15:02:29 --> Language Class Initialized
ERROR - 2020-02-04 15:02:29 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:02:40 --> Config Class Initialized
INFO - 2020-02-04 15:02:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:40 --> URI Class Initialized
INFO - 2020-02-04 15:02:40 --> Router Class Initialized
INFO - 2020-02-04 15:02:40 --> Output Class Initialized
INFO - 2020-02-04 15:02:40 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:40 --> Input Class Initialized
INFO - 2020-02-04 15:02:40 --> Language Class Initialized
INFO - 2020-02-04 15:02:40 --> Loader Class Initialized
INFO - 2020-02-04 15:02:40 --> Helper loaded: url_helper
INFO - 2020-02-04 15:02:40 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:02:40 --> Controller Class Initialized
INFO - 2020-02-04 15:02:40 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:02:40 --> Helper loaded: form_helper
INFO - 2020-02-04 15:02:40 --> Form Validation Class Initialized
INFO - 2020-02-04 15:02:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:02:40 --> Final output sent to browser
INFO - 2020-02-04 15:02:40 --> Config Class Initialized
INFO - 2020-02-04 15:02:40 --> Config Class Initialized
INFO - 2020-02-04 15:02:40 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:40 --> Total execution time: 0.5439
INFO - 2020-02-04 15:02:40 --> Config Class Initialized
DEBUG - 2020-02-04 15:02:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:40 --> Config Class Initialized
INFO - 2020-02-04 15:02:40 --> Config Class Initialized
INFO - 2020-02-04 15:02:40 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:40 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:40 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:40 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:02:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:40 --> Config Class Initialized
INFO - 2020-02-04 15:02:40 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:40 --> URI Class Initialized
DEBUG - 2020-02-04 15:02:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:02:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:02:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:40 --> Router Class Initialized
INFO - 2020-02-04 15:02:40 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:02:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:40 --> URI Class Initialized
INFO - 2020-02-04 15:02:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:40 --> URI Class Initialized
INFO - 2020-02-04 15:02:40 --> URI Class Initialized
INFO - 2020-02-04 15:02:40 --> Router Class Initialized
INFO - 2020-02-04 15:02:40 --> Output Class Initialized
INFO - 2020-02-04 15:02:40 --> URI Class Initialized
INFO - 2020-02-04 15:02:40 --> URI Class Initialized
INFO - 2020-02-04 15:02:40 --> Router Class Initialized
INFO - 2020-02-04 15:02:40 --> Output Class Initialized
INFO - 2020-02-04 15:02:40 --> Router Class Initialized
INFO - 2020-02-04 15:02:40 --> Security Class Initialized
INFO - 2020-02-04 15:02:40 --> Router Class Initialized
INFO - 2020-02-04 15:02:40 --> Security Class Initialized
INFO - 2020-02-04 15:02:40 --> Router Class Initialized
DEBUG - 2020-02-04 15:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:40 --> Output Class Initialized
INFO - 2020-02-04 15:02:40 --> Output Class Initialized
INFO - 2020-02-04 15:02:40 --> Output Class Initialized
INFO - 2020-02-04 15:02:40 --> Input Class Initialized
DEBUG - 2020-02-04 15:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:40 --> Security Class Initialized
INFO - 2020-02-04 15:02:40 --> Security Class Initialized
INFO - 2020-02-04 15:02:40 --> Output Class Initialized
INFO - 2020-02-04 15:02:40 --> Security Class Initialized
INFO - 2020-02-04 15:02:40 --> Input Class Initialized
INFO - 2020-02-04 15:02:40 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:40 --> Language Class Initialized
DEBUG - 2020-02-04 15:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:40 --> Input Class Initialized
INFO - 2020-02-04 15:02:40 --> Input Class Initialized
INFO - 2020-02-04 15:02:40 --> Language Class Initialized
INFO - 2020-02-04 15:02:40 --> Input Class Initialized
ERROR - 2020-02-04 15:02:40 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-04 15:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:41 --> Input Class Initialized
INFO - 2020-02-04 15:02:41 --> Language Class Initialized
INFO - 2020-02-04 15:02:41 --> Language Class Initialized
INFO - 2020-02-04 15:02:41 --> Language Class Initialized
ERROR - 2020-02-04 15:02:41 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 15:02:41 --> Config Class Initialized
INFO - 2020-02-04 15:02:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:41 --> Language Class Initialized
ERROR - 2020-02-04 15:02:41 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:02:41 --> Loader Class Initialized
INFO - 2020-02-04 15:02:41 --> Loader Class Initialized
INFO - 2020-02-04 15:02:41 --> Config Class Initialized
INFO - 2020-02-04 15:02:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:41 --> Helper loaded: url_helper
INFO - 2020-02-04 15:02:41 --> Helper loaded: url_helper
ERROR - 2020-02-04 15:02:41 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-04 15:02:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:41 --> Config Class Initialized
INFO - 2020-02-04 15:02:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:41 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:02:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:41 --> Database Driver Class Initialized
INFO - 2020-02-04 15:02:41 --> Database Driver Class Initialized
INFO - 2020-02-04 15:02:41 --> Config Class Initialized
INFO - 2020-02-04 15:02:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:41 --> URI Class Initialized
DEBUG - 2020-02-04 15:02:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 15:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:02:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:41 --> URI Class Initialized
INFO - 2020-02-04 15:02:41 --> Router Class Initialized
DEBUG - 2020-02-04 15:02:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:02:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:41 --> Controller Class Initialized
INFO - 2020-02-04 15:02:41 --> URI Class Initialized
INFO - 2020-02-04 15:02:41 --> Output Class Initialized
INFO - 2020-02-04 15:02:41 --> Router Class Initialized
INFO - 2020-02-04 15:02:41 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:02:41 --> Security Class Initialized
INFO - 2020-02-04 15:02:41 --> Router Class Initialized
INFO - 2020-02-04 15:02:41 --> Output Class Initialized
INFO - 2020-02-04 15:02:41 --> URI Class Initialized
INFO - 2020-02-04 15:02:41 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:41 --> Router Class Initialized
INFO - 2020-02-04 15:02:41 --> Helper loaded: form_helper
INFO - 2020-02-04 15:02:41 --> Output Class Initialized
INFO - 2020-02-04 15:02:41 --> Form Validation Class Initialized
INFO - 2020-02-04 15:02:41 --> Input Class Initialized
INFO - 2020-02-04 15:02:41 --> Security Class Initialized
INFO - 2020-02-04 15:02:41 --> Output Class Initialized
DEBUG - 2020-02-04 15:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:41 --> Input Class Initialized
INFO - 2020-02-04 15:02:41 --> Language Class Initialized
DEBUG - 2020-02-04 15:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:41 --> Security Class Initialized
ERROR - 2020-02-04 15:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:02:41 --> Input Class Initialized
DEBUG - 2020-02-04 15:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 15:02:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 15:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:02:41 --> Language Class Initialized
INFO - 2020-02-04 15:02:41 --> Input Class Initialized
INFO - 2020-02-04 15:02:41 --> Language Class Initialized
ERROR - 2020-02-04 15:02:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:02:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:02:41 --> Config Class Initialized
INFO - 2020-02-04 15:02:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:41 --> Language Class Initialized
INFO - 2020-02-04 15:02:41 --> Final output sent to browser
ERROR - 2020-02-04 15:02:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:02:41 --> Config Class Initialized
INFO - 2020-02-04 15:02:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:41 --> Total execution time: 0.6759
ERROR - 2020-02-04 15:02:41 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-04 15:02:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:41 --> Config Class Initialized
INFO - 2020-02-04 15:02:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:02:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:41 --> Config Class Initialized
INFO - 2020-02-04 15:02:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:02:41 --> Controller Class Initialized
INFO - 2020-02-04 15:02:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:41 --> URI Class Initialized
DEBUG - 2020-02-04 15:02:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:41 --> Router Class Initialized
INFO - 2020-02-04 15:02:41 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 15:02:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:41 --> URI Class Initialized
INFO - 2020-02-04 15:02:41 --> URI Class Initialized
INFO - 2020-02-04 15:02:41 --> Output Class Initialized
INFO - 2020-02-04 15:02:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:41 --> Router Class Initialized
INFO - 2020-02-04 15:02:41 --> Helper loaded: form_helper
INFO - 2020-02-04 15:02:41 --> Form Validation Class Initialized
INFO - 2020-02-04 15:02:41 --> Security Class Initialized
INFO - 2020-02-04 15:02:41 --> Router Class Initialized
INFO - 2020-02-04 15:02:41 --> Output Class Initialized
INFO - 2020-02-04 15:02:41 --> URI Class Initialized
INFO - 2020-02-04 15:02:41 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:41 --> Router Class Initialized
INFO - 2020-02-04 15:02:41 --> Output Class Initialized
ERROR - 2020-02-04 15:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:02:41 --> Input Class Initialized
ERROR - 2020-02-04 15:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-04 15:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:41 --> Security Class Initialized
INFO - 2020-02-04 15:02:41 --> Output Class Initialized
INFO - 2020-02-04 15:02:41 --> Input Class Initialized
INFO - 2020-02-04 15:02:41 --> Language Class Initialized
INFO - 2020-02-04 15:02:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-04 15:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:41 --> Security Class Initialized
INFO - 2020-02-04 15:02:41 --> Final output sent to browser
INFO - 2020-02-04 15:02:41 --> Language Class Initialized
ERROR - 2020-02-04 15:02:41 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:02:41 --> Input Class Initialized
DEBUG - 2020-02-04 15:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:41 --> Input Class Initialized
DEBUG - 2020-02-04 15:02:41 --> Total execution time: 0.9258
INFO - 2020-02-04 15:02:41 --> Language Class Initialized
ERROR - 2020-02-04 15:02:41 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:02:41 --> Language Class Initialized
ERROR - 2020-02-04 15:02:41 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 15:02:41 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 15:02:41 --> Config Class Initialized
INFO - 2020-02-04 15:02:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:41 --> URI Class Initialized
INFO - 2020-02-04 15:02:41 --> Router Class Initialized
INFO - 2020-02-04 15:02:41 --> Output Class Initialized
INFO - 2020-02-04 15:02:41 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:41 --> Input Class Initialized
INFO - 2020-02-04 15:02:42 --> Language Class Initialized
ERROR - 2020-02-04 15:02:42 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:02:42 --> Config Class Initialized
INFO - 2020-02-04 15:02:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:42 --> URI Class Initialized
INFO - 2020-02-04 15:02:42 --> Router Class Initialized
INFO - 2020-02-04 15:02:42 --> Output Class Initialized
INFO - 2020-02-04 15:02:42 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:42 --> Input Class Initialized
INFO - 2020-02-04 15:02:42 --> Language Class Initialized
ERROR - 2020-02-04 15:02:42 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:02:42 --> Config Class Initialized
INFO - 2020-02-04 15:02:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:42 --> URI Class Initialized
INFO - 2020-02-04 15:02:42 --> Router Class Initialized
INFO - 2020-02-04 15:02:42 --> Output Class Initialized
INFO - 2020-02-04 15:02:42 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:42 --> Input Class Initialized
INFO - 2020-02-04 15:02:42 --> Language Class Initialized
ERROR - 2020-02-04 15:02:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:02:42 --> Config Class Initialized
INFO - 2020-02-04 15:02:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:42 --> URI Class Initialized
INFO - 2020-02-04 15:02:42 --> Router Class Initialized
INFO - 2020-02-04 15:02:42 --> Output Class Initialized
INFO - 2020-02-04 15:02:42 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:42 --> Input Class Initialized
INFO - 2020-02-04 15:02:42 --> Language Class Initialized
ERROR - 2020-02-04 15:02:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:02:42 --> Config Class Initialized
INFO - 2020-02-04 15:02:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:43 --> URI Class Initialized
INFO - 2020-02-04 15:02:43 --> Router Class Initialized
INFO - 2020-02-04 15:02:43 --> Output Class Initialized
INFO - 2020-02-04 15:02:43 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:43 --> Input Class Initialized
INFO - 2020-02-04 15:02:43 --> Language Class Initialized
ERROR - 2020-02-04 15:02:43 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:02:43 --> Config Class Initialized
INFO - 2020-02-04 15:02:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:43 --> URI Class Initialized
INFO - 2020-02-04 15:02:43 --> Router Class Initialized
INFO - 2020-02-04 15:02:43 --> Output Class Initialized
INFO - 2020-02-04 15:02:43 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:43 --> Input Class Initialized
INFO - 2020-02-04 15:02:43 --> Language Class Initialized
ERROR - 2020-02-04 15:02:43 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:02:43 --> Config Class Initialized
INFO - 2020-02-04 15:02:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:43 --> URI Class Initialized
INFO - 2020-02-04 15:02:43 --> Router Class Initialized
INFO - 2020-02-04 15:02:43 --> Output Class Initialized
INFO - 2020-02-04 15:02:43 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:43 --> Input Class Initialized
INFO - 2020-02-04 15:02:43 --> Language Class Initialized
ERROR - 2020-02-04 15:02:43 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:02:43 --> Config Class Initialized
INFO - 2020-02-04 15:02:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:43 --> URI Class Initialized
INFO - 2020-02-04 15:02:43 --> Router Class Initialized
INFO - 2020-02-04 15:02:43 --> Output Class Initialized
INFO - 2020-02-04 15:02:44 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:44 --> Input Class Initialized
INFO - 2020-02-04 15:02:44 --> Language Class Initialized
ERROR - 2020-02-04 15:02:44 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:02:44 --> Config Class Initialized
INFO - 2020-02-04 15:02:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:02:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:02:44 --> Utf8 Class Initialized
INFO - 2020-02-04 15:02:44 --> URI Class Initialized
INFO - 2020-02-04 15:02:44 --> Router Class Initialized
INFO - 2020-02-04 15:02:44 --> Output Class Initialized
INFO - 2020-02-04 15:02:44 --> Security Class Initialized
DEBUG - 2020-02-04 15:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:02:44 --> Input Class Initialized
INFO - 2020-02-04 15:02:44 --> Language Class Initialized
ERROR - 2020-02-04 15:02:44 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:04:28 --> Config Class Initialized
INFO - 2020-02-04 15:04:28 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:04:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:04:28 --> Utf8 Class Initialized
INFO - 2020-02-04 15:04:28 --> URI Class Initialized
INFO - 2020-02-04 15:04:28 --> Router Class Initialized
INFO - 2020-02-04 15:04:29 --> Output Class Initialized
INFO - 2020-02-04 15:04:29 --> Security Class Initialized
DEBUG - 2020-02-04 15:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:04:29 --> Input Class Initialized
INFO - 2020-02-04 15:04:29 --> Language Class Initialized
INFO - 2020-02-04 15:04:29 --> Loader Class Initialized
INFO - 2020-02-04 15:04:29 --> Helper loaded: url_helper
INFO - 2020-02-04 15:04:29 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:04:29 --> Controller Class Initialized
INFO - 2020-02-04 15:04:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 15:04:29 --> Pagination Class Initialized
INFO - 2020-02-04 15:04:29 --> Model "M_show" initialized
INFO - 2020-02-04 15:04:29 --> Helper loaded: form_helper
INFO - 2020-02-04 15:04:29 --> Form Validation Class Initialized
INFO - 2020-02-04 15:04:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-04 15:04:29 --> Config Class Initialized
INFO - 2020-02-04 15:04:30 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:04:30 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:04:30 --> Utf8 Class Initialized
INFO - 2020-02-04 15:04:30 --> URI Class Initialized
INFO - 2020-02-04 15:04:30 --> Router Class Initialized
INFO - 2020-02-04 15:04:30 --> Output Class Initialized
INFO - 2020-02-04 15:04:30 --> Security Class Initialized
DEBUG - 2020-02-04 15:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:04:30 --> Input Class Initialized
INFO - 2020-02-04 15:04:30 --> Language Class Initialized
ERROR - 2020-02-04 15:04:31 --> 404 Page Not Found: Show/show_list
INFO - 2020-02-04 15:04:33 --> Config Class Initialized
INFO - 2020-02-04 15:04:33 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:04:33 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:04:34 --> Utf8 Class Initialized
INFO - 2020-02-04 15:04:34 --> URI Class Initialized
INFO - 2020-02-04 15:04:34 --> Router Class Initialized
INFO - 2020-02-04 15:04:34 --> Output Class Initialized
INFO - 2020-02-04 15:04:34 --> Security Class Initialized
DEBUG - 2020-02-04 15:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:04:34 --> Input Class Initialized
INFO - 2020-02-04 15:04:34 --> Language Class Initialized
INFO - 2020-02-04 15:04:34 --> Loader Class Initialized
INFO - 2020-02-04 15:04:34 --> Helper loaded: url_helper
INFO - 2020-02-04 15:04:34 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:04:35 --> Controller Class Initialized
INFO - 2020-02-04 15:04:35 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:04:35 --> Helper loaded: form_helper
INFO - 2020-02-04 15:04:35 --> Form Validation Class Initialized
INFO - 2020-02-04 15:04:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:04:35 --> Final output sent to browser
DEBUG - 2020-02-04 15:04:35 --> Total execution time: 1.5331
INFO - 2020-02-04 15:04:35 --> Config Class Initialized
INFO - 2020-02-04 15:04:35 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:04:35 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:04:35 --> Utf8 Class Initialized
INFO - 2020-02-04 15:04:35 --> URI Class Initialized
INFO - 2020-02-04 15:04:35 --> Router Class Initialized
INFO - 2020-02-04 15:04:35 --> Output Class Initialized
INFO - 2020-02-04 15:04:35 --> Security Class Initialized
DEBUG - 2020-02-04 15:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:04:35 --> Input Class Initialized
INFO - 2020-02-04 15:04:35 --> Language Class Initialized
ERROR - 2020-02-04 15:04:35 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 15:13:40 --> Config Class Initialized
INFO - 2020-02-04 15:13:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:13:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:40 --> URI Class Initialized
INFO - 2020-02-04 15:13:40 --> Router Class Initialized
INFO - 2020-02-04 15:13:40 --> Output Class Initialized
INFO - 2020-02-04 15:13:40 --> Security Class Initialized
DEBUG - 2020-02-04 15:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:41 --> Input Class Initialized
INFO - 2020-02-04 15:13:41 --> Language Class Initialized
INFO - 2020-02-04 15:13:41 --> Loader Class Initialized
INFO - 2020-02-04 15:13:41 --> Helper loaded: url_helper
INFO - 2020-02-04 15:13:41 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:13:41 --> Controller Class Initialized
INFO - 2020-02-04 15:13:41 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:13:41 --> Helper loaded: form_helper
INFO - 2020-02-04 15:13:41 --> Form Validation Class Initialized
INFO - 2020-02-04 15:13:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:13:41 --> Final output sent to browser
INFO - 2020-02-04 15:13:41 --> Config Class Initialized
INFO - 2020-02-04 15:13:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:13:41 --> Total execution time: 1.5711
INFO - 2020-02-04 15:13:41 --> Config Class Initialized
INFO - 2020-02-04 15:13:41 --> Config Class Initialized
INFO - 2020-02-04 15:13:41 --> Config Class Initialized
INFO - 2020-02-04 15:13:41 --> Config Class Initialized
INFO - 2020-02-04 15:13:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:13:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:13:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:13:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:13:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:41 --> Config Class Initialized
INFO - 2020-02-04 15:13:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:13:41 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:13:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:13:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:13:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:13:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:41 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:13:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:41 --> URI Class Initialized
INFO - 2020-02-04 15:13:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:41 --> URI Class Initialized
INFO - 2020-02-04 15:13:41 --> URI Class Initialized
INFO - 2020-02-04 15:13:41 --> Router Class Initialized
INFO - 2020-02-04 15:13:41 --> URI Class Initialized
INFO - 2020-02-04 15:13:41 --> URI Class Initialized
INFO - 2020-02-04 15:13:41 --> Router Class Initialized
INFO - 2020-02-04 15:13:41 --> Router Class Initialized
INFO - 2020-02-04 15:13:41 --> Router Class Initialized
INFO - 2020-02-04 15:13:41 --> URI Class Initialized
INFO - 2020-02-04 15:13:41 --> Output Class Initialized
INFO - 2020-02-04 15:13:41 --> Router Class Initialized
INFO - 2020-02-04 15:13:41 --> Router Class Initialized
INFO - 2020-02-04 15:13:41 --> Output Class Initialized
INFO - 2020-02-04 15:13:41 --> Output Class Initialized
INFO - 2020-02-04 15:13:41 --> Output Class Initialized
INFO - 2020-02-04 15:13:41 --> Security Class Initialized
INFO - 2020-02-04 15:13:41 --> Output Class Initialized
INFO - 2020-02-04 15:13:42 --> Security Class Initialized
INFO - 2020-02-04 15:13:42 --> Security Class Initialized
INFO - 2020-02-04 15:13:42 --> Security Class Initialized
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:42 --> Security Class Initialized
INFO - 2020-02-04 15:13:42 --> Output Class Initialized
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:42 --> Security Class Initialized
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
INFO - 2020-02-04 15:13:42 --> Language Class Initialized
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
INFO - 2020-02-04 15:13:42 --> Language Class Initialized
INFO - 2020-02-04 15:13:42 --> Language Class Initialized
INFO - 2020-02-04 15:13:42 --> Language Class Initialized
INFO - 2020-02-04 15:13:42 --> Language Class Initialized
ERROR - 2020-02-04 15:13:42 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 15:13:42 --> Language Class Initialized
ERROR - 2020-02-04 15:13:42 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 15:13:42 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:13:42 --> Loader Class Initialized
INFO - 2020-02-04 15:13:42 --> Loader Class Initialized
INFO - 2020-02-04 15:13:42 --> Config Class Initialized
INFO - 2020-02-04 15:13:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:13:42 --> Helper loaded: url_helper
INFO - 2020-02-04 15:13:42 --> Helper loaded: url_helper
ERROR - 2020-02-04 15:13:42 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:13:42 --> Config Class Initialized
INFO - 2020-02-04 15:13:42 --> Config Class Initialized
INFO - 2020-02-04 15:13:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:13:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:13:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:42 --> Database Driver Class Initialized
INFO - 2020-02-04 15:13:42 --> Database Driver Class Initialized
INFO - 2020-02-04 15:13:42 --> Config Class Initialized
INFO - 2020-02-04 15:13:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:13:42 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:13:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:13:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 15:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:13:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:42 --> URI Class Initialized
DEBUG - 2020-02-04 15:13:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:42 --> Controller Class Initialized
INFO - 2020-02-04 15:13:42 --> URI Class Initialized
INFO - 2020-02-04 15:13:42 --> URI Class Initialized
INFO - 2020-02-04 15:13:42 --> Router Class Initialized
INFO - 2020-02-04 15:13:42 --> Router Class Initialized
INFO - 2020-02-04 15:13:42 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:13:42 --> Router Class Initialized
INFO - 2020-02-04 15:13:42 --> Output Class Initialized
INFO - 2020-02-04 15:13:42 --> URI Class Initialized
INFO - 2020-02-04 15:13:42 --> Router Class Initialized
INFO - 2020-02-04 15:13:42 --> Security Class Initialized
INFO - 2020-02-04 15:13:42 --> Output Class Initialized
INFO - 2020-02-04 15:13:42 --> Helper loaded: form_helper
INFO - 2020-02-04 15:13:42 --> Output Class Initialized
INFO - 2020-02-04 15:13:42 --> Form Validation Class Initialized
INFO - 2020-02-04 15:13:42 --> Security Class Initialized
INFO - 2020-02-04 15:13:42 --> Security Class Initialized
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:42 --> Output Class Initialized
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:42 --> Security Class Initialized
ERROR - 2020-02-04 15:13:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
INFO - 2020-02-04 15:13:42 --> Language Class Initialized
ERROR - 2020-02-04 15:13:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:42 --> Language Class Initialized
INFO - 2020-02-04 15:13:42 --> Language Class Initialized
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
ERROR - 2020-02-04 15:13:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:13:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:13:42 --> Language Class Initialized
ERROR - 2020-02-04 15:13:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:13:42 --> Final output sent to browser
ERROR - 2020-02-04 15:13:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:13:42 --> Config Class Initialized
INFO - 2020-02-04 15:13:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:13:42 --> Total execution time: 0.8309
ERROR - 2020-02-04 15:13:42 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:13:42 --> Config Class Initialized
INFO - 2020-02-04 15:13:42 --> Config Class Initialized
INFO - 2020-02-04 15:13:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:13:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:13:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:13:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:42 --> Config Class Initialized
INFO - 2020-02-04 15:13:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:13:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:42 --> Controller Class Initialized
DEBUG - 2020-02-04 15:13:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:13:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:42 --> URI Class Initialized
INFO - 2020-02-04 15:13:42 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 15:13:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:42 --> URI Class Initialized
INFO - 2020-02-04 15:13:42 --> Router Class Initialized
INFO - 2020-02-04 15:13:42 --> URI Class Initialized
INFO - 2020-02-04 15:13:42 --> Helper loaded: form_helper
INFO - 2020-02-04 15:13:42 --> Form Validation Class Initialized
INFO - 2020-02-04 15:13:42 --> Router Class Initialized
INFO - 2020-02-04 15:13:42 --> Router Class Initialized
INFO - 2020-02-04 15:13:42 --> Output Class Initialized
INFO - 2020-02-04 15:13:42 --> URI Class Initialized
INFO - 2020-02-04 15:13:42 --> Security Class Initialized
INFO - 2020-02-04 15:13:42 --> Output Class Initialized
INFO - 2020-02-04 15:13:42 --> Output Class Initialized
INFO - 2020-02-04 15:13:42 --> Router Class Initialized
ERROR - 2020-02-04 15:13:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:13:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:42 --> Security Class Initialized
INFO - 2020-02-04 15:13:42 --> Security Class Initialized
INFO - 2020-02-04 15:13:42 --> Output Class Initialized
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
INFO - 2020-02-04 15:13:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:13:42 --> Security Class Initialized
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
INFO - 2020-02-04 15:13:42 --> Final output sent to browser
INFO - 2020-02-04 15:13:42 --> Language Class Initialized
DEBUG - 2020-02-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:13:42 --> Total execution time: 1.2074
INFO - 2020-02-04 15:13:42 --> Input Class Initialized
INFO - 2020-02-04 15:13:42 --> Language Class Initialized
INFO - 2020-02-04 15:13:42 --> Language Class Initialized
ERROR - 2020-02-04 15:13:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:13:43 --> Language Class Initialized
ERROR - 2020-02-04 15:13:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 15:13:43 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 15:13:43 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:13:43 --> Config Class Initialized
INFO - 2020-02-04 15:13:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:13:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:43 --> URI Class Initialized
INFO - 2020-02-04 15:13:43 --> Router Class Initialized
INFO - 2020-02-04 15:13:43 --> Output Class Initialized
INFO - 2020-02-04 15:13:43 --> Security Class Initialized
DEBUG - 2020-02-04 15:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:43 --> Input Class Initialized
INFO - 2020-02-04 15:13:43 --> Language Class Initialized
ERROR - 2020-02-04 15:13:43 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:13:43 --> Config Class Initialized
INFO - 2020-02-04 15:13:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:13:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:43 --> URI Class Initialized
INFO - 2020-02-04 15:13:43 --> Router Class Initialized
INFO - 2020-02-04 15:13:43 --> Output Class Initialized
INFO - 2020-02-04 15:13:43 --> Security Class Initialized
DEBUG - 2020-02-04 15:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:43 --> Input Class Initialized
INFO - 2020-02-04 15:13:43 --> Language Class Initialized
ERROR - 2020-02-04 15:13:43 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:13:43 --> Config Class Initialized
INFO - 2020-02-04 15:13:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:13:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:44 --> URI Class Initialized
INFO - 2020-02-04 15:13:44 --> Router Class Initialized
INFO - 2020-02-04 15:13:44 --> Output Class Initialized
INFO - 2020-02-04 15:13:44 --> Security Class Initialized
DEBUG - 2020-02-04 15:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:44 --> Input Class Initialized
INFO - 2020-02-04 15:13:44 --> Language Class Initialized
ERROR - 2020-02-04 15:13:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:13:44 --> Config Class Initialized
INFO - 2020-02-04 15:13:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:13:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:44 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:44 --> URI Class Initialized
INFO - 2020-02-04 15:13:44 --> Router Class Initialized
INFO - 2020-02-04 15:13:44 --> Output Class Initialized
INFO - 2020-02-04 15:13:44 --> Security Class Initialized
DEBUG - 2020-02-04 15:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:44 --> Input Class Initialized
INFO - 2020-02-04 15:13:44 --> Language Class Initialized
ERROR - 2020-02-04 15:13:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:13:44 --> Config Class Initialized
INFO - 2020-02-04 15:13:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:13:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:44 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:44 --> URI Class Initialized
INFO - 2020-02-04 15:13:44 --> Router Class Initialized
INFO - 2020-02-04 15:13:44 --> Output Class Initialized
INFO - 2020-02-04 15:13:44 --> Security Class Initialized
DEBUG - 2020-02-04 15:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:44 --> Input Class Initialized
INFO - 2020-02-04 15:13:45 --> Language Class Initialized
ERROR - 2020-02-04 15:13:45 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:13:45 --> Config Class Initialized
INFO - 2020-02-04 15:13:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:13:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:45 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:45 --> URI Class Initialized
INFO - 2020-02-04 15:13:45 --> Router Class Initialized
INFO - 2020-02-04 15:13:45 --> Output Class Initialized
INFO - 2020-02-04 15:13:45 --> Security Class Initialized
DEBUG - 2020-02-04 15:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:45 --> Input Class Initialized
INFO - 2020-02-04 15:13:45 --> Language Class Initialized
ERROR - 2020-02-04 15:13:45 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:13:45 --> Config Class Initialized
INFO - 2020-02-04 15:13:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:13:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:45 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:45 --> URI Class Initialized
INFO - 2020-02-04 15:13:45 --> Router Class Initialized
INFO - 2020-02-04 15:13:45 --> Output Class Initialized
INFO - 2020-02-04 15:13:45 --> Security Class Initialized
DEBUG - 2020-02-04 15:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:45 --> Input Class Initialized
INFO - 2020-02-04 15:13:45 --> Language Class Initialized
ERROR - 2020-02-04 15:13:45 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:13:45 --> Config Class Initialized
INFO - 2020-02-04 15:13:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:13:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:13:46 --> Utf8 Class Initialized
INFO - 2020-02-04 15:13:46 --> URI Class Initialized
INFO - 2020-02-04 15:13:46 --> Router Class Initialized
INFO - 2020-02-04 15:13:46 --> Output Class Initialized
INFO - 2020-02-04 15:13:46 --> Security Class Initialized
DEBUG - 2020-02-04 15:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:13:46 --> Input Class Initialized
INFO - 2020-02-04 15:13:46 --> Language Class Initialized
ERROR - 2020-02-04 15:13:46 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:14:49 --> Config Class Initialized
INFO - 2020-02-04 15:14:49 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:49 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:49 --> URI Class Initialized
INFO - 2020-02-04 15:14:49 --> Router Class Initialized
INFO - 2020-02-04 15:14:49 --> Output Class Initialized
INFO - 2020-02-04 15:14:49 --> Security Class Initialized
DEBUG - 2020-02-04 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:49 --> Input Class Initialized
INFO - 2020-02-04 15:14:49 --> Language Class Initialized
INFO - 2020-02-04 15:14:49 --> Loader Class Initialized
INFO - 2020-02-04 15:14:49 --> Helper loaded: url_helper
INFO - 2020-02-04 15:14:49 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:14:49 --> Controller Class Initialized
INFO - 2020-02-04 15:14:49 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:14:49 --> Helper loaded: form_helper
INFO - 2020-02-04 15:14:49 --> Form Validation Class Initialized
INFO - 2020-02-04 15:14:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:14:50 --> Final output sent to browser
INFO - 2020-02-04 15:14:50 --> Config Class Initialized
INFO - 2020-02-04 15:14:50 --> Config Class Initialized
INFO - 2020-02-04 15:14:50 --> Config Class Initialized
INFO - 2020-02-04 15:14:50 --> Hooks Class Initialized
INFO - 2020-02-04 15:14:50 --> Hooks Class Initialized
INFO - 2020-02-04 15:14:50 --> Hooks Class Initialized
INFO - 2020-02-04 15:14:50 --> Config Class Initialized
DEBUG - 2020-02-04 15:14:50 --> Total execution time: 0.7745
DEBUG - 2020-02-04 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:50 --> Config Class Initialized
INFO - 2020-02-04 15:14:50 --> Hooks Class Initialized
INFO - 2020-02-04 15:14:50 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:50 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:50 --> Config Class Initialized
INFO - 2020-02-04 15:14:50 --> Hooks Class Initialized
INFO - 2020-02-04 15:14:50 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:50 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:50 --> URI Class Initialized
DEBUG - 2020-02-04 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:50 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:50 --> URI Class Initialized
INFO - 2020-02-04 15:14:50 --> Router Class Initialized
INFO - 2020-02-04 15:14:50 --> URI Class Initialized
INFO - 2020-02-04 15:14:50 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:50 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:50 --> URI Class Initialized
INFO - 2020-02-04 15:14:50 --> Router Class Initialized
INFO - 2020-02-04 15:14:50 --> Output Class Initialized
INFO - 2020-02-04 15:14:50 --> Router Class Initialized
INFO - 2020-02-04 15:14:50 --> URI Class Initialized
INFO - 2020-02-04 15:14:50 --> Security Class Initialized
INFO - 2020-02-04 15:14:50 --> Router Class Initialized
INFO - 2020-02-04 15:14:50 --> Router Class Initialized
INFO - 2020-02-04 15:14:50 --> Output Class Initialized
INFO - 2020-02-04 15:14:50 --> URI Class Initialized
INFO - 2020-02-04 15:14:50 --> Output Class Initialized
INFO - 2020-02-04 15:14:50 --> Security Class Initialized
INFO - 2020-02-04 15:14:50 --> Security Class Initialized
INFO - 2020-02-04 15:14:50 --> Router Class Initialized
INFO - 2020-02-04 15:14:50 --> Output Class Initialized
DEBUG - 2020-02-04 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:50 --> Output Class Initialized
INFO - 2020-02-04 15:14:50 --> Input Class Initialized
DEBUG - 2020-02-04 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:50 --> Security Class Initialized
INFO - 2020-02-04 15:14:50 --> Output Class Initialized
DEBUG - 2020-02-04 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:50 --> Security Class Initialized
INFO - 2020-02-04 15:14:50 --> Input Class Initialized
INFO - 2020-02-04 15:14:50 --> Input Class Initialized
INFO - 2020-02-04 15:14:50 --> Language Class Initialized
INFO - 2020-02-04 15:14:50 --> Security Class Initialized
DEBUG - 2020-02-04 15:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:50 --> Input Class Initialized
INFO - 2020-02-04 15:14:50 --> Language Class Initialized
ERROR - 2020-02-04 15:14:50 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-04 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:50 --> Input Class Initialized
INFO - 2020-02-04 15:14:50 --> Language Class Initialized
INFO - 2020-02-04 15:14:50 --> Input Class Initialized
INFO - 2020-02-04 15:14:50 --> Language Class Initialized
INFO - 2020-02-04 15:14:50 --> Language Class Initialized
ERROR - 2020-02-04 15:14:50 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 15:14:50 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:14:50 --> Config Class Initialized
INFO - 2020-02-04 15:14:50 --> Hooks Class Initialized
INFO - 2020-02-04 15:14:50 --> Language Class Initialized
ERROR - 2020-02-04 15:14:50 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 15:14:50 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:14:50 --> Config Class Initialized
INFO - 2020-02-04 15:14:50 --> Config Class Initialized
INFO - 2020-02-04 15:14:50 --> Hooks Class Initialized
INFO - 2020-02-04 15:14:50 --> Hooks Class Initialized
ERROR - 2020-02-04 15:14:50 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-04 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:50 --> Config Class Initialized
INFO - 2020-02-04 15:14:50 --> Config Class Initialized
INFO - 2020-02-04 15:14:50 --> Hooks Class Initialized
INFO - 2020-02-04 15:14:50 --> Hooks Class Initialized
INFO - 2020-02-04 15:14:50 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:14:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:50 --> Config Class Initialized
INFO - 2020-02-04 15:14:50 --> Hooks Class Initialized
INFO - 2020-02-04 15:14:50 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:50 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:50 --> URI Class Initialized
DEBUG - 2020-02-04 15:14:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:50 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:50 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:50 --> URI Class Initialized
INFO - 2020-02-04 15:14:50 --> URI Class Initialized
INFO - 2020-02-04 15:14:50 --> Router Class Initialized
DEBUG - 2020-02-04 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:50 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:50 --> URI Class Initialized
INFO - 2020-02-04 15:14:50 --> URI Class Initialized
INFO - 2020-02-04 15:14:50 --> Router Class Initialized
INFO - 2020-02-04 15:14:50 --> Router Class Initialized
INFO - 2020-02-04 15:14:50 --> Output Class Initialized
INFO - 2020-02-04 15:14:50 --> Security Class Initialized
INFO - 2020-02-04 15:14:50 --> Router Class Initialized
INFO - 2020-02-04 15:14:50 --> URI Class Initialized
INFO - 2020-02-04 15:14:50 --> Output Class Initialized
INFO - 2020-02-04 15:14:50 --> Output Class Initialized
INFO - 2020-02-04 15:14:50 --> Router Class Initialized
DEBUG - 2020-02-04 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:50 --> Security Class Initialized
INFO - 2020-02-04 15:14:50 --> Security Class Initialized
INFO - 2020-02-04 15:14:50 --> Output Class Initialized
INFO - 2020-02-04 15:14:50 --> Router Class Initialized
INFO - 2020-02-04 15:14:50 --> Output Class Initialized
INFO - 2020-02-04 15:14:50 --> Input Class Initialized
DEBUG - 2020-02-04 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:50 --> Security Class Initialized
INFO - 2020-02-04 15:14:50 --> Output Class Initialized
DEBUG - 2020-02-04 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:50 --> Security Class Initialized
INFO - 2020-02-04 15:14:50 --> Input Class Initialized
INFO - 2020-02-04 15:14:50 --> Language Class Initialized
INFO - 2020-02-04 15:14:50 --> Security Class Initialized
DEBUG - 2020-02-04 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:50 --> Input Class Initialized
DEBUG - 2020-02-04 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:50 --> Input Class Initialized
INFO - 2020-02-04 15:14:50 --> Input Class Initialized
INFO - 2020-02-04 15:14:50 --> Language Class Initialized
INFO - 2020-02-04 15:14:50 --> Language Class Initialized
ERROR - 2020-02-04 15:14:50 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-04 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:50 --> Input Class Initialized
INFO - 2020-02-04 15:14:50 --> Language Class Initialized
INFO - 2020-02-04 15:14:50 --> Language Class Initialized
ERROR - 2020-02-04 15:14:50 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:14:50 --> Loader Class Initialized
INFO - 2020-02-04 15:14:50 --> Config Class Initialized
INFO - 2020-02-04 15:14:50 --> Hooks Class Initialized
INFO - 2020-02-04 15:14:50 --> Helper loaded: url_helper
ERROR - 2020-02-04 15:14:50 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:14:50 --> Language Class Initialized
INFO - 2020-02-04 15:14:50 --> Loader Class Initialized
INFO - 2020-02-04 15:14:51 --> Config Class Initialized
INFO - 2020-02-04 15:14:51 --> Hooks Class Initialized
ERROR - 2020-02-04 15:14:51 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-04 15:14:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:51 --> Helper loaded: url_helper
INFO - 2020-02-04 15:14:51 --> Database Driver Class Initialized
INFO - 2020-02-04 15:14:51 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:14:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:14:51 --> Database Driver Class Initialized
INFO - 2020-02-04 15:14:51 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:51 --> URI Class Initialized
INFO - 2020-02-04 15:14:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:14:51 --> Controller Class Initialized
INFO - 2020-02-04 15:14:51 --> URI Class Initialized
INFO - 2020-02-04 15:14:51 --> Router Class Initialized
INFO - 2020-02-04 15:14:51 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:14:51 --> Output Class Initialized
INFO - 2020-02-04 15:14:51 --> Router Class Initialized
INFO - 2020-02-04 15:14:51 --> Output Class Initialized
INFO - 2020-02-04 15:14:51 --> Security Class Initialized
INFO - 2020-02-04 15:14:51 --> Helper loaded: form_helper
INFO - 2020-02-04 15:14:51 --> Form Validation Class Initialized
INFO - 2020-02-04 15:14:51 --> Security Class Initialized
DEBUG - 2020-02-04 15:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:51 --> Input Class Initialized
DEBUG - 2020-02-04 15:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 15:14:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:14:51 --> Input Class Initialized
INFO - 2020-02-04 15:14:51 --> Language Class Initialized
ERROR - 2020-02-04 15:14:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:14:51 --> Language Class Initialized
INFO - 2020-02-04 15:14:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-04 15:14:51 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:14:51 --> Final output sent to browser
ERROR - 2020-02-04 15:14:51 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-04 15:14:51 --> Total execution time: 0.7886
INFO - 2020-02-04 15:14:51 --> Config Class Initialized
INFO - 2020-02-04 15:14:51 --> Hooks Class Initialized
INFO - 2020-02-04 15:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:14:51 --> Controller Class Initialized
DEBUG - 2020-02-04 15:14:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:51 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:51 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:14:51 --> URI Class Initialized
INFO - 2020-02-04 15:14:51 --> Helper loaded: form_helper
INFO - 2020-02-04 15:14:51 --> Form Validation Class Initialized
INFO - 2020-02-04 15:14:51 --> Router Class Initialized
INFO - 2020-02-04 15:14:51 --> Output Class Initialized
ERROR - 2020-02-04 15:14:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:14:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:14:51 --> Security Class Initialized
INFO - 2020-02-04 15:14:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-04 15:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:51 --> Input Class Initialized
INFO - 2020-02-04 15:14:51 --> Final output sent to browser
DEBUG - 2020-02-04 15:14:51 --> Total execution time: 1.0659
INFO - 2020-02-04 15:14:51 --> Language Class Initialized
ERROR - 2020-02-04 15:14:51 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:14:51 --> Config Class Initialized
INFO - 2020-02-04 15:14:51 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:14:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:51 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:51 --> URI Class Initialized
INFO - 2020-02-04 15:14:51 --> Router Class Initialized
INFO - 2020-02-04 15:14:51 --> Output Class Initialized
INFO - 2020-02-04 15:14:52 --> Security Class Initialized
DEBUG - 2020-02-04 15:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:52 --> Input Class Initialized
INFO - 2020-02-04 15:14:52 --> Language Class Initialized
ERROR - 2020-02-04 15:14:52 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:14:52 --> Config Class Initialized
INFO - 2020-02-04 15:14:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:14:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:52 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:52 --> URI Class Initialized
INFO - 2020-02-04 15:14:52 --> Router Class Initialized
INFO - 2020-02-04 15:14:52 --> Output Class Initialized
INFO - 2020-02-04 15:14:52 --> Security Class Initialized
DEBUG - 2020-02-04 15:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:52 --> Input Class Initialized
INFO - 2020-02-04 15:14:52 --> Language Class Initialized
ERROR - 2020-02-04 15:14:52 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:14:52 --> Config Class Initialized
INFO - 2020-02-04 15:14:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:14:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:52 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:52 --> URI Class Initialized
INFO - 2020-02-04 15:14:52 --> Router Class Initialized
INFO - 2020-02-04 15:14:52 --> Output Class Initialized
INFO - 2020-02-04 15:14:52 --> Security Class Initialized
DEBUG - 2020-02-04 15:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:52 --> Input Class Initialized
INFO - 2020-02-04 15:14:52 --> Language Class Initialized
ERROR - 2020-02-04 15:14:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:14:53 --> Config Class Initialized
INFO - 2020-02-04 15:14:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:14:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:53 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:53 --> URI Class Initialized
INFO - 2020-02-04 15:14:53 --> Router Class Initialized
INFO - 2020-02-04 15:14:53 --> Output Class Initialized
INFO - 2020-02-04 15:14:53 --> Security Class Initialized
DEBUG - 2020-02-04 15:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:53 --> Input Class Initialized
INFO - 2020-02-04 15:14:53 --> Language Class Initialized
ERROR - 2020-02-04 15:14:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:14:53 --> Config Class Initialized
INFO - 2020-02-04 15:14:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:14:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:53 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:53 --> URI Class Initialized
INFO - 2020-02-04 15:14:53 --> Router Class Initialized
INFO - 2020-02-04 15:14:53 --> Output Class Initialized
INFO - 2020-02-04 15:14:53 --> Security Class Initialized
DEBUG - 2020-02-04 15:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:53 --> Input Class Initialized
INFO - 2020-02-04 15:14:53 --> Language Class Initialized
ERROR - 2020-02-04 15:14:53 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:14:53 --> Config Class Initialized
INFO - 2020-02-04 15:14:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:14:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:53 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:54 --> URI Class Initialized
INFO - 2020-02-04 15:14:54 --> Router Class Initialized
INFO - 2020-02-04 15:14:54 --> Output Class Initialized
INFO - 2020-02-04 15:14:54 --> Security Class Initialized
DEBUG - 2020-02-04 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:54 --> Input Class Initialized
INFO - 2020-02-04 15:14:54 --> Language Class Initialized
ERROR - 2020-02-04 15:14:54 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:14:54 --> Config Class Initialized
INFO - 2020-02-04 15:14:54 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:14:54 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:54 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:54 --> URI Class Initialized
INFO - 2020-02-04 15:14:54 --> Router Class Initialized
INFO - 2020-02-04 15:14:54 --> Output Class Initialized
INFO - 2020-02-04 15:14:54 --> Security Class Initialized
DEBUG - 2020-02-04 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:54 --> Input Class Initialized
INFO - 2020-02-04 15:14:54 --> Language Class Initialized
ERROR - 2020-02-04 15:14:54 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:14:54 --> Config Class Initialized
INFO - 2020-02-04 15:14:54 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:14:54 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:14:54 --> Utf8 Class Initialized
INFO - 2020-02-04 15:14:54 --> URI Class Initialized
INFO - 2020-02-04 15:14:54 --> Router Class Initialized
INFO - 2020-02-04 15:14:54 --> Output Class Initialized
INFO - 2020-02-04 15:14:54 --> Security Class Initialized
DEBUG - 2020-02-04 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:14:55 --> Input Class Initialized
INFO - 2020-02-04 15:14:55 --> Language Class Initialized
ERROR - 2020-02-04 15:14:55 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:15:01 --> Config Class Initialized
INFO - 2020-02-04 15:15:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:15:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:15:02 --> Utf8 Class Initialized
INFO - 2020-02-04 15:15:02 --> URI Class Initialized
INFO - 2020-02-04 15:15:02 --> Router Class Initialized
INFO - 2020-02-04 15:15:02 --> Output Class Initialized
INFO - 2020-02-04 15:15:02 --> Security Class Initialized
DEBUG - 2020-02-04 15:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:15:02 --> Input Class Initialized
INFO - 2020-02-04 15:15:02 --> Language Class Initialized
INFO - 2020-02-04 15:15:02 --> Loader Class Initialized
INFO - 2020-02-04 15:15:02 --> Helper loaded: url_helper
INFO - 2020-02-04 15:15:02 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:15:02 --> Controller Class Initialized
INFO - 2020-02-04 15:15:02 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:15:02 --> Helper loaded: form_helper
INFO - 2020-02-04 15:15:02 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:15:02 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 30
ERROR - 2020-02-04 15:15:02 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-04 15:15:02 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-04 15:15:02 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-04 15:15:02 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\models\M_tiket.php 78
ERROR - 2020-02-04 15:15:02 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\models\M_tiket.php 79
ERROR - 2020-02-04 15:15:02 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\models\M_tiket.php 80
ERROR - 2020-02-04 15:15:02 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\models\M_tiket.php 81
ERROR - 2020-02-04 15:15:02 --> Query error: Unknown column 'id_show' in 'field list' - Invalid query: INSERT INTO `pengunjung` (`id_show`, `jenis`, `tanggal_mulai`, `tanggal_selesai`, `harga`, `jumlah_tiket`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
INFO - 2020-02-04 15:15:03 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-04 15:15:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow\system\core\Common.php 570
INFO - 2020-02-04 15:16:11 --> Config Class Initialized
INFO - 2020-02-04 15:16:12 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:12 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:12 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:12 --> URI Class Initialized
INFO - 2020-02-04 15:16:12 --> Router Class Initialized
INFO - 2020-02-04 15:16:12 --> Output Class Initialized
INFO - 2020-02-04 15:16:12 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:12 --> Input Class Initialized
INFO - 2020-02-04 15:16:12 --> Language Class Initialized
INFO - 2020-02-04 15:16:12 --> Loader Class Initialized
INFO - 2020-02-04 15:16:12 --> Helper loaded: url_helper
INFO - 2020-02-04 15:16:12 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:16:12 --> Controller Class Initialized
INFO - 2020-02-04 15:16:12 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:16:12 --> Helper loaded: form_helper
INFO - 2020-02-04 15:16:12 --> Form Validation Class Initialized
INFO - 2020-02-04 15:16:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:16:12 --> Final output sent to browser
INFO - 2020-02-04 15:16:12 --> Config Class Initialized
INFO - 2020-02-04 15:16:12 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:12 --> Total execution time: 0.8574
INFO - 2020-02-04 15:16:12 --> Config Class Initialized
INFO - 2020-02-04 15:16:12 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:12 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:12 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:16:12 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:13 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:13 --> URI Class Initialized
INFO - 2020-02-04 15:16:13 --> URI Class Initialized
INFO - 2020-02-04 15:16:13 --> Router Class Initialized
INFO - 2020-02-04 15:16:13 --> Router Class Initialized
INFO - 2020-02-04 15:16:13 --> Output Class Initialized
INFO - 2020-02-04 15:16:13 --> Security Class Initialized
INFO - 2020-02-04 15:16:13 --> Output Class Initialized
INFO - 2020-02-04 15:16:13 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:13 --> Input Class Initialized
DEBUG - 2020-02-04 15:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:13 --> Input Class Initialized
INFO - 2020-02-04 15:16:13 --> Language Class Initialized
INFO - 2020-02-04 15:16:13 --> Language Class Initialized
INFO - 2020-02-04 15:16:13 --> Loader Class Initialized
INFO - 2020-02-04 15:16:13 --> Helper loaded: url_helper
INFO - 2020-02-04 15:16:13 --> Loader Class Initialized
INFO - 2020-02-04 15:16:13 --> Helper loaded: url_helper
INFO - 2020-02-04 15:16:13 --> Database Driver Class Initialized
INFO - 2020-02-04 15:16:13 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:16:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:16:13 --> Controller Class Initialized
INFO - 2020-02-04 15:16:13 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:16:13 --> Helper loaded: form_helper
INFO - 2020-02-04 15:16:13 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:16:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:16:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:16:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:16:13 --> Final output sent to browser
DEBUG - 2020-02-04 15:16:13 --> Total execution time: 0.8694
INFO - 2020-02-04 15:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:16:13 --> Controller Class Initialized
INFO - 2020-02-04 15:16:13 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:16:13 --> Helper loaded: form_helper
INFO - 2020-02-04 15:16:13 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:16:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:16:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:16:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:16:14 --> Final output sent to browser
DEBUG - 2020-02-04 15:16:14 --> Total execution time: 1.1476
INFO - 2020-02-04 15:16:14 --> Config Class Initialized
INFO - 2020-02-04 15:16:14 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:14 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:14 --> URI Class Initialized
INFO - 2020-02-04 15:16:14 --> Router Class Initialized
INFO - 2020-02-04 15:16:14 --> Output Class Initialized
INFO - 2020-02-04 15:16:14 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:14 --> Input Class Initialized
INFO - 2020-02-04 15:16:14 --> Language Class Initialized
INFO - 2020-02-04 15:16:14 --> Loader Class Initialized
INFO - 2020-02-04 15:16:14 --> Helper loaded: url_helper
INFO - 2020-02-04 15:16:14 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:16:14 --> Controller Class Initialized
INFO - 2020-02-04 15:16:14 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:16:14 --> Helper loaded: form_helper
INFO - 2020-02-04 15:16:14 --> Form Validation Class Initialized
INFO - 2020-02-04 15:16:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:16:15 --> Final output sent to browser
INFO - 2020-02-04 15:16:15 --> Config Class Initialized
INFO - 2020-02-04 15:16:15 --> Config Class Initialized
INFO - 2020-02-04 15:16:15 --> Config Class Initialized
INFO - 2020-02-04 15:16:15 --> Config Class Initialized
INFO - 2020-02-04 15:16:15 --> Config Class Initialized
INFO - 2020-02-04 15:16:15 --> Hooks Class Initialized
INFO - 2020-02-04 15:16:15 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:15 --> Total execution time: 0.7435
INFO - 2020-02-04 15:16:15 --> Hooks Class Initialized
INFO - 2020-02-04 15:16:15 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:15 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:15 --> Config Class Initialized
DEBUG - 2020-02-04 15:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:15 --> Hooks Class Initialized
INFO - 2020-02-04 15:16:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:15 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:15 --> URI Class Initialized
INFO - 2020-02-04 15:16:15 --> URI Class Initialized
INFO - 2020-02-04 15:16:15 --> URI Class Initialized
INFO - 2020-02-04 15:16:15 --> URI Class Initialized
DEBUG - 2020-02-04 15:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:15 --> URI Class Initialized
INFO - 2020-02-04 15:16:15 --> Router Class Initialized
INFO - 2020-02-04 15:16:15 --> Router Class Initialized
INFO - 2020-02-04 15:16:15 --> Router Class Initialized
INFO - 2020-02-04 15:16:15 --> Router Class Initialized
INFO - 2020-02-04 15:16:15 --> Router Class Initialized
INFO - 2020-02-04 15:16:15 --> Output Class Initialized
INFO - 2020-02-04 15:16:15 --> Output Class Initialized
INFO - 2020-02-04 15:16:15 --> Output Class Initialized
INFO - 2020-02-04 15:16:15 --> URI Class Initialized
INFO - 2020-02-04 15:16:15 --> Output Class Initialized
INFO - 2020-02-04 15:16:15 --> Security Class Initialized
INFO - 2020-02-04 15:16:15 --> Security Class Initialized
INFO - 2020-02-04 15:16:15 --> Security Class Initialized
INFO - 2020-02-04 15:16:15 --> Router Class Initialized
INFO - 2020-02-04 15:16:15 --> Security Class Initialized
INFO - 2020-02-04 15:16:15 --> Output Class Initialized
DEBUG - 2020-02-04 15:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:15 --> Security Class Initialized
INFO - 2020-02-04 15:16:15 --> Output Class Initialized
DEBUG - 2020-02-04 15:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:15 --> Input Class Initialized
INFO - 2020-02-04 15:16:15 --> Input Class Initialized
INFO - 2020-02-04 15:16:15 --> Input Class Initialized
INFO - 2020-02-04 15:16:15 --> Input Class Initialized
DEBUG - 2020-02-04 15:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:15 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:15 --> Input Class Initialized
INFO - 2020-02-04 15:16:15 --> Language Class Initialized
INFO - 2020-02-04 15:16:15 --> Language Class Initialized
INFO - 2020-02-04 15:16:15 --> Language Class Initialized
INFO - 2020-02-04 15:16:15 --> Language Class Initialized
INFO - 2020-02-04 15:16:15 --> Input Class Initialized
INFO - 2020-02-04 15:16:15 --> Language Class Initialized
ERROR - 2020-02-04 15:16:15 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 15:16:15 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 15:16:15 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 15:16:15 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 15:16:15 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:16:15 --> Language Class Initialized
INFO - 2020-02-04 15:16:15 --> Config Class Initialized
INFO - 2020-02-04 15:16:15 --> Config Class Initialized
INFO - 2020-02-04 15:16:15 --> Config Class Initialized
INFO - 2020-02-04 15:16:15 --> Config Class Initialized
INFO - 2020-02-04 15:16:15 --> Hooks Class Initialized
INFO - 2020-02-04 15:16:15 --> Hooks Class Initialized
INFO - 2020-02-04 15:16:15 --> Hooks Class Initialized
INFO - 2020-02-04 15:16:15 --> Hooks Class Initialized
ERROR - 2020-02-04 15:16:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:16:15 --> Config Class Initialized
INFO - 2020-02-04 15:16:15 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:15 --> Config Class Initialized
INFO - 2020-02-04 15:16:15 --> Hooks Class Initialized
INFO - 2020-02-04 15:16:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:15 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:15 --> URI Class Initialized
INFO - 2020-02-04 15:16:15 --> URI Class Initialized
INFO - 2020-02-04 15:16:15 --> URI Class Initialized
INFO - 2020-02-04 15:16:15 --> URI Class Initialized
DEBUG - 2020-02-04 15:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:15 --> Router Class Initialized
INFO - 2020-02-04 15:16:15 --> Router Class Initialized
INFO - 2020-02-04 15:16:15 --> Router Class Initialized
INFO - 2020-02-04 15:16:15 --> Router Class Initialized
INFO - 2020-02-04 15:16:15 --> URI Class Initialized
INFO - 2020-02-04 15:16:15 --> Router Class Initialized
INFO - 2020-02-04 15:16:15 --> Output Class Initialized
INFO - 2020-02-04 15:16:15 --> Output Class Initialized
INFO - 2020-02-04 15:16:15 --> Output Class Initialized
INFO - 2020-02-04 15:16:15 --> URI Class Initialized
INFO - 2020-02-04 15:16:15 --> Output Class Initialized
INFO - 2020-02-04 15:16:15 --> Security Class Initialized
INFO - 2020-02-04 15:16:15 --> Security Class Initialized
INFO - 2020-02-04 15:16:15 --> Security Class Initialized
INFO - 2020-02-04 15:16:15 --> Router Class Initialized
INFO - 2020-02-04 15:16:15 --> Security Class Initialized
INFO - 2020-02-04 15:16:15 --> Output Class Initialized
DEBUG - 2020-02-04 15:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:15 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:15 --> Output Class Initialized
INFO - 2020-02-04 15:16:15 --> Input Class Initialized
INFO - 2020-02-04 15:16:15 --> Input Class Initialized
INFO - 2020-02-04 15:16:15 --> Input Class Initialized
INFO - 2020-02-04 15:16:15 --> Input Class Initialized
DEBUG - 2020-02-04 15:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:15 --> Security Class Initialized
INFO - 2020-02-04 15:16:15 --> Language Class Initialized
DEBUG - 2020-02-04 15:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:15 --> Language Class Initialized
INFO - 2020-02-04 15:16:15 --> Language Class Initialized
INFO - 2020-02-04 15:16:15 --> Input Class Initialized
INFO - 2020-02-04 15:16:15 --> Language Class Initialized
INFO - 2020-02-04 15:16:16 --> Language Class Initialized
INFO - 2020-02-04 15:16:16 --> Input Class Initialized
INFO - 2020-02-04 15:16:16 --> Loader Class Initialized
ERROR - 2020-02-04 15:16:16 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-04 15:16:16 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:16:16 --> Loader Class Initialized
INFO - 2020-02-04 15:16:16 --> Helper loaded: url_helper
ERROR - 2020-02-04 15:16:16 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:16:16 --> Language Class Initialized
INFO - 2020-02-04 15:16:16 --> Helper loaded: url_helper
INFO - 2020-02-04 15:16:16 --> Config Class Initialized
INFO - 2020-02-04 15:16:16 --> Config Class Initialized
INFO - 2020-02-04 15:16:16 --> Hooks Class Initialized
ERROR - 2020-02-04 15:16:16 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:16:16 --> Hooks Class Initialized
INFO - 2020-02-04 15:16:16 --> Database Driver Class Initialized
INFO - 2020-02-04 15:16:16 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:16:16 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 15:16:16 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:16:16 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:16 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:16:16 --> Controller Class Initialized
INFO - 2020-02-04 15:16:16 --> URI Class Initialized
INFO - 2020-02-04 15:16:16 --> URI Class Initialized
INFO - 2020-02-04 15:16:16 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:16:16 --> Router Class Initialized
INFO - 2020-02-04 15:16:16 --> Router Class Initialized
INFO - 2020-02-04 15:16:16 --> Output Class Initialized
INFO - 2020-02-04 15:16:16 --> Output Class Initialized
INFO - 2020-02-04 15:16:16 --> Helper loaded: form_helper
INFO - 2020-02-04 15:16:16 --> Form Validation Class Initialized
INFO - 2020-02-04 15:16:16 --> Security Class Initialized
INFO - 2020-02-04 15:16:16 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:16:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 15:16:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:16:16 --> Input Class Initialized
INFO - 2020-02-04 15:16:16 --> Input Class Initialized
ERROR - 2020-02-04 15:16:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:16:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:16:16 --> Language Class Initialized
INFO - 2020-02-04 15:16:16 --> Language Class Initialized
INFO - 2020-02-04 15:16:16 --> Final output sent to browser
ERROR - 2020-02-04 15:16:16 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 15:16:16 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-04 15:16:16 --> Total execution time: 0.8931
INFO - 2020-02-04 15:16:16 --> Config Class Initialized
INFO - 2020-02-04 15:16:16 --> Hooks Class Initialized
INFO - 2020-02-04 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:16:16 --> Controller Class Initialized
DEBUG - 2020-02-04 15:16:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:16 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:16 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:16:16 --> URI Class Initialized
INFO - 2020-02-04 15:16:16 --> Helper loaded: form_helper
INFO - 2020-02-04 15:16:16 --> Form Validation Class Initialized
INFO - 2020-02-04 15:16:16 --> Router Class Initialized
INFO - 2020-02-04 15:16:16 --> Output Class Initialized
ERROR - 2020-02-04 15:16:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:16:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:16:16 --> Security Class Initialized
INFO - 2020-02-04 15:16:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-04 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:16 --> Input Class Initialized
INFO - 2020-02-04 15:16:16 --> Final output sent to browser
DEBUG - 2020-02-04 15:16:16 --> Total execution time: 1.2479
INFO - 2020-02-04 15:16:16 --> Language Class Initialized
ERROR - 2020-02-04 15:16:16 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:16:16 --> Config Class Initialized
INFO - 2020-02-04 15:16:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:17 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:17 --> URI Class Initialized
INFO - 2020-02-04 15:16:17 --> Router Class Initialized
INFO - 2020-02-04 15:16:17 --> Output Class Initialized
INFO - 2020-02-04 15:16:17 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:17 --> Input Class Initialized
INFO - 2020-02-04 15:16:17 --> Language Class Initialized
ERROR - 2020-02-04 15:16:17 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:16:17 --> Config Class Initialized
INFO - 2020-02-04 15:16:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:17 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:17 --> URI Class Initialized
INFO - 2020-02-04 15:16:17 --> Router Class Initialized
INFO - 2020-02-04 15:16:17 --> Output Class Initialized
INFO - 2020-02-04 15:16:17 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:17 --> Input Class Initialized
INFO - 2020-02-04 15:16:17 --> Language Class Initialized
ERROR - 2020-02-04 15:16:17 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:16:17 --> Config Class Initialized
INFO - 2020-02-04 15:16:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:17 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:17 --> URI Class Initialized
INFO - 2020-02-04 15:16:17 --> Router Class Initialized
INFO - 2020-02-04 15:16:18 --> Output Class Initialized
INFO - 2020-02-04 15:16:18 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:18 --> Input Class Initialized
INFO - 2020-02-04 15:16:18 --> Language Class Initialized
ERROR - 2020-02-04 15:16:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:16:18 --> Config Class Initialized
INFO - 2020-02-04 15:16:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:18 --> URI Class Initialized
INFO - 2020-02-04 15:16:18 --> Router Class Initialized
INFO - 2020-02-04 15:16:18 --> Output Class Initialized
INFO - 2020-02-04 15:16:18 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:18 --> Input Class Initialized
INFO - 2020-02-04 15:16:18 --> Language Class Initialized
ERROR - 2020-02-04 15:16:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:16:18 --> Config Class Initialized
INFO - 2020-02-04 15:16:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:18 --> URI Class Initialized
INFO - 2020-02-04 15:16:18 --> Router Class Initialized
INFO - 2020-02-04 15:16:18 --> Output Class Initialized
INFO - 2020-02-04 15:16:18 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:18 --> Input Class Initialized
INFO - 2020-02-04 15:16:19 --> Language Class Initialized
ERROR - 2020-02-04 15:16:19 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:16:19 --> Config Class Initialized
INFO - 2020-02-04 15:16:19 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:19 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:19 --> URI Class Initialized
INFO - 2020-02-04 15:16:19 --> Router Class Initialized
INFO - 2020-02-04 15:16:19 --> Output Class Initialized
INFO - 2020-02-04 15:16:19 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:19 --> Input Class Initialized
INFO - 2020-02-04 15:16:19 --> Language Class Initialized
ERROR - 2020-02-04 15:16:19 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:16:19 --> Config Class Initialized
INFO - 2020-02-04 15:16:19 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:19 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:19 --> URI Class Initialized
INFO - 2020-02-04 15:16:19 --> Router Class Initialized
INFO - 2020-02-04 15:16:19 --> Output Class Initialized
INFO - 2020-02-04 15:16:19 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:19 --> Input Class Initialized
INFO - 2020-02-04 15:16:19 --> Language Class Initialized
ERROR - 2020-02-04 15:16:19 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:16:19 --> Config Class Initialized
INFO - 2020-02-04 15:16:20 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:20 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:20 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:20 --> URI Class Initialized
INFO - 2020-02-04 15:16:20 --> Router Class Initialized
INFO - 2020-02-04 15:16:20 --> Output Class Initialized
INFO - 2020-02-04 15:16:20 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:20 --> Input Class Initialized
INFO - 2020-02-04 15:16:20 --> Language Class Initialized
ERROR - 2020-02-04 15:16:20 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:16:32 --> Config Class Initialized
INFO - 2020-02-04 15:16:32 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:16:32 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:16:32 --> Utf8 Class Initialized
INFO - 2020-02-04 15:16:32 --> URI Class Initialized
INFO - 2020-02-04 15:16:32 --> Router Class Initialized
INFO - 2020-02-04 15:16:32 --> Output Class Initialized
INFO - 2020-02-04 15:16:32 --> Security Class Initialized
DEBUG - 2020-02-04 15:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:16:33 --> Input Class Initialized
INFO - 2020-02-04 15:16:33 --> Language Class Initialized
INFO - 2020-02-04 15:16:33 --> Loader Class Initialized
INFO - 2020-02-04 15:16:33 --> Helper loaded: url_helper
INFO - 2020-02-04 15:16:33 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:16:33 --> Controller Class Initialized
INFO - 2020-02-04 15:16:33 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:16:33 --> Helper loaded: form_helper
INFO - 2020-02-04 15:16:33 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:16:33 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-04 15:16:33 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\models\M_tiket.php 79
ERROR - 2020-02-04 15:16:33 --> Query error: Unknown column 'id_show' in 'field list' - Invalid query: INSERT INTO `pengunjung` (`id_show`, `jenis`, `tanggal_mulai`, `tanggal_selesai`, `harga`, `jumlah_tiket`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
INFO - 2020-02-04 15:16:33 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-04 15:18:25 --> Config Class Initialized
INFO - 2020-02-04 15:18:25 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:18:25 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:18:25 --> Utf8 Class Initialized
INFO - 2020-02-04 15:18:25 --> URI Class Initialized
INFO - 2020-02-04 15:18:25 --> Router Class Initialized
INFO - 2020-02-04 15:18:25 --> Output Class Initialized
INFO - 2020-02-04 15:18:25 --> Security Class Initialized
DEBUG - 2020-02-04 15:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:18:25 --> Input Class Initialized
INFO - 2020-02-04 15:18:25 --> Language Class Initialized
INFO - 2020-02-04 15:18:25 --> Loader Class Initialized
INFO - 2020-02-04 15:18:25 --> Helper loaded: url_helper
INFO - 2020-02-04 15:18:25 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:18:25 --> Controller Class Initialized
INFO - 2020-02-04 15:18:25 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:18:25 --> Helper loaded: form_helper
INFO - 2020-02-04 15:18:25 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:18:25 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 30
ERROR - 2020-02-04 15:18:25 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-04 15:18:25 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-04 15:18:25 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-04 15:18:25 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\models\M_tiket.php 78
ERROR - 2020-02-04 15:18:25 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\models\M_tiket.php 79
ERROR - 2020-02-04 15:18:25 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\models\M_tiket.php 80
ERROR - 2020-02-04 15:18:25 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\models\M_tiket.php 81
ERROR - 2020-02-04 15:18:26 --> Query error: Unknown column 'id_show' in 'field list' - Invalid query: INSERT INTO `pengunjung` (`id_show`, `jenis`, `tanggal_mulai`, `tanggal_selesai`, `harga`, `jumlah_tiket`, `nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
INFO - 2020-02-04 15:18:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-04 15:18:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow\system\core\Common.php 570
INFO - 2020-02-04 15:19:37 --> Config Class Initialized
INFO - 2020-02-04 15:19:38 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:19:38 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:19:38 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:38 --> URI Class Initialized
INFO - 2020-02-04 15:19:38 --> Router Class Initialized
INFO - 2020-02-04 15:19:38 --> Output Class Initialized
INFO - 2020-02-04 15:19:38 --> Security Class Initialized
DEBUG - 2020-02-04 15:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:38 --> Input Class Initialized
INFO - 2020-02-04 15:19:38 --> Language Class Initialized
INFO - 2020-02-04 15:19:38 --> Loader Class Initialized
INFO - 2020-02-04 15:19:38 --> Helper loaded: url_helper
INFO - 2020-02-04 15:19:38 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:19:38 --> Controller Class Initialized
INFO - 2020-02-04 15:19:38 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:19:38 --> Helper loaded: form_helper
INFO - 2020-02-04 15:19:38 --> Form Validation Class Initialized
INFO - 2020-02-04 15:19:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:19:38 --> Final output sent to browser
DEBUG - 2020-02-04 15:19:38 --> Total execution time: 1.0229
INFO - 2020-02-04 15:19:39 --> Config Class Initialized
INFO - 2020-02-04 15:19:39 --> Config Class Initialized
INFO - 2020-02-04 15:19:39 --> Hooks Class Initialized
INFO - 2020-02-04 15:19:39 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:19:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:19:39 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:19:39 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:39 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:39 --> URI Class Initialized
INFO - 2020-02-04 15:19:39 --> URI Class Initialized
INFO - 2020-02-04 15:19:39 --> Router Class Initialized
INFO - 2020-02-04 15:19:39 --> Router Class Initialized
INFO - 2020-02-04 15:19:39 --> Output Class Initialized
INFO - 2020-02-04 15:19:39 --> Output Class Initialized
INFO - 2020-02-04 15:19:39 --> Security Class Initialized
INFO - 2020-02-04 15:19:39 --> Security Class Initialized
DEBUG - 2020-02-04 15:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:39 --> Input Class Initialized
INFO - 2020-02-04 15:19:39 --> Input Class Initialized
INFO - 2020-02-04 15:19:39 --> Language Class Initialized
INFO - 2020-02-04 15:19:39 --> Language Class Initialized
INFO - 2020-02-04 15:19:39 --> Loader Class Initialized
INFO - 2020-02-04 15:19:39 --> Loader Class Initialized
INFO - 2020-02-04 15:19:39 --> Helper loaded: url_helper
INFO - 2020-02-04 15:19:39 --> Helper loaded: url_helper
INFO - 2020-02-04 15:19:39 --> Database Driver Class Initialized
INFO - 2020-02-04 15:19:39 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 15:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:19:39 --> Controller Class Initialized
INFO - 2020-02-04 15:19:39 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:19:39 --> Helper loaded: form_helper
INFO - 2020-02-04 15:19:39 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:19:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:19:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:19:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:19:39 --> Final output sent to browser
INFO - 2020-02-04 15:19:40 --> Config Class Initialized
DEBUG - 2020-02-04 15:19:40 --> Total execution time: 0.9356
INFO - 2020-02-04 15:19:40 --> Hooks Class Initialized
INFO - 2020-02-04 15:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:19:40 --> Controller Class Initialized
DEBUG - 2020-02-04 15:19:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:19:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:40 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:19:40 --> URI Class Initialized
INFO - 2020-02-04 15:19:40 --> Helper loaded: form_helper
INFO - 2020-02-04 15:19:40 --> Form Validation Class Initialized
INFO - 2020-02-04 15:19:40 --> Router Class Initialized
INFO - 2020-02-04 15:19:40 --> Output Class Initialized
ERROR - 2020-02-04 15:19:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:19:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:19:40 --> Security Class Initialized
INFO - 2020-02-04 15:19:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-04 15:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:40 --> Input Class Initialized
INFO - 2020-02-04 15:19:40 --> Final output sent to browser
DEBUG - 2020-02-04 15:19:40 --> Total execution time: 1.2975
INFO - 2020-02-04 15:19:40 --> Language Class Initialized
INFO - 2020-02-04 15:19:40 --> Loader Class Initialized
INFO - 2020-02-04 15:19:40 --> Helper loaded: url_helper
INFO - 2020-02-04 15:19:40 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:19:40 --> Controller Class Initialized
INFO - 2020-02-04 15:19:40 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:19:40 --> Helper loaded: form_helper
INFO - 2020-02-04 15:19:40 --> Form Validation Class Initialized
INFO - 2020-02-04 15:19:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:19:40 --> Final output sent to browser
INFO - 2020-02-04 15:19:40 --> Config Class Initialized
INFO - 2020-02-04 15:19:40 --> Config Class Initialized
INFO - 2020-02-04 15:19:40 --> Config Class Initialized
INFO - 2020-02-04 15:19:40 --> Hooks Class Initialized
INFO - 2020-02-04 15:19:40 --> Hooks Class Initialized
INFO - 2020-02-04 15:19:40 --> Config Class Initialized
DEBUG - 2020-02-04 15:19:40 --> Total execution time: 0.7576
INFO - 2020-02-04 15:19:40 --> Hooks Class Initialized
INFO - 2020-02-04 15:19:40 --> Config Class Initialized
INFO - 2020-02-04 15:19:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:19:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:19:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:19:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:19:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:19:40 --> Config Class Initialized
INFO - 2020-02-04 15:19:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:19:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:19:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:19:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:40 --> URI Class Initialized
INFO - 2020-02-04 15:19:40 --> URI Class Initialized
INFO - 2020-02-04 15:19:40 --> URI Class Initialized
DEBUG - 2020-02-04 15:19:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:19:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:41 --> URI Class Initialized
INFO - 2020-02-04 15:19:41 --> Router Class Initialized
INFO - 2020-02-04 15:19:41 --> Router Class Initialized
INFO - 2020-02-04 15:19:41 --> URI Class Initialized
INFO - 2020-02-04 15:19:41 --> Router Class Initialized
INFO - 2020-02-04 15:19:41 --> URI Class Initialized
INFO - 2020-02-04 15:19:41 --> Router Class Initialized
INFO - 2020-02-04 15:19:41 --> Router Class Initialized
INFO - 2020-02-04 15:19:41 --> Output Class Initialized
INFO - 2020-02-04 15:19:41 --> Output Class Initialized
INFO - 2020-02-04 15:19:41 --> Output Class Initialized
INFO - 2020-02-04 15:19:41 --> Security Class Initialized
INFO - 2020-02-04 15:19:41 --> Output Class Initialized
INFO - 2020-02-04 15:19:41 --> Output Class Initialized
INFO - 2020-02-04 15:19:41 --> Security Class Initialized
INFO - 2020-02-04 15:19:41 --> Security Class Initialized
INFO - 2020-02-04 15:19:41 --> Router Class Initialized
DEBUG - 2020-02-04 15:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:41 --> Security Class Initialized
INFO - 2020-02-04 15:19:41 --> Output Class Initialized
INFO - 2020-02-04 15:19:41 --> Security Class Initialized
DEBUG - 2020-02-04 15:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:41 --> Input Class Initialized
INFO - 2020-02-04 15:19:41 --> Input Class Initialized
INFO - 2020-02-04 15:19:41 --> Input Class Initialized
DEBUG - 2020-02-04 15:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:41 --> Security Class Initialized
DEBUG - 2020-02-04 15:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:41 --> Input Class Initialized
INFO - 2020-02-04 15:19:41 --> Input Class Initialized
INFO - 2020-02-04 15:19:41 --> Language Class Initialized
INFO - 2020-02-04 15:19:41 --> Language Class Initialized
DEBUG - 2020-02-04 15:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:41 --> Language Class Initialized
INFO - 2020-02-04 15:19:41 --> Input Class Initialized
INFO - 2020-02-04 15:19:41 --> Language Class Initialized
INFO - 2020-02-04 15:19:41 --> Language Class Initialized
ERROR - 2020-02-04 15:19:41 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 15:19:41 --> Loader Class Initialized
INFO - 2020-02-04 15:19:41 --> Loader Class Initialized
INFO - 2020-02-04 15:19:41 --> Language Class Initialized
ERROR - 2020-02-04 15:19:41 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:19:41 --> Helper loaded: url_helper
ERROR - 2020-02-04 15:19:41 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 15:19:41 --> Helper loaded: url_helper
INFO - 2020-02-04 15:19:41 --> Config Class Initialized
INFO - 2020-02-04 15:19:41 --> Hooks Class Initialized
ERROR - 2020-02-04 15:19:41 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:19:41 --> Database Driver Class Initialized
INFO - 2020-02-04 15:19:41 --> Database Driver Class Initialized
INFO - 2020-02-04 15:19:41 --> Config Class Initialized
INFO - 2020-02-04 15:19:41 --> Config Class Initialized
INFO - 2020-02-04 15:19:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:19:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:19:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 15:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:19:41 --> Config Class Initialized
INFO - 2020-02-04 15:19:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:19:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:19:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:19:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:19:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:41 --> Controller Class Initialized
INFO - 2020-02-04 15:19:41 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:19:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:19:41 --> URI Class Initialized
INFO - 2020-02-04 15:19:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:41 --> URI Class Initialized
INFO - 2020-02-04 15:19:41 --> URI Class Initialized
INFO - 2020-02-04 15:19:41 --> Router Class Initialized
INFO - 2020-02-04 15:19:41 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:19:41 --> URI Class Initialized
INFO - 2020-02-04 15:19:41 --> Output Class Initialized
INFO - 2020-02-04 15:19:41 --> Router Class Initialized
INFO - 2020-02-04 15:19:41 --> Helper loaded: form_helper
INFO - 2020-02-04 15:19:41 --> Router Class Initialized
INFO - 2020-02-04 15:19:41 --> Form Validation Class Initialized
INFO - 2020-02-04 15:19:41 --> Router Class Initialized
INFO - 2020-02-04 15:19:41 --> Security Class Initialized
INFO - 2020-02-04 15:19:41 --> Output Class Initialized
INFO - 2020-02-04 15:19:41 --> Output Class Initialized
INFO - 2020-02-04 15:19:41 --> Security Class Initialized
DEBUG - 2020-02-04 15:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:41 --> Security Class Initialized
INFO - 2020-02-04 15:19:41 --> Output Class Initialized
ERROR - 2020-02-04 15:19:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:19:41 --> Input Class Initialized
ERROR - 2020-02-04 15:19:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-04 15:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:41 --> Security Class Initialized
DEBUG - 2020-02-04 15:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:41 --> Input Class Initialized
INFO - 2020-02-04 15:19:41 --> Input Class Initialized
INFO - 2020-02-04 15:19:41 --> Language Class Initialized
INFO - 2020-02-04 15:19:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-04 15:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:41 --> Input Class Initialized
INFO - 2020-02-04 15:19:41 --> Language Class Initialized
INFO - 2020-02-04 15:19:41 --> Language Class Initialized
INFO - 2020-02-04 15:19:41 --> Final output sent to browser
ERROR - 2020-02-04 15:19:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-04 15:19:41 --> Total execution time: 0.9331
ERROR - 2020-02-04 15:19:41 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 15:19:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:19:41 --> Language Class Initialized
INFO - 2020-02-04 15:19:41 --> Config Class Initialized
INFO - 2020-02-04 15:19:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:19:41 --> Session: Class initialized using 'files' driver.
ERROR - 2020-02-04 15:19:41 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:19:41 --> Config Class Initialized
INFO - 2020-02-04 15:19:41 --> Config Class Initialized
INFO - 2020-02-04 15:19:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:19:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:19:41 --> Controller Class Initialized
DEBUG - 2020-02-04 15:19:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:19:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:41 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 15:19:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:19:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:19:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:42 --> URI Class Initialized
INFO - 2020-02-04 15:19:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:42 --> Helper loaded: form_helper
INFO - 2020-02-04 15:19:42 --> Form Validation Class Initialized
INFO - 2020-02-04 15:19:42 --> URI Class Initialized
INFO - 2020-02-04 15:19:42 --> URI Class Initialized
INFO - 2020-02-04 15:19:42 --> Router Class Initialized
INFO - 2020-02-04 15:19:42 --> Router Class Initialized
INFO - 2020-02-04 15:19:42 --> Router Class Initialized
INFO - 2020-02-04 15:19:42 --> Output Class Initialized
ERROR - 2020-02-04 15:19:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:19:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:19:42 --> Security Class Initialized
INFO - 2020-02-04 15:19:42 --> Output Class Initialized
INFO - 2020-02-04 15:19:42 --> Output Class Initialized
INFO - 2020-02-04 15:19:42 --> Security Class Initialized
INFO - 2020-02-04 15:19:42 --> Security Class Initialized
DEBUG - 2020-02-04 15:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:19:42 --> Final output sent to browser
INFO - 2020-02-04 15:19:42 --> Input Class Initialized
DEBUG - 2020-02-04 15:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:19:42 --> Total execution time: 1.3742
INFO - 2020-02-04 15:19:42 --> Input Class Initialized
INFO - 2020-02-04 15:19:42 --> Input Class Initialized
INFO - 2020-02-04 15:19:42 --> Language Class Initialized
INFO - 2020-02-04 15:19:42 --> Language Class Initialized
ERROR - 2020-02-04 15:19:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:19:42 --> Language Class Initialized
ERROR - 2020-02-04 15:19:42 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 15:19:42 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:19:42 --> Config Class Initialized
INFO - 2020-02-04 15:19:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:19:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:19:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:42 --> URI Class Initialized
INFO - 2020-02-04 15:19:42 --> Router Class Initialized
INFO - 2020-02-04 15:19:42 --> Output Class Initialized
INFO - 2020-02-04 15:19:42 --> Security Class Initialized
DEBUG - 2020-02-04 15:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:42 --> Input Class Initialized
INFO - 2020-02-04 15:19:42 --> Language Class Initialized
ERROR - 2020-02-04 15:19:42 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:19:57 --> Config Class Initialized
INFO - 2020-02-04 15:19:58 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:19:58 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:19:58 --> Utf8 Class Initialized
INFO - 2020-02-04 15:19:58 --> URI Class Initialized
INFO - 2020-02-04 15:19:58 --> Router Class Initialized
INFO - 2020-02-04 15:19:58 --> Output Class Initialized
INFO - 2020-02-04 15:19:58 --> Security Class Initialized
DEBUG - 2020-02-04 15:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:19:59 --> Input Class Initialized
INFO - 2020-02-04 15:19:59 --> Language Class Initialized
INFO - 2020-02-04 15:19:59 --> Loader Class Initialized
INFO - 2020-02-04 15:19:59 --> Helper loaded: url_helper
INFO - 2020-02-04 15:19:59 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:19:59 --> Controller Class Initialized
INFO - 2020-02-04 15:19:59 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:20:00 --> Helper loaded: form_helper
INFO - 2020-02-04 15:20:00 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:20:00 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-04 15:20:00 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\models\M_tiket.php 79
ERROR - 2020-02-04 15:20:00 --> Query error: Unknown column 'id_show' in 'field list' - Invalid query: INSERT INTO `pengunjung` (`id_show`, `jenis`, `tanggal_mulai`, `tanggal_selesai`, `harga`, `jumlah_tiket`, `nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, '1`', NULL, '1', 'iuiui@www.com')
INFO - 2020-02-04 15:20:00 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-04 15:21:13 --> Config Class Initialized
INFO - 2020-02-04 15:21:13 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:14 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:14 --> URI Class Initialized
INFO - 2020-02-04 15:21:14 --> Router Class Initialized
INFO - 2020-02-04 15:21:14 --> Output Class Initialized
INFO - 2020-02-04 15:21:14 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:14 --> Input Class Initialized
INFO - 2020-02-04 15:21:14 --> Language Class Initialized
INFO - 2020-02-04 15:21:14 --> Loader Class Initialized
INFO - 2020-02-04 15:21:14 --> Helper loaded: url_helper
INFO - 2020-02-04 15:21:14 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:21:14 --> Controller Class Initialized
INFO - 2020-02-04 15:21:14 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:21:14 --> Helper loaded: form_helper
INFO - 2020-02-04 15:21:14 --> Form Validation Class Initialized
INFO - 2020-02-04 15:21:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:21:14 --> Final output sent to browser
INFO - 2020-02-04 15:21:14 --> Config Class Initialized
INFO - 2020-02-04 15:21:14 --> Config Class Initialized
INFO - 2020-02-04 15:21:14 --> Config Class Initialized
INFO - 2020-02-04 15:21:14 --> Config Class Initialized
INFO - 2020-02-04 15:21:14 --> Config Class Initialized
INFO - 2020-02-04 15:21:14 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:14 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:14 --> Total execution time: 1.0157
INFO - 2020-02-04 15:21:14 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:14 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:14 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:21:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:21:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:21:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:21:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:15 --> Config Class Initialized
INFO - 2020-02-04 15:21:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:15 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:15 --> URI Class Initialized
INFO - 2020-02-04 15:21:15 --> URI Class Initialized
INFO - 2020-02-04 15:21:15 --> URI Class Initialized
INFO - 2020-02-04 15:21:15 --> URI Class Initialized
INFO - 2020-02-04 15:21:15 --> URI Class Initialized
DEBUG - 2020-02-04 15:21:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:15 --> Router Class Initialized
INFO - 2020-02-04 15:21:15 --> Router Class Initialized
INFO - 2020-02-04 15:21:15 --> Router Class Initialized
INFO - 2020-02-04 15:21:15 --> Router Class Initialized
INFO - 2020-02-04 15:21:15 --> Router Class Initialized
INFO - 2020-02-04 15:21:15 --> URI Class Initialized
INFO - 2020-02-04 15:21:15 --> Output Class Initialized
INFO - 2020-02-04 15:21:15 --> Output Class Initialized
INFO - 2020-02-04 15:21:15 --> Output Class Initialized
INFO - 2020-02-04 15:21:15 --> Output Class Initialized
INFO - 2020-02-04 15:21:15 --> Output Class Initialized
INFO - 2020-02-04 15:21:15 --> Security Class Initialized
INFO - 2020-02-04 15:21:15 --> Router Class Initialized
INFO - 2020-02-04 15:21:15 --> Security Class Initialized
INFO - 2020-02-04 15:21:15 --> Security Class Initialized
INFO - 2020-02-04 15:21:15 --> Security Class Initialized
INFO - 2020-02-04 15:21:15 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:15 --> Output Class Initialized
INFO - 2020-02-04 15:21:15 --> Input Class Initialized
INFO - 2020-02-04 15:21:15 --> Input Class Initialized
INFO - 2020-02-04 15:21:15 --> Input Class Initialized
INFO - 2020-02-04 15:21:15 --> Security Class Initialized
INFO - 2020-02-04 15:21:15 --> Input Class Initialized
INFO - 2020-02-04 15:21:15 --> Input Class Initialized
INFO - 2020-02-04 15:21:15 --> Language Class Initialized
INFO - 2020-02-04 15:21:15 --> Language Class Initialized
INFO - 2020-02-04 15:21:15 --> Language Class Initialized
INFO - 2020-02-04 15:21:15 --> Language Class Initialized
INFO - 2020-02-04 15:21:15 --> Language Class Initialized
DEBUG - 2020-02-04 15:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:15 --> Input Class Initialized
ERROR - 2020-02-04 15:21:15 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 15:21:15 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 15:21:15 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 15:21:15 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 15:21:15 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 15:21:15 --> Language Class Initialized
INFO - 2020-02-04 15:21:15 --> Config Class Initialized
INFO - 2020-02-04 15:21:15 --> Config Class Initialized
INFO - 2020-02-04 15:21:15 --> Config Class Initialized
INFO - 2020-02-04 15:21:15 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:15 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:15 --> Hooks Class Initialized
ERROR - 2020-02-04 15:21:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:21:15 --> Config Class Initialized
DEBUG - 2020-02-04 15:21:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:21:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:21:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:15 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:15 --> URI Class Initialized
INFO - 2020-02-04 15:21:15 --> URI Class Initialized
INFO - 2020-02-04 15:21:15 --> URI Class Initialized
DEBUG - 2020-02-04 15:21:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:15 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:15 --> Router Class Initialized
INFO - 2020-02-04 15:21:15 --> Router Class Initialized
INFO - 2020-02-04 15:21:15 --> Router Class Initialized
INFO - 2020-02-04 15:21:15 --> URI Class Initialized
INFO - 2020-02-04 15:21:15 --> Output Class Initialized
INFO - 2020-02-04 15:21:15 --> Output Class Initialized
INFO - 2020-02-04 15:21:15 --> Output Class Initialized
INFO - 2020-02-04 15:21:15 --> Security Class Initialized
INFO - 2020-02-04 15:21:15 --> Security Class Initialized
INFO - 2020-02-04 15:21:15 --> Router Class Initialized
INFO - 2020-02-04 15:21:15 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:15 --> Output Class Initialized
INFO - 2020-02-04 15:21:15 --> Input Class Initialized
INFO - 2020-02-04 15:21:15 --> Input Class Initialized
INFO - 2020-02-04 15:21:15 --> Input Class Initialized
INFO - 2020-02-04 15:21:15 --> Security Class Initialized
INFO - 2020-02-04 15:21:15 --> Language Class Initialized
INFO - 2020-02-04 15:21:15 --> Language Class Initialized
INFO - 2020-02-04 15:21:15 --> Language Class Initialized
DEBUG - 2020-02-04 15:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:15 --> Input Class Initialized
ERROR - 2020-02-04 15:21:15 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:21:15 --> Loader Class Initialized
INFO - 2020-02-04 15:21:15 --> Loader Class Initialized
INFO - 2020-02-04 15:21:15 --> Language Class Initialized
INFO - 2020-02-04 15:21:15 --> Helper loaded: url_helper
INFO - 2020-02-04 15:21:15 --> Helper loaded: url_helper
ERROR - 2020-02-04 15:21:15 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:21:15 --> Database Driver Class Initialized
INFO - 2020-02-04 15:21:15 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 15:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:21:16 --> Config Class Initialized
INFO - 2020-02-04 15:21:16 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:16 --> Controller Class Initialized
INFO - 2020-02-04 15:21:16 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 15:21:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:16 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:16 --> Helper loaded: form_helper
INFO - 2020-02-04 15:21:16 --> Form Validation Class Initialized
INFO - 2020-02-04 15:21:16 --> URI Class Initialized
INFO - 2020-02-04 15:21:16 --> Router Class Initialized
ERROR - 2020-02-04 15:21:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:21:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:21:16 --> Output Class Initialized
INFO - 2020-02-04 15:21:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:21:16 --> Security Class Initialized
INFO - 2020-02-04 15:21:16 --> Final output sent to browser
DEBUG - 2020-02-04 15:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:16 --> Input Class Initialized
DEBUG - 2020-02-04 15:21:16 --> Total execution time: 0.8675
INFO - 2020-02-04 15:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:21:16 --> Language Class Initialized
INFO - 2020-02-04 15:21:16 --> Controller Class Initialized
ERROR - 2020-02-04 15:21:16 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:21:16 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:21:16 --> Helper loaded: form_helper
INFO - 2020-02-04 15:21:16 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:21:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:21:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:21:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:21:16 --> Final output sent to browser
DEBUG - 2020-02-04 15:21:16 --> Total execution time: 1.2302
INFO - 2020-02-04 15:21:17 --> Config Class Initialized
INFO - 2020-02-04 15:21:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:17 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:17 --> URI Class Initialized
INFO - 2020-02-04 15:21:17 --> Router Class Initialized
INFO - 2020-02-04 15:21:17 --> Output Class Initialized
INFO - 2020-02-04 15:21:17 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:17 --> Input Class Initialized
INFO - 2020-02-04 15:21:17 --> Language Class Initialized
INFO - 2020-02-04 15:21:17 --> Loader Class Initialized
INFO - 2020-02-04 15:21:17 --> Helper loaded: url_helper
INFO - 2020-02-04 15:21:17 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:21:17 --> Controller Class Initialized
INFO - 2020-02-04 15:21:17 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:21:17 --> Helper loaded: form_helper
INFO - 2020-02-04 15:21:17 --> Form Validation Class Initialized
INFO - 2020-02-04 15:21:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:21:17 --> Final output sent to browser
INFO - 2020-02-04 15:21:17 --> Config Class Initialized
INFO - 2020-02-04 15:21:17 --> Config Class Initialized
INFO - 2020-02-04 15:21:17 --> Config Class Initialized
INFO - 2020-02-04 15:21:17 --> Config Class Initialized
INFO - 2020-02-04 15:21:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:17 --> Total execution time: 0.7774
INFO - 2020-02-04 15:21:17 --> Config Class Initialized
INFO - 2020-02-04 15:21:17 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:17 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:17 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:21:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:18 --> Config Class Initialized
INFO - 2020-02-04 15:21:18 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:18 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:21:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:18 --> URI Class Initialized
INFO - 2020-02-04 15:21:18 --> URI Class Initialized
INFO - 2020-02-04 15:21:18 --> URI Class Initialized
DEBUG - 2020-02-04 15:21:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:18 --> URI Class Initialized
INFO - 2020-02-04 15:21:18 --> Router Class Initialized
INFO - 2020-02-04 15:21:18 --> Router Class Initialized
INFO - 2020-02-04 15:21:18 --> Router Class Initialized
INFO - 2020-02-04 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:18 --> URI Class Initialized
INFO - 2020-02-04 15:21:18 --> Router Class Initialized
INFO - 2020-02-04 15:21:18 --> URI Class Initialized
INFO - 2020-02-04 15:21:18 --> Output Class Initialized
INFO - 2020-02-04 15:21:18 --> Router Class Initialized
INFO - 2020-02-04 15:21:18 --> Output Class Initialized
INFO - 2020-02-04 15:21:18 --> Output Class Initialized
INFO - 2020-02-04 15:21:18 --> Output Class Initialized
INFO - 2020-02-04 15:21:18 --> Security Class Initialized
INFO - 2020-02-04 15:21:18 --> Security Class Initialized
INFO - 2020-02-04 15:21:18 --> Security Class Initialized
INFO - 2020-02-04 15:21:18 --> Router Class Initialized
INFO - 2020-02-04 15:21:18 --> Output Class Initialized
INFO - 2020-02-04 15:21:18 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:18 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:18 --> Output Class Initialized
DEBUG - 2020-02-04 15:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:18 --> Input Class Initialized
INFO - 2020-02-04 15:21:18 --> Input Class Initialized
INFO - 2020-02-04 15:21:18 --> Input Class Initialized
INFO - 2020-02-04 15:21:18 --> Input Class Initialized
DEBUG - 2020-02-04 15:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:18 --> Security Class Initialized
INFO - 2020-02-04 15:21:18 --> Language Class Initialized
INFO - 2020-02-04 15:21:18 --> Language Class Initialized
INFO - 2020-02-04 15:21:18 --> Input Class Initialized
DEBUG - 2020-02-04 15:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:18 --> Language Class Initialized
INFO - 2020-02-04 15:21:18 --> Language Class Initialized
INFO - 2020-02-04 15:21:18 --> Input Class Initialized
INFO - 2020-02-04 15:21:18 --> Language Class Initialized
ERROR - 2020-02-04 15:21:18 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 15:21:18 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 15:21:18 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 15:21:18 --> Loader Class Initialized
ERROR - 2020-02-04 15:21:18 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:21:18 --> Helper loaded: url_helper
INFO - 2020-02-04 15:21:18 --> Language Class Initialized
INFO - 2020-02-04 15:21:18 --> Config Class Initialized
INFO - 2020-02-04 15:21:18 --> Config Class Initialized
INFO - 2020-02-04 15:21:18 --> Config Class Initialized
INFO - 2020-02-04 15:21:18 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:18 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:18 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:18 --> Loader Class Initialized
INFO - 2020-02-04 15:21:18 --> Database Driver Class Initialized
INFO - 2020-02-04 15:21:18 --> Config Class Initialized
INFO - 2020-02-04 15:21:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:21:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:18 --> Helper loaded: url_helper
DEBUG - 2020-02-04 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:21:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:18 --> Database Driver Class Initialized
INFO - 2020-02-04 15:21:18 --> Controller Class Initialized
INFO - 2020-02-04 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:18 --> URI Class Initialized
INFO - 2020-02-04 15:21:18 --> URI Class Initialized
INFO - 2020-02-04 15:21:18 --> URI Class Initialized
DEBUG - 2020-02-04 15:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:21:18 --> Router Class Initialized
INFO - 2020-02-04 15:21:18 --> Router Class Initialized
INFO - 2020-02-04 15:21:18 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:21:18 --> URI Class Initialized
INFO - 2020-02-04 15:21:18 --> Router Class Initialized
INFO - 2020-02-04 15:21:18 --> Output Class Initialized
INFO - 2020-02-04 15:21:18 --> Output Class Initialized
INFO - 2020-02-04 15:21:18 --> Output Class Initialized
INFO - 2020-02-04 15:21:18 --> Router Class Initialized
INFO - 2020-02-04 15:21:18 --> Helper loaded: form_helper
INFO - 2020-02-04 15:21:18 --> Form Validation Class Initialized
INFO - 2020-02-04 15:21:18 --> Security Class Initialized
INFO - 2020-02-04 15:21:18 --> Security Class Initialized
INFO - 2020-02-04 15:21:18 --> Output Class Initialized
INFO - 2020-02-04 15:21:18 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:18 --> Security Class Initialized
ERROR - 2020-02-04 15:21:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:21:18 --> Input Class Initialized
INFO - 2020-02-04 15:21:18 --> Input Class Initialized
INFO - 2020-02-04 15:21:18 --> Input Class Initialized
ERROR - 2020-02-04 15:21:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-04 15:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:21:18 --> Language Class Initialized
INFO - 2020-02-04 15:21:18 --> Language Class Initialized
INFO - 2020-02-04 15:21:18 --> Language Class Initialized
INFO - 2020-02-04 15:21:18 --> Input Class Initialized
INFO - 2020-02-04 15:21:18 --> Final output sent to browser
ERROR - 2020-02-04 15:21:18 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:21:18 --> Language Class Initialized
ERROR - 2020-02-04 15:21:18 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 15:21:18 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-04 15:21:18 --> Total execution time: 0.9277
ERROR - 2020-02-04 15:21:18 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:21:18 --> Config Class Initialized
INFO - 2020-02-04 15:21:18 --> Config Class Initialized
INFO - 2020-02-04 15:21:18 --> Config Class Initialized
INFO - 2020-02-04 15:21:18 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:18 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:18 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:21:18 --> Config Class Initialized
INFO - 2020-02-04 15:21:19 --> Hooks Class Initialized
INFO - 2020-02-04 15:21:19 --> Controller Class Initialized
DEBUG - 2020-02-04 15:21:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:21:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:21:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:19 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:19 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:19 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:19 --> Model "M_tiket" initialized
DEBUG - 2020-02-04 15:21:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:19 --> URI Class Initialized
INFO - 2020-02-04 15:21:19 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:19 --> URI Class Initialized
INFO - 2020-02-04 15:21:19 --> URI Class Initialized
INFO - 2020-02-04 15:21:19 --> Helper loaded: form_helper
INFO - 2020-02-04 15:21:19 --> Form Validation Class Initialized
INFO - 2020-02-04 15:21:19 --> URI Class Initialized
INFO - 2020-02-04 15:21:19 --> Router Class Initialized
INFO - 2020-02-04 15:21:19 --> Router Class Initialized
INFO - 2020-02-04 15:21:19 --> Router Class Initialized
INFO - 2020-02-04 15:21:19 --> Output Class Initialized
INFO - 2020-02-04 15:21:19 --> Router Class Initialized
INFO - 2020-02-04 15:21:19 --> Output Class Initialized
INFO - 2020-02-04 15:21:19 --> Output Class Initialized
ERROR - 2020-02-04 15:21:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:21:19 --> Security Class Initialized
INFO - 2020-02-04 15:21:19 --> Output Class Initialized
ERROR - 2020-02-04 15:21:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:21:19 --> Security Class Initialized
INFO - 2020-02-04 15:21:19 --> Security Class Initialized
INFO - 2020-02-04 15:21:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-04 15:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:19 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:19 --> Input Class Initialized
INFO - 2020-02-04 15:21:19 --> Final output sent to browser
INFO - 2020-02-04 15:21:19 --> Input Class Initialized
INFO - 2020-02-04 15:21:19 --> Input Class Initialized
DEBUG - 2020-02-04 15:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:19 --> Input Class Initialized
DEBUG - 2020-02-04 15:21:19 --> Total execution time: 1.2274
INFO - 2020-02-04 15:21:19 --> Language Class Initialized
INFO - 2020-02-04 15:21:19 --> Language Class Initialized
INFO - 2020-02-04 15:21:19 --> Language Class Initialized
INFO - 2020-02-04 15:21:19 --> Language Class Initialized
ERROR - 2020-02-04 15:21:19 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 15:21:19 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 15:21:19 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-04 15:21:19 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:21:19 --> Config Class Initialized
INFO - 2020-02-04 15:21:19 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:19 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:19 --> URI Class Initialized
INFO - 2020-02-04 15:21:19 --> Router Class Initialized
INFO - 2020-02-04 15:21:19 --> Output Class Initialized
INFO - 2020-02-04 15:21:19 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:19 --> Input Class Initialized
INFO - 2020-02-04 15:21:19 --> Language Class Initialized
ERROR - 2020-02-04 15:21:19 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:21:19 --> Config Class Initialized
INFO - 2020-02-04 15:21:19 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:20 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:20 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:20 --> URI Class Initialized
INFO - 2020-02-04 15:21:20 --> Router Class Initialized
INFO - 2020-02-04 15:21:20 --> Output Class Initialized
INFO - 2020-02-04 15:21:20 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:20 --> Input Class Initialized
INFO - 2020-02-04 15:21:20 --> Language Class Initialized
ERROR - 2020-02-04 15:21:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:21:20 --> Config Class Initialized
INFO - 2020-02-04 15:21:20 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:20 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:20 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:20 --> URI Class Initialized
INFO - 2020-02-04 15:21:20 --> Router Class Initialized
INFO - 2020-02-04 15:21:20 --> Output Class Initialized
INFO - 2020-02-04 15:21:20 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:20 --> Input Class Initialized
INFO - 2020-02-04 15:21:20 --> Language Class Initialized
ERROR - 2020-02-04 15:21:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:21:20 --> Config Class Initialized
INFO - 2020-02-04 15:21:20 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:20 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:20 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:21 --> URI Class Initialized
INFO - 2020-02-04 15:21:21 --> Router Class Initialized
INFO - 2020-02-04 15:21:21 --> Output Class Initialized
INFO - 2020-02-04 15:21:21 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:21 --> Input Class Initialized
INFO - 2020-02-04 15:21:21 --> Language Class Initialized
ERROR - 2020-02-04 15:21:21 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:21:21 --> Config Class Initialized
INFO - 2020-02-04 15:21:21 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:21 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:21 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:21 --> URI Class Initialized
INFO - 2020-02-04 15:21:21 --> Router Class Initialized
INFO - 2020-02-04 15:21:21 --> Output Class Initialized
INFO - 2020-02-04 15:21:21 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:21 --> Input Class Initialized
INFO - 2020-02-04 15:21:21 --> Language Class Initialized
ERROR - 2020-02-04 15:21:21 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:21:21 --> Config Class Initialized
INFO - 2020-02-04 15:21:21 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:21 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:21 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:21 --> URI Class Initialized
INFO - 2020-02-04 15:21:21 --> Router Class Initialized
INFO - 2020-02-04 15:21:21 --> Output Class Initialized
INFO - 2020-02-04 15:21:21 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:22 --> Input Class Initialized
INFO - 2020-02-04 15:21:22 --> Language Class Initialized
ERROR - 2020-02-04 15:21:22 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:21:22 --> Config Class Initialized
INFO - 2020-02-04 15:21:22 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:22 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:22 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:22 --> URI Class Initialized
INFO - 2020-02-04 15:21:22 --> Router Class Initialized
INFO - 2020-02-04 15:21:22 --> Output Class Initialized
INFO - 2020-02-04 15:21:22 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:22 --> Input Class Initialized
INFO - 2020-02-04 15:21:22 --> Language Class Initialized
ERROR - 2020-02-04 15:21:22 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:21:25 --> Config Class Initialized
INFO - 2020-02-04 15:21:25 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:21:25 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:21:25 --> Utf8 Class Initialized
INFO - 2020-02-04 15:21:25 --> URI Class Initialized
INFO - 2020-02-04 15:21:25 --> Router Class Initialized
INFO - 2020-02-04 15:21:25 --> Output Class Initialized
INFO - 2020-02-04 15:21:25 --> Security Class Initialized
DEBUG - 2020-02-04 15:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:21:26 --> Input Class Initialized
INFO - 2020-02-04 15:21:26 --> Language Class Initialized
INFO - 2020-02-04 15:21:26 --> Loader Class Initialized
INFO - 2020-02-04 15:21:26 --> Helper loaded: url_helper
INFO - 2020-02-04 15:21:26 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:21:26 --> Controller Class Initialized
INFO - 2020-02-04 15:21:26 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:21:26 --> Helper loaded: form_helper
INFO - 2020-02-04 15:21:26 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:21:26 --> Query error: Unknown column 'id_show' in 'field list' - Invalid query: INSERT INTO `pengunjung` (`id_show`, `jenis`, `tanggal_mulai`, `tanggal_selesai`, `harga`, `jumlah_tiket`, `nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, '1', '1', '1', '12167@smkn20jkt.sch.id')
INFO - 2020-02-04 15:21:26 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-04 15:25:19 --> Config Class Initialized
INFO - 2020-02-04 15:25:19 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:25:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:19 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:19 --> URI Class Initialized
INFO - 2020-02-04 15:25:20 --> Router Class Initialized
INFO - 2020-02-04 15:25:20 --> Output Class Initialized
INFO - 2020-02-04 15:25:20 --> Security Class Initialized
DEBUG - 2020-02-04 15:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:20 --> Input Class Initialized
INFO - 2020-02-04 15:25:20 --> Language Class Initialized
INFO - 2020-02-04 15:25:20 --> Loader Class Initialized
INFO - 2020-02-04 15:25:20 --> Helper loaded: url_helper
INFO - 2020-02-04 15:25:20 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:25:20 --> Controller Class Initialized
INFO - 2020-02-04 15:25:20 --> Model "M_tiket" initialized
ERROR - 2020-02-04 15:25:20 --> Severity: Compile Error --> Cannot declare class M_tiket, because the name is already in use C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 131
INFO - 2020-02-04 15:25:22 --> Config Class Initialized
INFO - 2020-02-04 15:25:22 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:25:22 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:22 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:22 --> URI Class Initialized
INFO - 2020-02-04 15:25:22 --> Router Class Initialized
INFO - 2020-02-04 15:25:22 --> Output Class Initialized
INFO - 2020-02-04 15:25:22 --> Security Class Initialized
DEBUG - 2020-02-04 15:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:22 --> Input Class Initialized
INFO - 2020-02-04 15:25:22 --> Language Class Initialized
INFO - 2020-02-04 15:25:22 --> Loader Class Initialized
INFO - 2020-02-04 15:25:22 --> Helper loaded: url_helper
INFO - 2020-02-04 15:25:23 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:25:23 --> Controller Class Initialized
INFO - 2020-02-04 15:25:23 --> Model "M_tiket" initialized
ERROR - 2020-02-04 15:25:23 --> Severity: Compile Error --> Cannot declare class M_tiket, because the name is already in use C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 131
INFO - 2020-02-04 15:25:41 --> Config Class Initialized
INFO - 2020-02-04 15:25:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:25:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:41 --> URI Class Initialized
INFO - 2020-02-04 15:25:41 --> Router Class Initialized
INFO - 2020-02-04 15:25:41 --> Output Class Initialized
INFO - 2020-02-04 15:25:41 --> Security Class Initialized
DEBUG - 2020-02-04 15:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:41 --> Input Class Initialized
INFO - 2020-02-04 15:25:41 --> Language Class Initialized
INFO - 2020-02-04 15:25:41 --> Loader Class Initialized
INFO - 2020-02-04 15:25:41 --> Helper loaded: url_helper
INFO - 2020-02-04 15:25:41 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:25:41 --> Controller Class Initialized
INFO - 2020-02-04 15:25:41 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:25:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:25:41 --> Helper loaded: form_helper
INFO - 2020-02-04 15:25:41 --> Form Validation Class Initialized
INFO - 2020-02-04 15:25:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:25:41 --> Final output sent to browser
INFO - 2020-02-04 15:25:41 --> Config Class Initialized
INFO - 2020-02-04 15:25:41 --> Config Class Initialized
INFO - 2020-02-04 15:25:41 --> Config Class Initialized
INFO - 2020-02-04 15:25:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:25:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:25:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:25:41 --> Total execution time: 0.7758
INFO - 2020-02-04 15:25:41 --> Config Class Initialized
INFO - 2020-02-04 15:25:41 --> Config Class Initialized
INFO - 2020-02-04 15:25:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:42 --> Config Class Initialized
INFO - 2020-02-04 15:25:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:25:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:42 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:42 --> URI Class Initialized
INFO - 2020-02-04 15:25:42 --> URI Class Initialized
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:42 --> URI Class Initialized
INFO - 2020-02-04 15:25:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:42 --> Router Class Initialized
INFO - 2020-02-04 15:25:42 --> Router Class Initialized
INFO - 2020-02-04 15:25:42 --> Router Class Initialized
INFO - 2020-02-04 15:25:42 --> URI Class Initialized
INFO - 2020-02-04 15:25:42 --> URI Class Initialized
INFO - 2020-02-04 15:25:42 --> Router Class Initialized
INFO - 2020-02-04 15:25:42 --> Output Class Initialized
INFO - 2020-02-04 15:25:42 --> Router Class Initialized
INFO - 2020-02-04 15:25:42 --> Output Class Initialized
INFO - 2020-02-04 15:25:42 --> URI Class Initialized
INFO - 2020-02-04 15:25:42 --> Output Class Initialized
INFO - 2020-02-04 15:25:42 --> Security Class Initialized
INFO - 2020-02-04 15:25:42 --> Security Class Initialized
INFO - 2020-02-04 15:25:42 --> Output Class Initialized
INFO - 2020-02-04 15:25:42 --> Output Class Initialized
INFO - 2020-02-04 15:25:42 --> Router Class Initialized
INFO - 2020-02-04 15:25:42 --> Security Class Initialized
INFO - 2020-02-04 15:25:42 --> Security Class Initialized
INFO - 2020-02-04 15:25:42 --> Security Class Initialized
DEBUG - 2020-02-04 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:42 --> Output Class Initialized
DEBUG - 2020-02-04 15:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:42 --> Input Class Initialized
INFO - 2020-02-04 15:25:42 --> Input Class Initialized
INFO - 2020-02-04 15:25:42 --> Input Class Initialized
DEBUG - 2020-02-04 15:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:42 --> Security Class Initialized
INFO - 2020-02-04 15:25:42 --> Input Class Initialized
INFO - 2020-02-04 15:25:42 --> Input Class Initialized
INFO - 2020-02-04 15:25:42 --> Language Class Initialized
INFO - 2020-02-04 15:25:42 --> Language Class Initialized
DEBUG - 2020-02-04 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:42 --> Language Class Initialized
INFO - 2020-02-04 15:25:42 --> Input Class Initialized
INFO - 2020-02-04 15:25:42 --> Language Class Initialized
INFO - 2020-02-04 15:25:42 --> Language Class Initialized
ERROR - 2020-02-04 15:25:42 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 15:25:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 15:25:42 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 15:25:42 --> Language Class Initialized
ERROR - 2020-02-04 15:25:42 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 15:25:42 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:25:42 --> Config Class Initialized
INFO - 2020-02-04 15:25:42 --> Config Class Initialized
INFO - 2020-02-04 15:25:42 --> Config Class Initialized
INFO - 2020-02-04 15:25:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:25:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:25:42 --> Hooks Class Initialized
ERROR - 2020-02-04 15:25:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:25:42 --> Config Class Initialized
INFO - 2020-02-04 15:25:42 --> Config Class Initialized
INFO - 2020-02-04 15:25:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:25:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:42 --> Config Class Initialized
INFO - 2020-02-04 15:25:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:25:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:42 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:42 --> URI Class Initialized
INFO - 2020-02-04 15:25:42 --> URI Class Initialized
INFO - 2020-02-04 15:25:42 --> URI Class Initialized
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:42 --> URI Class Initialized
INFO - 2020-02-04 15:25:42 --> URI Class Initialized
INFO - 2020-02-04 15:25:42 --> Router Class Initialized
INFO - 2020-02-04 15:25:42 --> Router Class Initialized
INFO - 2020-02-04 15:25:42 --> Router Class Initialized
INFO - 2020-02-04 15:25:42 --> Router Class Initialized
INFO - 2020-02-04 15:25:42 --> Output Class Initialized
INFO - 2020-02-04 15:25:42 --> Output Class Initialized
INFO - 2020-02-04 15:25:42 --> URI Class Initialized
INFO - 2020-02-04 15:25:42 --> Output Class Initialized
INFO - 2020-02-04 15:25:42 --> Router Class Initialized
INFO - 2020-02-04 15:25:42 --> Security Class Initialized
INFO - 2020-02-04 15:25:42 --> Security Class Initialized
INFO - 2020-02-04 15:25:42 --> Output Class Initialized
INFO - 2020-02-04 15:25:42 --> Security Class Initialized
INFO - 2020-02-04 15:25:42 --> Router Class Initialized
INFO - 2020-02-04 15:25:42 --> Output Class Initialized
DEBUG - 2020-02-04 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:42 --> Security Class Initialized
DEBUG - 2020-02-04 15:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:42 --> Output Class Initialized
INFO - 2020-02-04 15:25:42 --> Security Class Initialized
INFO - 2020-02-04 15:25:42 --> Input Class Initialized
DEBUG - 2020-02-04 15:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:42 --> Input Class Initialized
INFO - 2020-02-04 15:25:42 --> Input Class Initialized
INFO - 2020-02-04 15:25:42 --> Security Class Initialized
INFO - 2020-02-04 15:25:42 --> Input Class Initialized
INFO - 2020-02-04 15:25:42 --> Input Class Initialized
INFO - 2020-02-04 15:25:42 --> Language Class Initialized
DEBUG - 2020-02-04 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:42 --> Language Class Initialized
INFO - 2020-02-04 15:25:42 --> Language Class Initialized
INFO - 2020-02-04 15:25:42 --> Language Class Initialized
ERROR - 2020-02-04 15:25:42 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-04 15:25:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:25:42 --> Input Class Initialized
INFO - 2020-02-04 15:25:42 --> Language Class Initialized
ERROR - 2020-02-04 15:25:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:25:42 --> Language Class Initialized
ERROR - 2020-02-04 15:25:42 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 15:25:42 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:25:42 --> Config Class Initialized
INFO - 2020-02-04 15:25:42 --> Config Class Initialized
INFO - 2020-02-04 15:25:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:25:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:25:42 --> Loader Class Initialized
INFO - 2020-02-04 15:25:42 --> Helper loaded: url_helper
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:25:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:43 --> Database Driver Class Initialized
INFO - 2020-02-04 15:25:43 --> URI Class Initialized
INFO - 2020-02-04 15:25:43 --> URI Class Initialized
DEBUG - 2020-02-04 15:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:25:43 --> Router Class Initialized
INFO - 2020-02-04 15:25:43 --> Router Class Initialized
INFO - 2020-02-04 15:25:43 --> Controller Class Initialized
INFO - 2020-02-04 15:25:43 --> Output Class Initialized
INFO - 2020-02-04 15:25:43 --> Output Class Initialized
INFO - 2020-02-04 15:25:43 --> Security Class Initialized
INFO - 2020-02-04 15:25:43 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:25:43 --> Security Class Initialized
INFO - 2020-02-04 15:25:43 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-04 15:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:43 --> Input Class Initialized
INFO - 2020-02-04 15:25:43 --> Input Class Initialized
INFO - 2020-02-04 15:25:43 --> Helper loaded: form_helper
INFO - 2020-02-04 15:25:43 --> Form Validation Class Initialized
INFO - 2020-02-04 15:25:43 --> Language Class Initialized
INFO - 2020-02-04 15:25:43 --> Language Class Initialized
ERROR - 2020-02-04 15:25:43 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:25:43 --> Loader Class Initialized
ERROR - 2020-02-04 15:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:25:43 --> Helper loaded: url_helper
INFO - 2020-02-04 15:25:43 --> Config Class Initialized
INFO - 2020-02-04 15:25:43 --> Hooks Class Initialized
INFO - 2020-02-04 15:25:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:25:43 --> Database Driver Class Initialized
INFO - 2020-02-04 15:25:43 --> Final output sent to browser
DEBUG - 2020-02-04 15:25:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:25:43 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:25:43 --> Total execution time: 0.9174
INFO - 2020-02-04 15:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:25:43 --> URI Class Initialized
INFO - 2020-02-04 15:25:43 --> Controller Class Initialized
INFO - 2020-02-04 15:25:43 --> Router Class Initialized
INFO - 2020-02-04 15:25:43 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:25:43 --> Output Class Initialized
INFO - 2020-02-04 15:25:43 --> Security Class Initialized
INFO - 2020-02-04 15:25:43 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-04 15:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:43 --> Helper loaded: form_helper
INFO - 2020-02-04 15:25:43 --> Form Validation Class Initialized
INFO - 2020-02-04 15:25:43 --> Input Class Initialized
INFO - 2020-02-04 15:25:43 --> Language Class Initialized
ERROR - 2020-02-04 15:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-04 15:25:43 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:25:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:25:43 --> Config Class Initialized
INFO - 2020-02-04 15:25:43 --> Hooks Class Initialized
INFO - 2020-02-04 15:25:43 --> Final output sent to browser
DEBUG - 2020-02-04 15:25:43 --> Total execution time: 0.9503
DEBUG - 2020-02-04 15:25:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:43 --> URI Class Initialized
INFO - 2020-02-04 15:25:43 --> Router Class Initialized
INFO - 2020-02-04 15:25:44 --> Output Class Initialized
INFO - 2020-02-04 15:25:44 --> Security Class Initialized
DEBUG - 2020-02-04 15:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:44 --> Input Class Initialized
INFO - 2020-02-04 15:25:44 --> Language Class Initialized
ERROR - 2020-02-04 15:25:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:25:44 --> Config Class Initialized
INFO - 2020-02-04 15:25:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:25:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:44 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:44 --> URI Class Initialized
INFO - 2020-02-04 15:25:44 --> Router Class Initialized
INFO - 2020-02-04 15:25:44 --> Output Class Initialized
INFO - 2020-02-04 15:25:44 --> Security Class Initialized
DEBUG - 2020-02-04 15:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:44 --> Input Class Initialized
INFO - 2020-02-04 15:25:44 --> Language Class Initialized
ERROR - 2020-02-04 15:25:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:25:44 --> Config Class Initialized
INFO - 2020-02-04 15:25:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:25:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:44 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:44 --> URI Class Initialized
INFO - 2020-02-04 15:25:44 --> Router Class Initialized
INFO - 2020-02-04 15:25:44 --> Output Class Initialized
INFO - 2020-02-04 15:25:44 --> Security Class Initialized
DEBUG - 2020-02-04 15:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:45 --> Input Class Initialized
INFO - 2020-02-04 15:25:45 --> Language Class Initialized
ERROR - 2020-02-04 15:25:45 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:25:45 --> Config Class Initialized
INFO - 2020-02-04 15:25:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:25:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:45 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:45 --> URI Class Initialized
INFO - 2020-02-04 15:25:45 --> Router Class Initialized
INFO - 2020-02-04 15:25:45 --> Output Class Initialized
INFO - 2020-02-04 15:25:45 --> Security Class Initialized
DEBUG - 2020-02-04 15:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:45 --> Input Class Initialized
INFO - 2020-02-04 15:25:45 --> Language Class Initialized
ERROR - 2020-02-04 15:25:45 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:25:45 --> Config Class Initialized
INFO - 2020-02-04 15:25:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:25:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:45 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:45 --> URI Class Initialized
INFO - 2020-02-04 15:25:45 --> Router Class Initialized
INFO - 2020-02-04 15:25:45 --> Output Class Initialized
INFO - 2020-02-04 15:25:45 --> Security Class Initialized
DEBUG - 2020-02-04 15:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:45 --> Input Class Initialized
INFO - 2020-02-04 15:25:45 --> Language Class Initialized
ERROR - 2020-02-04 15:25:45 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:25:46 --> Config Class Initialized
INFO - 2020-02-04 15:25:46 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:25:46 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:46 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:46 --> URI Class Initialized
INFO - 2020-02-04 15:25:46 --> Router Class Initialized
INFO - 2020-02-04 15:25:46 --> Output Class Initialized
INFO - 2020-02-04 15:25:46 --> Security Class Initialized
DEBUG - 2020-02-04 15:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:46 --> Input Class Initialized
INFO - 2020-02-04 15:25:46 --> Language Class Initialized
ERROR - 2020-02-04 15:25:46 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:25:52 --> Config Class Initialized
INFO - 2020-02-04 15:25:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:25:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:25:52 --> Utf8 Class Initialized
INFO - 2020-02-04 15:25:52 --> URI Class Initialized
INFO - 2020-02-04 15:25:52 --> Router Class Initialized
INFO - 2020-02-04 15:25:52 --> Output Class Initialized
INFO - 2020-02-04 15:25:52 --> Security Class Initialized
DEBUG - 2020-02-04 15:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:25:52 --> Input Class Initialized
INFO - 2020-02-04 15:25:52 --> Language Class Initialized
INFO - 2020-02-04 15:25:52 --> Loader Class Initialized
INFO - 2020-02-04 15:25:52 --> Helper loaded: url_helper
INFO - 2020-02-04 15:25:52 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:25:53 --> Controller Class Initialized
INFO - 2020-02-04 15:25:53 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:25:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:25:53 --> Helper loaded: form_helper
INFO - 2020-02-04 15:25:53 --> Form Validation Class Initialized
INFO - 2020-02-04 15:25:53 --> Final output sent to browser
DEBUG - 2020-02-04 15:25:53 --> Total execution time: 0.8997
INFO - 2020-02-04 15:31:26 --> Config Class Initialized
INFO - 2020-02-04 15:31:26 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:26 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:26 --> URI Class Initialized
INFO - 2020-02-04 15:31:26 --> Router Class Initialized
INFO - 2020-02-04 15:31:27 --> Output Class Initialized
INFO - 2020-02-04 15:31:27 --> Security Class Initialized
DEBUG - 2020-02-04 15:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:27 --> Input Class Initialized
INFO - 2020-02-04 15:31:27 --> Language Class Initialized
INFO - 2020-02-04 15:31:27 --> Loader Class Initialized
INFO - 2020-02-04 15:31:27 --> Helper loaded: url_helper
INFO - 2020-02-04 15:31:27 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:31:27 --> Controller Class Initialized
INFO - 2020-02-04 15:31:27 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:31:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:31:27 --> Helper loaded: form_helper
INFO - 2020-02-04 15:31:27 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:31:27 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 34
ERROR - 2020-02-04 15:31:27 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 35
ERROR - 2020-02-04 15:31:27 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 36
ERROR - 2020-02-04 15:31:27 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 37
ERROR - 2020-02-04 15:31:27 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 81
ERROR - 2020-02-04 15:31:27 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 82
ERROR - 2020-02-04 15:31:27 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 83
ERROR - 2020-02-04 15:31:27 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 84
ERROR - 2020-02-04 15:31:27 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pengunjung` (`nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2020-02-04 15:31:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-04 15:31:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow\system\core\Common.php 570
INFO - 2020-02-04 15:31:35 --> Config Class Initialized
INFO - 2020-02-04 15:31:35 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:36 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:36 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:36 --> URI Class Initialized
INFO - 2020-02-04 15:31:36 --> Router Class Initialized
INFO - 2020-02-04 15:31:36 --> Output Class Initialized
INFO - 2020-02-04 15:31:36 --> Security Class Initialized
DEBUG - 2020-02-04 15:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:36 --> Input Class Initialized
INFO - 2020-02-04 15:31:36 --> Language Class Initialized
INFO - 2020-02-04 15:31:36 --> Loader Class Initialized
INFO - 2020-02-04 15:31:36 --> Helper loaded: url_helper
INFO - 2020-02-04 15:31:36 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:31:36 --> Controller Class Initialized
INFO - 2020-02-04 15:31:36 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:31:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:31:36 --> Helper loaded: form_helper
INFO - 2020-02-04 15:31:36 --> Form Validation Class Initialized
INFO - 2020-02-04 15:31:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:31:36 --> Final output sent to browser
INFO - 2020-02-04 15:31:36 --> Config Class Initialized
INFO - 2020-02-04 15:31:37 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:37 --> Total execution time: 1.1054
INFO - 2020-02-04 15:31:37 --> Config Class Initialized
INFO - 2020-02-04 15:31:37 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:37 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:37 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:31:37 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:37 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:37 --> URI Class Initialized
INFO - 2020-02-04 15:31:37 --> URI Class Initialized
INFO - 2020-02-04 15:31:37 --> Router Class Initialized
INFO - 2020-02-04 15:31:37 --> Router Class Initialized
INFO - 2020-02-04 15:31:37 --> Output Class Initialized
INFO - 2020-02-04 15:31:37 --> Security Class Initialized
INFO - 2020-02-04 15:31:37 --> Output Class Initialized
DEBUG - 2020-02-04 15:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:37 --> Security Class Initialized
INFO - 2020-02-04 15:31:37 --> Input Class Initialized
DEBUG - 2020-02-04 15:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:37 --> Input Class Initialized
INFO - 2020-02-04 15:31:37 --> Language Class Initialized
INFO - 2020-02-04 15:31:37 --> Language Class Initialized
INFO - 2020-02-04 15:31:37 --> Loader Class Initialized
INFO - 2020-02-04 15:31:37 --> Helper loaded: url_helper
INFO - 2020-02-04 15:31:37 --> Loader Class Initialized
INFO - 2020-02-04 15:31:37 --> Helper loaded: url_helper
INFO - 2020-02-04 15:31:37 --> Database Driver Class Initialized
INFO - 2020-02-04 15:31:37 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:31:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:31:37 --> Controller Class Initialized
INFO - 2020-02-04 15:31:37 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:31:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:31:37 --> Helper loaded: form_helper
INFO - 2020-02-04 15:31:37 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:31:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:31:37 --> Final output sent to browser
DEBUG - 2020-02-04 15:31:37 --> Total execution time: 0.9288
INFO - 2020-02-04 15:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:31:38 --> Controller Class Initialized
INFO - 2020-02-04 15:31:38 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:31:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:31:38 --> Helper loaded: form_helper
INFO - 2020-02-04 15:31:38 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:31:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:31:38 --> Final output sent to browser
DEBUG - 2020-02-04 15:31:38 --> Total execution time: 1.2640
INFO - 2020-02-04 15:31:40 --> Config Class Initialized
INFO - 2020-02-04 15:31:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:40 --> URI Class Initialized
INFO - 2020-02-04 15:31:40 --> Router Class Initialized
INFO - 2020-02-04 15:31:40 --> Output Class Initialized
INFO - 2020-02-04 15:31:40 --> Security Class Initialized
DEBUG - 2020-02-04 15:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:40 --> Input Class Initialized
INFO - 2020-02-04 15:31:40 --> Language Class Initialized
INFO - 2020-02-04 15:31:40 --> Loader Class Initialized
INFO - 2020-02-04 15:31:40 --> Helper loaded: url_helper
INFO - 2020-02-04 15:31:40 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:31:40 --> Controller Class Initialized
INFO - 2020-02-04 15:31:40 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:31:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:31:40 --> Helper loaded: form_helper
INFO - 2020-02-04 15:31:40 --> Form Validation Class Initialized
INFO - 2020-02-04 15:31:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:31:40 --> Final output sent to browser
INFO - 2020-02-04 15:31:40 --> Config Class Initialized
INFO - 2020-02-04 15:31:41 --> Config Class Initialized
INFO - 2020-02-04 15:31:41 --> Config Class Initialized
INFO - 2020-02-04 15:31:41 --> Config Class Initialized
INFO - 2020-02-04 15:31:41 --> Config Class Initialized
INFO - 2020-02-04 15:31:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:41 --> Total execution time: 0.8197
INFO - 2020-02-04 15:31:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:31:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:31:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:31:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:31:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:31:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:31:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:31:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:41 --> Config Class Initialized
INFO - 2020-02-04 15:31:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:31:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:41 --> URI Class Initialized
INFO - 2020-02-04 15:31:41 --> URI Class Initialized
INFO - 2020-02-04 15:31:41 --> URI Class Initialized
INFO - 2020-02-04 15:31:41 --> URI Class Initialized
INFO - 2020-02-04 15:31:41 --> URI Class Initialized
DEBUG - 2020-02-04 15:31:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:41 --> Router Class Initialized
INFO - 2020-02-04 15:31:41 --> Router Class Initialized
INFO - 2020-02-04 15:31:41 --> Router Class Initialized
INFO - 2020-02-04 15:31:41 --> Router Class Initialized
INFO - 2020-02-04 15:31:41 --> Router Class Initialized
INFO - 2020-02-04 15:31:41 --> Output Class Initialized
INFO - 2020-02-04 15:31:41 --> Output Class Initialized
INFO - 2020-02-04 15:31:41 --> Output Class Initialized
INFO - 2020-02-04 15:31:41 --> Output Class Initialized
INFO - 2020-02-04 15:31:41 --> URI Class Initialized
INFO - 2020-02-04 15:31:41 --> Output Class Initialized
INFO - 2020-02-04 15:31:41 --> Security Class Initialized
INFO - 2020-02-04 15:31:41 --> Security Class Initialized
INFO - 2020-02-04 15:31:41 --> Router Class Initialized
INFO - 2020-02-04 15:31:41 --> Security Class Initialized
INFO - 2020-02-04 15:31:41 --> Security Class Initialized
INFO - 2020-02-04 15:31:41 --> Security Class Initialized
DEBUG - 2020-02-04 15:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:41 --> Output Class Initialized
DEBUG - 2020-02-04 15:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:41 --> Input Class Initialized
INFO - 2020-02-04 15:31:41 --> Input Class Initialized
INFO - 2020-02-04 15:31:41 --> Input Class Initialized
INFO - 2020-02-04 15:31:41 --> Input Class Initialized
INFO - 2020-02-04 15:31:41 --> Input Class Initialized
INFO - 2020-02-04 15:31:41 --> Security Class Initialized
INFO - 2020-02-04 15:31:41 --> Language Class Initialized
INFO - 2020-02-04 15:31:41 --> Language Class Initialized
DEBUG - 2020-02-04 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:41 --> Language Class Initialized
INFO - 2020-02-04 15:31:41 --> Language Class Initialized
INFO - 2020-02-04 15:31:41 --> Language Class Initialized
INFO - 2020-02-04 15:31:41 --> Input Class Initialized
ERROR - 2020-02-04 15:31:41 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 15:31:41 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 15:31:41 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 15:31:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 15:31:41 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:31:41 --> Language Class Initialized
INFO - 2020-02-04 15:31:41 --> Config Class Initialized
INFO - 2020-02-04 15:31:41 --> Config Class Initialized
INFO - 2020-02-04 15:31:41 --> Config Class Initialized
INFO - 2020-02-04 15:31:41 --> Config Class Initialized
INFO - 2020-02-04 15:31:41 --> Config Class Initialized
INFO - 2020-02-04 15:31:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:31:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:31:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:31:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:31:41 --> Hooks Class Initialized
ERROR - 2020-02-04 15:31:41 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-04 15:31:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:41 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:31:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:31:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:31:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:31:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:41 --> Config Class Initialized
INFO - 2020-02-04 15:31:41 --> Hooks Class Initialized
INFO - 2020-02-04 15:31:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:41 --> URI Class Initialized
INFO - 2020-02-04 15:31:41 --> URI Class Initialized
INFO - 2020-02-04 15:31:41 --> URI Class Initialized
INFO - 2020-02-04 15:31:41 --> URI Class Initialized
INFO - 2020-02-04 15:31:41 --> URI Class Initialized
INFO - 2020-02-04 15:31:41 --> Router Class Initialized
DEBUG - 2020-02-04 15:31:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:41 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:41 --> Router Class Initialized
INFO - 2020-02-04 15:31:41 --> Router Class Initialized
INFO - 2020-02-04 15:31:41 --> Router Class Initialized
INFO - 2020-02-04 15:31:41 --> Router Class Initialized
INFO - 2020-02-04 15:31:41 --> Output Class Initialized
INFO - 2020-02-04 15:31:41 --> Security Class Initialized
INFO - 2020-02-04 15:31:41 --> URI Class Initialized
INFO - 2020-02-04 15:31:41 --> Output Class Initialized
INFO - 2020-02-04 15:31:41 --> Output Class Initialized
INFO - 2020-02-04 15:31:41 --> Output Class Initialized
INFO - 2020-02-04 15:31:41 --> Output Class Initialized
DEBUG - 2020-02-04 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:41 --> Security Class Initialized
INFO - 2020-02-04 15:31:41 --> Security Class Initialized
INFO - 2020-02-04 15:31:41 --> Security Class Initialized
INFO - 2020-02-04 15:31:41 --> Router Class Initialized
INFO - 2020-02-04 15:31:41 --> Security Class Initialized
INFO - 2020-02-04 15:31:41 --> Input Class Initialized
DEBUG - 2020-02-04 15:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:41 --> Output Class Initialized
DEBUG - 2020-02-04 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:41 --> Input Class Initialized
INFO - 2020-02-04 15:31:41 --> Input Class Initialized
INFO - 2020-02-04 15:31:41 --> Input Class Initialized
INFO - 2020-02-04 15:31:41 --> Input Class Initialized
INFO - 2020-02-04 15:31:41 --> Language Class Initialized
INFO - 2020-02-04 15:31:41 --> Security Class Initialized
INFO - 2020-02-04 15:31:41 --> Language Class Initialized
INFO - 2020-02-04 15:31:41 --> Language Class Initialized
INFO - 2020-02-04 15:31:41 --> Language Class Initialized
DEBUG - 2020-02-04 15:31:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 15:31:41 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:31:41 --> Language Class Initialized
INFO - 2020-02-04 15:31:42 --> Loader Class Initialized
INFO - 2020-02-04 15:31:42 --> Input Class Initialized
ERROR - 2020-02-04 15:31:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-04 15:31:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:31:42 --> Helper loaded: url_helper
INFO - 2020-02-04 15:31:42 --> Loader Class Initialized
INFO - 2020-02-04 15:31:42 --> Config Class Initialized
INFO - 2020-02-04 15:31:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:31:42 --> Helper loaded: url_helper
INFO - 2020-02-04 15:31:42 --> Language Class Initialized
INFO - 2020-02-04 15:31:42 --> Database Driver Class Initialized
INFO - 2020-02-04 15:31:42 --> Config Class Initialized
INFO - 2020-02-04 15:31:42 --> Hooks Class Initialized
ERROR - 2020-02-04 15:31:42 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-04 15:31:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:31:42 --> Database Driver Class Initialized
INFO - 2020-02-04 15:31:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:31:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:31:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:42 --> Controller Class Initialized
INFO - 2020-02-04 15:31:42 --> URI Class Initialized
INFO - 2020-02-04 15:31:42 --> URI Class Initialized
INFO - 2020-02-04 15:31:42 --> Router Class Initialized
INFO - 2020-02-04 15:31:42 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:31:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:31:42 --> Router Class Initialized
INFO - 2020-02-04 15:31:42 --> Output Class Initialized
INFO - 2020-02-04 15:31:42 --> Security Class Initialized
INFO - 2020-02-04 15:31:42 --> Output Class Initialized
INFO - 2020-02-04 15:31:42 --> Helper loaded: form_helper
INFO - 2020-02-04 15:31:42 --> Form Validation Class Initialized
INFO - 2020-02-04 15:31:42 --> Security Class Initialized
DEBUG - 2020-02-04 15:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:42 --> Input Class Initialized
DEBUG - 2020-02-04 15:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 15:31:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:31:42 --> Input Class Initialized
INFO - 2020-02-04 15:31:42 --> Language Class Initialized
ERROR - 2020-02-04 15:31:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:31:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:31:42 --> Language Class Initialized
ERROR - 2020-02-04 15:31:42 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:31:42 --> Final output sent to browser
ERROR - 2020-02-04 15:31:42 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-04 15:31:42 --> Total execution time: 1.0399
INFO - 2020-02-04 15:31:42 --> Config Class Initialized
INFO - 2020-02-04 15:31:42 --> Hooks Class Initialized
INFO - 2020-02-04 15:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:31:42 --> Controller Class Initialized
DEBUG - 2020-02-04 15:31:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:42 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:31:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:31:42 --> URI Class Initialized
INFO - 2020-02-04 15:31:42 --> Router Class Initialized
INFO - 2020-02-04 15:31:42 --> Helper loaded: form_helper
INFO - 2020-02-04 15:31:42 --> Form Validation Class Initialized
INFO - 2020-02-04 15:31:42 --> Output Class Initialized
INFO - 2020-02-04 15:31:42 --> Security Class Initialized
ERROR - 2020-02-04 15:31:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:31:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-04 15:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:42 --> Input Class Initialized
INFO - 2020-02-04 15:31:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:31:42 --> Final output sent to browser
INFO - 2020-02-04 15:31:42 --> Language Class Initialized
DEBUG - 2020-02-04 15:31:43 --> Total execution time: 1.4558
ERROR - 2020-02-04 15:31:43 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:31:43 --> Config Class Initialized
INFO - 2020-02-04 15:31:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:43 --> URI Class Initialized
INFO - 2020-02-04 15:31:43 --> Router Class Initialized
INFO - 2020-02-04 15:31:43 --> Output Class Initialized
INFO - 2020-02-04 15:31:43 --> Security Class Initialized
DEBUG - 2020-02-04 15:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:43 --> Input Class Initialized
INFO - 2020-02-04 15:31:43 --> Language Class Initialized
ERROR - 2020-02-04 15:31:43 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:31:43 --> Config Class Initialized
INFO - 2020-02-04 15:31:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:43 --> URI Class Initialized
INFO - 2020-02-04 15:31:43 --> Router Class Initialized
INFO - 2020-02-04 15:31:43 --> Output Class Initialized
INFO - 2020-02-04 15:31:43 --> Security Class Initialized
DEBUG - 2020-02-04 15:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:43 --> Input Class Initialized
INFO - 2020-02-04 15:31:43 --> Language Class Initialized
ERROR - 2020-02-04 15:31:43 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:31:44 --> Config Class Initialized
INFO - 2020-02-04 15:31:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:44 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:44 --> URI Class Initialized
INFO - 2020-02-04 15:31:44 --> Router Class Initialized
INFO - 2020-02-04 15:31:44 --> Output Class Initialized
INFO - 2020-02-04 15:31:44 --> Security Class Initialized
DEBUG - 2020-02-04 15:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:44 --> Input Class Initialized
INFO - 2020-02-04 15:31:44 --> Language Class Initialized
ERROR - 2020-02-04 15:31:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:31:44 --> Config Class Initialized
INFO - 2020-02-04 15:31:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:44 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:44 --> URI Class Initialized
INFO - 2020-02-04 15:31:44 --> Router Class Initialized
INFO - 2020-02-04 15:31:44 --> Output Class Initialized
INFO - 2020-02-04 15:31:44 --> Security Class Initialized
DEBUG - 2020-02-04 15:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:44 --> Input Class Initialized
INFO - 2020-02-04 15:31:44 --> Language Class Initialized
ERROR - 2020-02-04 15:31:44 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:31:44 --> Config Class Initialized
INFO - 2020-02-04 15:31:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:45 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:45 --> URI Class Initialized
INFO - 2020-02-04 15:31:45 --> Router Class Initialized
INFO - 2020-02-04 15:31:45 --> Output Class Initialized
INFO - 2020-02-04 15:31:45 --> Security Class Initialized
DEBUG - 2020-02-04 15:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:45 --> Input Class Initialized
INFO - 2020-02-04 15:31:45 --> Language Class Initialized
ERROR - 2020-02-04 15:31:45 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:31:45 --> Config Class Initialized
INFO - 2020-02-04 15:31:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:45 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:45 --> URI Class Initialized
INFO - 2020-02-04 15:31:45 --> Router Class Initialized
INFO - 2020-02-04 15:31:45 --> Output Class Initialized
INFO - 2020-02-04 15:31:45 --> Security Class Initialized
DEBUG - 2020-02-04 15:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:45 --> Input Class Initialized
INFO - 2020-02-04 15:31:45 --> Language Class Initialized
ERROR - 2020-02-04 15:31:45 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:31:45 --> Config Class Initialized
INFO - 2020-02-04 15:31:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:46 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:46 --> URI Class Initialized
INFO - 2020-02-04 15:31:46 --> Router Class Initialized
INFO - 2020-02-04 15:31:46 --> Output Class Initialized
INFO - 2020-02-04 15:31:46 --> Security Class Initialized
DEBUG - 2020-02-04 15:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:46 --> Input Class Initialized
INFO - 2020-02-04 15:31:46 --> Language Class Initialized
ERROR - 2020-02-04 15:31:46 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:31:51 --> Config Class Initialized
INFO - 2020-02-04 15:31:51 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:31:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:31:51 --> Utf8 Class Initialized
INFO - 2020-02-04 15:31:51 --> URI Class Initialized
INFO - 2020-02-04 15:31:51 --> Router Class Initialized
INFO - 2020-02-04 15:31:51 --> Output Class Initialized
INFO - 2020-02-04 15:31:52 --> Security Class Initialized
DEBUG - 2020-02-04 15:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:31:52 --> Input Class Initialized
INFO - 2020-02-04 15:31:52 --> Language Class Initialized
INFO - 2020-02-04 15:31:52 --> Loader Class Initialized
INFO - 2020-02-04 15:31:52 --> Helper loaded: url_helper
INFO - 2020-02-04 15:31:52 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:31:52 --> Controller Class Initialized
INFO - 2020-02-04 15:31:52 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:31:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:31:52 --> Helper loaded: form_helper
INFO - 2020-02-04 15:31:52 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:31:52 --> Severity: error --> Exception: Call to undefined method M_pengunjung::getidn() C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 39
INFO - 2020-02-04 15:32:32 --> Config Class Initialized
INFO - 2020-02-04 15:32:32 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:32:32 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:32:32 --> Utf8 Class Initialized
INFO - 2020-02-04 15:32:32 --> URI Class Initialized
INFO - 2020-02-04 15:32:32 --> Router Class Initialized
INFO - 2020-02-04 15:32:32 --> Output Class Initialized
INFO - 2020-02-04 15:32:33 --> Security Class Initialized
DEBUG - 2020-02-04 15:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:32:33 --> Input Class Initialized
INFO - 2020-02-04 15:32:33 --> Language Class Initialized
INFO - 2020-02-04 15:32:33 --> Loader Class Initialized
INFO - 2020-02-04 15:32:33 --> Helper loaded: url_helper
INFO - 2020-02-04 15:32:33 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:32:33 --> Controller Class Initialized
INFO - 2020-02-04 15:32:33 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:32:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:32:33 --> Helper loaded: form_helper
INFO - 2020-02-04 15:32:33 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:32:33 --> Severity: Notice --> Undefined property: Tiket::$add_pengunjung C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-04 15:32:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
INFO - 2020-02-04 15:32:33 --> Final output sent to browser
DEBUG - 2020-02-04 15:32:33 --> Total execution time: 1.0908
INFO - 2020-02-04 15:32:44 --> Config Class Initialized
INFO - 2020-02-04 15:32:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:32:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:32:44 --> Utf8 Class Initialized
INFO - 2020-02-04 15:32:44 --> URI Class Initialized
INFO - 2020-02-04 15:32:44 --> Router Class Initialized
INFO - 2020-02-04 15:32:44 --> Output Class Initialized
INFO - 2020-02-04 15:32:44 --> Security Class Initialized
DEBUG - 2020-02-04 15:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:32:44 --> Input Class Initialized
INFO - 2020-02-04 15:32:44 --> Language Class Initialized
INFO - 2020-02-04 15:32:44 --> Loader Class Initialized
INFO - 2020-02-04 15:32:44 --> Helper loaded: url_helper
INFO - 2020-02-04 15:32:44 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:32:44 --> Controller Class Initialized
INFO - 2020-02-04 15:32:44 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:32:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:32:45 --> Helper loaded: form_helper
INFO - 2020-02-04 15:32:45 --> Form Validation Class Initialized
INFO - 2020-02-04 15:32:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:32:45 --> Final output sent to browser
INFO - 2020-02-04 15:32:45 --> Config Class Initialized
INFO - 2020-02-04 15:32:45 --> Config Class Initialized
INFO - 2020-02-04 15:32:45 --> Hooks Class Initialized
INFO - 2020-02-04 15:32:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:32:45 --> Total execution time: 1.0713
INFO - 2020-02-04 15:32:45 --> Config Class Initialized
INFO - 2020-02-04 15:32:45 --> Config Class Initialized
INFO - 2020-02-04 15:32:45 --> Hooks Class Initialized
INFO - 2020-02-04 15:32:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:32:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:32:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:32:45 --> Utf8 Class Initialized
INFO - 2020-02-04 15:32:45 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:32:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:32:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:32:45 --> Utf8 Class Initialized
INFO - 2020-02-04 15:32:45 --> URI Class Initialized
INFO - 2020-02-04 15:32:45 --> Utf8 Class Initialized
INFO - 2020-02-04 15:32:45 --> URI Class Initialized
INFO - 2020-02-04 15:32:45 --> URI Class Initialized
INFO - 2020-02-04 15:32:45 --> Router Class Initialized
INFO - 2020-02-04 15:32:45 --> URI Class Initialized
INFO - 2020-02-04 15:32:45 --> Router Class Initialized
INFO - 2020-02-04 15:32:45 --> Router Class Initialized
INFO - 2020-02-04 15:32:45 --> Output Class Initialized
INFO - 2020-02-04 15:32:45 --> Router Class Initialized
INFO - 2020-02-04 15:32:45 --> Security Class Initialized
INFO - 2020-02-04 15:32:45 --> Output Class Initialized
INFO - 2020-02-04 15:32:45 --> Output Class Initialized
INFO - 2020-02-04 15:32:45 --> Output Class Initialized
DEBUG - 2020-02-04 15:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:32:45 --> Security Class Initialized
INFO - 2020-02-04 15:32:45 --> Security Class Initialized
INFO - 2020-02-04 15:32:45 --> Security Class Initialized
INFO - 2020-02-04 15:32:45 --> Input Class Initialized
DEBUG - 2020-02-04 15:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:32:45 --> Input Class Initialized
INFO - 2020-02-04 15:32:45 --> Input Class Initialized
INFO - 2020-02-04 15:32:45 --> Input Class Initialized
INFO - 2020-02-04 15:32:45 --> Language Class Initialized
INFO - 2020-02-04 15:32:45 --> Language Class Initialized
INFO - 2020-02-04 15:32:45 --> Language Class Initialized
INFO - 2020-02-04 15:32:45 --> Language Class Initialized
ERROR - 2020-02-04 15:32:45 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 15:32:45 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 15:32:45 --> Loader Class Initialized
INFO - 2020-02-04 15:32:45 --> Loader Class Initialized
INFO - 2020-02-04 15:32:45 --> Helper loaded: url_helper
INFO - 2020-02-04 15:32:45 --> Helper loaded: url_helper
INFO - 2020-02-04 15:32:45 --> Database Driver Class Initialized
INFO - 2020-02-04 15:32:45 --> Database Driver Class Initialized
INFO - 2020-02-04 15:32:45 --> Config Class Initialized
INFO - 2020-02-04 15:32:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 15:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:32:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:32:46 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:32:46 --> Utf8 Class Initialized
INFO - 2020-02-04 15:32:46 --> Controller Class Initialized
INFO - 2020-02-04 15:32:46 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:32:46 --> URI Class Initialized
INFO - 2020-02-04 15:32:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:32:46 --> Router Class Initialized
INFO - 2020-02-04 15:32:46 --> Output Class Initialized
INFO - 2020-02-04 15:32:46 --> Helper loaded: form_helper
INFO - 2020-02-04 15:32:46 --> Form Validation Class Initialized
INFO - 2020-02-04 15:32:46 --> Security Class Initialized
DEBUG - 2020-02-04 15:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 15:32:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:32:46 --> Input Class Initialized
ERROR - 2020-02-04 15:32:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:32:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:32:46 --> Language Class Initialized
INFO - 2020-02-04 15:32:46 --> Final output sent to browser
ERROR - 2020-02-04 15:32:46 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-04 15:32:46 --> Total execution time: 1.0680
INFO - 2020-02-04 15:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:32:46 --> Controller Class Initialized
INFO - 2020-02-04 15:32:46 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:32:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:32:46 --> Helper loaded: form_helper
INFO - 2020-02-04 15:32:46 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:32:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:32:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:32:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:32:46 --> Final output sent to browser
DEBUG - 2020-02-04 15:32:46 --> Total execution time: 1.4699
INFO - 2020-02-04 15:35:26 --> Config Class Initialized
INFO - 2020-02-04 15:35:26 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:35:27 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:35:27 --> Utf8 Class Initialized
INFO - 2020-02-04 15:35:27 --> URI Class Initialized
INFO - 2020-02-04 15:35:27 --> Router Class Initialized
INFO - 2020-02-04 15:35:27 --> Output Class Initialized
INFO - 2020-02-04 15:35:27 --> Security Class Initialized
DEBUG - 2020-02-04 15:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:35:27 --> Input Class Initialized
INFO - 2020-02-04 15:35:27 --> Language Class Initialized
INFO - 2020-02-04 15:35:27 --> Loader Class Initialized
INFO - 2020-02-04 15:35:27 --> Helper loaded: url_helper
INFO - 2020-02-04 15:35:27 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:35:27 --> Controller Class Initialized
INFO - 2020-02-04 15:35:27 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:35:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:35:27 --> Helper loaded: form_helper
INFO - 2020-02-04 15:35:27 --> Form Validation Class Initialized
INFO - 2020-02-04 15:35:28 --> Config Class Initialized
INFO - 2020-02-04 15:35:28 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:35:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:35:28 --> Utf8 Class Initialized
INFO - 2020-02-04 15:35:28 --> URI Class Initialized
INFO - 2020-02-04 15:35:28 --> Router Class Initialized
INFO - 2020-02-04 15:35:28 --> Output Class Initialized
INFO - 2020-02-04 15:35:28 --> Security Class Initialized
DEBUG - 2020-02-04 15:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:35:28 --> Input Class Initialized
INFO - 2020-02-04 15:35:28 --> Language Class Initialized
INFO - 2020-02-04 15:35:28 --> Loader Class Initialized
INFO - 2020-02-04 15:35:28 --> Helper loaded: url_helper
INFO - 2020-02-04 15:35:28 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:35:28 --> Controller Class Initialized
INFO - 2020-02-04 15:35:28 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:35:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:35:28 --> Helper loaded: form_helper
INFO - 2020-02-04 15:35:29 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:35:29 --> Severity: Notice --> Undefined property: Tiket::$idn C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 43
ERROR - 2020-02-04 15:35:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 43
INFO - 2020-02-04 15:35:29 --> Final output sent to browser
DEBUG - 2020-02-04 15:35:29 --> Total execution time: 0.9976
INFO - 2020-02-04 15:35:44 --> Config Class Initialized
INFO - 2020-02-04 15:35:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:35:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:35:45 --> Utf8 Class Initialized
INFO - 2020-02-04 15:35:45 --> URI Class Initialized
INFO - 2020-02-04 15:35:45 --> Router Class Initialized
INFO - 2020-02-04 15:35:45 --> Output Class Initialized
INFO - 2020-02-04 15:35:45 --> Security Class Initialized
DEBUG - 2020-02-04 15:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:35:45 --> Input Class Initialized
INFO - 2020-02-04 15:35:46 --> Language Class Initialized
INFO - 2020-02-04 15:35:46 --> Loader Class Initialized
INFO - 2020-02-04 15:35:46 --> Helper loaded: url_helper
INFO - 2020-02-04 15:35:46 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:35:46 --> Controller Class Initialized
INFO - 2020-02-04 15:35:46 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:35:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:35:46 --> Helper loaded: form_helper
INFO - 2020-02-04 15:35:46 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:35:46 --> Severity: Notice --> Undefined variable: idn C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 43
ERROR - 2020-02-04 15:35:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 43
INFO - 2020-02-04 15:35:46 --> Final output sent to browser
DEBUG - 2020-02-04 15:35:46 --> Total execution time: 1.8445
INFO - 2020-02-04 15:36:01 --> Config Class Initialized
INFO - 2020-02-04 15:36:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:36:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:36:01 --> Utf8 Class Initialized
INFO - 2020-02-04 15:36:01 --> URI Class Initialized
INFO - 2020-02-04 15:36:01 --> Router Class Initialized
INFO - 2020-02-04 15:36:01 --> Output Class Initialized
INFO - 2020-02-04 15:36:01 --> Security Class Initialized
DEBUG - 2020-02-04 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:36:02 --> Input Class Initialized
INFO - 2020-02-04 15:36:02 --> Language Class Initialized
INFO - 2020-02-04 15:36:02 --> Loader Class Initialized
INFO - 2020-02-04 15:36:02 --> Helper loaded: url_helper
INFO - 2020-02-04 15:36:02 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:36:02 --> Controller Class Initialized
INFO - 2020-02-04 15:36:02 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:36:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:36:02 --> Helper loaded: form_helper
INFO - 2020-02-04 15:36:02 --> Form Validation Class Initialized
INFO - 2020-02-04 15:36:02 --> Final output sent to browser
DEBUG - 2020-02-04 15:36:02 --> Total execution time: 1.2018
INFO - 2020-02-04 15:36:47 --> Config Class Initialized
INFO - 2020-02-04 15:36:47 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:36:47 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:36:47 --> Utf8 Class Initialized
INFO - 2020-02-04 15:36:48 --> URI Class Initialized
INFO - 2020-02-04 15:36:48 --> Router Class Initialized
INFO - 2020-02-04 15:36:48 --> Output Class Initialized
INFO - 2020-02-04 15:36:48 --> Security Class Initialized
DEBUG - 2020-02-04 15:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:36:48 --> Input Class Initialized
INFO - 2020-02-04 15:36:48 --> Language Class Initialized
INFO - 2020-02-04 15:36:48 --> Loader Class Initialized
INFO - 2020-02-04 15:36:48 --> Helper loaded: url_helper
INFO - 2020-02-04 15:36:48 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:36:48 --> Controller Class Initialized
INFO - 2020-02-04 15:36:48 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:36:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:36:48 --> Helper loaded: form_helper
INFO - 2020-02-04 15:36:48 --> Form Validation Class Initialized
INFO - 2020-02-04 15:36:48 --> Final output sent to browser
DEBUG - 2020-02-04 15:36:48 --> Total execution time: 0.8401
INFO - 2020-02-04 15:37:06 --> Config Class Initialized
INFO - 2020-02-04 15:37:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:37:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:37:06 --> Utf8 Class Initialized
INFO - 2020-02-04 15:37:06 --> URI Class Initialized
INFO - 2020-02-04 15:37:06 --> Router Class Initialized
INFO - 2020-02-04 15:37:07 --> Output Class Initialized
INFO - 2020-02-04 15:37:07 --> Security Class Initialized
DEBUG - 2020-02-04 15:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:37:07 --> Input Class Initialized
INFO - 2020-02-04 15:37:07 --> Language Class Initialized
INFO - 2020-02-04 15:37:07 --> Loader Class Initialized
INFO - 2020-02-04 15:37:07 --> Helper loaded: url_helper
INFO - 2020-02-04 15:37:07 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:37:07 --> Controller Class Initialized
INFO - 2020-02-04 15:37:07 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:37:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:37:07 --> Helper loaded: form_helper
INFO - 2020-02-04 15:37:07 --> Form Validation Class Initialized
INFO - 2020-02-04 15:37:07 --> Final output sent to browser
DEBUG - 2020-02-04 15:37:07 --> Total execution time: 0.9899
INFO - 2020-02-04 15:44:26 --> Config Class Initialized
INFO - 2020-02-04 15:44:26 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:44:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:44:26 --> Utf8 Class Initialized
INFO - 2020-02-04 15:44:26 --> URI Class Initialized
INFO - 2020-02-04 15:44:27 --> Router Class Initialized
INFO - 2020-02-04 15:44:27 --> Output Class Initialized
INFO - 2020-02-04 15:44:27 --> Security Class Initialized
DEBUG - 2020-02-04 15:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:44:27 --> Input Class Initialized
INFO - 2020-02-04 15:44:27 --> Language Class Initialized
INFO - 2020-02-04 15:44:27 --> Loader Class Initialized
INFO - 2020-02-04 15:44:27 --> Helper loaded: url_helper
INFO - 2020-02-04 15:44:27 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:44:27 --> Controller Class Initialized
INFO - 2020-02-04 15:44:27 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:44:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:44:27 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:44:27 --> Helper loaded: form_helper
INFO - 2020-02-04 15:44:27 --> Form Validation Class Initialized
INFO - 2020-02-04 15:44:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:44:28 --> Final output sent to browser
INFO - 2020-02-04 15:44:28 --> Config Class Initialized
INFO - 2020-02-04 15:44:28 --> Config Class Initialized
INFO - 2020-02-04 15:44:28 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:44:28 --> Total execution time: 1.5704
INFO - 2020-02-04 15:44:28 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:44:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:44:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:44:28 --> Utf8 Class Initialized
INFO - 2020-02-04 15:44:28 --> Utf8 Class Initialized
INFO - 2020-02-04 15:44:28 --> URI Class Initialized
INFO - 2020-02-04 15:44:28 --> URI Class Initialized
INFO - 2020-02-04 15:44:28 --> Router Class Initialized
INFO - 2020-02-04 15:44:28 --> Router Class Initialized
INFO - 2020-02-04 15:44:28 --> Output Class Initialized
INFO - 2020-02-04 15:44:28 --> Output Class Initialized
INFO - 2020-02-04 15:44:28 --> Security Class Initialized
INFO - 2020-02-04 15:44:28 --> Security Class Initialized
DEBUG - 2020-02-04 15:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:44:28 --> Input Class Initialized
INFO - 2020-02-04 15:44:28 --> Input Class Initialized
INFO - 2020-02-04 15:44:28 --> Language Class Initialized
INFO - 2020-02-04 15:44:28 --> Language Class Initialized
INFO - 2020-02-04 15:44:28 --> Loader Class Initialized
INFO - 2020-02-04 15:44:28 --> Loader Class Initialized
INFO - 2020-02-04 15:44:28 --> Helper loaded: url_helper
INFO - 2020-02-04 15:44:28 --> Helper loaded: url_helper
INFO - 2020-02-04 15:44:28 --> Database Driver Class Initialized
INFO - 2020-02-04 15:44:28 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 15:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:44:28 --> Controller Class Initialized
INFO - 2020-02-04 15:44:28 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:44:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:44:28 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:44:29 --> Helper loaded: form_helper
INFO - 2020-02-04 15:44:29 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:44:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:44:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:44:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:44:29 --> Final output sent to browser
DEBUG - 2020-02-04 15:44:29 --> Total execution time: 1.1267
INFO - 2020-02-04 15:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:44:29 --> Controller Class Initialized
INFO - 2020-02-04 15:44:29 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:44:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:44:29 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:44:29 --> Helper loaded: form_helper
INFO - 2020-02-04 15:44:29 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:44:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:44:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:44:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:44:29 --> Final output sent to browser
DEBUG - 2020-02-04 15:44:29 --> Total execution time: 1.6026
INFO - 2020-02-04 15:45:16 --> Config Class Initialized
INFO - 2020-02-04 15:45:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:45:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:16 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:16 --> URI Class Initialized
INFO - 2020-02-04 15:45:16 --> Router Class Initialized
INFO - 2020-02-04 15:45:16 --> Output Class Initialized
INFO - 2020-02-04 15:45:16 --> Security Class Initialized
DEBUG - 2020-02-04 15:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:16 --> Input Class Initialized
INFO - 2020-02-04 15:45:16 --> Language Class Initialized
INFO - 2020-02-04 15:45:17 --> Loader Class Initialized
INFO - 2020-02-04 15:45:17 --> Helper loaded: url_helper
INFO - 2020-02-04 15:45:17 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:45:17 --> Controller Class Initialized
INFO - 2020-02-04 15:45:17 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:45:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:45:17 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:45:17 --> Helper loaded: form_helper
INFO - 2020-02-04 15:45:17 --> Form Validation Class Initialized
INFO - 2020-02-04 15:45:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:45:17 --> Final output sent to browser
INFO - 2020-02-04 15:45:17 --> Config Class Initialized
INFO - 2020-02-04 15:45:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:45:17 --> Total execution time: 0.8818
INFO - 2020-02-04 15:45:17 --> Config Class Initialized
INFO - 2020-02-04 15:45:17 --> Config Class Initialized
INFO - 2020-02-04 15:45:17 --> Config Class Initialized
INFO - 2020-02-04 15:45:17 --> Config Class Initialized
INFO - 2020-02-04 15:45:17 --> Hooks Class Initialized
INFO - 2020-02-04 15:45:17 --> Hooks Class Initialized
INFO - 2020-02-04 15:45:17 --> Hooks Class Initialized
INFO - 2020-02-04 15:45:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:45:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:17 --> Config Class Initialized
INFO - 2020-02-04 15:45:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:45:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:17 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:45:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:45:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:45:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:17 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:17 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:17 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:17 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:17 --> URI Class Initialized
DEBUG - 2020-02-04 15:45:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:17 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:17 --> URI Class Initialized
INFO - 2020-02-04 15:45:17 --> URI Class Initialized
INFO - 2020-02-04 15:45:17 --> Router Class Initialized
INFO - 2020-02-04 15:45:17 --> URI Class Initialized
INFO - 2020-02-04 15:45:17 --> URI Class Initialized
INFO - 2020-02-04 15:45:17 --> URI Class Initialized
INFO - 2020-02-04 15:45:17 --> Router Class Initialized
INFO - 2020-02-04 15:45:17 --> Router Class Initialized
INFO - 2020-02-04 15:45:17 --> Router Class Initialized
INFO - 2020-02-04 15:45:17 --> Router Class Initialized
INFO - 2020-02-04 15:45:17 --> Output Class Initialized
INFO - 2020-02-04 15:45:17 --> Security Class Initialized
INFO - 2020-02-04 15:45:17 --> Router Class Initialized
INFO - 2020-02-04 15:45:17 --> Output Class Initialized
INFO - 2020-02-04 15:45:17 --> Output Class Initialized
INFO - 2020-02-04 15:45:17 --> Output Class Initialized
INFO - 2020-02-04 15:45:17 --> Output Class Initialized
DEBUG - 2020-02-04 15:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:17 --> Security Class Initialized
INFO - 2020-02-04 15:45:17 --> Security Class Initialized
INFO - 2020-02-04 15:45:17 --> Output Class Initialized
INFO - 2020-02-04 15:45:17 --> Security Class Initialized
INFO - 2020-02-04 15:45:17 --> Security Class Initialized
INFO - 2020-02-04 15:45:17 --> Input Class Initialized
DEBUG - 2020-02-04 15:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:17 --> Security Class Initialized
INFO - 2020-02-04 15:45:17 --> Input Class Initialized
INFO - 2020-02-04 15:45:17 --> Language Class Initialized
DEBUG - 2020-02-04 15:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:17 --> Input Class Initialized
INFO - 2020-02-04 15:45:17 --> Input Class Initialized
INFO - 2020-02-04 15:45:17 --> Input Class Initialized
INFO - 2020-02-04 15:45:18 --> Language Class Initialized
INFO - 2020-02-04 15:45:18 --> Language Class Initialized
INFO - 2020-02-04 15:45:18 --> Language Class Initialized
INFO - 2020-02-04 15:45:18 --> Input Class Initialized
ERROR - 2020-02-04 15:45:18 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 15:45:18 --> Language Class Initialized
INFO - 2020-02-04 15:45:18 --> Language Class Initialized
ERROR - 2020-02-04 15:45:18 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 15:45:18 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 15:45:18 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 15:45:18 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:45:18 --> Config Class Initialized
INFO - 2020-02-04 15:45:18 --> Hooks Class Initialized
ERROR - 2020-02-04 15:45:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:45:18 --> Config Class Initialized
INFO - 2020-02-04 15:45:18 --> Config Class Initialized
DEBUG - 2020-02-04 15:45:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:18 --> Config Class Initialized
INFO - 2020-02-04 15:45:18 --> Config Class Initialized
INFO - 2020-02-04 15:45:18 --> Config Class Initialized
INFO - 2020-02-04 15:45:18 --> Hooks Class Initialized
INFO - 2020-02-04 15:45:18 --> Hooks Class Initialized
INFO - 2020-02-04 15:45:18 --> Hooks Class Initialized
INFO - 2020-02-04 15:45:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:18 --> Hooks Class Initialized
INFO - 2020-02-04 15:45:18 --> Hooks Class Initialized
INFO - 2020-02-04 15:45:18 --> URI Class Initialized
DEBUG - 2020-02-04 15:45:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:45:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:45:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:45:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:45:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:18 --> Router Class Initialized
INFO - 2020-02-04 15:45:18 --> URI Class Initialized
INFO - 2020-02-04 15:45:18 --> URI Class Initialized
INFO - 2020-02-04 15:45:18 --> URI Class Initialized
INFO - 2020-02-04 15:45:18 --> URI Class Initialized
INFO - 2020-02-04 15:45:18 --> URI Class Initialized
INFO - 2020-02-04 15:45:18 --> Output Class Initialized
INFO - 2020-02-04 15:45:18 --> Security Class Initialized
INFO - 2020-02-04 15:45:18 --> Router Class Initialized
INFO - 2020-02-04 15:45:18 --> Router Class Initialized
INFO - 2020-02-04 15:45:18 --> Router Class Initialized
INFO - 2020-02-04 15:45:18 --> Router Class Initialized
INFO - 2020-02-04 15:45:18 --> Router Class Initialized
DEBUG - 2020-02-04 15:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:18 --> Output Class Initialized
INFO - 2020-02-04 15:45:18 --> Output Class Initialized
INFO - 2020-02-04 15:45:18 --> Output Class Initialized
INFO - 2020-02-04 15:45:18 --> Output Class Initialized
INFO - 2020-02-04 15:45:18 --> Output Class Initialized
INFO - 2020-02-04 15:45:18 --> Input Class Initialized
INFO - 2020-02-04 15:45:18 --> Security Class Initialized
INFO - 2020-02-04 15:45:18 --> Security Class Initialized
INFO - 2020-02-04 15:45:18 --> Security Class Initialized
INFO - 2020-02-04 15:45:18 --> Security Class Initialized
INFO - 2020-02-04 15:45:18 --> Security Class Initialized
DEBUG - 2020-02-04 15:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:18 --> Language Class Initialized
DEBUG - 2020-02-04 15:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:18 --> Input Class Initialized
INFO - 2020-02-04 15:45:18 --> Input Class Initialized
INFO - 2020-02-04 15:45:18 --> Input Class Initialized
INFO - 2020-02-04 15:45:18 --> Input Class Initialized
INFO - 2020-02-04 15:45:18 --> Input Class Initialized
ERROR - 2020-02-04 15:45:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:45:18 --> Language Class Initialized
INFO - 2020-02-04 15:45:18 --> Language Class Initialized
INFO - 2020-02-04 15:45:18 --> Language Class Initialized
INFO - 2020-02-04 15:45:18 --> Language Class Initialized
INFO - 2020-02-04 15:45:18 --> Language Class Initialized
INFO - 2020-02-04 15:45:18 --> Config Class Initialized
INFO - 2020-02-04 15:45:18 --> Hooks Class Initialized
ERROR - 2020-02-04 15:45:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-04 15:45:18 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:45:18 --> Loader Class Initialized
INFO - 2020-02-04 15:45:18 --> Loader Class Initialized
ERROR - 2020-02-04 15:45:18 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:45:18 --> Helper loaded: url_helper
INFO - 2020-02-04 15:45:18 --> Helper loaded: url_helper
DEBUG - 2020-02-04 15:45:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:18 --> Config Class Initialized
INFO - 2020-02-04 15:45:18 --> Hooks Class Initialized
INFO - 2020-02-04 15:45:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:18 --> Database Driver Class Initialized
INFO - 2020-02-04 15:45:18 --> Database Driver Class Initialized
INFO - 2020-02-04 15:45:18 --> URI Class Initialized
DEBUG - 2020-02-04 15:45:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 15:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:45:18 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:45:18 --> Router Class Initialized
INFO - 2020-02-04 15:45:18 --> Controller Class Initialized
INFO - 2020-02-04 15:45:18 --> URI Class Initialized
INFO - 2020-02-04 15:45:18 --> Output Class Initialized
INFO - 2020-02-04 15:45:18 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:45:18 --> Security Class Initialized
INFO - 2020-02-04 15:45:18 --> Router Class Initialized
INFO - 2020-02-04 15:45:18 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-04 15:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:18 --> Output Class Initialized
INFO - 2020-02-04 15:45:18 --> Input Class Initialized
INFO - 2020-02-04 15:45:18 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:45:18 --> Security Class Initialized
INFO - 2020-02-04 15:45:19 --> Language Class Initialized
DEBUG - 2020-02-04 15:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:19 --> Helper loaded: form_helper
INFO - 2020-02-04 15:45:19 --> Form Validation Class Initialized
INFO - 2020-02-04 15:45:19 --> Input Class Initialized
ERROR - 2020-02-04 15:45:19 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:45:19 --> Language Class Initialized
ERROR - 2020-02-04 15:45:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:45:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-04 15:45:19 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:45:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:45:19 --> Config Class Initialized
INFO - 2020-02-04 15:45:19 --> Hooks Class Initialized
INFO - 2020-02-04 15:45:19 --> Final output sent to browser
DEBUG - 2020-02-04 15:45:19 --> Total execution time: 1.1116
DEBUG - 2020-02-04 15:45:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:19 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:45:19 --> Controller Class Initialized
INFO - 2020-02-04 15:45:19 --> URI Class Initialized
INFO - 2020-02-04 15:45:19 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:45:19 --> Router Class Initialized
INFO - 2020-02-04 15:45:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:45:19 --> Output Class Initialized
INFO - 2020-02-04 15:45:19 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:45:19 --> Security Class Initialized
DEBUG - 2020-02-04 15:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:19 --> Helper loaded: form_helper
INFO - 2020-02-04 15:45:19 --> Form Validation Class Initialized
INFO - 2020-02-04 15:45:19 --> Input Class Initialized
INFO - 2020-02-04 15:45:19 --> Language Class Initialized
ERROR - 2020-02-04 15:45:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:45:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-04 15:45:19 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:45:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:45:19 --> Config Class Initialized
INFO - 2020-02-04 15:45:19 --> Hooks Class Initialized
INFO - 2020-02-04 15:45:19 --> Final output sent to browser
DEBUG - 2020-02-04 15:45:19 --> Total execution time: 1.5802
DEBUG - 2020-02-04 15:45:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:19 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:19 --> URI Class Initialized
INFO - 2020-02-04 15:45:19 --> Router Class Initialized
INFO - 2020-02-04 15:45:19 --> Output Class Initialized
INFO - 2020-02-04 15:45:19 --> Security Class Initialized
DEBUG - 2020-02-04 15:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:20 --> Input Class Initialized
INFO - 2020-02-04 15:45:20 --> Language Class Initialized
ERROR - 2020-02-04 15:45:20 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:45:20 --> Config Class Initialized
INFO - 2020-02-04 15:45:20 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:45:20 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:20 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:20 --> URI Class Initialized
INFO - 2020-02-04 15:45:20 --> Router Class Initialized
INFO - 2020-02-04 15:45:20 --> Output Class Initialized
INFO - 2020-02-04 15:45:20 --> Security Class Initialized
DEBUG - 2020-02-04 15:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:20 --> Input Class Initialized
INFO - 2020-02-04 15:45:20 --> Language Class Initialized
ERROR - 2020-02-04 15:45:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:45:20 --> Config Class Initialized
INFO - 2020-02-04 15:45:20 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:45:20 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:20 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:20 --> URI Class Initialized
INFO - 2020-02-04 15:45:20 --> Router Class Initialized
INFO - 2020-02-04 15:45:20 --> Output Class Initialized
INFO - 2020-02-04 15:45:20 --> Security Class Initialized
DEBUG - 2020-02-04 15:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:21 --> Input Class Initialized
INFO - 2020-02-04 15:45:21 --> Language Class Initialized
ERROR - 2020-02-04 15:45:21 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:45:21 --> Config Class Initialized
INFO - 2020-02-04 15:45:21 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:45:21 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:21 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:21 --> URI Class Initialized
INFO - 2020-02-04 15:45:21 --> Router Class Initialized
INFO - 2020-02-04 15:45:21 --> Output Class Initialized
INFO - 2020-02-04 15:45:21 --> Security Class Initialized
DEBUG - 2020-02-04 15:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:21 --> Input Class Initialized
INFO - 2020-02-04 15:45:21 --> Language Class Initialized
ERROR - 2020-02-04 15:45:21 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:45:21 --> Config Class Initialized
INFO - 2020-02-04 15:45:21 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:45:21 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:21 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:21 --> URI Class Initialized
INFO - 2020-02-04 15:45:21 --> Router Class Initialized
INFO - 2020-02-04 15:45:21 --> Output Class Initialized
INFO - 2020-02-04 15:45:21 --> Security Class Initialized
DEBUG - 2020-02-04 15:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:22 --> Input Class Initialized
INFO - 2020-02-04 15:45:22 --> Language Class Initialized
ERROR - 2020-02-04 15:45:22 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:45:22 --> Config Class Initialized
INFO - 2020-02-04 15:45:22 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:45:22 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:22 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:22 --> URI Class Initialized
INFO - 2020-02-04 15:45:22 --> Router Class Initialized
INFO - 2020-02-04 15:45:22 --> Output Class Initialized
INFO - 2020-02-04 15:45:22 --> Security Class Initialized
DEBUG - 2020-02-04 15:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:22 --> Input Class Initialized
INFO - 2020-02-04 15:45:22 --> Language Class Initialized
ERROR - 2020-02-04 15:45:22 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:45:22 --> Config Class Initialized
INFO - 2020-02-04 15:45:22 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:45:22 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:22 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:22 --> URI Class Initialized
INFO - 2020-02-04 15:45:22 --> Router Class Initialized
INFO - 2020-02-04 15:45:22 --> Output Class Initialized
INFO - 2020-02-04 15:45:22 --> Security Class Initialized
DEBUG - 2020-02-04 15:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:23 --> Input Class Initialized
INFO - 2020-02-04 15:45:23 --> Language Class Initialized
ERROR - 2020-02-04 15:45:23 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:45:32 --> Config Class Initialized
INFO - 2020-02-04 15:45:32 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:45:32 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:45:32 --> Utf8 Class Initialized
INFO - 2020-02-04 15:45:32 --> URI Class Initialized
INFO - 2020-02-04 15:45:33 --> Router Class Initialized
INFO - 2020-02-04 15:45:33 --> Output Class Initialized
INFO - 2020-02-04 15:45:33 --> Security Class Initialized
DEBUG - 2020-02-04 15:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:45:33 --> Input Class Initialized
INFO - 2020-02-04 15:45:33 --> Language Class Initialized
INFO - 2020-02-04 15:45:33 --> Loader Class Initialized
INFO - 2020-02-04 15:45:33 --> Helper loaded: url_helper
INFO - 2020-02-04 15:45:33 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:45:33 --> Controller Class Initialized
INFO - 2020-02-04 15:45:33 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:45:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:45:33 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:45:33 --> Helper loaded: form_helper
INFO - 2020-02-04 15:45:33 --> Form Validation Class Initialized
INFO - 2020-02-04 15:45:33 --> Final output sent to browser
DEBUG - 2020-02-04 15:45:33 --> Total execution time: 1.3275
INFO - 2020-02-04 15:46:22 --> Config Class Initialized
INFO - 2020-02-04 15:46:22 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:46:22 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:22 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:23 --> URI Class Initialized
INFO - 2020-02-04 15:46:23 --> Router Class Initialized
INFO - 2020-02-04 15:46:23 --> Output Class Initialized
INFO - 2020-02-04 15:46:23 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:23 --> Input Class Initialized
INFO - 2020-02-04 15:46:23 --> Language Class Initialized
ERROR - 2020-02-04 15:46:23 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 52
INFO - 2020-02-04 15:46:39 --> Config Class Initialized
INFO - 2020-02-04 15:46:39 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:46:39 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:39 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:39 --> URI Class Initialized
INFO - 2020-02-04 15:46:39 --> Router Class Initialized
INFO - 2020-02-04 15:46:39 --> Output Class Initialized
INFO - 2020-02-04 15:46:39 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:39 --> Input Class Initialized
INFO - 2020-02-04 15:46:39 --> Language Class Initialized
INFO - 2020-02-04 15:46:39 --> Loader Class Initialized
INFO - 2020-02-04 15:46:40 --> Helper loaded: url_helper
INFO - 2020-02-04 15:46:40 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:46:40 --> Controller Class Initialized
INFO - 2020-02-04 15:46:40 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:46:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:46:40 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:46:40 --> Helper loaded: form_helper
INFO - 2020-02-04 15:46:40 --> Form Validation Class Initialized
INFO - 2020-02-04 15:46:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:46:40 --> Final output sent to browser
INFO - 2020-02-04 15:46:40 --> Config Class Initialized
INFO - 2020-02-04 15:46:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:46:40 --> Total execution time: 0.9470
INFO - 2020-02-04 15:46:40 --> Config Class Initialized
INFO - 2020-02-04 15:46:40 --> Config Class Initialized
INFO - 2020-02-04 15:46:40 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:46:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:40 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:46:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:46:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:40 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:40 --> URI Class Initialized
INFO - 2020-02-04 15:46:40 --> URI Class Initialized
INFO - 2020-02-04 15:46:40 --> URI Class Initialized
INFO - 2020-02-04 15:46:40 --> Router Class Initialized
INFO - 2020-02-04 15:46:40 --> Router Class Initialized
INFO - 2020-02-04 15:46:40 --> Router Class Initialized
INFO - 2020-02-04 15:46:40 --> Output Class Initialized
INFO - 2020-02-04 15:46:40 --> Security Class Initialized
INFO - 2020-02-04 15:46:40 --> Output Class Initialized
INFO - 2020-02-04 15:46:40 --> Output Class Initialized
INFO - 2020-02-04 15:46:40 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:40 --> Security Class Initialized
INFO - 2020-02-04 15:46:40 --> Input Class Initialized
DEBUG - 2020-02-04 15:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:40 --> Input Class Initialized
INFO - 2020-02-04 15:46:40 --> Input Class Initialized
INFO - 2020-02-04 15:46:40 --> Language Class Initialized
INFO - 2020-02-04 15:46:40 --> Language Class Initialized
INFO - 2020-02-04 15:46:40 --> Language Class Initialized
ERROR - 2020-02-04 15:46:40 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:46:41 --> Loader Class Initialized
INFO - 2020-02-04 15:46:41 --> Loader Class Initialized
INFO - 2020-02-04 15:46:41 --> Helper loaded: url_helper
INFO - 2020-02-04 15:46:41 --> Helper loaded: url_helper
INFO - 2020-02-04 15:46:41 --> Database Driver Class Initialized
INFO - 2020-02-04 15:46:41 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 15:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:46:41 --> Controller Class Initialized
INFO - 2020-02-04 15:46:41 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:46:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:46:41 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:46:41 --> Helper loaded: form_helper
INFO - 2020-02-04 15:46:41 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:46:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:46:41 --> Final output sent to browser
DEBUG - 2020-02-04 15:46:41 --> Total execution time: 1.0878
INFO - 2020-02-04 15:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:46:41 --> Controller Class Initialized
INFO - 2020-02-04 15:46:41 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:46:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:46:41 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:46:41 --> Helper loaded: form_helper
INFO - 2020-02-04 15:46:41 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:46:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:46:42 --> Final output sent to browser
INFO - 2020-02-04 15:46:42 --> Config Class Initialized
DEBUG - 2020-02-04 15:46:42 --> Total execution time: 1.5316
INFO - 2020-02-04 15:46:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:46:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:42 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:42 --> URI Class Initialized
INFO - 2020-02-04 15:46:42 --> Router Class Initialized
INFO - 2020-02-04 15:46:42 --> Output Class Initialized
INFO - 2020-02-04 15:46:42 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:42 --> Input Class Initialized
INFO - 2020-02-04 15:46:42 --> Language Class Initialized
INFO - 2020-02-04 15:46:42 --> Loader Class Initialized
INFO - 2020-02-04 15:46:42 --> Helper loaded: url_helper
INFO - 2020-02-04 15:46:42 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:46:42 --> Controller Class Initialized
INFO - 2020-02-04 15:46:42 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:46:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:46:42 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:46:42 --> Helper loaded: form_helper
INFO - 2020-02-04 15:46:42 --> Form Validation Class Initialized
INFO - 2020-02-04 15:46:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:46:42 --> Final output sent to browser
INFO - 2020-02-04 15:46:43 --> Config Class Initialized
INFO - 2020-02-04 15:46:43 --> Config Class Initialized
INFO - 2020-02-04 15:46:43 --> Config Class Initialized
INFO - 2020-02-04 15:46:43 --> Config Class Initialized
INFO - 2020-02-04 15:46:43 --> Config Class Initialized
INFO - 2020-02-04 15:46:43 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:43 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:43 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:43 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:46:43 --> Total execution time: 0.8907
DEBUG - 2020-02-04 15:46:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:46:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:46:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:43 --> Config Class Initialized
DEBUG - 2020-02-04 15:46:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:46:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:43 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:43 --> URI Class Initialized
INFO - 2020-02-04 15:46:43 --> URI Class Initialized
INFO - 2020-02-04 15:46:43 --> URI Class Initialized
INFO - 2020-02-04 15:46:43 --> URI Class Initialized
INFO - 2020-02-04 15:46:43 --> URI Class Initialized
DEBUG - 2020-02-04 15:46:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:43 --> Router Class Initialized
INFO - 2020-02-04 15:46:43 --> Router Class Initialized
INFO - 2020-02-04 15:46:43 --> Router Class Initialized
INFO - 2020-02-04 15:46:43 --> Router Class Initialized
INFO - 2020-02-04 15:46:43 --> Router Class Initialized
INFO - 2020-02-04 15:46:43 --> Output Class Initialized
INFO - 2020-02-04 15:46:43 --> Output Class Initialized
INFO - 2020-02-04 15:46:43 --> Output Class Initialized
INFO - 2020-02-04 15:46:43 --> URI Class Initialized
INFO - 2020-02-04 15:46:43 --> Output Class Initialized
INFO - 2020-02-04 15:46:43 --> Output Class Initialized
INFO - 2020-02-04 15:46:43 --> Router Class Initialized
INFO - 2020-02-04 15:46:43 --> Security Class Initialized
INFO - 2020-02-04 15:46:43 --> Security Class Initialized
INFO - 2020-02-04 15:46:43 --> Security Class Initialized
INFO - 2020-02-04 15:46:43 --> Security Class Initialized
INFO - 2020-02-04 15:46:43 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:43 --> Output Class Initialized
DEBUG - 2020-02-04 15:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:43 --> Input Class Initialized
INFO - 2020-02-04 15:46:43 --> Input Class Initialized
INFO - 2020-02-04 15:46:43 --> Input Class Initialized
INFO - 2020-02-04 15:46:43 --> Input Class Initialized
INFO - 2020-02-04 15:46:43 --> Input Class Initialized
INFO - 2020-02-04 15:46:43 --> Security Class Initialized
INFO - 2020-02-04 15:46:43 --> Language Class Initialized
INFO - 2020-02-04 15:46:43 --> Language Class Initialized
INFO - 2020-02-04 15:46:43 --> Language Class Initialized
INFO - 2020-02-04 15:46:43 --> Language Class Initialized
INFO - 2020-02-04 15:46:43 --> Language Class Initialized
DEBUG - 2020-02-04 15:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:43 --> Input Class Initialized
ERROR - 2020-02-04 15:46:43 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 15:46:43 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 15:46:43 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 15:46:43 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 15:46:43 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:46:43 --> Language Class Initialized
INFO - 2020-02-04 15:46:43 --> Config Class Initialized
INFO - 2020-02-04 15:46:43 --> Config Class Initialized
INFO - 2020-02-04 15:46:43 --> Config Class Initialized
INFO - 2020-02-04 15:46:43 --> Config Class Initialized
INFO - 2020-02-04 15:46:43 --> Config Class Initialized
INFO - 2020-02-04 15:46:43 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:43 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:43 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:43 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:43 --> Hooks Class Initialized
ERROR - 2020-02-04 15:46:43 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-04 15:46:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:46:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:46:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:46:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:46:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:43 --> Config Class Initialized
INFO - 2020-02-04 15:46:43 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:43 --> URI Class Initialized
INFO - 2020-02-04 15:46:43 --> URI Class Initialized
INFO - 2020-02-04 15:46:43 --> URI Class Initialized
INFO - 2020-02-04 15:46:43 --> URI Class Initialized
INFO - 2020-02-04 15:46:43 --> URI Class Initialized
DEBUG - 2020-02-04 15:46:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:43 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:43 --> Router Class Initialized
INFO - 2020-02-04 15:46:43 --> Router Class Initialized
INFO - 2020-02-04 15:46:43 --> Router Class Initialized
INFO - 2020-02-04 15:46:43 --> Router Class Initialized
INFO - 2020-02-04 15:46:43 --> Router Class Initialized
INFO - 2020-02-04 15:46:43 --> Output Class Initialized
INFO - 2020-02-04 15:46:43 --> Output Class Initialized
INFO - 2020-02-04 15:46:43 --> Output Class Initialized
INFO - 2020-02-04 15:46:43 --> Output Class Initialized
INFO - 2020-02-04 15:46:43 --> URI Class Initialized
INFO - 2020-02-04 15:46:43 --> Output Class Initialized
INFO - 2020-02-04 15:46:43 --> Security Class Initialized
INFO - 2020-02-04 15:46:43 --> Security Class Initialized
INFO - 2020-02-04 15:46:43 --> Security Class Initialized
INFO - 2020-02-04 15:46:43 --> Security Class Initialized
INFO - 2020-02-04 15:46:43 --> Security Class Initialized
INFO - 2020-02-04 15:46:43 --> Router Class Initialized
DEBUG - 2020-02-04 15:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:43 --> Output Class Initialized
DEBUG - 2020-02-04 15:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:43 --> Input Class Initialized
INFO - 2020-02-04 15:46:43 --> Input Class Initialized
INFO - 2020-02-04 15:46:43 --> Input Class Initialized
INFO - 2020-02-04 15:46:43 --> Input Class Initialized
INFO - 2020-02-04 15:46:43 --> Input Class Initialized
INFO - 2020-02-04 15:46:43 --> Security Class Initialized
INFO - 2020-02-04 15:46:43 --> Language Class Initialized
INFO - 2020-02-04 15:46:43 --> Language Class Initialized
DEBUG - 2020-02-04 15:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:43 --> Language Class Initialized
INFO - 2020-02-04 15:46:43 --> Language Class Initialized
INFO - 2020-02-04 15:46:43 --> Language Class Initialized
INFO - 2020-02-04 15:46:44 --> Input Class Initialized
ERROR - 2020-02-04 15:46:44 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 15:46:44 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-04 15:46:44 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:46:44 --> Loader Class Initialized
INFO - 2020-02-04 15:46:44 --> Loader Class Initialized
INFO - 2020-02-04 15:46:44 --> Language Class Initialized
INFO - 2020-02-04 15:46:44 --> Helper loaded: url_helper
INFO - 2020-02-04 15:46:44 --> Helper loaded: url_helper
INFO - 2020-02-04 15:46:44 --> Config Class Initialized
INFO - 2020-02-04 15:46:44 --> Config Class Initialized
INFO - 2020-02-04 15:46:44 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:44 --> Hooks Class Initialized
ERROR - 2020-02-04 15:46:44 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:46:44 --> Database Driver Class Initialized
INFO - 2020-02-04 15:46:44 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:46:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:46:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 15:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:46:44 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:44 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:46:44 --> Controller Class Initialized
INFO - 2020-02-04 15:46:44 --> URI Class Initialized
INFO - 2020-02-04 15:46:44 --> URI Class Initialized
INFO - 2020-02-04 15:46:44 --> Router Class Initialized
INFO - 2020-02-04 15:46:44 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:46:44 --> Router Class Initialized
INFO - 2020-02-04 15:46:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:46:44 --> Output Class Initialized
INFO - 2020-02-04 15:46:44 --> Output Class Initialized
INFO - 2020-02-04 15:46:44 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:46:44 --> Security Class Initialized
INFO - 2020-02-04 15:46:44 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:44 --> Helper loaded: form_helper
INFO - 2020-02-04 15:46:44 --> Input Class Initialized
INFO - 2020-02-04 15:46:44 --> Form Validation Class Initialized
INFO - 2020-02-04 15:46:44 --> Input Class Initialized
INFO - 2020-02-04 15:46:44 --> Language Class Initialized
INFO - 2020-02-04 15:46:44 --> Language Class Initialized
ERROR - 2020-02-04 15:46:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:46:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-04 15:46:44 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 15:46:44 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:46:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:46:44 --> Config Class Initialized
INFO - 2020-02-04 15:46:44 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:44 --> Final output sent to browser
DEBUG - 2020-02-04 15:46:44 --> Total execution time: 1.0812
DEBUG - 2020-02-04 15:46:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:44 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:46:44 --> Controller Class Initialized
INFO - 2020-02-04 15:46:44 --> URI Class Initialized
INFO - 2020-02-04 15:46:44 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:46:44 --> Router Class Initialized
INFO - 2020-02-04 15:46:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:46:44 --> Output Class Initialized
INFO - 2020-02-04 15:46:44 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:46:44 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:44 --> Helper loaded: form_helper
INFO - 2020-02-04 15:46:44 --> Form Validation Class Initialized
INFO - 2020-02-04 15:46:44 --> Input Class Initialized
INFO - 2020-02-04 15:46:44 --> Language Class Initialized
ERROR - 2020-02-04 15:46:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:46:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-04 15:46:45 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:46:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:46:45 --> Config Class Initialized
INFO - 2020-02-04 15:46:45 --> Hooks Class Initialized
INFO - 2020-02-04 15:46:45 --> Final output sent to browser
DEBUG - 2020-02-04 15:46:45 --> Total execution time: 1.5647
DEBUG - 2020-02-04 15:46:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:45 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:45 --> URI Class Initialized
INFO - 2020-02-04 15:46:45 --> Router Class Initialized
INFO - 2020-02-04 15:46:45 --> Output Class Initialized
INFO - 2020-02-04 15:46:45 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:45 --> Input Class Initialized
INFO - 2020-02-04 15:46:45 --> Language Class Initialized
ERROR - 2020-02-04 15:46:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:46:45 --> Config Class Initialized
INFO - 2020-02-04 15:46:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:46:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:45 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:45 --> URI Class Initialized
INFO - 2020-02-04 15:46:45 --> Router Class Initialized
INFO - 2020-02-04 15:46:45 --> Output Class Initialized
INFO - 2020-02-04 15:46:45 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:45 --> Input Class Initialized
INFO - 2020-02-04 15:46:45 --> Language Class Initialized
ERROR - 2020-02-04 15:46:46 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:46:46 --> Config Class Initialized
INFO - 2020-02-04 15:46:46 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:46:46 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:46 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:46 --> URI Class Initialized
INFO - 2020-02-04 15:46:46 --> Router Class Initialized
INFO - 2020-02-04 15:46:46 --> Output Class Initialized
INFO - 2020-02-04 15:46:46 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:46 --> Input Class Initialized
INFO - 2020-02-04 15:46:46 --> Language Class Initialized
ERROR - 2020-02-04 15:46:46 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:46:46 --> Config Class Initialized
INFO - 2020-02-04 15:46:46 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:46:46 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:46 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:46 --> URI Class Initialized
INFO - 2020-02-04 15:46:46 --> Router Class Initialized
INFO - 2020-02-04 15:46:46 --> Output Class Initialized
INFO - 2020-02-04 15:46:46 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:46 --> Input Class Initialized
INFO - 2020-02-04 15:46:46 --> Language Class Initialized
ERROR - 2020-02-04 15:46:46 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:46:47 --> Config Class Initialized
INFO - 2020-02-04 15:46:47 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:46:47 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:47 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:47 --> URI Class Initialized
INFO - 2020-02-04 15:46:47 --> Router Class Initialized
INFO - 2020-02-04 15:46:47 --> Output Class Initialized
INFO - 2020-02-04 15:46:47 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:47 --> Input Class Initialized
INFO - 2020-02-04 15:46:47 --> Language Class Initialized
ERROR - 2020-02-04 15:46:47 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:46:47 --> Config Class Initialized
INFO - 2020-02-04 15:46:47 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:46:47 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:47 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:47 --> URI Class Initialized
INFO - 2020-02-04 15:46:47 --> Router Class Initialized
INFO - 2020-02-04 15:46:47 --> Output Class Initialized
INFO - 2020-02-04 15:46:47 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:47 --> Input Class Initialized
INFO - 2020-02-04 15:46:47 --> Language Class Initialized
ERROR - 2020-02-04 15:46:47 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:46:56 --> Config Class Initialized
INFO - 2020-02-04 15:46:57 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:46:57 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:46:57 --> Utf8 Class Initialized
INFO - 2020-02-04 15:46:57 --> URI Class Initialized
INFO - 2020-02-04 15:46:57 --> Router Class Initialized
INFO - 2020-02-04 15:46:57 --> Output Class Initialized
INFO - 2020-02-04 15:46:57 --> Security Class Initialized
DEBUG - 2020-02-04 15:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:46:57 --> Input Class Initialized
INFO - 2020-02-04 15:46:57 --> Language Class Initialized
INFO - 2020-02-04 15:46:57 --> Loader Class Initialized
INFO - 2020-02-04 15:46:58 --> Helper loaded: url_helper
INFO - 2020-02-04 15:46:58 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:46:58 --> Controller Class Initialized
INFO - 2020-02-04 15:46:58 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:46:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:46:58 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:46:58 --> Helper loaded: form_helper
INFO - 2020-02-04 15:46:58 --> Form Validation Class Initialized
INFO - 2020-02-04 15:46:58 --> Final output sent to browser
DEBUG - 2020-02-04 15:46:58 --> Total execution time: 1.7179
INFO - 2020-02-04 15:47:20 --> Config Class Initialized
INFO - 2020-02-04 15:47:20 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:47:21 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:47:21 --> Utf8 Class Initialized
INFO - 2020-02-04 15:47:21 --> URI Class Initialized
INFO - 2020-02-04 15:47:21 --> Router Class Initialized
INFO - 2020-02-04 15:47:21 --> Output Class Initialized
INFO - 2020-02-04 15:47:21 --> Security Class Initialized
DEBUG - 2020-02-04 15:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:47:21 --> Input Class Initialized
INFO - 2020-02-04 15:47:21 --> Language Class Initialized
INFO - 2020-02-04 15:47:21 --> Loader Class Initialized
INFO - 2020-02-04 15:47:21 --> Helper loaded: url_helper
INFO - 2020-02-04 15:47:21 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:47:21 --> Controller Class Initialized
INFO - 2020-02-04 15:47:22 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:47:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:47:22 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:47:22 --> Helper loaded: form_helper
INFO - 2020-02-04 15:47:22 --> Form Validation Class Initialized
INFO - 2020-02-04 15:47:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:47:22 --> Final output sent to browser
INFO - 2020-02-04 15:47:22 --> Config Class Initialized
INFO - 2020-02-04 15:47:22 --> Config Class Initialized
DEBUG - 2020-02-04 15:47:22 --> Total execution time: 1.5276
INFO - 2020-02-04 15:47:22 --> Hooks Class Initialized
INFO - 2020-02-04 15:47:22 --> Hooks Class Initialized
INFO - 2020-02-04 15:47:22 --> Config Class Initialized
INFO - 2020-02-04 15:47:22 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:47:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:47:22 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:47:22 --> Utf8 Class Initialized
INFO - 2020-02-04 15:47:22 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:47:22 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:47:22 --> Utf8 Class Initialized
INFO - 2020-02-04 15:47:22 --> URI Class Initialized
INFO - 2020-02-04 15:47:22 --> URI Class Initialized
INFO - 2020-02-04 15:47:22 --> URI Class Initialized
INFO - 2020-02-04 15:47:22 --> Router Class Initialized
INFO - 2020-02-04 15:47:22 --> Router Class Initialized
INFO - 2020-02-04 15:47:22 --> Router Class Initialized
INFO - 2020-02-04 15:47:22 --> Output Class Initialized
INFO - 2020-02-04 15:47:22 --> Output Class Initialized
INFO - 2020-02-04 15:47:22 --> Security Class Initialized
INFO - 2020-02-04 15:47:22 --> Security Class Initialized
INFO - 2020-02-04 15:47:22 --> Output Class Initialized
DEBUG - 2020-02-04 15:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:47:22 --> Security Class Initialized
INFO - 2020-02-04 15:47:22 --> Input Class Initialized
INFO - 2020-02-04 15:47:22 --> Input Class Initialized
DEBUG - 2020-02-04 15:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:47:22 --> Input Class Initialized
INFO - 2020-02-04 15:47:22 --> Language Class Initialized
INFO - 2020-02-04 15:47:22 --> Language Class Initialized
INFO - 2020-02-04 15:47:22 --> Language Class Initialized
ERROR - 2020-02-04 15:47:22 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:47:22 --> Loader Class Initialized
INFO - 2020-02-04 15:47:22 --> Helper loaded: url_helper
INFO - 2020-02-04 15:47:22 --> Loader Class Initialized
INFO - 2020-02-04 15:47:22 --> Helper loaded: url_helper
INFO - 2020-02-04 15:47:22 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:47:22 --> Database Driver Class Initialized
INFO - 2020-02-04 15:47:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:47:23 --> Controller Class Initialized
INFO - 2020-02-04 15:47:23 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:47:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:47:23 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:47:23 --> Helper loaded: form_helper
INFO - 2020-02-04 15:47:23 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:47:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:47:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:47:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:47:23 --> Final output sent to browser
DEBUG - 2020-02-04 15:47:23 --> Total execution time: 1.0383
INFO - 2020-02-04 15:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:47:23 --> Controller Class Initialized
INFO - 2020-02-04 15:47:23 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:47:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:47:23 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:47:23 --> Helper loaded: form_helper
INFO - 2020-02-04 15:47:23 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:47:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:47:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:47:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:47:23 --> Final output sent to browser
DEBUG - 2020-02-04 15:47:23 --> Total execution time: 1.4776
INFO - 2020-02-04 15:47:56 --> Config Class Initialized
INFO - 2020-02-04 15:47:56 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:47:56 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:47:56 --> Utf8 Class Initialized
INFO - 2020-02-04 15:47:56 --> URI Class Initialized
INFO - 2020-02-04 15:47:56 --> Router Class Initialized
INFO - 2020-02-04 15:47:56 --> Output Class Initialized
INFO - 2020-02-04 15:47:56 --> Security Class Initialized
DEBUG - 2020-02-04 15:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:47:56 --> Input Class Initialized
INFO - 2020-02-04 15:47:56 --> Language Class Initialized
INFO - 2020-02-04 15:47:57 --> Loader Class Initialized
INFO - 2020-02-04 15:47:57 --> Helper loaded: url_helper
INFO - 2020-02-04 15:47:57 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:47:57 --> Controller Class Initialized
INFO - 2020-02-04 15:47:57 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:47:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:47:57 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:47:57 --> Helper loaded: form_helper
INFO - 2020-02-04 15:47:57 --> Form Validation Class Initialized
INFO - 2020-02-04 15:47:57 --> Final output sent to browser
DEBUG - 2020-02-04 15:47:57 --> Total execution time: 1.2722
INFO - 2020-02-04 15:48:28 --> Config Class Initialized
INFO - 2020-02-04 15:48:28 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:48:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:48:28 --> Utf8 Class Initialized
INFO - 2020-02-04 15:48:28 --> URI Class Initialized
INFO - 2020-02-04 15:48:28 --> Router Class Initialized
INFO - 2020-02-04 15:48:28 --> Output Class Initialized
INFO - 2020-02-04 15:48:28 --> Security Class Initialized
DEBUG - 2020-02-04 15:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:48:28 --> Input Class Initialized
INFO - 2020-02-04 15:48:28 --> Language Class Initialized
INFO - 2020-02-04 15:48:28 --> Loader Class Initialized
INFO - 2020-02-04 15:48:28 --> Helper loaded: url_helper
INFO - 2020-02-04 15:48:28 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:48:28 --> Controller Class Initialized
INFO - 2020-02-04 15:48:28 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:48:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:48:28 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:48:28 --> Helper loaded: form_helper
INFO - 2020-02-04 15:48:28 --> Form Validation Class Initialized
INFO - 2020-02-04 15:48:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:48:29 --> Final output sent to browser
INFO - 2020-02-04 15:48:29 --> Config Class Initialized
INFO - 2020-02-04 15:48:29 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:48:29 --> Total execution time: 1.0762
INFO - 2020-02-04 15:48:29 --> Config Class Initialized
INFO - 2020-02-04 15:48:29 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:48:29 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:48:29 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:48:29 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:48:29 --> Utf8 Class Initialized
INFO - 2020-02-04 15:48:29 --> URI Class Initialized
INFO - 2020-02-04 15:48:29 --> URI Class Initialized
INFO - 2020-02-04 15:48:29 --> Router Class Initialized
INFO - 2020-02-04 15:48:29 --> Output Class Initialized
INFO - 2020-02-04 15:48:29 --> Router Class Initialized
INFO - 2020-02-04 15:48:29 --> Security Class Initialized
INFO - 2020-02-04 15:48:29 --> Output Class Initialized
DEBUG - 2020-02-04 15:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:48:29 --> Security Class Initialized
INFO - 2020-02-04 15:48:29 --> Input Class Initialized
DEBUG - 2020-02-04 15:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:48:29 --> Input Class Initialized
INFO - 2020-02-04 15:48:29 --> Language Class Initialized
INFO - 2020-02-04 15:48:29 --> Language Class Initialized
INFO - 2020-02-04 15:48:29 --> Loader Class Initialized
INFO - 2020-02-04 15:48:29 --> Helper loaded: url_helper
INFO - 2020-02-04 15:48:29 --> Loader Class Initialized
INFO - 2020-02-04 15:48:29 --> Helper loaded: url_helper
INFO - 2020-02-04 15:48:29 --> Database Driver Class Initialized
INFO - 2020-02-04 15:48:29 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:48:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:48:30 --> Controller Class Initialized
INFO - 2020-02-04 15:48:30 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:48:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:48:30 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:48:30 --> Helper loaded: form_helper
INFO - 2020-02-04 15:48:30 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:48:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:48:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:48:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:48:30 --> Final output sent to browser
DEBUG - 2020-02-04 15:48:30 --> Total execution time: 1.2639
INFO - 2020-02-04 15:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:48:30 --> Controller Class Initialized
INFO - 2020-02-04 15:48:30 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:48:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:48:30 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:48:30 --> Helper loaded: form_helper
INFO - 2020-02-04 15:48:30 --> Form Validation Class Initialized
ERROR - 2020-02-04 15:48:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:48:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:48:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:48:30 --> Final output sent to browser
DEBUG - 2020-02-04 15:48:30 --> Total execution time: 1.7306
INFO - 2020-02-04 15:52:01 --> Config Class Initialized
INFO - 2020-02-04 15:52:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:02 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:02 --> URI Class Initialized
INFO - 2020-02-04 15:52:02 --> Router Class Initialized
INFO - 2020-02-04 15:52:02 --> Output Class Initialized
INFO - 2020-02-04 15:52:02 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:02 --> Input Class Initialized
INFO - 2020-02-04 15:52:02 --> Language Class Initialized
INFO - 2020-02-04 15:52:02 --> Loader Class Initialized
INFO - 2020-02-04 15:52:03 --> Helper loaded: url_helper
INFO - 2020-02-04 15:52:03 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:52:03 --> Controller Class Initialized
INFO - 2020-02-04 15:52:03 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:52:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:52:03 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:52:03 --> Helper loaded: form_helper
INFO - 2020-02-04 15:52:03 --> Form Validation Class Initialized
INFO - 2020-02-04 15:52:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:52:03 --> Final output sent to browser
INFO - 2020-02-04 15:52:03 --> Config Class Initialized
INFO - 2020-02-04 15:52:03 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:03 --> Config Class Initialized
INFO - 2020-02-04 15:52:03 --> Config Class Initialized
DEBUG - 2020-02-04 15:52:03 --> Total execution time: 1.6639
INFO - 2020-02-04 15:52:03 --> Config Class Initialized
INFO - 2020-02-04 15:52:03 --> Config Class Initialized
INFO - 2020-02-04 15:52:03 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:03 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:03 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:03 --> Config Class Initialized
INFO - 2020-02-04 15:52:03 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:03 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:52:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:03 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:03 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:03 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:03 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:03 --> URI Class Initialized
DEBUG - 2020-02-04 15:52:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:03 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:03 --> URI Class Initialized
INFO - 2020-02-04 15:52:03 --> URI Class Initialized
INFO - 2020-02-04 15:52:03 --> URI Class Initialized
INFO - 2020-02-04 15:52:03 --> URI Class Initialized
INFO - 2020-02-04 15:52:03 --> Router Class Initialized
INFO - 2020-02-04 15:52:03 --> Router Class Initialized
INFO - 2020-02-04 15:52:03 --> Router Class Initialized
INFO - 2020-02-04 15:52:03 --> Output Class Initialized
INFO - 2020-02-04 15:52:03 --> Router Class Initialized
INFO - 2020-02-04 15:52:03 --> URI Class Initialized
INFO - 2020-02-04 15:52:03 --> Router Class Initialized
INFO - 2020-02-04 15:52:03 --> Output Class Initialized
INFO - 2020-02-04 15:52:03 --> Output Class Initialized
INFO - 2020-02-04 15:52:03 --> Output Class Initialized
INFO - 2020-02-04 15:52:03 --> Security Class Initialized
INFO - 2020-02-04 15:52:03 --> Router Class Initialized
INFO - 2020-02-04 15:52:03 --> Output Class Initialized
INFO - 2020-02-04 15:52:03 --> Security Class Initialized
INFO - 2020-02-04 15:52:03 --> Security Class Initialized
INFO - 2020-02-04 15:52:03 --> Security Class Initialized
INFO - 2020-02-04 15:52:03 --> Output Class Initialized
INFO - 2020-02-04 15:52:03 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:03 --> Input Class Initialized
DEBUG - 2020-02-04 15:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:03 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:03 --> Input Class Initialized
INFO - 2020-02-04 15:52:03 --> Input Class Initialized
INFO - 2020-02-04 15:52:03 --> Input Class Initialized
INFO - 2020-02-04 15:52:03 --> Input Class Initialized
DEBUG - 2020-02-04 15:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:03 --> Language Class Initialized
INFO - 2020-02-04 15:52:04 --> Input Class Initialized
INFO - 2020-02-04 15:52:04 --> Language Class Initialized
INFO - 2020-02-04 15:52:04 --> Language Class Initialized
INFO - 2020-02-04 15:52:04 --> Language Class Initialized
INFO - 2020-02-04 15:52:04 --> Language Class Initialized
INFO - 2020-02-04 15:52:04 --> Loader Class Initialized
ERROR - 2020-02-04 15:52:04 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 15:52:04 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 15:52:04 --> Helper loaded: url_helper
INFO - 2020-02-04 15:52:04 --> Language Class Initialized
ERROR - 2020-02-04 15:52:04 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 15:52:04 --> Loader Class Initialized
ERROR - 2020-02-04 15:52:04 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:52:04 --> Helper loaded: url_helper
INFO - 2020-02-04 15:52:04 --> Database Driver Class Initialized
INFO - 2020-02-04 15:52:04 --> Config Class Initialized
INFO - 2020-02-04 15:52:04 --> Config Class Initialized
INFO - 2020-02-04 15:52:04 --> Config Class Initialized
INFO - 2020-02-04 15:52:04 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:04 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:52:04 --> Database Driver Class Initialized
INFO - 2020-02-04 15:52:04 --> Config Class Initialized
INFO - 2020-02-04 15:52:04 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:52:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:52:04 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:04 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:04 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:04 --> Controller Class Initialized
DEBUG - 2020-02-04 15:52:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:04 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:04 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:52:04 --> URI Class Initialized
INFO - 2020-02-04 15:52:04 --> URI Class Initialized
INFO - 2020-02-04 15:52:04 --> URI Class Initialized
INFO - 2020-02-04 15:52:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:52:04 --> Router Class Initialized
INFO - 2020-02-04 15:52:04 --> Router Class Initialized
INFO - 2020-02-04 15:52:04 --> Router Class Initialized
INFO - 2020-02-04 15:52:04 --> URI Class Initialized
INFO - 2020-02-04 15:52:04 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:52:04 --> Router Class Initialized
INFO - 2020-02-04 15:52:04 --> Output Class Initialized
INFO - 2020-02-04 15:52:04 --> Output Class Initialized
INFO - 2020-02-04 15:52:04 --> Output Class Initialized
INFO - 2020-02-04 15:52:04 --> Security Class Initialized
INFO - 2020-02-04 15:52:04 --> Security Class Initialized
INFO - 2020-02-04 15:52:04 --> Security Class Initialized
INFO - 2020-02-04 15:52:04 --> Output Class Initialized
INFO - 2020-02-04 15:52:04 --> Helper loaded: form_helper
INFO - 2020-02-04 15:52:04 --> Form Validation Class Initialized
DEBUG - 2020-02-04 15:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:04 --> Security Class Initialized
INFO - 2020-02-04 15:52:04 --> Input Class Initialized
INFO - 2020-02-04 15:52:04 --> Input Class Initialized
INFO - 2020-02-04 15:52:04 --> Input Class Initialized
DEBUG - 2020-02-04 15:52:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 15:52:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:52:04 --> Input Class Initialized
ERROR - 2020-02-04 15:52:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:52:04 --> Language Class Initialized
INFO - 2020-02-04 15:52:04 --> Language Class Initialized
INFO - 2020-02-04 15:52:04 --> Language Class Initialized
INFO - 2020-02-04 15:52:04 --> Language Class Initialized
INFO - 2020-02-04 15:52:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-04 15:52:04 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 15:52:04 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 15:52:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:52:04 --> Final output sent to browser
ERROR - 2020-02-04 15:52:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:52:04 --> Config Class Initialized
INFO - 2020-02-04 15:52:04 --> Config Class Initialized
INFO - 2020-02-04 15:52:04 --> Config Class Initialized
INFO - 2020-02-04 15:52:04 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:04 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:04 --> Total execution time: 1.0560
INFO - 2020-02-04 15:52:04 --> Config Class Initialized
INFO - 2020-02-04 15:52:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:04 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:04 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:52:04 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:52:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:04 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:04 --> Controller Class Initialized
INFO - 2020-02-04 15:52:04 --> URI Class Initialized
INFO - 2020-02-04 15:52:04 --> URI Class Initialized
INFO - 2020-02-04 15:52:04 --> URI Class Initialized
INFO - 2020-02-04 15:52:04 --> Router Class Initialized
INFO - 2020-02-04 15:52:04 --> Router Class Initialized
INFO - 2020-02-04 15:52:04 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:52:04 --> Router Class Initialized
INFO - 2020-02-04 15:52:04 --> URI Class Initialized
INFO - 2020-02-04 15:52:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:52:04 --> Router Class Initialized
INFO - 2020-02-04 15:52:04 --> Output Class Initialized
INFO - 2020-02-04 15:52:04 --> Output Class Initialized
INFO - 2020-02-04 15:52:04 --> Output Class Initialized
INFO - 2020-02-04 15:52:04 --> Security Class Initialized
INFO - 2020-02-04 15:52:04 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:52:04 --> Output Class Initialized
INFO - 2020-02-04 15:52:04 --> Security Class Initialized
INFO - 2020-02-04 15:52:04 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:05 --> Security Class Initialized
INFO - 2020-02-04 15:52:05 --> Helper loaded: form_helper
INFO - 2020-02-04 15:52:05 --> Form Validation Class Initialized
INFO - 2020-02-04 15:52:05 --> Input Class Initialized
INFO - 2020-02-04 15:52:05 --> Input Class Initialized
INFO - 2020-02-04 15:52:05 --> Input Class Initialized
DEBUG - 2020-02-04 15:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:05 --> Input Class Initialized
INFO - 2020-02-04 15:52:05 --> Language Class Initialized
INFO - 2020-02-04 15:52:05 --> Language Class Initialized
INFO - 2020-02-04 15:52:05 --> Language Class Initialized
ERROR - 2020-02-04 15:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:52:05 --> Language Class Initialized
ERROR - 2020-02-04 15:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-04 15:52:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 15:52:05 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 15:52:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:52:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-04 15:52:05 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 15:52:05 --> Final output sent to browser
INFO - 2020-02-04 15:52:05 --> Config Class Initialized
INFO - 2020-02-04 15:52:05 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:05 --> Total execution time: 1.5931
DEBUG - 2020-02-04 15:52:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:05 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:05 --> URI Class Initialized
INFO - 2020-02-04 15:52:05 --> Router Class Initialized
INFO - 2020-02-04 15:52:05 --> Output Class Initialized
INFO - 2020-02-04 15:52:05 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:05 --> Input Class Initialized
INFO - 2020-02-04 15:52:05 --> Language Class Initialized
ERROR - 2020-02-04 15:52:05 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:52:05 --> Config Class Initialized
INFO - 2020-02-04 15:52:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:06 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:06 --> URI Class Initialized
INFO - 2020-02-04 15:52:06 --> Router Class Initialized
INFO - 2020-02-04 15:52:06 --> Output Class Initialized
INFO - 2020-02-04 15:52:06 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:06 --> Input Class Initialized
INFO - 2020-02-04 15:52:06 --> Language Class Initialized
ERROR - 2020-02-04 15:52:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:52:06 --> Config Class Initialized
INFO - 2020-02-04 15:52:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:06 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:06 --> URI Class Initialized
INFO - 2020-02-04 15:52:06 --> Router Class Initialized
INFO - 2020-02-04 15:52:06 --> Output Class Initialized
INFO - 2020-02-04 15:52:06 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:06 --> Input Class Initialized
INFO - 2020-02-04 15:52:06 --> Language Class Initialized
ERROR - 2020-02-04 15:52:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:52:06 --> Config Class Initialized
INFO - 2020-02-04 15:52:07 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:07 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:07 --> URI Class Initialized
INFO - 2020-02-04 15:52:07 --> Router Class Initialized
INFO - 2020-02-04 15:52:07 --> Output Class Initialized
INFO - 2020-02-04 15:52:07 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:07 --> Input Class Initialized
INFO - 2020-02-04 15:52:07 --> Language Class Initialized
ERROR - 2020-02-04 15:52:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:52:07 --> Config Class Initialized
INFO - 2020-02-04 15:52:07 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:07 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:07 --> URI Class Initialized
INFO - 2020-02-04 15:52:07 --> Router Class Initialized
INFO - 2020-02-04 15:52:07 --> Output Class Initialized
INFO - 2020-02-04 15:52:07 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:07 --> Input Class Initialized
INFO - 2020-02-04 15:52:07 --> Language Class Initialized
ERROR - 2020-02-04 15:52:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:52:07 --> Config Class Initialized
INFO - 2020-02-04 15:52:08 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:08 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:08 --> URI Class Initialized
INFO - 2020-02-04 15:52:08 --> Router Class Initialized
INFO - 2020-02-04 15:52:08 --> Output Class Initialized
INFO - 2020-02-04 15:52:08 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:08 --> Input Class Initialized
INFO - 2020-02-04 15:52:08 --> Language Class Initialized
ERROR - 2020-02-04 15:52:08 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:52:08 --> Config Class Initialized
INFO - 2020-02-04 15:52:08 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:08 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:08 --> URI Class Initialized
INFO - 2020-02-04 15:52:08 --> Router Class Initialized
INFO - 2020-02-04 15:52:08 --> Output Class Initialized
INFO - 2020-02-04 15:52:08 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:08 --> Input Class Initialized
INFO - 2020-02-04 15:52:08 --> Language Class Initialized
ERROR - 2020-02-04 15:52:08 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:52:08 --> Config Class Initialized
INFO - 2020-02-04 15:52:09 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:09 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:09 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:09 --> URI Class Initialized
INFO - 2020-02-04 15:52:09 --> Router Class Initialized
INFO - 2020-02-04 15:52:09 --> Output Class Initialized
INFO - 2020-02-04 15:52:09 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:09 --> Input Class Initialized
INFO - 2020-02-04 15:52:09 --> Language Class Initialized
ERROR - 2020-02-04 15:52:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:52:09 --> Config Class Initialized
INFO - 2020-02-04 15:52:09 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:09 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:09 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:09 --> URI Class Initialized
INFO - 2020-02-04 15:52:09 --> Router Class Initialized
INFO - 2020-02-04 15:52:09 --> Output Class Initialized
INFO - 2020-02-04 15:52:09 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:09 --> Input Class Initialized
INFO - 2020-02-04 15:52:09 --> Language Class Initialized
ERROR - 2020-02-04 15:52:09 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:52:47 --> Config Class Initialized
INFO - 2020-02-04 15:52:47 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:47 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:47 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:47 --> URI Class Initialized
INFO - 2020-02-04 15:52:47 --> Router Class Initialized
INFO - 2020-02-04 15:52:47 --> Output Class Initialized
INFO - 2020-02-04 15:52:47 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:47 --> Input Class Initialized
INFO - 2020-02-04 15:52:47 --> Language Class Initialized
INFO - 2020-02-04 15:52:47 --> Loader Class Initialized
INFO - 2020-02-04 15:52:47 --> Helper loaded: url_helper
INFO - 2020-02-04 15:52:48 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:52:48 --> Controller Class Initialized
INFO - 2020-02-04 15:52:48 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:52:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:52:48 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:52:48 --> Helper loaded: form_helper
INFO - 2020-02-04 15:52:48 --> Form Validation Class Initialized
INFO - 2020-02-04 15:52:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:52:48 --> Final output sent to browser
INFO - 2020-02-04 15:52:48 --> Config Class Initialized
DEBUG - 2020-02-04 15:52:48 --> Total execution time: 1.4194
INFO - 2020-02-04 15:52:48 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:48 --> Config Class Initialized
INFO - 2020-02-04 15:52:48 --> Config Class Initialized
INFO - 2020-02-04 15:52:48 --> Config Class Initialized
INFO - 2020-02-04 15:52:48 --> Config Class Initialized
INFO - 2020-02-04 15:52:48 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:48 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:48 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:48 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:48 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:48 --> Config Class Initialized
INFO - 2020-02-04 15:52:48 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:48 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:48 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:52:48 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:48 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:48 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:48 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:48 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:48 --> URI Class Initialized
DEBUG - 2020-02-04 15:52:48 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:48 --> URI Class Initialized
INFO - 2020-02-04 15:52:48 --> Router Class Initialized
INFO - 2020-02-04 15:52:48 --> URI Class Initialized
INFO - 2020-02-04 15:52:48 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:48 --> URI Class Initialized
INFO - 2020-02-04 15:52:48 --> URI Class Initialized
INFO - 2020-02-04 15:52:48 --> URI Class Initialized
INFO - 2020-02-04 15:52:48 --> Router Class Initialized
INFO - 2020-02-04 15:52:48 --> Router Class Initialized
INFO - 2020-02-04 15:52:48 --> Router Class Initialized
INFO - 2020-02-04 15:52:48 --> Router Class Initialized
INFO - 2020-02-04 15:52:48 --> Output Class Initialized
INFO - 2020-02-04 15:52:48 --> Security Class Initialized
INFO - 2020-02-04 15:52:48 --> Output Class Initialized
INFO - 2020-02-04 15:52:48 --> Router Class Initialized
INFO - 2020-02-04 15:52:48 --> Output Class Initialized
INFO - 2020-02-04 15:52:48 --> Output Class Initialized
INFO - 2020-02-04 15:52:48 --> Output Class Initialized
INFO - 2020-02-04 15:52:48 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:48 --> Security Class Initialized
INFO - 2020-02-04 15:52:48 --> Security Class Initialized
INFO - 2020-02-04 15:52:48 --> Output Class Initialized
INFO - 2020-02-04 15:52:48 --> Security Class Initialized
INFO - 2020-02-04 15:52:48 --> Input Class Initialized
DEBUG - 2020-02-04 15:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:48 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:48 --> Input Class Initialized
INFO - 2020-02-04 15:52:48 --> Input Class Initialized
INFO - 2020-02-04 15:52:48 --> Input Class Initialized
INFO - 2020-02-04 15:52:48 --> Input Class Initialized
DEBUG - 2020-02-04 15:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:48 --> Language Class Initialized
INFO - 2020-02-04 15:52:48 --> Input Class Initialized
INFO - 2020-02-04 15:52:48 --> Language Class Initialized
INFO - 2020-02-04 15:52:48 --> Language Class Initialized
INFO - 2020-02-04 15:52:48 --> Language Class Initialized
INFO - 2020-02-04 15:52:48 --> Language Class Initialized
ERROR - 2020-02-04 15:52:48 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 15:52:49 --> Language Class Initialized
ERROR - 2020-02-04 15:52:49 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 15:52:49 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 15:52:49 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-04 15:52:49 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:52:49 --> Config Class Initialized
INFO - 2020-02-04 15:52:49 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:49 --> Loader Class Initialized
INFO - 2020-02-04 15:52:49 --> Config Class Initialized
INFO - 2020-02-04 15:52:49 --> Config Class Initialized
INFO - 2020-02-04 15:52:49 --> Config Class Initialized
INFO - 2020-02-04 15:52:49 --> Config Class Initialized
INFO - 2020-02-04 15:52:49 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:49 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:49 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:49 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:49 --> Helper loaded: url_helper
DEBUG - 2020-02-04 15:52:49 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:49 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:52:49 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:49 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:49 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:49 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:52:49 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:49 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:49 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:49 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:49 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:49 --> URI Class Initialized
DEBUG - 2020-02-04 15:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:52:49 --> URI Class Initialized
INFO - 2020-02-04 15:52:49 --> URI Class Initialized
INFO - 2020-02-04 15:52:49 --> Router Class Initialized
INFO - 2020-02-04 15:52:49 --> URI Class Initialized
INFO - 2020-02-04 15:52:49 --> URI Class Initialized
INFO - 2020-02-04 15:52:49 --> Controller Class Initialized
INFO - 2020-02-04 15:52:49 --> Router Class Initialized
INFO - 2020-02-04 15:52:49 --> Router Class Initialized
INFO - 2020-02-04 15:52:49 --> Output Class Initialized
INFO - 2020-02-04 15:52:49 --> Router Class Initialized
INFO - 2020-02-04 15:52:49 --> Router Class Initialized
INFO - 2020-02-04 15:52:49 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:52:49 --> Output Class Initialized
INFO - 2020-02-04 15:52:49 --> Output Class Initialized
INFO - 2020-02-04 15:52:49 --> Security Class Initialized
INFO - 2020-02-04 15:52:49 --> Output Class Initialized
INFO - 2020-02-04 15:52:49 --> Output Class Initialized
INFO - 2020-02-04 15:52:49 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:49 --> Security Class Initialized
INFO - 2020-02-04 15:52:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:52:49 --> Security Class Initialized
INFO - 2020-02-04 15:52:49 --> Security Class Initialized
INFO - 2020-02-04 15:52:49 --> Input Class Initialized
INFO - 2020-02-04 15:52:49 --> Model "M_pesan" initialized
DEBUG - 2020-02-04 15:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:49 --> Input Class Initialized
INFO - 2020-02-04 15:52:49 --> Input Class Initialized
INFO - 2020-02-04 15:52:49 --> Input Class Initialized
INFO - 2020-02-04 15:52:49 --> Input Class Initialized
INFO - 2020-02-04 15:52:49 --> Language Class Initialized
INFO - 2020-02-04 15:52:49 --> Helper loaded: form_helper
INFO - 2020-02-04 15:52:49 --> Form Validation Class Initialized
INFO - 2020-02-04 15:52:49 --> Language Class Initialized
INFO - 2020-02-04 15:52:49 --> Language Class Initialized
INFO - 2020-02-04 15:52:49 --> Language Class Initialized
INFO - 2020-02-04 15:52:49 --> Language Class Initialized
ERROR - 2020-02-04 15:52:49 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 15:52:49 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 15:52:49 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-04 15:52:49 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 15:52:49 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-04 15:52:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:52:49 --> Config Class Initialized
INFO - 2020-02-04 15:52:49 --> Hooks Class Initialized
ERROR - 2020-02-04 15:52:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:52:49 --> Config Class Initialized
INFO - 2020-02-04 15:52:49 --> Config Class Initialized
INFO - 2020-02-04 15:52:49 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:49 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-04 15:52:49 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:49 --> Final output sent to browser
INFO - 2020-02-04 15:52:49 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:52:49 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:49 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:49 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:49 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:52:49 --> Total execution time: 1.1934
INFO - 2020-02-04 15:52:49 --> URI Class Initialized
INFO - 2020-02-04 15:52:49 --> URI Class Initialized
INFO - 2020-02-04 15:52:49 --> URI Class Initialized
INFO - 2020-02-04 15:52:49 --> Router Class Initialized
INFO - 2020-02-04 15:52:49 --> Router Class Initialized
INFO - 2020-02-04 15:52:49 --> Output Class Initialized
INFO - 2020-02-04 15:52:49 --> Router Class Initialized
INFO - 2020-02-04 15:52:50 --> Output Class Initialized
INFO - 2020-02-04 15:52:50 --> Security Class Initialized
INFO - 2020-02-04 15:52:50 --> Output Class Initialized
DEBUG - 2020-02-04 15:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:50 --> Security Class Initialized
INFO - 2020-02-04 15:52:50 --> Security Class Initialized
INFO - 2020-02-04 15:52:50 --> Input Class Initialized
DEBUG - 2020-02-04 15:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:50 --> Input Class Initialized
INFO - 2020-02-04 15:52:50 --> Input Class Initialized
INFO - 2020-02-04 15:52:50 --> Language Class Initialized
INFO - 2020-02-04 15:52:50 --> Language Class Initialized
INFO - 2020-02-04 15:52:50 --> Language Class Initialized
ERROR - 2020-02-04 15:52:50 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 15:52:50 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:52:50 --> Loader Class Initialized
INFO - 2020-02-04 15:52:50 --> Helper loaded: url_helper
INFO - 2020-02-04 15:52:50 --> Config Class Initialized
INFO - 2020-02-04 15:52:50 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:50 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:52:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:52:50 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:52:50 --> Controller Class Initialized
INFO - 2020-02-04 15:52:50 --> URI Class Initialized
INFO - 2020-02-04 15:52:50 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:52:50 --> Router Class Initialized
INFO - 2020-02-04 15:52:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:52:50 --> Output Class Initialized
INFO - 2020-02-04 15:52:50 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:52:50 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:50 --> Helper loaded: form_helper
INFO - 2020-02-04 15:52:50 --> Form Validation Class Initialized
INFO - 2020-02-04 15:52:50 --> Input Class Initialized
INFO - 2020-02-04 15:52:50 --> Language Class Initialized
ERROR - 2020-02-04 15:52:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 15:52:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-04 15:52:50 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:52:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:52:50 --> Config Class Initialized
INFO - 2020-02-04 15:52:50 --> Hooks Class Initialized
INFO - 2020-02-04 15:52:50 --> Final output sent to browser
DEBUG - 2020-02-04 15:52:50 --> Total execution time: 1.0872
DEBUG - 2020-02-04 15:52:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:50 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:50 --> URI Class Initialized
INFO - 2020-02-04 15:52:50 --> Router Class Initialized
INFO - 2020-02-04 15:52:51 --> Output Class Initialized
INFO - 2020-02-04 15:52:51 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:51 --> Input Class Initialized
INFO - 2020-02-04 15:52:51 --> Language Class Initialized
ERROR - 2020-02-04 15:52:51 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:52:51 --> Config Class Initialized
INFO - 2020-02-04 15:52:51 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:51 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:51 --> URI Class Initialized
INFO - 2020-02-04 15:52:51 --> Router Class Initialized
INFO - 2020-02-04 15:52:51 --> Output Class Initialized
INFO - 2020-02-04 15:52:51 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:51 --> Input Class Initialized
INFO - 2020-02-04 15:52:51 --> Language Class Initialized
ERROR - 2020-02-04 15:52:51 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:52:51 --> Config Class Initialized
INFO - 2020-02-04 15:52:51 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:51 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:51 --> URI Class Initialized
INFO - 2020-02-04 15:52:51 --> Router Class Initialized
INFO - 2020-02-04 15:52:52 --> Output Class Initialized
INFO - 2020-02-04 15:52:52 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:52 --> Input Class Initialized
INFO - 2020-02-04 15:52:52 --> Language Class Initialized
ERROR - 2020-02-04 15:52:52 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:52:52 --> Config Class Initialized
INFO - 2020-02-04 15:52:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:52 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:52 --> URI Class Initialized
INFO - 2020-02-04 15:52:52 --> Router Class Initialized
INFO - 2020-02-04 15:52:52 --> Output Class Initialized
INFO - 2020-02-04 15:52:52 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:52 --> Input Class Initialized
INFO - 2020-02-04 15:52:52 --> Language Class Initialized
ERROR - 2020-02-04 15:52:52 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:52:52 --> Config Class Initialized
INFO - 2020-02-04 15:52:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:52 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:52 --> URI Class Initialized
INFO - 2020-02-04 15:52:53 --> Router Class Initialized
INFO - 2020-02-04 15:52:53 --> Output Class Initialized
INFO - 2020-02-04 15:52:53 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:53 --> Input Class Initialized
INFO - 2020-02-04 15:52:53 --> Language Class Initialized
ERROR - 2020-02-04 15:52:53 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:52:53 --> Config Class Initialized
INFO - 2020-02-04 15:52:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:52:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:52:53 --> Utf8 Class Initialized
INFO - 2020-02-04 15:52:53 --> URI Class Initialized
INFO - 2020-02-04 15:52:53 --> Router Class Initialized
INFO - 2020-02-04 15:52:53 --> Output Class Initialized
INFO - 2020-02-04 15:52:53 --> Security Class Initialized
DEBUG - 2020-02-04 15:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:52:53 --> Input Class Initialized
INFO - 2020-02-04 15:52:53 --> Language Class Initialized
ERROR - 2020-02-04 15:52:53 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:53:01 --> Config Class Initialized
INFO - 2020-02-04 15:53:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:02 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:02 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:02 --> URI Class Initialized
INFO - 2020-02-04 15:53:02 --> Router Class Initialized
INFO - 2020-02-04 15:53:02 --> Output Class Initialized
INFO - 2020-02-04 15:53:02 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:02 --> Input Class Initialized
INFO - 2020-02-04 15:53:02 --> Language Class Initialized
INFO - 2020-02-04 15:53:02 --> Loader Class Initialized
INFO - 2020-02-04 15:53:02 --> Helper loaded: url_helper
INFO - 2020-02-04 15:53:02 --> Database Driver Class Initialized
DEBUG - 2020-02-04 15:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 15:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 15:53:02 --> Controller Class Initialized
INFO - 2020-02-04 15:53:02 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:53:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:53:03 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:53:03 --> Helper loaded: form_helper
INFO - 2020-02-04 15:53:03 --> Form Validation Class Initialized
INFO - 2020-02-04 15:53:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 15:53:03 --> Final output sent to browser
INFO - 2020-02-04 15:53:03 --> Config Class Initialized
INFO - 2020-02-04 15:53:03 --> Config Class Initialized
INFO - 2020-02-04 15:53:03 --> Config Class Initialized
INFO - 2020-02-04 15:53:03 --> Config Class Initialized
INFO - 2020-02-04 15:53:03 --> Hooks Class Initialized
INFO - 2020-02-04 15:53:03 --> Hooks Class Initialized
INFO - 2020-02-04 15:53:03 --> Hooks Class Initialized
INFO - 2020-02-04 15:53:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:03 --> Total execution time: 1.4311
INFO - 2020-02-04 15:53:03 --> Config Class Initialized
INFO - 2020-02-04 15:53:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:53:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:53:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:53:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:03 --> Config Class Initialized
INFO - 2020-02-04 15:53:03 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:03 --> Hooks Class Initialized
INFO - 2020-02-04 15:53:03 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:03 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:03 --> Utf8 Class Initialized
DEBUG - 2020-02-04 15:53:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:03 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:03 --> URI Class Initialized
INFO - 2020-02-04 15:53:03 --> URI Class Initialized
DEBUG - 2020-02-04 15:53:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:03 --> URI Class Initialized
INFO - 2020-02-04 15:53:03 --> URI Class Initialized
INFO - 2020-02-04 15:53:03 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:03 --> Router Class Initialized
INFO - 2020-02-04 15:53:03 --> URI Class Initialized
INFO - 2020-02-04 15:53:03 --> Router Class Initialized
INFO - 2020-02-04 15:53:03 --> Router Class Initialized
INFO - 2020-02-04 15:53:03 --> Router Class Initialized
INFO - 2020-02-04 15:53:03 --> Output Class Initialized
INFO - 2020-02-04 15:53:03 --> Output Class Initialized
INFO - 2020-02-04 15:53:03 --> Output Class Initialized
INFO - 2020-02-04 15:53:03 --> Router Class Initialized
INFO - 2020-02-04 15:53:03 --> URI Class Initialized
INFO - 2020-02-04 15:53:03 --> Output Class Initialized
INFO - 2020-02-04 15:53:03 --> Security Class Initialized
INFO - 2020-02-04 15:53:03 --> Router Class Initialized
INFO - 2020-02-04 15:53:03 --> Output Class Initialized
INFO - 2020-02-04 15:53:03 --> Security Class Initialized
INFO - 2020-02-04 15:53:03 --> Security Class Initialized
INFO - 2020-02-04 15:53:03 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:03 --> Output Class Initialized
INFO - 2020-02-04 15:53:03 --> Security Class Initialized
INFO - 2020-02-04 15:53:03 --> Input Class Initialized
DEBUG - 2020-02-04 15:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:03 --> Security Class Initialized
INFO - 2020-02-04 15:53:03 --> Input Class Initialized
INFO - 2020-02-04 15:53:03 --> Input Class Initialized
INFO - 2020-02-04 15:53:03 --> Input Class Initialized
INFO - 2020-02-04 15:53:03 --> Input Class Initialized
INFO - 2020-02-04 15:53:03 --> Language Class Initialized
INFO - 2020-02-04 15:53:03 --> Language Class Initialized
INFO - 2020-02-04 15:53:03 --> Language Class Initialized
INFO - 2020-02-04 15:53:03 --> Language Class Initialized
DEBUG - 2020-02-04 15:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:03 --> Input Class Initialized
INFO - 2020-02-04 15:53:03 --> Language Class Initialized
ERROR - 2020-02-04 15:53:03 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 15:53:03 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 15:53:03 --> Loader Class Initialized
INFO - 2020-02-04 15:53:03 --> Loader Class Initialized
INFO - 2020-02-04 15:53:03 --> Helper loaded: url_helper
INFO - 2020-02-04 15:53:03 --> Language Class Initialized
INFO - 2020-02-04 15:53:03 --> Helper loaded: url_helper
ERROR - 2020-02-04 15:53:03 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 15:53:03 --> Config Class Initialized
INFO - 2020-02-04 15:53:03 --> Config Class Initialized
INFO - 2020-02-04 15:53:03 --> Hooks Class Initialized
INFO - 2020-02-04 15:53:03 --> Hooks Class Initialized
ERROR - 2020-02-04 15:53:03 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:53:03 --> Database Driver Class Initialized
INFO - 2020-02-04 15:53:03 --> Database Driver Class Initialized
INFO - 2020-02-04 15:53:03 --> Config Class Initialized
INFO - 2020-02-04 15:53:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 15:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 15:53:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:03 --> Config Class Initialized
INFO - 2020-02-04 15:53:03 --> Hooks Class Initialized
INFO - 2020-02-04 15:53:03 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:03 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:53:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:03 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:03 --> Controller Class Initialized
INFO - 2020-02-04 15:53:03 --> URI Class Initialized
INFO - 2020-02-04 15:53:03 --> URI Class Initialized
DEBUG - 2020-02-04 15:53:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:04 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:04 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:53:04 --> URI Class Initialized
INFO - 2020-02-04 15:53:04 --> Router Class Initialized
INFO - 2020-02-04 15:53:04 --> Router Class Initialized
INFO - 2020-02-04 15:53:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:53:04 --> URI Class Initialized
INFO - 2020-02-04 15:53:04 --> Router Class Initialized
INFO - 2020-02-04 15:53:04 --> Output Class Initialized
INFO - 2020-02-04 15:53:04 --> Output Class Initialized
INFO - 2020-02-04 15:53:04 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:53:04 --> Router Class Initialized
INFO - 2020-02-04 15:53:04 --> Security Class Initialized
INFO - 2020-02-04 15:53:04 --> Security Class Initialized
INFO - 2020-02-04 15:53:04 --> Output Class Initialized
DEBUG - 2020-02-04 15:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 15:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:04 --> Security Class Initialized
INFO - 2020-02-04 15:53:04 --> Output Class Initialized
INFO - 2020-02-04 15:53:04 --> Helper loaded: form_helper
INFO - 2020-02-04 15:53:04 --> Input Class Initialized
INFO - 2020-02-04 15:53:04 --> Input Class Initialized
INFO - 2020-02-04 15:53:04 --> Form Validation Class Initialized
INFO - 2020-02-04 15:53:04 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:04 --> Input Class Initialized
INFO - 2020-02-04 15:53:04 --> Language Class Initialized
INFO - 2020-02-04 15:53:04 --> Language Class Initialized
DEBUG - 2020-02-04 15:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 15:53:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:53:04 --> Input Class Initialized
ERROR - 2020-02-04 15:53:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-04 15:53:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:53:04 --> Language Class Initialized
ERROR - 2020-02-04 15:53:04 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:53:04 --> Language Class Initialized
INFO - 2020-02-04 15:53:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-04 15:53:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:53:04 --> Config Class Initialized
INFO - 2020-02-04 15:53:04 --> Config Class Initialized
INFO - 2020-02-04 15:53:04 --> Hooks Class Initialized
INFO - 2020-02-04 15:53:04 --> Final output sent to browser
INFO - 2020-02-04 15:53:04 --> Hooks Class Initialized
ERROR - 2020-02-04 15:53:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:53:04 --> Config Class Initialized
INFO - 2020-02-04 15:53:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:04 --> Total execution time: 1.1629
DEBUG - 2020-02-04 15:53:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 15:53:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:04 --> Config Class Initialized
INFO - 2020-02-04 15:53:04 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:04 --> Hooks Class Initialized
INFO - 2020-02-04 15:53:04 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 15:53:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:04 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:04 --> Controller Class Initialized
INFO - 2020-02-04 15:53:04 --> URI Class Initialized
INFO - 2020-02-04 15:53:04 --> URI Class Initialized
DEBUG - 2020-02-04 15:53:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:04 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:04 --> URI Class Initialized
INFO - 2020-02-04 15:53:04 --> Router Class Initialized
INFO - 2020-02-04 15:53:04 --> Router Class Initialized
INFO - 2020-02-04 15:53:04 --> Model "M_tiket" initialized
INFO - 2020-02-04 15:53:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 15:53:04 --> URI Class Initialized
INFO - 2020-02-04 15:53:04 --> Output Class Initialized
INFO - 2020-02-04 15:53:04 --> Router Class Initialized
INFO - 2020-02-04 15:53:04 --> Output Class Initialized
INFO - 2020-02-04 15:53:04 --> Model "M_pesan" initialized
INFO - 2020-02-04 15:53:04 --> Security Class Initialized
INFO - 2020-02-04 15:53:04 --> Router Class Initialized
INFO - 2020-02-04 15:53:04 --> Output Class Initialized
INFO - 2020-02-04 15:53:04 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:04 --> Output Class Initialized
DEBUG - 2020-02-04 15:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:04 --> Security Class Initialized
INFO - 2020-02-04 15:53:04 --> Helper loaded: form_helper
INFO - 2020-02-04 15:53:04 --> Form Validation Class Initialized
INFO - 2020-02-04 15:53:04 --> Input Class Initialized
INFO - 2020-02-04 15:53:04 --> Input Class Initialized
INFO - 2020-02-04 15:53:04 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:04 --> Input Class Initialized
INFO - 2020-02-04 15:53:04 --> Language Class Initialized
DEBUG - 2020-02-04 15:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:04 --> Language Class Initialized
ERROR - 2020-02-04 15:53:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 15:53:04 --> Input Class Initialized
ERROR - 2020-02-04 15:53:04 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 15:53:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 15:53:04 --> Language Class Initialized
ERROR - 2020-02-04 15:53:04 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:53:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-04 15:53:04 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 15:53:04 --> Language Class Initialized
INFO - 2020-02-04 15:53:04 --> Final output sent to browser
ERROR - 2020-02-04 15:53:04 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-04 15:53:05 --> Total execution time: 1.7110
INFO - 2020-02-04 15:53:05 --> Config Class Initialized
INFO - 2020-02-04 15:53:05 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:05 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:05 --> URI Class Initialized
INFO - 2020-02-04 15:53:05 --> Router Class Initialized
INFO - 2020-02-04 15:53:05 --> Output Class Initialized
INFO - 2020-02-04 15:53:05 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:05 --> Input Class Initialized
INFO - 2020-02-04 15:53:05 --> Language Class Initialized
ERROR - 2020-02-04 15:53:05 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 15:53:05 --> Config Class Initialized
INFO - 2020-02-04 15:53:05 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:05 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:05 --> URI Class Initialized
INFO - 2020-02-04 15:53:05 --> Router Class Initialized
INFO - 2020-02-04 15:53:05 --> Output Class Initialized
INFO - 2020-02-04 15:53:05 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:05 --> Input Class Initialized
INFO - 2020-02-04 15:53:05 --> Language Class Initialized
ERROR - 2020-02-04 15:53:05 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 15:53:06 --> Config Class Initialized
INFO - 2020-02-04 15:53:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:06 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:06 --> URI Class Initialized
INFO - 2020-02-04 15:53:06 --> Router Class Initialized
INFO - 2020-02-04 15:53:06 --> Output Class Initialized
INFO - 2020-02-04 15:53:06 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:06 --> Input Class Initialized
INFO - 2020-02-04 15:53:06 --> Language Class Initialized
ERROR - 2020-02-04 15:53:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 15:53:06 --> Config Class Initialized
INFO - 2020-02-04 15:53:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:06 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:06 --> URI Class Initialized
INFO - 2020-02-04 15:53:06 --> Router Class Initialized
INFO - 2020-02-04 15:53:06 --> Output Class Initialized
INFO - 2020-02-04 15:53:06 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:06 --> Input Class Initialized
INFO - 2020-02-04 15:53:06 --> Language Class Initialized
ERROR - 2020-02-04 15:53:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:53:07 --> Config Class Initialized
INFO - 2020-02-04 15:53:07 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:07 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:07 --> URI Class Initialized
INFO - 2020-02-04 15:53:07 --> Router Class Initialized
INFO - 2020-02-04 15:53:07 --> Output Class Initialized
INFO - 2020-02-04 15:53:07 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:07 --> Input Class Initialized
INFO - 2020-02-04 15:53:07 --> Language Class Initialized
ERROR - 2020-02-04 15:53:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 15:53:08 --> Config Class Initialized
INFO - 2020-02-04 15:53:08 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:08 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:08 --> URI Class Initialized
INFO - 2020-02-04 15:53:08 --> Router Class Initialized
INFO - 2020-02-04 15:53:08 --> Output Class Initialized
INFO - 2020-02-04 15:53:08 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:08 --> Input Class Initialized
INFO - 2020-02-04 15:53:08 --> Language Class Initialized
ERROR - 2020-02-04 15:53:08 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 15:53:08 --> Config Class Initialized
INFO - 2020-02-04 15:53:08 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:08 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:08 --> URI Class Initialized
INFO - 2020-02-04 15:53:08 --> Router Class Initialized
INFO - 2020-02-04 15:53:08 --> Output Class Initialized
INFO - 2020-02-04 15:53:08 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:08 --> Input Class Initialized
INFO - 2020-02-04 15:53:08 --> Language Class Initialized
ERROR - 2020-02-04 15:53:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 15:53:09 --> Config Class Initialized
INFO - 2020-02-04 15:53:09 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:09 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:09 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:09 --> URI Class Initialized
INFO - 2020-02-04 15:53:09 --> Router Class Initialized
INFO - 2020-02-04 15:53:09 --> Output Class Initialized
INFO - 2020-02-04 15:53:09 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:09 --> Input Class Initialized
INFO - 2020-02-04 15:53:09 --> Language Class Initialized
ERROR - 2020-02-04 15:53:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 15:53:09 --> Config Class Initialized
INFO - 2020-02-04 15:53:09 --> Hooks Class Initialized
DEBUG - 2020-02-04 15:53:09 --> UTF-8 Support Enabled
INFO - 2020-02-04 15:53:09 --> Utf8 Class Initialized
INFO - 2020-02-04 15:53:09 --> URI Class Initialized
INFO - 2020-02-04 15:53:09 --> Router Class Initialized
INFO - 2020-02-04 15:53:09 --> Output Class Initialized
INFO - 2020-02-04 15:53:09 --> Security Class Initialized
DEBUG - 2020-02-04 15:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 15:53:09 --> Input Class Initialized
INFO - 2020-02-04 15:53:09 --> Language Class Initialized
ERROR - 2020-02-04 15:53:10 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 16:08:37 --> Config Class Initialized
INFO - 2020-02-04 16:08:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:08:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:08:46 --> Utf8 Class Initialized
INFO - 2020-02-04 16:08:47 --> URI Class Initialized
INFO - 2020-02-04 16:08:48 --> Router Class Initialized
INFO - 2020-02-04 16:08:50 --> Output Class Initialized
INFO - 2020-02-04 16:08:52 --> Security Class Initialized
DEBUG - 2020-02-04 16:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:08:55 --> Input Class Initialized
INFO - 2020-02-04 16:08:55 --> Language Class Initialized
INFO - 2020-02-04 16:08:58 --> Loader Class Initialized
INFO - 2020-02-04 16:08:59 --> Config Class Initialized
INFO - 2020-02-04 16:09:00 --> Helper loaded: url_helper
INFO - 2020-02-04 16:09:02 --> Hooks Class Initialized
ERROR - 2020-02-04 16:09:03 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\roadshow\system\database\DB.php 51
DEBUG - 2020-02-04 16:09:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:09:06 --> Utf8 Class Initialized
INFO - 2020-02-04 16:09:09 --> URI Class Initialized
DEBUG - 2020-02-04 16:09:11 --> No URI present. Default controller set.
INFO - 2020-02-04 16:09:13 --> Router Class Initialized
INFO - 2020-02-04 16:09:16 --> Output Class Initialized
INFO - 2020-02-04 16:09:16 --> Security Class Initialized
DEBUG - 2020-02-04 16:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:09:23 --> Input Class Initialized
INFO - 2020-02-04 16:09:23 --> Language Class Initialized
INFO - 2020-02-04 16:09:25 --> Loader Class Initialized
INFO - 2020-02-04 16:09:27 --> Helper loaded: url_helper
ERROR - 2020-02-04 16:09:31 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\roadshow\system\core\Log.php 231
INFO - 2020-02-04 16:09:56 --> Config Class Initialized
INFO - 2020-02-04 16:09:58 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:09:58 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:09:59 --> Utf8 Class Initialized
INFO - 2020-02-04 16:09:59 --> URI Class Initialized
DEBUG - 2020-02-04 16:10:00 --> No URI present. Default controller set.
INFO - 2020-02-04 16:10:00 --> Router Class Initialized
INFO - 2020-02-04 16:10:01 --> Config Class Initialized
INFO - 2020-02-04 16:10:01 --> Output Class Initialized
INFO - 2020-02-04 16:10:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:10:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:10:01 --> Security Class Initialized
INFO - 2020-02-04 16:10:04 --> Utf8 Class Initialized
DEBUG - 2020-02-04 16:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:10:04 --> Input Class Initialized
INFO - 2020-02-04 16:10:04 --> URI Class Initialized
DEBUG - 2020-02-04 16:10:06 --> No URI present. Default controller set.
INFO - 2020-02-04 16:10:06 --> Language Class Initialized
INFO - 2020-02-04 16:10:06 --> Router Class Initialized
INFO - 2020-02-04 16:10:06 --> Loader Class Initialized
INFO - 2020-02-04 16:10:06 --> Output Class Initialized
INFO - 2020-02-04 16:10:06 --> Helper loaded: url_helper
INFO - 2020-02-04 16:10:07 --> Security Class Initialized
DEBUG - 2020-02-04 16:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:10:07 --> Input Class Initialized
INFO - 2020-02-04 16:10:07 --> Language Class Initialized
INFO - 2020-02-04 16:10:08 --> Loader Class Initialized
INFO - 2020-02-04 16:10:08 --> Helper loaded: url_helper
INFO - 2020-02-04 16:10:09 --> Database Driver Class Initialized
INFO - 2020-02-04 16:10:09 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 16:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:10:12 --> Controller Class Initialized
INFO - 2020-02-04 16:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:10:14 --> Controller Class Initialized
INFO - 2020-02-04 16:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 16:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-04 16:10:16 --> Pagination Class Initialized
INFO - 2020-02-04 16:10:16 --> Pagination Class Initialized
INFO - 2020-02-04 16:10:18 --> Model "M_show" initialized
INFO - 2020-02-04 16:10:19 --> Model "M_show" initialized
INFO - 2020-02-04 16:10:19 --> Helper loaded: form_helper
INFO - 2020-02-04 16:10:21 --> Form Validation Class Initialized
INFO - 2020-02-04 16:10:21 --> Helper loaded: form_helper
INFO - 2020-02-04 16:10:21 --> Form Validation Class Initialized
INFO - 2020-02-04 16:10:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 16:10:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-04 16:10:23 --> Final output sent to browser
INFO - 2020-02-04 16:10:23 --> Final output sent to browser
DEBUG - 2020-02-04 16:10:24 --> Total execution time: 26.7295
DEBUG - 2020-02-04 16:10:24 --> Total execution time: 22.3937
INFO - 2020-02-04 16:11:00 --> Config Class Initialized
INFO - 2020-02-04 16:11:02 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:11:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:03 --> Utf8 Class Initialized
INFO - 2020-02-04 16:11:03 --> URI Class Initialized
INFO - 2020-02-04 16:11:03 --> Router Class Initialized
INFO - 2020-02-04 16:11:03 --> Output Class Initialized
INFO - 2020-02-04 16:11:04 --> Security Class Initialized
DEBUG - 2020-02-04 16:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:11:04 --> Input Class Initialized
INFO - 2020-02-04 16:11:04 --> Language Class Initialized
INFO - 2020-02-04 16:11:05 --> Loader Class Initialized
INFO - 2020-02-04 16:11:05 --> Helper loaded: url_helper
INFO - 2020-02-04 16:11:05 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:11:06 --> Controller Class Initialized
INFO - 2020-02-04 16:11:06 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:11:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:11:06 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:11:07 --> Helper loaded: form_helper
INFO - 2020-02-04 16:11:07 --> Form Validation Class Initialized
INFO - 2020-02-04 16:11:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:11:17 --> Final output sent to browser
DEBUG - 2020-02-04 16:11:18 --> Total execution time: 16.6807
INFO - 2020-02-04 16:11:21 --> Config Class Initialized
INFO - 2020-02-04 16:11:22 --> Hooks Class Initialized
INFO - 2020-02-04 16:11:22 --> Config Class Initialized
INFO - 2020-02-04 16:11:22 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:11:22 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:22 --> Config Class Initialized
INFO - 2020-02-04 16:11:22 --> Hooks Class Initialized
INFO - 2020-02-04 16:11:22 --> Utf8 Class Initialized
DEBUG - 2020-02-04 16:11:22 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:22 --> Utf8 Class Initialized
INFO - 2020-02-04 16:11:23 --> URI Class Initialized
DEBUG - 2020-02-04 16:11:23 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:23 --> Utf8 Class Initialized
INFO - 2020-02-04 16:11:23 --> URI Class Initialized
INFO - 2020-02-04 16:11:23 --> Router Class Initialized
INFO - 2020-02-04 16:11:23 --> Router Class Initialized
INFO - 2020-02-04 16:11:23 --> Output Class Initialized
INFO - 2020-02-04 16:11:23 --> URI Class Initialized
INFO - 2020-02-04 16:11:23 --> Router Class Initialized
INFO - 2020-02-04 16:11:23 --> Security Class Initialized
INFO - 2020-02-04 16:11:23 --> Output Class Initialized
DEBUG - 2020-02-04 16:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:11:23 --> Output Class Initialized
INFO - 2020-02-04 16:11:23 --> Security Class Initialized
INFO - 2020-02-04 16:11:23 --> Input Class Initialized
DEBUG - 2020-02-04 16:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:11:23 --> Security Class Initialized
INFO - 2020-02-04 16:11:23 --> Input Class Initialized
DEBUG - 2020-02-04 16:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:11:24 --> Input Class Initialized
INFO - 2020-02-04 16:11:24 --> Language Class Initialized
INFO - 2020-02-04 16:11:24 --> Language Class Initialized
INFO - 2020-02-04 16:11:24 --> Language Class Initialized
ERROR - 2020-02-04 16:11:25 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 16:11:25 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 16:11:25 --> Config Class Initialized
INFO - 2020-02-04 16:11:25 --> Hooks Class Initialized
ERROR - 2020-02-04 16:11:25 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 16:11:25 --> Config Class Initialized
INFO - 2020-02-04 16:11:25 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:11:25 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:25 --> Utf8 Class Initialized
DEBUG - 2020-02-04 16:11:25 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:25 --> Config Class Initialized
INFO - 2020-02-04 16:11:25 --> Utf8 Class Initialized
INFO - 2020-02-04 16:11:25 --> Hooks Class Initialized
INFO - 2020-02-04 16:11:25 --> URI Class Initialized
INFO - 2020-02-04 16:11:26 --> URI Class Initialized
DEBUG - 2020-02-04 16:11:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:26 --> Router Class Initialized
INFO - 2020-02-04 16:11:26 --> Utf8 Class Initialized
INFO - 2020-02-04 16:11:26 --> Router Class Initialized
INFO - 2020-02-04 16:11:26 --> Output Class Initialized
INFO - 2020-02-04 16:11:26 --> URI Class Initialized
INFO - 2020-02-04 16:11:26 --> Security Class Initialized
INFO - 2020-02-04 16:11:26 --> Output Class Initialized
DEBUG - 2020-02-04 16:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:11:26 --> Security Class Initialized
INFO - 2020-02-04 16:11:26 --> Router Class Initialized
INFO - 2020-02-04 16:11:26 --> Input Class Initialized
DEBUG - 2020-02-04 16:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:11:26 --> Output Class Initialized
INFO - 2020-02-04 16:11:26 --> Input Class Initialized
INFO - 2020-02-04 16:11:26 --> Language Class Initialized
INFO - 2020-02-04 16:11:26 --> Security Class Initialized
INFO - 2020-02-04 16:11:26 --> Language Class Initialized
DEBUG - 2020-02-04 16:11:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 16:11:26 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 16:11:26 --> Input Class Initialized
ERROR - 2020-02-04 16:11:26 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 16:11:26 --> Language Class Initialized
ERROR - 2020-02-04 16:11:26 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 16:11:26 --> Config Class Initialized
INFO - 2020-02-04 16:11:26 --> Config Class Initialized
INFO - 2020-02-04 16:11:26 --> Config Class Initialized
INFO - 2020-02-04 16:11:27 --> Hooks Class Initialized
INFO - 2020-02-04 16:11:27 --> Hooks Class Initialized
INFO - 2020-02-04 16:11:27 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:11:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:11:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:11:27 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:27 --> Utf8 Class Initialized
INFO - 2020-02-04 16:11:27 --> Utf8 Class Initialized
INFO - 2020-02-04 16:11:27 --> Utf8 Class Initialized
INFO - 2020-02-04 16:11:27 --> Config Class Initialized
INFO - 2020-02-04 16:11:27 --> Hooks Class Initialized
INFO - 2020-02-04 16:11:27 --> URI Class Initialized
INFO - 2020-02-04 16:11:27 --> URI Class Initialized
INFO - 2020-02-04 16:11:27 --> URI Class Initialized
INFO - 2020-02-04 16:11:27 --> Router Class Initialized
INFO - 2020-02-04 16:11:27 --> Router Class Initialized
INFO - 2020-02-04 16:11:27 --> Router Class Initialized
DEBUG - 2020-02-04 16:11:27 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:27 --> Config Class Initialized
INFO - 2020-02-04 16:11:27 --> Hooks Class Initialized
INFO - 2020-02-04 16:11:27 --> Utf8 Class Initialized
INFO - 2020-02-04 16:11:27 --> Output Class Initialized
INFO - 2020-02-04 16:11:27 --> Output Class Initialized
INFO - 2020-02-04 16:11:27 --> Output Class Initialized
INFO - 2020-02-04 16:11:27 --> URI Class Initialized
INFO - 2020-02-04 16:11:27 --> Security Class Initialized
INFO - 2020-02-04 16:11:27 --> Security Class Initialized
INFO - 2020-02-04 16:11:27 --> Security Class Initialized
DEBUG - 2020-02-04 16:11:27 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:27 --> Utf8 Class Initialized
DEBUG - 2020-02-04 16:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:11:27 --> Router Class Initialized
DEBUG - 2020-02-04 16:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:11:27 --> Input Class Initialized
INFO - 2020-02-04 16:11:27 --> URI Class Initialized
INFO - 2020-02-04 16:11:27 --> Input Class Initialized
INFO - 2020-02-04 16:11:27 --> Input Class Initialized
INFO - 2020-02-04 16:11:27 --> Output Class Initialized
INFO - 2020-02-04 16:11:27 --> Language Class Initialized
INFO - 2020-02-04 16:11:27 --> Language Class Initialized
INFO - 2020-02-04 16:11:27 --> Router Class Initialized
INFO - 2020-02-04 16:11:27 --> Language Class Initialized
INFO - 2020-02-04 16:11:27 --> Security Class Initialized
ERROR - 2020-02-04 16:11:27 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-04 16:11:27 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 16:11:27 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-04 16:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:11:27 --> Output Class Initialized
INFO - 2020-02-04 16:11:28 --> Input Class Initialized
INFO - 2020-02-04 16:11:28 --> Security Class Initialized
INFO - 2020-02-04 16:11:28 --> Config Class Initialized
INFO - 2020-02-04 16:11:28 --> Config Class Initialized
INFO - 2020-02-04 16:11:28 --> Config Class Initialized
INFO - 2020-02-04 16:11:28 --> Hooks Class Initialized
INFO - 2020-02-04 16:11:28 --> Hooks Class Initialized
INFO - 2020-02-04 16:11:28 --> Hooks Class Initialized
INFO - 2020-02-04 16:11:28 --> Language Class Initialized
DEBUG - 2020-02-04 16:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:11:28 --> Input Class Initialized
DEBUG - 2020-02-04 16:11:28 --> UTF-8 Support Enabled
ERROR - 2020-02-04 16:11:28 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-04 16:11:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:11:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:28 --> Utf8 Class Initialized
INFO - 2020-02-04 16:11:28 --> Utf8 Class Initialized
INFO - 2020-02-04 16:11:28 --> Utf8 Class Initialized
INFO - 2020-02-04 16:11:28 --> Language Class Initialized
INFO - 2020-02-04 16:11:28 --> URI Class Initialized
INFO - 2020-02-04 16:11:28 --> URI Class Initialized
INFO - 2020-02-04 16:11:28 --> URI Class Initialized
INFO - 2020-02-04 16:11:28 --> Loader Class Initialized
INFO - 2020-02-04 16:11:29 --> Router Class Initialized
INFO - 2020-02-04 16:11:29 --> Router Class Initialized
INFO - 2020-02-04 16:11:29 --> Helper loaded: url_helper
INFO - 2020-02-04 16:11:29 --> Router Class Initialized
INFO - 2020-02-04 16:11:29 --> Output Class Initialized
INFO - 2020-02-04 16:11:29 --> Output Class Initialized
INFO - 2020-02-04 16:11:29 --> Output Class Initialized
INFO - 2020-02-04 16:11:29 --> Database Driver Class Initialized
INFO - 2020-02-04 16:11:29 --> Security Class Initialized
INFO - 2020-02-04 16:11:29 --> Security Class Initialized
INFO - 2020-02-04 16:11:29 --> Security Class Initialized
DEBUG - 2020-02-04 16:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:11:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 16:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:11:29 --> Input Class Initialized
INFO - 2020-02-04 16:11:29 --> Input Class Initialized
INFO - 2020-02-04 16:11:29 --> Controller Class Initialized
INFO - 2020-02-04 16:11:29 --> Input Class Initialized
INFO - 2020-02-04 16:11:29 --> Language Class Initialized
INFO - 2020-02-04 16:11:29 --> Language Class Initialized
INFO - 2020-02-04 16:11:29 --> Language Class Initialized
INFO - 2020-02-04 16:11:29 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:11:29 --> Model "M_pengunjung" initialized
ERROR - 2020-02-04 16:11:29 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-04 16:11:29 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 16:11:29 --> Loader Class Initialized
INFO - 2020-02-04 16:11:29 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:11:29 --> Helper loaded: url_helper
INFO - 2020-02-04 16:11:29 --> Config Class Initialized
INFO - 2020-02-04 16:11:29 --> Hooks Class Initialized
INFO - 2020-02-04 16:11:29 --> Helper loaded: form_helper
INFO - 2020-02-04 16:11:29 --> Form Validation Class Initialized
DEBUG - 2020-02-04 16:11:29 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:29 --> Database Driver Class Initialized
INFO - 2020-02-04 16:11:29 --> Utf8 Class Initialized
ERROR - 2020-02-04 16:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
DEBUG - 2020-02-04 16:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:11:29 --> URI Class Initialized
ERROR - 2020-02-04 16:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 16:11:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:11:30 --> Router Class Initialized
INFO - 2020-02-04 16:11:30 --> Final output sent to browser
INFO - 2020-02-04 16:11:30 --> Output Class Initialized
DEBUG - 2020-02-04 16:11:30 --> Total execution time: 2.6556
INFO - 2020-02-04 16:11:30 --> Security Class Initialized
INFO - 2020-02-04 16:11:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 16:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:11:30 --> Controller Class Initialized
INFO - 2020-02-04 16:11:30 --> Input Class Initialized
INFO - 2020-02-04 16:11:30 --> Language Class Initialized
INFO - 2020-02-04 16:11:30 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:11:30 --> Model "M_pengunjung" initialized
ERROR - 2020-02-04 16:11:30 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 16:11:30 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:11:30 --> Config Class Initialized
INFO - 2020-02-04 16:11:30 --> Hooks Class Initialized
INFO - 2020-02-04 16:11:31 --> Helper loaded: form_helper
INFO - 2020-02-04 16:11:31 --> Form Validation Class Initialized
DEBUG - 2020-02-04 16:11:31 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:31 --> Utf8 Class Initialized
ERROR - 2020-02-04 16:11:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 16:11:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 16:11:31 --> URI Class Initialized
INFO - 2020-02-04 16:11:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:11:31 --> Router Class Initialized
INFO - 2020-02-04 16:11:31 --> Final output sent to browser
INFO - 2020-02-04 16:11:31 --> Output Class Initialized
DEBUG - 2020-02-04 16:11:31 --> Total execution time: 3.2270
INFO - 2020-02-04 16:11:31 --> Security Class Initialized
DEBUG - 2020-02-04 16:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:11:47 --> Input Class Initialized
INFO - 2020-02-04 16:11:47 --> Language Class Initialized
ERROR - 2020-02-04 16:11:47 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 16:11:47 --> Config Class Initialized
INFO - 2020-02-04 16:11:47 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:11:47 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:11:47 --> Utf8 Class Initialized
INFO - 2020-02-04 16:12:19 --> Config Class Initialized
INFO - 2020-02-04 16:12:19 --> Config Class Initialized
INFO - 2020-02-04 16:12:19 --> Hooks Class Initialized
INFO - 2020-02-04 16:12:19 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:12:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:12:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:12:20 --> Utf8 Class Initialized
INFO - 2020-02-04 16:12:20 --> Utf8 Class Initialized
INFO - 2020-02-04 16:12:20 --> URI Class Initialized
INFO - 2020-02-04 16:12:20 --> URI Class Initialized
INFO - 2020-02-04 16:12:20 --> Router Class Initialized
INFO - 2020-02-04 16:12:20 --> Router Class Initialized
INFO - 2020-02-04 16:12:20 --> Output Class Initialized
INFO - 2020-02-04 16:12:20 --> Output Class Initialized
INFO - 2020-02-04 16:12:20 --> Security Class Initialized
INFO - 2020-02-04 16:12:20 --> Security Class Initialized
DEBUG - 2020-02-04 16:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:12:20 --> Input Class Initialized
INFO - 2020-02-04 16:12:20 --> Input Class Initialized
INFO - 2020-02-04 16:12:20 --> Language Class Initialized
INFO - 2020-02-04 16:12:20 --> Language Class Initialized
ERROR - 2020-02-04 16:12:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 16:12:20 --> Loader Class Initialized
INFO - 2020-02-04 16:12:21 --> Helper loaded: url_helper
INFO - 2020-02-04 16:12:21 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:12:21 --> Controller Class Initialized
INFO - 2020-02-04 16:12:21 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:12:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:12:21 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:12:21 --> Helper loaded: form_helper
INFO - 2020-02-04 16:12:22 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:12:22 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 39
ERROR - 2020-02-04 16:12:22 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\models\M_pesan.php 55
ERROR - 2020-02-04 16:12:22 --> Query error: Column 'id_tiket' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `jumlah_pesanan`, `id_pengunjung`) VALUES (NULL, '0', '9')
INFO - 2020-02-04 16:12:22 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-04 16:12:57 --> Config Class Initialized
INFO - 2020-02-04 16:12:57 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:12:57 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:12:57 --> Utf8 Class Initialized
INFO - 2020-02-04 16:12:57 --> URI Class Initialized
INFO - 2020-02-04 16:12:57 --> Router Class Initialized
INFO - 2020-02-04 16:12:57 --> Output Class Initialized
INFO - 2020-02-04 16:12:58 --> Security Class Initialized
DEBUG - 2020-02-04 16:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:12:58 --> Input Class Initialized
INFO - 2020-02-04 16:12:58 --> Language Class Initialized
INFO - 2020-02-04 16:12:58 --> Loader Class Initialized
INFO - 2020-02-04 16:12:58 --> Helper loaded: url_helper
INFO - 2020-02-04 16:12:58 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:12:58 --> Controller Class Initialized
INFO - 2020-02-04 16:12:58 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:12:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:12:58 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:12:58 --> Helper loaded: form_helper
INFO - 2020-02-04 16:12:58 --> Form Validation Class Initialized
INFO - 2020-02-04 16:12:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:12:58 --> Final output sent to browser
INFO - 2020-02-04 16:12:58 --> Config Class Initialized
INFO - 2020-02-04 16:12:58 --> Config Class Initialized
INFO - 2020-02-04 16:12:58 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:12:58 --> Total execution time: 1.5225
INFO - 2020-02-04 16:12:58 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:12:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:12:59 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:12:59 --> Config Class Initialized
INFO - 2020-02-04 16:12:59 --> Hooks Class Initialized
INFO - 2020-02-04 16:12:59 --> Utf8 Class Initialized
INFO - 2020-02-04 16:12:59 --> Utf8 Class Initialized
INFO - 2020-02-04 16:12:59 --> URI Class Initialized
INFO - 2020-02-04 16:12:59 --> URI Class Initialized
DEBUG - 2020-02-04 16:12:59 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:12:59 --> Utf8 Class Initialized
INFO - 2020-02-04 16:12:59 --> Router Class Initialized
INFO - 2020-02-04 16:12:59 --> Router Class Initialized
INFO - 2020-02-04 16:12:59 --> URI Class Initialized
INFO - 2020-02-04 16:12:59 --> Output Class Initialized
INFO - 2020-02-04 16:12:59 --> Output Class Initialized
INFO - 2020-02-04 16:12:59 --> Security Class Initialized
INFO - 2020-02-04 16:12:59 --> Security Class Initialized
INFO - 2020-02-04 16:12:59 --> Router Class Initialized
DEBUG - 2020-02-04 16:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:12:59 --> Output Class Initialized
INFO - 2020-02-04 16:12:59 --> Input Class Initialized
INFO - 2020-02-04 16:12:59 --> Input Class Initialized
INFO - 2020-02-04 16:12:59 --> Security Class Initialized
INFO - 2020-02-04 16:12:59 --> Language Class Initialized
INFO - 2020-02-04 16:12:59 --> Language Class Initialized
DEBUG - 2020-02-04 16:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:12:59 --> Input Class Initialized
ERROR - 2020-02-04 16:12:59 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 16:12:59 --> Loader Class Initialized
INFO - 2020-02-04 16:12:59 --> Helper loaded: url_helper
INFO - 2020-02-04 16:12:59 --> Language Class Initialized
INFO - 2020-02-04 16:12:59 --> Loader Class Initialized
INFO - 2020-02-04 16:12:59 --> Database Driver Class Initialized
INFO - 2020-02-04 16:12:59 --> Helper loaded: url_helper
DEBUG - 2020-02-04 16:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:12:59 --> Database Driver Class Initialized
INFO - 2020-02-04 16:12:59 --> Controller Class Initialized
DEBUG - 2020-02-04 16:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:12:59 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:13:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:13:00 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:13:00 --> Helper loaded: form_helper
INFO - 2020-02-04 16:13:00 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:13:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 16:13:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 16:13:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:13:00 --> Final output sent to browser
DEBUG - 2020-02-04 16:13:00 --> Total execution time: 1.6186
INFO - 2020-02-04 16:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:13:00 --> Controller Class Initialized
INFO - 2020-02-04 16:13:00 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:13:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:13:00 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:13:00 --> Helper loaded: form_helper
INFO - 2020-02-04 16:13:00 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:13:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 16:13:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 16:13:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:13:00 --> Final output sent to browser
DEBUG - 2020-02-04 16:13:00 --> Total execution time: 2.1075
INFO - 2020-02-04 16:13:03 --> Config Class Initialized
INFO - 2020-02-04 16:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:04 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:04 --> URI Class Initialized
INFO - 2020-02-04 16:13:04 --> Router Class Initialized
INFO - 2020-02-04 16:13:04 --> Output Class Initialized
INFO - 2020-02-04 16:13:04 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:04 --> Input Class Initialized
INFO - 2020-02-04 16:13:04 --> Language Class Initialized
INFO - 2020-02-04 16:13:04 --> Loader Class Initialized
INFO - 2020-02-04 16:13:04 --> Helper loaded: url_helper
INFO - 2020-02-04 16:13:04 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:13:05 --> Controller Class Initialized
INFO - 2020-02-04 16:13:05 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:13:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:13:05 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:13:05 --> Helper loaded: form_helper
INFO - 2020-02-04 16:13:05 --> Form Validation Class Initialized
INFO - 2020-02-04 16:13:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:13:05 --> Final output sent to browser
INFO - 2020-02-04 16:13:05 --> Config Class Initialized
INFO - 2020-02-04 16:13:05 --> Config Class Initialized
INFO - 2020-02-04 16:13:05 --> Config Class Initialized
INFO - 2020-02-04 16:13:05 --> Config Class Initialized
INFO - 2020-02-04 16:13:05 --> Hooks Class Initialized
INFO - 2020-02-04 16:13:05 --> Config Class Initialized
INFO - 2020-02-04 16:13:05 --> Hooks Class Initialized
INFO - 2020-02-04 16:13:05 --> Hooks Class Initialized
INFO - 2020-02-04 16:13:05 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:05 --> Total execution time: 1.5697
INFO - 2020-02-04 16:13:05 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:05 --> Config Class Initialized
INFO - 2020-02-04 16:13:05 --> Hooks Class Initialized
INFO - 2020-02-04 16:13:05 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:05 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:05 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:05 --> Utf8 Class Initialized
DEBUG - 2020-02-04 16:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:05 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:05 --> URI Class Initialized
INFO - 2020-02-04 16:13:05 --> URI Class Initialized
INFO - 2020-02-04 16:13:05 --> URI Class Initialized
DEBUG - 2020-02-04 16:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:05 --> URI Class Initialized
INFO - 2020-02-04 16:13:05 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:05 --> Router Class Initialized
INFO - 2020-02-04 16:13:05 --> Router Class Initialized
INFO - 2020-02-04 16:13:05 --> Router Class Initialized
INFO - 2020-02-04 16:13:05 --> Router Class Initialized
INFO - 2020-02-04 16:13:05 --> URI Class Initialized
INFO - 2020-02-04 16:13:05 --> URI Class Initialized
INFO - 2020-02-04 16:13:05 --> Router Class Initialized
INFO - 2020-02-04 16:13:05 --> Output Class Initialized
INFO - 2020-02-04 16:13:05 --> Output Class Initialized
INFO - 2020-02-04 16:13:05 --> Output Class Initialized
INFO - 2020-02-04 16:13:05 --> Output Class Initialized
INFO - 2020-02-04 16:13:05 --> Security Class Initialized
INFO - 2020-02-04 16:13:05 --> Security Class Initialized
INFO - 2020-02-04 16:13:05 --> Router Class Initialized
INFO - 2020-02-04 16:13:05 --> Output Class Initialized
INFO - 2020-02-04 16:13:05 --> Security Class Initialized
INFO - 2020-02-04 16:13:05 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:05 --> Security Class Initialized
INFO - 2020-02-04 16:13:05 --> Output Class Initialized
INFO - 2020-02-04 16:13:05 --> Input Class Initialized
INFO - 2020-02-04 16:13:05 --> Input Class Initialized
INFO - 2020-02-04 16:13:05 --> Input Class Initialized
INFO - 2020-02-04 16:13:05 --> Input Class Initialized
DEBUG - 2020-02-04 16:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:05 --> Security Class Initialized
INFO - 2020-02-04 16:13:05 --> Input Class Initialized
INFO - 2020-02-04 16:13:05 --> Language Class Initialized
INFO - 2020-02-04 16:13:05 --> Language Class Initialized
INFO - 2020-02-04 16:13:05 --> Language Class Initialized
DEBUG - 2020-02-04 16:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:05 --> Language Class Initialized
INFO - 2020-02-04 16:13:05 --> Input Class Initialized
INFO - 2020-02-04 16:13:05 --> Loader Class Initialized
INFO - 2020-02-04 16:13:05 --> Loader Class Initialized
ERROR - 2020-02-04 16:13:05 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 16:13:05 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 16:13:05 --> Language Class Initialized
INFO - 2020-02-04 16:13:05 --> Language Class Initialized
ERROR - 2020-02-04 16:13:05 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 16:13:05 --> Helper loaded: url_helper
INFO - 2020-02-04 16:13:05 --> Helper loaded: url_helper
INFO - 2020-02-04 16:13:06 --> Config Class Initialized
INFO - 2020-02-04 16:13:06 --> Config Class Initialized
INFO - 2020-02-04 16:13:06 --> Hooks Class Initialized
INFO - 2020-02-04 16:13:06 --> Hooks Class Initialized
ERROR - 2020-02-04 16:13:06 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 16:13:06 --> Database Driver Class Initialized
INFO - 2020-02-04 16:13:06 --> Database Driver Class Initialized
INFO - 2020-02-04 16:13:06 --> Config Class Initialized
INFO - 2020-02-04 16:13:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:13:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 16:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:13:06 --> Config Class Initialized
INFO - 2020-02-04 16:13:06 --> Hooks Class Initialized
INFO - 2020-02-04 16:13:06 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:06 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 16:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:06 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:06 --> Controller Class Initialized
INFO - 2020-02-04 16:13:06 --> URI Class Initialized
INFO - 2020-02-04 16:13:06 --> URI Class Initialized
DEBUG - 2020-02-04 16:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:06 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:06 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:13:06 --> URI Class Initialized
INFO - 2020-02-04 16:13:06 --> Router Class Initialized
INFO - 2020-02-04 16:13:06 --> Router Class Initialized
INFO - 2020-02-04 16:13:06 --> URI Class Initialized
INFO - 2020-02-04 16:13:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:13:06 --> Output Class Initialized
INFO - 2020-02-04 16:13:06 --> Output Class Initialized
INFO - 2020-02-04 16:13:06 --> Router Class Initialized
INFO - 2020-02-04 16:13:06 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:13:06 --> Security Class Initialized
INFO - 2020-02-04 16:13:06 --> Output Class Initialized
INFO - 2020-02-04 16:13:06 --> Router Class Initialized
INFO - 2020-02-04 16:13:06 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:06 --> Security Class Initialized
INFO - 2020-02-04 16:13:06 --> Output Class Initialized
INFO - 2020-02-04 16:13:06 --> Helper loaded: form_helper
INFO - 2020-02-04 16:13:06 --> Form Validation Class Initialized
INFO - 2020-02-04 16:13:06 --> Input Class Initialized
INFO - 2020-02-04 16:13:06 --> Input Class Initialized
DEBUG - 2020-02-04 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:06 --> Security Class Initialized
INFO - 2020-02-04 16:13:06 --> Input Class Initialized
INFO - 2020-02-04 16:13:06 --> Language Class Initialized
DEBUG - 2020-02-04 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:06 --> Language Class Initialized
ERROR - 2020-02-04 16:13:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 16:13:06 --> Input Class Initialized
ERROR - 2020-02-04 16:13:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-04 16:13:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 16:13:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 16:13:06 --> Language Class Initialized
INFO - 2020-02-04 16:13:06 --> Language Class Initialized
INFO - 2020-02-04 16:13:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-04 16:13:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 16:13:06 --> Config Class Initialized
INFO - 2020-02-04 16:13:06 --> Config Class Initialized
INFO - 2020-02-04 16:13:06 --> Hooks Class Initialized
INFO - 2020-02-04 16:13:06 --> Hooks Class Initialized
INFO - 2020-02-04 16:13:06 --> Final output sent to browser
ERROR - 2020-02-04 16:13:06 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 16:13:06 --> Config Class Initialized
INFO - 2020-02-04 16:13:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:06 --> Total execution time: 1.1492
DEBUG - 2020-02-04 16:13:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:06 --> Config Class Initialized
INFO - 2020-02-04 16:13:06 --> Hooks Class Initialized
INFO - 2020-02-04 16:13:06 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:06 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 16:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:06 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:06 --> URI Class Initialized
INFO - 2020-02-04 16:13:06 --> URI Class Initialized
INFO - 2020-02-04 16:13:06 --> Controller Class Initialized
DEBUG - 2020-02-04 16:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:06 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:06 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:13:06 --> Router Class Initialized
INFO - 2020-02-04 16:13:06 --> Router Class Initialized
INFO - 2020-02-04 16:13:06 --> URI Class Initialized
INFO - 2020-02-04 16:13:06 --> Router Class Initialized
INFO - 2020-02-04 16:13:06 --> URI Class Initialized
INFO - 2020-02-04 16:13:06 --> Output Class Initialized
INFO - 2020-02-04 16:13:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:13:06 --> Output Class Initialized
INFO - 2020-02-04 16:13:06 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:13:06 --> Security Class Initialized
INFO - 2020-02-04 16:13:06 --> Output Class Initialized
INFO - 2020-02-04 16:13:06 --> Security Class Initialized
INFO - 2020-02-04 16:13:06 --> Router Class Initialized
DEBUG - 2020-02-04 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:06 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:06 --> Output Class Initialized
INFO - 2020-02-04 16:13:06 --> Helper loaded: form_helper
INFO - 2020-02-04 16:13:06 --> Form Validation Class Initialized
INFO - 2020-02-04 16:13:06 --> Input Class Initialized
INFO - 2020-02-04 16:13:06 --> Input Class Initialized
DEBUG - 2020-02-04 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:06 --> Security Class Initialized
INFO - 2020-02-04 16:13:07 --> Input Class Initialized
INFO - 2020-02-04 16:13:07 --> Language Class Initialized
INFO - 2020-02-04 16:13:07 --> Language Class Initialized
DEBUG - 2020-02-04 16:13:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-04 16:13:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 16:13:07 --> Input Class Initialized
ERROR - 2020-02-04 16:13:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-04 16:13:07 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 16:13:07 --> Language Class Initialized
ERROR - 2020-02-04 16:13:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 16:13:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:13:07 --> Language Class Initialized
ERROR - 2020-02-04 16:13:07 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 16:13:07 --> Final output sent to browser
ERROR - 2020-02-04 16:13:07 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-04 16:13:07 --> Total execution time: 1.6853
INFO - 2020-02-04 16:13:07 --> Config Class Initialized
INFO - 2020-02-04 16:13:07 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:07 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:07 --> URI Class Initialized
INFO - 2020-02-04 16:13:07 --> Router Class Initialized
INFO - 2020-02-04 16:13:07 --> Output Class Initialized
INFO - 2020-02-04 16:13:07 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:07 --> Input Class Initialized
INFO - 2020-02-04 16:13:07 --> Language Class Initialized
ERROR - 2020-02-04 16:13:07 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 16:13:07 --> Config Class Initialized
INFO - 2020-02-04 16:13:07 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:07 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:07 --> URI Class Initialized
INFO - 2020-02-04 16:13:07 --> Router Class Initialized
INFO - 2020-02-04 16:13:07 --> Output Class Initialized
INFO - 2020-02-04 16:13:08 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:08 --> Input Class Initialized
INFO - 2020-02-04 16:13:08 --> Language Class Initialized
ERROR - 2020-02-04 16:13:08 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 16:13:08 --> Config Class Initialized
INFO - 2020-02-04 16:13:08 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:08 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:08 --> URI Class Initialized
INFO - 2020-02-04 16:13:08 --> Router Class Initialized
INFO - 2020-02-04 16:13:08 --> Output Class Initialized
INFO - 2020-02-04 16:13:08 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:08 --> Input Class Initialized
INFO - 2020-02-04 16:13:08 --> Language Class Initialized
ERROR - 2020-02-04 16:13:08 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 16:13:08 --> Config Class Initialized
INFO - 2020-02-04 16:13:08 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:08 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:08 --> URI Class Initialized
INFO - 2020-02-04 16:13:08 --> Router Class Initialized
INFO - 2020-02-04 16:13:09 --> Output Class Initialized
INFO - 2020-02-04 16:13:09 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:09 --> Input Class Initialized
INFO - 2020-02-04 16:13:09 --> Language Class Initialized
ERROR - 2020-02-04 16:13:09 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 16:13:09 --> Config Class Initialized
INFO - 2020-02-04 16:13:09 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:09 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:09 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:09 --> URI Class Initialized
INFO - 2020-02-04 16:13:09 --> Router Class Initialized
INFO - 2020-02-04 16:13:09 --> Output Class Initialized
INFO - 2020-02-04 16:13:09 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:09 --> Input Class Initialized
INFO - 2020-02-04 16:13:09 --> Language Class Initialized
ERROR - 2020-02-04 16:13:09 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 16:13:09 --> Config Class Initialized
INFO - 2020-02-04 16:13:09 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:09 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:09 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:10 --> URI Class Initialized
INFO - 2020-02-04 16:13:10 --> Router Class Initialized
INFO - 2020-02-04 16:13:10 --> Output Class Initialized
INFO - 2020-02-04 16:13:10 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:10 --> Input Class Initialized
INFO - 2020-02-04 16:13:10 --> Language Class Initialized
ERROR - 2020-02-04 16:13:10 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 16:13:10 --> Config Class Initialized
INFO - 2020-02-04 16:13:10 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:10 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:10 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:10 --> URI Class Initialized
INFO - 2020-02-04 16:13:10 --> Router Class Initialized
INFO - 2020-02-04 16:13:10 --> Output Class Initialized
INFO - 2020-02-04 16:13:10 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:10 --> Input Class Initialized
INFO - 2020-02-04 16:13:10 --> Language Class Initialized
ERROR - 2020-02-04 16:13:10 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 16:13:10 --> Config Class Initialized
INFO - 2020-02-04 16:13:10 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:11 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:11 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:11 --> URI Class Initialized
INFO - 2020-02-04 16:13:11 --> Router Class Initialized
INFO - 2020-02-04 16:13:11 --> Output Class Initialized
INFO - 2020-02-04 16:13:11 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:11 --> Input Class Initialized
INFO - 2020-02-04 16:13:11 --> Language Class Initialized
ERROR - 2020-02-04 16:13:11 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 16:13:11 --> Config Class Initialized
INFO - 2020-02-04 16:13:11 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:11 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:11 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:11 --> URI Class Initialized
INFO - 2020-02-04 16:13:11 --> Router Class Initialized
INFO - 2020-02-04 16:13:11 --> Output Class Initialized
INFO - 2020-02-04 16:13:11 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:11 --> Input Class Initialized
INFO - 2020-02-04 16:13:11 --> Language Class Initialized
ERROR - 2020-02-04 16:13:11 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 16:13:35 --> Config Class Initialized
INFO - 2020-02-04 16:13:35 --> Hooks Class Initialized
INFO - 2020-02-04 16:13:35 --> Config Class Initialized
INFO - 2020-02-04 16:13:35 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:35 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:35 --> Utf8 Class Initialized
DEBUG - 2020-02-04 16:13:35 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:35 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:35 --> URI Class Initialized
INFO - 2020-02-04 16:13:35 --> URI Class Initialized
INFO - 2020-02-04 16:13:35 --> Router Class Initialized
INFO - 2020-02-04 16:13:35 --> Router Class Initialized
INFO - 2020-02-04 16:13:35 --> Output Class Initialized
INFO - 2020-02-04 16:13:35 --> Security Class Initialized
INFO - 2020-02-04 16:13:35 --> Output Class Initialized
DEBUG - 2020-02-04 16:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:35 --> Security Class Initialized
INFO - 2020-02-04 16:13:35 --> Input Class Initialized
DEBUG - 2020-02-04 16:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:35 --> Input Class Initialized
INFO - 2020-02-04 16:13:35 --> Language Class Initialized
INFO - 2020-02-04 16:13:36 --> Language Class Initialized
INFO - 2020-02-04 16:13:36 --> Loader Class Initialized
INFO - 2020-02-04 16:13:36 --> Helper loaded: url_helper
INFO - 2020-02-04 16:13:36 --> Loader Class Initialized
INFO - 2020-02-04 16:13:36 --> Helper loaded: url_helper
INFO - 2020-02-04 16:13:36 --> Database Driver Class Initialized
INFO - 2020-02-04 16:13:36 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:13:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 16:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:13:36 --> Controller Class Initialized
INFO - 2020-02-04 16:13:36 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:13:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:13:36 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:13:36 --> Helper loaded: form_helper
INFO - 2020-02-04 16:13:36 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:13:36 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 39
ERROR - 2020-02-04 16:13:36 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\models\M_pesan.php 55
ERROR - 2020-02-04 16:13:36 --> Query error: Column 'id_tiket' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `jumlah_pesanan`, `id_pengunjung`) VALUES (NULL, '0', '10')
INFO - 2020-02-04 16:13:37 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-04 16:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:13:37 --> Controller Class Initialized
INFO - 2020-02-04 16:13:37 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:13:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:13:37 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:13:37 --> Helper loaded: form_helper
INFO - 2020-02-04 16:13:37 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:13:38 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 39
ERROR - 2020-02-04 16:13:38 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\models\M_pesan.php 55
ERROR - 2020-02-04 16:13:38 --> Query error: Column 'id_tiket' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `jumlah_pesanan`, `id_pengunjung`) VALUES (NULL, '0', '10')
INFO - 2020-02-04 16:13:38 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-04 16:13:43 --> Config Class Initialized
INFO - 2020-02-04 16:13:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:44 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:44 --> URI Class Initialized
INFO - 2020-02-04 16:13:44 --> Router Class Initialized
INFO - 2020-02-04 16:13:44 --> Output Class Initialized
INFO - 2020-02-04 16:13:44 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:44 --> Input Class Initialized
INFO - 2020-02-04 16:13:44 --> Language Class Initialized
INFO - 2020-02-04 16:13:44 --> Loader Class Initialized
INFO - 2020-02-04 16:13:44 --> Helper loaded: url_helper
INFO - 2020-02-04 16:13:44 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:13:44 --> Controller Class Initialized
INFO - 2020-02-04 16:13:44 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:13:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:13:44 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:13:44 --> Helper loaded: form_helper
INFO - 2020-02-04 16:13:44 --> Form Validation Class Initialized
INFO - 2020-02-04 16:13:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:13:44 --> Final output sent to browser
INFO - 2020-02-04 16:13:45 --> Config Class Initialized
INFO - 2020-02-04 16:13:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:45 --> Total execution time: 1.1936
DEBUG - 2020-02-04 16:13:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:45 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:45 --> URI Class Initialized
INFO - 2020-02-04 16:13:45 --> Router Class Initialized
INFO - 2020-02-04 16:13:45 --> Output Class Initialized
INFO - 2020-02-04 16:13:45 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:45 --> Input Class Initialized
INFO - 2020-02-04 16:13:45 --> Language Class Initialized
ERROR - 2020-02-04 16:13:45 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-04 16:13:50 --> Config Class Initialized
INFO - 2020-02-04 16:13:50 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:13:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:13:50 --> Utf8 Class Initialized
INFO - 2020-02-04 16:13:50 --> URI Class Initialized
INFO - 2020-02-04 16:13:50 --> Router Class Initialized
INFO - 2020-02-04 16:13:51 --> Output Class Initialized
INFO - 2020-02-04 16:13:51 --> Security Class Initialized
DEBUG - 2020-02-04 16:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:13:51 --> Input Class Initialized
INFO - 2020-02-04 16:13:51 --> Language Class Initialized
INFO - 2020-02-04 16:13:51 --> Loader Class Initialized
INFO - 2020-02-04 16:13:51 --> Helper loaded: url_helper
INFO - 2020-02-04 16:13:51 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:13:51 --> Controller Class Initialized
INFO - 2020-02-04 16:13:51 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:13:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:13:51 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:13:51 --> Helper loaded: form_helper
INFO - 2020-02-04 16:13:51 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:13:51 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 39
ERROR - 2020-02-04 16:13:51 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\models\M_pesan.php 55
ERROR - 2020-02-04 16:13:51 --> Query error: Column 'id_tiket' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `jumlah_pesanan`, `id_pengunjung`) VALUES (NULL, '1', '10')
INFO - 2020-02-04 16:13:52 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-04 16:14:25 --> Config Class Initialized
INFO - 2020-02-04 16:14:25 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:14:25 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:14:25 --> Utf8 Class Initialized
INFO - 2020-02-04 16:14:25 --> URI Class Initialized
INFO - 2020-02-04 16:14:25 --> Router Class Initialized
INFO - 2020-02-04 16:14:25 --> Output Class Initialized
INFO - 2020-02-04 16:14:25 --> Security Class Initialized
DEBUG - 2020-02-04 16:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:14:25 --> Input Class Initialized
INFO - 2020-02-04 16:14:25 --> Language Class Initialized
INFO - 2020-02-04 16:14:25 --> Loader Class Initialized
INFO - 2020-02-04 16:14:25 --> Helper loaded: url_helper
INFO - 2020-02-04 16:14:26 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:14:26 --> Controller Class Initialized
INFO - 2020-02-04 16:14:26 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:14:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:14:26 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:14:26 --> Helper loaded: form_helper
INFO - 2020-02-04 16:14:26 --> Form Validation Class Initialized
INFO - 2020-02-04 16:14:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:14:26 --> Final output sent to browser
INFO - 2020-02-04 16:14:26 --> Config Class Initialized
INFO - 2020-02-04 16:14:26 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:14:26 --> Total execution time: 1.2890
INFO - 2020-02-04 16:14:26 --> Config Class Initialized
INFO - 2020-02-04 16:14:26 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:14:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:14:26 --> Utf8 Class Initialized
DEBUG - 2020-02-04 16:14:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:14:26 --> Utf8 Class Initialized
INFO - 2020-02-04 16:14:26 --> URI Class Initialized
INFO - 2020-02-04 16:14:26 --> URI Class Initialized
INFO - 2020-02-04 16:14:26 --> Router Class Initialized
INFO - 2020-02-04 16:14:26 --> Router Class Initialized
INFO - 2020-02-04 16:14:26 --> Output Class Initialized
INFO - 2020-02-04 16:14:26 --> Security Class Initialized
INFO - 2020-02-04 16:14:26 --> Output Class Initialized
DEBUG - 2020-02-04 16:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:14:27 --> Security Class Initialized
INFO - 2020-02-04 16:14:27 --> Input Class Initialized
DEBUG - 2020-02-04 16:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:14:27 --> Input Class Initialized
INFO - 2020-02-04 16:14:27 --> Language Class Initialized
INFO - 2020-02-04 16:14:27 --> Language Class Initialized
INFO - 2020-02-04 16:14:27 --> Loader Class Initialized
INFO - 2020-02-04 16:14:27 --> Helper loaded: url_helper
INFO - 2020-02-04 16:14:27 --> Loader Class Initialized
INFO - 2020-02-04 16:14:27 --> Helper loaded: url_helper
INFO - 2020-02-04 16:14:27 --> Database Driver Class Initialized
INFO - 2020-02-04 16:14:27 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:14:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-04 16:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:14:27 --> Controller Class Initialized
INFO - 2020-02-04 16:14:27 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:14:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:14:27 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:14:27 --> Helper loaded: form_helper
INFO - 2020-02-04 16:14:27 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:14:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 16:14:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 16:14:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:14:27 --> Final output sent to browser
DEBUG - 2020-02-04 16:14:27 --> Total execution time: 1.1700
INFO - 2020-02-04 16:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:14:27 --> Controller Class Initialized
INFO - 2020-02-04 16:14:27 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:14:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:14:28 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:14:28 --> Helper loaded: form_helper
INFO - 2020-02-04 16:14:28 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:14:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 16:14:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 16:14:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:14:28 --> Final output sent to browser
DEBUG - 2020-02-04 16:14:28 --> Total execution time: 1.6955
INFO - 2020-02-04 16:14:32 --> Config Class Initialized
INFO - 2020-02-04 16:14:32 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:14:32 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:14:32 --> Utf8 Class Initialized
INFO - 2020-02-04 16:14:32 --> URI Class Initialized
INFO - 2020-02-04 16:14:32 --> Router Class Initialized
INFO - 2020-02-04 16:14:32 --> Output Class Initialized
INFO - 2020-02-04 16:14:32 --> Security Class Initialized
DEBUG - 2020-02-04 16:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:14:32 --> Input Class Initialized
INFO - 2020-02-04 16:14:32 --> Language Class Initialized
INFO - 2020-02-04 16:14:32 --> Loader Class Initialized
INFO - 2020-02-04 16:14:32 --> Helper loaded: url_helper
INFO - 2020-02-04 16:14:32 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:14:32 --> Controller Class Initialized
INFO - 2020-02-04 16:14:32 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:14:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:14:33 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:14:33 --> Helper loaded: form_helper
INFO - 2020-02-04 16:14:33 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:14:33 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 39
ERROR - 2020-02-04 16:14:33 --> Severity: Notice --> Undefined index: id_tiket C:\xampp\htdocs\roadshow\application\models\M_pesan.php 55
ERROR - 2020-02-04 16:14:33 --> Query error: Column 'id_tiket' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `jumlah_pesanan`, `id_pengunjung`) VALUES (NULL, '1', '10')
INFO - 2020-02-04 16:14:33 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-04 16:15:08 --> Config Class Initialized
INFO - 2020-02-04 16:15:09 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:15:09 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:09 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:09 --> URI Class Initialized
INFO - 2020-02-04 16:15:09 --> Router Class Initialized
INFO - 2020-02-04 16:15:09 --> Output Class Initialized
INFO - 2020-02-04 16:15:09 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:09 --> Input Class Initialized
INFO - 2020-02-04 16:15:09 --> Language Class Initialized
INFO - 2020-02-04 16:15:09 --> Loader Class Initialized
INFO - 2020-02-04 16:15:09 --> Helper loaded: url_helper
INFO - 2020-02-04 16:15:09 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:15:10 --> Controller Class Initialized
INFO - 2020-02-04 16:15:10 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:15:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:15:10 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:15:10 --> Helper loaded: form_helper
INFO - 2020-02-04 16:15:10 --> Form Validation Class Initialized
INFO - 2020-02-04 16:15:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:15:10 --> Final output sent to browser
DEBUG - 2020-02-04 16:15:10 --> Total execution time: 1.4174
INFO - 2020-02-04 16:15:10 --> Config Class Initialized
INFO - 2020-02-04 16:15:10 --> Config Class Initialized
INFO - 2020-02-04 16:15:10 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:10 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:15:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:15:10 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:10 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:10 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:10 --> URI Class Initialized
INFO - 2020-02-04 16:15:10 --> URI Class Initialized
INFO - 2020-02-04 16:15:10 --> Router Class Initialized
INFO - 2020-02-04 16:15:10 --> Router Class Initialized
INFO - 2020-02-04 16:15:10 --> Output Class Initialized
INFO - 2020-02-04 16:15:10 --> Output Class Initialized
INFO - 2020-02-04 16:15:10 --> Security Class Initialized
INFO - 2020-02-04 16:15:10 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:10 --> Input Class Initialized
INFO - 2020-02-04 16:15:10 --> Input Class Initialized
INFO - 2020-02-04 16:15:11 --> Language Class Initialized
INFO - 2020-02-04 16:15:11 --> Language Class Initialized
INFO - 2020-02-04 16:15:11 --> Loader Class Initialized
INFO - 2020-02-04 16:15:11 --> Loader Class Initialized
INFO - 2020-02-04 16:15:11 --> Helper loaded: url_helper
INFO - 2020-02-04 16:15:11 --> Helper loaded: url_helper
INFO - 2020-02-04 16:15:11 --> Database Driver Class Initialized
INFO - 2020-02-04 16:15:11 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 16:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:15:11 --> Controller Class Initialized
INFO - 2020-02-04 16:15:11 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:15:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:15:11 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:15:11 --> Helper loaded: form_helper
INFO - 2020-02-04 16:15:11 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:15:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 16:15:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 16:15:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:15:11 --> Final output sent to browser
DEBUG - 2020-02-04 16:15:11 --> Total execution time: 1.1590
INFO - 2020-02-04 16:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:15:11 --> Controller Class Initialized
INFO - 2020-02-04 16:15:11 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:15:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:15:11 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:15:11 --> Helper loaded: form_helper
INFO - 2020-02-04 16:15:12 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:15:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 16:15:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 16:15:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:15:12 --> Final output sent to browser
DEBUG - 2020-02-04 16:15:12 --> Total execution time: 1.6655
INFO - 2020-02-04 16:15:12 --> Config Class Initialized
INFO - 2020-02-04 16:15:12 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:15:12 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:12 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:12 --> URI Class Initialized
INFO - 2020-02-04 16:15:12 --> Router Class Initialized
INFO - 2020-02-04 16:15:12 --> Output Class Initialized
INFO - 2020-02-04 16:15:12 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:12 --> Input Class Initialized
INFO - 2020-02-04 16:15:12 --> Language Class Initialized
INFO - 2020-02-04 16:15:12 --> Loader Class Initialized
INFO - 2020-02-04 16:15:12 --> Helper loaded: url_helper
INFO - 2020-02-04 16:15:12 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:15:12 --> Controller Class Initialized
INFO - 2020-02-04 16:15:12 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:15:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:15:13 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:15:13 --> Helper loaded: form_helper
INFO - 2020-02-04 16:15:13 --> Form Validation Class Initialized
INFO - 2020-02-04 16:15:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:15:13 --> Final output sent to browser
DEBUG - 2020-02-04 16:15:13 --> Total execution time: 1.0031
INFO - 2020-02-04 16:15:13 --> Config Class Initialized
INFO - 2020-02-04 16:15:13 --> Config Class Initialized
INFO - 2020-02-04 16:15:13 --> Config Class Initialized
INFO - 2020-02-04 16:15:13 --> Config Class Initialized
INFO - 2020-02-04 16:15:13 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:13 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:13 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:13 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:13 --> Config Class Initialized
INFO - 2020-02-04 16:15:13 --> Config Class Initialized
INFO - 2020-02-04 16:15:13 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:13 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:15:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:15:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:15:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:15:13 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:13 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:13 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:13 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:13 --> Utf8 Class Initialized
DEBUG - 2020-02-04 16:15:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:15:13 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:13 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:13 --> URI Class Initialized
INFO - 2020-02-04 16:15:13 --> URI Class Initialized
INFO - 2020-02-04 16:15:13 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:13 --> URI Class Initialized
INFO - 2020-02-04 16:15:13 --> URI Class Initialized
INFO - 2020-02-04 16:15:13 --> URI Class Initialized
INFO - 2020-02-04 16:15:13 --> Router Class Initialized
INFO - 2020-02-04 16:15:13 --> Router Class Initialized
INFO - 2020-02-04 16:15:13 --> Router Class Initialized
INFO - 2020-02-04 16:15:13 --> URI Class Initialized
INFO - 2020-02-04 16:15:13 --> Router Class Initialized
INFO - 2020-02-04 16:15:13 --> Router Class Initialized
INFO - 2020-02-04 16:15:13 --> Output Class Initialized
INFO - 2020-02-04 16:15:13 --> Output Class Initialized
INFO - 2020-02-04 16:15:13 --> Output Class Initialized
INFO - 2020-02-04 16:15:13 --> Output Class Initialized
INFO - 2020-02-04 16:15:13 --> Router Class Initialized
INFO - 2020-02-04 16:15:13 --> Security Class Initialized
INFO - 2020-02-04 16:15:13 --> Security Class Initialized
INFO - 2020-02-04 16:15:13 --> Output Class Initialized
INFO - 2020-02-04 16:15:13 --> Output Class Initialized
INFO - 2020-02-04 16:15:13 --> Security Class Initialized
INFO - 2020-02-04 16:15:13 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:13 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:13 --> Security Class Initialized
INFO - 2020-02-04 16:15:13 --> Input Class Initialized
INFO - 2020-02-04 16:15:13 --> Input Class Initialized
INFO - 2020-02-04 16:15:13 --> Input Class Initialized
INFO - 2020-02-04 16:15:13 --> Input Class Initialized
DEBUG - 2020-02-04 16:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:13 --> Language Class Initialized
INFO - 2020-02-04 16:15:13 --> Input Class Initialized
INFO - 2020-02-04 16:15:13 --> Language Class Initialized
INFO - 2020-02-04 16:15:13 --> Language Class Initialized
INFO - 2020-02-04 16:15:13 --> Input Class Initialized
INFO - 2020-02-04 16:15:13 --> Language Class Initialized
INFO - 2020-02-04 16:15:13 --> Language Class Initialized
ERROR - 2020-02-04 16:15:13 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 16:15:13 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 16:15:13 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 16:15:13 --> Language Class Initialized
ERROR - 2020-02-04 16:15:13 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 16:15:13 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 16:15:13 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 16:15:14 --> Config Class Initialized
INFO - 2020-02-04 16:15:14 --> Config Class Initialized
INFO - 2020-02-04 16:15:14 --> Config Class Initialized
INFO - 2020-02-04 16:15:14 --> Config Class Initialized
INFO - 2020-02-04 16:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:14 --> Config Class Initialized
INFO - 2020-02-04 16:15:14 --> Config Class Initialized
INFO - 2020-02-04 16:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:14 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:15:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:14 --> Utf8 Class Initialized
DEBUG - 2020-02-04 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:15:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:14 --> URI Class Initialized
INFO - 2020-02-04 16:15:14 --> URI Class Initialized
INFO - 2020-02-04 16:15:14 --> URI Class Initialized
INFO - 2020-02-04 16:15:14 --> URI Class Initialized
INFO - 2020-02-04 16:15:14 --> Router Class Initialized
INFO - 2020-02-04 16:15:14 --> Router Class Initialized
INFO - 2020-02-04 16:15:14 --> URI Class Initialized
INFO - 2020-02-04 16:15:14 --> URI Class Initialized
INFO - 2020-02-04 16:15:14 --> Router Class Initialized
INFO - 2020-02-04 16:15:14 --> Router Class Initialized
INFO - 2020-02-04 16:15:14 --> Router Class Initialized
INFO - 2020-02-04 16:15:14 --> Output Class Initialized
INFO - 2020-02-04 16:15:14 --> Output Class Initialized
INFO - 2020-02-04 16:15:14 --> Output Class Initialized
INFO - 2020-02-04 16:15:14 --> Router Class Initialized
INFO - 2020-02-04 16:15:14 --> Output Class Initialized
INFO - 2020-02-04 16:15:14 --> Security Class Initialized
INFO - 2020-02-04 16:15:14 --> Output Class Initialized
INFO - 2020-02-04 16:15:14 --> Security Class Initialized
INFO - 2020-02-04 16:15:14 --> Output Class Initialized
INFO - 2020-02-04 16:15:14 --> Security Class Initialized
INFO - 2020-02-04 16:15:14 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:14 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:14 --> Security Class Initialized
INFO - 2020-02-04 16:15:14 --> Input Class Initialized
INFO - 2020-02-04 16:15:14 --> Input Class Initialized
INFO - 2020-02-04 16:15:14 --> Input Class Initialized
INFO - 2020-02-04 16:15:14 --> Input Class Initialized
DEBUG - 2020-02-04 16:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:14 --> Input Class Initialized
INFO - 2020-02-04 16:15:14 --> Input Class Initialized
INFO - 2020-02-04 16:15:14 --> Language Class Initialized
INFO - 2020-02-04 16:15:14 --> Language Class Initialized
INFO - 2020-02-04 16:15:14 --> Language Class Initialized
INFO - 2020-02-04 16:15:14 --> Language Class Initialized
INFO - 2020-02-04 16:15:14 --> Language Class Initialized
INFO - 2020-02-04 16:15:14 --> Language Class Initialized
ERROR - 2020-02-04 16:15:14 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 16:15:14 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-04 16:15:14 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-04 16:15:14 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-04 16:15:14 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 16:15:14 --> Loader Class Initialized
INFO - 2020-02-04 16:15:14 --> Config Class Initialized
INFO - 2020-02-04 16:15:14 --> Config Class Initialized
INFO - 2020-02-04 16:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:14 --> Helper loaded: url_helper
DEBUG - 2020-02-04 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:15:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:14 --> Database Driver Class Initialized
INFO - 2020-02-04 16:15:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:14 --> Utf8 Class Initialized
DEBUG - 2020-02-04 16:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:15:14 --> URI Class Initialized
INFO - 2020-02-04 16:15:14 --> URI Class Initialized
INFO - 2020-02-04 16:15:14 --> Router Class Initialized
INFO - 2020-02-04 16:15:14 --> Router Class Initialized
INFO - 2020-02-04 16:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:15:14 --> Controller Class Initialized
INFO - 2020-02-04 16:15:14 --> Output Class Initialized
INFO - 2020-02-04 16:15:14 --> Output Class Initialized
INFO - 2020-02-04 16:15:14 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:15:14 --> Security Class Initialized
INFO - 2020-02-04 16:15:14 --> Security Class Initialized
INFO - 2020-02-04 16:15:15 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-04 16:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:15 --> Input Class Initialized
INFO - 2020-02-04 16:15:15 --> Input Class Initialized
INFO - 2020-02-04 16:15:15 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:15:15 --> Language Class Initialized
INFO - 2020-02-04 16:15:15 --> Language Class Initialized
INFO - 2020-02-04 16:15:15 --> Helper loaded: form_helper
INFO - 2020-02-04 16:15:15 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:15:15 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 16:15:15 --> Loader Class Initialized
INFO - 2020-02-04 16:15:15 --> Helper loaded: url_helper
ERROR - 2020-02-04 16:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 16:15:15 --> Config Class Initialized
INFO - 2020-02-04 16:15:15 --> Hooks Class Initialized
ERROR - 2020-02-04 16:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 16:15:15 --> Database Driver Class Initialized
INFO - 2020-02-04 16:15:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-04 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:15:15 --> Final output sent to browser
INFO - 2020-02-04 16:15:15 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:15:15 --> Controller Class Initialized
DEBUG - 2020-02-04 16:15:15 --> Total execution time: 1.2396
INFO - 2020-02-04 16:15:15 --> URI Class Initialized
INFO - 2020-02-04 16:15:15 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:15:15 --> Router Class Initialized
INFO - 2020-02-04 16:15:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:15:15 --> Output Class Initialized
INFO - 2020-02-04 16:15:15 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:15:15 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:15 --> Helper loaded: form_helper
INFO - 2020-02-04 16:15:15 --> Form Validation Class Initialized
INFO - 2020-02-04 16:15:15 --> Input Class Initialized
INFO - 2020-02-04 16:15:15 --> Language Class Initialized
ERROR - 2020-02-04 16:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 16:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-04 16:15:15 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 16:15:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:15:15 --> Config Class Initialized
INFO - 2020-02-04 16:15:15 --> Hooks Class Initialized
INFO - 2020-02-04 16:15:15 --> Final output sent to browser
DEBUG - 2020-02-04 16:15:15 --> Total execution time: 1.1493
DEBUG - 2020-02-04 16:15:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:15 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:15 --> URI Class Initialized
INFO - 2020-02-04 16:15:15 --> Router Class Initialized
INFO - 2020-02-04 16:15:15 --> Output Class Initialized
INFO - 2020-02-04 16:15:16 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:16 --> Input Class Initialized
INFO - 2020-02-04 16:15:16 --> Language Class Initialized
ERROR - 2020-02-04 16:15:16 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 16:15:16 --> Config Class Initialized
INFO - 2020-02-04 16:15:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:15:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:16 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:16 --> URI Class Initialized
INFO - 2020-02-04 16:15:16 --> Router Class Initialized
INFO - 2020-02-04 16:15:16 --> Output Class Initialized
INFO - 2020-02-04 16:15:16 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:16 --> Input Class Initialized
INFO - 2020-02-04 16:15:16 --> Language Class Initialized
ERROR - 2020-02-04 16:15:16 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 16:15:16 --> Config Class Initialized
INFO - 2020-02-04 16:15:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:15:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:16 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:17 --> URI Class Initialized
INFO - 2020-02-04 16:15:17 --> Router Class Initialized
INFO - 2020-02-04 16:15:17 --> Output Class Initialized
INFO - 2020-02-04 16:15:17 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:17 --> Input Class Initialized
INFO - 2020-02-04 16:15:17 --> Language Class Initialized
ERROR - 2020-02-04 16:15:17 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 16:15:17 --> Config Class Initialized
INFO - 2020-02-04 16:15:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:15:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:17 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:17 --> URI Class Initialized
INFO - 2020-02-04 16:15:17 --> Router Class Initialized
INFO - 2020-02-04 16:15:17 --> Output Class Initialized
INFO - 2020-02-04 16:15:17 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:17 --> Input Class Initialized
INFO - 2020-02-04 16:15:17 --> Language Class Initialized
ERROR - 2020-02-04 16:15:17 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 16:15:17 --> Config Class Initialized
INFO - 2020-02-04 16:15:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:15:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:18 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:18 --> URI Class Initialized
INFO - 2020-02-04 16:15:18 --> Router Class Initialized
INFO - 2020-02-04 16:15:18 --> Output Class Initialized
INFO - 2020-02-04 16:15:18 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:18 --> Input Class Initialized
INFO - 2020-02-04 16:15:18 --> Language Class Initialized
ERROR - 2020-02-04 16:15:18 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 16:15:18 --> Config Class Initialized
INFO - 2020-02-04 16:15:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:15:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:18 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:18 --> URI Class Initialized
INFO - 2020-02-04 16:15:18 --> Router Class Initialized
INFO - 2020-02-04 16:15:18 --> Output Class Initialized
INFO - 2020-02-04 16:15:18 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:18 --> Input Class Initialized
INFO - 2020-02-04 16:15:18 --> Language Class Initialized
ERROR - 2020-02-04 16:15:19 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 16:15:19 --> Config Class Initialized
INFO - 2020-02-04 16:15:19 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:15:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:19 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:19 --> URI Class Initialized
INFO - 2020-02-04 16:15:19 --> Router Class Initialized
INFO - 2020-02-04 16:15:19 --> Output Class Initialized
INFO - 2020-02-04 16:15:19 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:19 --> Input Class Initialized
INFO - 2020-02-04 16:15:19 --> Language Class Initialized
ERROR - 2020-02-04 16:15:19 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 16:15:19 --> Config Class Initialized
INFO - 2020-02-04 16:15:19 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:15:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:19 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:19 --> URI Class Initialized
INFO - 2020-02-04 16:15:19 --> Router Class Initialized
INFO - 2020-02-04 16:15:19 --> Output Class Initialized
INFO - 2020-02-04 16:15:19 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:20 --> Input Class Initialized
INFO - 2020-02-04 16:15:20 --> Language Class Initialized
ERROR - 2020-02-04 16:15:20 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 16:15:46 --> Config Class Initialized
INFO - 2020-02-04 16:15:46 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:15:46 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:15:46 --> Utf8 Class Initialized
INFO - 2020-02-04 16:15:46 --> URI Class Initialized
INFO - 2020-02-04 16:15:46 --> Router Class Initialized
INFO - 2020-02-04 16:15:46 --> Output Class Initialized
INFO - 2020-02-04 16:15:46 --> Security Class Initialized
DEBUG - 2020-02-04 16:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:15:46 --> Input Class Initialized
INFO - 2020-02-04 16:15:46 --> Language Class Initialized
INFO - 2020-02-04 16:15:46 --> Loader Class Initialized
INFO - 2020-02-04 16:15:46 --> Helper loaded: url_helper
INFO - 2020-02-04 16:15:47 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:15:47 --> Controller Class Initialized
INFO - 2020-02-04 16:15:47 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:15:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:15:47 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:15:47 --> Helper loaded: form_helper
INFO - 2020-02-04 16:15:47 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:15:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 42
ERROR - 2020-02-04 16:15:47 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('33', '2', NULL)
INFO - 2020-02-04 16:15:47 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-04 16:16:08 --> Config Class Initialized
INFO - 2020-02-04 16:16:08 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:08 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:08 --> URI Class Initialized
INFO - 2020-02-04 16:16:09 --> Router Class Initialized
INFO - 2020-02-04 16:16:09 --> Output Class Initialized
INFO - 2020-02-04 16:16:09 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:09 --> Input Class Initialized
INFO - 2020-02-04 16:16:09 --> Language Class Initialized
INFO - 2020-02-04 16:16:09 --> Loader Class Initialized
INFO - 2020-02-04 16:16:09 --> Helper loaded: url_helper
INFO - 2020-02-04 16:16:09 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:16:09 --> Controller Class Initialized
INFO - 2020-02-04 16:16:09 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:16:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:16:09 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:16:09 --> Helper loaded: form_helper
INFO - 2020-02-04 16:16:09 --> Form Validation Class Initialized
INFO - 2020-02-04 16:16:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:16:09 --> Final output sent to browser
INFO - 2020-02-04 16:16:10 --> Config Class Initialized
INFO - 2020-02-04 16:16:10 --> Config Class Initialized
INFO - 2020-02-04 16:16:10 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:10 --> Total execution time: 1.6568
INFO - 2020-02-04 16:16:10 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:16:10 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:10 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:10 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:10 --> URI Class Initialized
INFO - 2020-02-04 16:16:10 --> URI Class Initialized
INFO - 2020-02-04 16:16:10 --> Router Class Initialized
INFO - 2020-02-04 16:16:10 --> Router Class Initialized
INFO - 2020-02-04 16:16:10 --> Output Class Initialized
INFO - 2020-02-04 16:16:10 --> Output Class Initialized
INFO - 2020-02-04 16:16:10 --> Security Class Initialized
INFO - 2020-02-04 16:16:10 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:10 --> Input Class Initialized
INFO - 2020-02-04 16:16:10 --> Input Class Initialized
INFO - 2020-02-04 16:16:10 --> Language Class Initialized
INFO - 2020-02-04 16:16:10 --> Language Class Initialized
INFO - 2020-02-04 16:16:10 --> Loader Class Initialized
INFO - 2020-02-04 16:16:10 --> Loader Class Initialized
INFO - 2020-02-04 16:16:10 --> Helper loaded: url_helper
INFO - 2020-02-04 16:16:10 --> Helper loaded: url_helper
INFO - 2020-02-04 16:16:10 --> Database Driver Class Initialized
INFO - 2020-02-04 16:16:10 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 16:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:16:10 --> Controller Class Initialized
INFO - 2020-02-04 16:16:10 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:16:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:16:11 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:16:11 --> Helper loaded: form_helper
INFO - 2020-02-04 16:16:11 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 16:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 16:16:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:16:11 --> Final output sent to browser
DEBUG - 2020-02-04 16:16:11 --> Total execution time: 1.2117
INFO - 2020-02-04 16:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:16:11 --> Controller Class Initialized
INFO - 2020-02-04 16:16:11 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:16:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:16:11 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:16:11 --> Helper loaded: form_helper
INFO - 2020-02-04 16:16:11 --> Form Validation Class Initialized
ERROR - 2020-02-04 16:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-04 16:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 16:16:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:16:11 --> Final output sent to browser
DEBUG - 2020-02-04 16:16:11 --> Total execution time: 1.7928
INFO - 2020-02-04 16:16:12 --> Config Class Initialized
INFO - 2020-02-04 16:16:12 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:12 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:13 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:13 --> URI Class Initialized
INFO - 2020-02-04 16:16:13 --> Router Class Initialized
INFO - 2020-02-04 16:16:13 --> Output Class Initialized
INFO - 2020-02-04 16:16:13 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:13 --> Input Class Initialized
INFO - 2020-02-04 16:16:13 --> Language Class Initialized
INFO - 2020-02-04 16:16:13 --> Loader Class Initialized
INFO - 2020-02-04 16:16:13 --> Helper loaded: url_helper
INFO - 2020-02-04 16:16:13 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:16:13 --> Controller Class Initialized
INFO - 2020-02-04 16:16:13 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:16:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:16:13 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:16:13 --> Helper loaded: form_helper
INFO - 2020-02-04 16:16:13 --> Form Validation Class Initialized
INFO - 2020-02-04 16:16:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-04 16:16:13 --> Final output sent to browser
DEBUG - 2020-02-04 16:16:13 --> Total execution time: 1.0516
INFO - 2020-02-04 16:16:14 --> Config Class Initialized
INFO - 2020-02-04 16:16:14 --> Config Class Initialized
INFO - 2020-02-04 16:16:14 --> Config Class Initialized
INFO - 2020-02-04 16:16:14 --> Config Class Initialized
INFO - 2020-02-04 16:16:14 --> Config Class Initialized
INFO - 2020-02-04 16:16:14 --> Config Class Initialized
INFO - 2020-02-04 16:16:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:16:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:16:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:16:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:16:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:16:14 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:16:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:16:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:16:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:16:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:16:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:14 --> URI Class Initialized
INFO - 2020-02-04 16:16:14 --> URI Class Initialized
INFO - 2020-02-04 16:16:14 --> URI Class Initialized
INFO - 2020-02-04 16:16:14 --> URI Class Initialized
INFO - 2020-02-04 16:16:14 --> URI Class Initialized
INFO - 2020-02-04 16:16:14 --> URI Class Initialized
INFO - 2020-02-04 16:16:14 --> Router Class Initialized
INFO - 2020-02-04 16:16:14 --> Router Class Initialized
INFO - 2020-02-04 16:16:14 --> Router Class Initialized
INFO - 2020-02-04 16:16:14 --> Router Class Initialized
INFO - 2020-02-04 16:16:14 --> Router Class Initialized
INFO - 2020-02-04 16:16:14 --> Router Class Initialized
INFO - 2020-02-04 16:16:14 --> Output Class Initialized
INFO - 2020-02-04 16:16:14 --> Output Class Initialized
INFO - 2020-02-04 16:16:14 --> Output Class Initialized
INFO - 2020-02-04 16:16:14 --> Output Class Initialized
INFO - 2020-02-04 16:16:14 --> Output Class Initialized
INFO - 2020-02-04 16:16:14 --> Output Class Initialized
INFO - 2020-02-04 16:16:14 --> Security Class Initialized
INFO - 2020-02-04 16:16:14 --> Security Class Initialized
INFO - 2020-02-04 16:16:14 --> Security Class Initialized
INFO - 2020-02-04 16:16:14 --> Security Class Initialized
INFO - 2020-02-04 16:16:14 --> Security Class Initialized
INFO - 2020-02-04 16:16:14 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-04 16:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:14 --> Input Class Initialized
INFO - 2020-02-04 16:16:14 --> Input Class Initialized
INFO - 2020-02-04 16:16:14 --> Input Class Initialized
INFO - 2020-02-04 16:16:14 --> Input Class Initialized
INFO - 2020-02-04 16:16:14 --> Input Class Initialized
INFO - 2020-02-04 16:16:14 --> Input Class Initialized
INFO - 2020-02-04 16:16:14 --> Language Class Initialized
INFO - 2020-02-04 16:16:14 --> Language Class Initialized
INFO - 2020-02-04 16:16:14 --> Language Class Initialized
INFO - 2020-02-04 16:16:14 --> Language Class Initialized
INFO - 2020-02-04 16:16:14 --> Language Class Initialized
ERROR - 2020-02-04 16:16:14 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 16:16:14 --> Language Class Initialized
ERROR - 2020-02-04 16:16:14 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-04 16:16:14 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-04 16:16:14 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 16:16:14 --> Loader Class Initialized
INFO - 2020-02-04 16:16:14 --> Loader Class Initialized
INFO - 2020-02-04 16:16:14 --> Config Class Initialized
INFO - 2020-02-04 16:16:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:16:14 --> Helper loaded: url_helper
INFO - 2020-02-04 16:16:14 --> Helper loaded: url_helper
INFO - 2020-02-04 16:16:14 --> Config Class Initialized
INFO - 2020-02-04 16:16:14 --> Config Class Initialized
INFO - 2020-02-04 16:16:14 --> Hooks Class Initialized
INFO - 2020-02-04 16:16:14 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:14 --> Config Class Initialized
INFO - 2020-02-04 16:16:14 --> Database Driver Class Initialized
INFO - 2020-02-04 16:16:14 --> Database Driver Class Initialized
INFO - 2020-02-04 16:16:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:14 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:16:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-04 16:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:16:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:16:14 --> URI Class Initialized
DEBUG - 2020-02-04 16:16:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:14 --> Controller Class Initialized
INFO - 2020-02-04 16:16:14 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:14 --> URI Class Initialized
INFO - 2020-02-04 16:16:14 --> URI Class Initialized
INFO - 2020-02-04 16:16:14 --> Router Class Initialized
INFO - 2020-02-04 16:16:15 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:16:15 --> URI Class Initialized
INFO - 2020-02-04 16:16:15 --> Router Class Initialized
INFO - 2020-02-04 16:16:15 --> Router Class Initialized
INFO - 2020-02-04 16:16:15 --> Output Class Initialized
INFO - 2020-02-04 16:16:15 --> Security Class Initialized
INFO - 2020-02-04 16:16:15 --> Output Class Initialized
INFO - 2020-02-04 16:16:15 --> Output Class Initialized
INFO - 2020-02-04 16:16:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:16:15 --> Router Class Initialized
DEBUG - 2020-02-04 16:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:15 --> Security Class Initialized
INFO - 2020-02-04 16:16:15 --> Security Class Initialized
INFO - 2020-02-04 16:16:15 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:16:15 --> Output Class Initialized
DEBUG - 2020-02-04 16:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:15 --> Security Class Initialized
INFO - 2020-02-04 16:16:15 --> Input Class Initialized
DEBUG - 2020-02-04 16:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:15 --> Helper loaded: form_helper
INFO - 2020-02-04 16:16:15 --> Form Validation Class Initialized
INFO - 2020-02-04 16:16:15 --> Input Class Initialized
INFO - 2020-02-04 16:16:15 --> Input Class Initialized
INFO - 2020-02-04 16:16:15 --> Language Class Initialized
DEBUG - 2020-02-04 16:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:15 --> Input Class Initialized
INFO - 2020-02-04 16:16:15 --> Language Class Initialized
INFO - 2020-02-04 16:16:15 --> Language Class Initialized
ERROR - 2020-02-04 16:16:15 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-04 16:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 16:16:15 --> Language Class Initialized
ERROR - 2020-02-04 16:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-04 16:16:15 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-04 16:16:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 16:16:15 --> Config Class Initialized
INFO - 2020-02-04 16:16:15 --> Hooks Class Initialized
INFO - 2020-02-04 16:16:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-04 16:16:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 16:16:15 --> Config Class Initialized
INFO - 2020-02-04 16:16:15 --> Config Class Initialized
INFO - 2020-02-04 16:16:15 --> Hooks Class Initialized
INFO - 2020-02-04 16:16:15 --> Hooks Class Initialized
INFO - 2020-02-04 16:16:15 --> Final output sent to browser
DEBUG - 2020-02-04 16:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:15 --> Config Class Initialized
INFO - 2020-02-04 16:16:15 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:15 --> Total execution time: 1.4018
INFO - 2020-02-04 16:16:15 --> Utf8 Class Initialized
DEBUG - 2020-02-04 16:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-04 16:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:15 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:16:15 --> URI Class Initialized
INFO - 2020-02-04 16:16:15 --> Utf8 Class Initialized
DEBUG - 2020-02-04 16:16:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:15 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:15 --> Controller Class Initialized
INFO - 2020-02-04 16:16:15 --> URI Class Initialized
INFO - 2020-02-04 16:16:15 --> URI Class Initialized
INFO - 2020-02-04 16:16:15 --> Router Class Initialized
INFO - 2020-02-04 16:16:15 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:16:15 --> URI Class Initialized
INFO - 2020-02-04 16:16:15 --> Router Class Initialized
INFO - 2020-02-04 16:16:15 --> Router Class Initialized
INFO - 2020-02-04 16:16:15 --> Output Class Initialized
INFO - 2020-02-04 16:16:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:16:15 --> Output Class Initialized
INFO - 2020-02-04 16:16:15 --> Output Class Initialized
INFO - 2020-02-04 16:16:15 --> Router Class Initialized
INFO - 2020-02-04 16:16:15 --> Security Class Initialized
INFO - 2020-02-04 16:16:15 --> Model "M_pesan" initialized
DEBUG - 2020-02-04 16:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:15 --> Output Class Initialized
INFO - 2020-02-04 16:16:15 --> Security Class Initialized
INFO - 2020-02-04 16:16:15 --> Security Class Initialized
INFO - 2020-02-04 16:16:15 --> Input Class Initialized
DEBUG - 2020-02-04 16:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:15 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:15 --> Helper loaded: form_helper
INFO - 2020-02-04 16:16:15 --> Form Validation Class Initialized
INFO - 2020-02-04 16:16:15 --> Input Class Initialized
INFO - 2020-02-04 16:16:15 --> Input Class Initialized
INFO - 2020-02-04 16:16:15 --> Language Class Initialized
DEBUG - 2020-02-04 16:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:15 --> Input Class Initialized
INFO - 2020-02-04 16:16:15 --> Language Class Initialized
INFO - 2020-02-04 16:16:15 --> Language Class Initialized
ERROR - 2020-02-04 16:16:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-04 16:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-04 16:16:15 --> Language Class Initialized
ERROR - 2020-02-04 16:16:15 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-04 16:16:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-04 16:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-04 16:16:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-04 16:16:15 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-04 16:16:16 --> Final output sent to browser
INFO - 2020-02-04 16:16:16 --> Config Class Initialized
INFO - 2020-02-04 16:16:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:16 --> Total execution time: 1.8344
DEBUG - 2020-02-04 16:16:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:16 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:16 --> URI Class Initialized
INFO - 2020-02-04 16:16:16 --> Router Class Initialized
INFO - 2020-02-04 16:16:16 --> Output Class Initialized
INFO - 2020-02-04 16:16:16 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:16 --> Input Class Initialized
INFO - 2020-02-04 16:16:16 --> Language Class Initialized
ERROR - 2020-02-04 16:16:16 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-04 16:16:16 --> Config Class Initialized
INFO - 2020-02-04 16:16:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:16 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:16 --> URI Class Initialized
INFO - 2020-02-04 16:16:16 --> Router Class Initialized
INFO - 2020-02-04 16:16:16 --> Output Class Initialized
INFO - 2020-02-04 16:16:16 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:16 --> Input Class Initialized
INFO - 2020-02-04 16:16:17 --> Language Class Initialized
ERROR - 2020-02-04 16:16:17 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-04 16:16:17 --> Config Class Initialized
INFO - 2020-02-04 16:16:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:17 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:17 --> URI Class Initialized
INFO - 2020-02-04 16:16:17 --> Router Class Initialized
INFO - 2020-02-04 16:16:17 --> Output Class Initialized
INFO - 2020-02-04 16:16:17 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:17 --> Input Class Initialized
INFO - 2020-02-04 16:16:17 --> Language Class Initialized
ERROR - 2020-02-04 16:16:17 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-04 16:16:17 --> Config Class Initialized
INFO - 2020-02-04 16:16:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:17 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:17 --> URI Class Initialized
INFO - 2020-02-04 16:16:17 --> Router Class Initialized
INFO - 2020-02-04 16:16:17 --> Output Class Initialized
INFO - 2020-02-04 16:16:18 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:18 --> Input Class Initialized
INFO - 2020-02-04 16:16:18 --> Language Class Initialized
ERROR - 2020-02-04 16:16:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 16:16:18 --> Config Class Initialized
INFO - 2020-02-04 16:16:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:18 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:18 --> URI Class Initialized
INFO - 2020-02-04 16:16:18 --> Router Class Initialized
INFO - 2020-02-04 16:16:18 --> Output Class Initialized
INFO - 2020-02-04 16:16:18 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:18 --> Input Class Initialized
INFO - 2020-02-04 16:16:18 --> Language Class Initialized
ERROR - 2020-02-04 16:16:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-04 16:16:18 --> Config Class Initialized
INFO - 2020-02-04 16:16:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:18 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:19 --> URI Class Initialized
INFO - 2020-02-04 16:16:19 --> Router Class Initialized
INFO - 2020-02-04 16:16:19 --> Output Class Initialized
INFO - 2020-02-04 16:16:19 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:19 --> Input Class Initialized
INFO - 2020-02-04 16:16:19 --> Language Class Initialized
ERROR - 2020-02-04 16:16:19 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-04 16:16:19 --> Config Class Initialized
INFO - 2020-02-04 16:16:19 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:19 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:19 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:19 --> URI Class Initialized
INFO - 2020-02-04 16:16:19 --> Router Class Initialized
INFO - 2020-02-04 16:16:19 --> Output Class Initialized
INFO - 2020-02-04 16:16:19 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:19 --> Input Class Initialized
INFO - 2020-02-04 16:16:19 --> Language Class Initialized
ERROR - 2020-02-04 16:16:19 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-04 16:16:19 --> Config Class Initialized
INFO - 2020-02-04 16:16:19 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:20 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:20 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:20 --> URI Class Initialized
INFO - 2020-02-04 16:16:20 --> Router Class Initialized
INFO - 2020-02-04 16:16:20 --> Output Class Initialized
INFO - 2020-02-04 16:16:20 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:20 --> Input Class Initialized
INFO - 2020-02-04 16:16:20 --> Language Class Initialized
ERROR - 2020-02-04 16:16:20 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-04 16:16:20 --> Config Class Initialized
INFO - 2020-02-04 16:16:20 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:20 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:20 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:20 --> URI Class Initialized
INFO - 2020-02-04 16:16:20 --> Router Class Initialized
INFO - 2020-02-04 16:16:20 --> Output Class Initialized
INFO - 2020-02-04 16:16:20 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:20 --> Input Class Initialized
INFO - 2020-02-04 16:16:20 --> Language Class Initialized
ERROR - 2020-02-04 16:16:21 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-04 16:16:26 --> Config Class Initialized
INFO - 2020-02-04 16:16:26 --> Hooks Class Initialized
DEBUG - 2020-02-04 16:16:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 16:16:26 --> Utf8 Class Initialized
INFO - 2020-02-04 16:16:26 --> URI Class Initialized
INFO - 2020-02-04 16:16:26 --> Router Class Initialized
INFO - 2020-02-04 16:16:26 --> Output Class Initialized
INFO - 2020-02-04 16:16:26 --> Security Class Initialized
DEBUG - 2020-02-04 16:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 16:16:26 --> Input Class Initialized
INFO - 2020-02-04 16:16:27 --> Language Class Initialized
INFO - 2020-02-04 16:16:27 --> Loader Class Initialized
INFO - 2020-02-04 16:16:27 --> Helper loaded: url_helper
INFO - 2020-02-04 16:16:27 --> Database Driver Class Initialized
DEBUG - 2020-02-04 16:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 16:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 16:16:27 --> Controller Class Initialized
INFO - 2020-02-04 16:16:27 --> Model "M_tiket" initialized
INFO - 2020-02-04 16:16:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-04 16:16:27 --> Model "M_pesan" initialized
INFO - 2020-02-04 16:16:27 --> Helper loaded: form_helper
INFO - 2020-02-04 16:16:27 --> Form Validation Class Initialized
INFO - 2020-02-04 16:16:27 --> Final output sent to browser
DEBUG - 2020-02-04 16:16:27 --> Total execution time: 1.1905
