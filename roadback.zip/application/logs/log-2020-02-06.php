<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-06 04:01:12 --> Config Class Initialized
INFO - 2020-02-06 04:01:12 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:01:13 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:13 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:13 --> URI Class Initialized
DEBUG - 2020-02-06 04:01:13 --> No URI present. Default controller set.
INFO - 2020-02-06 04:01:13 --> Router Class Initialized
INFO - 2020-02-06 04:01:13 --> Output Class Initialized
INFO - 2020-02-06 04:01:14 --> Security Class Initialized
DEBUG - 2020-02-06 04:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:14 --> Input Class Initialized
INFO - 2020-02-06 04:01:14 --> Language Class Initialized
INFO - 2020-02-06 04:01:14 --> Loader Class Initialized
INFO - 2020-02-06 04:01:14 --> Helper loaded: url_helper
INFO - 2020-02-06 04:01:15 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:01:15 --> Controller Class Initialized
INFO - 2020-02-06 04:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-06 04:01:15 --> Pagination Class Initialized
INFO - 2020-02-06 04:01:15 --> Model "M_show" initialized
INFO - 2020-02-06 04:01:16 --> Helper loaded: form_helper
INFO - 2020-02-06 04:01:16 --> Form Validation Class Initialized
INFO - 2020-02-06 04:01:16 --> Config Class Initialized
INFO - 2020-02-06 04:01:16 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:01:16 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:16 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:16 --> URI Class Initialized
INFO - 2020-02-06 04:01:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-06 04:01:16 --> Final output sent to browser
DEBUG - 2020-02-06 04:01:16 --> No URI present. Default controller set.
DEBUG - 2020-02-06 04:01:16 --> Total execution time: 4.3662
INFO - 2020-02-06 04:01:16 --> Router Class Initialized
INFO - 2020-02-06 04:01:17 --> Output Class Initialized
INFO - 2020-02-06 04:01:17 --> Security Class Initialized
DEBUG - 2020-02-06 04:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:17 --> Input Class Initialized
INFO - 2020-02-06 04:01:17 --> Language Class Initialized
INFO - 2020-02-06 04:01:17 --> Loader Class Initialized
INFO - 2020-02-06 04:01:17 --> Helper loaded: url_helper
INFO - 2020-02-06 04:01:17 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:01:17 --> Controller Class Initialized
INFO - 2020-02-06 04:01:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-06 04:01:17 --> Pagination Class Initialized
INFO - 2020-02-06 04:01:17 --> Model "M_show" initialized
INFO - 2020-02-06 04:01:17 --> Helper loaded: form_helper
INFO - 2020-02-06 04:01:17 --> Form Validation Class Initialized
INFO - 2020-02-06 04:01:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-06 04:01:17 --> Final output sent to browser
DEBUG - 2020-02-06 04:01:17 --> Total execution time: 1.2359
INFO - 2020-02-06 04:01:28 --> Config Class Initialized
INFO - 2020-02-06 04:01:28 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:01:28 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:28 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:29 --> URI Class Initialized
INFO - 2020-02-06 04:01:29 --> Router Class Initialized
INFO - 2020-02-06 04:01:29 --> Output Class Initialized
INFO - 2020-02-06 04:01:29 --> Security Class Initialized
DEBUG - 2020-02-06 04:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:29 --> Input Class Initialized
INFO - 2020-02-06 04:01:29 --> Language Class Initialized
INFO - 2020-02-06 04:01:29 --> Loader Class Initialized
INFO - 2020-02-06 04:01:29 --> Helper loaded: url_helper
INFO - 2020-02-06 04:01:29 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:01:29 --> Controller Class Initialized
INFO - 2020-02-06 04:01:30 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:01:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:01:30 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:01:30 --> Helper loaded: form_helper
INFO - 2020-02-06 04:01:30 --> Form Validation Class Initialized
INFO - 2020-02-06 04:01:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:01:30 --> Final output sent to browser
DEBUG - 2020-02-06 04:01:30 --> Total execution time: 1.8725
INFO - 2020-02-06 04:01:30 --> Config Class Initialized
INFO - 2020-02-06 04:01:30 --> Config Class Initialized
INFO - 2020-02-06 04:01:30 --> Config Class Initialized
INFO - 2020-02-06 04:01:30 --> Hooks Class Initialized
INFO - 2020-02-06 04:01:30 --> Hooks Class Initialized
INFO - 2020-02-06 04:01:30 --> Config Class Initialized
INFO - 2020-02-06 04:01:30 --> Hooks Class Initialized
INFO - 2020-02-06 04:01:30 --> Hooks Class Initialized
INFO - 2020-02-06 04:01:30 --> Config Class Initialized
DEBUG - 2020-02-06 04:01:30 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:01:30 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:30 --> Config Class Initialized
INFO - 2020-02-06 04:01:30 --> Hooks Class Initialized
INFO - 2020-02-06 04:01:30 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:30 --> Hooks Class Initialized
INFO - 2020-02-06 04:01:30 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:01:30 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:01:30 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:30 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:30 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
DEBUG - 2020-02-06 04:01:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:01:31 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:31 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
INFO - 2020-02-06 04:01:31 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
INFO - 2020-02-06 04:01:31 --> Loader Class Initialized
INFO - 2020-02-06 04:01:31 --> Loader Class Initialized
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
INFO - 2020-02-06 04:01:31 --> Helper loaded: url_helper
INFO - 2020-02-06 04:01:31 --> Helper loaded: url_helper
INFO - 2020-02-06 04:01:31 --> Database Driver Class Initialized
INFO - 2020-02-06 04:01:31 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-06 04:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:01:31 --> Controller Class Initialized
ERROR - 2020-02-06 04:01:31 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-06 04:01:31 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-06 04:01:31 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-06 04:01:31 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-06 04:01:31 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:01:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:01:31 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:01:31 --> Helper loaded: form_helper
INFO - 2020-02-06 04:01:31 --> Form Validation Class Initialized
INFO - 2020-02-06 04:01:31 --> Config Class Initialized
INFO - 2020-02-06 04:01:31 --> Config Class Initialized
INFO - 2020-02-06 04:01:31 --> Config Class Initialized
INFO - 2020-02-06 04:01:31 --> Config Class Initialized
INFO - 2020-02-06 04:01:31 --> Hooks Class Initialized
INFO - 2020-02-06 04:01:31 --> Hooks Class Initialized
INFO - 2020-02-06 04:01:31 --> Hooks Class Initialized
INFO - 2020-02-06 04:01:31 --> Hooks Class Initialized
ERROR - 2020-02-06 04:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
DEBUG - 2020-02-06 04:01:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:01:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:01:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:01:31 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:31 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:31 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:31 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:31 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
ERROR - 2020-02-06 04:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:01:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
INFO - 2020-02-06 04:01:31 --> Final output sent to browser
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
DEBUG - 2020-02-06 04:01:31 --> Total execution time: 0.6843
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
INFO - 2020-02-06 04:01:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:31 --> Config Class Initialized
INFO - 2020-02-06 04:01:31 --> Hooks Class Initialized
INFO - 2020-02-06 04:01:31 --> Controller Class Initialized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
INFO - 2020-02-06 04:01:31 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
DEBUG - 2020-02-06 04:01:31 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:31 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:31 --> Model "M_pengunjung" initialized
ERROR - 2020-02-06 04:01:31 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-06 04:01:31 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-06 04:01:31 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-06 04:01:31 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-06 04:01:31 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
INFO - 2020-02-06 04:01:31 --> Helper loaded: form_helper
INFO - 2020-02-06 04:01:31 --> Config Class Initialized
INFO - 2020-02-06 04:01:31 --> Config Class Initialized
INFO - 2020-02-06 04:01:31 --> Config Class Initialized
INFO - 2020-02-06 04:01:31 --> Hooks Class Initialized
INFO - 2020-02-06 04:01:31 --> Hooks Class Initialized
INFO - 2020-02-06 04:01:31 --> Form Validation Class Initialized
INFO - 2020-02-06 04:01:31 --> Hooks Class Initialized
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
DEBUG - 2020-02-06 04:01:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:01:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:01:31 --> UTF-8 Support Enabled
ERROR - 2020-02-06 04:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-06 04:01:31 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:31 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:31 --> Utf8 Class Initialized
ERROR - 2020-02-06 04:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
INFO - 2020-02-06 04:01:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
INFO - 2020-02-06 04:01:31 --> URI Class Initialized
INFO - 2020-02-06 04:01:31 --> Final output sent to browser
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
INFO - 2020-02-06 04:01:31 --> Router Class Initialized
DEBUG - 2020-02-06 04:01:31 --> Total execution time: 0.9559
ERROR - 2020-02-06 04:01:31 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
INFO - 2020-02-06 04:01:31 --> Output Class Initialized
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
INFO - 2020-02-06 04:01:31 --> Security Class Initialized
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
INFO - 2020-02-06 04:01:31 --> Input Class Initialized
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
INFO - 2020-02-06 04:01:31 --> Language Class Initialized
ERROR - 2020-02-06 04:01:32 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-06 04:01:32 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-06 04:01:32 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-06 04:01:32 --> Config Class Initialized
INFO - 2020-02-06 04:01:32 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:01:32 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:32 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:32 --> URI Class Initialized
INFO - 2020-02-06 04:01:32 --> Router Class Initialized
INFO - 2020-02-06 04:01:32 --> Output Class Initialized
INFO - 2020-02-06 04:01:32 --> Security Class Initialized
DEBUG - 2020-02-06 04:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:32 --> Input Class Initialized
INFO - 2020-02-06 04:01:32 --> Language Class Initialized
ERROR - 2020-02-06 04:01:32 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-06 04:01:32 --> Config Class Initialized
INFO - 2020-02-06 04:01:32 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:01:32 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:32 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:32 --> URI Class Initialized
INFO - 2020-02-06 04:01:32 --> Router Class Initialized
INFO - 2020-02-06 04:01:32 --> Output Class Initialized
INFO - 2020-02-06 04:01:32 --> Security Class Initialized
DEBUG - 2020-02-06 04:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:32 --> Input Class Initialized
INFO - 2020-02-06 04:01:32 --> Language Class Initialized
ERROR - 2020-02-06 04:01:32 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:01:32 --> Config Class Initialized
INFO - 2020-02-06 04:01:32 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:01:32 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:32 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:32 --> URI Class Initialized
INFO - 2020-02-06 04:01:32 --> Router Class Initialized
INFO - 2020-02-06 04:01:32 --> Output Class Initialized
INFO - 2020-02-06 04:01:32 --> Security Class Initialized
DEBUG - 2020-02-06 04:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:32 --> Input Class Initialized
INFO - 2020-02-06 04:01:32 --> Language Class Initialized
ERROR - 2020-02-06 04:01:32 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:01:32 --> Config Class Initialized
INFO - 2020-02-06 04:01:32 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:01:32 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:32 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:32 --> URI Class Initialized
INFO - 2020-02-06 04:01:32 --> Router Class Initialized
INFO - 2020-02-06 04:01:32 --> Output Class Initialized
INFO - 2020-02-06 04:01:33 --> Security Class Initialized
DEBUG - 2020-02-06 04:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:33 --> Input Class Initialized
INFO - 2020-02-06 04:01:33 --> Language Class Initialized
ERROR - 2020-02-06 04:01:33 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-06 04:01:33 --> Config Class Initialized
INFO - 2020-02-06 04:01:33 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:01:33 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:33 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:33 --> URI Class Initialized
INFO - 2020-02-06 04:01:33 --> Router Class Initialized
INFO - 2020-02-06 04:01:33 --> Output Class Initialized
INFO - 2020-02-06 04:01:33 --> Security Class Initialized
DEBUG - 2020-02-06 04:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:33 --> Input Class Initialized
INFO - 2020-02-06 04:01:33 --> Language Class Initialized
ERROR - 2020-02-06 04:01:33 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-06 04:01:33 --> Config Class Initialized
INFO - 2020-02-06 04:01:33 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:01:33 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:33 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:33 --> URI Class Initialized
INFO - 2020-02-06 04:01:33 --> Router Class Initialized
INFO - 2020-02-06 04:01:33 --> Output Class Initialized
INFO - 2020-02-06 04:01:33 --> Security Class Initialized
DEBUG - 2020-02-06 04:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:33 --> Input Class Initialized
INFO - 2020-02-06 04:01:33 --> Language Class Initialized
ERROR - 2020-02-06 04:01:33 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-06 04:01:33 --> Config Class Initialized
INFO - 2020-02-06 04:01:33 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:01:33 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:01:33 --> Utf8 Class Initialized
INFO - 2020-02-06 04:01:33 --> URI Class Initialized
INFO - 2020-02-06 04:01:33 --> Router Class Initialized
INFO - 2020-02-06 04:01:33 --> Output Class Initialized
INFO - 2020-02-06 04:01:33 --> Security Class Initialized
DEBUG - 2020-02-06 04:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:01:33 --> Input Class Initialized
INFO - 2020-02-06 04:01:33 --> Language Class Initialized
ERROR - 2020-02-06 04:01:33 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-06 04:05:47 --> Config Class Initialized
INFO - 2020-02-06 04:05:47 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:05:47 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:05:47 --> Utf8 Class Initialized
INFO - 2020-02-06 04:05:47 --> URI Class Initialized
INFO - 2020-02-06 04:05:47 --> Router Class Initialized
INFO - 2020-02-06 04:05:47 --> Output Class Initialized
INFO - 2020-02-06 04:05:47 --> Security Class Initialized
DEBUG - 2020-02-06 04:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:05:47 --> Input Class Initialized
INFO - 2020-02-06 04:05:47 --> Language Class Initialized
INFO - 2020-02-06 04:05:47 --> Loader Class Initialized
INFO - 2020-02-06 04:05:47 --> Helper loaded: url_helper
INFO - 2020-02-06 04:05:47 --> Database Driver Class Initialized
ERROR - 2020-02-06 04:05:47 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::gc) C:\xampp\htdocs\roadshow\system\libraries\Session\drivers\Session_files_driver.php 49
INFO - 2020-02-06 04:05:59 --> Config Class Initialized
INFO - 2020-02-06 04:05:59 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:05:59 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:05:59 --> Utf8 Class Initialized
INFO - 2020-02-06 04:05:59 --> URI Class Initialized
INFO - 2020-02-06 04:05:59 --> Router Class Initialized
INFO - 2020-02-06 04:05:59 --> Output Class Initialized
INFO - 2020-02-06 04:05:59 --> Security Class Initialized
DEBUG - 2020-02-06 04:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:05:59 --> Input Class Initialized
INFO - 2020-02-06 04:05:59 --> Language Class Initialized
INFO - 2020-02-06 04:05:59 --> Loader Class Initialized
INFO - 2020-02-06 04:05:59 --> Helper loaded: url_helper
INFO - 2020-02-06 04:05:59 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:05:59 --> Controller Class Initialized
INFO - 2020-02-06 04:06:00 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:06:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:06:00 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:06:00 --> Helper loaded: form_helper
INFO - 2020-02-06 04:06:00 --> Form Validation Class Initialized
INFO - 2020-02-06 04:06:00 --> Final output sent to browser
DEBUG - 2020-02-06 04:06:00 --> Total execution time: 0.7124
INFO - 2020-02-06 04:08:02 --> Config Class Initialized
INFO - 2020-02-06 04:08:02 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:08:02 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:08:02 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:02 --> URI Class Initialized
INFO - 2020-02-06 04:08:02 --> Router Class Initialized
INFO - 2020-02-06 04:08:02 --> Output Class Initialized
INFO - 2020-02-06 04:08:02 --> Security Class Initialized
DEBUG - 2020-02-06 04:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:08:02 --> Input Class Initialized
INFO - 2020-02-06 04:08:02 --> Language Class Initialized
INFO - 2020-02-06 04:08:02 --> Loader Class Initialized
INFO - 2020-02-06 04:08:03 --> Helper loaded: url_helper
INFO - 2020-02-06 04:08:03 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:08:03 --> Controller Class Initialized
INFO - 2020-02-06 04:08:03 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:08:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:08:03 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:08:03 --> Helper loaded: form_helper
INFO - 2020-02-06 04:08:03 --> Form Validation Class Initialized
INFO - 2020-02-06 04:08:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:08:03 --> Final output sent to browser
DEBUG - 2020-02-06 04:08:03 --> Total execution time: 0.6565
INFO - 2020-02-06 04:08:03 --> Config Class Initialized
INFO - 2020-02-06 04:08:03 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:08:03 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:08:03 --> Config Class Initialized
INFO - 2020-02-06 04:08:03 --> Config Class Initialized
INFO - 2020-02-06 04:08:03 --> Hooks Class Initialized
INFO - 2020-02-06 04:08:03 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:03 --> Hooks Class Initialized
INFO - 2020-02-06 04:08:03 --> URI Class Initialized
DEBUG - 2020-02-06 04:08:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:08:03 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:08:03 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:03 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:03 --> Router Class Initialized
INFO - 2020-02-06 04:08:03 --> URI Class Initialized
INFO - 2020-02-06 04:08:03 --> URI Class Initialized
INFO - 2020-02-06 04:08:03 --> Output Class Initialized
INFO - 2020-02-06 04:08:03 --> Router Class Initialized
INFO - 2020-02-06 04:08:03 --> Router Class Initialized
INFO - 2020-02-06 04:08:03 --> Security Class Initialized
INFO - 2020-02-06 04:08:03 --> Output Class Initialized
INFO - 2020-02-06 04:08:03 --> Output Class Initialized
DEBUG - 2020-02-06 04:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:08:03 --> Input Class Initialized
INFO - 2020-02-06 04:08:03 --> Security Class Initialized
INFO - 2020-02-06 04:08:03 --> Security Class Initialized
INFO - 2020-02-06 04:08:03 --> Language Class Initialized
DEBUG - 2020-02-06 04:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:08:03 --> Input Class Initialized
INFO - 2020-02-06 04:08:03 --> Input Class Initialized
ERROR - 2020-02-06 04:08:03 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-06 04:08:03 --> Language Class Initialized
INFO - 2020-02-06 04:08:03 --> Language Class Initialized
INFO - 2020-02-06 04:08:03 --> Loader Class Initialized
INFO - 2020-02-06 04:08:03 --> Loader Class Initialized
INFO - 2020-02-06 04:08:03 --> Helper loaded: url_helper
INFO - 2020-02-06 04:08:03 --> Helper loaded: url_helper
INFO - 2020-02-06 04:08:03 --> Database Driver Class Initialized
INFO - 2020-02-06 04:08:03 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-06 04:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:08:03 --> Controller Class Initialized
INFO - 2020-02-06 04:08:03 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:08:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:08:03 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:08:03 --> Helper loaded: form_helper
INFO - 2020-02-06 04:08:03 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:08:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:08:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:08:04 --> Final output sent to browser
DEBUG - 2020-02-06 04:08:04 --> Total execution time: 0.5883
INFO - 2020-02-06 04:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:08:04 --> Controller Class Initialized
INFO - 2020-02-06 04:08:04 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:08:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:08:04 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:08:04 --> Helper loaded: form_helper
INFO - 2020-02-06 04:08:04 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:08:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:08:04 --> Final output sent to browser
DEBUG - 2020-02-06 04:08:04 --> Total execution time: 0.8484
INFO - 2020-02-06 04:08:07 --> Config Class Initialized
INFO - 2020-02-06 04:08:07 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:08:07 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:08:07 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:07 --> URI Class Initialized
INFO - 2020-02-06 04:08:07 --> Router Class Initialized
INFO - 2020-02-06 04:08:07 --> Output Class Initialized
INFO - 2020-02-06 04:08:07 --> Security Class Initialized
DEBUG - 2020-02-06 04:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:08:07 --> Input Class Initialized
INFO - 2020-02-06 04:08:07 --> Language Class Initialized
INFO - 2020-02-06 04:08:07 --> Loader Class Initialized
INFO - 2020-02-06 04:08:07 --> Helper loaded: url_helper
INFO - 2020-02-06 04:08:07 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:08:08 --> Controller Class Initialized
INFO - 2020-02-06 04:08:08 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:08:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:08:08 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:08:08 --> Helper loaded: form_helper
INFO - 2020-02-06 04:08:08 --> Form Validation Class Initialized
INFO - 2020-02-06 04:08:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:08:08 --> Final output sent to browser
DEBUG - 2020-02-06 04:08:08 --> Total execution time: 1.2554
INFO - 2020-02-06 04:08:08 --> Config Class Initialized
INFO - 2020-02-06 04:08:08 --> Config Class Initialized
INFO - 2020-02-06 04:08:08 --> Config Class Initialized
INFO - 2020-02-06 04:08:08 --> Hooks Class Initialized
INFO - 2020-02-06 04:08:08 --> Hooks Class Initialized
INFO - 2020-02-06 04:08:08 --> Config Class Initialized
DEBUG - 2020-02-06 04:08:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:08:08 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:08:08 --> Config Class Initialized
INFO - 2020-02-06 04:08:08 --> Hooks Class Initialized
INFO - 2020-02-06 04:08:08 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:08 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:08 --> Hooks Class Initialized
INFO - 2020-02-06 04:08:08 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:08:08 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:08:08 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:08 --> URI Class Initialized
INFO - 2020-02-06 04:08:08 --> URI Class Initialized
DEBUG - 2020-02-06 04:08:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:08:08 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:08:08 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:08 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:08 --> Router Class Initialized
INFO - 2020-02-06 04:08:08 --> Router Class Initialized
INFO - 2020-02-06 04:08:08 --> URI Class Initialized
INFO - 2020-02-06 04:08:08 --> URI Class Initialized
INFO - 2020-02-06 04:08:08 --> URI Class Initialized
INFO - 2020-02-06 04:08:08 --> Router Class Initialized
INFO - 2020-02-06 04:08:08 --> Output Class Initialized
INFO - 2020-02-06 04:08:08 --> Output Class Initialized
INFO - 2020-02-06 04:08:08 --> Security Class Initialized
INFO - 2020-02-06 04:08:08 --> Router Class Initialized
INFO - 2020-02-06 04:08:08 --> Security Class Initialized
INFO - 2020-02-06 04:08:08 --> Output Class Initialized
INFO - 2020-02-06 04:08:08 --> Router Class Initialized
DEBUG - 2020-02-06 04:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:08:08 --> Output Class Initialized
INFO - 2020-02-06 04:08:08 --> Output Class Initialized
INFO - 2020-02-06 04:08:08 --> Security Class Initialized
INFO - 2020-02-06 04:08:08 --> Input Class Initialized
INFO - 2020-02-06 04:08:08 --> Input Class Initialized
INFO - 2020-02-06 04:08:08 --> Security Class Initialized
DEBUG - 2020-02-06 04:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:08:08 --> Security Class Initialized
INFO - 2020-02-06 04:08:08 --> Input Class Initialized
INFO - 2020-02-06 04:08:08 --> Language Class Initialized
INFO - 2020-02-06 04:08:08 --> Language Class Initialized
DEBUG - 2020-02-06 04:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:08:08 --> Input Class Initialized
INFO - 2020-02-06 04:08:08 --> Input Class Initialized
INFO - 2020-02-06 04:08:08 --> Language Class Initialized
ERROR - 2020-02-06 04:08:08 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-06 04:08:08 --> Loader Class Initialized
INFO - 2020-02-06 04:08:08 --> Language Class Initialized
INFO - 2020-02-06 04:08:08 --> Language Class Initialized
INFO - 2020-02-06 04:08:08 --> Helper loaded: url_helper
INFO - 2020-02-06 04:08:08 --> Loader Class Initialized
INFO - 2020-02-06 04:08:08 --> Config Class Initialized
ERROR - 2020-02-06 04:08:08 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-06 04:08:08 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-06 04:08:08 --> Helper loaded: url_helper
INFO - 2020-02-06 04:08:08 --> Database Driver Class Initialized
INFO - 2020-02-06 04:08:08 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:08:08 --> Database Driver Class Initialized
INFO - 2020-02-06 04:08:08 --> Config Class Initialized
INFO - 2020-02-06 04:08:08 --> Config Class Initialized
INFO - 2020-02-06 04:08:08 --> Hooks Class Initialized
INFO - 2020-02-06 04:08:08 --> Hooks Class Initialized
INFO - 2020-02-06 04:08:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-06 04:08:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:08:08 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:08 --> Controller Class Initialized
DEBUG - 2020-02-06 04:08:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:08:08 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:08:08 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:08 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:08 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:08:08 --> URI Class Initialized
INFO - 2020-02-06 04:08:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:08:08 --> URI Class Initialized
INFO - 2020-02-06 04:08:08 --> URI Class Initialized
INFO - 2020-02-06 04:08:08 --> Router Class Initialized
INFO - 2020-02-06 04:08:08 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:08:08 --> Router Class Initialized
INFO - 2020-02-06 04:08:08 --> Router Class Initialized
INFO - 2020-02-06 04:08:08 --> Output Class Initialized
INFO - 2020-02-06 04:08:08 --> Security Class Initialized
INFO - 2020-02-06 04:08:08 --> Output Class Initialized
INFO - 2020-02-06 04:08:08 --> Output Class Initialized
INFO - 2020-02-06 04:08:08 --> Helper loaded: form_helper
INFO - 2020-02-06 04:08:09 --> Form Validation Class Initialized
INFO - 2020-02-06 04:08:09 --> Security Class Initialized
DEBUG - 2020-02-06 04:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:08:09 --> Security Class Initialized
INFO - 2020-02-06 04:08:09 --> Input Class Initialized
DEBUG - 2020-02-06 04:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-06 04:08:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-06 04:08:09 --> Input Class Initialized
INFO - 2020-02-06 04:08:09 --> Input Class Initialized
INFO - 2020-02-06 04:08:09 --> Language Class Initialized
ERROR - 2020-02-06 04:08:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:08:09 --> Language Class Initialized
INFO - 2020-02-06 04:08:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:08:09 --> Language Class Initialized
ERROR - 2020-02-06 04:08:09 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-06 04:08:09 --> Final output sent to browser
ERROR - 2020-02-06 04:08:09 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-06 04:08:09 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-06 04:08:09 --> Config Class Initialized
DEBUG - 2020-02-06 04:08:09 --> Total execution time: 0.6312
INFO - 2020-02-06 04:08:09 --> Config Class Initialized
INFO - 2020-02-06 04:08:09 --> Config Class Initialized
INFO - 2020-02-06 04:08:09 --> Hooks Class Initialized
INFO - 2020-02-06 04:08:09 --> Hooks Class Initialized
INFO - 2020-02-06 04:08:09 --> Hooks Class Initialized
INFO - 2020-02-06 04:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:08:09 --> Config Class Initialized
INFO - 2020-02-06 04:08:09 --> Hooks Class Initialized
INFO - 2020-02-06 04:08:09 --> Controller Class Initialized
DEBUG - 2020-02-06 04:08:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:08:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:08:09 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:08:09 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:09 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:09 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:09 --> Model "M_tiket" initialized
DEBUG - 2020-02-06 04:08:09 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:08:09 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:08:09 --> URI Class Initialized
INFO - 2020-02-06 04:08:09 --> URI Class Initialized
INFO - 2020-02-06 04:08:09 --> URI Class Initialized
INFO - 2020-02-06 04:08:09 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:08:09 --> URI Class Initialized
INFO - 2020-02-06 04:08:09 --> Router Class Initialized
INFO - 2020-02-06 04:08:09 --> Router Class Initialized
INFO - 2020-02-06 04:08:09 --> Router Class Initialized
INFO - 2020-02-06 04:08:09 --> Router Class Initialized
INFO - 2020-02-06 04:08:09 --> Output Class Initialized
INFO - 2020-02-06 04:08:09 --> Output Class Initialized
INFO - 2020-02-06 04:08:09 --> Helper loaded: form_helper
INFO - 2020-02-06 04:08:09 --> Output Class Initialized
INFO - 2020-02-06 04:08:09 --> Form Validation Class Initialized
INFO - 2020-02-06 04:08:09 --> Security Class Initialized
INFO - 2020-02-06 04:08:09 --> Security Class Initialized
INFO - 2020-02-06 04:08:09 --> Output Class Initialized
INFO - 2020-02-06 04:08:09 --> Security Class Initialized
INFO - 2020-02-06 04:08:09 --> Security Class Initialized
DEBUG - 2020-02-06 04:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-06 04:08:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-06 04:08:09 --> Input Class Initialized
INFO - 2020-02-06 04:08:09 --> Input Class Initialized
INFO - 2020-02-06 04:08:09 --> Input Class Initialized
ERROR - 2020-02-06 04:08:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-06 04:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:08:09 --> Input Class Initialized
INFO - 2020-02-06 04:08:09 --> Language Class Initialized
INFO - 2020-02-06 04:08:09 --> Language Class Initialized
INFO - 2020-02-06 04:08:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:08:09 --> Language Class Initialized
INFO - 2020-02-06 04:08:09 --> Final output sent to browser
ERROR - 2020-02-06 04:08:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-06 04:08:09 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-06 04:08:09 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:08:09 --> Language Class Initialized
DEBUG - 2020-02-06 04:08:09 --> Total execution time: 0.8884
ERROR - 2020-02-06 04:08:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-06 04:08:09 --> Config Class Initialized
INFO - 2020-02-06 04:08:09 --> Config Class Initialized
INFO - 2020-02-06 04:08:09 --> Hooks Class Initialized
INFO - 2020-02-06 04:08:09 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:08:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:08:09 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:08:09 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:09 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:09 --> URI Class Initialized
INFO - 2020-02-06 04:08:09 --> URI Class Initialized
INFO - 2020-02-06 04:08:09 --> Router Class Initialized
INFO - 2020-02-06 04:08:09 --> Router Class Initialized
INFO - 2020-02-06 04:08:09 --> Output Class Initialized
INFO - 2020-02-06 04:08:09 --> Output Class Initialized
INFO - 2020-02-06 04:08:09 --> Security Class Initialized
INFO - 2020-02-06 04:08:09 --> Security Class Initialized
DEBUG - 2020-02-06 04:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:08:09 --> Input Class Initialized
INFO - 2020-02-06 04:08:09 --> Input Class Initialized
INFO - 2020-02-06 04:08:09 --> Language Class Initialized
INFO - 2020-02-06 04:08:09 --> Language Class Initialized
ERROR - 2020-02-06 04:08:09 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-06 04:08:09 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-06 04:08:09 --> Config Class Initialized
INFO - 2020-02-06 04:08:09 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:08:09 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:08:09 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:09 --> URI Class Initialized
INFO - 2020-02-06 04:08:10 --> Router Class Initialized
INFO - 2020-02-06 04:08:20 --> Output Class Initialized
INFO - 2020-02-06 04:08:20 --> Security Class Initialized
DEBUG - 2020-02-06 04:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:08:24 --> Config Class Initialized
INFO - 2020-02-06 04:08:24 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:08:24 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:08:24 --> Utf8 Class Initialized
INFO - 2020-02-06 04:08:24 --> URI Class Initialized
INFO - 2020-02-06 04:08:24 --> Router Class Initialized
INFO - 2020-02-06 04:08:24 --> Output Class Initialized
INFO - 2020-02-06 04:08:24 --> Security Class Initialized
DEBUG - 2020-02-06 04:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:08:24 --> Input Class Initialized
INFO - 2020-02-06 04:08:24 --> Language Class Initialized
ERROR - 2020-02-06 04:08:24 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-06 04:09:23 --> Config Class Initialized
INFO - 2020-02-06 04:09:23 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:09:23 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:09:23 --> Utf8 Class Initialized
INFO - 2020-02-06 04:09:23 --> URI Class Initialized
INFO - 2020-02-06 04:09:23 --> Router Class Initialized
INFO - 2020-02-06 04:09:23 --> Output Class Initialized
INFO - 2020-02-06 04:09:23 --> Security Class Initialized
DEBUG - 2020-02-06 04:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:09:23 --> Input Class Initialized
INFO - 2020-02-06 04:09:23 --> Language Class Initialized
INFO - 2020-02-06 04:09:23 --> Loader Class Initialized
INFO - 2020-02-06 04:09:23 --> Helper loaded: url_helper
INFO - 2020-02-06 04:09:23 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:09:23 --> Controller Class Initialized
INFO - 2020-02-06 04:09:23 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:09:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:09:23 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:09:23 --> Helper loaded: form_helper
INFO - 2020-02-06 04:09:23 --> Form Validation Class Initialized
INFO - 2020-02-06 04:09:23 --> Final output sent to browser
DEBUG - 2020-02-06 04:09:24 --> Total execution time: 0.9661
INFO - 2020-02-06 04:12:49 --> Config Class Initialized
INFO - 2020-02-06 04:12:50 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:12:50 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:12:50 --> Utf8 Class Initialized
INFO - 2020-02-06 04:12:50 --> URI Class Initialized
INFO - 2020-02-06 04:12:50 --> Router Class Initialized
INFO - 2020-02-06 04:12:50 --> Output Class Initialized
INFO - 2020-02-06 04:12:50 --> Security Class Initialized
DEBUG - 2020-02-06 04:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:12:50 --> Input Class Initialized
INFO - 2020-02-06 04:12:50 --> Language Class Initialized
INFO - 2020-02-06 04:12:50 --> Loader Class Initialized
INFO - 2020-02-06 04:12:50 --> Helper loaded: url_helper
INFO - 2020-02-06 04:12:50 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:12:50 --> Controller Class Initialized
INFO - 2020-02-06 04:12:50 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:12:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:12:50 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:12:50 --> Helper loaded: form_helper
INFO - 2020-02-06 04:12:50 --> Form Validation Class Initialized
INFO - 2020-02-06 04:12:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:12:50 --> Final output sent to browser
DEBUG - 2020-02-06 04:12:50 --> Total execution time: 0.7887
INFO - 2020-02-06 04:12:50 --> Config Class Initialized
INFO - 2020-02-06 04:12:50 --> Config Class Initialized
INFO - 2020-02-06 04:12:50 --> Config Class Initialized
INFO - 2020-02-06 04:12:50 --> Hooks Class Initialized
INFO - 2020-02-06 04:12:50 --> Hooks Class Initialized
INFO - 2020-02-06 04:12:50 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:12:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:12:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:12:51 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:12:51 --> Utf8 Class Initialized
INFO - 2020-02-06 04:12:51 --> Utf8 Class Initialized
INFO - 2020-02-06 04:12:51 --> URI Class Initialized
INFO - 2020-02-06 04:12:51 --> Utf8 Class Initialized
INFO - 2020-02-06 04:12:51 --> URI Class Initialized
INFO - 2020-02-06 04:12:51 --> Router Class Initialized
INFO - 2020-02-06 04:12:51 --> URI Class Initialized
INFO - 2020-02-06 04:12:51 --> Router Class Initialized
INFO - 2020-02-06 04:12:51 --> Router Class Initialized
INFO - 2020-02-06 04:12:51 --> Output Class Initialized
INFO - 2020-02-06 04:12:51 --> Security Class Initialized
INFO - 2020-02-06 04:12:51 --> Output Class Initialized
INFO - 2020-02-06 04:12:51 --> Output Class Initialized
DEBUG - 2020-02-06 04:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:12:51 --> Security Class Initialized
INFO - 2020-02-06 04:12:51 --> Security Class Initialized
INFO - 2020-02-06 04:12:51 --> Input Class Initialized
DEBUG - 2020-02-06 04:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:12:51 --> Input Class Initialized
INFO - 2020-02-06 04:12:51 --> Input Class Initialized
INFO - 2020-02-06 04:12:51 --> Language Class Initialized
INFO - 2020-02-06 04:12:51 --> Language Class Initialized
INFO - 2020-02-06 04:12:51 --> Language Class Initialized
ERROR - 2020-02-06 04:12:51 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-06 04:12:51 --> Loader Class Initialized
INFO - 2020-02-06 04:12:51 --> Loader Class Initialized
INFO - 2020-02-06 04:12:51 --> Helper loaded: url_helper
INFO - 2020-02-06 04:12:51 --> Helper loaded: url_helper
INFO - 2020-02-06 04:12:51 --> Database Driver Class Initialized
INFO - 2020-02-06 04:12:51 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-06 04:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:12:51 --> Controller Class Initialized
INFO - 2020-02-06 04:12:51 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:12:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:12:51 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:12:51 --> Helper loaded: form_helper
INFO - 2020-02-06 04:12:51 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:12:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:12:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:12:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:12:51 --> Final output sent to browser
DEBUG - 2020-02-06 04:12:51 --> Total execution time: 0.8255
INFO - 2020-02-06 04:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:12:51 --> Controller Class Initialized
INFO - 2020-02-06 04:12:51 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:12:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:12:51 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:12:51 --> Helper loaded: form_helper
INFO - 2020-02-06 04:12:51 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:12:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:12:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:12:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:12:52 --> Final output sent to browser
DEBUG - 2020-02-06 04:12:52 --> Total execution time: 1.1020
INFO - 2020-02-06 04:13:03 --> Config Class Initialized
INFO - 2020-02-06 04:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:03 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:03 --> URI Class Initialized
INFO - 2020-02-06 04:13:03 --> Router Class Initialized
INFO - 2020-02-06 04:13:03 --> Output Class Initialized
INFO - 2020-02-06 04:13:03 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:03 --> Input Class Initialized
INFO - 2020-02-06 04:13:04 --> Language Class Initialized
INFO - 2020-02-06 04:13:04 --> Loader Class Initialized
INFO - 2020-02-06 04:13:04 --> Helper loaded: url_helper
INFO - 2020-02-06 04:13:04 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:13:04 --> Controller Class Initialized
INFO - 2020-02-06 04:13:04 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:13:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:13:04 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:13:04 --> Helper loaded: form_helper
INFO - 2020-02-06 04:13:04 --> Form Validation Class Initialized
INFO - 2020-02-06 04:13:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:13:04 --> Final output sent to browser
INFO - 2020-02-06 04:13:04 --> Config Class Initialized
INFO - 2020-02-06 04:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:04 --> Total execution time: 0.6623
INFO - 2020-02-06 04:13:04 --> Config Class Initialized
INFO - 2020-02-06 04:13:04 --> Config Class Initialized
INFO - 2020-02-06 04:13:04 --> Hooks Class Initialized
INFO - 2020-02-06 04:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:04 --> Config Class Initialized
INFO - 2020-02-06 04:13:04 --> Config Class Initialized
INFO - 2020-02-06 04:13:04 --> Config Class Initialized
INFO - 2020-02-06 04:13:04 --> Hooks Class Initialized
INFO - 2020-02-06 04:13:04 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:04 --> Hooks Class Initialized
INFO - 2020-02-06 04:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:04 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:04 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:04 --> URI Class Initialized
INFO - 2020-02-06 04:13:04 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:04 --> URI Class Initialized
DEBUG - 2020-02-06 04:13:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:04 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:04 --> URI Class Initialized
INFO - 2020-02-06 04:13:04 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:04 --> Router Class Initialized
INFO - 2020-02-06 04:13:04 --> URI Class Initialized
INFO - 2020-02-06 04:13:04 --> Router Class Initialized
INFO - 2020-02-06 04:13:04 --> URI Class Initialized
INFO - 2020-02-06 04:13:04 --> Output Class Initialized
INFO - 2020-02-06 04:13:04 --> URI Class Initialized
INFO - 2020-02-06 04:13:04 --> Router Class Initialized
INFO - 2020-02-06 04:13:04 --> Router Class Initialized
INFO - 2020-02-06 04:13:04 --> Output Class Initialized
INFO - 2020-02-06 04:13:04 --> Security Class Initialized
INFO - 2020-02-06 04:13:04 --> Security Class Initialized
INFO - 2020-02-06 04:13:04 --> Router Class Initialized
INFO - 2020-02-06 04:13:04 --> Router Class Initialized
INFO - 2020-02-06 04:13:04 --> Output Class Initialized
INFO - 2020-02-06 04:13:04 --> Output Class Initialized
DEBUG - 2020-02-06 04:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:04 --> Output Class Initialized
INFO - 2020-02-06 04:13:04 --> Output Class Initialized
INFO - 2020-02-06 04:13:04 --> Security Class Initialized
INFO - 2020-02-06 04:13:04 --> Security Class Initialized
INFO - 2020-02-06 04:13:04 --> Input Class Initialized
INFO - 2020-02-06 04:13:04 --> Input Class Initialized
DEBUG - 2020-02-06 04:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:04 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:04 --> Security Class Initialized
INFO - 2020-02-06 04:13:04 --> Input Class Initialized
INFO - 2020-02-06 04:13:04 --> Input Class Initialized
INFO - 2020-02-06 04:13:04 --> Language Class Initialized
INFO - 2020-02-06 04:13:04 --> Language Class Initialized
DEBUG - 2020-02-06 04:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:04 --> Input Class Initialized
INFO - 2020-02-06 04:13:04 --> Input Class Initialized
INFO - 2020-02-06 04:13:04 --> Language Class Initialized
INFO - 2020-02-06 04:13:04 --> Language Class Initialized
ERROR - 2020-02-06 04:13:04 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-06 04:13:04 --> Loader Class Initialized
INFO - 2020-02-06 04:13:04 --> Helper loaded: url_helper
ERROR - 2020-02-06 04:13:04 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-06 04:13:04 --> Language Class Initialized
INFO - 2020-02-06 04:13:04 --> Loader Class Initialized
INFO - 2020-02-06 04:13:04 --> Language Class Initialized
INFO - 2020-02-06 04:13:04 --> Config Class Initialized
INFO - 2020-02-06 04:13:04 --> Hooks Class Initialized
ERROR - 2020-02-06 04:13:04 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-06 04:13:04 --> Helper loaded: url_helper
ERROR - 2020-02-06 04:13:04 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-06 04:13:04 --> Database Driver Class Initialized
INFO - 2020-02-06 04:13:04 --> Config Class Initialized
INFO - 2020-02-06 04:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:04 --> Database Driver Class Initialized
INFO - 2020-02-06 04:13:04 --> Config Class Initialized
INFO - 2020-02-06 04:13:04 --> Config Class Initialized
DEBUG - 2020-02-06 04:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:13:04 --> Hooks Class Initialized
INFO - 2020-02-06 04:13:04 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:13:05 --> Controller Class Initialized
INFO - 2020-02-06 04:13:05 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:05 --> URI Class Initialized
DEBUG - 2020-02-06 04:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:05 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:05 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:05 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:13:05 --> URI Class Initialized
INFO - 2020-02-06 04:13:05 --> Router Class Initialized
INFO - 2020-02-06 04:13:05 --> URI Class Initialized
INFO - 2020-02-06 04:13:05 --> URI Class Initialized
INFO - 2020-02-06 04:13:05 --> Router Class Initialized
INFO - 2020-02-06 04:13:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:13:05 --> Output Class Initialized
INFO - 2020-02-06 04:13:05 --> Router Class Initialized
INFO - 2020-02-06 04:13:05 --> Output Class Initialized
INFO - 2020-02-06 04:13:05 --> Security Class Initialized
INFO - 2020-02-06 04:13:05 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:13:05 --> Router Class Initialized
INFO - 2020-02-06 04:13:05 --> Output Class Initialized
DEBUG - 2020-02-06 04:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:05 --> Helper loaded: form_helper
INFO - 2020-02-06 04:13:05 --> Output Class Initialized
INFO - 2020-02-06 04:13:05 --> Input Class Initialized
INFO - 2020-02-06 04:13:05 --> Security Class Initialized
INFO - 2020-02-06 04:13:05 --> Security Class Initialized
INFO - 2020-02-06 04:13:05 --> Form Validation Class Initialized
INFO - 2020-02-06 04:13:05 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:05 --> Language Class Initialized
DEBUG - 2020-02-06 04:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:13:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-06 04:13:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-06 04:13:05 --> Input Class Initialized
ERROR - 2020-02-06 04:13:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:13:05 --> Input Class Initialized
INFO - 2020-02-06 04:13:05 --> Input Class Initialized
ERROR - 2020-02-06 04:13:05 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-06 04:13:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:13:05 --> Language Class Initialized
INFO - 2020-02-06 04:13:05 --> Language Class Initialized
INFO - 2020-02-06 04:13:05 --> Language Class Initialized
INFO - 2020-02-06 04:13:05 --> Final output sent to browser
ERROR - 2020-02-06 04:13:05 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-06 04:13:05 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:13:05 --> Config Class Initialized
ERROR - 2020-02-06 04:13:05 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-06 04:13:05 --> Total execution time: 0.8707
INFO - 2020-02-06 04:13:05 --> Hooks Class Initialized
INFO - 2020-02-06 04:13:05 --> Config Class Initialized
INFO - 2020-02-06 04:13:05 --> Config Class Initialized
INFO - 2020-02-06 04:13:05 --> Hooks Class Initialized
INFO - 2020-02-06 04:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:13:05 --> Config Class Initialized
INFO - 2020-02-06 04:13:05 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:05 --> Hooks Class Initialized
INFO - 2020-02-06 04:13:05 --> Controller Class Initialized
INFO - 2020-02-06 04:13:05 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:05 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:05 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:05 --> URI Class Initialized
INFO - 2020-02-06 04:13:05 --> Model "M_tiket" initialized
DEBUG - 2020-02-06 04:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:05 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:13:05 --> URI Class Initialized
INFO - 2020-02-06 04:13:05 --> URI Class Initialized
INFO - 2020-02-06 04:13:05 --> Router Class Initialized
INFO - 2020-02-06 04:13:05 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:13:05 --> Router Class Initialized
INFO - 2020-02-06 04:13:05 --> Output Class Initialized
INFO - 2020-02-06 04:13:05 --> URI Class Initialized
INFO - 2020-02-06 04:13:05 --> Router Class Initialized
INFO - 2020-02-06 04:13:05 --> Security Class Initialized
INFO - 2020-02-06 04:13:05 --> Output Class Initialized
INFO - 2020-02-06 04:13:05 --> Router Class Initialized
INFO - 2020-02-06 04:13:05 --> Helper loaded: form_helper
INFO - 2020-02-06 04:13:05 --> Output Class Initialized
INFO - 2020-02-06 04:13:05 --> Form Validation Class Initialized
INFO - 2020-02-06 04:13:05 --> Security Class Initialized
INFO - 2020-02-06 04:13:05 --> Output Class Initialized
INFO - 2020-02-06 04:13:05 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:05 --> Input Class Initialized
DEBUG - 2020-02-06 04:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:05 --> Security Class Initialized
ERROR - 2020-02-06 04:13:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-06 04:13:05 --> Input Class Initialized
INFO - 2020-02-06 04:13:05 --> Input Class Initialized
INFO - 2020-02-06 04:13:05 --> Language Class Initialized
ERROR - 2020-02-06 04:13:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-06 04:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:05 --> Input Class Initialized
INFO - 2020-02-06 04:13:05 --> Language Class Initialized
INFO - 2020-02-06 04:13:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:13:05 --> Language Class Initialized
ERROR - 2020-02-06 04:13:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-06 04:13:05 --> Final output sent to browser
INFO - 2020-02-06 04:13:05 --> Language Class Initialized
ERROR - 2020-02-06 04:13:05 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-06 04:13:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-06 04:13:05 --> Total execution time: 1.1999
ERROR - 2020-02-06 04:13:05 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-06 04:13:05 --> Config Class Initialized
INFO - 2020-02-06 04:13:05 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:05 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:05 --> URI Class Initialized
INFO - 2020-02-06 04:13:05 --> Router Class Initialized
INFO - 2020-02-06 04:13:05 --> Output Class Initialized
INFO - 2020-02-06 04:13:05 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:06 --> Input Class Initialized
INFO - 2020-02-06 04:13:06 --> Language Class Initialized
ERROR - 2020-02-06 04:13:06 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-06 04:13:06 --> Config Class Initialized
INFO - 2020-02-06 04:13:06 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:06 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:06 --> URI Class Initialized
INFO - 2020-02-06 04:13:06 --> Router Class Initialized
INFO - 2020-02-06 04:13:06 --> Output Class Initialized
INFO - 2020-02-06 04:13:06 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:06 --> Input Class Initialized
INFO - 2020-02-06 04:13:06 --> Language Class Initialized
ERROR - 2020-02-06 04:13:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-06 04:13:06 --> Config Class Initialized
INFO - 2020-02-06 04:13:06 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:06 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:06 --> URI Class Initialized
INFO - 2020-02-06 04:13:06 --> Router Class Initialized
INFO - 2020-02-06 04:13:06 --> Output Class Initialized
INFO - 2020-02-06 04:13:06 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:06 --> Input Class Initialized
INFO - 2020-02-06 04:13:06 --> Language Class Initialized
ERROR - 2020-02-06 04:13:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-06 04:13:06 --> Config Class Initialized
INFO - 2020-02-06 04:13:06 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:06 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:06 --> URI Class Initialized
INFO - 2020-02-06 04:13:06 --> Router Class Initialized
INFO - 2020-02-06 04:13:06 --> Output Class Initialized
INFO - 2020-02-06 04:13:06 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:06 --> Input Class Initialized
INFO - 2020-02-06 04:13:06 --> Language Class Initialized
ERROR - 2020-02-06 04:13:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:13:06 --> Config Class Initialized
INFO - 2020-02-06 04:13:07 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:07 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:07 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:07 --> URI Class Initialized
INFO - 2020-02-06 04:13:07 --> Router Class Initialized
INFO - 2020-02-06 04:13:07 --> Output Class Initialized
INFO - 2020-02-06 04:13:07 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:07 --> Input Class Initialized
INFO - 2020-02-06 04:13:07 --> Language Class Initialized
ERROR - 2020-02-06 04:13:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:13:07 --> Config Class Initialized
INFO - 2020-02-06 04:13:07 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:07 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:07 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:07 --> URI Class Initialized
INFO - 2020-02-06 04:13:07 --> Router Class Initialized
INFO - 2020-02-06 04:13:07 --> Output Class Initialized
INFO - 2020-02-06 04:13:07 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:07 --> Input Class Initialized
INFO - 2020-02-06 04:13:07 --> Language Class Initialized
ERROR - 2020-02-06 04:13:07 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-06 04:13:07 --> Config Class Initialized
INFO - 2020-02-06 04:13:07 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:07 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:07 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:07 --> URI Class Initialized
INFO - 2020-02-06 04:13:07 --> Router Class Initialized
INFO - 2020-02-06 04:13:07 --> Output Class Initialized
INFO - 2020-02-06 04:13:07 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:07 --> Input Class Initialized
INFO - 2020-02-06 04:13:07 --> Language Class Initialized
ERROR - 2020-02-06 04:13:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-06 04:13:07 --> Config Class Initialized
INFO - 2020-02-06 04:13:08 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:08 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:08 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:08 --> URI Class Initialized
INFO - 2020-02-06 04:13:08 --> Router Class Initialized
INFO - 2020-02-06 04:13:08 --> Output Class Initialized
INFO - 2020-02-06 04:13:08 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:08 --> Input Class Initialized
INFO - 2020-02-06 04:13:08 --> Language Class Initialized
ERROR - 2020-02-06 04:13:08 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-06 04:13:08 --> Config Class Initialized
INFO - 2020-02-06 04:13:08 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:08 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:08 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:08 --> URI Class Initialized
INFO - 2020-02-06 04:13:08 --> Router Class Initialized
INFO - 2020-02-06 04:13:08 --> Output Class Initialized
INFO - 2020-02-06 04:13:08 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:08 --> Input Class Initialized
INFO - 2020-02-06 04:13:08 --> Language Class Initialized
ERROR - 2020-02-06 04:13:08 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-06 04:13:28 --> Config Class Initialized
INFO - 2020-02-06 04:13:28 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:13:28 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:13:28 --> Utf8 Class Initialized
INFO - 2020-02-06 04:13:28 --> URI Class Initialized
INFO - 2020-02-06 04:13:28 --> Router Class Initialized
INFO - 2020-02-06 04:13:28 --> Output Class Initialized
INFO - 2020-02-06 04:13:28 --> Security Class Initialized
DEBUG - 2020-02-06 04:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:13:28 --> Input Class Initialized
INFO - 2020-02-06 04:13:28 --> Language Class Initialized
INFO - 2020-02-06 04:13:28 --> Loader Class Initialized
INFO - 2020-02-06 04:13:28 --> Helper loaded: url_helper
INFO - 2020-02-06 04:13:28 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:13:28 --> Controller Class Initialized
INFO - 2020-02-06 04:13:28 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:13:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:13:28 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:13:29 --> Helper loaded: form_helper
INFO - 2020-02-06 04:13:29 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:13:29 --> Query error: Column 'totalbayar' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('33', NULL, NULL, '1', '36')
INFO - 2020-02-06 04:13:29 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-06 04:14:36 --> Config Class Initialized
INFO - 2020-02-06 04:14:36 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:14:36 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:14:36 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:36 --> URI Class Initialized
INFO - 2020-02-06 04:14:36 --> Router Class Initialized
INFO - 2020-02-06 04:14:36 --> Output Class Initialized
INFO - 2020-02-06 04:14:36 --> Security Class Initialized
DEBUG - 2020-02-06 04:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:36 --> Input Class Initialized
INFO - 2020-02-06 04:14:36 --> Language Class Initialized
INFO - 2020-02-06 04:14:36 --> Loader Class Initialized
INFO - 2020-02-06 04:14:36 --> Helper loaded: url_helper
INFO - 2020-02-06 04:14:36 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:14:36 --> Controller Class Initialized
INFO - 2020-02-06 04:14:36 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:14:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:14:36 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:14:36 --> Helper loaded: form_helper
INFO - 2020-02-06 04:14:36 --> Form Validation Class Initialized
INFO - 2020-02-06 04:14:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:14:37 --> Final output sent to browser
INFO - 2020-02-06 04:14:37 --> Config Class Initialized
INFO - 2020-02-06 04:14:37 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:14:37 --> Total execution time: 0.7198
INFO - 2020-02-06 04:14:37 --> Config Class Initialized
INFO - 2020-02-06 04:14:37 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:14:37 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:14:37 --> Config Class Initialized
INFO - 2020-02-06 04:14:37 --> Hooks Class Initialized
INFO - 2020-02-06 04:14:37 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:14:37 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:14:37 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:37 --> URI Class Initialized
DEBUG - 2020-02-06 04:14:37 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:14:37 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:37 --> URI Class Initialized
INFO - 2020-02-06 04:14:37 --> Router Class Initialized
INFO - 2020-02-06 04:14:37 --> URI Class Initialized
INFO - 2020-02-06 04:14:37 --> Router Class Initialized
INFO - 2020-02-06 04:14:37 --> Output Class Initialized
INFO - 2020-02-06 04:14:37 --> Router Class Initialized
INFO - 2020-02-06 04:14:37 --> Security Class Initialized
INFO - 2020-02-06 04:14:37 --> Output Class Initialized
INFO - 2020-02-06 04:14:37 --> Security Class Initialized
DEBUG - 2020-02-06 04:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:37 --> Output Class Initialized
INFO - 2020-02-06 04:14:37 --> Input Class Initialized
DEBUG - 2020-02-06 04:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:37 --> Security Class Initialized
INFO - 2020-02-06 04:14:37 --> Input Class Initialized
INFO - 2020-02-06 04:14:37 --> Language Class Initialized
DEBUG - 2020-02-06 04:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:37 --> Input Class Initialized
INFO - 2020-02-06 04:14:37 --> Language Class Initialized
ERROR - 2020-02-06 04:14:37 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-06 04:14:37 --> Language Class Initialized
INFO - 2020-02-06 04:14:37 --> Loader Class Initialized
INFO - 2020-02-06 04:14:37 --> Helper loaded: url_helper
INFO - 2020-02-06 04:14:37 --> Loader Class Initialized
INFO - 2020-02-06 04:14:37 --> Helper loaded: url_helper
INFO - 2020-02-06 04:14:37 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:14:37 --> Database Driver Class Initialized
INFO - 2020-02-06 04:14:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-06 04:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:14:37 --> Controller Class Initialized
INFO - 2020-02-06 04:14:37 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:14:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:14:37 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:14:37 --> Helper loaded: form_helper
INFO - 2020-02-06 04:14:37 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:14:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:14:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:14:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:14:38 --> Final output sent to browser
DEBUG - 2020-02-06 04:14:38 --> Total execution time: 0.6914
INFO - 2020-02-06 04:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:14:38 --> Controller Class Initialized
INFO - 2020-02-06 04:14:38 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:14:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:14:38 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:14:38 --> Helper loaded: form_helper
INFO - 2020-02-06 04:14:38 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:14:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:14:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:14:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:14:38 --> Final output sent to browser
DEBUG - 2020-02-06 04:14:38 --> Total execution time: 0.9249
INFO - 2020-02-06 04:14:41 --> Config Class Initialized
INFO - 2020-02-06 04:14:41 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:14:41 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:14:41 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:41 --> URI Class Initialized
INFO - 2020-02-06 04:14:41 --> Router Class Initialized
INFO - 2020-02-06 04:14:41 --> Output Class Initialized
INFO - 2020-02-06 04:14:41 --> Security Class Initialized
DEBUG - 2020-02-06 04:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:41 --> Input Class Initialized
INFO - 2020-02-06 04:14:41 --> Language Class Initialized
INFO - 2020-02-06 04:14:41 --> Loader Class Initialized
INFO - 2020-02-06 04:14:41 --> Helper loaded: url_helper
INFO - 2020-02-06 04:14:41 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:14:41 --> Controller Class Initialized
INFO - 2020-02-06 04:14:41 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:14:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:14:41 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:14:41 --> Helper loaded: form_helper
INFO - 2020-02-06 04:14:41 --> Form Validation Class Initialized
INFO - 2020-02-06 04:14:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:14:42 --> Final output sent to browser
DEBUG - 2020-02-06 04:14:42 --> Total execution time: 0.5755
INFO - 2020-02-06 04:14:42 --> Config Class Initialized
INFO - 2020-02-06 04:14:42 --> Config Class Initialized
INFO - 2020-02-06 04:14:42 --> Config Class Initialized
INFO - 2020-02-06 04:14:42 --> Hooks Class Initialized
INFO - 2020-02-06 04:14:42 --> Config Class Initialized
INFO - 2020-02-06 04:14:42 --> Hooks Class Initialized
INFO - 2020-02-06 04:14:42 --> Hooks Class Initialized
INFO - 2020-02-06 04:14:42 --> Config Class Initialized
INFO - 2020-02-06 04:14:42 --> Config Class Initialized
INFO - 2020-02-06 04:14:42 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:14:42 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:14:42 --> Hooks Class Initialized
INFO - 2020-02-06 04:14:42 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:42 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:14:42 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:14:42 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:42 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:42 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:42 --> URI Class Initialized
INFO - 2020-02-06 04:14:42 --> URI Class Initialized
DEBUG - 2020-02-06 04:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:14:42 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:14:42 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:42 --> URI Class Initialized
INFO - 2020-02-06 04:14:42 --> Router Class Initialized
INFO - 2020-02-06 04:14:42 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:42 --> URI Class Initialized
INFO - 2020-02-06 04:14:42 --> Router Class Initialized
INFO - 2020-02-06 04:14:42 --> Router Class Initialized
INFO - 2020-02-06 04:14:42 --> Output Class Initialized
INFO - 2020-02-06 04:14:42 --> Output Class Initialized
INFO - 2020-02-06 04:14:42 --> Output Class Initialized
INFO - 2020-02-06 04:14:42 --> Security Class Initialized
INFO - 2020-02-06 04:14:42 --> Security Class Initialized
INFO - 2020-02-06 04:14:42 --> Router Class Initialized
INFO - 2020-02-06 04:14:42 --> URI Class Initialized
INFO - 2020-02-06 04:14:42 --> URI Class Initialized
DEBUG - 2020-02-06 04:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:42 --> Router Class Initialized
INFO - 2020-02-06 04:14:42 --> Output Class Initialized
DEBUG - 2020-02-06 04:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:42 --> Router Class Initialized
INFO - 2020-02-06 04:14:42 --> Security Class Initialized
INFO - 2020-02-06 04:14:42 --> Input Class Initialized
INFO - 2020-02-06 04:14:42 --> Input Class Initialized
DEBUG - 2020-02-06 04:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:42 --> Security Class Initialized
INFO - 2020-02-06 04:14:42 --> Output Class Initialized
INFO - 2020-02-06 04:14:42 --> Output Class Initialized
INFO - 2020-02-06 04:14:42 --> Language Class Initialized
INFO - 2020-02-06 04:14:42 --> Security Class Initialized
INFO - 2020-02-06 04:14:42 --> Input Class Initialized
INFO - 2020-02-06 04:14:42 --> Security Class Initialized
INFO - 2020-02-06 04:14:42 --> Language Class Initialized
DEBUG - 2020-02-06 04:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:42 --> Language Class Initialized
ERROR - 2020-02-06 04:14:42 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-06 04:14:42 --> 404 Page Not Found: Bower_components/jquery
DEBUG - 2020-02-06 04:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:42 --> Input Class Initialized
DEBUG - 2020-02-06 04:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:42 --> Input Class Initialized
INFO - 2020-02-06 04:14:42 --> Language Class Initialized
INFO - 2020-02-06 04:14:42 --> Input Class Initialized
INFO - 2020-02-06 04:14:42 --> Loader Class Initialized
INFO - 2020-02-06 04:14:42 --> Config Class Initialized
INFO - 2020-02-06 04:14:42 --> Config Class Initialized
INFO - 2020-02-06 04:14:42 --> Hooks Class Initialized
INFO - 2020-02-06 04:14:42 --> Hooks Class Initialized
INFO - 2020-02-06 04:14:42 --> Language Class Initialized
INFO - 2020-02-06 04:14:42 --> Language Class Initialized
ERROR - 2020-02-06 04:14:42 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-06 04:14:42 --> Helper loaded: url_helper
DEBUG - 2020-02-06 04:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:14:42 --> UTF-8 Support Enabled
ERROR - 2020-02-06 04:14:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-06 04:14:42 --> Database Driver Class Initialized
ERROR - 2020-02-06 04:14:42 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-06 04:14:42 --> Config Class Initialized
INFO - 2020-02-06 04:14:42 --> Hooks Class Initialized
INFO - 2020-02-06 04:14:42 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:42 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:14:42 --> Config Class Initialized
INFO - 2020-02-06 04:14:42 --> Config Class Initialized
INFO - 2020-02-06 04:14:42 --> Hooks Class Initialized
INFO - 2020-02-06 04:14:42 --> Hooks Class Initialized
INFO - 2020-02-06 04:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:14:42 --> URI Class Initialized
INFO - 2020-02-06 04:14:42 --> URI Class Initialized
DEBUG - 2020-02-06 04:14:42 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:14:42 --> Controller Class Initialized
INFO - 2020-02-06 04:14:42 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:42 --> Router Class Initialized
INFO - 2020-02-06 04:14:42 --> Router Class Initialized
DEBUG - 2020-02-06 04:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:14:42 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:14:42 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:42 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:42 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:14:42 --> Output Class Initialized
INFO - 2020-02-06 04:14:42 --> URI Class Initialized
INFO - 2020-02-06 04:14:42 --> Output Class Initialized
INFO - 2020-02-06 04:14:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:14:42 --> URI Class Initialized
INFO - 2020-02-06 04:14:42 --> URI Class Initialized
INFO - 2020-02-06 04:14:42 --> Router Class Initialized
INFO - 2020-02-06 04:14:42 --> Security Class Initialized
INFO - 2020-02-06 04:14:42 --> Security Class Initialized
INFO - 2020-02-06 04:14:42 --> Model "M_pesan" initialized
DEBUG - 2020-02-06 04:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:42 --> Output Class Initialized
INFO - 2020-02-06 04:14:42 --> Router Class Initialized
INFO - 2020-02-06 04:14:42 --> Router Class Initialized
INFO - 2020-02-06 04:14:42 --> Input Class Initialized
INFO - 2020-02-06 04:14:42 --> Input Class Initialized
INFO - 2020-02-06 04:14:42 --> Security Class Initialized
INFO - 2020-02-06 04:14:42 --> Output Class Initialized
INFO - 2020-02-06 04:14:42 --> Output Class Initialized
INFO - 2020-02-06 04:14:42 --> Helper loaded: form_helper
INFO - 2020-02-06 04:14:42 --> Language Class Initialized
INFO - 2020-02-06 04:14:42 --> Form Validation Class Initialized
DEBUG - 2020-02-06 04:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:42 --> Security Class Initialized
INFO - 2020-02-06 04:14:42 --> Language Class Initialized
INFO - 2020-02-06 04:14:42 --> Security Class Initialized
INFO - 2020-02-06 04:14:42 --> Input Class Initialized
ERROR - 2020-02-06 04:14:42 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-06 04:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:42 --> Loader Class Initialized
ERROR - 2020-02-06 04:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-06 04:14:42 --> Input Class Initialized
ERROR - 2020-02-06 04:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:14:42 --> Language Class Initialized
INFO - 2020-02-06 04:14:42 --> Input Class Initialized
INFO - 2020-02-06 04:14:42 --> Helper loaded: url_helper
INFO - 2020-02-06 04:14:42 --> Config Class Initialized
INFO - 2020-02-06 04:14:42 --> Hooks Class Initialized
INFO - 2020-02-06 04:14:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:14:42 --> Language Class Initialized
INFO - 2020-02-06 04:14:42 --> Language Class Initialized
ERROR - 2020-02-06 04:14:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:14:42 --> Database Driver Class Initialized
INFO - 2020-02-06 04:14:42 --> Final output sent to browser
ERROR - 2020-02-06 04:14:42 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-06 04:14:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-06 04:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:14:42 --> Config Class Initialized
INFO - 2020-02-06 04:14:42 --> Hooks Class Initialized
INFO - 2020-02-06 04:14:42 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:14:42 --> Total execution time: 0.6997
INFO - 2020-02-06 04:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:14:42 --> URI Class Initialized
DEBUG - 2020-02-06 04:14:42 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:14:42 --> Utf8 Class Initialized
INFO - 2020-02-06 04:14:42 --> Controller Class Initialized
INFO - 2020-02-06 04:14:42 --> Router Class Initialized
INFO - 2020-02-06 04:14:42 --> URI Class Initialized
INFO - 2020-02-06 04:14:42 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:14:42 --> Output Class Initialized
INFO - 2020-02-06 04:14:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:14:43 --> Router Class Initialized
INFO - 2020-02-06 04:14:43 --> Security Class Initialized
INFO - 2020-02-06 04:14:43 --> Model "M_pesan" initialized
DEBUG - 2020-02-06 04:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:43 --> Output Class Initialized
INFO - 2020-02-06 04:14:43 --> Input Class Initialized
INFO - 2020-02-06 04:14:43 --> Security Class Initialized
INFO - 2020-02-06 04:14:43 --> Helper loaded: form_helper
INFO - 2020-02-06 04:14:43 --> Form Validation Class Initialized
INFO - 2020-02-06 04:14:43 --> Language Class Initialized
DEBUG - 2020-02-06 04:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:14:43 --> Input Class Initialized
ERROR - 2020-02-06 04:14:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-06 04:14:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:14:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:14:43 --> Language Class Initialized
INFO - 2020-02-06 04:14:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-06 04:14:43 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-06 04:14:43 --> Final output sent to browser
DEBUG - 2020-02-06 04:14:43 --> Total execution time: 0.7132
INFO - 2020-02-06 04:15:02 --> Config Class Initialized
INFO - 2020-02-06 04:15:02 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:15:02 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:15:02 --> Utf8 Class Initialized
INFO - 2020-02-06 04:15:02 --> URI Class Initialized
INFO - 2020-02-06 04:15:02 --> Router Class Initialized
INFO - 2020-02-06 04:15:02 --> Output Class Initialized
INFO - 2020-02-06 04:15:02 --> Security Class Initialized
DEBUG - 2020-02-06 04:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:15:02 --> Input Class Initialized
INFO - 2020-02-06 04:15:02 --> Language Class Initialized
INFO - 2020-02-06 04:15:02 --> Loader Class Initialized
INFO - 2020-02-06 04:15:02 --> Helper loaded: url_helper
INFO - 2020-02-06 04:15:02 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:15:02 --> Controller Class Initialized
INFO - 2020-02-06 04:15:02 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:15:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:15:02 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:15:02 --> Helper loaded: form_helper
INFO - 2020-02-06 04:15:02 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:15:02 --> Query error: Column 'totalbayar' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('33', NULL, NULL, '1', '37')
INFO - 2020-02-06 04:15:02 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-06 04:18:20 --> Config Class Initialized
INFO - 2020-02-06 04:18:20 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:18:20 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:20 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:21 --> URI Class Initialized
INFO - 2020-02-06 04:18:21 --> Router Class Initialized
INFO - 2020-02-06 04:18:21 --> Output Class Initialized
INFO - 2020-02-06 04:18:21 --> Security Class Initialized
DEBUG - 2020-02-06 04:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:21 --> Input Class Initialized
INFO - 2020-02-06 04:18:21 --> Language Class Initialized
INFO - 2020-02-06 04:18:21 --> Loader Class Initialized
INFO - 2020-02-06 04:18:21 --> Helper loaded: url_helper
INFO - 2020-02-06 04:18:21 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:18:21 --> Controller Class Initialized
INFO - 2020-02-06 04:18:21 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:18:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:18:21 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:18:22 --> Helper loaded: form_helper
INFO - 2020-02-06 04:18:22 --> Form Validation Class Initialized
INFO - 2020-02-06 04:18:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:18:22 --> Final output sent to browser
DEBUG - 2020-02-06 04:18:22 --> Total execution time: 1.5472
INFO - 2020-02-06 04:18:22 --> Config Class Initialized
INFO - 2020-02-06 04:18:22 --> Config Class Initialized
INFO - 2020-02-06 04:18:22 --> Config Class Initialized
INFO - 2020-02-06 04:18:22 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:22 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:22 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:22 --> Config Class Initialized
INFO - 2020-02-06 04:18:22 --> Config Class Initialized
INFO - 2020-02-06 04:18:22 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:22 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:18:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:18:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:18:22 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:22 --> Config Class Initialized
INFO - 2020-02-06 04:18:22 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:22 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:22 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:22 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:18:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:18:22 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:22 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:22 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:22 --> URI Class Initialized
INFO - 2020-02-06 04:18:22 --> URI Class Initialized
INFO - 2020-02-06 04:18:22 --> URI Class Initialized
DEBUG - 2020-02-06 04:18:22 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:22 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:22 --> Router Class Initialized
INFO - 2020-02-06 04:18:22 --> Router Class Initialized
INFO - 2020-02-06 04:18:22 --> URI Class Initialized
INFO - 2020-02-06 04:18:22 --> URI Class Initialized
INFO - 2020-02-06 04:18:22 --> Router Class Initialized
INFO - 2020-02-06 04:18:22 --> URI Class Initialized
INFO - 2020-02-06 04:18:22 --> Router Class Initialized
INFO - 2020-02-06 04:18:22 --> Output Class Initialized
INFO - 2020-02-06 04:18:22 --> Output Class Initialized
INFO - 2020-02-06 04:18:22 --> Output Class Initialized
INFO - 2020-02-06 04:18:22 --> Router Class Initialized
INFO - 2020-02-06 04:18:22 --> Security Class Initialized
INFO - 2020-02-06 04:18:22 --> Security Class Initialized
INFO - 2020-02-06 04:18:22 --> Output Class Initialized
INFO - 2020-02-06 04:18:22 --> Router Class Initialized
INFO - 2020-02-06 04:18:22 --> Security Class Initialized
INFO - 2020-02-06 04:18:22 --> Output Class Initialized
INFO - 2020-02-06 04:18:22 --> Security Class Initialized
DEBUG - 2020-02-06 04:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:22 --> Security Class Initialized
INFO - 2020-02-06 04:18:22 --> Output Class Initialized
INFO - 2020-02-06 04:18:22 --> Input Class Initialized
INFO - 2020-02-06 04:18:22 --> Input Class Initialized
INFO - 2020-02-06 04:18:22 --> Input Class Initialized
INFO - 2020-02-06 04:18:22 --> Security Class Initialized
DEBUG - 2020-02-06 04:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:22 --> Input Class Initialized
INFO - 2020-02-06 04:18:22 --> Input Class Initialized
INFO - 2020-02-06 04:18:22 --> Language Class Initialized
INFO - 2020-02-06 04:18:22 --> Language Class Initialized
DEBUG - 2020-02-06 04:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:22 --> Language Class Initialized
INFO - 2020-02-06 04:18:22 --> Input Class Initialized
ERROR - 2020-02-06 04:18:22 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-06 04:18:22 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-06 04:18:22 --> Language Class Initialized
INFO - 2020-02-06 04:18:22 --> Language Class Initialized
ERROR - 2020-02-06 04:18:22 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-06 04:18:22 --> Language Class Initialized
ERROR - 2020-02-06 04:18:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:18:22 --> Loader Class Initialized
INFO - 2020-02-06 04:18:22 --> Config Class Initialized
INFO - 2020-02-06 04:18:22 --> Helper loaded: url_helper
INFO - 2020-02-06 04:18:22 --> Loader Class Initialized
INFO - 2020-02-06 04:18:22 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:22 --> Helper loaded: url_helper
INFO - 2020-02-06 04:18:23 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:18:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:18:23 --> Database Driver Class Initialized
INFO - 2020-02-06 04:18:23 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-06 04:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:18:23 --> Controller Class Initialized
INFO - 2020-02-06 04:18:23 --> URI Class Initialized
INFO - 2020-02-06 04:18:23 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:18:23 --> Router Class Initialized
INFO - 2020-02-06 04:18:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:18:23 --> Output Class Initialized
INFO - 2020-02-06 04:18:23 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:18:23 --> Security Class Initialized
DEBUG - 2020-02-06 04:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:23 --> Helper loaded: form_helper
INFO - 2020-02-06 04:18:23 --> Form Validation Class Initialized
INFO - 2020-02-06 04:18:23 --> Input Class Initialized
INFO - 2020-02-06 04:18:23 --> Language Class Initialized
ERROR - 2020-02-06 04:18:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:18:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-06 04:18:23 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-06 04:18:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:18:23 --> Config Class Initialized
INFO - 2020-02-06 04:18:23 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:23 --> Final output sent to browser
DEBUG - 2020-02-06 04:18:23 --> Total execution time: 0.7962
DEBUG - 2020-02-06 04:18:23 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:23 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:18:23 --> Controller Class Initialized
INFO - 2020-02-06 04:18:23 --> URI Class Initialized
INFO - 2020-02-06 04:18:23 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:18:23 --> Router Class Initialized
INFO - 2020-02-06 04:18:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:18:23 --> Output Class Initialized
INFO - 2020-02-06 04:18:23 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:18:23 --> Security Class Initialized
DEBUG - 2020-02-06 04:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:23 --> Helper loaded: form_helper
INFO - 2020-02-06 04:18:23 --> Form Validation Class Initialized
INFO - 2020-02-06 04:18:23 --> Input Class Initialized
INFO - 2020-02-06 04:18:23 --> Language Class Initialized
ERROR - 2020-02-06 04:18:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:18:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-06 04:18:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:18:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:18:23 --> Config Class Initialized
INFO - 2020-02-06 04:18:23 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:23 --> Final output sent to browser
DEBUG - 2020-02-06 04:18:23 --> Total execution time: 1.0471
DEBUG - 2020-02-06 04:18:23 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:23 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:23 --> URI Class Initialized
INFO - 2020-02-06 04:18:23 --> Router Class Initialized
INFO - 2020-02-06 04:18:23 --> Output Class Initialized
INFO - 2020-02-06 04:18:23 --> Security Class Initialized
DEBUG - 2020-02-06 04:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:23 --> Input Class Initialized
INFO - 2020-02-06 04:18:23 --> Language Class Initialized
ERROR - 2020-02-06 04:18:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:18:26 --> Config Class Initialized
INFO - 2020-02-06 04:18:26 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:18:26 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:26 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:26 --> URI Class Initialized
INFO - 2020-02-06 04:18:26 --> Router Class Initialized
INFO - 2020-02-06 04:18:26 --> Output Class Initialized
INFO - 2020-02-06 04:18:26 --> Security Class Initialized
DEBUG - 2020-02-06 04:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:26 --> Input Class Initialized
INFO - 2020-02-06 04:18:26 --> Language Class Initialized
INFO - 2020-02-06 04:18:26 --> Loader Class Initialized
INFO - 2020-02-06 04:18:26 --> Helper loaded: url_helper
INFO - 2020-02-06 04:18:26 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:18:27 --> Controller Class Initialized
INFO - 2020-02-06 04:18:27 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:18:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:18:27 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:18:27 --> Helper loaded: form_helper
INFO - 2020-02-06 04:18:27 --> Form Validation Class Initialized
INFO - 2020-02-06 04:18:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:18:27 --> Final output sent to browser
DEBUG - 2020-02-06 04:18:27 --> Total execution time: 1.5276
INFO - 2020-02-06 04:18:28 --> Config Class Initialized
INFO - 2020-02-06 04:18:28 --> Config Class Initialized
INFO - 2020-02-06 04:18:28 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:28 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:18:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:18:28 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:28 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:28 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:28 --> URI Class Initialized
INFO - 2020-02-06 04:18:28 --> URI Class Initialized
INFO - 2020-02-06 04:18:28 --> Router Class Initialized
INFO - 2020-02-06 04:18:28 --> Router Class Initialized
INFO - 2020-02-06 04:18:28 --> Output Class Initialized
INFO - 2020-02-06 04:18:28 --> Output Class Initialized
INFO - 2020-02-06 04:18:28 --> Config Class Initialized
INFO - 2020-02-06 04:18:28 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:28 --> Security Class Initialized
INFO - 2020-02-06 04:18:28 --> Security Class Initialized
DEBUG - 2020-02-06 04:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:18:28 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:28 --> Input Class Initialized
INFO - 2020-02-06 04:18:28 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:28 --> Input Class Initialized
INFO - 2020-02-06 04:18:28 --> Language Class Initialized
INFO - 2020-02-06 04:18:28 --> Language Class Initialized
INFO - 2020-02-06 04:18:28 --> URI Class Initialized
ERROR - 2020-02-06 04:18:28 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-06 04:18:28 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-06 04:18:28 --> Router Class Initialized
INFO - 2020-02-06 04:18:28 --> Output Class Initialized
INFO - 2020-02-06 04:18:28 --> Config Class Initialized
INFO - 2020-02-06 04:18:28 --> Config Class Initialized
INFO - 2020-02-06 04:18:28 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:28 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:28 --> Security Class Initialized
DEBUG - 2020-02-06 04:18:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:18:28 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:28 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:28 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:28 --> Input Class Initialized
INFO - 2020-02-06 04:18:28 --> Language Class Initialized
INFO - 2020-02-06 04:18:28 --> URI Class Initialized
INFO - 2020-02-06 04:18:28 --> URI Class Initialized
ERROR - 2020-02-06 04:18:28 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-06 04:18:28 --> Router Class Initialized
INFO - 2020-02-06 04:18:28 --> Router Class Initialized
INFO - 2020-02-06 04:18:28 --> Output Class Initialized
INFO - 2020-02-06 04:18:28 --> Output Class Initialized
INFO - 2020-02-06 04:18:28 --> Config Class Initialized
INFO - 2020-02-06 04:18:28 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:28 --> Security Class Initialized
INFO - 2020-02-06 04:18:28 --> Security Class Initialized
DEBUG - 2020-02-06 04:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:18:28 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:28 --> Input Class Initialized
INFO - 2020-02-06 04:18:28 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:28 --> Input Class Initialized
INFO - 2020-02-06 04:18:29 --> Language Class Initialized
INFO - 2020-02-06 04:18:29 --> URI Class Initialized
INFO - 2020-02-06 04:18:29 --> Language Class Initialized
ERROR - 2020-02-06 04:18:29 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-06 04:18:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-06 04:18:29 --> Router Class Initialized
INFO - 2020-02-06 04:18:29 --> Output Class Initialized
INFO - 2020-02-06 04:18:29 --> Config Class Initialized
INFO - 2020-02-06 04:18:29 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:29 --> Config Class Initialized
INFO - 2020-02-06 04:18:29 --> Security Class Initialized
INFO - 2020-02-06 04:18:29 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:18:29 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:29 --> Input Class Initialized
INFO - 2020-02-06 04:18:29 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:18:29 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:29 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:29 --> Language Class Initialized
INFO - 2020-02-06 04:18:29 --> URI Class Initialized
INFO - 2020-02-06 04:18:29 --> URI Class Initialized
INFO - 2020-02-06 04:18:29 --> Router Class Initialized
ERROR - 2020-02-06 04:18:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:18:29 --> Output Class Initialized
INFO - 2020-02-06 04:18:29 --> Router Class Initialized
INFO - 2020-02-06 04:18:29 --> Security Class Initialized
INFO - 2020-02-06 04:18:29 --> Output Class Initialized
DEBUG - 2020-02-06 04:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:29 --> Security Class Initialized
INFO - 2020-02-06 04:18:29 --> Input Class Initialized
INFO - 2020-02-06 04:18:29 --> Config Class Initialized
DEBUG - 2020-02-06 04:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:29 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:29 --> Input Class Initialized
INFO - 2020-02-06 04:18:29 --> Language Class Initialized
INFO - 2020-02-06 04:18:29 --> Language Class Initialized
ERROR - 2020-02-06 04:18:29 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-06 04:18:29 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:29 --> Utf8 Class Initialized
ERROR - 2020-02-06 04:18:29 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-06 04:18:29 --> Config Class Initialized
INFO - 2020-02-06 04:18:29 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:29 --> URI Class Initialized
INFO - 2020-02-06 04:18:29 --> Config Class Initialized
INFO - 2020-02-06 04:18:29 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:29 --> Router Class Initialized
DEBUG - 2020-02-06 04:18:29 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:29 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:29 --> Output Class Initialized
DEBUG - 2020-02-06 04:18:29 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:29 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:29 --> URI Class Initialized
INFO - 2020-02-06 04:18:29 --> Security Class Initialized
INFO - 2020-02-06 04:18:29 --> URI Class Initialized
DEBUG - 2020-02-06 04:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:29 --> Router Class Initialized
INFO - 2020-02-06 04:18:29 --> Input Class Initialized
INFO - 2020-02-06 04:18:29 --> Router Class Initialized
INFO - 2020-02-06 04:18:29 --> Output Class Initialized
INFO - 2020-02-06 04:18:29 --> Output Class Initialized
INFO - 2020-02-06 04:18:29 --> Security Class Initialized
INFO - 2020-02-06 04:18:29 --> Language Class Initialized
ERROR - 2020-02-06 04:18:29 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-06 04:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:29 --> Security Class Initialized
INFO - 2020-02-06 04:18:29 --> Input Class Initialized
DEBUG - 2020-02-06 04:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:29 --> Config Class Initialized
INFO - 2020-02-06 04:18:29 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:29 --> Input Class Initialized
INFO - 2020-02-06 04:18:29 --> Language Class Initialized
INFO - 2020-02-06 04:18:29 --> Language Class Initialized
DEBUG - 2020-02-06 04:18:29 --> UTF-8 Support Enabled
ERROR - 2020-02-06 04:18:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-06 04:18:30 --> Utf8 Class Initialized
ERROR - 2020-02-06 04:18:30 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-06 04:18:30 --> Config Class Initialized
INFO - 2020-02-06 04:18:30 --> Hooks Class Initialized
INFO - 2020-02-06 04:18:30 --> URI Class Initialized
INFO - 2020-02-06 04:18:30 --> Router Class Initialized
DEBUG - 2020-02-06 04:18:30 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:18:30 --> Utf8 Class Initialized
INFO - 2020-02-06 04:18:30 --> Output Class Initialized
INFO - 2020-02-06 04:18:30 --> URI Class Initialized
INFO - 2020-02-06 04:18:30 --> Security Class Initialized
DEBUG - 2020-02-06 04:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:30 --> Router Class Initialized
INFO - 2020-02-06 04:18:30 --> Input Class Initialized
INFO - 2020-02-06 04:18:30 --> Output Class Initialized
INFO - 2020-02-06 04:18:30 --> Language Class Initialized
INFO - 2020-02-06 04:18:30 --> Security Class Initialized
DEBUG - 2020-02-06 04:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:18:30 --> Loader Class Initialized
INFO - 2020-02-06 04:18:30 --> Input Class Initialized
INFO - 2020-02-06 04:18:30 --> Helper loaded: url_helper
INFO - 2020-02-06 04:18:30 --> Language Class Initialized
INFO - 2020-02-06 04:18:30 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:18:30 --> Loader Class Initialized
INFO - 2020-02-06 04:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:18:30 --> Helper loaded: url_helper
INFO - 2020-02-06 04:18:30 --> Controller Class Initialized
INFO - 2020-02-06 04:18:30 --> Database Driver Class Initialized
INFO - 2020-02-06 04:18:30 --> Model "M_tiket" initialized
DEBUG - 2020-02-06 04:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:18:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:18:30 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:18:30 --> Helper loaded: form_helper
INFO - 2020-02-06 04:18:30 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:18:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:18:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:18:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:18:30 --> Final output sent to browser
DEBUG - 2020-02-06 04:18:30 --> Total execution time: 0.8391
INFO - 2020-02-06 04:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:18:30 --> Controller Class Initialized
INFO - 2020-02-06 04:18:30 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:18:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:18:30 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:18:30 --> Helper loaded: form_helper
INFO - 2020-02-06 04:18:30 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:18:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:18:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:18:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:18:31 --> Final output sent to browser
DEBUG - 2020-02-06 04:18:31 --> Total execution time: 1.0899
INFO - 2020-02-06 04:19:05 --> Config Class Initialized
INFO - 2020-02-06 04:19:05 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:19:05 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:19:05 --> Utf8 Class Initialized
INFO - 2020-02-06 04:19:05 --> URI Class Initialized
INFO - 2020-02-06 04:19:05 --> Router Class Initialized
INFO - 2020-02-06 04:19:05 --> Output Class Initialized
INFO - 2020-02-06 04:19:05 --> Security Class Initialized
DEBUG - 2020-02-06 04:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:19:05 --> Input Class Initialized
INFO - 2020-02-06 04:19:05 --> Language Class Initialized
INFO - 2020-02-06 04:19:05 --> Loader Class Initialized
INFO - 2020-02-06 04:19:05 --> Helper loaded: url_helper
INFO - 2020-02-06 04:19:05 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:19:05 --> Controller Class Initialized
INFO - 2020-02-06 04:19:05 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:19:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:19:06 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:19:06 --> Helper loaded: form_helper
INFO - 2020-02-06 04:19:06 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:19:06 --> Query error: Column 'status_pemesanan' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('33', '100000', NULL, '1', '37')
INFO - 2020-02-06 04:19:06 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-06 04:20:05 --> Config Class Initialized
INFO - 2020-02-06 04:20:05 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:05 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:05 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:06 --> URI Class Initialized
INFO - 2020-02-06 04:20:06 --> Router Class Initialized
INFO - 2020-02-06 04:20:06 --> Output Class Initialized
INFO - 2020-02-06 04:20:06 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:06 --> Input Class Initialized
INFO - 2020-02-06 04:20:06 --> Language Class Initialized
INFO - 2020-02-06 04:20:06 --> Loader Class Initialized
INFO - 2020-02-06 04:20:06 --> Helper loaded: url_helper
INFO - 2020-02-06 04:20:06 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:20:06 --> Controller Class Initialized
INFO - 2020-02-06 04:20:06 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:20:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:20:06 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:20:06 --> Helper loaded: form_helper
INFO - 2020-02-06 04:20:06 --> Form Validation Class Initialized
INFO - 2020-02-06 04:20:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:20:06 --> Final output sent to browser
DEBUG - 2020-02-06 04:20:06 --> Total execution time: 0.7187
INFO - 2020-02-06 04:20:06 --> Config Class Initialized
INFO - 2020-02-06 04:20:06 --> Hooks Class Initialized
INFO - 2020-02-06 04:20:06 --> Config Class Initialized
INFO - 2020-02-06 04:20:06 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:06 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:06 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:20:06 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:06 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:06 --> URI Class Initialized
INFO - 2020-02-06 04:20:06 --> URI Class Initialized
INFO - 2020-02-06 04:20:06 --> Router Class Initialized
INFO - 2020-02-06 04:20:06 --> Router Class Initialized
INFO - 2020-02-06 04:20:06 --> Output Class Initialized
INFO - 2020-02-06 04:20:06 --> Security Class Initialized
INFO - 2020-02-06 04:20:06 --> Output Class Initialized
INFO - 2020-02-06 04:20:06 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:06 --> Input Class Initialized
DEBUG - 2020-02-06 04:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:06 --> Input Class Initialized
INFO - 2020-02-06 04:20:06 --> Language Class Initialized
INFO - 2020-02-06 04:20:07 --> Language Class Initialized
INFO - 2020-02-06 04:20:07 --> Loader Class Initialized
INFO - 2020-02-06 04:20:07 --> Helper loaded: url_helper
INFO - 2020-02-06 04:20:07 --> Loader Class Initialized
INFO - 2020-02-06 04:20:07 --> Helper loaded: url_helper
INFO - 2020-02-06 04:20:07 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:20:07 --> Database Driver Class Initialized
INFO - 2020-02-06 04:20:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-06 04:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:20:07 --> Controller Class Initialized
INFO - 2020-02-06 04:20:07 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:20:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:20:07 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:20:07 --> Helper loaded: form_helper
INFO - 2020-02-06 04:20:07 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:20:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:20:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:20:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:20:07 --> Final output sent to browser
DEBUG - 2020-02-06 04:20:07 --> Total execution time: 0.7652
INFO - 2020-02-06 04:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:20:07 --> Controller Class Initialized
INFO - 2020-02-06 04:20:07 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:20:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:20:07 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:20:07 --> Helper loaded: form_helper
INFO - 2020-02-06 04:20:07 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:20:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:20:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:20:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:20:07 --> Final output sent to browser
DEBUG - 2020-02-06 04:20:07 --> Total execution time: 1.0901
INFO - 2020-02-06 04:20:10 --> Config Class Initialized
INFO - 2020-02-06 04:20:10 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:10 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:10 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:10 --> URI Class Initialized
INFO - 2020-02-06 04:20:10 --> Router Class Initialized
INFO - 2020-02-06 04:20:10 --> Output Class Initialized
INFO - 2020-02-06 04:20:10 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:10 --> Input Class Initialized
INFO - 2020-02-06 04:20:10 --> Language Class Initialized
INFO - 2020-02-06 04:20:10 --> Loader Class Initialized
INFO - 2020-02-06 04:20:10 --> Helper loaded: url_helper
INFO - 2020-02-06 04:20:10 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:20:10 --> Controller Class Initialized
INFO - 2020-02-06 04:20:10 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:20:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:20:10 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:20:10 --> Helper loaded: form_helper
INFO - 2020-02-06 04:20:10 --> Form Validation Class Initialized
INFO - 2020-02-06 04:20:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:20:10 --> Final output sent to browser
INFO - 2020-02-06 04:20:10 --> Config Class Initialized
INFO - 2020-02-06 04:20:10 --> Config Class Initialized
INFO - 2020-02-06 04:20:10 --> Config Class Initialized
INFO - 2020-02-06 04:20:10 --> Hooks Class Initialized
INFO - 2020-02-06 04:20:10 --> Config Class Initialized
DEBUG - 2020-02-06 04:20:10 --> Total execution time: 0.5578
INFO - 2020-02-06 04:20:10 --> Hooks Class Initialized
INFO - 2020-02-06 04:20:10 --> Hooks Class Initialized
INFO - 2020-02-06 04:20:10 --> Config Class Initialized
INFO - 2020-02-06 04:20:10 --> Hooks Class Initialized
INFO - 2020-02-06 04:20:10 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:20:10 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:10 --> Config Class Initialized
INFO - 2020-02-06 04:20:10 --> Hooks Class Initialized
INFO - 2020-02-06 04:20:10 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:10 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:10 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:20:10 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:10 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:10 --> URI Class Initialized
INFO - 2020-02-06 04:20:10 --> URI Class Initialized
DEBUG - 2020-02-06 04:20:10 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:10 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:10 --> URI Class Initialized
INFO - 2020-02-06 04:20:10 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:10 --> URI Class Initialized
INFO - 2020-02-06 04:20:10 --> Router Class Initialized
INFO - 2020-02-06 04:20:10 --> Router Class Initialized
INFO - 2020-02-06 04:20:10 --> Router Class Initialized
INFO - 2020-02-06 04:20:10 --> URI Class Initialized
INFO - 2020-02-06 04:20:10 --> Output Class Initialized
INFO - 2020-02-06 04:20:10 --> URI Class Initialized
INFO - 2020-02-06 04:20:10 --> Output Class Initialized
INFO - 2020-02-06 04:20:10 --> Router Class Initialized
INFO - 2020-02-06 04:20:10 --> Output Class Initialized
INFO - 2020-02-06 04:20:10 --> Router Class Initialized
INFO - 2020-02-06 04:20:10 --> Security Class Initialized
INFO - 2020-02-06 04:20:10 --> Security Class Initialized
INFO - 2020-02-06 04:20:10 --> Security Class Initialized
INFO - 2020-02-06 04:20:10 --> Output Class Initialized
INFO - 2020-02-06 04:20:10 --> Router Class Initialized
INFO - 2020-02-06 04:20:10 --> Output Class Initialized
DEBUG - 2020-02-06 04:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:10 --> Security Class Initialized
INFO - 2020-02-06 04:20:10 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:10 --> Output Class Initialized
DEBUG - 2020-02-06 04:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:10 --> Input Class Initialized
INFO - 2020-02-06 04:20:10 --> Input Class Initialized
INFO - 2020-02-06 04:20:10 --> Input Class Initialized
DEBUG - 2020-02-06 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:10 --> Security Class Initialized
INFO - 2020-02-06 04:20:10 --> Input Class Initialized
INFO - 2020-02-06 04:20:10 --> Input Class Initialized
INFO - 2020-02-06 04:20:10 --> Language Class Initialized
INFO - 2020-02-06 04:20:10 --> Language Class Initialized
DEBUG - 2020-02-06 04:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:10 --> Language Class Initialized
INFO - 2020-02-06 04:20:10 --> Input Class Initialized
INFO - 2020-02-06 04:20:10 --> Language Class Initialized
ERROR - 2020-02-06 04:20:10 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-06 04:20:10 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-06 04:20:10 --> Language Class Initialized
INFO - 2020-02-06 04:20:10 --> Loader Class Initialized
INFO - 2020-02-06 04:20:10 --> Language Class Initialized
INFO - 2020-02-06 04:20:10 --> Helper loaded: url_helper
ERROR - 2020-02-06 04:20:10 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-06 04:20:11 --> Loader Class Initialized
INFO - 2020-02-06 04:20:11 --> Config Class Initialized
INFO - 2020-02-06 04:20:11 --> Config Class Initialized
INFO - 2020-02-06 04:20:11 --> Hooks Class Initialized
INFO - 2020-02-06 04:20:11 --> Hooks Class Initialized
INFO - 2020-02-06 04:20:11 --> Helper loaded: url_helper
ERROR - 2020-02-06 04:20:11 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-06 04:20:11 --> Database Driver Class Initialized
INFO - 2020-02-06 04:20:11 --> Config Class Initialized
INFO - 2020-02-06 04:20:11 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:20:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:20:11 --> Database Driver Class Initialized
INFO - 2020-02-06 04:20:11 --> Config Class Initialized
INFO - 2020-02-06 04:20:11 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:11 --> Hooks Class Initialized
INFO - 2020-02-06 04:20:11 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-06 04:20:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:20:11 --> Controller Class Initialized
INFO - 2020-02-06 04:20:11 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:11 --> URI Class Initialized
INFO - 2020-02-06 04:20:11 --> URI Class Initialized
DEBUG - 2020-02-06 04:20:11 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:11 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:11 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:20:11 --> URI Class Initialized
INFO - 2020-02-06 04:20:11 --> Router Class Initialized
INFO - 2020-02-06 04:20:11 --> Router Class Initialized
INFO - 2020-02-06 04:20:11 --> URI Class Initialized
INFO - 2020-02-06 04:20:11 --> Output Class Initialized
INFO - 2020-02-06 04:20:11 --> Output Class Initialized
INFO - 2020-02-06 04:20:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:20:11 --> Router Class Initialized
INFO - 2020-02-06 04:20:11 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:20:11 --> Security Class Initialized
INFO - 2020-02-06 04:20:11 --> Router Class Initialized
INFO - 2020-02-06 04:20:11 --> Security Class Initialized
INFO - 2020-02-06 04:20:11 --> Output Class Initialized
DEBUG - 2020-02-06 04:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:11 --> Output Class Initialized
DEBUG - 2020-02-06 04:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:11 --> Security Class Initialized
INFO - 2020-02-06 04:20:11 --> Helper loaded: form_helper
INFO - 2020-02-06 04:20:11 --> Form Validation Class Initialized
INFO - 2020-02-06 04:20:11 --> Input Class Initialized
INFO - 2020-02-06 04:20:11 --> Input Class Initialized
DEBUG - 2020-02-06 04:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:11 --> Security Class Initialized
INFO - 2020-02-06 04:20:11 --> Input Class Initialized
INFO - 2020-02-06 04:20:11 --> Language Class Initialized
INFO - 2020-02-06 04:20:11 --> Language Class Initialized
DEBUG - 2020-02-06 04:20:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-06 04:20:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-06 04:20:11 --> Input Class Initialized
INFO - 2020-02-06 04:20:11 --> Language Class Initialized
ERROR - 2020-02-06 04:20:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-06 04:20:11 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-06 04:20:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:20:11 --> Language Class Initialized
ERROR - 2020-02-06 04:20:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:20:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:20:11 --> Config Class Initialized
INFO - 2020-02-06 04:20:11 --> Config Class Initialized
INFO - 2020-02-06 04:20:11 --> Hooks Class Initialized
INFO - 2020-02-06 04:20:11 --> Hooks Class Initialized
INFO - 2020-02-06 04:20:11 --> Final output sent to browser
ERROR - 2020-02-06 04:20:11 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-06 04:20:11 --> Config Class Initialized
INFO - 2020-02-06 04:20:11 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:11 --> Total execution time: 0.7032
DEBUG - 2020-02-06 04:20:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:20:11 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:11 --> Config Class Initialized
INFO - 2020-02-06 04:20:11 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:11 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:11 --> Hooks Class Initialized
INFO - 2020-02-06 04:20:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-06 04:20:11 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:11 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:11 --> Controller Class Initialized
INFO - 2020-02-06 04:20:11 --> URI Class Initialized
INFO - 2020-02-06 04:20:11 --> URI Class Initialized
DEBUG - 2020-02-06 04:20:11 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:11 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:20:11 --> URI Class Initialized
INFO - 2020-02-06 04:20:11 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:11 --> Router Class Initialized
INFO - 2020-02-06 04:20:11 --> Router Class Initialized
INFO - 2020-02-06 04:20:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:20:11 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:20:11 --> Helper loaded: form_helper
INFO - 2020-02-06 04:20:11 --> Router Class Initialized
INFO - 2020-02-06 04:20:11 --> Output Class Initialized
INFO - 2020-02-06 04:20:11 --> Form Validation Class Initialized
INFO - 2020-02-06 04:20:11 --> Output Class Initialized
INFO - 2020-02-06 04:20:11 --> URI Class Initialized
INFO - 2020-02-06 04:20:11 --> Router Class Initialized
INFO - 2020-02-06 04:20:11 --> Output Class Initialized
INFO - 2020-02-06 04:20:11 --> Security Class Initialized
INFO - 2020-02-06 04:20:11 --> Security Class Initialized
ERROR - 2020-02-06 04:20:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:20:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:20:11 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:11 --> Output Class Initialized
DEBUG - 2020-02-06 04:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:11 --> Input Class Initialized
INFO - 2020-02-06 04:20:11 --> Input Class Initialized
INFO - 2020-02-06 04:20:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-06 04:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:11 --> Security Class Initialized
INFO - 2020-02-06 04:20:11 --> Final output sent to browser
INFO - 2020-02-06 04:20:11 --> Input Class Initialized
INFO - 2020-02-06 04:20:11 --> Language Class Initialized
INFO - 2020-02-06 04:20:11 --> Language Class Initialized
DEBUG - 2020-02-06 04:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:20:11 --> Total execution time: 1.0765
INFO - 2020-02-06 04:20:11 --> Input Class Initialized
INFO - 2020-02-06 04:20:11 --> Language Class Initialized
ERROR - 2020-02-06 04:20:11 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-06 04:20:11 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-06 04:20:11 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-06 04:20:11 --> Language Class Initialized
ERROR - 2020-02-06 04:20:11 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-06 04:20:11 --> Config Class Initialized
INFO - 2020-02-06 04:20:11 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:11 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:11 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:11 --> URI Class Initialized
INFO - 2020-02-06 04:20:12 --> Router Class Initialized
INFO - 2020-02-06 04:20:12 --> Output Class Initialized
INFO - 2020-02-06 04:20:12 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:12 --> Input Class Initialized
INFO - 2020-02-06 04:20:12 --> Language Class Initialized
ERROR - 2020-02-06 04:20:12 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-06 04:20:12 --> Config Class Initialized
INFO - 2020-02-06 04:20:12 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:12 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:12 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:12 --> URI Class Initialized
INFO - 2020-02-06 04:20:12 --> Router Class Initialized
INFO - 2020-02-06 04:20:12 --> Output Class Initialized
INFO - 2020-02-06 04:20:12 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:12 --> Input Class Initialized
INFO - 2020-02-06 04:20:12 --> Language Class Initialized
ERROR - 2020-02-06 04:20:12 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-06 04:20:12 --> Config Class Initialized
INFO - 2020-02-06 04:20:12 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:12 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:12 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:12 --> URI Class Initialized
INFO - 2020-02-06 04:20:12 --> Router Class Initialized
INFO - 2020-02-06 04:20:12 --> Output Class Initialized
INFO - 2020-02-06 04:20:12 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:12 --> Input Class Initialized
INFO - 2020-02-06 04:20:12 --> Language Class Initialized
ERROR - 2020-02-06 04:20:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:20:12 --> Config Class Initialized
INFO - 2020-02-06 04:20:12 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:12 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:12 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:12 --> URI Class Initialized
INFO - 2020-02-06 04:20:12 --> Router Class Initialized
INFO - 2020-02-06 04:20:12 --> Output Class Initialized
INFO - 2020-02-06 04:20:12 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:13 --> Input Class Initialized
INFO - 2020-02-06 04:20:13 --> Language Class Initialized
ERROR - 2020-02-06 04:20:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:20:13 --> Config Class Initialized
INFO - 2020-02-06 04:20:13 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:13 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:13 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:13 --> URI Class Initialized
INFO - 2020-02-06 04:20:13 --> Router Class Initialized
INFO - 2020-02-06 04:20:13 --> Output Class Initialized
INFO - 2020-02-06 04:20:13 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:13 --> Input Class Initialized
INFO - 2020-02-06 04:20:13 --> Language Class Initialized
ERROR - 2020-02-06 04:20:13 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-06 04:20:13 --> Config Class Initialized
INFO - 2020-02-06 04:20:13 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:13 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:13 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:13 --> URI Class Initialized
INFO - 2020-02-06 04:20:13 --> Router Class Initialized
INFO - 2020-02-06 04:20:13 --> Output Class Initialized
INFO - 2020-02-06 04:20:13 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:13 --> Input Class Initialized
INFO - 2020-02-06 04:20:13 --> Language Class Initialized
ERROR - 2020-02-06 04:20:13 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-06 04:20:13 --> Config Class Initialized
INFO - 2020-02-06 04:20:13 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:13 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:13 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:13 --> URI Class Initialized
INFO - 2020-02-06 04:20:13 --> Router Class Initialized
INFO - 2020-02-06 04:20:13 --> Output Class Initialized
INFO - 2020-02-06 04:20:13 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:13 --> Input Class Initialized
INFO - 2020-02-06 04:20:13 --> Language Class Initialized
ERROR - 2020-02-06 04:20:13 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-06 04:20:13 --> Config Class Initialized
INFO - 2020-02-06 04:20:14 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:14 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:14 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:14 --> URI Class Initialized
INFO - 2020-02-06 04:20:14 --> Router Class Initialized
INFO - 2020-02-06 04:20:14 --> Output Class Initialized
INFO - 2020-02-06 04:20:14 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:14 --> Input Class Initialized
INFO - 2020-02-06 04:20:14 --> Language Class Initialized
ERROR - 2020-02-06 04:20:14 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-06 04:20:29 --> Config Class Initialized
INFO - 2020-02-06 04:20:29 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:20:29 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:20:29 --> Utf8 Class Initialized
INFO - 2020-02-06 04:20:29 --> URI Class Initialized
INFO - 2020-02-06 04:20:29 --> Router Class Initialized
INFO - 2020-02-06 04:20:29 --> Output Class Initialized
INFO - 2020-02-06 04:20:29 --> Security Class Initialized
DEBUG - 2020-02-06 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:20:29 --> Input Class Initialized
INFO - 2020-02-06 04:20:29 --> Language Class Initialized
INFO - 2020-02-06 04:20:29 --> Loader Class Initialized
INFO - 2020-02-06 04:20:29 --> Helper loaded: url_helper
INFO - 2020-02-06 04:20:29 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:20:29 --> Controller Class Initialized
INFO - 2020-02-06 04:20:30 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:20:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:20:30 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:20:30 --> Helper loaded: form_helper
INFO - 2020-02-06 04:20:30 --> Form Validation Class Initialized
INFO - 2020-02-06 04:20:30 --> Final output sent to browser
DEBUG - 2020-02-06 04:20:30 --> Total execution time: 0.7064
INFO - 2020-02-06 04:22:37 --> Config Class Initialized
INFO - 2020-02-06 04:22:37 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:22:37 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:22:37 --> Utf8 Class Initialized
INFO - 2020-02-06 04:22:38 --> URI Class Initialized
INFO - 2020-02-06 04:22:38 --> Router Class Initialized
INFO - 2020-02-06 04:22:38 --> Output Class Initialized
INFO - 2020-02-06 04:22:38 --> Security Class Initialized
DEBUG - 2020-02-06 04:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:22:38 --> Input Class Initialized
INFO - 2020-02-06 04:22:38 --> Language Class Initialized
INFO - 2020-02-06 04:22:38 --> Loader Class Initialized
INFO - 2020-02-06 04:22:38 --> Helper loaded: url_helper
INFO - 2020-02-06 04:22:38 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:22:38 --> Controller Class Initialized
INFO - 2020-02-06 04:22:38 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:22:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:22:38 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:22:38 --> Helper loaded: form_helper
INFO - 2020-02-06 04:22:38 --> Form Validation Class Initialized
INFO - 2020-02-06 04:22:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:22:38 --> Final output sent to browser
DEBUG - 2020-02-06 04:22:38 --> Total execution time: 1.0114
INFO - 2020-02-06 04:25:59 --> Config Class Initialized
INFO - 2020-02-06 04:25:59 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:25:59 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:25:59 --> Utf8 Class Initialized
INFO - 2020-02-06 04:25:59 --> URI Class Initialized
INFO - 2020-02-06 04:25:59 --> Router Class Initialized
INFO - 2020-02-06 04:25:59 --> Output Class Initialized
INFO - 2020-02-06 04:25:59 --> Security Class Initialized
DEBUG - 2020-02-06 04:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:25:59 --> Input Class Initialized
INFO - 2020-02-06 04:25:59 --> Language Class Initialized
INFO - 2020-02-06 04:25:59 --> Loader Class Initialized
INFO - 2020-02-06 04:25:59 --> Helper loaded: url_helper
INFO - 2020-02-06 04:25:59 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:25:59 --> Controller Class Initialized
INFO - 2020-02-06 04:25:59 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:25:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:25:59 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:25:59 --> Helper loaded: form_helper
INFO - 2020-02-06 04:26:00 --> Form Validation Class Initialized
INFO - 2020-02-06 04:26:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:26:00 --> Final output sent to browser
INFO - 2020-02-06 04:26:00 --> Config Class Initialized
INFO - 2020-02-06 04:26:00 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:00 --> Total execution time: 0.6735
INFO - 2020-02-06 04:26:00 --> Config Class Initialized
INFO - 2020-02-06 04:26:00 --> Config Class Initialized
DEBUG - 2020-02-06 04:26:00 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:00 --> Config Class Initialized
INFO - 2020-02-06 04:26:00 --> Hooks Class Initialized
INFO - 2020-02-06 04:26:00 --> Hooks Class Initialized
INFO - 2020-02-06 04:26:00 --> Config Class Initialized
INFO - 2020-02-06 04:26:00 --> Config Class Initialized
INFO - 2020-02-06 04:26:00 --> Hooks Class Initialized
INFO - 2020-02-06 04:26:00 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:00 --> Hooks Class Initialized
INFO - 2020-02-06 04:26:00 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:26:00 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:00 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:00 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:26:00 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:00 --> URI Class Initialized
DEBUG - 2020-02-06 04:26:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:26:00 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:00 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:00 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:00 --> Router Class Initialized
INFO - 2020-02-06 04:26:00 --> URI Class Initialized
INFO - 2020-02-06 04:26:00 --> URI Class Initialized
INFO - 2020-02-06 04:26:00 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:00 --> Router Class Initialized
INFO - 2020-02-06 04:26:00 --> Router Class Initialized
INFO - 2020-02-06 04:26:00 --> URI Class Initialized
INFO - 2020-02-06 04:26:00 --> Output Class Initialized
INFO - 2020-02-06 04:26:00 --> URI Class Initialized
INFO - 2020-02-06 04:26:00 --> Router Class Initialized
INFO - 2020-02-06 04:26:00 --> Security Class Initialized
INFO - 2020-02-06 04:26:00 --> Router Class Initialized
INFO - 2020-02-06 04:26:00 --> URI Class Initialized
INFO - 2020-02-06 04:26:00 --> Output Class Initialized
INFO - 2020-02-06 04:26:00 --> Output Class Initialized
DEBUG - 2020-02-06 04:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:00 --> Router Class Initialized
INFO - 2020-02-06 04:26:00 --> Output Class Initialized
INFO - 2020-02-06 04:26:00 --> Output Class Initialized
INFO - 2020-02-06 04:26:00 --> Security Class Initialized
INFO - 2020-02-06 04:26:00 --> Security Class Initialized
INFO - 2020-02-06 04:26:00 --> Input Class Initialized
INFO - 2020-02-06 04:26:00 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:00 --> Output Class Initialized
INFO - 2020-02-06 04:26:00 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:00 --> Input Class Initialized
INFO - 2020-02-06 04:26:00 --> Language Class Initialized
INFO - 2020-02-06 04:26:00 --> Input Class Initialized
DEBUG - 2020-02-06 04:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:00 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:00 --> Input Class Initialized
INFO - 2020-02-06 04:26:00 --> Language Class Initialized
INFO - 2020-02-06 04:26:00 --> Input Class Initialized
INFO - 2020-02-06 04:26:00 --> Language Class Initialized
DEBUG - 2020-02-06 04:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:00 --> Loader Class Initialized
INFO - 2020-02-06 04:26:00 --> Language Class Initialized
INFO - 2020-02-06 04:26:00 --> Language Class Initialized
ERROR - 2020-02-06 04:26:00 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-06 04:26:00 --> Input Class Initialized
INFO - 2020-02-06 04:26:00 --> Helper loaded: url_helper
INFO - 2020-02-06 04:26:00 --> Loader Class Initialized
INFO - 2020-02-06 04:26:00 --> Language Class Initialized
ERROR - 2020-02-06 04:26:00 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-06 04:26:00 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-06 04:26:00 --> Helper loaded: url_helper
INFO - 2020-02-06 04:26:00 --> Database Driver Class Initialized
INFO - 2020-02-06 04:26:00 --> Config Class Initialized
INFO - 2020-02-06 04:26:00 --> Hooks Class Initialized
ERROR - 2020-02-06 04:26:00 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-06 04:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:26:00 --> Database Driver Class Initialized
INFO - 2020-02-06 04:26:00 --> Config Class Initialized
INFO - 2020-02-06 04:26:00 --> Config Class Initialized
INFO - 2020-02-06 04:26:00 --> Hooks Class Initialized
INFO - 2020-02-06 04:26:00 --> Hooks Class Initialized
INFO - 2020-02-06 04:26:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-06 04:26:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:26:00 --> Config Class Initialized
INFO - 2020-02-06 04:26:00 --> Hooks Class Initialized
INFO - 2020-02-06 04:26:00 --> Controller Class Initialized
INFO - 2020-02-06 04:26:00 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:26:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:26:00 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:00 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:00 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:00 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:26:00 --> URI Class Initialized
DEBUG - 2020-02-06 04:26:00 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:00 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:26:00 --> URI Class Initialized
INFO - 2020-02-06 04:26:00 --> URI Class Initialized
INFO - 2020-02-06 04:26:00 --> Router Class Initialized
INFO - 2020-02-06 04:26:00 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:26:00 --> Router Class Initialized
INFO - 2020-02-06 04:26:00 --> Output Class Initialized
INFO - 2020-02-06 04:26:00 --> URI Class Initialized
INFO - 2020-02-06 04:26:00 --> Router Class Initialized
INFO - 2020-02-06 04:26:00 --> Router Class Initialized
INFO - 2020-02-06 04:26:00 --> Output Class Initialized
INFO - 2020-02-06 04:26:00 --> Output Class Initialized
INFO - 2020-02-06 04:26:00 --> Helper loaded: form_helper
INFO - 2020-02-06 04:26:00 --> Security Class Initialized
INFO - 2020-02-06 04:26:00 --> Form Validation Class Initialized
DEBUG - 2020-02-06 04:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:00 --> Security Class Initialized
INFO - 2020-02-06 04:26:00 --> Security Class Initialized
INFO - 2020-02-06 04:26:00 --> Output Class Initialized
INFO - 2020-02-06 04:26:00 --> Input Class Initialized
DEBUG - 2020-02-06 04:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:00 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-06 04:26:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-06 04:26:00 --> Input Class Initialized
INFO - 2020-02-06 04:26:00 --> Input Class Initialized
INFO - 2020-02-06 04:26:00 --> Language Class Initialized
ERROR - 2020-02-06 04:26:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-06 04:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:00 --> Input Class Initialized
INFO - 2020-02-06 04:26:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:26:00 --> Language Class Initialized
ERROR - 2020-02-06 04:26:00 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-06 04:26:00 --> Language Class Initialized
INFO - 2020-02-06 04:26:00 --> Language Class Initialized
INFO - 2020-02-06 04:26:00 --> Final output sent to browser
ERROR - 2020-02-06 04:26:00 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-06 04:26:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:26:00 --> Config Class Initialized
INFO - 2020-02-06 04:26:00 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:00 --> Total execution time: 0.7467
ERROR - 2020-02-06 04:26:00 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-06 04:26:00 --> Config Class Initialized
INFO - 2020-02-06 04:26:00 --> Config Class Initialized
INFO - 2020-02-06 04:26:01 --> Hooks Class Initialized
INFO - 2020-02-06 04:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:26:01 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:01 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:01 --> Config Class Initialized
INFO - 2020-02-06 04:26:01 --> Hooks Class Initialized
INFO - 2020-02-06 04:26:01 --> Controller Class Initialized
INFO - 2020-02-06 04:26:01 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:26:01 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:01 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:01 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:01 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:26:01 --> URI Class Initialized
DEBUG - 2020-02-06 04:26:01 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:01 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:01 --> URI Class Initialized
INFO - 2020-02-06 04:26:01 --> Router Class Initialized
INFO - 2020-02-06 04:26:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:26:01 --> URI Class Initialized
INFO - 2020-02-06 04:26:01 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:26:01 --> Router Class Initialized
INFO - 2020-02-06 04:26:01 --> Router Class Initialized
INFO - 2020-02-06 04:26:01 --> URI Class Initialized
INFO - 2020-02-06 04:26:01 --> Output Class Initialized
INFO - 2020-02-06 04:26:01 --> Output Class Initialized
INFO - 2020-02-06 04:26:01 --> Output Class Initialized
INFO - 2020-02-06 04:26:01 --> Router Class Initialized
INFO - 2020-02-06 04:26:01 --> Security Class Initialized
INFO - 2020-02-06 04:26:01 --> Helper loaded: form_helper
INFO - 2020-02-06 04:26:01 --> Form Validation Class Initialized
INFO - 2020-02-06 04:26:01 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:01 --> Security Class Initialized
INFO - 2020-02-06 04:26:01 --> Output Class Initialized
INFO - 2020-02-06 04:26:01 --> Input Class Initialized
DEBUG - 2020-02-06 04:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:01 --> Security Class Initialized
ERROR - 2020-02-06 04:26:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-06 04:26:01 --> Input Class Initialized
INFO - 2020-02-06 04:26:01 --> Input Class Initialized
ERROR - 2020-02-06 04:26:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:26:01 --> Language Class Initialized
DEBUG - 2020-02-06 04:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:01 --> Input Class Initialized
INFO - 2020-02-06 04:26:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:26:01 --> Language Class Initialized
ERROR - 2020-02-06 04:26:01 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-06 04:26:01 --> Language Class Initialized
INFO - 2020-02-06 04:26:01 --> Final output sent to browser
INFO - 2020-02-06 04:26:01 --> Language Class Initialized
ERROR - 2020-02-06 04:26:01 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-06 04:26:01 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-06 04:26:01 --> Total execution time: 1.0894
ERROR - 2020-02-06 04:26:01 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-06 04:26:01 --> Config Class Initialized
INFO - 2020-02-06 04:26:01 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:01 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:01 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:01 --> URI Class Initialized
INFO - 2020-02-06 04:26:01 --> Router Class Initialized
INFO - 2020-02-06 04:26:01 --> Output Class Initialized
INFO - 2020-02-06 04:26:01 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:01 --> Input Class Initialized
INFO - 2020-02-06 04:26:01 --> Language Class Initialized
ERROR - 2020-02-06 04:26:01 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-06 04:26:01 --> Config Class Initialized
INFO - 2020-02-06 04:26:01 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:01 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:01 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:01 --> URI Class Initialized
INFO - 2020-02-06 04:26:01 --> Router Class Initialized
INFO - 2020-02-06 04:26:01 --> Output Class Initialized
INFO - 2020-02-06 04:26:01 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:01 --> Input Class Initialized
INFO - 2020-02-06 04:26:01 --> Language Class Initialized
ERROR - 2020-02-06 04:26:01 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-06 04:26:02 --> Config Class Initialized
INFO - 2020-02-06 04:26:02 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:02 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:02 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:02 --> URI Class Initialized
INFO - 2020-02-06 04:26:02 --> Router Class Initialized
INFO - 2020-02-06 04:26:02 --> Output Class Initialized
INFO - 2020-02-06 04:26:02 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:02 --> Input Class Initialized
INFO - 2020-02-06 04:26:02 --> Language Class Initialized
ERROR - 2020-02-06 04:26:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-06 04:26:02 --> Config Class Initialized
INFO - 2020-02-06 04:26:02 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:02 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:02 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:02 --> URI Class Initialized
INFO - 2020-02-06 04:26:02 --> Router Class Initialized
INFO - 2020-02-06 04:26:02 --> Output Class Initialized
INFO - 2020-02-06 04:26:02 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:02 --> Input Class Initialized
INFO - 2020-02-06 04:26:02 --> Language Class Initialized
ERROR - 2020-02-06 04:26:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:26:02 --> Config Class Initialized
INFO - 2020-02-06 04:26:02 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:02 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:02 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:02 --> URI Class Initialized
INFO - 2020-02-06 04:26:02 --> Router Class Initialized
INFO - 2020-02-06 04:26:02 --> Output Class Initialized
INFO - 2020-02-06 04:26:02 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:02 --> Input Class Initialized
INFO - 2020-02-06 04:26:02 --> Language Class Initialized
ERROR - 2020-02-06 04:26:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 04:26:02 --> Config Class Initialized
INFO - 2020-02-06 04:26:03 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:03 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:03 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:03 --> URI Class Initialized
INFO - 2020-02-06 04:26:03 --> Router Class Initialized
INFO - 2020-02-06 04:26:03 --> Output Class Initialized
INFO - 2020-02-06 04:26:03 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:03 --> Input Class Initialized
INFO - 2020-02-06 04:26:03 --> Language Class Initialized
ERROR - 2020-02-06 04:26:03 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-06 04:26:03 --> Config Class Initialized
INFO - 2020-02-06 04:26:03 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:03 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:03 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:03 --> URI Class Initialized
INFO - 2020-02-06 04:26:03 --> Router Class Initialized
INFO - 2020-02-06 04:26:03 --> Output Class Initialized
INFO - 2020-02-06 04:26:03 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:03 --> Input Class Initialized
INFO - 2020-02-06 04:26:03 --> Language Class Initialized
ERROR - 2020-02-06 04:26:03 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-06 04:26:03 --> Config Class Initialized
INFO - 2020-02-06 04:26:03 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:03 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:03 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:03 --> URI Class Initialized
INFO - 2020-02-06 04:26:03 --> Router Class Initialized
INFO - 2020-02-06 04:26:03 --> Output Class Initialized
INFO - 2020-02-06 04:26:03 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:03 --> Input Class Initialized
INFO - 2020-02-06 04:26:03 --> Language Class Initialized
ERROR - 2020-02-06 04:26:03 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-06 04:26:03 --> Config Class Initialized
INFO - 2020-02-06 04:26:03 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:03 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:03 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:03 --> URI Class Initialized
INFO - 2020-02-06 04:26:04 --> Router Class Initialized
INFO - 2020-02-06 04:26:04 --> Output Class Initialized
INFO - 2020-02-06 04:26:04 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:04 --> Input Class Initialized
INFO - 2020-02-06 04:26:04 --> Language Class Initialized
ERROR - 2020-02-06 04:26:04 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-06 04:26:23 --> Config Class Initialized
INFO - 2020-02-06 04:26:23 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:26:23 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:26:23 --> Utf8 Class Initialized
INFO - 2020-02-06 04:26:23 --> URI Class Initialized
INFO - 2020-02-06 04:26:23 --> Router Class Initialized
INFO - 2020-02-06 04:26:23 --> Output Class Initialized
INFO - 2020-02-06 04:26:23 --> Security Class Initialized
DEBUG - 2020-02-06 04:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:26:23 --> Input Class Initialized
INFO - 2020-02-06 04:26:24 --> Language Class Initialized
INFO - 2020-02-06 04:26:24 --> Loader Class Initialized
INFO - 2020-02-06 04:26:24 --> Helper loaded: url_helper
INFO - 2020-02-06 04:26:24 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:26:24 --> Controller Class Initialized
INFO - 2020-02-06 04:26:24 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:26:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:26:24 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:26:24 --> Helper loaded: form_helper
INFO - 2020-02-06 04:26:24 --> Form Validation Class Initialized
INFO - 2020-02-06 04:26:24 --> Final output sent to browser
DEBUG - 2020-02-06 04:26:24 --> Total execution time: 0.7464
INFO - 2020-02-06 04:27:26 --> Config Class Initialized
INFO - 2020-02-06 04:27:26 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:27:26 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:27:27 --> Utf8 Class Initialized
INFO - 2020-02-06 04:27:27 --> URI Class Initialized
INFO - 2020-02-06 04:27:27 --> Router Class Initialized
INFO - 2020-02-06 04:27:27 --> Output Class Initialized
INFO - 2020-02-06 04:27:27 --> Security Class Initialized
DEBUG - 2020-02-06 04:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:27:27 --> Input Class Initialized
INFO - 2020-02-06 04:27:27 --> Language Class Initialized
INFO - 2020-02-06 04:27:27 --> Loader Class Initialized
INFO - 2020-02-06 04:27:27 --> Helper loaded: url_helper
INFO - 2020-02-06 04:27:27 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:27:27 --> Controller Class Initialized
INFO - 2020-02-06 04:27:27 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:27:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:27:27 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:27:27 --> Helper loaded: form_helper
INFO - 2020-02-06 04:27:27 --> Form Validation Class Initialized
INFO - 2020-02-06 04:27:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:27:27 --> Final output sent to browser
DEBUG - 2020-02-06 04:27:27 --> Total execution time: 0.6716
INFO - 2020-02-06 04:27:27 --> Config Class Initialized
INFO - 2020-02-06 04:27:27 --> Config Class Initialized
INFO - 2020-02-06 04:27:27 --> Config Class Initialized
INFO - 2020-02-06 04:27:27 --> Hooks Class Initialized
INFO - 2020-02-06 04:27:27 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:27:27 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:27:27 --> Hooks Class Initialized
INFO - 2020-02-06 04:27:27 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:27:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 04:27:27 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:27:27 --> Utf8 Class Initialized
INFO - 2020-02-06 04:27:27 --> URI Class Initialized
INFO - 2020-02-06 04:27:27 --> Utf8 Class Initialized
INFO - 2020-02-06 04:27:27 --> URI Class Initialized
INFO - 2020-02-06 04:27:27 --> URI Class Initialized
INFO - 2020-02-06 04:27:27 --> Router Class Initialized
INFO - 2020-02-06 04:27:27 --> Router Class Initialized
INFO - 2020-02-06 04:27:27 --> Router Class Initialized
INFO - 2020-02-06 04:27:27 --> Output Class Initialized
INFO - 2020-02-06 04:27:27 --> Security Class Initialized
INFO - 2020-02-06 04:27:27 --> Output Class Initialized
INFO - 2020-02-06 04:27:27 --> Output Class Initialized
INFO - 2020-02-06 04:27:28 --> Security Class Initialized
DEBUG - 2020-02-06 04:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:27:28 --> Security Class Initialized
INFO - 2020-02-06 04:27:28 --> Input Class Initialized
DEBUG - 2020-02-06 04:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 04:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:27:28 --> Input Class Initialized
INFO - 2020-02-06 04:27:28 --> Input Class Initialized
INFO - 2020-02-06 04:27:28 --> Language Class Initialized
INFO - 2020-02-06 04:27:28 --> Language Class Initialized
INFO - 2020-02-06 04:27:28 --> Language Class Initialized
ERROR - 2020-02-06 04:27:28 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-06 04:27:28 --> Loader Class Initialized
INFO - 2020-02-06 04:27:28 --> Loader Class Initialized
INFO - 2020-02-06 04:27:28 --> Helper loaded: url_helper
INFO - 2020-02-06 04:27:28 --> Helper loaded: url_helper
INFO - 2020-02-06 04:27:28 --> Database Driver Class Initialized
INFO - 2020-02-06 04:27:28 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-06 04:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:27:28 --> Controller Class Initialized
INFO - 2020-02-06 04:27:28 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:27:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:27:28 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:27:28 --> Helper loaded: form_helper
INFO - 2020-02-06 04:27:28 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:27:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:27:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:27:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:27:28 --> Final output sent to browser
DEBUG - 2020-02-06 04:27:28 --> Total execution time: 1.0761
INFO - 2020-02-06 04:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:27:28 --> Controller Class Initialized
INFO - 2020-02-06 04:27:28 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:27:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:27:28 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:27:28 --> Helper loaded: form_helper
INFO - 2020-02-06 04:27:28 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:27:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:27:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:27:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:27:29 --> Final output sent to browser
DEBUG - 2020-02-06 04:27:29 --> Total execution time: 1.4816
INFO - 2020-02-06 04:27:31 --> Config Class Initialized
INFO - 2020-02-06 04:27:31 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:27:32 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:27:32 --> Utf8 Class Initialized
INFO - 2020-02-06 04:27:32 --> URI Class Initialized
INFO - 2020-02-06 04:27:32 --> Router Class Initialized
INFO - 2020-02-06 04:27:32 --> Output Class Initialized
INFO - 2020-02-06 04:27:32 --> Security Class Initialized
DEBUG - 2020-02-06 04:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:27:32 --> Input Class Initialized
INFO - 2020-02-06 04:27:32 --> Language Class Initialized
INFO - 2020-02-06 04:27:32 --> Loader Class Initialized
INFO - 2020-02-06 04:27:32 --> Helper loaded: url_helper
INFO - 2020-02-06 04:27:32 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:27:32 --> Controller Class Initialized
INFO - 2020-02-06 04:27:32 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:27:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:27:32 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:27:32 --> Helper loaded: form_helper
INFO - 2020-02-06 04:27:32 --> Form Validation Class Initialized
INFO - 2020-02-06 04:27:32 --> Final output sent to browser
DEBUG - 2020-02-06 04:27:32 --> Total execution time: 0.8937
INFO - 2020-02-06 04:39:39 --> Config Class Initialized
INFO - 2020-02-06 04:39:39 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:39:39 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:39:39 --> Utf8 Class Initialized
INFO - 2020-02-06 04:39:39 --> URI Class Initialized
INFO - 2020-02-06 04:39:39 --> Router Class Initialized
INFO - 2020-02-06 04:39:39 --> Output Class Initialized
INFO - 2020-02-06 04:39:39 --> Security Class Initialized
DEBUG - 2020-02-06 04:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:39:39 --> Input Class Initialized
INFO - 2020-02-06 04:39:39 --> Language Class Initialized
INFO - 2020-02-06 04:39:39 --> Loader Class Initialized
INFO - 2020-02-06 04:39:40 --> Helper loaded: url_helper
INFO - 2020-02-06 04:39:40 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:39:40 --> Controller Class Initialized
INFO - 2020-02-06 04:39:40 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:39:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:39:40 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:39:40 --> Helper loaded: form_helper
INFO - 2020-02-06 04:39:40 --> Form Validation Class Initialized
INFO - 2020-02-06 04:39:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:39:40 --> Final output sent to browser
INFO - 2020-02-06 04:39:40 --> Config Class Initialized
INFO - 2020-02-06 04:39:40 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:39:40 --> Total execution time: 1.2110
INFO - 2020-02-06 04:39:40 --> Config Class Initialized
INFO - 2020-02-06 04:39:40 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:39:40 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:39:40 --> Config Class Initialized
INFO - 2020-02-06 04:39:40 --> Hooks Class Initialized
INFO - 2020-02-06 04:39:40 --> Utf8 Class Initialized
DEBUG - 2020-02-06 04:39:40 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:39:40 --> Utf8 Class Initialized
INFO - 2020-02-06 04:39:40 --> URI Class Initialized
DEBUG - 2020-02-06 04:39:40 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:39:40 --> Utf8 Class Initialized
INFO - 2020-02-06 04:39:40 --> URI Class Initialized
INFO - 2020-02-06 04:39:40 --> Router Class Initialized
INFO - 2020-02-06 04:39:41 --> URI Class Initialized
INFO - 2020-02-06 04:39:41 --> Output Class Initialized
INFO - 2020-02-06 04:39:41 --> Router Class Initialized
INFO - 2020-02-06 04:39:41 --> Security Class Initialized
INFO - 2020-02-06 04:39:41 --> Router Class Initialized
INFO - 2020-02-06 04:39:41 --> Output Class Initialized
DEBUG - 2020-02-06 04:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:39:41 --> Output Class Initialized
INFO - 2020-02-06 04:39:41 --> Security Class Initialized
INFO - 2020-02-06 04:39:41 --> Input Class Initialized
DEBUG - 2020-02-06 04:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:39:41 --> Security Class Initialized
INFO - 2020-02-06 04:39:41 --> Input Class Initialized
DEBUG - 2020-02-06 04:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:39:41 --> Language Class Initialized
INFO - 2020-02-06 04:39:41 --> Input Class Initialized
INFO - 2020-02-06 04:39:41 --> Language Class Initialized
ERROR - 2020-02-06 04:39:41 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-06 04:39:41 --> Language Class Initialized
INFO - 2020-02-06 04:39:41 --> Loader Class Initialized
INFO - 2020-02-06 04:39:41 --> Loader Class Initialized
INFO - 2020-02-06 04:39:41 --> Helper loaded: url_helper
INFO - 2020-02-06 04:39:41 --> Helper loaded: url_helper
INFO - 2020-02-06 04:39:41 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:39:41 --> Database Driver Class Initialized
INFO - 2020-02-06 04:39:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-06 04:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:39:41 --> Controller Class Initialized
INFO - 2020-02-06 04:39:41 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:39:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:39:41 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:39:41 --> Helper loaded: form_helper
INFO - 2020-02-06 04:39:41 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:39:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:39:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:39:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:39:41 --> Final output sent to browser
DEBUG - 2020-02-06 04:39:41 --> Total execution time: 0.7411
INFO - 2020-02-06 04:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:39:41 --> Controller Class Initialized
INFO - 2020-02-06 04:39:41 --> Model "M_tiket" initialized
INFO - 2020-02-06 04:39:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 04:39:41 --> Model "M_pesan" initialized
INFO - 2020-02-06 04:39:41 --> Helper loaded: form_helper
INFO - 2020-02-06 04:39:41 --> Form Validation Class Initialized
ERROR - 2020-02-06 04:39:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 04:39:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 04:39:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 04:39:41 --> Final output sent to browser
DEBUG - 2020-02-06 04:39:41 --> Total execution time: 1.0430
INFO - 2020-02-06 09:05:24 --> Config Class Initialized
INFO - 2020-02-06 09:05:25 --> Hooks Class Initialized
DEBUG - 2020-02-06 09:05:25 --> UTF-8 Support Enabled
INFO - 2020-02-06 09:05:25 --> Utf8 Class Initialized
INFO - 2020-02-06 09:05:25 --> URI Class Initialized
INFO - 2020-02-06 09:05:25 --> Router Class Initialized
INFO - 2020-02-06 09:05:25 --> Output Class Initialized
INFO - 2020-02-06 09:05:25 --> Security Class Initialized
DEBUG - 2020-02-06 09:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 09:05:25 --> Input Class Initialized
INFO - 2020-02-06 09:05:25 --> Language Class Initialized
INFO - 2020-02-06 09:05:25 --> Loader Class Initialized
INFO - 2020-02-06 09:05:25 --> Helper loaded: url_helper
INFO - 2020-02-06 09:05:25 --> Database Driver Class Initialized
DEBUG - 2020-02-06 09:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 09:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 09:05:25 --> Controller Class Initialized
INFO - 2020-02-06 09:05:25 --> Model "M_tiket" initialized
INFO - 2020-02-06 09:05:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 09:05:26 --> Model "M_pesan" initialized
INFO - 2020-02-06 09:05:26 --> Helper loaded: form_helper
INFO - 2020-02-06 09:05:26 --> Form Validation Class Initialized
INFO - 2020-02-06 09:05:26 --> Final output sent to browser
DEBUG - 2020-02-06 09:05:26 --> Total execution time: 1.2649
INFO - 2020-02-06 09:50:48 --> Config Class Initialized
INFO - 2020-02-06 09:50:48 --> Hooks Class Initialized
DEBUG - 2020-02-06 09:50:48 --> UTF-8 Support Enabled
INFO - 2020-02-06 09:50:48 --> Utf8 Class Initialized
INFO - 2020-02-06 09:50:48 --> URI Class Initialized
DEBUG - 2020-02-06 09:50:48 --> No URI present. Default controller set.
INFO - 2020-02-06 09:50:48 --> Router Class Initialized
INFO - 2020-02-06 09:50:48 --> Output Class Initialized
INFO - 2020-02-06 09:50:48 --> Security Class Initialized
DEBUG - 2020-02-06 09:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 09:50:48 --> Input Class Initialized
INFO - 2020-02-06 09:50:48 --> Language Class Initialized
INFO - 2020-02-06 09:50:48 --> Loader Class Initialized
INFO - 2020-02-06 09:50:48 --> Helper loaded: url_helper
INFO - 2020-02-06 09:50:48 --> Database Driver Class Initialized
DEBUG - 2020-02-06 09:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 09:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 09:50:49 --> Controller Class Initialized
INFO - 2020-02-06 09:50:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-06 09:50:49 --> Pagination Class Initialized
INFO - 2020-02-06 09:50:49 --> Model "M_show" initialized
INFO - 2020-02-06 09:50:49 --> Helper loaded: form_helper
INFO - 2020-02-06 09:50:49 --> Form Validation Class Initialized
INFO - 2020-02-06 09:50:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-06 09:50:49 --> Final output sent to browser
DEBUG - 2020-02-06 09:50:49 --> Total execution time: 0.6279
INFO - 2020-02-06 11:30:07 --> Config Class Initialized
INFO - 2020-02-06 11:30:07 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:30:08 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:30:08 --> Utf8 Class Initialized
INFO - 2020-02-06 11:30:08 --> URI Class Initialized
INFO - 2020-02-06 11:30:08 --> Router Class Initialized
INFO - 2020-02-06 11:30:09 --> Output Class Initialized
INFO - 2020-02-06 11:30:09 --> Security Class Initialized
DEBUG - 2020-02-06 11:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:30:09 --> Input Class Initialized
INFO - 2020-02-06 11:30:09 --> Language Class Initialized
INFO - 2020-02-06 11:30:10 --> Loader Class Initialized
INFO - 2020-02-06 11:30:10 --> Helper loaded: url_helper
INFO - 2020-02-06 11:30:10 --> Database Driver Class Initialized
DEBUG - 2020-02-06 11:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 11:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 11:30:11 --> Controller Class Initialized
ERROR - 2020-02-06 11:30:11 --> Severity: error --> Exception: Call to undefined function check_not_login() C:\xampp\htdocs\roadshow\application\controllers\Admin.php 9
INFO - 2020-02-06 11:31:43 --> Config Class Initialized
INFO - 2020-02-06 11:31:43 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:31:43 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:31:43 --> Utf8 Class Initialized
INFO - 2020-02-06 11:31:43 --> URI Class Initialized
INFO - 2020-02-06 11:31:43 --> Router Class Initialized
INFO - 2020-02-06 11:31:43 --> Output Class Initialized
INFO - 2020-02-06 11:31:43 --> Security Class Initialized
DEBUG - 2020-02-06 11:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:31:43 --> Input Class Initialized
INFO - 2020-02-06 11:31:43 --> Language Class Initialized
INFO - 2020-02-06 11:31:43 --> Loader Class Initialized
INFO - 2020-02-06 11:31:43 --> Helper loaded: url_helper
INFO - 2020-02-06 11:31:43 --> Database Driver Class Initialized
DEBUG - 2020-02-06 11:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 11:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 11:31:43 --> Controller Class Initialized
ERROR - 2020-02-06 11:31:43 --> Severity: error --> Exception: Call to undefined method CI_Loader::load() C:\xampp\htdocs\roadshow\application\controllers\Admin.php 9
INFO - 2020-02-06 11:31:47 --> Config Class Initialized
INFO - 2020-02-06 11:31:47 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:31:47 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:31:47 --> Utf8 Class Initialized
INFO - 2020-02-06 11:31:47 --> URI Class Initialized
INFO - 2020-02-06 11:31:47 --> Router Class Initialized
INFO - 2020-02-06 11:31:47 --> Output Class Initialized
INFO - 2020-02-06 11:31:47 --> Security Class Initialized
DEBUG - 2020-02-06 11:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:31:47 --> Input Class Initialized
INFO - 2020-02-06 11:31:47 --> Language Class Initialized
INFO - 2020-02-06 11:31:47 --> Loader Class Initialized
INFO - 2020-02-06 11:31:47 --> Helper loaded: url_helper
INFO - 2020-02-06 11:31:48 --> Database Driver Class Initialized
DEBUG - 2020-02-06 11:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 11:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 11:31:48 --> Controller Class Initialized
ERROR - 2020-02-06 11:31:48 --> Severity: error --> Exception: Call to undefined method CI_Loader::load() C:\xampp\htdocs\roadshow\application\controllers\Admin.php 9
INFO - 2020-02-06 11:32:11 --> Config Class Initialized
INFO - 2020-02-06 11:32:11 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:32:11 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:32:11 --> Utf8 Class Initialized
INFO - 2020-02-06 11:32:11 --> URI Class Initialized
INFO - 2020-02-06 11:32:11 --> Router Class Initialized
INFO - 2020-02-06 11:32:11 --> Output Class Initialized
INFO - 2020-02-06 11:32:11 --> Security Class Initialized
DEBUG - 2020-02-06 11:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:32:12 --> Input Class Initialized
INFO - 2020-02-06 11:32:12 --> Language Class Initialized
INFO - 2020-02-06 11:32:12 --> Loader Class Initialized
INFO - 2020-02-06 11:32:12 --> Helper loaded: url_helper
INFO - 2020-02-06 11:32:12 --> Database Driver Class Initialized
DEBUG - 2020-02-06 11:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 11:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 11:32:12 --> Controller Class Initialized
ERROR - 2020-02-06 11:32:12 --> Severity: Notice --> Undefined property: CI_Loader::$fungsi C:\xampp\htdocs\roadshow\application\views\template.php 75
ERROR - 2020-02-06 11:32:12 --> Severity: error --> Exception: Call to a member function user_login() on null C:\xampp\htdocs\roadshow\application\views\template.php 75
INFO - 2020-02-06 11:33:01 --> Config Class Initialized
INFO - 2020-02-06 11:33:01 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:33:01 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:33:01 --> Utf8 Class Initialized
INFO - 2020-02-06 11:33:01 --> URI Class Initialized
INFO - 2020-02-06 11:33:01 --> Router Class Initialized
INFO - 2020-02-06 11:33:01 --> Output Class Initialized
INFO - 2020-02-06 11:33:01 --> Security Class Initialized
DEBUG - 2020-02-06 11:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:33:02 --> Input Class Initialized
INFO - 2020-02-06 11:33:02 --> Language Class Initialized
ERROR - 2020-02-06 11:33:02 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\roadshow\application\controllers\Admin.php 9
INFO - 2020-02-06 11:33:28 --> Config Class Initialized
INFO - 2020-02-06 11:33:28 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:33:28 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:33:28 --> Utf8 Class Initialized
INFO - 2020-02-06 11:33:28 --> URI Class Initialized
INFO - 2020-02-06 11:33:29 --> Router Class Initialized
INFO - 2020-02-06 11:33:29 --> Output Class Initialized
INFO - 2020-02-06 11:33:29 --> Security Class Initialized
DEBUG - 2020-02-06 11:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:33:29 --> Input Class Initialized
INFO - 2020-02-06 11:33:29 --> Language Class Initialized
INFO - 2020-02-06 11:33:29 --> Loader Class Initialized
INFO - 2020-02-06 11:33:29 --> Helper loaded: url_helper
INFO - 2020-02-06 11:33:29 --> Database Driver Class Initialized
DEBUG - 2020-02-06 11:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 11:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 11:33:30 --> Controller Class Initialized
ERROR - 2020-02-06 11:33:30 --> Severity: Notice --> Undefined property: Admin::$template C:\xampp\htdocs\roadshow\application\controllers\Admin.php 9
ERROR - 2020-02-06 11:33:30 --> Severity: error --> Exception: Call to a member function load() on null C:\xampp\htdocs\roadshow\application\controllers\Admin.php 9
INFO - 2020-02-06 11:43:54 --> Config Class Initialized
INFO - 2020-02-06 11:43:55 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:43:55 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:43:55 --> Utf8 Class Initialized
INFO - 2020-02-06 11:43:55 --> URI Class Initialized
DEBUG - 2020-02-06 11:43:56 --> No URI present. Default controller set.
INFO - 2020-02-06 11:43:56 --> Router Class Initialized
INFO - 2020-02-06 11:43:56 --> Output Class Initialized
INFO - 2020-02-06 11:43:56 --> Security Class Initialized
DEBUG - 2020-02-06 11:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:43:56 --> Input Class Initialized
INFO - 2020-02-06 11:43:56 --> Language Class Initialized
INFO - 2020-02-06 11:43:56 --> Loader Class Initialized
INFO - 2020-02-06 11:43:56 --> Helper loaded: url_helper
INFO - 2020-02-06 11:43:56 --> Database Driver Class Initialized
DEBUG - 2020-02-06 11:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 11:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 11:43:56 --> Controller Class Initialized
INFO - 2020-02-06 11:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-06 11:43:56 --> Pagination Class Initialized
INFO - 2020-02-06 11:43:56 --> Model "M_show" initialized
INFO - 2020-02-06 11:43:56 --> Helper loaded: form_helper
INFO - 2020-02-06 11:43:56 --> Form Validation Class Initialized
INFO - 2020-02-06 11:43:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-06 11:43:57 --> Final output sent to browser
DEBUG - 2020-02-06 11:43:57 --> Total execution time: 2.2525
INFO - 2020-02-06 11:44:20 --> Config Class Initialized
INFO - 2020-02-06 11:44:21 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:44:21 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:44:21 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:21 --> URI Class Initialized
INFO - 2020-02-06 11:44:21 --> Router Class Initialized
INFO - 2020-02-06 11:44:21 --> Output Class Initialized
INFO - 2020-02-06 11:44:21 --> Security Class Initialized
DEBUG - 2020-02-06 11:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:21 --> Input Class Initialized
INFO - 2020-02-06 11:44:21 --> Language Class Initialized
INFO - 2020-02-06 11:44:21 --> Loader Class Initialized
INFO - 2020-02-06 11:44:22 --> Helper loaded: url_helper
INFO - 2020-02-06 11:44:22 --> Database Driver Class Initialized
DEBUG - 2020-02-06 11:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 11:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 11:44:22 --> Controller Class Initialized
INFO - 2020-02-06 11:44:22 --> Model "M_tiket" initialized
INFO - 2020-02-06 11:44:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 11:44:22 --> Model "M_pesan" initialized
INFO - 2020-02-06 11:44:23 --> Helper loaded: form_helper
INFO - 2020-02-06 11:44:23 --> Form Validation Class Initialized
INFO - 2020-02-06 11:44:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 11:44:23 --> Final output sent to browser
DEBUG - 2020-02-06 11:44:23 --> Total execution time: 3.0841
INFO - 2020-02-06 11:44:23 --> Config Class Initialized
INFO - 2020-02-06 11:44:23 --> Hooks Class Initialized
INFO - 2020-02-06 11:44:23 --> Config Class Initialized
INFO - 2020-02-06 11:44:23 --> Config Class Initialized
INFO - 2020-02-06 11:44:23 --> Config Class Initialized
INFO - 2020-02-06 11:44:23 --> Hooks Class Initialized
INFO - 2020-02-06 11:44:23 --> Hooks Class Initialized
INFO - 2020-02-06 11:44:23 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:44:23 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:44:23 --> Config Class Initialized
INFO - 2020-02-06 11:44:23 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:23 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:44:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 11:44:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 11:44:24 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:44:24 --> Config Class Initialized
INFO - 2020-02-06 11:44:24 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:24 --> Hooks Class Initialized
INFO - 2020-02-06 11:44:24 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:24 --> Utf8 Class Initialized
DEBUG - 2020-02-06 11:44:24 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:44:24 --> URI Class Initialized
INFO - 2020-02-06 11:44:24 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:24 --> URI Class Initialized
INFO - 2020-02-06 11:44:24 --> URI Class Initialized
INFO - 2020-02-06 11:44:24 --> URI Class Initialized
INFO - 2020-02-06 11:44:24 --> Router Class Initialized
DEBUG - 2020-02-06 11:44:24 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:44:24 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:24 --> URI Class Initialized
INFO - 2020-02-06 11:44:24 --> Router Class Initialized
INFO - 2020-02-06 11:44:24 --> Router Class Initialized
INFO - 2020-02-06 11:44:24 --> Output Class Initialized
INFO - 2020-02-06 11:44:24 --> Router Class Initialized
INFO - 2020-02-06 11:44:24 --> Output Class Initialized
INFO - 2020-02-06 11:44:24 --> Security Class Initialized
INFO - 2020-02-06 11:44:24 --> Output Class Initialized
INFO - 2020-02-06 11:44:24 --> URI Class Initialized
INFO - 2020-02-06 11:44:24 --> Router Class Initialized
INFO - 2020-02-06 11:44:24 --> Output Class Initialized
INFO - 2020-02-06 11:44:24 --> Security Class Initialized
DEBUG - 2020-02-06 11:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:24 --> Security Class Initialized
INFO - 2020-02-06 11:44:24 --> Router Class Initialized
INFO - 2020-02-06 11:44:24 --> Output Class Initialized
INFO - 2020-02-06 11:44:24 --> Security Class Initialized
INFO - 2020-02-06 11:44:24 --> Input Class Initialized
DEBUG - 2020-02-06 11:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:24 --> Output Class Initialized
DEBUG - 2020-02-06 11:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 11:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:24 --> Security Class Initialized
INFO - 2020-02-06 11:44:24 --> Input Class Initialized
INFO - 2020-02-06 11:44:24 --> Input Class Initialized
DEBUG - 2020-02-06 11:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:24 --> Language Class Initialized
INFO - 2020-02-06 11:44:24 --> Security Class Initialized
INFO - 2020-02-06 11:44:24 --> Language Class Initialized
INFO - 2020-02-06 11:44:24 --> Input Class Initialized
INFO - 2020-02-06 11:44:24 --> Language Class Initialized
DEBUG - 2020-02-06 11:44:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-06 11:44:24 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-06 11:44:24 --> Input Class Initialized
INFO - 2020-02-06 11:44:24 --> Language Class Initialized
INFO - 2020-02-06 11:44:24 --> Language Class Initialized
INFO - 2020-02-06 11:44:24 --> Input Class Initialized
INFO - 2020-02-06 11:44:24 --> Loader Class Initialized
INFO - 2020-02-06 11:44:24 --> Loader Class Initialized
ERROR - 2020-02-06 11:44:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 11:44:24 --> Helper loaded: url_helper
INFO - 2020-02-06 11:44:24 --> Language Class Initialized
ERROR - 2020-02-06 11:44:24 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-06 11:44:24 --> Helper loaded: url_helper
INFO - 2020-02-06 11:44:24 --> Config Class Initialized
ERROR - 2020-02-06 11:44:24 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-06 11:44:24 --> Database Driver Class Initialized
INFO - 2020-02-06 11:44:24 --> Database Driver Class Initialized
INFO - 2020-02-06 11:44:24 --> Hooks Class Initialized
INFO - 2020-02-06 11:44:24 --> Config Class Initialized
INFO - 2020-02-06 11:44:24 --> Config Class Initialized
INFO - 2020-02-06 11:44:24 --> Hooks Class Initialized
INFO - 2020-02-06 11:44:24 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:44:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 11:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 11:44:24 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-06 11:44:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 11:44:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 11:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 11:44:24 --> Config Class Initialized
INFO - 2020-02-06 11:44:24 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:24 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:24 --> Controller Class Initialized
INFO - 2020-02-06 11:44:24 --> Hooks Class Initialized
INFO - 2020-02-06 11:44:24 --> URI Class Initialized
INFO - 2020-02-06 11:44:24 --> Model "M_tiket" initialized
INFO - 2020-02-06 11:44:24 --> URI Class Initialized
INFO - 2020-02-06 11:44:24 --> URI Class Initialized
INFO - 2020-02-06 11:44:24 --> Router Class Initialized
DEBUG - 2020-02-06 11:44:24 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:44:24 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:24 --> Router Class Initialized
INFO - 2020-02-06 11:44:24 --> Router Class Initialized
INFO - 2020-02-06 11:44:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 11:44:24 --> Output Class Initialized
INFO - 2020-02-06 11:44:24 --> Model "M_pesan" initialized
INFO - 2020-02-06 11:44:24 --> URI Class Initialized
INFO - 2020-02-06 11:44:24 --> Output Class Initialized
INFO - 2020-02-06 11:44:24 --> Output Class Initialized
INFO - 2020-02-06 11:44:24 --> Security Class Initialized
INFO - 2020-02-06 11:44:24 --> Security Class Initialized
INFO - 2020-02-06 11:44:24 --> Security Class Initialized
DEBUG - 2020-02-06 11:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:24 --> Router Class Initialized
INFO - 2020-02-06 11:44:24 --> Helper loaded: form_helper
INFO - 2020-02-06 11:44:24 --> Form Validation Class Initialized
INFO - 2020-02-06 11:44:24 --> Input Class Initialized
DEBUG - 2020-02-06 11:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 11:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:24 --> Output Class Initialized
INFO - 2020-02-06 11:44:24 --> Input Class Initialized
INFO - 2020-02-06 11:44:24 --> Input Class Initialized
INFO - 2020-02-06 11:44:24 --> Language Class Initialized
INFO - 2020-02-06 11:44:24 --> Security Class Initialized
ERROR - 2020-02-06 11:44:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-06 11:44:24 --> Language Class Initialized
ERROR - 2020-02-06 11:44:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-06 11:44:24 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-06 11:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:24 --> Language Class Initialized
INFO - 2020-02-06 11:44:24 --> Input Class Initialized
INFO - 2020-02-06 11:44:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-06 11:44:24 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-06 11:44:24 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-06 11:44:24 --> Config Class Initialized
INFO - 2020-02-06 11:44:24 --> Hooks Class Initialized
INFO - 2020-02-06 11:44:24 --> Final output sent to browser
INFO - 2020-02-06 11:44:24 --> Language Class Initialized
INFO - 2020-02-06 11:44:24 --> Config Class Initialized
INFO - 2020-02-06 11:44:24 --> Config Class Initialized
DEBUG - 2020-02-06 11:44:24 --> Total execution time: 0.9908
INFO - 2020-02-06 11:44:24 --> Hooks Class Initialized
INFO - 2020-02-06 11:44:24 --> Hooks Class Initialized
ERROR - 2020-02-06 11:44:24 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-06 11:44:24 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:44:24 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-06 11:44:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 11:44:24 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:44:25 --> Config Class Initialized
INFO - 2020-02-06 11:44:25 --> Hooks Class Initialized
INFO - 2020-02-06 11:44:25 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:25 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:25 --> Controller Class Initialized
INFO - 2020-02-06 11:44:25 --> URI Class Initialized
INFO - 2020-02-06 11:44:25 --> URI Class Initialized
INFO - 2020-02-06 11:44:25 --> Model "M_tiket" initialized
INFO - 2020-02-06 11:44:25 --> URI Class Initialized
DEBUG - 2020-02-06 11:44:25 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:44:25 --> Router Class Initialized
INFO - 2020-02-06 11:44:25 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 11:44:25 --> Router Class Initialized
INFO - 2020-02-06 11:44:25 --> Router Class Initialized
INFO - 2020-02-06 11:44:25 --> Output Class Initialized
INFO - 2020-02-06 11:44:25 --> URI Class Initialized
INFO - 2020-02-06 11:44:25 --> Security Class Initialized
INFO - 2020-02-06 11:44:25 --> Output Class Initialized
INFO - 2020-02-06 11:44:25 --> Model "M_pesan" initialized
INFO - 2020-02-06 11:44:25 --> Output Class Initialized
INFO - 2020-02-06 11:44:25 --> Security Class Initialized
INFO - 2020-02-06 11:44:25 --> Router Class Initialized
DEBUG - 2020-02-06 11:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:25 --> Security Class Initialized
INFO - 2020-02-06 11:44:25 --> Helper loaded: form_helper
INFO - 2020-02-06 11:44:25 --> Form Validation Class Initialized
INFO - 2020-02-06 11:44:25 --> Input Class Initialized
DEBUG - 2020-02-06 11:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 11:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:25 --> Output Class Initialized
INFO - 2020-02-06 11:44:25 --> Input Class Initialized
INFO - 2020-02-06 11:44:25 --> Language Class Initialized
INFO - 2020-02-06 11:44:25 --> Input Class Initialized
INFO - 2020-02-06 11:44:25 --> Security Class Initialized
ERROR - 2020-02-06 11:44:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-06 11:44:25 --> Language Class Initialized
DEBUG - 2020-02-06 11:44:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-06 11:44:25 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-06 11:44:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 11:44:25 --> Language Class Initialized
INFO - 2020-02-06 11:44:25 --> Input Class Initialized
ERROR - 2020-02-06 11:44:25 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-06 11:44:25 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-06 11:44:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 11:44:25 --> Final output sent to browser
INFO - 2020-02-06 11:44:25 --> Language Class Initialized
DEBUG - 2020-02-06 11:44:25 --> Total execution time: 1.3250
ERROR - 2020-02-06 11:44:25 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 11:44:25 --> Config Class Initialized
INFO - 2020-02-06 11:44:25 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:44:25 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:44:25 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:25 --> URI Class Initialized
INFO - 2020-02-06 11:44:25 --> Router Class Initialized
INFO - 2020-02-06 11:44:25 --> Output Class Initialized
INFO - 2020-02-06 11:44:25 --> Security Class Initialized
DEBUG - 2020-02-06 11:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:25 --> Input Class Initialized
INFO - 2020-02-06 11:44:25 --> Language Class Initialized
ERROR - 2020-02-06 11:44:25 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-06 11:44:25 --> Config Class Initialized
INFO - 2020-02-06 11:44:25 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:44:25 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:44:25 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:25 --> URI Class Initialized
INFO - 2020-02-06 11:44:25 --> Router Class Initialized
INFO - 2020-02-06 11:44:25 --> Output Class Initialized
INFO - 2020-02-06 11:44:25 --> Security Class Initialized
DEBUG - 2020-02-06 11:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:25 --> Input Class Initialized
INFO - 2020-02-06 11:44:25 --> Language Class Initialized
ERROR - 2020-02-06 11:44:25 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-06 11:44:26 --> Config Class Initialized
INFO - 2020-02-06 11:44:26 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:44:26 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:44:26 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:26 --> URI Class Initialized
INFO - 2020-02-06 11:44:26 --> Router Class Initialized
INFO - 2020-02-06 11:44:26 --> Output Class Initialized
INFO - 2020-02-06 11:44:26 --> Security Class Initialized
DEBUG - 2020-02-06 11:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:26 --> Input Class Initialized
INFO - 2020-02-06 11:44:26 --> Language Class Initialized
ERROR - 2020-02-06 11:44:26 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-06 11:44:26 --> Config Class Initialized
INFO - 2020-02-06 11:44:26 --> Hooks Class Initialized
DEBUG - 2020-02-06 11:44:26 --> UTF-8 Support Enabled
INFO - 2020-02-06 11:44:26 --> Utf8 Class Initialized
INFO - 2020-02-06 11:44:26 --> URI Class Initialized
INFO - 2020-02-06 11:44:26 --> Router Class Initialized
INFO - 2020-02-06 11:44:26 --> Output Class Initialized
INFO - 2020-02-06 11:44:26 --> Security Class Initialized
DEBUG - 2020-02-06 11:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 11:44:26 --> Input Class Initialized
INFO - 2020-02-06 11:44:26 --> Language Class Initialized
ERROR - 2020-02-06 11:44:26 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-06 12:02:10 --> Config Class Initialized
INFO - 2020-02-06 12:02:11 --> Hooks Class Initialized
DEBUG - 2020-02-06 12:02:11 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:11 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:11 --> URI Class Initialized
INFO - 2020-02-06 12:02:11 --> Router Class Initialized
INFO - 2020-02-06 12:02:11 --> Output Class Initialized
INFO - 2020-02-06 12:02:11 --> Security Class Initialized
DEBUG - 2020-02-06 12:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:12 --> Input Class Initialized
INFO - 2020-02-06 12:02:12 --> Language Class Initialized
INFO - 2020-02-06 12:02:12 --> Loader Class Initialized
INFO - 2020-02-06 12:02:12 --> Helper loaded: url_helper
INFO - 2020-02-06 12:02:12 --> Database Driver Class Initialized
DEBUG - 2020-02-06 12:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 12:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 12:02:12 --> Controller Class Initialized
INFO - 2020-02-06 12:02:12 --> Model "M_tiket" initialized
INFO - 2020-02-06 12:02:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 12:02:12 --> Model "M_pesan" initialized
INFO - 2020-02-06 12:02:12 --> Helper loaded: form_helper
INFO - 2020-02-06 12:02:13 --> Form Validation Class Initialized
INFO - 2020-02-06 12:02:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 12:02:13 --> Final output sent to browser
INFO - 2020-02-06 12:02:13 --> Config Class Initialized
INFO - 2020-02-06 12:02:13 --> Hooks Class Initialized
DEBUG - 2020-02-06 12:02:13 --> Total execution time: 2.4028
INFO - 2020-02-06 12:02:13 --> Config Class Initialized
INFO - 2020-02-06 12:02:13 --> Config Class Initialized
INFO - 2020-02-06 12:02:13 --> Config Class Initialized
INFO - 2020-02-06 12:02:13 --> Hooks Class Initialized
INFO - 2020-02-06 12:02:13 --> Hooks Class Initialized
DEBUG - 2020-02-06 12:02:13 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:13 --> Hooks Class Initialized
INFO - 2020-02-06 12:02:13 --> Config Class Initialized
INFO - 2020-02-06 12:02:13 --> Config Class Initialized
INFO - 2020-02-06 12:02:13 --> Hooks Class Initialized
INFO - 2020-02-06 12:02:13 --> Hooks Class Initialized
INFO - 2020-02-06 12:02:13 --> Utf8 Class Initialized
DEBUG - 2020-02-06 12:02:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 12:02:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 12:02:13 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:13 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:13 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:13 --> Utf8 Class Initialized
DEBUG - 2020-02-06 12:02:13 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:13 --> URI Class Initialized
DEBUG - 2020-02-06 12:02:13 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:13 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:13 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:13 --> URI Class Initialized
INFO - 2020-02-06 12:02:13 --> URI Class Initialized
INFO - 2020-02-06 12:02:13 --> URI Class Initialized
INFO - 2020-02-06 12:02:13 --> Router Class Initialized
INFO - 2020-02-06 12:02:13 --> URI Class Initialized
INFO - 2020-02-06 12:02:13 --> Router Class Initialized
INFO - 2020-02-06 12:02:13 --> Router Class Initialized
INFO - 2020-02-06 12:02:13 --> Router Class Initialized
INFO - 2020-02-06 12:02:13 --> URI Class Initialized
INFO - 2020-02-06 12:02:13 --> Output Class Initialized
INFO - 2020-02-06 12:02:13 --> Security Class Initialized
INFO - 2020-02-06 12:02:13 --> Output Class Initialized
INFO - 2020-02-06 12:02:13 --> Output Class Initialized
INFO - 2020-02-06 12:02:13 --> Output Class Initialized
INFO - 2020-02-06 12:02:13 --> Router Class Initialized
INFO - 2020-02-06 12:02:13 --> Router Class Initialized
DEBUG - 2020-02-06 12:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:13 --> Security Class Initialized
INFO - 2020-02-06 12:02:13 --> Security Class Initialized
INFO - 2020-02-06 12:02:13 --> Security Class Initialized
INFO - 2020-02-06 12:02:13 --> Output Class Initialized
INFO - 2020-02-06 12:02:13 --> Output Class Initialized
INFO - 2020-02-06 12:02:13 --> Input Class Initialized
DEBUG - 2020-02-06 12:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:13 --> Security Class Initialized
DEBUG - 2020-02-06 12:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 12:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:13 --> Security Class Initialized
INFO - 2020-02-06 12:02:14 --> Input Class Initialized
INFO - 2020-02-06 12:02:14 --> Input Class Initialized
DEBUG - 2020-02-06 12:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:14 --> Language Class Initialized
INFO - 2020-02-06 12:02:14 --> Input Class Initialized
DEBUG - 2020-02-06 12:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:14 --> Input Class Initialized
INFO - 2020-02-06 12:02:14 --> Input Class Initialized
INFO - 2020-02-06 12:02:14 --> Language Class Initialized
INFO - 2020-02-06 12:02:14 --> Language Class Initialized
ERROR - 2020-02-06 12:02:14 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-06 12:02:14 --> Language Class Initialized
INFO - 2020-02-06 12:02:14 --> Language Class Initialized
INFO - 2020-02-06 12:02:14 --> Language Class Initialized
ERROR - 2020-02-06 12:02:14 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-06 12:02:14 --> Loader Class Initialized
ERROR - 2020-02-06 12:02:14 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-06 12:02:14 --> Config Class Initialized
INFO - 2020-02-06 12:02:14 --> Hooks Class Initialized
INFO - 2020-02-06 12:02:14 --> Helper loaded: url_helper
INFO - 2020-02-06 12:02:14 --> Loader Class Initialized
ERROR - 2020-02-06 12:02:14 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-06 12:02:14 --> Config Class Initialized
INFO - 2020-02-06 12:02:14 --> Config Class Initialized
INFO - 2020-02-06 12:02:14 --> Hooks Class Initialized
INFO - 2020-02-06 12:02:14 --> Hooks Class Initialized
DEBUG - 2020-02-06 12:02:14 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:14 --> Helper loaded: url_helper
INFO - 2020-02-06 12:02:14 --> Database Driver Class Initialized
INFO - 2020-02-06 12:02:14 --> Config Class Initialized
INFO - 2020-02-06 12:02:14 --> Hooks Class Initialized
INFO - 2020-02-06 12:02:14 --> Utf8 Class Initialized
DEBUG - 2020-02-06 12:02:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 12:02:14 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:14 --> Database Driver Class Initialized
DEBUG - 2020-02-06 12:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 12:02:14 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 12:02:14 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:14 --> URI Class Initialized
DEBUG - 2020-02-06 12:02:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 12:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 12:02:14 --> Controller Class Initialized
INFO - 2020-02-06 12:02:14 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:14 --> URI Class Initialized
INFO - 2020-02-06 12:02:14 --> URI Class Initialized
INFO - 2020-02-06 12:02:14 --> Router Class Initialized
INFO - 2020-02-06 12:02:14 --> URI Class Initialized
INFO - 2020-02-06 12:02:14 --> Router Class Initialized
INFO - 2020-02-06 12:02:14 --> Model "M_tiket" initialized
INFO - 2020-02-06 12:02:14 --> Output Class Initialized
INFO - 2020-02-06 12:02:14 --> Router Class Initialized
INFO - 2020-02-06 12:02:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 12:02:14 --> Output Class Initialized
INFO - 2020-02-06 12:02:14 --> Router Class Initialized
INFO - 2020-02-06 12:02:14 --> Output Class Initialized
INFO - 2020-02-06 12:02:14 --> Security Class Initialized
DEBUG - 2020-02-06 12:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:14 --> Security Class Initialized
INFO - 2020-02-06 12:02:14 --> Security Class Initialized
INFO - 2020-02-06 12:02:14 --> Output Class Initialized
INFO - 2020-02-06 12:02:14 --> Model "M_pesan" initialized
INFO - 2020-02-06 12:02:14 --> Input Class Initialized
DEBUG - 2020-02-06 12:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:14 --> Security Class Initialized
DEBUG - 2020-02-06 12:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:14 --> Helper loaded: form_helper
INFO - 2020-02-06 12:02:14 --> Input Class Initialized
INFO - 2020-02-06 12:02:14 --> Form Validation Class Initialized
INFO - 2020-02-06 12:02:14 --> Language Class Initialized
INFO - 2020-02-06 12:02:14 --> Input Class Initialized
DEBUG - 2020-02-06 12:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:14 --> Input Class Initialized
INFO - 2020-02-06 12:02:14 --> Language Class Initialized
INFO - 2020-02-06 12:02:14 --> Language Class Initialized
ERROR - 2020-02-06 12:02:14 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-06 12:02:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-06 12:02:14 --> Language Class Initialized
ERROR - 2020-02-06 12:02:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-06 12:02:14 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-06 12:02:14 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 12:02:14 --> Config Class Initialized
INFO - 2020-02-06 12:02:14 --> Hooks Class Initialized
INFO - 2020-02-06 12:02:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-06 12:02:14 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-06 12:02:14 --> Config Class Initialized
INFO - 2020-02-06 12:02:14 --> Config Class Initialized
INFO - 2020-02-06 12:02:14 --> Hooks Class Initialized
INFO - 2020-02-06 12:02:14 --> Final output sent to browser
INFO - 2020-02-06 12:02:14 --> Hooks Class Initialized
DEBUG - 2020-02-06 12:02:14 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:14 --> Config Class Initialized
INFO - 2020-02-06 12:02:14 --> Hooks Class Initialized
INFO - 2020-02-06 12:02:14 --> Utf8 Class Initialized
DEBUG - 2020-02-06 12:02:14 --> Total execution time: 1.4217
DEBUG - 2020-02-06 12:02:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 12:02:14 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:14 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:14 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 12:02:14 --> URI Class Initialized
DEBUG - 2020-02-06 12:02:14 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:14 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:14 --> Controller Class Initialized
INFO - 2020-02-06 12:02:14 --> URI Class Initialized
INFO - 2020-02-06 12:02:14 --> Router Class Initialized
INFO - 2020-02-06 12:02:14 --> URI Class Initialized
INFO - 2020-02-06 12:02:14 --> URI Class Initialized
INFO - 2020-02-06 12:02:14 --> Model "M_tiket" initialized
INFO - 2020-02-06 12:02:14 --> Router Class Initialized
INFO - 2020-02-06 12:02:14 --> Router Class Initialized
INFO - 2020-02-06 12:02:14 --> Output Class Initialized
INFO - 2020-02-06 12:02:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 12:02:14 --> Output Class Initialized
INFO - 2020-02-06 12:02:14 --> Security Class Initialized
INFO - 2020-02-06 12:02:14 --> Router Class Initialized
INFO - 2020-02-06 12:02:14 --> Output Class Initialized
INFO - 2020-02-06 12:02:14 --> Model "M_pesan" initialized
DEBUG - 2020-02-06 12:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:14 --> Security Class Initialized
INFO - 2020-02-06 12:02:14 --> Security Class Initialized
INFO - 2020-02-06 12:02:14 --> Output Class Initialized
INFO - 2020-02-06 12:02:15 --> Input Class Initialized
DEBUG - 2020-02-06 12:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 12:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:15 --> Security Class Initialized
INFO - 2020-02-06 12:02:15 --> Helper loaded: form_helper
INFO - 2020-02-06 12:02:15 --> Input Class Initialized
INFO - 2020-02-06 12:02:15 --> Input Class Initialized
INFO - 2020-02-06 12:02:15 --> Language Class Initialized
INFO - 2020-02-06 12:02:15 --> Form Validation Class Initialized
DEBUG - 2020-02-06 12:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:15 --> Input Class Initialized
INFO - 2020-02-06 12:02:15 --> Language Class Initialized
ERROR - 2020-02-06 12:02:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-06 12:02:15 --> Language Class Initialized
ERROR - 2020-02-06 12:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-06 12:02:15 --> Language Class Initialized
ERROR - 2020-02-06 12:02:15 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-06 12:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-06 12:02:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-06 12:02:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-06 12:02:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-06 12:02:15 --> Final output sent to browser
INFO - 2020-02-06 12:02:15 --> Config Class Initialized
INFO - 2020-02-06 12:02:15 --> Hooks Class Initialized
DEBUG - 2020-02-06 12:02:15 --> Total execution time: 1.7133
DEBUG - 2020-02-06 12:02:15 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:15 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:15 --> URI Class Initialized
INFO - 2020-02-06 12:02:15 --> Router Class Initialized
INFO - 2020-02-06 12:02:15 --> Output Class Initialized
INFO - 2020-02-06 12:02:15 --> Security Class Initialized
DEBUG - 2020-02-06 12:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:15 --> Input Class Initialized
INFO - 2020-02-06 12:02:15 --> Language Class Initialized
ERROR - 2020-02-06 12:02:15 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-06 12:02:15 --> Config Class Initialized
INFO - 2020-02-06 12:02:15 --> Hooks Class Initialized
DEBUG - 2020-02-06 12:02:15 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:15 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:15 --> URI Class Initialized
INFO - 2020-02-06 12:02:15 --> Router Class Initialized
INFO - 2020-02-06 12:02:15 --> Output Class Initialized
INFO - 2020-02-06 12:02:15 --> Security Class Initialized
DEBUG - 2020-02-06 12:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:15 --> Input Class Initialized
INFO - 2020-02-06 12:02:15 --> Language Class Initialized
ERROR - 2020-02-06 12:02:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-06 12:02:16 --> Config Class Initialized
INFO - 2020-02-06 12:02:16 --> Hooks Class Initialized
DEBUG - 2020-02-06 12:02:16 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:16 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:16 --> URI Class Initialized
INFO - 2020-02-06 12:02:16 --> Router Class Initialized
INFO - 2020-02-06 12:02:16 --> Output Class Initialized
INFO - 2020-02-06 12:02:16 --> Security Class Initialized
DEBUG - 2020-02-06 12:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:16 --> Input Class Initialized
INFO - 2020-02-06 12:02:16 --> Language Class Initialized
ERROR - 2020-02-06 12:02:17 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-06 12:02:17 --> Config Class Initialized
INFO - 2020-02-06 12:02:17 --> Hooks Class Initialized
DEBUG - 2020-02-06 12:02:17 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:17 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:17 --> URI Class Initialized
INFO - 2020-02-06 12:02:17 --> Router Class Initialized
INFO - 2020-02-06 12:02:17 --> Output Class Initialized
INFO - 2020-02-06 12:02:17 --> Security Class Initialized
DEBUG - 2020-02-06 12:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:17 --> Input Class Initialized
INFO - 2020-02-06 12:02:17 --> Language Class Initialized
ERROR - 2020-02-06 12:02:17 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-06 12:02:45 --> Config Class Initialized
INFO - 2020-02-06 12:02:45 --> Hooks Class Initialized
DEBUG - 2020-02-06 12:02:45 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:02:45 --> Utf8 Class Initialized
INFO - 2020-02-06 12:02:45 --> URI Class Initialized
INFO - 2020-02-06 12:02:45 --> Router Class Initialized
INFO - 2020-02-06 12:02:45 --> Output Class Initialized
INFO - 2020-02-06 12:02:45 --> Security Class Initialized
DEBUG - 2020-02-06 12:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:02:45 --> Input Class Initialized
INFO - 2020-02-06 12:02:45 --> Language Class Initialized
INFO - 2020-02-06 12:02:45 --> Loader Class Initialized
INFO - 2020-02-06 12:02:45 --> Helper loaded: url_helper
INFO - 2020-02-06 12:02:45 --> Database Driver Class Initialized
DEBUG - 2020-02-06 12:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 12:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 12:02:45 --> Controller Class Initialized
INFO - 2020-02-06 12:02:45 --> Model "M_tiket" initialized
INFO - 2020-02-06 12:02:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 12:02:45 --> Model "M_pesan" initialized
INFO - 2020-02-06 12:02:45 --> Helper loaded: form_helper
INFO - 2020-02-06 12:02:45 --> Form Validation Class Initialized
INFO - 2020-02-06 12:02:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-02-06 12:02:45 --> Severity: Notice --> Undefined variable: show C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 12:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 12:02:46 --> Severity: Notice --> Undefined variable: show C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-06 12:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-06 12:02:46 --> Severity: Notice --> Undefined variable: tiket C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 81
ERROR - 2020-02-06 12:02:46 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 81
INFO - 2020-02-06 12:03:44 --> Config Class Initialized
INFO - 2020-02-06 12:03:44 --> Hooks Class Initialized
DEBUG - 2020-02-06 12:03:44 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:03:44 --> Utf8 Class Initialized
INFO - 2020-02-06 12:03:44 --> URI Class Initialized
INFO - 2020-02-06 12:03:44 --> Router Class Initialized
INFO - 2020-02-06 12:03:44 --> Output Class Initialized
INFO - 2020-02-06 12:03:45 --> Security Class Initialized
DEBUG - 2020-02-06 12:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:03:45 --> Input Class Initialized
INFO - 2020-02-06 12:03:45 --> Language Class Initialized
INFO - 2020-02-06 12:03:45 --> Loader Class Initialized
INFO - 2020-02-06 12:03:45 --> Helper loaded: url_helper
INFO - 2020-02-06 12:03:45 --> Database Driver Class Initialized
DEBUG - 2020-02-06 12:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 12:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 12:03:45 --> Controller Class Initialized
INFO - 2020-02-06 12:03:45 --> Model "M_tiket" initialized
INFO - 2020-02-06 12:03:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 12:03:45 --> Model "M_pesan" initialized
INFO - 2020-02-06 12:03:45 --> Helper loaded: form_helper
INFO - 2020-02-06 12:03:45 --> Form Validation Class Initialized
INFO - 2020-02-06 12:03:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 12:03:45 --> Final output sent to browser
INFO - 2020-02-06 12:03:45 --> Config Class Initialized
INFO - 2020-02-06 12:03:45 --> Hooks Class Initialized
DEBUG - 2020-02-06 12:03:45 --> Total execution time: 0.8078
INFO - 2020-02-06 12:03:45 --> Config Class Initialized
INFO - 2020-02-06 12:03:45 --> Config Class Initialized
INFO - 2020-02-06 12:03:45 --> Config Class Initialized
DEBUG - 2020-02-06 12:03:45 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:03:45 --> Hooks Class Initialized
INFO - 2020-02-06 12:03:45 --> Utf8 Class Initialized
INFO - 2020-02-06 12:03:45 --> Hooks Class Initialized
INFO - 2020-02-06 12:03:45 --> Hooks Class Initialized
INFO - 2020-02-06 12:03:45 --> URI Class Initialized
DEBUG - 2020-02-06 12:03:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 12:03:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-06 12:03:45 --> UTF-8 Support Enabled
INFO - 2020-02-06 12:03:45 --> Utf8 Class Initialized
INFO - 2020-02-06 12:03:45 --> Utf8 Class Initialized
INFO - 2020-02-06 12:03:45 --> Utf8 Class Initialized
INFO - 2020-02-06 12:03:45 --> Router Class Initialized
INFO - 2020-02-06 12:03:45 --> URI Class Initialized
INFO - 2020-02-06 12:03:45 --> Output Class Initialized
INFO - 2020-02-06 12:03:45 --> URI Class Initialized
INFO - 2020-02-06 12:03:45 --> URI Class Initialized
INFO - 2020-02-06 12:03:45 --> Security Class Initialized
INFO - 2020-02-06 12:03:45 --> Router Class Initialized
INFO - 2020-02-06 12:03:45 --> Router Class Initialized
INFO - 2020-02-06 12:03:45 --> Router Class Initialized
DEBUG - 2020-02-06 12:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:03:46 --> Output Class Initialized
INFO - 2020-02-06 12:03:46 --> Output Class Initialized
INFO - 2020-02-06 12:03:46 --> Output Class Initialized
INFO - 2020-02-06 12:03:46 --> Input Class Initialized
INFO - 2020-02-06 12:03:46 --> Security Class Initialized
INFO - 2020-02-06 12:03:46 --> Security Class Initialized
INFO - 2020-02-06 12:03:46 --> Security Class Initialized
INFO - 2020-02-06 12:03:46 --> Language Class Initialized
DEBUG - 2020-02-06 12:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 12:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-06 12:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 12:03:46 --> Input Class Initialized
INFO - 2020-02-06 12:03:46 --> Input Class Initialized
INFO - 2020-02-06 12:03:46 --> Input Class Initialized
ERROR - 2020-02-06 12:03:46 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-06 12:03:46 --> Language Class Initialized
INFO - 2020-02-06 12:03:46 --> Language Class Initialized
INFO - 2020-02-06 12:03:46 --> Language Class Initialized
ERROR - 2020-02-06 12:03:46 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-06 12:03:46 --> Loader Class Initialized
INFO - 2020-02-06 12:03:46 --> Loader Class Initialized
INFO - 2020-02-06 12:03:46 --> Helper loaded: url_helper
INFO - 2020-02-06 12:03:46 --> Helper loaded: url_helper
INFO - 2020-02-06 12:03:46 --> Database Driver Class Initialized
INFO - 2020-02-06 12:03:46 --> Database Driver Class Initialized
DEBUG - 2020-02-06 12:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-06 12:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 12:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 12:03:46 --> Controller Class Initialized
INFO - 2020-02-06 12:03:46 --> Model "M_tiket" initialized
INFO - 2020-02-06 12:03:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 12:03:46 --> Model "M_pesan" initialized
INFO - 2020-02-06 12:03:46 --> Helper loaded: form_helper
INFO - 2020-02-06 12:03:46 --> Form Validation Class Initialized
ERROR - 2020-02-06 12:03:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 12:03:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 12:03:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 12:03:46 --> Final output sent to browser
DEBUG - 2020-02-06 12:03:46 --> Total execution time: 0.9139
INFO - 2020-02-06 12:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 12:03:46 --> Controller Class Initialized
INFO - 2020-02-06 12:03:46 --> Model "M_tiket" initialized
INFO - 2020-02-06 12:03:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-06 12:03:46 --> Model "M_pesan" initialized
INFO - 2020-02-06 12:03:46 --> Helper loaded: form_helper
INFO - 2020-02-06 12:03:46 --> Form Validation Class Initialized
ERROR - 2020-02-06 12:03:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-06 12:03:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-06 12:03:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-06 12:03:46 --> Final output sent to browser
DEBUG - 2020-02-06 12:03:46 --> Total execution time: 1.2066
