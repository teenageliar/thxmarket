<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-09 01:28:53 --> Config Class Initialized
INFO - 2020-01-09 01:28:53 --> Hooks Class Initialized
DEBUG - 2020-01-09 01:28:54 --> UTF-8 Support Enabled
INFO - 2020-01-09 01:28:54 --> Utf8 Class Initialized
INFO - 2020-01-09 01:28:54 --> URI Class Initialized
INFO - 2020-01-09 01:28:54 --> Router Class Initialized
INFO - 2020-01-09 01:28:54 --> Output Class Initialized
INFO - 2020-01-09 01:28:54 --> Security Class Initialized
DEBUG - 2020-01-09 01:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-09 01:28:54 --> Input Class Initialized
INFO - 2020-01-09 01:28:54 --> Language Class Initialized
INFO - 2020-01-09 01:28:54 --> Loader Class Initialized
INFO - 2020-01-09 01:28:54 --> Helper loaded: url_helper
INFO - 2020-01-09 01:28:54 --> Database Driver Class Initialized
ERROR - 2020-01-09 01:28:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\Musikologi-1\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-01-09 01:28:58 --> Unable to connect to the database
INFO - 2020-01-09 01:28:59 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-09 01:29:04 --> Config Class Initialized
INFO - 2020-01-09 01:29:04 --> Hooks Class Initialized
DEBUG - 2020-01-09 01:29:04 --> UTF-8 Support Enabled
INFO - 2020-01-09 01:29:04 --> Utf8 Class Initialized
INFO - 2020-01-09 01:29:04 --> URI Class Initialized
INFO - 2020-01-09 01:29:04 --> Router Class Initialized
INFO - 2020-01-09 01:29:04 --> Output Class Initialized
INFO - 2020-01-09 01:29:04 --> Security Class Initialized
DEBUG - 2020-01-09 01:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-09 01:29:04 --> Input Class Initialized
INFO - 2020-01-09 01:29:04 --> Language Class Initialized
INFO - 2020-01-09 01:29:04 --> Loader Class Initialized
INFO - 2020-01-09 01:29:04 --> Helper loaded: url_helper
INFO - 2020-01-09 01:29:04 --> Database Driver Class Initialized
DEBUG - 2020-01-09 01:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-09 01:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-09 01:29:05 --> Controller Class Initialized
INFO - 2020-01-09 01:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-09 01:29:05 --> Pagination Class Initialized
INFO - 2020-01-09 01:29:05 --> Model "M_event" initialized
INFO - 2020-01-09 01:29:05 --> Model "M_tiket" initialized
INFO - 2020-01-09 01:29:05 --> Helper loaded: form_helper
INFO - 2020-01-09 01:29:05 --> Form Validation Class Initialized
INFO - 2020-01-09 01:29:05 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-09 01:29:05 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-09 01:29:05 --> Final output sent to browser
DEBUG - 2020-01-09 01:29:05 --> Total execution time: 0.9749
INFO - 2020-01-09 01:29:06 --> Config Class Initialized
INFO - 2020-01-09 01:29:06 --> Config Class Initialized
INFO - 2020-01-09 01:29:06 --> Hooks Class Initialized
INFO - 2020-01-09 01:29:06 --> Hooks Class Initialized
DEBUG - 2020-01-09 01:29:06 --> UTF-8 Support Enabled
INFO - 2020-01-09 01:29:06 --> Utf8 Class Initialized
DEBUG - 2020-01-09 01:29:06 --> UTF-8 Support Enabled
INFO - 2020-01-09 01:29:06 --> Utf8 Class Initialized
INFO - 2020-01-09 01:29:06 --> URI Class Initialized
INFO - 2020-01-09 01:29:06 --> URI Class Initialized
INFO - 2020-01-09 01:29:06 --> Router Class Initialized
INFO - 2020-01-09 01:29:06 --> Output Class Initialized
INFO - 2020-01-09 01:29:06 --> Security Class Initialized
INFO - 2020-01-09 01:29:06 --> Router Class Initialized
DEBUG - 2020-01-09 01:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-09 01:29:06 --> Output Class Initialized
INFO - 2020-01-09 01:29:06 --> Input Class Initialized
INFO - 2020-01-09 01:29:06 --> Security Class Initialized
INFO - 2020-01-09 01:29:06 --> Language Class Initialized
ERROR - 2020-01-09 01:29:06 --> 404 Page Not Found: Event/assets
DEBUG - 2020-01-09 01:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-09 01:29:06 --> Input Class Initialized
INFO - 2020-01-09 01:29:06 --> Language Class Initialized
ERROR - 2020-01-09 01:29:06 --> 404 Page Not Found: Event/assets
