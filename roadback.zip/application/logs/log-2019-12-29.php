<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-29 03:54:46 --> Config Class Initialized
INFO - 2019-12-29 03:54:46 --> Hooks Class Initialized
DEBUG - 2019-12-29 03:54:47 --> UTF-8 Support Enabled
INFO - 2019-12-29 03:54:47 --> Utf8 Class Initialized
INFO - 2019-12-29 03:54:47 --> URI Class Initialized
DEBUG - 2019-12-29 03:54:47 --> No URI present. Default controller set.
INFO - 2019-12-29 03:54:47 --> Router Class Initialized
INFO - 2019-12-29 03:54:47 --> Output Class Initialized
INFO - 2019-12-29 03:54:47 --> Security Class Initialized
DEBUG - 2019-12-29 03:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 03:54:47 --> Input Class Initialized
INFO - 2019-12-29 03:54:47 --> Language Class Initialized
INFO - 2019-12-29 03:54:47 --> Loader Class Initialized
INFO - 2019-12-29 03:54:47 --> Helper loaded: url_helper
INFO - 2019-12-29 03:54:48 --> Database Driver Class Initialized
DEBUG - 2019-12-29 03:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-29 03:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-29 03:54:48 --> Controller Class Initialized
INFO - 2019-12-29 03:54:48 --> Model "M_login" initialized
INFO - 2019-12-29 03:54:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2019-12-29 03:54:48 --> Final output sent to browser
DEBUG - 2019-12-29 03:54:48 --> Total execution time: 1.6908
INFO - 2019-12-29 03:54:53 --> Config Class Initialized
INFO - 2019-12-29 03:54:53 --> Hooks Class Initialized
DEBUG - 2019-12-29 03:54:53 --> UTF-8 Support Enabled
INFO - 2019-12-29 03:54:53 --> Utf8 Class Initialized
INFO - 2019-12-29 03:54:53 --> URI Class Initialized
INFO - 2019-12-29 03:54:53 --> Router Class Initialized
INFO - 2019-12-29 03:54:53 --> Output Class Initialized
INFO - 2019-12-29 03:54:53 --> Security Class Initialized
DEBUG - 2019-12-29 03:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 03:54:53 --> Input Class Initialized
INFO - 2019-12-29 03:54:53 --> Language Class Initialized
INFO - 2019-12-29 03:54:53 --> Loader Class Initialized
INFO - 2019-12-29 03:54:53 --> Helper loaded: url_helper
INFO - 2019-12-29 03:54:53 --> Database Driver Class Initialized
DEBUG - 2019-12-29 03:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-29 03:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-29 03:54:53 --> Controller Class Initialized
INFO - 2019-12-29 03:54:53 --> Model "M_login" initialized
INFO - 2019-12-29 03:54:53 --> Config Class Initialized
INFO - 2019-12-29 03:54:53 --> Hooks Class Initialized
DEBUG - 2019-12-29 03:54:53 --> UTF-8 Support Enabled
INFO - 2019-12-29 03:54:53 --> Utf8 Class Initialized
INFO - 2019-12-29 03:54:53 --> URI Class Initialized
INFO - 2019-12-29 03:54:53 --> Router Class Initialized
INFO - 2019-12-29 03:54:53 --> Output Class Initialized
INFO - 2019-12-29 03:54:53 --> Security Class Initialized
DEBUG - 2019-12-29 03:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 03:54:53 --> Input Class Initialized
INFO - 2019-12-29 03:54:53 --> Language Class Initialized
INFO - 2019-12-29 03:54:53 --> Loader Class Initialized
INFO - 2019-12-29 03:54:54 --> Helper loaded: url_helper
INFO - 2019-12-29 03:54:54 --> Database Driver Class Initialized
DEBUG - 2019-12-29 03:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-29 03:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-29 03:54:54 --> Controller Class Initialized
INFO - 2019-12-29 03:54:54 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-29 03:54:54 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-29 03:54:54 --> Final output sent to browser
DEBUG - 2019-12-29 03:54:54 --> Total execution time: 0.4857
INFO - 2019-12-29 03:54:54 --> Config Class Initialized
INFO - 2019-12-29 03:54:54 --> Config Class Initialized
INFO - 2019-12-29 03:54:54 --> Hooks Class Initialized
INFO - 2019-12-29 03:54:54 --> Hooks Class Initialized
DEBUG - 2019-12-29 03:54:54 --> UTF-8 Support Enabled
DEBUG - 2019-12-29 03:54:54 --> UTF-8 Support Enabled
INFO - 2019-12-29 03:54:54 --> Utf8 Class Initialized
INFO - 2019-12-29 03:54:54 --> Utf8 Class Initialized
INFO - 2019-12-29 03:54:54 --> URI Class Initialized
INFO - 2019-12-29 03:54:54 --> URI Class Initialized
INFO - 2019-12-29 03:54:54 --> Router Class Initialized
INFO - 2019-12-29 03:54:54 --> Router Class Initialized
INFO - 2019-12-29 03:54:54 --> Output Class Initialized
INFO - 2019-12-29 03:54:54 --> Output Class Initialized
INFO - 2019-12-29 03:54:54 --> Security Class Initialized
INFO - 2019-12-29 03:54:54 --> Security Class Initialized
DEBUG - 2019-12-29 03:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-29 03:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 03:54:54 --> Input Class Initialized
INFO - 2019-12-29 03:54:54 --> Input Class Initialized
INFO - 2019-12-29 03:54:54 --> Language Class Initialized
INFO - 2019-12-29 03:54:54 --> Language Class Initialized
ERROR - 2019-12-29 03:54:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-29 03:54:54 --> 404 Page Not Found: Assets/js
INFO - 2019-12-29 03:54:54 --> Config Class Initialized
INFO - 2019-12-29 03:54:54 --> Hooks Class Initialized
DEBUG - 2019-12-29 03:54:54 --> UTF-8 Support Enabled
INFO - 2019-12-29 03:54:54 --> Utf8 Class Initialized
INFO - 2019-12-29 03:54:54 --> URI Class Initialized
INFO - 2019-12-29 03:54:54 --> Router Class Initialized
INFO - 2019-12-29 03:54:54 --> Output Class Initialized
INFO - 2019-12-29 03:54:54 --> Security Class Initialized
DEBUG - 2019-12-29 03:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 03:54:54 --> Input Class Initialized
INFO - 2019-12-29 03:54:54 --> Language Class Initialized
ERROR - 2019-12-29 03:54:54 --> 404 Page Not Found: Assets/js
INFO - 2019-12-29 03:54:57 --> Config Class Initialized
INFO - 2019-12-29 03:54:57 --> Hooks Class Initialized
DEBUG - 2019-12-29 03:54:57 --> UTF-8 Support Enabled
INFO - 2019-12-29 03:54:57 --> Utf8 Class Initialized
INFO - 2019-12-29 03:54:57 --> URI Class Initialized
INFO - 2019-12-29 03:54:57 --> Router Class Initialized
INFO - 2019-12-29 03:54:57 --> Output Class Initialized
INFO - 2019-12-29 03:54:57 --> Security Class Initialized
DEBUG - 2019-12-29 03:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 03:54:57 --> Input Class Initialized
INFO - 2019-12-29 03:54:57 --> Language Class Initialized
INFO - 2019-12-29 03:54:57 --> Loader Class Initialized
INFO - 2019-12-29 03:54:58 --> Helper loaded: url_helper
INFO - 2019-12-29 03:54:58 --> Database Driver Class Initialized
DEBUG - 2019-12-29 03:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-29 03:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-29 03:54:58 --> Controller Class Initialized
INFO - 2019-12-29 03:54:58 --> Model "M_login" initialized
INFO - 2019-12-29 03:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-29 03:54:58 --> Pagination Class Initialized
INFO - 2019-12-29 03:54:58 --> Model "M_pesan" initialized
INFO - 2019-12-29 03:54:58 --> Helper loaded: form_helper
INFO - 2019-12-29 03:54:58 --> Form Validation Class Initialized
ERROR - 2019-12-29 03:54:58 --> Severity: error --> Exception: Call to undefined method M_pesan::_table() C:\xampp\htdocs\Musikologi-1\application\models\M_pesan.php 43
INFO - 2019-12-29 03:55:35 --> Config Class Initialized
INFO - 2019-12-29 03:55:35 --> Hooks Class Initialized
DEBUG - 2019-12-29 03:55:35 --> UTF-8 Support Enabled
INFO - 2019-12-29 03:55:35 --> Utf8 Class Initialized
INFO - 2019-12-29 03:55:35 --> URI Class Initialized
INFO - 2019-12-29 03:55:35 --> Router Class Initialized
INFO - 2019-12-29 03:55:35 --> Output Class Initialized
INFO - 2019-12-29 03:55:35 --> Security Class Initialized
DEBUG - 2019-12-29 03:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 03:55:35 --> Input Class Initialized
INFO - 2019-12-29 03:55:35 --> Language Class Initialized
INFO - 2019-12-29 03:55:35 --> Loader Class Initialized
INFO - 2019-12-29 03:55:35 --> Helper loaded: url_helper
INFO - 2019-12-29 03:55:35 --> Database Driver Class Initialized
DEBUG - 2019-12-29 03:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-29 03:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-29 03:55:35 --> Controller Class Initialized
INFO - 2019-12-29 03:55:35 --> Model "M_login" initialized
INFO - 2019-12-29 03:55:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-29 03:55:35 --> Pagination Class Initialized
INFO - 2019-12-29 03:55:35 --> Model "M_pesan" initialized
INFO - 2019-12-29 03:55:35 --> Helper loaded: form_helper
INFO - 2019-12-29 03:55:35 --> Form Validation Class Initialized
ERROR - 2019-12-29 03:55:35 --> Severity: error --> Exception: Call to undefined method M_pesan::_table() C:\xampp\htdocs\Musikologi-1\application\models\M_pesan.php 43
INFO - 2019-12-29 03:56:13 --> Config Class Initialized
INFO - 2019-12-29 03:56:13 --> Hooks Class Initialized
DEBUG - 2019-12-29 03:56:13 --> UTF-8 Support Enabled
INFO - 2019-12-29 03:56:13 --> Utf8 Class Initialized
INFO - 2019-12-29 03:56:13 --> URI Class Initialized
INFO - 2019-12-29 03:56:13 --> Router Class Initialized
INFO - 2019-12-29 03:56:13 --> Output Class Initialized
INFO - 2019-12-29 03:56:13 --> Security Class Initialized
DEBUG - 2019-12-29 03:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 03:56:13 --> Input Class Initialized
INFO - 2019-12-29 03:56:13 --> Language Class Initialized
INFO - 2019-12-29 03:56:13 --> Loader Class Initialized
INFO - 2019-12-29 03:56:13 --> Helper loaded: url_helper
INFO - 2019-12-29 03:56:13 --> Database Driver Class Initialized
DEBUG - 2019-12-29 03:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-29 03:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-29 03:56:13 --> Controller Class Initialized
INFO - 2019-12-29 03:56:13 --> Model "M_login" initialized
INFO - 2019-12-29 03:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-29 03:56:13 --> Pagination Class Initialized
INFO - 2019-12-29 03:56:13 --> Model "M_pesan" initialized
INFO - 2019-12-29 03:56:14 --> Helper loaded: form_helper
INFO - 2019-12-29 03:56:14 --> Form Validation Class Initialized
ERROR - 2019-12-29 03:56:14 --> Severity: Warning --> Illegal string offset 'pemesanan' C:\xampp\htdocs\Musikologi-1\application\models\M_pesan.php 43
ERROR - 2019-12-29 03:56:14 --> Query error: Table 'musikologi.p' doesn't exist - Invalid query: SELECT *
FROM `p`
 LIMIT 20
INFO - 2019-12-29 03:56:14 --> Language file loaded: language/english/db_lang.php
INFO - 2019-12-29 03:56:50 --> Config Class Initialized
INFO - 2019-12-29 03:56:50 --> Hooks Class Initialized
DEBUG - 2019-12-29 03:56:50 --> UTF-8 Support Enabled
INFO - 2019-12-29 03:56:50 --> Utf8 Class Initialized
INFO - 2019-12-29 03:56:50 --> URI Class Initialized
INFO - 2019-12-29 03:56:50 --> Router Class Initialized
INFO - 2019-12-29 03:56:50 --> Output Class Initialized
INFO - 2019-12-29 03:56:50 --> Security Class Initialized
DEBUG - 2019-12-29 03:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 03:56:50 --> Input Class Initialized
INFO - 2019-12-29 03:56:50 --> Language Class Initialized
INFO - 2019-12-29 03:56:50 --> Loader Class Initialized
INFO - 2019-12-29 03:56:50 --> Helper loaded: url_helper
INFO - 2019-12-29 03:56:50 --> Database Driver Class Initialized
DEBUG - 2019-12-29 03:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-29 03:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-29 03:56:50 --> Controller Class Initialized
INFO - 2019-12-29 03:56:50 --> Model "M_login" initialized
INFO - 2019-12-29 03:56:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-29 03:56:50 --> Pagination Class Initialized
INFO - 2019-12-29 03:56:50 --> Model "M_pesan" initialized
INFO - 2019-12-29 03:56:50 --> Helper loaded: form_helper
INFO - 2019-12-29 03:56:50 --> Form Validation Class Initialized
INFO - 2019-12-29 03:56:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-29 03:56:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-29 03:56:50 --> Final output sent to browser
DEBUG - 2019-12-29 03:56:50 --> Total execution time: 0.5718
INFO - 2019-12-29 03:56:50 --> Config Class Initialized
INFO - 2019-12-29 03:56:50 --> Hooks Class Initialized
INFO - 2019-12-29 03:56:50 --> Config Class Initialized
DEBUG - 2019-12-29 03:56:50 --> UTF-8 Support Enabled
INFO - 2019-12-29 03:56:50 --> Hooks Class Initialized
INFO - 2019-12-29 03:56:50 --> Utf8 Class Initialized
INFO - 2019-12-29 03:56:51 --> URI Class Initialized
DEBUG - 2019-12-29 03:56:51 --> UTF-8 Support Enabled
INFO - 2019-12-29 03:56:51 --> Utf8 Class Initialized
INFO - 2019-12-29 03:56:51 --> Router Class Initialized
INFO - 2019-12-29 03:56:51 --> URI Class Initialized
INFO - 2019-12-29 03:56:51 --> Output Class Initialized
INFO - 2019-12-29 03:56:51 --> Security Class Initialized
INFO - 2019-12-29 03:56:51 --> Router Class Initialized
DEBUG - 2019-12-29 03:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 03:56:51 --> Output Class Initialized
INFO - 2019-12-29 03:56:51 --> Input Class Initialized
INFO - 2019-12-29 03:56:51 --> Security Class Initialized
INFO - 2019-12-29 03:56:51 --> Language Class Initialized
DEBUG - 2019-12-29 03:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 03:56:51 --> Input Class Initialized
ERROR - 2019-12-29 03:56:51 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-29 03:56:51 --> Language Class Initialized
ERROR - 2019-12-29 03:56:51 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-29 03:56:51 --> Config Class Initialized
INFO - 2019-12-29 03:56:51 --> Hooks Class Initialized
DEBUG - 2019-12-29 03:56:51 --> UTF-8 Support Enabled
INFO - 2019-12-29 03:56:51 --> Utf8 Class Initialized
INFO - 2019-12-29 03:56:51 --> URI Class Initialized
INFO - 2019-12-29 03:56:51 --> Router Class Initialized
INFO - 2019-12-29 03:56:51 --> Output Class Initialized
INFO - 2019-12-29 03:56:51 --> Security Class Initialized
DEBUG - 2019-12-29 03:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 03:56:51 --> Input Class Initialized
INFO - 2019-12-29 03:56:51 --> Language Class Initialized
ERROR - 2019-12-29 03:56:51 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-29 03:56:51 --> Config Class Initialized
INFO - 2019-12-29 03:56:51 --> Hooks Class Initialized
DEBUG - 2019-12-29 03:56:51 --> UTF-8 Support Enabled
INFO - 2019-12-29 03:56:51 --> Utf8 Class Initialized
INFO - 2019-12-29 03:56:51 --> URI Class Initialized
INFO - 2019-12-29 03:56:51 --> Router Class Initialized
INFO - 2019-12-29 03:56:51 --> Output Class Initialized
INFO - 2019-12-29 03:56:51 --> Security Class Initialized
DEBUG - 2019-12-29 03:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 03:56:51 --> Input Class Initialized
INFO - 2019-12-29 03:56:51 --> Language Class Initialized
ERROR - 2019-12-29 03:56:51 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-29 07:45:06 --> Config Class Initialized
INFO - 2019-12-29 07:45:06 --> Hooks Class Initialized
DEBUG - 2019-12-29 07:45:06 --> UTF-8 Support Enabled
INFO - 2019-12-29 07:45:06 --> Utf8 Class Initialized
INFO - 2019-12-29 07:45:06 --> URI Class Initialized
INFO - 2019-12-29 07:45:06 --> Router Class Initialized
INFO - 2019-12-29 07:45:06 --> Output Class Initialized
INFO - 2019-12-29 07:45:06 --> Security Class Initialized
DEBUG - 2019-12-29 07:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-29 07:45:06 --> Input Class Initialized
INFO - 2019-12-29 07:45:06 --> Language Class Initialized
INFO - 2019-12-29 07:45:06 --> Loader Class Initialized
INFO - 2019-12-29 07:45:06 --> Helper loaded: url_helper
INFO - 2019-12-29 07:45:06 --> Database Driver Class Initialized
DEBUG - 2019-12-29 07:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-29 07:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-29 07:45:06 --> Controller Class Initialized
INFO - 2019-12-29 07:45:06 --> Model "M_login" initialized
INFO - 2019-12-29 07:45:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-29 07:45:06 --> Pagination Class Initialized
INFO - 2019-12-29 07:45:06 --> Model "M_show" initialized
INFO - 2019-12-29 07:45:06 --> Helper loaded: form_helper
INFO - 2019-12-29 07:45:06 --> Form Validation Class Initialized
ERROR - 2019-12-29 07:45:06 --> 404 Page Not Found: 
