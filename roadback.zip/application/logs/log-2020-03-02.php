<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-02 00:04:55 --> Upload Class Initialized
INFO - 2020-03-02 00:06:40 --> Upload Class Initialized
ERROR - 2020-03-02 00:24:14 --> Query error: Unknown column 'tanggal_bayar' in 'field list' - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_bayar`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `atas_nama`, `bukti_bayar`, `id_pengunjung`) VALUES ('34', 600376, '1', '5', '20-03-02 12:24:14', '2020-03-03 12:24:14', NULL, NULL, 'PM207', NULL, NULL, 'default.jpg', '139')
INFO - 2020-03-02 00:24:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-03-02 00:25:09 --> Query error: Unknown column 'tanggal_bayar' in 'field list' - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_bayar`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `atas_nama`, `bukti_bayar`, `id_pengunjung`) VALUES ('34', 600348, '1', '5', '20-03-02 12:25:09', '2020-03-03 12:25:09', NULL, NULL, 'PM207', NULL, NULL, 'default.jpg', '139')
INFO - 2020-03-02 00:25:09 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-03-02 00:25:24 --> Query error: Unknown column 'tanggal_bayar' in 'field list' - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_bayar`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `atas_nama`, `bukti_bayar`, `id_pengunjung`) VALUES ('34', 600728, '1', '5', '20-03-02 12:25:24', '2020-03-03 12:25:24', NULL, NULL, 'PM207', NULL, NULL, 'default.jpg', '234')
INFO - 2020-03-02 00:25:24 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-03-02 00:26:50 --> Query error: Column 'atas_nama' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_bayar`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `atas_nama`, `bukti_bayar`, `id_pengunjung`) VALUES ('34', 360341, '1', '3', '20-03-02 12:26:50', '2020-03-03 12:26:50', NULL, NULL, 'PM1', NULL, NULL, 'default.jpg', '232')
INFO - 2020-03-02 00:26:51 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-03-02 00:27:12 --> Severity: error --> Exception: Call to undefined method M_pesan::getPesan() C:\xampp\htdocs\roadshow-2.1\application\controllers\Tiket.php 80
ERROR - 2020-03-02 00:31:56 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\roadshow-2.1\application\controllers\Tiket.php 130
ERROR - 2020-03-02 00:31:56 --> Severity: error --> Exception: Call to undefined method M_pesan::getPesan() C:\xampp\htdocs\roadshow-2.1\application\controllers\Tiket.php 80
ERROR - 2020-03-02 00:32:31 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\roadshow-2.1\application\controllers\Tiket.php 130
ERROR - 2020-03-02 00:33:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\roadshow-2.1\application\models\M_pesan.php 110
ERROR - 2020-03-02 00:33:25 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\roadshow-2.1\application\controllers\Tiket.php 130
INFO - 2020-03-02 00:34:56 --> Upload Class Initialized
ERROR - 2020-03-02 01:40:32 --> Query error: Column 'tanggal_bayar' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_bayar`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `atas_nama`, `bukti_bayar`, `id_pengunjung`) VALUES ('34', 360426, '1', '3', '20-03-02 01:40:32', '2020-03-03 01:40:32', NULL, NULL, 'PM209', NULL, NULL, 'default.jpg', '232')
INFO - 2020-03-02 01:40:32 --> Language file loaded: language/english/db_lang.php
INFO - 2020-03-02 01:55:59 --> Upload Class Initialized
INFO - 2020-03-02 01:55:59 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2020-03-02 01:55:59 --> You did not select a file to upload.
INFO - 2020-03-02 02:04:39 --> Upload Class Initialized
INFO - 2020-03-02 02:04:39 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2020-03-02 02:04:39 --> You did not select a file to upload.
INFO - 2020-03-02 02:06:04 --> Upload Class Initialized
INFO - 2020-03-02 02:06:04 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2020-03-02 02:06:04 --> You did not select a file to upload.
INFO - 2020-03-02 02:10:52 --> Upload Class Initialized
INFO - 2020-03-02 02:10:52 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2020-03-02 02:10:52 --> You did not select a file to upload.
INFO - 2020-03-02 02:19:20 --> Upload Class Initialized
INFO - 2020-03-02 02:19:20 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2020-03-02 02:19:20 --> You did not select a file to upload.
