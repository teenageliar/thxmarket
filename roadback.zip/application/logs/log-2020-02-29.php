<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-29 07:20:44 --> Config Class Initialized
INFO - 2020-02-29 07:20:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:20:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:20:45 --> Utf8 Class Initialized
INFO - 2020-02-29 07:20:45 --> Config Class Initialized
INFO - 2020-02-29 07:20:45 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:20:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:20:45 --> URI Class Initialized
INFO - 2020-02-29 07:20:45 --> Utf8 Class Initialized
INFO - 2020-02-29 07:20:45 --> URI Class Initialized
DEBUG - 2020-02-29 07:20:45 --> No URI present. Default controller set.
DEBUG - 2020-02-29 07:20:45 --> No URI present. Default controller set.
INFO - 2020-02-29 07:20:45 --> Router Class Initialized
INFO - 2020-02-29 07:20:45 --> Router Class Initialized
INFO - 2020-02-29 07:20:46 --> Output Class Initialized
INFO - 2020-02-29 07:20:46 --> Output Class Initialized
INFO - 2020-02-29 07:20:46 --> Security Class Initialized
INFO - 2020-02-29 07:20:46 --> Security Class Initialized
DEBUG - 2020-02-29 07:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 07:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:20:46 --> Input Class Initialized
INFO - 2020-02-29 07:20:46 --> Input Class Initialized
INFO - 2020-02-29 07:20:47 --> Language Class Initialized
INFO - 2020-02-29 07:20:47 --> Language Class Initialized
INFO - 2020-02-29 07:20:48 --> Loader Class Initialized
INFO - 2020-02-29 07:20:48 --> Loader Class Initialized
INFO - 2020-02-29 07:20:48 --> Helper loaded: url_helper
INFO - 2020-02-29 07:20:48 --> Helper loaded: url_helper
INFO - 2020-02-29 07:20:48 --> Helper loaded: string_helper
INFO - 2020-02-29 07:20:48 --> Helper loaded: string_helper
INFO - 2020-02-29 07:20:49 --> Database Driver Class Initialized
INFO - 2020-02-29 07:20:49 --> Database Driver Class Initialized
DEBUG - 2020-02-29 07:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-29 07:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 07:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 07:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 07:20:50 --> Controller Class Initialized
INFO - 2020-02-29 07:20:50 --> Controller Class Initialized
INFO - 2020-02-29 07:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 07:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 07:20:50 --> Pagination Class Initialized
INFO - 2020-02-29 07:20:50 --> Pagination Class Initialized
INFO - 2020-02-29 07:20:51 --> Model "M_show" initialized
INFO - 2020-02-29 07:20:51 --> Model "M_show" initialized
INFO - 2020-02-29 07:20:51 --> Helper loaded: form_helper
INFO - 2020-02-29 07:20:51 --> Helper loaded: form_helper
INFO - 2020-02-29 07:20:51 --> Form Validation Class Initialized
INFO - 2020-02-29 07:20:51 --> Form Validation Class Initialized
INFO - 2020-02-29 07:20:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-29 07:20:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-29 07:20:52 --> Final output sent to browser
INFO - 2020-02-29 07:20:52 --> Final output sent to browser
DEBUG - 2020-02-29 07:20:52 --> Total execution time: 7.4125
DEBUG - 2020-02-29 07:20:52 --> Total execution time: 9.5823
INFO - 2020-02-29 07:21:03 --> Config Class Initialized
INFO - 2020-02-29 07:21:03 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:21:03 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:03 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:03 --> URI Class Initialized
INFO - 2020-02-29 07:21:04 --> Router Class Initialized
INFO - 2020-02-29 07:21:04 --> Output Class Initialized
INFO - 2020-02-29 07:21:04 --> Security Class Initialized
DEBUG - 2020-02-29 07:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:04 --> Input Class Initialized
INFO - 2020-02-29 07:21:04 --> Language Class Initialized
INFO - 2020-02-29 07:21:04 --> Loader Class Initialized
INFO - 2020-02-29 07:21:04 --> Helper loaded: url_helper
INFO - 2020-02-29 07:21:04 --> Helper loaded: string_helper
INFO - 2020-02-29 07:21:04 --> Database Driver Class Initialized
DEBUG - 2020-02-29 07:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 07:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 07:21:04 --> Controller Class Initialized
INFO - 2020-02-29 07:21:04 --> Model "M_tiket" initialized
INFO - 2020-02-29 07:21:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 07:21:04 --> Model "M_pesan" initialized
INFO - 2020-02-29 07:21:04 --> Helper loaded: form_helper
INFO - 2020-02-29 07:21:04 --> Form Validation Class Initialized
INFO - 2020-02-29 07:21:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 07:21:05 --> Final output sent to browser
DEBUG - 2020-02-29 07:21:05 --> Total execution time: 1.1932
INFO - 2020-02-29 07:21:05 --> Config Class Initialized
INFO - 2020-02-29 07:21:05 --> Config Class Initialized
INFO - 2020-02-29 07:21:05 --> Config Class Initialized
INFO - 2020-02-29 07:21:05 --> Config Class Initialized
INFO - 2020-02-29 07:21:05 --> Hooks Class Initialized
INFO - 2020-02-29 07:21:05 --> Hooks Class Initialized
INFO - 2020-02-29 07:21:05 --> Hooks Class Initialized
INFO - 2020-02-29 07:21:05 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 07:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 07:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 07:21:05 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:05 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:05 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:05 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:05 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:05 --> URI Class Initialized
INFO - 2020-02-29 07:21:05 --> URI Class Initialized
INFO - 2020-02-29 07:21:05 --> URI Class Initialized
INFO - 2020-02-29 07:21:05 --> Router Class Initialized
INFO - 2020-02-29 07:21:05 --> Router Class Initialized
INFO - 2020-02-29 07:21:05 --> Router Class Initialized
INFO - 2020-02-29 07:21:05 --> Output Class Initialized
INFO - 2020-02-29 07:21:05 --> Output Class Initialized
INFO - 2020-02-29 07:21:05 --> Output Class Initialized
INFO - 2020-02-29 07:21:05 --> Security Class Initialized
INFO - 2020-02-29 07:21:05 --> Security Class Initialized
INFO - 2020-02-29 07:21:05 --> URI Class Initialized
INFO - 2020-02-29 07:21:05 --> Security Class Initialized
INFO - 2020-02-29 07:21:05 --> Router Class Initialized
DEBUG - 2020-02-29 07:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 07:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 07:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:05 --> Config Class Initialized
INFO - 2020-02-29 07:21:05 --> Config Class Initialized
INFO - 2020-02-29 07:21:05 --> Hooks Class Initialized
INFO - 2020-02-29 07:21:05 --> Input Class Initialized
INFO - 2020-02-29 07:21:05 --> Input Class Initialized
INFO - 2020-02-29 07:21:05 --> Hooks Class Initialized
INFO - 2020-02-29 07:21:05 --> Input Class Initialized
INFO - 2020-02-29 07:21:05 --> Output Class Initialized
INFO - 2020-02-29 07:21:05 --> Language Class Initialized
INFO - 2020-02-29 07:21:05 --> Language Class Initialized
INFO - 2020-02-29 07:21:05 --> Language Class Initialized
DEBUG - 2020-02-29 07:21:05 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:05 --> Security Class Initialized
DEBUG - 2020-02-29 07:21:05 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:05 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:05 --> Utf8 Class Initialized
DEBUG - 2020-02-29 07:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:05 --> Input Class Initialized
INFO - 2020-02-29 07:21:05 --> URI Class Initialized
INFO - 2020-02-29 07:21:05 --> Language Class Initialized
INFO - 2020-02-29 07:21:05 --> Router Class Initialized
INFO - 2020-02-29 07:21:05 --> URI Class Initialized
ERROR - 2020-02-29 07:21:05 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 07:21:05 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-29 07:21:05 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-29 07:21:05 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 07:21:05 --> Router Class Initialized
INFO - 2020-02-29 07:21:05 --> Output Class Initialized
INFO - 2020-02-29 07:21:05 --> Security Class Initialized
INFO - 2020-02-29 07:21:05 --> Output Class Initialized
INFO - 2020-02-29 07:21:05 --> Security Class Initialized
DEBUG - 2020-02-29 07:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:05 --> Input Class Initialized
INFO - 2020-02-29 07:21:05 --> Config Class Initialized
DEBUG - 2020-02-29 07:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:05 --> Config Class Initialized
INFO - 2020-02-29 07:21:05 --> Config Class Initialized
INFO - 2020-02-29 07:21:05 --> Config Class Initialized
INFO - 2020-02-29 07:21:05 --> Hooks Class Initialized
INFO - 2020-02-29 07:21:05 --> Hooks Class Initialized
INFO - 2020-02-29 07:21:05 --> Hooks Class Initialized
INFO - 2020-02-29 07:21:05 --> Language Class Initialized
INFO - 2020-02-29 07:21:05 --> Input Class Initialized
INFO - 2020-02-29 07:21:05 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:21:05 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:05 --> Utf8 Class Initialized
ERROR - 2020-02-29 07:21:05 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-29 07:21:05 --> Language Class Initialized
DEBUG - 2020-02-29 07:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 07:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 07:21:05 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:05 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:05 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:05 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:05 --> URI Class Initialized
ERROR - 2020-02-29 07:21:05 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 07:21:05 --> URI Class Initialized
INFO - 2020-02-29 07:21:05 --> URI Class Initialized
INFO - 2020-02-29 07:21:05 --> URI Class Initialized
INFO - 2020-02-29 07:21:05 --> Router Class Initialized
INFO - 2020-02-29 07:21:05 --> Config Class Initialized
INFO - 2020-02-29 07:21:05 --> Config Class Initialized
INFO - 2020-02-29 07:21:05 --> Hooks Class Initialized
INFO - 2020-02-29 07:21:05 --> Hooks Class Initialized
INFO - 2020-02-29 07:21:05 --> Router Class Initialized
INFO - 2020-02-29 07:21:05 --> Router Class Initialized
INFO - 2020-02-29 07:21:05 --> Router Class Initialized
INFO - 2020-02-29 07:21:05 --> Output Class Initialized
INFO - 2020-02-29 07:21:05 --> Output Class Initialized
INFO - 2020-02-29 07:21:05 --> Output Class Initialized
INFO - 2020-02-29 07:21:05 --> Output Class Initialized
DEBUG - 2020-02-29 07:21:05 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:05 --> Security Class Initialized
DEBUG - 2020-02-29 07:21:05 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:05 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:05 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:05 --> Security Class Initialized
INFO - 2020-02-29 07:21:05 --> Security Class Initialized
INFO - 2020-02-29 07:21:05 --> Security Class Initialized
DEBUG - 2020-02-29 07:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 07:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 07:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 07:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:05 --> URI Class Initialized
INFO - 2020-02-29 07:21:05 --> Input Class Initialized
INFO - 2020-02-29 07:21:05 --> URI Class Initialized
INFO - 2020-02-29 07:21:05 --> Input Class Initialized
INFO - 2020-02-29 07:21:05 --> Input Class Initialized
INFO - 2020-02-29 07:21:05 --> Input Class Initialized
INFO - 2020-02-29 07:21:05 --> Language Class Initialized
INFO - 2020-02-29 07:21:05 --> Router Class Initialized
INFO - 2020-02-29 07:21:05 --> Router Class Initialized
INFO - 2020-02-29 07:21:05 --> Language Class Initialized
INFO - 2020-02-29 07:21:05 --> Language Class Initialized
INFO - 2020-02-29 07:21:05 --> Output Class Initialized
INFO - 2020-02-29 07:21:05 --> Language Class Initialized
INFO - 2020-02-29 07:21:05 --> Output Class Initialized
ERROR - 2020-02-29 07:21:05 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-29 07:21:05 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 07:21:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 07:21:05 --> Security Class Initialized
ERROR - 2020-02-29 07:21:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 07:21:06 --> Security Class Initialized
INFO - 2020-02-29 07:21:06 --> Config Class Initialized
DEBUG - 2020-02-29 07:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 07:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:06 --> Input Class Initialized
INFO - 2020-02-29 07:21:06 --> Hooks Class Initialized
INFO - 2020-02-29 07:21:06 --> Input Class Initialized
INFO - 2020-02-29 07:21:06 --> Config Class Initialized
INFO - 2020-02-29 07:21:06 --> Hooks Class Initialized
INFO - 2020-02-29 07:21:06 --> Language Class Initialized
INFO - 2020-02-29 07:21:06 --> Language Class Initialized
DEBUG - 2020-02-29 07:21:06 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:06 --> Utf8 Class Initialized
ERROR - 2020-02-29 07:21:06 --> 404 Page Not Found: Bower_components/jquery-i18next
DEBUG - 2020-02-29 07:21:06 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:06 --> Loader Class Initialized
INFO - 2020-02-29 07:21:06 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:06 --> URI Class Initialized
INFO - 2020-02-29 07:21:06 --> Helper loaded: url_helper
INFO - 2020-02-29 07:21:06 --> Helper loaded: string_helper
INFO - 2020-02-29 07:21:06 --> URI Class Initialized
INFO - 2020-02-29 07:21:06 --> Router Class Initialized
INFO - 2020-02-29 07:21:06 --> Router Class Initialized
INFO - 2020-02-29 07:21:06 --> Output Class Initialized
INFO - 2020-02-29 07:21:06 --> Database Driver Class Initialized
INFO - 2020-02-29 07:21:06 --> Security Class Initialized
INFO - 2020-02-29 07:21:06 --> Output Class Initialized
DEBUG - 2020-02-29 07:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 07:21:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-29 07:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:06 --> Security Class Initialized
INFO - 2020-02-29 07:21:06 --> Input Class Initialized
INFO - 2020-02-29 07:21:06 --> Controller Class Initialized
DEBUG - 2020-02-29 07:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:06 --> Input Class Initialized
INFO - 2020-02-29 07:21:06 --> Language Class Initialized
INFO - 2020-02-29 07:21:06 --> Model "M_tiket" initialized
INFO - 2020-02-29 07:21:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 07:21:06 --> Language Class Initialized
INFO - 2020-02-29 07:21:06 --> Loader Class Initialized
INFO - 2020-02-29 07:21:06 --> Model "M_pesan" initialized
INFO - 2020-02-29 07:21:06 --> Helper loaded: url_helper
INFO - 2020-02-29 07:21:06 --> Helper loaded: string_helper
ERROR - 2020-02-29 07:21:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 07:21:06 --> Helper loaded: form_helper
INFO - 2020-02-29 07:21:06 --> Form Validation Class Initialized
INFO - 2020-02-29 07:21:06 --> Database Driver Class Initialized
INFO - 2020-02-29 07:21:06 --> Config Class Initialized
ERROR - 2020-02-29 07:21:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
DEBUG - 2020-02-29 07:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 07:21:06 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:21:06 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:06 --> Utf8 Class Initialized
ERROR - 2020-02-29 07:21:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 07:21:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 07:21:06 --> URI Class Initialized
INFO - 2020-02-29 07:21:06 --> Final output sent to browser
INFO - 2020-02-29 07:21:06 --> Router Class Initialized
DEBUG - 2020-02-29 07:21:06 --> Total execution time: 0.6394
INFO - 2020-02-29 07:21:06 --> Output Class Initialized
INFO - 2020-02-29 07:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 07:21:06 --> Security Class Initialized
INFO - 2020-02-29 07:21:06 --> Controller Class Initialized
DEBUG - 2020-02-29 07:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:06 --> Input Class Initialized
INFO - 2020-02-29 07:21:06 --> Model "M_tiket" initialized
INFO - 2020-02-29 07:21:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 07:21:06 --> Language Class Initialized
INFO - 2020-02-29 07:21:06 --> Model "M_pesan" initialized
ERROR - 2020-02-29 07:21:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 07:21:06 --> Helper loaded: form_helper
INFO - 2020-02-29 07:21:06 --> Form Validation Class Initialized
INFO - 2020-02-29 07:21:06 --> Config Class Initialized
INFO - 2020-02-29 07:21:06 --> Hooks Class Initialized
ERROR - 2020-02-29 07:21:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 07:21:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
DEBUG - 2020-02-29 07:21:06 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:06 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 07:21:06 --> Final output sent to browser
INFO - 2020-02-29 07:21:06 --> URI Class Initialized
DEBUG - 2020-02-29 07:21:06 --> Total execution time: 0.7311
INFO - 2020-02-29 07:21:06 --> Router Class Initialized
INFO - 2020-02-29 07:21:06 --> Output Class Initialized
INFO - 2020-02-29 07:21:06 --> Security Class Initialized
DEBUG - 2020-02-29 07:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:06 --> Input Class Initialized
INFO - 2020-02-29 07:21:06 --> Language Class Initialized
ERROR - 2020-02-29 07:21:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 07:21:07 --> Config Class Initialized
INFO - 2020-02-29 07:21:07 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:21:07 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:07 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:07 --> URI Class Initialized
INFO - 2020-02-29 07:21:07 --> Router Class Initialized
INFO - 2020-02-29 07:21:07 --> Output Class Initialized
INFO - 2020-02-29 07:21:07 --> Security Class Initialized
DEBUG - 2020-02-29 07:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:07 --> Input Class Initialized
INFO - 2020-02-29 07:21:07 --> Language Class Initialized
ERROR - 2020-02-29 07:21:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 07:21:07 --> Config Class Initialized
INFO - 2020-02-29 07:21:07 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:21:07 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:07 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:07 --> URI Class Initialized
INFO - 2020-02-29 07:21:07 --> Router Class Initialized
INFO - 2020-02-29 07:21:07 --> Output Class Initialized
INFO - 2020-02-29 07:21:07 --> Security Class Initialized
DEBUG - 2020-02-29 07:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:07 --> Input Class Initialized
INFO - 2020-02-29 07:21:07 --> Language Class Initialized
ERROR - 2020-02-29 07:21:07 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 07:21:07 --> Config Class Initialized
INFO - 2020-02-29 07:21:07 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:21:07 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:07 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:07 --> URI Class Initialized
INFO - 2020-02-29 07:21:07 --> Router Class Initialized
INFO - 2020-02-29 07:21:07 --> Output Class Initialized
INFO - 2020-02-29 07:21:07 --> Security Class Initialized
DEBUG - 2020-02-29 07:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:07 --> Input Class Initialized
INFO - 2020-02-29 07:21:07 --> Language Class Initialized
ERROR - 2020-02-29 07:21:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 07:21:08 --> Config Class Initialized
INFO - 2020-02-29 07:21:08 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:21:08 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:08 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:08 --> URI Class Initialized
INFO - 2020-02-29 07:21:08 --> Router Class Initialized
INFO - 2020-02-29 07:21:08 --> Output Class Initialized
INFO - 2020-02-29 07:21:08 --> Security Class Initialized
DEBUG - 2020-02-29 07:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:08 --> Input Class Initialized
INFO - 2020-02-29 07:21:08 --> Language Class Initialized
ERROR - 2020-02-29 07:21:08 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 07:21:08 --> Config Class Initialized
INFO - 2020-02-29 07:21:08 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:21:08 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:08 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:08 --> URI Class Initialized
INFO - 2020-02-29 07:21:08 --> Router Class Initialized
INFO - 2020-02-29 07:21:08 --> Output Class Initialized
INFO - 2020-02-29 07:21:08 --> Security Class Initialized
DEBUG - 2020-02-29 07:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:08 --> Input Class Initialized
INFO - 2020-02-29 07:21:08 --> Language Class Initialized
ERROR - 2020-02-29 07:21:08 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 07:21:25 --> Config Class Initialized
INFO - 2020-02-29 07:21:25 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:21:25 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:25 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:25 --> URI Class Initialized
INFO - 2020-02-29 07:21:25 --> Router Class Initialized
INFO - 2020-02-29 07:21:25 --> Output Class Initialized
INFO - 2020-02-29 07:21:25 --> Security Class Initialized
DEBUG - 2020-02-29 07:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:25 --> Input Class Initialized
INFO - 2020-02-29 07:21:25 --> Language Class Initialized
INFO - 2020-02-29 07:21:26 --> Loader Class Initialized
INFO - 2020-02-29 07:21:26 --> Helper loaded: url_helper
INFO - 2020-02-29 07:21:26 --> Helper loaded: string_helper
INFO - 2020-02-29 07:21:26 --> Database Driver Class Initialized
DEBUG - 2020-02-29 07:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 07:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 07:21:26 --> Controller Class Initialized
INFO - 2020-02-29 07:21:26 --> Model "M_tiket" initialized
INFO - 2020-02-29 07:21:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 07:21:26 --> Model "M_pesan" initialized
INFO - 2020-02-29 07:21:26 --> Helper loaded: form_helper
INFO - 2020-02-29 07:21:26 --> Form Validation Class Initialized
INFO - 2020-02-29 13:21:26 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-29 13:21:26 --> Final output sent to browser
DEBUG - 2020-02-29 13:21:26 --> Total execution time: 1.0093
INFO - 2020-02-29 07:21:32 --> Config Class Initialized
INFO - 2020-02-29 07:21:32 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:21:32 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:21:32 --> Utf8 Class Initialized
INFO - 2020-02-29 07:21:32 --> URI Class Initialized
INFO - 2020-02-29 07:21:32 --> Router Class Initialized
INFO - 2020-02-29 07:21:32 --> Output Class Initialized
INFO - 2020-02-29 07:21:32 --> Security Class Initialized
DEBUG - 2020-02-29 07:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:21:32 --> Input Class Initialized
INFO - 2020-02-29 07:21:32 --> Language Class Initialized
INFO - 2020-02-29 07:21:32 --> Loader Class Initialized
INFO - 2020-02-29 07:21:32 --> Helper loaded: url_helper
INFO - 2020-02-29 07:21:32 --> Helper loaded: string_helper
INFO - 2020-02-29 07:21:32 --> Database Driver Class Initialized
DEBUG - 2020-02-29 07:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 07:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 07:21:32 --> Controller Class Initialized
INFO - 2020-02-29 07:21:32 --> Model "M_tiket" initialized
INFO - 2020-02-29 07:21:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 07:21:32 --> Model "M_pesan" initialized
INFO - 2020-02-29 07:21:32 --> Helper loaded: form_helper
INFO - 2020-02-29 07:21:32 --> Form Validation Class Initialized
ERROR - 2020-02-29 07:21:33 --> Severity: Notice --> Undefined variable: tanggalp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-29 07:21:33 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-29 07:21:33 --> Final output sent to browser
DEBUG - 2020-02-29 07:21:33 --> Total execution time: 1.0207
INFO - 2020-02-29 07:22:29 --> Config Class Initialized
INFO - 2020-02-29 07:22:29 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:22:29 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:22:29 --> Utf8 Class Initialized
INFO - 2020-02-29 07:22:29 --> URI Class Initialized
INFO - 2020-02-29 07:22:29 --> Router Class Initialized
INFO - 2020-02-29 07:22:29 --> Output Class Initialized
INFO - 2020-02-29 07:22:29 --> Security Class Initialized
DEBUG - 2020-02-29 07:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:22:29 --> Input Class Initialized
INFO - 2020-02-29 07:22:30 --> Language Class Initialized
INFO - 2020-02-29 07:22:30 --> Loader Class Initialized
INFO - 2020-02-29 07:22:30 --> Helper loaded: url_helper
INFO - 2020-02-29 07:22:30 --> Helper loaded: string_helper
INFO - 2020-02-29 07:22:30 --> Database Driver Class Initialized
DEBUG - 2020-02-29 07:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 07:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 07:22:30 --> Controller Class Initialized
INFO - 2020-02-29 07:22:30 --> Model "M_tiket" initialized
INFO - 2020-02-29 07:22:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 07:22:30 --> Model "M_pesan" initialized
INFO - 2020-02-29 07:22:30 --> Helper loaded: form_helper
INFO - 2020-02-29 07:22:30 --> Form Validation Class Initialized
INFO - 2020-02-29 07:22:30 --> Upload Class Initialized
INFO - 2020-02-29 07:22:30 --> Config Class Initialized
INFO - 2020-02-29 07:22:30 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:22:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:22:30 --> Utf8 Class Initialized
INFO - 2020-02-29 07:22:30 --> URI Class Initialized
INFO - 2020-02-29 07:22:30 --> Router Class Initialized
INFO - 2020-02-29 07:22:30 --> Output Class Initialized
INFO - 2020-02-29 07:22:30 --> Security Class Initialized
DEBUG - 2020-02-29 07:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:22:30 --> Input Class Initialized
INFO - 2020-02-29 07:22:30 --> Language Class Initialized
INFO - 2020-02-29 07:22:30 --> Loader Class Initialized
INFO - 2020-02-29 07:22:30 --> Helper loaded: url_helper
INFO - 2020-02-29 07:22:30 --> Helper loaded: string_helper
INFO - 2020-02-29 07:22:30 --> Database Driver Class Initialized
DEBUG - 2020-02-29 07:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 07:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 07:22:30 --> Controller Class Initialized
INFO - 2020-02-29 07:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 07:22:31 --> Pagination Class Initialized
INFO - 2020-02-29 07:22:31 --> Model "M_show" initialized
INFO - 2020-02-29 07:22:31 --> Helper loaded: form_helper
INFO - 2020-02-29 07:22:31 --> Form Validation Class Initialized
INFO - 2020-02-29 07:22:31 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-29 07:22:31 --> Final output sent to browser
DEBUG - 2020-02-29 07:22:31 --> Total execution time: 0.4997
INFO - 2020-02-29 07:22:31 --> Config Class Initialized
INFO - 2020-02-29 07:22:31 --> Config Class Initialized
INFO - 2020-02-29 07:22:31 --> Hooks Class Initialized
INFO - 2020-02-29 07:22:31 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:22:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 07:22:31 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:22:31 --> Utf8 Class Initialized
INFO - 2020-02-29 07:22:31 --> Utf8 Class Initialized
INFO - 2020-02-29 07:22:31 --> URI Class Initialized
INFO - 2020-02-29 07:22:31 --> URI Class Initialized
INFO - 2020-02-29 07:22:31 --> Router Class Initialized
INFO - 2020-02-29 07:22:31 --> Router Class Initialized
INFO - 2020-02-29 07:22:31 --> Output Class Initialized
INFO - 2020-02-29 07:22:31 --> Output Class Initialized
INFO - 2020-02-29 07:22:31 --> Security Class Initialized
INFO - 2020-02-29 07:22:31 --> Security Class Initialized
DEBUG - 2020-02-29 07:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 07:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:22:31 --> Input Class Initialized
INFO - 2020-02-29 07:22:31 --> Input Class Initialized
INFO - 2020-02-29 07:22:31 --> Language Class Initialized
INFO - 2020-02-29 07:22:31 --> Language Class Initialized
ERROR - 2020-02-29 07:22:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-29 07:22:31 --> 404 Page Not Found: Assets/js
INFO - 2020-02-29 07:22:31 --> Config Class Initialized
INFO - 2020-02-29 07:22:31 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:22:31 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:22:31 --> Utf8 Class Initialized
INFO - 2020-02-29 07:22:32 --> URI Class Initialized
INFO - 2020-02-29 07:22:32 --> Router Class Initialized
INFO - 2020-02-29 07:22:32 --> Output Class Initialized
INFO - 2020-02-29 07:22:32 --> Security Class Initialized
DEBUG - 2020-02-29 07:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:22:32 --> Input Class Initialized
INFO - 2020-02-29 07:22:32 --> Language Class Initialized
ERROR - 2020-02-29 07:22:32 --> 404 Page Not Found: Assets/js
INFO - 2020-02-29 07:22:32 --> Config Class Initialized
INFO - 2020-02-29 07:22:32 --> Hooks Class Initialized
DEBUG - 2020-02-29 07:22:32 --> UTF-8 Support Enabled
INFO - 2020-02-29 07:22:32 --> Utf8 Class Initialized
INFO - 2020-02-29 07:22:32 --> URI Class Initialized
INFO - 2020-02-29 07:22:32 --> Router Class Initialized
INFO - 2020-02-29 07:22:32 --> Output Class Initialized
INFO - 2020-02-29 07:22:32 --> Security Class Initialized
DEBUG - 2020-02-29 07:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 07:22:32 --> Input Class Initialized
INFO - 2020-02-29 07:22:32 --> Language Class Initialized
ERROR - 2020-02-29 07:22:32 --> 404 Page Not Found: Assets/js
INFO - 2020-02-29 10:28:22 --> Config Class Initialized
INFO - 2020-02-29 10:28:22 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:28:22 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:28:22 --> Utf8 Class Initialized
INFO - 2020-02-29 10:28:22 --> URI Class Initialized
DEBUG - 2020-02-29 10:28:22 --> No URI present. Default controller set.
INFO - 2020-02-29 10:28:22 --> Router Class Initialized
INFO - 2020-02-29 10:28:22 --> Output Class Initialized
INFO - 2020-02-29 10:28:22 --> Security Class Initialized
DEBUG - 2020-02-29 10:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:28:22 --> Input Class Initialized
INFO - 2020-02-29 10:28:22 --> Language Class Initialized
INFO - 2020-02-29 10:28:22 --> Loader Class Initialized
INFO - 2020-02-29 10:28:22 --> Helper loaded: url_helper
INFO - 2020-02-29 10:28:22 --> Helper loaded: string_helper
INFO - 2020-02-29 10:28:22 --> Database Driver Class Initialized
ERROR - 2020-02-29 10:28:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'musikologi-v3' C:\xampp\htdocs\roadshow-2\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-02-29 10:28:22 --> Unable to connect to the database
INFO - 2020-02-29 10:28:22 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-29 10:31:02 --> Config Class Initialized
INFO - 2020-02-29 10:31:03 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:31:03 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:31:03 --> Utf8 Class Initialized
INFO - 2020-02-29 10:31:03 --> URI Class Initialized
DEBUG - 2020-02-29 10:31:03 --> No URI present. Default controller set.
INFO - 2020-02-29 10:31:03 --> Router Class Initialized
INFO - 2020-02-29 10:31:03 --> Output Class Initialized
INFO - 2020-02-29 10:31:03 --> Security Class Initialized
DEBUG - 2020-02-29 10:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:31:03 --> Input Class Initialized
INFO - 2020-02-29 10:31:03 --> Language Class Initialized
INFO - 2020-02-29 10:31:03 --> Loader Class Initialized
INFO - 2020-02-29 10:31:03 --> Helper loaded: url_helper
INFO - 2020-02-29 10:31:03 --> Helper loaded: string_helper
INFO - 2020-02-29 10:31:03 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:31:04 --> Controller Class Initialized
INFO - 2020-02-29 10:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:31:04 --> Pagination Class Initialized
INFO - 2020-02-29 10:31:04 --> Model "M_show" initialized
INFO - 2020-02-29 10:31:04 --> Helper loaded: form_helper
INFO - 2020-02-29 10:31:04 --> Form Validation Class Initialized
INFO - 2020-02-29 10:31:04 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-29 10:31:04 --> Final output sent to browser
DEBUG - 2020-02-29 10:31:04 --> Total execution time: 2.0314
INFO - 2020-02-29 10:31:10 --> Config Class Initialized
INFO - 2020-02-29 10:31:15 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:31:17 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:31:17 --> Utf8 Class Initialized
INFO - 2020-02-29 10:31:17 --> URI Class Initialized
INFO - 2020-02-29 10:31:17 --> Router Class Initialized
INFO - 2020-02-29 10:31:17 --> Output Class Initialized
INFO - 2020-02-29 10:31:17 --> Security Class Initialized
DEBUG - 2020-02-29 10:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:31:17 --> Input Class Initialized
INFO - 2020-02-29 10:31:17 --> Language Class Initialized
ERROR - 2020-02-29 10:31:17 --> 404 Page Not Found: Tiket/bayar_nanti
INFO - 2020-02-29 10:32:38 --> Config Class Initialized
INFO - 2020-02-29 10:32:38 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:32:38 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:32:38 --> Utf8 Class Initialized
INFO - 2020-02-29 10:32:38 --> URI Class Initialized
INFO - 2020-02-29 10:32:38 --> Router Class Initialized
INFO - 2020-02-29 10:32:38 --> Output Class Initialized
INFO - 2020-02-29 10:32:38 --> Security Class Initialized
DEBUG - 2020-02-29 10:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:32:38 --> Input Class Initialized
INFO - 2020-02-29 10:32:38 --> Language Class Initialized
ERROR - 2020-02-29 10:32:38 --> 404 Page Not Found: Upload_bukti/index
INFO - 2020-02-29 10:32:55 --> Config Class Initialized
INFO - 2020-02-29 10:32:55 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:32:55 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:32:55 --> Utf8 Class Initialized
INFO - 2020-02-29 10:32:55 --> URI Class Initialized
INFO - 2020-02-29 10:32:55 --> Router Class Initialized
INFO - 2020-02-29 10:32:55 --> Output Class Initialized
INFO - 2020-02-29 10:32:55 --> Security Class Initialized
DEBUG - 2020-02-29 10:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:32:55 --> Input Class Initialized
INFO - 2020-02-29 10:32:55 --> Language Class Initialized
INFO - 2020-02-29 10:32:55 --> Loader Class Initialized
INFO - 2020-02-29 10:32:55 --> Helper loaded: url_helper
INFO - 2020-02-29 10:32:55 --> Helper loaded: string_helper
INFO - 2020-02-29 10:32:55 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:32:55 --> Controller Class Initialized
INFO - 2020-02-29 10:32:55 --> Model "M_tiket" initialized
INFO - 2020-02-29 10:32:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 10:32:55 --> Model "M_pesan" initialized
INFO - 2020-02-29 10:32:55 --> Helper loaded: form_helper
INFO - 2020-02-29 10:32:55 --> Form Validation Class Initialized
ERROR - 2020-02-29 10:32:55 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 30
ERROR - 2020-02-29 10:32:55 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 31
ERROR - 2020-02-29 10:32:55 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 32
ERROR - 2020-02-29 10:32:55 --> Severity: Notice --> Undefined index: kode_bayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 33
ERROR - 2020-02-29 10:32:55 --> Severity: Notice --> Undefined variable: tanggalp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-29 10:32:55 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-29 10:32:55 --> Final output sent to browser
DEBUG - 2020-02-29 10:32:55 --> Total execution time: 0.2729
INFO - 2020-02-29 10:35:10 --> Config Class Initialized
INFO - 2020-02-29 10:35:10 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:35:10 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:35:10 --> Utf8 Class Initialized
INFO - 2020-02-29 10:35:10 --> URI Class Initialized
DEBUG - 2020-02-29 10:35:10 --> No URI present. Default controller set.
INFO - 2020-02-29 10:35:10 --> Router Class Initialized
INFO - 2020-02-29 10:35:10 --> Output Class Initialized
INFO - 2020-02-29 10:35:10 --> Security Class Initialized
DEBUG - 2020-02-29 10:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:35:10 --> Input Class Initialized
INFO - 2020-02-29 10:35:10 --> Language Class Initialized
INFO - 2020-02-29 10:35:10 --> Loader Class Initialized
INFO - 2020-02-29 10:35:10 --> Helper loaded: url_helper
INFO - 2020-02-29 10:35:10 --> Helper loaded: string_helper
INFO - 2020-02-29 10:35:10 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:35:10 --> Controller Class Initialized
INFO - 2020-02-29 10:35:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:35:10 --> Pagination Class Initialized
INFO - 2020-02-29 10:35:10 --> Model "M_show" initialized
INFO - 2020-02-29 10:35:10 --> Helper loaded: form_helper
INFO - 2020-02-29 10:35:10 --> Form Validation Class Initialized
INFO - 2020-02-29 10:35:10 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-29 10:35:10 --> Final output sent to browser
DEBUG - 2020-02-29 10:35:10 --> Total execution time: 0.2238
INFO - 2020-02-29 10:45:54 --> Config Class Initialized
INFO - 2020-02-29 10:45:54 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:45:54 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:45:54 --> Utf8 Class Initialized
INFO - 2020-02-29 10:45:54 --> URI Class Initialized
DEBUG - 2020-02-29 10:45:54 --> No URI present. Default controller set.
INFO - 2020-02-29 10:45:54 --> Router Class Initialized
INFO - 2020-02-29 10:45:54 --> Output Class Initialized
INFO - 2020-02-29 10:45:54 --> Security Class Initialized
DEBUG - 2020-02-29 10:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:45:54 --> Input Class Initialized
INFO - 2020-02-29 10:45:54 --> Language Class Initialized
ERROR - 2020-02-29 10:45:54 --> Severity: Compile Error --> Cannot redeclare Show::index_2() C:\xampp\htdocs\roadshow-2\application\controllers\Show.php 30
INFO - 2020-02-29 10:46:06 --> Config Class Initialized
INFO - 2020-02-29 10:46:06 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:46:06 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:46:06 --> Utf8 Class Initialized
INFO - 2020-02-29 10:46:06 --> URI Class Initialized
DEBUG - 2020-02-29 10:46:06 --> No URI present. Default controller set.
INFO - 2020-02-29 10:46:06 --> Router Class Initialized
INFO - 2020-02-29 10:46:06 --> Output Class Initialized
INFO - 2020-02-29 10:46:06 --> Security Class Initialized
DEBUG - 2020-02-29 10:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:46:06 --> Input Class Initialized
INFO - 2020-02-29 10:46:06 --> Language Class Initialized
INFO - 2020-02-29 10:46:06 --> Loader Class Initialized
INFO - 2020-02-29 10:46:06 --> Helper loaded: url_helper
INFO - 2020-02-29 10:46:06 --> Helper loaded: string_helper
INFO - 2020-02-29 10:46:06 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:46:06 --> Controller Class Initialized
INFO - 2020-02-29 10:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:46:06 --> Pagination Class Initialized
INFO - 2020-02-29 10:46:06 --> Model "M_show" initialized
INFO - 2020-02-29 10:46:06 --> Helper loaded: form_helper
INFO - 2020-02-29 10:46:06 --> Form Validation Class Initialized
INFO - 2020-02-29 10:46:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:47:05 --> Config Class Initialized
INFO - 2020-02-29 10:47:05 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:47:05 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:47:05 --> Utf8 Class Initialized
INFO - 2020-02-29 10:47:05 --> URI Class Initialized
DEBUG - 2020-02-29 10:47:05 --> No URI present. Default controller set.
INFO - 2020-02-29 10:47:05 --> Router Class Initialized
INFO - 2020-02-29 10:47:05 --> Output Class Initialized
INFO - 2020-02-29 10:47:05 --> Security Class Initialized
DEBUG - 2020-02-29 10:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:47:05 --> Input Class Initialized
INFO - 2020-02-29 10:47:05 --> Language Class Initialized
INFO - 2020-02-29 10:47:05 --> Loader Class Initialized
INFO - 2020-02-29 10:47:05 --> Helper loaded: url_helper
INFO - 2020-02-29 10:47:05 --> Helper loaded: string_helper
INFO - 2020-02-29 10:47:05 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:47:05 --> Controller Class Initialized
INFO - 2020-02-29 10:47:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:47:05 --> Pagination Class Initialized
INFO - 2020-02-29 10:47:05 --> Model "M_show" initialized
INFO - 2020-02-29 10:47:05 --> Helper loaded: form_helper
INFO - 2020-02-29 10:47:05 --> Form Validation Class Initialized
INFO - 2020-02-29 10:47:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:47:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\home.php
INFO - 2020-02-29 10:47:06 --> Final output sent to browser
DEBUG - 2020-02-29 10:47:06 --> Total execution time: 0.7363
INFO - 2020-02-29 10:48:26 --> Config Class Initialized
INFO - 2020-02-29 10:48:26 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:48:26 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:48:26 --> Utf8 Class Initialized
INFO - 2020-02-29 10:48:26 --> URI Class Initialized
DEBUG - 2020-02-29 10:48:26 --> No URI present. Default controller set.
INFO - 2020-02-29 10:48:26 --> Router Class Initialized
INFO - 2020-02-29 10:48:26 --> Output Class Initialized
INFO - 2020-02-29 10:48:27 --> Security Class Initialized
DEBUG - 2020-02-29 10:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:48:27 --> Input Class Initialized
INFO - 2020-02-29 10:48:27 --> Language Class Initialized
INFO - 2020-02-29 10:48:27 --> Loader Class Initialized
INFO - 2020-02-29 10:48:27 --> Helper loaded: url_helper
INFO - 2020-02-29 10:48:27 --> Helper loaded: string_helper
INFO - 2020-02-29 10:48:27 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:48:27 --> Controller Class Initialized
INFO - 2020-02-29 10:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:48:27 --> Pagination Class Initialized
INFO - 2020-02-29 10:48:27 --> Model "M_show" initialized
INFO - 2020-02-29 10:48:27 --> Helper loaded: form_helper
INFO - 2020-02-29 10:48:27 --> Form Validation Class Initialized
INFO - 2020-02-29 10:48:27 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:48:27 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\home.php
INFO - 2020-02-29 10:48:27 --> Final output sent to browser
DEBUG - 2020-02-29 10:48:27 --> Total execution time: 1.4004
INFO - 2020-02-29 10:49:59 --> Config Class Initialized
INFO - 2020-02-29 10:49:59 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:49:59 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:49:59 --> Utf8 Class Initialized
INFO - 2020-02-29 10:49:59 --> URI Class Initialized
DEBUG - 2020-02-29 10:49:59 --> No URI present. Default controller set.
INFO - 2020-02-29 10:49:59 --> Router Class Initialized
INFO - 2020-02-29 10:49:59 --> Output Class Initialized
INFO - 2020-02-29 10:49:59 --> Security Class Initialized
DEBUG - 2020-02-29 10:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:49:59 --> Input Class Initialized
INFO - 2020-02-29 10:49:59 --> Language Class Initialized
INFO - 2020-02-29 10:49:59 --> Loader Class Initialized
INFO - 2020-02-29 10:49:59 --> Helper loaded: url_helper
INFO - 2020-02-29 10:49:59 --> Helper loaded: string_helper
INFO - 2020-02-29 10:49:59 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:49:59 --> Controller Class Initialized
INFO - 2020-02-29 10:49:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:49:59 --> Pagination Class Initialized
INFO - 2020-02-29 10:49:59 --> Model "M_show" initialized
INFO - 2020-02-29 10:49:59 --> Helper loaded: form_helper
INFO - 2020-02-29 10:49:59 --> Form Validation Class Initialized
INFO - 2020-02-29 10:49:59 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:49:59 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\home.php
INFO - 2020-02-29 10:49:59 --> Final output sent to browser
DEBUG - 2020-02-29 10:49:59 --> Total execution time: 0.6761
INFO - 2020-02-29 10:50:36 --> Config Class Initialized
INFO - 2020-02-29 10:50:38 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:50:38 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:50:38 --> Utf8 Class Initialized
INFO - 2020-02-29 10:50:38 --> URI Class Initialized
DEBUG - 2020-02-29 10:50:38 --> No URI present. Default controller set.
INFO - 2020-02-29 10:50:38 --> Router Class Initialized
INFO - 2020-02-29 10:50:38 --> Output Class Initialized
INFO - 2020-02-29 10:50:38 --> Security Class Initialized
DEBUG - 2020-02-29 10:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:50:38 --> Input Class Initialized
INFO - 2020-02-29 10:50:38 --> Language Class Initialized
INFO - 2020-02-29 10:50:38 --> Loader Class Initialized
INFO - 2020-02-29 10:50:38 --> Helper loaded: url_helper
INFO - 2020-02-29 10:50:38 --> Helper loaded: string_helper
INFO - 2020-02-29 10:50:38 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:50:38 --> Controller Class Initialized
INFO - 2020-02-29 10:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:50:38 --> Pagination Class Initialized
INFO - 2020-02-29 10:50:38 --> Model "M_show" initialized
INFO - 2020-02-29 10:50:38 --> Helper loaded: form_helper
INFO - 2020-02-29 10:50:38 --> Form Validation Class Initialized
INFO - 2020-02-29 10:50:38 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:50:38 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\home.php
INFO - 2020-02-29 10:50:38 --> Final output sent to browser
DEBUG - 2020-02-29 10:50:38 --> Total execution time: 3.8050
INFO - 2020-02-29 10:52:40 --> Config Class Initialized
INFO - 2020-02-29 10:52:40 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:52:40 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:52:40 --> Utf8 Class Initialized
INFO - 2020-02-29 10:52:40 --> URI Class Initialized
DEBUG - 2020-02-29 10:52:40 --> No URI present. Default controller set.
INFO - 2020-02-29 10:52:40 --> Router Class Initialized
INFO - 2020-02-29 10:52:40 --> Output Class Initialized
INFO - 2020-02-29 10:52:40 --> Security Class Initialized
DEBUG - 2020-02-29 10:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:52:40 --> Input Class Initialized
INFO - 2020-02-29 10:52:40 --> Language Class Initialized
INFO - 2020-02-29 10:52:40 --> Loader Class Initialized
INFO - 2020-02-29 10:52:40 --> Helper loaded: url_helper
INFO - 2020-02-29 10:52:40 --> Helper loaded: string_helper
INFO - 2020-02-29 10:52:40 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:52:40 --> Controller Class Initialized
INFO - 2020-02-29 10:52:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:52:40 --> Pagination Class Initialized
INFO - 2020-02-29 10:52:40 --> Model "M_show" initialized
INFO - 2020-02-29 10:52:40 --> Helper loaded: form_helper
INFO - 2020-02-29 10:52:40 --> Form Validation Class Initialized
INFO - 2020-02-29 10:52:40 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:52:40 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\home.php
INFO - 2020-02-29 10:52:41 --> Final output sent to browser
DEBUG - 2020-02-29 10:52:41 --> Total execution time: 0.2524
INFO - 2020-02-29 10:52:59 --> Config Class Initialized
INFO - 2020-02-29 10:52:59 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:52:59 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:52:59 --> Utf8 Class Initialized
INFO - 2020-02-29 10:52:59 --> URI Class Initialized
DEBUG - 2020-02-29 10:52:59 --> No URI present. Default controller set.
INFO - 2020-02-29 10:52:59 --> Router Class Initialized
INFO - 2020-02-29 10:52:59 --> Output Class Initialized
INFO - 2020-02-29 10:52:59 --> Security Class Initialized
DEBUG - 2020-02-29 10:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:52:59 --> Input Class Initialized
INFO - 2020-02-29 10:52:59 --> Language Class Initialized
INFO - 2020-02-29 10:52:59 --> Loader Class Initialized
INFO - 2020-02-29 10:52:59 --> Helper loaded: url_helper
INFO - 2020-02-29 10:52:59 --> Helper loaded: string_helper
INFO - 2020-02-29 10:52:59 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:52:59 --> Controller Class Initialized
INFO - 2020-02-29 10:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:53:00 --> Pagination Class Initialized
INFO - 2020-02-29 10:53:00 --> Model "M_show" initialized
INFO - 2020-02-29 10:53:00 --> Helper loaded: form_helper
INFO - 2020-02-29 10:53:00 --> Form Validation Class Initialized
INFO - 2020-02-29 10:53:00 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:53:00 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\home.php
INFO - 2020-02-29 10:53:00 --> Final output sent to browser
DEBUG - 2020-02-29 10:53:00 --> Total execution time: 0.2677
INFO - 2020-02-29 10:53:05 --> Config Class Initialized
INFO - 2020-02-29 10:53:05 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:53:05 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:53:05 --> Utf8 Class Initialized
INFO - 2020-02-29 10:53:05 --> URI Class Initialized
INFO - 2020-02-29 10:53:05 --> Router Class Initialized
INFO - 2020-02-29 10:53:05 --> Output Class Initialized
INFO - 2020-02-29 10:53:05 --> Security Class Initialized
DEBUG - 2020-02-29 10:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:53:05 --> Input Class Initialized
INFO - 2020-02-29 10:53:05 --> Language Class Initialized
INFO - 2020-02-29 10:53:05 --> Loader Class Initialized
INFO - 2020-02-29 10:53:05 --> Helper loaded: url_helper
INFO - 2020-02-29 10:53:05 --> Helper loaded: string_helper
INFO - 2020-02-29 10:53:05 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:53:05 --> Controller Class Initialized
INFO - 2020-02-29 10:53:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:53:05 --> Pagination Class Initialized
INFO - 2020-02-29 10:53:05 --> Model "M_show" initialized
INFO - 2020-02-29 10:53:05 --> Helper loaded: form_helper
INFO - 2020-02-29 10:53:05 --> Form Validation Class Initialized
INFO - 2020-02-29 10:53:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:53:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\hub.php
INFO - 2020-02-29 10:53:06 --> Final output sent to browser
DEBUG - 2020-02-29 10:53:06 --> Total execution time: 2.5985
INFO - 2020-02-29 10:53:36 --> Config Class Initialized
INFO - 2020-02-29 10:53:36 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:53:36 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:53:36 --> Utf8 Class Initialized
INFO - 2020-02-29 10:53:36 --> URI Class Initialized
INFO - 2020-02-29 10:53:36 --> Router Class Initialized
INFO - 2020-02-29 10:53:36 --> Output Class Initialized
INFO - 2020-02-29 10:53:36 --> Security Class Initialized
DEBUG - 2020-02-29 10:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:53:37 --> Input Class Initialized
INFO - 2020-02-29 10:53:37 --> Language Class Initialized
INFO - 2020-02-29 10:53:37 --> Loader Class Initialized
INFO - 2020-02-29 10:53:37 --> Helper loaded: url_helper
INFO - 2020-02-29 10:53:37 --> Helper loaded: string_helper
INFO - 2020-02-29 10:53:37 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:53:37 --> Controller Class Initialized
INFO - 2020-02-29 10:53:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:53:37 --> Pagination Class Initialized
INFO - 2020-02-29 10:53:37 --> Model "M_show" initialized
INFO - 2020-02-29 10:53:37 --> Helper loaded: form_helper
INFO - 2020-02-29 10:53:37 --> Form Validation Class Initialized
INFO - 2020-02-29 10:53:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:53:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\hub.php
INFO - 2020-02-29 10:53:37 --> Final output sent to browser
DEBUG - 2020-02-29 10:53:37 --> Total execution time: 0.2402
INFO - 2020-02-29 10:53:45 --> Config Class Initialized
INFO - 2020-02-29 10:53:45 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:53:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:53:45 --> Utf8 Class Initialized
INFO - 2020-02-29 10:53:45 --> URI Class Initialized
INFO - 2020-02-29 10:53:45 --> Router Class Initialized
INFO - 2020-02-29 10:53:45 --> Output Class Initialized
INFO - 2020-02-29 10:53:45 --> Security Class Initialized
DEBUG - 2020-02-29 10:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:53:45 --> Input Class Initialized
INFO - 2020-02-29 10:53:45 --> Language Class Initialized
INFO - 2020-02-29 10:53:45 --> Loader Class Initialized
INFO - 2020-02-29 10:53:45 --> Helper loaded: url_helper
INFO - 2020-02-29 10:53:45 --> Helper loaded: string_helper
INFO - 2020-02-29 10:53:45 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:53:45 --> Controller Class Initialized
INFO - 2020-02-29 10:53:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:53:45 --> Pagination Class Initialized
INFO - 2020-02-29 10:53:45 --> Model "M_show" initialized
INFO - 2020-02-29 10:53:45 --> Helper loaded: form_helper
INFO - 2020-02-29 10:53:45 --> Form Validation Class Initialized
INFO - 2020-02-29 10:53:45 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:53:45 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\home.php
INFO - 2020-02-29 10:53:45 --> Final output sent to browser
DEBUG - 2020-02-29 10:53:45 --> Total execution time: 0.2464
INFO - 2020-02-29 10:54:08 --> Config Class Initialized
INFO - 2020-02-29 10:54:09 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:54:09 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:54:09 --> Utf8 Class Initialized
INFO - 2020-02-29 10:54:09 --> URI Class Initialized
INFO - 2020-02-29 10:54:09 --> Router Class Initialized
INFO - 2020-02-29 10:54:09 --> Output Class Initialized
INFO - 2020-02-29 10:54:09 --> Security Class Initialized
DEBUG - 2020-02-29 10:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:54:09 --> Input Class Initialized
INFO - 2020-02-29 10:54:09 --> Language Class Initialized
INFO - 2020-02-29 10:54:09 --> Loader Class Initialized
INFO - 2020-02-29 10:54:09 --> Helper loaded: url_helper
INFO - 2020-02-29 10:54:09 --> Helper loaded: string_helper
INFO - 2020-02-29 10:54:09 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:54:09 --> Controller Class Initialized
INFO - 2020-02-29 10:54:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:54:09 --> Pagination Class Initialized
INFO - 2020-02-29 10:54:09 --> Model "M_show" initialized
INFO - 2020-02-29 10:54:09 --> Helper loaded: form_helper
INFO - 2020-02-29 10:54:09 --> Form Validation Class Initialized
INFO - 2020-02-29 10:54:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:54:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\home.php
INFO - 2020-02-29 10:54:09 --> Final output sent to browser
DEBUG - 2020-02-29 10:54:09 --> Total execution time: 1.0612
INFO - 2020-02-29 10:54:14 --> Config Class Initialized
INFO - 2020-02-29 10:54:14 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:54:14 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:54:14 --> Utf8 Class Initialized
INFO - 2020-02-29 10:54:14 --> URI Class Initialized
INFO - 2020-02-29 10:54:14 --> Router Class Initialized
INFO - 2020-02-29 10:54:14 --> Output Class Initialized
INFO - 2020-02-29 10:54:14 --> Security Class Initialized
DEBUG - 2020-02-29 10:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:54:14 --> Input Class Initialized
INFO - 2020-02-29 10:54:14 --> Language Class Initialized
INFO - 2020-02-29 10:54:14 --> Loader Class Initialized
INFO - 2020-02-29 10:54:14 --> Helper loaded: url_helper
INFO - 2020-02-29 10:54:15 --> Helper loaded: string_helper
INFO - 2020-02-29 10:54:15 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:54:15 --> Controller Class Initialized
INFO - 2020-02-29 10:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:54:15 --> Pagination Class Initialized
INFO - 2020-02-29 10:54:15 --> Model "M_show" initialized
INFO - 2020-02-29 10:54:15 --> Helper loaded: form_helper
INFO - 2020-02-29 10:54:15 --> Form Validation Class Initialized
INFO - 2020-02-29 10:54:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:54:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\home.php
INFO - 2020-02-29 10:54:15 --> Final output sent to browser
DEBUG - 2020-02-29 10:54:15 --> Total execution time: 3.1873
INFO - 2020-02-29 10:57:04 --> Config Class Initialized
INFO - 2020-02-29 10:57:04 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:57:04 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:57:04 --> Utf8 Class Initialized
INFO - 2020-02-29 10:57:04 --> URI Class Initialized
INFO - 2020-02-29 10:57:04 --> Router Class Initialized
INFO - 2020-02-29 10:57:04 --> Output Class Initialized
INFO - 2020-02-29 10:57:04 --> Security Class Initialized
DEBUG - 2020-02-29 10:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:57:04 --> Input Class Initialized
INFO - 2020-02-29 10:57:04 --> Language Class Initialized
INFO - 2020-02-29 10:57:04 --> Loader Class Initialized
INFO - 2020-02-29 10:57:04 --> Helper loaded: url_helper
INFO - 2020-02-29 10:57:04 --> Helper loaded: string_helper
INFO - 2020-02-29 10:57:04 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:57:04 --> Controller Class Initialized
INFO - 2020-02-29 10:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:57:04 --> Pagination Class Initialized
INFO - 2020-02-29 10:57:04 --> Model "M_show" initialized
INFO - 2020-02-29 10:57:05 --> Helper loaded: form_helper
INFO - 2020-02-29 10:57:05 --> Form Validation Class Initialized
INFO - 2020-02-29 10:57:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:57:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\home.php
INFO - 2020-02-29 10:57:05 --> Final output sent to browser
DEBUG - 2020-02-29 10:57:05 --> Total execution time: 0.2366
INFO - 2020-02-29 10:57:11 --> Config Class Initialized
INFO - 2020-02-29 10:57:13 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:57:13 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:57:13 --> Utf8 Class Initialized
INFO - 2020-02-29 10:57:13 --> URI Class Initialized
INFO - 2020-02-29 10:57:13 --> Router Class Initialized
INFO - 2020-02-29 10:57:13 --> Output Class Initialized
INFO - 2020-02-29 10:57:13 --> Security Class Initialized
DEBUG - 2020-02-29 10:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:57:13 --> Input Class Initialized
INFO - 2020-02-29 10:57:13 --> Language Class Initialized
INFO - 2020-02-29 10:57:13 --> Loader Class Initialized
INFO - 2020-02-29 10:57:13 --> Helper loaded: url_helper
INFO - 2020-02-29 10:57:13 --> Helper loaded: string_helper
INFO - 2020-02-29 10:57:13 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:57:13 --> Controller Class Initialized
INFO - 2020-02-29 10:57:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:57:13 --> Pagination Class Initialized
INFO - 2020-02-29 10:57:13 --> Model "M_show" initialized
INFO - 2020-02-29 10:57:13 --> Helper loaded: form_helper
INFO - 2020-02-29 10:57:13 --> Form Validation Class Initialized
INFO - 2020-02-29 10:57:13 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:57:13 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tentang.php
INFO - 2020-02-29 10:57:13 --> Final output sent to browser
DEBUG - 2020-02-29 10:57:13 --> Total execution time: 4.3737
INFO - 2020-02-29 10:57:13 --> Config Class Initialized
INFO - 2020-02-29 10:57:13 --> Config Class Initialized
INFO - 2020-02-29 10:57:13 --> Config Class Initialized
INFO - 2020-02-29 10:57:13 --> Hooks Class Initialized
INFO - 2020-02-29 10:57:13 --> Hooks Class Initialized
INFO - 2020-02-29 10:57:13 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:57:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 10:57:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 10:57:13 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:57:13 --> Utf8 Class Initialized
INFO - 2020-02-29 10:57:13 --> Utf8 Class Initialized
INFO - 2020-02-29 10:57:13 --> Utf8 Class Initialized
INFO - 2020-02-29 10:57:13 --> URI Class Initialized
INFO - 2020-02-29 10:57:13 --> URI Class Initialized
INFO - 2020-02-29 10:57:13 --> URI Class Initialized
INFO - 2020-02-29 10:57:13 --> Router Class Initialized
INFO - 2020-02-29 10:57:13 --> Router Class Initialized
INFO - 2020-02-29 10:57:13 --> Router Class Initialized
INFO - 2020-02-29 10:57:13 --> Output Class Initialized
INFO - 2020-02-29 10:57:13 --> Output Class Initialized
INFO - 2020-02-29 10:57:13 --> Output Class Initialized
INFO - 2020-02-29 10:57:13 --> Security Class Initialized
INFO - 2020-02-29 10:57:13 --> Security Class Initialized
INFO - 2020-02-29 10:57:13 --> Security Class Initialized
DEBUG - 2020-02-29 10:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 10:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 10:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:57:13 --> Input Class Initialized
INFO - 2020-02-29 10:57:13 --> Input Class Initialized
INFO - 2020-02-29 10:57:13 --> Input Class Initialized
INFO - 2020-02-29 10:57:13 --> Language Class Initialized
INFO - 2020-02-29 10:57:13 --> Language Class Initialized
INFO - 2020-02-29 10:57:13 --> Language Class Initialized
ERROR - 2020-02-29 10:57:13 --> 404 Page Not Found: Show/image
ERROR - 2020-02-29 10:57:13 --> 404 Page Not Found: Show/image
ERROR - 2020-02-29 10:57:13 --> 404 Page Not Found: Show/image
INFO - 2020-02-29 10:57:13 --> Config Class Initialized
INFO - 2020-02-29 10:57:13 --> Config Class Initialized
INFO - 2020-02-29 10:57:13 --> Hooks Class Initialized
INFO - 2020-02-29 10:57:13 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:57:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 10:57:13 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:57:13 --> Utf8 Class Initialized
INFO - 2020-02-29 10:57:13 --> Utf8 Class Initialized
INFO - 2020-02-29 10:57:13 --> URI Class Initialized
INFO - 2020-02-29 10:57:13 --> URI Class Initialized
INFO - 2020-02-29 10:57:13 --> Router Class Initialized
INFO - 2020-02-29 10:57:13 --> Router Class Initialized
INFO - 2020-02-29 10:57:13 --> Output Class Initialized
INFO - 2020-02-29 10:57:13 --> Output Class Initialized
INFO - 2020-02-29 10:57:13 --> Security Class Initialized
INFO - 2020-02-29 10:57:13 --> Security Class Initialized
DEBUG - 2020-02-29 10:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 10:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:57:13 --> Input Class Initialized
INFO - 2020-02-29 10:57:13 --> Input Class Initialized
INFO - 2020-02-29 10:57:13 --> Language Class Initialized
INFO - 2020-02-29 10:57:13 --> Language Class Initialized
ERROR - 2020-02-29 10:57:13 --> 404 Page Not Found: Show/image
ERROR - 2020-02-29 10:57:13 --> 404 Page Not Found: Show/image
INFO - 2020-02-29 10:58:44 --> Config Class Initialized
INFO - 2020-02-29 10:58:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 10:58:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 10:58:44 --> Utf8 Class Initialized
INFO - 2020-02-29 10:58:44 --> URI Class Initialized
INFO - 2020-02-29 10:58:44 --> Router Class Initialized
INFO - 2020-02-29 10:58:44 --> Output Class Initialized
INFO - 2020-02-29 10:58:44 --> Security Class Initialized
DEBUG - 2020-02-29 10:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 10:58:44 --> Input Class Initialized
INFO - 2020-02-29 10:58:44 --> Language Class Initialized
INFO - 2020-02-29 10:58:44 --> Loader Class Initialized
INFO - 2020-02-29 10:58:44 --> Helper loaded: url_helper
INFO - 2020-02-29 10:58:44 --> Helper loaded: string_helper
INFO - 2020-02-29 10:58:44 --> Database Driver Class Initialized
DEBUG - 2020-02-29 10:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 10:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 10:58:44 --> Controller Class Initialized
INFO - 2020-02-29 10:58:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 10:58:44 --> Pagination Class Initialized
INFO - 2020-02-29 10:58:44 --> Model "M_show" initialized
INFO - 2020-02-29 10:58:44 --> Helper loaded: form_helper
INFO - 2020-02-29 10:58:44 --> Form Validation Class Initialized
INFO - 2020-02-29 10:58:44 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 10:58:44 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tentang.php
INFO - 2020-02-29 10:58:44 --> Final output sent to browser
DEBUG - 2020-02-29 10:58:44 --> Total execution time: 0.2457
INFO - 2020-02-29 11:05:00 --> Config Class Initialized
INFO - 2020-02-29 11:05:00 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:05:00 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:05:00 --> Utf8 Class Initialized
INFO - 2020-02-29 11:05:00 --> URI Class Initialized
INFO - 2020-02-29 11:05:00 --> Router Class Initialized
INFO - 2020-02-29 11:05:00 --> Output Class Initialized
INFO - 2020-02-29 11:05:00 --> Security Class Initialized
DEBUG - 2020-02-29 11:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:05:00 --> Input Class Initialized
INFO - 2020-02-29 11:05:00 --> Language Class Initialized
INFO - 2020-02-29 11:05:01 --> Loader Class Initialized
INFO - 2020-02-29 11:05:01 --> Helper loaded: url_helper
INFO - 2020-02-29 11:05:01 --> Helper loaded: string_helper
INFO - 2020-02-29 11:05:01 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:05:01 --> Controller Class Initialized
INFO - 2020-02-29 11:05:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:05:01 --> Pagination Class Initialized
INFO - 2020-02-29 11:05:01 --> Model "M_show" initialized
INFO - 2020-02-29 11:05:01 --> Helper loaded: form_helper
INFO - 2020-02-29 11:05:01 --> Form Validation Class Initialized
INFO - 2020-02-29 11:05:01 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:05:01 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tentang.php
INFO - 2020-02-29 11:05:01 --> Final output sent to browser
DEBUG - 2020-02-29 11:05:01 --> Total execution time: 0.2412
INFO - 2020-02-29 11:05:04 --> Config Class Initialized
INFO - 2020-02-29 11:05:04 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:05:04 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:05:04 --> Utf8 Class Initialized
INFO - 2020-02-29 11:05:04 --> URI Class Initialized
INFO - 2020-02-29 11:05:04 --> Router Class Initialized
INFO - 2020-02-29 11:05:04 --> Output Class Initialized
INFO - 2020-02-29 11:05:04 --> Security Class Initialized
DEBUG - 2020-02-29 11:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:05:04 --> Input Class Initialized
INFO - 2020-02-29 11:05:04 --> Language Class Initialized
INFO - 2020-02-29 11:05:04 --> Loader Class Initialized
INFO - 2020-02-29 11:05:04 --> Helper loaded: url_helper
INFO - 2020-02-29 11:05:04 --> Helper loaded: string_helper
INFO - 2020-02-29 11:05:04 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:05:04 --> Controller Class Initialized
INFO - 2020-02-29 11:05:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:05:04 --> Pagination Class Initialized
INFO - 2020-02-29 11:05:04 --> Model "M_show" initialized
INFO - 2020-02-29 11:05:04 --> Helper loaded: form_helper
INFO - 2020-02-29 11:05:04 --> Form Validation Class Initialized
INFO - 2020-02-29 11:05:04 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:05:04 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\vol1.php
INFO - 2020-02-29 11:05:04 --> Final output sent to browser
DEBUG - 2020-02-29 11:05:04 --> Total execution time: 0.2554
INFO - 2020-02-29 11:08:17 --> Config Class Initialized
INFO - 2020-02-29 11:08:17 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:08:17 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:08:17 --> Utf8 Class Initialized
INFO - 2020-02-29 11:08:17 --> URI Class Initialized
INFO - 2020-02-29 11:08:17 --> Router Class Initialized
INFO - 2020-02-29 11:08:17 --> Output Class Initialized
INFO - 2020-02-29 11:08:17 --> Security Class Initialized
DEBUG - 2020-02-29 11:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:08:17 --> Input Class Initialized
INFO - 2020-02-29 11:08:17 --> Language Class Initialized
INFO - 2020-02-29 11:08:17 --> Loader Class Initialized
INFO - 2020-02-29 11:08:17 --> Helper loaded: url_helper
INFO - 2020-02-29 11:08:17 --> Helper loaded: string_helper
INFO - 2020-02-29 11:08:17 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:08:17 --> Controller Class Initialized
INFO - 2020-02-29 11:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:08:17 --> Pagination Class Initialized
INFO - 2020-02-29 11:08:17 --> Model "M_show" initialized
INFO - 2020-02-29 11:08:17 --> Helper loaded: form_helper
INFO - 2020-02-29 11:08:17 --> Form Validation Class Initialized
INFO - 2020-02-29 11:08:17 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:08:17 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\vol1.php
INFO - 2020-02-29 11:08:17 --> Final output sent to browser
DEBUG - 2020-02-29 11:08:17 --> Total execution time: 0.2462
INFO - 2020-02-29 11:08:22 --> Config Class Initialized
INFO - 2020-02-29 11:08:22 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:08:22 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:08:22 --> Utf8 Class Initialized
INFO - 2020-02-29 11:08:22 --> URI Class Initialized
INFO - 2020-02-29 11:08:22 --> Router Class Initialized
INFO - 2020-02-29 11:08:22 --> Output Class Initialized
INFO - 2020-02-29 11:08:22 --> Security Class Initialized
DEBUG - 2020-02-29 11:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:08:22 --> Input Class Initialized
INFO - 2020-02-29 11:08:22 --> Language Class Initialized
INFO - 2020-02-29 11:08:22 --> Loader Class Initialized
INFO - 2020-02-29 11:08:22 --> Helper loaded: url_helper
INFO - 2020-02-29 11:08:22 --> Helper loaded: string_helper
INFO - 2020-02-29 11:08:22 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:08:22 --> Controller Class Initialized
INFO - 2020-02-29 11:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:08:22 --> Pagination Class Initialized
INFO - 2020-02-29 11:08:22 --> Model "M_show" initialized
INFO - 2020-02-29 11:08:22 --> Helper loaded: form_helper
INFO - 2020-02-29 11:08:22 --> Form Validation Class Initialized
INFO - 2020-02-29 11:08:22 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:08:22 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\vol2.php
INFO - 2020-02-29 11:08:22 --> Final output sent to browser
DEBUG - 2020-02-29 11:08:22 --> Total execution time: 0.3375
INFO - 2020-02-29 11:09:26 --> Config Class Initialized
INFO - 2020-02-29 11:09:26 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:09:26 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:09:26 --> Utf8 Class Initialized
INFO - 2020-02-29 11:09:26 --> URI Class Initialized
INFO - 2020-02-29 11:09:26 --> Router Class Initialized
INFO - 2020-02-29 11:09:26 --> Output Class Initialized
INFO - 2020-02-29 11:09:26 --> Security Class Initialized
DEBUG - 2020-02-29 11:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:09:26 --> Input Class Initialized
INFO - 2020-02-29 11:09:26 --> Language Class Initialized
INFO - 2020-02-29 11:09:26 --> Loader Class Initialized
INFO - 2020-02-29 11:09:26 --> Helper loaded: url_helper
INFO - 2020-02-29 11:09:26 --> Helper loaded: string_helper
INFO - 2020-02-29 11:09:26 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:09:26 --> Controller Class Initialized
INFO - 2020-02-29 11:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:09:26 --> Pagination Class Initialized
INFO - 2020-02-29 11:09:26 --> Model "M_show" initialized
INFO - 2020-02-29 11:09:26 --> Helper loaded: form_helper
INFO - 2020-02-29 11:09:26 --> Form Validation Class Initialized
INFO - 2020-02-29 11:09:26 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:09:26 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\vol2.php
INFO - 2020-02-29 11:09:26 --> Final output sent to browser
DEBUG - 2020-02-29 11:09:26 --> Total execution time: 0.2526
INFO - 2020-02-29 11:09:30 --> Config Class Initialized
INFO - 2020-02-29 11:09:30 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:09:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:09:30 --> Utf8 Class Initialized
INFO - 2020-02-29 11:09:30 --> URI Class Initialized
INFO - 2020-02-29 11:09:30 --> Router Class Initialized
INFO - 2020-02-29 11:09:30 --> Output Class Initialized
INFO - 2020-02-29 11:09:30 --> Security Class Initialized
DEBUG - 2020-02-29 11:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:09:30 --> Input Class Initialized
INFO - 2020-02-29 11:09:30 --> Language Class Initialized
INFO - 2020-02-29 11:09:30 --> Loader Class Initialized
INFO - 2020-02-29 11:09:30 --> Helper loaded: url_helper
INFO - 2020-02-29 11:09:30 --> Helper loaded: string_helper
INFO - 2020-02-29 11:09:30 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:09:30 --> Controller Class Initialized
INFO - 2020-02-29 11:09:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:09:30 --> Pagination Class Initialized
INFO - 2020-02-29 11:09:30 --> Model "M_show" initialized
INFO - 2020-02-29 11:09:30 --> Helper loaded: form_helper
INFO - 2020-02-29 11:09:30 --> Form Validation Class Initialized
INFO - 2020-02-29 11:09:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:09:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\vol1.php
INFO - 2020-02-29 11:09:30 --> Final output sent to browser
DEBUG - 2020-02-29 11:09:30 --> Total execution time: 0.2419
INFO - 2020-02-29 11:09:38 --> Config Class Initialized
INFO - 2020-02-29 11:09:38 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:09:38 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:09:38 --> Utf8 Class Initialized
INFO - 2020-02-29 11:09:38 --> URI Class Initialized
INFO - 2020-02-29 11:09:38 --> Router Class Initialized
INFO - 2020-02-29 11:09:38 --> Output Class Initialized
INFO - 2020-02-29 11:09:38 --> Security Class Initialized
DEBUG - 2020-02-29 11:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:09:38 --> Input Class Initialized
INFO - 2020-02-29 11:09:38 --> Language Class Initialized
INFO - 2020-02-29 11:09:38 --> Loader Class Initialized
INFO - 2020-02-29 11:09:38 --> Helper loaded: url_helper
INFO - 2020-02-29 11:09:38 --> Helper loaded: string_helper
INFO - 2020-02-29 11:09:38 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:09:39 --> Controller Class Initialized
INFO - 2020-02-29 11:09:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:09:39 --> Pagination Class Initialized
INFO - 2020-02-29 11:09:39 --> Model "M_show" initialized
INFO - 2020-02-29 11:09:39 --> Helper loaded: form_helper
INFO - 2020-02-29 11:09:39 --> Form Validation Class Initialized
INFO - 2020-02-29 11:09:39 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:09:39 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\home.php
INFO - 2020-02-29 11:09:39 --> Final output sent to browser
DEBUG - 2020-02-29 11:09:39 --> Total execution time: 0.2401
INFO - 2020-02-29 11:09:52 --> Config Class Initialized
INFO - 2020-02-29 11:09:52 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:09:52 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:09:52 --> Utf8 Class Initialized
INFO - 2020-02-29 11:09:52 --> URI Class Initialized
INFO - 2020-02-29 11:09:52 --> Router Class Initialized
INFO - 2020-02-29 11:09:52 --> Output Class Initialized
INFO - 2020-02-29 11:09:52 --> Security Class Initialized
DEBUG - 2020-02-29 11:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:09:52 --> Input Class Initialized
INFO - 2020-02-29 11:09:52 --> Language Class Initialized
INFO - 2020-02-29 11:09:52 --> Loader Class Initialized
INFO - 2020-02-29 11:09:52 --> Helper loaded: url_helper
INFO - 2020-02-29 11:09:52 --> Helper loaded: string_helper
INFO - 2020-02-29 11:09:52 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:09:52 --> Controller Class Initialized
INFO - 2020-02-29 11:09:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:09:52 --> Pagination Class Initialized
INFO - 2020-02-29 11:09:52 --> Model "M_show" initialized
INFO - 2020-02-29 11:09:52 --> Helper loaded: form_helper
INFO - 2020-02-29 11:09:52 --> Form Validation Class Initialized
INFO - 2020-02-29 11:09:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:09:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tentang.php
INFO - 2020-02-29 11:09:52 --> Final output sent to browser
DEBUG - 2020-02-29 11:09:52 --> Total execution time: 0.2399
INFO - 2020-02-29 11:09:57 --> Config Class Initialized
INFO - 2020-02-29 11:09:57 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:09:57 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:09:57 --> Utf8 Class Initialized
INFO - 2020-02-29 11:09:57 --> URI Class Initialized
INFO - 2020-02-29 11:09:57 --> Router Class Initialized
INFO - 2020-02-29 11:09:57 --> Output Class Initialized
INFO - 2020-02-29 11:09:57 --> Security Class Initialized
DEBUG - 2020-02-29 11:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:09:57 --> Input Class Initialized
INFO - 2020-02-29 11:09:57 --> Language Class Initialized
INFO - 2020-02-29 11:09:57 --> Loader Class Initialized
INFO - 2020-02-29 11:09:57 --> Helper loaded: url_helper
INFO - 2020-02-29 11:09:57 --> Helper loaded: string_helper
INFO - 2020-02-29 11:09:57 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:09:57 --> Controller Class Initialized
INFO - 2020-02-29 11:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:09:57 --> Pagination Class Initialized
INFO - 2020-02-29 11:09:57 --> Model "M_show" initialized
INFO - 2020-02-29 11:09:57 --> Helper loaded: form_helper
INFO - 2020-02-29 11:09:57 --> Form Validation Class Initialized
INFO - 2020-02-29 11:09:57 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:09:57 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\vol1.php
INFO - 2020-02-29 11:09:57 --> Final output sent to browser
DEBUG - 2020-02-29 11:09:57 --> Total execution time: 0.2500
INFO - 2020-02-29 11:13:42 --> Config Class Initialized
INFO - 2020-02-29 11:13:42 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:13:42 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:13:42 --> Utf8 Class Initialized
INFO - 2020-02-29 11:13:42 --> URI Class Initialized
INFO - 2020-02-29 11:13:42 --> Router Class Initialized
INFO - 2020-02-29 11:13:43 --> Output Class Initialized
INFO - 2020-02-29 11:13:43 --> Security Class Initialized
DEBUG - 2020-02-29 11:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:13:43 --> Input Class Initialized
INFO - 2020-02-29 11:13:43 --> Language Class Initialized
INFO - 2020-02-29 11:13:43 --> Loader Class Initialized
INFO - 2020-02-29 11:13:43 --> Helper loaded: url_helper
INFO - 2020-02-29 11:13:43 --> Helper loaded: string_helper
INFO - 2020-02-29 11:13:43 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:13:43 --> Controller Class Initialized
INFO - 2020-02-29 11:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:13:43 --> Pagination Class Initialized
INFO - 2020-02-29 11:13:43 --> Model "M_show" initialized
INFO - 2020-02-29 11:13:43 --> Helper loaded: form_helper
INFO - 2020-02-29 11:13:43 --> Form Validation Class Initialized
INFO - 2020-02-29 11:13:43 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:13:43 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\vol2.php
INFO - 2020-02-29 11:13:43 --> Final output sent to browser
DEBUG - 2020-02-29 11:13:43 --> Total execution time: 0.2778
INFO - 2020-02-29 11:13:45 --> Config Class Initialized
INFO - 2020-02-29 11:13:45 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:13:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:13:45 --> Utf8 Class Initialized
INFO - 2020-02-29 11:13:45 --> URI Class Initialized
INFO - 2020-02-29 11:13:45 --> Router Class Initialized
INFO - 2020-02-29 11:13:45 --> Output Class Initialized
INFO - 2020-02-29 11:13:45 --> Security Class Initialized
DEBUG - 2020-02-29 11:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:13:45 --> Input Class Initialized
INFO - 2020-02-29 11:13:45 --> Language Class Initialized
INFO - 2020-02-29 11:13:45 --> Loader Class Initialized
INFO - 2020-02-29 11:13:45 --> Helper loaded: url_helper
INFO - 2020-02-29 11:13:45 --> Helper loaded: string_helper
INFO - 2020-02-29 11:13:45 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:13:45 --> Controller Class Initialized
INFO - 2020-02-29 11:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:13:45 --> Pagination Class Initialized
INFO - 2020-02-29 11:13:45 --> Model "M_show" initialized
INFO - 2020-02-29 11:13:45 --> Helper loaded: form_helper
INFO - 2020-02-29 11:13:45 --> Form Validation Class Initialized
INFO - 2020-02-29 11:13:45 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:13:45 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\gal.php
INFO - 2020-02-29 11:13:45 --> Final output sent to browser
DEBUG - 2020-02-29 11:13:45 --> Total execution time: 0.2682
INFO - 2020-02-29 11:14:41 --> Config Class Initialized
INFO - 2020-02-29 11:14:41 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:14:41 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:14:41 --> Utf8 Class Initialized
INFO - 2020-02-29 11:14:41 --> URI Class Initialized
INFO - 2020-02-29 11:14:41 --> Router Class Initialized
INFO - 2020-02-29 11:14:41 --> Output Class Initialized
INFO - 2020-02-29 11:14:41 --> Security Class Initialized
DEBUG - 2020-02-29 11:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:14:41 --> Input Class Initialized
INFO - 2020-02-29 11:14:41 --> Language Class Initialized
INFO - 2020-02-29 11:14:41 --> Loader Class Initialized
INFO - 2020-02-29 11:14:41 --> Helper loaded: url_helper
INFO - 2020-02-29 11:14:41 --> Helper loaded: string_helper
INFO - 2020-02-29 11:14:41 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:14:41 --> Controller Class Initialized
INFO - 2020-02-29 11:14:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:14:41 --> Pagination Class Initialized
INFO - 2020-02-29 11:14:41 --> Model "M_show" initialized
INFO - 2020-02-29 11:14:41 --> Helper loaded: form_helper
INFO - 2020-02-29 11:14:41 --> Form Validation Class Initialized
INFO - 2020-02-29 11:14:41 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:14:41 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\gal.php
INFO - 2020-02-29 11:14:41 --> Final output sent to browser
DEBUG - 2020-02-29 11:14:41 --> Total execution time: 0.2447
INFO - 2020-02-29 11:15:35 --> Config Class Initialized
INFO - 2020-02-29 11:15:35 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:15:35 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:15:35 --> Utf8 Class Initialized
INFO - 2020-02-29 11:15:35 --> URI Class Initialized
INFO - 2020-02-29 11:15:35 --> Router Class Initialized
INFO - 2020-02-29 11:15:35 --> Output Class Initialized
INFO - 2020-02-29 11:15:35 --> Security Class Initialized
DEBUG - 2020-02-29 11:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:15:35 --> Input Class Initialized
INFO - 2020-02-29 11:15:35 --> Language Class Initialized
ERROR - 2020-02-29 11:15:35 --> 404 Page Not Found: Show/index.html
INFO - 2020-02-29 11:15:36 --> Config Class Initialized
INFO - 2020-02-29 11:15:36 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:15:36 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:15:36 --> Utf8 Class Initialized
INFO - 2020-02-29 11:15:36 --> URI Class Initialized
INFO - 2020-02-29 11:15:36 --> Router Class Initialized
INFO - 2020-02-29 11:15:36 --> Output Class Initialized
INFO - 2020-02-29 11:15:36 --> Security Class Initialized
DEBUG - 2020-02-29 11:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:15:36 --> Input Class Initialized
INFO - 2020-02-29 11:15:36 --> Language Class Initialized
INFO - 2020-02-29 11:15:36 --> Loader Class Initialized
INFO - 2020-02-29 11:15:36 --> Helper loaded: url_helper
INFO - 2020-02-29 11:15:36 --> Helper loaded: string_helper
INFO - 2020-02-29 11:15:36 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:15:36 --> Controller Class Initialized
INFO - 2020-02-29 11:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:15:36 --> Pagination Class Initialized
INFO - 2020-02-29 11:15:36 --> Model "M_show" initialized
INFO - 2020-02-29 11:15:36 --> Helper loaded: form_helper
INFO - 2020-02-29 11:15:36 --> Form Validation Class Initialized
INFO - 2020-02-29 11:15:36 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:15:36 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\gal.php
INFO - 2020-02-29 11:15:36 --> Final output sent to browser
DEBUG - 2020-02-29 11:15:36 --> Total execution time: 0.2468
INFO - 2020-02-29 11:15:39 --> Config Class Initialized
INFO - 2020-02-29 11:15:39 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:15:39 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:15:39 --> Utf8 Class Initialized
INFO - 2020-02-29 11:15:39 --> URI Class Initialized
INFO - 2020-02-29 11:15:39 --> Router Class Initialized
INFO - 2020-02-29 11:15:39 --> Output Class Initialized
INFO - 2020-02-29 11:15:39 --> Security Class Initialized
DEBUG - 2020-02-29 11:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:15:39 --> Input Class Initialized
INFO - 2020-02-29 11:15:39 --> Language Class Initialized
INFO - 2020-02-29 11:15:39 --> Loader Class Initialized
INFO - 2020-02-29 11:15:39 --> Helper loaded: url_helper
INFO - 2020-02-29 11:15:39 --> Helper loaded: string_helper
INFO - 2020-02-29 11:15:39 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:15:39 --> Controller Class Initialized
INFO - 2020-02-29 11:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:15:39 --> Pagination Class Initialized
INFO - 2020-02-29 11:15:39 --> Model "M_show" initialized
INFO - 2020-02-29 11:15:39 --> Helper loaded: form_helper
INFO - 2020-02-29 11:15:39 --> Form Validation Class Initialized
INFO - 2020-02-29 11:15:39 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:15:39 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\gal.php
INFO - 2020-02-29 11:15:39 --> Final output sent to browser
DEBUG - 2020-02-29 11:15:39 --> Total execution time: 0.2663
INFO - 2020-02-29 11:15:43 --> Config Class Initialized
INFO - 2020-02-29 11:15:43 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:15:43 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:15:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:15:43 --> URI Class Initialized
INFO - 2020-02-29 11:15:43 --> Router Class Initialized
INFO - 2020-02-29 11:15:43 --> Output Class Initialized
INFO - 2020-02-29 11:15:43 --> Security Class Initialized
DEBUG - 2020-02-29 11:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:15:43 --> Input Class Initialized
INFO - 2020-02-29 11:15:43 --> Language Class Initialized
INFO - 2020-02-29 11:15:43 --> Loader Class Initialized
INFO - 2020-02-29 11:15:43 --> Helper loaded: url_helper
INFO - 2020-02-29 11:15:43 --> Helper loaded: string_helper
INFO - 2020-02-29 11:15:43 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:15:43 --> Controller Class Initialized
INFO - 2020-02-29 11:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:15:43 --> Pagination Class Initialized
INFO - 2020-02-29 11:15:43 --> Model "M_show" initialized
INFO - 2020-02-29 11:15:43 --> Helper loaded: form_helper
INFO - 2020-02-29 11:15:43 --> Form Validation Class Initialized
INFO - 2020-02-29 11:15:43 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:15:43 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\hub.php
INFO - 2020-02-29 11:15:43 --> Final output sent to browser
DEBUG - 2020-02-29 11:15:43 --> Total execution time: 0.2807
INFO - 2020-02-29 11:15:47 --> Config Class Initialized
INFO - 2020-02-29 11:15:47 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:15:47 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:15:47 --> Utf8 Class Initialized
INFO - 2020-02-29 11:15:47 --> URI Class Initialized
INFO - 2020-02-29 11:15:47 --> Router Class Initialized
INFO - 2020-02-29 11:15:47 --> Output Class Initialized
INFO - 2020-02-29 11:15:47 --> Security Class Initialized
DEBUG - 2020-02-29 11:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:15:47 --> Input Class Initialized
INFO - 2020-02-29 11:15:47 --> Language Class Initialized
ERROR - 2020-02-29 11:15:47 --> 404 Page Not Found: Show/index.html
INFO - 2020-02-29 11:15:49 --> Config Class Initialized
INFO - 2020-02-29 11:15:49 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:15:49 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:15:49 --> Utf8 Class Initialized
INFO - 2020-02-29 11:15:49 --> URI Class Initialized
INFO - 2020-02-29 11:15:49 --> Router Class Initialized
INFO - 2020-02-29 11:15:49 --> Output Class Initialized
INFO - 2020-02-29 11:15:49 --> Security Class Initialized
DEBUG - 2020-02-29 11:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:15:49 --> Input Class Initialized
INFO - 2020-02-29 11:15:49 --> Language Class Initialized
INFO - 2020-02-29 11:15:49 --> Loader Class Initialized
INFO - 2020-02-29 11:15:49 --> Helper loaded: url_helper
INFO - 2020-02-29 11:15:49 --> Helper loaded: string_helper
INFO - 2020-02-29 11:15:49 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:15:49 --> Controller Class Initialized
INFO - 2020-02-29 11:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:15:49 --> Pagination Class Initialized
INFO - 2020-02-29 11:15:49 --> Model "M_show" initialized
INFO - 2020-02-29 11:15:49 --> Helper loaded: form_helper
INFO - 2020-02-29 11:15:49 --> Form Validation Class Initialized
INFO - 2020-02-29 11:15:49 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:15:49 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\hub.php
INFO - 2020-02-29 11:15:49 --> Final output sent to browser
DEBUG - 2020-02-29 11:15:49 --> Total execution time: 0.2558
INFO - 2020-02-29 11:15:52 --> Config Class Initialized
INFO - 2020-02-29 11:15:52 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:15:52 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:15:52 --> Utf8 Class Initialized
INFO - 2020-02-29 11:15:52 --> URI Class Initialized
INFO - 2020-02-29 11:15:52 --> Router Class Initialized
INFO - 2020-02-29 11:15:52 --> Output Class Initialized
INFO - 2020-02-29 11:15:52 --> Security Class Initialized
DEBUG - 2020-02-29 11:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:15:52 --> Input Class Initialized
INFO - 2020-02-29 11:15:52 --> Language Class Initialized
INFO - 2020-02-29 11:15:52 --> Loader Class Initialized
INFO - 2020-02-29 11:15:52 --> Helper loaded: url_helper
INFO - 2020-02-29 11:15:52 --> Helper loaded: string_helper
INFO - 2020-02-29 11:15:52 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:15:52 --> Controller Class Initialized
INFO - 2020-02-29 11:15:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:15:52 --> Pagination Class Initialized
INFO - 2020-02-29 11:15:52 --> Model "M_show" initialized
INFO - 2020-02-29 11:15:52 --> Helper loaded: form_helper
INFO - 2020-02-29 11:15:52 --> Form Validation Class Initialized
INFO - 2020-02-29 11:15:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:15:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\home.php
INFO - 2020-02-29 11:15:52 --> Final output sent to browser
DEBUG - 2020-02-29 11:15:52 --> Total execution time: 0.2502
INFO - 2020-02-29 11:29:20 --> Config Class Initialized
INFO - 2020-02-29 11:29:20 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:29:20 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:29:20 --> Utf8 Class Initialized
INFO - 2020-02-29 11:29:20 --> URI Class Initialized
INFO - 2020-02-29 11:29:20 --> Router Class Initialized
INFO - 2020-02-29 11:29:20 --> Output Class Initialized
INFO - 2020-02-29 11:29:20 --> Security Class Initialized
DEBUG - 2020-02-29 11:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:29:20 --> Input Class Initialized
INFO - 2020-02-29 11:29:20 --> Language Class Initialized
INFO - 2020-02-29 11:29:20 --> Loader Class Initialized
INFO - 2020-02-29 11:29:20 --> Helper loaded: url_helper
INFO - 2020-02-29 11:29:20 --> Helper loaded: string_helper
INFO - 2020-02-29 11:29:20 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:29:20 --> Controller Class Initialized
INFO - 2020-02-29 11:29:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:29:20 --> Pagination Class Initialized
INFO - 2020-02-29 11:29:20 --> Model "M_show" initialized
INFO - 2020-02-29 11:29:20 --> Helper loaded: form_helper
INFO - 2020-02-29 11:29:20 --> Form Validation Class Initialized
INFO - 2020-02-29 11:29:20 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:29:20 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\home.php
INFO - 2020-02-29 11:29:20 --> Final output sent to browser
DEBUG - 2020-02-29 11:29:20 --> Total execution time: 0.3084
INFO - 2020-02-29 11:29:26 --> Config Class Initialized
INFO - 2020-02-29 11:29:26 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:29:26 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:29:26 --> Utf8 Class Initialized
INFO - 2020-02-29 11:29:26 --> URI Class Initialized
INFO - 2020-02-29 11:29:26 --> Router Class Initialized
INFO - 2020-02-29 11:29:26 --> Output Class Initialized
INFO - 2020-02-29 11:29:26 --> Security Class Initialized
DEBUG - 2020-02-29 11:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:29:26 --> Input Class Initialized
INFO - 2020-02-29 11:29:26 --> Language Class Initialized
INFO - 2020-02-29 11:29:26 --> Loader Class Initialized
INFO - 2020-02-29 11:29:26 --> Helper loaded: url_helper
INFO - 2020-02-29 11:29:26 --> Helper loaded: string_helper
INFO - 2020-02-29 11:29:26 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:29:26 --> Controller Class Initialized
INFO - 2020-02-29 11:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:29:26 --> Pagination Class Initialized
INFO - 2020-02-29 11:29:26 --> Model "M_show" initialized
INFO - 2020-02-29 11:29:26 --> Helper loaded: form_helper
INFO - 2020-02-29 11:29:26 --> Form Validation Class Initialized
INFO - 2020-02-29 11:29:26 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:29:26 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\beli.php
INFO - 2020-02-29 11:29:26 --> Final output sent to browser
DEBUG - 2020-02-29 11:29:26 --> Total execution time: 1.4473
INFO - 2020-02-29 11:29:51 --> Config Class Initialized
INFO - 2020-02-29 11:29:51 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:29:52 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:29:52 --> Utf8 Class Initialized
INFO - 2020-02-29 11:29:52 --> URI Class Initialized
INFO - 2020-02-29 11:29:52 --> Router Class Initialized
INFO - 2020-02-29 11:29:52 --> Output Class Initialized
INFO - 2020-02-29 11:29:52 --> Security Class Initialized
DEBUG - 2020-02-29 11:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:29:52 --> Input Class Initialized
INFO - 2020-02-29 11:29:52 --> Language Class Initialized
INFO - 2020-02-29 11:29:52 --> Loader Class Initialized
INFO - 2020-02-29 11:29:52 --> Helper loaded: url_helper
INFO - 2020-02-29 11:29:52 --> Helper loaded: string_helper
INFO - 2020-02-29 11:29:52 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:29:52 --> Controller Class Initialized
INFO - 2020-02-29 11:29:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:29:52 --> Pagination Class Initialized
INFO - 2020-02-29 11:29:52 --> Model "M_show" initialized
INFO - 2020-02-29 11:29:52 --> Helper loaded: form_helper
INFO - 2020-02-29 11:29:52 --> Form Validation Class Initialized
INFO - 2020-02-29 11:29:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:29:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\beli.php
INFO - 2020-02-29 11:29:52 --> Final output sent to browser
DEBUG - 2020-02-29 11:29:52 --> Total execution time: 0.2966
INFO - 2020-02-29 11:30:05 --> Config Class Initialized
INFO - 2020-02-29 11:30:05 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:30:05 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:05 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:05 --> URI Class Initialized
INFO - 2020-02-29 11:30:05 --> Router Class Initialized
INFO - 2020-02-29 11:30:05 --> Output Class Initialized
INFO - 2020-02-29 11:30:05 --> Security Class Initialized
DEBUG - 2020-02-29 11:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:05 --> Input Class Initialized
INFO - 2020-02-29 11:30:05 --> Language Class Initialized
INFO - 2020-02-29 11:30:05 --> Loader Class Initialized
INFO - 2020-02-29 11:30:05 --> Helper loaded: url_helper
INFO - 2020-02-29 11:30:05 --> Helper loaded: string_helper
INFO - 2020-02-29 11:30:05 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:30:05 --> Controller Class Initialized
INFO - 2020-02-29 11:30:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:30:05 --> Pagination Class Initialized
INFO - 2020-02-29 11:30:05 --> Model "M_show" initialized
INFO - 2020-02-29 11:30:05 --> Helper loaded: form_helper
INFO - 2020-02-29 11:30:05 --> Form Validation Class Initialized
INFO - 2020-02-29 11:30:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:30:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\beli.php
INFO - 2020-02-29 11:30:06 --> Final output sent to browser
DEBUG - 2020-02-29 11:30:06 --> Total execution time: 0.4427
INFO - 2020-02-29 11:30:26 --> Config Class Initialized
INFO - 2020-02-29 11:30:26 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:30:26 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:26 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:26 --> URI Class Initialized
INFO - 2020-02-29 11:30:26 --> Router Class Initialized
INFO - 2020-02-29 11:30:26 --> Output Class Initialized
INFO - 2020-02-29 11:30:26 --> Security Class Initialized
DEBUG - 2020-02-29 11:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:26 --> Input Class Initialized
INFO - 2020-02-29 11:30:26 --> Language Class Initialized
INFO - 2020-02-29 11:30:26 --> Loader Class Initialized
INFO - 2020-02-29 11:30:26 --> Helper loaded: url_helper
INFO - 2020-02-29 11:30:26 --> Helper loaded: string_helper
INFO - 2020-02-29 11:30:26 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:30:26 --> Controller Class Initialized
INFO - 2020-02-29 11:30:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:30:26 --> Pagination Class Initialized
INFO - 2020-02-29 11:30:26 --> Model "M_show" initialized
INFO - 2020-02-29 11:30:26 --> Helper loaded: form_helper
INFO - 2020-02-29 11:30:26 --> Form Validation Class Initialized
INFO - 2020-02-29 11:30:26 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:30:26 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\beli.php
INFO - 2020-02-29 11:30:26 --> Final output sent to browser
DEBUG - 2020-02-29 11:30:26 --> Total execution time: 0.2698
INFO - 2020-02-29 11:30:28 --> Config Class Initialized
INFO - 2020-02-29 11:30:28 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:30:28 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:28 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:28 --> URI Class Initialized
INFO - 2020-02-29 11:30:28 --> Router Class Initialized
INFO - 2020-02-29 11:30:28 --> Output Class Initialized
INFO - 2020-02-29 11:30:28 --> Security Class Initialized
DEBUG - 2020-02-29 11:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:28 --> Input Class Initialized
INFO - 2020-02-29 11:30:28 --> Language Class Initialized
INFO - 2020-02-29 11:30:28 --> Loader Class Initialized
INFO - 2020-02-29 11:30:28 --> Helper loaded: url_helper
INFO - 2020-02-29 11:30:28 --> Helper loaded: string_helper
INFO - 2020-02-29 11:30:28 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:30:28 --> Controller Class Initialized
INFO - 2020-02-29 11:30:28 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:30:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:30:29 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:30:29 --> Helper loaded: form_helper
INFO - 2020-02-29 11:30:29 --> Form Validation Class Initialized
INFO - 2020-02-29 11:30:29 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:30:29 --> Final output sent to browser
DEBUG - 2020-02-29 11:30:29 --> Total execution time: 1.3902
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
ERROR - 2020-02-29 11:30:29 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:30:29 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-29 11:30:29 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-29 11:30:29 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-29 11:30:29 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 11:30:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
ERROR - 2020-02-29 11:30:29 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-29 11:30:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-29 11:30:29 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:30:29 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-29 11:30:29 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 11:30:29 --> Loader Class Initialized
INFO - 2020-02-29 11:30:29 --> Helper loaded: url_helper
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:30:29 --> Helper loaded: string_helper
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:29 --> Database Driver Class Initialized
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
DEBUG - 2020-02-29 11:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Controller Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
INFO - 2020-02-29 11:30:29 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
INFO - 2020-02-29 11:30:29 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
INFO - 2020-02-29 11:30:29 --> Helper loaded: form_helper
INFO - 2020-02-29 11:30:29 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:30:29 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-29 11:30:29 --> Loader Class Initialized
INFO - 2020-02-29 11:30:29 --> Helper loaded: url_helper
ERROR - 2020-02-29 11:30:29 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:30:29 --> Helper loaded: string_helper
ERROR - 2020-02-29 11:30:29 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:30:29 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-29 11:30:29 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:29 --> Database Driver Class Initialized
INFO - 2020-02-29 11:30:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:29 --> Final output sent to browser
DEBUG - 2020-02-29 11:30:29 --> Total execution time: 0.2716
INFO - 2020-02-29 11:30:29 --> URI Class Initialized
DEBUG - 2020-02-29 11:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:30:29 --> Router Class Initialized
INFO - 2020-02-29 11:30:29 --> Controller Class Initialized
INFO - 2020-02-29 11:30:29 --> Output Class Initialized
INFO - 2020-02-29 11:30:29 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:30:29 --> Security Class Initialized
INFO - 2020-02-29 11:30:29 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 11:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:29 --> Input Class Initialized
INFO - 2020-02-29 11:30:29 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:30:29 --> Language Class Initialized
INFO - 2020-02-29 11:30:29 --> Helper loaded: form_helper
INFO - 2020-02-29 11:30:29 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:30:29 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 11:30:29 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 11:30:29 --> Config Class Initialized
INFO - 2020-02-29 11:30:29 --> Hooks Class Initialized
ERROR - 2020-02-29 11:30:29 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:30:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-29 11:30:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:30 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:30 --> Final output sent to browser
DEBUG - 2020-02-29 11:30:30 --> Total execution time: 0.2571
INFO - 2020-02-29 11:30:30 --> URI Class Initialized
INFO - 2020-02-29 11:30:30 --> Router Class Initialized
INFO - 2020-02-29 11:30:30 --> Output Class Initialized
INFO - 2020-02-29 11:30:30 --> Security Class Initialized
DEBUG - 2020-02-29 11:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:30 --> Input Class Initialized
INFO - 2020-02-29 11:30:30 --> Language Class Initialized
ERROR - 2020-02-29 11:30:30 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 11:30:30 --> Config Class Initialized
INFO - 2020-02-29 11:30:30 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:30:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:30 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:30 --> URI Class Initialized
INFO - 2020-02-29 11:30:30 --> Router Class Initialized
INFO - 2020-02-29 11:30:30 --> Output Class Initialized
INFO - 2020-02-29 11:30:30 --> Security Class Initialized
DEBUG - 2020-02-29 11:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:30 --> Input Class Initialized
INFO - 2020-02-29 11:30:30 --> Language Class Initialized
ERROR - 2020-02-29 11:30:30 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 11:30:30 --> Config Class Initialized
INFO - 2020-02-29 11:30:30 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:30:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:30 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:30 --> URI Class Initialized
INFO - 2020-02-29 11:30:30 --> Router Class Initialized
INFO - 2020-02-29 11:30:30 --> Output Class Initialized
INFO - 2020-02-29 11:30:30 --> Security Class Initialized
DEBUG - 2020-02-29 11:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:30 --> Input Class Initialized
INFO - 2020-02-29 11:30:30 --> Language Class Initialized
ERROR - 2020-02-29 11:30:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:30:30 --> Config Class Initialized
INFO - 2020-02-29 11:30:30 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:30:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:30 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:30 --> URI Class Initialized
INFO - 2020-02-29 11:30:30 --> Router Class Initialized
INFO - 2020-02-29 11:30:30 --> Output Class Initialized
INFO - 2020-02-29 11:30:30 --> Security Class Initialized
DEBUG - 2020-02-29 11:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:30 --> Input Class Initialized
INFO - 2020-02-29 11:30:30 --> Language Class Initialized
ERROR - 2020-02-29 11:30:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:30:30 --> Config Class Initialized
INFO - 2020-02-29 11:30:30 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:30:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:30 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:30 --> URI Class Initialized
INFO - 2020-02-29 11:30:30 --> Router Class Initialized
INFO - 2020-02-29 11:30:30 --> Output Class Initialized
INFO - 2020-02-29 11:30:30 --> Security Class Initialized
DEBUG - 2020-02-29 11:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:30 --> Input Class Initialized
INFO - 2020-02-29 11:30:30 --> Language Class Initialized
ERROR - 2020-02-29 11:30:30 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 11:30:30 --> Config Class Initialized
INFO - 2020-02-29 11:30:30 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:30:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:30 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:30 --> URI Class Initialized
INFO - 2020-02-29 11:30:30 --> Router Class Initialized
INFO - 2020-02-29 11:30:30 --> Output Class Initialized
INFO - 2020-02-29 11:30:30 --> Security Class Initialized
DEBUG - 2020-02-29 11:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:30 --> Input Class Initialized
INFO - 2020-02-29 11:30:30 --> Language Class Initialized
ERROR - 2020-02-29 11:30:30 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 11:30:30 --> Config Class Initialized
INFO - 2020-02-29 11:30:30 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:30:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:30 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:30 --> URI Class Initialized
INFO - 2020-02-29 11:30:30 --> Router Class Initialized
INFO - 2020-02-29 11:30:30 --> Output Class Initialized
INFO - 2020-02-29 11:30:30 --> Security Class Initialized
DEBUG - 2020-02-29 11:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:30 --> Input Class Initialized
INFO - 2020-02-29 11:30:30 --> Language Class Initialized
ERROR - 2020-02-29 11:30:30 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 11:30:30 --> Config Class Initialized
INFO - 2020-02-29 11:30:30 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:30:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:30:30 --> Utf8 Class Initialized
INFO - 2020-02-29 11:30:30 --> URI Class Initialized
INFO - 2020-02-29 11:30:30 --> Router Class Initialized
INFO - 2020-02-29 11:30:31 --> Output Class Initialized
INFO - 2020-02-29 11:30:31 --> Security Class Initialized
DEBUG - 2020-02-29 11:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:30:31 --> Input Class Initialized
INFO - 2020-02-29 11:30:31 --> Language Class Initialized
ERROR - 2020-02-29 11:30:31 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
INFO - 2020-02-29 11:33:55 --> Loader Class Initialized
INFO - 2020-02-29 11:33:55 --> Helper loaded: url_helper
INFO - 2020-02-29 11:33:55 --> Helper loaded: string_helper
INFO - 2020-02-29 11:33:55 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:33:55 --> Controller Class Initialized
INFO - 2020-02-29 11:33:55 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:33:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:33:55 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:33:55 --> Helper loaded: form_helper
INFO - 2020-02-29 11:33:55 --> Form Validation Class Initialized
INFO - 2020-02-29 11:33:55 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:33:55 --> Final output sent to browser
DEBUG - 2020-02-29 11:33:55 --> Total execution time: 0.2771
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
ERROR - 2020-02-29 11:33:55 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-29 11:33:55 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 11:33:55 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:33:55 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-29 11:33:55 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-29 11:33:55 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
ERROR - 2020-02-29 11:33:55 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-29 11:33:55 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-29 11:33:55 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:33:55 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-29 11:33:55 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 11:33:55 --> Loader Class Initialized
INFO - 2020-02-29 11:33:55 --> Helper loaded: url_helper
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
INFO - 2020-02-29 11:33:55 --> Helper loaded: string_helper
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:33:55 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:33:55 --> Database Driver Class Initialized
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:55 --> Utf8 Class Initialized
DEBUG - 2020-02-29 11:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> URI Class Initialized
INFO - 2020-02-29 11:33:55 --> Controller Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Router Class Initialized
INFO - 2020-02-29 11:33:55 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Output Class Initialized
INFO - 2020-02-29 11:33:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
INFO - 2020-02-29 11:33:55 --> Security Class Initialized
INFO - 2020-02-29 11:33:55 --> Model "M_pesan" initialized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Input Class Initialized
INFO - 2020-02-29 11:33:55 --> Helper loaded: form_helper
INFO - 2020-02-29 11:33:55 --> Form Validation Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
INFO - 2020-02-29 11:33:55 --> Language Class Initialized
ERROR - 2020-02-29 11:33:55 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 11:33:55 --> Loader Class Initialized
ERROR - 2020-02-29 11:33:55 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:33:55 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:33:55 --> Helper loaded: url_helper
INFO - 2020-02-29 11:33:55 --> Config Class Initialized
INFO - 2020-02-29 11:33:55 --> Hooks Class Initialized
INFO - 2020-02-29 11:33:55 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:33:55 --> Helper loaded: string_helper
INFO - 2020-02-29 11:33:55 --> Final output sent to browser
DEBUG - 2020-02-29 11:33:56 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:33:56 --> Database Driver Class Initialized
INFO - 2020-02-29 11:33:56 --> Utf8 Class Initialized
DEBUG - 2020-02-29 11:33:56 --> Total execution time: 0.3060
INFO - 2020-02-29 11:33:56 --> URI Class Initialized
DEBUG - 2020-02-29 11:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:33:56 --> Router Class Initialized
INFO - 2020-02-29 11:33:56 --> Controller Class Initialized
INFO - 2020-02-29 11:33:56 --> Output Class Initialized
INFO - 2020-02-29 11:33:56 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:33:56 --> Security Class Initialized
INFO - 2020-02-29 11:33:56 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 11:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:33:56 --> Input Class Initialized
INFO - 2020-02-29 11:33:56 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:33:56 --> Language Class Initialized
INFO - 2020-02-29 11:33:56 --> Helper loaded: form_helper
INFO - 2020-02-29 11:33:56 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:33:56 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-29 11:33:56 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 11:33:56 --> Config Class Initialized
INFO - 2020-02-29 11:33:56 --> Hooks Class Initialized
ERROR - 2020-02-29 11:33:56 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:33:56 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-29 11:33:56 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:33:56 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:56 --> Final output sent to browser
DEBUG - 2020-02-29 11:33:56 --> Total execution time: 0.2956
INFO - 2020-02-29 11:33:56 --> URI Class Initialized
INFO - 2020-02-29 11:33:56 --> Router Class Initialized
INFO - 2020-02-29 11:33:56 --> Output Class Initialized
INFO - 2020-02-29 11:33:56 --> Security Class Initialized
DEBUG - 2020-02-29 11:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:33:56 --> Input Class Initialized
INFO - 2020-02-29 11:33:56 --> Language Class Initialized
ERROR - 2020-02-29 11:33:56 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 11:33:56 --> Config Class Initialized
INFO - 2020-02-29 11:33:56 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:33:56 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:33:56 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:56 --> URI Class Initialized
INFO - 2020-02-29 11:33:56 --> Router Class Initialized
INFO - 2020-02-29 11:33:56 --> Output Class Initialized
INFO - 2020-02-29 11:33:56 --> Security Class Initialized
DEBUG - 2020-02-29 11:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:33:56 --> Input Class Initialized
INFO - 2020-02-29 11:33:56 --> Language Class Initialized
ERROR - 2020-02-29 11:33:56 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:33:56 --> Config Class Initialized
INFO - 2020-02-29 11:33:56 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:33:56 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:33:56 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:56 --> URI Class Initialized
INFO - 2020-02-29 11:33:56 --> Router Class Initialized
INFO - 2020-02-29 11:33:56 --> Output Class Initialized
INFO - 2020-02-29 11:33:56 --> Security Class Initialized
DEBUG - 2020-02-29 11:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:33:56 --> Input Class Initialized
INFO - 2020-02-29 11:33:56 --> Language Class Initialized
ERROR - 2020-02-29 11:33:56 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:33:56 --> Config Class Initialized
INFO - 2020-02-29 11:33:56 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:33:56 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:33:56 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:56 --> URI Class Initialized
INFO - 2020-02-29 11:33:56 --> Router Class Initialized
INFO - 2020-02-29 11:33:56 --> Output Class Initialized
INFO - 2020-02-29 11:33:56 --> Security Class Initialized
DEBUG - 2020-02-29 11:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:33:56 --> Input Class Initialized
INFO - 2020-02-29 11:33:56 --> Language Class Initialized
ERROR - 2020-02-29 11:33:56 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 11:33:56 --> Config Class Initialized
INFO - 2020-02-29 11:33:56 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:33:56 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:33:56 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:56 --> URI Class Initialized
INFO - 2020-02-29 11:33:56 --> Router Class Initialized
INFO - 2020-02-29 11:33:56 --> Output Class Initialized
INFO - 2020-02-29 11:33:56 --> Security Class Initialized
DEBUG - 2020-02-29 11:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:33:56 --> Input Class Initialized
INFO - 2020-02-29 11:33:56 --> Language Class Initialized
ERROR - 2020-02-29 11:33:56 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 11:33:56 --> Config Class Initialized
INFO - 2020-02-29 11:33:56 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:33:56 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:33:56 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:56 --> URI Class Initialized
INFO - 2020-02-29 11:33:56 --> Router Class Initialized
INFO - 2020-02-29 11:33:56 --> Output Class Initialized
INFO - 2020-02-29 11:33:56 --> Security Class Initialized
DEBUG - 2020-02-29 11:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:33:56 --> Input Class Initialized
INFO - 2020-02-29 11:33:56 --> Language Class Initialized
ERROR - 2020-02-29 11:33:56 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 11:33:56 --> Config Class Initialized
INFO - 2020-02-29 11:33:56 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:33:56 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:33:56 --> Utf8 Class Initialized
INFO - 2020-02-29 11:33:56 --> URI Class Initialized
INFO - 2020-02-29 11:33:56 --> Router Class Initialized
INFO - 2020-02-29 11:33:56 --> Output Class Initialized
INFO - 2020-02-29 11:33:56 --> Security Class Initialized
DEBUG - 2020-02-29 11:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:33:57 --> Input Class Initialized
INFO - 2020-02-29 11:33:57 --> Language Class Initialized
ERROR - 2020-02-29 11:33:57 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Security Class Initialized
DEBUG - 2020-02-29 11:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:34:18 --> Input Class Initialized
INFO - 2020-02-29 11:34:18 --> Language Class Initialized
INFO - 2020-02-29 11:34:18 --> Loader Class Initialized
INFO - 2020-02-29 11:34:18 --> Helper loaded: url_helper
INFO - 2020-02-29 11:34:18 --> Helper loaded: string_helper
INFO - 2020-02-29 11:34:18 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:34:18 --> Controller Class Initialized
INFO - 2020-02-29 11:34:18 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:34:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:34:18 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:34:18 --> Helper loaded: form_helper
INFO - 2020-02-29 11:34:18 --> Form Validation Class Initialized
INFO - 2020-02-29 11:34:18 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:34:18 --> Final output sent to browser
DEBUG - 2020-02-29 11:34:18 --> Total execution time: 0.2899
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Security Class Initialized
INFO - 2020-02-29 11:34:18 --> Security Class Initialized
INFO - 2020-02-29 11:34:18 --> Security Class Initialized
INFO - 2020-02-29 11:34:18 --> Security Class Initialized
INFO - 2020-02-29 11:34:18 --> Security Class Initialized
INFO - 2020-02-29 11:34:18 --> Security Class Initialized
DEBUG - 2020-02-29 11:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:34:18 --> Input Class Initialized
INFO - 2020-02-29 11:34:18 --> Input Class Initialized
INFO - 2020-02-29 11:34:18 --> Input Class Initialized
INFO - 2020-02-29 11:34:18 --> Input Class Initialized
INFO - 2020-02-29 11:34:18 --> Input Class Initialized
INFO - 2020-02-29 11:34:18 --> Input Class Initialized
INFO - 2020-02-29 11:34:18 --> Language Class Initialized
INFO - 2020-02-29 11:34:18 --> Language Class Initialized
INFO - 2020-02-29 11:34:18 --> Language Class Initialized
INFO - 2020-02-29 11:34:18 --> Language Class Initialized
INFO - 2020-02-29 11:34:18 --> Language Class Initialized
INFO - 2020-02-29 11:34:18 --> Language Class Initialized
ERROR - 2020-02-29 11:34:18 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 11:34:18 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:34:18 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-29 11:34:18 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-29 11:34:18 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-29 11:34:18 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Security Class Initialized
INFO - 2020-02-29 11:34:18 --> Security Class Initialized
INFO - 2020-02-29 11:34:18 --> Security Class Initialized
INFO - 2020-02-29 11:34:18 --> Security Class Initialized
INFO - 2020-02-29 11:34:18 --> Security Class Initialized
INFO - 2020-02-29 11:34:18 --> Security Class Initialized
DEBUG - 2020-02-29 11:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:34:18 --> Input Class Initialized
INFO - 2020-02-29 11:34:18 --> Input Class Initialized
INFO - 2020-02-29 11:34:18 --> Input Class Initialized
INFO - 2020-02-29 11:34:18 --> Input Class Initialized
INFO - 2020-02-29 11:34:18 --> Input Class Initialized
INFO - 2020-02-29 11:34:18 --> Input Class Initialized
INFO - 2020-02-29 11:34:18 --> Language Class Initialized
INFO - 2020-02-29 11:34:18 --> Language Class Initialized
INFO - 2020-02-29 11:34:18 --> Language Class Initialized
INFO - 2020-02-29 11:34:18 --> Language Class Initialized
INFO - 2020-02-29 11:34:18 --> Language Class Initialized
INFO - 2020-02-29 11:34:18 --> Language Class Initialized
ERROR - 2020-02-29 11:34:18 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-29 11:34:18 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:34:18 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-29 11:34:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-29 11:34:18 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 11:34:18 --> Loader Class Initialized
INFO - 2020-02-29 11:34:18 --> Helper loaded: url_helper
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Config Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
INFO - 2020-02-29 11:34:18 --> Hooks Class Initialized
INFO - 2020-02-29 11:34:18 --> Helper loaded: string_helper
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:34:18 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:34:18 --> Database Driver Class Initialized
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
INFO - 2020-02-29 11:34:18 --> URI Class Initialized
DEBUG - 2020-02-29 11:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Router Class Initialized
INFO - 2020-02-29 11:34:18 --> Controller Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:18 --> Output Class Initialized
INFO - 2020-02-29 11:34:19 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:34:19 --> Security Class Initialized
INFO - 2020-02-29 11:34:19 --> Security Class Initialized
INFO - 2020-02-29 11:34:19 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 11:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:34:19 --> Input Class Initialized
INFO - 2020-02-29 11:34:19 --> Input Class Initialized
INFO - 2020-02-29 11:34:19 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:34:19 --> Language Class Initialized
INFO - 2020-02-29 11:34:19 --> Language Class Initialized
INFO - 2020-02-29 11:34:19 --> Helper loaded: form_helper
INFO - 2020-02-29 11:34:19 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:34:19 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-29 11:34:19 --> Loader Class Initialized
INFO - 2020-02-29 11:34:19 --> Helper loaded: url_helper
ERROR - 2020-02-29 11:34:19 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 11:34:19 --> Config Class Initialized
INFO - 2020-02-29 11:34:19 --> Hooks Class Initialized
INFO - 2020-02-29 11:34:19 --> Helper loaded: string_helper
ERROR - 2020-02-29 11:34:19 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:34:19 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-29 11:34:19 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:34:19 --> Database Driver Class Initialized
INFO - 2020-02-29 11:34:19 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:19 --> Final output sent to browser
DEBUG - 2020-02-29 11:34:19 --> Total execution time: 0.3162
INFO - 2020-02-29 11:34:19 --> URI Class Initialized
DEBUG - 2020-02-29 11:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:34:19 --> Router Class Initialized
INFO - 2020-02-29 11:34:19 --> Controller Class Initialized
INFO - 2020-02-29 11:34:19 --> Output Class Initialized
INFO - 2020-02-29 11:34:19 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:34:19 --> Security Class Initialized
INFO - 2020-02-29 11:34:19 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 11:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:34:19 --> Input Class Initialized
INFO - 2020-02-29 11:34:19 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:34:19 --> Language Class Initialized
INFO - 2020-02-29 11:34:19 --> Helper loaded: form_helper
INFO - 2020-02-29 11:34:19 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:34:19 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 11:34:19 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 11:34:19 --> Config Class Initialized
INFO - 2020-02-29 11:34:19 --> Hooks Class Initialized
ERROR - 2020-02-29 11:34:19 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:34:19 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-29 11:34:19 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:34:19 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:19 --> Final output sent to browser
DEBUG - 2020-02-29 11:34:19 --> Total execution time: 0.2979
INFO - 2020-02-29 11:34:19 --> URI Class Initialized
INFO - 2020-02-29 11:34:19 --> Router Class Initialized
INFO - 2020-02-29 11:34:19 --> Output Class Initialized
INFO - 2020-02-29 11:34:19 --> Security Class Initialized
DEBUG - 2020-02-29 11:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:34:19 --> Input Class Initialized
INFO - 2020-02-29 11:34:19 --> Language Class Initialized
ERROR - 2020-02-29 11:34:19 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 11:34:19 --> Config Class Initialized
INFO - 2020-02-29 11:34:19 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:34:19 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:34:19 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:19 --> URI Class Initialized
INFO - 2020-02-29 11:34:19 --> Router Class Initialized
INFO - 2020-02-29 11:34:19 --> Output Class Initialized
INFO - 2020-02-29 11:34:19 --> Security Class Initialized
DEBUG - 2020-02-29 11:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:34:19 --> Input Class Initialized
INFO - 2020-02-29 11:34:19 --> Language Class Initialized
ERROR - 2020-02-29 11:34:19 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 11:34:19 --> Config Class Initialized
INFO - 2020-02-29 11:34:19 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:34:19 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:34:19 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:19 --> URI Class Initialized
INFO - 2020-02-29 11:34:19 --> Router Class Initialized
INFO - 2020-02-29 11:34:19 --> Output Class Initialized
INFO - 2020-02-29 11:34:19 --> Security Class Initialized
DEBUG - 2020-02-29 11:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:34:19 --> Input Class Initialized
INFO - 2020-02-29 11:34:19 --> Language Class Initialized
ERROR - 2020-02-29 11:34:19 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:34:19 --> Config Class Initialized
INFO - 2020-02-29 11:34:19 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:34:19 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:34:19 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:19 --> URI Class Initialized
INFO - 2020-02-29 11:34:19 --> Router Class Initialized
INFO - 2020-02-29 11:34:19 --> Output Class Initialized
INFO - 2020-02-29 11:34:19 --> Security Class Initialized
DEBUG - 2020-02-29 11:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:34:19 --> Input Class Initialized
INFO - 2020-02-29 11:34:19 --> Language Class Initialized
ERROR - 2020-02-29 11:34:19 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:34:19 --> Config Class Initialized
INFO - 2020-02-29 11:34:19 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:34:19 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:34:19 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:19 --> URI Class Initialized
INFO - 2020-02-29 11:34:19 --> Router Class Initialized
INFO - 2020-02-29 11:34:19 --> Output Class Initialized
INFO - 2020-02-29 11:34:19 --> Security Class Initialized
DEBUG - 2020-02-29 11:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:34:19 --> Input Class Initialized
INFO - 2020-02-29 11:34:19 --> Language Class Initialized
ERROR - 2020-02-29 11:34:19 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 11:34:19 --> Config Class Initialized
INFO - 2020-02-29 11:34:19 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:34:19 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:34:19 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:19 --> URI Class Initialized
INFO - 2020-02-29 11:34:19 --> Router Class Initialized
INFO - 2020-02-29 11:34:19 --> Output Class Initialized
INFO - 2020-02-29 11:34:19 --> Security Class Initialized
DEBUG - 2020-02-29 11:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:34:19 --> Input Class Initialized
INFO - 2020-02-29 11:34:19 --> Language Class Initialized
ERROR - 2020-02-29 11:34:20 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 11:34:20 --> Config Class Initialized
INFO - 2020-02-29 11:34:20 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:34:20 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:34:20 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:20 --> URI Class Initialized
INFO - 2020-02-29 11:34:20 --> Router Class Initialized
INFO - 2020-02-29 11:34:20 --> Output Class Initialized
INFO - 2020-02-29 11:34:20 --> Security Class Initialized
DEBUG - 2020-02-29 11:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:34:20 --> Input Class Initialized
INFO - 2020-02-29 11:34:20 --> Language Class Initialized
ERROR - 2020-02-29 11:34:20 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 11:34:20 --> Config Class Initialized
INFO - 2020-02-29 11:34:20 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:34:20 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:34:20 --> Utf8 Class Initialized
INFO - 2020-02-29 11:34:20 --> URI Class Initialized
INFO - 2020-02-29 11:34:20 --> Router Class Initialized
INFO - 2020-02-29 11:34:20 --> Output Class Initialized
INFO - 2020-02-29 11:34:20 --> Security Class Initialized
DEBUG - 2020-02-29 11:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:34:20 --> Input Class Initialized
INFO - 2020-02-29 11:34:20 --> Language Class Initialized
ERROR - 2020-02-29 11:34:20 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 11:38:40 --> Config Class Initialized
INFO - 2020-02-29 11:38:40 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:38:40 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:38:40 --> Utf8 Class Initialized
INFO - 2020-02-29 11:38:40 --> URI Class Initialized
INFO - 2020-02-29 11:38:40 --> Router Class Initialized
INFO - 2020-02-29 11:38:40 --> Output Class Initialized
INFO - 2020-02-29 11:38:40 --> Security Class Initialized
DEBUG - 2020-02-29 11:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:38:40 --> Input Class Initialized
INFO - 2020-02-29 11:38:40 --> Language Class Initialized
INFO - 2020-02-29 11:38:40 --> Loader Class Initialized
INFO - 2020-02-29 11:38:40 --> Helper loaded: url_helper
INFO - 2020-02-29 11:38:40 --> Helper loaded: string_helper
INFO - 2020-02-29 11:38:40 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:38:40 --> Controller Class Initialized
INFO - 2020-02-29 11:38:40 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:38:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:38:40 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:38:40 --> Helper loaded: form_helper
INFO - 2020-02-29 11:38:40 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:38:40 --> Severity: Notice --> Trying to get property 'id_pengunjung' of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 97
ERROR - 2020-02-29 17:38:40 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `bukti_bayar`, `id_pengunjung`) VALUES ('35', '', '1', '0', '20-02-29 05:38:40', '2020-03-01 05:38:40', NULL, 'PM202', NULL, 'default.jpg', NULL)
INFO - 2020-02-29 17:38:40 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-29 11:39:42 --> Config Class Initialized
INFO - 2020-02-29 11:39:42 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:39:42 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:39:42 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:42 --> URI Class Initialized
INFO - 2020-02-29 11:39:42 --> Router Class Initialized
INFO - 2020-02-29 11:39:42 --> Output Class Initialized
INFO - 2020-02-29 11:39:42 --> Security Class Initialized
DEBUG - 2020-02-29 11:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:42 --> Input Class Initialized
INFO - 2020-02-29 11:39:42 --> Language Class Initialized
INFO - 2020-02-29 11:39:42 --> Loader Class Initialized
INFO - 2020-02-29 11:39:42 --> Helper loaded: url_helper
INFO - 2020-02-29 11:39:42 --> Helper loaded: string_helper
INFO - 2020-02-29 11:39:42 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:39:42 --> Controller Class Initialized
INFO - 2020-02-29 11:39:42 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:39:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:39:42 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:39:42 --> Helper loaded: form_helper
INFO - 2020-02-29 11:39:42 --> Form Validation Class Initialized
INFO - 2020-02-29 11:39:42 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:39:42 --> Final output sent to browser
DEBUG - 2020-02-29 11:39:42 --> Total execution time: 0.2927
INFO - 2020-02-29 11:39:42 --> Config Class Initialized
INFO - 2020-02-29 11:39:42 --> Config Class Initialized
INFO - 2020-02-29 11:39:42 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:42 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:39:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:39:42 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:39:42 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:42 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:42 --> URI Class Initialized
INFO - 2020-02-29 11:39:42 --> URI Class Initialized
INFO - 2020-02-29 11:39:42 --> Router Class Initialized
INFO - 2020-02-29 11:39:42 --> Router Class Initialized
INFO - 2020-02-29 11:39:42 --> Output Class Initialized
INFO - 2020-02-29 11:39:42 --> Output Class Initialized
INFO - 2020-02-29 11:39:42 --> Security Class Initialized
INFO - 2020-02-29 11:39:42 --> Security Class Initialized
DEBUG - 2020-02-29 11:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:42 --> Input Class Initialized
INFO - 2020-02-29 11:39:42 --> Input Class Initialized
INFO - 2020-02-29 11:39:42 --> Language Class Initialized
INFO - 2020-02-29 11:39:42 --> Language Class Initialized
INFO - 2020-02-29 11:39:42 --> Loader Class Initialized
INFO - 2020-02-29 11:39:42 --> Loader Class Initialized
INFO - 2020-02-29 11:39:42 --> Helper loaded: url_helper
INFO - 2020-02-29 11:39:42 --> Helper loaded: url_helper
INFO - 2020-02-29 11:39:42 --> Helper loaded: string_helper
INFO - 2020-02-29 11:39:42 --> Helper loaded: string_helper
INFO - 2020-02-29 11:39:42 --> Database Driver Class Initialized
INFO - 2020-02-29 11:39:42 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-29 11:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:39:42 --> Controller Class Initialized
INFO - 2020-02-29 11:39:42 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:39:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:39:42 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:39:42 --> Helper loaded: form_helper
INFO - 2020-02-29 11:39:42 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:39:42 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:39:42 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:39:42 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:39:42 --> Final output sent to browser
DEBUG - 2020-02-29 11:39:42 --> Total execution time: 0.3211
INFO - 2020-02-29 11:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:39:42 --> Controller Class Initialized
INFO - 2020-02-29 11:39:42 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:39:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:39:42 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:39:42 --> Helper loaded: form_helper
INFO - 2020-02-29 11:39:42 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:39:42 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:39:42 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:39:42 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:39:42 --> Final output sent to browser
DEBUG - 2020-02-29 11:39:42 --> Total execution time: 0.4500
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Security Class Initialized
DEBUG - 2020-02-29 11:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:44 --> Input Class Initialized
INFO - 2020-02-29 11:39:44 --> Language Class Initialized
INFO - 2020-02-29 11:39:44 --> Loader Class Initialized
INFO - 2020-02-29 11:39:44 --> Helper loaded: url_helper
INFO - 2020-02-29 11:39:44 --> Helper loaded: string_helper
INFO - 2020-02-29 11:39:44 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:39:44 --> Controller Class Initialized
INFO - 2020-02-29 11:39:44 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:39:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:39:44 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:39:44 --> Helper loaded: form_helper
INFO - 2020-02-29 11:39:44 --> Form Validation Class Initialized
INFO - 2020-02-29 11:39:44 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:39:44 --> Final output sent to browser
DEBUG - 2020-02-29 11:39:44 --> Total execution time: 0.4043
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Security Class Initialized
INFO - 2020-02-29 11:39:44 --> Security Class Initialized
INFO - 2020-02-29 11:39:44 --> Security Class Initialized
INFO - 2020-02-29 11:39:44 --> Security Class Initialized
INFO - 2020-02-29 11:39:44 --> Security Class Initialized
INFO - 2020-02-29 11:39:44 --> Security Class Initialized
DEBUG - 2020-02-29 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:44 --> Input Class Initialized
INFO - 2020-02-29 11:39:44 --> Input Class Initialized
INFO - 2020-02-29 11:39:44 --> Input Class Initialized
INFO - 2020-02-29 11:39:44 --> Input Class Initialized
INFO - 2020-02-29 11:39:44 --> Input Class Initialized
INFO - 2020-02-29 11:39:44 --> Input Class Initialized
INFO - 2020-02-29 11:39:44 --> Language Class Initialized
INFO - 2020-02-29 11:39:44 --> Language Class Initialized
INFO - 2020-02-29 11:39:44 --> Language Class Initialized
INFO - 2020-02-29 11:39:44 --> Language Class Initialized
INFO - 2020-02-29 11:39:44 --> Language Class Initialized
INFO - 2020-02-29 11:39:44 --> Language Class Initialized
ERROR - 2020-02-29 11:39:44 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-29 11:39:44 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 11:39:44 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-29 11:39:44 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-29 11:39:44 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-29 11:39:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Security Class Initialized
INFO - 2020-02-29 11:39:44 --> Security Class Initialized
INFO - 2020-02-29 11:39:44 --> Security Class Initialized
INFO - 2020-02-29 11:39:44 --> Security Class Initialized
INFO - 2020-02-29 11:39:44 --> Security Class Initialized
INFO - 2020-02-29 11:39:44 --> Security Class Initialized
DEBUG - 2020-02-29 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:44 --> Input Class Initialized
INFO - 2020-02-29 11:39:44 --> Input Class Initialized
INFO - 2020-02-29 11:39:44 --> Input Class Initialized
INFO - 2020-02-29 11:39:44 --> Input Class Initialized
INFO - 2020-02-29 11:39:44 --> Input Class Initialized
INFO - 2020-02-29 11:39:44 --> Input Class Initialized
INFO - 2020-02-29 11:39:44 --> Language Class Initialized
INFO - 2020-02-29 11:39:44 --> Language Class Initialized
INFO - 2020-02-29 11:39:44 --> Language Class Initialized
INFO - 2020-02-29 11:39:44 --> Language Class Initialized
INFO - 2020-02-29 11:39:44 --> Language Class Initialized
INFO - 2020-02-29 11:39:44 --> Language Class Initialized
ERROR - 2020-02-29 11:39:44 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-29 11:39:44 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-29 11:39:44 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-29 11:39:44 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:39:44 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 11:39:44 --> Loader Class Initialized
INFO - 2020-02-29 11:39:44 --> Helper loaded: url_helper
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Config Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:44 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:44 --> Helper loaded: string_helper
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:39:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:39:44 --> Database Driver Class Initialized
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:44 --> Utf8 Class Initialized
DEBUG - 2020-02-29 11:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> URI Class Initialized
INFO - 2020-02-29 11:39:44 --> Controller Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Router Class Initialized
INFO - 2020-02-29 11:39:44 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:44 --> Output Class Initialized
INFO - 2020-02-29 11:39:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:39:45 --> Security Class Initialized
INFO - 2020-02-29 11:39:45 --> Security Class Initialized
INFO - 2020-02-29 11:39:45 --> Model "M_pesan" initialized
DEBUG - 2020-02-29 11:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:45 --> Input Class Initialized
INFO - 2020-02-29 11:39:45 --> Input Class Initialized
INFO - 2020-02-29 11:39:45 --> Helper loaded: form_helper
INFO - 2020-02-29 11:39:45 --> Form Validation Class Initialized
INFO - 2020-02-29 11:39:45 --> Language Class Initialized
INFO - 2020-02-29 11:39:45 --> Language Class Initialized
ERROR - 2020-02-29 11:39:45 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 11:39:45 --> Loader Class Initialized
ERROR - 2020-02-29 11:39:45 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:39:45 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:39:45 --> Helper loaded: url_helper
INFO - 2020-02-29 11:39:45 --> Config Class Initialized
INFO - 2020-02-29 11:39:45 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:39:45 --> Helper loaded: string_helper
INFO - 2020-02-29 11:39:45 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:45 --> Final output sent to browser
INFO - 2020-02-29 11:39:45 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:39:45 --> Total execution time: 0.2949
DEBUG - 2020-02-29 11:39:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:39:45 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:39:45 --> Controller Class Initialized
INFO - 2020-02-29 11:39:45 --> URI Class Initialized
INFO - 2020-02-29 11:39:45 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:39:45 --> Router Class Initialized
INFO - 2020-02-29 11:39:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:39:45 --> Output Class Initialized
INFO - 2020-02-29 11:39:45 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:39:45 --> Security Class Initialized
DEBUG - 2020-02-29 11:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:45 --> Helper loaded: form_helper
INFO - 2020-02-29 11:39:45 --> Input Class Initialized
INFO - 2020-02-29 11:39:45 --> Form Validation Class Initialized
INFO - 2020-02-29 11:39:45 --> Language Class Initialized
ERROR - 2020-02-29 11:39:45 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:39:45 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-29 11:39:45 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 11:39:45 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:39:45 --> Config Class Initialized
INFO - 2020-02-29 11:39:45 --> Hooks Class Initialized
INFO - 2020-02-29 11:39:45 --> Final output sent to browser
DEBUG - 2020-02-29 11:39:45 --> Total execution time: 0.2826
DEBUG - 2020-02-29 11:39:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:39:45 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:45 --> URI Class Initialized
INFO - 2020-02-29 11:39:45 --> Router Class Initialized
INFO - 2020-02-29 11:39:45 --> Output Class Initialized
INFO - 2020-02-29 11:39:45 --> Security Class Initialized
DEBUG - 2020-02-29 11:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:45 --> Input Class Initialized
INFO - 2020-02-29 11:39:45 --> Language Class Initialized
ERROR - 2020-02-29 11:39:45 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 11:39:45 --> Config Class Initialized
INFO - 2020-02-29 11:39:45 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:39:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:39:45 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:45 --> URI Class Initialized
INFO - 2020-02-29 11:39:45 --> Router Class Initialized
INFO - 2020-02-29 11:39:45 --> Output Class Initialized
INFO - 2020-02-29 11:39:45 --> Security Class Initialized
DEBUG - 2020-02-29 11:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:45 --> Input Class Initialized
INFO - 2020-02-29 11:39:45 --> Language Class Initialized
ERROR - 2020-02-29 11:39:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:39:45 --> Config Class Initialized
INFO - 2020-02-29 11:39:45 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:39:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:39:45 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:45 --> URI Class Initialized
INFO - 2020-02-29 11:39:45 --> Router Class Initialized
INFO - 2020-02-29 11:39:45 --> Output Class Initialized
INFO - 2020-02-29 11:39:45 --> Security Class Initialized
DEBUG - 2020-02-29 11:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:45 --> Input Class Initialized
INFO - 2020-02-29 11:39:45 --> Language Class Initialized
ERROR - 2020-02-29 11:39:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:39:45 --> Config Class Initialized
INFO - 2020-02-29 11:39:45 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:39:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:39:45 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:45 --> URI Class Initialized
INFO - 2020-02-29 11:39:45 --> Router Class Initialized
INFO - 2020-02-29 11:39:45 --> Output Class Initialized
INFO - 2020-02-29 11:39:45 --> Security Class Initialized
DEBUG - 2020-02-29 11:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:45 --> Input Class Initialized
INFO - 2020-02-29 11:39:45 --> Language Class Initialized
ERROR - 2020-02-29 11:39:45 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 11:39:45 --> Config Class Initialized
INFO - 2020-02-29 11:39:45 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:39:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:39:45 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:45 --> URI Class Initialized
INFO - 2020-02-29 11:39:45 --> Router Class Initialized
INFO - 2020-02-29 11:39:45 --> Output Class Initialized
INFO - 2020-02-29 11:39:45 --> Security Class Initialized
DEBUG - 2020-02-29 11:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:45 --> Input Class Initialized
INFO - 2020-02-29 11:39:45 --> Language Class Initialized
ERROR - 2020-02-29 11:39:45 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 11:39:45 --> Config Class Initialized
INFO - 2020-02-29 11:39:45 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:39:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:39:45 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:45 --> URI Class Initialized
INFO - 2020-02-29 11:39:45 --> Router Class Initialized
INFO - 2020-02-29 11:39:45 --> Output Class Initialized
INFO - 2020-02-29 11:39:45 --> Security Class Initialized
DEBUG - 2020-02-29 11:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:46 --> Input Class Initialized
INFO - 2020-02-29 11:39:46 --> Language Class Initialized
ERROR - 2020-02-29 11:39:46 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 11:39:46 --> Config Class Initialized
INFO - 2020-02-29 11:39:46 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:39:46 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:39:46 --> Utf8 Class Initialized
INFO - 2020-02-29 11:39:46 --> URI Class Initialized
INFO - 2020-02-29 11:39:46 --> Router Class Initialized
INFO - 2020-02-29 11:39:46 --> Output Class Initialized
INFO - 2020-02-29 11:39:46 --> Security Class Initialized
DEBUG - 2020-02-29 11:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:39:46 --> Input Class Initialized
INFO - 2020-02-29 11:39:46 --> Language Class Initialized
ERROR - 2020-02-29 11:39:46 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 11:40:15 --> Config Class Initialized
INFO - 2020-02-29 11:40:15 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:15 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:15 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:15 --> URI Class Initialized
INFO - 2020-02-29 11:40:15 --> Router Class Initialized
INFO - 2020-02-29 11:40:15 --> Output Class Initialized
INFO - 2020-02-29 11:40:15 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:15 --> Input Class Initialized
INFO - 2020-02-29 11:40:15 --> Language Class Initialized
INFO - 2020-02-29 11:40:15 --> Loader Class Initialized
INFO - 2020-02-29 11:40:15 --> Helper loaded: url_helper
INFO - 2020-02-29 11:40:15 --> Helper loaded: string_helper
INFO - 2020-02-29 11:40:15 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:40:15 --> Controller Class Initialized
INFO - 2020-02-29 11:40:15 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:40:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:40:15 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:40:15 --> Helper loaded: form_helper
INFO - 2020-02-29 11:40:15 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:40:15 --> Severity: Notice --> Trying to get property 'id_pengunjung' of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 97
ERROR - 2020-02-29 17:40:15 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `bukti_bayar`, `id_pengunjung`) VALUES ('35', '', '1', '0', '20-02-29 05:40:15', '2020-03-01 05:40:15', NULL, 'PM202', NULL, 'default.jpg', NULL)
INFO - 2020-02-29 17:40:15 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-29 11:40:38 --> Config Class Initialized
INFO - 2020-02-29 11:40:38 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:38 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:38 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:38 --> URI Class Initialized
INFO - 2020-02-29 11:40:38 --> Router Class Initialized
INFO - 2020-02-29 11:40:38 --> Output Class Initialized
INFO - 2020-02-29 11:40:38 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:38 --> Input Class Initialized
INFO - 2020-02-29 11:40:38 --> Language Class Initialized
INFO - 2020-02-29 11:40:38 --> Loader Class Initialized
INFO - 2020-02-29 11:40:38 --> Helper loaded: url_helper
INFO - 2020-02-29 11:40:38 --> Helper loaded: string_helper
INFO - 2020-02-29 11:40:38 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:40:38 --> Controller Class Initialized
INFO - 2020-02-29 11:40:38 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:40:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:40:38 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:40:38 --> Helper loaded: form_helper
INFO - 2020-02-29 11:40:38 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:40:38 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 86
ERROR - 2020-02-29 11:40:38 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 87
ERROR - 2020-02-29 11:40:38 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 88
ERROR - 2020-02-29 11:40:38 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 89
ERROR - 2020-02-29 11:40:38 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 81
ERROR - 2020-02-29 11:40:38 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 82
ERROR - 2020-02-29 11:40:38 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 83
ERROR - 2020-02-29 11:40:39 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 84
ERROR - 2020-02-29 11:40:39 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pengunjung` (`nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2020-02-29 11:40:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-29 11:40:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow-2\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow-2\system\core\Common.php 570
INFO - 2020-02-29 11:40:40 --> Config Class Initialized
INFO - 2020-02-29 11:40:40 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:40 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:40 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:40 --> URI Class Initialized
INFO - 2020-02-29 11:40:40 --> Router Class Initialized
INFO - 2020-02-29 11:40:40 --> Output Class Initialized
INFO - 2020-02-29 11:40:40 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:40 --> Input Class Initialized
INFO - 2020-02-29 11:40:40 --> Language Class Initialized
INFO - 2020-02-29 11:40:40 --> Loader Class Initialized
INFO - 2020-02-29 11:40:40 --> Helper loaded: url_helper
INFO - 2020-02-29 11:40:40 --> Helper loaded: string_helper
INFO - 2020-02-29 11:40:41 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:40:41 --> Controller Class Initialized
INFO - 2020-02-29 11:40:41 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:40:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:40:41 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:40:41 --> Helper loaded: form_helper
INFO - 2020-02-29 11:40:41 --> Form Validation Class Initialized
INFO - 2020-02-29 11:40:41 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:40:41 --> Final output sent to browser
DEBUG - 2020-02-29 11:40:41 --> Total execution time: 0.3071
INFO - 2020-02-29 11:40:41 --> Config Class Initialized
INFO - 2020-02-29 11:40:41 --> Config Class Initialized
INFO - 2020-02-29 11:40:41 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:41 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:40:41 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:41 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:41 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:41 --> URI Class Initialized
INFO - 2020-02-29 11:40:41 --> URI Class Initialized
INFO - 2020-02-29 11:40:41 --> Router Class Initialized
INFO - 2020-02-29 11:40:41 --> Router Class Initialized
INFO - 2020-02-29 11:40:41 --> Output Class Initialized
INFO - 2020-02-29 11:40:41 --> Output Class Initialized
INFO - 2020-02-29 11:40:41 --> Security Class Initialized
INFO - 2020-02-29 11:40:41 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:41 --> Input Class Initialized
INFO - 2020-02-29 11:40:41 --> Input Class Initialized
INFO - 2020-02-29 11:40:41 --> Language Class Initialized
INFO - 2020-02-29 11:40:41 --> Language Class Initialized
INFO - 2020-02-29 11:40:41 --> Loader Class Initialized
INFO - 2020-02-29 11:40:41 --> Loader Class Initialized
INFO - 2020-02-29 11:40:41 --> Helper loaded: url_helper
INFO - 2020-02-29 11:40:41 --> Helper loaded: url_helper
INFO - 2020-02-29 11:40:41 --> Helper loaded: string_helper
INFO - 2020-02-29 11:40:41 --> Helper loaded: string_helper
INFO - 2020-02-29 11:40:41 --> Database Driver Class Initialized
INFO - 2020-02-29 11:40:41 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-29 11:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:40:41 --> Controller Class Initialized
INFO - 2020-02-29 11:40:41 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:40:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:40:41 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:40:41 --> Helper loaded: form_helper
INFO - 2020-02-29 11:40:41 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:40:41 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:40:41 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:40:41 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:40:41 --> Final output sent to browser
DEBUG - 2020-02-29 11:40:41 --> Total execution time: 0.3324
INFO - 2020-02-29 11:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:40:41 --> Controller Class Initialized
INFO - 2020-02-29 11:40:41 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:40:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:40:41 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:40:41 --> Helper loaded: form_helper
INFO - 2020-02-29 11:40:41 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:40:41 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:40:41 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:40:41 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:40:41 --> Final output sent to browser
DEBUG - 2020-02-29 11:40:41 --> Total execution time: 0.4637
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
INFO - 2020-02-29 11:40:43 --> Loader Class Initialized
INFO - 2020-02-29 11:40:43 --> Helper loaded: url_helper
INFO - 2020-02-29 11:40:43 --> Helper loaded: string_helper
INFO - 2020-02-29 11:40:43 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:40:43 --> Controller Class Initialized
INFO - 2020-02-29 11:40:43 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:40:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:40:43 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:40:43 --> Helper loaded: form_helper
INFO - 2020-02-29 11:40:43 --> Form Validation Class Initialized
INFO - 2020-02-29 11:40:43 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:40:43 --> Final output sent to browser
DEBUG - 2020-02-29 11:40:43 --> Total execution time: 0.2857
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
ERROR - 2020-02-29 11:40:43 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-29 11:40:43 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-29 11:40:43 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 11:40:43 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:40:43 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-29 11:40:43 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
ERROR - 2020-02-29 11:40:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-29 11:40:43 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-29 11:40:43 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:40:43 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-29 11:40:43 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 11:40:43 --> Loader Class Initialized
INFO - 2020-02-29 11:40:43 --> Helper loaded: url_helper
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:43 --> Helper loaded: string_helper
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:43 --> Database Driver Class Initialized
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
DEBUG - 2020-02-29 11:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
INFO - 2020-02-29 11:40:43 --> Controller Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
INFO - 2020-02-29 11:40:43 --> Model "M_pesan" initialized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Helper loaded: form_helper
INFO - 2020-02-29 11:40:43 --> Form Validation Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
INFO - 2020-02-29 11:40:43 --> Language Class Initialized
ERROR - 2020-02-29 11:40:43 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 11:40:43 --> Loader Class Initialized
ERROR - 2020-02-29 11:40:43 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:40:43 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:40:43 --> Helper loaded: url_helper
INFO - 2020-02-29 11:40:43 --> Config Class Initialized
INFO - 2020-02-29 11:40:43 --> Hooks Class Initialized
INFO - 2020-02-29 11:40:43 --> Helper loaded: string_helper
INFO - 2020-02-29 11:40:43 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:40:43 --> Final output sent to browser
DEBUG - 2020-02-29 11:40:43 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:43 --> Database Driver Class Initialized
INFO - 2020-02-29 11:40:43 --> Utf8 Class Initialized
DEBUG - 2020-02-29 11:40:43 --> Total execution time: 0.3192
INFO - 2020-02-29 11:40:43 --> URI Class Initialized
DEBUG - 2020-02-29 11:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:40:43 --> Router Class Initialized
INFO - 2020-02-29 11:40:43 --> Controller Class Initialized
INFO - 2020-02-29 11:40:43 --> Output Class Initialized
INFO - 2020-02-29 11:40:43 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:40:43 --> Security Class Initialized
INFO - 2020-02-29 11:40:43 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 11:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:43 --> Input Class Initialized
INFO - 2020-02-29 11:40:43 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:40:44 --> Language Class Initialized
INFO - 2020-02-29 11:40:44 --> Helper loaded: form_helper
INFO - 2020-02-29 11:40:44 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:40:44 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-29 11:40:44 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 11:40:44 --> Config Class Initialized
INFO - 2020-02-29 11:40:44 --> Hooks Class Initialized
ERROR - 2020-02-29 11:40:44 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:40:44 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-29 11:40:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:44 --> Final output sent to browser
DEBUG - 2020-02-29 11:40:44 --> Total execution time: 0.3065
INFO - 2020-02-29 11:40:44 --> URI Class Initialized
INFO - 2020-02-29 11:40:44 --> Router Class Initialized
INFO - 2020-02-29 11:40:44 --> Output Class Initialized
INFO - 2020-02-29 11:40:44 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:44 --> Input Class Initialized
INFO - 2020-02-29 11:40:44 --> Language Class Initialized
ERROR - 2020-02-29 11:40:44 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 11:40:44 --> Config Class Initialized
INFO - 2020-02-29 11:40:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:44 --> URI Class Initialized
INFO - 2020-02-29 11:40:44 --> Router Class Initialized
INFO - 2020-02-29 11:40:44 --> Output Class Initialized
INFO - 2020-02-29 11:40:44 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:44 --> Input Class Initialized
INFO - 2020-02-29 11:40:44 --> Language Class Initialized
ERROR - 2020-02-29 11:40:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:40:44 --> Config Class Initialized
INFO - 2020-02-29 11:40:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:44 --> URI Class Initialized
INFO - 2020-02-29 11:40:44 --> Router Class Initialized
INFO - 2020-02-29 11:40:44 --> Output Class Initialized
INFO - 2020-02-29 11:40:44 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:44 --> Input Class Initialized
INFO - 2020-02-29 11:40:44 --> Language Class Initialized
ERROR - 2020-02-29 11:40:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:40:44 --> Config Class Initialized
INFO - 2020-02-29 11:40:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:44 --> URI Class Initialized
INFO - 2020-02-29 11:40:44 --> Router Class Initialized
INFO - 2020-02-29 11:40:44 --> Output Class Initialized
INFO - 2020-02-29 11:40:44 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:44 --> Input Class Initialized
INFO - 2020-02-29 11:40:44 --> Language Class Initialized
ERROR - 2020-02-29 11:40:44 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 11:40:44 --> Config Class Initialized
INFO - 2020-02-29 11:40:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:44 --> URI Class Initialized
INFO - 2020-02-29 11:40:44 --> Router Class Initialized
INFO - 2020-02-29 11:40:44 --> Output Class Initialized
INFO - 2020-02-29 11:40:44 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:44 --> Input Class Initialized
INFO - 2020-02-29 11:40:44 --> Language Class Initialized
ERROR - 2020-02-29 11:40:44 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 11:40:44 --> Config Class Initialized
INFO - 2020-02-29 11:40:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:44 --> URI Class Initialized
INFO - 2020-02-29 11:40:44 --> Router Class Initialized
INFO - 2020-02-29 11:40:44 --> Output Class Initialized
INFO - 2020-02-29 11:40:44 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:44 --> Input Class Initialized
INFO - 2020-02-29 11:40:44 --> Language Class Initialized
ERROR - 2020-02-29 11:40:44 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 11:40:44 --> Config Class Initialized
INFO - 2020-02-29 11:40:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:44 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:44 --> URI Class Initialized
INFO - 2020-02-29 11:40:44 --> Router Class Initialized
INFO - 2020-02-29 11:40:45 --> Output Class Initialized
INFO - 2020-02-29 11:40:45 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:45 --> Input Class Initialized
INFO - 2020-02-29 11:40:45 --> Language Class Initialized
ERROR - 2020-02-29 11:40:45 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 11:40:55 --> Config Class Initialized
INFO - 2020-02-29 11:40:55 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:40:55 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:40:55 --> Utf8 Class Initialized
INFO - 2020-02-29 11:40:55 --> URI Class Initialized
INFO - 2020-02-29 11:40:55 --> Router Class Initialized
INFO - 2020-02-29 11:40:55 --> Output Class Initialized
INFO - 2020-02-29 11:40:55 --> Security Class Initialized
DEBUG - 2020-02-29 11:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:40:55 --> Input Class Initialized
INFO - 2020-02-29 11:40:55 --> Language Class Initialized
INFO - 2020-02-29 11:40:55 --> Loader Class Initialized
INFO - 2020-02-29 11:40:55 --> Helper loaded: url_helper
INFO - 2020-02-29 11:40:55 --> Helper loaded: string_helper
INFO - 2020-02-29 11:40:55 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:40:55 --> Controller Class Initialized
INFO - 2020-02-29 11:40:55 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:40:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:40:55 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:40:55 --> Helper loaded: form_helper
INFO - 2020-02-29 11:40:55 --> Form Validation Class Initialized
ERROR - 2020-02-29 17:40:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\roadshow-2\application\views\Pemesanan\konfirm_bayar.php 5
INFO - 2020-02-29 17:40:55 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-29 17:40:55 --> Final output sent to browser
DEBUG - 2020-02-29 17:40:55 --> Total execution time: 0.4350
INFO - 2020-02-29 11:41:00 --> Config Class Initialized
INFO - 2020-02-29 11:41:00 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:00 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:00 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:00 --> URI Class Initialized
INFO - 2020-02-29 11:41:00 --> Router Class Initialized
INFO - 2020-02-29 11:41:00 --> Output Class Initialized
INFO - 2020-02-29 11:41:00 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:00 --> Input Class Initialized
INFO - 2020-02-29 11:41:00 --> Language Class Initialized
INFO - 2020-02-29 11:41:00 --> Loader Class Initialized
INFO - 2020-02-29 11:41:00 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:00 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:00 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:00 --> Controller Class Initialized
INFO - 2020-02-29 11:41:00 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:41:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:41:00 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:41:00 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:00 --> Form Validation Class Initialized
INFO - 2020-02-29 11:41:00 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:41:00 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:00 --> Total execution time: 0.3503
INFO - 2020-02-29 11:41:00 --> Config Class Initialized
INFO - 2020-02-29 11:41:00 --> Config Class Initialized
INFO - 2020-02-29 11:41:00 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:00 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:01 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:01 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:01 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:01 --> URI Class Initialized
INFO - 2020-02-29 11:41:01 --> URI Class Initialized
INFO - 2020-02-29 11:41:01 --> Router Class Initialized
INFO - 2020-02-29 11:41:01 --> Router Class Initialized
INFO - 2020-02-29 11:41:01 --> Output Class Initialized
INFO - 2020-02-29 11:41:01 --> Output Class Initialized
INFO - 2020-02-29 11:41:01 --> Security Class Initialized
INFO - 2020-02-29 11:41:01 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:01 --> Input Class Initialized
INFO - 2020-02-29 11:41:01 --> Input Class Initialized
INFO - 2020-02-29 11:41:01 --> Language Class Initialized
INFO - 2020-02-29 11:41:01 --> Language Class Initialized
INFO - 2020-02-29 11:41:01 --> Loader Class Initialized
INFO - 2020-02-29 11:41:01 --> Loader Class Initialized
INFO - 2020-02-29 11:41:01 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:01 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:01 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:01 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:01 --> Database Driver Class Initialized
INFO - 2020-02-29 11:41:01 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:41:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-29 11:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:41:01 --> Controller Class Initialized
INFO - 2020-02-29 11:41:01 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:41:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:41:01 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:41:01 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:01 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:41:01 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:41:01 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:41:01 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:41:01 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:01 --> Total execution time: 0.3525
INFO - 2020-02-29 11:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:01 --> Controller Class Initialized
INFO - 2020-02-29 11:41:01 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:41:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:41:01 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:41:01 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:01 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:41:01 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:41:01 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:41:01 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:41:01 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:01 --> Total execution time: 0.4967
INFO - 2020-02-29 11:41:02 --> Config Class Initialized
INFO - 2020-02-29 11:41:02 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:02 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:02 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:02 --> URI Class Initialized
INFO - 2020-02-29 11:41:02 --> Router Class Initialized
INFO - 2020-02-29 11:41:03 --> Output Class Initialized
INFO - 2020-02-29 11:41:03 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:03 --> Input Class Initialized
INFO - 2020-02-29 11:41:03 --> Language Class Initialized
INFO - 2020-02-29 11:41:03 --> Loader Class Initialized
INFO - 2020-02-29 11:41:03 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:03 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:03 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:03 --> Controller Class Initialized
INFO - 2020-02-29 11:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:41:03 --> Pagination Class Initialized
INFO - 2020-02-29 11:41:03 --> Model "M_show" initialized
INFO - 2020-02-29 11:41:03 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:03 --> Form Validation Class Initialized
INFO - 2020-02-29 11:41:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:41:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\beli.php
INFO - 2020-02-29 11:41:03 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:03 --> Total execution time: 0.3079
INFO - 2020-02-29 11:41:04 --> Config Class Initialized
INFO - 2020-02-29 11:41:04 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:04 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:04 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:04 --> URI Class Initialized
INFO - 2020-02-29 11:41:04 --> Router Class Initialized
INFO - 2020-02-29 11:41:04 --> Output Class Initialized
INFO - 2020-02-29 11:41:04 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:04 --> Input Class Initialized
INFO - 2020-02-29 11:41:04 --> Language Class Initialized
INFO - 2020-02-29 11:41:04 --> Loader Class Initialized
INFO - 2020-02-29 11:41:04 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:04 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:04 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:04 --> Controller Class Initialized
INFO - 2020-02-29 11:41:04 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:41:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:41:04 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:41:04 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:04 --> Form Validation Class Initialized
INFO - 2020-02-29 11:41:04 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:41:04 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:04 --> Total execution time: 0.2953
INFO - 2020-02-29 11:41:04 --> Config Class Initialized
INFO - 2020-02-29 11:41:04 --> Config Class Initialized
INFO - 2020-02-29 11:41:04 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:04 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:04 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:04 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:04 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:04 --> URI Class Initialized
INFO - 2020-02-29 11:41:04 --> URI Class Initialized
INFO - 2020-02-29 11:41:04 --> Router Class Initialized
INFO - 2020-02-29 11:41:04 --> Router Class Initialized
INFO - 2020-02-29 11:41:04 --> Output Class Initialized
INFO - 2020-02-29 11:41:04 --> Output Class Initialized
INFO - 2020-02-29 11:41:04 --> Security Class Initialized
INFO - 2020-02-29 11:41:04 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:04 --> Input Class Initialized
INFO - 2020-02-29 11:41:04 --> Input Class Initialized
INFO - 2020-02-29 11:41:04 --> Language Class Initialized
INFO - 2020-02-29 11:41:04 --> Language Class Initialized
INFO - 2020-02-29 11:41:04 --> Loader Class Initialized
INFO - 2020-02-29 11:41:04 --> Loader Class Initialized
INFO - 2020-02-29 11:41:04 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:04 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:04 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:04 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:05 --> Database Driver Class Initialized
INFO - 2020-02-29 11:41:05 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-29 11:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:05 --> Controller Class Initialized
INFO - 2020-02-29 11:41:05 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:41:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:41:05 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:41:05 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:05 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:41:05 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:41:05 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:41:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:41:05 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:05 --> Total execution time: 0.3694
INFO - 2020-02-29 11:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:05 --> Controller Class Initialized
INFO - 2020-02-29 11:41:05 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:41:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:41:05 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:41:05 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:05 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:41:05 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:41:05 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:41:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:41:05 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:05 --> Total execution time: 0.5205
INFO - 2020-02-29 11:41:07 --> Config Class Initialized
INFO - 2020-02-29 11:41:07 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:07 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:07 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:07 --> URI Class Initialized
INFO - 2020-02-29 11:41:07 --> Router Class Initialized
INFO - 2020-02-29 11:41:07 --> Output Class Initialized
INFO - 2020-02-29 11:41:07 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:07 --> Input Class Initialized
INFO - 2020-02-29 11:41:07 --> Language Class Initialized
INFO - 2020-02-29 11:41:07 --> Loader Class Initialized
INFO - 2020-02-29 11:41:07 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:07 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:07 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:07 --> Controller Class Initialized
INFO - 2020-02-29 11:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:41:07 --> Pagination Class Initialized
INFO - 2020-02-29 11:41:07 --> Model "M_show" initialized
INFO - 2020-02-29 11:41:07 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:07 --> Form Validation Class Initialized
INFO - 2020-02-29 11:41:07 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:41:07 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\beli.php
INFO - 2020-02-29 11:41:07 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:07 --> Total execution time: 0.3282
INFO - 2020-02-29 11:41:09 --> Config Class Initialized
INFO - 2020-02-29 11:41:09 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:09 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:09 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:09 --> URI Class Initialized
INFO - 2020-02-29 11:41:09 --> Router Class Initialized
INFO - 2020-02-29 11:41:09 --> Output Class Initialized
INFO - 2020-02-29 11:41:09 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:09 --> Input Class Initialized
INFO - 2020-02-29 11:41:09 --> Language Class Initialized
INFO - 2020-02-29 11:41:09 --> Loader Class Initialized
INFO - 2020-02-29 11:41:09 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:09 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:09 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:09 --> Controller Class Initialized
INFO - 2020-02-29 11:41:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:41:09 --> Pagination Class Initialized
INFO - 2020-02-29 11:41:09 --> Model "M_show" initialized
INFO - 2020-02-29 11:41:09 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:09 --> Form Validation Class Initialized
INFO - 2020-02-29 11:41:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:41:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\beli.php
INFO - 2020-02-29 11:41:09 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:09 --> Total execution time: 0.3201
INFO - 2020-02-29 11:41:12 --> Config Class Initialized
INFO - 2020-02-29 11:41:12 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:12 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:12 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:12 --> URI Class Initialized
INFO - 2020-02-29 11:41:12 --> Router Class Initialized
INFO - 2020-02-29 11:41:12 --> Output Class Initialized
INFO - 2020-02-29 11:41:12 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:12 --> Input Class Initialized
INFO - 2020-02-29 11:41:12 --> Language Class Initialized
INFO - 2020-02-29 11:41:12 --> Loader Class Initialized
INFO - 2020-02-29 11:41:12 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:12 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:12 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:12 --> Controller Class Initialized
INFO - 2020-02-29 11:41:12 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:41:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:41:12 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:41:12 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:12 --> Form Validation Class Initialized
INFO - 2020-02-29 11:41:12 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:41:12 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:12 --> Total execution time: 0.3246
INFO - 2020-02-29 11:41:12 --> Config Class Initialized
INFO - 2020-02-29 11:41:12 --> Config Class Initialized
INFO - 2020-02-29 11:41:12 --> Config Class Initialized
INFO - 2020-02-29 11:41:12 --> Config Class Initialized
INFO - 2020-02-29 11:41:12 --> Config Class Initialized
INFO - 2020-02-29 11:41:12 --> Config Class Initialized
INFO - 2020-02-29 11:41:12 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:12 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:12 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:12 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:12 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:12 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:12 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-29 11:41:13 --> Config Class Initialized
INFO - 2020-02-29 11:41:13 --> Config Class Initialized
INFO - 2020-02-29 11:41:13 --> Config Class Initialized
INFO - 2020-02-29 11:41:13 --> Config Class Initialized
INFO - 2020-02-29 11:41:13 --> Config Class Initialized
INFO - 2020-02-29 11:41:13 --> Config Class Initialized
INFO - 2020-02-29 11:41:13 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:13 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:13 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:13 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:13 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:13 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:13 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 11:41:13 --> Loader Class Initialized
INFO - 2020-02-29 11:41:13 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:13 --> Config Class Initialized
INFO - 2020-02-29 11:41:13 --> Config Class Initialized
INFO - 2020-02-29 11:41:13 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:13 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:13 --> Helper loaded: string_helper
DEBUG - 2020-02-29 11:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:13 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:13 --> Database Driver Class Initialized
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
DEBUG - 2020-02-29 11:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Controller Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
INFO - 2020-02-29 11:41:13 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
INFO - 2020-02-29 11:41:13 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:13 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 11:41:13 --> Loader Class Initialized
INFO - 2020-02-29 11:41:13 --> Helper loaded: url_helper
ERROR - 2020-02-29 11:41:13 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 11:41:13 --> Config Class Initialized
INFO - 2020-02-29 11:41:13 --> Hooks Class Initialized
ERROR - 2020-02-29 11:41:13 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:41:13 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:13 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-29 11:41:13 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:13 --> Database Driver Class Initialized
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-29 11:41:13 --> Total execution time: 0.3363
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Controller Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
INFO - 2020-02-29 11:41:13 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
INFO - 2020-02-29 11:41:13 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:13 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-29 11:41:13 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 11:41:13 --> Config Class Initialized
INFO - 2020-02-29 11:41:13 --> Hooks Class Initialized
ERROR - 2020-02-29 11:41:13 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:41:13 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-29 11:41:13 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:13 --> Total execution time: 0.3179
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 11:41:13 --> Config Class Initialized
INFO - 2020-02-29 11:41:13 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:13 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:13 --> Language Class Initialized
ERROR - 2020-02-29 11:41:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:41:13 --> Config Class Initialized
INFO - 2020-02-29 11:41:13 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:13 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:13 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:13 --> URI Class Initialized
INFO - 2020-02-29 11:41:13 --> Router Class Initialized
INFO - 2020-02-29 11:41:13 --> Output Class Initialized
INFO - 2020-02-29 11:41:13 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:13 --> Input Class Initialized
INFO - 2020-02-29 11:41:14 --> Language Class Initialized
ERROR - 2020-02-29 11:41:14 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:41:14 --> Config Class Initialized
INFO - 2020-02-29 11:41:14 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:14 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:14 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:14 --> URI Class Initialized
INFO - 2020-02-29 11:41:14 --> Router Class Initialized
INFO - 2020-02-29 11:41:14 --> Output Class Initialized
INFO - 2020-02-29 11:41:14 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:14 --> Input Class Initialized
INFO - 2020-02-29 11:41:14 --> Language Class Initialized
ERROR - 2020-02-29 11:41:14 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 11:41:14 --> Config Class Initialized
INFO - 2020-02-29 11:41:14 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:14 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:14 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:14 --> URI Class Initialized
INFO - 2020-02-29 11:41:14 --> Router Class Initialized
INFO - 2020-02-29 11:41:14 --> Output Class Initialized
INFO - 2020-02-29 11:41:14 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:14 --> Input Class Initialized
INFO - 2020-02-29 11:41:14 --> Language Class Initialized
ERROR - 2020-02-29 11:41:14 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 11:41:14 --> Config Class Initialized
INFO - 2020-02-29 11:41:14 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:14 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:14 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:14 --> URI Class Initialized
INFO - 2020-02-29 11:41:14 --> Router Class Initialized
INFO - 2020-02-29 11:41:14 --> Output Class Initialized
INFO - 2020-02-29 11:41:14 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:14 --> Input Class Initialized
INFO - 2020-02-29 11:41:14 --> Language Class Initialized
ERROR - 2020-02-29 11:41:14 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 11:41:14 --> Config Class Initialized
INFO - 2020-02-29 11:41:14 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:14 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:14 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:14 --> URI Class Initialized
INFO - 2020-02-29 11:41:14 --> Router Class Initialized
INFO - 2020-02-29 11:41:14 --> Output Class Initialized
INFO - 2020-02-29 11:41:14 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:14 --> Input Class Initialized
INFO - 2020-02-29 11:41:14 --> Language Class Initialized
ERROR - 2020-02-29 11:41:14 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 11:41:24 --> Config Class Initialized
INFO - 2020-02-29 11:41:24 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:24 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:24 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:24 --> URI Class Initialized
INFO - 2020-02-29 11:41:24 --> Router Class Initialized
INFO - 2020-02-29 11:41:24 --> Output Class Initialized
INFO - 2020-02-29 11:41:24 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:24 --> Input Class Initialized
INFO - 2020-02-29 11:41:24 --> Language Class Initialized
INFO - 2020-02-29 11:41:24 --> Loader Class Initialized
INFO - 2020-02-29 11:41:24 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:25 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:25 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:25 --> Controller Class Initialized
INFO - 2020-02-29 11:41:25 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:41:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:41:25 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:41:25 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:25 --> Form Validation Class Initialized
INFO - 2020-02-29 17:41:25 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-29 17:41:25 --> Final output sent to browser
DEBUG - 2020-02-29 17:41:25 --> Total execution time: 0.4487
INFO - 2020-02-29 11:41:30 --> Config Class Initialized
INFO - 2020-02-29 11:41:30 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:30 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:30 --> URI Class Initialized
INFO - 2020-02-29 11:41:30 --> Router Class Initialized
INFO - 2020-02-29 11:41:30 --> Output Class Initialized
INFO - 2020-02-29 11:41:30 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:30 --> Input Class Initialized
INFO - 2020-02-29 11:41:30 --> Language Class Initialized
INFO - 2020-02-29 11:41:30 --> Loader Class Initialized
INFO - 2020-02-29 11:41:30 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:30 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:30 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:30 --> Controller Class Initialized
INFO - 2020-02-29 11:41:30 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:41:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:41:30 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:41:30 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:30 --> Form Validation Class Initialized
INFO - 2020-02-29 11:41:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:41:31 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:31 --> Total execution time: 0.3161
INFO - 2020-02-29 11:41:31 --> Config Class Initialized
INFO - 2020-02-29 11:41:31 --> Config Class Initialized
INFO - 2020-02-29 11:41:31 --> Hooks Class Initialized
INFO - 2020-02-29 11:41:31 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:41:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:41:31 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:41:31 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:31 --> Utf8 Class Initialized
INFO - 2020-02-29 11:41:31 --> URI Class Initialized
INFO - 2020-02-29 11:41:31 --> URI Class Initialized
INFO - 2020-02-29 11:41:31 --> Router Class Initialized
INFO - 2020-02-29 11:41:31 --> Router Class Initialized
INFO - 2020-02-29 11:41:31 --> Output Class Initialized
INFO - 2020-02-29 11:41:31 --> Output Class Initialized
INFO - 2020-02-29 11:41:31 --> Security Class Initialized
INFO - 2020-02-29 11:41:31 --> Security Class Initialized
DEBUG - 2020-02-29 11:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:41:31 --> Input Class Initialized
INFO - 2020-02-29 11:41:31 --> Input Class Initialized
INFO - 2020-02-29 11:41:31 --> Language Class Initialized
INFO - 2020-02-29 11:41:31 --> Language Class Initialized
INFO - 2020-02-29 11:41:31 --> Loader Class Initialized
INFO - 2020-02-29 11:41:31 --> Loader Class Initialized
INFO - 2020-02-29 11:41:31 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:31 --> Helper loaded: url_helper
INFO - 2020-02-29 11:41:31 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:31 --> Helper loaded: string_helper
INFO - 2020-02-29 11:41:31 --> Database Driver Class Initialized
INFO - 2020-02-29 11:41:31 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-29 11:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:31 --> Controller Class Initialized
INFO - 2020-02-29 11:41:31 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:41:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:41:31 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:41:31 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:31 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:41:31 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:41:31 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:41:31 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:41:31 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:31 --> Total execution time: 0.3547
INFO - 2020-02-29 11:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:41:31 --> Controller Class Initialized
INFO - 2020-02-29 11:41:31 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:41:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:41:31 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:41:31 --> Helper loaded: form_helper
INFO - 2020-02-29 11:41:31 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:41:31 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:41:31 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:41:31 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:41:31 --> Final output sent to browser
DEBUG - 2020-02-29 11:41:31 --> Total execution time: 0.4961
INFO - 2020-02-29 11:42:03 --> Config Class Initialized
INFO - 2020-02-29 11:42:03 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:42:03 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:42:03 --> Utf8 Class Initialized
INFO - 2020-02-29 11:42:03 --> URI Class Initialized
INFO - 2020-02-29 11:42:03 --> Router Class Initialized
INFO - 2020-02-29 11:42:03 --> Output Class Initialized
INFO - 2020-02-29 11:42:03 --> Security Class Initialized
DEBUG - 2020-02-29 11:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:42:03 --> Input Class Initialized
INFO - 2020-02-29 11:42:03 --> Language Class Initialized
INFO - 2020-02-29 11:42:03 --> Loader Class Initialized
INFO - 2020-02-29 11:42:03 --> Helper loaded: url_helper
INFO - 2020-02-29 11:42:03 --> Helper loaded: string_helper
INFO - 2020-02-29 11:42:03 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:42:03 --> Controller Class Initialized
INFO - 2020-02-29 11:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:42:03 --> Pagination Class Initialized
INFO - 2020-02-29 11:42:03 --> Model "M_show" initialized
INFO - 2020-02-29 11:42:03 --> Helper loaded: form_helper
INFO - 2020-02-29 11:42:03 --> Form Validation Class Initialized
INFO - 2020-02-29 11:42:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:42:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\beli.php
INFO - 2020-02-29 11:42:03 --> Final output sent to browser
DEBUG - 2020-02-29 11:42:03 --> Total execution time: 0.3512
INFO - 2020-02-29 11:45:25 --> Config Class Initialized
INFO - 2020-02-29 11:45:25 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:45:25 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:45:25 --> Utf8 Class Initialized
INFO - 2020-02-29 11:45:25 --> URI Class Initialized
INFO - 2020-02-29 11:45:25 --> Router Class Initialized
INFO - 2020-02-29 11:45:25 --> Output Class Initialized
INFO - 2020-02-29 11:45:25 --> Security Class Initialized
DEBUG - 2020-02-29 11:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:45:25 --> Input Class Initialized
INFO - 2020-02-29 11:45:25 --> Language Class Initialized
INFO - 2020-02-29 11:45:25 --> Loader Class Initialized
INFO - 2020-02-29 11:45:25 --> Helper loaded: url_helper
INFO - 2020-02-29 11:45:25 --> Helper loaded: string_helper
INFO - 2020-02-29 11:45:25 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:45:25 --> Controller Class Initialized
INFO - 2020-02-29 11:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:45:25 --> Pagination Class Initialized
INFO - 2020-02-29 11:45:25 --> Model "M_show" initialized
INFO - 2020-02-29 11:45:25 --> Helper loaded: form_helper
INFO - 2020-02-29 11:45:25 --> Form Validation Class Initialized
INFO - 2020-02-29 11:45:25 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:45:25 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\beli.php
INFO - 2020-02-29 11:45:25 --> Final output sent to browser
DEBUG - 2020-02-29 11:45:25 --> Total execution time: 0.3823
INFO - 2020-02-29 11:45:40 --> Config Class Initialized
INFO - 2020-02-29 11:45:40 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:45:40 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:45:40 --> Utf8 Class Initialized
INFO - 2020-02-29 11:45:40 --> URI Class Initialized
INFO - 2020-02-29 11:45:40 --> Router Class Initialized
INFO - 2020-02-29 11:45:40 --> Output Class Initialized
INFO - 2020-02-29 11:45:40 --> Security Class Initialized
DEBUG - 2020-02-29 11:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:45:40 --> Input Class Initialized
INFO - 2020-02-29 11:45:40 --> Language Class Initialized
INFO - 2020-02-29 11:45:40 --> Loader Class Initialized
INFO - 2020-02-29 11:45:40 --> Helper loaded: url_helper
INFO - 2020-02-29 11:45:40 --> Helper loaded: string_helper
INFO - 2020-02-29 11:45:40 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:45:40 --> Controller Class Initialized
INFO - 2020-02-29 11:45:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:45:40 --> Pagination Class Initialized
INFO - 2020-02-29 11:45:40 --> Model "M_show" initialized
INFO - 2020-02-29 11:45:40 --> Helper loaded: form_helper
INFO - 2020-02-29 11:45:40 --> Form Validation Class Initialized
INFO - 2020-02-29 11:45:40 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:45:40 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\vol1.php
INFO - 2020-02-29 11:45:40 --> Final output sent to browser
DEBUG - 2020-02-29 11:45:40 --> Total execution time: 0.3465
INFO - 2020-02-29 11:45:46 --> Config Class Initialized
INFO - 2020-02-29 11:45:46 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:45:46 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:45:46 --> Utf8 Class Initialized
INFO - 2020-02-29 11:45:46 --> URI Class Initialized
INFO - 2020-02-29 11:45:46 --> Router Class Initialized
INFO - 2020-02-29 11:45:46 --> Output Class Initialized
INFO - 2020-02-29 11:45:46 --> Security Class Initialized
DEBUG - 2020-02-29 11:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:45:46 --> Input Class Initialized
INFO - 2020-02-29 11:45:46 --> Language Class Initialized
INFO - 2020-02-29 11:45:46 --> Loader Class Initialized
INFO - 2020-02-29 11:45:47 --> Helper loaded: url_helper
INFO - 2020-02-29 11:45:47 --> Helper loaded: string_helper
INFO - 2020-02-29 11:45:47 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:45:47 --> Controller Class Initialized
INFO - 2020-02-29 11:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 11:45:47 --> Pagination Class Initialized
INFO - 2020-02-29 11:45:47 --> Model "M_show" initialized
INFO - 2020-02-29 11:45:47 --> Helper loaded: form_helper
INFO - 2020-02-29 11:45:47 --> Form Validation Class Initialized
INFO - 2020-02-29 11:45:47 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\header/header.php
INFO - 2020-02-29 11:45:47 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\beli.php
INFO - 2020-02-29 11:45:47 --> Final output sent to browser
DEBUG - 2020-02-29 11:45:47 --> Total execution time: 0.3322
INFO - 2020-02-29 11:48:36 --> Config Class Initialized
INFO - 2020-02-29 11:48:36 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:48:36 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:48:36 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:36 --> URI Class Initialized
INFO - 2020-02-29 11:48:36 --> Router Class Initialized
INFO - 2020-02-29 11:48:36 --> Output Class Initialized
INFO - 2020-02-29 11:48:36 --> Security Class Initialized
DEBUG - 2020-02-29 11:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:48:36 --> Input Class Initialized
INFO - 2020-02-29 11:48:36 --> Language Class Initialized
INFO - 2020-02-29 11:48:36 --> Loader Class Initialized
INFO - 2020-02-29 11:48:37 --> Helper loaded: url_helper
INFO - 2020-02-29 11:48:37 --> Helper loaded: string_helper
INFO - 2020-02-29 11:48:37 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:48:37 --> Controller Class Initialized
INFO - 2020-02-29 11:48:37 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:48:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:48:37 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:48:37 --> Helper loaded: form_helper
INFO - 2020-02-29 11:48:37 --> Form Validation Class Initialized
INFO - 2020-02-29 11:48:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:48:37 --> Final output sent to browser
DEBUG - 2020-02-29 11:48:37 --> Total execution time: 0.3282
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
ERROR - 2020-02-29 11:48:37 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:48:37 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-29 11:48:37 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-29 11:48:37 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-29 11:48:37 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-29 11:48:37 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
ERROR - 2020-02-29 11:48:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-29 11:48:37 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-29 11:48:37 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:48:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-29 11:48:37 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 11:48:37 --> Loader Class Initialized
INFO - 2020-02-29 11:48:37 --> Helper loaded: url_helper
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
INFO - 2020-02-29 11:48:37 --> Helper loaded: string_helper
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:48:37 --> Database Driver Class Initialized
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
DEBUG - 2020-02-29 11:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Controller Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
INFO - 2020-02-29 11:48:37 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
INFO - 2020-02-29 11:48:37 --> Helper loaded: form_helper
INFO - 2020-02-29 11:48:37 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:48:37 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-29 11:48:37 --> Loader Class Initialized
INFO - 2020-02-29 11:48:37 --> Helper loaded: url_helper
ERROR - 2020-02-29 11:48:37 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
INFO - 2020-02-29 11:48:37 --> Helper loaded: string_helper
ERROR - 2020-02-29 11:48:37 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:48:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:48:37 --> Database Driver Class Initialized
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> Final output sent to browser
DEBUG - 2020-02-29 11:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-29 11:48:37 --> Total execution time: 0.3472
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Controller Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
INFO - 2020-02-29 11:48:37 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:37 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:48:37 --> Language Class Initialized
INFO - 2020-02-29 11:48:37 --> Helper loaded: form_helper
INFO - 2020-02-29 11:48:37 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:48:37 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 11:48:37 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 11:48:37 --> Config Class Initialized
INFO - 2020-02-29 11:48:37 --> Hooks Class Initialized
ERROR - 2020-02-29 11:48:37 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:48:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-29 11:48:37 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:48:37 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:37 --> Final output sent to browser
DEBUG - 2020-02-29 11:48:37 --> Total execution time: 0.3446
INFO - 2020-02-29 11:48:37 --> URI Class Initialized
INFO - 2020-02-29 11:48:37 --> Router Class Initialized
INFO - 2020-02-29 11:48:37 --> Output Class Initialized
INFO - 2020-02-29 11:48:37 --> Security Class Initialized
DEBUG - 2020-02-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:48:37 --> Input Class Initialized
INFO - 2020-02-29 11:48:38 --> Language Class Initialized
ERROR - 2020-02-29 11:48:38 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 11:48:38 --> Config Class Initialized
INFO - 2020-02-29 11:48:38 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:48:38 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:48:38 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:38 --> URI Class Initialized
INFO - 2020-02-29 11:48:38 --> Router Class Initialized
INFO - 2020-02-29 11:48:38 --> Output Class Initialized
INFO - 2020-02-29 11:48:38 --> Security Class Initialized
DEBUG - 2020-02-29 11:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:48:38 --> Input Class Initialized
INFO - 2020-02-29 11:48:38 --> Language Class Initialized
ERROR - 2020-02-29 11:48:38 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 11:48:38 --> Config Class Initialized
INFO - 2020-02-29 11:48:38 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:48:38 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:48:38 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:38 --> URI Class Initialized
INFO - 2020-02-29 11:48:38 --> Router Class Initialized
INFO - 2020-02-29 11:48:38 --> Output Class Initialized
INFO - 2020-02-29 11:48:38 --> Security Class Initialized
DEBUG - 2020-02-29 11:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:48:38 --> Input Class Initialized
INFO - 2020-02-29 11:48:38 --> Language Class Initialized
ERROR - 2020-02-29 11:48:38 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:48:38 --> Config Class Initialized
INFO - 2020-02-29 11:48:38 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:48:38 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:48:38 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:38 --> URI Class Initialized
INFO - 2020-02-29 11:48:38 --> Router Class Initialized
INFO - 2020-02-29 11:48:38 --> Output Class Initialized
INFO - 2020-02-29 11:48:38 --> Security Class Initialized
DEBUG - 2020-02-29 11:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:48:38 --> Input Class Initialized
INFO - 2020-02-29 11:48:38 --> Language Class Initialized
ERROR - 2020-02-29 11:48:38 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:48:38 --> Config Class Initialized
INFO - 2020-02-29 11:48:38 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:48:38 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:48:38 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:38 --> URI Class Initialized
INFO - 2020-02-29 11:48:38 --> Router Class Initialized
INFO - 2020-02-29 11:48:38 --> Output Class Initialized
INFO - 2020-02-29 11:48:38 --> Security Class Initialized
DEBUG - 2020-02-29 11:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:48:38 --> Input Class Initialized
INFO - 2020-02-29 11:48:38 --> Language Class Initialized
ERROR - 2020-02-29 11:48:38 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 11:48:38 --> Config Class Initialized
INFO - 2020-02-29 11:48:38 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:48:38 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:48:38 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:38 --> URI Class Initialized
INFO - 2020-02-29 11:48:38 --> Router Class Initialized
INFO - 2020-02-29 11:48:38 --> Output Class Initialized
INFO - 2020-02-29 11:48:38 --> Security Class Initialized
DEBUG - 2020-02-29 11:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:48:38 --> Input Class Initialized
INFO - 2020-02-29 11:48:38 --> Language Class Initialized
ERROR - 2020-02-29 11:48:38 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 11:48:38 --> Config Class Initialized
INFO - 2020-02-29 11:48:38 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:48:38 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:48:38 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:38 --> URI Class Initialized
INFO - 2020-02-29 11:48:38 --> Router Class Initialized
INFO - 2020-02-29 11:48:38 --> Output Class Initialized
INFO - 2020-02-29 11:48:38 --> Security Class Initialized
DEBUG - 2020-02-29 11:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:48:38 --> Input Class Initialized
INFO - 2020-02-29 11:48:38 --> Language Class Initialized
ERROR - 2020-02-29 11:48:39 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 11:48:39 --> Config Class Initialized
INFO - 2020-02-29 11:48:39 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:48:39 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:48:39 --> Utf8 Class Initialized
INFO - 2020-02-29 11:48:39 --> URI Class Initialized
INFO - 2020-02-29 11:48:39 --> Router Class Initialized
INFO - 2020-02-29 11:48:39 --> Output Class Initialized
INFO - 2020-02-29 11:48:39 --> Security Class Initialized
DEBUG - 2020-02-29 11:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:48:39 --> Input Class Initialized
INFO - 2020-02-29 11:48:39 --> Language Class Initialized
ERROR - 2020-02-29 11:48:39 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 11:53:14 --> Config Class Initialized
INFO - 2020-02-29 11:53:14 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:53:14 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:53:14 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:14 --> URI Class Initialized
INFO - 2020-02-29 11:53:14 --> Router Class Initialized
INFO - 2020-02-29 11:53:14 --> Output Class Initialized
INFO - 2020-02-29 11:53:14 --> Security Class Initialized
DEBUG - 2020-02-29 11:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:14 --> Input Class Initialized
INFO - 2020-02-29 11:53:14 --> Language Class Initialized
INFO - 2020-02-29 11:53:14 --> Loader Class Initialized
INFO - 2020-02-29 11:53:14 --> Helper loaded: url_helper
INFO - 2020-02-29 11:53:14 --> Helper loaded: string_helper
INFO - 2020-02-29 11:53:14 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:53:14 --> Controller Class Initialized
INFO - 2020-02-29 11:53:14 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:53:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:53:14 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:53:14 --> Helper loaded: form_helper
INFO - 2020-02-29 11:53:14 --> Form Validation Class Initialized
INFO - 2020-02-29 11:53:14 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:53:14 --> Final output sent to browser
DEBUG - 2020-02-29 11:53:14 --> Total execution time: 0.4346
INFO - 2020-02-29 11:53:14 --> Config Class Initialized
INFO - 2020-02-29 11:53:14 --> Config Class Initialized
INFO - 2020-02-29 11:53:14 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:14 --> Config Class Initialized
INFO - 2020-02-29 11:53:14 --> Config Class Initialized
INFO - 2020-02-29 11:53:14 --> Config Class Initialized
INFO - 2020-02-29 11:53:14 --> Config Class Initialized
INFO - 2020-02-29 11:53:14 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:14 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:14 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:14 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:14 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:53:14 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 11:53:15 --> Config Class Initialized
INFO - 2020-02-29 11:53:15 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:15 --> Config Class Initialized
INFO - 2020-02-29 11:53:15 --> Config Class Initialized
INFO - 2020-02-29 11:53:15 --> Config Class Initialized
INFO - 2020-02-29 11:53:15 --> Config Class Initialized
INFO - 2020-02-29 11:53:15 --> Config Class Initialized
INFO - 2020-02-29 11:53:15 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:15 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:15 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:15 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:15 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 11:53:15 --> Loader Class Initialized
INFO - 2020-02-29 11:53:15 --> Config Class Initialized
INFO - 2020-02-29 11:53:15 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:15 --> Helper loaded: url_helper
INFO - 2020-02-29 11:53:15 --> Config Class Initialized
INFO - 2020-02-29 11:53:15 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:15 --> Helper loaded: string_helper
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:53:15 --> Database Driver Class Initialized
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
DEBUG - 2020-02-29 11:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Controller Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Model "M_pesan" initialized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
INFO - 2020-02-29 11:53:15 --> Helper loaded: form_helper
INFO - 2020-02-29 11:53:15 --> Form Validation Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
INFO - 2020-02-29 11:53:15 --> Loader Class Initialized
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 11:53:15 --> Helper loaded: url_helper
ERROR - 2020-02-29 11:53:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 11:53:15 --> Helper loaded: string_helper
ERROR - 2020-02-29 11:53:15 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:53:15 --> Config Class Initialized
INFO - 2020-02-29 11:53:15 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:53:15 --> Database Driver Class Initialized
INFO - 2020-02-29 11:53:15 --> Final output sent to browser
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
DEBUG - 2020-02-29 11:53:15 --> Total execution time: 0.3444
INFO - 2020-02-29 11:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> Controller Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
INFO - 2020-02-29 11:53:15 --> Model "M_pesan" initialized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Helper loaded: form_helper
INFO - 2020-02-29 11:53:15 --> Form Validation Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 11:53:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:53:15 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:53:15 --> Config Class Initialized
INFO - 2020-02-29 11:53:15 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:53:15 --> Final output sent to browser
DEBUG - 2020-02-29 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:53:15 --> Total execution time: 0.3429
INFO - 2020-02-29 11:53:15 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:15 --> URI Class Initialized
INFO - 2020-02-29 11:53:15 --> Router Class Initialized
INFO - 2020-02-29 11:53:15 --> Output Class Initialized
INFO - 2020-02-29 11:53:15 --> Security Class Initialized
DEBUG - 2020-02-29 11:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:15 --> Input Class Initialized
INFO - 2020-02-29 11:53:15 --> Language Class Initialized
ERROR - 2020-02-29 11:53:15 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 11:53:18 --> Config Class Initialized
INFO - 2020-02-29 11:53:18 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:53:18 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:53:18 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:18 --> URI Class Initialized
INFO - 2020-02-29 11:53:18 --> Router Class Initialized
INFO - 2020-02-29 11:53:18 --> Output Class Initialized
INFO - 2020-02-29 11:53:18 --> Security Class Initialized
DEBUG - 2020-02-29 11:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:18 --> Input Class Initialized
INFO - 2020-02-29 11:53:18 --> Language Class Initialized
ERROR - 2020-02-29 11:53:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 11:53:18 --> Config Class Initialized
INFO - 2020-02-29 11:53:18 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:53:19 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:53:19 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:19 --> URI Class Initialized
INFO - 2020-02-29 11:53:19 --> Router Class Initialized
INFO - 2020-02-29 11:53:19 --> Output Class Initialized
INFO - 2020-02-29 11:53:19 --> Security Class Initialized
DEBUG - 2020-02-29 11:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:19 --> Input Class Initialized
INFO - 2020-02-29 11:53:19 --> Language Class Initialized
ERROR - 2020-02-29 11:53:19 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 11:53:19 --> Config Class Initialized
INFO - 2020-02-29 11:53:19 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:53:19 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:53:19 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:19 --> URI Class Initialized
INFO - 2020-02-29 11:53:19 --> Router Class Initialized
INFO - 2020-02-29 11:53:19 --> Output Class Initialized
INFO - 2020-02-29 11:53:19 --> Security Class Initialized
DEBUG - 2020-02-29 11:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:19 --> Input Class Initialized
INFO - 2020-02-29 11:53:19 --> Language Class Initialized
ERROR - 2020-02-29 11:53:19 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 11:53:22 --> Config Class Initialized
INFO - 2020-02-29 11:53:22 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:53:22 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:53:22 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:22 --> URI Class Initialized
INFO - 2020-02-29 11:53:22 --> Router Class Initialized
INFO - 2020-02-29 11:53:22 --> Output Class Initialized
INFO - 2020-02-29 11:53:22 --> Security Class Initialized
DEBUG - 2020-02-29 11:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:22 --> Input Class Initialized
INFO - 2020-02-29 11:53:22 --> Language Class Initialized
INFO - 2020-02-29 11:53:22 --> Loader Class Initialized
INFO - 2020-02-29 11:53:22 --> Helper loaded: url_helper
INFO - 2020-02-29 11:53:22 --> Helper loaded: string_helper
INFO - 2020-02-29 11:53:22 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:53:22 --> Controller Class Initialized
INFO - 2020-02-29 11:53:22 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:53:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:53:22 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:53:22 --> Helper loaded: form_helper
INFO - 2020-02-29 11:53:22 --> Form Validation Class Initialized
ERROR - 2020-02-29 17:53:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\roadshow-2\application\views\Pemesanan\konfirm_bayar.php 5
INFO - 2020-02-29 17:53:23 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-29 17:53:23 --> Final output sent to browser
DEBUG - 2020-02-29 17:53:23 --> Total execution time: 1.5065
INFO - 2020-02-29 11:53:29 --> Config Class Initialized
INFO - 2020-02-29 11:53:29 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:53:29 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:53:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:29 --> URI Class Initialized
INFO - 2020-02-29 11:53:29 --> Router Class Initialized
INFO - 2020-02-29 11:53:29 --> Output Class Initialized
INFO - 2020-02-29 11:53:29 --> Security Class Initialized
DEBUG - 2020-02-29 11:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:29 --> Input Class Initialized
INFO - 2020-02-29 11:53:29 --> Language Class Initialized
INFO - 2020-02-29 11:53:29 --> Loader Class Initialized
INFO - 2020-02-29 11:53:29 --> Helper loaded: url_helper
INFO - 2020-02-29 11:53:29 --> Helper loaded: string_helper
INFO - 2020-02-29 11:53:29 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:53:29 --> Controller Class Initialized
INFO - 2020-02-29 11:53:29 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:53:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:53:29 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:53:29 --> Helper loaded: form_helper
INFO - 2020-02-29 11:53:29 --> Form Validation Class Initialized
INFO - 2020-02-29 11:53:29 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:53:29 --> Final output sent to browser
DEBUG - 2020-02-29 11:53:29 --> Total execution time: 0.3403
INFO - 2020-02-29 11:53:29 --> Config Class Initialized
INFO - 2020-02-29 11:53:29 --> Config Class Initialized
INFO - 2020-02-29 11:53:29 --> Hooks Class Initialized
INFO - 2020-02-29 11:53:29 --> Hooks Class Initialized
DEBUG - 2020-02-29 11:53:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 11:53:29 --> UTF-8 Support Enabled
INFO - 2020-02-29 11:53:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:29 --> Utf8 Class Initialized
INFO - 2020-02-29 11:53:29 --> URI Class Initialized
INFO - 2020-02-29 11:53:29 --> URI Class Initialized
INFO - 2020-02-29 11:53:29 --> Router Class Initialized
INFO - 2020-02-29 11:53:29 --> Router Class Initialized
INFO - 2020-02-29 11:53:29 --> Output Class Initialized
INFO - 2020-02-29 11:53:29 --> Output Class Initialized
INFO - 2020-02-29 11:53:30 --> Security Class Initialized
INFO - 2020-02-29 11:53:30 --> Security Class Initialized
DEBUG - 2020-02-29 11:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 11:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 11:53:30 --> Input Class Initialized
INFO - 2020-02-29 11:53:30 --> Input Class Initialized
INFO - 2020-02-29 11:53:30 --> Language Class Initialized
INFO - 2020-02-29 11:53:30 --> Language Class Initialized
INFO - 2020-02-29 11:53:30 --> Loader Class Initialized
INFO - 2020-02-29 11:53:30 --> Loader Class Initialized
INFO - 2020-02-29 11:53:30 --> Helper loaded: url_helper
INFO - 2020-02-29 11:53:30 --> Helper loaded: url_helper
INFO - 2020-02-29 11:53:30 --> Helper loaded: string_helper
INFO - 2020-02-29 11:53:30 --> Helper loaded: string_helper
INFO - 2020-02-29 11:53:30 --> Database Driver Class Initialized
INFO - 2020-02-29 11:53:30 --> Database Driver Class Initialized
DEBUG - 2020-02-29 11:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-29 11:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 11:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:53:30 --> Controller Class Initialized
INFO - 2020-02-29 11:53:30 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:53:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:53:30 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:53:30 --> Helper loaded: form_helper
INFO - 2020-02-29 11:53:30 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:53:30 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:53:30 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:53:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:53:30 --> Final output sent to browser
DEBUG - 2020-02-29 11:53:30 --> Total execution time: 0.3700
INFO - 2020-02-29 11:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 11:53:30 --> Controller Class Initialized
INFO - 2020-02-29 11:53:30 --> Model "M_tiket" initialized
INFO - 2020-02-29 11:53:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 11:53:30 --> Model "M_pesan" initialized
INFO - 2020-02-29 11:53:30 --> Helper loaded: form_helper
INFO - 2020-02-29 11:53:30 --> Form Validation Class Initialized
ERROR - 2020-02-29 11:53:30 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 11:53:30 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 11:53:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 11:53:30 --> Final output sent to browser
DEBUG - 2020-02-29 11:53:30 --> Total execution time: 0.5333
INFO - 2020-02-29 16:23:45 --> Config Class Initialized
INFO - 2020-02-29 16:23:45 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:23:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:23:45 --> Utf8 Class Initialized
INFO - 2020-02-29 16:23:45 --> URI Class Initialized
DEBUG - 2020-02-29 16:23:45 --> No URI present. Default controller set.
INFO - 2020-02-29 16:23:45 --> Router Class Initialized
INFO - 2020-02-29 16:23:45 --> Output Class Initialized
INFO - 2020-02-29 16:23:45 --> Security Class Initialized
DEBUG - 2020-02-29 16:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:23:45 --> Input Class Initialized
INFO - 2020-02-29 16:23:45 --> Language Class Initialized
INFO - 2020-02-29 16:23:45 --> Loader Class Initialized
INFO - 2020-02-29 16:23:45 --> Helper loaded: url_helper
INFO - 2020-02-29 16:23:45 --> Helper loaded: string_helper
INFO - 2020-02-29 16:23:46 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:23:46 --> Controller Class Initialized
INFO - 2020-02-29 16:23:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 16:23:46 --> Pagination Class Initialized
INFO - 2020-02-29 16:23:46 --> Model "M_show" initialized
INFO - 2020-02-29 16:23:46 --> Helper loaded: form_helper
INFO - 2020-02-29 16:23:46 --> Form Validation Class Initialized
INFO - 2020-02-29 16:23:46 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\header/header.php
INFO - 2020-02-29 16:23:46 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\home.php
INFO - 2020-02-29 16:23:46 --> Final output sent to browser
DEBUG - 2020-02-29 16:23:46 --> Total execution time: 1.0990
INFO - 2020-02-29 16:24:01 --> Config Class Initialized
INFO - 2020-02-29 16:24:01 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:01 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:01 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:01 --> URI Class Initialized
INFO - 2020-02-29 16:24:01 --> Router Class Initialized
INFO - 2020-02-29 16:24:01 --> Output Class Initialized
INFO - 2020-02-29 16:24:01 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:01 --> Input Class Initialized
INFO - 2020-02-29 16:24:01 --> Language Class Initialized
INFO - 2020-02-29 16:24:01 --> Loader Class Initialized
INFO - 2020-02-29 16:24:01 --> Helper loaded: url_helper
INFO - 2020-02-29 16:24:01 --> Helper loaded: string_helper
INFO - 2020-02-29 16:24:01 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:24:01 --> Controller Class Initialized
INFO - 2020-02-29 16:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 16:24:01 --> Pagination Class Initialized
INFO - 2020-02-29 16:24:01 --> Model "M_show" initialized
INFO - 2020-02-29 16:24:01 --> Helper loaded: form_helper
INFO - 2020-02-29 16:24:01 --> Form Validation Class Initialized
INFO - 2020-02-29 16:24:01 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\header/header.php
INFO - 2020-02-29 16:24:01 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\home.php
INFO - 2020-02-29 16:24:01 --> Final output sent to browser
DEBUG - 2020-02-29 16:24:01 --> Total execution time: 0.5838
INFO - 2020-02-29 16:24:07 --> Config Class Initialized
INFO - 2020-02-29 16:24:08 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:08 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:08 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:08 --> URI Class Initialized
INFO - 2020-02-29 16:24:08 --> Router Class Initialized
INFO - 2020-02-29 16:24:08 --> Output Class Initialized
INFO - 2020-02-29 16:24:08 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:08 --> Input Class Initialized
INFO - 2020-02-29 16:24:08 --> Language Class Initialized
INFO - 2020-02-29 16:24:08 --> Loader Class Initialized
INFO - 2020-02-29 16:24:08 --> Helper loaded: url_helper
INFO - 2020-02-29 16:24:08 --> Helper loaded: string_helper
INFO - 2020-02-29 16:24:08 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:24:08 --> Controller Class Initialized
INFO - 2020-02-29 16:24:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 16:24:08 --> Pagination Class Initialized
INFO - 2020-02-29 16:24:08 --> Model "M_show" initialized
INFO - 2020-02-29 16:24:08 --> Helper loaded: form_helper
INFO - 2020-02-29 16:24:08 --> Form Validation Class Initialized
INFO - 2020-02-29 16:24:08 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\header/header.php
INFO - 2020-02-29 16:24:08 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\beli.php
INFO - 2020-02-29 16:24:08 --> Final output sent to browser
DEBUG - 2020-02-29 16:24:08 --> Total execution time: 0.7051
INFO - 2020-02-29 16:24:15 --> Config Class Initialized
INFO - 2020-02-29 16:24:15 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:15 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:15 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:16 --> URI Class Initialized
INFO - 2020-02-29 16:24:16 --> Router Class Initialized
INFO - 2020-02-29 16:24:16 --> Output Class Initialized
INFO - 2020-02-29 16:24:16 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:16 --> Input Class Initialized
INFO - 2020-02-29 16:24:16 --> Language Class Initialized
INFO - 2020-02-29 16:24:16 --> Loader Class Initialized
INFO - 2020-02-29 16:24:16 --> Helper loaded: url_helper
INFO - 2020-02-29 16:24:16 --> Helper loaded: string_helper
INFO - 2020-02-29 16:24:16 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:24:16 --> Controller Class Initialized
INFO - 2020-02-29 16:24:16 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:24:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:24:16 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:24:16 --> Helper loaded: form_helper
INFO - 2020-02-29 16:24:16 --> Form Validation Class Initialized
INFO - 2020-02-29 16:24:16 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:24:16 --> Final output sent to browser
DEBUG - 2020-02-29 16:24:16 --> Total execution time: 0.9976
INFO - 2020-02-29 16:24:17 --> Config Class Initialized
INFO - 2020-02-29 16:24:17 --> Config Class Initialized
INFO - 2020-02-29 16:24:17 --> Config Class Initialized
INFO - 2020-02-29 16:24:17 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:17 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:17 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:17 --> Config Class Initialized
INFO - 2020-02-29 16:24:17 --> Config Class Initialized
INFO - 2020-02-29 16:24:17 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:17 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:17 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:17 --> Config Class Initialized
INFO - 2020-02-29 16:24:17 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:17 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:17 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:17 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:17 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:17 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:17 --> URI Class Initialized
INFO - 2020-02-29 16:24:17 --> URI Class Initialized
INFO - 2020-02-29 16:24:17 --> URI Class Initialized
INFO - 2020-02-29 16:24:17 --> URI Class Initialized
INFO - 2020-02-29 16:24:17 --> URI Class Initialized
DEBUG - 2020-02-29 16:24:17 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:17 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:17 --> Router Class Initialized
INFO - 2020-02-29 16:24:17 --> Router Class Initialized
INFO - 2020-02-29 16:24:17 --> Router Class Initialized
INFO - 2020-02-29 16:24:17 --> Router Class Initialized
INFO - 2020-02-29 16:24:17 --> Router Class Initialized
INFO - 2020-02-29 16:24:17 --> Output Class Initialized
INFO - 2020-02-29 16:24:17 --> Output Class Initialized
INFO - 2020-02-29 16:24:17 --> Output Class Initialized
INFO - 2020-02-29 16:24:17 --> Output Class Initialized
INFO - 2020-02-29 16:24:17 --> Output Class Initialized
INFO - 2020-02-29 16:24:17 --> URI Class Initialized
INFO - 2020-02-29 16:24:17 --> Security Class Initialized
INFO - 2020-02-29 16:24:17 --> Security Class Initialized
INFO - 2020-02-29 16:24:17 --> Security Class Initialized
INFO - 2020-02-29 16:24:17 --> Security Class Initialized
INFO - 2020-02-29 16:24:17 --> Security Class Initialized
INFO - 2020-02-29 16:24:17 --> Router Class Initialized
DEBUG - 2020-02-29 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:17 --> Output Class Initialized
DEBUG - 2020-02-29 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:17 --> Input Class Initialized
INFO - 2020-02-29 16:24:17 --> Input Class Initialized
INFO - 2020-02-29 16:24:17 --> Input Class Initialized
INFO - 2020-02-29 16:24:17 --> Input Class Initialized
INFO - 2020-02-29 16:24:17 --> Input Class Initialized
INFO - 2020-02-29 16:24:17 --> Security Class Initialized
INFO - 2020-02-29 16:24:17 --> Language Class Initialized
INFO - 2020-02-29 16:24:17 --> Language Class Initialized
INFO - 2020-02-29 16:24:17 --> Language Class Initialized
INFO - 2020-02-29 16:24:17 --> Language Class Initialized
DEBUG - 2020-02-29 16:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:17 --> Language Class Initialized
INFO - 2020-02-29 16:24:17 --> Input Class Initialized
INFO - 2020-02-29 16:24:17 --> Language Class Initialized
ERROR - 2020-02-29 16:24:17 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 16:24:17 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-29 16:24:17 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-29 16:24:17 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-29 16:24:17 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 16:24:17 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 16:24:17 --> Config Class Initialized
INFO - 2020-02-29 16:24:17 --> Config Class Initialized
INFO - 2020-02-29 16:24:17 --> Config Class Initialized
INFO - 2020-02-29 16:24:17 --> Config Class Initialized
INFO - 2020-02-29 16:24:17 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:17 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:17 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:17 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:17 --> Config Class Initialized
INFO - 2020-02-29 16:24:17 --> Config Class Initialized
INFO - 2020-02-29 16:24:17 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:17 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:17 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:17 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:17 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:17 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:17 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:17 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:17 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:17 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:17 --> URI Class Initialized
INFO - 2020-02-29 16:24:17 --> URI Class Initialized
INFO - 2020-02-29 16:24:17 --> URI Class Initialized
INFO - 2020-02-29 16:24:17 --> URI Class Initialized
INFO - 2020-02-29 16:24:17 --> URI Class Initialized
INFO - 2020-02-29 16:24:17 --> URI Class Initialized
INFO - 2020-02-29 16:24:17 --> Router Class Initialized
INFO - 2020-02-29 16:24:17 --> Router Class Initialized
INFO - 2020-02-29 16:24:17 --> Router Class Initialized
INFO - 2020-02-29 16:24:17 --> Router Class Initialized
INFO - 2020-02-29 16:24:17 --> Output Class Initialized
INFO - 2020-02-29 16:24:17 --> Output Class Initialized
INFO - 2020-02-29 16:24:17 --> Output Class Initialized
INFO - 2020-02-29 16:24:17 --> Router Class Initialized
INFO - 2020-02-29 16:24:17 --> Output Class Initialized
INFO - 2020-02-29 16:24:17 --> Router Class Initialized
INFO - 2020-02-29 16:24:17 --> Security Class Initialized
INFO - 2020-02-29 16:24:17 --> Security Class Initialized
INFO - 2020-02-29 16:24:17 --> Security Class Initialized
INFO - 2020-02-29 16:24:17 --> Output Class Initialized
INFO - 2020-02-29 16:24:17 --> Security Class Initialized
INFO - 2020-02-29 16:24:17 --> Output Class Initialized
DEBUG - 2020-02-29 16:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:17 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:17 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:17 --> Input Class Initialized
INFO - 2020-02-29 16:24:17 --> Input Class Initialized
INFO - 2020-02-29 16:24:17 --> Input Class Initialized
INFO - 2020-02-29 16:24:17 --> Input Class Initialized
DEBUG - 2020-02-29 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:17 --> Input Class Initialized
INFO - 2020-02-29 16:24:17 --> Input Class Initialized
INFO - 2020-02-29 16:24:17 --> Language Class Initialized
INFO - 2020-02-29 16:24:17 --> Language Class Initialized
INFO - 2020-02-29 16:24:17 --> Language Class Initialized
INFO - 2020-02-29 16:24:17 --> Language Class Initialized
INFO - 2020-02-29 16:24:17 --> Language Class Initialized
INFO - 2020-02-29 16:24:17 --> Language Class Initialized
ERROR - 2020-02-29 16:24:17 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-29 16:24:17 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-29 16:24:17 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 16:24:17 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-29 16:24:17 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 16:24:17 --> Loader Class Initialized
INFO - 2020-02-29 16:24:17 --> Config Class Initialized
INFO - 2020-02-29 16:24:18 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:18 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:18 --> Helper loaded: url_helper
INFO - 2020-02-29 16:24:18 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:18 --> Helper loaded: string_helper
INFO - 2020-02-29 16:24:18 --> URI Class Initialized
INFO - 2020-02-29 16:24:18 --> Router Class Initialized
INFO - 2020-02-29 16:24:18 --> Database Driver Class Initialized
INFO - 2020-02-29 16:24:18 --> Output Class Initialized
DEBUG - 2020-02-29 16:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:24:18 --> Security Class Initialized
INFO - 2020-02-29 16:24:18 --> Controller Class Initialized
INFO - 2020-02-29 16:24:18 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:24:18 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 16:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:18 --> Input Class Initialized
INFO - 2020-02-29 16:24:18 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:24:18 --> Language Class Initialized
INFO - 2020-02-29 16:24:18 --> Helper loaded: form_helper
INFO - 2020-02-29 16:24:18 --> Form Validation Class Initialized
INFO - 2020-02-29 16:24:18 --> Loader Class Initialized
INFO - 2020-02-29 16:24:18 --> Helper loaded: url_helper
INFO - 2020-02-29 16:24:18 --> Helper loaded: string_helper
ERROR - 2020-02-29 16:24:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 16:24:18 --> Database Driver Class Initialized
ERROR - 2020-02-29 16:24:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
DEBUG - 2020-02-29 16:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:24:18 --> Config Class Initialized
INFO - 2020-02-29 16:24:18 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:24:18 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:18 --> Final output sent to browser
DEBUG - 2020-02-29 16:24:18 --> Total execution time: 1.2002
DEBUG - 2020-02-29 16:24:18 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:18 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:24:18 --> Controller Class Initialized
INFO - 2020-02-29 16:24:18 --> URI Class Initialized
INFO - 2020-02-29 16:24:18 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:24:18 --> Router Class Initialized
INFO - 2020-02-29 16:24:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:24:18 --> Output Class Initialized
INFO - 2020-02-29 16:24:18 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:24:18 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:19 --> Helper loaded: form_helper
INFO - 2020-02-29 16:24:19 --> Input Class Initialized
INFO - 2020-02-29 16:24:19 --> Form Validation Class Initialized
INFO - 2020-02-29 16:24:19 --> Language Class Initialized
ERROR - 2020-02-29 16:24:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 16:24:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-29 16:24:19 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 16:24:19 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:24:19 --> Config Class Initialized
INFO - 2020-02-29 16:24:19 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:19 --> Final output sent to browser
DEBUG - 2020-02-29 16:24:19 --> Total execution time: 1.2045
DEBUG - 2020-02-29 16:24:19 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:19 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:19 --> URI Class Initialized
INFO - 2020-02-29 16:24:19 --> Router Class Initialized
INFO - 2020-02-29 16:24:19 --> Output Class Initialized
INFO - 2020-02-29 16:24:19 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:19 --> Input Class Initialized
INFO - 2020-02-29 16:24:19 --> Language Class Initialized
ERROR - 2020-02-29 16:24:19 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 16:24:19 --> Config Class Initialized
INFO - 2020-02-29 16:24:19 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:19 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:19 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:19 --> URI Class Initialized
INFO - 2020-02-29 16:24:19 --> Router Class Initialized
INFO - 2020-02-29 16:24:19 --> Output Class Initialized
INFO - 2020-02-29 16:24:19 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:19 --> Input Class Initialized
INFO - 2020-02-29 16:24:19 --> Language Class Initialized
ERROR - 2020-02-29 16:24:19 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 16:24:20 --> Config Class Initialized
INFO - 2020-02-29 16:24:20 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:20 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:20 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:20 --> URI Class Initialized
INFO - 2020-02-29 16:24:20 --> Router Class Initialized
INFO - 2020-02-29 16:24:20 --> Output Class Initialized
INFO - 2020-02-29 16:24:20 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:20 --> Input Class Initialized
INFO - 2020-02-29 16:24:20 --> Language Class Initialized
ERROR - 2020-02-29 16:24:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:24:20 --> Config Class Initialized
INFO - 2020-02-29 16:24:20 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:20 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:20 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:20 --> URI Class Initialized
INFO - 2020-02-29 16:24:20 --> Router Class Initialized
INFO - 2020-02-29 16:24:20 --> Output Class Initialized
INFO - 2020-02-29 16:24:20 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:20 --> Input Class Initialized
INFO - 2020-02-29 16:24:20 --> Language Class Initialized
ERROR - 2020-02-29 16:24:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:24:20 --> Config Class Initialized
INFO - 2020-02-29 16:24:20 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:20 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:20 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:21 --> URI Class Initialized
INFO - 2020-02-29 16:24:21 --> Router Class Initialized
INFO - 2020-02-29 16:24:21 --> Output Class Initialized
INFO - 2020-02-29 16:24:21 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:21 --> Input Class Initialized
INFO - 2020-02-29 16:24:21 --> Language Class Initialized
ERROR - 2020-02-29 16:24:21 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 16:24:21 --> Config Class Initialized
INFO - 2020-02-29 16:24:21 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:21 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:21 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:21 --> URI Class Initialized
INFO - 2020-02-29 16:24:21 --> Router Class Initialized
INFO - 2020-02-29 16:24:21 --> Output Class Initialized
INFO - 2020-02-29 16:24:21 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:21 --> Input Class Initialized
INFO - 2020-02-29 16:24:21 --> Language Class Initialized
ERROR - 2020-02-29 16:24:21 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 16:24:21 --> Config Class Initialized
INFO - 2020-02-29 16:24:21 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:21 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:21 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:21 --> URI Class Initialized
INFO - 2020-02-29 16:24:21 --> Router Class Initialized
INFO - 2020-02-29 16:24:21 --> Output Class Initialized
INFO - 2020-02-29 16:24:21 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:21 --> Input Class Initialized
INFO - 2020-02-29 16:24:21 --> Language Class Initialized
ERROR - 2020-02-29 16:24:21 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 16:24:21 --> Config Class Initialized
INFO - 2020-02-29 16:24:22 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:22 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:22 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:22 --> URI Class Initialized
INFO - 2020-02-29 16:24:22 --> Router Class Initialized
INFO - 2020-02-29 16:24:22 --> Output Class Initialized
INFO - 2020-02-29 16:24:22 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:22 --> Input Class Initialized
INFO - 2020-02-29 16:24:22 --> Language Class Initialized
ERROR - 2020-02-29 16:24:22 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 16:24:23 --> Config Class Initialized
INFO - 2020-02-29 16:24:23 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:23 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:23 --> URI Class Initialized
INFO - 2020-02-29 16:24:23 --> Router Class Initialized
INFO - 2020-02-29 16:24:23 --> Output Class Initialized
INFO - 2020-02-29 16:24:23 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:23 --> Input Class Initialized
INFO - 2020-02-29 16:24:23 --> Language Class Initialized
INFO - 2020-02-29 16:24:23 --> Loader Class Initialized
INFO - 2020-02-29 16:24:23 --> Helper loaded: url_helper
INFO - 2020-02-29 16:24:23 --> Helper loaded: string_helper
INFO - 2020-02-29 16:24:23 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:24:23 --> Controller Class Initialized
INFO - 2020-02-29 16:24:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 16:24:23 --> Pagination Class Initialized
INFO - 2020-02-29 16:24:23 --> Model "M_show" initialized
INFO - 2020-02-29 16:24:23 --> Helper loaded: form_helper
INFO - 2020-02-29 16:24:23 --> Form Validation Class Initialized
INFO - 2020-02-29 16:24:23 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\header/header.php
INFO - 2020-02-29 16:24:23 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\beli.php
INFO - 2020-02-29 16:24:23 --> Final output sent to browser
DEBUG - 2020-02-29 16:24:23 --> Total execution time: 0.7859
INFO - 2020-02-29 16:24:43 --> Config Class Initialized
INFO - 2020-02-29 16:24:43 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:43 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:43 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:43 --> URI Class Initialized
INFO - 2020-02-29 16:24:43 --> Router Class Initialized
INFO - 2020-02-29 16:24:43 --> Output Class Initialized
INFO - 2020-02-29 16:24:43 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:43 --> Input Class Initialized
INFO - 2020-02-29 16:24:43 --> Language Class Initialized
INFO - 2020-02-29 16:24:43 --> Loader Class Initialized
INFO - 2020-02-29 16:24:44 --> Helper loaded: url_helper
INFO - 2020-02-29 16:24:44 --> Helper loaded: string_helper
INFO - 2020-02-29 16:24:44 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:24:44 --> Controller Class Initialized
INFO - 2020-02-29 16:24:44 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:24:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:24:44 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:24:44 --> Helper loaded: form_helper
INFO - 2020-02-29 16:24:44 --> Form Validation Class Initialized
INFO - 2020-02-29 16:24:44 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:24:44 --> Final output sent to browser
DEBUG - 2020-02-29 16:24:44 --> Total execution time: 0.6935
INFO - 2020-02-29 16:24:44 --> Config Class Initialized
INFO - 2020-02-29 16:24:44 --> Config Class Initialized
INFO - 2020-02-29 16:24:44 --> Config Class Initialized
INFO - 2020-02-29 16:24:44 --> Config Class Initialized
INFO - 2020-02-29 16:24:44 --> Config Class Initialized
INFO - 2020-02-29 16:24:44 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:44 --> Config Class Initialized
INFO - 2020-02-29 16:24:44 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:44 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:44 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:44 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:44 --> URI Class Initialized
INFO - 2020-02-29 16:24:44 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:44 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:24:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:44 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:44 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:44 --> URI Class Initialized
INFO - 2020-02-29 16:24:44 --> URI Class Initialized
INFO - 2020-02-29 16:24:44 --> URI Class Initialized
INFO - 2020-02-29 16:24:44 --> Router Class Initialized
INFO - 2020-02-29 16:24:44 --> URI Class Initialized
INFO - 2020-02-29 16:24:44 --> Router Class Initialized
INFO - 2020-02-29 16:24:44 --> Output Class Initialized
INFO - 2020-02-29 16:24:44 --> Router Class Initialized
INFO - 2020-02-29 16:24:44 --> URI Class Initialized
INFO - 2020-02-29 16:24:44 --> Router Class Initialized
INFO - 2020-02-29 16:24:44 --> Security Class Initialized
INFO - 2020-02-29 16:24:44 --> Router Class Initialized
INFO - 2020-02-29 16:24:44 --> Router Class Initialized
INFO - 2020-02-29 16:24:44 --> Output Class Initialized
INFO - 2020-02-29 16:24:44 --> Output Class Initialized
INFO - 2020-02-29 16:24:44 --> Output Class Initialized
DEBUG - 2020-02-29 16:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:44 --> Security Class Initialized
INFO - 2020-02-29 16:24:44 --> Output Class Initialized
INFO - 2020-02-29 16:24:44 --> Output Class Initialized
INFO - 2020-02-29 16:24:44 --> Security Class Initialized
INFO - 2020-02-29 16:24:44 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:44 --> Input Class Initialized
DEBUG - 2020-02-29 16:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:44 --> Security Class Initialized
INFO - 2020-02-29 16:24:44 --> Security Class Initialized
INFO - 2020-02-29 16:24:45 --> Input Class Initialized
INFO - 2020-02-29 16:24:45 --> Input Class Initialized
INFO - 2020-02-29 16:24:45 --> Input Class Initialized
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
DEBUG - 2020-02-29 16:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
INFO - 2020-02-29 16:24:45 --> Input Class Initialized
ERROR - 2020-02-29 16:24:45 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-29 16:24:45 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-29 16:24:45 --> Input Class Initialized
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
ERROR - 2020-02-29 16:24:45 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 16:24:45 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
INFO - 2020-02-29 16:24:45 --> Config Class Initialized
INFO - 2020-02-29 16:24:45 --> Config Class Initialized
INFO - 2020-02-29 16:24:45 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:45 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:45 --> Loader Class Initialized
INFO - 2020-02-29 16:24:45 --> Loader Class Initialized
INFO - 2020-02-29 16:24:45 --> Config Class Initialized
INFO - 2020-02-29 16:24:45 --> Config Class Initialized
INFO - 2020-02-29 16:24:45 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:45 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:45 --> Helper loaded: url_helper
INFO - 2020-02-29 16:24:45 --> Helper loaded: url_helper
DEBUG - 2020-02-29 16:24:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:45 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:45 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:45 --> Helper loaded: string_helper
INFO - 2020-02-29 16:24:45 --> Helper loaded: string_helper
DEBUG - 2020-02-29 16:24:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:45 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:45 --> URI Class Initialized
INFO - 2020-02-29 16:24:45 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:45 --> Database Driver Class Initialized
INFO - 2020-02-29 16:24:45 --> URI Class Initialized
INFO - 2020-02-29 16:24:45 --> Database Driver Class Initialized
INFO - 2020-02-29 16:24:45 --> URI Class Initialized
INFO - 2020-02-29 16:24:45 --> Router Class Initialized
INFO - 2020-02-29 16:24:45 --> URI Class Initialized
INFO - 2020-02-29 16:24:45 --> Router Class Initialized
DEBUG - 2020-02-29 16:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:24:45 --> Router Class Initialized
INFO - 2020-02-29 16:24:45 --> Output Class Initialized
INFO - 2020-02-29 16:24:45 --> Output Class Initialized
INFO - 2020-02-29 16:24:45 --> Router Class Initialized
INFO - 2020-02-29 16:24:45 --> Controller Class Initialized
INFO - 2020-02-29 16:24:45 --> Security Class Initialized
INFO - 2020-02-29 16:24:45 --> Security Class Initialized
INFO - 2020-02-29 16:24:45 --> Output Class Initialized
INFO - 2020-02-29 16:24:45 --> Output Class Initialized
DEBUG - 2020-02-29 16:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:24:45 --> Model "M_tiket" initialized
DEBUG - 2020-02-29 16:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:45 --> Security Class Initialized
INFO - 2020-02-29 16:24:45 --> Security Class Initialized
INFO - 2020-02-29 16:24:45 --> Input Class Initialized
INFO - 2020-02-29 16:24:45 --> Input Class Initialized
INFO - 2020-02-29 16:24:45 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 16:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:45 --> Input Class Initialized
INFO - 2020-02-29 16:24:45 --> Input Class Initialized
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
INFO - 2020-02-29 16:24:45 --> Model "M_pesan" initialized
ERROR - 2020-02-29 16:24:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
ERROR - 2020-02-29 16:24:45 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
INFO - 2020-02-29 16:24:45 --> Helper loaded: form_helper
INFO - 2020-02-29 16:24:45 --> Form Validation Class Initialized
ERROR - 2020-02-29 16:24:45 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-29 16:24:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:24:45 --> Config Class Initialized
INFO - 2020-02-29 16:24:45 --> Config Class Initialized
INFO - 2020-02-29 16:24:45 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:45 --> Hooks Class Initialized
ERROR - 2020-02-29 16:24:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 16:24:45 --> Config Class Initialized
INFO - 2020-02-29 16:24:45 --> Config Class Initialized
INFO - 2020-02-29 16:24:45 --> Hooks Class Initialized
INFO - 2020-02-29 16:24:45 --> Hooks Class Initialized
ERROR - 2020-02-29 16:24:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
DEBUG - 2020-02-29 16:24:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:45 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:45 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:45 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-29 16:24:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:45 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:45 --> Final output sent to browser
INFO - 2020-02-29 16:24:45 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:45 --> URI Class Initialized
INFO - 2020-02-29 16:24:45 --> URI Class Initialized
DEBUG - 2020-02-29 16:24:45 --> Total execution time: 1.0977
INFO - 2020-02-29 16:24:45 --> URI Class Initialized
INFO - 2020-02-29 16:24:45 --> Router Class Initialized
INFO - 2020-02-29 16:24:45 --> URI Class Initialized
INFO - 2020-02-29 16:24:45 --> Router Class Initialized
INFO - 2020-02-29 16:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:24:45 --> Router Class Initialized
INFO - 2020-02-29 16:24:45 --> Router Class Initialized
INFO - 2020-02-29 16:24:45 --> Output Class Initialized
INFO - 2020-02-29 16:24:45 --> Output Class Initialized
INFO - 2020-02-29 16:24:45 --> Controller Class Initialized
INFO - 2020-02-29 16:24:45 --> Security Class Initialized
INFO - 2020-02-29 16:24:45 --> Output Class Initialized
INFO - 2020-02-29 16:24:45 --> Output Class Initialized
INFO - 2020-02-29 16:24:45 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:45 --> Security Class Initialized
INFO - 2020-02-29 16:24:45 --> Security Class Initialized
INFO - 2020-02-29 16:24:45 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:24:45 --> Input Class Initialized
INFO - 2020-02-29 16:24:45 --> Input Class Initialized
DEBUG - 2020-02-29 16:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:45 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 16:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
INFO - 2020-02-29 16:24:45 --> Input Class Initialized
INFO - 2020-02-29 16:24:45 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
ERROR - 2020-02-29 16:24:45 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 16:24:45 --> Input Class Initialized
INFO - 2020-02-29 16:24:45 --> Helper loaded: form_helper
INFO - 2020-02-29 16:24:45 --> Form Validation Class Initialized
INFO - 2020-02-29 16:24:45 --> Language Class Initialized
ERROR - 2020-02-29 16:24:45 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-29 16:24:45 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-29 16:24:45 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-29 16:24:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 16:24:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 16:24:45 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:24:45 --> Final output sent to browser
INFO - 2020-02-29 16:24:45 --> Config Class Initialized
INFO - 2020-02-29 16:24:45 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:45 --> Total execution time: 1.3979
DEBUG - 2020-02-29 16:24:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:45 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:46 --> URI Class Initialized
INFO - 2020-02-29 16:24:46 --> Router Class Initialized
INFO - 2020-02-29 16:24:46 --> Output Class Initialized
INFO - 2020-02-29 16:24:46 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:46 --> Input Class Initialized
INFO - 2020-02-29 16:24:46 --> Language Class Initialized
ERROR - 2020-02-29 16:24:46 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 16:24:46 --> Config Class Initialized
INFO - 2020-02-29 16:24:46 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:46 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:46 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:46 --> URI Class Initialized
INFO - 2020-02-29 16:24:46 --> Router Class Initialized
INFO - 2020-02-29 16:24:46 --> Output Class Initialized
INFO - 2020-02-29 16:24:46 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:46 --> Input Class Initialized
INFO - 2020-02-29 16:24:46 --> Language Class Initialized
ERROR - 2020-02-29 16:24:46 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 16:24:46 --> Config Class Initialized
INFO - 2020-02-29 16:24:46 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:46 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:46 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:46 --> URI Class Initialized
INFO - 2020-02-29 16:24:46 --> Router Class Initialized
INFO - 2020-02-29 16:24:46 --> Output Class Initialized
INFO - 2020-02-29 16:24:46 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:46 --> Input Class Initialized
INFO - 2020-02-29 16:24:46 --> Language Class Initialized
ERROR - 2020-02-29 16:24:46 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 16:24:47 --> Config Class Initialized
INFO - 2020-02-29 16:24:47 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:47 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:47 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:47 --> URI Class Initialized
INFO - 2020-02-29 16:24:47 --> Router Class Initialized
INFO - 2020-02-29 16:24:47 --> Output Class Initialized
INFO - 2020-02-29 16:24:47 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:47 --> Input Class Initialized
INFO - 2020-02-29 16:24:47 --> Language Class Initialized
ERROR - 2020-02-29 16:24:47 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:24:47 --> Config Class Initialized
INFO - 2020-02-29 16:24:47 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:47 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:47 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:47 --> URI Class Initialized
INFO - 2020-02-29 16:24:47 --> Router Class Initialized
INFO - 2020-02-29 16:24:47 --> Output Class Initialized
INFO - 2020-02-29 16:24:47 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:47 --> Input Class Initialized
INFO - 2020-02-29 16:24:47 --> Language Class Initialized
ERROR - 2020-02-29 16:24:47 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:24:47 --> Config Class Initialized
INFO - 2020-02-29 16:24:47 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:47 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:47 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:47 --> URI Class Initialized
INFO - 2020-02-29 16:24:48 --> Router Class Initialized
INFO - 2020-02-29 16:24:48 --> Output Class Initialized
INFO - 2020-02-29 16:24:48 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:48 --> Input Class Initialized
INFO - 2020-02-29 16:24:48 --> Language Class Initialized
ERROR - 2020-02-29 16:24:48 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 16:24:48 --> Config Class Initialized
INFO - 2020-02-29 16:24:48 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:48 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:48 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:48 --> URI Class Initialized
INFO - 2020-02-29 16:24:48 --> Router Class Initialized
INFO - 2020-02-29 16:24:48 --> Output Class Initialized
INFO - 2020-02-29 16:24:48 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:48 --> Input Class Initialized
INFO - 2020-02-29 16:24:48 --> Language Class Initialized
ERROR - 2020-02-29 16:24:48 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 16:24:48 --> Config Class Initialized
INFO - 2020-02-29 16:24:48 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:48 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:48 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:48 --> URI Class Initialized
INFO - 2020-02-29 16:24:48 --> Router Class Initialized
INFO - 2020-02-29 16:24:48 --> Output Class Initialized
INFO - 2020-02-29 16:24:48 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:48 --> Input Class Initialized
INFO - 2020-02-29 16:24:48 --> Language Class Initialized
ERROR - 2020-02-29 16:24:48 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 16:24:49 --> Config Class Initialized
INFO - 2020-02-29 16:24:49 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:49 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:24:49 --> Utf8 Class Initialized
INFO - 2020-02-29 16:24:49 --> URI Class Initialized
INFO - 2020-02-29 16:24:49 --> Router Class Initialized
INFO - 2020-02-29 16:24:49 --> Output Class Initialized
INFO - 2020-02-29 16:24:49 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:24:49 --> Input Class Initialized
INFO - 2020-02-29 16:24:49 --> Language Class Initialized
ERROR - 2020-02-29 16:24:49 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 16:25:08 --> Config Class Initialized
INFO - 2020-02-29 16:25:08 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:25:08 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:25:09 --> Utf8 Class Initialized
INFO - 2020-02-29 16:25:09 --> URI Class Initialized
INFO - 2020-02-29 16:25:09 --> Router Class Initialized
INFO - 2020-02-29 16:25:09 --> Output Class Initialized
INFO - 2020-02-29 16:25:09 --> Security Class Initialized
DEBUG - 2020-02-29 16:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:25:09 --> Input Class Initialized
INFO - 2020-02-29 16:25:09 --> Language Class Initialized
INFO - 2020-02-29 16:25:09 --> Loader Class Initialized
INFO - 2020-02-29 16:25:09 --> Helper loaded: url_helper
INFO - 2020-02-29 16:25:09 --> Helper loaded: string_helper
INFO - 2020-02-29 16:25:09 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:25:09 --> Controller Class Initialized
INFO - 2020-02-29 16:25:09 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:25:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:25:09 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:25:09 --> Helper loaded: form_helper
INFO - 2020-02-29 16:25:09 --> Form Validation Class Initialized
ERROR - 2020-02-29 22:25:09 --> Severity: Notice --> Undefined index: pengunjung.nama_pengunjung C:\xampp\htdocs\roadshow-2.1\application\controllers\Tiket.php 86
ERROR - 2020-02-29 22:25:12 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\roadshow-2.1\application\controllers\Tiket.php 132
INFO - 2020-02-29 22:25:12 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-29 22:25:12 --> Final output sent to browser
DEBUG - 2020-02-29 22:25:12 --> Total execution time: 3.4454
INFO - 2020-02-29 16:25:31 --> Config Class Initialized
INFO - 2020-02-29 16:25:31 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:25:31 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:25:32 --> Utf8 Class Initialized
INFO - 2020-02-29 16:25:32 --> URI Class Initialized
INFO - 2020-02-29 16:25:32 --> Router Class Initialized
INFO - 2020-02-29 16:25:32 --> Output Class Initialized
INFO - 2020-02-29 16:25:32 --> Security Class Initialized
DEBUG - 2020-02-29 16:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:25:32 --> Input Class Initialized
INFO - 2020-02-29 16:25:32 --> Language Class Initialized
INFO - 2020-02-29 16:25:32 --> Loader Class Initialized
INFO - 2020-02-29 16:25:32 --> Helper loaded: url_helper
INFO - 2020-02-29 16:25:32 --> Helper loaded: string_helper
INFO - 2020-02-29 16:25:32 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:25:32 --> Controller Class Initialized
INFO - 2020-02-29 16:25:32 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:25:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:25:32 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:25:32 --> Helper loaded: form_helper
INFO - 2020-02-29 16:25:32 --> Form Validation Class Initialized
ERROR - 2020-02-29 16:25:32 --> Severity: Notice --> Undefined variable: tanggalp C:\xampp\htdocs\roadshow-2.1\application\controllers\Tiket.php 36
INFO - 2020-02-29 16:25:32 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\pemesanan/form_bukti.php
INFO - 2020-02-29 16:25:32 --> Final output sent to browser
DEBUG - 2020-02-29 16:25:32 --> Total execution time: 0.6853
INFO - 2020-02-29 16:30:13 --> Config Class Initialized
INFO - 2020-02-29 16:30:13 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:13 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:13 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:13 --> URI Class Initialized
INFO - 2020-02-29 16:30:13 --> Router Class Initialized
INFO - 2020-02-29 16:30:13 --> Output Class Initialized
INFO - 2020-02-29 16:30:13 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:14 --> Input Class Initialized
INFO - 2020-02-29 16:30:14 --> Language Class Initialized
INFO - 2020-02-29 16:30:14 --> Loader Class Initialized
INFO - 2020-02-29 16:30:14 --> Helper loaded: url_helper
INFO - 2020-02-29 16:30:14 --> Helper loaded: string_helper
INFO - 2020-02-29 16:30:14 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:30:14 --> Controller Class Initialized
INFO - 2020-02-29 16:30:14 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:30:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:30:14 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:30:14 --> Helper loaded: form_helper
INFO - 2020-02-29 16:30:14 --> Form Validation Class Initialized
INFO - 2020-02-29 16:30:15 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:30:15 --> Final output sent to browser
DEBUG - 2020-02-29 16:30:15 --> Total execution time: 2.2034
INFO - 2020-02-29 16:30:15 --> Config Class Initialized
INFO - 2020-02-29 16:30:15 --> Config Class Initialized
INFO - 2020-02-29 16:30:15 --> Config Class Initialized
INFO - 2020-02-29 16:30:15 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:15 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:15 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:15 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:15 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:15 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:15 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:15 --> URI Class Initialized
INFO - 2020-02-29 16:30:15 --> URI Class Initialized
INFO - 2020-02-29 16:30:15 --> URI Class Initialized
INFO - 2020-02-29 16:30:15 --> Router Class Initialized
INFO - 2020-02-29 16:30:15 --> Router Class Initialized
INFO - 2020-02-29 16:30:15 --> Router Class Initialized
INFO - 2020-02-29 16:30:15 --> Output Class Initialized
INFO - 2020-02-29 16:30:15 --> Output Class Initialized
INFO - 2020-02-29 16:30:15 --> Output Class Initialized
INFO - 2020-02-29 16:30:15 --> Security Class Initialized
INFO - 2020-02-29 16:30:15 --> Security Class Initialized
INFO - 2020-02-29 16:30:15 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:15 --> Input Class Initialized
INFO - 2020-02-29 16:30:15 --> Input Class Initialized
INFO - 2020-02-29 16:30:15 --> Input Class Initialized
INFO - 2020-02-29 16:30:15 --> Language Class Initialized
INFO - 2020-02-29 16:30:15 --> Language Class Initialized
INFO - 2020-02-29 16:30:15 --> Language Class Initialized
INFO - 2020-02-29 16:30:15 --> Loader Class Initialized
INFO - 2020-02-29 16:30:15 --> Loader Class Initialized
INFO - 2020-02-29 16:30:15 --> Helper loaded: url_helper
INFO - 2020-02-29 16:30:15 --> Helper loaded: url_helper
ERROR - 2020-02-29 16:30:15 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-29 16:30:15 --> Helper loaded: string_helper
INFO - 2020-02-29 16:30:15 --> Helper loaded: string_helper
INFO - 2020-02-29 16:30:15 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:30:16 --> Database Driver Class Initialized
INFO - 2020-02-29 16:30:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-29 16:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:30:16 --> Controller Class Initialized
INFO - 2020-02-29 16:30:16 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:30:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:30:16 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:30:16 --> Helper loaded: form_helper
INFO - 2020-02-29 16:30:16 --> Form Validation Class Initialized
ERROR - 2020-02-29 16:30:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 16:30:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 16:30:16 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:30:16 --> Final output sent to browser
DEBUG - 2020-02-29 16:30:16 --> Total execution time: 1.0944
INFO - 2020-02-29 16:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:30:16 --> Controller Class Initialized
INFO - 2020-02-29 16:30:16 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:30:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:30:16 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:30:16 --> Helper loaded: form_helper
INFO - 2020-02-29 16:30:16 --> Form Validation Class Initialized
ERROR - 2020-02-29 16:30:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 16:30:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 16:30:16 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:30:16 --> Final output sent to browser
DEBUG - 2020-02-29 16:30:16 --> Total execution time: 1.4424
INFO - 2020-02-29 16:30:19 --> Config Class Initialized
INFO - 2020-02-29 16:30:19 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:19 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:19 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:19 --> URI Class Initialized
INFO - 2020-02-29 16:30:19 --> Router Class Initialized
INFO - 2020-02-29 16:30:19 --> Output Class Initialized
INFO - 2020-02-29 16:30:19 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:19 --> Input Class Initialized
INFO - 2020-02-29 16:30:19 --> Language Class Initialized
INFO - 2020-02-29 16:30:19 --> Loader Class Initialized
INFO - 2020-02-29 16:30:19 --> Helper loaded: url_helper
INFO - 2020-02-29 16:30:20 --> Helper loaded: string_helper
INFO - 2020-02-29 16:30:20 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:30:20 --> Controller Class Initialized
INFO - 2020-02-29 16:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 16:30:20 --> Pagination Class Initialized
INFO - 2020-02-29 16:30:20 --> Model "M_show" initialized
INFO - 2020-02-29 16:30:20 --> Helper loaded: form_helper
INFO - 2020-02-29 16:30:20 --> Form Validation Class Initialized
INFO - 2020-02-29 16:30:20 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\header/header.php
INFO - 2020-02-29 16:30:20 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\beli.php
INFO - 2020-02-29 16:30:20 --> Final output sent to browser
DEBUG - 2020-02-29 16:30:20 --> Total execution time: 0.9094
INFO - 2020-02-29 16:30:22 --> Config Class Initialized
INFO - 2020-02-29 16:30:22 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:22 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:22 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:22 --> URI Class Initialized
INFO - 2020-02-29 16:30:22 --> Router Class Initialized
INFO - 2020-02-29 16:30:22 --> Output Class Initialized
INFO - 2020-02-29 16:30:22 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:22 --> Input Class Initialized
INFO - 2020-02-29 16:30:23 --> Language Class Initialized
INFO - 2020-02-29 16:30:23 --> Loader Class Initialized
INFO - 2020-02-29 16:30:23 --> Helper loaded: url_helper
INFO - 2020-02-29 16:30:23 --> Helper loaded: string_helper
INFO - 2020-02-29 16:30:23 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:30:23 --> Controller Class Initialized
INFO - 2020-02-29 16:30:23 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:30:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:30:23 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:30:23 --> Helper loaded: form_helper
INFO - 2020-02-29 16:30:23 --> Form Validation Class Initialized
INFO - 2020-02-29 16:30:23 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:30:23 --> Final output sent to browser
INFO - 2020-02-29 16:30:23 --> Config Class Initialized
INFO - 2020-02-29 16:30:23 --> Config Class Initialized
INFO - 2020-02-29 16:30:23 --> Config Class Initialized
INFO - 2020-02-29 16:30:23 --> Config Class Initialized
INFO - 2020-02-29 16:30:23 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:23 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:23 --> Total execution time: 0.6758
INFO - 2020-02-29 16:30:23 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:23 --> Config Class Initialized
INFO - 2020-02-29 16:30:23 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:23 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:23 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:23 --> Config Class Initialized
DEBUG - 2020-02-29 16:30:23 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:23 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:30:23 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:23 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:23 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:23 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:23 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:23 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:23 --> URI Class Initialized
INFO - 2020-02-29 16:30:23 --> URI Class Initialized
INFO - 2020-02-29 16:30:23 --> Router Class Initialized
INFO - 2020-02-29 16:30:23 --> URI Class Initialized
INFO - 2020-02-29 16:30:23 --> URI Class Initialized
INFO - 2020-02-29 16:30:23 --> URI Class Initialized
DEBUG - 2020-02-29 16:30:23 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:23 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:23 --> Router Class Initialized
INFO - 2020-02-29 16:30:23 --> Router Class Initialized
INFO - 2020-02-29 16:30:23 --> Output Class Initialized
INFO - 2020-02-29 16:30:23 --> Router Class Initialized
INFO - 2020-02-29 16:30:23 --> Router Class Initialized
INFO - 2020-02-29 16:30:23 --> URI Class Initialized
INFO - 2020-02-29 16:30:23 --> Output Class Initialized
INFO - 2020-02-29 16:30:23 --> Output Class Initialized
INFO - 2020-02-29 16:30:23 --> Output Class Initialized
INFO - 2020-02-29 16:30:23 --> Output Class Initialized
INFO - 2020-02-29 16:30:23 --> Security Class Initialized
INFO - 2020-02-29 16:30:23 --> Security Class Initialized
INFO - 2020-02-29 16:30:23 --> Security Class Initialized
INFO - 2020-02-29 16:30:23 --> Security Class Initialized
INFO - 2020-02-29 16:30:23 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:23 --> Router Class Initialized
INFO - 2020-02-29 16:30:23 --> Input Class Initialized
DEBUG - 2020-02-29 16:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:23 --> Output Class Initialized
DEBUG - 2020-02-29 16:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:23 --> Input Class Initialized
INFO - 2020-02-29 16:30:23 --> Input Class Initialized
INFO - 2020-02-29 16:30:23 --> Input Class Initialized
INFO - 2020-02-29 16:30:23 --> Input Class Initialized
INFO - 2020-02-29 16:30:23 --> Security Class Initialized
INFO - 2020-02-29 16:30:23 --> Language Class Initialized
INFO - 2020-02-29 16:30:23 --> Language Class Initialized
INFO - 2020-02-29 16:30:23 --> Language Class Initialized
ERROR - 2020-02-29 16:30:23 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-29 16:30:23 --> Language Class Initialized
INFO - 2020-02-29 16:30:23 --> Language Class Initialized
DEBUG - 2020-02-29 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:23 --> Input Class Initialized
ERROR - 2020-02-29 16:30:23 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 16:30:23 --> Loader Class Initialized
ERROR - 2020-02-29 16:30:23 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-29 16:30:23 --> Loader Class Initialized
INFO - 2020-02-29 16:30:23 --> Config Class Initialized
INFO - 2020-02-29 16:30:23 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:24 --> Helper loaded: url_helper
INFO - 2020-02-29 16:30:24 --> Helper loaded: url_helper
INFO - 2020-02-29 16:30:24 --> Language Class Initialized
INFO - 2020-02-29 16:30:24 --> Config Class Initialized
INFO - 2020-02-29 16:30:24 --> Config Class Initialized
INFO - 2020-02-29 16:30:24 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:24 --> Helper loaded: string_helper
INFO - 2020-02-29 16:30:24 --> Hooks Class Initialized
ERROR - 2020-02-29 16:30:24 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 16:30:24 --> Helper loaded: string_helper
DEBUG - 2020-02-29 16:30:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:24 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:24 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:24 --> Database Driver Class Initialized
INFO - 2020-02-29 16:30:24 --> Database Driver Class Initialized
INFO - 2020-02-29 16:30:24 --> Config Class Initialized
INFO - 2020-02-29 16:30:24 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:24 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:24 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:24 --> URI Class Initialized
DEBUG - 2020-02-29 16:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-29 16:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:30:24 --> URI Class Initialized
INFO - 2020-02-29 16:30:24 --> URI Class Initialized
DEBUG - 2020-02-29 16:30:24 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:24 --> Router Class Initialized
INFO - 2020-02-29 16:30:24 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:24 --> Controller Class Initialized
INFO - 2020-02-29 16:30:24 --> Output Class Initialized
INFO - 2020-02-29 16:30:24 --> Router Class Initialized
INFO - 2020-02-29 16:30:24 --> Router Class Initialized
INFO - 2020-02-29 16:30:24 --> URI Class Initialized
INFO - 2020-02-29 16:30:24 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:30:24 --> Security Class Initialized
INFO - 2020-02-29 16:30:24 --> Output Class Initialized
INFO - 2020-02-29 16:30:24 --> Output Class Initialized
INFO - 2020-02-29 16:30:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:30:24 --> Security Class Initialized
INFO - 2020-02-29 16:30:24 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:24 --> Router Class Initialized
INFO - 2020-02-29 16:30:24 --> Input Class Initialized
INFO - 2020-02-29 16:30:24 --> Model "M_pesan" initialized
DEBUG - 2020-02-29 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:24 --> Output Class Initialized
DEBUG - 2020-02-29 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:24 --> Input Class Initialized
INFO - 2020-02-29 16:30:24 --> Input Class Initialized
INFO - 2020-02-29 16:30:24 --> Language Class Initialized
INFO - 2020-02-29 16:30:24 --> Security Class Initialized
INFO - 2020-02-29 16:30:24 --> Helper loaded: form_helper
INFO - 2020-02-29 16:30:24 --> Language Class Initialized
DEBUG - 2020-02-29 16:30:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-29 16:30:24 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 16:30:24 --> Form Validation Class Initialized
INFO - 2020-02-29 16:30:24 --> Language Class Initialized
INFO - 2020-02-29 16:30:24 --> Input Class Initialized
ERROR - 2020-02-29 16:30:24 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 16:30:24 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 16:30:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 16:30:24 --> Config Class Initialized
INFO - 2020-02-29 16:30:24 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:24 --> Language Class Initialized
ERROR - 2020-02-29 16:30:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 16:30:24 --> Config Class Initialized
INFO - 2020-02-29 16:30:24 --> Config Class Initialized
INFO - 2020-02-29 16:30:24 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:24 --> Hooks Class Initialized
ERROR - 2020-02-29 16:30:24 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 16:30:24 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-29 16:30:24 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:24 --> Final output sent to browser
INFO - 2020-02-29 16:30:24 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:30:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:24 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:24 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:30:24 --> Total execution time: 1.0442
INFO - 2020-02-29 16:30:24 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:24 --> URI Class Initialized
INFO - 2020-02-29 16:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:30:24 --> URI Class Initialized
INFO - 2020-02-29 16:30:24 --> Router Class Initialized
INFO - 2020-02-29 16:30:24 --> URI Class Initialized
INFO - 2020-02-29 16:30:24 --> Controller Class Initialized
INFO - 2020-02-29 16:30:24 --> Router Class Initialized
INFO - 2020-02-29 16:30:24 --> Output Class Initialized
INFO - 2020-02-29 16:30:24 --> Router Class Initialized
INFO - 2020-02-29 16:30:24 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:30:24 --> Security Class Initialized
INFO - 2020-02-29 16:30:24 --> Output Class Initialized
INFO - 2020-02-29 16:30:24 --> Output Class Initialized
INFO - 2020-02-29 16:30:24 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:24 --> Security Class Initialized
INFO - 2020-02-29 16:30:24 --> Security Class Initialized
INFO - 2020-02-29 16:30:24 --> Input Class Initialized
INFO - 2020-02-29 16:30:24 --> Model "M_pesan" initialized
DEBUG - 2020-02-29 16:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:24 --> Input Class Initialized
INFO - 2020-02-29 16:30:24 --> Input Class Initialized
INFO - 2020-02-29 16:30:24 --> Language Class Initialized
INFO - 2020-02-29 16:30:24 --> Helper loaded: form_helper
INFO - 2020-02-29 16:30:24 --> Language Class Initialized
INFO - 2020-02-29 16:30:24 --> Language Class Initialized
INFO - 2020-02-29 16:30:24 --> Form Validation Class Initialized
ERROR - 2020-02-29 16:30:24 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-29 16:30:24 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-29 16:30:24 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-29 16:30:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 16:30:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 16:30:24 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:30:24 --> Final output sent to browser
DEBUG - 2020-02-29 16:30:24 --> Total execution time: 1.4204
INFO - 2020-02-29 16:30:42 --> Config Class Initialized
INFO - 2020-02-29 16:30:42 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:42 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:42 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:42 --> URI Class Initialized
INFO - 2020-02-29 16:30:42 --> Router Class Initialized
INFO - 2020-02-29 16:30:42 --> Output Class Initialized
INFO - 2020-02-29 16:30:42 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:42 --> Input Class Initialized
INFO - 2020-02-29 16:30:42 --> Language Class Initialized
INFO - 2020-02-29 16:30:43 --> Loader Class Initialized
INFO - 2020-02-29 16:30:43 --> Helper loaded: url_helper
INFO - 2020-02-29 16:30:43 --> Helper loaded: string_helper
INFO - 2020-02-29 16:30:43 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:30:43 --> Controller Class Initialized
INFO - 2020-02-29 16:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 16:30:43 --> Pagination Class Initialized
INFO - 2020-02-29 16:30:43 --> Model "M_show" initialized
INFO - 2020-02-29 16:30:43 --> Helper loaded: form_helper
INFO - 2020-02-29 16:30:43 --> Form Validation Class Initialized
INFO - 2020-02-29 16:30:43 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\header/header.php
INFO - 2020-02-29 16:30:43 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\beli.php
INFO - 2020-02-29 16:30:43 --> Final output sent to browser
DEBUG - 2020-02-29 16:30:43 --> Total execution time: 0.7061
INFO - 2020-02-29 16:30:46 --> Config Class Initialized
INFO - 2020-02-29 16:30:46 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:46 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:46 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:46 --> URI Class Initialized
INFO - 2020-02-29 16:30:46 --> Router Class Initialized
INFO - 2020-02-29 16:30:46 --> Output Class Initialized
INFO - 2020-02-29 16:30:46 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:46 --> Input Class Initialized
INFO - 2020-02-29 16:30:46 --> Language Class Initialized
INFO - 2020-02-29 16:30:46 --> Loader Class Initialized
INFO - 2020-02-29 16:30:46 --> Helper loaded: url_helper
INFO - 2020-02-29 16:30:46 --> Helper loaded: string_helper
INFO - 2020-02-29 16:30:46 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:30:47 --> Controller Class Initialized
INFO - 2020-02-29 16:30:47 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:30:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:30:47 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:30:47 --> Helper loaded: form_helper
INFO - 2020-02-29 16:30:47 --> Form Validation Class Initialized
INFO - 2020-02-29 16:30:47 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:30:47 --> Final output sent to browser
DEBUG - 2020-02-29 16:30:47 --> Total execution time: 0.6443
INFO - 2020-02-29 16:30:47 --> Config Class Initialized
INFO - 2020-02-29 16:30:47 --> Config Class Initialized
INFO - 2020-02-29 16:30:47 --> Config Class Initialized
INFO - 2020-02-29 16:30:47 --> Config Class Initialized
INFO - 2020-02-29 16:30:47 --> Config Class Initialized
INFO - 2020-02-29 16:30:47 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:47 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:47 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:47 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:47 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:47 --> Config Class Initialized
INFO - 2020-02-29 16:30:47 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:47 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:47 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:47 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:47 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:47 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:47 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:47 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:47 --> URI Class Initialized
INFO - 2020-02-29 16:30:47 --> URI Class Initialized
INFO - 2020-02-29 16:30:47 --> URI Class Initialized
INFO - 2020-02-29 16:30:47 --> URI Class Initialized
INFO - 2020-02-29 16:30:47 --> URI Class Initialized
INFO - 2020-02-29 16:30:47 --> URI Class Initialized
INFO - 2020-02-29 16:30:47 --> Router Class Initialized
INFO - 2020-02-29 16:30:47 --> Router Class Initialized
INFO - 2020-02-29 16:30:47 --> Router Class Initialized
INFO - 2020-02-29 16:30:47 --> Router Class Initialized
INFO - 2020-02-29 16:30:47 --> Router Class Initialized
INFO - 2020-02-29 16:30:47 --> Router Class Initialized
INFO - 2020-02-29 16:30:47 --> Output Class Initialized
INFO - 2020-02-29 16:30:47 --> Output Class Initialized
INFO - 2020-02-29 16:30:47 --> Output Class Initialized
INFO - 2020-02-29 16:30:47 --> Output Class Initialized
INFO - 2020-02-29 16:30:47 --> Output Class Initialized
INFO - 2020-02-29 16:30:47 --> Output Class Initialized
INFO - 2020-02-29 16:30:47 --> Security Class Initialized
INFO - 2020-02-29 16:30:47 --> Security Class Initialized
INFO - 2020-02-29 16:30:47 --> Security Class Initialized
INFO - 2020-02-29 16:30:47 --> Security Class Initialized
INFO - 2020-02-29 16:30:47 --> Security Class Initialized
INFO - 2020-02-29 16:30:47 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:47 --> Input Class Initialized
INFO - 2020-02-29 16:30:47 --> Input Class Initialized
INFO - 2020-02-29 16:30:47 --> Input Class Initialized
INFO - 2020-02-29 16:30:47 --> Input Class Initialized
INFO - 2020-02-29 16:30:47 --> Input Class Initialized
INFO - 2020-02-29 16:30:47 --> Input Class Initialized
INFO - 2020-02-29 16:30:47 --> Language Class Initialized
INFO - 2020-02-29 16:30:47 --> Language Class Initialized
INFO - 2020-02-29 16:30:47 --> Language Class Initialized
INFO - 2020-02-29 16:30:47 --> Language Class Initialized
INFO - 2020-02-29 16:30:47 --> Language Class Initialized
INFO - 2020-02-29 16:30:47 --> Language Class Initialized
ERROR - 2020-02-29 16:30:47 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 16:30:47 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-29 16:30:47 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-29 16:30:47 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 16:30:47 --> Loader Class Initialized
ERROR - 2020-02-29 16:30:47 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 16:30:47 --> Helper loaded: url_helper
INFO - 2020-02-29 16:30:47 --> Config Class Initialized
INFO - 2020-02-29 16:30:47 --> Config Class Initialized
INFO - 2020-02-29 16:30:47 --> Config Class Initialized
INFO - 2020-02-29 16:30:47 --> Config Class Initialized
INFO - 2020-02-29 16:30:47 --> Config Class Initialized
INFO - 2020-02-29 16:30:47 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:47 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:47 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:47 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:47 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:47 --> Helper loaded: string_helper
DEBUG - 2020-02-29 16:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:47 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:47 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:47 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:47 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:47 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:47 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:47 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:47 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:30:47 --> URI Class Initialized
INFO - 2020-02-29 16:30:47 --> URI Class Initialized
INFO - 2020-02-29 16:30:47 --> URI Class Initialized
INFO - 2020-02-29 16:30:47 --> URI Class Initialized
INFO - 2020-02-29 16:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:30:47 --> URI Class Initialized
INFO - 2020-02-29 16:30:47 --> Controller Class Initialized
INFO - 2020-02-29 16:30:47 --> Router Class Initialized
INFO - 2020-02-29 16:30:47 --> Router Class Initialized
INFO - 2020-02-29 16:30:47 --> Router Class Initialized
INFO - 2020-02-29 16:30:47 --> Router Class Initialized
INFO - 2020-02-29 16:30:47 --> Router Class Initialized
INFO - 2020-02-29 16:30:47 --> Output Class Initialized
INFO - 2020-02-29 16:30:47 --> Output Class Initialized
INFO - 2020-02-29 16:30:47 --> Output Class Initialized
INFO - 2020-02-29 16:30:47 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:30:47 --> Output Class Initialized
INFO - 2020-02-29 16:30:47 --> Output Class Initialized
INFO - 2020-02-29 16:30:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:30:47 --> Security Class Initialized
INFO - 2020-02-29 16:30:47 --> Security Class Initialized
INFO - 2020-02-29 16:30:47 --> Security Class Initialized
INFO - 2020-02-29 16:30:47 --> Security Class Initialized
INFO - 2020-02-29 16:30:47 --> Security Class Initialized
INFO - 2020-02-29 16:30:47 --> Model "M_pesan" initialized
DEBUG - 2020-02-29 16:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:47 --> Input Class Initialized
INFO - 2020-02-29 16:30:47 --> Input Class Initialized
INFO - 2020-02-29 16:30:47 --> Input Class Initialized
INFO - 2020-02-29 16:30:47 --> Input Class Initialized
INFO - 2020-02-29 16:30:47 --> Input Class Initialized
INFO - 2020-02-29 16:30:47 --> Helper loaded: form_helper
INFO - 2020-02-29 16:30:48 --> Form Validation Class Initialized
INFO - 2020-02-29 16:30:48 --> Language Class Initialized
INFO - 2020-02-29 16:30:48 --> Language Class Initialized
INFO - 2020-02-29 16:30:48 --> Language Class Initialized
INFO - 2020-02-29 16:30:48 --> Language Class Initialized
INFO - 2020-02-29 16:30:48 --> Language Class Initialized
ERROR - 2020-02-29 16:30:48 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-29 16:30:48 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 16:30:48 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-29 16:30:48 --> Loader Class Initialized
ERROR - 2020-02-29 16:30:48 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 16:30:48 --> Helper loaded: url_helper
INFO - 2020-02-29 16:30:48 --> Config Class Initialized
INFO - 2020-02-29 16:30:48 --> Config Class Initialized
INFO - 2020-02-29 16:30:48 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:48 --> Helper loaded: string_helper
INFO - 2020-02-29 16:30:48 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:48 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:30:48 --> Config Class Initialized
INFO - 2020-02-29 16:30:48 --> Hooks Class Initialized
INFO - 2020-02-29 16:30:48 --> Final output sent to browser
DEBUG - 2020-02-29 16:30:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:48 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:48 --> Database Driver Class Initialized
INFO - 2020-02-29 16:30:48 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:30:48 --> Total execution time: 0.7956
INFO - 2020-02-29 16:30:48 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:30:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:30:48 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:48 --> URI Class Initialized
INFO - 2020-02-29 16:30:48 --> URI Class Initialized
INFO - 2020-02-29 16:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:30:48 --> Controller Class Initialized
INFO - 2020-02-29 16:30:48 --> URI Class Initialized
INFO - 2020-02-29 16:30:48 --> Router Class Initialized
INFO - 2020-02-29 16:30:48 --> Router Class Initialized
INFO - 2020-02-29 16:30:48 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:30:48 --> Output Class Initialized
INFO - 2020-02-29 16:30:48 --> Output Class Initialized
INFO - 2020-02-29 16:30:48 --> Router Class Initialized
INFO - 2020-02-29 16:30:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:30:48 --> Security Class Initialized
INFO - 2020-02-29 16:30:48 --> Output Class Initialized
INFO - 2020-02-29 16:30:48 --> Security Class Initialized
INFO - 2020-02-29 16:30:48 --> Model "M_pesan" initialized
DEBUG - 2020-02-29 16:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:48 --> Security Class Initialized
INFO - 2020-02-29 16:30:48 --> Input Class Initialized
INFO - 2020-02-29 16:30:48 --> Input Class Initialized
DEBUG - 2020-02-29 16:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:48 --> Helper loaded: form_helper
INFO - 2020-02-29 16:30:48 --> Form Validation Class Initialized
INFO - 2020-02-29 16:30:48 --> Input Class Initialized
INFO - 2020-02-29 16:30:48 --> Language Class Initialized
INFO - 2020-02-29 16:30:48 --> Language Class Initialized
ERROR - 2020-02-29 16:30:48 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 16:30:48 --> Language Class Initialized
ERROR - 2020-02-29 16:30:48 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-29 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-29 16:30:48 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 16:30:48 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:30:48 --> Final output sent to browser
DEBUG - 2020-02-29 16:30:48 --> Total execution time: 0.7626
INFO - 2020-02-29 16:30:48 --> Config Class Initialized
INFO - 2020-02-29 16:30:48 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:48 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:48 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:48 --> URI Class Initialized
INFO - 2020-02-29 16:30:48 --> Router Class Initialized
INFO - 2020-02-29 16:30:48 --> Output Class Initialized
INFO - 2020-02-29 16:30:48 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:48 --> Input Class Initialized
INFO - 2020-02-29 16:30:48 --> Language Class Initialized
ERROR - 2020-02-29 16:30:48 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 16:30:48 --> Config Class Initialized
INFO - 2020-02-29 16:30:48 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:48 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:48 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:48 --> URI Class Initialized
INFO - 2020-02-29 16:30:48 --> Router Class Initialized
INFO - 2020-02-29 16:30:48 --> Output Class Initialized
INFO - 2020-02-29 16:30:49 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:49 --> Input Class Initialized
INFO - 2020-02-29 16:30:49 --> Language Class Initialized
ERROR - 2020-02-29 16:30:49 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 16:30:49 --> Config Class Initialized
INFO - 2020-02-29 16:30:49 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:49 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:49 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:49 --> URI Class Initialized
INFO - 2020-02-29 16:30:49 --> Router Class Initialized
INFO - 2020-02-29 16:30:49 --> Output Class Initialized
INFO - 2020-02-29 16:30:49 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:49 --> Input Class Initialized
INFO - 2020-02-29 16:30:49 --> Language Class Initialized
ERROR - 2020-02-29 16:30:49 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:30:49 --> Config Class Initialized
INFO - 2020-02-29 16:30:49 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:49 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:49 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:49 --> URI Class Initialized
INFO - 2020-02-29 16:30:49 --> Router Class Initialized
INFO - 2020-02-29 16:30:49 --> Output Class Initialized
INFO - 2020-02-29 16:30:49 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:49 --> Input Class Initialized
INFO - 2020-02-29 16:30:49 --> Language Class Initialized
ERROR - 2020-02-29 16:30:49 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:30:49 --> Config Class Initialized
INFO - 2020-02-29 16:30:49 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:49 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:49 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:49 --> URI Class Initialized
INFO - 2020-02-29 16:30:49 --> Router Class Initialized
INFO - 2020-02-29 16:30:49 --> Output Class Initialized
INFO - 2020-02-29 16:30:50 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:50 --> Input Class Initialized
INFO - 2020-02-29 16:30:50 --> Language Class Initialized
ERROR - 2020-02-29 16:30:50 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 16:30:50 --> Config Class Initialized
INFO - 2020-02-29 16:30:50 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:50 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:50 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:50 --> URI Class Initialized
INFO - 2020-02-29 16:30:50 --> Router Class Initialized
INFO - 2020-02-29 16:30:50 --> Output Class Initialized
INFO - 2020-02-29 16:30:50 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:50 --> Input Class Initialized
INFO - 2020-02-29 16:30:50 --> Language Class Initialized
ERROR - 2020-02-29 16:30:50 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 16:30:50 --> Config Class Initialized
INFO - 2020-02-29 16:30:50 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:50 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:50 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:50 --> URI Class Initialized
INFO - 2020-02-29 16:30:50 --> Router Class Initialized
INFO - 2020-02-29 16:30:50 --> Output Class Initialized
INFO - 2020-02-29 16:30:50 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:50 --> Input Class Initialized
INFO - 2020-02-29 16:30:50 --> Language Class Initialized
ERROR - 2020-02-29 16:30:50 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 16:30:50 --> Config Class Initialized
INFO - 2020-02-29 16:30:50 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:30:50 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:30:50 --> Utf8 Class Initialized
INFO - 2020-02-29 16:30:50 --> URI Class Initialized
INFO - 2020-02-29 16:30:50 --> Router Class Initialized
INFO - 2020-02-29 16:30:50 --> Output Class Initialized
INFO - 2020-02-29 16:30:51 --> Security Class Initialized
DEBUG - 2020-02-29 16:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:30:51 --> Input Class Initialized
INFO - 2020-02-29 16:30:51 --> Language Class Initialized
ERROR - 2020-02-29 16:30:51 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 16:32:29 --> Config Class Initialized
INFO - 2020-02-29 16:32:29 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:32:29 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:32:29 --> Utf8 Class Initialized
INFO - 2020-02-29 16:32:29 --> URI Class Initialized
DEBUG - 2020-02-29 16:32:29 --> No URI present. Default controller set.
INFO - 2020-02-29 16:32:29 --> Router Class Initialized
INFO - 2020-02-29 16:32:29 --> Output Class Initialized
INFO - 2020-02-29 16:32:29 --> Security Class Initialized
DEBUG - 2020-02-29 16:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:32:29 --> Input Class Initialized
INFO - 2020-02-29 16:32:29 --> Language Class Initialized
INFO - 2020-02-29 16:32:29 --> Loader Class Initialized
INFO - 2020-02-29 16:32:29 --> Helper loaded: url_helper
INFO - 2020-02-29 16:32:29 --> Helper loaded: string_helper
INFO - 2020-02-29 16:32:29 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:32:29 --> Controller Class Initialized
INFO - 2020-02-29 16:32:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 16:32:29 --> Pagination Class Initialized
INFO - 2020-02-29 16:32:29 --> Model "M_show" initialized
INFO - 2020-02-29 16:32:30 --> Helper loaded: form_helper
INFO - 2020-02-29 16:32:30 --> Form Validation Class Initialized
INFO - 2020-02-29 16:32:30 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\header/header.php
INFO - 2020-02-29 16:32:30 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\home.php
INFO - 2020-02-29 16:32:30 --> Final output sent to browser
DEBUG - 2020-02-29 16:32:30 --> Total execution time: 0.9987
INFO - 2020-02-29 16:32:58 --> Config Class Initialized
INFO - 2020-02-29 16:32:58 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:32:58 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:32:58 --> Utf8 Class Initialized
INFO - 2020-02-29 16:32:58 --> URI Class Initialized
INFO - 2020-02-29 16:32:58 --> Router Class Initialized
INFO - 2020-02-29 16:32:58 --> Output Class Initialized
INFO - 2020-02-29 16:32:58 --> Security Class Initialized
DEBUG - 2020-02-29 16:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:32:58 --> Input Class Initialized
INFO - 2020-02-29 16:32:58 --> Language Class Initialized
INFO - 2020-02-29 16:32:58 --> Loader Class Initialized
INFO - 2020-02-29 16:32:58 --> Helper loaded: url_helper
INFO - 2020-02-29 16:32:58 --> Helper loaded: string_helper
INFO - 2020-02-29 16:32:58 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:32:58 --> Controller Class Initialized
INFO - 2020-02-29 16:32:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 16:32:58 --> Pagination Class Initialized
INFO - 2020-02-29 16:32:59 --> Model "M_show" initialized
INFO - 2020-02-29 16:32:59 --> Helper loaded: form_helper
INFO - 2020-02-29 16:32:59 --> Form Validation Class Initialized
INFO - 2020-02-29 16:32:59 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\header/header.php
INFO - 2020-02-29 16:32:59 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\vol1.php
INFO - 2020-02-29 16:32:59 --> Final output sent to browser
DEBUG - 2020-02-29 16:32:59 --> Total execution time: 0.7585
INFO - 2020-02-29 16:33:52 --> Config Class Initialized
INFO - 2020-02-29 16:33:52 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:33:52 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:33:52 --> Utf8 Class Initialized
INFO - 2020-02-29 16:33:52 --> URI Class Initialized
INFO - 2020-02-29 16:33:52 --> Router Class Initialized
INFO - 2020-02-29 16:33:52 --> Output Class Initialized
INFO - 2020-02-29 16:33:52 --> Security Class Initialized
DEBUG - 2020-02-29 16:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:33:52 --> Input Class Initialized
INFO - 2020-02-29 16:33:53 --> Language Class Initialized
INFO - 2020-02-29 16:33:53 --> Loader Class Initialized
INFO - 2020-02-29 16:33:53 --> Helper loaded: url_helper
INFO - 2020-02-29 16:33:53 --> Helper loaded: string_helper
INFO - 2020-02-29 16:33:53 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:33:53 --> Controller Class Initialized
INFO - 2020-02-29 16:33:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 16:33:53 --> Pagination Class Initialized
INFO - 2020-02-29 16:33:53 --> Model "M_show" initialized
INFO - 2020-02-29 16:33:53 --> Helper loaded: form_helper
INFO - 2020-02-29 16:33:53 --> Form Validation Class Initialized
INFO - 2020-02-29 16:33:53 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\header/header.php
INFO - 2020-02-29 16:33:53 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\home.php
INFO - 2020-02-29 16:33:53 --> Final output sent to browser
DEBUG - 2020-02-29 16:33:53 --> Total execution time: 0.8914
INFO - 2020-02-29 16:33:56 --> Config Class Initialized
INFO - 2020-02-29 16:33:56 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:33:56 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:33:56 --> Utf8 Class Initialized
INFO - 2020-02-29 16:33:56 --> URI Class Initialized
INFO - 2020-02-29 16:33:57 --> Router Class Initialized
INFO - 2020-02-29 16:33:57 --> Output Class Initialized
INFO - 2020-02-29 16:33:57 --> Security Class Initialized
DEBUG - 2020-02-29 16:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:33:57 --> Input Class Initialized
INFO - 2020-02-29 16:33:57 --> Language Class Initialized
INFO - 2020-02-29 16:33:57 --> Loader Class Initialized
INFO - 2020-02-29 16:33:57 --> Helper loaded: url_helper
INFO - 2020-02-29 16:33:57 --> Helper loaded: string_helper
INFO - 2020-02-29 16:33:57 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:33:57 --> Controller Class Initialized
INFO - 2020-02-29 16:33:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 16:33:57 --> Pagination Class Initialized
INFO - 2020-02-29 16:33:57 --> Model "M_show" initialized
INFO - 2020-02-29 16:33:57 --> Helper loaded: form_helper
INFO - 2020-02-29 16:33:57 --> Form Validation Class Initialized
INFO - 2020-02-29 16:33:57 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\header/header.php
INFO - 2020-02-29 16:33:57 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\beli.php
INFO - 2020-02-29 16:33:57 --> Final output sent to browser
DEBUG - 2020-02-29 16:33:57 --> Total execution time: 0.7976
INFO - 2020-02-29 16:34:26 --> Config Class Initialized
INFO - 2020-02-29 16:34:26 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:26 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:26 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:26 --> URI Class Initialized
INFO - 2020-02-29 16:34:26 --> Router Class Initialized
INFO - 2020-02-29 16:34:26 --> Output Class Initialized
INFO - 2020-02-29 16:34:26 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:26 --> Input Class Initialized
INFO - 2020-02-29 16:34:26 --> Language Class Initialized
INFO - 2020-02-29 16:34:26 --> Loader Class Initialized
INFO - 2020-02-29 16:34:27 --> Helper loaded: url_helper
INFO - 2020-02-29 16:34:27 --> Helper loaded: string_helper
INFO - 2020-02-29 16:34:27 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:34:27 --> Controller Class Initialized
INFO - 2020-02-29 16:34:27 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:34:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:34:27 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:34:27 --> Helper loaded: form_helper
INFO - 2020-02-29 16:34:27 --> Form Validation Class Initialized
INFO - 2020-02-29 16:34:27 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:34:27 --> Final output sent to browser
INFO - 2020-02-29 16:34:27 --> Config Class Initialized
INFO - 2020-02-29 16:34:27 --> Config Class Initialized
DEBUG - 2020-02-29 16:34:27 --> Total execution time: 0.7356
INFO - 2020-02-29 16:34:27 --> Config Class Initialized
INFO - 2020-02-29 16:34:27 --> Config Class Initialized
INFO - 2020-02-29 16:34:27 --> Config Class Initialized
INFO - 2020-02-29 16:34:27 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:27 --> Config Class Initialized
INFO - 2020-02-29 16:34:27 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:27 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:27 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:27 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:27 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:27 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:27 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:27 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:34:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:27 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:27 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:27 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:27 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:27 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:27 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:27 --> URI Class Initialized
INFO - 2020-02-29 16:34:27 --> URI Class Initialized
INFO - 2020-02-29 16:34:27 --> URI Class Initialized
INFO - 2020-02-29 16:34:27 --> URI Class Initialized
INFO - 2020-02-29 16:34:27 --> URI Class Initialized
INFO - 2020-02-29 16:34:27 --> URI Class Initialized
INFO - 2020-02-29 16:34:27 --> Router Class Initialized
INFO - 2020-02-29 16:34:27 --> Router Class Initialized
INFO - 2020-02-29 16:34:27 --> Router Class Initialized
INFO - 2020-02-29 16:34:27 --> Router Class Initialized
INFO - 2020-02-29 16:34:27 --> Router Class Initialized
INFO - 2020-02-29 16:34:27 --> Router Class Initialized
INFO - 2020-02-29 16:34:27 --> Output Class Initialized
INFO - 2020-02-29 16:34:27 --> Security Class Initialized
INFO - 2020-02-29 16:34:27 --> Output Class Initialized
INFO - 2020-02-29 16:34:27 --> Output Class Initialized
INFO - 2020-02-29 16:34:27 --> Output Class Initialized
INFO - 2020-02-29 16:34:27 --> Output Class Initialized
INFO - 2020-02-29 16:34:27 --> Output Class Initialized
DEBUG - 2020-02-29 16:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:27 --> Security Class Initialized
INFO - 2020-02-29 16:34:27 --> Security Class Initialized
INFO - 2020-02-29 16:34:27 --> Security Class Initialized
INFO - 2020-02-29 16:34:27 --> Security Class Initialized
INFO - 2020-02-29 16:34:27 --> Security Class Initialized
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
DEBUG - 2020-02-29 16:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
INFO - 2020-02-29 16:34:28 --> Loader Class Initialized
ERROR - 2020-02-29 16:34:28 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 16:34:28 --> Helper loaded: url_helper
ERROR - 2020-02-29 16:34:28 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-29 16:34:28 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 16:34:28 --> Loader Class Initialized
ERROR - 2020-02-29 16:34:28 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-29 16:34:28 --> Helper loaded: url_helper
INFO - 2020-02-29 16:34:28 --> Helper loaded: string_helper
INFO - 2020-02-29 16:34:28 --> Config Class Initialized
INFO - 2020-02-29 16:34:28 --> Config Class Initialized
INFO - 2020-02-29 16:34:28 --> Config Class Initialized
INFO - 2020-02-29 16:34:28 --> Config Class Initialized
INFO - 2020-02-29 16:34:28 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:28 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:28 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:28 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:28 --> Helper loaded: string_helper
INFO - 2020-02-29 16:34:28 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:28 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:28 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-29 16:34:28 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:28 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:28 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:28 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:28 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-29 16:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:34:28 --> Controller Class Initialized
INFO - 2020-02-29 16:34:28 --> URI Class Initialized
INFO - 2020-02-29 16:34:28 --> URI Class Initialized
INFO - 2020-02-29 16:34:28 --> URI Class Initialized
INFO - 2020-02-29 16:34:28 --> URI Class Initialized
INFO - 2020-02-29 16:34:28 --> Router Class Initialized
INFO - 2020-02-29 16:34:28 --> Router Class Initialized
INFO - 2020-02-29 16:34:28 --> Router Class Initialized
INFO - 2020-02-29 16:34:28 --> Router Class Initialized
INFO - 2020-02-29 16:34:28 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:34:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:34:28 --> Output Class Initialized
INFO - 2020-02-29 16:34:28 --> Output Class Initialized
INFO - 2020-02-29 16:34:28 --> Output Class Initialized
INFO - 2020-02-29 16:34:28 --> Output Class Initialized
INFO - 2020-02-29 16:34:28 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:34:28 --> Security Class Initialized
INFO - 2020-02-29 16:34:28 --> Security Class Initialized
INFO - 2020-02-29 16:34:28 --> Security Class Initialized
INFO - 2020-02-29 16:34:28 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:28 --> Helper loaded: form_helper
DEBUG - 2020-02-29 16:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
INFO - 2020-02-29 16:34:28 --> Form Validation Class Initialized
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
ERROR - 2020-02-29 16:34:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 16:34:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-29 16:34:28 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 16:34:28 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 16:34:28 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-29 16:34:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 16:34:28 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:34:28 --> Config Class Initialized
INFO - 2020-02-29 16:34:28 --> Config Class Initialized
INFO - 2020-02-29 16:34:28 --> Config Class Initialized
INFO - 2020-02-29 16:34:28 --> Config Class Initialized
INFO - 2020-02-29 16:34:28 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:28 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:28 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:28 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:28 --> Final output sent to browser
DEBUG - 2020-02-29 16:34:28 --> Total execution time: 1.1847
DEBUG - 2020-02-29 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:28 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:28 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:28 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:34:28 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:28 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:28 --> Controller Class Initialized
INFO - 2020-02-29 16:34:28 --> URI Class Initialized
INFO - 2020-02-29 16:34:28 --> URI Class Initialized
INFO - 2020-02-29 16:34:28 --> URI Class Initialized
INFO - 2020-02-29 16:34:28 --> URI Class Initialized
INFO - 2020-02-29 16:34:28 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:34:28 --> Router Class Initialized
INFO - 2020-02-29 16:34:28 --> Router Class Initialized
INFO - 2020-02-29 16:34:28 --> Router Class Initialized
INFO - 2020-02-29 16:34:28 --> Router Class Initialized
INFO - 2020-02-29 16:34:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:34:28 --> Output Class Initialized
INFO - 2020-02-29 16:34:28 --> Output Class Initialized
INFO - 2020-02-29 16:34:28 --> Output Class Initialized
INFO - 2020-02-29 16:34:28 --> Output Class Initialized
INFO - 2020-02-29 16:34:28 --> Security Class Initialized
INFO - 2020-02-29 16:34:28 --> Security Class Initialized
INFO - 2020-02-29 16:34:28 --> Security Class Initialized
INFO - 2020-02-29 16:34:28 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:34:28 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:28 --> Helper loaded: form_helper
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
INFO - 2020-02-29 16:34:28 --> Input Class Initialized
INFO - 2020-02-29 16:34:28 --> Form Validation Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
INFO - 2020-02-29 16:34:28 --> Language Class Initialized
ERROR - 2020-02-29 16:34:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 16:34:28 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 16:34:28 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-29 16:34:28 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-29 16:34:28 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-29 16:34:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 16:34:29 --> Config Class Initialized
INFO - 2020-02-29 16:34:29 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:29 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:34:29 --> Final output sent to browser
DEBUG - 2020-02-29 16:34:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:29 --> Total execution time: 1.6213
INFO - 2020-02-29 16:34:29 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:29 --> URI Class Initialized
INFO - 2020-02-29 16:34:29 --> Router Class Initialized
INFO - 2020-02-29 16:34:29 --> Output Class Initialized
INFO - 2020-02-29 16:34:29 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:29 --> Input Class Initialized
INFO - 2020-02-29 16:34:29 --> Language Class Initialized
ERROR - 2020-02-29 16:34:29 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 16:34:29 --> Config Class Initialized
INFO - 2020-02-29 16:34:29 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:29 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:29 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:29 --> URI Class Initialized
INFO - 2020-02-29 16:34:29 --> Router Class Initialized
INFO - 2020-02-29 16:34:29 --> Output Class Initialized
INFO - 2020-02-29 16:34:29 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:29 --> Input Class Initialized
INFO - 2020-02-29 16:34:29 --> Language Class Initialized
ERROR - 2020-02-29 16:34:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 16:34:29 --> Config Class Initialized
INFO - 2020-02-29 16:34:29 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:29 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:29 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:29 --> URI Class Initialized
INFO - 2020-02-29 16:34:29 --> Router Class Initialized
INFO - 2020-02-29 16:34:29 --> Output Class Initialized
INFO - 2020-02-29 16:34:29 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:30 --> Input Class Initialized
INFO - 2020-02-29 16:34:30 --> Language Class Initialized
ERROR - 2020-02-29 16:34:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:34:30 --> Config Class Initialized
INFO - 2020-02-29 16:34:30 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:30 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:30 --> URI Class Initialized
INFO - 2020-02-29 16:34:30 --> Router Class Initialized
INFO - 2020-02-29 16:34:30 --> Output Class Initialized
INFO - 2020-02-29 16:34:30 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:30 --> Input Class Initialized
INFO - 2020-02-29 16:34:30 --> Language Class Initialized
ERROR - 2020-02-29 16:34:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:34:30 --> Config Class Initialized
INFO - 2020-02-29 16:34:30 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:30 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:30 --> URI Class Initialized
INFO - 2020-02-29 16:34:30 --> Router Class Initialized
INFO - 2020-02-29 16:34:30 --> Output Class Initialized
INFO - 2020-02-29 16:34:30 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:30 --> Input Class Initialized
INFO - 2020-02-29 16:34:30 --> Language Class Initialized
ERROR - 2020-02-29 16:34:30 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 16:34:30 --> Config Class Initialized
INFO - 2020-02-29 16:34:30 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:30 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:30 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:30 --> URI Class Initialized
INFO - 2020-02-29 16:34:30 --> Router Class Initialized
INFO - 2020-02-29 16:34:30 --> Output Class Initialized
INFO - 2020-02-29 16:34:30 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:31 --> Input Class Initialized
INFO - 2020-02-29 16:34:31 --> Language Class Initialized
ERROR - 2020-02-29 16:34:31 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 16:34:31 --> Config Class Initialized
INFO - 2020-02-29 16:34:31 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:31 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:31 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:31 --> URI Class Initialized
INFO - 2020-02-29 16:34:31 --> Router Class Initialized
INFO - 2020-02-29 16:34:31 --> Output Class Initialized
INFO - 2020-02-29 16:34:31 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:31 --> Input Class Initialized
INFO - 2020-02-29 16:34:31 --> Language Class Initialized
ERROR - 2020-02-29 16:34:31 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 16:34:31 --> Config Class Initialized
INFO - 2020-02-29 16:34:31 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:32 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:32 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:32 --> URI Class Initialized
INFO - 2020-02-29 16:34:32 --> Router Class Initialized
INFO - 2020-02-29 16:34:32 --> Output Class Initialized
INFO - 2020-02-29 16:34:32 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:32 --> Input Class Initialized
INFO - 2020-02-29 16:34:32 --> Language Class Initialized
ERROR - 2020-02-29 16:34:32 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 16:34:32 --> Config Class Initialized
INFO - 2020-02-29 16:34:32 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:32 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:32 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:32 --> URI Class Initialized
INFO - 2020-02-29 16:34:32 --> Router Class Initialized
INFO - 2020-02-29 16:34:32 --> Output Class Initialized
INFO - 2020-02-29 16:34:33 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:33 --> Input Class Initialized
INFO - 2020-02-29 16:34:33 --> Language Class Initialized
INFO - 2020-02-29 16:34:33 --> Loader Class Initialized
INFO - 2020-02-29 16:34:33 --> Helper loaded: url_helper
INFO - 2020-02-29 16:34:33 --> Helper loaded: string_helper
INFO - 2020-02-29 16:34:33 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:34:33 --> Controller Class Initialized
INFO - 2020-02-29 16:34:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 16:34:33 --> Pagination Class Initialized
INFO - 2020-02-29 16:34:33 --> Model "M_show" initialized
INFO - 2020-02-29 16:34:33 --> Helper loaded: form_helper
INFO - 2020-02-29 16:34:33 --> Form Validation Class Initialized
INFO - 2020-02-29 16:34:33 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\header/header.php
INFO - 2020-02-29 16:34:33 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\beli.php
INFO - 2020-02-29 16:34:33 --> Final output sent to browser
DEBUG - 2020-02-29 16:34:33 --> Total execution time: 1.1184
INFO - 2020-02-29 16:34:41 --> Config Class Initialized
INFO - 2020-02-29 16:34:41 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:41 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:41 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:41 --> URI Class Initialized
INFO - 2020-02-29 16:34:41 --> Router Class Initialized
INFO - 2020-02-29 16:34:41 --> Output Class Initialized
INFO - 2020-02-29 16:34:41 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:41 --> Input Class Initialized
INFO - 2020-02-29 16:34:41 --> Language Class Initialized
INFO - 2020-02-29 16:34:41 --> Loader Class Initialized
INFO - 2020-02-29 16:34:41 --> Helper loaded: url_helper
INFO - 2020-02-29 16:34:41 --> Helper loaded: string_helper
INFO - 2020-02-29 16:34:41 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:34:41 --> Controller Class Initialized
INFO - 2020-02-29 16:34:41 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:34:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:34:41 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:34:41 --> Helper loaded: form_helper
INFO - 2020-02-29 16:34:41 --> Form Validation Class Initialized
INFO - 2020-02-29 16:34:41 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:34:41 --> Final output sent to browser
DEBUG - 2020-02-29 16:34:41 --> Total execution time: 0.7065
INFO - 2020-02-29 16:34:41 --> Config Class Initialized
INFO - 2020-02-29 16:34:41 --> Config Class Initialized
INFO - 2020-02-29 16:34:41 --> Config Class Initialized
INFO - 2020-02-29 16:34:41 --> Config Class Initialized
INFO - 2020-02-29 16:34:41 --> Config Class Initialized
INFO - 2020-02-29 16:34:41 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:42 --> Config Class Initialized
INFO - 2020-02-29 16:34:42 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:42 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:42 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:42 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:42 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:42 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:42 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:34:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:42 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:42 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:42 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:42 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:42 --> URI Class Initialized
INFO - 2020-02-29 16:34:42 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:42 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:42 --> URI Class Initialized
INFO - 2020-02-29 16:34:42 --> URI Class Initialized
INFO - 2020-02-29 16:34:42 --> Router Class Initialized
INFO - 2020-02-29 16:34:42 --> URI Class Initialized
INFO - 2020-02-29 16:34:42 --> URI Class Initialized
INFO - 2020-02-29 16:34:42 --> URI Class Initialized
INFO - 2020-02-29 16:34:42 --> Output Class Initialized
INFO - 2020-02-29 16:34:42 --> Router Class Initialized
INFO - 2020-02-29 16:34:42 --> Router Class Initialized
INFO - 2020-02-29 16:34:42 --> Router Class Initialized
INFO - 2020-02-29 16:34:42 --> Router Class Initialized
INFO - 2020-02-29 16:34:42 --> Router Class Initialized
INFO - 2020-02-29 16:34:42 --> Security Class Initialized
INFO - 2020-02-29 16:34:42 --> Output Class Initialized
INFO - 2020-02-29 16:34:42 --> Output Class Initialized
INFO - 2020-02-29 16:34:42 --> Output Class Initialized
INFO - 2020-02-29 16:34:42 --> Output Class Initialized
INFO - 2020-02-29 16:34:42 --> Output Class Initialized
INFO - 2020-02-29 16:34:42 --> Security Class Initialized
INFO - 2020-02-29 16:34:42 --> Security Class Initialized
INFO - 2020-02-29 16:34:42 --> Security Class Initialized
INFO - 2020-02-29 16:34:42 --> Security Class Initialized
INFO - 2020-02-29 16:34:42 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:42 --> Input Class Initialized
DEBUG - 2020-02-29 16:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:42 --> Input Class Initialized
INFO - 2020-02-29 16:34:42 --> Input Class Initialized
INFO - 2020-02-29 16:34:42 --> Input Class Initialized
INFO - 2020-02-29 16:34:42 --> Input Class Initialized
INFO - 2020-02-29 16:34:42 --> Input Class Initialized
INFO - 2020-02-29 16:34:42 --> Language Class Initialized
INFO - 2020-02-29 16:34:42 --> Language Class Initialized
INFO - 2020-02-29 16:34:42 --> Language Class Initialized
INFO - 2020-02-29 16:34:42 --> Language Class Initialized
ERROR - 2020-02-29 16:34:42 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-29 16:34:42 --> Language Class Initialized
INFO - 2020-02-29 16:34:42 --> Language Class Initialized
ERROR - 2020-02-29 16:34:42 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-29 16:34:42 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-29 16:34:42 --> Loader Class Initialized
ERROR - 2020-02-29 16:34:42 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 16:34:42 --> Loader Class Initialized
INFO - 2020-02-29 16:34:42 --> Config Class Initialized
INFO - 2020-02-29 16:34:42 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:42 --> Helper loaded: url_helper
INFO - 2020-02-29 16:34:42 --> Helper loaded: url_helper
INFO - 2020-02-29 16:34:42 --> Config Class Initialized
INFO - 2020-02-29 16:34:42 --> Config Class Initialized
INFO - 2020-02-29 16:34:42 --> Config Class Initialized
INFO - 2020-02-29 16:34:42 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:42 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:42 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:42 --> Helper loaded: string_helper
INFO - 2020-02-29 16:34:42 --> Helper loaded: string_helper
DEBUG - 2020-02-29 16:34:42 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:42 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:34:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:42 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:42 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:34:42 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:42 --> Database Driver Class Initialized
INFO - 2020-02-29 16:34:42 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:42 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:42 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:42 --> URI Class Initialized
DEBUG - 2020-02-29 16:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-29 16:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:34:42 --> URI Class Initialized
INFO - 2020-02-29 16:34:42 --> URI Class Initialized
INFO - 2020-02-29 16:34:42 --> URI Class Initialized
INFO - 2020-02-29 16:34:42 --> Router Class Initialized
INFO - 2020-02-29 16:34:42 --> Controller Class Initialized
INFO - 2020-02-29 16:34:42 --> Router Class Initialized
INFO - 2020-02-29 16:34:42 --> Router Class Initialized
INFO - 2020-02-29 16:34:42 --> Output Class Initialized
INFO - 2020-02-29 16:34:42 --> Router Class Initialized
INFO - 2020-02-29 16:34:42 --> Output Class Initialized
INFO - 2020-02-29 16:34:42 --> Output Class Initialized
INFO - 2020-02-29 16:34:42 --> Output Class Initialized
INFO - 2020-02-29 16:34:42 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:34:42 --> Security Class Initialized
INFO - 2020-02-29 16:34:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:34:42 --> Security Class Initialized
INFO - 2020-02-29 16:34:42 --> Security Class Initialized
INFO - 2020-02-29 16:34:42 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:42 --> Input Class Initialized
DEBUG - 2020-02-29 16:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:42 --> Model "M_pesan" initialized
DEBUG - 2020-02-29 16:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:42 --> Input Class Initialized
INFO - 2020-02-29 16:34:42 --> Input Class Initialized
INFO - 2020-02-29 16:34:42 --> Input Class Initialized
INFO - 2020-02-29 16:34:42 --> Language Class Initialized
INFO - 2020-02-29 16:34:42 --> Helper loaded: form_helper
INFO - 2020-02-29 16:34:42 --> Form Validation Class Initialized
INFO - 2020-02-29 16:34:42 --> Language Class Initialized
INFO - 2020-02-29 16:34:42 --> Language Class Initialized
ERROR - 2020-02-29 16:34:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 16:34:42 --> Language Class Initialized
ERROR - 2020-02-29 16:34:42 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 16:34:42 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-29 16:34:42 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-29 16:34:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 16:34:42 --> Config Class Initialized
INFO - 2020-02-29 16:34:42 --> Hooks Class Initialized
ERROR - 2020-02-29 16:34:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 16:34:42 --> Config Class Initialized
INFO - 2020-02-29 16:34:42 --> Config Class Initialized
INFO - 2020-02-29 16:34:42 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:42 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:42 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-29 16:34:42 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:42 --> Config Class Initialized
INFO - 2020-02-29 16:34:42 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:42 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:42 --> Final output sent to browser
DEBUG - 2020-02-29 16:34:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:42 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:43 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:34:43 --> Total execution time: 1.0514
INFO - 2020-02-29 16:34:43 --> URI Class Initialized
INFO - 2020-02-29 16:34:43 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:34:43 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:43 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:43 --> URI Class Initialized
INFO - 2020-02-29 16:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:34:43 --> URI Class Initialized
INFO - 2020-02-29 16:34:43 --> Router Class Initialized
INFO - 2020-02-29 16:34:43 --> Router Class Initialized
INFO - 2020-02-29 16:34:43 --> URI Class Initialized
INFO - 2020-02-29 16:34:43 --> Controller Class Initialized
INFO - 2020-02-29 16:34:43 --> Router Class Initialized
INFO - 2020-02-29 16:34:43 --> Router Class Initialized
INFO - 2020-02-29 16:34:43 --> Output Class Initialized
INFO - 2020-02-29 16:34:43 --> Output Class Initialized
INFO - 2020-02-29 16:34:43 --> Security Class Initialized
INFO - 2020-02-29 16:34:43 --> Security Class Initialized
INFO - 2020-02-29 16:34:43 --> Output Class Initialized
INFO - 2020-02-29 16:34:43 --> Output Class Initialized
INFO - 2020-02-29 16:34:43 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:34:43 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-29 16:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:43 --> Security Class Initialized
INFO - 2020-02-29 16:34:43 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:43 --> Input Class Initialized
INFO - 2020-02-29 16:34:43 --> Input Class Initialized
INFO - 2020-02-29 16:34:43 --> Model "M_pesan" initialized
DEBUG - 2020-02-29 16:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:43 --> Input Class Initialized
INFO - 2020-02-29 16:34:43 --> Input Class Initialized
INFO - 2020-02-29 16:34:43 --> Language Class Initialized
INFO - 2020-02-29 16:34:43 --> Language Class Initialized
INFO - 2020-02-29 16:34:43 --> Helper loaded: form_helper
INFO - 2020-02-29 16:34:43 --> Form Validation Class Initialized
INFO - 2020-02-29 16:34:43 --> Language Class Initialized
INFO - 2020-02-29 16:34:43 --> Language Class Initialized
ERROR - 2020-02-29 16:34:43 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-29 16:34:43 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-29 16:34:43 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-29 16:34:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-29 16:34:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 16:34:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 16:34:43 --> Config Class Initialized
INFO - 2020-02-29 16:34:43 --> Hooks Class Initialized
INFO - 2020-02-29 16:34:43 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:34:43 --> Final output sent to browser
DEBUG - 2020-02-29 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:34:43 --> Total execution time: 1.5260
INFO - 2020-02-29 16:34:43 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:43 --> URI Class Initialized
INFO - 2020-02-29 16:34:43 --> Router Class Initialized
INFO - 2020-02-29 16:34:43 --> Output Class Initialized
INFO - 2020-02-29 16:34:43 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:43 --> Input Class Initialized
INFO - 2020-02-29 16:34:43 --> Language Class Initialized
ERROR - 2020-02-29 16:34:43 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 16:34:43 --> Config Class Initialized
INFO - 2020-02-29 16:34:43 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:43 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:43 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:43 --> URI Class Initialized
INFO - 2020-02-29 16:34:43 --> Router Class Initialized
INFO - 2020-02-29 16:34:43 --> Output Class Initialized
INFO - 2020-02-29 16:34:43 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:43 --> Input Class Initialized
INFO - 2020-02-29 16:34:43 --> Language Class Initialized
ERROR - 2020-02-29 16:34:43 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 16:34:44 --> Config Class Initialized
INFO - 2020-02-29 16:34:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:44 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:44 --> URI Class Initialized
INFO - 2020-02-29 16:34:44 --> Router Class Initialized
INFO - 2020-02-29 16:34:44 --> Output Class Initialized
INFO - 2020-02-29 16:34:44 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:44 --> Input Class Initialized
INFO - 2020-02-29 16:34:44 --> Language Class Initialized
ERROR - 2020-02-29 16:34:44 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 16:34:44 --> Config Class Initialized
INFO - 2020-02-29 16:34:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:44 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:44 --> URI Class Initialized
INFO - 2020-02-29 16:34:44 --> Router Class Initialized
INFO - 2020-02-29 16:34:44 --> Output Class Initialized
INFO - 2020-02-29 16:34:44 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:44 --> Input Class Initialized
INFO - 2020-02-29 16:34:44 --> Language Class Initialized
ERROR - 2020-02-29 16:34:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:34:44 --> Config Class Initialized
INFO - 2020-02-29 16:34:44 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:44 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:44 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:44 --> URI Class Initialized
INFO - 2020-02-29 16:34:44 --> Router Class Initialized
INFO - 2020-02-29 16:34:44 --> Output Class Initialized
INFO - 2020-02-29 16:34:44 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:44 --> Input Class Initialized
INFO - 2020-02-29 16:34:44 --> Language Class Initialized
ERROR - 2020-02-29 16:34:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:34:45 --> Config Class Initialized
INFO - 2020-02-29 16:34:45 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:45 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:45 --> URI Class Initialized
INFO - 2020-02-29 16:34:45 --> Router Class Initialized
INFO - 2020-02-29 16:34:45 --> Output Class Initialized
INFO - 2020-02-29 16:34:45 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:45 --> Input Class Initialized
INFO - 2020-02-29 16:34:45 --> Language Class Initialized
ERROR - 2020-02-29 16:34:45 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 16:34:45 --> Config Class Initialized
INFO - 2020-02-29 16:34:45 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:45 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:45 --> URI Class Initialized
INFO - 2020-02-29 16:34:45 --> Router Class Initialized
INFO - 2020-02-29 16:34:45 --> Output Class Initialized
INFO - 2020-02-29 16:34:45 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:45 --> Input Class Initialized
INFO - 2020-02-29 16:34:45 --> Language Class Initialized
ERROR - 2020-02-29 16:34:45 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 16:34:45 --> Config Class Initialized
INFO - 2020-02-29 16:34:45 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:45 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:45 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:45 --> URI Class Initialized
INFO - 2020-02-29 16:34:45 --> Router Class Initialized
INFO - 2020-02-29 16:34:45 --> Output Class Initialized
INFO - 2020-02-29 16:34:45 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:45 --> Input Class Initialized
INFO - 2020-02-29 16:34:45 --> Language Class Initialized
ERROR - 2020-02-29 16:34:46 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 16:34:46 --> Config Class Initialized
INFO - 2020-02-29 16:34:46 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:46 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:46 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:46 --> URI Class Initialized
INFO - 2020-02-29 16:34:46 --> Router Class Initialized
INFO - 2020-02-29 16:34:46 --> Output Class Initialized
INFO - 2020-02-29 16:34:46 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:46 --> Input Class Initialized
INFO - 2020-02-29 16:34:46 --> Language Class Initialized
ERROR - 2020-02-29 16:34:46 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 16:34:54 --> Config Class Initialized
INFO - 2020-02-29 16:34:54 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:54 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:54 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:54 --> URI Class Initialized
INFO - 2020-02-29 16:34:54 --> Router Class Initialized
INFO - 2020-02-29 16:34:54 --> Output Class Initialized
INFO - 2020-02-29 16:34:54 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:54 --> Input Class Initialized
INFO - 2020-02-29 16:34:54 --> Language Class Initialized
INFO - 2020-02-29 16:34:54 --> Loader Class Initialized
INFO - 2020-02-29 16:34:54 --> Helper loaded: url_helper
INFO - 2020-02-29 16:34:54 --> Helper loaded: string_helper
INFO - 2020-02-29 16:34:55 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:34:55 --> Controller Class Initialized
INFO - 2020-02-29 16:34:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 16:34:55 --> Pagination Class Initialized
INFO - 2020-02-29 16:34:55 --> Model "M_show" initialized
INFO - 2020-02-29 16:34:55 --> Helper loaded: form_helper
INFO - 2020-02-29 16:34:55 --> Form Validation Class Initialized
INFO - 2020-02-29 16:34:55 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\header/header.php
INFO - 2020-02-29 16:34:55 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\beli.php
INFO - 2020-02-29 16:34:55 --> Final output sent to browser
DEBUG - 2020-02-29 16:34:55 --> Total execution time: 0.8175
INFO - 2020-02-29 16:34:59 --> Config Class Initialized
INFO - 2020-02-29 16:34:59 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:34:59 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:34:59 --> Utf8 Class Initialized
INFO - 2020-02-29 16:34:59 --> URI Class Initialized
INFO - 2020-02-29 16:34:59 --> Router Class Initialized
INFO - 2020-02-29 16:34:59 --> Output Class Initialized
INFO - 2020-02-29 16:34:59 --> Security Class Initialized
DEBUG - 2020-02-29 16:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:34:59 --> Input Class Initialized
INFO - 2020-02-29 16:34:59 --> Language Class Initialized
INFO - 2020-02-29 16:34:59 --> Loader Class Initialized
INFO - 2020-02-29 16:34:59 --> Helper loaded: url_helper
INFO - 2020-02-29 16:34:59 --> Helper loaded: string_helper
INFO - 2020-02-29 16:34:59 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:35:00 --> Controller Class Initialized
INFO - 2020-02-29 16:35:00 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:35:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:35:00 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:35:00 --> Helper loaded: form_helper
INFO - 2020-02-29 16:35:00 --> Form Validation Class Initialized
INFO - 2020-02-29 16:35:00 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:35:00 --> Final output sent to browser
INFO - 2020-02-29 16:35:00 --> Config Class Initialized
INFO - 2020-02-29 16:35:00 --> Config Class Initialized
INFO - 2020-02-29 16:35:00 --> Config Class Initialized
INFO - 2020-02-29 16:35:00 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:00 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:35:00 --> Total execution time: 0.7071
INFO - 2020-02-29 16:35:00 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:00 --> Config Class Initialized
INFO - 2020-02-29 16:35:00 --> Config Class Initialized
INFO - 2020-02-29 16:35:00 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:00 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:35:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:35:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:35:00 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:00 --> Config Class Initialized
INFO - 2020-02-29 16:35:00 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:00 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:00 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:00 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:35:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:35:00 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:00 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:00 --> URI Class Initialized
DEBUG - 2020-02-29 16:35:00 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:00 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:00 --> URI Class Initialized
INFO - 2020-02-29 16:35:00 --> URI Class Initialized
INFO - 2020-02-29 16:35:00 --> URI Class Initialized
INFO - 2020-02-29 16:35:00 --> URI Class Initialized
INFO - 2020-02-29 16:35:00 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:00 --> Router Class Initialized
INFO - 2020-02-29 16:35:00 --> Router Class Initialized
INFO - 2020-02-29 16:35:00 --> Router Class Initialized
INFO - 2020-02-29 16:35:00 --> Output Class Initialized
INFO - 2020-02-29 16:35:00 --> Router Class Initialized
INFO - 2020-02-29 16:35:00 --> Output Class Initialized
INFO - 2020-02-29 16:35:00 --> Router Class Initialized
INFO - 2020-02-29 16:35:00 --> URI Class Initialized
INFO - 2020-02-29 16:35:00 --> Output Class Initialized
INFO - 2020-02-29 16:35:00 --> Security Class Initialized
INFO - 2020-02-29 16:35:00 --> Security Class Initialized
INFO - 2020-02-29 16:35:00 --> Output Class Initialized
INFO - 2020-02-29 16:35:00 --> Router Class Initialized
INFO - 2020-02-29 16:35:00 --> Output Class Initialized
INFO - 2020-02-29 16:35:00 --> Security Class Initialized
DEBUG - 2020-02-29 16:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:00 --> Security Class Initialized
INFO - 2020-02-29 16:35:00 --> Security Class Initialized
INFO - 2020-02-29 16:35:00 --> Output Class Initialized
INFO - 2020-02-29 16:35:00 --> Input Class Initialized
INFO - 2020-02-29 16:35:00 --> Input Class Initialized
INFO - 2020-02-29 16:35:00 --> Input Class Initialized
DEBUG - 2020-02-29 16:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:00 --> Security Class Initialized
DEBUG - 2020-02-29 16:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:00 --> Input Class Initialized
INFO - 2020-02-29 16:35:00 --> Input Class Initialized
INFO - 2020-02-29 16:35:00 --> Language Class Initialized
INFO - 2020-02-29 16:35:00 --> Language Class Initialized
DEBUG - 2020-02-29 16:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:00 --> Language Class Initialized
INFO - 2020-02-29 16:35:00 --> Input Class Initialized
INFO - 2020-02-29 16:35:00 --> Language Class Initialized
INFO - 2020-02-29 16:35:00 --> Language Class Initialized
ERROR - 2020-02-29 16:35:00 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-29 16:35:00 --> Loader Class Initialized
INFO - 2020-02-29 16:35:00 --> Loader Class Initialized
ERROR - 2020-02-29 16:35:00 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 16:35:00 --> Helper loaded: url_helper
INFO - 2020-02-29 16:35:00 --> Helper loaded: url_helper
INFO - 2020-02-29 16:35:00 --> Language Class Initialized
ERROR - 2020-02-29 16:35:00 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-29 16:35:00 --> Config Class Initialized
INFO - 2020-02-29 16:35:00 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:00 --> Helper loaded: string_helper
INFO - 2020-02-29 16:35:00 --> Helper loaded: string_helper
ERROR - 2020-02-29 16:35:00 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 16:35:00 --> Config Class Initialized
INFO - 2020-02-29 16:35:00 --> Config Class Initialized
INFO - 2020-02-29 16:35:00 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:00 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:35:00 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:00 --> Database Driver Class Initialized
INFO - 2020-02-29 16:35:00 --> Database Driver Class Initialized
INFO - 2020-02-29 16:35:00 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:35:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:35:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-29 16:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:35:00 --> Config Class Initialized
INFO - 2020-02-29 16:35:00 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:00 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:00 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:35:00 --> URI Class Initialized
INFO - 2020-02-29 16:35:00 --> URI Class Initialized
INFO - 2020-02-29 16:35:00 --> URI Class Initialized
INFO - 2020-02-29 16:35:00 --> Router Class Initialized
INFO - 2020-02-29 16:35:00 --> Controller Class Initialized
DEBUG - 2020-02-29 16:35:00 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:00 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:00 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:35:00 --> Router Class Initialized
INFO - 2020-02-29 16:35:00 --> Router Class Initialized
INFO - 2020-02-29 16:35:00 --> Output Class Initialized
INFO - 2020-02-29 16:35:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:35:00 --> Security Class Initialized
INFO - 2020-02-29 16:35:00 --> URI Class Initialized
INFO - 2020-02-29 16:35:00 --> Output Class Initialized
INFO - 2020-02-29 16:35:00 --> Output Class Initialized
INFO - 2020-02-29 16:35:01 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:35:01 --> Security Class Initialized
DEBUG - 2020-02-29 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:01 --> Security Class Initialized
INFO - 2020-02-29 16:35:01 --> Router Class Initialized
DEBUG - 2020-02-29 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:01 --> Output Class Initialized
INFO - 2020-02-29 16:35:01 --> Helper loaded: form_helper
INFO - 2020-02-29 16:35:01 --> Input Class Initialized
DEBUG - 2020-02-29 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:01 --> Form Validation Class Initialized
INFO - 2020-02-29 16:35:01 --> Input Class Initialized
INFO - 2020-02-29 16:35:01 --> Input Class Initialized
INFO - 2020-02-29 16:35:01 --> Language Class Initialized
INFO - 2020-02-29 16:35:01 --> Language Class Initialized
INFO - 2020-02-29 16:35:01 --> Security Class Initialized
ERROR - 2020-02-29 16:35:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 16:35:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-29 16:35:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-29 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:01 --> Language Class Initialized
ERROR - 2020-02-29 16:35:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:35:01 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:35:01 --> Input Class Initialized
ERROR - 2020-02-29 16:35:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:35:01 --> Config Class Initialized
INFO - 2020-02-29 16:35:01 --> Config Class Initialized
INFO - 2020-02-29 16:35:01 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:01 --> Final output sent to browser
INFO - 2020-02-29 16:35:01 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:01 --> Language Class Initialized
INFO - 2020-02-29 16:35:01 --> Config Class Initialized
INFO - 2020-02-29 16:35:01 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:35:01 --> Total execution time: 0.8760
ERROR - 2020-02-29 16:35:01 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-29 16:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:01 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:01 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-29 16:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:01 --> Config Class Initialized
INFO - 2020-02-29 16:35:01 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:01 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:01 --> Controller Class Initialized
INFO - 2020-02-29 16:35:01 --> URI Class Initialized
INFO - 2020-02-29 16:35:01 --> URI Class Initialized
INFO - 2020-02-29 16:35:01 --> Router Class Initialized
INFO - 2020-02-29 16:35:01 --> Router Class Initialized
INFO - 2020-02-29 16:35:01 --> URI Class Initialized
DEBUG - 2020-02-29 16:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:01 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:35:01 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:01 --> Router Class Initialized
INFO - 2020-02-29 16:35:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:35:01 --> Output Class Initialized
INFO - 2020-02-29 16:35:01 --> Output Class Initialized
INFO - 2020-02-29 16:35:01 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:35:01 --> Security Class Initialized
INFO - 2020-02-29 16:35:01 --> Output Class Initialized
INFO - 2020-02-29 16:35:01 --> URI Class Initialized
INFO - 2020-02-29 16:35:01 --> Security Class Initialized
DEBUG - 2020-02-29 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:01 --> Router Class Initialized
INFO - 2020-02-29 16:35:01 --> Security Class Initialized
INFO - 2020-02-29 16:35:01 --> Helper loaded: form_helper
DEBUG - 2020-02-29 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:01 --> Form Validation Class Initialized
INFO - 2020-02-29 16:35:01 --> Input Class Initialized
INFO - 2020-02-29 16:35:01 --> Input Class Initialized
DEBUG - 2020-02-29 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:01 --> Output Class Initialized
INFO - 2020-02-29 16:35:01 --> Input Class Initialized
INFO - 2020-02-29 16:35:01 --> Language Class Initialized
INFO - 2020-02-29 16:35:01 --> Language Class Initialized
INFO - 2020-02-29 16:35:01 --> Security Class Initialized
ERROR - 2020-02-29 16:35:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-29 16:35:01 --> Language Class Initialized
ERROR - 2020-02-29 16:35:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-29 16:35:01 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-29 16:35:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-29 16:35:01 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 16:35:01 --> Input Class Initialized
ERROR - 2020-02-29 16:35:01 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-29 16:35:01 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:35:01 --> Final output sent to browser
INFO - 2020-02-29 16:35:01 --> Language Class Initialized
DEBUG - 2020-02-29 16:35:01 --> Total execution time: 1.2687
ERROR - 2020-02-29 16:35:01 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-29 16:35:01 --> Config Class Initialized
INFO - 2020-02-29 16:35:01 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:01 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:01 --> URI Class Initialized
INFO - 2020-02-29 16:35:01 --> Router Class Initialized
INFO - 2020-02-29 16:35:01 --> Output Class Initialized
INFO - 2020-02-29 16:35:01 --> Security Class Initialized
DEBUG - 2020-02-29 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:02 --> Input Class Initialized
INFO - 2020-02-29 16:35:02 --> Language Class Initialized
ERROR - 2020-02-29 16:35:02 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 16:35:02 --> Config Class Initialized
INFO - 2020-02-29 16:35:02 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:35:02 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:02 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:02 --> URI Class Initialized
INFO - 2020-02-29 16:35:02 --> Router Class Initialized
INFO - 2020-02-29 16:35:02 --> Output Class Initialized
INFO - 2020-02-29 16:35:02 --> Security Class Initialized
DEBUG - 2020-02-29 16:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:02 --> Input Class Initialized
INFO - 2020-02-29 16:35:02 --> Language Class Initialized
ERROR - 2020-02-29 16:35:02 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-29 16:35:02 --> Config Class Initialized
INFO - 2020-02-29 16:35:02 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:35:02 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:02 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:02 --> URI Class Initialized
INFO - 2020-02-29 16:35:02 --> Router Class Initialized
INFO - 2020-02-29 16:35:02 --> Output Class Initialized
INFO - 2020-02-29 16:35:02 --> Security Class Initialized
DEBUG - 2020-02-29 16:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:02 --> Input Class Initialized
INFO - 2020-02-29 16:35:02 --> Language Class Initialized
ERROR - 2020-02-29 16:35:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-29 16:35:02 --> Config Class Initialized
INFO - 2020-02-29 16:35:02 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:35:02 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:02 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:02 --> URI Class Initialized
INFO - 2020-02-29 16:35:03 --> Router Class Initialized
INFO - 2020-02-29 16:35:03 --> Output Class Initialized
INFO - 2020-02-29 16:35:03 --> Security Class Initialized
DEBUG - 2020-02-29 16:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:03 --> Input Class Initialized
INFO - 2020-02-29 16:35:03 --> Language Class Initialized
ERROR - 2020-02-29 16:35:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:35:03 --> Config Class Initialized
INFO - 2020-02-29 16:35:03 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:03 --> Config Class Initialized
DEBUG - 2020-02-29 16:35:03 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:03 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:03 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:03 --> URI Class Initialized
DEBUG - 2020-02-29 16:35:03 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:03 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:03 --> Router Class Initialized
INFO - 2020-02-29 16:35:03 --> URI Class Initialized
INFO - 2020-02-29 16:35:03 --> Output Class Initialized
INFO - 2020-02-29 16:35:03 --> Security Class Initialized
INFO - 2020-02-29 16:35:03 --> Router Class Initialized
DEBUG - 2020-02-29 16:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:03 --> Output Class Initialized
INFO - 2020-02-29 16:35:03 --> Input Class Initialized
INFO - 2020-02-29 16:35:03 --> Security Class Initialized
INFO - 2020-02-29 16:35:03 --> Language Class Initialized
DEBUG - 2020-02-29 16:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:03 --> Input Class Initialized
ERROR - 2020-02-29 16:35:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:35:03 --> Language Class Initialized
INFO - 2020-02-29 16:35:03 --> Config Class Initialized
INFO - 2020-02-29 16:35:03 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:03 --> Loader Class Initialized
INFO - 2020-02-29 16:35:03 --> Helper loaded: url_helper
DEBUG - 2020-02-29 16:35:03 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:03 --> Utf8 Class Initialized
INFO - 2020-02-29 16:35:03 --> Helper loaded: string_helper
INFO - 2020-02-29 16:35:03 --> URI Class Initialized
INFO - 2020-02-29 16:35:03 --> Database Driver Class Initialized
INFO - 2020-02-29 16:35:03 --> Router Class Initialized
DEBUG - 2020-02-29 16:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:35:03 --> Output Class Initialized
INFO - 2020-02-29 16:35:03 --> Controller Class Initialized
INFO - 2020-02-29 16:35:03 --> Security Class Initialized
DEBUG - 2020-02-29 16:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-29 16:35:03 --> Input Class Initialized
INFO - 2020-02-29 16:35:03 --> Pagination Class Initialized
INFO - 2020-02-29 16:35:03 --> Language Class Initialized
INFO - 2020-02-29 16:35:03 --> Model "M_show" initialized
ERROR - 2020-02-29 16:35:03 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-29 16:35:03 --> Helper loaded: form_helper
INFO - 2020-02-29 16:35:03 --> Form Validation Class Initialized
INFO - 2020-02-29 16:35:03 --> Config Class Initialized
INFO - 2020-02-29 16:35:03 --> Hooks Class Initialized
INFO - 2020-02-29 16:35:03 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\header/header.php
INFO - 2020-02-29 16:35:04 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\beli.php
DEBUG - 2020-02-29 16:35:04 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:35:04 --> Final output sent to browser
INFO - 2020-02-29 16:35:04 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:35:04 --> Total execution time: 0.7410
INFO - 2020-02-29 16:35:04 --> URI Class Initialized
INFO - 2020-02-29 16:35:04 --> Router Class Initialized
INFO - 2020-02-29 16:35:04 --> Output Class Initialized
INFO - 2020-02-29 16:35:04 --> Security Class Initialized
DEBUG - 2020-02-29 16:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:35:04 --> Input Class Initialized
INFO - 2020-02-29 16:35:04 --> Language Class Initialized
ERROR - 2020-02-29 16:35:04 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 16:38:51 --> Config Class Initialized
INFO - 2020-02-29 16:38:51 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:38:51 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:38:51 --> Utf8 Class Initialized
INFO - 2020-02-29 16:38:51 --> URI Class Initialized
INFO - 2020-02-29 16:38:51 --> Router Class Initialized
INFO - 2020-02-29 16:38:51 --> Output Class Initialized
INFO - 2020-02-29 16:38:51 --> Security Class Initialized
DEBUG - 2020-02-29 16:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:38:51 --> Input Class Initialized
INFO - 2020-02-29 16:38:51 --> Language Class Initialized
INFO - 2020-02-29 16:38:51 --> Loader Class Initialized
INFO - 2020-02-29 16:38:51 --> Helper loaded: url_helper
INFO - 2020-02-29 16:38:51 --> Helper loaded: string_helper
INFO - 2020-02-29 16:38:51 --> Database Driver Class Initialized
DEBUG - 2020-02-29 16:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:38:51 --> Controller Class Initialized
INFO - 2020-02-29 16:38:51 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:38:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:38:52 --> Model "M_pesan" initialized
INFO - 2020-02-29 16:38:52 --> Helper loaded: form_helper
INFO - 2020-02-29 16:38:52 --> Form Validation Class Initialized
INFO - 2020-02-29 16:38:52 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:38:52 --> Final output sent to browser
DEBUG - 2020-02-29 16:38:52 --> Total execution time: 0.7105
INFO - 2020-02-29 16:38:52 --> Config Class Initialized
INFO - 2020-02-29 16:38:52 --> Config Class Initialized
INFO - 2020-02-29 16:38:52 --> Config Class Initialized
INFO - 2020-02-29 16:38:52 --> Config Class Initialized
INFO - 2020-02-29 16:38:52 --> Config Class Initialized
INFO - 2020-02-29 16:38:52 --> Hooks Class Initialized
INFO - 2020-02-29 16:38:52 --> Hooks Class Initialized
INFO - 2020-02-29 16:38:52 --> Hooks Class Initialized
INFO - 2020-02-29 16:38:52 --> Hooks Class Initialized
INFO - 2020-02-29 16:38:52 --> Hooks Class Initialized
INFO - 2020-02-29 16:38:52 --> Config Class Initialized
INFO - 2020-02-29 16:38:52 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:38:52 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:38:52 --> Utf8 Class Initialized
INFO - 2020-02-29 16:38:52 --> Utf8 Class Initialized
INFO - 2020-02-29 16:38:52 --> Utf8 Class Initialized
INFO - 2020-02-29 16:38:52 --> Utf8 Class Initialized
INFO - 2020-02-29 16:38:52 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:38:52 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:38:52 --> Utf8 Class Initialized
INFO - 2020-02-29 16:38:52 --> URI Class Initialized
INFO - 2020-02-29 16:38:52 --> URI Class Initialized
INFO - 2020-02-29 16:38:52 --> URI Class Initialized
INFO - 2020-02-29 16:38:52 --> URI Class Initialized
INFO - 2020-02-29 16:38:52 --> URI Class Initialized
INFO - 2020-02-29 16:38:52 --> URI Class Initialized
INFO - 2020-02-29 16:38:52 --> Router Class Initialized
INFO - 2020-02-29 16:38:52 --> Router Class Initialized
INFO - 2020-02-29 16:38:52 --> Router Class Initialized
INFO - 2020-02-29 16:38:52 --> Router Class Initialized
INFO - 2020-02-29 16:38:52 --> Router Class Initialized
INFO - 2020-02-29 16:38:52 --> Output Class Initialized
INFO - 2020-02-29 16:38:52 --> Output Class Initialized
INFO - 2020-02-29 16:38:52 --> Output Class Initialized
INFO - 2020-02-29 16:38:52 --> Output Class Initialized
INFO - 2020-02-29 16:38:52 --> Output Class Initialized
INFO - 2020-02-29 16:38:52 --> Router Class Initialized
INFO - 2020-02-29 16:38:52 --> Output Class Initialized
INFO - 2020-02-29 16:38:52 --> Security Class Initialized
INFO - 2020-02-29 16:38:52 --> Security Class Initialized
INFO - 2020-02-29 16:38:52 --> Security Class Initialized
INFO - 2020-02-29 16:38:52 --> Security Class Initialized
INFO - 2020-02-29 16:38:52 --> Security Class Initialized
DEBUG - 2020-02-29 16:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:38:52 --> Security Class Initialized
DEBUG - 2020-02-29 16:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:38:52 --> Input Class Initialized
INFO - 2020-02-29 16:38:52 --> Input Class Initialized
INFO - 2020-02-29 16:38:52 --> Input Class Initialized
INFO - 2020-02-29 16:38:52 --> Input Class Initialized
INFO - 2020-02-29 16:38:52 --> Input Class Initialized
DEBUG - 2020-02-29 16:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:38:52 --> Input Class Initialized
INFO - 2020-02-29 16:38:52 --> Language Class Initialized
INFO - 2020-02-29 16:38:52 --> Language Class Initialized
INFO - 2020-02-29 16:38:52 --> Language Class Initialized
INFO - 2020-02-29 16:38:52 --> Language Class Initialized
INFO - 2020-02-29 16:38:52 --> Language Class Initialized
INFO - 2020-02-29 16:38:52 --> Language Class Initialized
ERROR - 2020-02-29 16:38:52 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-29 16:38:52 --> Loader Class Initialized
INFO - 2020-02-29 16:38:52 --> Loader Class Initialized
ERROR - 2020-02-29 16:38:52 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-29 16:38:52 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-29 16:38:52 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-29 16:38:52 --> Helper loaded: url_helper
INFO - 2020-02-29 16:38:52 --> Helper loaded: url_helper
INFO - 2020-02-29 16:38:52 --> Config Class Initialized
INFO - 2020-02-29 16:38:52 --> Config Class Initialized
INFO - 2020-02-29 16:38:52 --> Config Class Initialized
INFO - 2020-02-29 16:38:52 --> Hooks Class Initialized
INFO - 2020-02-29 16:38:52 --> Hooks Class Initialized
INFO - 2020-02-29 16:38:52 --> Hooks Class Initialized
INFO - 2020-02-29 16:38:52 --> Helper loaded: string_helper
INFO - 2020-02-29 16:38:52 --> Helper loaded: string_helper
INFO - 2020-02-29 16:38:52 --> Config Class Initialized
INFO - 2020-02-29 16:38:52 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:38:52 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:38:52 --> Database Driver Class Initialized
INFO - 2020-02-29 16:38:52 --> Database Driver Class Initialized
INFO - 2020-02-29 16:38:52 --> Utf8 Class Initialized
INFO - 2020-02-29 16:38:52 --> Utf8 Class Initialized
INFO - 2020-02-29 16:38:52 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-29 16:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-29 16:38:52 --> Utf8 Class Initialized
INFO - 2020-02-29 16:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:38:52 --> URI Class Initialized
INFO - 2020-02-29 16:38:52 --> URI Class Initialized
INFO - 2020-02-29 16:38:52 --> URI Class Initialized
INFO - 2020-02-29 16:38:53 --> Controller Class Initialized
INFO - 2020-02-29 16:38:53 --> URI Class Initialized
INFO - 2020-02-29 16:38:53 --> Router Class Initialized
INFO - 2020-02-29 16:38:53 --> Router Class Initialized
INFO - 2020-02-29 16:38:53 --> Router Class Initialized
INFO - 2020-02-29 16:38:53 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:38:53 --> Output Class Initialized
INFO - 2020-02-29 16:38:53 --> Output Class Initialized
INFO - 2020-02-29 16:38:53 --> Router Class Initialized
INFO - 2020-02-29 16:38:53 --> Output Class Initialized
INFO - 2020-02-29 16:38:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:38:53 --> Security Class Initialized
INFO - 2020-02-29 16:38:53 --> Output Class Initialized
INFO - 2020-02-29 16:38:53 --> Security Class Initialized
INFO - 2020-02-29 16:38:53 --> Security Class Initialized
INFO - 2020-02-29 16:38:53 --> Model "M_pesan" initialized
DEBUG - 2020-02-29 16:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:38:53 --> Security Class Initialized
DEBUG - 2020-02-29 16:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:38:53 --> Input Class Initialized
INFO - 2020-02-29 16:38:53 --> Input Class Initialized
INFO - 2020-02-29 16:38:53 --> Input Class Initialized
DEBUG - 2020-02-29 16:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:38:53 --> Helper loaded: form_helper
INFO - 2020-02-29 16:38:53 --> Form Validation Class Initialized
INFO - 2020-02-29 16:38:53 --> Input Class Initialized
INFO - 2020-02-29 16:38:53 --> Language Class Initialized
INFO - 2020-02-29 16:38:53 --> Language Class Initialized
INFO - 2020-02-29 16:38:53 --> Language Class Initialized
ERROR - 2020-02-29 16:38:53 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-29 16:38:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:38:53 --> Language Class Initialized
ERROR - 2020-02-29 16:38:53 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-29 16:38:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 16:38:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-29 16:38:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-29 16:38:53 --> Config Class Initialized
INFO - 2020-02-29 16:38:53 --> Config Class Initialized
INFO - 2020-02-29 16:38:53 --> Config Class Initialized
INFO - 2020-02-29 16:38:53 --> Hooks Class Initialized
INFO - 2020-02-29 16:38:53 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:38:53 --> Hooks Class Initialized
INFO - 2020-02-29 16:38:53 --> Hooks Class Initialized
INFO - 2020-02-29 16:38:53 --> Final output sent to browser
DEBUG - 2020-02-29 16:38:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:38:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:38:53 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:38:53 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:38:53 --> Total execution time: 1.0542
INFO - 2020-02-29 16:38:53 --> Utf8 Class Initialized
INFO - 2020-02-29 16:38:53 --> Utf8 Class Initialized
INFO - 2020-02-29 16:38:53 --> URI Class Initialized
INFO - 2020-02-29 16:38:53 --> URI Class Initialized
INFO - 2020-02-29 16:38:53 --> URI Class Initialized
INFO - 2020-02-29 16:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-29 16:38:53 --> Controller Class Initialized
INFO - 2020-02-29 16:38:53 --> Router Class Initialized
INFO - 2020-02-29 16:38:53 --> Router Class Initialized
INFO - 2020-02-29 16:38:53 --> Router Class Initialized
INFO - 2020-02-29 16:38:53 --> Output Class Initialized
INFO - 2020-02-29 16:38:53 --> Output Class Initialized
INFO - 2020-02-29 16:38:53 --> Output Class Initialized
INFO - 2020-02-29 16:38:53 --> Model "M_tiket" initialized
INFO - 2020-02-29 16:38:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-29 16:38:53 --> Security Class Initialized
INFO - 2020-02-29 16:38:53 --> Security Class Initialized
INFO - 2020-02-29 16:38:53 --> Security Class Initialized
INFO - 2020-02-29 16:38:53 --> Model "M_pesan" initialized
DEBUG - 2020-02-29 16:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-29 16:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:38:53 --> Input Class Initialized
INFO - 2020-02-29 16:38:53 --> Input Class Initialized
INFO - 2020-02-29 16:38:53 --> Input Class Initialized
INFO - 2020-02-29 16:38:53 --> Helper loaded: form_helper
INFO - 2020-02-29 16:38:53 --> Language Class Initialized
INFO - 2020-02-29 16:38:53 --> Form Validation Class Initialized
INFO - 2020-02-29 16:38:53 --> Language Class Initialized
INFO - 2020-02-29 16:38:53 --> Language Class Initialized
ERROR - 2020-02-29 16:38:53 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-29 16:38:53 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-29 16:38:53 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-29 16:38:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-29 16:38:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2.1\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-29 16:38:53 --> Config Class Initialized
INFO - 2020-02-29 16:38:53 --> Hooks Class Initialized
INFO - 2020-02-29 16:38:53 --> File loaded: C:\xampp\htdocs\roadshow-2.1\application\views\tiket/lihat_jenis.php
INFO - 2020-02-29 16:38:53 --> Final output sent to browser
DEBUG - 2020-02-29 16:38:53 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:38:53 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:38:53 --> Total execution time: 1.4333
INFO - 2020-02-29 16:38:53 --> URI Class Initialized
INFO - 2020-02-29 16:38:53 --> Router Class Initialized
INFO - 2020-02-29 16:38:53 --> Output Class Initialized
INFO - 2020-02-29 16:38:53 --> Security Class Initialized
DEBUG - 2020-02-29 16:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:38:53 --> Input Class Initialized
INFO - 2020-02-29 16:38:53 --> Language Class Initialized
ERROR - 2020-02-29 16:38:53 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-29 16:38:54 --> Config Class Initialized
INFO - 2020-02-29 16:38:54 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:38:54 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:38:54 --> Utf8 Class Initialized
INFO - 2020-02-29 16:38:54 --> URI Class Initialized
INFO - 2020-02-29 16:38:54 --> Router Class Initialized
INFO - 2020-02-29 16:38:54 --> Output Class Initialized
INFO - 2020-02-29 16:38:54 --> Security Class Initialized
DEBUG - 2020-02-29 16:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:38:54 --> Input Class Initialized
INFO - 2020-02-29 16:38:54 --> Language Class Initialized
ERROR - 2020-02-29 16:38:54 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-29 16:38:54 --> Config Class Initialized
INFO - 2020-02-29 16:38:54 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:38:54 --> UTF-8 Support Enabled
INFO - 2020-02-29 16:38:54 --> Utf8 Class Initialized
INFO - 2020-02-29 16:38:54 --> URI Class Initialized
INFO - 2020-02-29 16:38:54 --> Router Class Initialized
INFO - 2020-02-29 16:38:54 --> Output Class Initialized
INFO - 2020-02-29 16:38:54 --> Security Class Initialized
DEBUG - 2020-02-29 16:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-29 16:38:54 --> Input Class Initialized
INFO - 2020-02-29 16:38:54 --> Language Class Initialized
ERROR - 2020-02-29 16:38:54 --> 404 Page Not Found: Bower_components/jquery-i18next
