<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-10 05:10:54 --> Config Class Initialized
INFO - 2020-02-10 05:10:54 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:10:55 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:10:55 --> Utf8 Class Initialized
INFO - 2020-02-10 05:10:55 --> URI Class Initialized
DEBUG - 2020-02-10 05:10:55 --> No URI present. Default controller set.
INFO - 2020-02-10 05:10:55 --> Router Class Initialized
INFO - 2020-02-10 05:10:55 --> Output Class Initialized
INFO - 2020-02-10 05:10:55 --> Security Class Initialized
DEBUG - 2020-02-10 05:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:10:55 --> Input Class Initialized
INFO - 2020-02-10 05:10:55 --> Language Class Initialized
INFO - 2020-02-10 05:10:55 --> Loader Class Initialized
INFO - 2020-02-10 05:10:56 --> Helper loaded: url_helper
INFO - 2020-02-10 05:10:56 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:10:57 --> Controller Class Initialized
INFO - 2020-02-10 05:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-10 05:10:57 --> Pagination Class Initialized
INFO - 2020-02-10 05:10:57 --> Model "M_show" initialized
INFO - 2020-02-10 05:10:57 --> Helper loaded: form_helper
INFO - 2020-02-10 05:10:57 --> Form Validation Class Initialized
INFO - 2020-02-10 05:10:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-10 05:10:58 --> Final output sent to browser
DEBUG - 2020-02-10 05:10:58 --> Total execution time: 4.0808
INFO - 2020-02-10 05:10:58 --> Config Class Initialized
INFO - 2020-02-10 05:10:58 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:10:58 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:10:58 --> Utf8 Class Initialized
INFO - 2020-02-10 05:10:58 --> URI Class Initialized
DEBUG - 2020-02-10 05:10:58 --> No URI present. Default controller set.
INFO - 2020-02-10 05:10:58 --> Router Class Initialized
INFO - 2020-02-10 05:10:58 --> Output Class Initialized
INFO - 2020-02-10 05:10:58 --> Security Class Initialized
DEBUG - 2020-02-10 05:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:10:58 --> Input Class Initialized
INFO - 2020-02-10 05:10:58 --> Language Class Initialized
INFO - 2020-02-10 05:10:58 --> Loader Class Initialized
INFO - 2020-02-10 05:10:58 --> Helper loaded: url_helper
INFO - 2020-02-10 05:10:58 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:10:59 --> Controller Class Initialized
INFO - 2020-02-10 05:10:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-10 05:10:59 --> Pagination Class Initialized
INFO - 2020-02-10 05:10:59 --> Model "M_show" initialized
INFO - 2020-02-10 05:10:59 --> Helper loaded: form_helper
INFO - 2020-02-10 05:10:59 --> Form Validation Class Initialized
INFO - 2020-02-10 05:10:59 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-10 05:10:59 --> Final output sent to browser
DEBUG - 2020-02-10 05:10:59 --> Total execution time: 0.5793
INFO - 2020-02-10 05:11:04 --> Config Class Initialized
INFO - 2020-02-10 05:11:04 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:11:04 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:04 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:04 --> URI Class Initialized
INFO - 2020-02-10 05:11:04 --> Router Class Initialized
INFO - 2020-02-10 05:11:04 --> Output Class Initialized
INFO - 2020-02-10 05:11:04 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:04 --> Input Class Initialized
INFO - 2020-02-10 05:11:04 --> Language Class Initialized
INFO - 2020-02-10 05:11:04 --> Loader Class Initialized
INFO - 2020-02-10 05:11:04 --> Helper loaded: url_helper
INFO - 2020-02-10 05:11:05 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:11:05 --> Controller Class Initialized
INFO - 2020-02-10 05:11:05 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:11:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:11:05 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:11:05 --> Helper loaded: form_helper
INFO - 2020-02-10 05:11:05 --> Form Validation Class Initialized
INFO - 2020-02-10 05:11:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:11:06 --> Final output sent to browser
DEBUG - 2020-02-10 05:11:06 --> Total execution time: 2.3298
INFO - 2020-02-10 05:11:06 --> Config Class Initialized
INFO - 2020-02-10 05:11:06 --> Config Class Initialized
INFO - 2020-02-10 05:11:06 --> Config Class Initialized
INFO - 2020-02-10 05:11:06 --> Config Class Initialized
INFO - 2020-02-10 05:11:06 --> Config Class Initialized
INFO - 2020-02-10 05:11:06 --> Config Class Initialized
INFO - 2020-02-10 05:11:06 --> Hooks Class Initialized
INFO - 2020-02-10 05:11:06 --> Hooks Class Initialized
INFO - 2020-02-10 05:11:06 --> Hooks Class Initialized
INFO - 2020-02-10 05:11:06 --> Hooks Class Initialized
INFO - 2020-02-10 05:11:06 --> Hooks Class Initialized
INFO - 2020-02-10 05:11:06 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:11:06 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:06 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:06 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:06 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:06 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:06 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:06 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:06 --> URI Class Initialized
INFO - 2020-02-10 05:11:06 --> URI Class Initialized
INFO - 2020-02-10 05:11:06 --> URI Class Initialized
INFO - 2020-02-10 05:11:06 --> URI Class Initialized
INFO - 2020-02-10 05:11:06 --> URI Class Initialized
INFO - 2020-02-10 05:11:06 --> URI Class Initialized
INFO - 2020-02-10 05:11:06 --> Router Class Initialized
INFO - 2020-02-10 05:11:06 --> Router Class Initialized
INFO - 2020-02-10 05:11:06 --> Router Class Initialized
INFO - 2020-02-10 05:11:06 --> Router Class Initialized
INFO - 2020-02-10 05:11:06 --> Router Class Initialized
INFO - 2020-02-10 05:11:06 --> Router Class Initialized
INFO - 2020-02-10 05:11:06 --> Output Class Initialized
INFO - 2020-02-10 05:11:06 --> Output Class Initialized
INFO - 2020-02-10 05:11:06 --> Output Class Initialized
INFO - 2020-02-10 05:11:06 --> Output Class Initialized
INFO - 2020-02-10 05:11:06 --> Output Class Initialized
INFO - 2020-02-10 05:11:06 --> Output Class Initialized
INFO - 2020-02-10 05:11:06 --> Security Class Initialized
INFO - 2020-02-10 05:11:06 --> Security Class Initialized
INFO - 2020-02-10 05:11:06 --> Security Class Initialized
INFO - 2020-02-10 05:11:06 --> Security Class Initialized
INFO - 2020-02-10 05:11:06 --> Security Class Initialized
INFO - 2020-02-10 05:11:06 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
INFO - 2020-02-10 05:11:07 --> Loader Class Initialized
INFO - 2020-02-10 05:11:07 --> Loader Class Initialized
INFO - 2020-02-10 05:11:07 --> Helper loaded: url_helper
INFO - 2020-02-10 05:11:07 --> Helper loaded: url_helper
INFO - 2020-02-10 05:11:07 --> Database Driver Class Initialized
INFO - 2020-02-10 05:11:07 --> Database Driver Class Initialized
ERROR - 2020-02-10 05:11:07 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 05:11:07 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-10 05:11:07 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-10 05:11:07 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-10 05:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-10 05:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:11:07 --> Controller Class Initialized
INFO - 2020-02-10 05:11:07 --> Config Class Initialized
INFO - 2020-02-10 05:11:07 --> Config Class Initialized
INFO - 2020-02-10 05:11:07 --> Hooks Class Initialized
INFO - 2020-02-10 05:11:07 --> Hooks Class Initialized
INFO - 2020-02-10 05:11:07 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:11:07 --> Config Class Initialized
INFO - 2020-02-10 05:11:07 --> Config Class Initialized
INFO - 2020-02-10 05:11:07 --> Hooks Class Initialized
INFO - 2020-02-10 05:11:07 --> Hooks Class Initialized
INFO - 2020-02-10 05:11:07 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-10 05:11:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:11:07 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:07 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:07 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:07 --> Model "M_pesan" initialized
DEBUG - 2020-02-10 05:11:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:11:07 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:07 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:07 --> URI Class Initialized
INFO - 2020-02-10 05:11:07 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:07 --> URI Class Initialized
INFO - 2020-02-10 05:11:07 --> Helper loaded: form_helper
INFO - 2020-02-10 05:11:07 --> Form Validation Class Initialized
INFO - 2020-02-10 05:11:07 --> URI Class Initialized
INFO - 2020-02-10 05:11:07 --> Router Class Initialized
INFO - 2020-02-10 05:11:07 --> Router Class Initialized
INFO - 2020-02-10 05:11:07 --> URI Class Initialized
INFO - 2020-02-10 05:11:07 --> Router Class Initialized
INFO - 2020-02-10 05:11:07 --> Output Class Initialized
INFO - 2020-02-10 05:11:07 --> Output Class Initialized
ERROR - 2020-02-10 05:11:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 05:11:07 --> Router Class Initialized
INFO - 2020-02-10 05:11:07 --> Security Class Initialized
INFO - 2020-02-10 05:11:07 --> Security Class Initialized
INFO - 2020-02-10 05:11:07 --> Output Class Initialized
INFO - 2020-02-10 05:11:07 --> Output Class Initialized
INFO - 2020-02-10 05:11:07 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:07 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
DEBUG - 2020-02-10 05:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:11:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-10 05:11:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
INFO - 2020-02-10 05:11:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
INFO - 2020-02-10 05:11:07 --> Final output sent to browser
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
ERROR - 2020-02-10 05:11:07 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 05:11:07 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-10 05:11:07 --> Total execution time: 0.6446
ERROR - 2020-02-10 05:11:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-10 05:11:07 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 05:11:07 --> Config Class Initialized
INFO - 2020-02-10 05:11:07 --> Config Class Initialized
INFO - 2020-02-10 05:11:07 --> Hooks Class Initialized
INFO - 2020-02-10 05:11:07 --> Hooks Class Initialized
INFO - 2020-02-10 05:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:11:07 --> Config Class Initialized
INFO - 2020-02-10 05:11:07 --> Controller Class Initialized
DEBUG - 2020-02-10 05:11:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:11:07 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:07 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:07 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:07 --> Hooks Class Initialized
INFO - 2020-02-10 05:11:07 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:11:07 --> URI Class Initialized
INFO - 2020-02-10 05:11:07 --> URI Class Initialized
INFO - 2020-02-10 05:11:07 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-10 05:11:07 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:07 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:07 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:11:07 --> Router Class Initialized
INFO - 2020-02-10 05:11:07 --> Router Class Initialized
INFO - 2020-02-10 05:11:07 --> URI Class Initialized
INFO - 2020-02-10 05:11:07 --> Output Class Initialized
INFO - 2020-02-10 05:11:07 --> Output Class Initialized
INFO - 2020-02-10 05:11:07 --> Helper loaded: form_helper
INFO - 2020-02-10 05:11:07 --> Form Validation Class Initialized
INFO - 2020-02-10 05:11:07 --> Security Class Initialized
INFO - 2020-02-10 05:11:07 --> Router Class Initialized
INFO - 2020-02-10 05:11:07 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:07 --> Output Class Initialized
ERROR - 2020-02-10 05:11:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
ERROR - 2020-02-10 05:11:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:11:07 --> Security Class Initialized
INFO - 2020-02-10 05:11:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
DEBUG - 2020-02-10 05:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:07 --> Final output sent to browser
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
ERROR - 2020-02-10 05:11:07 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-10 05:11:07 --> 404 Page Not Found: Bower_components/jquery-i18next
DEBUG - 2020-02-10 05:11:07 --> Total execution time: 0.9373
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
ERROR - 2020-02-10 05:11:07 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-10 05:11:07 --> Config Class Initialized
INFO - 2020-02-10 05:11:07 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:11:07 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:07 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:07 --> URI Class Initialized
INFO - 2020-02-10 05:11:07 --> Router Class Initialized
INFO - 2020-02-10 05:11:07 --> Output Class Initialized
INFO - 2020-02-10 05:11:07 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:07 --> Input Class Initialized
INFO - 2020-02-10 05:11:07 --> Language Class Initialized
ERROR - 2020-02-10 05:11:07 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-10 05:11:07 --> Config Class Initialized
INFO - 2020-02-10 05:11:07 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:11:08 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:08 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:08 --> URI Class Initialized
INFO - 2020-02-10 05:11:08 --> Router Class Initialized
INFO - 2020-02-10 05:11:08 --> Output Class Initialized
INFO - 2020-02-10 05:11:08 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:08 --> Input Class Initialized
INFO - 2020-02-10 05:11:08 --> Language Class Initialized
ERROR - 2020-02-10 05:11:08 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 05:11:08 --> Config Class Initialized
INFO - 2020-02-10 05:11:08 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:11:08 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:08 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:08 --> URI Class Initialized
INFO - 2020-02-10 05:11:08 --> Router Class Initialized
INFO - 2020-02-10 05:11:08 --> Output Class Initialized
INFO - 2020-02-10 05:11:08 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:08 --> Input Class Initialized
INFO - 2020-02-10 05:11:08 --> Language Class Initialized
ERROR - 2020-02-10 05:11:08 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 05:11:08 --> Config Class Initialized
INFO - 2020-02-10 05:11:08 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:11:08 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:08 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:08 --> URI Class Initialized
INFO - 2020-02-10 05:11:08 --> Router Class Initialized
INFO - 2020-02-10 05:11:08 --> Output Class Initialized
INFO - 2020-02-10 05:11:08 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:08 --> Input Class Initialized
INFO - 2020-02-10 05:11:08 --> Language Class Initialized
ERROR - 2020-02-10 05:11:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 05:11:08 --> Config Class Initialized
INFO - 2020-02-10 05:11:08 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:11:08 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:08 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:08 --> URI Class Initialized
INFO - 2020-02-10 05:11:08 --> Router Class Initialized
INFO - 2020-02-10 05:11:08 --> Output Class Initialized
INFO - 2020-02-10 05:11:08 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:08 --> Input Class Initialized
INFO - 2020-02-10 05:11:08 --> Language Class Initialized
ERROR - 2020-02-10 05:11:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 05:11:09 --> Config Class Initialized
INFO - 2020-02-10 05:11:09 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:11:09 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:09 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:09 --> URI Class Initialized
INFO - 2020-02-10 05:11:09 --> Router Class Initialized
INFO - 2020-02-10 05:11:09 --> Output Class Initialized
INFO - 2020-02-10 05:11:09 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:09 --> Input Class Initialized
INFO - 2020-02-10 05:11:09 --> Language Class Initialized
ERROR - 2020-02-10 05:11:09 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 05:11:09 --> Config Class Initialized
INFO - 2020-02-10 05:11:09 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:11:09 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:09 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:09 --> URI Class Initialized
INFO - 2020-02-10 05:11:09 --> Router Class Initialized
INFO - 2020-02-10 05:11:09 --> Output Class Initialized
INFO - 2020-02-10 05:11:09 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:09 --> Input Class Initialized
INFO - 2020-02-10 05:11:09 --> Language Class Initialized
ERROR - 2020-02-10 05:11:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 05:11:09 --> Config Class Initialized
INFO - 2020-02-10 05:11:09 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:11:09 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:09 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:09 --> URI Class Initialized
INFO - 2020-02-10 05:11:09 --> Router Class Initialized
INFO - 2020-02-10 05:11:09 --> Output Class Initialized
INFO - 2020-02-10 05:11:09 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:09 --> Input Class Initialized
INFO - 2020-02-10 05:11:09 --> Language Class Initialized
ERROR - 2020-02-10 05:11:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 05:11:09 --> Config Class Initialized
INFO - 2020-02-10 05:11:09 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:11:09 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:11:09 --> Utf8 Class Initialized
INFO - 2020-02-10 05:11:09 --> URI Class Initialized
INFO - 2020-02-10 05:11:10 --> Router Class Initialized
INFO - 2020-02-10 05:11:10 --> Output Class Initialized
INFO - 2020-02-10 05:11:10 --> Security Class Initialized
DEBUG - 2020-02-10 05:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:11:10 --> Input Class Initialized
INFO - 2020-02-10 05:11:10 --> Language Class Initialized
ERROR - 2020-02-10 05:11:10 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 05:14:10 --> Config Class Initialized
INFO - 2020-02-10 05:14:10 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:14:11 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:14:11 --> Utf8 Class Initialized
INFO - 2020-02-10 05:14:11 --> URI Class Initialized
INFO - 2020-02-10 05:14:11 --> Router Class Initialized
INFO - 2020-02-10 05:14:11 --> Output Class Initialized
INFO - 2020-02-10 05:14:11 --> Security Class Initialized
DEBUG - 2020-02-10 05:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:14:11 --> Input Class Initialized
INFO - 2020-02-10 05:14:11 --> Language Class Initialized
INFO - 2020-02-10 05:14:11 --> Loader Class Initialized
INFO - 2020-02-10 05:14:11 --> Helper loaded: url_helper
INFO - 2020-02-10 05:14:11 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:14:12 --> Controller Class Initialized
INFO - 2020-02-10 05:14:12 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:14:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:14:12 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:14:12 --> Helper loaded: form_helper
INFO - 2020-02-10 05:14:12 --> Form Validation Class Initialized
INFO - 2020-02-10 05:18:54 --> Config Class Initialized
INFO - 2020-02-10 05:18:54 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:18:54 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:18:54 --> Utf8 Class Initialized
INFO - 2020-02-10 05:18:54 --> URI Class Initialized
INFO - 2020-02-10 05:18:54 --> Router Class Initialized
INFO - 2020-02-10 05:18:54 --> Output Class Initialized
INFO - 2020-02-10 05:18:54 --> Security Class Initialized
DEBUG - 2020-02-10 05:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:18:54 --> Input Class Initialized
INFO - 2020-02-10 05:18:54 --> Language Class Initialized
INFO - 2020-02-10 05:18:54 --> Loader Class Initialized
INFO - 2020-02-10 05:18:54 --> Helper loaded: url_helper
INFO - 2020-02-10 05:18:54 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:18:54 --> Controller Class Initialized
INFO - 2020-02-10 05:18:54 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:18:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:18:54 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:18:54 --> Helper loaded: form_helper
INFO - 2020-02-10 05:18:54 --> Form Validation Class Initialized
INFO - 2020-02-10 05:19:23 --> Config Class Initialized
INFO - 2020-02-10 05:19:23 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:19:23 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:19:23 --> Utf8 Class Initialized
INFO - 2020-02-10 05:19:23 --> URI Class Initialized
INFO - 2020-02-10 05:19:23 --> Router Class Initialized
INFO - 2020-02-10 05:19:23 --> Output Class Initialized
INFO - 2020-02-10 05:19:23 --> Security Class Initialized
DEBUG - 2020-02-10 05:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:19:23 --> Input Class Initialized
INFO - 2020-02-10 05:19:23 --> Language Class Initialized
INFO - 2020-02-10 05:19:23 --> Loader Class Initialized
INFO - 2020-02-10 05:19:23 --> Helper loaded: url_helper
INFO - 2020-02-10 05:19:23 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:19:23 --> Controller Class Initialized
INFO - 2020-02-10 05:19:23 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:19:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:19:23 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:19:23 --> Helper loaded: form_helper
INFO - 2020-02-10 05:19:23 --> Form Validation Class Initialized
INFO - 2020-02-10 05:19:26 --> Config Class Initialized
INFO - 2020-02-10 05:19:26 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:19:26 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:19:26 --> Utf8 Class Initialized
INFO - 2020-02-10 05:19:26 --> URI Class Initialized
INFO - 2020-02-10 05:19:26 --> Router Class Initialized
INFO - 2020-02-10 05:19:26 --> Output Class Initialized
INFO - 2020-02-10 05:19:26 --> Security Class Initialized
DEBUG - 2020-02-10 05:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:19:26 --> Input Class Initialized
INFO - 2020-02-10 05:19:26 --> Language Class Initialized
INFO - 2020-02-10 05:19:26 --> Loader Class Initialized
INFO - 2020-02-10 05:19:26 --> Helper loaded: url_helper
INFO - 2020-02-10 05:19:26 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:19:26 --> Controller Class Initialized
INFO - 2020-02-10 05:19:26 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:19:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:19:26 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:19:26 --> Helper loaded: form_helper
INFO - 2020-02-10 05:19:26 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:19:27 --> Severity: Notice --> Undefined variable: show C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:19:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:19:27 --> Severity: Notice --> Undefined variable: show C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-10 05:19:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-10 05:19:27 --> Severity: Notice --> Undefined variable: tiket C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 81
ERROR - 2020-02-10 05:19:27 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 81
INFO - 2020-02-10 05:20:24 --> Config Class Initialized
INFO - 2020-02-10 05:20:24 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:24 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:24 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:24 --> URI Class Initialized
INFO - 2020-02-10 05:20:24 --> Router Class Initialized
INFO - 2020-02-10 05:20:24 --> Output Class Initialized
INFO - 2020-02-10 05:20:25 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:25 --> Input Class Initialized
INFO - 2020-02-10 05:20:25 --> Language Class Initialized
INFO - 2020-02-10 05:20:25 --> Loader Class Initialized
INFO - 2020-02-10 05:20:25 --> Helper loaded: url_helper
INFO - 2020-02-10 05:20:25 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:20:25 --> Controller Class Initialized
INFO - 2020-02-10 05:20:25 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:20:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:20:25 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:20:25 --> Helper loaded: form_helper
INFO - 2020-02-10 05:20:25 --> Form Validation Class Initialized
INFO - 2020-02-10 05:20:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:20:25 --> Final output sent to browser
DEBUG - 2020-02-10 05:20:25 --> Total execution time: 0.7483
INFO - 2020-02-10 05:20:25 --> Config Class Initialized
INFO - 2020-02-10 05:20:25 --> Config Class Initialized
INFO - 2020-02-10 05:20:25 --> Config Class Initialized
INFO - 2020-02-10 05:20:25 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:25 --> Config Class Initialized
INFO - 2020-02-10 05:20:25 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:25 --> Config Class Initialized
INFO - 2020-02-10 05:20:25 --> Config Class Initialized
INFO - 2020-02-10 05:20:25 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:25 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:25 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:25 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:25 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:20:25 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:25 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:25 --> Utf8 Class Initialized
DEBUG - 2020-02-10 05:20:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:20:25 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:25 --> Utf8 Class Initialized
DEBUG - 2020-02-10 05:20:25 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:25 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:25 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:25 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:25 --> URI Class Initialized
INFO - 2020-02-10 05:20:25 --> URI Class Initialized
INFO - 2020-02-10 05:20:25 --> URI Class Initialized
INFO - 2020-02-10 05:20:25 --> URI Class Initialized
INFO - 2020-02-10 05:20:25 --> URI Class Initialized
INFO - 2020-02-10 05:20:25 --> Router Class Initialized
INFO - 2020-02-10 05:20:25 --> Router Class Initialized
INFO - 2020-02-10 05:20:25 --> URI Class Initialized
INFO - 2020-02-10 05:20:25 --> Router Class Initialized
INFO - 2020-02-10 05:20:25 --> Router Class Initialized
INFO - 2020-02-10 05:20:25 --> Router Class Initialized
INFO - 2020-02-10 05:20:25 --> Router Class Initialized
INFO - 2020-02-10 05:20:25 --> Output Class Initialized
INFO - 2020-02-10 05:20:25 --> Output Class Initialized
INFO - 2020-02-10 05:20:25 --> Output Class Initialized
INFO - 2020-02-10 05:20:25 --> Output Class Initialized
INFO - 2020-02-10 05:20:25 --> Output Class Initialized
INFO - 2020-02-10 05:20:25 --> Output Class Initialized
INFO - 2020-02-10 05:20:25 --> Security Class Initialized
INFO - 2020-02-10 05:20:25 --> Security Class Initialized
INFO - 2020-02-10 05:20:25 --> Security Class Initialized
INFO - 2020-02-10 05:20:25 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:25 --> Security Class Initialized
INFO - 2020-02-10 05:20:25 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:25 --> Input Class Initialized
INFO - 2020-02-10 05:20:25 --> Input Class Initialized
INFO - 2020-02-10 05:20:25 --> Input Class Initialized
DEBUG - 2020-02-10 05:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:25 --> Input Class Initialized
INFO - 2020-02-10 05:20:25 --> Input Class Initialized
INFO - 2020-02-10 05:20:25 --> Input Class Initialized
INFO - 2020-02-10 05:20:25 --> Language Class Initialized
INFO - 2020-02-10 05:20:25 --> Language Class Initialized
INFO - 2020-02-10 05:20:25 --> Language Class Initialized
INFO - 2020-02-10 05:20:25 --> Language Class Initialized
INFO - 2020-02-10 05:20:25 --> Language Class Initialized
INFO - 2020-02-10 05:20:25 --> Language Class Initialized
ERROR - 2020-02-10 05:20:25 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-10 05:20:25 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 05:20:25 --> Loader Class Initialized
ERROR - 2020-02-10 05:20:25 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-10 05:20:25 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-10 05:20:25 --> Helper loaded: url_helper
INFO - 2020-02-10 05:20:25 --> Loader Class Initialized
INFO - 2020-02-10 05:20:25 --> Helper loaded: url_helper
INFO - 2020-02-10 05:20:25 --> Config Class Initialized
INFO - 2020-02-10 05:20:25 --> Config Class Initialized
INFO - 2020-02-10 05:20:25 --> Config Class Initialized
INFO - 2020-02-10 05:20:25 --> Database Driver Class Initialized
INFO - 2020-02-10 05:20:25 --> Config Class Initialized
INFO - 2020-02-10 05:20:25 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:25 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:20:25 --> Database Driver Class Initialized
INFO - 2020-02-10 05:20:25 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:25 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:25 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 05:20:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:20:25 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:25 --> Controller Class Initialized
INFO - 2020-02-10 05:20:25 --> Utf8 Class Initialized
DEBUG - 2020-02-10 05:20:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:20:26 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:26 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:26 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:26 --> URI Class Initialized
INFO - 2020-02-10 05:20:26 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:20:26 --> URI Class Initialized
INFO - 2020-02-10 05:20:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:20:26 --> Router Class Initialized
INFO - 2020-02-10 05:20:26 --> URI Class Initialized
INFO - 2020-02-10 05:20:26 --> URI Class Initialized
INFO - 2020-02-10 05:20:26 --> Router Class Initialized
INFO - 2020-02-10 05:20:26 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:20:26 --> Router Class Initialized
INFO - 2020-02-10 05:20:26 --> Router Class Initialized
INFO - 2020-02-10 05:20:26 --> Output Class Initialized
INFO - 2020-02-10 05:20:26 --> Output Class Initialized
INFO - 2020-02-10 05:20:26 --> Security Class Initialized
INFO - 2020-02-10 05:20:26 --> Security Class Initialized
INFO - 2020-02-10 05:20:26 --> Output Class Initialized
INFO - 2020-02-10 05:20:26 --> Output Class Initialized
INFO - 2020-02-10 05:20:26 --> Helper loaded: form_helper
INFO - 2020-02-10 05:20:26 --> Form Validation Class Initialized
DEBUG - 2020-02-10 05:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:26 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:26 --> Security Class Initialized
INFO - 2020-02-10 05:20:26 --> Input Class Initialized
INFO - 2020-02-10 05:20:26 --> Input Class Initialized
DEBUG - 2020-02-10 05:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:20:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-10 05:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 05:20:26 --> Input Class Initialized
INFO - 2020-02-10 05:20:26 --> Input Class Initialized
INFO - 2020-02-10 05:20:26 --> Language Class Initialized
ERROR - 2020-02-10 05:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:20:26 --> Language Class Initialized
INFO - 2020-02-10 05:20:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:20:26 --> Language Class Initialized
INFO - 2020-02-10 05:20:26 --> Language Class Initialized
ERROR - 2020-02-10 05:20:26 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-10 05:20:26 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 05:20:26 --> Final output sent to browser
ERROR - 2020-02-10 05:20:26 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 05:20:26 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 05:20:26 --> Config Class Initialized
INFO - 2020-02-10 05:20:26 --> Config Class Initialized
INFO - 2020-02-10 05:20:26 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:26 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:26 --> Total execution time: 0.6216
INFO - 2020-02-10 05:20:26 --> Config Class Initialized
INFO - 2020-02-10 05:20:26 --> Config Class Initialized
INFO - 2020-02-10 05:20:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 05:20:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:20:26 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:26 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:26 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:26 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:26 --> Controller Class Initialized
INFO - 2020-02-10 05:20:26 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:26 --> URI Class Initialized
INFO - 2020-02-10 05:20:26 --> URI Class Initialized
INFO - 2020-02-10 05:20:26 --> Model "M_tiket" initialized
DEBUG - 2020-02-10 05:20:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:20:26 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:26 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:26 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:20:26 --> Router Class Initialized
INFO - 2020-02-10 05:20:26 --> Router Class Initialized
INFO - 2020-02-10 05:20:26 --> URI Class Initialized
INFO - 2020-02-10 05:20:26 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:20:26 --> Output Class Initialized
INFO - 2020-02-10 05:20:26 --> Output Class Initialized
INFO - 2020-02-10 05:20:26 --> URI Class Initialized
INFO - 2020-02-10 05:20:26 --> Security Class Initialized
INFO - 2020-02-10 05:20:26 --> Router Class Initialized
INFO - 2020-02-10 05:20:26 --> Router Class Initialized
INFO - 2020-02-10 05:20:26 --> Security Class Initialized
INFO - 2020-02-10 05:20:26 --> Helper loaded: form_helper
INFO - 2020-02-10 05:20:26 --> Form Validation Class Initialized
DEBUG - 2020-02-10 05:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:26 --> Output Class Initialized
INFO - 2020-02-10 05:20:26 --> Output Class Initialized
INFO - 2020-02-10 05:20:26 --> Input Class Initialized
INFO - 2020-02-10 05:20:26 --> Input Class Initialized
INFO - 2020-02-10 05:20:26 --> Security Class Initialized
INFO - 2020-02-10 05:20:26 --> Security Class Initialized
ERROR - 2020-02-10 05:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:20:26 --> Language Class Initialized
INFO - 2020-02-10 05:20:26 --> Language Class Initialized
DEBUG - 2020-02-10 05:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:26 --> Input Class Initialized
INFO - 2020-02-10 05:20:26 --> Input Class Initialized
INFO - 2020-02-10 05:20:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-10 05:20:26 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-10 05:20:26 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 05:20:26 --> Final output sent to browser
INFO - 2020-02-10 05:20:26 --> Language Class Initialized
INFO - 2020-02-10 05:20:26 --> Language Class Initialized
DEBUG - 2020-02-10 05:20:26 --> Total execution time: 0.8673
ERROR - 2020-02-10 05:20:26 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-10 05:20:26 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 05:20:26 --> Config Class Initialized
INFO - 2020-02-10 05:20:26 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:26 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:26 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:26 --> URI Class Initialized
INFO - 2020-02-10 05:20:26 --> Router Class Initialized
INFO - 2020-02-10 05:20:26 --> Output Class Initialized
INFO - 2020-02-10 05:20:26 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:26 --> Input Class Initialized
INFO - 2020-02-10 05:20:26 --> Language Class Initialized
ERROR - 2020-02-10 05:20:26 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 05:20:26 --> Config Class Initialized
INFO - 2020-02-10 05:20:26 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:26 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:26 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:26 --> URI Class Initialized
INFO - 2020-02-10 05:20:26 --> Router Class Initialized
INFO - 2020-02-10 05:20:26 --> Output Class Initialized
INFO - 2020-02-10 05:20:26 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:26 --> Input Class Initialized
INFO - 2020-02-10 05:20:26 --> Language Class Initialized
ERROR - 2020-02-10 05:20:26 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 05:20:27 --> Config Class Initialized
INFO - 2020-02-10 05:20:27 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:27 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:27 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:27 --> URI Class Initialized
INFO - 2020-02-10 05:20:27 --> Router Class Initialized
INFO - 2020-02-10 05:20:27 --> Output Class Initialized
INFO - 2020-02-10 05:20:27 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:27 --> Input Class Initialized
INFO - 2020-02-10 05:20:27 --> Language Class Initialized
ERROR - 2020-02-10 05:20:27 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 05:20:27 --> Config Class Initialized
INFO - 2020-02-10 05:20:27 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:27 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:27 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:27 --> URI Class Initialized
INFO - 2020-02-10 05:20:27 --> Router Class Initialized
INFO - 2020-02-10 05:20:27 --> Output Class Initialized
INFO - 2020-02-10 05:20:27 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:27 --> Input Class Initialized
INFO - 2020-02-10 05:20:27 --> Language Class Initialized
ERROR - 2020-02-10 05:20:27 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 05:20:27 --> Config Class Initialized
INFO - 2020-02-10 05:20:27 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:27 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:27 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:27 --> URI Class Initialized
INFO - 2020-02-10 05:20:28 --> Router Class Initialized
INFO - 2020-02-10 05:20:28 --> Output Class Initialized
INFO - 2020-02-10 05:20:28 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:28 --> Input Class Initialized
INFO - 2020-02-10 05:20:28 --> Language Class Initialized
ERROR - 2020-02-10 05:20:28 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 05:20:28 --> Config Class Initialized
INFO - 2020-02-10 05:20:28 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:28 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:28 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:28 --> URI Class Initialized
INFO - 2020-02-10 05:20:28 --> Router Class Initialized
INFO - 2020-02-10 05:20:28 --> Output Class Initialized
INFO - 2020-02-10 05:20:28 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:28 --> Input Class Initialized
INFO - 2020-02-10 05:20:29 --> Language Class Initialized
ERROR - 2020-02-10 05:20:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 05:20:29 --> Config Class Initialized
INFO - 2020-02-10 05:20:29 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:29 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:29 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:29 --> URI Class Initialized
INFO - 2020-02-10 05:20:29 --> Router Class Initialized
INFO - 2020-02-10 05:20:29 --> Output Class Initialized
INFO - 2020-02-10 05:20:29 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:29 --> Input Class Initialized
INFO - 2020-02-10 05:20:29 --> Language Class Initialized
ERROR - 2020-02-10 05:20:29 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 05:20:36 --> Config Class Initialized
INFO - 2020-02-10 05:20:37 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:37 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:37 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:37 --> URI Class Initialized
INFO - 2020-02-10 05:20:37 --> Router Class Initialized
INFO - 2020-02-10 05:20:37 --> Output Class Initialized
INFO - 2020-02-10 05:20:37 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:37 --> Input Class Initialized
INFO - 2020-02-10 05:20:37 --> Language Class Initialized
INFO - 2020-02-10 05:20:37 --> Loader Class Initialized
INFO - 2020-02-10 05:20:37 --> Helper loaded: url_helper
INFO - 2020-02-10 05:20:37 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:20:37 --> Controller Class Initialized
INFO - 2020-02-10 05:20:37 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:20:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:20:37 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:20:37 --> Helper loaded: form_helper
INFO - 2020-02-10 05:20:37 --> Form Validation Class Initialized
INFO - 2020-02-10 05:20:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:20:37 --> Final output sent to browser
DEBUG - 2020-02-10 05:20:37 --> Total execution time: 0.5620
INFO - 2020-02-10 05:20:37 --> Config Class Initialized
INFO - 2020-02-10 05:20:37 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:37 --> Config Class Initialized
INFO - 2020-02-10 05:20:37 --> Config Class Initialized
INFO - 2020-02-10 05:20:37 --> Config Class Initialized
INFO - 2020-02-10 05:20:37 --> Config Class Initialized
DEBUG - 2020-02-10 05:20:37 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:37 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:37 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:37 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:37 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:37 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:37 --> URI Class Initialized
DEBUG - 2020-02-10 05:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:20:37 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:37 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:37 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:37 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:37 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:37 --> Router Class Initialized
INFO - 2020-02-10 05:20:37 --> URI Class Initialized
INFO - 2020-02-10 05:20:37 --> URI Class Initialized
INFO - 2020-02-10 05:20:37 --> URI Class Initialized
INFO - 2020-02-10 05:20:37 --> Output Class Initialized
INFO - 2020-02-10 05:20:37 --> URI Class Initialized
INFO - 2020-02-10 05:20:37 --> Security Class Initialized
INFO - 2020-02-10 05:20:37 --> Router Class Initialized
INFO - 2020-02-10 05:20:37 --> Router Class Initialized
INFO - 2020-02-10 05:20:37 --> Router Class Initialized
INFO - 2020-02-10 05:20:37 --> Router Class Initialized
INFO - 2020-02-10 05:20:37 --> Output Class Initialized
INFO - 2020-02-10 05:20:37 --> Output Class Initialized
DEBUG - 2020-02-10 05:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:37 --> Output Class Initialized
INFO - 2020-02-10 05:20:37 --> Output Class Initialized
INFO - 2020-02-10 05:20:37 --> Input Class Initialized
INFO - 2020-02-10 05:20:37 --> Security Class Initialized
INFO - 2020-02-10 05:20:37 --> Security Class Initialized
INFO - 2020-02-10 05:20:37 --> Security Class Initialized
INFO - 2020-02-10 05:20:37 --> Security Class Initialized
INFO - 2020-02-10 05:20:37 --> Language Class Initialized
DEBUG - 2020-02-10 05:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:37 --> Input Class Initialized
INFO - 2020-02-10 05:20:37 --> Input Class Initialized
INFO - 2020-02-10 05:20:37 --> Input Class Initialized
INFO - 2020-02-10 05:20:37 --> Input Class Initialized
ERROR - 2020-02-10 05:20:37 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-10 05:20:37 --> Language Class Initialized
INFO - 2020-02-10 05:20:37 --> Language Class Initialized
INFO - 2020-02-10 05:20:37 --> Language Class Initialized
INFO - 2020-02-10 05:20:37 --> Language Class Initialized
ERROR - 2020-02-10 05:20:37 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-10 05:20:37 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-10 05:20:37 --> Loader Class Initialized
INFO - 2020-02-10 05:20:37 --> Loader Class Initialized
INFO - 2020-02-10 05:20:37 --> Helper loaded: url_helper
INFO - 2020-02-10 05:20:37 --> Helper loaded: url_helper
INFO - 2020-02-10 05:20:38 --> Database Driver Class Initialized
INFO - 2020-02-10 05:20:38 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-10 05:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:20:38 --> Controller Class Initialized
INFO - 2020-02-10 05:20:38 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:20:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:20:38 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:20:38 --> Helper loaded: form_helper
INFO - 2020-02-10 05:20:38 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:20:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:20:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:20:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:20:38 --> Final output sent to browser
DEBUG - 2020-02-10 05:20:38 --> Total execution time: 0.7019
INFO - 2020-02-10 05:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:20:38 --> Controller Class Initialized
INFO - 2020-02-10 05:20:38 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:20:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:20:38 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:20:38 --> Helper loaded: form_helper
INFO - 2020-02-10 05:20:38 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:20:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:20:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:20:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:20:38 --> Final output sent to browser
DEBUG - 2020-02-10 05:20:38 --> Total execution time: 1.1292
INFO - 2020-02-10 05:20:57 --> Config Class Initialized
INFO - 2020-02-10 05:20:57 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:20:57 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:57 --> Utf8 Class Initialized
INFO - 2020-02-10 05:20:57 --> URI Class Initialized
INFO - 2020-02-10 05:20:57 --> Router Class Initialized
INFO - 2020-02-10 05:20:57 --> Config Class Initialized
INFO - 2020-02-10 05:20:57 --> Hooks Class Initialized
INFO - 2020-02-10 05:20:57 --> Output Class Initialized
INFO - 2020-02-10 05:20:57 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:57 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:20:57 --> Utf8 Class Initialized
DEBUG - 2020-02-10 05:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:57 --> Input Class Initialized
INFO - 2020-02-10 05:20:57 --> URI Class Initialized
INFO - 2020-02-10 05:20:57 --> Language Class Initialized
INFO - 2020-02-10 05:20:57 --> Router Class Initialized
INFO - 2020-02-10 05:20:57 --> Output Class Initialized
INFO - 2020-02-10 05:20:57 --> Loader Class Initialized
INFO - 2020-02-10 05:20:57 --> Helper loaded: url_helper
INFO - 2020-02-10 05:20:57 --> Security Class Initialized
DEBUG - 2020-02-10 05:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:20:57 --> Database Driver Class Initialized
INFO - 2020-02-10 05:20:57 --> Input Class Initialized
DEBUG - 2020-02-10 05:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:20:57 --> Language Class Initialized
INFO - 2020-02-10 05:20:57 --> Controller Class Initialized
INFO - 2020-02-10 05:20:57 --> Loader Class Initialized
INFO - 2020-02-10 05:20:57 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:20:57 --> Helper loaded: url_helper
INFO - 2020-02-10 05:20:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:20:57 --> Database Driver Class Initialized
INFO - 2020-02-10 05:20:57 --> Model "M_pesan" initialized
DEBUG - 2020-02-10 05:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:20:57 --> Helper loaded: form_helper
INFO - 2020-02-10 05:20:57 --> Form Validation Class Initialized
INFO - 2020-02-10 05:20:57 --> Final output sent to browser
DEBUG - 2020-02-10 05:20:57 --> Total execution time: 0.8111
INFO - 2020-02-10 05:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:20:57 --> Controller Class Initialized
INFO - 2020-02-10 05:20:58 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:20:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:20:58 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:20:58 --> Helper loaded: form_helper
INFO - 2020-02-10 05:20:58 --> Form Validation Class Initialized
INFO - 2020-02-10 05:20:58 --> Final output sent to browser
DEBUG - 2020-02-10 05:20:58 --> Total execution time: 1.1930
INFO - 2020-02-10 05:21:20 --> Config Class Initialized
INFO - 2020-02-10 05:21:20 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:21:20 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:21:20 --> Utf8 Class Initialized
INFO - 2020-02-10 05:21:20 --> URI Class Initialized
INFO - 2020-02-10 05:21:20 --> Router Class Initialized
INFO - 2020-02-10 05:21:20 --> Output Class Initialized
INFO - 2020-02-10 05:21:20 --> Security Class Initialized
DEBUG - 2020-02-10 05:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:21:20 --> Input Class Initialized
INFO - 2020-02-10 05:21:20 --> Language Class Initialized
INFO - 2020-02-10 05:21:21 --> Loader Class Initialized
INFO - 2020-02-10 05:21:21 --> Helper loaded: url_helper
INFO - 2020-02-10 05:21:21 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:21:21 --> Controller Class Initialized
INFO - 2020-02-10 05:21:21 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:21:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:21:21 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:21:21 --> Helper loaded: form_helper
INFO - 2020-02-10 05:21:21 --> Form Validation Class Initialized
INFO - 2020-02-10 05:21:21 --> Final output sent to browser
DEBUG - 2020-02-10 05:21:21 --> Total execution time: 0.8816
INFO - 2020-02-10 05:28:57 --> Config Class Initialized
INFO - 2020-02-10 05:28:57 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:28:57 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:28:57 --> Utf8 Class Initialized
INFO - 2020-02-10 05:28:57 --> URI Class Initialized
INFO - 2020-02-10 05:28:57 --> Router Class Initialized
INFO - 2020-02-10 05:28:57 --> Output Class Initialized
INFO - 2020-02-10 05:28:57 --> Security Class Initialized
DEBUG - 2020-02-10 05:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:28:57 --> Input Class Initialized
INFO - 2020-02-10 05:28:57 --> Language Class Initialized
INFO - 2020-02-10 05:28:57 --> Loader Class Initialized
INFO - 2020-02-10 05:28:57 --> Helper loaded: url_helper
INFO - 2020-02-10 05:28:57 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:28:57 --> Controller Class Initialized
INFO - 2020-02-10 05:28:57 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:28:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:28:57 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:28:57 --> Helper loaded: form_helper
INFO - 2020-02-10 05:28:57 --> Form Validation Class Initialized
INFO - 2020-02-10 05:28:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:28:57 --> Final output sent to browser
DEBUG - 2020-02-10 05:28:57 --> Total execution time: 0.5772
INFO - 2020-02-10 05:29:02 --> Config Class Initialized
INFO - 2020-02-10 05:29:02 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:29:02 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:29:02 --> Utf8 Class Initialized
INFO - 2020-02-10 05:29:02 --> URI Class Initialized
INFO - 2020-02-10 05:29:02 --> Router Class Initialized
INFO - 2020-02-10 05:29:02 --> Output Class Initialized
INFO - 2020-02-10 05:29:02 --> Security Class Initialized
DEBUG - 2020-02-10 05:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:29:02 --> Input Class Initialized
INFO - 2020-02-10 05:29:02 --> Language Class Initialized
INFO - 2020-02-10 05:29:02 --> Loader Class Initialized
INFO - 2020-02-10 05:29:02 --> Helper loaded: url_helper
INFO - 2020-02-10 05:29:02 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:29:02 --> Controller Class Initialized
INFO - 2020-02-10 05:29:02 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:29:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:29:02 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:29:02 --> Helper loaded: form_helper
INFO - 2020-02-10 05:29:02 --> Form Validation Class Initialized
INFO - 2020-02-10 05:29:03 --> Final output sent to browser
DEBUG - 2020-02-10 05:29:03 --> Total execution time: 0.8261
INFO - 2020-02-10 05:41:41 --> Config Class Initialized
INFO - 2020-02-10 05:41:41 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:41:41 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:41:41 --> Utf8 Class Initialized
INFO - 2020-02-10 05:41:41 --> URI Class Initialized
INFO - 2020-02-10 05:41:41 --> Router Class Initialized
INFO - 2020-02-10 05:41:41 --> Output Class Initialized
INFO - 2020-02-10 05:41:41 --> Security Class Initialized
DEBUG - 2020-02-10 05:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:41:41 --> Input Class Initialized
INFO - 2020-02-10 05:41:41 --> Language Class Initialized
INFO - 2020-02-10 05:41:41 --> Loader Class Initialized
INFO - 2020-02-10 05:41:41 --> Helper loaded: url_helper
INFO - 2020-02-10 05:41:41 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:41:42 --> Controller Class Initialized
INFO - 2020-02-10 05:41:42 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:41:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:41:42 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:41:42 --> Helper loaded: form_helper
INFO - 2020-02-10 05:41:42 --> Form Validation Class Initialized
INFO - 2020-02-10 05:41:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:41:42 --> Final output sent to browser
INFO - 2020-02-10 05:41:42 --> Config Class Initialized
DEBUG - 2020-02-10 05:41:42 --> Total execution time: 0.8407
INFO - 2020-02-10 05:41:42 --> Config Class Initialized
INFO - 2020-02-10 05:41:42 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:41:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:41:43 --> Utf8 Class Initialized
INFO - 2020-02-10 05:41:43 --> Hooks Class Initialized
INFO - 2020-02-10 05:41:43 --> URI Class Initialized
INFO - 2020-02-10 05:41:43 --> Router Class Initialized
DEBUG - 2020-02-10 05:41:43 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:41:43 --> Utf8 Class Initialized
INFO - 2020-02-10 05:41:43 --> Output Class Initialized
INFO - 2020-02-10 05:41:43 --> URI Class Initialized
INFO - 2020-02-10 05:41:43 --> Security Class Initialized
DEBUG - 2020-02-10 05:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:41:43 --> Router Class Initialized
INFO - 2020-02-10 05:41:43 --> Input Class Initialized
INFO - 2020-02-10 05:41:43 --> Output Class Initialized
INFO - 2020-02-10 05:41:43 --> Security Class Initialized
INFO - 2020-02-10 05:41:43 --> Language Class Initialized
DEBUG - 2020-02-10 05:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:41:43 --> Loader Class Initialized
INFO - 2020-02-10 05:41:43 --> Input Class Initialized
INFO - 2020-02-10 05:41:43 --> Helper loaded: url_helper
INFO - 2020-02-10 05:41:43 --> Language Class Initialized
INFO - 2020-02-10 05:41:43 --> Database Driver Class Initialized
INFO - 2020-02-10 05:41:43 --> Loader Class Initialized
DEBUG - 2020-02-10 05:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:41:43 --> Helper loaded: url_helper
INFO - 2020-02-10 05:41:43 --> Controller Class Initialized
INFO - 2020-02-10 05:41:43 --> Database Driver Class Initialized
INFO - 2020-02-10 05:41:43 --> Model "M_tiket" initialized
DEBUG - 2020-02-10 05:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:41:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:41:43 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:41:43 --> Helper loaded: form_helper
INFO - 2020-02-10 05:41:43 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:41:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:41:43 --> Final output sent to browser
DEBUG - 2020-02-10 05:41:43 --> Total execution time: 1.1836
INFO - 2020-02-10 05:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:41:43 --> Controller Class Initialized
INFO - 2020-02-10 05:41:43 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:41:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:41:43 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:41:43 --> Helper loaded: form_helper
INFO - 2020-02-10 05:41:43 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:41:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:41:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:41:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:41:44 --> Final output sent to browser
DEBUG - 2020-02-10 05:41:44 --> Total execution time: 1.6002
INFO - 2020-02-10 05:42:04 --> Config Class Initialized
INFO - 2020-02-10 05:42:04 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:42:04 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:42:04 --> Utf8 Class Initialized
INFO - 2020-02-10 05:42:04 --> URI Class Initialized
INFO - 2020-02-10 05:42:04 --> Router Class Initialized
INFO - 2020-02-10 05:42:04 --> Output Class Initialized
INFO - 2020-02-10 05:42:04 --> Security Class Initialized
DEBUG - 2020-02-10 05:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:42:04 --> Input Class Initialized
INFO - 2020-02-10 05:42:04 --> Language Class Initialized
INFO - 2020-02-10 05:42:04 --> Loader Class Initialized
INFO - 2020-02-10 05:42:04 --> Helper loaded: url_helper
INFO - 2020-02-10 05:42:04 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:42:04 --> Controller Class Initialized
INFO - 2020-02-10 05:42:04 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:42:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:42:04 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:42:04 --> Helper loaded: form_helper
INFO - 2020-02-10 05:42:04 --> Form Validation Class Initialized
INFO - 2020-02-10 05:42:05 --> Final output sent to browser
DEBUG - 2020-02-10 05:42:05 --> Total execution time: 0.7702
INFO - 2020-02-10 05:42:18 --> Config Class Initialized
INFO - 2020-02-10 05:42:18 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:42:18 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:42:18 --> Utf8 Class Initialized
INFO - 2020-02-10 05:42:18 --> URI Class Initialized
INFO - 2020-02-10 05:42:18 --> Router Class Initialized
INFO - 2020-02-10 05:42:18 --> Output Class Initialized
INFO - 2020-02-10 05:42:18 --> Security Class Initialized
DEBUG - 2020-02-10 05:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:42:18 --> Input Class Initialized
INFO - 2020-02-10 05:42:18 --> Language Class Initialized
INFO - 2020-02-10 05:42:18 --> Loader Class Initialized
INFO - 2020-02-10 05:42:18 --> Helper loaded: url_helper
INFO - 2020-02-10 05:42:18 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:42:18 --> Controller Class Initialized
INFO - 2020-02-10 05:42:18 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:42:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:42:18 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:42:18 --> Helper loaded: form_helper
INFO - 2020-02-10 05:42:18 --> Form Validation Class Initialized
INFO - 2020-02-10 05:42:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:42:18 --> Final output sent to browser
DEBUG - 2020-02-10 05:42:18 --> Total execution time: 0.8588
INFO - 2020-02-10 05:42:19 --> Config Class Initialized
INFO - 2020-02-10 05:42:19 --> Hooks Class Initialized
INFO - 2020-02-10 05:42:19 --> Config Class Initialized
INFO - 2020-02-10 05:42:19 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:42:19 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:42:19 --> Utf8 Class Initialized
DEBUG - 2020-02-10 05:42:19 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:42:19 --> Utf8 Class Initialized
INFO - 2020-02-10 05:42:19 --> URI Class Initialized
INFO - 2020-02-10 05:42:19 --> URI Class Initialized
INFO - 2020-02-10 05:42:19 --> Router Class Initialized
INFO - 2020-02-10 05:42:19 --> Router Class Initialized
INFO - 2020-02-10 05:42:19 --> Output Class Initialized
INFO - 2020-02-10 05:42:19 --> Security Class Initialized
INFO - 2020-02-10 05:42:19 --> Output Class Initialized
INFO - 2020-02-10 05:42:19 --> Security Class Initialized
DEBUG - 2020-02-10 05:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:42:19 --> Input Class Initialized
DEBUG - 2020-02-10 05:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:42:19 --> Input Class Initialized
INFO - 2020-02-10 05:42:19 --> Language Class Initialized
INFO - 2020-02-10 05:42:19 --> Language Class Initialized
INFO - 2020-02-10 05:42:19 --> Loader Class Initialized
INFO - 2020-02-10 05:42:19 --> Helper loaded: url_helper
INFO - 2020-02-10 05:42:19 --> Loader Class Initialized
INFO - 2020-02-10 05:42:19 --> Helper loaded: url_helper
INFO - 2020-02-10 05:42:19 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:42:19 --> Database Driver Class Initialized
INFO - 2020-02-10 05:42:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 05:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:42:19 --> Controller Class Initialized
INFO - 2020-02-10 05:42:19 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:42:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:42:19 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:42:19 --> Helper loaded: form_helper
INFO - 2020-02-10 05:42:19 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:42:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:42:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:42:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:42:19 --> Final output sent to browser
DEBUG - 2020-02-10 05:42:19 --> Total execution time: 0.6397
INFO - 2020-02-10 05:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:42:19 --> Controller Class Initialized
INFO - 2020-02-10 05:42:19 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:42:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:42:19 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:42:19 --> Helper loaded: form_helper
INFO - 2020-02-10 05:42:19 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:42:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:42:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:42:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:42:19 --> Final output sent to browser
DEBUG - 2020-02-10 05:42:19 --> Total execution time: 0.8794
INFO - 2020-02-10 05:43:52 --> Config Class Initialized
INFO - 2020-02-10 05:43:52 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:52 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:52 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:53 --> URI Class Initialized
INFO - 2020-02-10 05:43:53 --> Router Class Initialized
INFO - 2020-02-10 05:43:53 --> Output Class Initialized
INFO - 2020-02-10 05:43:53 --> Security Class Initialized
DEBUG - 2020-02-10 05:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:53 --> Input Class Initialized
INFO - 2020-02-10 05:43:53 --> Language Class Initialized
INFO - 2020-02-10 05:43:53 --> Loader Class Initialized
INFO - 2020-02-10 05:43:53 --> Helper loaded: url_helper
INFO - 2020-02-10 05:43:53 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:43:53 --> Controller Class Initialized
INFO - 2020-02-10 05:43:53 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:43:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:43:53 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:43:53 --> Helper loaded: form_helper
INFO - 2020-02-10 05:43:53 --> Form Validation Class Initialized
INFO - 2020-02-10 05:43:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:43:53 --> Final output sent to browser
DEBUG - 2020-02-10 05:43:53 --> Total execution time: 0.6625
INFO - 2020-02-10 05:43:53 --> Config Class Initialized
INFO - 2020-02-10 05:43:53 --> Config Class Initialized
INFO - 2020-02-10 05:43:53 --> Hooks Class Initialized
INFO - 2020-02-10 05:43:53 --> Hooks Class Initialized
INFO - 2020-02-10 05:43:53 --> Config Class Initialized
INFO - 2020-02-10 05:43:53 --> Config Class Initialized
INFO - 2020-02-10 05:43:53 --> Config Class Initialized
INFO - 2020-02-10 05:43:53 --> Config Class Initialized
INFO - 2020-02-10 05:43:53 --> Hooks Class Initialized
INFO - 2020-02-10 05:43:53 --> Hooks Class Initialized
INFO - 2020-02-10 05:43:53 --> Hooks Class Initialized
INFO - 2020-02-10 05:43:53 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:43:53 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:53 --> Utf8 Class Initialized
DEBUG - 2020-02-10 05:43:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:43:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:43:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:43:53 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:53 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:53 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:53 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:53 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:53 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:53 --> URI Class Initialized
INFO - 2020-02-10 05:43:53 --> URI Class Initialized
INFO - 2020-02-10 05:43:53 --> URI Class Initialized
INFO - 2020-02-10 05:43:53 --> URI Class Initialized
INFO - 2020-02-10 05:43:53 --> Router Class Initialized
INFO - 2020-02-10 05:43:53 --> Router Class Initialized
INFO - 2020-02-10 05:43:53 --> Router Class Initialized
INFO - 2020-02-10 05:43:53 --> URI Class Initialized
INFO - 2020-02-10 05:43:53 --> URI Class Initialized
INFO - 2020-02-10 05:43:53 --> Router Class Initialized
INFO - 2020-02-10 05:43:53 --> Output Class Initialized
INFO - 2020-02-10 05:43:53 --> Output Class Initialized
INFO - 2020-02-10 05:43:53 --> Router Class Initialized
INFO - 2020-02-10 05:43:53 --> Output Class Initialized
INFO - 2020-02-10 05:43:53 --> Router Class Initialized
INFO - 2020-02-10 05:43:53 --> Output Class Initialized
INFO - 2020-02-10 05:43:53 --> Output Class Initialized
INFO - 2020-02-10 05:43:53 --> Output Class Initialized
INFO - 2020-02-10 05:43:53 --> Security Class Initialized
INFO - 2020-02-10 05:43:53 --> Security Class Initialized
INFO - 2020-02-10 05:43:53 --> Security Class Initialized
DEBUG - 2020-02-10 05:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:53 --> Security Class Initialized
INFO - 2020-02-10 05:43:53 --> Security Class Initialized
INFO - 2020-02-10 05:43:53 --> Security Class Initialized
DEBUG - 2020-02-10 05:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:53 --> Input Class Initialized
INFO - 2020-02-10 05:43:53 --> Input Class Initialized
INFO - 2020-02-10 05:43:53 --> Input Class Initialized
DEBUG - 2020-02-10 05:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:53 --> Input Class Initialized
INFO - 2020-02-10 05:43:53 --> Input Class Initialized
INFO - 2020-02-10 05:43:53 --> Language Class Initialized
INFO - 2020-02-10 05:43:53 --> Language Class Initialized
INFO - 2020-02-10 05:43:53 --> Language Class Initialized
INFO - 2020-02-10 05:43:53 --> Input Class Initialized
INFO - 2020-02-10 05:43:54 --> Language Class Initialized
ERROR - 2020-02-10 05:43:54 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-10 05:43:54 --> Language Class Initialized
ERROR - 2020-02-10 05:43:54 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-10 05:43:54 --> Language Class Initialized
INFO - 2020-02-10 05:43:54 --> Loader Class Initialized
ERROR - 2020-02-10 05:43:54 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 05:43:54 --> Helper loaded: url_helper
ERROR - 2020-02-10 05:43:54 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-10 05:43:54 --> Loader Class Initialized
INFO - 2020-02-10 05:43:54 --> Config Class Initialized
INFO - 2020-02-10 05:43:54 --> Config Class Initialized
INFO - 2020-02-10 05:43:54 --> Hooks Class Initialized
INFO - 2020-02-10 05:43:54 --> Hooks Class Initialized
INFO - 2020-02-10 05:43:54 --> Helper loaded: url_helper
INFO - 2020-02-10 05:43:54 --> Database Driver Class Initialized
INFO - 2020-02-10 05:43:54 --> Config Class Initialized
INFO - 2020-02-10 05:43:54 --> Config Class Initialized
INFO - 2020-02-10 05:43:54 --> Hooks Class Initialized
INFO - 2020-02-10 05:43:54 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:43:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:43:54 --> Database Driver Class Initialized
INFO - 2020-02-10 05:43:54 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:54 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 05:43:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:43:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:43:54 --> Controller Class Initialized
INFO - 2020-02-10 05:43:54 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:54 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:54 --> URI Class Initialized
INFO - 2020-02-10 05:43:54 --> URI Class Initialized
INFO - 2020-02-10 05:43:54 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:43:54 --> URI Class Initialized
INFO - 2020-02-10 05:43:54 --> URI Class Initialized
INFO - 2020-02-10 05:43:54 --> Router Class Initialized
INFO - 2020-02-10 05:43:54 --> Router Class Initialized
INFO - 2020-02-10 05:43:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:43:54 --> Router Class Initialized
INFO - 2020-02-10 05:43:54 --> Output Class Initialized
INFO - 2020-02-10 05:43:54 --> Output Class Initialized
INFO - 2020-02-10 05:43:54 --> Router Class Initialized
INFO - 2020-02-10 05:43:54 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:43:54 --> Security Class Initialized
INFO - 2020-02-10 05:43:54 --> Security Class Initialized
INFO - 2020-02-10 05:43:54 --> Output Class Initialized
INFO - 2020-02-10 05:43:54 --> Output Class Initialized
DEBUG - 2020-02-10 05:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:54 --> Security Class Initialized
INFO - 2020-02-10 05:43:54 --> Security Class Initialized
INFO - 2020-02-10 05:43:54 --> Helper loaded: form_helper
INFO - 2020-02-10 05:43:54 --> Form Validation Class Initialized
INFO - 2020-02-10 05:43:54 --> Input Class Initialized
INFO - 2020-02-10 05:43:54 --> Input Class Initialized
DEBUG - 2020-02-10 05:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:54 --> Input Class Initialized
INFO - 2020-02-10 05:43:54 --> Language Class Initialized
INFO - 2020-02-10 05:43:54 --> Language Class Initialized
INFO - 2020-02-10 05:43:54 --> Input Class Initialized
ERROR - 2020-02-10 05:43:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 05:43:54 --> Language Class Initialized
ERROR - 2020-02-10 05:43:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-10 05:43:54 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 05:43:54 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 05:43:54 --> Language Class Initialized
INFO - 2020-02-10 05:43:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-10 05:43:54 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 05:43:54 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 05:43:54 --> Config Class Initialized
INFO - 2020-02-10 05:43:54 --> Hooks Class Initialized
INFO - 2020-02-10 05:43:54 --> Final output sent to browser
INFO - 2020-02-10 05:43:54 --> Config Class Initialized
INFO - 2020-02-10 05:43:54 --> Config Class Initialized
INFO - 2020-02-10 05:43:54 --> Config Class Initialized
INFO - 2020-02-10 05:43:54 --> Hooks Class Initialized
INFO - 2020-02-10 05:43:54 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:54 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:54 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:54 --> Total execution time: 0.6935
INFO - 2020-02-10 05:43:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 05:43:54 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:54 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:54 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:54 --> Controller Class Initialized
DEBUG - 2020-02-10 05:43:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:43:54 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:54 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:43:54 --> URI Class Initialized
INFO - 2020-02-10 05:43:54 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:54 --> URI Class Initialized
INFO - 2020-02-10 05:43:55 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:43:55 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:43:55 --> Router Class Initialized
INFO - 2020-02-10 05:43:55 --> URI Class Initialized
INFO - 2020-02-10 05:43:55 --> URI Class Initialized
INFO - 2020-02-10 05:43:55 --> Router Class Initialized
INFO - 2020-02-10 05:43:55 --> Helper loaded: form_helper
INFO - 2020-02-10 05:43:55 --> Output Class Initialized
INFO - 2020-02-10 05:43:55 --> Router Class Initialized
INFO - 2020-02-10 05:43:55 --> Router Class Initialized
INFO - 2020-02-10 05:43:55 --> Output Class Initialized
INFO - 2020-02-10 05:43:55 --> Output Class Initialized
INFO - 2020-02-10 05:43:55 --> Output Class Initialized
INFO - 2020-02-10 05:43:55 --> Form Validation Class Initialized
INFO - 2020-02-10 05:43:55 --> Security Class Initialized
DEBUG - 2020-02-10 05:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:55 --> Security Class Initialized
INFO - 2020-02-10 05:43:55 --> Security Class Initialized
INFO - 2020-02-10 05:43:55 --> Security Class Initialized
ERROR - 2020-02-10 05:43:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 05:43:55 --> Input Class Initialized
DEBUG - 2020-02-10 05:43:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-10 05:43:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
DEBUG - 2020-02-10 05:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:55 --> Input Class Initialized
INFO - 2020-02-10 05:43:55 --> Input Class Initialized
INFO - 2020-02-10 05:43:55 --> Language Class Initialized
INFO - 2020-02-10 05:43:55 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:43:55 --> Input Class Initialized
INFO - 2020-02-10 05:43:55 --> Language Class Initialized
INFO - 2020-02-10 05:43:55 --> Language Class Initialized
INFO - 2020-02-10 05:43:55 --> Language Class Initialized
ERROR - 2020-02-10 05:43:55 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 05:43:55 --> Final output sent to browser
DEBUG - 2020-02-10 05:43:55 --> Total execution time: 1.7336
ERROR - 2020-02-10 05:43:55 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-10 05:43:55 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-10 05:43:55 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-10 05:43:55 --> Config Class Initialized
INFO - 2020-02-10 05:43:55 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:55 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:55 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:55 --> URI Class Initialized
INFO - 2020-02-10 05:43:55 --> Router Class Initialized
INFO - 2020-02-10 05:43:55 --> Output Class Initialized
INFO - 2020-02-10 05:43:55 --> Security Class Initialized
DEBUG - 2020-02-10 05:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:55 --> Input Class Initialized
INFO - 2020-02-10 05:43:55 --> Language Class Initialized
ERROR - 2020-02-10 05:43:55 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-10 05:43:55 --> Config Class Initialized
INFO - 2020-02-10 05:43:56 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:56 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:56 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:56 --> URI Class Initialized
INFO - 2020-02-10 05:43:56 --> Router Class Initialized
INFO - 2020-02-10 05:43:56 --> Output Class Initialized
INFO - 2020-02-10 05:43:56 --> Security Class Initialized
DEBUG - 2020-02-10 05:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:56 --> Input Class Initialized
INFO - 2020-02-10 05:43:56 --> Language Class Initialized
ERROR - 2020-02-10 05:43:56 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 05:43:56 --> Config Class Initialized
INFO - 2020-02-10 05:43:56 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:56 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:56 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:56 --> URI Class Initialized
INFO - 2020-02-10 05:43:56 --> Router Class Initialized
INFO - 2020-02-10 05:43:56 --> Output Class Initialized
INFO - 2020-02-10 05:43:56 --> Security Class Initialized
DEBUG - 2020-02-10 05:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:56 --> Input Class Initialized
INFO - 2020-02-10 05:43:56 --> Language Class Initialized
ERROR - 2020-02-10 05:43:56 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 05:43:56 --> Config Class Initialized
INFO - 2020-02-10 05:43:56 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:56 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:56 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:56 --> URI Class Initialized
INFO - 2020-02-10 05:43:56 --> Router Class Initialized
INFO - 2020-02-10 05:43:56 --> Output Class Initialized
INFO - 2020-02-10 05:43:56 --> Security Class Initialized
DEBUG - 2020-02-10 05:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:56 --> Input Class Initialized
INFO - 2020-02-10 05:43:56 --> Language Class Initialized
ERROR - 2020-02-10 05:43:56 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 05:43:57 --> Config Class Initialized
INFO - 2020-02-10 05:43:57 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:57 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:57 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:57 --> URI Class Initialized
INFO - 2020-02-10 05:43:57 --> Router Class Initialized
INFO - 2020-02-10 05:43:57 --> Output Class Initialized
INFO - 2020-02-10 05:43:57 --> Security Class Initialized
DEBUG - 2020-02-10 05:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:57 --> Input Class Initialized
INFO - 2020-02-10 05:43:57 --> Language Class Initialized
ERROR - 2020-02-10 05:43:57 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 05:43:57 --> Config Class Initialized
INFO - 2020-02-10 05:43:57 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:57 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:57 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:57 --> URI Class Initialized
INFO - 2020-02-10 05:43:57 --> Router Class Initialized
INFO - 2020-02-10 05:43:57 --> Output Class Initialized
INFO - 2020-02-10 05:43:57 --> Security Class Initialized
DEBUG - 2020-02-10 05:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:57 --> Input Class Initialized
INFO - 2020-02-10 05:43:57 --> Language Class Initialized
ERROR - 2020-02-10 05:43:57 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 05:43:57 --> Config Class Initialized
INFO - 2020-02-10 05:43:57 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:57 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:57 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:58 --> URI Class Initialized
INFO - 2020-02-10 05:43:58 --> Router Class Initialized
INFO - 2020-02-10 05:43:58 --> Output Class Initialized
INFO - 2020-02-10 05:43:58 --> Security Class Initialized
DEBUG - 2020-02-10 05:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:58 --> Input Class Initialized
INFO - 2020-02-10 05:43:58 --> Language Class Initialized
ERROR - 2020-02-10 05:43:58 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 05:43:58 --> Config Class Initialized
INFO - 2020-02-10 05:43:58 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:58 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:58 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:58 --> URI Class Initialized
INFO - 2020-02-10 05:43:58 --> Router Class Initialized
INFO - 2020-02-10 05:43:58 --> Output Class Initialized
INFO - 2020-02-10 05:43:58 --> Security Class Initialized
DEBUG - 2020-02-10 05:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:58 --> Input Class Initialized
INFO - 2020-02-10 05:43:58 --> Language Class Initialized
ERROR - 2020-02-10 05:43:58 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 05:43:58 --> Config Class Initialized
INFO - 2020-02-10 05:43:58 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:43:58 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:43:58 --> Utf8 Class Initialized
INFO - 2020-02-10 05:43:58 --> URI Class Initialized
INFO - 2020-02-10 05:43:58 --> Router Class Initialized
INFO - 2020-02-10 05:43:58 --> Output Class Initialized
INFO - 2020-02-10 05:43:58 --> Security Class Initialized
DEBUG - 2020-02-10 05:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:43:58 --> Input Class Initialized
INFO - 2020-02-10 05:43:58 --> Language Class Initialized
ERROR - 2020-02-10 05:43:58 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 05:48:19 --> Config Class Initialized
INFO - 2020-02-10 05:48:19 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:48:19 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:48:19 --> Utf8 Class Initialized
INFO - 2020-02-10 05:48:19 --> URI Class Initialized
INFO - 2020-02-10 05:48:19 --> Router Class Initialized
INFO - 2020-02-10 05:48:19 --> Output Class Initialized
INFO - 2020-02-10 05:48:19 --> Security Class Initialized
DEBUG - 2020-02-10 05:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:48:19 --> Input Class Initialized
INFO - 2020-02-10 05:48:19 --> Language Class Initialized
INFO - 2020-02-10 05:48:19 --> Loader Class Initialized
INFO - 2020-02-10 05:48:19 --> Helper loaded: url_helper
INFO - 2020-02-10 05:48:19 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:48:19 --> Controller Class Initialized
INFO - 2020-02-10 05:48:19 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:48:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:48:19 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:48:19 --> Helper loaded: form_helper
INFO - 2020-02-10 05:48:19 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:48:19 --> Severity: Notice --> Undefined variable: show C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:48:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:48:19 --> Severity: Notice --> Undefined variable: show C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-10 05:48:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-10 05:48:20 --> Severity: Notice --> Undefined variable: tiket C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 81
ERROR - 2020-02-10 05:48:20 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 81
INFO - 2020-02-10 05:50:04 --> Config Class Initialized
INFO - 2020-02-10 05:50:04 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:50:04 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:05 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:05 --> URI Class Initialized
INFO - 2020-02-10 05:50:05 --> Router Class Initialized
INFO - 2020-02-10 05:50:05 --> Output Class Initialized
INFO - 2020-02-10 05:50:05 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:05 --> Input Class Initialized
INFO - 2020-02-10 05:50:05 --> Language Class Initialized
INFO - 2020-02-10 05:50:05 --> Loader Class Initialized
INFO - 2020-02-10 05:50:05 --> Helper loaded: url_helper
INFO - 2020-02-10 05:50:05 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:50:05 --> Controller Class Initialized
INFO - 2020-02-10 05:50:05 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:50:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:50:05 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:50:05 --> Helper loaded: form_helper
INFO - 2020-02-10 05:50:05 --> Form Validation Class Initialized
INFO - 2020-02-10 05:50:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:50:05 --> Final output sent to browser
DEBUG - 2020-02-10 05:50:05 --> Total execution time: 0.7642
INFO - 2020-02-10 05:50:05 --> Config Class Initialized
INFO - 2020-02-10 05:50:05 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:05 --> Config Class Initialized
INFO - 2020-02-10 05:50:05 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:50:05 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:05 --> Utf8 Class Initialized
DEBUG - 2020-02-10 05:50:05 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:05 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:05 --> URI Class Initialized
INFO - 2020-02-10 05:50:05 --> URI Class Initialized
INFO - 2020-02-10 05:50:05 --> Router Class Initialized
INFO - 2020-02-10 05:50:05 --> Router Class Initialized
INFO - 2020-02-10 05:50:05 --> Output Class Initialized
INFO - 2020-02-10 05:50:05 --> Output Class Initialized
INFO - 2020-02-10 05:50:05 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:05 --> Security Class Initialized
INFO - 2020-02-10 05:50:06 --> Input Class Initialized
DEBUG - 2020-02-10 05:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:06 --> Input Class Initialized
INFO - 2020-02-10 05:50:06 --> Language Class Initialized
INFO - 2020-02-10 05:50:06 --> Language Class Initialized
INFO - 2020-02-10 05:50:06 --> Loader Class Initialized
INFO - 2020-02-10 05:50:06 --> Helper loaded: url_helper
INFO - 2020-02-10 05:50:06 --> Loader Class Initialized
INFO - 2020-02-10 05:50:06 --> Helper loaded: url_helper
INFO - 2020-02-10 05:50:06 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:50:06 --> Database Driver Class Initialized
INFO - 2020-02-10 05:50:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 05:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:50:06 --> Controller Class Initialized
INFO - 2020-02-10 05:50:06 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:50:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:50:06 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:50:06 --> Helper loaded: form_helper
INFO - 2020-02-10 05:50:06 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:50:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:50:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:50:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:50:06 --> Final output sent to browser
DEBUG - 2020-02-10 05:50:06 --> Total execution time: 0.6375
INFO - 2020-02-10 05:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:50:06 --> Controller Class Initialized
INFO - 2020-02-10 05:50:06 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:50:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:50:06 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:50:06 --> Helper loaded: form_helper
INFO - 2020-02-10 05:50:06 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:50:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:50:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:50:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:50:06 --> Final output sent to browser
DEBUG - 2020-02-10 05:50:06 --> Total execution time: 0.8539
INFO - 2020-02-10 05:50:09 --> Config Class Initialized
INFO - 2020-02-10 05:50:09 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:50:09 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:09 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:09 --> URI Class Initialized
INFO - 2020-02-10 05:50:09 --> Router Class Initialized
INFO - 2020-02-10 05:50:09 --> Output Class Initialized
INFO - 2020-02-10 05:50:09 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:09 --> Input Class Initialized
INFO - 2020-02-10 05:50:09 --> Language Class Initialized
INFO - 2020-02-10 05:50:09 --> Loader Class Initialized
INFO - 2020-02-10 05:50:09 --> Helper loaded: url_helper
INFO - 2020-02-10 05:50:09 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:50:10 --> Controller Class Initialized
INFO - 2020-02-10 05:50:10 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:50:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:50:10 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:50:10 --> Helper loaded: form_helper
INFO - 2020-02-10 05:50:10 --> Form Validation Class Initialized
INFO - 2020-02-10 05:50:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:50:10 --> Final output sent to browser
DEBUG - 2020-02-10 05:50:10 --> Total execution time: 0.9305
INFO - 2020-02-10 05:50:10 --> Config Class Initialized
INFO - 2020-02-10 05:50:10 --> Config Class Initialized
INFO - 2020-02-10 05:50:10 --> Config Class Initialized
INFO - 2020-02-10 05:50:10 --> Config Class Initialized
INFO - 2020-02-10 05:50:10 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:10 --> Config Class Initialized
INFO - 2020-02-10 05:50:10 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:10 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:10 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:10 --> Config Class Initialized
INFO - 2020-02-10 05:50:10 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:10 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:50:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:50:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:50:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:50:10 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:10 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:10 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:10 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:10 --> Utf8 Class Initialized
DEBUG - 2020-02-10 05:50:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:50:10 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:10 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:10 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:10 --> URI Class Initialized
INFO - 2020-02-10 05:50:10 --> URI Class Initialized
INFO - 2020-02-10 05:50:10 --> URI Class Initialized
INFO - 2020-02-10 05:50:10 --> URI Class Initialized
INFO - 2020-02-10 05:50:10 --> URI Class Initialized
INFO - 2020-02-10 05:50:10 --> Router Class Initialized
INFO - 2020-02-10 05:50:10 --> Router Class Initialized
INFO - 2020-02-10 05:50:10 --> Router Class Initialized
INFO - 2020-02-10 05:50:10 --> Router Class Initialized
INFO - 2020-02-10 05:50:10 --> URI Class Initialized
INFO - 2020-02-10 05:50:10 --> Router Class Initialized
INFO - 2020-02-10 05:50:10 --> Output Class Initialized
INFO - 2020-02-10 05:50:10 --> Output Class Initialized
INFO - 2020-02-10 05:50:10 --> Output Class Initialized
INFO - 2020-02-10 05:50:10 --> Output Class Initialized
INFO - 2020-02-10 05:50:10 --> Router Class Initialized
INFO - 2020-02-10 05:50:10 --> Output Class Initialized
INFO - 2020-02-10 05:50:10 --> Security Class Initialized
INFO - 2020-02-10 05:50:10 --> Security Class Initialized
INFO - 2020-02-10 05:50:10 --> Output Class Initialized
INFO - 2020-02-10 05:50:10 --> Security Class Initialized
INFO - 2020-02-10 05:50:10 --> Security Class Initialized
INFO - 2020-02-10 05:50:10 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:10 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:10 --> Input Class Initialized
INFO - 2020-02-10 05:50:10 --> Input Class Initialized
INFO - 2020-02-10 05:50:10 --> Input Class Initialized
INFO - 2020-02-10 05:50:10 --> Input Class Initialized
DEBUG - 2020-02-10 05:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:10 --> Input Class Initialized
INFO - 2020-02-10 05:50:10 --> Input Class Initialized
INFO - 2020-02-10 05:50:10 --> Language Class Initialized
INFO - 2020-02-10 05:50:10 --> Language Class Initialized
INFO - 2020-02-10 05:50:10 --> Language Class Initialized
INFO - 2020-02-10 05:50:10 --> Language Class Initialized
INFO - 2020-02-10 05:50:10 --> Language Class Initialized
INFO - 2020-02-10 05:50:10 --> Language Class Initialized
ERROR - 2020-02-10 05:50:10 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-10 05:50:10 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-10 05:50:10 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-10 05:50:10 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-10 05:50:10 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 05:50:10 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 05:50:10 --> Config Class Initialized
INFO - 2020-02-10 05:50:10 --> Config Class Initialized
INFO - 2020-02-10 05:50:10 --> Config Class Initialized
INFO - 2020-02-10 05:50:10 --> Config Class Initialized
INFO - 2020-02-10 05:50:10 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:10 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:10 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:10 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:50:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:50:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:50:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:50:10 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:10 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:10 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:10 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:10 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:10 --> URI Class Initialized
INFO - 2020-02-10 05:50:10 --> URI Class Initialized
INFO - 2020-02-10 05:50:10 --> URI Class Initialized
INFO - 2020-02-10 05:50:10 --> URI Class Initialized
INFO - 2020-02-10 05:50:10 --> Config Class Initialized
INFO - 2020-02-10 05:50:10 --> Config Class Initialized
INFO - 2020-02-10 05:50:10 --> Router Class Initialized
INFO - 2020-02-10 05:50:10 --> Router Class Initialized
INFO - 2020-02-10 05:50:10 --> Router Class Initialized
INFO - 2020-02-10 05:50:10 --> Router Class Initialized
INFO - 2020-02-10 05:50:10 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:10 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:10 --> Output Class Initialized
INFO - 2020-02-10 05:50:10 --> Output Class Initialized
INFO - 2020-02-10 05:50:10 --> Output Class Initialized
INFO - 2020-02-10 05:50:10 --> Output Class Initialized
INFO - 2020-02-10 05:50:10 --> Security Class Initialized
INFO - 2020-02-10 05:50:10 --> Security Class Initialized
INFO - 2020-02-10 05:50:10 --> Security Class Initialized
INFO - 2020-02-10 05:50:10 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:50:10 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:10 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:10 --> Utf8 Class Initialized
DEBUG - 2020-02-10 05:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:10 --> Input Class Initialized
INFO - 2020-02-10 05:50:10 --> Input Class Initialized
INFO - 2020-02-10 05:50:10 --> Input Class Initialized
INFO - 2020-02-10 05:50:10 --> Input Class Initialized
INFO - 2020-02-10 05:50:10 --> URI Class Initialized
INFO - 2020-02-10 05:50:10 --> URI Class Initialized
INFO - 2020-02-10 05:50:10 --> Language Class Initialized
INFO - 2020-02-10 05:50:10 --> Language Class Initialized
INFO - 2020-02-10 05:50:10 --> Language Class Initialized
INFO - 2020-02-10 05:50:10 --> Router Class Initialized
INFO - 2020-02-10 05:50:10 --> Language Class Initialized
INFO - 2020-02-10 05:50:10 --> Router Class Initialized
ERROR - 2020-02-10 05:50:10 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-10 05:50:10 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 05:50:10 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 05:50:10 --> Output Class Initialized
ERROR - 2020-02-10 05:50:10 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 05:50:10 --> Output Class Initialized
INFO - 2020-02-10 05:50:10 --> Security Class Initialized
INFO - 2020-02-10 05:50:10 --> Security Class Initialized
INFO - 2020-02-10 05:50:11 --> Config Class Initialized
INFO - 2020-02-10 05:50:11 --> Config Class Initialized
INFO - 2020-02-10 05:50:11 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:11 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:11 --> Input Class Initialized
INFO - 2020-02-10 05:50:11 --> Input Class Initialized
DEBUG - 2020-02-10 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:50:11 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:11 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:11 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:11 --> Language Class Initialized
INFO - 2020-02-10 05:50:11 --> Language Class Initialized
INFO - 2020-02-10 05:50:11 --> URI Class Initialized
INFO - 2020-02-10 05:50:11 --> URI Class Initialized
ERROR - 2020-02-10 05:50:11 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 05:50:11 --> Loader Class Initialized
INFO - 2020-02-10 05:50:11 --> Router Class Initialized
INFO - 2020-02-10 05:50:11 --> Helper loaded: url_helper
INFO - 2020-02-10 05:50:11 --> Router Class Initialized
INFO - 2020-02-10 05:50:11 --> Output Class Initialized
INFO - 2020-02-10 05:50:11 --> Output Class Initialized
INFO - 2020-02-10 05:50:11 --> Database Driver Class Initialized
INFO - 2020-02-10 05:50:11 --> Security Class Initialized
INFO - 2020-02-10 05:50:11 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:50:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 05:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:11 --> Input Class Initialized
INFO - 2020-02-10 05:50:11 --> Input Class Initialized
INFO - 2020-02-10 05:50:11 --> Controller Class Initialized
INFO - 2020-02-10 05:50:11 --> Language Class Initialized
INFO - 2020-02-10 05:50:11 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:50:11 --> Language Class Initialized
INFO - 2020-02-10 05:50:11 --> Model "M_pengunjung" initialized
ERROR - 2020-02-10 05:50:11 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-10 05:50:11 --> Loader Class Initialized
INFO - 2020-02-10 05:50:11 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:50:11 --> Helper loaded: url_helper
INFO - 2020-02-10 05:50:11 --> Config Class Initialized
INFO - 2020-02-10 05:50:11 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:11 --> Helper loaded: form_helper
INFO - 2020-02-10 05:50:11 --> Database Driver Class Initialized
INFO - 2020-02-10 05:50:11 --> Form Validation Class Initialized
DEBUG - 2020-02-10 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:50:11 --> Utf8 Class Initialized
ERROR - 2020-02-10 05:50:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:50:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:50:11 --> URI Class Initialized
INFO - 2020-02-10 05:50:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:50:11 --> Router Class Initialized
INFO - 2020-02-10 05:50:11 --> Final output sent to browser
INFO - 2020-02-10 05:50:11 --> Output Class Initialized
DEBUG - 2020-02-10 05:50:11 --> Total execution time: 0.6219
INFO - 2020-02-10 05:50:11 --> Security Class Initialized
INFO - 2020-02-10 05:50:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 05:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:11 --> Input Class Initialized
INFO - 2020-02-10 05:50:11 --> Controller Class Initialized
INFO - 2020-02-10 05:50:11 --> Language Class Initialized
INFO - 2020-02-10 05:50:11 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:50:11 --> Model "M_pengunjung" initialized
ERROR - 2020-02-10 05:50:11 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-10 05:50:11 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:50:11 --> Helper loaded: form_helper
INFO - 2020-02-10 05:50:11 --> Config Class Initialized
INFO - 2020-02-10 05:50:11 --> Hooks Class Initialized
INFO - 2020-02-10 05:50:11 --> Form Validation Class Initialized
DEBUG - 2020-02-10 05:50:11 --> UTF-8 Support Enabled
ERROR - 2020-02-10 05:50:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 05:50:11 --> Utf8 Class Initialized
ERROR - 2020-02-10 05:50:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:50:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:50:11 --> URI Class Initialized
INFO - 2020-02-10 05:50:11 --> Final output sent to browser
INFO - 2020-02-10 05:50:11 --> Router Class Initialized
DEBUG - 2020-02-10 05:50:11 --> Total execution time: 0.6890
INFO - 2020-02-10 05:50:11 --> Output Class Initialized
INFO - 2020-02-10 05:50:11 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:11 --> Input Class Initialized
INFO - 2020-02-10 05:50:11 --> Language Class Initialized
ERROR - 2020-02-10 05:50:11 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 05:50:11 --> Config Class Initialized
INFO - 2020-02-10 05:50:11 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:50:11 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:11 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:11 --> URI Class Initialized
INFO - 2020-02-10 05:50:11 --> Router Class Initialized
INFO - 2020-02-10 05:50:12 --> Output Class Initialized
INFO - 2020-02-10 05:50:12 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:12 --> Input Class Initialized
INFO - 2020-02-10 05:50:12 --> Language Class Initialized
ERROR - 2020-02-10 05:50:12 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 05:50:12 --> Config Class Initialized
INFO - 2020-02-10 05:50:12 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:50:12 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:12 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:12 --> URI Class Initialized
INFO - 2020-02-10 05:50:12 --> Router Class Initialized
INFO - 2020-02-10 05:50:12 --> Output Class Initialized
INFO - 2020-02-10 05:50:12 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:12 --> Input Class Initialized
INFO - 2020-02-10 05:50:12 --> Language Class Initialized
ERROR - 2020-02-10 05:50:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 05:50:12 --> Config Class Initialized
INFO - 2020-02-10 05:50:12 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:50:12 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:12 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:12 --> URI Class Initialized
INFO - 2020-02-10 05:50:12 --> Router Class Initialized
INFO - 2020-02-10 05:50:12 --> Output Class Initialized
INFO - 2020-02-10 05:50:12 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:12 --> Input Class Initialized
INFO - 2020-02-10 05:50:12 --> Language Class Initialized
ERROR - 2020-02-10 05:50:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 05:50:12 --> Config Class Initialized
INFO - 2020-02-10 05:50:12 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:50:12 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:12 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:12 --> URI Class Initialized
INFO - 2020-02-10 05:50:12 --> Router Class Initialized
INFO - 2020-02-10 05:50:12 --> Output Class Initialized
INFO - 2020-02-10 05:50:12 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:12 --> Input Class Initialized
INFO - 2020-02-10 05:50:12 --> Language Class Initialized
ERROR - 2020-02-10 05:50:12 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 05:50:13 --> Config Class Initialized
INFO - 2020-02-10 05:50:13 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:50:13 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:13 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:13 --> URI Class Initialized
INFO - 2020-02-10 05:50:13 --> Router Class Initialized
INFO - 2020-02-10 05:50:13 --> Output Class Initialized
INFO - 2020-02-10 05:50:13 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:13 --> Input Class Initialized
INFO - 2020-02-10 05:50:13 --> Language Class Initialized
ERROR - 2020-02-10 05:50:13 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 05:50:13 --> Config Class Initialized
INFO - 2020-02-10 05:50:13 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:50:13 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:13 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:13 --> URI Class Initialized
INFO - 2020-02-10 05:50:13 --> Router Class Initialized
INFO - 2020-02-10 05:50:13 --> Output Class Initialized
INFO - 2020-02-10 05:50:13 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:13 --> Input Class Initialized
INFO - 2020-02-10 05:50:13 --> Language Class Initialized
ERROR - 2020-02-10 05:50:13 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 05:50:13 --> Config Class Initialized
INFO - 2020-02-10 05:50:13 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:50:13 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:50:13 --> Utf8 Class Initialized
INFO - 2020-02-10 05:50:13 --> URI Class Initialized
INFO - 2020-02-10 05:50:13 --> Router Class Initialized
INFO - 2020-02-10 05:50:13 --> Output Class Initialized
INFO - 2020-02-10 05:50:13 --> Security Class Initialized
DEBUG - 2020-02-10 05:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:50:13 --> Input Class Initialized
INFO - 2020-02-10 05:50:13 --> Language Class Initialized
ERROR - 2020-02-10 05:50:13 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 05:51:12 --> Config Class Initialized
INFO - 2020-02-10 05:51:12 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:51:12 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:51:12 --> Utf8 Class Initialized
INFO - 2020-02-10 05:51:12 --> URI Class Initialized
INFO - 2020-02-10 05:51:12 --> Router Class Initialized
INFO - 2020-02-10 05:51:12 --> Output Class Initialized
INFO - 2020-02-10 05:51:12 --> Security Class Initialized
DEBUG - 2020-02-10 05:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:51:13 --> Input Class Initialized
INFO - 2020-02-10 05:51:13 --> Language Class Initialized
INFO - 2020-02-10 05:51:13 --> Loader Class Initialized
INFO - 2020-02-10 05:51:13 --> Helper loaded: url_helper
INFO - 2020-02-10 05:51:13 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:51:13 --> Controller Class Initialized
INFO - 2020-02-10 05:51:13 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:51:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:51:13 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:51:13 --> Helper loaded: form_helper
INFO - 2020-02-10 05:51:13 --> Form Validation Class Initialized
INFO - 2020-02-10 05:51:47 --> Config Class Initialized
INFO - 2020-02-10 05:51:47 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:51:47 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:51:47 --> Utf8 Class Initialized
INFO - 2020-02-10 05:51:47 --> URI Class Initialized
INFO - 2020-02-10 05:51:47 --> Router Class Initialized
INFO - 2020-02-10 05:51:47 --> Output Class Initialized
INFO - 2020-02-10 05:51:47 --> Security Class Initialized
DEBUG - 2020-02-10 05:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:51:48 --> Input Class Initialized
INFO - 2020-02-10 05:51:48 --> Language Class Initialized
INFO - 2020-02-10 05:51:48 --> Loader Class Initialized
INFO - 2020-02-10 05:51:48 --> Helper loaded: url_helper
INFO - 2020-02-10 05:51:48 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:51:48 --> Controller Class Initialized
INFO - 2020-02-10 05:51:48 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:51:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:51:48 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:51:48 --> Helper loaded: form_helper
INFO - 2020-02-10 05:51:48 --> Form Validation Class Initialized
INFO - 2020-02-10 05:51:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:51:48 --> Final output sent to browser
DEBUG - 2020-02-10 05:51:48 --> Total execution time: 0.7030
INFO - 2020-02-10 05:51:48 --> Config Class Initialized
INFO - 2020-02-10 05:51:48 --> Config Class Initialized
INFO - 2020-02-10 05:51:48 --> Hooks Class Initialized
INFO - 2020-02-10 05:51:48 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:51:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:51:48 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:51:48 --> Utf8 Class Initialized
INFO - 2020-02-10 05:51:48 --> Utf8 Class Initialized
INFO - 2020-02-10 05:51:48 --> URI Class Initialized
INFO - 2020-02-10 05:51:48 --> URI Class Initialized
INFO - 2020-02-10 05:51:48 --> Router Class Initialized
INFO - 2020-02-10 05:51:48 --> Router Class Initialized
INFO - 2020-02-10 05:51:48 --> Output Class Initialized
INFO - 2020-02-10 05:51:48 --> Output Class Initialized
INFO - 2020-02-10 05:51:48 --> Security Class Initialized
INFO - 2020-02-10 05:51:48 --> Security Class Initialized
DEBUG - 2020-02-10 05:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:51:48 --> Input Class Initialized
INFO - 2020-02-10 05:51:48 --> Input Class Initialized
INFO - 2020-02-10 05:51:48 --> Language Class Initialized
INFO - 2020-02-10 05:51:48 --> Language Class Initialized
INFO - 2020-02-10 05:51:48 --> Loader Class Initialized
INFO - 2020-02-10 05:51:48 --> Loader Class Initialized
INFO - 2020-02-10 05:51:49 --> Helper loaded: url_helper
INFO - 2020-02-10 05:51:49 --> Helper loaded: url_helper
INFO - 2020-02-10 05:51:49 --> Database Driver Class Initialized
INFO - 2020-02-10 05:51:49 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-10 05:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:51:49 --> Controller Class Initialized
INFO - 2020-02-10 05:51:49 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:51:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:51:49 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:51:49 --> Helper loaded: form_helper
INFO - 2020-02-10 05:51:49 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:51:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:51:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:51:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:51:49 --> Final output sent to browser
DEBUG - 2020-02-10 05:51:49 --> Total execution time: 0.7526
INFO - 2020-02-10 05:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:51:49 --> Controller Class Initialized
INFO - 2020-02-10 05:51:49 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:51:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:51:49 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:51:49 --> Helper loaded: form_helper
INFO - 2020-02-10 05:51:49 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:51:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:51:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:51:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:51:49 --> Final output sent to browser
DEBUG - 2020-02-10 05:51:49 --> Total execution time: 1.2612
INFO - 2020-02-10 05:51:55 --> Config Class Initialized
INFO - 2020-02-10 05:51:55 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:51:55 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:51:55 --> Utf8 Class Initialized
INFO - 2020-02-10 05:51:55 --> URI Class Initialized
INFO - 2020-02-10 05:51:55 --> Router Class Initialized
INFO - 2020-02-10 05:51:55 --> Output Class Initialized
INFO - 2020-02-10 05:51:55 --> Security Class Initialized
DEBUG - 2020-02-10 05:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:51:55 --> Input Class Initialized
INFO - 2020-02-10 05:51:55 --> Language Class Initialized
INFO - 2020-02-10 05:51:55 --> Loader Class Initialized
INFO - 2020-02-10 05:51:55 --> Helper loaded: url_helper
INFO - 2020-02-10 05:51:55 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:51:55 --> Controller Class Initialized
INFO - 2020-02-10 05:51:56 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:51:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:51:56 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:51:56 --> Helper loaded: form_helper
INFO - 2020-02-10 05:51:56 --> Form Validation Class Initialized
INFO - 2020-02-10 05:51:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 05:51:56 --> Final output sent to browser
DEBUG - 2020-02-10 05:51:56 --> Total execution time: 1.0980
INFO - 2020-02-10 05:53:44 --> Config Class Initialized
INFO - 2020-02-10 05:53:44 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:53:44 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:53:44 --> Utf8 Class Initialized
INFO - 2020-02-10 05:53:44 --> URI Class Initialized
INFO - 2020-02-10 05:53:44 --> Router Class Initialized
INFO - 2020-02-10 05:53:44 --> Output Class Initialized
INFO - 2020-02-10 05:53:44 --> Security Class Initialized
DEBUG - 2020-02-10 05:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:53:44 --> Input Class Initialized
INFO - 2020-02-10 05:53:44 --> Language Class Initialized
INFO - 2020-02-10 05:53:44 --> Loader Class Initialized
INFO - 2020-02-10 05:53:45 --> Helper loaded: url_helper
INFO - 2020-02-10 05:53:45 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:53:45 --> Controller Class Initialized
INFO - 2020-02-10 05:53:45 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:53:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:53:45 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:53:45 --> Helper loaded: form_helper
INFO - 2020-02-10 05:53:45 --> Form Validation Class Initialized
INFO - 2020-02-10 05:53:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:53:45 --> Final output sent to browser
INFO - 2020-02-10 05:53:45 --> Config Class Initialized
INFO - 2020-02-10 05:53:45 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:53:45 --> Total execution time: 0.6853
INFO - 2020-02-10 05:53:45 --> Config Class Initialized
INFO - 2020-02-10 05:53:45 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:53:45 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:53:45 --> Utf8 Class Initialized
DEBUG - 2020-02-10 05:53:45 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:53:45 --> Utf8 Class Initialized
INFO - 2020-02-10 05:53:45 --> URI Class Initialized
INFO - 2020-02-10 05:53:45 --> URI Class Initialized
INFO - 2020-02-10 05:53:45 --> Router Class Initialized
INFO - 2020-02-10 05:53:45 --> Router Class Initialized
INFO - 2020-02-10 05:53:45 --> Output Class Initialized
INFO - 2020-02-10 05:53:45 --> Security Class Initialized
INFO - 2020-02-10 05:53:45 --> Output Class Initialized
DEBUG - 2020-02-10 05:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:53:45 --> Security Class Initialized
INFO - 2020-02-10 05:53:45 --> Input Class Initialized
DEBUG - 2020-02-10 05:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:53:45 --> Input Class Initialized
INFO - 2020-02-10 05:53:45 --> Language Class Initialized
INFO - 2020-02-10 05:53:45 --> Language Class Initialized
INFO - 2020-02-10 05:53:45 --> Loader Class Initialized
INFO - 2020-02-10 05:53:45 --> Helper loaded: url_helper
INFO - 2020-02-10 05:53:45 --> Loader Class Initialized
INFO - 2020-02-10 05:53:45 --> Helper loaded: url_helper
INFO - 2020-02-10 05:53:45 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:53:45 --> Database Driver Class Initialized
INFO - 2020-02-10 05:53:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 05:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:53:46 --> Controller Class Initialized
INFO - 2020-02-10 05:53:46 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:53:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:53:46 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:53:46 --> Helper loaded: form_helper
INFO - 2020-02-10 05:53:46 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:53:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:53:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:53:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:53:46 --> Final output sent to browser
DEBUG - 2020-02-10 05:53:46 --> Total execution time: 0.8593
INFO - 2020-02-10 05:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:53:46 --> Controller Class Initialized
INFO - 2020-02-10 05:53:46 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:53:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:53:46 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:53:46 --> Helper loaded: form_helper
INFO - 2020-02-10 05:53:46 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:53:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 05:53:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:53:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:53:46 --> Final output sent to browser
DEBUG - 2020-02-10 05:53:46 --> Total execution time: 1.1419
INFO - 2020-02-10 05:53:50 --> Config Class Initialized
INFO - 2020-02-10 05:53:50 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:53:50 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:53:50 --> Utf8 Class Initialized
INFO - 2020-02-10 05:53:50 --> URI Class Initialized
INFO - 2020-02-10 05:53:50 --> Router Class Initialized
INFO - 2020-02-10 05:53:50 --> Output Class Initialized
INFO - 2020-02-10 05:53:50 --> Security Class Initialized
DEBUG - 2020-02-10 05:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:53:50 --> Input Class Initialized
INFO - 2020-02-10 05:53:50 --> Language Class Initialized
INFO - 2020-02-10 05:53:50 --> Loader Class Initialized
INFO - 2020-02-10 05:53:50 --> Helper loaded: url_helper
INFO - 2020-02-10 05:53:50 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:53:50 --> Controller Class Initialized
INFO - 2020-02-10 05:53:50 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:53:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:53:50 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:53:50 --> Helper loaded: form_helper
INFO - 2020-02-10 05:53:50 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:53:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 05:53:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 05:53:51 --> Final output sent to browser
DEBUG - 2020-02-10 05:53:51 --> Total execution time: 1.0742
INFO - 2020-02-10 05:57:32 --> Config Class Initialized
INFO - 2020-02-10 05:57:32 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:57:32 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:32 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:32 --> URI Class Initialized
INFO - 2020-02-10 05:57:32 --> Router Class Initialized
INFO - 2020-02-10 05:57:32 --> Output Class Initialized
INFO - 2020-02-10 05:57:32 --> Security Class Initialized
DEBUG - 2020-02-10 05:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:32 --> Input Class Initialized
INFO - 2020-02-10 05:57:32 --> Language Class Initialized
INFO - 2020-02-10 05:57:32 --> Loader Class Initialized
INFO - 2020-02-10 05:57:32 --> Helper loaded: url_helper
INFO - 2020-02-10 05:57:32 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:57:32 --> Controller Class Initialized
INFO - 2020-02-10 05:57:32 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:57:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:57:32 --> Config Class Initialized
INFO - 2020-02-10 05:57:32 --> Hooks Class Initialized
INFO - 2020-02-10 05:57:32 --> Model "M_pesan" initialized
DEBUG - 2020-02-10 05:57:32 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:32 --> Helper loaded: form_helper
INFO - 2020-02-10 05:57:32 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:32 --> Form Validation Class Initialized
INFO - 2020-02-10 05:57:32 --> URI Class Initialized
INFO - 2020-02-10 05:57:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:57:32 --> Final output sent to browser
DEBUG - 2020-02-10 05:57:32 --> No URI present. Default controller set.
DEBUG - 2020-02-10 05:57:32 --> Total execution time: 0.7279
INFO - 2020-02-10 05:57:32 --> Router Class Initialized
INFO - 2020-02-10 05:57:32 --> Output Class Initialized
INFO - 2020-02-10 05:57:32 --> Security Class Initialized
DEBUG - 2020-02-10 05:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:32 --> Input Class Initialized
INFO - 2020-02-10 05:57:32 --> Language Class Initialized
INFO - 2020-02-10 05:57:33 --> Loader Class Initialized
INFO - 2020-02-10 05:57:33 --> Helper loaded: url_helper
INFO - 2020-02-10 05:57:33 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:57:33 --> Controller Class Initialized
INFO - 2020-02-10 05:57:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-10 05:57:33 --> Pagination Class Initialized
INFO - 2020-02-10 05:57:33 --> Model "M_show" initialized
INFO - 2020-02-10 05:57:33 --> Helper loaded: form_helper
INFO - 2020-02-10 05:57:33 --> Form Validation Class Initialized
INFO - 2020-02-10 05:57:33 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-10 05:57:33 --> Final output sent to browser
DEBUG - 2020-02-10 05:57:33 --> Total execution time: 0.9839
INFO - 2020-02-10 05:57:39 --> Config Class Initialized
INFO - 2020-02-10 05:57:39 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:57:39 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:39 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:39 --> URI Class Initialized
INFO - 2020-02-10 05:57:39 --> Router Class Initialized
INFO - 2020-02-10 05:57:39 --> Output Class Initialized
INFO - 2020-02-10 05:57:39 --> Security Class Initialized
DEBUG - 2020-02-10 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:39 --> Input Class Initialized
INFO - 2020-02-10 05:57:40 --> Language Class Initialized
INFO - 2020-02-10 05:57:40 --> Loader Class Initialized
INFO - 2020-02-10 05:57:40 --> Helper loaded: url_helper
INFO - 2020-02-10 05:57:40 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:57:40 --> Controller Class Initialized
INFO - 2020-02-10 05:57:40 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:57:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:57:40 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:57:40 --> Helper loaded: form_helper
INFO - 2020-02-10 05:57:40 --> Form Validation Class Initialized
INFO - 2020-02-10 05:57:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:57:40 --> Final output sent to browser
DEBUG - 2020-02-10 05:57:40 --> Total execution time: 0.9356
INFO - 2020-02-10 05:57:40 --> Config Class Initialized
INFO - 2020-02-10 05:57:40 --> Config Class Initialized
INFO - 2020-02-10 05:57:40 --> Config Class Initialized
INFO - 2020-02-10 05:57:40 --> Config Class Initialized
INFO - 2020-02-10 05:57:40 --> Config Class Initialized
INFO - 2020-02-10 05:57:40 --> Hooks Class Initialized
INFO - 2020-02-10 05:57:40 --> Hooks Class Initialized
INFO - 2020-02-10 05:57:40 --> Config Class Initialized
INFO - 2020-02-10 05:57:40 --> Hooks Class Initialized
INFO - 2020-02-10 05:57:40 --> Hooks Class Initialized
INFO - 2020-02-10 05:57:40 --> Hooks Class Initialized
INFO - 2020-02-10 05:57:40 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:57:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:57:40 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:40 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:40 --> Utf8 Class Initialized
DEBUG - 2020-02-10 05:57:40 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:40 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:40 --> URI Class Initialized
INFO - 2020-02-10 05:57:40 --> URI Class Initialized
DEBUG - 2020-02-10 05:57:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:57:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:57:40 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:40 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:40 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:40 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:40 --> URI Class Initialized
INFO - 2020-02-10 05:57:40 --> Router Class Initialized
INFO - 2020-02-10 05:57:40 --> Router Class Initialized
INFO - 2020-02-10 05:57:40 --> URI Class Initialized
INFO - 2020-02-10 05:57:40 --> Router Class Initialized
INFO - 2020-02-10 05:57:40 --> Output Class Initialized
INFO - 2020-02-10 05:57:40 --> URI Class Initialized
INFO - 2020-02-10 05:57:40 --> URI Class Initialized
INFO - 2020-02-10 05:57:40 --> Output Class Initialized
INFO - 2020-02-10 05:57:40 --> Router Class Initialized
INFO - 2020-02-10 05:57:40 --> Router Class Initialized
INFO - 2020-02-10 05:57:40 --> Output Class Initialized
INFO - 2020-02-10 05:57:40 --> Router Class Initialized
INFO - 2020-02-10 05:57:40 --> Security Class Initialized
INFO - 2020-02-10 05:57:40 --> Security Class Initialized
DEBUG - 2020-02-10 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:40 --> Security Class Initialized
DEBUG - 2020-02-10 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:40 --> Output Class Initialized
INFO - 2020-02-10 05:57:40 --> Output Class Initialized
INFO - 2020-02-10 05:57:40 --> Output Class Initialized
INFO - 2020-02-10 05:57:40 --> Input Class Initialized
DEBUG - 2020-02-10 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:40 --> Security Class Initialized
INFO - 2020-02-10 05:57:40 --> Security Class Initialized
INFO - 2020-02-10 05:57:40 --> Input Class Initialized
INFO - 2020-02-10 05:57:40 --> Security Class Initialized
INFO - 2020-02-10 05:57:40 --> Input Class Initialized
INFO - 2020-02-10 05:57:40 --> Language Class Initialized
INFO - 2020-02-10 05:57:40 --> Language Class Initialized
DEBUG - 2020-02-10 05:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:40 --> Input Class Initialized
INFO - 2020-02-10 05:57:40 --> Language Class Initialized
INFO - 2020-02-10 05:57:40 --> Input Class Initialized
INFO - 2020-02-10 05:57:40 --> Input Class Initialized
ERROR - 2020-02-10 05:57:40 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-10 05:57:40 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-10 05:57:40 --> Language Class Initialized
INFO - 2020-02-10 05:57:40 --> Language Class Initialized
INFO - 2020-02-10 05:57:40 --> Language Class Initialized
ERROR - 2020-02-10 05:57:40 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 05:57:41 --> Config Class Initialized
INFO - 2020-02-10 05:57:41 --> Config Class Initialized
INFO - 2020-02-10 05:57:41 --> Hooks Class Initialized
INFO - 2020-02-10 05:57:41 --> Hooks Class Initialized
ERROR - 2020-02-10 05:57:41 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-10 05:57:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-10 05:57:41 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-10 05:57:41 --> Config Class Initialized
INFO - 2020-02-10 05:57:41 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:57:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:57:41 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:41 --> Config Class Initialized
INFO - 2020-02-10 05:57:41 --> Config Class Initialized
INFO - 2020-02-10 05:57:41 --> Config Class Initialized
INFO - 2020-02-10 05:57:41 --> Hooks Class Initialized
INFO - 2020-02-10 05:57:41 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:41 --> Hooks Class Initialized
INFO - 2020-02-10 05:57:41 --> Hooks Class Initialized
INFO - 2020-02-10 05:57:41 --> Utf8 Class Initialized
DEBUG - 2020-02-10 05:57:41 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:41 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:41 --> URI Class Initialized
DEBUG - 2020-02-10 05:57:41 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:41 --> URI Class Initialized
DEBUG - 2020-02-10 05:57:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 05:57:41 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:41 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:41 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:41 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:41 --> URI Class Initialized
INFO - 2020-02-10 05:57:41 --> Router Class Initialized
INFO - 2020-02-10 05:57:41 --> Router Class Initialized
INFO - 2020-02-10 05:57:41 --> URI Class Initialized
INFO - 2020-02-10 05:57:41 --> URI Class Initialized
INFO - 2020-02-10 05:57:41 --> Output Class Initialized
INFO - 2020-02-10 05:57:41 --> Output Class Initialized
INFO - 2020-02-10 05:57:41 --> URI Class Initialized
INFO - 2020-02-10 05:57:41 --> Router Class Initialized
INFO - 2020-02-10 05:57:41 --> Security Class Initialized
INFO - 2020-02-10 05:57:41 --> Router Class Initialized
INFO - 2020-02-10 05:57:41 --> Router Class Initialized
INFO - 2020-02-10 05:57:41 --> Router Class Initialized
INFO - 2020-02-10 05:57:41 --> Security Class Initialized
INFO - 2020-02-10 05:57:41 --> Output Class Initialized
DEBUG - 2020-02-10 05:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:41 --> Security Class Initialized
INFO - 2020-02-10 05:57:41 --> Output Class Initialized
INFO - 2020-02-10 05:57:41 --> Output Class Initialized
DEBUG - 2020-02-10 05:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:41 --> Output Class Initialized
DEBUG - 2020-02-10 05:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:41 --> Security Class Initialized
INFO - 2020-02-10 05:57:41 --> Security Class Initialized
INFO - 2020-02-10 05:57:41 --> Input Class Initialized
INFO - 2020-02-10 05:57:41 --> Input Class Initialized
INFO - 2020-02-10 05:57:41 --> Security Class Initialized
INFO - 2020-02-10 05:57:41 --> Input Class Initialized
INFO - 2020-02-10 05:57:41 --> Language Class Initialized
INFO - 2020-02-10 05:57:41 --> Language Class Initialized
DEBUG - 2020-02-10 05:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 05:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:41 --> Input Class Initialized
INFO - 2020-02-10 05:57:41 --> Input Class Initialized
INFO - 2020-02-10 05:57:41 --> Input Class Initialized
INFO - 2020-02-10 05:57:41 --> Language Class Initialized
INFO - 2020-02-10 05:57:41 --> Loader Class Initialized
INFO - 2020-02-10 05:57:41 --> Loader Class Initialized
INFO - 2020-02-10 05:57:41 --> Language Class Initialized
INFO - 2020-02-10 05:57:41 --> Language Class Initialized
INFO - 2020-02-10 05:57:41 --> Language Class Initialized
INFO - 2020-02-10 05:57:41 --> Helper loaded: url_helper
INFO - 2020-02-10 05:57:41 --> Helper loaded: url_helper
ERROR - 2020-02-10 05:57:41 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 05:57:41 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-10 05:57:41 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-10 05:57:41 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 05:57:41 --> Database Driver Class Initialized
INFO - 2020-02-10 05:57:41 --> Database Driver Class Initialized
INFO - 2020-02-10 05:57:41 --> Config Class Initialized
INFO - 2020-02-10 05:57:41 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-10 05:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:57:41 --> Config Class Initialized
INFO - 2020-02-10 05:57:41 --> Hooks Class Initialized
INFO - 2020-02-10 05:57:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 05:57:41 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:41 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:41 --> Controller Class Initialized
DEBUG - 2020-02-10 05:57:41 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:41 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:41 --> URI Class Initialized
INFO - 2020-02-10 05:57:41 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:57:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:57:41 --> URI Class Initialized
INFO - 2020-02-10 05:57:41 --> Router Class Initialized
INFO - 2020-02-10 05:57:41 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:57:41 --> Router Class Initialized
INFO - 2020-02-10 05:57:41 --> Output Class Initialized
INFO - 2020-02-10 05:57:41 --> Security Class Initialized
INFO - 2020-02-10 05:57:41 --> Output Class Initialized
INFO - 2020-02-10 05:57:41 --> Helper loaded: form_helper
INFO - 2020-02-10 05:57:41 --> Form Validation Class Initialized
DEBUG - 2020-02-10 05:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:41 --> Security Class Initialized
INFO - 2020-02-10 05:57:41 --> Input Class Initialized
DEBUG - 2020-02-10 05:57:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-10 05:57:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 05:57:41 --> Input Class Initialized
ERROR - 2020-02-10 05:57:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:57:41 --> Language Class Initialized
INFO - 2020-02-10 05:57:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:57:41 --> Language Class Initialized
ERROR - 2020-02-10 05:57:41 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 05:57:41 --> Final output sent to browser
ERROR - 2020-02-10 05:57:41 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-10 05:57:41 --> Total execution time: 0.8169
INFO - 2020-02-10 05:57:41 --> Config Class Initialized
INFO - 2020-02-10 05:57:41 --> Hooks Class Initialized
INFO - 2020-02-10 05:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:57:41 --> Controller Class Initialized
DEBUG - 2020-02-10 05:57:41 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:41 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:41 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:57:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:57:41 --> URI Class Initialized
INFO - 2020-02-10 05:57:42 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:57:42 --> Router Class Initialized
INFO - 2020-02-10 05:57:42 --> Output Class Initialized
INFO - 2020-02-10 05:57:42 --> Helper loaded: form_helper
INFO - 2020-02-10 05:57:42 --> Form Validation Class Initialized
INFO - 2020-02-10 05:57:42 --> Security Class Initialized
DEBUG - 2020-02-10 05:57:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-10 05:57:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 05:57:42 --> Input Class Initialized
ERROR - 2020-02-10 05:57:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 05:57:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 05:57:42 --> Language Class Initialized
INFO - 2020-02-10 05:57:42 --> Final output sent to browser
ERROR - 2020-02-10 05:57:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-10 05:57:42 --> Total execution time: 1.1792
INFO - 2020-02-10 05:57:42 --> Config Class Initialized
INFO - 2020-02-10 05:57:42 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:57:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:42 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:42 --> URI Class Initialized
INFO - 2020-02-10 05:57:42 --> Router Class Initialized
INFO - 2020-02-10 05:57:42 --> Output Class Initialized
INFO - 2020-02-10 05:57:42 --> Security Class Initialized
DEBUG - 2020-02-10 05:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:42 --> Input Class Initialized
INFO - 2020-02-10 05:57:42 --> Language Class Initialized
ERROR - 2020-02-10 05:57:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 05:57:42 --> Config Class Initialized
INFO - 2020-02-10 05:57:42 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:57:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:42 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:42 --> URI Class Initialized
INFO - 2020-02-10 05:57:42 --> Router Class Initialized
INFO - 2020-02-10 05:57:42 --> Output Class Initialized
INFO - 2020-02-10 05:57:42 --> Security Class Initialized
DEBUG - 2020-02-10 05:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:42 --> Input Class Initialized
INFO - 2020-02-10 05:57:42 --> Language Class Initialized
ERROR - 2020-02-10 05:57:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 05:57:43 --> Config Class Initialized
INFO - 2020-02-10 05:57:43 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:57:43 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:43 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:43 --> URI Class Initialized
INFO - 2020-02-10 05:57:43 --> Router Class Initialized
INFO - 2020-02-10 05:57:43 --> Output Class Initialized
INFO - 2020-02-10 05:57:43 --> Security Class Initialized
DEBUG - 2020-02-10 05:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:43 --> Input Class Initialized
INFO - 2020-02-10 05:57:43 --> Language Class Initialized
ERROR - 2020-02-10 05:57:43 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 05:57:43 --> Config Class Initialized
INFO - 2020-02-10 05:57:43 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:57:43 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:43 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:43 --> URI Class Initialized
INFO - 2020-02-10 05:57:43 --> Router Class Initialized
INFO - 2020-02-10 05:57:43 --> Output Class Initialized
INFO - 2020-02-10 05:57:43 --> Security Class Initialized
DEBUG - 2020-02-10 05:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:43 --> Input Class Initialized
INFO - 2020-02-10 05:57:43 --> Language Class Initialized
ERROR - 2020-02-10 05:57:43 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 05:57:43 --> Config Class Initialized
INFO - 2020-02-10 05:57:43 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:57:43 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:43 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:43 --> URI Class Initialized
INFO - 2020-02-10 05:57:43 --> Router Class Initialized
INFO - 2020-02-10 05:57:43 --> Output Class Initialized
INFO - 2020-02-10 05:57:43 --> Security Class Initialized
DEBUG - 2020-02-10 05:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:44 --> Input Class Initialized
INFO - 2020-02-10 05:57:44 --> Language Class Initialized
ERROR - 2020-02-10 05:57:44 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 05:57:44 --> Config Class Initialized
INFO - 2020-02-10 05:57:44 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:57:44 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:57:44 --> Utf8 Class Initialized
INFO - 2020-02-10 05:57:44 --> URI Class Initialized
INFO - 2020-02-10 05:57:44 --> Router Class Initialized
INFO - 2020-02-10 05:57:44 --> Output Class Initialized
INFO - 2020-02-10 05:57:44 --> Security Class Initialized
DEBUG - 2020-02-10 05:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:57:44 --> Input Class Initialized
INFO - 2020-02-10 05:57:44 --> Language Class Initialized
ERROR - 2020-02-10 05:57:44 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 05:58:06 --> Config Class Initialized
INFO - 2020-02-10 05:58:06 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:58:06 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:58:06 --> Utf8 Class Initialized
INFO - 2020-02-10 05:58:06 --> URI Class Initialized
INFO - 2020-02-10 05:58:06 --> Router Class Initialized
INFO - 2020-02-10 05:58:06 --> Output Class Initialized
INFO - 2020-02-10 05:58:06 --> Security Class Initialized
DEBUG - 2020-02-10 05:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:58:06 --> Input Class Initialized
INFO - 2020-02-10 05:58:06 --> Language Class Initialized
INFO - 2020-02-10 05:58:06 --> Loader Class Initialized
INFO - 2020-02-10 05:58:06 --> Helper loaded: url_helper
INFO - 2020-02-10 05:58:06 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:58:06 --> Controller Class Initialized
INFO - 2020-02-10 05:58:06 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:58:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:58:06 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:58:06 --> Helper loaded: form_helper
INFO - 2020-02-10 05:58:06 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:58:07 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 05:59:32 --> Config Class Initialized
INFO - 2020-02-10 05:59:32 --> Hooks Class Initialized
DEBUG - 2020-02-10 05:59:32 --> UTF-8 Support Enabled
INFO - 2020-02-10 05:59:32 --> Utf8 Class Initialized
INFO - 2020-02-10 05:59:32 --> URI Class Initialized
INFO - 2020-02-10 05:59:32 --> Router Class Initialized
INFO - 2020-02-10 05:59:32 --> Output Class Initialized
INFO - 2020-02-10 05:59:32 --> Security Class Initialized
DEBUG - 2020-02-10 05:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 05:59:32 --> Input Class Initialized
INFO - 2020-02-10 05:59:32 --> Language Class Initialized
INFO - 2020-02-10 05:59:32 --> Loader Class Initialized
INFO - 2020-02-10 05:59:32 --> Helper loaded: url_helper
INFO - 2020-02-10 05:59:32 --> Database Driver Class Initialized
DEBUG - 2020-02-10 05:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 05:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 05:59:32 --> Controller Class Initialized
INFO - 2020-02-10 05:59:32 --> Model "M_tiket" initialized
INFO - 2020-02-10 05:59:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 05:59:32 --> Model "M_pesan" initialized
INFO - 2020-02-10 05:59:32 --> Helper loaded: form_helper
INFO - 2020-02-10 05:59:32 --> Form Validation Class Initialized
ERROR - 2020-02-10 05:59:32 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:00:02 --> Config Class Initialized
INFO - 2020-02-10 06:00:02 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:00:02 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:00:02 --> Utf8 Class Initialized
INFO - 2020-02-10 06:00:02 --> URI Class Initialized
INFO - 2020-02-10 06:00:02 --> Router Class Initialized
INFO - 2020-02-10 06:00:02 --> Output Class Initialized
INFO - 2020-02-10 06:00:02 --> Security Class Initialized
DEBUG - 2020-02-10 06:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:00:02 --> Input Class Initialized
INFO - 2020-02-10 06:00:02 --> Language Class Initialized
INFO - 2020-02-10 06:00:02 --> Loader Class Initialized
INFO - 2020-02-10 06:00:02 --> Helper loaded: url_helper
INFO - 2020-02-10 06:00:02 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:00:02 --> Controller Class Initialized
INFO - 2020-02-10 06:00:03 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:00:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:00:03 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:00:03 --> Helper loaded: form_helper
INFO - 2020-02-10 06:00:03 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:00:03 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:00:24 --> Config Class Initialized
INFO - 2020-02-10 06:00:24 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:00:24 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:00:24 --> Utf8 Class Initialized
INFO - 2020-02-10 06:00:24 --> URI Class Initialized
INFO - 2020-02-10 06:00:24 --> Router Class Initialized
INFO - 2020-02-10 06:00:24 --> Output Class Initialized
INFO - 2020-02-10 06:00:24 --> Security Class Initialized
DEBUG - 2020-02-10 06:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:00:24 --> Input Class Initialized
INFO - 2020-02-10 06:00:24 --> Language Class Initialized
INFO - 2020-02-10 06:00:24 --> Loader Class Initialized
INFO - 2020-02-10 06:00:24 --> Helper loaded: url_helper
INFO - 2020-02-10 06:00:25 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:00:25 --> Controller Class Initialized
INFO - 2020-02-10 06:00:25 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:00:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:00:25 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:00:25 --> Helper loaded: form_helper
INFO - 2020-02-10 06:00:25 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:00:25 --> Severity: Notice --> Undefined variable: tiket C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
ERROR - 2020-02-10 06:00:25 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:00:36 --> Config Class Initialized
INFO - 2020-02-10 06:00:36 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:00:36 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:00:36 --> Utf8 Class Initialized
INFO - 2020-02-10 06:00:36 --> URI Class Initialized
INFO - 2020-02-10 06:00:36 --> Router Class Initialized
INFO - 2020-02-10 06:00:36 --> Output Class Initialized
INFO - 2020-02-10 06:00:36 --> Security Class Initialized
DEBUG - 2020-02-10 06:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:00:36 --> Input Class Initialized
INFO - 2020-02-10 06:00:36 --> Language Class Initialized
INFO - 2020-02-10 06:00:36 --> Loader Class Initialized
INFO - 2020-02-10 06:00:36 --> Helper loaded: url_helper
INFO - 2020-02-10 06:00:36 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:00:36 --> Controller Class Initialized
INFO - 2020-02-10 06:00:36 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:00:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:00:37 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:00:37 --> Helper loaded: form_helper
INFO - 2020-02-10 06:00:37 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:00:37 --> Severity: Notice --> Undefined variable: tiket C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
ERROR - 2020-02-10 06:00:37 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 3
INFO - 2020-02-10 06:01:15 --> Config Class Initialized
INFO - 2020-02-10 06:01:15 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:01:15 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:01:15 --> Utf8 Class Initialized
INFO - 2020-02-10 06:01:15 --> URI Class Initialized
INFO - 2020-02-10 06:01:15 --> Router Class Initialized
INFO - 2020-02-10 06:01:15 --> Output Class Initialized
INFO - 2020-02-10 06:01:15 --> Security Class Initialized
DEBUG - 2020-02-10 06:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:01:15 --> Input Class Initialized
INFO - 2020-02-10 06:01:15 --> Language Class Initialized
INFO - 2020-02-10 06:01:15 --> Loader Class Initialized
INFO - 2020-02-10 06:01:15 --> Helper loaded: url_helper
INFO - 2020-02-10 06:01:15 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:01:15 --> Controller Class Initialized
INFO - 2020-02-10 06:01:15 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:01:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:01:15 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:01:15 --> Helper loaded: form_helper
INFO - 2020-02-10 06:01:15 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:01:16 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:02:10 --> Config Class Initialized
INFO - 2020-02-10 06:02:10 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:02:10 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:02:10 --> Utf8 Class Initialized
INFO - 2020-02-10 06:02:10 --> URI Class Initialized
INFO - 2020-02-10 06:02:10 --> Router Class Initialized
INFO - 2020-02-10 06:02:11 --> Output Class Initialized
INFO - 2020-02-10 06:02:11 --> Security Class Initialized
DEBUG - 2020-02-10 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:02:11 --> Input Class Initialized
INFO - 2020-02-10 06:02:11 --> Language Class Initialized
INFO - 2020-02-10 06:02:11 --> Loader Class Initialized
INFO - 2020-02-10 06:02:11 --> Helper loaded: url_helper
INFO - 2020-02-10 06:02:11 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:02:11 --> Controller Class Initialized
INFO - 2020-02-10 06:02:11 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:02:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:02:11 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:02:11 --> Helper loaded: form_helper
INFO - 2020-02-10 06:02:11 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:02:11 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:02:21 --> Config Class Initialized
INFO - 2020-02-10 06:02:21 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:02:21 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:02:21 --> Utf8 Class Initialized
INFO - 2020-02-10 06:02:21 --> URI Class Initialized
INFO - 2020-02-10 06:02:21 --> Router Class Initialized
INFO - 2020-02-10 06:02:21 --> Output Class Initialized
INFO - 2020-02-10 06:02:21 --> Security Class Initialized
DEBUG - 2020-02-10 06:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:02:21 --> Input Class Initialized
INFO - 2020-02-10 06:02:21 --> Language Class Initialized
INFO - 2020-02-10 06:02:21 --> Loader Class Initialized
INFO - 2020-02-10 06:02:21 --> Helper loaded: url_helper
INFO - 2020-02-10 06:02:21 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:02:21 --> Controller Class Initialized
INFO - 2020-02-10 06:02:21 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:02:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:02:21 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:02:21 --> Helper loaded: form_helper
INFO - 2020-02-10 06:02:21 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:02:21 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:03:20 --> Config Class Initialized
INFO - 2020-02-10 06:03:20 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:03:20 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:03:20 --> Utf8 Class Initialized
INFO - 2020-02-10 06:03:20 --> URI Class Initialized
INFO - 2020-02-10 06:03:20 --> Router Class Initialized
INFO - 2020-02-10 06:03:20 --> Output Class Initialized
INFO - 2020-02-10 06:03:20 --> Security Class Initialized
DEBUG - 2020-02-10 06:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:03:20 --> Input Class Initialized
INFO - 2020-02-10 06:03:20 --> Language Class Initialized
INFO - 2020-02-10 06:03:20 --> Loader Class Initialized
INFO - 2020-02-10 06:03:20 --> Helper loaded: url_helper
INFO - 2020-02-10 06:03:20 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:03:20 --> Controller Class Initialized
INFO - 2020-02-10 06:03:20 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:03:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:03:20 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:03:20 --> Helper loaded: form_helper
INFO - 2020-02-10 06:03:20 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:03:20 --> Severity: error --> Exception: Call to a member function result() on array C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 2
INFO - 2020-02-10 06:04:29 --> Config Class Initialized
INFO - 2020-02-10 06:04:29 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:04:29 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:04:29 --> Utf8 Class Initialized
INFO - 2020-02-10 06:04:29 --> URI Class Initialized
INFO - 2020-02-10 06:04:29 --> Router Class Initialized
INFO - 2020-02-10 06:04:29 --> Output Class Initialized
INFO - 2020-02-10 06:04:29 --> Security Class Initialized
DEBUG - 2020-02-10 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:04:29 --> Input Class Initialized
INFO - 2020-02-10 06:04:29 --> Language Class Initialized
INFO - 2020-02-10 06:04:29 --> Loader Class Initialized
INFO - 2020-02-10 06:04:29 --> Helper loaded: url_helper
INFO - 2020-02-10 06:04:29 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:04:29 --> Controller Class Initialized
INFO - 2020-02-10 06:04:29 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:04:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:04:29 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:04:29 --> Helper loaded: form_helper
INFO - 2020-02-10 06:04:29 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:04:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:04:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:04:30 --> Final output sent to browser
DEBUG - 2020-02-10 06:04:30 --> Total execution time: 0.8442
INFO - 2020-02-10 06:06:27 --> Config Class Initialized
INFO - 2020-02-10 06:06:27 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:06:27 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:06:27 --> Utf8 Class Initialized
INFO - 2020-02-10 06:06:27 --> URI Class Initialized
INFO - 2020-02-10 06:06:27 --> Router Class Initialized
INFO - 2020-02-10 06:06:27 --> Output Class Initialized
INFO - 2020-02-10 06:06:27 --> Security Class Initialized
DEBUG - 2020-02-10 06:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:06:27 --> Input Class Initialized
INFO - 2020-02-10 06:06:27 --> Language Class Initialized
INFO - 2020-02-10 06:06:27 --> Loader Class Initialized
INFO - 2020-02-10 06:06:27 --> Helper loaded: url_helper
INFO - 2020-02-10 06:06:27 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:06:27 --> Controller Class Initialized
INFO - 2020-02-10 06:06:27 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:06:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:06:28 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:06:28 --> Helper loaded: form_helper
INFO - 2020-02-10 06:06:28 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:06:28 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
ERROR - 2020-02-10 06:06:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:06:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:06:28 --> Final output sent to browser
DEBUG - 2020-02-10 06:06:28 --> Total execution time: 1.2159
INFO - 2020-02-10 06:07:49 --> Config Class Initialized
INFO - 2020-02-10 06:07:49 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:07:49 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:07:49 --> Utf8 Class Initialized
INFO - 2020-02-10 06:07:49 --> URI Class Initialized
INFO - 2020-02-10 06:07:49 --> Router Class Initialized
INFO - 2020-02-10 06:07:50 --> Output Class Initialized
INFO - 2020-02-10 06:07:50 --> Security Class Initialized
DEBUG - 2020-02-10 06:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:07:50 --> Input Class Initialized
INFO - 2020-02-10 06:07:50 --> Language Class Initialized
INFO - 2020-02-10 06:07:50 --> Loader Class Initialized
INFO - 2020-02-10 06:07:50 --> Helper loaded: url_helper
INFO - 2020-02-10 06:07:50 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:07:50 --> Controller Class Initialized
INFO - 2020-02-10 06:07:51 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:07:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:07:51 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:07:51 --> Helper loaded: form_helper
INFO - 2020-02-10 06:07:51 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:07:51 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
ERROR - 2020-02-10 06:07:51 --> Severity: Notice --> Undefined variable: bank C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:07:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:07:51 --> Final output sent to browser
DEBUG - 2020-02-10 06:07:51 --> Total execution time: 2.0399
INFO - 2020-02-10 06:08:19 --> Config Class Initialized
INFO - 2020-02-10 06:08:19 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:08:19 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:08:19 --> Utf8 Class Initialized
INFO - 2020-02-10 06:08:19 --> URI Class Initialized
INFO - 2020-02-10 06:08:19 --> Router Class Initialized
INFO - 2020-02-10 06:08:19 --> Output Class Initialized
INFO - 2020-02-10 06:08:19 --> Security Class Initialized
DEBUG - 2020-02-10 06:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:08:20 --> Input Class Initialized
INFO - 2020-02-10 06:08:20 --> Language Class Initialized
INFO - 2020-02-10 06:08:20 --> Loader Class Initialized
INFO - 2020-02-10 06:08:20 --> Helper loaded: url_helper
INFO - 2020-02-10 06:08:20 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:08:20 --> Controller Class Initialized
INFO - 2020-02-10 06:08:20 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:08:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:08:20 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:08:20 --> Helper loaded: form_helper
INFO - 2020-02-10 06:08:20 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:08:20 --> Severity: Notice --> Undefined variable: bank C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:08:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:08:20 --> Final output sent to browser
DEBUG - 2020-02-10 06:08:20 --> Total execution time: 0.9798
INFO - 2020-02-10 06:08:46 --> Config Class Initialized
INFO - 2020-02-10 06:08:46 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:08:46 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:08:46 --> Utf8 Class Initialized
INFO - 2020-02-10 06:08:46 --> URI Class Initialized
INFO - 2020-02-10 06:08:46 --> Router Class Initialized
INFO - 2020-02-10 06:08:46 --> Output Class Initialized
INFO - 2020-02-10 06:08:46 --> Security Class Initialized
DEBUG - 2020-02-10 06:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:08:46 --> Input Class Initialized
INFO - 2020-02-10 06:08:46 --> Language Class Initialized
INFO - 2020-02-10 06:08:46 --> Loader Class Initialized
INFO - 2020-02-10 06:08:46 --> Helper loaded: url_helper
INFO - 2020-02-10 06:08:46 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:08:46 --> Controller Class Initialized
INFO - 2020-02-10 06:08:46 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:08:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:08:46 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:08:46 --> Helper loaded: form_helper
INFO - 2020-02-10 06:08:46 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:08:46 --> Severity: Notice --> Undefined variable: bank C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:08:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:08:47 --> Final output sent to browser
DEBUG - 2020-02-10 06:08:47 --> Total execution time: 0.9843
INFO - 2020-02-10 06:09:12 --> Config Class Initialized
INFO - 2020-02-10 06:09:12 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:09:12 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:09:12 --> Utf8 Class Initialized
INFO - 2020-02-10 06:09:12 --> URI Class Initialized
INFO - 2020-02-10 06:09:12 --> Router Class Initialized
INFO - 2020-02-10 06:09:12 --> Output Class Initialized
INFO - 2020-02-10 06:09:12 --> Security Class Initialized
DEBUG - 2020-02-10 06:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:09:12 --> Input Class Initialized
INFO - 2020-02-10 06:09:12 --> Language Class Initialized
INFO - 2020-02-10 06:09:12 --> Loader Class Initialized
INFO - 2020-02-10 06:09:12 --> Helper loaded: url_helper
INFO - 2020-02-10 06:09:12 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:09:12 --> Controller Class Initialized
INFO - 2020-02-10 06:09:12 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:09:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:09:12 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:09:12 --> Helper loaded: form_helper
INFO - 2020-02-10 06:09:12 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:09:13 --> Severity: Notice --> Undefined variable: namabank C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:09:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:09:13 --> Final output sent to browser
DEBUG - 2020-02-10 06:09:13 --> Total execution time: 1.0479
INFO - 2020-02-10 06:10:22 --> Config Class Initialized
INFO - 2020-02-10 06:10:22 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:10:22 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:10:22 --> Utf8 Class Initialized
INFO - 2020-02-10 06:10:22 --> URI Class Initialized
INFO - 2020-02-10 06:10:22 --> Router Class Initialized
INFO - 2020-02-10 06:10:23 --> Output Class Initialized
INFO - 2020-02-10 06:10:23 --> Security Class Initialized
DEBUG - 2020-02-10 06:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:10:23 --> Input Class Initialized
INFO - 2020-02-10 06:10:23 --> Language Class Initialized
INFO - 2020-02-10 06:10:23 --> Loader Class Initialized
INFO - 2020-02-10 06:10:23 --> Helper loaded: url_helper
INFO - 2020-02-10 06:10:23 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:10:23 --> Controller Class Initialized
INFO - 2020-02-10 06:10:23 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:10:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:10:23 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:10:23 --> Helper loaded: form_helper
INFO - 2020-02-10 06:10:23 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:10:23 --> Severity: Notice --> Undefined variable: namabank C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:10:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:10:23 --> Final output sent to browser
DEBUG - 2020-02-10 06:10:23 --> Total execution time: 1.0619
INFO - 2020-02-10 06:14:18 --> Config Class Initialized
INFO - 2020-02-10 06:14:18 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:14:18 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:14:18 --> Utf8 Class Initialized
INFO - 2020-02-10 06:14:18 --> URI Class Initialized
INFO - 2020-02-10 06:14:18 --> Router Class Initialized
INFO - 2020-02-10 06:14:18 --> Output Class Initialized
INFO - 2020-02-10 06:14:18 --> Security Class Initialized
DEBUG - 2020-02-10 06:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:14:18 --> Input Class Initialized
INFO - 2020-02-10 06:14:18 --> Language Class Initialized
INFO - 2020-02-10 06:14:18 --> Loader Class Initialized
INFO - 2020-02-10 06:14:18 --> Helper loaded: url_helper
INFO - 2020-02-10 06:14:18 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:14:18 --> Controller Class Initialized
INFO - 2020-02-10 06:14:18 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:14:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:14:18 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:14:18 --> Helper loaded: form_helper
INFO - 2020-02-10 06:14:18 --> Form Validation Class Initialized
INFO - 2020-02-10 06:14:19 --> Final output sent to browser
DEBUG - 2020-02-10 06:14:19 --> Total execution time: 0.7673
INFO - 2020-02-10 06:22:43 --> Config Class Initialized
INFO - 2020-02-10 06:22:43 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:22:43 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:22:43 --> Utf8 Class Initialized
INFO - 2020-02-10 06:22:43 --> URI Class Initialized
INFO - 2020-02-10 06:22:43 --> Router Class Initialized
INFO - 2020-02-10 06:22:43 --> Output Class Initialized
INFO - 2020-02-10 06:22:43 --> Security Class Initialized
DEBUG - 2020-02-10 06:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:22:43 --> Input Class Initialized
INFO - 2020-02-10 06:22:43 --> Language Class Initialized
INFO - 2020-02-10 06:22:44 --> Loader Class Initialized
INFO - 2020-02-10 06:22:44 --> Helper loaded: url_helper
INFO - 2020-02-10 06:22:44 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:22:44 --> Controller Class Initialized
INFO - 2020-02-10 06:22:44 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:22:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:22:44 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:22:44 --> Helper loaded: form_helper
INFO - 2020-02-10 06:22:44 --> Form Validation Class Initialized
INFO - 2020-02-10 06:22:44 --> Final output sent to browser
DEBUG - 2020-02-10 06:22:44 --> Total execution time: 1.0132
INFO - 2020-02-10 06:22:53 --> Config Class Initialized
INFO - 2020-02-10 06:22:53 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:22:53 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:22:53 --> Utf8 Class Initialized
INFO - 2020-02-10 06:22:53 --> URI Class Initialized
INFO - 2020-02-10 06:22:53 --> Router Class Initialized
INFO - 2020-02-10 06:22:53 --> Output Class Initialized
INFO - 2020-02-10 06:22:53 --> Security Class Initialized
DEBUG - 2020-02-10 06:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:22:53 --> Input Class Initialized
INFO - 2020-02-10 06:22:53 --> Language Class Initialized
INFO - 2020-02-10 06:22:53 --> Loader Class Initialized
INFO - 2020-02-10 06:22:53 --> Helper loaded: url_helper
INFO - 2020-02-10 06:22:53 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:22:53 --> Controller Class Initialized
INFO - 2020-02-10 06:22:53 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:22:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:22:53 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:22:54 --> Helper loaded: form_helper
INFO - 2020-02-10 06:22:54 --> Form Validation Class Initialized
INFO - 2020-02-10 06:22:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 06:22:54 --> Final output sent to browser
DEBUG - 2020-02-10 06:22:54 --> Total execution time: 0.7115
INFO - 2020-02-10 06:22:54 --> Config Class Initialized
INFO - 2020-02-10 06:22:54 --> Config Class Initialized
INFO - 2020-02-10 06:22:54 --> Config Class Initialized
INFO - 2020-02-10 06:22:54 --> Hooks Class Initialized
INFO - 2020-02-10 06:22:54 --> Hooks Class Initialized
INFO - 2020-02-10 06:22:54 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:22:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 06:22:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 06:22:54 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:22:54 --> Utf8 Class Initialized
INFO - 2020-02-10 06:22:54 --> Utf8 Class Initialized
INFO - 2020-02-10 06:22:54 --> Utf8 Class Initialized
INFO - 2020-02-10 06:22:54 --> URI Class Initialized
INFO - 2020-02-10 06:22:54 --> URI Class Initialized
INFO - 2020-02-10 06:22:54 --> URI Class Initialized
INFO - 2020-02-10 06:22:54 --> Router Class Initialized
INFO - 2020-02-10 06:22:54 --> Router Class Initialized
INFO - 2020-02-10 06:22:54 --> Router Class Initialized
INFO - 2020-02-10 06:22:54 --> Output Class Initialized
INFO - 2020-02-10 06:22:54 --> Output Class Initialized
INFO - 2020-02-10 06:22:54 --> Output Class Initialized
INFO - 2020-02-10 06:22:54 --> Security Class Initialized
INFO - 2020-02-10 06:22:54 --> Security Class Initialized
INFO - 2020-02-10 06:22:54 --> Security Class Initialized
DEBUG - 2020-02-10 06:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 06:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 06:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:22:54 --> Input Class Initialized
INFO - 2020-02-10 06:22:54 --> Input Class Initialized
INFO - 2020-02-10 06:22:54 --> Input Class Initialized
INFO - 2020-02-10 06:22:54 --> Language Class Initialized
INFO - 2020-02-10 06:22:54 --> Language Class Initialized
INFO - 2020-02-10 06:22:54 --> Language Class Initialized
ERROR - 2020-02-10 06:22:54 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-10 06:22:54 --> Loader Class Initialized
INFO - 2020-02-10 06:22:54 --> Loader Class Initialized
INFO - 2020-02-10 06:22:54 --> Helper loaded: url_helper
INFO - 2020-02-10 06:22:54 --> Helper loaded: url_helper
INFO - 2020-02-10 06:22:54 --> Database Driver Class Initialized
INFO - 2020-02-10 06:22:54 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-10 06:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:22:54 --> Controller Class Initialized
INFO - 2020-02-10 06:22:54 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:22:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:22:54 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:22:54 --> Helper loaded: form_helper
INFO - 2020-02-10 06:22:54 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:22:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 06:22:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 06:22:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 06:22:54 --> Final output sent to browser
DEBUG - 2020-02-10 06:22:55 --> Total execution time: 0.7678
INFO - 2020-02-10 06:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:22:55 --> Controller Class Initialized
INFO - 2020-02-10 06:22:55 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:22:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:22:55 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:22:55 --> Helper loaded: form_helper
INFO - 2020-02-10 06:22:55 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:22:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 06:22:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 06:22:55 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 06:22:55 --> Final output sent to browser
DEBUG - 2020-02-10 06:22:55 --> Total execution time: 1.0643
INFO - 2020-02-10 06:22:58 --> Config Class Initialized
INFO - 2020-02-10 06:22:58 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:22:58 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:22:58 --> Utf8 Class Initialized
INFO - 2020-02-10 06:22:58 --> URI Class Initialized
INFO - 2020-02-10 06:22:58 --> Router Class Initialized
INFO - 2020-02-10 06:22:58 --> Output Class Initialized
INFO - 2020-02-10 06:22:58 --> Security Class Initialized
DEBUG - 2020-02-10 06:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:22:59 --> Input Class Initialized
INFO - 2020-02-10 06:22:59 --> Language Class Initialized
INFO - 2020-02-10 06:22:59 --> Loader Class Initialized
INFO - 2020-02-10 06:22:59 --> Helper loaded: url_helper
INFO - 2020-02-10 06:22:59 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:22:59 --> Controller Class Initialized
INFO - 2020-02-10 06:22:59 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:22:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:22:59 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:22:59 --> Helper loaded: form_helper
INFO - 2020-02-10 06:22:59 --> Form Validation Class Initialized
INFO - 2020-02-10 06:22:59 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 06:22:59 --> Final output sent to browser
INFO - 2020-02-10 06:22:59 --> Config Class Initialized
INFO - 2020-02-10 06:22:59 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:22:59 --> Total execution time: 0.8940
INFO - 2020-02-10 06:22:59 --> Config Class Initialized
INFO - 2020-02-10 06:22:59 --> Config Class Initialized
INFO - 2020-02-10 06:22:59 --> Config Class Initialized
INFO - 2020-02-10 06:22:59 --> Config Class Initialized
INFO - 2020-02-10 06:22:59 --> Hooks Class Initialized
INFO - 2020-02-10 06:22:59 --> Hooks Class Initialized
INFO - 2020-02-10 06:22:59 --> Hooks Class Initialized
INFO - 2020-02-10 06:22:59 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:22:59 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:22:59 --> Config Class Initialized
INFO - 2020-02-10 06:22:59 --> Hooks Class Initialized
INFO - 2020-02-10 06:22:59 --> Utf8 Class Initialized
DEBUG - 2020-02-10 06:22:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 06:22:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 06:22:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 06:22:59 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:22:59 --> Utf8 Class Initialized
INFO - 2020-02-10 06:22:59 --> Utf8 Class Initialized
INFO - 2020-02-10 06:22:59 --> Utf8 Class Initialized
INFO - 2020-02-10 06:22:59 --> URI Class Initialized
INFO - 2020-02-10 06:22:59 --> Utf8 Class Initialized
DEBUG - 2020-02-10 06:22:59 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:22:59 --> Utf8 Class Initialized
INFO - 2020-02-10 06:22:59 --> URI Class Initialized
INFO - 2020-02-10 06:22:59 --> URI Class Initialized
INFO - 2020-02-10 06:22:59 --> URI Class Initialized
INFO - 2020-02-10 06:22:59 --> Router Class Initialized
INFO - 2020-02-10 06:22:59 --> URI Class Initialized
INFO - 2020-02-10 06:22:59 --> URI Class Initialized
INFO - 2020-02-10 06:22:59 --> Router Class Initialized
INFO - 2020-02-10 06:22:59 --> Router Class Initialized
INFO - 2020-02-10 06:22:59 --> Output Class Initialized
INFO - 2020-02-10 06:22:59 --> Router Class Initialized
INFO - 2020-02-10 06:22:59 --> Router Class Initialized
INFO - 2020-02-10 06:22:59 --> Security Class Initialized
INFO - 2020-02-10 06:22:59 --> Router Class Initialized
INFO - 2020-02-10 06:22:59 --> Output Class Initialized
INFO - 2020-02-10 06:22:59 --> Output Class Initialized
INFO - 2020-02-10 06:22:59 --> Output Class Initialized
INFO - 2020-02-10 06:22:59 --> Output Class Initialized
DEBUG - 2020-02-10 06:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:22:59 --> Security Class Initialized
INFO - 2020-02-10 06:22:59 --> Output Class Initialized
INFO - 2020-02-10 06:22:59 --> Security Class Initialized
INFO - 2020-02-10 06:22:59 --> Security Class Initialized
INFO - 2020-02-10 06:22:59 --> Security Class Initialized
INFO - 2020-02-10 06:22:59 --> Input Class Initialized
DEBUG - 2020-02-10 06:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:22:59 --> Security Class Initialized
DEBUG - 2020-02-10 06:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 06:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 06:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:22:59 --> Input Class Initialized
INFO - 2020-02-10 06:22:59 --> Input Class Initialized
INFO - 2020-02-10 06:22:59 --> Input Class Initialized
INFO - 2020-02-10 06:22:59 --> Input Class Initialized
INFO - 2020-02-10 06:22:59 --> Language Class Initialized
DEBUG - 2020-02-10 06:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:22:59 --> Input Class Initialized
INFO - 2020-02-10 06:22:59 --> Language Class Initialized
INFO - 2020-02-10 06:22:59 --> Language Class Initialized
ERROR - 2020-02-10 06:22:59 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-10 06:22:59 --> Language Class Initialized
INFO - 2020-02-10 06:22:59 --> Language Class Initialized
INFO - 2020-02-10 06:22:59 --> Language Class Initialized
ERROR - 2020-02-10 06:22:59 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-10 06:22:59 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-10 06:22:59 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-10 06:22:59 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 06:22:59 --> Config Class Initialized
INFO - 2020-02-10 06:22:59 --> Hooks Class Initialized
ERROR - 2020-02-10 06:22:59 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 06:22:59 --> Config Class Initialized
INFO - 2020-02-10 06:22:59 --> Config Class Initialized
INFO - 2020-02-10 06:22:59 --> Config Class Initialized
INFO - 2020-02-10 06:22:59 --> Config Class Initialized
INFO - 2020-02-10 06:22:59 --> Hooks Class Initialized
INFO - 2020-02-10 06:22:59 --> Hooks Class Initialized
INFO - 2020-02-10 06:22:59 --> Hooks Class Initialized
INFO - 2020-02-10 06:22:59 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:22:59 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:22:59 --> Config Class Initialized
INFO - 2020-02-10 06:22:59 --> Utf8 Class Initialized
DEBUG - 2020-02-10 06:22:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 06:22:59 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:22:59 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:22:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 06:23:00 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:23:00 --> Utf8 Class Initialized
INFO - 2020-02-10 06:23:00 --> Utf8 Class Initialized
INFO - 2020-02-10 06:23:00 --> Utf8 Class Initialized
INFO - 2020-02-10 06:23:00 --> Utf8 Class Initialized
INFO - 2020-02-10 06:23:00 --> URI Class Initialized
DEBUG - 2020-02-10 06:23:00 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:23:00 --> Utf8 Class Initialized
INFO - 2020-02-10 06:23:00 --> URI Class Initialized
INFO - 2020-02-10 06:23:00 --> URI Class Initialized
INFO - 2020-02-10 06:23:00 --> Router Class Initialized
INFO - 2020-02-10 06:23:00 --> URI Class Initialized
INFO - 2020-02-10 06:23:00 --> URI Class Initialized
INFO - 2020-02-10 06:23:00 --> Router Class Initialized
INFO - 2020-02-10 06:23:00 --> Router Class Initialized
INFO - 2020-02-10 06:23:00 --> URI Class Initialized
INFO - 2020-02-10 06:23:00 --> Router Class Initialized
INFO - 2020-02-10 06:23:00 --> Router Class Initialized
INFO - 2020-02-10 06:23:00 --> Output Class Initialized
INFO - 2020-02-10 06:23:00 --> Security Class Initialized
INFO - 2020-02-10 06:23:00 --> Output Class Initialized
INFO - 2020-02-10 06:23:00 --> Router Class Initialized
INFO - 2020-02-10 06:23:00 --> Output Class Initialized
INFO - 2020-02-10 06:23:00 --> Output Class Initialized
INFO - 2020-02-10 06:23:00 --> Output Class Initialized
INFO - 2020-02-10 06:23:00 --> Security Class Initialized
INFO - 2020-02-10 06:23:00 --> Security Class Initialized
DEBUG - 2020-02-10 06:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:00 --> Security Class Initialized
INFO - 2020-02-10 06:23:00 --> Security Class Initialized
INFO - 2020-02-10 06:23:00 --> Output Class Initialized
INFO - 2020-02-10 06:23:00 --> Input Class Initialized
DEBUG - 2020-02-10 06:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 06:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 06:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 06:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:00 --> Security Class Initialized
INFO - 2020-02-10 06:23:00 --> Input Class Initialized
INFO - 2020-02-10 06:23:00 --> Input Class Initialized
INFO - 2020-02-10 06:23:00 --> Input Class Initialized
INFO - 2020-02-10 06:23:00 --> Input Class Initialized
DEBUG - 2020-02-10 06:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:00 --> Language Class Initialized
INFO - 2020-02-10 06:23:00 --> Input Class Initialized
INFO - 2020-02-10 06:23:00 --> Language Class Initialized
INFO - 2020-02-10 06:23:00 --> Language Class Initialized
ERROR - 2020-02-10 06:23:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 06:23:00 --> Language Class Initialized
INFO - 2020-02-10 06:23:00 --> Language Class Initialized
ERROR - 2020-02-10 06:23:00 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-10 06:23:00 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-10 06:23:00 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-10 06:23:00 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 06:23:00 --> Language Class Initialized
INFO - 2020-02-10 06:23:00 --> Config Class Initialized
INFO - 2020-02-10 06:23:00 --> Hooks Class Initialized
INFO - 2020-02-10 06:23:00 --> Loader Class Initialized
INFO - 2020-02-10 06:23:00 --> Config Class Initialized
INFO - 2020-02-10 06:23:00 --> Hooks Class Initialized
INFO - 2020-02-10 06:23:00 --> Helper loaded: url_helper
DEBUG - 2020-02-10 06:23:00 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:23:00 --> Utf8 Class Initialized
DEBUG - 2020-02-10 06:23:00 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:23:00 --> Database Driver Class Initialized
INFO - 2020-02-10 06:23:00 --> Utf8 Class Initialized
INFO - 2020-02-10 06:23:00 --> URI Class Initialized
DEBUG - 2020-02-10 06:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:23:00 --> URI Class Initialized
INFO - 2020-02-10 06:23:00 --> Router Class Initialized
INFO - 2020-02-10 06:23:00 --> Controller Class Initialized
INFO - 2020-02-10 06:23:00 --> Output Class Initialized
INFO - 2020-02-10 06:23:00 --> Router Class Initialized
INFO - 2020-02-10 06:23:00 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:23:00 --> Security Class Initialized
INFO - 2020-02-10 06:23:00 --> Output Class Initialized
INFO - 2020-02-10 06:23:00 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-10 06:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:00 --> Security Class Initialized
INFO - 2020-02-10 06:23:00 --> Input Class Initialized
INFO - 2020-02-10 06:23:00 --> Model "M_pesan" initialized
DEBUG - 2020-02-10 06:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:00 --> Input Class Initialized
INFO - 2020-02-10 06:23:00 --> Language Class Initialized
INFO - 2020-02-10 06:23:00 --> Helper loaded: form_helper
INFO - 2020-02-10 06:23:00 --> Form Validation Class Initialized
INFO - 2020-02-10 06:23:00 --> Language Class Initialized
INFO - 2020-02-10 06:23:00 --> Loader Class Initialized
ERROR - 2020-02-10 06:23:00 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-10 06:23:00 --> Helper loaded: url_helper
ERROR - 2020-02-10 06:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 06:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 06:23:00 --> Database Driver Class Initialized
INFO - 2020-02-10 06:23:00 --> Config Class Initialized
INFO - 2020-02-10 06:23:00 --> Hooks Class Initialized
INFO - 2020-02-10 06:23:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-10 06:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:23:00 --> Final output sent to browser
DEBUG - 2020-02-10 06:23:00 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:23:00 --> Utf8 Class Initialized
DEBUG - 2020-02-10 06:23:00 --> Total execution time: 0.7417
INFO - 2020-02-10 06:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:23:00 --> URI Class Initialized
INFO - 2020-02-10 06:23:00 --> Controller Class Initialized
INFO - 2020-02-10 06:23:00 --> Router Class Initialized
INFO - 2020-02-10 06:23:00 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:23:00 --> Output Class Initialized
INFO - 2020-02-10 06:23:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:23:00 --> Security Class Initialized
INFO - 2020-02-10 06:23:00 --> Model "M_pesan" initialized
DEBUG - 2020-02-10 06:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:00 --> Input Class Initialized
INFO - 2020-02-10 06:23:00 --> Helper loaded: form_helper
INFO - 2020-02-10 06:23:00 --> Form Validation Class Initialized
INFO - 2020-02-10 06:23:00 --> Language Class Initialized
ERROR - 2020-02-10 06:23:00 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-10 06:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 06:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 06:23:00 --> Config Class Initialized
INFO - 2020-02-10 06:23:00 --> Hooks Class Initialized
INFO - 2020-02-10 06:23:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 06:23:01 --> Final output sent to browser
DEBUG - 2020-02-10 06:23:01 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:23:01 --> Utf8 Class Initialized
DEBUG - 2020-02-10 06:23:01 --> Total execution time: 0.7020
INFO - 2020-02-10 06:23:01 --> URI Class Initialized
INFO - 2020-02-10 06:23:01 --> Router Class Initialized
INFO - 2020-02-10 06:23:01 --> Output Class Initialized
INFO - 2020-02-10 06:23:01 --> Security Class Initialized
DEBUG - 2020-02-10 06:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:01 --> Input Class Initialized
INFO - 2020-02-10 06:23:01 --> Language Class Initialized
ERROR - 2020-02-10 06:23:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 06:23:01 --> Config Class Initialized
INFO - 2020-02-10 06:23:01 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:23:01 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:23:01 --> Utf8 Class Initialized
INFO - 2020-02-10 06:23:01 --> URI Class Initialized
INFO - 2020-02-10 06:23:01 --> Router Class Initialized
INFO - 2020-02-10 06:23:01 --> Output Class Initialized
INFO - 2020-02-10 06:23:01 --> Security Class Initialized
DEBUG - 2020-02-10 06:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:01 --> Input Class Initialized
INFO - 2020-02-10 06:23:01 --> Language Class Initialized
ERROR - 2020-02-10 06:23:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 06:23:01 --> Config Class Initialized
INFO - 2020-02-10 06:23:01 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:23:01 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:23:01 --> Utf8 Class Initialized
INFO - 2020-02-10 06:23:01 --> URI Class Initialized
INFO - 2020-02-10 06:23:01 --> Router Class Initialized
INFO - 2020-02-10 06:23:01 --> Output Class Initialized
INFO - 2020-02-10 06:23:01 --> Security Class Initialized
DEBUG - 2020-02-10 06:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:01 --> Input Class Initialized
INFO - 2020-02-10 06:23:01 --> Language Class Initialized
ERROR - 2020-02-10 06:23:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 06:23:01 --> Config Class Initialized
INFO - 2020-02-10 06:23:01 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:23:02 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:23:02 --> Utf8 Class Initialized
INFO - 2020-02-10 06:23:02 --> URI Class Initialized
INFO - 2020-02-10 06:23:02 --> Router Class Initialized
INFO - 2020-02-10 06:23:02 --> Output Class Initialized
INFO - 2020-02-10 06:23:02 --> Security Class Initialized
DEBUG - 2020-02-10 06:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:02 --> Input Class Initialized
INFO - 2020-02-10 06:23:02 --> Language Class Initialized
ERROR - 2020-02-10 06:23:02 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 06:23:02 --> Config Class Initialized
INFO - 2020-02-10 06:23:02 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:23:02 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:23:02 --> Utf8 Class Initialized
INFO - 2020-02-10 06:23:02 --> URI Class Initialized
INFO - 2020-02-10 06:23:02 --> Router Class Initialized
INFO - 2020-02-10 06:23:02 --> Output Class Initialized
INFO - 2020-02-10 06:23:02 --> Security Class Initialized
DEBUG - 2020-02-10 06:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:02 --> Input Class Initialized
INFO - 2020-02-10 06:23:02 --> Language Class Initialized
ERROR - 2020-02-10 06:23:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 06:23:02 --> Config Class Initialized
INFO - 2020-02-10 06:23:02 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:23:02 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:23:02 --> Utf8 Class Initialized
INFO - 2020-02-10 06:23:02 --> URI Class Initialized
INFO - 2020-02-10 06:23:02 --> Router Class Initialized
INFO - 2020-02-10 06:23:02 --> Output Class Initialized
INFO - 2020-02-10 06:23:02 --> Security Class Initialized
DEBUG - 2020-02-10 06:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:02 --> Input Class Initialized
INFO - 2020-02-10 06:23:02 --> Language Class Initialized
ERROR - 2020-02-10 06:23:02 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 06:23:02 --> Config Class Initialized
INFO - 2020-02-10 06:23:02 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:23:02 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:23:03 --> Utf8 Class Initialized
INFO - 2020-02-10 06:23:03 --> URI Class Initialized
INFO - 2020-02-10 06:23:03 --> Router Class Initialized
INFO - 2020-02-10 06:23:03 --> Output Class Initialized
INFO - 2020-02-10 06:23:03 --> Security Class Initialized
DEBUG - 2020-02-10 06:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:03 --> Input Class Initialized
INFO - 2020-02-10 06:23:03 --> Language Class Initialized
ERROR - 2020-02-10 06:23:03 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 06:23:35 --> Config Class Initialized
INFO - 2020-02-10 06:23:35 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:23:35 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:23:35 --> Utf8 Class Initialized
INFO - 2020-02-10 06:23:35 --> URI Class Initialized
INFO - 2020-02-10 06:23:35 --> Router Class Initialized
INFO - 2020-02-10 06:23:35 --> Output Class Initialized
INFO - 2020-02-10 06:23:35 --> Security Class Initialized
DEBUG - 2020-02-10 06:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:23:35 --> Input Class Initialized
INFO - 2020-02-10 06:23:35 --> Language Class Initialized
INFO - 2020-02-10 06:23:35 --> Loader Class Initialized
INFO - 2020-02-10 06:23:35 --> Helper loaded: url_helper
INFO - 2020-02-10 06:23:35 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:23:35 --> Controller Class Initialized
INFO - 2020-02-10 06:23:35 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:23:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:23:35 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:23:35 --> Helper loaded: form_helper
INFO - 2020-02-10 06:23:35 --> Form Validation Class Initialized
INFO - 2020-02-10 06:23:35 --> Final output sent to browser
DEBUG - 2020-02-10 06:23:36 --> Total execution time: 0.7933
INFO - 2020-02-10 06:26:08 --> Config Class Initialized
INFO - 2020-02-10 06:26:08 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:26:08 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:26:08 --> Utf8 Class Initialized
INFO - 2020-02-10 06:26:08 --> URI Class Initialized
INFO - 2020-02-10 06:26:08 --> Router Class Initialized
INFO - 2020-02-10 06:26:08 --> Output Class Initialized
INFO - 2020-02-10 06:26:08 --> Security Class Initialized
DEBUG - 2020-02-10 06:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:26:08 --> Input Class Initialized
INFO - 2020-02-10 06:26:08 --> Language Class Initialized
INFO - 2020-02-10 06:26:08 --> Loader Class Initialized
INFO - 2020-02-10 06:26:08 --> Helper loaded: url_helper
INFO - 2020-02-10 06:26:08 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:26:09 --> Controller Class Initialized
INFO - 2020-02-10 06:26:09 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:26:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:26:09 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:26:09 --> Helper loaded: form_helper
INFO - 2020-02-10 06:26:09 --> Form Validation Class Initialized
INFO - 2020-02-10 06:26:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 06:26:09 --> Final output sent to browser
DEBUG - 2020-02-10 06:26:09 --> Total execution time: 0.9376
INFO - 2020-02-10 06:26:09 --> Config Class Initialized
INFO - 2020-02-10 06:26:09 --> Config Class Initialized
INFO - 2020-02-10 06:26:09 --> Config Class Initialized
INFO - 2020-02-10 06:26:09 --> Hooks Class Initialized
INFO - 2020-02-10 06:26:09 --> Hooks Class Initialized
INFO - 2020-02-10 06:26:09 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:26:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 06:26:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 06:26:09 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:26:09 --> Utf8 Class Initialized
INFO - 2020-02-10 06:26:09 --> Utf8 Class Initialized
INFO - 2020-02-10 06:26:09 --> Utf8 Class Initialized
INFO - 2020-02-10 06:26:09 --> URI Class Initialized
INFO - 2020-02-10 06:26:09 --> URI Class Initialized
INFO - 2020-02-10 06:26:09 --> URI Class Initialized
INFO - 2020-02-10 06:26:09 --> Router Class Initialized
INFO - 2020-02-10 06:26:09 --> Router Class Initialized
INFO - 2020-02-10 06:26:09 --> Router Class Initialized
INFO - 2020-02-10 06:26:09 --> Output Class Initialized
INFO - 2020-02-10 06:26:09 --> Output Class Initialized
INFO - 2020-02-10 06:26:09 --> Output Class Initialized
INFO - 2020-02-10 06:26:09 --> Security Class Initialized
INFO - 2020-02-10 06:26:09 --> Security Class Initialized
INFO - 2020-02-10 06:26:09 --> Security Class Initialized
DEBUG - 2020-02-10 06:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 06:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 06:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:26:09 --> Input Class Initialized
INFO - 2020-02-10 06:26:09 --> Input Class Initialized
INFO - 2020-02-10 06:26:09 --> Input Class Initialized
INFO - 2020-02-10 06:26:09 --> Language Class Initialized
INFO - 2020-02-10 06:26:09 --> Language Class Initialized
INFO - 2020-02-10 06:26:09 --> Language Class Initialized
ERROR - 2020-02-10 06:26:09 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-10 06:26:09 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-10 06:26:09 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-10 06:26:18 --> Config Class Initialized
INFO - 2020-02-10 06:26:18 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:26:18 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:26:18 --> Utf8 Class Initialized
INFO - 2020-02-10 06:26:18 --> URI Class Initialized
INFO - 2020-02-10 06:26:18 --> Router Class Initialized
INFO - 2020-02-10 06:26:18 --> Output Class Initialized
INFO - 2020-02-10 06:26:18 --> Security Class Initialized
DEBUG - 2020-02-10 06:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:26:18 --> Input Class Initialized
INFO - 2020-02-10 06:26:18 --> Language Class Initialized
INFO - 2020-02-10 06:26:18 --> Loader Class Initialized
INFO - 2020-02-10 06:26:18 --> Helper loaded: url_helper
INFO - 2020-02-10 06:26:18 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:26:18 --> Controller Class Initialized
INFO - 2020-02-10 06:26:18 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:26:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:26:19 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:26:19 --> Helper loaded: form_helper
INFO - 2020-02-10 06:26:19 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:26:19 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
ERROR - 2020-02-10 06:26:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:26:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:26:19 --> Final output sent to browser
DEBUG - 2020-02-10 06:26:19 --> Total execution time: 0.9381
INFO - 2020-02-10 06:26:49 --> Config Class Initialized
INFO - 2020-02-10 06:26:49 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:26:49 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:26:49 --> Utf8 Class Initialized
INFO - 2020-02-10 06:26:49 --> URI Class Initialized
INFO - 2020-02-10 06:26:49 --> Router Class Initialized
INFO - 2020-02-10 06:26:49 --> Output Class Initialized
INFO - 2020-02-10 06:26:49 --> Security Class Initialized
DEBUG - 2020-02-10 06:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:26:49 --> Input Class Initialized
INFO - 2020-02-10 06:26:49 --> Language Class Initialized
INFO - 2020-02-10 06:26:49 --> Loader Class Initialized
INFO - 2020-02-10 06:26:49 --> Helper loaded: url_helper
INFO - 2020-02-10 06:26:49 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:26:49 --> Controller Class Initialized
INFO - 2020-02-10 06:26:49 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:26:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:26:49 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:26:49 --> Helper loaded: form_helper
INFO - 2020-02-10 06:26:49 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:26:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
ERROR - 2020-02-10 06:26:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:26:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:26:50 --> Final output sent to browser
DEBUG - 2020-02-10 06:26:50 --> Total execution time: 0.9014
INFO - 2020-02-10 06:27:35 --> Config Class Initialized
INFO - 2020-02-10 06:27:35 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:27:35 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:27:35 --> Utf8 Class Initialized
INFO - 2020-02-10 06:27:35 --> URI Class Initialized
INFO - 2020-02-10 06:27:35 --> Router Class Initialized
INFO - 2020-02-10 06:27:35 --> Output Class Initialized
INFO - 2020-02-10 06:27:35 --> Security Class Initialized
DEBUG - 2020-02-10 06:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:27:35 --> Input Class Initialized
INFO - 2020-02-10 06:27:35 --> Language Class Initialized
INFO - 2020-02-10 06:27:35 --> Loader Class Initialized
INFO - 2020-02-10 06:27:35 --> Helper loaded: url_helper
INFO - 2020-02-10 06:27:35 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:27:35 --> Controller Class Initialized
INFO - 2020-02-10 06:27:35 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:27:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:27:35 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:27:35 --> Helper loaded: form_helper
INFO - 2020-02-10 06:27:35 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:27:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
ERROR - 2020-02-10 06:27:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:27:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:27:35 --> Final output sent to browser
DEBUG - 2020-02-10 06:27:36 --> Total execution time: 0.9248
INFO - 2020-02-10 06:27:44 --> Config Class Initialized
INFO - 2020-02-10 06:27:44 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:27:44 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:27:44 --> Utf8 Class Initialized
INFO - 2020-02-10 06:27:45 --> URI Class Initialized
INFO - 2020-02-10 06:27:45 --> Router Class Initialized
INFO - 2020-02-10 06:27:45 --> Output Class Initialized
INFO - 2020-02-10 06:27:45 --> Security Class Initialized
DEBUG - 2020-02-10 06:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:27:45 --> Input Class Initialized
INFO - 2020-02-10 06:27:45 --> Language Class Initialized
INFO - 2020-02-10 06:27:45 --> Loader Class Initialized
INFO - 2020-02-10 06:27:45 --> Helper loaded: url_helper
INFO - 2020-02-10 06:27:45 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:27:45 --> Controller Class Initialized
INFO - 2020-02-10 06:27:45 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:27:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:27:45 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:27:45 --> Helper loaded: form_helper
INFO - 2020-02-10 06:27:45 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:27:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:27:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:27:45 --> Final output sent to browser
DEBUG - 2020-02-10 06:27:45 --> Total execution time: 0.8364
INFO - 2020-02-10 06:35:19 --> Config Class Initialized
INFO - 2020-02-10 06:35:19 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:35:19 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:35:19 --> Utf8 Class Initialized
INFO - 2020-02-10 06:35:19 --> URI Class Initialized
INFO - 2020-02-10 06:35:19 --> Router Class Initialized
INFO - 2020-02-10 06:35:19 --> Output Class Initialized
INFO - 2020-02-10 06:35:19 --> Security Class Initialized
DEBUG - 2020-02-10 06:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:35:20 --> Input Class Initialized
INFO - 2020-02-10 06:35:20 --> Language Class Initialized
INFO - 2020-02-10 06:35:20 --> Loader Class Initialized
INFO - 2020-02-10 06:35:20 --> Helper loaded: url_helper
INFO - 2020-02-10 06:35:20 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:35:20 --> Controller Class Initialized
INFO - 2020-02-10 06:35:20 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:35:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:35:20 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:35:20 --> Helper loaded: form_helper
INFO - 2020-02-10 06:35:20 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:35:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:35:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:35:20 --> Final output sent to browser
DEBUG - 2020-02-10 06:35:20 --> Total execution time: 0.8679
INFO - 2020-02-10 06:35:28 --> Config Class Initialized
INFO - 2020-02-10 06:35:28 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:35:28 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:35:28 --> Utf8 Class Initialized
INFO - 2020-02-10 06:35:28 --> URI Class Initialized
INFO - 2020-02-10 06:35:28 --> Router Class Initialized
INFO - 2020-02-10 06:35:28 --> Output Class Initialized
INFO - 2020-02-10 06:35:28 --> Security Class Initialized
DEBUG - 2020-02-10 06:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:35:28 --> Input Class Initialized
INFO - 2020-02-10 06:35:28 --> Language Class Initialized
INFO - 2020-02-10 06:35:28 --> Loader Class Initialized
INFO - 2020-02-10 06:35:28 --> Helper loaded: url_helper
INFO - 2020-02-10 06:35:28 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:35:28 --> Controller Class Initialized
INFO - 2020-02-10 06:35:28 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:35:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:35:28 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:35:28 --> Helper loaded: form_helper
INFO - 2020-02-10 06:35:28 --> Form Validation Class Initialized
INFO - 2020-02-10 06:35:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 06:35:28 --> Final output sent to browser
DEBUG - 2020-02-10 06:35:28 --> Total execution time: 0.8112
INFO - 2020-02-10 06:35:29 --> Config Class Initialized
INFO - 2020-02-10 06:35:29 --> Config Class Initialized
INFO - 2020-02-10 06:35:29 --> Hooks Class Initialized
INFO - 2020-02-10 06:35:29 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:35:29 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:35:29 --> Utf8 Class Initialized
DEBUG - 2020-02-10 06:35:29 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:35:29 --> Utf8 Class Initialized
INFO - 2020-02-10 06:35:29 --> URI Class Initialized
INFO - 2020-02-10 06:35:29 --> URI Class Initialized
INFO - 2020-02-10 06:35:29 --> Router Class Initialized
INFO - 2020-02-10 06:35:29 --> Router Class Initialized
INFO - 2020-02-10 06:35:29 --> Output Class Initialized
INFO - 2020-02-10 06:35:29 --> Security Class Initialized
INFO - 2020-02-10 06:35:29 --> Output Class Initialized
DEBUG - 2020-02-10 06:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:35:29 --> Security Class Initialized
INFO - 2020-02-10 06:35:29 --> Input Class Initialized
DEBUG - 2020-02-10 06:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:35:29 --> Input Class Initialized
INFO - 2020-02-10 06:35:29 --> Language Class Initialized
INFO - 2020-02-10 06:35:29 --> Language Class Initialized
INFO - 2020-02-10 06:35:29 --> Loader Class Initialized
INFO - 2020-02-10 06:35:29 --> Helper loaded: url_helper
INFO - 2020-02-10 06:35:29 --> Loader Class Initialized
INFO - 2020-02-10 06:35:29 --> Helper loaded: url_helper
INFO - 2020-02-10 06:35:29 --> Database Driver Class Initialized
INFO - 2020-02-10 06:35:29 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:35:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 06:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:35:29 --> Controller Class Initialized
INFO - 2020-02-10 06:35:29 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:35:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:35:29 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:35:29 --> Helper loaded: form_helper
INFO - 2020-02-10 06:35:29 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:35:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 06:35:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 06:35:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 06:35:29 --> Final output sent to browser
DEBUG - 2020-02-10 06:35:29 --> Total execution time: 0.7154
INFO - 2020-02-10 06:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:35:29 --> Controller Class Initialized
INFO - 2020-02-10 06:35:29 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:35:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:35:29 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:35:29 --> Helper loaded: form_helper
INFO - 2020-02-10 06:35:30 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:35:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 06:35:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 06:35:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 06:35:30 --> Final output sent to browser
DEBUG - 2020-02-10 06:35:30 --> Total execution time: 1.0701
INFO - 2020-02-10 06:35:40 --> Config Class Initialized
INFO - 2020-02-10 06:35:40 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:35:40 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:35:40 --> Utf8 Class Initialized
INFO - 2020-02-10 06:35:40 --> URI Class Initialized
INFO - 2020-02-10 06:35:40 --> Router Class Initialized
INFO - 2020-02-10 06:35:40 --> Output Class Initialized
INFO - 2020-02-10 06:35:40 --> Security Class Initialized
DEBUG - 2020-02-10 06:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:35:40 --> Input Class Initialized
INFO - 2020-02-10 06:35:40 --> Language Class Initialized
INFO - 2020-02-10 06:35:40 --> Loader Class Initialized
INFO - 2020-02-10 06:35:40 --> Helper loaded: url_helper
INFO - 2020-02-10 06:35:40 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:35:41 --> Controller Class Initialized
INFO - 2020-02-10 06:35:41 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:35:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:35:41 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:35:41 --> Helper loaded: form_helper
INFO - 2020-02-10 06:35:41 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:35:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:35:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:35:41 --> Final output sent to browser
DEBUG - 2020-02-10 06:35:41 --> Total execution time: 1.0543
INFO - 2020-02-10 06:36:01 --> Config Class Initialized
INFO - 2020-02-10 06:36:01 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:36:01 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:36:01 --> Utf8 Class Initialized
INFO - 2020-02-10 06:36:01 --> URI Class Initialized
INFO - 2020-02-10 06:36:01 --> Router Class Initialized
INFO - 2020-02-10 06:36:01 --> Output Class Initialized
INFO - 2020-02-10 06:36:01 --> Security Class Initialized
DEBUG - 2020-02-10 06:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:36:01 --> Input Class Initialized
INFO - 2020-02-10 06:36:01 --> Language Class Initialized
INFO - 2020-02-10 06:36:01 --> Loader Class Initialized
INFO - 2020-02-10 06:36:01 --> Helper loaded: url_helper
INFO - 2020-02-10 06:36:01 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:36:01 --> Controller Class Initialized
INFO - 2020-02-10 06:36:01 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:36:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:36:02 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:36:02 --> Helper loaded: form_helper
INFO - 2020-02-10 06:36:02 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:36:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:36:02 --> Final output sent to browser
DEBUG - 2020-02-10 06:36:02 --> Total execution time: 1.1204
INFO - 2020-02-10 06:38:31 --> Config Class Initialized
INFO - 2020-02-10 06:38:31 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:38:31 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:38:31 --> Utf8 Class Initialized
INFO - 2020-02-10 06:38:31 --> URI Class Initialized
INFO - 2020-02-10 06:38:31 --> Router Class Initialized
INFO - 2020-02-10 06:38:31 --> Output Class Initialized
INFO - 2020-02-10 06:38:31 --> Security Class Initialized
DEBUG - 2020-02-10 06:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:38:31 --> Input Class Initialized
INFO - 2020-02-10 06:38:31 --> Language Class Initialized
INFO - 2020-02-10 06:38:31 --> Loader Class Initialized
INFO - 2020-02-10 06:38:31 --> Helper loaded: url_helper
INFO - 2020-02-10 06:38:31 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:38:31 --> Controller Class Initialized
INFO - 2020-02-10 06:38:31 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:38:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:38:31 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:38:31 --> Helper loaded: form_helper
INFO - 2020-02-10 06:38:31 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:38:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-10 06:38:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-10 06:38:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-10 06:38:32 --> Final output sent to browser
DEBUG - 2020-02-10 06:38:32 --> Total execution time: 0.9677
INFO - 2020-02-10 06:39:04 --> Config Class Initialized
INFO - 2020-02-10 06:39:04 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:39:04 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:39:04 --> Utf8 Class Initialized
INFO - 2020-02-10 06:39:04 --> URI Class Initialized
INFO - 2020-02-10 06:39:04 --> Router Class Initialized
INFO - 2020-02-10 06:39:04 --> Output Class Initialized
INFO - 2020-02-10 06:39:04 --> Security Class Initialized
DEBUG - 2020-02-10 06:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:39:04 --> Input Class Initialized
INFO - 2020-02-10 06:39:04 --> Language Class Initialized
INFO - 2020-02-10 06:39:04 --> Loader Class Initialized
INFO - 2020-02-10 06:39:04 --> Helper loaded: url_helper
INFO - 2020-02-10 06:39:04 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:39:04 --> Controller Class Initialized
INFO - 2020-02-10 06:39:04 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:39:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:39:04 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:39:04 --> Helper loaded: form_helper
INFO - 2020-02-10 06:39:04 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:39:05 --> Severity: Notice --> Undefined variable: diti C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-10 06:39:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
INFO - 2020-02-10 06:39:05 --> Final output sent to browser
DEBUG - 2020-02-10 06:39:05 --> Total execution time: 0.9122
INFO - 2020-02-10 06:39:19 --> Config Class Initialized
INFO - 2020-02-10 06:39:19 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:39:19 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:39:19 --> Utf8 Class Initialized
INFO - 2020-02-10 06:39:19 --> URI Class Initialized
INFO - 2020-02-10 06:39:19 --> Router Class Initialized
INFO - 2020-02-10 06:39:19 --> Output Class Initialized
INFO - 2020-02-10 06:39:20 --> Security Class Initialized
DEBUG - 2020-02-10 06:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:39:20 --> Input Class Initialized
INFO - 2020-02-10 06:39:20 --> Language Class Initialized
INFO - 2020-02-10 06:39:20 --> Loader Class Initialized
INFO - 2020-02-10 06:39:20 --> Helper loaded: url_helper
INFO - 2020-02-10 06:39:20 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:39:20 --> Controller Class Initialized
INFO - 2020-02-10 06:39:20 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:39:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:39:20 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:39:20 --> Helper loaded: form_helper
INFO - 2020-02-10 06:39:20 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:39:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
INFO - 2020-02-10 06:39:20 --> Final output sent to browser
DEBUG - 2020-02-10 06:39:20 --> Total execution time: 0.8173
INFO - 2020-02-10 06:39:43 --> Config Class Initialized
INFO - 2020-02-10 06:39:43 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:39:43 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:39:43 --> Utf8 Class Initialized
INFO - 2020-02-10 06:39:43 --> URI Class Initialized
INFO - 2020-02-10 06:39:43 --> Router Class Initialized
INFO - 2020-02-10 06:39:43 --> Output Class Initialized
INFO - 2020-02-10 06:39:43 --> Security Class Initialized
DEBUG - 2020-02-10 06:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:39:43 --> Input Class Initialized
INFO - 2020-02-10 06:39:43 --> Language Class Initialized
INFO - 2020-02-10 06:39:43 --> Loader Class Initialized
INFO - 2020-02-10 06:39:43 --> Helper loaded: url_helper
INFO - 2020-02-10 06:39:44 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:39:44 --> Controller Class Initialized
INFO - 2020-02-10 06:39:44 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:39:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:39:44 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:39:44 --> Helper loaded: form_helper
INFO - 2020-02-10 06:39:44 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:39:44 --> Severity: Notice --> Undefined variable: diti C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-10 06:39:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
INFO - 2020-02-10 06:39:44 --> Final output sent to browser
DEBUG - 2020-02-10 06:39:44 --> Total execution time: 1.0025
INFO - 2020-02-10 06:40:01 --> Config Class Initialized
INFO - 2020-02-10 06:40:01 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:40:01 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:40:01 --> Utf8 Class Initialized
INFO - 2020-02-10 06:40:01 --> URI Class Initialized
INFO - 2020-02-10 06:40:01 --> Router Class Initialized
INFO - 2020-02-10 06:40:01 --> Output Class Initialized
INFO - 2020-02-10 06:40:01 --> Security Class Initialized
DEBUG - 2020-02-10 06:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:40:02 --> Input Class Initialized
INFO - 2020-02-10 06:40:02 --> Language Class Initialized
INFO - 2020-02-10 06:40:02 --> Loader Class Initialized
INFO - 2020-02-10 06:40:02 --> Helper loaded: url_helper
INFO - 2020-02-10 06:40:02 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:40:02 --> Controller Class Initialized
INFO - 2020-02-10 06:40:02 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:40:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:40:02 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:40:02 --> Helper loaded: form_helper
INFO - 2020-02-10 06:40:02 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:40:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
INFO - 2020-02-10 06:40:02 --> Final output sent to browser
DEBUG - 2020-02-10 06:40:02 --> Total execution time: 1.0455
INFO - 2020-02-10 06:43:15 --> Config Class Initialized
INFO - 2020-02-10 06:43:15 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:43:15 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:43:15 --> Utf8 Class Initialized
INFO - 2020-02-10 06:43:15 --> URI Class Initialized
INFO - 2020-02-10 06:43:15 --> Router Class Initialized
INFO - 2020-02-10 06:43:15 --> Output Class Initialized
INFO - 2020-02-10 06:43:15 --> Security Class Initialized
DEBUG - 2020-02-10 06:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:43:15 --> Input Class Initialized
INFO - 2020-02-10 06:43:15 --> Language Class Initialized
INFO - 2020-02-10 06:43:15 --> Loader Class Initialized
INFO - 2020-02-10 06:43:15 --> Helper loaded: url_helper
INFO - 2020-02-10 06:43:15 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:43:16 --> Controller Class Initialized
INFO - 2020-02-10 06:43:16 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:43:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:43:16 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:43:16 --> Helper loaded: form_helper
INFO - 2020-02-10 06:43:16 --> Form Validation Class Initialized
ERROR - 2020-02-10 06:43:16 --> Severity: error --> Exception: Call to a member function result() on array C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
INFO - 2020-02-10 06:50:03 --> Config Class Initialized
INFO - 2020-02-10 06:50:04 --> Hooks Class Initialized
DEBUG - 2020-02-10 06:50:04 --> UTF-8 Support Enabled
INFO - 2020-02-10 06:50:04 --> Utf8 Class Initialized
INFO - 2020-02-10 06:50:04 --> URI Class Initialized
INFO - 2020-02-10 06:50:04 --> Router Class Initialized
INFO - 2020-02-10 06:50:04 --> Output Class Initialized
INFO - 2020-02-10 06:50:04 --> Security Class Initialized
DEBUG - 2020-02-10 06:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 06:50:04 --> Input Class Initialized
INFO - 2020-02-10 06:50:04 --> Language Class Initialized
INFO - 2020-02-10 06:50:04 --> Loader Class Initialized
INFO - 2020-02-10 06:50:04 --> Helper loaded: url_helper
INFO - 2020-02-10 06:50:04 --> Database Driver Class Initialized
DEBUG - 2020-02-10 06:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 06:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 06:50:04 --> Controller Class Initialized
INFO - 2020-02-10 06:50:04 --> Model "M_tiket" initialized
INFO - 2020-02-10 06:50:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 06:50:04 --> Model "M_pesan" initialized
INFO - 2020-02-10 06:50:04 --> Helper loaded: form_helper
INFO - 2020-02-10 06:50:04 --> Form Validation Class Initialized
INFO - 2020-02-10 06:50:04 --> Final output sent to browser
DEBUG - 2020-02-10 06:50:04 --> Total execution time: 0.7684
INFO - 2020-02-10 07:05:12 --> Config Class Initialized
INFO - 2020-02-10 07:05:12 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:05:12 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:05:12 --> Utf8 Class Initialized
INFO - 2020-02-10 07:05:12 --> URI Class Initialized
INFO - 2020-02-10 07:05:12 --> Router Class Initialized
INFO - 2020-02-10 07:05:12 --> Output Class Initialized
INFO - 2020-02-10 07:05:12 --> Security Class Initialized
DEBUG - 2020-02-10 07:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:05:12 --> Input Class Initialized
INFO - 2020-02-10 07:05:12 --> Language Class Initialized
INFO - 2020-02-10 07:05:13 --> Loader Class Initialized
INFO - 2020-02-10 07:05:13 --> Helper loaded: url_helper
INFO - 2020-02-10 07:05:13 --> Database Driver Class Initialized
DEBUG - 2020-02-10 07:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:05:13 --> Controller Class Initialized
INFO - 2020-02-10 07:05:13 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:05:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:05:13 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:05:13 --> Helper loaded: form_helper
INFO - 2020-02-10 07:05:13 --> Form Validation Class Initialized
ERROR - 2020-02-10 07:05:13 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$nama_bank C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 07:05:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 07:05:14 --> Final output sent to browser
DEBUG - 2020-02-10 07:05:14 --> Total execution time: 2.0193
INFO - 2020-02-10 07:05:14 --> Config Class Initialized
INFO - 2020-02-10 07:05:14 --> Config Class Initialized
INFO - 2020-02-10 07:05:14 --> Hooks Class Initialized
INFO - 2020-02-10 07:05:14 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:05:14 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:05:14 --> Utf8 Class Initialized
INFO - 2020-02-10 07:05:14 --> Utf8 Class Initialized
INFO - 2020-02-10 07:05:14 --> URI Class Initialized
INFO - 2020-02-10 07:05:14 --> URI Class Initialized
INFO - 2020-02-10 07:05:14 --> Router Class Initialized
INFO - 2020-02-10 07:05:14 --> Router Class Initialized
INFO - 2020-02-10 07:05:14 --> Output Class Initialized
INFO - 2020-02-10 07:05:14 --> Output Class Initialized
INFO - 2020-02-10 07:05:14 --> Security Class Initialized
INFO - 2020-02-10 07:05:14 --> Security Class Initialized
DEBUG - 2020-02-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:05:14 --> Input Class Initialized
INFO - 2020-02-10 07:05:14 --> Input Class Initialized
INFO - 2020-02-10 07:05:14 --> Language Class Initialized
INFO - 2020-02-10 07:05:14 --> Language Class Initialized
INFO - 2020-02-10 07:05:14 --> Loader Class Initialized
INFO - 2020-02-10 07:05:14 --> Loader Class Initialized
INFO - 2020-02-10 07:05:14 --> Helper loaded: url_helper
INFO - 2020-02-10 07:05:14 --> Helper loaded: url_helper
INFO - 2020-02-10 07:05:14 --> Database Driver Class Initialized
INFO - 2020-02-10 07:05:14 --> Database Driver Class Initialized
DEBUG - 2020-02-10 07:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-10 07:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:05:14 --> Controller Class Initialized
INFO - 2020-02-10 07:05:14 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:05:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:05:14 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:05:15 --> Helper loaded: form_helper
INFO - 2020-02-10 07:05:15 --> Form Validation Class Initialized
ERROR - 2020-02-10 07:05:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 07:05:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-10 07:05:15 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$nama_bank C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 07:05:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 07:05:15 --> Final output sent to browser
DEBUG - 2020-02-10 07:05:15 --> Total execution time: 0.9473
INFO - 2020-02-10 07:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:05:15 --> Controller Class Initialized
INFO - 2020-02-10 07:05:15 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:05:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:05:15 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:05:15 --> Helper loaded: form_helper
INFO - 2020-02-10 07:05:15 --> Form Validation Class Initialized
ERROR - 2020-02-10 07:05:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 07:05:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-10 07:05:15 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$nama_bank C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 07:05:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 07:05:15 --> Final output sent to browser
DEBUG - 2020-02-10 07:05:15 --> Total execution time: 1.3183
INFO - 2020-02-10 07:06:41 --> Config Class Initialized
INFO - 2020-02-10 07:06:41 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:06:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:06:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:06:42 --> URI Class Initialized
INFO - 2020-02-10 07:06:42 --> Router Class Initialized
INFO - 2020-02-10 07:06:42 --> Output Class Initialized
INFO - 2020-02-10 07:06:42 --> Security Class Initialized
DEBUG - 2020-02-10 07:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:06:42 --> Input Class Initialized
INFO - 2020-02-10 07:06:42 --> Language Class Initialized
INFO - 2020-02-10 07:06:42 --> Loader Class Initialized
INFO - 2020-02-10 07:06:42 --> Helper loaded: url_helper
INFO - 2020-02-10 07:06:42 --> Database Driver Class Initialized
DEBUG - 2020-02-10 07:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:06:42 --> Controller Class Initialized
INFO - 2020-02-10 07:06:42 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:06:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:06:42 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:06:42 --> Helper loaded: form_helper
INFO - 2020-02-10 07:06:42 --> Form Validation Class Initialized
ERROR - 2020-02-10 07:06:42 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$id_bank C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 07:06:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 07:06:42 --> Final output sent to browser
DEBUG - 2020-02-10 07:06:42 --> Total execution time: 0.7983
INFO - 2020-02-10 07:06:42 --> Config Class Initialized
INFO - 2020-02-10 07:06:42 --> Config Class Initialized
INFO - 2020-02-10 07:06:42 --> Config Class Initialized
INFO - 2020-02-10 07:06:42 --> Config Class Initialized
INFO - 2020-02-10 07:06:42 --> Config Class Initialized
INFO - 2020-02-10 07:06:42 --> Hooks Class Initialized
INFO - 2020-02-10 07:06:42 --> Hooks Class Initialized
INFO - 2020-02-10 07:06:42 --> Hooks Class Initialized
INFO - 2020-02-10 07:06:42 --> Hooks Class Initialized
INFO - 2020-02-10 07:06:42 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:06:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:06:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:06:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:06:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:06:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:06:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:06:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:06:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:06:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:06:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:06:42 --> URI Class Initialized
INFO - 2020-02-10 07:06:42 --> URI Class Initialized
INFO - 2020-02-10 07:06:42 --> URI Class Initialized
INFO - 2020-02-10 07:06:42 --> URI Class Initialized
INFO - 2020-02-10 07:06:42 --> URI Class Initialized
INFO - 2020-02-10 07:06:43 --> Router Class Initialized
INFO - 2020-02-10 07:06:43 --> Router Class Initialized
INFO - 2020-02-10 07:06:43 --> Router Class Initialized
INFO - 2020-02-10 07:06:43 --> Router Class Initialized
INFO - 2020-02-10 07:06:43 --> Router Class Initialized
INFO - 2020-02-10 07:06:43 --> Output Class Initialized
INFO - 2020-02-10 07:06:43 --> Output Class Initialized
INFO - 2020-02-10 07:06:43 --> Output Class Initialized
INFO - 2020-02-10 07:06:43 --> Output Class Initialized
INFO - 2020-02-10 07:06:43 --> Output Class Initialized
INFO - 2020-02-10 07:06:43 --> Security Class Initialized
INFO - 2020-02-10 07:06:43 --> Security Class Initialized
INFO - 2020-02-10 07:06:43 --> Security Class Initialized
INFO - 2020-02-10 07:06:43 --> Security Class Initialized
INFO - 2020-02-10 07:06:43 --> Security Class Initialized
DEBUG - 2020-02-10 07:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:06:43 --> Input Class Initialized
INFO - 2020-02-10 07:06:43 --> Input Class Initialized
INFO - 2020-02-10 07:06:43 --> Input Class Initialized
INFO - 2020-02-10 07:06:43 --> Input Class Initialized
INFO - 2020-02-10 07:06:43 --> Input Class Initialized
INFO - 2020-02-10 07:06:43 --> Language Class Initialized
INFO - 2020-02-10 07:06:43 --> Language Class Initialized
INFO - 2020-02-10 07:06:43 --> Language Class Initialized
INFO - 2020-02-10 07:06:43 --> Language Class Initialized
INFO - 2020-02-10 07:06:43 --> Language Class Initialized
ERROR - 2020-02-10 07:06:47 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-10 07:06:47 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-10 07:06:47 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-10 07:06:47 --> Loader Class Initialized
INFO - 2020-02-10 07:06:47 --> Loader Class Initialized
INFO - 2020-02-10 07:06:51 --> Config Class Initialized
INFO - 2020-02-10 07:06:51 --> Config Class Initialized
INFO - 2020-02-10 07:06:51 --> Config Class Initialized
INFO - 2020-02-10 07:06:51 --> Config Class Initialized
INFO - 2020-02-10 07:06:51 --> Config Class Initialized
INFO - 2020-02-10 07:06:51 --> Config Class Initialized
INFO - 2020-02-10 07:06:51 --> Hooks Class Initialized
INFO - 2020-02-10 07:06:51 --> Hooks Class Initialized
INFO - 2020-02-10 07:06:51 --> Hooks Class Initialized
INFO - 2020-02-10 07:06:51 --> Hooks Class Initialized
INFO - 2020-02-10 07:06:51 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:06:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:06:51 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:06:51 --> Utf8 Class Initialized
INFO - 2020-02-10 07:06:51 --> Utf8 Class Initialized
DEBUG - 2020-02-10 07:06:51 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:06:51 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:06:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:06:51 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:06:51 --> Utf8 Class Initialized
INFO - 2020-02-10 07:06:51 --> URI Class Initialized
INFO - 2020-02-10 07:06:51 --> URI Class Initialized
INFO - 2020-02-10 07:06:51 --> Utf8 Class Initialized
INFO - 2020-02-10 07:06:51 --> Utf8 Class Initialized
DEBUG - 2020-02-10 07:06:51 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:06:51 --> URI Class Initialized
INFO - 2020-02-10 07:06:51 --> URI Class Initialized
INFO - 2020-02-10 07:06:51 --> URI Class Initialized
INFO - 2020-02-10 07:06:51 --> Utf8 Class Initialized
INFO - 2020-02-10 07:06:51 --> Router Class Initialized
INFO - 2020-02-10 07:06:51 --> Router Class Initialized
INFO - 2020-02-10 07:06:51 --> Output Class Initialized
INFO - 2020-02-10 07:06:51 --> Output Class Initialized
INFO - 2020-02-10 07:06:51 --> Router Class Initialized
INFO - 2020-02-10 07:06:51 --> URI Class Initialized
INFO - 2020-02-10 07:06:51 --> Router Class Initialized
INFO - 2020-02-10 07:06:51 --> Router Class Initialized
INFO - 2020-02-10 07:06:51 --> Security Class Initialized
INFO - 2020-02-10 07:06:51 --> Security Class Initialized
INFO - 2020-02-10 07:06:51 --> Output Class Initialized
INFO - 2020-02-10 07:06:51 --> Output Class Initialized
INFO - 2020-02-10 07:06:51 --> Output Class Initialized
INFO - 2020-02-10 07:06:51 --> Router Class Initialized
INFO - 2020-02-10 07:06:51 --> Security Class Initialized
DEBUG - 2020-02-10 07:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:06:51 --> Security Class Initialized
INFO - 2020-02-10 07:06:51 --> Security Class Initialized
INFO - 2020-02-10 07:06:51 --> Output Class Initialized
DEBUG - 2020-02-10 07:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:06:51 --> Input Class Initialized
DEBUG - 2020-02-10 07:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:06:51 --> Input Class Initialized
INFO - 2020-02-10 07:06:51 --> Security Class Initialized
DEBUG - 2020-02-10 07:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:06:51 --> Input Class Initialized
INFO - 2020-02-10 07:06:51 --> Input Class Initialized
INFO - 2020-02-10 07:06:51 --> Input Class Initialized
INFO - 2020-02-10 07:06:51 --> Language Class Initialized
DEBUG - 2020-02-10 07:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:06:51 --> Language Class Initialized
INFO - 2020-02-10 07:06:51 --> Language Class Initialized
INFO - 2020-02-10 07:06:51 --> Language Class Initialized
INFO - 2020-02-10 07:06:51 --> Input Class Initialized
ERROR - 2020-02-10 07:06:51 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 07:06:51 --> Language Class Initialized
ERROR - 2020-02-10 07:06:51 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 07:06:51 --> Language Class Initialized
ERROR - 2020-02-10 07:06:51 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-10 07:06:51 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 07:06:51 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 07:06:51 --> Config Class Initialized
INFO - 2020-02-10 07:06:51 --> Config Class Initialized
INFO - 2020-02-10 07:06:51 --> Hooks Class Initialized
ERROR - 2020-02-10 07:06:51 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 07:06:51 --> Hooks Class Initialized
INFO - 2020-02-10 07:06:51 --> Config Class Initialized
INFO - 2020-02-10 07:06:51 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:06:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:06:51 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:06:52 --> Utf8 Class Initialized
INFO - 2020-02-10 07:06:52 --> Utf8 Class Initialized
DEBUG - 2020-02-10 07:06:52 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:06:52 --> Utf8 Class Initialized
INFO - 2020-02-10 07:06:52 --> URI Class Initialized
INFO - 2020-02-10 07:06:52 --> URI Class Initialized
INFO - 2020-02-10 07:06:52 --> URI Class Initialized
INFO - 2020-02-10 07:06:52 --> Router Class Initialized
INFO - 2020-02-10 07:06:52 --> Router Class Initialized
INFO - 2020-02-10 07:06:52 --> Router Class Initialized
INFO - 2020-02-10 07:06:52 --> Output Class Initialized
INFO - 2020-02-10 07:06:52 --> Output Class Initialized
INFO - 2020-02-10 07:06:52 --> Security Class Initialized
INFO - 2020-02-10 07:06:52 --> Output Class Initialized
INFO - 2020-02-10 07:06:52 --> Security Class Initialized
DEBUG - 2020-02-10 07:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:06:52 --> Security Class Initialized
DEBUG - 2020-02-10 07:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:06:52 --> Input Class Initialized
INFO - 2020-02-10 07:06:52 --> Input Class Initialized
DEBUG - 2020-02-10 07:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:06:52 --> Input Class Initialized
INFO - 2020-02-10 07:06:52 --> Language Class Initialized
INFO - 2020-02-10 07:06:52 --> Language Class Initialized
INFO - 2020-02-10 07:06:52 --> Language Class Initialized
ERROR - 2020-02-10 07:06:52 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-10 07:06:52 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 07:06:52 --> Loader Class Initialized
INFO - 2020-02-10 07:06:52 --> Helper loaded: url_helper
INFO - 2020-02-10 07:06:52 --> Database Driver Class Initialized
DEBUG - 2020-02-10 07:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:06:52 --> Controller Class Initialized
INFO - 2020-02-10 07:06:52 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:06:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:06:52 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:06:52 --> Helper loaded: form_helper
INFO - 2020-02-10 07:06:52 --> Form Validation Class Initialized
ERROR - 2020-02-10 07:06:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 07:06:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-10 07:06:52 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$id_bank C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 07:06:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 07:06:52 --> Final output sent to browser
DEBUG - 2020-02-10 07:06:52 --> Total execution time: 0.8526
INFO - 2020-02-10 07:16:41 --> Config Class Initialized
INFO - 2020-02-10 07:16:41 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:16:41 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:41 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:41 --> URI Class Initialized
INFO - 2020-02-10 07:16:41 --> Router Class Initialized
INFO - 2020-02-10 07:16:41 --> Output Class Initialized
INFO - 2020-02-10 07:16:41 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:41 --> Input Class Initialized
INFO - 2020-02-10 07:16:41 --> Language Class Initialized
INFO - 2020-02-10 07:16:41 --> Loader Class Initialized
INFO - 2020-02-10 07:16:41 --> Helper loaded: url_helper
INFO - 2020-02-10 07:16:41 --> Database Driver Class Initialized
DEBUG - 2020-02-10 07:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:16:41 --> Controller Class Initialized
INFO - 2020-02-10 07:16:41 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:16:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:16:41 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:16:41 --> Helper loaded: form_helper
INFO - 2020-02-10 07:16:42 --> Form Validation Class Initialized
INFO - 2020-02-10 07:16:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 07:16:42 --> Final output sent to browser
INFO - 2020-02-10 07:16:42 --> Config Class Initialized
INFO - 2020-02-10 07:16:42 --> Config Class Initialized
INFO - 2020-02-10 07:16:42 --> Config Class Initialized
INFO - 2020-02-10 07:16:42 --> Hooks Class Initialized
INFO - 2020-02-10 07:16:42 --> Hooks Class Initialized
INFO - 2020-02-10 07:16:42 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:16:42 --> Total execution time: 0.9020
INFO - 2020-02-10 07:16:42 --> Config Class Initialized
INFO - 2020-02-10 07:16:42 --> Config Class Initialized
INFO - 2020-02-10 07:16:42 --> Hooks Class Initialized
INFO - 2020-02-10 07:16:42 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:16:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:16:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:16:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:42 --> Config Class Initialized
INFO - 2020-02-10 07:16:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:42 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:16:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:42 --> Utf8 Class Initialized
DEBUG - 2020-02-10 07:16:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:42 --> URI Class Initialized
INFO - 2020-02-10 07:16:42 --> URI Class Initialized
INFO - 2020-02-10 07:16:42 --> URI Class Initialized
DEBUG - 2020-02-10 07:16:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:42 --> Router Class Initialized
INFO - 2020-02-10 07:16:42 --> Router Class Initialized
INFO - 2020-02-10 07:16:42 --> URI Class Initialized
INFO - 2020-02-10 07:16:42 --> Router Class Initialized
INFO - 2020-02-10 07:16:42 --> URI Class Initialized
INFO - 2020-02-10 07:16:42 --> URI Class Initialized
INFO - 2020-02-10 07:16:42 --> Router Class Initialized
INFO - 2020-02-10 07:16:42 --> Output Class Initialized
INFO - 2020-02-10 07:16:42 --> Router Class Initialized
INFO - 2020-02-10 07:16:42 --> Output Class Initialized
INFO - 2020-02-10 07:16:42 --> Output Class Initialized
INFO - 2020-02-10 07:16:42 --> Router Class Initialized
INFO - 2020-02-10 07:16:42 --> Security Class Initialized
INFO - 2020-02-10 07:16:42 --> Security Class Initialized
INFO - 2020-02-10 07:16:42 --> Output Class Initialized
INFO - 2020-02-10 07:16:42 --> Security Class Initialized
INFO - 2020-02-10 07:16:42 --> Output Class Initialized
DEBUG - 2020-02-10 07:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:42 --> Output Class Initialized
INFO - 2020-02-10 07:16:42 --> Security Class Initialized
INFO - 2020-02-10 07:16:42 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:42 --> Input Class Initialized
INFO - 2020-02-10 07:16:42 --> Input Class Initialized
INFO - 2020-02-10 07:16:42 --> Input Class Initialized
INFO - 2020-02-10 07:16:42 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:42 --> Input Class Initialized
INFO - 2020-02-10 07:16:42 --> Language Class Initialized
INFO - 2020-02-10 07:16:42 --> Language Class Initialized
INFO - 2020-02-10 07:16:42 --> Input Class Initialized
INFO - 2020-02-10 07:16:42 --> Language Class Initialized
DEBUG - 2020-02-10 07:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:42 --> Input Class Initialized
INFO - 2020-02-10 07:16:42 --> Language Class Initialized
ERROR - 2020-02-10 07:16:42 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-10 07:16:42 --> Language Class Initialized
ERROR - 2020-02-10 07:16:42 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-10 07:16:42 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-10 07:16:42 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-10 07:16:42 --> Language Class Initialized
ERROR - 2020-02-10 07:16:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 07:16:42 --> Config Class Initialized
INFO - 2020-02-10 07:16:42 --> Config Class Initialized
INFO - 2020-02-10 07:16:42 --> Config Class Initialized
INFO - 2020-02-10 07:16:42 --> Hooks Class Initialized
INFO - 2020-02-10 07:16:42 --> Hooks Class Initialized
INFO - 2020-02-10 07:16:42 --> Hooks Class Initialized
ERROR - 2020-02-10 07:16:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 07:16:42 --> Config Class Initialized
INFO - 2020-02-10 07:16:42 --> Config Class Initialized
INFO - 2020-02-10 07:16:42 --> Hooks Class Initialized
INFO - 2020-02-10 07:16:42 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:16:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:16:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:16:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:42 --> Config Class Initialized
INFO - 2020-02-10 07:16:42 --> Hooks Class Initialized
INFO - 2020-02-10 07:16:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:42 --> Utf8 Class Initialized
DEBUG - 2020-02-10 07:16:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:16:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:42 --> URI Class Initialized
INFO - 2020-02-10 07:16:42 --> URI Class Initialized
INFO - 2020-02-10 07:16:42 --> URI Class Initialized
DEBUG - 2020-02-10 07:16:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:42 --> URI Class Initialized
INFO - 2020-02-10 07:16:42 --> Router Class Initialized
INFO - 2020-02-10 07:16:42 --> Router Class Initialized
INFO - 2020-02-10 07:16:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:42 --> URI Class Initialized
INFO - 2020-02-10 07:16:42 --> Router Class Initialized
INFO - 2020-02-10 07:16:42 --> URI Class Initialized
INFO - 2020-02-10 07:16:42 --> Output Class Initialized
INFO - 2020-02-10 07:16:42 --> Output Class Initialized
INFO - 2020-02-10 07:16:42 --> Router Class Initialized
INFO - 2020-02-10 07:16:42 --> Output Class Initialized
INFO - 2020-02-10 07:16:42 --> Router Class Initialized
INFO - 2020-02-10 07:16:42 --> Security Class Initialized
INFO - 2020-02-10 07:16:42 --> Router Class Initialized
INFO - 2020-02-10 07:16:42 --> Output Class Initialized
INFO - 2020-02-10 07:16:42 --> Output Class Initialized
INFO - 2020-02-10 07:16:42 --> Security Class Initialized
INFO - 2020-02-10 07:16:42 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:42 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:42 --> Output Class Initialized
INFO - 2020-02-10 07:16:42 --> Security Class Initialized
INFO - 2020-02-10 07:16:42 --> Input Class Initialized
INFO - 2020-02-10 07:16:42 --> Input Class Initialized
DEBUG - 2020-02-10 07:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:42 --> Input Class Initialized
DEBUG - 2020-02-10 07:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:42 --> Security Class Initialized
INFO - 2020-02-10 07:16:43 --> Input Class Initialized
INFO - 2020-02-10 07:16:43 --> Input Class Initialized
INFO - 2020-02-10 07:16:43 --> Language Class Initialized
INFO - 2020-02-10 07:16:43 --> Language Class Initialized
INFO - 2020-02-10 07:16:43 --> Language Class Initialized
DEBUG - 2020-02-10 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:43 --> Input Class Initialized
ERROR - 2020-02-10 07:16:43 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 07:16:43 --> Language Class Initialized
ERROR - 2020-02-10 07:16:43 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 07:16:43 --> Loader Class Initialized
INFO - 2020-02-10 07:16:43 --> Language Class Initialized
ERROR - 2020-02-10 07:16:43 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 07:16:43 --> Helper loaded: url_helper
INFO - 2020-02-10 07:16:43 --> Language Class Initialized
INFO - 2020-02-10 07:16:43 --> Loader Class Initialized
INFO - 2020-02-10 07:16:43 --> Config Class Initialized
INFO - 2020-02-10 07:16:43 --> Config Class Initialized
INFO - 2020-02-10 07:16:43 --> Hooks Class Initialized
INFO - 2020-02-10 07:16:43 --> Hooks Class Initialized
ERROR - 2020-02-10 07:16:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 07:16:43 --> Helper loaded: url_helper
INFO - 2020-02-10 07:16:43 --> Database Driver Class Initialized
DEBUG - 2020-02-10 07:16:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:16:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:16:43 --> Database Driver Class Initialized
INFO - 2020-02-10 07:16:43 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:43 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 07:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:16:43 --> Controller Class Initialized
INFO - 2020-02-10 07:16:43 --> URI Class Initialized
INFO - 2020-02-10 07:16:43 --> URI Class Initialized
INFO - 2020-02-10 07:16:43 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:16:43 --> Router Class Initialized
INFO - 2020-02-10 07:16:43 --> Router Class Initialized
INFO - 2020-02-10 07:16:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:16:43 --> Output Class Initialized
INFO - 2020-02-10 07:16:43 --> Output Class Initialized
INFO - 2020-02-10 07:16:43 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:16:43 --> Security Class Initialized
INFO - 2020-02-10 07:16:43 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:43 --> Helper loaded: form_helper
INFO - 2020-02-10 07:16:43 --> Form Validation Class Initialized
INFO - 2020-02-10 07:16:43 --> Input Class Initialized
INFO - 2020-02-10 07:16:43 --> Input Class Initialized
INFO - 2020-02-10 07:16:43 --> Language Class Initialized
INFO - 2020-02-10 07:16:43 --> Language Class Initialized
ERROR - 2020-02-10 07:16:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 07:16:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-10 07:16:43 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-10 07:16:43 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-10 07:16:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 07:16:43 --> Config Class Initialized
INFO - 2020-02-10 07:16:43 --> Hooks Class Initialized
INFO - 2020-02-10 07:16:43 --> Final output sent to browser
DEBUG - 2020-02-10 07:16:43 --> Total execution time: 0.8303
DEBUG - 2020-02-10 07:16:43 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:43 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:16:43 --> Controller Class Initialized
INFO - 2020-02-10 07:16:43 --> URI Class Initialized
INFO - 2020-02-10 07:16:43 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:16:43 --> Router Class Initialized
INFO - 2020-02-10 07:16:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:16:43 --> Output Class Initialized
INFO - 2020-02-10 07:16:43 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:16:43 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:43 --> Helper loaded: form_helper
INFO - 2020-02-10 07:16:43 --> Input Class Initialized
INFO - 2020-02-10 07:16:43 --> Form Validation Class Initialized
INFO - 2020-02-10 07:16:43 --> Language Class Initialized
ERROR - 2020-02-10 07:16:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 07:16:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-10 07:16:43 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 07:16:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 07:16:43 --> Config Class Initialized
INFO - 2020-02-10 07:16:43 --> Hooks Class Initialized
INFO - 2020-02-10 07:16:43 --> Final output sent to browser
DEBUG - 2020-02-10 07:16:43 --> Total execution time: 1.1302
DEBUG - 2020-02-10 07:16:43 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:43 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:43 --> URI Class Initialized
INFO - 2020-02-10 07:16:43 --> Router Class Initialized
INFO - 2020-02-10 07:16:44 --> Output Class Initialized
INFO - 2020-02-10 07:16:44 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:44 --> Input Class Initialized
INFO - 2020-02-10 07:16:44 --> Language Class Initialized
ERROR - 2020-02-10 07:16:44 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 07:16:44 --> Config Class Initialized
INFO - 2020-02-10 07:16:44 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:16:44 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:44 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:44 --> URI Class Initialized
INFO - 2020-02-10 07:16:44 --> Router Class Initialized
INFO - 2020-02-10 07:16:44 --> Output Class Initialized
INFO - 2020-02-10 07:16:44 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:44 --> Input Class Initialized
INFO - 2020-02-10 07:16:44 --> Language Class Initialized
ERROR - 2020-02-10 07:16:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 07:16:44 --> Config Class Initialized
INFO - 2020-02-10 07:16:44 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:16:44 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:44 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:44 --> URI Class Initialized
INFO - 2020-02-10 07:16:44 --> Router Class Initialized
INFO - 2020-02-10 07:16:44 --> Output Class Initialized
INFO - 2020-02-10 07:16:44 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:44 --> Input Class Initialized
INFO - 2020-02-10 07:16:44 --> Language Class Initialized
ERROR - 2020-02-10 07:16:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 07:16:44 --> Config Class Initialized
INFO - 2020-02-10 07:16:44 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:16:45 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:45 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:45 --> URI Class Initialized
INFO - 2020-02-10 07:16:45 --> Router Class Initialized
INFO - 2020-02-10 07:16:45 --> Output Class Initialized
INFO - 2020-02-10 07:16:45 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:45 --> Input Class Initialized
INFO - 2020-02-10 07:16:45 --> Language Class Initialized
ERROR - 2020-02-10 07:16:45 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 07:16:45 --> Config Class Initialized
INFO - 2020-02-10 07:16:45 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:16:45 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:45 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:45 --> URI Class Initialized
INFO - 2020-02-10 07:16:45 --> Router Class Initialized
INFO - 2020-02-10 07:16:45 --> Output Class Initialized
INFO - 2020-02-10 07:16:45 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:45 --> Input Class Initialized
INFO - 2020-02-10 07:16:45 --> Language Class Initialized
ERROR - 2020-02-10 07:16:45 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 07:16:45 --> Config Class Initialized
INFO - 2020-02-10 07:16:45 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:16:45 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:45 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:45 --> URI Class Initialized
INFO - 2020-02-10 07:16:45 --> Router Class Initialized
INFO - 2020-02-10 07:16:45 --> Output Class Initialized
INFO - 2020-02-10 07:16:45 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:45 --> Input Class Initialized
INFO - 2020-02-10 07:16:45 --> Language Class Initialized
ERROR - 2020-02-10 07:16:45 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 07:16:46 --> Config Class Initialized
INFO - 2020-02-10 07:16:46 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:16:46 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:16:46 --> Utf8 Class Initialized
INFO - 2020-02-10 07:16:46 --> URI Class Initialized
INFO - 2020-02-10 07:16:46 --> Router Class Initialized
INFO - 2020-02-10 07:16:46 --> Output Class Initialized
INFO - 2020-02-10 07:16:46 --> Security Class Initialized
DEBUG - 2020-02-10 07:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:16:46 --> Input Class Initialized
INFO - 2020-02-10 07:16:46 --> Language Class Initialized
ERROR - 2020-02-10 07:16:46 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 07:18:53 --> Config Class Initialized
INFO - 2020-02-10 07:18:53 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:18:53 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:18:53 --> Utf8 Class Initialized
INFO - 2020-02-10 07:18:54 --> URI Class Initialized
INFO - 2020-02-10 07:18:54 --> Router Class Initialized
INFO - 2020-02-10 07:18:54 --> Output Class Initialized
INFO - 2020-02-10 07:18:54 --> Security Class Initialized
DEBUG - 2020-02-10 07:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:18:54 --> Input Class Initialized
INFO - 2020-02-10 07:18:54 --> Language Class Initialized
INFO - 2020-02-10 07:18:54 --> Loader Class Initialized
INFO - 2020-02-10 07:18:54 --> Helper loaded: url_helper
INFO - 2020-02-10 07:18:54 --> Database Driver Class Initialized
DEBUG - 2020-02-10 07:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:18:55 --> Controller Class Initialized
INFO - 2020-02-10 07:18:55 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:18:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:18:55 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:18:55 --> Helper loaded: form_helper
INFO - 2020-02-10 07:18:55 --> Form Validation Class Initialized
INFO - 2020-02-10 07:18:55 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 07:18:55 --> Final output sent to browser
INFO - 2020-02-10 07:18:55 --> Config Class Initialized
INFO - 2020-02-10 07:18:55 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:18:55 --> Total execution time: 2.0968
INFO - 2020-02-10 07:18:55 --> Config Class Initialized
INFO - 2020-02-10 07:18:55 --> Config Class Initialized
INFO - 2020-02-10 07:18:55 --> Config Class Initialized
INFO - 2020-02-10 07:18:55 --> Config Class Initialized
INFO - 2020-02-10 07:18:55 --> Hooks Class Initialized
INFO - 2020-02-10 07:18:55 --> Hooks Class Initialized
INFO - 2020-02-10 07:18:55 --> Hooks Class Initialized
INFO - 2020-02-10 07:18:55 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:18:55 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:18:56 --> Config Class Initialized
INFO - 2020-02-10 07:18:56 --> Utf8 Class Initialized
DEBUG - 2020-02-10 07:18:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:18:56 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:18:56 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:18:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:18:56 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:18:56 --> Utf8 Class Initialized
INFO - 2020-02-10 07:18:56 --> Utf8 Class Initialized
INFO - 2020-02-10 07:18:56 --> Utf8 Class Initialized
INFO - 2020-02-10 07:18:56 --> Utf8 Class Initialized
INFO - 2020-02-10 07:18:56 --> URI Class Initialized
DEBUG - 2020-02-10 07:18:56 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:18:56 --> Utf8 Class Initialized
INFO - 2020-02-10 07:18:56 --> URI Class Initialized
INFO - 2020-02-10 07:18:56 --> Router Class Initialized
INFO - 2020-02-10 07:18:56 --> URI Class Initialized
INFO - 2020-02-10 07:18:56 --> URI Class Initialized
INFO - 2020-02-10 07:18:56 --> URI Class Initialized
INFO - 2020-02-10 07:18:56 --> URI Class Initialized
INFO - 2020-02-10 07:18:56 --> Router Class Initialized
INFO - 2020-02-10 07:18:56 --> Output Class Initialized
INFO - 2020-02-10 07:18:56 --> Router Class Initialized
INFO - 2020-02-10 07:18:56 --> Router Class Initialized
INFO - 2020-02-10 07:18:56 --> Router Class Initialized
INFO - 2020-02-10 07:18:56 --> Security Class Initialized
INFO - 2020-02-10 07:18:56 --> Output Class Initialized
INFO - 2020-02-10 07:18:56 --> Output Class Initialized
INFO - 2020-02-10 07:18:56 --> Output Class Initialized
INFO - 2020-02-10 07:18:56 --> Router Class Initialized
INFO - 2020-02-10 07:18:56 --> Output Class Initialized
DEBUG - 2020-02-10 07:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:18:56 --> Security Class Initialized
INFO - 2020-02-10 07:18:56 --> Security Class Initialized
INFO - 2020-02-10 07:18:56 --> Output Class Initialized
INFO - 2020-02-10 07:18:56 --> Security Class Initialized
INFO - 2020-02-10 07:18:56 --> Security Class Initialized
INFO - 2020-02-10 07:18:56 --> Input Class Initialized
DEBUG - 2020-02-10 07:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:18:56 --> Security Class Initialized
DEBUG - 2020-02-10 07:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:18:56 --> Input Class Initialized
INFO - 2020-02-10 07:18:56 --> Input Class Initialized
INFO - 2020-02-10 07:18:56 --> Input Class Initialized
INFO - 2020-02-10 07:18:56 --> Input Class Initialized
INFO - 2020-02-10 07:18:56 --> Language Class Initialized
DEBUG - 2020-02-10 07:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:18:56 --> Language Class Initialized
INFO - 2020-02-10 07:18:56 --> Language Class Initialized
INFO - 2020-02-10 07:18:56 --> Language Class Initialized
INFO - 2020-02-10 07:18:56 --> Input Class Initialized
INFO - 2020-02-10 07:18:56 --> Language Class Initialized
ERROR - 2020-02-10 07:18:56 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-10 07:18:56 --> Language Class Initialized
INFO - 2020-02-10 07:18:56 --> Loader Class Initialized
ERROR - 2020-02-10 07:18:56 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-10 07:18:56 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-10 07:18:56 --> Config Class Initialized
INFO - 2020-02-10 07:18:56 --> Hooks Class Initialized
ERROR - 2020-02-10 07:18:56 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 07:18:56 --> Loader Class Initialized
INFO - 2020-02-10 07:18:56 --> Helper loaded: url_helper
INFO - 2020-02-10 07:18:56 --> Config Class Initialized
INFO - 2020-02-10 07:18:56 --> Config Class Initialized
INFO - 2020-02-10 07:18:56 --> Hooks Class Initialized
INFO - 2020-02-10 07:18:56 --> Hooks Class Initialized
INFO - 2020-02-10 07:18:56 --> Helper loaded: url_helper
DEBUG - 2020-02-10 07:18:56 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:18:56 --> Database Driver Class Initialized
INFO - 2020-02-10 07:18:56 --> Config Class Initialized
INFO - 2020-02-10 07:18:56 --> Hooks Class Initialized
INFO - 2020-02-10 07:18:56 --> Utf8 Class Initialized
DEBUG - 2020-02-10 07:18:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:18:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:18:56 --> Database Driver Class Initialized
INFO - 2020-02-10 07:18:56 --> Utf8 Class Initialized
INFO - 2020-02-10 07:18:56 --> Utf8 Class Initialized
INFO - 2020-02-10 07:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:18:56 --> URI Class Initialized
DEBUG - 2020-02-10 07:18:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:18:56 --> Controller Class Initialized
INFO - 2020-02-10 07:18:56 --> Utf8 Class Initialized
INFO - 2020-02-10 07:18:56 --> URI Class Initialized
INFO - 2020-02-10 07:18:56 --> URI Class Initialized
INFO - 2020-02-10 07:18:56 --> Router Class Initialized
INFO - 2020-02-10 07:18:56 --> URI Class Initialized
INFO - 2020-02-10 07:18:56 --> Router Class Initialized
INFO - 2020-02-10 07:18:56 --> Router Class Initialized
INFO - 2020-02-10 07:18:56 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:18:56 --> Output Class Initialized
INFO - 2020-02-10 07:18:56 --> Router Class Initialized
INFO - 2020-02-10 07:18:56 --> Output Class Initialized
INFO - 2020-02-10 07:18:56 --> Output Class Initialized
INFO - 2020-02-10 07:18:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:18:56 --> Security Class Initialized
INFO - 2020-02-10 07:18:56 --> Model "M_pesan" initialized
DEBUG - 2020-02-10 07:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:18:56 --> Security Class Initialized
INFO - 2020-02-10 07:18:56 --> Security Class Initialized
INFO - 2020-02-10 07:18:56 --> Output Class Initialized
INFO - 2020-02-10 07:18:56 --> Input Class Initialized
INFO - 2020-02-10 07:18:56 --> Security Class Initialized
DEBUG - 2020-02-10 07:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:18:56 --> Helper loaded: form_helper
INFO - 2020-02-10 07:18:56 --> Input Class Initialized
INFO - 2020-02-10 07:18:56 --> Input Class Initialized
INFO - 2020-02-10 07:18:56 --> Form Validation Class Initialized
INFO - 2020-02-10 07:18:56 --> Language Class Initialized
DEBUG - 2020-02-10 07:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:18:56 --> Input Class Initialized
INFO - 2020-02-10 07:18:56 --> Language Class Initialized
INFO - 2020-02-10 07:18:56 --> Language Class Initialized
ERROR - 2020-02-10 07:18:56 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-10 07:18:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 07:18:56 --> Language Class Initialized
ERROR - 2020-02-10 07:18:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-10 07:18:56 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 07:18:56 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 07:18:56 --> Config Class Initialized
INFO - 2020-02-10 07:18:56 --> Hooks Class Initialized
INFO - 2020-02-10 07:18:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-10 07:18:56 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 07:18:56 --> Config Class Initialized
INFO - 2020-02-10 07:18:56 --> Config Class Initialized
INFO - 2020-02-10 07:18:56 --> Hooks Class Initialized
INFO - 2020-02-10 07:18:56 --> Final output sent to browser
INFO - 2020-02-10 07:18:56 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:18:56 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:18:56 --> Utf8 Class Initialized
DEBUG - 2020-02-10 07:18:56 --> Total execution time: 0.8663
DEBUG - 2020-02-10 07:18:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:18:56 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:18:56 --> Utf8 Class Initialized
INFO - 2020-02-10 07:18:56 --> Utf8 Class Initialized
INFO - 2020-02-10 07:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:18:56 --> URI Class Initialized
INFO - 2020-02-10 07:18:56 --> Controller Class Initialized
INFO - 2020-02-10 07:18:56 --> URI Class Initialized
INFO - 2020-02-10 07:18:56 --> URI Class Initialized
INFO - 2020-02-10 07:18:56 --> Router Class Initialized
INFO - 2020-02-10 07:18:56 --> Router Class Initialized
INFO - 2020-02-10 07:18:56 --> Router Class Initialized
INFO - 2020-02-10 07:18:56 --> Output Class Initialized
INFO - 2020-02-10 07:18:56 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:18:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:18:56 --> Security Class Initialized
INFO - 2020-02-10 07:18:56 --> Output Class Initialized
INFO - 2020-02-10 07:18:56 --> Output Class Initialized
INFO - 2020-02-10 07:18:57 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:18:57 --> Security Class Initialized
INFO - 2020-02-10 07:18:57 --> Security Class Initialized
DEBUG - 2020-02-10 07:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:18:57 --> Input Class Initialized
DEBUG - 2020-02-10 07:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:18:57 --> Helper loaded: form_helper
INFO - 2020-02-10 07:18:57 --> Form Validation Class Initialized
INFO - 2020-02-10 07:18:57 --> Input Class Initialized
INFO - 2020-02-10 07:18:57 --> Input Class Initialized
INFO - 2020-02-10 07:18:57 --> Language Class Initialized
INFO - 2020-02-10 07:18:57 --> Language Class Initialized
INFO - 2020-02-10 07:18:57 --> Language Class Initialized
ERROR - 2020-02-10 07:18:57 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-10 07:18:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 07:18:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-10 07:18:57 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-10 07:18:57 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 07:18:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 07:18:57 --> Config Class Initialized
INFO - 2020-02-10 07:18:57 --> Hooks Class Initialized
INFO - 2020-02-10 07:18:57 --> Final output sent to browser
DEBUG - 2020-02-10 07:18:57 --> Total execution time: 1.2551
DEBUG - 2020-02-10 07:18:57 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:18:57 --> Utf8 Class Initialized
INFO - 2020-02-10 07:18:57 --> URI Class Initialized
INFO - 2020-02-10 07:18:57 --> Router Class Initialized
INFO - 2020-02-10 07:18:57 --> Output Class Initialized
INFO - 2020-02-10 07:18:57 --> Security Class Initialized
DEBUG - 2020-02-10 07:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:18:57 --> Input Class Initialized
INFO - 2020-02-10 07:18:57 --> Language Class Initialized
ERROR - 2020-02-10 07:18:57 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 07:19:37 --> Config Class Initialized
INFO - 2020-02-10 07:19:37 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:37 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:37 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:37 --> URI Class Initialized
INFO - 2020-02-10 07:19:37 --> Router Class Initialized
INFO - 2020-02-10 07:19:38 --> Output Class Initialized
INFO - 2020-02-10 07:19:38 --> Security Class Initialized
DEBUG - 2020-02-10 07:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:38 --> Input Class Initialized
INFO - 2020-02-10 07:19:38 --> Language Class Initialized
INFO - 2020-02-10 07:19:38 --> Loader Class Initialized
INFO - 2020-02-10 07:19:38 --> Helper loaded: url_helper
INFO - 2020-02-10 07:19:38 --> Database Driver Class Initialized
DEBUG - 2020-02-10 07:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:19:38 --> Controller Class Initialized
INFO - 2020-02-10 07:19:38 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:19:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:19:38 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:19:38 --> Helper loaded: form_helper
INFO - 2020-02-10 07:19:38 --> Form Validation Class Initialized
INFO - 2020-02-10 07:19:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 07:19:38 --> Final output sent to browser
INFO - 2020-02-10 07:19:38 --> Config Class Initialized
INFO - 2020-02-10 07:19:38 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:38 --> Total execution time: 1.1478
INFO - 2020-02-10 07:19:38 --> Config Class Initialized
INFO - 2020-02-10 07:19:38 --> Config Class Initialized
INFO - 2020-02-10 07:19:38 --> Config Class Initialized
INFO - 2020-02-10 07:19:38 --> Config Class Initialized
INFO - 2020-02-10 07:19:38 --> Hooks Class Initialized
INFO - 2020-02-10 07:19:38 --> Hooks Class Initialized
INFO - 2020-02-10 07:19:38 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:38 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:38 --> Hooks Class Initialized
INFO - 2020-02-10 07:19:38 --> Config Class Initialized
INFO - 2020-02-10 07:19:38 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:38 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:19:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:19:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:19:38 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:38 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:38 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:38 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:38 --> URI Class Initialized
INFO - 2020-02-10 07:19:38 --> Utf8 Class Initialized
DEBUG - 2020-02-10 07:19:38 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:38 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:38 --> Router Class Initialized
INFO - 2020-02-10 07:19:38 --> URI Class Initialized
INFO - 2020-02-10 07:19:38 --> URI Class Initialized
INFO - 2020-02-10 07:19:38 --> URI Class Initialized
INFO - 2020-02-10 07:19:39 --> URI Class Initialized
INFO - 2020-02-10 07:19:39 --> Router Class Initialized
INFO - 2020-02-10 07:19:39 --> Router Class Initialized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> URI Class Initialized
INFO - 2020-02-10 07:19:39 --> Router Class Initialized
INFO - 2020-02-10 07:19:39 --> Router Class Initialized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
INFO - 2020-02-10 07:19:39 --> Router Class Initialized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
INFO - 2020-02-10 07:19:39 --> Language Class Initialized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
INFO - 2020-02-10 07:19:39 --> Language Class Initialized
INFO - 2020-02-10 07:19:39 --> Language Class Initialized
INFO - 2020-02-10 07:19:39 --> Language Class Initialized
ERROR - 2020-02-10 07:19:39 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-10 07:19:39 --> Language Class Initialized
INFO - 2020-02-10 07:19:39 --> Language Class Initialized
ERROR - 2020-02-10 07:19:39 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-10 07:19:39 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 07:19:39 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-10 07:19:39 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 07:19:39 --> Config Class Initialized
INFO - 2020-02-10 07:19:39 --> Hooks Class Initialized
ERROR - 2020-02-10 07:19:39 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 07:19:39 --> Config Class Initialized
INFO - 2020-02-10 07:19:39 --> Config Class Initialized
INFO - 2020-02-10 07:19:39 --> Config Class Initialized
INFO - 2020-02-10 07:19:39 --> Config Class Initialized
INFO - 2020-02-10 07:19:39 --> Hooks Class Initialized
INFO - 2020-02-10 07:19:39 --> Hooks Class Initialized
INFO - 2020-02-10 07:19:39 --> Hooks Class Initialized
INFO - 2020-02-10 07:19:39 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:39 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:39 --> Config Class Initialized
INFO - 2020-02-10 07:19:39 --> Hooks Class Initialized
INFO - 2020-02-10 07:19:39 --> Utf8 Class Initialized
DEBUG - 2020-02-10 07:19:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:19:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:19:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:19:39 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:39 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:39 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:39 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:39 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:39 --> URI Class Initialized
DEBUG - 2020-02-10 07:19:39 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:39 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:39 --> URI Class Initialized
INFO - 2020-02-10 07:19:39 --> URI Class Initialized
INFO - 2020-02-10 07:19:39 --> Router Class Initialized
INFO - 2020-02-10 07:19:39 --> URI Class Initialized
INFO - 2020-02-10 07:19:39 --> URI Class Initialized
INFO - 2020-02-10 07:19:39 --> Router Class Initialized
INFO - 2020-02-10 07:19:39 --> URI Class Initialized
INFO - 2020-02-10 07:19:39 --> Router Class Initialized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> Router Class Initialized
INFO - 2020-02-10 07:19:39 --> Router Class Initialized
INFO - 2020-02-10 07:19:39 --> Router Class Initialized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
INFO - 2020-02-10 07:19:39 --> Language Class Initialized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:39 --> Language Class Initialized
INFO - 2020-02-10 07:19:39 --> Language Class Initialized
INFO - 2020-02-10 07:19:39 --> Language Class Initialized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
INFO - 2020-02-10 07:19:39 --> Language Class Initialized
INFO - 2020-02-10 07:19:39 --> Loader Class Initialized
ERROR - 2020-02-10 07:19:39 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 07:19:39 --> Helper loaded: url_helper
INFO - 2020-02-10 07:19:39 --> Language Class Initialized
ERROR - 2020-02-10 07:19:39 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 07:19:39 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-10 07:19:39 --> Loader Class Initialized
INFO - 2020-02-10 07:19:39 --> Helper loaded: url_helper
ERROR - 2020-02-10 07:19:39 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 07:19:39 --> Database Driver Class Initialized
INFO - 2020-02-10 07:19:39 --> Config Class Initialized
INFO - 2020-02-10 07:19:39 --> Config Class Initialized
INFO - 2020-02-10 07:19:39 --> Hooks Class Initialized
INFO - 2020-02-10 07:19:39 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:19:39 --> Database Driver Class Initialized
INFO - 2020-02-10 07:19:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 07:19:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 07:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-10 07:19:39 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:39 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:39 --> Controller Class Initialized
INFO - 2020-02-10 07:19:39 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:39 --> URI Class Initialized
INFO - 2020-02-10 07:19:39 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:19:39 --> URI Class Initialized
INFO - 2020-02-10 07:19:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:19:39 --> Router Class Initialized
INFO - 2020-02-10 07:19:39 --> Router Class Initialized
INFO - 2020-02-10 07:19:39 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> Output Class Initialized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
INFO - 2020-02-10 07:19:39 --> Security Class Initialized
INFO - 2020-02-10 07:19:39 --> Helper loaded: form_helper
INFO - 2020-02-10 07:19:39 --> Form Validation Class Initialized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 07:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
INFO - 2020-02-10 07:19:39 --> Input Class Initialized
ERROR - 2020-02-10 07:19:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 07:19:40 --> Language Class Initialized
INFO - 2020-02-10 07:19:40 --> Language Class Initialized
ERROR - 2020-02-10 07:19:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 07:19:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-10 07:19:40 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-10 07:19:40 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 07:19:40 --> Final output sent to browser
INFO - 2020-02-10 07:19:40 --> Config Class Initialized
INFO - 2020-02-10 07:19:40 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:40 --> Total execution time: 0.8423
INFO - 2020-02-10 07:19:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 07:19:40 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:40 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:40 --> Controller Class Initialized
INFO - 2020-02-10 07:19:40 --> URI Class Initialized
INFO - 2020-02-10 07:19:40 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:19:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:19:40 --> Router Class Initialized
INFO - 2020-02-10 07:19:40 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:19:40 --> Output Class Initialized
INFO - 2020-02-10 07:19:40 --> Security Class Initialized
INFO - 2020-02-10 07:19:40 --> Helper loaded: form_helper
INFO - 2020-02-10 07:19:40 --> Form Validation Class Initialized
DEBUG - 2020-02-10 07:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:40 --> Input Class Initialized
ERROR - 2020-02-10 07:19:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 07:19:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 07:19:40 --> Language Class Initialized
INFO - 2020-02-10 07:19:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-10 07:19:40 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-10 07:19:40 --> Final output sent to browser
INFO - 2020-02-10 07:19:40 --> Config Class Initialized
DEBUG - 2020-02-10 07:19:40 --> Total execution time: 1.1389
INFO - 2020-02-10 07:19:40 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:40 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:40 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:40 --> URI Class Initialized
INFO - 2020-02-10 07:19:40 --> Router Class Initialized
INFO - 2020-02-10 07:19:40 --> Output Class Initialized
INFO - 2020-02-10 07:19:40 --> Security Class Initialized
DEBUG - 2020-02-10 07:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:40 --> Input Class Initialized
INFO - 2020-02-10 07:19:40 --> Language Class Initialized
ERROR - 2020-02-10 07:19:40 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 07:19:40 --> Config Class Initialized
INFO - 2020-02-10 07:19:40 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:40 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:40 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:40 --> URI Class Initialized
INFO - 2020-02-10 07:19:40 --> Router Class Initialized
INFO - 2020-02-10 07:19:41 --> Output Class Initialized
INFO - 2020-02-10 07:19:41 --> Security Class Initialized
DEBUG - 2020-02-10 07:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:41 --> Input Class Initialized
INFO - 2020-02-10 07:19:41 --> Language Class Initialized
ERROR - 2020-02-10 07:19:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 07:19:41 --> Config Class Initialized
INFO - 2020-02-10 07:19:41 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:41 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:41 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:41 --> URI Class Initialized
INFO - 2020-02-10 07:19:41 --> Router Class Initialized
INFO - 2020-02-10 07:19:41 --> Output Class Initialized
INFO - 2020-02-10 07:19:41 --> Security Class Initialized
DEBUG - 2020-02-10 07:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:41 --> Input Class Initialized
INFO - 2020-02-10 07:19:41 --> Language Class Initialized
ERROR - 2020-02-10 07:19:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 07:19:41 --> Config Class Initialized
INFO - 2020-02-10 07:19:41 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:41 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:41 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:41 --> URI Class Initialized
INFO - 2020-02-10 07:19:41 --> Router Class Initialized
INFO - 2020-02-10 07:19:41 --> Output Class Initialized
INFO - 2020-02-10 07:19:41 --> Security Class Initialized
DEBUG - 2020-02-10 07:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:41 --> Input Class Initialized
INFO - 2020-02-10 07:19:41 --> Language Class Initialized
ERROR - 2020-02-10 07:19:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 07:19:41 --> Config Class Initialized
INFO - 2020-02-10 07:19:41 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:42 --> URI Class Initialized
INFO - 2020-02-10 07:19:42 --> Router Class Initialized
INFO - 2020-02-10 07:19:42 --> Output Class Initialized
INFO - 2020-02-10 07:19:42 --> Security Class Initialized
DEBUG - 2020-02-10 07:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:42 --> Input Class Initialized
INFO - 2020-02-10 07:19:42 --> Language Class Initialized
ERROR - 2020-02-10 07:19:42 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 07:19:42 --> Config Class Initialized
INFO - 2020-02-10 07:19:42 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:42 --> URI Class Initialized
INFO - 2020-02-10 07:19:42 --> Router Class Initialized
INFO - 2020-02-10 07:19:42 --> Output Class Initialized
INFO - 2020-02-10 07:19:42 --> Security Class Initialized
DEBUG - 2020-02-10 07:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:42 --> Input Class Initialized
INFO - 2020-02-10 07:19:42 --> Language Class Initialized
ERROR - 2020-02-10 07:19:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 07:19:42 --> Config Class Initialized
INFO - 2020-02-10 07:19:42 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:42 --> URI Class Initialized
INFO - 2020-02-10 07:19:42 --> Router Class Initialized
INFO - 2020-02-10 07:19:42 --> Output Class Initialized
INFO - 2020-02-10 07:19:42 --> Security Class Initialized
DEBUG - 2020-02-10 07:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:42 --> Input Class Initialized
INFO - 2020-02-10 07:19:43 --> Language Class Initialized
ERROR - 2020-02-10 07:19:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 07:19:43 --> Config Class Initialized
INFO - 2020-02-10 07:19:43 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:19:43 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:19:43 --> Utf8 Class Initialized
INFO - 2020-02-10 07:19:43 --> URI Class Initialized
INFO - 2020-02-10 07:19:43 --> Router Class Initialized
INFO - 2020-02-10 07:19:43 --> Output Class Initialized
INFO - 2020-02-10 07:19:43 --> Security Class Initialized
DEBUG - 2020-02-10 07:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:19:43 --> Input Class Initialized
INFO - 2020-02-10 07:19:43 --> Language Class Initialized
ERROR - 2020-02-10 07:19:43 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 07:22:42 --> Config Class Initialized
INFO - 2020-02-10 07:22:42 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:22:42 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:22:42 --> Utf8 Class Initialized
INFO - 2020-02-10 07:22:42 --> URI Class Initialized
INFO - 2020-02-10 07:22:42 --> Router Class Initialized
INFO - 2020-02-10 07:22:42 --> Output Class Initialized
INFO - 2020-02-10 07:22:42 --> Security Class Initialized
DEBUG - 2020-02-10 07:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:22:42 --> Input Class Initialized
INFO - 2020-02-10 07:22:42 --> Language Class Initialized
INFO - 2020-02-10 07:22:42 --> Loader Class Initialized
INFO - 2020-02-10 07:22:42 --> Helper loaded: url_helper
INFO - 2020-02-10 07:22:42 --> Database Driver Class Initialized
DEBUG - 2020-02-10 07:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:22:42 --> Controller Class Initialized
INFO - 2020-02-10 07:22:42 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:22:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:22:42 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:22:42 --> Helper loaded: form_helper
INFO - 2020-02-10 07:22:42 --> Form Validation Class Initialized
INFO - 2020-02-10 07:22:43 --> Final output sent to browser
DEBUG - 2020-02-10 07:22:43 --> Total execution time: 0.9298
INFO - 2020-02-10 07:47:38 --> Config Class Initialized
INFO - 2020-02-10 07:47:38 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:47:38 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:47:38 --> Utf8 Class Initialized
INFO - 2020-02-10 07:47:38 --> URI Class Initialized
INFO - 2020-02-10 07:47:38 --> Router Class Initialized
INFO - 2020-02-10 07:47:38 --> Output Class Initialized
INFO - 2020-02-10 07:47:38 --> Security Class Initialized
DEBUG - 2020-02-10 07:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:47:38 --> Input Class Initialized
INFO - 2020-02-10 07:47:38 --> Language Class Initialized
INFO - 2020-02-10 07:47:39 --> Loader Class Initialized
INFO - 2020-02-10 07:47:39 --> Helper loaded: url_helper
INFO - 2020-02-10 07:47:39 --> Database Driver Class Initialized
DEBUG - 2020-02-10 07:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:47:39 --> Controller Class Initialized
INFO - 2020-02-10 07:47:39 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:47:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:47:39 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:47:39 --> Helper loaded: form_helper
INFO - 2020-02-10 07:47:39 --> Form Validation Class Initialized
INFO - 2020-02-10 07:47:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 07:47:39 --> Final output sent to browser
DEBUG - 2020-02-10 07:47:39 --> Total execution time: 0.9130
INFO - 2020-02-10 07:47:44 --> Config Class Initialized
INFO - 2020-02-10 07:47:44 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:47:44 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:47:44 --> Utf8 Class Initialized
INFO - 2020-02-10 07:47:44 --> URI Class Initialized
INFO - 2020-02-10 07:47:44 --> Router Class Initialized
INFO - 2020-02-10 07:47:44 --> Output Class Initialized
INFO - 2020-02-10 07:47:44 --> Security Class Initialized
DEBUG - 2020-02-10 07:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:47:44 --> Input Class Initialized
INFO - 2020-02-10 07:47:44 --> Language Class Initialized
INFO - 2020-02-10 07:47:44 --> Loader Class Initialized
INFO - 2020-02-10 07:47:44 --> Helper loaded: url_helper
INFO - 2020-02-10 07:47:45 --> Database Driver Class Initialized
DEBUG - 2020-02-10 07:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:47:45 --> Controller Class Initialized
INFO - 2020-02-10 07:47:45 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:47:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:47:45 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:47:45 --> Helper loaded: form_helper
INFO - 2020-02-10 07:47:45 --> Form Validation Class Initialized
ERROR - 2020-02-10 07:47:45 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 27
INFO - 2020-02-10 07:48:48 --> Config Class Initialized
INFO - 2020-02-10 07:48:49 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:48:49 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:48:49 --> Utf8 Class Initialized
INFO - 2020-02-10 07:48:49 --> URI Class Initialized
INFO - 2020-02-10 07:48:50 --> Router Class Initialized
INFO - 2020-02-10 07:48:50 --> Output Class Initialized
INFO - 2020-02-10 07:48:50 --> Security Class Initialized
DEBUG - 2020-02-10 07:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:48:51 --> Input Class Initialized
INFO - 2020-02-10 07:48:51 --> Language Class Initialized
INFO - 2020-02-10 07:48:51 --> Loader Class Initialized
INFO - 2020-02-10 07:48:51 --> Helper loaded: url_helper
INFO - 2020-02-10 07:48:51 --> Database Driver Class Initialized
DEBUG - 2020-02-10 07:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:48:52 --> Controller Class Initialized
INFO - 2020-02-10 07:48:52 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:48:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:48:53 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:48:53 --> Helper loaded: form_helper
INFO - 2020-02-10 07:48:53 --> Form Validation Class Initialized
ERROR - 2020-02-10 07:48:53 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 27
INFO - 2020-02-10 07:50:01 --> Config Class Initialized
INFO - 2020-02-10 07:50:01 --> Hooks Class Initialized
DEBUG - 2020-02-10 07:50:01 --> UTF-8 Support Enabled
INFO - 2020-02-10 07:50:01 --> Utf8 Class Initialized
INFO - 2020-02-10 07:50:02 --> URI Class Initialized
INFO - 2020-02-10 07:50:02 --> Router Class Initialized
INFO - 2020-02-10 07:50:02 --> Output Class Initialized
INFO - 2020-02-10 07:50:02 --> Security Class Initialized
DEBUG - 2020-02-10 07:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 07:50:03 --> Input Class Initialized
INFO - 2020-02-10 07:50:03 --> Language Class Initialized
INFO - 2020-02-10 07:50:03 --> Loader Class Initialized
INFO - 2020-02-10 07:50:03 --> Helper loaded: url_helper
INFO - 2020-02-10 07:50:03 --> Database Driver Class Initialized
DEBUG - 2020-02-10 07:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 07:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 07:50:04 --> Controller Class Initialized
INFO - 2020-02-10 07:50:04 --> Model "M_tiket" initialized
INFO - 2020-02-10 07:50:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 07:50:05 --> Model "M_pesan" initialized
INFO - 2020-02-10 07:50:05 --> Helper loaded: form_helper
INFO - 2020-02-10 07:50:05 --> Form Validation Class Initialized
INFO - 2020-02-10 07:50:06 --> Final output sent to browser
DEBUG - 2020-02-10 07:50:06 --> Total execution time: 4.7136
INFO - 2020-02-10 09:31:42 --> Config Class Initialized
INFO - 2020-02-10 09:31:43 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:31:43 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:31:43 --> Utf8 Class Initialized
INFO - 2020-02-10 09:31:43 --> URI Class Initialized
INFO - 2020-02-10 09:31:43 --> Router Class Initialized
INFO - 2020-02-10 09:31:43 --> Output Class Initialized
INFO - 2020-02-10 09:31:43 --> Security Class Initialized
DEBUG - 2020-02-10 09:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:31:43 --> Input Class Initialized
INFO - 2020-02-10 09:31:43 --> Language Class Initialized
INFO - 2020-02-10 09:31:43 --> Loader Class Initialized
INFO - 2020-02-10 09:31:43 --> Helper loaded: url_helper
INFO - 2020-02-10 09:31:44 --> Database Driver Class Initialized
DEBUG - 2020-02-10 09:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 09:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 09:31:44 --> Controller Class Initialized
INFO - 2020-02-10 09:31:44 --> Model "M_tiket" initialized
INFO - 2020-02-10 09:31:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 09:31:44 --> Model "M_pesan" initialized
INFO - 2020-02-10 09:31:44 --> Helper loaded: form_helper
INFO - 2020-02-10 09:31:44 --> Form Validation Class Initialized
INFO - 2020-02-10 09:31:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 09:31:44 --> Final output sent to browser
DEBUG - 2020-02-10 09:31:44 --> Total execution time: 1.6417
INFO - 2020-02-10 09:31:44 --> Config Class Initialized
INFO - 2020-02-10 09:31:44 --> Hooks Class Initialized
INFO - 2020-02-10 09:31:44 --> Config Class Initialized
INFO - 2020-02-10 09:31:44 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:31:44 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:31:44 --> Utf8 Class Initialized
DEBUG - 2020-02-10 09:31:44 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:31:44 --> URI Class Initialized
INFO - 2020-02-10 09:31:44 --> Utf8 Class Initialized
INFO - 2020-02-10 09:31:44 --> URI Class Initialized
INFO - 2020-02-10 09:31:44 --> Router Class Initialized
INFO - 2020-02-10 09:31:44 --> Router Class Initialized
INFO - 2020-02-10 09:31:44 --> Output Class Initialized
INFO - 2020-02-10 09:31:44 --> Security Class Initialized
INFO - 2020-02-10 09:31:44 --> Output Class Initialized
DEBUG - 2020-02-10 09:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:31:44 --> Security Class Initialized
INFO - 2020-02-10 09:31:45 --> Input Class Initialized
DEBUG - 2020-02-10 09:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:31:45 --> Input Class Initialized
INFO - 2020-02-10 09:31:45 --> Language Class Initialized
INFO - 2020-02-10 09:31:45 --> Language Class Initialized
INFO - 2020-02-10 09:31:45 --> Loader Class Initialized
INFO - 2020-02-10 09:31:45 --> Helper loaded: url_helper
INFO - 2020-02-10 09:31:45 --> Loader Class Initialized
INFO - 2020-02-10 09:31:45 --> Helper loaded: url_helper
INFO - 2020-02-10 09:31:45 --> Database Driver Class Initialized
DEBUG - 2020-02-10 09:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 09:31:45 --> Database Driver Class Initialized
INFO - 2020-02-10 09:31:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 09:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 09:31:45 --> Controller Class Initialized
INFO - 2020-02-10 09:31:45 --> Model "M_tiket" initialized
INFO - 2020-02-10 09:31:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 09:31:45 --> Model "M_pesan" initialized
INFO - 2020-02-10 09:31:45 --> Helper loaded: form_helper
INFO - 2020-02-10 09:31:45 --> Form Validation Class Initialized
ERROR - 2020-02-10 09:31:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 09:31:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 09:31:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 09:31:45 --> Final output sent to browser
DEBUG - 2020-02-10 09:31:45 --> Total execution time: 0.9102
INFO - 2020-02-10 09:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 09:31:45 --> Controller Class Initialized
INFO - 2020-02-10 09:31:45 --> Model "M_tiket" initialized
INFO - 2020-02-10 09:31:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 09:31:45 --> Model "M_pesan" initialized
INFO - 2020-02-10 09:31:45 --> Helper loaded: form_helper
INFO - 2020-02-10 09:31:45 --> Form Validation Class Initialized
ERROR - 2020-02-10 09:31:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 09:31:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 09:31:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 09:31:45 --> Final output sent to browser
DEBUG - 2020-02-10 09:31:45 --> Total execution time: 0.9566
INFO - 2020-02-10 09:46:25 --> Config Class Initialized
INFO - 2020-02-10 09:46:25 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:46:25 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:25 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:25 --> URI Class Initialized
DEBUG - 2020-02-10 09:46:25 --> No URI present. Default controller set.
INFO - 2020-02-10 09:46:26 --> Router Class Initialized
INFO - 2020-02-10 09:46:26 --> Output Class Initialized
INFO - 2020-02-10 09:46:26 --> Security Class Initialized
DEBUG - 2020-02-10 09:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:26 --> Input Class Initialized
INFO - 2020-02-10 09:46:26 --> Language Class Initialized
INFO - 2020-02-10 09:46:26 --> Loader Class Initialized
INFO - 2020-02-10 09:46:26 --> Helper loaded: url_helper
INFO - 2020-02-10 09:46:26 --> Database Driver Class Initialized
DEBUG - 2020-02-10 09:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 09:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 09:46:27 --> Controller Class Initialized
INFO - 2020-02-10 09:46:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-10 09:46:27 --> Pagination Class Initialized
INFO - 2020-02-10 09:46:27 --> Model "M_show" initialized
INFO - 2020-02-10 09:46:27 --> Helper loaded: form_helper
INFO - 2020-02-10 09:46:27 --> Form Validation Class Initialized
INFO - 2020-02-10 09:46:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-10 09:46:28 --> Final output sent to browser
DEBUG - 2020-02-10 09:46:28 --> Total execution time: 2.4012
INFO - 2020-02-10 09:46:31 --> Config Class Initialized
INFO - 2020-02-10 09:46:31 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:46:31 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:31 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:31 --> URI Class Initialized
INFO - 2020-02-10 09:46:31 --> Router Class Initialized
INFO - 2020-02-10 09:46:31 --> Output Class Initialized
INFO - 2020-02-10 09:46:31 --> Security Class Initialized
DEBUG - 2020-02-10 09:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:31 --> Input Class Initialized
INFO - 2020-02-10 09:46:31 --> Language Class Initialized
INFO - 2020-02-10 09:46:32 --> Loader Class Initialized
INFO - 2020-02-10 09:46:32 --> Helper loaded: url_helper
INFO - 2020-02-10 09:46:32 --> Database Driver Class Initialized
DEBUG - 2020-02-10 09:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 09:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 09:46:32 --> Controller Class Initialized
INFO - 2020-02-10 09:46:32 --> Model "M_tiket" initialized
INFO - 2020-02-10 09:46:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 09:46:32 --> Model "M_pesan" initialized
INFO - 2020-02-10 09:46:32 --> Helper loaded: form_helper
INFO - 2020-02-10 09:46:32 --> Form Validation Class Initialized
INFO - 2020-02-10 09:46:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 09:46:32 --> Final output sent to browser
INFO - 2020-02-10 09:46:32 --> Config Class Initialized
INFO - 2020-02-10 09:46:32 --> Config Class Initialized
INFO - 2020-02-10 09:46:32 --> Hooks Class Initialized
INFO - 2020-02-10 09:46:32 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:46:32 --> Total execution time: 1.2343
INFO - 2020-02-10 09:46:32 --> Config Class Initialized
INFO - 2020-02-10 09:46:32 --> Config Class Initialized
INFO - 2020-02-10 09:46:32 --> Config Class Initialized
INFO - 2020-02-10 09:46:32 --> Hooks Class Initialized
INFO - 2020-02-10 09:46:32 --> Hooks Class Initialized
INFO - 2020-02-10 09:46:32 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:46:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 09:46:32 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:32 --> Config Class Initialized
INFO - 2020-02-10 09:46:32 --> Hooks Class Initialized
INFO - 2020-02-10 09:46:32 --> Utf8 Class Initialized
DEBUG - 2020-02-10 09:46:32 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:32 --> Utf8 Class Initialized
DEBUG - 2020-02-10 09:46:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 09:46:32 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:32 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:32 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:32 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:32 --> URI Class Initialized
INFO - 2020-02-10 09:46:32 --> URI Class Initialized
DEBUG - 2020-02-10 09:46:32 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:32 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:32 --> Router Class Initialized
INFO - 2020-02-10 09:46:32 --> Router Class Initialized
INFO - 2020-02-10 09:46:32 --> URI Class Initialized
INFO - 2020-02-10 09:46:32 --> URI Class Initialized
INFO - 2020-02-10 09:46:32 --> URI Class Initialized
INFO - 2020-02-10 09:46:32 --> Router Class Initialized
INFO - 2020-02-10 09:46:32 --> Output Class Initialized
INFO - 2020-02-10 09:46:32 --> Router Class Initialized
INFO - 2020-02-10 09:46:32 --> URI Class Initialized
INFO - 2020-02-10 09:46:32 --> Output Class Initialized
INFO - 2020-02-10 09:46:32 --> Router Class Initialized
INFO - 2020-02-10 09:46:32 --> Security Class Initialized
INFO - 2020-02-10 09:46:32 --> Output Class Initialized
INFO - 2020-02-10 09:46:32 --> Output Class Initialized
INFO - 2020-02-10 09:46:32 --> Router Class Initialized
INFO - 2020-02-10 09:46:32 --> Security Class Initialized
INFO - 2020-02-10 09:46:32 --> Output Class Initialized
DEBUG - 2020-02-10 09:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:32 --> Security Class Initialized
INFO - 2020-02-10 09:46:32 --> Security Class Initialized
INFO - 2020-02-10 09:46:32 --> Output Class Initialized
DEBUG - 2020-02-10 09:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:32 --> Security Class Initialized
INFO - 2020-02-10 09:46:32 --> Input Class Initialized
INFO - 2020-02-10 09:46:32 --> Input Class Initialized
DEBUG - 2020-02-10 09:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 09:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 09:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:32 --> Security Class Initialized
INFO - 2020-02-10 09:46:32 --> Input Class Initialized
INFO - 2020-02-10 09:46:32 --> Input Class Initialized
INFO - 2020-02-10 09:46:32 --> Input Class Initialized
INFO - 2020-02-10 09:46:32 --> Language Class Initialized
INFO - 2020-02-10 09:46:32 --> Language Class Initialized
DEBUG - 2020-02-10 09:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:32 --> Language Class Initialized
INFO - 2020-02-10 09:46:32 --> Language Class Initialized
INFO - 2020-02-10 09:46:32 --> Input Class Initialized
INFO - 2020-02-10 09:46:32 --> Language Class Initialized
INFO - 2020-02-10 09:46:32 --> Loader Class Initialized
INFO - 2020-02-10 09:46:32 --> Loader Class Initialized
ERROR - 2020-02-10 09:46:32 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-10 09:46:32 --> Helper loaded: url_helper
INFO - 2020-02-10 09:46:32 --> Language Class Initialized
ERROR - 2020-02-10 09:46:32 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-10 09:46:32 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-10 09:46:32 --> Helper loaded: url_helper
ERROR - 2020-02-10 09:46:33 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 09:46:33 --> Database Driver Class Initialized
INFO - 2020-02-10 09:46:33 --> Database Driver Class Initialized
DEBUG - 2020-02-10 09:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-10 09:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 09:46:33 --> Config Class Initialized
INFO - 2020-02-10 09:46:33 --> Config Class Initialized
INFO - 2020-02-10 09:46:33 --> Config Class Initialized
INFO - 2020-02-10 09:46:33 --> Config Class Initialized
INFO - 2020-02-10 09:46:33 --> Hooks Class Initialized
INFO - 2020-02-10 09:46:33 --> Hooks Class Initialized
INFO - 2020-02-10 09:46:33 --> Hooks Class Initialized
INFO - 2020-02-10 09:46:33 --> Hooks Class Initialized
INFO - 2020-02-10 09:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 09:46:33 --> Controller Class Initialized
DEBUG - 2020-02-10 09:46:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 09:46:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 09:46:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 09:46:33 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:33 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:33 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:33 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:33 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:33 --> Model "M_tiket" initialized
INFO - 2020-02-10 09:46:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 09:46:33 --> URI Class Initialized
INFO - 2020-02-10 09:46:33 --> URI Class Initialized
INFO - 2020-02-10 09:46:33 --> URI Class Initialized
INFO - 2020-02-10 09:46:33 --> URI Class Initialized
INFO - 2020-02-10 09:46:33 --> Model "M_pesan" initialized
INFO - 2020-02-10 09:46:33 --> Router Class Initialized
INFO - 2020-02-10 09:46:33 --> Router Class Initialized
INFO - 2020-02-10 09:46:33 --> Router Class Initialized
INFO - 2020-02-10 09:46:33 --> Router Class Initialized
INFO - 2020-02-10 09:46:33 --> Output Class Initialized
INFO - 2020-02-10 09:46:33 --> Output Class Initialized
INFO - 2020-02-10 09:46:33 --> Output Class Initialized
INFO - 2020-02-10 09:46:33 --> Output Class Initialized
INFO - 2020-02-10 09:46:33 --> Helper loaded: form_helper
INFO - 2020-02-10 09:46:33 --> Form Validation Class Initialized
INFO - 2020-02-10 09:46:33 --> Security Class Initialized
INFO - 2020-02-10 09:46:33 --> Security Class Initialized
INFO - 2020-02-10 09:46:33 --> Security Class Initialized
INFO - 2020-02-10 09:46:33 --> Security Class Initialized
DEBUG - 2020-02-10 09:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 09:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 09:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 09:46:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-10 09:46:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 09:46:33 --> Input Class Initialized
INFO - 2020-02-10 09:46:33 --> Input Class Initialized
INFO - 2020-02-10 09:46:33 --> Input Class Initialized
INFO - 2020-02-10 09:46:33 --> Input Class Initialized
ERROR - 2020-02-10 09:46:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 09:46:33 --> Language Class Initialized
INFO - 2020-02-10 09:46:33 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 09:46:33 --> Language Class Initialized
INFO - 2020-02-10 09:46:33 --> Language Class Initialized
INFO - 2020-02-10 09:46:33 --> Language Class Initialized
ERROR - 2020-02-10 09:46:33 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 09:46:33 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 09:46:33 --> Final output sent to browser
ERROR - 2020-02-10 09:46:33 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 09:46:33 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-10 09:46:33 --> Total execution time: 0.8686
INFO - 2020-02-10 09:46:33 --> Config Class Initialized
INFO - 2020-02-10 09:46:33 --> Config Class Initialized
INFO - 2020-02-10 09:46:33 --> Config Class Initialized
INFO - 2020-02-10 09:46:33 --> Config Class Initialized
INFO - 2020-02-10 09:46:33 --> Hooks Class Initialized
INFO - 2020-02-10 09:46:33 --> Hooks Class Initialized
INFO - 2020-02-10 09:46:33 --> Hooks Class Initialized
INFO - 2020-02-10 09:46:33 --> Hooks Class Initialized
INFO - 2020-02-10 09:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 09:46:33 --> Controller Class Initialized
DEBUG - 2020-02-10 09:46:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 09:46:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 09:46:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 09:46:33 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:33 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:33 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:33 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:33 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:33 --> Model "M_tiket" initialized
INFO - 2020-02-10 09:46:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 09:46:33 --> URI Class Initialized
INFO - 2020-02-10 09:46:33 --> URI Class Initialized
INFO - 2020-02-10 09:46:33 --> URI Class Initialized
INFO - 2020-02-10 09:46:33 --> URI Class Initialized
INFO - 2020-02-10 09:46:33 --> Model "M_pesan" initialized
INFO - 2020-02-10 09:46:33 --> Router Class Initialized
INFO - 2020-02-10 09:46:33 --> Router Class Initialized
INFO - 2020-02-10 09:46:33 --> Router Class Initialized
INFO - 2020-02-10 09:46:33 --> Router Class Initialized
INFO - 2020-02-10 09:46:33 --> Output Class Initialized
INFO - 2020-02-10 09:46:33 --> Output Class Initialized
INFO - 2020-02-10 09:46:33 --> Output Class Initialized
INFO - 2020-02-10 09:46:33 --> Output Class Initialized
INFO - 2020-02-10 09:46:33 --> Helper loaded: form_helper
INFO - 2020-02-10 09:46:33 --> Form Validation Class Initialized
INFO - 2020-02-10 09:46:33 --> Security Class Initialized
INFO - 2020-02-10 09:46:33 --> Security Class Initialized
INFO - 2020-02-10 09:46:33 --> Security Class Initialized
INFO - 2020-02-10 09:46:33 --> Security Class Initialized
DEBUG - 2020-02-10 09:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 09:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 09:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 09:46:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-10 09:46:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 09:46:33 --> Input Class Initialized
INFO - 2020-02-10 09:46:33 --> Input Class Initialized
INFO - 2020-02-10 09:46:33 --> Input Class Initialized
INFO - 2020-02-10 09:46:33 --> Input Class Initialized
ERROR - 2020-02-10 09:46:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 09:46:33 --> Language Class Initialized
INFO - 2020-02-10 09:46:33 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 09:46:33 --> Language Class Initialized
INFO - 2020-02-10 09:46:33 --> Language Class Initialized
INFO - 2020-02-10 09:46:33 --> Language Class Initialized
INFO - 2020-02-10 09:46:33 --> Final output sent to browser
ERROR - 2020-02-10 09:46:33 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-10 09:46:33 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-10 09:46:33 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-10 09:46:33 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-10 09:46:33 --> Total execution time: 1.2973
INFO - 2020-02-10 09:46:33 --> Config Class Initialized
INFO - 2020-02-10 09:46:33 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:46:33 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:34 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:34 --> URI Class Initialized
INFO - 2020-02-10 09:46:34 --> Router Class Initialized
INFO - 2020-02-10 09:46:34 --> Output Class Initialized
INFO - 2020-02-10 09:46:34 --> Security Class Initialized
DEBUG - 2020-02-10 09:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:34 --> Input Class Initialized
INFO - 2020-02-10 09:46:34 --> Language Class Initialized
ERROR - 2020-02-10 09:46:34 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-10 09:46:34 --> Config Class Initialized
INFO - 2020-02-10 09:46:34 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:46:34 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:34 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:34 --> URI Class Initialized
INFO - 2020-02-10 09:46:34 --> Router Class Initialized
INFO - 2020-02-10 09:46:34 --> Output Class Initialized
INFO - 2020-02-10 09:46:34 --> Security Class Initialized
DEBUG - 2020-02-10 09:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:34 --> Input Class Initialized
INFO - 2020-02-10 09:46:34 --> Language Class Initialized
ERROR - 2020-02-10 09:46:34 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 09:46:34 --> Config Class Initialized
INFO - 2020-02-10 09:46:34 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:46:34 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:34 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:34 --> URI Class Initialized
INFO - 2020-02-10 09:46:34 --> Router Class Initialized
INFO - 2020-02-10 09:46:34 --> Output Class Initialized
INFO - 2020-02-10 09:46:34 --> Security Class Initialized
DEBUG - 2020-02-10 09:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:35 --> Input Class Initialized
INFO - 2020-02-10 09:46:35 --> Language Class Initialized
ERROR - 2020-02-10 09:46:35 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 09:46:35 --> Config Class Initialized
INFO - 2020-02-10 09:46:35 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:46:35 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:35 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:35 --> URI Class Initialized
INFO - 2020-02-10 09:46:35 --> Router Class Initialized
INFO - 2020-02-10 09:46:35 --> Output Class Initialized
INFO - 2020-02-10 09:46:35 --> Security Class Initialized
DEBUG - 2020-02-10 09:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:35 --> Input Class Initialized
INFO - 2020-02-10 09:46:35 --> Language Class Initialized
ERROR - 2020-02-10 09:46:35 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 09:46:35 --> Config Class Initialized
INFO - 2020-02-10 09:46:35 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:46:35 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:35 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:35 --> URI Class Initialized
INFO - 2020-02-10 09:46:35 --> Router Class Initialized
INFO - 2020-02-10 09:46:35 --> Output Class Initialized
INFO - 2020-02-10 09:46:35 --> Security Class Initialized
DEBUG - 2020-02-10 09:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:35 --> Input Class Initialized
INFO - 2020-02-10 09:46:35 --> Language Class Initialized
ERROR - 2020-02-10 09:46:35 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 09:46:35 --> Config Class Initialized
INFO - 2020-02-10 09:46:35 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:46:35 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:35 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:36 --> URI Class Initialized
INFO - 2020-02-10 09:46:36 --> Router Class Initialized
INFO - 2020-02-10 09:46:36 --> Output Class Initialized
INFO - 2020-02-10 09:46:36 --> Security Class Initialized
DEBUG - 2020-02-10 09:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:36 --> Input Class Initialized
INFO - 2020-02-10 09:46:36 --> Language Class Initialized
ERROR - 2020-02-10 09:46:36 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 09:46:36 --> Config Class Initialized
INFO - 2020-02-10 09:46:36 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:46:36 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:36 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:36 --> URI Class Initialized
INFO - 2020-02-10 09:46:36 --> Router Class Initialized
INFO - 2020-02-10 09:46:36 --> Output Class Initialized
INFO - 2020-02-10 09:46:36 --> Security Class Initialized
DEBUG - 2020-02-10 09:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:36 --> Input Class Initialized
INFO - 2020-02-10 09:46:36 --> Language Class Initialized
ERROR - 2020-02-10 09:46:36 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 09:46:36 --> Config Class Initialized
INFO - 2020-02-10 09:46:36 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:46:36 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:36 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:36 --> URI Class Initialized
INFO - 2020-02-10 09:46:36 --> Router Class Initialized
INFO - 2020-02-10 09:46:36 --> Output Class Initialized
INFO - 2020-02-10 09:46:36 --> Security Class Initialized
DEBUG - 2020-02-10 09:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:36 --> Input Class Initialized
INFO - 2020-02-10 09:46:36 --> Language Class Initialized
ERROR - 2020-02-10 09:46:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 09:46:37 --> Config Class Initialized
INFO - 2020-02-10 09:46:37 --> Hooks Class Initialized
DEBUG - 2020-02-10 09:46:37 --> UTF-8 Support Enabled
INFO - 2020-02-10 09:46:37 --> Utf8 Class Initialized
INFO - 2020-02-10 09:46:37 --> URI Class Initialized
INFO - 2020-02-10 09:46:37 --> Router Class Initialized
INFO - 2020-02-10 09:46:37 --> Output Class Initialized
INFO - 2020-02-10 09:46:37 --> Security Class Initialized
DEBUG - 2020-02-10 09:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 09:46:37 --> Input Class Initialized
INFO - 2020-02-10 09:46:37 --> Language Class Initialized
ERROR - 2020-02-10 09:46:37 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 11:16:13 --> Config Class Initialized
INFO - 2020-02-10 11:16:14 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:16:14 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:14 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:14 --> URI Class Initialized
DEBUG - 2020-02-10 11:16:14 --> No URI present. Default controller set.
INFO - 2020-02-10 11:16:14 --> Router Class Initialized
INFO - 2020-02-10 11:16:14 --> Output Class Initialized
INFO - 2020-02-10 11:16:14 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:15 --> Input Class Initialized
INFO - 2020-02-10 11:16:15 --> Language Class Initialized
INFO - 2020-02-10 11:16:15 --> Loader Class Initialized
INFO - 2020-02-10 11:16:15 --> Helper loaded: url_helper
INFO - 2020-02-10 11:16:15 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:16:15 --> Controller Class Initialized
INFO - 2020-02-10 11:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-10 11:16:15 --> Pagination Class Initialized
INFO - 2020-02-10 11:16:15 --> Model "M_show" initialized
INFO - 2020-02-10 11:16:15 --> Helper loaded: form_helper
INFO - 2020-02-10 11:16:15 --> Form Validation Class Initialized
INFO - 2020-02-10 11:16:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-10 11:16:15 --> Final output sent to browser
DEBUG - 2020-02-10 11:16:15 --> Total execution time: 2.3102
INFO - 2020-02-10 11:16:18 --> Config Class Initialized
INFO - 2020-02-10 11:16:18 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:16:18 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:18 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:18 --> URI Class Initialized
INFO - 2020-02-10 11:16:18 --> Router Class Initialized
INFO - 2020-02-10 11:16:18 --> Output Class Initialized
INFO - 2020-02-10 11:16:18 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:18 --> Input Class Initialized
INFO - 2020-02-10 11:16:18 --> Language Class Initialized
ERROR - 2020-02-10 11:16:19 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 55
INFO - 2020-02-10 11:16:21 --> Config Class Initialized
INFO - 2020-02-10 11:16:21 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:16:21 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:22 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:22 --> URI Class Initialized
DEBUG - 2020-02-10 11:16:22 --> No URI present. Default controller set.
INFO - 2020-02-10 11:16:22 --> Router Class Initialized
INFO - 2020-02-10 11:16:22 --> Output Class Initialized
INFO - 2020-02-10 11:16:22 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:22 --> Input Class Initialized
INFO - 2020-02-10 11:16:22 --> Language Class Initialized
INFO - 2020-02-10 11:16:22 --> Loader Class Initialized
INFO - 2020-02-10 11:16:22 --> Helper loaded: url_helper
INFO - 2020-02-10 11:16:22 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:16:23 --> Controller Class Initialized
INFO - 2020-02-10 11:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-10 11:16:23 --> Pagination Class Initialized
INFO - 2020-02-10 11:16:23 --> Model "M_show" initialized
INFO - 2020-02-10 11:16:23 --> Helper loaded: form_helper
INFO - 2020-02-10 11:16:23 --> Form Validation Class Initialized
INFO - 2020-02-10 11:16:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-10 11:16:23 --> Final output sent to browser
DEBUG - 2020-02-10 11:16:23 --> Total execution time: 1.7910
INFO - 2020-02-10 11:16:25 --> Config Class Initialized
INFO - 2020-02-10 11:16:25 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:16:25 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:25 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:25 --> URI Class Initialized
INFO - 2020-02-10 11:16:25 --> Router Class Initialized
INFO - 2020-02-10 11:16:26 --> Output Class Initialized
INFO - 2020-02-10 11:16:26 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:26 --> Input Class Initialized
INFO - 2020-02-10 11:16:26 --> Language Class Initialized
ERROR - 2020-02-10 11:16:26 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 55
INFO - 2020-02-10 11:16:49 --> Config Class Initialized
INFO - 2020-02-10 11:16:49 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:16:49 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:49 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:50 --> URI Class Initialized
INFO - 2020-02-10 11:16:50 --> Router Class Initialized
INFO - 2020-02-10 11:16:50 --> Output Class Initialized
INFO - 2020-02-10 11:16:50 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:50 --> Input Class Initialized
INFO - 2020-02-10 11:16:50 --> Language Class Initialized
INFO - 2020-02-10 11:16:50 --> Loader Class Initialized
INFO - 2020-02-10 11:16:50 --> Helper loaded: url_helper
INFO - 2020-02-10 11:16:50 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:16:50 --> Controller Class Initialized
INFO - 2020-02-10 11:16:51 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:16:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:16:51 --> Model "M_pesan" initialized
INFO - 2020-02-10 11:16:51 --> Helper loaded: form_helper
INFO - 2020-02-10 11:16:51 --> Form Validation Class Initialized
INFO - 2020-02-10 11:16:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 11:16:51 --> Final output sent to browser
DEBUG - 2020-02-10 11:16:51 --> Total execution time: 1.4939
INFO - 2020-02-10 11:16:51 --> Config Class Initialized
INFO - 2020-02-10 11:16:51 --> Config Class Initialized
INFO - 2020-02-10 11:16:51 --> Config Class Initialized
INFO - 2020-02-10 11:16:51 --> Config Class Initialized
INFO - 2020-02-10 11:16:51 --> Config Class Initialized
INFO - 2020-02-10 11:16:51 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:51 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:51 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:51 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:51 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:51 --> Config Class Initialized
INFO - 2020-02-10 11:16:51 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:16:51 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:51 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:51 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:51 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:51 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:51 --> Utf8 Class Initialized
DEBUG - 2020-02-10 11:16:51 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:51 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:51 --> URI Class Initialized
INFO - 2020-02-10 11:16:51 --> URI Class Initialized
INFO - 2020-02-10 11:16:51 --> URI Class Initialized
INFO - 2020-02-10 11:16:51 --> URI Class Initialized
INFO - 2020-02-10 11:16:51 --> URI Class Initialized
INFO - 2020-02-10 11:16:51 --> Router Class Initialized
INFO - 2020-02-10 11:16:51 --> Router Class Initialized
INFO - 2020-02-10 11:16:51 --> Router Class Initialized
INFO - 2020-02-10 11:16:51 --> Router Class Initialized
INFO - 2020-02-10 11:16:51 --> Router Class Initialized
INFO - 2020-02-10 11:16:51 --> URI Class Initialized
INFO - 2020-02-10 11:16:51 --> Output Class Initialized
INFO - 2020-02-10 11:16:51 --> Router Class Initialized
INFO - 2020-02-10 11:16:51 --> Output Class Initialized
INFO - 2020-02-10 11:16:51 --> Output Class Initialized
INFO - 2020-02-10 11:16:51 --> Output Class Initialized
INFO - 2020-02-10 11:16:51 --> Output Class Initialized
INFO - 2020-02-10 11:16:51 --> Security Class Initialized
INFO - 2020-02-10 11:16:51 --> Security Class Initialized
INFO - 2020-02-10 11:16:51 --> Security Class Initialized
INFO - 2020-02-10 11:16:51 --> Output Class Initialized
INFO - 2020-02-10 11:16:51 --> Security Class Initialized
INFO - 2020-02-10 11:16:51 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 11:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 11:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 11:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 11:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:51 --> Security Class Initialized
INFO - 2020-02-10 11:16:51 --> Input Class Initialized
INFO - 2020-02-10 11:16:51 --> Input Class Initialized
INFO - 2020-02-10 11:16:51 --> Input Class Initialized
INFO - 2020-02-10 11:16:51 --> Input Class Initialized
INFO - 2020-02-10 11:16:51 --> Input Class Initialized
DEBUG - 2020-02-10 11:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:51 --> Input Class Initialized
INFO - 2020-02-10 11:16:51 --> Language Class Initialized
INFO - 2020-02-10 11:16:51 --> Language Class Initialized
INFO - 2020-02-10 11:16:51 --> Language Class Initialized
INFO - 2020-02-10 11:16:51 --> Language Class Initialized
INFO - 2020-02-10 11:16:51 --> Language Class Initialized
ERROR - 2020-02-10 11:16:51 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-10 11:16:51 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-10 11:16:51 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-10 11:16:51 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-10 11:16:51 --> Language Class Initialized
ERROR - 2020-02-10 11:16:51 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-10 11:16:51 --> Loader Class Initialized
INFO - 2020-02-10 11:16:51 --> Config Class Initialized
INFO - 2020-02-10 11:16:51 --> Config Class Initialized
INFO - 2020-02-10 11:16:51 --> Config Class Initialized
INFO - 2020-02-10 11:16:51 --> Config Class Initialized
INFO - 2020-02-10 11:16:51 --> Config Class Initialized
INFO - 2020-02-10 11:16:51 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:51 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:51 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:51 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:51 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:51 --> Helper loaded: url_helper
DEBUG - 2020-02-10 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:16:51 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:51 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:16:51 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:51 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:51 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:51 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:51 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:51 --> Utf8 Class Initialized
DEBUG - 2020-02-10 11:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:16:52 --> URI Class Initialized
INFO - 2020-02-10 11:16:52 --> URI Class Initialized
INFO - 2020-02-10 11:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:16:52 --> URI Class Initialized
INFO - 2020-02-10 11:16:52 --> URI Class Initialized
INFO - 2020-02-10 11:16:52 --> URI Class Initialized
INFO - 2020-02-10 11:16:52 --> Controller Class Initialized
INFO - 2020-02-10 11:16:52 --> Router Class Initialized
INFO - 2020-02-10 11:16:52 --> Router Class Initialized
INFO - 2020-02-10 11:16:52 --> Router Class Initialized
INFO - 2020-02-10 11:16:52 --> Router Class Initialized
INFO - 2020-02-10 11:16:52 --> Router Class Initialized
INFO - 2020-02-10 11:16:52 --> Output Class Initialized
INFO - 2020-02-10 11:16:52 --> Output Class Initialized
INFO - 2020-02-10 11:16:52 --> Output Class Initialized
INFO - 2020-02-10 11:16:52 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:16:52 --> Output Class Initialized
INFO - 2020-02-10 11:16:52 --> Output Class Initialized
INFO - 2020-02-10 11:16:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:16:52 --> Security Class Initialized
INFO - 2020-02-10 11:16:52 --> Security Class Initialized
INFO - 2020-02-10 11:16:52 --> Security Class Initialized
INFO - 2020-02-10 11:16:52 --> Security Class Initialized
INFO - 2020-02-10 11:16:52 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 11:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 11:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:52 --> Model "M_pesan" initialized
DEBUG - 2020-02-10 11:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 11:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:52 --> Input Class Initialized
INFO - 2020-02-10 11:16:52 --> Input Class Initialized
INFO - 2020-02-10 11:16:52 --> Input Class Initialized
INFO - 2020-02-10 11:16:52 --> Input Class Initialized
INFO - 2020-02-10 11:16:52 --> Input Class Initialized
INFO - 2020-02-10 11:16:52 --> Helper loaded: form_helper
INFO - 2020-02-10 11:16:52 --> Form Validation Class Initialized
INFO - 2020-02-10 11:16:52 --> Language Class Initialized
INFO - 2020-02-10 11:16:52 --> Language Class Initialized
INFO - 2020-02-10 11:16:52 --> Language Class Initialized
INFO - 2020-02-10 11:16:52 --> Language Class Initialized
INFO - 2020-02-10 11:16:52 --> Language Class Initialized
ERROR - 2020-02-10 11:16:52 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-10 11:16:52 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-10 11:16:52 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 11:16:52 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 11:16:52 --> Loader Class Initialized
ERROR - 2020-02-10 11:16:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 11:16:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 11:16:52 --> Helper loaded: url_helper
INFO - 2020-02-10 11:16:52 --> Config Class Initialized
INFO - 2020-02-10 11:16:52 --> Config Class Initialized
INFO - 2020-02-10 11:16:52 --> Config Class Initialized
INFO - 2020-02-10 11:16:52 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:52 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:52 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 11:16:52 --> Database Driver Class Initialized
INFO - 2020-02-10 11:16:52 --> Final output sent to browser
DEBUG - 2020-02-10 11:16:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:16:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:16:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-10 11:16:52 --> Total execution time: 1.2654
INFO - 2020-02-10 11:16:52 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:52 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:52 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:16:52 --> URI Class Initialized
INFO - 2020-02-10 11:16:52 --> URI Class Initialized
INFO - 2020-02-10 11:16:52 --> URI Class Initialized
INFO - 2020-02-10 11:16:52 --> Controller Class Initialized
INFO - 2020-02-10 11:16:52 --> Router Class Initialized
INFO - 2020-02-10 11:16:52 --> Router Class Initialized
INFO - 2020-02-10 11:16:52 --> Router Class Initialized
INFO - 2020-02-10 11:16:52 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:16:52 --> Output Class Initialized
INFO - 2020-02-10 11:16:52 --> Output Class Initialized
INFO - 2020-02-10 11:16:52 --> Output Class Initialized
INFO - 2020-02-10 11:16:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:16:52 --> Security Class Initialized
INFO - 2020-02-10 11:16:52 --> Security Class Initialized
INFO - 2020-02-10 11:16:52 --> Security Class Initialized
INFO - 2020-02-10 11:16:52 --> Model "M_pesan" initialized
DEBUG - 2020-02-10 11:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 11:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 11:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:52 --> Input Class Initialized
INFO - 2020-02-10 11:16:52 --> Input Class Initialized
INFO - 2020-02-10 11:16:52 --> Input Class Initialized
INFO - 2020-02-10 11:16:52 --> Helper loaded: form_helper
INFO - 2020-02-10 11:16:52 --> Form Validation Class Initialized
INFO - 2020-02-10 11:16:52 --> Language Class Initialized
INFO - 2020-02-10 11:16:52 --> Language Class Initialized
INFO - 2020-02-10 11:16:52 --> Language Class Initialized
ERROR - 2020-02-10 11:16:52 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-10 11:16:52 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-10 11:16:52 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-10 11:16:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 11:16:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 11:16:52 --> Config Class Initialized
INFO - 2020-02-10 11:16:52 --> Hooks Class Initialized
INFO - 2020-02-10 11:16:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 11:16:53 --> Final output sent to browser
DEBUG - 2020-02-10 11:16:53 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:53 --> Utf8 Class Initialized
DEBUG - 2020-02-10 11:16:53 --> Total execution time: 1.1696
INFO - 2020-02-10 11:16:53 --> URI Class Initialized
INFO - 2020-02-10 11:16:53 --> Router Class Initialized
INFO - 2020-02-10 11:16:53 --> Output Class Initialized
INFO - 2020-02-10 11:16:53 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:53 --> Input Class Initialized
INFO - 2020-02-10 11:16:53 --> Language Class Initialized
ERROR - 2020-02-10 11:16:53 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 11:16:53 --> Config Class Initialized
INFO - 2020-02-10 11:16:53 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:16:53 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:53 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:53 --> URI Class Initialized
INFO - 2020-02-10 11:16:53 --> Router Class Initialized
INFO - 2020-02-10 11:16:53 --> Output Class Initialized
INFO - 2020-02-10 11:16:53 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:53 --> Input Class Initialized
INFO - 2020-02-10 11:16:53 --> Language Class Initialized
ERROR - 2020-02-10 11:16:53 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 11:16:53 --> Config Class Initialized
INFO - 2020-02-10 11:16:53 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:16:53 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:53 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:53 --> URI Class Initialized
INFO - 2020-02-10 11:16:53 --> Router Class Initialized
INFO - 2020-02-10 11:16:53 --> Output Class Initialized
INFO - 2020-02-10 11:16:53 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:54 --> Input Class Initialized
INFO - 2020-02-10 11:16:54 --> Language Class Initialized
ERROR - 2020-02-10 11:16:54 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 11:16:54 --> Config Class Initialized
INFO - 2020-02-10 11:16:54 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:16:54 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:54 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:54 --> URI Class Initialized
INFO - 2020-02-10 11:16:54 --> Router Class Initialized
INFO - 2020-02-10 11:16:54 --> Output Class Initialized
INFO - 2020-02-10 11:16:54 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:54 --> Input Class Initialized
INFO - 2020-02-10 11:16:54 --> Language Class Initialized
ERROR - 2020-02-10 11:16:54 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 11:16:54 --> Config Class Initialized
INFO - 2020-02-10 11:16:54 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:16:54 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:54 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:54 --> URI Class Initialized
INFO - 2020-02-10 11:16:54 --> Router Class Initialized
INFO - 2020-02-10 11:16:54 --> Output Class Initialized
INFO - 2020-02-10 11:16:54 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:54 --> Input Class Initialized
INFO - 2020-02-10 11:16:54 --> Language Class Initialized
ERROR - 2020-02-10 11:16:54 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 11:16:55 --> Config Class Initialized
INFO - 2020-02-10 11:16:55 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:16:55 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:55 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:55 --> URI Class Initialized
INFO - 2020-02-10 11:16:55 --> Router Class Initialized
INFO - 2020-02-10 11:16:55 --> Output Class Initialized
INFO - 2020-02-10 11:16:55 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:55 --> Input Class Initialized
INFO - 2020-02-10 11:16:55 --> Language Class Initialized
ERROR - 2020-02-10 11:16:55 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 11:16:55 --> Config Class Initialized
INFO - 2020-02-10 11:16:55 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:16:55 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:55 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:55 --> URI Class Initialized
INFO - 2020-02-10 11:16:55 --> Router Class Initialized
INFO - 2020-02-10 11:16:55 --> Output Class Initialized
INFO - 2020-02-10 11:16:55 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:55 --> Input Class Initialized
INFO - 2020-02-10 11:16:55 --> Language Class Initialized
ERROR - 2020-02-10 11:16:55 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 11:16:55 --> Config Class Initialized
INFO - 2020-02-10 11:16:55 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:16:55 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:16:56 --> Utf8 Class Initialized
INFO - 2020-02-10 11:16:56 --> URI Class Initialized
INFO - 2020-02-10 11:16:56 --> Router Class Initialized
INFO - 2020-02-10 11:16:56 --> Output Class Initialized
INFO - 2020-02-10 11:16:56 --> Security Class Initialized
DEBUG - 2020-02-10 11:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:16:56 --> Input Class Initialized
INFO - 2020-02-10 11:16:56 --> Language Class Initialized
ERROR - 2020-02-10 11:16:56 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 11:19:57 --> Config Class Initialized
INFO - 2020-02-10 11:19:57 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:19:57 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:19:57 --> Utf8 Class Initialized
INFO - 2020-02-10 11:19:57 --> URI Class Initialized
INFO - 2020-02-10 11:19:57 --> Router Class Initialized
INFO - 2020-02-10 11:19:57 --> Output Class Initialized
INFO - 2020-02-10 11:19:57 --> Security Class Initialized
DEBUG - 2020-02-10 11:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:19:57 --> Input Class Initialized
INFO - 2020-02-10 11:19:57 --> Language Class Initialized
INFO - 2020-02-10 11:19:57 --> Loader Class Initialized
INFO - 2020-02-10 11:19:57 --> Helper loaded: url_helper
INFO - 2020-02-10 11:19:57 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:19:58 --> Controller Class Initialized
INFO - 2020-02-10 11:19:58 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:19:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:19:58 --> Model "M_pesan" initialized
INFO - 2020-02-10 11:19:58 --> Helper loaded: form_helper
INFO - 2020-02-10 11:19:58 --> Form Validation Class Initialized
INFO - 2020-02-10 11:19:58 --> Final output sent to browser
DEBUG - 2020-02-10 11:19:58 --> Total execution time: 1.1917
INFO - 2020-02-10 11:23:05 --> Config Class Initialized
INFO - 2020-02-10 11:23:05 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:23:05 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:23:05 --> Utf8 Class Initialized
INFO - 2020-02-10 11:23:05 --> URI Class Initialized
INFO - 2020-02-10 11:23:05 --> Router Class Initialized
INFO - 2020-02-10 11:23:05 --> Output Class Initialized
INFO - 2020-02-10 11:23:05 --> Security Class Initialized
DEBUG - 2020-02-10 11:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:23:05 --> Input Class Initialized
INFO - 2020-02-10 11:23:05 --> Language Class Initialized
INFO - 2020-02-10 11:23:05 --> Loader Class Initialized
INFO - 2020-02-10 11:23:05 --> Helper loaded: url_helper
INFO - 2020-02-10 11:23:05 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:23:05 --> Controller Class Initialized
INFO - 2020-02-10 11:23:05 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:23:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:23:05 --> Model "M_pesan" initialized
INFO - 2020-02-10 11:23:05 --> Helper loaded: form_helper
INFO - 2020-02-10 11:23:05 --> Form Validation Class Initialized
INFO - 2020-02-10 11:23:06 --> Final output sent to browser
DEBUG - 2020-02-10 11:23:06 --> Total execution time: 0.9017
INFO - 2020-02-10 11:23:21 --> Config Class Initialized
INFO - 2020-02-10 11:23:21 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:23:21 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:23:21 --> Utf8 Class Initialized
INFO - 2020-02-10 11:23:21 --> URI Class Initialized
INFO - 2020-02-10 11:23:21 --> Router Class Initialized
INFO - 2020-02-10 11:23:21 --> Output Class Initialized
INFO - 2020-02-10 11:23:21 --> Security Class Initialized
DEBUG - 2020-02-10 11:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:23:21 --> Input Class Initialized
INFO - 2020-02-10 11:23:21 --> Language Class Initialized
INFO - 2020-02-10 11:23:21 --> Loader Class Initialized
INFO - 2020-02-10 11:23:21 --> Helper loaded: url_helper
INFO - 2020-02-10 11:23:21 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:23:22 --> Controller Class Initialized
INFO - 2020-02-10 11:23:22 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:23:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:23:22 --> Model "M_pesan" initialized
INFO - 2020-02-10 11:23:22 --> Helper loaded: form_helper
INFO - 2020-02-10 11:23:22 --> Form Validation Class Initialized
INFO - 2020-02-10 11:23:22 --> Final output sent to browser
DEBUG - 2020-02-10 11:23:22 --> Total execution time: 0.9520
INFO - 2020-02-10 11:23:50 --> Config Class Initialized
INFO - 2020-02-10 11:23:50 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:23:50 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:23:50 --> Utf8 Class Initialized
INFO - 2020-02-10 11:23:50 --> URI Class Initialized
INFO - 2020-02-10 11:23:50 --> Router Class Initialized
INFO - 2020-02-10 11:23:50 --> Output Class Initialized
INFO - 2020-02-10 11:23:50 --> Security Class Initialized
DEBUG - 2020-02-10 11:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:23:50 --> Input Class Initialized
INFO - 2020-02-10 11:23:50 --> Language Class Initialized
INFO - 2020-02-10 11:23:50 --> Loader Class Initialized
INFO - 2020-02-10 11:23:50 --> Helper loaded: url_helper
INFO - 2020-02-10 11:23:50 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:23:50 --> Controller Class Initialized
INFO - 2020-02-10 11:23:50 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:23:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:23:51 --> Model "M_pesan" initialized
INFO - 2020-02-10 11:23:51 --> Helper loaded: form_helper
INFO - 2020-02-10 11:23:51 --> Form Validation Class Initialized
INFO - 2020-02-10 11:23:51 --> Final output sent to browser
DEBUG - 2020-02-10 11:23:51 --> Total execution time: 1.0372
INFO - 2020-02-10 11:24:15 --> Config Class Initialized
INFO - 2020-02-10 11:24:15 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:24:15 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:24:15 --> Utf8 Class Initialized
INFO - 2020-02-10 11:24:15 --> URI Class Initialized
INFO - 2020-02-10 11:24:15 --> Router Class Initialized
INFO - 2020-02-10 11:24:15 --> Output Class Initialized
INFO - 2020-02-10 11:24:15 --> Security Class Initialized
DEBUG - 2020-02-10 11:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:24:16 --> Input Class Initialized
INFO - 2020-02-10 11:24:16 --> Language Class Initialized
INFO - 2020-02-10 11:24:16 --> Loader Class Initialized
INFO - 2020-02-10 11:24:16 --> Helper loaded: url_helper
INFO - 2020-02-10 11:24:16 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:24:16 --> Controller Class Initialized
INFO - 2020-02-10 11:24:16 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:24:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:24:16 --> Model "M_pesan" initialized
INFO - 2020-02-10 11:24:16 --> Helper loaded: form_helper
INFO - 2020-02-10 11:24:16 --> Form Validation Class Initialized
INFO - 2020-02-10 11:24:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 11:24:16 --> Final output sent to browser
DEBUG - 2020-02-10 11:24:16 --> Total execution time: 1.5404
INFO - 2020-02-10 11:24:28 --> Config Class Initialized
INFO - 2020-02-10 11:24:28 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:24:28 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:24:28 --> Utf8 Class Initialized
INFO - 2020-02-10 11:24:28 --> URI Class Initialized
INFO - 2020-02-10 11:24:28 --> Router Class Initialized
INFO - 2020-02-10 11:24:28 --> Output Class Initialized
INFO - 2020-02-10 11:24:28 --> Security Class Initialized
DEBUG - 2020-02-10 11:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:24:28 --> Input Class Initialized
INFO - 2020-02-10 11:24:28 --> Language Class Initialized
INFO - 2020-02-10 11:24:28 --> Loader Class Initialized
INFO - 2020-02-10 11:24:29 --> Helper loaded: url_helper
INFO - 2020-02-10 11:24:29 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:24:29 --> Controller Class Initialized
INFO - 2020-02-10 11:24:29 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:24:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:24:29 --> Model "M_pesan" initialized
INFO - 2020-02-10 11:24:29 --> Helper loaded: form_helper
INFO - 2020-02-10 11:24:29 --> Form Validation Class Initialized
INFO - 2020-02-10 11:24:29 --> Final output sent to browser
DEBUG - 2020-02-10 11:24:29 --> Total execution time: 0.9694
INFO - 2020-02-10 11:24:59 --> Config Class Initialized
INFO - 2020-02-10 11:24:59 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:24:59 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:25:00 --> Utf8 Class Initialized
INFO - 2020-02-10 11:25:00 --> URI Class Initialized
INFO - 2020-02-10 11:25:00 --> Router Class Initialized
INFO - 2020-02-10 11:25:00 --> Output Class Initialized
INFO - 2020-02-10 11:25:00 --> Security Class Initialized
DEBUG - 2020-02-10 11:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:25:00 --> Input Class Initialized
INFO - 2020-02-10 11:25:00 --> Language Class Initialized
INFO - 2020-02-10 11:25:00 --> Loader Class Initialized
INFO - 2020-02-10 11:25:00 --> Helper loaded: url_helper
INFO - 2020-02-10 11:25:00 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:25:00 --> Controller Class Initialized
INFO - 2020-02-10 11:25:00 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:25:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:25:00 --> Model "M_pesan" initialized
INFO - 2020-02-10 11:25:00 --> Helper loaded: form_helper
INFO - 2020-02-10 11:25:00 --> Form Validation Class Initialized
INFO - 2020-02-10 11:25:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 11:25:00 --> Final output sent to browser
INFO - 2020-02-10 11:25:00 --> Config Class Initialized
INFO - 2020-02-10 11:25:00 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:25:00 --> Total execution time: 1.0915
INFO - 2020-02-10 11:25:00 --> Config Class Initialized
INFO - 2020-02-10 11:25:00 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:25:01 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:25:01 --> Utf8 Class Initialized
DEBUG - 2020-02-10 11:25:01 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:25:01 --> Utf8 Class Initialized
INFO - 2020-02-10 11:25:01 --> URI Class Initialized
INFO - 2020-02-10 11:25:01 --> URI Class Initialized
INFO - 2020-02-10 11:25:01 --> Router Class Initialized
INFO - 2020-02-10 11:25:01 --> Router Class Initialized
INFO - 2020-02-10 11:25:01 --> Output Class Initialized
INFO - 2020-02-10 11:25:01 --> Security Class Initialized
INFO - 2020-02-10 11:25:01 --> Output Class Initialized
DEBUG - 2020-02-10 11:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:25:01 --> Security Class Initialized
INFO - 2020-02-10 11:25:01 --> Input Class Initialized
DEBUG - 2020-02-10 11:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:25:01 --> Input Class Initialized
INFO - 2020-02-10 11:25:01 --> Language Class Initialized
INFO - 2020-02-10 11:25:01 --> Language Class Initialized
INFO - 2020-02-10 11:25:01 --> Loader Class Initialized
INFO - 2020-02-10 11:25:01 --> Helper loaded: url_helper
INFO - 2020-02-10 11:25:01 --> Loader Class Initialized
INFO - 2020-02-10 11:25:01 --> Helper loaded: url_helper
INFO - 2020-02-10 11:25:01 --> Database Driver Class Initialized
INFO - 2020-02-10 11:25:01 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:25:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-10 11:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:25:01 --> Controller Class Initialized
INFO - 2020-02-10 11:25:01 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:25:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:25:01 --> Model "M_pesan" initialized
INFO - 2020-02-10 11:25:01 --> Helper loaded: form_helper
INFO - 2020-02-10 11:25:01 --> Form Validation Class Initialized
ERROR - 2020-02-10 11:25:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 11:25:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 11:25:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 11:25:01 --> Final output sent to browser
DEBUG - 2020-02-10 11:25:01 --> Total execution time: 0.8726
INFO - 2020-02-10 11:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:25:01 --> Controller Class Initialized
INFO - 2020-02-10 11:25:01 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:25:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:25:01 --> Model "M_pesan" initialized
INFO - 2020-02-10 11:25:01 --> Helper loaded: form_helper
INFO - 2020-02-10 11:25:02 --> Form Validation Class Initialized
ERROR - 2020-02-10 11:25:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-10 11:25:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 11:25:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 11:25:02 --> Final output sent to browser
DEBUG - 2020-02-10 11:25:02 --> Total execution time: 1.1936
INFO - 2020-02-10 11:46:14 --> Config Class Initialized
INFO - 2020-02-10 11:46:15 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:46:15 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:15 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:16 --> URI Class Initialized
DEBUG - 2020-02-10 11:46:16 --> No URI present. Default controller set.
INFO - 2020-02-10 11:46:16 --> Router Class Initialized
INFO - 2020-02-10 11:46:16 --> Output Class Initialized
INFO - 2020-02-10 11:46:16 --> Security Class Initialized
DEBUG - 2020-02-10 11:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:16 --> Input Class Initialized
INFO - 2020-02-10 11:46:16 --> Language Class Initialized
INFO - 2020-02-10 11:46:16 --> Loader Class Initialized
INFO - 2020-02-10 11:46:16 --> Helper loaded: url_helper
INFO - 2020-02-10 11:46:16 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:46:16 --> Controller Class Initialized
INFO - 2020-02-10 11:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-10 11:46:17 --> Pagination Class Initialized
INFO - 2020-02-10 11:46:17 --> Model "M_show" initialized
INFO - 2020-02-10 11:46:17 --> Helper loaded: form_helper
INFO - 2020-02-10 11:46:17 --> Form Validation Class Initialized
INFO - 2020-02-10 11:46:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-10 11:46:17 --> Final output sent to browser
DEBUG - 2020-02-10 11:46:17 --> Total execution time: 2.5619
INFO - 2020-02-10 11:46:24 --> Config Class Initialized
INFO - 2020-02-10 11:46:24 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:46:24 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:24 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:24 --> URI Class Initialized
INFO - 2020-02-10 11:46:24 --> Router Class Initialized
INFO - 2020-02-10 11:46:24 --> Output Class Initialized
INFO - 2020-02-10 11:46:24 --> Security Class Initialized
DEBUG - 2020-02-10 11:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:24 --> Input Class Initialized
INFO - 2020-02-10 11:46:25 --> Language Class Initialized
INFO - 2020-02-10 11:46:25 --> Loader Class Initialized
INFO - 2020-02-10 11:46:25 --> Helper loaded: url_helper
INFO - 2020-02-10 11:46:25 --> Database Driver Class Initialized
DEBUG - 2020-02-10 11:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:46:25 --> Controller Class Initialized
INFO - 2020-02-10 11:46:25 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:46:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:46:25 --> Model "M_pesan" initialized
INFO - 2020-02-10 11:46:25 --> Helper loaded: form_helper
INFO - 2020-02-10 11:46:25 --> Form Validation Class Initialized
INFO - 2020-02-10 11:46:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 11:46:25 --> Final output sent to browser
INFO - 2020-02-10 11:46:25 --> Config Class Initialized
INFO - 2020-02-10 11:46:25 --> Config Class Initialized
INFO - 2020-02-10 11:46:25 --> Config Class Initialized
INFO - 2020-02-10 11:46:25 --> Config Class Initialized
INFO - 2020-02-10 11:46:25 --> Hooks Class Initialized
INFO - 2020-02-10 11:46:25 --> Hooks Class Initialized
INFO - 2020-02-10 11:46:25 --> Hooks Class Initialized
INFO - 2020-02-10 11:46:25 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:46:25 --> Total execution time: 1.2572
INFO - 2020-02-10 11:46:25 --> Config Class Initialized
INFO - 2020-02-10 11:46:25 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:46:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:46:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:46:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:46:25 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:25 --> Config Class Initialized
INFO - 2020-02-10 11:46:25 --> Hooks Class Initialized
INFO - 2020-02-10 11:46:25 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:25 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:25 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:25 --> Utf8 Class Initialized
DEBUG - 2020-02-10 11:46:25 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:25 --> URI Class Initialized
INFO - 2020-02-10 11:46:25 --> URI Class Initialized
INFO - 2020-02-10 11:46:25 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:25 --> URI Class Initialized
INFO - 2020-02-10 11:46:25 --> URI Class Initialized
DEBUG - 2020-02-10 11:46:25 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:25 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:25 --> Router Class Initialized
INFO - 2020-02-10 11:46:25 --> Router Class Initialized
INFO - 2020-02-10 11:46:25 --> URI Class Initialized
INFO - 2020-02-10 11:46:25 --> Router Class Initialized
INFO - 2020-02-10 11:46:25 --> Router Class Initialized
INFO - 2020-02-10 11:46:25 --> Router Class Initialized
INFO - 2020-02-10 11:46:25 --> Output Class Initialized
INFO - 2020-02-10 11:46:25 --> Security Class Initialized
INFO - 2020-02-10 11:46:25 --> Output Class Initialized
INFO - 2020-02-10 11:46:25 --> Output Class Initialized
INFO - 2020-02-10 11:46:25 --> URI Class Initialized
INFO - 2020-02-10 11:46:25 --> Output Class Initialized
INFO - 2020-02-10 11:46:25 --> Output Class Initialized
INFO - 2020-02-10 11:46:25 --> Security Class Initialized
INFO - 2020-02-10 11:46:25 --> Security Class Initialized
INFO - 2020-02-10 11:46:25 --> Security Class Initialized
INFO - 2020-02-10 11:46:25 --> Router Class Initialized
DEBUG - 2020-02-10 11:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:25 --> Security Class Initialized
INFO - 2020-02-10 11:46:25 --> Input Class Initialized
DEBUG - 2020-02-10 11:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 11:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:25 --> Output Class Initialized
DEBUG - 2020-02-10 11:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-10 11:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:25 --> Input Class Initialized
INFO - 2020-02-10 11:46:25 --> Input Class Initialized
INFO - 2020-02-10 11:46:25 --> Input Class Initialized
INFO - 2020-02-10 11:46:25 --> Input Class Initialized
INFO - 2020-02-10 11:46:25 --> Language Class Initialized
INFO - 2020-02-10 11:46:25 --> Security Class Initialized
INFO - 2020-02-10 11:46:25 --> Language Class Initialized
INFO - 2020-02-10 11:46:25 --> Language Class Initialized
ERROR - 2020-02-10 11:46:25 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-10 11:46:25 --> Language Class Initialized
DEBUG - 2020-02-10 11:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:25 --> Language Class Initialized
ERROR - 2020-02-10 11:46:25 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-10 11:46:25 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-10 11:46:25 --> Loader Class Initialized
INFO - 2020-02-10 11:46:25 --> Input Class Initialized
INFO - 2020-02-10 11:46:25 --> Loader Class Initialized
INFO - 2020-02-10 11:46:25 --> Config Class Initialized
INFO - 2020-02-10 11:46:25 --> Hooks Class Initialized
INFO - 2020-02-10 11:46:25 --> Language Class Initialized
INFO - 2020-02-10 11:46:25 --> Helper loaded: url_helper
INFO - 2020-02-10 11:46:26 --> Helper loaded: url_helper
INFO - 2020-02-10 11:46:26 --> Config Class Initialized
INFO - 2020-02-10 11:46:26 --> Config Class Initialized
INFO - 2020-02-10 11:46:26 --> Hooks Class Initialized
INFO - 2020-02-10 11:46:26 --> Hooks Class Initialized
ERROR - 2020-02-10 11:46:26 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-10 11:46:26 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:26 --> Database Driver Class Initialized
INFO - 2020-02-10 11:46:26 --> Database Driver Class Initialized
INFO - 2020-02-10 11:46:26 --> Utf8 Class Initialized
DEBUG - 2020-02-10 11:46:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:46:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-10 11:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 11:46:26 --> Config Class Initialized
INFO - 2020-02-10 11:46:26 --> Hooks Class Initialized
INFO - 2020-02-10 11:46:26 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:26 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:46:26 --> URI Class Initialized
INFO - 2020-02-10 11:46:26 --> URI Class Initialized
INFO - 2020-02-10 11:46:26 --> URI Class Initialized
INFO - 2020-02-10 11:46:26 --> Controller Class Initialized
INFO - 2020-02-10 11:46:26 --> Router Class Initialized
DEBUG - 2020-02-10 11:46:26 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:26 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:26 --> Router Class Initialized
INFO - 2020-02-10 11:46:26 --> Output Class Initialized
INFO - 2020-02-10 11:46:26 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:46:26 --> Router Class Initialized
INFO - 2020-02-10 11:46:26 --> URI Class Initialized
INFO - 2020-02-10 11:46:26 --> Output Class Initialized
INFO - 2020-02-10 11:46:26 --> Security Class Initialized
INFO - 2020-02-10 11:46:26 --> Output Class Initialized
INFO - 2020-02-10 11:46:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:46:26 --> Model "M_pesan" initialized
DEBUG - 2020-02-10 11:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:26 --> Security Class Initialized
INFO - 2020-02-10 11:46:26 --> Router Class Initialized
INFO - 2020-02-10 11:46:26 --> Security Class Initialized
INFO - 2020-02-10 11:46:26 --> Input Class Initialized
DEBUG - 2020-02-10 11:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:26 --> Output Class Initialized
DEBUG - 2020-02-10 11:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:26 --> Helper loaded: form_helper
INFO - 2020-02-10 11:46:26 --> Input Class Initialized
INFO - 2020-02-10 11:46:26 --> Form Validation Class Initialized
INFO - 2020-02-10 11:46:26 --> Input Class Initialized
INFO - 2020-02-10 11:46:26 --> Language Class Initialized
INFO - 2020-02-10 11:46:26 --> Security Class Initialized
INFO - 2020-02-10 11:46:26 --> Language Class Initialized
INFO - 2020-02-10 11:46:26 --> Language Class Initialized
DEBUG - 2020-02-10 11:46:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-10 11:46:26 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-10 11:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 11:46:26 --> Input Class Initialized
ERROR - 2020-02-10 11:46:26 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 11:46:26 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-10 11:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-10 11:46:26 --> Config Class Initialized
INFO - 2020-02-10 11:46:26 --> Hooks Class Initialized
INFO - 2020-02-10 11:46:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 11:46:26 --> Language Class Initialized
INFO - 2020-02-10 11:46:26 --> Config Class Initialized
INFO - 2020-02-10 11:46:26 --> Config Class Initialized
INFO - 2020-02-10 11:46:26 --> Hooks Class Initialized
INFO - 2020-02-10 11:46:26 --> Final output sent to browser
INFO - 2020-02-10 11:46:26 --> Hooks Class Initialized
ERROR - 2020-02-10 11:46:26 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-10 11:46:26 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:27 --> Utf8 Class Initialized
DEBUG - 2020-02-10 11:46:27 --> Total execution time: 1.3961
DEBUG - 2020-02-10 11:46:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-10 11:46:27 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:27 --> Config Class Initialized
INFO - 2020-02-10 11:46:27 --> Hooks Class Initialized
INFO - 2020-02-10 11:46:27 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 11:46:27 --> URI Class Initialized
INFO - 2020-02-10 11:46:27 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:27 --> Controller Class Initialized
INFO - 2020-02-10 11:46:27 --> URI Class Initialized
INFO - 2020-02-10 11:46:27 --> Router Class Initialized
INFO - 2020-02-10 11:46:27 --> URI Class Initialized
DEBUG - 2020-02-10 11:46:27 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:27 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:27 --> Router Class Initialized
INFO - 2020-02-10 11:46:27 --> Output Class Initialized
INFO - 2020-02-10 11:46:27 --> Router Class Initialized
INFO - 2020-02-10 11:46:27 --> Model "M_tiket" initialized
INFO - 2020-02-10 11:46:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 11:46:27 --> URI Class Initialized
INFO - 2020-02-10 11:46:27 --> Security Class Initialized
INFO - 2020-02-10 11:46:27 --> Output Class Initialized
INFO - 2020-02-10 11:46:27 --> Output Class Initialized
INFO - 2020-02-10 11:46:27 --> Model "M_pesan" initialized
INFO - 2020-02-10 11:46:27 --> Security Class Initialized
INFO - 2020-02-10 11:46:27 --> Router Class Initialized
INFO - 2020-02-10 11:46:27 --> Security Class Initialized
DEBUG - 2020-02-10 11:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:27 --> Input Class Initialized
DEBUG - 2020-02-10 11:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:27 --> Output Class Initialized
DEBUG - 2020-02-10 11:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:27 --> Helper loaded: form_helper
INFO - 2020-02-10 11:46:27 --> Form Validation Class Initialized
INFO - 2020-02-10 11:46:27 --> Input Class Initialized
INFO - 2020-02-10 11:46:27 --> Language Class Initialized
INFO - 2020-02-10 11:46:27 --> Input Class Initialized
INFO - 2020-02-10 11:46:27 --> Security Class Initialized
INFO - 2020-02-10 11:46:27 --> Language Class Initialized
INFO - 2020-02-10 11:46:27 --> Language Class Initialized
DEBUG - 2020-02-10 11:46:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-10 11:46:27 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-10 11:46:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-10 11:46:27 --> Input Class Initialized
ERROR - 2020-02-10 11:46:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-10 11:46:27 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-10 11:46:27 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 11:46:27 --> Language Class Initialized
INFO - 2020-02-10 11:46:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-10 11:46:27 --> Final output sent to browser
ERROR - 2020-02-10 11:46:27 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-10 11:46:27 --> Total execution time: 1.8301
INFO - 2020-02-10 11:46:27 --> Config Class Initialized
INFO - 2020-02-10 11:46:27 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:46:27 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:27 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:27 --> URI Class Initialized
INFO - 2020-02-10 11:46:27 --> Router Class Initialized
INFO - 2020-02-10 11:46:27 --> Output Class Initialized
INFO - 2020-02-10 11:46:27 --> Security Class Initialized
DEBUG - 2020-02-10 11:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:27 --> Input Class Initialized
INFO - 2020-02-10 11:46:27 --> Language Class Initialized
ERROR - 2020-02-10 11:46:27 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-10 11:46:27 --> Config Class Initialized
INFO - 2020-02-10 11:46:27 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:46:27 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:27 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:28 --> URI Class Initialized
INFO - 2020-02-10 11:46:28 --> Router Class Initialized
INFO - 2020-02-10 11:46:28 --> Output Class Initialized
INFO - 2020-02-10 11:46:28 --> Security Class Initialized
DEBUG - 2020-02-10 11:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:28 --> Input Class Initialized
INFO - 2020-02-10 11:46:28 --> Language Class Initialized
ERROR - 2020-02-10 11:46:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-10 11:46:28 --> Config Class Initialized
INFO - 2020-02-10 11:46:28 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:46:28 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:28 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:28 --> URI Class Initialized
INFO - 2020-02-10 11:46:28 --> Router Class Initialized
INFO - 2020-02-10 11:46:28 --> Output Class Initialized
INFO - 2020-02-10 11:46:28 --> Security Class Initialized
DEBUG - 2020-02-10 11:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:28 --> Input Class Initialized
INFO - 2020-02-10 11:46:28 --> Language Class Initialized
ERROR - 2020-02-10 11:46:28 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 11:46:28 --> Config Class Initialized
INFO - 2020-02-10 11:46:28 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:46:28 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:28 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:28 --> URI Class Initialized
INFO - 2020-02-10 11:46:28 --> Router Class Initialized
INFO - 2020-02-10 11:46:28 --> Output Class Initialized
INFO - 2020-02-10 11:46:29 --> Security Class Initialized
DEBUG - 2020-02-10 11:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:29 --> Input Class Initialized
INFO - 2020-02-10 11:46:29 --> Language Class Initialized
ERROR - 2020-02-10 11:46:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-10 11:46:29 --> Config Class Initialized
INFO - 2020-02-10 11:46:29 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:46:29 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:29 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:29 --> URI Class Initialized
INFO - 2020-02-10 11:46:29 --> Router Class Initialized
INFO - 2020-02-10 11:46:29 --> Output Class Initialized
INFO - 2020-02-10 11:46:29 --> Security Class Initialized
DEBUG - 2020-02-10 11:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:29 --> Input Class Initialized
INFO - 2020-02-10 11:46:29 --> Language Class Initialized
ERROR - 2020-02-10 11:46:29 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-10 11:46:29 --> Config Class Initialized
INFO - 2020-02-10 11:46:29 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:46:29 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:29 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:29 --> URI Class Initialized
INFO - 2020-02-10 11:46:29 --> Router Class Initialized
INFO - 2020-02-10 11:46:29 --> Output Class Initialized
INFO - 2020-02-10 11:46:29 --> Security Class Initialized
DEBUG - 2020-02-10 11:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:29 --> Input Class Initialized
INFO - 2020-02-10 11:46:29 --> Language Class Initialized
ERROR - 2020-02-10 11:46:30 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-10 11:46:30 --> Config Class Initialized
INFO - 2020-02-10 11:46:30 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:46:30 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:30 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:30 --> URI Class Initialized
INFO - 2020-02-10 11:46:30 --> Router Class Initialized
INFO - 2020-02-10 11:46:30 --> Output Class Initialized
INFO - 2020-02-10 11:46:30 --> Security Class Initialized
DEBUG - 2020-02-10 11:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:30 --> Input Class Initialized
INFO - 2020-02-10 11:46:30 --> Language Class Initialized
ERROR - 2020-02-10 11:46:30 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-10 11:46:30 --> Config Class Initialized
INFO - 2020-02-10 11:46:30 --> Hooks Class Initialized
DEBUG - 2020-02-10 11:46:30 --> UTF-8 Support Enabled
INFO - 2020-02-10 11:46:30 --> Utf8 Class Initialized
INFO - 2020-02-10 11:46:30 --> URI Class Initialized
INFO - 2020-02-10 11:46:30 --> Router Class Initialized
INFO - 2020-02-10 11:46:30 --> Output Class Initialized
INFO - 2020-02-10 11:46:30 --> Security Class Initialized
DEBUG - 2020-02-10 11:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 11:46:30 --> Input Class Initialized
INFO - 2020-02-10 11:46:30 --> Language Class Initialized
ERROR - 2020-02-10 11:46:30 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-10 12:09:31 --> Config Class Initialized
INFO - 2020-02-10 12:09:31 --> Hooks Class Initialized
DEBUG - 2020-02-10 12:09:31 --> UTF-8 Support Enabled
INFO - 2020-02-10 12:09:31 --> Utf8 Class Initialized
INFO - 2020-02-10 12:09:31 --> URI Class Initialized
INFO - 2020-02-10 12:09:31 --> Router Class Initialized
INFO - 2020-02-10 12:09:31 --> Output Class Initialized
INFO - 2020-02-10 12:09:31 --> Security Class Initialized
DEBUG - 2020-02-10 12:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 12:09:31 --> Input Class Initialized
INFO - 2020-02-10 12:09:31 --> Language Class Initialized
INFO - 2020-02-10 12:09:31 --> Loader Class Initialized
INFO - 2020-02-10 12:09:32 --> Helper loaded: url_helper
INFO - 2020-02-10 12:09:32 --> Database Driver Class Initialized
DEBUG - 2020-02-10 12:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 12:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 12:09:32 --> Controller Class Initialized
INFO - 2020-02-10 12:09:32 --> Model "M_tiket" initialized
INFO - 2020-02-10 12:09:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-10 12:09:32 --> Model "M_pesan" initialized
INFO - 2020-02-10 12:09:32 --> Helper loaded: form_helper
INFO - 2020-02-10 12:09:32 --> Form Validation Class Initialized
INFO - 2020-02-10 12:09:32 --> Final output sent to browser
DEBUG - 2020-02-10 12:09:32 --> Total execution time: 0.9448
