<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-26 08:01:00 --> Config Class Initialized
INFO - 2019-12-26 08:01:00 --> Hooks Class Initialized
DEBUG - 2019-12-26 08:01:01 --> UTF-8 Support Enabled
INFO - 2019-12-26 08:01:01 --> Utf8 Class Initialized
INFO - 2019-12-26 08:01:01 --> URI Class Initialized
DEBUG - 2019-12-26 08:01:01 --> No URI present. Default controller set.
INFO - 2019-12-26 08:01:01 --> Router Class Initialized
INFO - 2019-12-26 08:01:01 --> Output Class Initialized
INFO - 2019-12-26 08:01:01 --> Security Class Initialized
DEBUG - 2019-12-26 08:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 08:01:01 --> Input Class Initialized
INFO - 2019-12-26 08:01:01 --> Language Class Initialized
INFO - 2019-12-26 08:01:01 --> Loader Class Initialized
INFO - 2019-12-26 08:01:02 --> Helper loaded: url_helper
INFO - 2019-12-26 08:01:02 --> Database Driver Class Initialized
DEBUG - 2019-12-26 08:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 08:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 08:01:03 --> Controller Class Initialized
INFO - 2019-12-26 08:01:03 --> Model "M_login" initialized
INFO - 2019-12-26 08:01:03 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2019-12-26 08:01:03 --> Final output sent to browser
DEBUG - 2019-12-26 08:01:03 --> Total execution time: 3.0079
INFO - 2019-12-26 08:01:12 --> Config Class Initialized
INFO - 2019-12-26 08:01:12 --> Hooks Class Initialized
DEBUG - 2019-12-26 08:01:12 --> UTF-8 Support Enabled
INFO - 2019-12-26 08:01:12 --> Utf8 Class Initialized
INFO - 2019-12-26 08:01:12 --> URI Class Initialized
INFO - 2019-12-26 08:01:12 --> Router Class Initialized
INFO - 2019-12-26 08:01:12 --> Output Class Initialized
INFO - 2019-12-26 08:01:12 --> Security Class Initialized
DEBUG - 2019-12-26 08:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 08:01:12 --> Input Class Initialized
INFO - 2019-12-26 08:01:12 --> Language Class Initialized
INFO - 2019-12-26 08:01:12 --> Loader Class Initialized
INFO - 2019-12-26 08:01:12 --> Helper loaded: url_helper
INFO - 2019-12-26 08:01:12 --> Database Driver Class Initialized
DEBUG - 2019-12-26 08:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 08:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 08:01:12 --> Controller Class Initialized
INFO - 2019-12-26 08:01:12 --> Model "M_login" initialized
INFO - 2019-12-26 08:01:12 --> Config Class Initialized
INFO - 2019-12-26 08:01:12 --> Hooks Class Initialized
DEBUG - 2019-12-26 08:01:13 --> UTF-8 Support Enabled
INFO - 2019-12-26 08:01:13 --> Utf8 Class Initialized
INFO - 2019-12-26 08:01:13 --> URI Class Initialized
INFO - 2019-12-26 08:01:13 --> Router Class Initialized
INFO - 2019-12-26 08:01:13 --> Output Class Initialized
INFO - 2019-12-26 08:01:13 --> Security Class Initialized
DEBUG - 2019-12-26 08:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 08:01:13 --> Input Class Initialized
INFO - 2019-12-26 08:01:13 --> Language Class Initialized
INFO - 2019-12-26 08:01:13 --> Loader Class Initialized
INFO - 2019-12-26 08:01:13 --> Helper loaded: url_helper
INFO - 2019-12-26 08:01:13 --> Database Driver Class Initialized
DEBUG - 2019-12-26 08:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 08:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 08:01:13 --> Controller Class Initialized
INFO - 2019-12-26 08:01:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 08:01:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-26 08:01:13 --> Final output sent to browser
DEBUG - 2019-12-26 08:01:13 --> Total execution time: 0.6389
INFO - 2019-12-26 08:01:14 --> Config Class Initialized
INFO - 2019-12-26 08:01:14 --> Hooks Class Initialized
INFO - 2019-12-26 08:01:14 --> Config Class Initialized
INFO - 2019-12-26 08:01:14 --> Hooks Class Initialized
DEBUG - 2019-12-26 08:01:14 --> UTF-8 Support Enabled
INFO - 2019-12-26 08:01:14 --> Utf8 Class Initialized
DEBUG - 2019-12-26 08:01:14 --> UTF-8 Support Enabled
INFO - 2019-12-26 08:01:14 --> Utf8 Class Initialized
INFO - 2019-12-26 08:01:14 --> URI Class Initialized
INFO - 2019-12-26 08:01:14 --> URI Class Initialized
INFO - 2019-12-26 08:01:14 --> Router Class Initialized
INFO - 2019-12-26 08:01:14 --> Router Class Initialized
INFO - 2019-12-26 08:01:14 --> Output Class Initialized
INFO - 2019-12-26 08:01:14 --> Output Class Initialized
INFO - 2019-12-26 08:01:14 --> Security Class Initialized
INFO - 2019-12-26 08:01:14 --> Security Class Initialized
DEBUG - 2019-12-26 08:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 08:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 08:01:14 --> Input Class Initialized
INFO - 2019-12-26 08:01:14 --> Input Class Initialized
INFO - 2019-12-26 08:01:14 --> Language Class Initialized
INFO - 2019-12-26 08:01:14 --> Language Class Initialized
ERROR - 2019-12-26 08:01:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-26 08:01:14 --> 404 Page Not Found: Assets/js
INFO - 2019-12-26 08:01:14 --> Config Class Initialized
INFO - 2019-12-26 08:01:14 --> Hooks Class Initialized
DEBUG - 2019-12-26 08:01:14 --> UTF-8 Support Enabled
INFO - 2019-12-26 08:01:14 --> Utf8 Class Initialized
INFO - 2019-12-26 08:01:14 --> URI Class Initialized
INFO - 2019-12-26 08:01:14 --> Router Class Initialized
INFO - 2019-12-26 08:01:14 --> Output Class Initialized
INFO - 2019-12-26 08:01:14 --> Security Class Initialized
DEBUG - 2019-12-26 08:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 08:01:14 --> Input Class Initialized
INFO - 2019-12-26 08:01:15 --> Language Class Initialized
ERROR - 2019-12-26 08:01:15 --> 404 Page Not Found: Assets/js
INFO - 2019-12-26 09:31:23 --> Config Class Initialized
INFO - 2019-12-26 09:31:23 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:31:23 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:31:23 --> Utf8 Class Initialized
INFO - 2019-12-26 09:31:23 --> URI Class Initialized
DEBUG - 2019-12-26 09:31:23 --> No URI present. Default controller set.
INFO - 2019-12-26 09:31:23 --> Router Class Initialized
INFO - 2019-12-26 09:31:23 --> Output Class Initialized
INFO - 2019-12-26 09:31:24 --> Security Class Initialized
DEBUG - 2019-12-26 09:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:31:24 --> Input Class Initialized
INFO - 2019-12-26 09:31:24 --> Language Class Initialized
INFO - 2019-12-26 09:31:24 --> Loader Class Initialized
INFO - 2019-12-26 09:31:24 --> Helper loaded: url_helper
INFO - 2019-12-26 09:31:24 --> Database Driver Class Initialized
DEBUG - 2019-12-26 09:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 09:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 09:31:24 --> Controller Class Initialized
INFO - 2019-12-26 09:31:24 --> Model "M_login" initialized
INFO - 2019-12-26 09:31:24 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2019-12-26 09:31:25 --> Final output sent to browser
DEBUG - 2019-12-26 09:31:25 --> Total execution time: 1.6575
INFO - 2019-12-26 09:31:34 --> Config Class Initialized
INFO - 2019-12-26 09:31:34 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:31:34 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:31:34 --> Utf8 Class Initialized
INFO - 2019-12-26 09:31:34 --> URI Class Initialized
INFO - 2019-12-26 09:31:34 --> Router Class Initialized
INFO - 2019-12-26 09:31:34 --> Output Class Initialized
INFO - 2019-12-26 09:31:34 --> Security Class Initialized
DEBUG - 2019-12-26 09:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:31:34 --> Input Class Initialized
INFO - 2019-12-26 09:31:34 --> Language Class Initialized
INFO - 2019-12-26 09:31:35 --> Loader Class Initialized
INFO - 2019-12-26 09:31:35 --> Helper loaded: url_helper
INFO - 2019-12-26 09:31:35 --> Database Driver Class Initialized
DEBUG - 2019-12-26 09:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 09:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 09:31:35 --> Controller Class Initialized
INFO - 2019-12-26 09:31:35 --> Model "M_login" initialized
INFO - 2019-12-26 09:31:35 --> Config Class Initialized
INFO - 2019-12-26 09:31:35 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:31:35 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:31:35 --> Utf8 Class Initialized
INFO - 2019-12-26 09:31:35 --> URI Class Initialized
INFO - 2019-12-26 09:31:35 --> Router Class Initialized
INFO - 2019-12-26 09:31:35 --> Output Class Initialized
INFO - 2019-12-26 09:31:35 --> Security Class Initialized
DEBUG - 2019-12-26 09:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:31:35 --> Input Class Initialized
INFO - 2019-12-26 09:31:35 --> Language Class Initialized
INFO - 2019-12-26 09:31:35 --> Loader Class Initialized
INFO - 2019-12-26 09:31:35 --> Helper loaded: url_helper
INFO - 2019-12-26 09:31:36 --> Database Driver Class Initialized
DEBUG - 2019-12-26 09:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 09:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 09:31:36 --> Controller Class Initialized
INFO - 2019-12-26 09:31:36 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 09:31:36 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-26 09:31:36 --> Final output sent to browser
DEBUG - 2019-12-26 09:31:36 --> Total execution time: 1.1701
INFO - 2019-12-26 09:31:36 --> Config Class Initialized
INFO - 2019-12-26 09:31:36 --> Hooks Class Initialized
INFO - 2019-12-26 09:31:36 --> Config Class Initialized
INFO - 2019-12-26 09:31:36 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:31:36 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:31:36 --> Utf8 Class Initialized
DEBUG - 2019-12-26 09:31:36 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:31:36 --> Utf8 Class Initialized
INFO - 2019-12-26 09:31:36 --> URI Class Initialized
INFO - 2019-12-26 09:31:36 --> Router Class Initialized
INFO - 2019-12-26 09:31:36 --> URI Class Initialized
INFO - 2019-12-26 09:31:36 --> Router Class Initialized
INFO - 2019-12-26 09:31:36 --> Output Class Initialized
INFO - 2019-12-26 09:31:36 --> Security Class Initialized
INFO - 2019-12-26 09:31:36 --> Output Class Initialized
INFO - 2019-12-26 09:31:36 --> Security Class Initialized
DEBUG - 2019-12-26 09:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:31:36 --> Input Class Initialized
DEBUG - 2019-12-26 09:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:31:36 --> Input Class Initialized
INFO - 2019-12-26 09:31:36 --> Language Class Initialized
INFO - 2019-12-26 09:31:36 --> Language Class Initialized
ERROR - 2019-12-26 09:31:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-26 09:31:36 --> 404 Page Not Found: Assets/js
INFO - 2019-12-26 09:31:37 --> Config Class Initialized
INFO - 2019-12-26 09:31:37 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:31:37 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:31:37 --> Utf8 Class Initialized
INFO - 2019-12-26 09:31:37 --> URI Class Initialized
INFO - 2019-12-26 09:31:37 --> Router Class Initialized
INFO - 2019-12-26 09:31:37 --> Output Class Initialized
INFO - 2019-12-26 09:31:37 --> Security Class Initialized
DEBUG - 2019-12-26 09:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:31:37 --> Input Class Initialized
INFO - 2019-12-26 09:31:37 --> Language Class Initialized
ERROR - 2019-12-26 09:31:38 --> 404 Page Not Found: Assets/js
INFO - 2019-12-26 09:31:38 --> Config Class Initialized
INFO - 2019-12-26 09:31:38 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:31:38 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:31:38 --> Utf8 Class Initialized
INFO - 2019-12-26 09:31:38 --> URI Class Initialized
INFO - 2019-12-26 09:31:38 --> Router Class Initialized
INFO - 2019-12-26 09:31:38 --> Output Class Initialized
INFO - 2019-12-26 09:31:38 --> Security Class Initialized
DEBUG - 2019-12-26 09:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:31:38 --> Input Class Initialized
INFO - 2019-12-26 09:31:38 --> Language Class Initialized
ERROR - 2019-12-26 09:31:38 --> 404 Page Not Found: Assets/js
INFO - 2019-12-26 09:31:46 --> Config Class Initialized
INFO - 2019-12-26 09:31:46 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:31:46 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:31:46 --> Utf8 Class Initialized
INFO - 2019-12-26 09:31:46 --> URI Class Initialized
INFO - 2019-12-26 09:31:46 --> Router Class Initialized
INFO - 2019-12-26 09:31:46 --> Output Class Initialized
INFO - 2019-12-26 09:31:46 --> Security Class Initialized
DEBUG - 2019-12-26 09:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:31:46 --> Input Class Initialized
INFO - 2019-12-26 09:31:46 --> Language Class Initialized
ERROR - 2019-12-26 09:31:46 --> 404 Page Not Found: Admin/index
INFO - 2019-12-26 09:32:07 --> Config Class Initialized
INFO - 2019-12-26 09:32:07 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:32:07 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:32:07 --> Utf8 Class Initialized
INFO - 2019-12-26 09:32:07 --> URI Class Initialized
INFO - 2019-12-26 09:32:07 --> Router Class Initialized
INFO - 2019-12-26 09:32:07 --> Output Class Initialized
INFO - 2019-12-26 09:32:07 --> Security Class Initialized
DEBUG - 2019-12-26 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:32:07 --> Input Class Initialized
INFO - 2019-12-26 09:32:07 --> Language Class Initialized
ERROR - 2019-12-26 09:32:08 --> 404 Page Not Found: Pemesanan/index
INFO - 2019-12-26 09:32:21 --> Config Class Initialized
INFO - 2019-12-26 09:32:21 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:32:21 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:32:21 --> Utf8 Class Initialized
INFO - 2019-12-26 09:32:21 --> URI Class Initialized
INFO - 2019-12-26 09:32:21 --> Router Class Initialized
INFO - 2019-12-26 09:32:21 --> Output Class Initialized
INFO - 2019-12-26 09:32:21 --> Security Class Initialized
DEBUG - 2019-12-26 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:32:21 --> Input Class Initialized
INFO - 2019-12-26 09:32:21 --> Language Class Initialized
ERROR - 2019-12-26 09:32:21 --> 404 Page Not Found: Tambah_pemesanan/index
INFO - 2019-12-26 09:34:16 --> Config Class Initialized
INFO - 2019-12-26 09:34:16 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:34:16 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:34:16 --> Utf8 Class Initialized
INFO - 2019-12-26 09:34:16 --> URI Class Initialized
INFO - 2019-12-26 09:34:16 --> Router Class Initialized
INFO - 2019-12-26 09:34:16 --> Output Class Initialized
INFO - 2019-12-26 09:34:16 --> Security Class Initialized
DEBUG - 2019-12-26 09:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:34:16 --> Input Class Initialized
INFO - 2019-12-26 09:34:16 --> Language Class Initialized
INFO - 2019-12-26 09:34:16 --> Config Class Initialized
INFO - 2019-12-26 09:34:16 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:34:16 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:34:16 --> Utf8 Class Initialized
INFO - 2019-12-26 09:34:16 --> URI Class Initialized
INFO - 2019-12-26 09:34:16 --> Loader Class Initialized
DEBUG - 2019-12-26 09:34:16 --> No URI present. Default controller set.
INFO - 2019-12-26 09:34:16 --> Helper loaded: url_helper
INFO - 2019-12-26 09:34:16 --> Router Class Initialized
INFO - 2019-12-26 09:34:16 --> Database Driver Class Initialized
INFO - 2019-12-26 09:34:16 --> Output Class Initialized
INFO - 2019-12-26 09:34:16 --> Security Class Initialized
DEBUG - 2019-12-26 09:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 09:34:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-12-26 09:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:34:16 --> Controller Class Initialized
INFO - 2019-12-26 09:34:16 --> Input Class Initialized
INFO - 2019-12-26 09:34:16 --> Language Class Initialized
INFO - 2019-12-26 09:34:16 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 09:34:16 --> Loader Class Initialized
INFO - 2019-12-26 09:34:16 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-26 09:34:16 --> Helper loaded: url_helper
INFO - 2019-12-26 09:34:16 --> Final output sent to browser
INFO - 2019-12-26 09:34:17 --> Database Driver Class Initialized
DEBUG - 2019-12-26 09:34:17 --> Total execution time: 0.7989
DEBUG - 2019-12-26 09:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 09:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 09:34:17 --> Controller Class Initialized
INFO - 2019-12-26 09:34:17 --> Model "M_login" initialized
INFO - 2019-12-26 09:34:17 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2019-12-26 09:34:17 --> Final output sent to browser
DEBUG - 2019-12-26 09:34:17 --> Total execution time: 0.4029
INFO - 2019-12-26 09:34:20 --> Config Class Initialized
INFO - 2019-12-26 09:34:20 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:34:20 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:34:20 --> Utf8 Class Initialized
INFO - 2019-12-26 09:34:20 --> URI Class Initialized
INFO - 2019-12-26 09:34:20 --> Router Class Initialized
INFO - 2019-12-26 09:34:21 --> Output Class Initialized
INFO - 2019-12-26 09:34:21 --> Security Class Initialized
DEBUG - 2019-12-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:34:21 --> Input Class Initialized
INFO - 2019-12-26 09:34:21 --> Language Class Initialized
INFO - 2019-12-26 09:34:21 --> Loader Class Initialized
INFO - 2019-12-26 09:34:21 --> Helper loaded: url_helper
INFO - 2019-12-26 09:34:21 --> Database Driver Class Initialized
DEBUG - 2019-12-26 09:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 09:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 09:34:21 --> Controller Class Initialized
INFO - 2019-12-26 09:34:21 --> Model "M_login" initialized
INFO - 2019-12-26 09:34:21 --> Config Class Initialized
INFO - 2019-12-26 09:34:21 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:34:21 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:34:21 --> Utf8 Class Initialized
INFO - 2019-12-26 09:34:21 --> URI Class Initialized
INFO - 2019-12-26 09:34:21 --> Router Class Initialized
INFO - 2019-12-26 09:34:21 --> Output Class Initialized
INFO - 2019-12-26 09:34:21 --> Security Class Initialized
DEBUG - 2019-12-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:34:21 --> Input Class Initialized
INFO - 2019-12-26 09:34:21 --> Language Class Initialized
INFO - 2019-12-26 09:34:21 --> Loader Class Initialized
INFO - 2019-12-26 09:34:21 --> Helper loaded: url_helper
INFO - 2019-12-26 09:34:21 --> Database Driver Class Initialized
DEBUG - 2019-12-26 09:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 09:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 09:34:22 --> Controller Class Initialized
INFO - 2019-12-26 09:34:22 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 09:34:22 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-26 09:34:22 --> Final output sent to browser
DEBUG - 2019-12-26 09:34:22 --> Total execution time: 0.6800
INFO - 2019-12-26 09:34:22 --> Config Class Initialized
INFO - 2019-12-26 09:34:22 --> Config Class Initialized
INFO - 2019-12-26 09:34:22 --> Hooks Class Initialized
INFO - 2019-12-26 09:34:22 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:34:22 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 09:34:22 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:34:22 --> Utf8 Class Initialized
INFO - 2019-12-26 09:34:22 --> Utf8 Class Initialized
INFO - 2019-12-26 09:34:22 --> URI Class Initialized
INFO - 2019-12-26 09:34:22 --> URI Class Initialized
INFO - 2019-12-26 09:34:22 --> Router Class Initialized
INFO - 2019-12-26 09:34:22 --> Router Class Initialized
INFO - 2019-12-26 09:34:22 --> Output Class Initialized
INFO - 2019-12-26 09:34:22 --> Output Class Initialized
INFO - 2019-12-26 09:34:22 --> Security Class Initialized
INFO - 2019-12-26 09:34:22 --> Security Class Initialized
DEBUG - 2019-12-26 09:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:34:22 --> Input Class Initialized
INFO - 2019-12-26 09:34:22 --> Input Class Initialized
INFO - 2019-12-26 09:34:22 --> Language Class Initialized
INFO - 2019-12-26 09:34:22 --> Language Class Initialized
ERROR - 2019-12-26 09:34:22 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-26 09:34:22 --> 404 Page Not Found: Assets/js
INFO - 2019-12-26 09:34:22 --> Config Class Initialized
INFO - 2019-12-26 09:34:22 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:34:22 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:34:22 --> Utf8 Class Initialized
INFO - 2019-12-26 09:34:22 --> URI Class Initialized
INFO - 2019-12-26 09:34:22 --> Router Class Initialized
INFO - 2019-12-26 09:34:23 --> Output Class Initialized
INFO - 2019-12-26 09:34:23 --> Security Class Initialized
DEBUG - 2019-12-26 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:34:23 --> Input Class Initialized
INFO - 2019-12-26 09:34:23 --> Language Class Initialized
ERROR - 2019-12-26 09:34:23 --> 404 Page Not Found: Assets/js
INFO - 2019-12-26 09:34:26 --> Config Class Initialized
INFO - 2019-12-26 09:34:26 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:34:26 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:34:26 --> Utf8 Class Initialized
INFO - 2019-12-26 09:34:26 --> URI Class Initialized
INFO - 2019-12-26 09:34:26 --> Router Class Initialized
INFO - 2019-12-26 09:34:26 --> Output Class Initialized
INFO - 2019-12-26 09:34:26 --> Security Class Initialized
DEBUG - 2019-12-26 09:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:34:27 --> Input Class Initialized
INFO - 2019-12-26 09:34:27 --> Language Class Initialized
INFO - 2019-12-26 09:34:27 --> Loader Class Initialized
INFO - 2019-12-26 09:34:27 --> Helper loaded: url_helper
INFO - 2019-12-26 09:34:27 --> Database Driver Class Initialized
DEBUG - 2019-12-26 09:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 09:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 09:34:27 --> Controller Class Initialized
INFO - 2019-12-26 09:34:27 --> Model "M_login" initialized
INFO - 2019-12-26 09:34:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 09:34:27 --> Pagination Class Initialized
INFO - 2019-12-26 09:34:27 --> Model "M_show" initialized
INFO - 2019-12-26 09:34:28 --> Helper loaded: form_helper
INFO - 2019-12-26 09:34:28 --> Form Validation Class Initialized
INFO - 2019-12-26 09:34:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 09:34:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2019-12-26 09:34:28 --> Final output sent to browser
DEBUG - 2019-12-26 09:34:28 --> Total execution time: 1.8463
INFO - 2019-12-26 09:34:28 --> Config Class Initialized
INFO - 2019-12-26 09:34:28 --> Config Class Initialized
INFO - 2019-12-26 09:34:28 --> Hooks Class Initialized
INFO - 2019-12-26 09:34:28 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 09:34:28 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:34:28 --> Utf8 Class Initialized
INFO - 2019-12-26 09:34:28 --> Utf8 Class Initialized
INFO - 2019-12-26 09:34:28 --> URI Class Initialized
INFO - 2019-12-26 09:34:28 --> URI Class Initialized
INFO - 2019-12-26 09:34:28 --> Router Class Initialized
INFO - 2019-12-26 09:34:28 --> Router Class Initialized
INFO - 2019-12-26 09:34:28 --> Output Class Initialized
INFO - 2019-12-26 09:34:28 --> Output Class Initialized
INFO - 2019-12-26 09:34:28 --> Security Class Initialized
INFO - 2019-12-26 09:34:28 --> Security Class Initialized
DEBUG - 2019-12-26 09:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 09:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:34:28 --> Input Class Initialized
INFO - 2019-12-26 09:34:28 --> Input Class Initialized
INFO - 2019-12-26 09:34:28 --> Language Class Initialized
INFO - 2019-12-26 09:34:28 --> Language Class Initialized
ERROR - 2019-12-26 09:34:28 --> 404 Page Not Found: Show/assets
ERROR - 2019-12-26 09:34:28 --> 404 Page Not Found: Show/assets
INFO - 2019-12-26 09:34:28 --> Config Class Initialized
INFO - 2019-12-26 09:34:28 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:34:29 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:34:29 --> Utf8 Class Initialized
INFO - 2019-12-26 09:34:29 --> URI Class Initialized
INFO - 2019-12-26 09:34:29 --> Router Class Initialized
INFO - 2019-12-26 09:34:29 --> Output Class Initialized
INFO - 2019-12-26 09:34:29 --> Security Class Initialized
DEBUG - 2019-12-26 09:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:34:29 --> Input Class Initialized
INFO - 2019-12-26 09:34:29 --> Language Class Initialized
ERROR - 2019-12-26 09:34:29 --> 404 Page Not Found: Show/assets
INFO - 2019-12-26 09:34:29 --> Config Class Initialized
INFO - 2019-12-26 09:34:29 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:34:29 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:34:29 --> Utf8 Class Initialized
INFO - 2019-12-26 09:34:29 --> URI Class Initialized
INFO - 2019-12-26 09:34:29 --> Router Class Initialized
INFO - 2019-12-26 09:34:29 --> Output Class Initialized
INFO - 2019-12-26 09:34:29 --> Security Class Initialized
DEBUG - 2019-12-26 09:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:34:29 --> Input Class Initialized
INFO - 2019-12-26 09:34:29 --> Language Class Initialized
ERROR - 2019-12-26 09:34:29 --> 404 Page Not Found: Show/assets
INFO - 2019-12-26 09:35:16 --> Config Class Initialized
INFO - 2019-12-26 09:35:16 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:35:16 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:35:16 --> Utf8 Class Initialized
INFO - 2019-12-26 09:35:16 --> URI Class Initialized
INFO - 2019-12-26 09:35:16 --> Router Class Initialized
INFO - 2019-12-26 09:35:16 --> Output Class Initialized
INFO - 2019-12-26 09:35:16 --> Security Class Initialized
DEBUG - 2019-12-26 09:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:35:16 --> Input Class Initialized
INFO - 2019-12-26 09:35:16 --> Language Class Initialized
ERROR - 2019-12-26 09:35:16 --> 404 Page Not Found: Pemesanan/index
INFO - 2019-12-26 09:35:25 --> Config Class Initialized
INFO - 2019-12-26 09:35:25 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:35:25 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:35:25 --> Utf8 Class Initialized
INFO - 2019-12-26 09:35:25 --> URI Class Initialized
INFO - 2019-12-26 09:35:25 --> Router Class Initialized
INFO - 2019-12-26 09:35:25 --> Output Class Initialized
INFO - 2019-12-26 09:35:25 --> Security Class Initialized
DEBUG - 2019-12-26 09:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:35:25 --> Input Class Initialized
INFO - 2019-12-26 09:35:25 --> Language Class Initialized
INFO - 2019-12-26 09:35:25 --> Loader Class Initialized
INFO - 2019-12-26 09:35:25 --> Helper loaded: url_helper
INFO - 2019-12-26 09:35:25 --> Database Driver Class Initialized
DEBUG - 2019-12-26 09:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 09:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 09:35:25 --> Controller Class Initialized
INFO - 2019-12-26 09:35:25 --> Model "M_login" initialized
INFO - 2019-12-26 09:35:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 09:35:25 --> Pagination Class Initialized
INFO - 2019-12-26 09:35:25 --> Model "M_show" initialized
INFO - 2019-12-26 09:35:25 --> Helper loaded: form_helper
INFO - 2019-12-26 09:35:25 --> Form Validation Class Initialized
INFO - 2019-12-26 09:35:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 09:35:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2019-12-26 09:35:25 --> Final output sent to browser
DEBUG - 2019-12-26 09:35:25 --> Total execution time: 0.6020
INFO - 2019-12-26 09:35:25 --> Config Class Initialized
INFO - 2019-12-26 09:35:25 --> Config Class Initialized
INFO - 2019-12-26 09:35:25 --> Hooks Class Initialized
INFO - 2019-12-26 09:35:25 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:35:25 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 09:35:25 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:35:26 --> Utf8 Class Initialized
INFO - 2019-12-26 09:35:26 --> Utf8 Class Initialized
INFO - 2019-12-26 09:35:26 --> URI Class Initialized
INFO - 2019-12-26 09:35:26 --> URI Class Initialized
INFO - 2019-12-26 09:35:26 --> Router Class Initialized
INFO - 2019-12-26 09:35:26 --> Router Class Initialized
INFO - 2019-12-26 09:35:26 --> Output Class Initialized
INFO - 2019-12-26 09:35:26 --> Output Class Initialized
INFO - 2019-12-26 09:35:26 --> Security Class Initialized
INFO - 2019-12-26 09:35:26 --> Security Class Initialized
DEBUG - 2019-12-26 09:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 09:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:35:26 --> Input Class Initialized
INFO - 2019-12-26 09:35:26 --> Input Class Initialized
INFO - 2019-12-26 09:35:26 --> Language Class Initialized
INFO - 2019-12-26 09:35:26 --> Language Class Initialized
ERROR - 2019-12-26 09:35:26 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 09:35:26 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 09:35:26 --> Config Class Initialized
INFO - 2019-12-26 09:35:26 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:35:26 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:35:26 --> Utf8 Class Initialized
INFO - 2019-12-26 09:35:26 --> URI Class Initialized
INFO - 2019-12-26 09:35:26 --> Router Class Initialized
INFO - 2019-12-26 09:35:26 --> Output Class Initialized
INFO - 2019-12-26 09:35:26 --> Security Class Initialized
DEBUG - 2019-12-26 09:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:35:26 --> Input Class Initialized
INFO - 2019-12-26 09:35:26 --> Language Class Initialized
ERROR - 2019-12-26 09:35:26 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 09:35:26 --> Config Class Initialized
INFO - 2019-12-26 09:35:26 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:35:26 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:35:26 --> Utf8 Class Initialized
INFO - 2019-12-26 09:35:26 --> URI Class Initialized
INFO - 2019-12-26 09:35:26 --> Router Class Initialized
INFO - 2019-12-26 09:35:26 --> Output Class Initialized
INFO - 2019-12-26 09:35:26 --> Security Class Initialized
DEBUG - 2019-12-26 09:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:35:26 --> Input Class Initialized
INFO - 2019-12-26 09:35:26 --> Language Class Initialized
ERROR - 2019-12-26 09:35:26 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 09:37:09 --> Config Class Initialized
INFO - 2019-12-26 09:37:09 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:37:09 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:37:09 --> Utf8 Class Initialized
INFO - 2019-12-26 09:37:10 --> URI Class Initialized
INFO - 2019-12-26 09:37:10 --> Router Class Initialized
INFO - 2019-12-26 09:37:10 --> Output Class Initialized
INFO - 2019-12-26 09:37:10 --> Security Class Initialized
DEBUG - 2019-12-26 09:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:37:10 --> Input Class Initialized
INFO - 2019-12-26 09:37:10 --> Language Class Initialized
ERROR - 2019-12-26 09:37:10 --> 404 Page Not Found: Pemesanan/index
INFO - 2019-12-26 09:37:15 --> Config Class Initialized
INFO - 2019-12-26 09:37:15 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:37:15 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:37:15 --> Utf8 Class Initialized
INFO - 2019-12-26 09:37:15 --> URI Class Initialized
INFO - 2019-12-26 09:37:16 --> Router Class Initialized
INFO - 2019-12-26 09:37:16 --> Output Class Initialized
INFO - 2019-12-26 09:37:16 --> Security Class Initialized
DEBUG - 2019-12-26 09:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:37:16 --> Input Class Initialized
INFO - 2019-12-26 09:37:16 --> Language Class Initialized
INFO - 2019-12-26 09:37:16 --> Loader Class Initialized
INFO - 2019-12-26 09:37:16 --> Helper loaded: url_helper
INFO - 2019-12-26 09:37:16 --> Database Driver Class Initialized
DEBUG - 2019-12-26 09:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 09:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 09:37:16 --> Controller Class Initialized
INFO - 2019-12-26 09:37:16 --> Model "M_login" initialized
INFO - 2019-12-26 09:37:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 09:37:16 --> Pagination Class Initialized
INFO - 2019-12-26 09:37:16 --> Model "M_show" initialized
INFO - 2019-12-26 09:37:16 --> Helper loaded: form_helper
INFO - 2019-12-26 09:37:16 --> Form Validation Class Initialized
INFO - 2019-12-26 09:37:16 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 09:37:16 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 09:37:16 --> Final output sent to browser
DEBUG - 2019-12-26 09:37:16 --> Total execution time: 0.5806
INFO - 2019-12-26 09:37:16 --> Config Class Initialized
INFO - 2019-12-26 09:37:16 --> Config Class Initialized
INFO - 2019-12-26 09:37:16 --> Hooks Class Initialized
INFO - 2019-12-26 09:37:16 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:37:16 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 09:37:16 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:37:16 --> Utf8 Class Initialized
INFO - 2019-12-26 09:37:16 --> Utf8 Class Initialized
INFO - 2019-12-26 09:37:16 --> URI Class Initialized
INFO - 2019-12-26 09:37:16 --> URI Class Initialized
INFO - 2019-12-26 09:37:16 --> Router Class Initialized
INFO - 2019-12-26 09:37:16 --> Router Class Initialized
INFO - 2019-12-26 09:37:16 --> Output Class Initialized
INFO - 2019-12-26 09:37:16 --> Output Class Initialized
INFO - 2019-12-26 09:37:16 --> Security Class Initialized
INFO - 2019-12-26 09:37:16 --> Security Class Initialized
DEBUG - 2019-12-26 09:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 09:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:37:16 --> Input Class Initialized
INFO - 2019-12-26 09:37:16 --> Input Class Initialized
INFO - 2019-12-26 09:37:16 --> Language Class Initialized
INFO - 2019-12-26 09:37:16 --> Language Class Initialized
ERROR - 2019-12-26 09:37:16 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 09:37:16 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 09:37:17 --> Config Class Initialized
INFO - 2019-12-26 09:37:17 --> Hooks Class Initialized
DEBUG - 2019-12-26 09:37:17 --> UTF-8 Support Enabled
INFO - 2019-12-26 09:37:17 --> Utf8 Class Initialized
INFO - 2019-12-26 09:37:17 --> URI Class Initialized
INFO - 2019-12-26 09:37:17 --> Router Class Initialized
INFO - 2019-12-26 09:37:17 --> Output Class Initialized
INFO - 2019-12-26 09:37:17 --> Security Class Initialized
DEBUG - 2019-12-26 09:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 09:37:17 --> Input Class Initialized
INFO - 2019-12-26 09:37:17 --> Language Class Initialized
ERROR - 2019-12-26 09:37:17 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:08:25 --> Config Class Initialized
INFO - 2019-12-26 10:08:25 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:08:25 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:08:25 --> Utf8 Class Initialized
INFO - 2019-12-26 10:08:25 --> URI Class Initialized
INFO - 2019-12-26 10:08:25 --> Router Class Initialized
INFO - 2019-12-26 10:08:25 --> Output Class Initialized
INFO - 2019-12-26 10:08:25 --> Security Class Initialized
DEBUG - 2019-12-26 10:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:08:25 --> Input Class Initialized
INFO - 2019-12-26 10:08:25 --> Language Class Initialized
INFO - 2019-12-26 10:08:25 --> Loader Class Initialized
INFO - 2019-12-26 10:08:25 --> Helper loaded: url_helper
INFO - 2019-12-26 10:08:25 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:08:25 --> Controller Class Initialized
INFO - 2019-12-26 10:08:25 --> Model "M_login" initialized
INFO - 2019-12-26 10:08:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:08:25 --> Pagination Class Initialized
INFO - 2019-12-26 10:08:25 --> Model "M_show" initialized
INFO - 2019-12-26 10:08:25 --> Helper loaded: form_helper
INFO - 2019-12-26 10:08:25 --> Form Validation Class Initialized
INFO - 2019-12-26 10:08:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-26 10:08:25 --> Severity: Notice --> Undefined property: stdClass::$id_pemesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 84
ERROR - 2019-12-26 10:08:26 --> Severity: Notice --> Undefined property: stdClass::$jumlah_pesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 86
ERROR - 2019-12-26 10:08:26 --> Severity: Notice --> Undefined property: stdClass::$status_pemesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 87
INFO - 2019-12-26 10:08:26 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:08:26 --> Final output sent to browser
DEBUG - 2019-12-26 10:08:26 --> Total execution time: 0.8388
INFO - 2019-12-26 10:13:00 --> Config Class Initialized
INFO - 2019-12-26 10:13:00 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:13:00 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:13:00 --> Utf8 Class Initialized
INFO - 2019-12-26 10:13:00 --> URI Class Initialized
INFO - 2019-12-26 10:13:00 --> Router Class Initialized
INFO - 2019-12-26 10:13:00 --> Output Class Initialized
INFO - 2019-12-26 10:13:00 --> Security Class Initialized
DEBUG - 2019-12-26 10:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:13:00 --> Input Class Initialized
INFO - 2019-12-26 10:13:00 --> Language Class Initialized
INFO - 2019-12-26 10:13:00 --> Loader Class Initialized
INFO - 2019-12-26 10:13:00 --> Helper loaded: url_helper
INFO - 2019-12-26 10:13:00 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:13:00 --> Controller Class Initialized
INFO - 2019-12-26 10:13:00 --> Model "M_login" initialized
INFO - 2019-12-26 10:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:13:00 --> Pagination Class Initialized
INFO - 2019-12-26 10:13:00 --> Model "M_show" initialized
INFO - 2019-12-26 10:13:00 --> Helper loaded: form_helper
INFO - 2019-12-26 10:13:00 --> Form Validation Class Initialized
INFO - 2019-12-26 10:13:00 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-26 10:13:00 --> Severity: Notice --> Undefined property: stdClass::$id_pemesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 84
ERROR - 2019-12-26 10:13:00 --> Severity: Notice --> Undefined property: stdClass::$jumlah_pesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 86
ERROR - 2019-12-26 10:13:00 --> Severity: Notice --> Undefined property: stdClass::$status_pemesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 87
INFO - 2019-12-26 10:13:00 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:13:00 --> Final output sent to browser
DEBUG - 2019-12-26 10:13:01 --> Total execution time: 0.5216
INFO - 2019-12-26 10:13:45 --> Config Class Initialized
INFO - 2019-12-26 10:13:45 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:13:45 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:13:46 --> Utf8 Class Initialized
INFO - 2019-12-26 10:13:46 --> URI Class Initialized
INFO - 2019-12-26 10:13:46 --> Router Class Initialized
INFO - 2019-12-26 10:13:46 --> Output Class Initialized
INFO - 2019-12-26 10:13:46 --> Security Class Initialized
DEBUG - 2019-12-26 10:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:13:46 --> Input Class Initialized
INFO - 2019-12-26 10:13:46 --> Language Class Initialized
INFO - 2019-12-26 10:13:46 --> Loader Class Initialized
INFO - 2019-12-26 10:13:46 --> Helper loaded: url_helper
INFO - 2019-12-26 10:13:46 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:13:46 --> Controller Class Initialized
INFO - 2019-12-26 10:13:46 --> Model "M_login" initialized
INFO - 2019-12-26 10:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:13:46 --> Pagination Class Initialized
INFO - 2019-12-26 10:13:46 --> Model "M_show" initialized
INFO - 2019-12-26 10:13:46 --> Helper loaded: form_helper
INFO - 2019-12-26 10:13:46 --> Form Validation Class Initialized
INFO - 2019-12-26 10:13:46 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-26 10:13:46 --> Severity: Notice --> Undefined property: stdClass::$id_pemesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 84
ERROR - 2019-12-26 10:13:46 --> Severity: Notice --> Undefined property: stdClass::$jumlah_pesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 86
ERROR - 2019-12-26 10:13:46 --> Severity: Notice --> Undefined property: stdClass::$status_pemesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 87
INFO - 2019-12-26 10:13:46 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:13:46 --> Final output sent to browser
DEBUG - 2019-12-26 10:13:46 --> Total execution time: 0.5074
INFO - 2019-12-26 10:13:46 --> Config Class Initialized
INFO - 2019-12-26 10:13:46 --> Config Class Initialized
INFO - 2019-12-26 10:13:46 --> Hooks Class Initialized
INFO - 2019-12-26 10:13:46 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:13:46 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 10:13:46 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:13:46 --> Utf8 Class Initialized
INFO - 2019-12-26 10:13:46 --> Utf8 Class Initialized
INFO - 2019-12-26 10:13:46 --> URI Class Initialized
INFO - 2019-12-26 10:13:46 --> URI Class Initialized
INFO - 2019-12-26 10:13:46 --> Router Class Initialized
INFO - 2019-12-26 10:13:46 --> Router Class Initialized
INFO - 2019-12-26 10:13:46 --> Output Class Initialized
INFO - 2019-12-26 10:13:46 --> Output Class Initialized
INFO - 2019-12-26 10:13:46 --> Security Class Initialized
INFO - 2019-12-26 10:13:46 --> Security Class Initialized
DEBUG - 2019-12-26 10:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 10:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:13:46 --> Input Class Initialized
INFO - 2019-12-26 10:13:46 --> Input Class Initialized
INFO - 2019-12-26 10:13:46 --> Language Class Initialized
INFO - 2019-12-26 10:13:46 --> Language Class Initialized
ERROR - 2019-12-26 10:13:46 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 10:13:47 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:13:47 --> Config Class Initialized
INFO - 2019-12-26 10:13:47 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:13:47 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:13:47 --> Utf8 Class Initialized
INFO - 2019-12-26 10:13:47 --> URI Class Initialized
INFO - 2019-12-26 10:13:47 --> Router Class Initialized
INFO - 2019-12-26 10:13:47 --> Output Class Initialized
INFO - 2019-12-26 10:13:47 --> Security Class Initialized
DEBUG - 2019-12-26 10:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:13:47 --> Input Class Initialized
INFO - 2019-12-26 10:13:47 --> Language Class Initialized
ERROR - 2019-12-26 10:13:47 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:13:47 --> Config Class Initialized
INFO - 2019-12-26 10:13:47 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:13:47 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:13:47 --> Utf8 Class Initialized
INFO - 2019-12-26 10:13:47 --> URI Class Initialized
INFO - 2019-12-26 10:13:47 --> Router Class Initialized
INFO - 2019-12-26 10:13:47 --> Output Class Initialized
INFO - 2019-12-26 10:13:47 --> Security Class Initialized
DEBUG - 2019-12-26 10:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:13:47 --> Input Class Initialized
INFO - 2019-12-26 10:13:47 --> Language Class Initialized
ERROR - 2019-12-26 10:13:47 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:16:25 --> Config Class Initialized
INFO - 2019-12-26 10:16:25 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:16:25 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:16:25 --> Utf8 Class Initialized
INFO - 2019-12-26 10:16:25 --> URI Class Initialized
INFO - 2019-12-26 10:16:25 --> Router Class Initialized
INFO - 2019-12-26 10:16:25 --> Output Class Initialized
INFO - 2019-12-26 10:16:25 --> Security Class Initialized
DEBUG - 2019-12-26 10:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:16:25 --> Input Class Initialized
INFO - 2019-12-26 10:16:25 --> Language Class Initialized
INFO - 2019-12-26 10:16:25 --> Loader Class Initialized
INFO - 2019-12-26 10:16:26 --> Helper loaded: url_helper
INFO - 2019-12-26 10:16:26 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:16:26 --> Controller Class Initialized
INFO - 2019-12-26 10:16:26 --> Model "M_login" initialized
INFO - 2019-12-26 10:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:16:26 --> Pagination Class Initialized
INFO - 2019-12-26 10:16:26 --> Model "M_show" initialized
INFO - 2019-12-26 10:16:26 --> Helper loaded: form_helper
INFO - 2019-12-26 10:16:26 --> Form Validation Class Initialized
INFO - 2019-12-26 10:16:26 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 10:16:26 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/tambah_show.php
INFO - 2019-12-26 10:16:26 --> Final output sent to browser
DEBUG - 2019-12-26 10:16:26 --> Total execution time: 0.4575
INFO - 2019-12-26 10:17:17 --> Config Class Initialized
INFO - 2019-12-26 10:17:17 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:17:17 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:17:17 --> Utf8 Class Initialized
INFO - 2019-12-26 10:17:17 --> URI Class Initialized
INFO - 2019-12-26 10:17:17 --> Router Class Initialized
INFO - 2019-12-26 10:17:17 --> Output Class Initialized
INFO - 2019-12-26 10:17:17 --> Security Class Initialized
DEBUG - 2019-12-26 10:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:17:17 --> Input Class Initialized
INFO - 2019-12-26 10:17:17 --> Language Class Initialized
INFO - 2019-12-26 10:17:17 --> Loader Class Initialized
INFO - 2019-12-26 10:17:18 --> Helper loaded: url_helper
INFO - 2019-12-26 10:17:18 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:17:18 --> Controller Class Initialized
INFO - 2019-12-26 10:17:18 --> Model "M_login" initialized
INFO - 2019-12-26 10:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:17:18 --> Pagination Class Initialized
INFO - 2019-12-26 10:17:18 --> Model "M_show" initialized
INFO - 2019-12-26 10:17:18 --> Helper loaded: form_helper
INFO - 2019-12-26 10:17:18 --> Form Validation Class Initialized
INFO - 2019-12-26 10:17:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-12-26 10:17:19 --> Upload Class Initialized
INFO - 2019-12-26 10:17:19 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2019-12-26 10:17:19 --> You did not select a file to upload.
INFO - 2019-12-26 10:17:19 --> Config Class Initialized
INFO - 2019-12-26 10:17:19 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:17:19 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:17:19 --> Utf8 Class Initialized
INFO - 2019-12-26 10:17:19 --> URI Class Initialized
INFO - 2019-12-26 10:17:19 --> Router Class Initialized
INFO - 2019-12-26 10:17:19 --> Output Class Initialized
INFO - 2019-12-26 10:17:19 --> Security Class Initialized
DEBUG - 2019-12-26 10:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:17:19 --> Input Class Initialized
INFO - 2019-12-26 10:17:19 --> Language Class Initialized
INFO - 2019-12-26 10:17:19 --> Loader Class Initialized
INFO - 2019-12-26 10:17:19 --> Helper loaded: url_helper
INFO - 2019-12-26 10:17:19 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:17:19 --> Controller Class Initialized
INFO - 2019-12-26 10:17:19 --> Model "M_login" initialized
INFO - 2019-12-26 10:17:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:17:19 --> Pagination Class Initialized
INFO - 2019-12-26 10:17:19 --> Model "M_show" initialized
INFO - 2019-12-26 10:17:19 --> Helper loaded: form_helper
INFO - 2019-12-26 10:17:19 --> Form Validation Class Initialized
INFO - 2019-12-26 10:17:19 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 10:17:19 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2019-12-26 10:17:19 --> Final output sent to browser
DEBUG - 2019-12-26 10:17:19 --> Total execution time: 0.4311
INFO - 2019-12-26 10:17:20 --> Config Class Initialized
INFO - 2019-12-26 10:17:20 --> Config Class Initialized
INFO - 2019-12-26 10:17:20 --> Hooks Class Initialized
INFO - 2019-12-26 10:17:20 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:17:20 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 10:17:20 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:17:20 --> Utf8 Class Initialized
INFO - 2019-12-26 10:17:20 --> Utf8 Class Initialized
INFO - 2019-12-26 10:17:20 --> URI Class Initialized
INFO - 2019-12-26 10:17:20 --> URI Class Initialized
INFO - 2019-12-26 10:17:20 --> Router Class Initialized
INFO - 2019-12-26 10:17:20 --> Router Class Initialized
INFO - 2019-12-26 10:17:20 --> Output Class Initialized
INFO - 2019-12-26 10:17:20 --> Output Class Initialized
INFO - 2019-12-26 10:17:20 --> Security Class Initialized
INFO - 2019-12-26 10:17:20 --> Security Class Initialized
DEBUG - 2019-12-26 10:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 10:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:17:20 --> Input Class Initialized
INFO - 2019-12-26 10:17:20 --> Input Class Initialized
INFO - 2019-12-26 10:17:20 --> Language Class Initialized
INFO - 2019-12-26 10:17:20 --> Language Class Initialized
ERROR - 2019-12-26 10:17:20 --> 404 Page Not Found: Show/assets
ERROR - 2019-12-26 10:17:20 --> 404 Page Not Found: Show/assets
INFO - 2019-12-26 10:17:20 --> Config Class Initialized
INFO - 2019-12-26 10:17:20 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:17:20 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:17:20 --> Utf8 Class Initialized
INFO - 2019-12-26 10:17:20 --> URI Class Initialized
INFO - 2019-12-26 10:17:20 --> Router Class Initialized
INFO - 2019-12-26 10:17:21 --> Output Class Initialized
INFO - 2019-12-26 10:17:21 --> Security Class Initialized
DEBUG - 2019-12-26 10:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:17:21 --> Input Class Initialized
INFO - 2019-12-26 10:17:21 --> Language Class Initialized
ERROR - 2019-12-26 10:17:21 --> 404 Page Not Found: Show/assets
INFO - 2019-12-26 10:17:30 --> Config Class Initialized
INFO - 2019-12-26 10:17:30 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:17:30 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:17:30 --> Utf8 Class Initialized
INFO - 2019-12-26 10:17:30 --> URI Class Initialized
INFO - 2019-12-26 10:17:30 --> Router Class Initialized
INFO - 2019-12-26 10:17:30 --> Output Class Initialized
INFO - 2019-12-26 10:17:30 --> Security Class Initialized
DEBUG - 2019-12-26 10:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:17:30 --> Input Class Initialized
INFO - 2019-12-26 10:17:30 --> Language Class Initialized
INFO - 2019-12-26 10:17:30 --> Loader Class Initialized
INFO - 2019-12-26 10:17:30 --> Helper loaded: url_helper
INFO - 2019-12-26 10:17:30 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:17:30 --> Controller Class Initialized
INFO - 2019-12-26 10:17:30 --> Model "M_login" initialized
INFO - 2019-12-26 10:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:17:30 --> Pagination Class Initialized
INFO - 2019-12-26 10:17:30 --> Model "M_show" initialized
INFO - 2019-12-26 10:17:30 --> Helper loaded: form_helper
INFO - 2019-12-26 10:17:30 --> Form Validation Class Initialized
INFO - 2019-12-26 10:17:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-26 10:17:30 --> Severity: Notice --> Undefined property: stdClass::$id_pemesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 84
ERROR - 2019-12-26 10:17:30 --> Severity: Notice --> Undefined property: stdClass::$jumlah_pesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 86
ERROR - 2019-12-26 10:17:30 --> Severity: Notice --> Undefined property: stdClass::$status_pemesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 87
ERROR - 2019-12-26 10:17:30 --> Severity: Notice --> Undefined property: stdClass::$id_pemesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 84
ERROR - 2019-12-26 10:17:30 --> Severity: Notice --> Undefined property: stdClass::$jumlah_pesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 86
ERROR - 2019-12-26 10:17:30 --> Severity: Notice --> Undefined property: stdClass::$status_pemesanan C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 87
INFO - 2019-12-26 10:17:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:17:30 --> Final output sent to browser
DEBUG - 2019-12-26 10:17:31 --> Total execution time: 0.5265
INFO - 2019-12-26 10:17:31 --> Config Class Initialized
INFO - 2019-12-26 10:17:31 --> Config Class Initialized
INFO - 2019-12-26 10:17:31 --> Hooks Class Initialized
INFO - 2019-12-26 10:17:31 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:17:31 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 10:17:31 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:17:31 --> Utf8 Class Initialized
INFO - 2019-12-26 10:17:31 --> Utf8 Class Initialized
INFO - 2019-12-26 10:17:31 --> URI Class Initialized
INFO - 2019-12-26 10:17:31 --> URI Class Initialized
INFO - 2019-12-26 10:17:31 --> Router Class Initialized
INFO - 2019-12-26 10:17:31 --> Router Class Initialized
INFO - 2019-12-26 10:17:31 --> Output Class Initialized
INFO - 2019-12-26 10:17:31 --> Output Class Initialized
INFO - 2019-12-26 10:17:31 --> Security Class Initialized
INFO - 2019-12-26 10:17:31 --> Security Class Initialized
DEBUG - 2019-12-26 10:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 10:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:17:31 --> Input Class Initialized
INFO - 2019-12-26 10:17:31 --> Input Class Initialized
INFO - 2019-12-26 10:17:31 --> Language Class Initialized
INFO - 2019-12-26 10:17:31 --> Language Class Initialized
ERROR - 2019-12-26 10:17:31 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 10:17:31 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:17:31 --> Config Class Initialized
INFO - 2019-12-26 10:17:31 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:17:31 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:17:31 --> Utf8 Class Initialized
INFO - 2019-12-26 10:17:31 --> URI Class Initialized
INFO - 2019-12-26 10:17:31 --> Router Class Initialized
INFO - 2019-12-26 10:17:31 --> Output Class Initialized
INFO - 2019-12-26 10:17:31 --> Security Class Initialized
DEBUG - 2019-12-26 10:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:17:31 --> Input Class Initialized
INFO - 2019-12-26 10:17:31 --> Language Class Initialized
ERROR - 2019-12-26 10:17:31 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:18:08 --> Config Class Initialized
INFO - 2019-12-26 10:18:08 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:18:08 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:18:08 --> Utf8 Class Initialized
INFO - 2019-12-26 10:18:08 --> URI Class Initialized
INFO - 2019-12-26 10:18:08 --> Router Class Initialized
INFO - 2019-12-26 10:18:08 --> Output Class Initialized
INFO - 2019-12-26 10:18:08 --> Security Class Initialized
DEBUG - 2019-12-26 10:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:18:08 --> Input Class Initialized
INFO - 2019-12-26 10:18:08 --> Language Class Initialized
INFO - 2019-12-26 10:18:08 --> Loader Class Initialized
INFO - 2019-12-26 10:18:08 --> Helper loaded: url_helper
INFO - 2019-12-26 10:18:08 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:18:08 --> Controller Class Initialized
INFO - 2019-12-26 10:18:08 --> Model "M_login" initialized
INFO - 2019-12-26 10:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:18:09 --> Pagination Class Initialized
INFO - 2019-12-26 10:18:09 --> Model "M_pesan" initialized
INFO - 2019-12-26 10:18:09 --> Helper loaded: form_helper
INFO - 2019-12-26 10:18:09 --> Form Validation Class Initialized
ERROR - 2019-12-26 10:18:09 --> Severity: Notice --> Undefined property: pemesanan::$M_show C:\xampp\htdocs\Musikologi-1\application\controllers\pemesanan.php 67
ERROR - 2019-12-26 10:18:09 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\Musikologi-1\application\controllers\pemesanan.php 67
INFO - 2019-12-26 10:18:39 --> Config Class Initialized
INFO - 2019-12-26 10:18:39 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:18:39 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:18:39 --> Utf8 Class Initialized
INFO - 2019-12-26 10:18:39 --> URI Class Initialized
INFO - 2019-12-26 10:18:39 --> Router Class Initialized
INFO - 2019-12-26 10:18:39 --> Output Class Initialized
INFO - 2019-12-26 10:18:39 --> Security Class Initialized
DEBUG - 2019-12-26 10:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:18:39 --> Input Class Initialized
INFO - 2019-12-26 10:18:39 --> Language Class Initialized
INFO - 2019-12-26 10:18:39 --> Loader Class Initialized
INFO - 2019-12-26 10:18:39 --> Helper loaded: url_helper
INFO - 2019-12-26 10:18:39 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:18:39 --> Controller Class Initialized
INFO - 2019-12-26 10:18:39 --> Model "M_login" initialized
INFO - 2019-12-26 10:18:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:18:39 --> Pagination Class Initialized
INFO - 2019-12-26 10:18:39 --> Model "M_pesan" initialized
INFO - 2019-12-26 10:18:39 --> Helper loaded: form_helper
INFO - 2019-12-26 10:18:39 --> Form Validation Class Initialized
INFO - 2019-12-26 10:18:39 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-26 10:18:39 --> Severity: Notice --> Undefined property: stdClass::$id_show C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 89
ERROR - 2019-12-26 10:18:39 --> Severity: Notice --> Undefined property: stdClass::$id_show C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 90
ERROR - 2019-12-26 10:18:39 --> Severity: Notice --> Undefined property: stdClass::$id_show C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 91
INFO - 2019-12-26 10:18:39 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:18:39 --> Final output sent to browser
DEBUG - 2019-12-26 10:18:39 --> Total execution time: 0.4513
INFO - 2019-12-26 10:18:40 --> Config Class Initialized
INFO - 2019-12-26 10:18:40 --> Config Class Initialized
INFO - 2019-12-26 10:18:40 --> Hooks Class Initialized
INFO - 2019-12-26 10:18:40 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:18:40 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 10:18:40 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:18:40 --> Utf8 Class Initialized
INFO - 2019-12-26 10:18:40 --> Utf8 Class Initialized
INFO - 2019-12-26 10:18:40 --> URI Class Initialized
INFO - 2019-12-26 10:18:40 --> Router Class Initialized
INFO - 2019-12-26 10:18:40 --> URI Class Initialized
INFO - 2019-12-26 10:18:40 --> Router Class Initialized
INFO - 2019-12-26 10:18:40 --> Output Class Initialized
INFO - 2019-12-26 10:18:40 --> Security Class Initialized
INFO - 2019-12-26 10:18:40 --> Output Class Initialized
DEBUG - 2019-12-26 10:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:18:40 --> Security Class Initialized
INFO - 2019-12-26 10:18:40 --> Input Class Initialized
DEBUG - 2019-12-26 10:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:18:40 --> Input Class Initialized
INFO - 2019-12-26 10:18:40 --> Language Class Initialized
INFO - 2019-12-26 10:18:40 --> Language Class Initialized
ERROR - 2019-12-26 10:18:40 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 10:18:40 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:18:40 --> Config Class Initialized
INFO - 2019-12-26 10:18:40 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:18:40 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:18:40 --> Utf8 Class Initialized
INFO - 2019-12-26 10:18:40 --> URI Class Initialized
INFO - 2019-12-26 10:18:40 --> Router Class Initialized
INFO - 2019-12-26 10:18:40 --> Output Class Initialized
INFO - 2019-12-26 10:18:40 --> Security Class Initialized
DEBUG - 2019-12-26 10:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:18:40 --> Input Class Initialized
INFO - 2019-12-26 10:18:40 --> Language Class Initialized
ERROR - 2019-12-26 10:18:40 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:18:40 --> Config Class Initialized
INFO - 2019-12-26 10:18:40 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:18:40 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:18:40 --> Utf8 Class Initialized
INFO - 2019-12-26 10:18:40 --> URI Class Initialized
INFO - 2019-12-26 10:18:40 --> Router Class Initialized
INFO - 2019-12-26 10:18:40 --> Output Class Initialized
INFO - 2019-12-26 10:18:40 --> Security Class Initialized
DEBUG - 2019-12-26 10:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:18:40 --> Input Class Initialized
INFO - 2019-12-26 10:18:40 --> Language Class Initialized
ERROR - 2019-12-26 10:18:40 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:19:31 --> Config Class Initialized
INFO - 2019-12-26 10:19:31 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:19:31 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:19:31 --> Utf8 Class Initialized
INFO - 2019-12-26 10:19:31 --> URI Class Initialized
INFO - 2019-12-26 10:19:31 --> Router Class Initialized
INFO - 2019-12-26 10:19:31 --> Output Class Initialized
INFO - 2019-12-26 10:19:31 --> Security Class Initialized
DEBUG - 2019-12-26 10:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:19:31 --> Input Class Initialized
INFO - 2019-12-26 10:19:31 --> Language Class Initialized
INFO - 2019-12-26 10:19:31 --> Loader Class Initialized
INFO - 2019-12-26 10:19:31 --> Helper loaded: url_helper
INFO - 2019-12-26 10:19:31 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:19:31 --> Controller Class Initialized
INFO - 2019-12-26 10:19:31 --> Model "M_login" initialized
INFO - 2019-12-26 10:19:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:19:31 --> Pagination Class Initialized
INFO - 2019-12-26 10:19:31 --> Model "M_pesan" initialized
INFO - 2019-12-26 10:19:31 --> Helper loaded: form_helper
INFO - 2019-12-26 10:19:31 --> Form Validation Class Initialized
INFO - 2019-12-26 10:19:31 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-26 10:19:31 --> Severity: Notice --> Undefined property: stdClass::$id_show C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 89
ERROR - 2019-12-26 10:19:31 --> Severity: Notice --> Undefined property: stdClass::$id_show C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 90
ERROR - 2019-12-26 10:19:31 --> Severity: Notice --> Undefined property: stdClass::$id_show C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 91
INFO - 2019-12-26 10:19:31 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:19:31 --> Final output sent to browser
DEBUG - 2019-12-26 10:19:31 --> Total execution time: 0.4770
INFO - 2019-12-26 10:19:32 --> Config Class Initialized
INFO - 2019-12-26 10:19:32 --> Config Class Initialized
INFO - 2019-12-26 10:19:32 --> Hooks Class Initialized
INFO - 2019-12-26 10:19:32 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:19:32 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 10:19:32 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:19:32 --> Utf8 Class Initialized
INFO - 2019-12-26 10:19:32 --> Utf8 Class Initialized
INFO - 2019-12-26 10:19:32 --> URI Class Initialized
INFO - 2019-12-26 10:19:32 --> URI Class Initialized
INFO - 2019-12-26 10:19:32 --> Router Class Initialized
INFO - 2019-12-26 10:19:32 --> Router Class Initialized
INFO - 2019-12-26 10:19:32 --> Output Class Initialized
INFO - 2019-12-26 10:19:32 --> Output Class Initialized
INFO - 2019-12-26 10:19:32 --> Security Class Initialized
INFO - 2019-12-26 10:19:32 --> Security Class Initialized
DEBUG - 2019-12-26 10:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 10:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:19:32 --> Input Class Initialized
INFO - 2019-12-26 10:19:32 --> Input Class Initialized
INFO - 2019-12-26 10:19:32 --> Language Class Initialized
INFO - 2019-12-26 10:19:32 --> Language Class Initialized
ERROR - 2019-12-26 10:19:32 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 10:19:32 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:20:36 --> Config Class Initialized
INFO - 2019-12-26 10:20:36 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:20:36 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:20:36 --> Utf8 Class Initialized
INFO - 2019-12-26 10:20:36 --> URI Class Initialized
INFO - 2019-12-26 10:20:36 --> Router Class Initialized
INFO - 2019-12-26 10:20:36 --> Output Class Initialized
INFO - 2019-12-26 10:20:36 --> Security Class Initialized
DEBUG - 2019-12-26 10:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:20:36 --> Input Class Initialized
INFO - 2019-12-26 10:20:36 --> Language Class Initialized
INFO - 2019-12-26 10:20:36 --> Loader Class Initialized
INFO - 2019-12-26 10:20:36 --> Helper loaded: url_helper
INFO - 2019-12-26 10:20:36 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:20:36 --> Controller Class Initialized
INFO - 2019-12-26 10:20:36 --> Model "M_login" initialized
INFO - 2019-12-26 10:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:20:36 --> Pagination Class Initialized
INFO - 2019-12-26 10:20:36 --> Model "M_pesan" initialized
INFO - 2019-12-26 10:20:36 --> Helper loaded: form_helper
INFO - 2019-12-26 10:20:36 --> Form Validation Class Initialized
INFO - 2019-12-26 10:20:36 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 10:20:36 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:20:36 --> Final output sent to browser
DEBUG - 2019-12-26 10:20:36 --> Total execution time: 0.4205
INFO - 2019-12-26 10:20:36 --> Config Class Initialized
INFO - 2019-12-26 10:20:36 --> Config Class Initialized
INFO - 2019-12-26 10:20:36 --> Hooks Class Initialized
INFO - 2019-12-26 10:20:36 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:20:36 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 10:20:36 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:20:36 --> Utf8 Class Initialized
INFO - 2019-12-26 10:20:36 --> Utf8 Class Initialized
INFO - 2019-12-26 10:20:36 --> URI Class Initialized
INFO - 2019-12-26 10:20:36 --> URI Class Initialized
INFO - 2019-12-26 10:20:36 --> Router Class Initialized
INFO - 2019-12-26 10:20:36 --> Router Class Initialized
INFO - 2019-12-26 10:20:36 --> Output Class Initialized
INFO - 2019-12-26 10:20:36 --> Output Class Initialized
INFO - 2019-12-26 10:20:36 --> Security Class Initialized
INFO - 2019-12-26 10:20:36 --> Security Class Initialized
DEBUG - 2019-12-26 10:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 10:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:20:36 --> Input Class Initialized
INFO - 2019-12-26 10:20:36 --> Input Class Initialized
INFO - 2019-12-26 10:20:36 --> Language Class Initialized
INFO - 2019-12-26 10:20:36 --> Language Class Initialized
ERROR - 2019-12-26 10:20:37 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 10:20:37 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:21:26 --> Config Class Initialized
INFO - 2019-12-26 10:21:26 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:21:26 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:21:26 --> Utf8 Class Initialized
INFO - 2019-12-26 10:21:26 --> URI Class Initialized
INFO - 2019-12-26 10:21:26 --> Router Class Initialized
INFO - 2019-12-26 10:21:26 --> Output Class Initialized
INFO - 2019-12-26 10:21:26 --> Security Class Initialized
DEBUG - 2019-12-26 10:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:21:26 --> Input Class Initialized
INFO - 2019-12-26 10:21:26 --> Language Class Initialized
INFO - 2019-12-26 10:21:26 --> Loader Class Initialized
INFO - 2019-12-26 10:21:26 --> Helper loaded: url_helper
INFO - 2019-12-26 10:21:26 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:21:26 --> Controller Class Initialized
INFO - 2019-12-26 10:21:26 --> Model "M_login" initialized
INFO - 2019-12-26 10:21:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:21:27 --> Pagination Class Initialized
INFO - 2019-12-26 10:21:27 --> Model "M_pesan" initialized
INFO - 2019-12-26 10:21:27 --> Helper loaded: form_helper
INFO - 2019-12-26 10:21:27 --> Form Validation Class Initialized
INFO - 2019-12-26 10:21:27 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 10:21:27 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:21:27 --> Final output sent to browser
DEBUG - 2019-12-26 10:21:27 --> Total execution time: 0.4348
INFO - 2019-12-26 10:21:27 --> Config Class Initialized
INFO - 2019-12-26 10:21:27 --> Config Class Initialized
INFO - 2019-12-26 10:21:27 --> Hooks Class Initialized
INFO - 2019-12-26 10:21:27 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:21:27 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 10:21:27 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:21:27 --> Utf8 Class Initialized
INFO - 2019-12-26 10:21:27 --> Utf8 Class Initialized
INFO - 2019-12-26 10:21:27 --> URI Class Initialized
INFO - 2019-12-26 10:21:27 --> URI Class Initialized
INFO - 2019-12-26 10:21:27 --> Router Class Initialized
INFO - 2019-12-26 10:21:27 --> Router Class Initialized
INFO - 2019-12-26 10:21:27 --> Output Class Initialized
INFO - 2019-12-26 10:21:27 --> Output Class Initialized
INFO - 2019-12-26 10:21:27 --> Security Class Initialized
INFO - 2019-12-26 10:21:27 --> Security Class Initialized
DEBUG - 2019-12-26 10:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 10:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:21:27 --> Input Class Initialized
INFO - 2019-12-26 10:21:27 --> Input Class Initialized
INFO - 2019-12-26 10:21:27 --> Language Class Initialized
INFO - 2019-12-26 10:21:27 --> Language Class Initialized
ERROR - 2019-12-26 10:21:27 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 10:21:27 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:21:27 --> Config Class Initialized
INFO - 2019-12-26 10:21:27 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:21:27 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:21:27 --> Utf8 Class Initialized
INFO - 2019-12-26 10:21:27 --> URI Class Initialized
INFO - 2019-12-26 10:21:27 --> Router Class Initialized
INFO - 2019-12-26 10:21:27 --> Output Class Initialized
INFO - 2019-12-26 10:21:27 --> Security Class Initialized
DEBUG - 2019-12-26 10:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:21:27 --> Input Class Initialized
INFO - 2019-12-26 10:21:27 --> Language Class Initialized
ERROR - 2019-12-26 10:21:27 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:22:17 --> Config Class Initialized
INFO - 2019-12-26 10:22:17 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:22:17 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:22:17 --> Utf8 Class Initialized
INFO - 2019-12-26 10:22:17 --> URI Class Initialized
INFO - 2019-12-26 10:22:17 --> Router Class Initialized
INFO - 2019-12-26 10:22:17 --> Output Class Initialized
INFO - 2019-12-26 10:22:17 --> Security Class Initialized
DEBUG - 2019-12-26 10:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:22:17 --> Input Class Initialized
INFO - 2019-12-26 10:22:17 --> Language Class Initialized
INFO - 2019-12-26 10:22:17 --> Loader Class Initialized
INFO - 2019-12-26 10:22:18 --> Helper loaded: url_helper
INFO - 2019-12-26 10:22:18 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:22:18 --> Controller Class Initialized
INFO - 2019-12-26 10:22:18 --> Model "M_login" initialized
INFO - 2019-12-26 10:22:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:22:18 --> Pagination Class Initialized
INFO - 2019-12-26 10:22:18 --> Model "M_pesan" initialized
INFO - 2019-12-26 10:22:18 --> Helper loaded: form_helper
INFO - 2019-12-26 10:22:18 --> Form Validation Class Initialized
INFO - 2019-12-26 10:22:18 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 10:22:18 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:22:18 --> Final output sent to browser
DEBUG - 2019-12-26 10:22:18 --> Total execution time: 0.4113
INFO - 2019-12-26 10:22:18 --> Config Class Initialized
INFO - 2019-12-26 10:22:18 --> Config Class Initialized
INFO - 2019-12-26 10:22:18 --> Hooks Class Initialized
INFO - 2019-12-26 10:22:18 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:22:18 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 10:22:18 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:22:18 --> Utf8 Class Initialized
INFO - 2019-12-26 10:22:18 --> Utf8 Class Initialized
INFO - 2019-12-26 10:22:18 --> URI Class Initialized
INFO - 2019-12-26 10:22:18 --> URI Class Initialized
INFO - 2019-12-26 10:22:18 --> Router Class Initialized
INFO - 2019-12-26 10:22:18 --> Router Class Initialized
INFO - 2019-12-26 10:22:18 --> Output Class Initialized
INFO - 2019-12-26 10:22:18 --> Output Class Initialized
INFO - 2019-12-26 10:22:18 --> Security Class Initialized
INFO - 2019-12-26 10:22:18 --> Security Class Initialized
DEBUG - 2019-12-26 10:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 10:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:22:18 --> Input Class Initialized
INFO - 2019-12-26 10:22:18 --> Input Class Initialized
INFO - 2019-12-26 10:22:18 --> Language Class Initialized
INFO - 2019-12-26 10:22:18 --> Language Class Initialized
ERROR - 2019-12-26 10:22:18 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 10:22:18 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:22:18 --> Config Class Initialized
INFO - 2019-12-26 10:22:18 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:22:18 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:22:18 --> Utf8 Class Initialized
INFO - 2019-12-26 10:22:18 --> URI Class Initialized
INFO - 2019-12-26 10:22:18 --> Router Class Initialized
INFO - 2019-12-26 10:22:18 --> Output Class Initialized
INFO - 2019-12-26 10:22:18 --> Security Class Initialized
DEBUG - 2019-12-26 10:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:22:18 --> Input Class Initialized
INFO - 2019-12-26 10:22:18 --> Language Class Initialized
ERROR - 2019-12-26 10:22:18 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:23:04 --> Config Class Initialized
INFO - 2019-12-26 10:23:04 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:23:04 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:23:04 --> Utf8 Class Initialized
INFO - 2019-12-26 10:23:04 --> URI Class Initialized
INFO - 2019-12-26 10:23:04 --> Router Class Initialized
INFO - 2019-12-26 10:23:04 --> Output Class Initialized
INFO - 2019-12-26 10:23:04 --> Security Class Initialized
DEBUG - 2019-12-26 10:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:23:04 --> Input Class Initialized
INFO - 2019-12-26 10:23:04 --> Language Class Initialized
INFO - 2019-12-26 10:23:04 --> Loader Class Initialized
INFO - 2019-12-26 10:23:04 --> Helper loaded: url_helper
INFO - 2019-12-26 10:23:04 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:23:04 --> Controller Class Initialized
INFO - 2019-12-26 10:23:04 --> Model "M_login" initialized
INFO - 2019-12-26 10:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:23:04 --> Pagination Class Initialized
INFO - 2019-12-26 10:23:04 --> Model "M_pesan" initialized
INFO - 2019-12-26 10:23:04 --> Helper loaded: form_helper
INFO - 2019-12-26 10:23:04 --> Form Validation Class Initialized
INFO - 2019-12-26 10:23:04 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 10:23:04 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:23:04 --> Final output sent to browser
DEBUG - 2019-12-26 10:23:04 --> Total execution time: 0.4275
INFO - 2019-12-26 10:23:05 --> Config Class Initialized
INFO - 2019-12-26 10:23:05 --> Config Class Initialized
INFO - 2019-12-26 10:23:05 --> Hooks Class Initialized
INFO - 2019-12-26 10:23:05 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:23:05 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 10:23:05 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:23:05 --> Utf8 Class Initialized
INFO - 2019-12-26 10:23:05 --> Utf8 Class Initialized
INFO - 2019-12-26 10:23:05 --> URI Class Initialized
INFO - 2019-12-26 10:23:05 --> URI Class Initialized
INFO - 2019-12-26 10:23:05 --> Router Class Initialized
INFO - 2019-12-26 10:23:05 --> Router Class Initialized
INFO - 2019-12-26 10:23:05 --> Output Class Initialized
INFO - 2019-12-26 10:23:05 --> Output Class Initialized
INFO - 2019-12-26 10:23:05 --> Security Class Initialized
INFO - 2019-12-26 10:23:05 --> Security Class Initialized
DEBUG - 2019-12-26 10:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 10:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:23:05 --> Input Class Initialized
INFO - 2019-12-26 10:23:05 --> Input Class Initialized
INFO - 2019-12-26 10:23:05 --> Language Class Initialized
INFO - 2019-12-26 10:23:05 --> Language Class Initialized
ERROR - 2019-12-26 10:23:05 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 10:23:05 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:23:49 --> Config Class Initialized
INFO - 2019-12-26 10:23:49 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:23:49 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:23:49 --> Utf8 Class Initialized
INFO - 2019-12-26 10:23:49 --> URI Class Initialized
INFO - 2019-12-26 10:23:49 --> Router Class Initialized
INFO - 2019-12-26 10:23:49 --> Output Class Initialized
INFO - 2019-12-26 10:23:49 --> Security Class Initialized
DEBUG - 2019-12-26 10:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:23:49 --> Input Class Initialized
INFO - 2019-12-26 10:23:49 --> Language Class Initialized
INFO - 2019-12-26 10:23:49 --> Loader Class Initialized
INFO - 2019-12-26 10:23:49 --> Helper loaded: url_helper
INFO - 2019-12-26 10:23:49 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:23:49 --> Controller Class Initialized
INFO - 2019-12-26 10:23:49 --> Model "M_login" initialized
INFO - 2019-12-26 10:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:23:49 --> Pagination Class Initialized
INFO - 2019-12-26 10:23:49 --> Model "M_pesan" initialized
INFO - 2019-12-26 10:23:49 --> Helper loaded: form_helper
INFO - 2019-12-26 10:23:49 --> Form Validation Class Initialized
INFO - 2019-12-26 10:23:49 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 10:23:49 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:23:49 --> Final output sent to browser
DEBUG - 2019-12-26 10:23:49 --> Total execution time: 0.4149
INFO - 2019-12-26 10:23:49 --> Config Class Initialized
INFO - 2019-12-26 10:23:49 --> Config Class Initialized
INFO - 2019-12-26 10:23:49 --> Hooks Class Initialized
INFO - 2019-12-26 10:23:49 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:23:49 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 10:23:49 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:23:49 --> Utf8 Class Initialized
INFO - 2019-12-26 10:23:49 --> Utf8 Class Initialized
INFO - 2019-12-26 10:23:49 --> URI Class Initialized
INFO - 2019-12-26 10:23:49 --> URI Class Initialized
INFO - 2019-12-26 10:23:49 --> Router Class Initialized
INFO - 2019-12-26 10:23:49 --> Router Class Initialized
INFO - 2019-12-26 10:23:49 --> Output Class Initialized
INFO - 2019-12-26 10:23:49 --> Output Class Initialized
INFO - 2019-12-26 10:23:49 --> Security Class Initialized
INFO - 2019-12-26 10:23:49 --> Security Class Initialized
DEBUG - 2019-12-26 10:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 10:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:23:50 --> Input Class Initialized
INFO - 2019-12-26 10:23:50 --> Input Class Initialized
INFO - 2019-12-26 10:23:50 --> Language Class Initialized
INFO - 2019-12-26 10:23:50 --> Language Class Initialized
ERROR - 2019-12-26 10:23:50 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 10:23:50 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:24:36 --> Config Class Initialized
INFO - 2019-12-26 10:24:36 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:24:36 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:24:36 --> Utf8 Class Initialized
INFO - 2019-12-26 10:24:36 --> URI Class Initialized
INFO - 2019-12-26 10:24:36 --> Router Class Initialized
INFO - 2019-12-26 10:24:36 --> Output Class Initialized
INFO - 2019-12-26 10:24:36 --> Security Class Initialized
DEBUG - 2019-12-26 10:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:24:36 --> Input Class Initialized
INFO - 2019-12-26 10:24:36 --> Language Class Initialized
INFO - 2019-12-26 10:24:36 --> Loader Class Initialized
INFO - 2019-12-26 10:24:36 --> Helper loaded: url_helper
INFO - 2019-12-26 10:24:36 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:24:36 --> Controller Class Initialized
INFO - 2019-12-26 10:24:36 --> Model "M_login" initialized
INFO - 2019-12-26 10:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:24:36 --> Pagination Class Initialized
INFO - 2019-12-26 10:24:36 --> Model "M_pesan" initialized
INFO - 2019-12-26 10:24:36 --> Helper loaded: form_helper
INFO - 2019-12-26 10:24:36 --> Form Validation Class Initialized
INFO - 2019-12-26 10:24:36 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 10:24:36 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:24:36 --> Final output sent to browser
DEBUG - 2019-12-26 10:24:36 --> Total execution time: 0.4362
INFO - 2019-12-26 10:24:36 --> Config Class Initialized
INFO - 2019-12-26 10:24:36 --> Config Class Initialized
INFO - 2019-12-26 10:24:36 --> Hooks Class Initialized
INFO - 2019-12-26 10:24:36 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:24:37 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 10:24:37 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:24:37 --> Utf8 Class Initialized
INFO - 2019-12-26 10:24:37 --> Utf8 Class Initialized
INFO - 2019-12-26 10:24:37 --> URI Class Initialized
INFO - 2019-12-26 10:24:37 --> URI Class Initialized
INFO - 2019-12-26 10:24:37 --> Router Class Initialized
INFO - 2019-12-26 10:24:37 --> Router Class Initialized
INFO - 2019-12-26 10:24:37 --> Output Class Initialized
INFO - 2019-12-26 10:24:37 --> Output Class Initialized
INFO - 2019-12-26 10:24:37 --> Security Class Initialized
INFO - 2019-12-26 10:24:37 --> Security Class Initialized
DEBUG - 2019-12-26 10:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 10:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:24:37 --> Input Class Initialized
INFO - 2019-12-26 10:24:37 --> Input Class Initialized
INFO - 2019-12-26 10:24:37 --> Language Class Initialized
INFO - 2019-12-26 10:24:37 --> Language Class Initialized
ERROR - 2019-12-26 10:24:37 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 10:24:37 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:24:37 --> Config Class Initialized
INFO - 2019-12-26 10:24:37 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:24:37 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:24:37 --> Utf8 Class Initialized
INFO - 2019-12-26 10:24:37 --> URI Class Initialized
INFO - 2019-12-26 10:24:37 --> Router Class Initialized
INFO - 2019-12-26 10:24:37 --> Output Class Initialized
INFO - 2019-12-26 10:24:37 --> Security Class Initialized
DEBUG - 2019-12-26 10:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:24:37 --> Input Class Initialized
INFO - 2019-12-26 10:24:37 --> Language Class Initialized
ERROR - 2019-12-26 10:24:37 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:44:24 --> Config Class Initialized
INFO - 2019-12-26 10:44:24 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:44:24 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:44:24 --> Utf8 Class Initialized
INFO - 2019-12-26 10:44:25 --> URI Class Initialized
INFO - 2019-12-26 10:44:25 --> Router Class Initialized
INFO - 2019-12-26 10:44:25 --> Output Class Initialized
INFO - 2019-12-26 10:44:25 --> Security Class Initialized
DEBUG - 2019-12-26 10:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:44:25 --> Input Class Initialized
INFO - 2019-12-26 10:44:25 --> Language Class Initialized
INFO - 2019-12-26 10:44:25 --> Loader Class Initialized
INFO - 2019-12-26 10:44:25 --> Helper loaded: url_helper
INFO - 2019-12-26 10:44:25 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:44:25 --> Controller Class Initialized
INFO - 2019-12-26 10:44:25 --> Model "M_login" initialized
INFO - 2019-12-26 10:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:44:25 --> Pagination Class Initialized
INFO - 2019-12-26 10:44:25 --> Model "M_pesan" initialized
INFO - 2019-12-26 10:44:25 --> Helper loaded: form_helper
INFO - 2019-12-26 10:44:25 --> Form Validation Class Initialized
INFO - 2019-12-26 10:44:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 10:44:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:44:25 --> Final output sent to browser
DEBUG - 2019-12-26 10:44:25 --> Total execution time: 0.6031
INFO - 2019-12-26 10:44:25 --> Config Class Initialized
INFO - 2019-12-26 10:44:25 --> Config Class Initialized
INFO - 2019-12-26 10:44:25 --> Hooks Class Initialized
INFO - 2019-12-26 10:44:25 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:44:25 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 10:44:25 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:44:25 --> Utf8 Class Initialized
INFO - 2019-12-26 10:44:25 --> Utf8 Class Initialized
INFO - 2019-12-26 10:44:25 --> URI Class Initialized
INFO - 2019-12-26 10:44:25 --> URI Class Initialized
INFO - 2019-12-26 10:44:25 --> Router Class Initialized
INFO - 2019-12-26 10:44:25 --> Router Class Initialized
INFO - 2019-12-26 10:44:25 --> Output Class Initialized
INFO - 2019-12-26 10:44:25 --> Output Class Initialized
INFO - 2019-12-26 10:44:25 --> Security Class Initialized
INFO - 2019-12-26 10:44:25 --> Security Class Initialized
DEBUG - 2019-12-26 10:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 10:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:44:25 --> Input Class Initialized
INFO - 2019-12-26 10:44:25 --> Input Class Initialized
INFO - 2019-12-26 10:44:25 --> Language Class Initialized
INFO - 2019-12-26 10:44:25 --> Language Class Initialized
ERROR - 2019-12-26 10:44:25 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 10:44:25 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:44:25 --> Config Class Initialized
INFO - 2019-12-26 10:44:25 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:44:25 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:44:26 --> Utf8 Class Initialized
INFO - 2019-12-26 10:44:26 --> URI Class Initialized
INFO - 2019-12-26 10:44:26 --> Router Class Initialized
INFO - 2019-12-26 10:44:26 --> Output Class Initialized
INFO - 2019-12-26 10:44:26 --> Security Class Initialized
DEBUG - 2019-12-26 10:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:44:26 --> Input Class Initialized
INFO - 2019-12-26 10:44:26 --> Language Class Initialized
ERROR - 2019-12-26 10:44:26 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 10:45:51 --> Config Class Initialized
INFO - 2019-12-26 10:45:51 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:45:51 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:45:51 --> Utf8 Class Initialized
INFO - 2019-12-26 10:45:51 --> URI Class Initialized
INFO - 2019-12-26 10:45:51 --> Router Class Initialized
INFO - 2019-12-26 10:45:51 --> Output Class Initialized
INFO - 2019-12-26 10:45:51 --> Security Class Initialized
DEBUG - 2019-12-26 10:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:45:51 --> Input Class Initialized
INFO - 2019-12-26 10:45:51 --> Language Class Initialized
INFO - 2019-12-26 10:45:51 --> Loader Class Initialized
INFO - 2019-12-26 10:45:51 --> Helper loaded: url_helper
INFO - 2019-12-26 10:45:51 --> Database Driver Class Initialized
DEBUG - 2019-12-26 10:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 10:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 10:45:52 --> Controller Class Initialized
INFO - 2019-12-26 10:45:52 --> Model "M_login" initialized
INFO - 2019-12-26 10:45:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 10:45:52 --> Pagination Class Initialized
INFO - 2019-12-26 10:45:52 --> Model "M_pesan" initialized
INFO - 2019-12-26 10:45:52 --> Helper loaded: form_helper
INFO - 2019-12-26 10:45:52 --> Form Validation Class Initialized
INFO - 2019-12-26 10:45:52 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 10:45:52 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 10:45:52 --> Final output sent to browser
DEBUG - 2019-12-26 10:45:52 --> Total execution time: 0.5486
INFO - 2019-12-26 10:45:52 --> Config Class Initialized
INFO - 2019-12-26 10:45:52 --> Config Class Initialized
INFO - 2019-12-26 10:45:52 --> Hooks Class Initialized
INFO - 2019-12-26 10:45:52 --> Hooks Class Initialized
DEBUG - 2019-12-26 10:45:52 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 10:45:52 --> UTF-8 Support Enabled
INFO - 2019-12-26 10:45:52 --> Utf8 Class Initialized
INFO - 2019-12-26 10:45:52 --> Utf8 Class Initialized
INFO - 2019-12-26 10:45:52 --> URI Class Initialized
INFO - 2019-12-26 10:45:52 --> URI Class Initialized
INFO - 2019-12-26 10:45:52 --> Router Class Initialized
INFO - 2019-12-26 10:45:52 --> Router Class Initialized
INFO - 2019-12-26 10:45:52 --> Output Class Initialized
INFO - 2019-12-26 10:45:52 --> Output Class Initialized
INFO - 2019-12-26 10:45:52 --> Security Class Initialized
INFO - 2019-12-26 10:45:52 --> Security Class Initialized
DEBUG - 2019-12-26 10:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 10:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 10:45:52 --> Input Class Initialized
INFO - 2019-12-26 10:45:52 --> Input Class Initialized
INFO - 2019-12-26 10:45:52 --> Language Class Initialized
INFO - 2019-12-26 10:45:52 --> Language Class Initialized
ERROR - 2019-12-26 10:45:52 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 10:45:52 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 11:18:55 --> Config Class Initialized
INFO - 2019-12-26 11:18:55 --> Hooks Class Initialized
DEBUG - 2019-12-26 11:18:55 --> UTF-8 Support Enabled
INFO - 2019-12-26 11:18:55 --> Utf8 Class Initialized
INFO - 2019-12-26 11:18:55 --> URI Class Initialized
INFO - 2019-12-26 11:18:55 --> Router Class Initialized
INFO - 2019-12-26 11:18:55 --> Output Class Initialized
INFO - 2019-12-26 11:18:55 --> Security Class Initialized
DEBUG - 2019-12-26 11:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 11:18:55 --> Input Class Initialized
INFO - 2019-12-26 11:18:55 --> Language Class Initialized
INFO - 2019-12-26 11:18:55 --> Loader Class Initialized
INFO - 2019-12-26 11:18:55 --> Helper loaded: url_helper
INFO - 2019-12-26 11:18:55 --> Database Driver Class Initialized
DEBUG - 2019-12-26 11:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 11:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 11:18:55 --> Controller Class Initialized
INFO - 2019-12-26 11:18:55 --> Model "M_login" initialized
INFO - 2019-12-26 11:18:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 11:18:56 --> Pagination Class Initialized
INFO - 2019-12-26 11:18:56 --> Model "M_pesan" initialized
INFO - 2019-12-26 11:18:56 --> Helper loaded: form_helper
INFO - 2019-12-26 11:18:56 --> Form Validation Class Initialized
INFO - 2019-12-26 11:18:56 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-26 11:18:56 --> Severity: error --> Exception: Function name must be a string C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 78
INFO - 2019-12-26 11:19:20 --> Config Class Initialized
INFO - 2019-12-26 11:19:20 --> Hooks Class Initialized
DEBUG - 2019-12-26 11:19:20 --> UTF-8 Support Enabled
INFO - 2019-12-26 11:19:20 --> Utf8 Class Initialized
INFO - 2019-12-26 11:19:20 --> URI Class Initialized
INFO - 2019-12-26 11:19:20 --> Router Class Initialized
INFO - 2019-12-26 11:19:20 --> Output Class Initialized
INFO - 2019-12-26 11:19:20 --> Security Class Initialized
DEBUG - 2019-12-26 11:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 11:19:20 --> Input Class Initialized
INFO - 2019-12-26 11:19:20 --> Language Class Initialized
INFO - 2019-12-26 11:19:20 --> Loader Class Initialized
INFO - 2019-12-26 11:19:20 --> Helper loaded: url_helper
INFO - 2019-12-26 11:19:20 --> Database Driver Class Initialized
DEBUG - 2019-12-26 11:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 11:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 11:19:20 --> Controller Class Initialized
INFO - 2019-12-26 11:19:20 --> Model "M_login" initialized
INFO - 2019-12-26 11:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 11:19:20 --> Pagination Class Initialized
INFO - 2019-12-26 11:19:20 --> Model "M_pesan" initialized
INFO - 2019-12-26 11:19:20 --> Helper loaded: form_helper
INFO - 2019-12-26 11:19:20 --> Form Validation Class Initialized
INFO - 2019-12-26 11:19:20 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-26 11:19:20 --> Severity: error --> Exception: Function name must be a string C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 78
INFO - 2019-12-26 11:19:25 --> Config Class Initialized
INFO - 2019-12-26 11:19:25 --> Hooks Class Initialized
DEBUG - 2019-12-26 11:19:25 --> UTF-8 Support Enabled
INFO - 2019-12-26 11:19:25 --> Utf8 Class Initialized
INFO - 2019-12-26 11:19:25 --> URI Class Initialized
INFO - 2019-12-26 11:19:25 --> Router Class Initialized
INFO - 2019-12-26 11:19:25 --> Output Class Initialized
INFO - 2019-12-26 11:19:25 --> Security Class Initialized
DEBUG - 2019-12-26 11:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 11:19:25 --> Input Class Initialized
INFO - 2019-12-26 11:19:25 --> Language Class Initialized
INFO - 2019-12-26 11:19:25 --> Loader Class Initialized
INFO - 2019-12-26 11:19:25 --> Helper loaded: url_helper
INFO - 2019-12-26 11:19:25 --> Database Driver Class Initialized
DEBUG - 2019-12-26 11:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 11:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 11:19:25 --> Controller Class Initialized
INFO - 2019-12-26 11:19:25 --> Model "M_login" initialized
INFO - 2019-12-26 11:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 11:19:25 --> Pagination Class Initialized
INFO - 2019-12-26 11:19:25 --> Model "M_show" initialized
INFO - 2019-12-26 11:19:25 --> Helper loaded: form_helper
INFO - 2019-12-26 11:19:26 --> Form Validation Class Initialized
INFO - 2019-12-26 11:19:26 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 11:19:26 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2019-12-26 11:19:26 --> Final output sent to browser
DEBUG - 2019-12-26 11:19:26 --> Total execution time: 0.5078
INFO - 2019-12-26 11:19:26 --> Config Class Initialized
INFO - 2019-12-26 11:19:26 --> Hooks Class Initialized
DEBUG - 2019-12-26 11:19:26 --> UTF-8 Support Enabled
INFO - 2019-12-26 11:19:26 --> Utf8 Class Initialized
INFO - 2019-12-26 11:19:26 --> URI Class Initialized
INFO - 2019-12-26 11:19:26 --> Router Class Initialized
INFO - 2019-12-26 11:19:26 --> Output Class Initialized
INFO - 2019-12-26 11:19:26 --> Security Class Initialized
DEBUG - 2019-12-26 11:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 11:19:26 --> Input Class Initialized
INFO - 2019-12-26 11:19:26 --> Language Class Initialized
ERROR - 2019-12-26 11:19:26 --> 404 Page Not Found: Show/assets
INFO - 2019-12-26 11:19:31 --> Config Class Initialized
INFO - 2019-12-26 11:19:31 --> Hooks Class Initialized
DEBUG - 2019-12-26 11:19:31 --> UTF-8 Support Enabled
INFO - 2019-12-26 11:19:31 --> Utf8 Class Initialized
INFO - 2019-12-26 11:19:31 --> URI Class Initialized
INFO - 2019-12-26 11:19:31 --> Router Class Initialized
INFO - 2019-12-26 11:19:31 --> Output Class Initialized
INFO - 2019-12-26 11:19:31 --> Security Class Initialized
DEBUG - 2019-12-26 11:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 11:19:31 --> Input Class Initialized
INFO - 2019-12-26 11:19:31 --> Language Class Initialized
INFO - 2019-12-26 11:19:31 --> Loader Class Initialized
INFO - 2019-12-26 11:19:31 --> Helper loaded: url_helper
INFO - 2019-12-26 11:19:31 --> Database Driver Class Initialized
DEBUG - 2019-12-26 11:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 11:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 11:19:31 --> Controller Class Initialized
INFO - 2019-12-26 11:19:31 --> Model "M_login" initialized
INFO - 2019-12-26 11:19:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 11:19:31 --> Pagination Class Initialized
INFO - 2019-12-26 11:19:31 --> Model "M_pesan" initialized
INFO - 2019-12-26 11:19:31 --> Helper loaded: form_helper
INFO - 2019-12-26 11:19:31 --> Form Validation Class Initialized
INFO - 2019-12-26 11:19:31 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-26 11:19:31 --> Severity: error --> Exception: Function name must be a string C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 78
INFO - 2019-12-26 11:20:22 --> Config Class Initialized
INFO - 2019-12-26 11:20:22 --> Hooks Class Initialized
DEBUG - 2019-12-26 11:20:22 --> UTF-8 Support Enabled
INFO - 2019-12-26 11:20:22 --> Utf8 Class Initialized
INFO - 2019-12-26 11:20:22 --> URI Class Initialized
INFO - 2019-12-26 11:20:22 --> Router Class Initialized
INFO - 2019-12-26 11:20:22 --> Output Class Initialized
INFO - 2019-12-26 11:20:22 --> Security Class Initialized
DEBUG - 2019-12-26 11:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 11:20:22 --> Input Class Initialized
INFO - 2019-12-26 11:20:22 --> Language Class Initialized
INFO - 2019-12-26 11:20:22 --> Loader Class Initialized
INFO - 2019-12-26 11:20:23 --> Helper loaded: url_helper
INFO - 2019-12-26 11:20:23 --> Database Driver Class Initialized
DEBUG - 2019-12-26 11:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 11:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 11:20:23 --> Controller Class Initialized
INFO - 2019-12-26 11:20:23 --> Model "M_login" initialized
INFO - 2019-12-26 11:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 11:20:23 --> Pagination Class Initialized
INFO - 2019-12-26 11:20:23 --> Model "M_pesan" initialized
INFO - 2019-12-26 11:20:23 --> Helper loaded: form_helper
INFO - 2019-12-26 11:20:23 --> Form Validation Class Initialized
INFO - 2019-12-26 11:20:23 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 11:20:23 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 11:20:23 --> Final output sent to browser
DEBUG - 2019-12-26 11:20:23 --> Total execution time: 0.4550
INFO - 2019-12-26 11:20:23 --> Config Class Initialized
INFO - 2019-12-26 11:20:23 --> Config Class Initialized
INFO - 2019-12-26 11:20:23 --> Hooks Class Initialized
INFO - 2019-12-26 11:20:23 --> Hooks Class Initialized
DEBUG - 2019-12-26 11:20:23 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 11:20:23 --> UTF-8 Support Enabled
INFO - 2019-12-26 11:20:24 --> Utf8 Class Initialized
INFO - 2019-12-26 11:20:24 --> Utf8 Class Initialized
INFO - 2019-12-26 11:20:24 --> URI Class Initialized
INFO - 2019-12-26 11:20:24 --> URI Class Initialized
INFO - 2019-12-26 11:20:24 --> Router Class Initialized
INFO - 2019-12-26 11:20:24 --> Router Class Initialized
INFO - 2019-12-26 11:20:24 --> Output Class Initialized
INFO - 2019-12-26 11:20:24 --> Output Class Initialized
INFO - 2019-12-26 11:20:24 --> Security Class Initialized
INFO - 2019-12-26 11:20:24 --> Security Class Initialized
DEBUG - 2019-12-26 11:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 11:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 11:20:24 --> Input Class Initialized
INFO - 2019-12-26 11:20:24 --> Input Class Initialized
INFO - 2019-12-26 11:20:24 --> Language Class Initialized
INFO - 2019-12-26 11:20:24 --> Language Class Initialized
ERROR - 2019-12-26 11:20:24 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 11:20:24 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 11:21:32 --> Config Class Initialized
INFO - 2019-12-26 11:21:32 --> Hooks Class Initialized
DEBUG - 2019-12-26 11:21:32 --> UTF-8 Support Enabled
INFO - 2019-12-26 11:21:32 --> Utf8 Class Initialized
INFO - 2019-12-26 11:21:32 --> URI Class Initialized
INFO - 2019-12-26 11:21:32 --> Router Class Initialized
INFO - 2019-12-26 11:21:32 --> Output Class Initialized
INFO - 2019-12-26 11:21:32 --> Security Class Initialized
DEBUG - 2019-12-26 11:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 11:21:32 --> Input Class Initialized
INFO - 2019-12-26 11:21:32 --> Language Class Initialized
INFO - 2019-12-26 11:21:32 --> Loader Class Initialized
INFO - 2019-12-26 11:21:32 --> Helper loaded: url_helper
INFO - 2019-12-26 11:21:32 --> Database Driver Class Initialized
DEBUG - 2019-12-26 11:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 11:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 11:21:32 --> Controller Class Initialized
INFO - 2019-12-26 11:21:32 --> Model "M_login" initialized
INFO - 2019-12-26 11:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 11:21:32 --> Pagination Class Initialized
INFO - 2019-12-26 11:21:32 --> Model "M_pesan" initialized
INFO - 2019-12-26 11:21:32 --> Helper loaded: form_helper
INFO - 2019-12-26 11:21:32 --> Form Validation Class Initialized
INFO - 2019-12-26 11:21:32 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-26 11:21:32 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 78
ERROR - 2019-12-26 11:21:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\pemesanan\lihat_pemesanan.php 78
INFO - 2019-12-26 11:21:32 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 11:21:32 --> Final output sent to browser
DEBUG - 2019-12-26 11:21:32 --> Total execution time: 0.5069
INFO - 2019-12-26 11:21:33 --> Config Class Initialized
INFO - 2019-12-26 11:21:33 --> Config Class Initialized
INFO - 2019-12-26 11:21:33 --> Hooks Class Initialized
INFO - 2019-12-26 11:21:33 --> Hooks Class Initialized
DEBUG - 2019-12-26 11:21:33 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 11:21:33 --> UTF-8 Support Enabled
INFO - 2019-12-26 11:21:33 --> Utf8 Class Initialized
INFO - 2019-12-26 11:21:33 --> Utf8 Class Initialized
INFO - 2019-12-26 11:21:33 --> URI Class Initialized
INFO - 2019-12-26 11:21:33 --> URI Class Initialized
INFO - 2019-12-26 11:21:33 --> Router Class Initialized
INFO - 2019-12-26 11:21:33 --> Router Class Initialized
INFO - 2019-12-26 11:21:33 --> Output Class Initialized
INFO - 2019-12-26 11:21:33 --> Output Class Initialized
INFO - 2019-12-26 11:21:33 --> Security Class Initialized
INFO - 2019-12-26 11:21:33 --> Security Class Initialized
DEBUG - 2019-12-26 11:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 11:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 11:21:33 --> Input Class Initialized
INFO - 2019-12-26 11:21:33 --> Input Class Initialized
INFO - 2019-12-26 11:21:33 --> Language Class Initialized
INFO - 2019-12-26 11:21:33 --> Language Class Initialized
ERROR - 2019-12-26 11:21:33 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 11:21:33 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 11:22:17 --> Config Class Initialized
INFO - 2019-12-26 11:22:17 --> Hooks Class Initialized
DEBUG - 2019-12-26 11:22:17 --> UTF-8 Support Enabled
INFO - 2019-12-26 11:22:17 --> Utf8 Class Initialized
INFO - 2019-12-26 11:22:17 --> URI Class Initialized
INFO - 2019-12-26 11:22:17 --> Router Class Initialized
INFO - 2019-12-26 11:22:17 --> Output Class Initialized
INFO - 2019-12-26 11:22:17 --> Security Class Initialized
DEBUG - 2019-12-26 11:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 11:22:17 --> Input Class Initialized
INFO - 2019-12-26 11:22:17 --> Language Class Initialized
INFO - 2019-12-26 11:22:17 --> Loader Class Initialized
INFO - 2019-12-26 11:22:17 --> Helper loaded: url_helper
INFO - 2019-12-26 11:22:17 --> Database Driver Class Initialized
DEBUG - 2019-12-26 11:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-26 11:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-26 11:22:17 --> Controller Class Initialized
INFO - 2019-12-26 11:22:17 --> Model "M_login" initialized
INFO - 2019-12-26 11:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-26 11:22:17 --> Pagination Class Initialized
INFO - 2019-12-26 11:22:17 --> Model "M_pesan" initialized
INFO - 2019-12-26 11:22:17 --> Helper loaded: form_helper
INFO - 2019-12-26 11:22:17 --> Form Validation Class Initialized
INFO - 2019-12-26 11:22:17 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-26 11:22:17 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-26 11:22:17 --> Final output sent to browser
DEBUG - 2019-12-26 11:22:17 --> Total execution time: 0.4384
INFO - 2019-12-26 11:22:18 --> Config Class Initialized
INFO - 2019-12-26 11:22:18 --> Config Class Initialized
INFO - 2019-12-26 11:22:18 --> Hooks Class Initialized
INFO - 2019-12-26 11:22:18 --> Hooks Class Initialized
DEBUG - 2019-12-26 11:22:18 --> UTF-8 Support Enabled
DEBUG - 2019-12-26 11:22:18 --> UTF-8 Support Enabled
INFO - 2019-12-26 11:22:18 --> Utf8 Class Initialized
INFO - 2019-12-26 11:22:18 --> Utf8 Class Initialized
INFO - 2019-12-26 11:22:18 --> URI Class Initialized
INFO - 2019-12-26 11:22:18 --> URI Class Initialized
INFO - 2019-12-26 11:22:18 --> Router Class Initialized
INFO - 2019-12-26 11:22:18 --> Router Class Initialized
INFO - 2019-12-26 11:22:18 --> Output Class Initialized
INFO - 2019-12-26 11:22:18 --> Output Class Initialized
INFO - 2019-12-26 11:22:18 --> Security Class Initialized
INFO - 2019-12-26 11:22:18 --> Security Class Initialized
DEBUG - 2019-12-26 11:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-26 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 11:22:18 --> Input Class Initialized
INFO - 2019-12-26 11:22:18 --> Input Class Initialized
INFO - 2019-12-26 11:22:18 --> Language Class Initialized
INFO - 2019-12-26 11:22:18 --> Language Class Initialized
ERROR - 2019-12-26 11:22:18 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-26 11:22:18 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-26 11:22:18 --> Config Class Initialized
INFO - 2019-12-26 11:22:18 --> Hooks Class Initialized
DEBUG - 2019-12-26 11:22:18 --> UTF-8 Support Enabled
INFO - 2019-12-26 11:22:18 --> Utf8 Class Initialized
INFO - 2019-12-26 11:22:18 --> URI Class Initialized
INFO - 2019-12-26 11:22:18 --> Router Class Initialized
INFO - 2019-12-26 11:22:18 --> Output Class Initialized
INFO - 2019-12-26 11:22:18 --> Security Class Initialized
DEBUG - 2019-12-26 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-26 11:22:18 --> Input Class Initialized
INFO - 2019-12-26 11:22:18 --> Language Class Initialized
ERROR - 2019-12-26 11:22:18 --> 404 Page Not Found: Pemesanan/assets
