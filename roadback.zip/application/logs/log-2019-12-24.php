<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-24 21:13:41 --> Config Class Initialized
INFO - 2019-12-24 21:13:41 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:41 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:41 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:41 --> URI Class Initialized
DEBUG - 2019-12-24 21:13:41 --> No URI present. Default controller set.
INFO - 2019-12-24 21:13:41 --> Router Class Initialized
INFO - 2019-12-24 21:13:41 --> Output Class Initialized
INFO - 2019-12-24 21:13:41 --> Security Class Initialized
DEBUG - 2019-12-24 21:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:41 --> Input Class Initialized
INFO - 2019-12-24 21:13:41 --> Language Class Initialized
INFO - 2019-12-24 21:13:41 --> Loader Class Initialized
INFO - 2019-12-24 21:13:41 --> Helper loaded: url_helper
INFO - 2019-12-24 21:13:41 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:13:41 --> Controller Class Initialized
INFO - 2019-12-24 21:13:41 --> Model "M_login" initialized
INFO - 2019-12-24 21:13:41 --> File loaded: C:\xampp\htdocs\Musikologi\application\views\admin/login.php
INFO - 2019-12-24 21:13:41 --> Final output sent to browser
DEBUG - 2019-12-24 21:13:41 --> Total execution time: 0.3489
INFO - 2019-12-24 21:13:44 --> Config Class Initialized
INFO - 2019-12-24 21:13:44 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:44 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:44 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:44 --> URI Class Initialized
INFO - 2019-12-24 21:13:44 --> Router Class Initialized
INFO - 2019-12-24 21:13:44 --> Output Class Initialized
INFO - 2019-12-24 21:13:44 --> Security Class Initialized
DEBUG - 2019-12-24 21:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:44 --> Input Class Initialized
INFO - 2019-12-24 21:13:44 --> Language Class Initialized
INFO - 2019-12-24 21:13:44 --> Loader Class Initialized
INFO - 2019-12-24 21:13:44 --> Helper loaded: url_helper
INFO - 2019-12-24 21:13:44 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:13:44 --> Controller Class Initialized
INFO - 2019-12-24 21:13:45 --> Model "M_login" initialized
INFO - 2019-12-24 21:13:45 --> Config Class Initialized
INFO - 2019-12-24 21:13:45 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:45 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:45 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:45 --> URI Class Initialized
DEBUG - 2019-12-24 21:13:45 --> No URI present. Default controller set.
INFO - 2019-12-24 21:13:45 --> Router Class Initialized
INFO - 2019-12-24 21:13:45 --> Output Class Initialized
INFO - 2019-12-24 21:13:45 --> Security Class Initialized
DEBUG - 2019-12-24 21:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:45 --> Input Class Initialized
INFO - 2019-12-24 21:13:45 --> Language Class Initialized
INFO - 2019-12-24 21:13:45 --> Loader Class Initialized
INFO - 2019-12-24 21:13:45 --> Helper loaded: url_helper
INFO - 2019-12-24 21:13:45 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:13:45 --> Controller Class Initialized
INFO - 2019-12-24 21:13:45 --> Model "M_login" initialized
INFO - 2019-12-24 21:13:45 --> File loaded: C:\xampp\htdocs\Musikologi\application\views\admin/login.php
INFO - 2019-12-24 21:13:45 --> Final output sent to browser
DEBUG - 2019-12-24 21:13:45 --> Total execution time: 0.2641
INFO - 2019-12-24 21:13:49 --> Config Class Initialized
INFO - 2019-12-24 21:13:49 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:49 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:49 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:50 --> URI Class Initialized
INFO - 2019-12-24 21:13:50 --> Router Class Initialized
INFO - 2019-12-24 21:13:50 --> Output Class Initialized
INFO - 2019-12-24 21:13:50 --> Security Class Initialized
DEBUG - 2019-12-24 21:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:50 --> Input Class Initialized
INFO - 2019-12-24 21:13:50 --> Language Class Initialized
INFO - 2019-12-24 21:13:50 --> Loader Class Initialized
INFO - 2019-12-24 21:13:50 --> Helper loaded: url_helper
INFO - 2019-12-24 21:13:50 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:13:50 --> Controller Class Initialized
INFO - 2019-12-24 21:13:50 --> Model "M_login" initialized
INFO - 2019-12-24 21:13:50 --> Config Class Initialized
INFO - 2019-12-24 21:13:50 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:50 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:50 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:50 --> URI Class Initialized
INFO - 2019-12-24 21:13:50 --> Router Class Initialized
INFO - 2019-12-24 21:13:50 --> Output Class Initialized
INFO - 2019-12-24 21:13:50 --> Security Class Initialized
DEBUG - 2019-12-24 21:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:50 --> Input Class Initialized
INFO - 2019-12-24 21:13:50 --> Language Class Initialized
INFO - 2019-12-24 21:13:50 --> Loader Class Initialized
INFO - 2019-12-24 21:13:50 --> Helper loaded: url_helper
INFO - 2019-12-24 21:13:50 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:13:50 --> Controller Class Initialized
INFO - 2019-12-24 21:13:50 --> File loaded: C:\xampp\htdocs\Musikologi\application\views\component/menu.php
INFO - 2019-12-24 21:13:50 --> File loaded: C:\xampp\htdocs\Musikologi\application\views\admin/beranda.php
INFO - 2019-12-24 21:13:50 --> Final output sent to browser
DEBUG - 2019-12-24 21:13:50 --> Total execution time: 0.2131
INFO - 2019-12-24 21:13:50 --> Config Class Initialized
INFO - 2019-12-24 21:13:50 --> Config Class Initialized
INFO - 2019-12-24 21:13:50 --> Config Class Initialized
INFO - 2019-12-24 21:13:50 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:50 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:50 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:50 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:50 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:50 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:50 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:50 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:50 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:50 --> URI Class Initialized
INFO - 2019-12-24 21:13:50 --> URI Class Initialized
INFO - 2019-12-24 21:13:50 --> URI Class Initialized
INFO - 2019-12-24 21:13:50 --> Router Class Initialized
INFO - 2019-12-24 21:13:50 --> Router Class Initialized
INFO - 2019-12-24 21:13:50 --> Router Class Initialized
INFO - 2019-12-24 21:13:50 --> Output Class Initialized
INFO - 2019-12-24 21:13:50 --> Output Class Initialized
INFO - 2019-12-24 21:13:50 --> Output Class Initialized
INFO - 2019-12-24 21:13:50 --> Security Class Initialized
INFO - 2019-12-24 21:13:50 --> Security Class Initialized
INFO - 2019-12-24 21:13:50 --> Security Class Initialized
DEBUG - 2019-12-24 21:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:50 --> Input Class Initialized
INFO - 2019-12-24 21:13:50 --> Input Class Initialized
INFO - 2019-12-24 21:13:50 --> Input Class Initialized
INFO - 2019-12-24 21:13:50 --> Language Class Initialized
INFO - 2019-12-24 21:13:50 --> Language Class Initialized
INFO - 2019-12-24 21:13:50 --> Language Class Initialized
ERROR - 2019-12-24 21:13:50 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-24 21:13:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-24 21:13:50 --> 404 Page Not Found: Assets/js
INFO - 2019-12-24 21:13:50 --> Config Class Initialized
INFO - 2019-12-24 21:13:50 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:50 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:50 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:50 --> URI Class Initialized
INFO - 2019-12-24 21:13:50 --> Router Class Initialized
INFO - 2019-12-24 21:13:50 --> Output Class Initialized
INFO - 2019-12-24 21:13:50 --> Security Class Initialized
DEBUG - 2019-12-24 21:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:50 --> Input Class Initialized
INFO - 2019-12-24 21:13:50 --> Language Class Initialized
ERROR - 2019-12-24 21:13:50 --> 404 Page Not Found: Assets/js
INFO - 2019-12-24 21:13:53 --> Config Class Initialized
INFO - 2019-12-24 21:13:53 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:53 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:53 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:53 --> URI Class Initialized
INFO - 2019-12-24 21:13:53 --> Router Class Initialized
INFO - 2019-12-24 21:13:53 --> Output Class Initialized
INFO - 2019-12-24 21:13:53 --> Security Class Initialized
DEBUG - 2019-12-24 21:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:53 --> Input Class Initialized
INFO - 2019-12-24 21:13:53 --> Language Class Initialized
INFO - 2019-12-24 21:13:53 --> Loader Class Initialized
INFO - 2019-12-24 21:13:53 --> Helper loaded: url_helper
INFO - 2019-12-24 21:13:53 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:13:53 --> Controller Class Initialized
INFO - 2019-12-24 21:13:53 --> Model "M_login" initialized
INFO - 2019-12-24 21:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-24 21:13:53 --> Pagination Class Initialized
INFO - 2019-12-24 21:13:53 --> Model "M_show" initialized
INFO - 2019-12-24 21:13:53 --> Helper loaded: form_helper
INFO - 2019-12-24 21:13:53 --> Form Validation Class Initialized
INFO - 2019-12-24 21:13:53 --> File loaded: C:\xampp\htdocs\Musikologi\application\views\component/menu.php
INFO - 2019-12-24 21:13:53 --> File loaded: C:\xampp\htdocs\Musikologi\application\views\admin/show/tambah_show.php
INFO - 2019-12-24 21:13:53 --> Final output sent to browser
DEBUG - 2019-12-24 21:13:53 --> Total execution time: 0.2960
INFO - 2019-12-24 21:13:53 --> Config Class Initialized
INFO - 2019-12-24 21:13:53 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:53 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:53 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:53 --> URI Class Initialized
INFO - 2019-12-24 21:13:53 --> Router Class Initialized
INFO - 2019-12-24 21:13:53 --> Output Class Initialized
INFO - 2019-12-24 21:13:53 --> Security Class Initialized
DEBUG - 2019-12-24 21:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:53 --> Input Class Initialized
INFO - 2019-12-24 21:13:53 --> Language Class Initialized
ERROR - 2019-12-24 21:13:53 --> 404 Page Not Found: Show/assets
INFO - 2019-12-24 21:13:56 --> Config Class Initialized
INFO - 2019-12-24 21:13:56 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:56 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:56 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:56 --> URI Class Initialized
INFO - 2019-12-24 21:13:56 --> Router Class Initialized
INFO - 2019-12-24 21:13:56 --> Output Class Initialized
INFO - 2019-12-24 21:13:56 --> Security Class Initialized
DEBUG - 2019-12-24 21:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:56 --> Input Class Initialized
INFO - 2019-12-24 21:13:56 --> Language Class Initialized
INFO - 2019-12-24 21:13:56 --> Loader Class Initialized
INFO - 2019-12-24 21:13:56 --> Helper loaded: url_helper
INFO - 2019-12-24 21:13:56 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:13:56 --> Controller Class Initialized
INFO - 2019-12-24 21:13:56 --> Model "M_login" initialized
INFO - 2019-12-24 21:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-24 21:13:56 --> Pagination Class Initialized
INFO - 2019-12-24 21:13:56 --> Model "M_show" initialized
INFO - 2019-12-24 21:13:56 --> Helper loaded: form_helper
INFO - 2019-12-24 21:13:56 --> Form Validation Class Initialized
INFO - 2019-12-24 21:13:56 --> File loaded: C:\xampp\htdocs\Musikologi\application\views\component/menu.php
INFO - 2019-12-24 21:13:56 --> File loaded: C:\xampp\htdocs\Musikologi\application\views\admin/show/lihat_show.php
INFO - 2019-12-24 21:13:56 --> Final output sent to browser
DEBUG - 2019-12-24 21:13:56 --> Total execution time: 0.3220
INFO - 2019-12-24 21:13:56 --> Config Class Initialized
INFO - 2019-12-24 21:13:56 --> Config Class Initialized
INFO - 2019-12-24 21:13:56 --> Config Class Initialized
INFO - 2019-12-24 21:13:56 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:56 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:56 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:56 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:56 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:56 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:56 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:56 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:56 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:56 --> URI Class Initialized
INFO - 2019-12-24 21:13:56 --> URI Class Initialized
INFO - 2019-12-24 21:13:56 --> URI Class Initialized
INFO - 2019-12-24 21:13:56 --> Router Class Initialized
INFO - 2019-12-24 21:13:56 --> Router Class Initialized
INFO - 2019-12-24 21:13:56 --> Router Class Initialized
INFO - 2019-12-24 21:13:56 --> Output Class Initialized
INFO - 2019-12-24 21:13:56 --> Output Class Initialized
INFO - 2019-12-24 21:13:56 --> Output Class Initialized
INFO - 2019-12-24 21:13:56 --> Security Class Initialized
INFO - 2019-12-24 21:13:56 --> Security Class Initialized
INFO - 2019-12-24 21:13:56 --> Security Class Initialized
DEBUG - 2019-12-24 21:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:56 --> Input Class Initialized
INFO - 2019-12-24 21:13:56 --> Input Class Initialized
INFO - 2019-12-24 21:13:56 --> Input Class Initialized
INFO - 2019-12-24 21:13:56 --> Language Class Initialized
INFO - 2019-12-24 21:13:56 --> Language Class Initialized
INFO - 2019-12-24 21:13:56 --> Language Class Initialized
ERROR - 2019-12-24 21:13:56 --> 404 Page Not Found: Show/assets
ERROR - 2019-12-24 21:13:56 --> 404 Page Not Found: Show/assets
ERROR - 2019-12-24 21:13:56 --> 404 Page Not Found: Show/assets
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
DEBUG - 2019-12-24 21:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:59 --> Input Class Initialized
INFO - 2019-12-24 21:13:59 --> Language Class Initialized
INFO - 2019-12-24 21:13:59 --> Loader Class Initialized
INFO - 2019-12-24 21:13:59 --> Helper loaded: url_helper
INFO - 2019-12-24 21:13:59 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:13:59 --> Controller Class Initialized
INFO - 2019-12-24 21:13:59 --> Model "M_login" initialized
INFO - 2019-12-24 21:13:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-24 21:13:59 --> Pagination Class Initialized
INFO - 2019-12-24 21:13:59 --> Model "M_show" initialized
INFO - 2019-12-24 21:13:59 --> Helper loaded: form_helper
INFO - 2019-12-24 21:13:59 --> Form Validation Class Initialized
INFO - 2019-12-24 21:13:59 --> File loaded: C:\xampp\htdocs\Musikologi\application\views\component/menu.php
INFO - 2019-12-24 21:13:59 --> File loaded: C:\xampp\htdocs\Musikologi\application\views\admin/show/edit_show.php
INFO - 2019-12-24 21:13:59 --> Final output sent to browser
DEBUG - 2019-12-24 21:13:59 --> Total execution time: 0.2923
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
DEBUG - 2019-12-24 21:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:59 --> Input Class Initialized
INFO - 2019-12-24 21:13:59 --> Input Class Initialized
INFO - 2019-12-24 21:13:59 --> Input Class Initialized
INFO - 2019-12-24 21:13:59 --> Input Class Initialized
INFO - 2019-12-24 21:13:59 --> Input Class Initialized
INFO - 2019-12-24 21:13:59 --> Input Class Initialized
INFO - 2019-12-24 21:13:59 --> Language Class Initialized
INFO - 2019-12-24 21:13:59 --> Language Class Initialized
INFO - 2019-12-24 21:13:59 --> Language Class Initialized
INFO - 2019-12-24 21:13:59 --> Language Class Initialized
INFO - 2019-12-24 21:13:59 --> Language Class Initialized
INFO - 2019-12-24 21:13:59 --> Language Class Initialized
ERROR - 2019-12-24 21:13:59 --> 404 Page Not Found: Bower_components/tether
ERROR - 2019-12-24 21:13:59 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2019-12-24 21:13:59 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2019-12-24 21:13:59 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2019-12-24 21:13:59 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2019-12-24 21:13:59 --> Loader Class Initialized
INFO - 2019-12-24 21:13:59 --> Helper loaded: url_helper
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:59 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:13:59 --> Controller Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> Model "M_login" initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Pagination Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
INFO - 2019-12-24 21:13:59 --> Model "M_show" initialized
DEBUG - 2019-12-24 21:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:13:59 --> Input Class Initialized
INFO - 2019-12-24 21:13:59 --> Input Class Initialized
INFO - 2019-12-24 21:13:59 --> Input Class Initialized
INFO - 2019-12-24 21:13:59 --> Input Class Initialized
INFO - 2019-12-24 21:13:59 --> Input Class Initialized
INFO - 2019-12-24 21:13:59 --> Helper loaded: form_helper
INFO - 2019-12-24 21:13:59 --> Form Validation Class Initialized
INFO - 2019-12-24 21:13:59 --> Language Class Initialized
INFO - 2019-12-24 21:13:59 --> Language Class Initialized
INFO - 2019-12-24 21:13:59 --> Language Class Initialized
INFO - 2019-12-24 21:13:59 --> Language Class Initialized
INFO - 2019-12-24 21:13:59 --> Language Class Initialized
ERROR - 2019-12-24 21:13:59 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2019-12-24 21:13:59 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2019-12-24 21:13:59 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2019-12-24 21:13:59 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2019-12-24 21:13:59 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2019-12-24 21:13:59 --> 404 Page Not Found: 
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Config Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
INFO - 2019-12-24 21:13:59 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:13:59 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> Utf8 Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> URI Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Router Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Output Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
INFO - 2019-12-24 21:13:59 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:00 --> Input Class Initialized
INFO - 2019-12-24 21:14:00 --> Input Class Initialized
INFO - 2019-12-24 21:14:00 --> Input Class Initialized
INFO - 2019-12-24 21:14:00 --> Input Class Initialized
INFO - 2019-12-24 21:14:00 --> Language Class Initialized
INFO - 2019-12-24 21:14:00 --> Language Class Initialized
INFO - 2019-12-24 21:14:00 --> Language Class Initialized
INFO - 2019-12-24 21:14:00 --> Language Class Initialized
ERROR - 2019-12-24 21:14:00 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2019-12-24 21:14:00 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2019-12-24 21:14:00 --> Loader Class Initialized
INFO - 2019-12-24 21:14:00 --> Loader Class Initialized
INFO - 2019-12-24 21:14:00 --> Helper loaded: url_helper
INFO - 2019-12-24 21:14:00 --> Helper loaded: url_helper
INFO - 2019-12-24 21:14:00 --> Config Class Initialized
INFO - 2019-12-24 21:14:00 --> Database Driver Class Initialized
INFO - 2019-12-24 21:14:00 --> Database Driver Class Initialized
INFO - 2019-12-24 21:14:00 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-12-24 21:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:14:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-12-24 21:14:00 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:00 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:00 --> Controller Class Initialized
INFO - 2019-12-24 21:14:00 --> Model "M_login" initialized
INFO - 2019-12-24 21:14:00 --> URI Class Initialized
INFO - 2019-12-24 21:14:00 --> Router Class Initialized
INFO - 2019-12-24 21:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-24 21:14:00 --> Pagination Class Initialized
INFO - 2019-12-24 21:14:00 --> Output Class Initialized
INFO - 2019-12-24 21:14:00 --> Model "M_show" initialized
INFO - 2019-12-24 21:14:00 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:00 --> Helper loaded: form_helper
INFO - 2019-12-24 21:14:00 --> Input Class Initialized
INFO - 2019-12-24 21:14:00 --> Form Validation Class Initialized
INFO - 2019-12-24 21:14:00 --> Language Class Initialized
ERROR - 2019-12-24 21:14:00 --> 404 Page Not Found: 
INFO - 2019-12-24 21:14:00 --> Session: Class initialized using 'files' driver.
ERROR - 2019-12-24 21:14:00 --> 404 Page Not Found: Bower_components/tether
INFO - 2019-12-24 21:14:00 --> Controller Class Initialized
INFO - 2019-12-24 21:14:00 --> Model "M_login" initialized
INFO - 2019-12-24 21:14:00 --> Config Class Initialized
INFO - 2019-12-24 21:14:00 --> Hooks Class Initialized
INFO - 2019-12-24 21:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-24 21:14:00 --> Pagination Class Initialized
DEBUG - 2019-12-24 21:14:00 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:00 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:00 --> Model "M_show" initialized
INFO - 2019-12-24 21:14:00 --> URI Class Initialized
INFO - 2019-12-24 21:14:00 --> Helper loaded: form_helper
INFO - 2019-12-24 21:14:00 --> Form Validation Class Initialized
INFO - 2019-12-24 21:14:00 --> Router Class Initialized
INFO - 2019-12-24 21:14:00 --> Output Class Initialized
ERROR - 2019-12-24 21:14:00 --> 404 Page Not Found: 
INFO - 2019-12-24 21:14:00 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:00 --> Input Class Initialized
INFO - 2019-12-24 21:14:00 --> Language Class Initialized
ERROR - 2019-12-24 21:14:00 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2019-12-24 21:14:00 --> Config Class Initialized
INFO - 2019-12-24 21:14:00 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:00 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:00 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:00 --> URI Class Initialized
INFO - 2019-12-24 21:14:00 --> Router Class Initialized
INFO - 2019-12-24 21:14:00 --> Output Class Initialized
INFO - 2019-12-24 21:14:00 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:00 --> Input Class Initialized
INFO - 2019-12-24 21:14:00 --> Language Class Initialized
ERROR - 2019-12-24 21:14:00 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2019-12-24 21:14:00 --> Config Class Initialized
INFO - 2019-12-24 21:14:00 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:00 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:00 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:00 --> URI Class Initialized
INFO - 2019-12-24 21:14:00 --> Router Class Initialized
INFO - 2019-12-24 21:14:00 --> Output Class Initialized
INFO - 2019-12-24 21:14:00 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:00 --> Input Class Initialized
INFO - 2019-12-24 21:14:00 --> Language Class Initialized
ERROR - 2019-12-24 21:14:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-24 21:14:00 --> Config Class Initialized
INFO - 2019-12-24 21:14:00 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:00 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:00 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:00 --> URI Class Initialized
INFO - 2019-12-24 21:14:00 --> Router Class Initialized
INFO - 2019-12-24 21:14:00 --> Output Class Initialized
INFO - 2019-12-24 21:14:00 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:00 --> Input Class Initialized
INFO - 2019-12-24 21:14:00 --> Language Class Initialized
ERROR - 2019-12-24 21:14:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-24 21:14:00 --> Config Class Initialized
INFO - 2019-12-24 21:14:00 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:00 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:00 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:00 --> URI Class Initialized
INFO - 2019-12-24 21:14:00 --> Router Class Initialized
INFO - 2019-12-24 21:14:00 --> Output Class Initialized
INFO - 2019-12-24 21:14:00 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:00 --> Input Class Initialized
INFO - 2019-12-24 21:14:00 --> Language Class Initialized
ERROR - 2019-12-24 21:14:00 --> 404 Page Not Found: Bower_components/i18next
INFO - 2019-12-24 21:14:00 --> Config Class Initialized
INFO - 2019-12-24 21:14:00 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:00 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:00 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:01 --> URI Class Initialized
INFO - 2019-12-24 21:14:01 --> Router Class Initialized
INFO - 2019-12-24 21:14:01 --> Output Class Initialized
INFO - 2019-12-24 21:14:01 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:01 --> Input Class Initialized
INFO - 2019-12-24 21:14:01 --> Language Class Initialized
ERROR - 2019-12-24 21:14:01 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2019-12-24 21:14:01 --> Config Class Initialized
INFO - 2019-12-24 21:14:01 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:01 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:01 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:01 --> URI Class Initialized
INFO - 2019-12-24 21:14:01 --> Router Class Initialized
INFO - 2019-12-24 21:14:01 --> Output Class Initialized
INFO - 2019-12-24 21:14:01 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:01 --> Input Class Initialized
INFO - 2019-12-24 21:14:01 --> Language Class Initialized
ERROR - 2019-12-24 21:14:01 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-24 21:14:01 --> Config Class Initialized
INFO - 2019-12-24 21:14:01 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:01 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:01 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:01 --> URI Class Initialized
INFO - 2019-12-24 21:14:01 --> Router Class Initialized
INFO - 2019-12-24 21:14:01 --> Output Class Initialized
INFO - 2019-12-24 21:14:01 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:01 --> Input Class Initialized
INFO - 2019-12-24 21:14:01 --> Language Class Initialized
ERROR - 2019-12-24 21:14:01 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2019-12-24 21:14:01 --> Config Class Initialized
INFO - 2019-12-24 21:14:01 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:01 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:01 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:01 --> URI Class Initialized
INFO - 2019-12-24 21:14:01 --> Router Class Initialized
INFO - 2019-12-24 21:14:01 --> Output Class Initialized
INFO - 2019-12-24 21:14:01 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:01 --> Input Class Initialized
INFO - 2019-12-24 21:14:01 --> Language Class Initialized
INFO - 2019-12-24 21:14:01 --> Loader Class Initialized
INFO - 2019-12-24 21:14:01 --> Helper loaded: url_helper
INFO - 2019-12-24 21:14:01 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:14:01 --> Controller Class Initialized
INFO - 2019-12-24 21:14:01 --> Model "M_login" initialized
INFO - 2019-12-24 21:14:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-24 21:14:01 --> Pagination Class Initialized
INFO - 2019-12-24 21:14:01 --> Model "M_show" initialized
INFO - 2019-12-24 21:14:01 --> Helper loaded: form_helper
INFO - 2019-12-24 21:14:01 --> Form Validation Class Initialized
ERROR - 2019-12-24 21:14:01 --> 404 Page Not Found: 
INFO - 2019-12-24 21:14:01 --> Config Class Initialized
INFO - 2019-12-24 21:14:01 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:01 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:01 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:01 --> URI Class Initialized
INFO - 2019-12-24 21:14:01 --> Router Class Initialized
INFO - 2019-12-24 21:14:01 --> Output Class Initialized
INFO - 2019-12-24 21:14:01 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:01 --> Input Class Initialized
INFO - 2019-12-24 21:14:01 --> Language Class Initialized
INFO - 2019-12-24 21:14:01 --> Loader Class Initialized
INFO - 2019-12-24 21:14:01 --> Helper loaded: url_helper
INFO - 2019-12-24 21:14:01 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:14:01 --> Controller Class Initialized
INFO - 2019-12-24 21:14:01 --> Model "M_login" initialized
INFO - 2019-12-24 21:14:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-24 21:14:01 --> Pagination Class Initialized
INFO - 2019-12-24 21:14:01 --> Model "M_show" initialized
INFO - 2019-12-24 21:14:02 --> Helper loaded: form_helper
INFO - 2019-12-24 21:14:02 --> Form Validation Class Initialized
ERROR - 2019-12-24 21:14:02 --> 404 Page Not Found: 
INFO - 2019-12-24 21:14:04 --> Config Class Initialized
INFO - 2019-12-24 21:14:04 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:04 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:04 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:04 --> URI Class Initialized
INFO - 2019-12-24 21:14:04 --> Router Class Initialized
INFO - 2019-12-24 21:14:04 --> Output Class Initialized
INFO - 2019-12-24 21:14:04 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:04 --> Input Class Initialized
INFO - 2019-12-24 21:14:04 --> Language Class Initialized
INFO - 2019-12-24 21:14:04 --> Loader Class Initialized
INFO - 2019-12-24 21:14:04 --> Helper loaded: url_helper
INFO - 2019-12-24 21:14:04 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:14:04 --> Controller Class Initialized
INFO - 2019-12-24 21:14:04 --> Model "M_login" initialized
INFO - 2019-12-24 21:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-24 21:14:04 --> Pagination Class Initialized
INFO - 2019-12-24 21:14:04 --> Model "M_show" initialized
INFO - 2019-12-24 21:14:04 --> Helper loaded: form_helper
INFO - 2019-12-24 21:14:04 --> Form Validation Class Initialized
INFO - 2019-12-24 21:14:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2019-12-24 21:14:04 --> Severity: Notice --> Undefined index: edit C:\xampp\htdocs\Musikologi\application\models\M_show.php 71
INFO - 2019-12-24 21:14:04 --> Config Class Initialized
INFO - 2019-12-24 21:14:04 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:04 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:04 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:04 --> URI Class Initialized
INFO - 2019-12-24 21:14:04 --> Router Class Initialized
INFO - 2019-12-24 21:14:05 --> Output Class Initialized
INFO - 2019-12-24 21:14:05 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:05 --> Input Class Initialized
INFO - 2019-12-24 21:14:05 --> Language Class Initialized
INFO - 2019-12-24 21:14:05 --> Loader Class Initialized
INFO - 2019-12-24 21:14:05 --> Helper loaded: url_helper
INFO - 2019-12-24 21:14:05 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:14:05 --> Controller Class Initialized
INFO - 2019-12-24 21:14:05 --> Model "M_login" initialized
INFO - 2019-12-24 21:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-24 21:14:05 --> Pagination Class Initialized
INFO - 2019-12-24 21:14:05 --> Model "M_show" initialized
INFO - 2019-12-24 21:14:05 --> Helper loaded: form_helper
INFO - 2019-12-24 21:14:05 --> Form Validation Class Initialized
INFO - 2019-12-24 21:14:05 --> File loaded: C:\xampp\htdocs\Musikologi\application\views\component/menu.php
INFO - 2019-12-24 21:14:05 --> File loaded: C:\xampp\htdocs\Musikologi\application\views\admin/show/lihat_show.php
INFO - 2019-12-24 21:14:05 --> Final output sent to browser
DEBUG - 2019-12-24 21:14:05 --> Total execution time: 0.2821
INFO - 2019-12-24 21:14:05 --> Config Class Initialized
INFO - 2019-12-24 21:14:05 --> Config Class Initialized
INFO - 2019-12-24 21:14:05 --> Config Class Initialized
INFO - 2019-12-24 21:14:05 --> Hooks Class Initialized
INFO - 2019-12-24 21:14:05 --> Hooks Class Initialized
INFO - 2019-12-24 21:14:05 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:05 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:14:05 --> UTF-8 Support Enabled
DEBUG - 2019-12-24 21:14:05 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:05 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:05 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:05 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:05 --> URI Class Initialized
INFO - 2019-12-24 21:14:05 --> URI Class Initialized
INFO - 2019-12-24 21:14:05 --> URI Class Initialized
INFO - 2019-12-24 21:14:05 --> Router Class Initialized
INFO - 2019-12-24 21:14:05 --> Router Class Initialized
INFO - 2019-12-24 21:14:05 --> Router Class Initialized
INFO - 2019-12-24 21:14:05 --> Output Class Initialized
INFO - 2019-12-24 21:14:05 --> Output Class Initialized
INFO - 2019-12-24 21:14:05 --> Output Class Initialized
INFO - 2019-12-24 21:14:05 --> Security Class Initialized
INFO - 2019-12-24 21:14:05 --> Security Class Initialized
INFO - 2019-12-24 21:14:05 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-24 21:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:05 --> Input Class Initialized
INFO - 2019-12-24 21:14:05 --> Input Class Initialized
INFO - 2019-12-24 21:14:05 --> Input Class Initialized
INFO - 2019-12-24 21:14:05 --> Language Class Initialized
INFO - 2019-12-24 21:14:05 --> Language Class Initialized
INFO - 2019-12-24 21:14:05 --> Language Class Initialized
ERROR - 2019-12-24 21:14:05 --> 404 Page Not Found: Show/assets
ERROR - 2019-12-24 21:14:05 --> 404 Page Not Found: Show/assets
ERROR - 2019-12-24 21:14:05 --> 404 Page Not Found: Show/assets
INFO - 2019-12-24 21:14:05 --> Config Class Initialized
INFO - 2019-12-24 21:14:05 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:05 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:05 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:05 --> URI Class Initialized
INFO - 2019-12-24 21:14:05 --> Router Class Initialized
INFO - 2019-12-24 21:14:05 --> Output Class Initialized
INFO - 2019-12-24 21:14:05 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:05 --> Input Class Initialized
INFO - 2019-12-24 21:14:05 --> Language Class Initialized
ERROR - 2019-12-24 21:14:05 --> 404 Page Not Found: Show/assets
INFO - 2019-12-24 21:14:05 --> Config Class Initialized
INFO - 2019-12-24 21:14:05 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:14:05 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:14:05 --> Utf8 Class Initialized
INFO - 2019-12-24 21:14:05 --> URI Class Initialized
INFO - 2019-12-24 21:14:05 --> Router Class Initialized
INFO - 2019-12-24 21:14:05 --> Output Class Initialized
INFO - 2019-12-24 21:14:05 --> Security Class Initialized
DEBUG - 2019-12-24 21:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:14:05 --> Input Class Initialized
INFO - 2019-12-24 21:14:05 --> Language Class Initialized
ERROR - 2019-12-24 21:14:05 --> 404 Page Not Found: Show/assets
INFO - 2019-12-24 21:18:28 --> Config Class Initialized
INFO - 2019-12-24 21:18:28 --> Hooks Class Initialized
DEBUG - 2019-12-24 21:18:28 --> UTF-8 Support Enabled
INFO - 2019-12-24 21:18:28 --> Utf8 Class Initialized
INFO - 2019-12-24 21:18:28 --> URI Class Initialized
DEBUG - 2019-12-24 21:18:28 --> No URI present. Default controller set.
INFO - 2019-12-24 21:18:28 --> Router Class Initialized
INFO - 2019-12-24 21:18:28 --> Output Class Initialized
INFO - 2019-12-24 21:18:28 --> Security Class Initialized
DEBUG - 2019-12-24 21:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 21:18:28 --> Input Class Initialized
INFO - 2019-12-24 21:18:28 --> Language Class Initialized
INFO - 2019-12-24 21:18:28 --> Loader Class Initialized
INFO - 2019-12-24 21:18:28 --> Helper loaded: url_helper
INFO - 2019-12-24 21:18:28 --> Database Driver Class Initialized
DEBUG - 2019-12-24 21:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-24 21:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-24 21:18:28 --> Controller Class Initialized
INFO - 2019-12-24 21:18:28 --> Model "M_login" initialized
INFO - 2019-12-24 21:18:28 --> File loaded: C:\xampp\htdocs\Musikologi\application\views\admin/login.php
INFO - 2019-12-24 21:18:28 --> Final output sent to browser
DEBUG - 2019-12-24 21:18:28 --> Total execution time: 0.2259
