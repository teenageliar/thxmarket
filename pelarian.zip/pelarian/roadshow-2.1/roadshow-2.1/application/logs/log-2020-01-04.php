<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-04 13:44:52 --> Config Class Initialized
INFO - 2020-01-04 13:44:52 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:44:52 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:44:52 --> Utf8 Class Initialized
INFO - 2020-01-04 13:44:52 --> URI Class Initialized
DEBUG - 2020-01-04 13:44:52 --> No URI present. Default controller set.
INFO - 2020-01-04 13:44:52 --> Router Class Initialized
INFO - 2020-01-04 13:44:52 --> Output Class Initialized
INFO - 2020-01-04 13:44:52 --> Security Class Initialized
DEBUG - 2020-01-04 13:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:44:52 --> Input Class Initialized
INFO - 2020-01-04 13:44:52 --> Language Class Initialized
INFO - 2020-01-04 13:44:52 --> Loader Class Initialized
INFO - 2020-01-04 13:44:52 --> Helper loaded: url_helper
INFO - 2020-01-04 13:44:53 --> Database Driver Class Initialized
DEBUG - 2020-01-04 13:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-04 13:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-04 13:44:53 --> Controller Class Initialized
INFO - 2020-01-04 13:44:53 --> Model "M_login" initialized
INFO - 2020-01-04 13:44:53 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2020-01-04 13:44:53 --> Final output sent to browser
DEBUG - 2020-01-04 13:44:54 --> Total execution time: 2.1272
INFO - 2020-01-04 13:44:58 --> Config Class Initialized
INFO - 2020-01-04 13:44:58 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:44:58 --> Utf8 Class Initialized
INFO - 2020-01-04 13:44:58 --> URI Class Initialized
INFO - 2020-01-04 13:44:58 --> Router Class Initialized
INFO - 2020-01-04 13:44:58 --> Output Class Initialized
INFO - 2020-01-04 13:44:58 --> Security Class Initialized
DEBUG - 2020-01-04 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:44:58 --> Input Class Initialized
INFO - 2020-01-04 13:44:58 --> Language Class Initialized
INFO - 2020-01-04 13:44:58 --> Loader Class Initialized
INFO - 2020-01-04 13:44:58 --> Helper loaded: url_helper
INFO - 2020-01-04 13:44:58 --> Database Driver Class Initialized
DEBUG - 2020-01-04 13:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-04 13:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-04 13:44:58 --> Controller Class Initialized
INFO - 2020-01-04 13:44:58 --> Model "M_login" initialized
INFO - 2020-01-04 13:44:59 --> Config Class Initialized
INFO - 2020-01-04 13:44:59 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:44:59 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:44:59 --> Utf8 Class Initialized
INFO - 2020-01-04 13:44:59 --> URI Class Initialized
INFO - 2020-01-04 13:44:59 --> Router Class Initialized
INFO - 2020-01-04 13:44:59 --> Output Class Initialized
INFO - 2020-01-04 13:44:59 --> Security Class Initialized
DEBUG - 2020-01-04 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:44:59 --> Input Class Initialized
INFO - 2020-01-04 13:44:59 --> Language Class Initialized
INFO - 2020-01-04 13:44:59 --> Loader Class Initialized
INFO - 2020-01-04 13:44:59 --> Helper loaded: url_helper
INFO - 2020-01-04 13:44:59 --> Database Driver Class Initialized
DEBUG - 2020-01-04 13:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-04 13:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-04 13:44:59 --> Controller Class Initialized
INFO - 2020-01-04 13:44:59 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-04 13:44:59 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2020-01-04 13:44:59 --> Final output sent to browser
DEBUG - 2020-01-04 13:44:59 --> Total execution time: 0.5332
INFO - 2020-01-04 13:44:59 --> Config Class Initialized
INFO - 2020-01-04 13:44:59 --> Hooks Class Initialized
INFO - 2020-01-04 13:44:59 --> Config Class Initialized
INFO - 2020-01-04 13:44:59 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:44:59 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:45:00 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:00 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:00 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:00 --> URI Class Initialized
INFO - 2020-01-04 13:45:00 --> URI Class Initialized
INFO - 2020-01-04 13:45:00 --> Router Class Initialized
INFO - 2020-01-04 13:45:00 --> Router Class Initialized
INFO - 2020-01-04 13:45:00 --> Output Class Initialized
INFO - 2020-01-04 13:45:00 --> Output Class Initialized
INFO - 2020-01-04 13:45:00 --> Security Class Initialized
INFO - 2020-01-04 13:45:00 --> Security Class Initialized
DEBUG - 2020-01-04 13:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:00 --> Input Class Initialized
INFO - 2020-01-04 13:45:00 --> Input Class Initialized
INFO - 2020-01-04 13:45:00 --> Language Class Initialized
INFO - 2020-01-04 13:45:00 --> Language Class Initialized
ERROR - 2020-01-04 13:45:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-04 13:45:00 --> 404 Page Not Found: Assets/js
INFO - 2020-01-04 13:45:00 --> Config Class Initialized
INFO - 2020-01-04 13:45:00 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:45:00 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:00 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:00 --> URI Class Initialized
INFO - 2020-01-04 13:45:00 --> Router Class Initialized
INFO - 2020-01-04 13:45:00 --> Output Class Initialized
INFO - 2020-01-04 13:45:00 --> Security Class Initialized
DEBUG - 2020-01-04 13:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:00 --> Input Class Initialized
INFO - 2020-01-04 13:45:00 --> Language Class Initialized
ERROR - 2020-01-04 13:45:00 --> 404 Page Not Found: Assets/js
INFO - 2020-01-04 13:45:02 --> Config Class Initialized
INFO - 2020-01-04 13:45:02 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:45:02 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:02 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:02 --> URI Class Initialized
INFO - 2020-01-04 13:45:02 --> Router Class Initialized
INFO - 2020-01-04 13:45:02 --> Output Class Initialized
INFO - 2020-01-04 13:45:02 --> Security Class Initialized
DEBUG - 2020-01-04 13:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:02 --> Input Class Initialized
INFO - 2020-01-04 13:45:02 --> Language Class Initialized
INFO - 2020-01-04 13:45:02 --> Loader Class Initialized
INFO - 2020-01-04 13:45:02 --> Helper loaded: url_helper
INFO - 2020-01-04 13:45:03 --> Database Driver Class Initialized
DEBUG - 2020-01-04 13:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-04 13:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-04 13:45:03 --> Controller Class Initialized
INFO - 2020-01-04 13:45:03 --> Model "M_login" initialized
INFO - 2020-01-04 13:45:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-04 13:45:03 --> Pagination Class Initialized
INFO - 2020-01-04 13:45:03 --> Model "M_show" initialized
INFO - 2020-01-04 13:45:03 --> Helper loaded: form_helper
INFO - 2020-01-04 13:45:03 --> Form Validation Class Initialized
INFO - 2020-01-04 13:45:03 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-04 13:45:03 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-04 13:45:03 --> Final output sent to browser
DEBUG - 2020-01-04 13:45:03 --> Total execution time: 1.3008
INFO - 2020-01-04 13:45:04 --> Config Class Initialized
INFO - 2020-01-04 13:45:04 --> Config Class Initialized
INFO - 2020-01-04 13:45:04 --> Hooks Class Initialized
INFO - 2020-01-04 13:45:04 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:45:04 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:45:04 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:04 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:04 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:04 --> URI Class Initialized
INFO - 2020-01-04 13:45:04 --> URI Class Initialized
INFO - 2020-01-04 13:45:04 --> Router Class Initialized
INFO - 2020-01-04 13:45:04 --> Router Class Initialized
INFO - 2020-01-04 13:45:04 --> Output Class Initialized
INFO - 2020-01-04 13:45:04 --> Output Class Initialized
INFO - 2020-01-04 13:45:04 --> Security Class Initialized
INFO - 2020-01-04 13:45:04 --> Security Class Initialized
DEBUG - 2020-01-04 13:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:04 --> Input Class Initialized
INFO - 2020-01-04 13:45:04 --> Input Class Initialized
INFO - 2020-01-04 13:45:04 --> Language Class Initialized
INFO - 2020-01-04 13:45:04 --> Language Class Initialized
ERROR - 2020-01-04 13:45:04 --> 404 Page Not Found: Show/assets
ERROR - 2020-01-04 13:45:04 --> 404 Page Not Found: Show/assets
INFO - 2020-01-04 13:45:08 --> Config Class Initialized
INFO - 2020-01-04 13:45:08 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:45:08 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:08 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:08 --> URI Class Initialized
INFO - 2020-01-04 13:45:08 --> Router Class Initialized
INFO - 2020-01-04 13:45:08 --> Output Class Initialized
INFO - 2020-01-04 13:45:08 --> Security Class Initialized
DEBUG - 2020-01-04 13:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:08 --> Input Class Initialized
INFO - 2020-01-04 13:45:08 --> Language Class Initialized
INFO - 2020-01-04 13:45:08 --> Loader Class Initialized
INFO - 2020-01-04 13:45:08 --> Helper loaded: url_helper
INFO - 2020-01-04 13:45:08 --> Database Driver Class Initialized
DEBUG - 2020-01-04 13:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-04 13:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-04 13:45:08 --> Controller Class Initialized
INFO - 2020-01-04 13:45:08 --> Model "M_login" initialized
INFO - 2020-01-04 13:45:08 --> Model "M_tiket" initialized
INFO - 2020-01-04 13:45:08 --> Helper loaded: form_helper
INFO - 2020-01-04 13:45:08 --> Form Validation Class Initialized
INFO - 2020-01-04 13:45:08 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-04 13:45:08 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-04 13:45:08 --> Final output sent to browser
DEBUG - 2020-01-04 13:45:08 --> Total execution time: 0.7600
INFO - 2020-01-04 13:45:08 --> Config Class Initialized
INFO - 2020-01-04 13:45:08 --> Config Class Initialized
INFO - 2020-01-04 13:45:08 --> Hooks Class Initialized
INFO - 2020-01-04 13:45:08 --> Hooks Class Initialized
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
ERROR - 2020-01-04 13:45:09 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-01-04 13:45:09 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
ERROR - 2020-01-04 13:45:09 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
ERROR - 2020-01-04 13:45:09 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-04 13:45:09 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-04 13:45:09 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
ERROR - 2020-01-04 13:45:09 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-04 13:45:09 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
ERROR - 2020-01-04 13:45:09 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-01-04 13:45:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-01-04 13:45:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-04 13:45:09 --> Loader Class Initialized
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
INFO - 2020-01-04 13:45:09 --> Helper loaded: url_helper
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:09 --> Database Driver Class Initialized
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
DEBUG - 2020-01-04 13:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-04 13:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> Controller Class Initialized
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> Model "M_login" initialized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> Model "M_tiket" initialized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:09 --> Helper loaded: form_helper
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
INFO - 2020-01-04 13:45:09 --> Form Validation Class Initialized
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
ERROR - 2020-01-04 13:45:09 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-01-04 13:45:09 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-04 13:45:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-04 13:45:09 --> Loader Class Initialized
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
INFO - 2020-01-04 13:45:09 --> Helper loaded: url_helper
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
ERROR - 2020-01-04 13:45:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2020-01-04 13:45:09 --> Database Driver Class Initialized
INFO - 2020-01-04 13:45:09 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-01-04 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-04 13:45:09 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:09 --> Final output sent to browser
DEBUG - 2020-01-04 13:45:09 --> Total execution time: 0.4877
INFO - 2020-01-04 13:45:09 --> URI Class Initialized
INFO - 2020-01-04 13:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-04 13:45:09 --> Router Class Initialized
INFO - 2020-01-04 13:45:09 --> Controller Class Initialized
INFO - 2020-01-04 13:45:09 --> Output Class Initialized
INFO - 2020-01-04 13:45:09 --> Model "M_login" initialized
INFO - 2020-01-04 13:45:09 --> Security Class Initialized
INFO - 2020-01-04 13:45:09 --> Model "M_tiket" initialized
DEBUG - 2020-01-04 13:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:09 --> Input Class Initialized
INFO - 2020-01-04 13:45:09 --> Helper loaded: form_helper
INFO - 2020-01-04 13:45:09 --> Form Validation Class Initialized
INFO - 2020-01-04 13:45:09 --> Language Class Initialized
ERROR - 2020-01-04 13:45:09 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-04 13:45:09 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-04 13:45:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-01-04 13:45:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2020-01-04 13:45:09 --> Config Class Initialized
INFO - 2020-01-04 13:45:09 --> Hooks Class Initialized
INFO - 2020-01-04 13:45:09 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-04 13:45:10 --> Final output sent to browser
DEBUG - 2020-01-04 13:45:10 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:10 --> Utf8 Class Initialized
DEBUG - 2020-01-04 13:45:10 --> Total execution time: 0.5043
INFO - 2020-01-04 13:45:10 --> URI Class Initialized
INFO - 2020-01-04 13:45:10 --> Router Class Initialized
INFO - 2020-01-04 13:45:10 --> Output Class Initialized
INFO - 2020-01-04 13:45:10 --> Security Class Initialized
DEBUG - 2020-01-04 13:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:10 --> Input Class Initialized
INFO - 2020-01-04 13:45:10 --> Language Class Initialized
ERROR - 2020-01-04 13:45:10 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-04 13:45:10 --> Config Class Initialized
INFO - 2020-01-04 13:45:10 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:45:10 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:10 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:10 --> URI Class Initialized
INFO - 2020-01-04 13:45:10 --> Router Class Initialized
INFO - 2020-01-04 13:45:10 --> Output Class Initialized
INFO - 2020-01-04 13:45:10 --> Security Class Initialized
DEBUG - 2020-01-04 13:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:10 --> Input Class Initialized
INFO - 2020-01-04 13:45:10 --> Language Class Initialized
ERROR - 2020-01-04 13:45:10 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-04 13:45:10 --> Config Class Initialized
INFO - 2020-01-04 13:45:10 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:45:10 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:10 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:10 --> URI Class Initialized
INFO - 2020-01-04 13:45:10 --> Router Class Initialized
INFO - 2020-01-04 13:45:10 --> Output Class Initialized
INFO - 2020-01-04 13:45:10 --> Security Class Initialized
DEBUG - 2020-01-04 13:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:10 --> Input Class Initialized
INFO - 2020-01-04 13:45:10 --> Language Class Initialized
ERROR - 2020-01-04 13:45:10 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-04 13:45:10 --> Config Class Initialized
INFO - 2020-01-04 13:45:10 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:45:10 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:10 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:10 --> URI Class Initialized
INFO - 2020-01-04 13:45:10 --> Router Class Initialized
INFO - 2020-01-04 13:45:10 --> Output Class Initialized
INFO - 2020-01-04 13:45:10 --> Security Class Initialized
DEBUG - 2020-01-04 13:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:10 --> Input Class Initialized
INFO - 2020-01-04 13:45:10 --> Language Class Initialized
ERROR - 2020-01-04 13:45:10 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-04 13:45:10 --> Config Class Initialized
INFO - 2020-01-04 13:45:10 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:45:10 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:45:10 --> Utf8 Class Initialized
INFO - 2020-01-04 13:45:10 --> URI Class Initialized
INFO - 2020-01-04 13:45:11 --> Router Class Initialized
INFO - 2020-01-04 13:45:11 --> Output Class Initialized
INFO - 2020-01-04 13:45:11 --> Security Class Initialized
DEBUG - 2020-01-04 13:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:45:11 --> Input Class Initialized
INFO - 2020-01-04 13:45:11 --> Language Class Initialized
ERROR - 2020-01-04 13:45:11 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-04 13:46:06 --> Config Class Initialized
INFO - 2020-01-04 13:46:06 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:46:06 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:46:06 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:06 --> URI Class Initialized
INFO - 2020-01-04 13:46:06 --> Router Class Initialized
INFO - 2020-01-04 13:46:06 --> Output Class Initialized
INFO - 2020-01-04 13:46:06 --> Security Class Initialized
DEBUG - 2020-01-04 13:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:46:06 --> Input Class Initialized
INFO - 2020-01-04 13:46:06 --> Language Class Initialized
INFO - 2020-01-04 13:46:06 --> Loader Class Initialized
INFO - 2020-01-04 13:46:06 --> Helper loaded: url_helper
INFO - 2020-01-04 13:46:06 --> Database Driver Class Initialized
DEBUG - 2020-01-04 13:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-04 13:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-04 13:46:06 --> Controller Class Initialized
INFO - 2020-01-04 13:46:06 --> Model "M_login" initialized
INFO - 2020-01-04 13:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-04 13:46:06 --> Pagination Class Initialized
INFO - 2020-01-04 13:46:06 --> Model "M_show" initialized
INFO - 2020-01-04 13:46:06 --> Helper loaded: form_helper
INFO - 2020-01-04 13:46:06 --> Form Validation Class Initialized
INFO - 2020-01-04 13:46:06 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-04 13:46:06 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-04 13:46:06 --> Final output sent to browser
DEBUG - 2020-01-04 13:46:06 --> Total execution time: 0.5410
INFO - 2020-01-04 13:46:10 --> Config Class Initialized
INFO - 2020-01-04 13:46:10 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:46:10 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:46:10 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:10 --> URI Class Initialized
INFO - 2020-01-04 13:46:10 --> Router Class Initialized
INFO - 2020-01-04 13:46:10 --> Output Class Initialized
INFO - 2020-01-04 13:46:10 --> Security Class Initialized
DEBUG - 2020-01-04 13:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:46:10 --> Input Class Initialized
INFO - 2020-01-04 13:46:10 --> Language Class Initialized
INFO - 2020-01-04 13:46:10 --> Loader Class Initialized
INFO - 2020-01-04 13:46:10 --> Helper loaded: url_helper
INFO - 2020-01-04 13:46:10 --> Database Driver Class Initialized
DEBUG - 2020-01-04 13:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-04 13:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-04 13:46:10 --> Controller Class Initialized
INFO - 2020-01-04 13:46:10 --> Model "M_login" initialized
INFO - 2020-01-04 13:46:10 --> Model "M_tiket" initialized
INFO - 2020-01-04 13:46:10 --> Helper loaded: form_helper
INFO - 2020-01-04 13:46:10 --> Form Validation Class Initialized
INFO - 2020-01-04 13:46:10 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-04 13:46:10 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-04 13:46:10 --> Final output sent to browser
DEBUG - 2020-01-04 13:46:10 --> Total execution time: 0.4524
INFO - 2020-01-04 13:46:10 --> Config Class Initialized
INFO - 2020-01-04 13:46:10 --> Hooks Class Initialized
INFO - 2020-01-04 13:46:10 --> Config Class Initialized
INFO - 2020-01-04 13:46:10 --> Config Class Initialized
INFO - 2020-01-04 13:46:10 --> Config Class Initialized
INFO - 2020-01-04 13:46:10 --> Config Class Initialized
INFO - 2020-01-04 13:46:10 --> Config Class Initialized
INFO - 2020-01-04 13:46:10 --> Hooks Class Initialized
INFO - 2020-01-04 13:46:10 --> Hooks Class Initialized
INFO - 2020-01-04 13:46:10 --> Hooks Class Initialized
INFO - 2020-01-04 13:46:10 --> Hooks Class Initialized
INFO - 2020-01-04 13:46:10 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:46:10 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:46:10 --> Utf8 Class Initialized
DEBUG - 2020-01-04 13:46:10 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:46:10 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:46:10 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:46:10 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:46:10 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:46:10 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:10 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:10 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:10 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:10 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:10 --> URI Class Initialized
INFO - 2020-01-04 13:46:10 --> URI Class Initialized
INFO - 2020-01-04 13:46:10 --> URI Class Initialized
INFO - 2020-01-04 13:46:10 --> URI Class Initialized
INFO - 2020-01-04 13:46:10 --> URI Class Initialized
INFO - 2020-01-04 13:46:10 --> URI Class Initialized
INFO - 2020-01-04 13:46:10 --> Router Class Initialized
INFO - 2020-01-04 13:46:10 --> Router Class Initialized
INFO - 2020-01-04 13:46:10 --> Router Class Initialized
INFO - 2020-01-04 13:46:10 --> Router Class Initialized
INFO - 2020-01-04 13:46:10 --> Output Class Initialized
INFO - 2020-01-04 13:46:10 --> Router Class Initialized
INFO - 2020-01-04 13:46:10 --> Router Class Initialized
INFO - 2020-01-04 13:46:10 --> Security Class Initialized
INFO - 2020-01-04 13:46:10 --> Output Class Initialized
INFO - 2020-01-04 13:46:10 --> Output Class Initialized
INFO - 2020-01-04 13:46:10 --> Output Class Initialized
INFO - 2020-01-04 13:46:10 --> Output Class Initialized
INFO - 2020-01-04 13:46:10 --> Output Class Initialized
DEBUG - 2020-01-04 13:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:46:10 --> Security Class Initialized
INFO - 2020-01-04 13:46:10 --> Security Class Initialized
INFO - 2020-01-04 13:46:10 --> Security Class Initialized
INFO - 2020-01-04 13:46:10 --> Security Class Initialized
INFO - 2020-01-04 13:46:10 --> Security Class Initialized
INFO - 2020-01-04 13:46:10 --> Input Class Initialized
DEBUG - 2020-01-04 13:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:46:10 --> Input Class Initialized
INFO - 2020-01-04 13:46:10 --> Input Class Initialized
INFO - 2020-01-04 13:46:10 --> Input Class Initialized
INFO - 2020-01-04 13:46:10 --> Input Class Initialized
INFO - 2020-01-04 13:46:10 --> Input Class Initialized
INFO - 2020-01-04 13:46:10 --> Language Class Initialized
INFO - 2020-01-04 13:46:10 --> Language Class Initialized
INFO - 2020-01-04 13:46:10 --> Language Class Initialized
INFO - 2020-01-04 13:46:10 --> Language Class Initialized
INFO - 2020-01-04 13:46:10 --> Language Class Initialized
INFO - 2020-01-04 13:46:10 --> Language Class Initialized
ERROR - 2020-01-04 13:46:10 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-01-04 13:46:10 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-01-04 13:46:10 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-01-04 13:46:10 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-04 13:46:10 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-04 13:46:10 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-04 13:46:10 --> Config Class Initialized
INFO - 2020-01-04 13:46:10 --> Config Class Initialized
INFO - 2020-01-04 13:46:10 --> Config Class Initialized
INFO - 2020-01-04 13:46:10 --> Config Class Initialized
INFO - 2020-01-04 13:46:10 --> Config Class Initialized
INFO - 2020-01-04 13:46:11 --> Config Class Initialized
INFO - 2020-01-04 13:46:11 --> Hooks Class Initialized
INFO - 2020-01-04 13:46:11 --> Hooks Class Initialized
INFO - 2020-01-04 13:46:11 --> Hooks Class Initialized
INFO - 2020-01-04 13:46:11 --> Hooks Class Initialized
INFO - 2020-01-04 13:46:11 --> Hooks Class Initialized
INFO - 2020-01-04 13:46:11 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:46:11 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:46:11 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:11 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:11 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:11 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:11 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:11 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:11 --> URI Class Initialized
INFO - 2020-01-04 13:46:11 --> URI Class Initialized
INFO - 2020-01-04 13:46:11 --> URI Class Initialized
INFO - 2020-01-04 13:46:11 --> URI Class Initialized
INFO - 2020-01-04 13:46:11 --> URI Class Initialized
INFO - 2020-01-04 13:46:11 --> URI Class Initialized
INFO - 2020-01-04 13:46:11 --> Router Class Initialized
INFO - 2020-01-04 13:46:11 --> Router Class Initialized
INFO - 2020-01-04 13:46:11 --> Router Class Initialized
INFO - 2020-01-04 13:46:11 --> Router Class Initialized
INFO - 2020-01-04 13:46:11 --> Router Class Initialized
INFO - 2020-01-04 13:46:11 --> Router Class Initialized
INFO - 2020-01-04 13:46:11 --> Output Class Initialized
INFO - 2020-01-04 13:46:11 --> Output Class Initialized
INFO - 2020-01-04 13:46:11 --> Output Class Initialized
INFO - 2020-01-04 13:46:11 --> Output Class Initialized
INFO - 2020-01-04 13:46:11 --> Output Class Initialized
INFO - 2020-01-04 13:46:11 --> Output Class Initialized
INFO - 2020-01-04 13:46:11 --> Security Class Initialized
INFO - 2020-01-04 13:46:11 --> Security Class Initialized
INFO - 2020-01-04 13:46:11 --> Security Class Initialized
INFO - 2020-01-04 13:46:11 --> Security Class Initialized
INFO - 2020-01-04 13:46:11 --> Security Class Initialized
INFO - 2020-01-04 13:46:11 --> Security Class Initialized
DEBUG - 2020-01-04 13:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:46:11 --> Input Class Initialized
INFO - 2020-01-04 13:46:11 --> Input Class Initialized
INFO - 2020-01-04 13:46:11 --> Input Class Initialized
INFO - 2020-01-04 13:46:11 --> Input Class Initialized
INFO - 2020-01-04 13:46:11 --> Input Class Initialized
INFO - 2020-01-04 13:46:11 --> Input Class Initialized
INFO - 2020-01-04 13:46:11 --> Language Class Initialized
INFO - 2020-01-04 13:46:11 --> Language Class Initialized
INFO - 2020-01-04 13:46:11 --> Language Class Initialized
INFO - 2020-01-04 13:46:11 --> Language Class Initialized
INFO - 2020-01-04 13:46:11 --> Language Class Initialized
INFO - 2020-01-04 13:46:11 --> Language Class Initialized
ERROR - 2020-01-04 13:46:11 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-01-04 13:46:11 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-01-04 13:46:11 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-04 13:46:11 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-01-04 13:46:11 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-04 13:46:11 --> Loader Class Initialized
INFO - 2020-01-04 13:46:11 --> Helper loaded: url_helper
INFO - 2020-01-04 13:46:11 --> Config Class Initialized
INFO - 2020-01-04 13:46:11 --> Config Class Initialized
INFO - 2020-01-04 13:46:11 --> Hooks Class Initialized
INFO - 2020-01-04 13:46:11 --> Hooks Class Initialized
INFO - 2020-01-04 13:46:11 --> Database Driver Class Initialized
DEBUG - 2020-01-04 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2020-01-04 13:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-04 13:46:11 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:11 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-04 13:46:11 --> Controller Class Initialized
INFO - 2020-01-04 13:46:11 --> URI Class Initialized
INFO - 2020-01-04 13:46:11 --> URI Class Initialized
INFO - 2020-01-04 13:46:11 --> Model "M_login" initialized
INFO - 2020-01-04 13:46:11 --> Router Class Initialized
INFO - 2020-01-04 13:46:11 --> Router Class Initialized
INFO - 2020-01-04 13:46:11 --> Model "M_tiket" initialized
INFO - 2020-01-04 13:46:11 --> Output Class Initialized
INFO - 2020-01-04 13:46:11 --> Output Class Initialized
INFO - 2020-01-04 13:46:11 --> Security Class Initialized
INFO - 2020-01-04 13:46:11 --> Security Class Initialized
INFO - 2020-01-04 13:46:11 --> Helper loaded: form_helper
INFO - 2020-01-04 13:46:11 --> Form Validation Class Initialized
DEBUG - 2020-01-04 13:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-04 13:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:46:11 --> Input Class Initialized
INFO - 2020-01-04 13:46:11 --> Input Class Initialized
INFO - 2020-01-04 13:46:11 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-04 13:46:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-04 13:46:11 --> Language Class Initialized
INFO - 2020-01-04 13:46:11 --> Language Class Initialized
ERROR - 2020-01-04 13:46:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-01-04 13:46:11 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-01-04 13:46:11 --> Loader Class Initialized
INFO - 2020-01-04 13:46:11 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-04 13:46:11 --> Helper loaded: url_helper
INFO - 2020-01-04 13:46:11 --> Final output sent to browser
INFO - 2020-01-04 13:46:11 --> Config Class Initialized
INFO - 2020-01-04 13:46:11 --> Database Driver Class Initialized
INFO - 2020-01-04 13:46:11 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:46:11 --> Total execution time: 0.6066
DEBUG - 2020-01-04 13:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-04 13:46:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-01-04 13:46:11 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:46:11 --> Controller Class Initialized
INFO - 2020-01-04 13:46:11 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:11 --> Model "M_login" initialized
INFO - 2020-01-04 13:46:11 --> URI Class Initialized
INFO - 2020-01-04 13:46:11 --> Model "M_tiket" initialized
INFO - 2020-01-04 13:46:11 --> Router Class Initialized
INFO - 2020-01-04 13:46:11 --> Output Class Initialized
INFO - 2020-01-04 13:46:11 --> Helper loaded: form_helper
INFO - 2020-01-04 13:46:11 --> Form Validation Class Initialized
INFO - 2020-01-04 13:46:11 --> Security Class Initialized
DEBUG - 2020-01-04 13:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:46:11 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-04 13:46:11 --> Input Class Initialized
ERROR - 2020-01-04 13:46:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-04 13:46:11 --> Language Class Initialized
ERROR - 2020-01-04 13:46:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2020-01-04 13:46:11 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-01-04 13:46:11 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-01-04 13:46:11 --> Final output sent to browser
DEBUG - 2020-01-04 13:46:11 --> Total execution time: 0.4544
INFO - 2020-01-04 13:46:11 --> Config Class Initialized
INFO - 2020-01-04 13:46:11 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:46:11 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:46:11 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:11 --> URI Class Initialized
INFO - 2020-01-04 13:46:11 --> Router Class Initialized
INFO - 2020-01-04 13:46:11 --> Output Class Initialized
INFO - 2020-01-04 13:46:11 --> Security Class Initialized
DEBUG - 2020-01-04 13:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:46:11 --> Input Class Initialized
INFO - 2020-01-04 13:46:12 --> Language Class Initialized
ERROR - 2020-01-04 13:46:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-04 13:46:12 --> Config Class Initialized
INFO - 2020-01-04 13:46:12 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:46:12 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:12 --> URI Class Initialized
INFO - 2020-01-04 13:46:12 --> Router Class Initialized
INFO - 2020-01-04 13:46:12 --> Output Class Initialized
INFO - 2020-01-04 13:46:12 --> Security Class Initialized
DEBUG - 2020-01-04 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:46:12 --> Input Class Initialized
INFO - 2020-01-04 13:46:12 --> Language Class Initialized
ERROR - 2020-01-04 13:46:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-04 13:46:12 --> Config Class Initialized
INFO - 2020-01-04 13:46:12 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:46:12 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:12 --> URI Class Initialized
INFO - 2020-01-04 13:46:12 --> Router Class Initialized
INFO - 2020-01-04 13:46:12 --> Output Class Initialized
INFO - 2020-01-04 13:46:12 --> Security Class Initialized
DEBUG - 2020-01-04 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:46:12 --> Input Class Initialized
INFO - 2020-01-04 13:46:12 --> Language Class Initialized
ERROR - 2020-01-04 13:46:12 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-04 13:46:12 --> Config Class Initialized
INFO - 2020-01-04 13:46:12 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:46:12 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:12 --> URI Class Initialized
INFO - 2020-01-04 13:46:12 --> Router Class Initialized
INFO - 2020-01-04 13:46:12 --> Output Class Initialized
INFO - 2020-01-04 13:46:12 --> Security Class Initialized
DEBUG - 2020-01-04 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:46:12 --> Input Class Initialized
INFO - 2020-01-04 13:46:12 --> Language Class Initialized
ERROR - 2020-01-04 13:46:12 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-04 13:46:12 --> Config Class Initialized
INFO - 2020-01-04 13:46:12 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:46:12 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:12 --> URI Class Initialized
INFO - 2020-01-04 13:46:12 --> Router Class Initialized
INFO - 2020-01-04 13:46:12 --> Output Class Initialized
INFO - 2020-01-04 13:46:12 --> Security Class Initialized
DEBUG - 2020-01-04 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:46:12 --> Input Class Initialized
INFO - 2020-01-04 13:46:12 --> Language Class Initialized
ERROR - 2020-01-04 13:46:12 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-04 13:46:12 --> Config Class Initialized
INFO - 2020-01-04 13:46:12 --> Hooks Class Initialized
DEBUG - 2020-01-04 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-01-04 13:46:13 --> Utf8 Class Initialized
INFO - 2020-01-04 13:46:13 --> URI Class Initialized
INFO - 2020-01-04 13:46:13 --> Router Class Initialized
INFO - 2020-01-04 13:46:13 --> Output Class Initialized
INFO - 2020-01-04 13:46:13 --> Security Class Initialized
DEBUG - 2020-01-04 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 13:46:13 --> Input Class Initialized
INFO - 2020-01-04 13:46:13 --> Language Class Initialized
ERROR - 2020-01-04 13:46:13 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-04 14:55:06 --> Config Class Initialized
INFO - 2020-01-04 14:55:06 --> Hooks Class Initialized
DEBUG - 2020-01-04 14:55:07 --> UTF-8 Support Enabled
INFO - 2020-01-04 14:55:07 --> Utf8 Class Initialized
INFO - 2020-01-04 14:55:07 --> URI Class Initialized
INFO - 2020-01-04 14:55:07 --> Router Class Initialized
INFO - 2020-01-04 14:55:07 --> Output Class Initialized
INFO - 2020-01-04 14:55:07 --> Security Class Initialized
DEBUG - 2020-01-04 14:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 14:55:07 --> Input Class Initialized
INFO - 2020-01-04 14:55:07 --> Language Class Initialized
INFO - 2020-01-04 14:55:07 --> Loader Class Initialized
INFO - 2020-01-04 14:55:08 --> Helper loaded: url_helper
INFO - 2020-01-04 14:55:08 --> Database Driver Class Initialized
DEBUG - 2020-01-04 14:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-04 14:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-04 14:55:08 --> Controller Class Initialized
INFO - 2020-01-04 14:55:08 --> Model "M_login" initialized
INFO - 2020-01-04 14:55:08 --> Model "M_tiket" initialized
INFO - 2020-01-04 14:55:08 --> Helper loaded: form_helper
INFO - 2020-01-04 14:55:08 --> Form Validation Class Initialized
INFO - 2020-01-04 14:55:09 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-04 14:55:09 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-04 14:55:09 --> Final output sent to browser
DEBUG - 2020-01-04 14:55:09 --> Total execution time: 2.8654
INFO - 2020-01-04 14:55:09 --> Config Class Initialized
INFO - 2020-01-04 14:55:09 --> Hooks Class Initialized
DEBUG - 2020-01-04 14:55:09 --> UTF-8 Support Enabled
INFO - 2020-01-04 14:55:09 --> Config Class Initialized
INFO - 2020-01-04 14:55:09 --> Hooks Class Initialized
INFO - 2020-01-04 14:55:09 --> Utf8 Class Initialized
INFO - 2020-01-04 14:55:09 --> URI Class Initialized
DEBUG - 2020-01-04 14:55:09 --> UTF-8 Support Enabled
INFO - 2020-01-04 14:55:09 --> Utf8 Class Initialized
INFO - 2020-01-04 14:55:09 --> Router Class Initialized
INFO - 2020-01-04 14:55:09 --> Config Class Initialized
INFO - 2020-01-04 14:55:09 --> Hooks Class Initialized
INFO - 2020-01-04 14:55:09 --> URI Class Initialized
INFO - 2020-01-04 14:55:09 --> Output Class Initialized
INFO - 2020-01-04 14:55:09 --> Security Class Initialized
INFO - 2020-01-04 14:55:09 --> Router Class Initialized
DEBUG - 2020-01-04 14:55:09 --> UTF-8 Support Enabled
INFO - 2020-01-04 14:55:09 --> Utf8 Class Initialized
DEBUG - 2020-01-04 14:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 14:55:09 --> Output Class Initialized
INFO - 2020-01-04 14:55:09 --> Input Class Initialized
INFO - 2020-01-04 14:55:09 --> URI Class Initialized
INFO - 2020-01-04 14:55:09 --> Security Class Initialized
INFO - 2020-01-04 14:55:09 --> Language Class Initialized
DEBUG - 2020-01-04 14:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 14:55:09 --> Router Class Initialized
INFO - 2020-01-04 14:55:09 --> Input Class Initialized
INFO - 2020-01-04 14:55:09 --> Language Class Initialized
INFO - 2020-01-04 14:55:09 --> Output Class Initialized
ERROR - 2020-01-04 14:55:09 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-01-04 14:55:09 --> Loader Class Initialized
INFO - 2020-01-04 14:55:09 --> Helper loaded: url_helper
INFO - 2020-01-04 14:55:09 --> Security Class Initialized
INFO - 2020-01-04 14:55:09 --> Database Driver Class Initialized
DEBUG - 2020-01-04 14:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-01-04 14:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-04 14:55:09 --> Input Class Initialized
INFO - 2020-01-04 14:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-04 14:55:10 --> Controller Class Initialized
INFO - 2020-01-04 14:55:10 --> Language Class Initialized
INFO - 2020-01-04 14:55:10 --> Model "M_login" initialized
INFO - 2020-01-04 14:55:10 --> Model "M_tiket" initialized
INFO - 2020-01-04 14:55:10 --> Helper loaded: form_helper
INFO - 2020-01-04 14:55:10 --> Form Validation Class Initialized
INFO - 2020-01-04 14:55:10 --> Loader Class Initialized
INFO - 2020-01-04 14:55:10 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-04 14:55:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-04 14:55:10 --> Helper loaded: url_helper
ERROR - 2020-01-04 14:55:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2020-01-04 14:55:10 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-04 14:55:10 --> Database Driver Class Initialized
INFO - 2020-01-04 14:55:10 --> Final output sent to browser
DEBUG - 2020-01-04 14:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-01-04 14:55:10 --> Total execution time: 1.0124
INFO - 2020-01-04 14:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-04 14:55:10 --> Controller Class Initialized
INFO - 2020-01-04 14:55:10 --> Model "M_login" initialized
INFO - 2020-01-04 14:55:10 --> Model "M_tiket" initialized
INFO - 2020-01-04 14:55:10 --> Helper loaded: form_helper
INFO - 2020-01-04 14:55:10 --> Form Validation Class Initialized
INFO - 2020-01-04 14:55:10 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-04 14:55:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-01-04 14:55:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2020-01-04 14:55:10 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-04 14:55:10 --> Final output sent to browser
DEBUG - 2020-01-04 14:55:10 --> Total execution time: 1.1846
