<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-02 19:08:14 --> Config Class Initialized
INFO - 2020-02-02 19:08:14 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:08:14 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:08:14 --> Utf8 Class Initialized
INFO - 2020-02-02 19:08:15 --> URI Class Initialized
DEBUG - 2020-02-02 19:08:15 --> No URI present. Default controller set.
INFO - 2020-02-02 19:08:15 --> Router Class Initialized
INFO - 2020-02-02 19:08:15 --> Output Class Initialized
INFO - 2020-02-02 19:08:15 --> Security Class Initialized
DEBUG - 2020-02-02 19:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:08:15 --> Input Class Initialized
INFO - 2020-02-02 19:08:15 --> Language Class Initialized
INFO - 2020-02-02 19:08:15 --> Loader Class Initialized
INFO - 2020-02-02 19:08:16 --> Helper loaded: url_helper
INFO - 2020-02-02 19:08:16 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:08:16 --> Controller Class Initialized
INFO - 2020-02-02 19:08:16 --> Model "M_login" initialized
INFO - 2020-02-02 19:08:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/login.php
INFO - 2020-02-02 19:08:17 --> Final output sent to browser
DEBUG - 2020-02-02 19:08:17 --> Total execution time: 2.4747
INFO - 2020-02-02 19:10:26 --> Config Class Initialized
INFO - 2020-02-02 19:10:26 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:10:26 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:10:26 --> Utf8 Class Initialized
INFO - 2020-02-02 19:10:26 --> URI Class Initialized
DEBUG - 2020-02-02 19:10:26 --> No URI present. Default controller set.
INFO - 2020-02-02 19:10:26 --> Router Class Initialized
INFO - 2020-02-02 19:10:26 --> Output Class Initialized
INFO - 2020-02-02 19:10:26 --> Security Class Initialized
DEBUG - 2020-02-02 19:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:10:26 --> Input Class Initialized
INFO - 2020-02-02 19:10:26 --> Language Class Initialized
INFO - 2020-02-02 19:10:27 --> Loader Class Initialized
INFO - 2020-02-02 19:10:27 --> Helper loaded: url_helper
INFO - 2020-02-02 19:10:27 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:10:27 --> Controller Class Initialized
INFO - 2020-02-02 19:10:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\component/menu.php
INFO - 2020-02-02 19:10:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/beranda.php
INFO - 2020-02-02 19:10:27 --> Final output sent to browser
DEBUG - 2020-02-02 19:10:28 --> Total execution time: 1.1460
INFO - 2020-02-02 19:10:47 --> Config Class Initialized
INFO - 2020-02-02 19:10:47 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:10:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:10:47 --> Utf8 Class Initialized
INFO - 2020-02-02 19:10:47 --> URI Class Initialized
DEBUG - 2020-02-02 19:10:47 --> No URI present. Default controller set.
INFO - 2020-02-02 19:10:47 --> Router Class Initialized
INFO - 2020-02-02 19:10:47 --> Output Class Initialized
INFO - 2020-02-02 19:10:47 --> Security Class Initialized
DEBUG - 2020-02-02 19:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:10:47 --> Input Class Initialized
INFO - 2020-02-02 19:10:47 --> Language Class Initialized
ERROR - 2020-02-02 19:10:48 --> 404 Page Not Found: Show/index
INFO - 2020-02-02 19:12:48 --> Config Class Initialized
INFO - 2020-02-02 19:12:48 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:12:48 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:12:48 --> Utf8 Class Initialized
INFO - 2020-02-02 19:12:48 --> URI Class Initialized
DEBUG - 2020-02-02 19:12:48 --> No URI present. Default controller set.
INFO - 2020-02-02 19:12:48 --> Router Class Initialized
INFO - 2020-02-02 19:12:48 --> Output Class Initialized
INFO - 2020-02-02 19:12:48 --> Security Class Initialized
DEBUG - 2020-02-02 19:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:12:48 --> Input Class Initialized
INFO - 2020-02-02 19:12:48 --> Language Class Initialized
INFO - 2020-02-02 19:12:48 --> Loader Class Initialized
INFO - 2020-02-02 19:12:48 --> Helper loaded: url_helper
INFO - 2020-02-02 19:12:48 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:12:48 --> Controller Class Initialized
INFO - 2020-02-02 19:12:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-02 19:12:48 --> Pagination Class Initialized
INFO - 2020-02-02 19:12:49 --> Model "M_show" initialized
INFO - 2020-02-02 19:12:49 --> Helper loaded: form_helper
INFO - 2020-02-02 19:12:49 --> Form Validation Class Initialized
INFO - 2020-02-02 19:12:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\component/menu.php
INFO - 2020-02-02 19:12:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-02 19:12:50 --> Final output sent to browser
DEBUG - 2020-02-02 19:12:50 --> Total execution time: 2.0259
INFO - 2020-02-02 19:14:54 --> Config Class Initialized
INFO - 2020-02-02 19:14:54 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:14:54 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:14:54 --> Utf8 Class Initialized
INFO - 2020-02-02 19:14:54 --> URI Class Initialized
DEBUG - 2020-02-02 19:14:54 --> No URI present. Default controller set.
INFO - 2020-02-02 19:14:54 --> Router Class Initialized
INFO - 2020-02-02 19:14:54 --> Output Class Initialized
INFO - 2020-02-02 19:14:54 --> Security Class Initialized
DEBUG - 2020-02-02 19:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:14:54 --> Input Class Initialized
INFO - 2020-02-02 19:14:54 --> Language Class Initialized
INFO - 2020-02-02 19:14:54 --> Loader Class Initialized
INFO - 2020-02-02 19:14:55 --> Helper loaded: url_helper
INFO - 2020-02-02 19:14:55 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:14:55 --> Controller Class Initialized
INFO - 2020-02-02 19:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-02 19:14:55 --> Pagination Class Initialized
INFO - 2020-02-02 19:14:55 --> Model "M_show" initialized
INFO - 2020-02-02 19:14:55 --> Helper loaded: form_helper
INFO - 2020-02-02 19:14:55 --> Form Validation Class Initialized
INFO - 2020-02-02 19:14:55 --> File loaded: C:\xampp\htdocs\roadshow\application\views\component/menu.php
ERROR - 2020-02-02 19:14:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\roadshow\application\views\admin\show\lihat_show.php 84
ERROR - 2020-02-02 19:14:55 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\admin\show\lihat_show.php 84
INFO - 2020-02-02 19:16:42 --> Config Class Initialized
INFO - 2020-02-02 19:16:42 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:16:42 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:16:42 --> Utf8 Class Initialized
INFO - 2020-02-02 19:16:42 --> URI Class Initialized
DEBUG - 2020-02-02 19:16:42 --> No URI present. Default controller set.
INFO - 2020-02-02 19:16:42 --> Router Class Initialized
INFO - 2020-02-02 19:16:42 --> Output Class Initialized
INFO - 2020-02-02 19:16:42 --> Security Class Initialized
DEBUG - 2020-02-02 19:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:16:42 --> Input Class Initialized
INFO - 2020-02-02 19:16:42 --> Language Class Initialized
INFO - 2020-02-02 19:16:42 --> Loader Class Initialized
INFO - 2020-02-02 19:16:42 --> Helper loaded: url_helper
INFO - 2020-02-02 19:16:42 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:16:43 --> Controller Class Initialized
INFO - 2020-02-02 19:16:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-02 19:16:43 --> Pagination Class Initialized
INFO - 2020-02-02 19:16:43 --> Model "M_show" initialized
INFO - 2020-02-02 19:16:43 --> Helper loaded: form_helper
INFO - 2020-02-02 19:16:43 --> Form Validation Class Initialized
INFO - 2020-02-02 19:16:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\component/menu.php
INFO - 2020-02-02 19:16:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-02 19:16:43 --> Final output sent to browser
DEBUG - 2020-02-02 19:16:43 --> Total execution time: 0.6858
INFO - 2020-02-02 19:18:32 --> Config Class Initialized
INFO - 2020-02-02 19:18:32 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:18:32 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:32 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:32 --> URI Class Initialized
DEBUG - 2020-02-02 19:18:32 --> No URI present. Default controller set.
INFO - 2020-02-02 19:18:32 --> Router Class Initialized
INFO - 2020-02-02 19:18:33 --> Output Class Initialized
INFO - 2020-02-02 19:18:33 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:33 --> Input Class Initialized
INFO - 2020-02-02 19:18:33 --> Language Class Initialized
INFO - 2020-02-02 19:18:33 --> Loader Class Initialized
INFO - 2020-02-02 19:18:33 --> Helper loaded: url_helper
INFO - 2020-02-02 19:18:33 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:18:33 --> Controller Class Initialized
INFO - 2020-02-02 19:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-02 19:18:33 --> Pagination Class Initialized
INFO - 2020-02-02 19:18:33 --> Model "M_show" initialized
INFO - 2020-02-02 19:18:33 --> Helper loaded: form_helper
INFO - 2020-02-02 19:18:33 --> Form Validation Class Initialized
INFO - 2020-02-02 19:18:33 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-02 19:18:33 --> Final output sent to browser
DEBUG - 2020-02-02 19:18:34 --> Total execution time: 1.5135
INFO - 2020-02-02 19:18:45 --> Config Class Initialized
INFO - 2020-02-02 19:18:45 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:18:45 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:45 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:45 --> URI Class Initialized
INFO - 2020-02-02 19:18:45 --> Router Class Initialized
INFO - 2020-02-02 19:18:45 --> Output Class Initialized
INFO - 2020-02-02 19:18:45 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:46 --> Input Class Initialized
INFO - 2020-02-02 19:18:46 --> Language Class Initialized
INFO - 2020-02-02 19:18:46 --> Loader Class Initialized
INFO - 2020-02-02 19:18:46 --> Helper loaded: url_helper
INFO - 2020-02-02 19:18:46 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:18:46 --> Controller Class Initialized
INFO - 2020-02-02 19:18:46 --> Model "M_login" initialized
INFO - 2020-02-02 19:18:46 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:18:46 --> Helper loaded: form_helper
INFO - 2020-02-02 19:18:46 --> Form Validation Class Initialized
INFO - 2020-02-02 19:18:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\component/menu.php
INFO - 2020-02-02 19:18:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:18:46 --> Final output sent to browser
DEBUG - 2020-02-02 19:18:46 --> Total execution time: 0.7970
INFO - 2020-02-02 19:18:46 --> Config Class Initialized
INFO - 2020-02-02 19:18:46 --> Hooks Class Initialized
INFO - 2020-02-02 19:18:46 --> Config Class Initialized
INFO - 2020-02-02 19:18:46 --> Config Class Initialized
INFO - 2020-02-02 19:18:46 --> Config Class Initialized
INFO - 2020-02-02 19:18:46 --> Config Class Initialized
INFO - 2020-02-02 19:18:46 --> Hooks Class Initialized
INFO - 2020-02-02 19:18:46 --> Hooks Class Initialized
INFO - 2020-02-02 19:18:46 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:18:46 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:46 --> Hooks Class Initialized
INFO - 2020-02-02 19:18:46 --> Config Class Initialized
INFO - 2020-02-02 19:18:46 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:18:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:18:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:18:46 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:46 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:18:46 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:46 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:46 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:46 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:46 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:46 --> URI Class Initialized
DEBUG - 2020-02-02 19:18:46 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:46 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:46 --> URI Class Initialized
INFO - 2020-02-02 19:18:46 --> URI Class Initialized
INFO - 2020-02-02 19:18:46 --> URI Class Initialized
INFO - 2020-02-02 19:18:46 --> URI Class Initialized
INFO - 2020-02-02 19:18:46 --> Router Class Initialized
INFO - 2020-02-02 19:18:46 --> URI Class Initialized
INFO - 2020-02-02 19:18:46 --> Router Class Initialized
INFO - 2020-02-02 19:18:46 --> Router Class Initialized
INFO - 2020-02-02 19:18:46 --> Router Class Initialized
INFO - 2020-02-02 19:18:46 --> Router Class Initialized
INFO - 2020-02-02 19:18:46 --> Output Class Initialized
INFO - 2020-02-02 19:18:46 --> Router Class Initialized
INFO - 2020-02-02 19:18:46 --> Output Class Initialized
INFO - 2020-02-02 19:18:46 --> Security Class Initialized
INFO - 2020-02-02 19:18:46 --> Output Class Initialized
INFO - 2020-02-02 19:18:46 --> Output Class Initialized
INFO - 2020-02-02 19:18:46 --> Output Class Initialized
INFO - 2020-02-02 19:18:46 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:46 --> Output Class Initialized
INFO - 2020-02-02 19:18:46 --> Security Class Initialized
INFO - 2020-02-02 19:18:46 --> Security Class Initialized
INFO - 2020-02-02 19:18:46 --> Security Class Initialized
INFO - 2020-02-02 19:18:46 --> Input Class Initialized
DEBUG - 2020-02-02 19:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:46 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:46 --> Input Class Initialized
INFO - 2020-02-02 19:18:46 --> Input Class Initialized
INFO - 2020-02-02 19:18:46 --> Input Class Initialized
INFO - 2020-02-02 19:18:46 --> Input Class Initialized
INFO - 2020-02-02 19:18:46 --> Language Class Initialized
DEBUG - 2020-02-02 19:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:46 --> Input Class Initialized
INFO - 2020-02-02 19:18:46 --> Language Class Initialized
INFO - 2020-02-02 19:18:46 --> Language Class Initialized
INFO - 2020-02-02 19:18:46 --> Language Class Initialized
ERROR - 2020-02-02 19:18:46 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 19:18:46 --> Language Class Initialized
INFO - 2020-02-02 19:18:46 --> Language Class Initialized
ERROR - 2020-02-02 19:18:46 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-02 19:18:46 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-02 19:18:46 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 19:18:46 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:18:47 --> Config Class Initialized
INFO - 2020-02-02 19:18:47 --> Hooks Class Initialized
ERROR - 2020-02-02 19:18:47 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:18:47 --> Config Class Initialized
INFO - 2020-02-02 19:18:47 --> Config Class Initialized
INFO - 2020-02-02 19:18:47 --> Config Class Initialized
INFO - 2020-02-02 19:18:47 --> Config Class Initialized
INFO - 2020-02-02 19:18:47 --> Hooks Class Initialized
INFO - 2020-02-02 19:18:47 --> Hooks Class Initialized
INFO - 2020-02-02 19:18:47 --> Hooks Class Initialized
INFO - 2020-02-02 19:18:47 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:18:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:47 --> Config Class Initialized
DEBUG - 2020-02-02 19:18:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:18:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:18:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:47 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:18:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:47 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:47 --> Hooks Class Initialized
INFO - 2020-02-02 19:18:47 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:47 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:47 --> URI Class Initialized
INFO - 2020-02-02 19:18:47 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:47 --> URI Class Initialized
INFO - 2020-02-02 19:18:47 --> URI Class Initialized
INFO - 2020-02-02 19:18:47 --> URI Class Initialized
INFO - 2020-02-02 19:18:47 --> Router Class Initialized
INFO - 2020-02-02 19:18:47 --> URI Class Initialized
DEBUG - 2020-02-02 19:18:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:47 --> Router Class Initialized
INFO - 2020-02-02 19:18:47 --> Router Class Initialized
INFO - 2020-02-02 19:18:47 --> Output Class Initialized
INFO - 2020-02-02 19:18:47 --> Router Class Initialized
INFO - 2020-02-02 19:18:47 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:47 --> Router Class Initialized
INFO - 2020-02-02 19:18:47 --> Security Class Initialized
INFO - 2020-02-02 19:18:47 --> Output Class Initialized
INFO - 2020-02-02 19:18:47 --> Output Class Initialized
INFO - 2020-02-02 19:18:47 --> Output Class Initialized
INFO - 2020-02-02 19:18:47 --> URI Class Initialized
INFO - 2020-02-02 19:18:47 --> Output Class Initialized
INFO - 2020-02-02 19:18:47 --> Security Class Initialized
INFO - 2020-02-02 19:18:47 --> Router Class Initialized
INFO - 2020-02-02 19:18:47 --> Security Class Initialized
INFO - 2020-02-02 19:18:47 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:47 --> Security Class Initialized
INFO - 2020-02-02 19:18:47 --> Input Class Initialized
DEBUG - 2020-02-02 19:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:47 --> Output Class Initialized
DEBUG - 2020-02-02 19:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:47 --> Input Class Initialized
INFO - 2020-02-02 19:18:47 --> Input Class Initialized
INFO - 2020-02-02 19:18:47 --> Input Class Initialized
INFO - 2020-02-02 19:18:47 --> Input Class Initialized
INFO - 2020-02-02 19:18:47 --> Language Class Initialized
INFO - 2020-02-02 19:18:47 --> Security Class Initialized
INFO - 2020-02-02 19:18:47 --> Language Class Initialized
INFO - 2020-02-02 19:18:47 --> Language Class Initialized
DEBUG - 2020-02-02 19:18:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 19:18:47 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:18:47 --> Language Class Initialized
INFO - 2020-02-02 19:18:47 --> Language Class Initialized
ERROR - 2020-02-02 19:18:47 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-02 19:18:47 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:18:47 --> Input Class Initialized
ERROR - 2020-02-02 19:18:47 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-02 19:18:47 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:18:47 --> Config Class Initialized
INFO - 2020-02-02 19:18:47 --> Hooks Class Initialized
INFO - 2020-02-02 19:18:47 --> Language Class Initialized
INFO - 2020-02-02 19:18:47 --> Config Class Initialized
INFO - 2020-02-02 19:18:47 --> Hooks Class Initialized
INFO - 2020-02-02 19:18:47 --> Loader Class Initialized
DEBUG - 2020-02-02 19:18:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:47 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:47 --> Helper loaded: url_helper
DEBUG - 2020-02-02 19:18:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:47 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:47 --> URI Class Initialized
INFO - 2020-02-02 19:18:47 --> Database Driver Class Initialized
INFO - 2020-02-02 19:18:47 --> URI Class Initialized
INFO - 2020-02-02 19:18:47 --> Router Class Initialized
DEBUG - 2020-02-02 19:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:18:47 --> Router Class Initialized
INFO - 2020-02-02 19:18:47 --> Output Class Initialized
INFO - 2020-02-02 19:18:47 --> Controller Class Initialized
INFO - 2020-02-02 19:18:47 --> Security Class Initialized
INFO - 2020-02-02 19:18:47 --> Output Class Initialized
INFO - 2020-02-02 19:18:47 --> Model "M_login" initialized
DEBUG - 2020-02-02 19:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:47 --> Security Class Initialized
INFO - 2020-02-02 19:18:47 --> Input Class Initialized
INFO - 2020-02-02 19:18:47 --> Model "M_tiket" initialized
DEBUG - 2020-02-02 19:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:47 --> Input Class Initialized
INFO - 2020-02-02 19:18:47 --> Language Class Initialized
INFO - 2020-02-02 19:18:47 --> Helper loaded: form_helper
INFO - 2020-02-02 19:18:47 --> Form Validation Class Initialized
INFO - 2020-02-02 19:18:47 --> Language Class Initialized
INFO - 2020-02-02 19:18:47 --> Loader Class Initialized
ERROR - 2020-02-02 19:18:47 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 19:18:47 --> Helper loaded: url_helper
INFO - 2020-02-02 19:18:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\component/menu.php
ERROR - 2020-02-02 19:18:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:18:47 --> Database Driver Class Initialized
INFO - 2020-02-02 19:18:47 --> Config Class Initialized
ERROR - 2020-02-02 19:18:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 59
DEBUG - 2020-02-02 19:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:18:47 --> Hooks Class Initialized
ERROR - 2020-02-02 19:18:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-02-02 19:18:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-02 19:18:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:47 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:47 --> Final output sent to browser
DEBUG - 2020-02-02 19:18:47 --> Total execution time: 0.6058
INFO - 2020-02-02 19:18:47 --> URI Class Initialized
INFO - 2020-02-02 19:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:18:47 --> Router Class Initialized
INFO - 2020-02-02 19:18:47 --> Controller Class Initialized
INFO - 2020-02-02 19:18:47 --> Output Class Initialized
INFO - 2020-02-02 19:18:47 --> Model "M_login" initialized
INFO - 2020-02-02 19:18:47 --> Security Class Initialized
INFO - 2020-02-02 19:18:47 --> Model "M_tiket" initialized
DEBUG - 2020-02-02 19:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:47 --> Input Class Initialized
INFO - 2020-02-02 19:18:47 --> Helper loaded: form_helper
INFO - 2020-02-02 19:18:47 --> Form Validation Class Initialized
INFO - 2020-02-02 19:18:47 --> Language Class Initialized
ERROR - 2020-02-02 19:18:47 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:18:47 --> Config Class Initialized
INFO - 2020-02-02 19:18:47 --> Hooks Class Initialized
INFO - 2020-02-02 19:18:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\component/menu.php
ERROR - 2020-02-02 19:18:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-02 19:18:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:47 --> Utf8 Class Initialized
ERROR - 2020-02-02 19:18:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-02-02 19:18:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-02-02 19:18:47 --> URI Class Initialized
INFO - 2020-02-02 19:18:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:18:48 --> Router Class Initialized
INFO - 2020-02-02 19:18:48 --> Final output sent to browser
INFO - 2020-02-02 19:18:48 --> Output Class Initialized
DEBUG - 2020-02-02 19:18:48 --> Total execution time: 0.6983
INFO - 2020-02-02 19:18:48 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:48 --> Input Class Initialized
INFO - 2020-02-02 19:18:48 --> Language Class Initialized
ERROR - 2020-02-02 19:18:48 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:18:48 --> Config Class Initialized
INFO - 2020-02-02 19:18:48 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:18:48 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:48 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:48 --> URI Class Initialized
INFO - 2020-02-02 19:18:48 --> Router Class Initialized
INFO - 2020-02-02 19:18:48 --> Output Class Initialized
INFO - 2020-02-02 19:18:48 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:48 --> Input Class Initialized
INFO - 2020-02-02 19:18:48 --> Language Class Initialized
ERROR - 2020-02-02 19:18:48 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:18:48 --> Config Class Initialized
INFO - 2020-02-02 19:18:48 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:18:48 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:48 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:48 --> URI Class Initialized
INFO - 2020-02-02 19:18:48 --> Router Class Initialized
INFO - 2020-02-02 19:18:48 --> Output Class Initialized
INFO - 2020-02-02 19:18:48 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:48 --> Input Class Initialized
INFO - 2020-02-02 19:18:48 --> Language Class Initialized
ERROR - 2020-02-02 19:18:48 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:18:48 --> Config Class Initialized
INFO - 2020-02-02 19:18:48 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:18:48 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:48 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:48 --> URI Class Initialized
INFO - 2020-02-02 19:18:48 --> Router Class Initialized
INFO - 2020-02-02 19:18:48 --> Output Class Initialized
INFO - 2020-02-02 19:18:48 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:48 --> Input Class Initialized
INFO - 2020-02-02 19:18:48 --> Language Class Initialized
ERROR - 2020-02-02 19:18:48 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:18:49 --> Config Class Initialized
INFO - 2020-02-02 19:18:49 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:18:49 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:49 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:49 --> URI Class Initialized
INFO - 2020-02-02 19:18:49 --> Router Class Initialized
INFO - 2020-02-02 19:18:49 --> Output Class Initialized
INFO - 2020-02-02 19:18:49 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:49 --> Input Class Initialized
INFO - 2020-02-02 19:18:49 --> Language Class Initialized
ERROR - 2020-02-02 19:18:49 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:18:49 --> Config Class Initialized
INFO - 2020-02-02 19:18:49 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:18:49 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:49 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:49 --> URI Class Initialized
INFO - 2020-02-02 19:18:49 --> Router Class Initialized
INFO - 2020-02-02 19:18:49 --> Output Class Initialized
INFO - 2020-02-02 19:18:49 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:49 --> Input Class Initialized
INFO - 2020-02-02 19:18:49 --> Language Class Initialized
ERROR - 2020-02-02 19:18:49 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:18:49 --> Config Class Initialized
INFO - 2020-02-02 19:18:49 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:18:49 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:49 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:49 --> URI Class Initialized
INFO - 2020-02-02 19:18:49 --> Router Class Initialized
INFO - 2020-02-02 19:18:49 --> Output Class Initialized
INFO - 2020-02-02 19:18:49 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:49 --> Input Class Initialized
INFO - 2020-02-02 19:18:49 --> Language Class Initialized
ERROR - 2020-02-02 19:18:49 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:18:49 --> Config Class Initialized
INFO - 2020-02-02 19:18:49 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:18:49 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:49 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:49 --> URI Class Initialized
INFO - 2020-02-02 19:18:49 --> Router Class Initialized
INFO - 2020-02-02 19:18:50 --> Output Class Initialized
INFO - 2020-02-02 19:18:50 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:50 --> Input Class Initialized
INFO - 2020-02-02 19:18:50 --> Language Class Initialized
ERROR - 2020-02-02 19:18:50 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:18:50 --> Config Class Initialized
INFO - 2020-02-02 19:18:50 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:18:50 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:18:50 --> Utf8 Class Initialized
INFO - 2020-02-02 19:18:50 --> URI Class Initialized
INFO - 2020-02-02 19:18:50 --> Router Class Initialized
INFO - 2020-02-02 19:18:50 --> Output Class Initialized
INFO - 2020-02-02 19:18:50 --> Security Class Initialized
DEBUG - 2020-02-02 19:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:18:50 --> Input Class Initialized
INFO - 2020-02-02 19:18:50 --> Language Class Initialized
ERROR - 2020-02-02 19:18:50 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:20:34 --> Config Class Initialized
INFO - 2020-02-02 19:20:34 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:34 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:34 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:34 --> URI Class Initialized
INFO - 2020-02-02 19:20:34 --> Router Class Initialized
INFO - 2020-02-02 19:20:34 --> Output Class Initialized
INFO - 2020-02-02 19:20:34 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:34 --> Input Class Initialized
INFO - 2020-02-02 19:20:34 --> Language Class Initialized
INFO - 2020-02-02 19:20:34 --> Loader Class Initialized
INFO - 2020-02-02 19:20:35 --> Helper loaded: url_helper
INFO - 2020-02-02 19:20:35 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:20:35 --> Controller Class Initialized
INFO - 2020-02-02 19:20:35 --> Model "M_login" initialized
INFO - 2020-02-02 19:20:35 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:20:35 --> Helper loaded: form_helper
INFO - 2020-02-02 19:20:35 --> Form Validation Class Initialized
INFO - 2020-02-02 19:20:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:20:35 --> Final output sent to browser
DEBUG - 2020-02-02 19:20:35 --> Total execution time: 1.3948
INFO - 2020-02-02 19:20:35 --> Config Class Initialized
INFO - 2020-02-02 19:20:35 --> Config Class Initialized
INFO - 2020-02-02 19:20:35 --> Config Class Initialized
INFO - 2020-02-02 19:20:35 --> Config Class Initialized
INFO - 2020-02-02 19:20:35 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:35 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:35 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:35 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:35 --> Config Class Initialized
INFO - 2020-02-02 19:20:35 --> Config Class Initialized
INFO - 2020-02-02 19:20:35 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:35 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:35 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:35 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:35 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:35 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:35 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:20:35 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:35 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:20:35 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:35 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:35 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:35 --> URI Class Initialized
INFO - 2020-02-02 19:20:35 --> URI Class Initialized
INFO - 2020-02-02 19:20:35 --> URI Class Initialized
INFO - 2020-02-02 19:20:35 --> URI Class Initialized
INFO - 2020-02-02 19:20:35 --> Router Class Initialized
INFO - 2020-02-02 19:20:35 --> Router Class Initialized
INFO - 2020-02-02 19:20:35 --> Router Class Initialized
INFO - 2020-02-02 19:20:35 --> URI Class Initialized
INFO - 2020-02-02 19:20:35 --> Router Class Initialized
INFO - 2020-02-02 19:20:35 --> URI Class Initialized
INFO - 2020-02-02 19:20:35 --> Router Class Initialized
INFO - 2020-02-02 19:20:35 --> Output Class Initialized
INFO - 2020-02-02 19:20:35 --> Output Class Initialized
INFO - 2020-02-02 19:20:35 --> Output Class Initialized
INFO - 2020-02-02 19:20:35 --> Router Class Initialized
INFO - 2020-02-02 19:20:35 --> Output Class Initialized
INFO - 2020-02-02 19:20:35 --> Output Class Initialized
INFO - 2020-02-02 19:20:35 --> Output Class Initialized
INFO - 2020-02-02 19:20:35 --> Security Class Initialized
INFO - 2020-02-02 19:20:35 --> Security Class Initialized
INFO - 2020-02-02 19:20:35 --> Security Class Initialized
INFO - 2020-02-02 19:20:35 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:35 --> Security Class Initialized
INFO - 2020-02-02 19:20:35 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:35 --> Input Class Initialized
INFO - 2020-02-02 19:20:35 --> Input Class Initialized
INFO - 2020-02-02 19:20:35 --> Input Class Initialized
INFO - 2020-02-02 19:20:35 --> Input Class Initialized
DEBUG - 2020-02-02 19:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:36 --> Input Class Initialized
INFO - 2020-02-02 19:20:36 --> Input Class Initialized
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
ERROR - 2020-02-02 19:20:36 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-02 19:20:36 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-02 19:20:36 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 19:20:36 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-02 19:20:36 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-02 19:20:36 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:20:36 --> Config Class Initialized
INFO - 2020-02-02 19:20:36 --> Config Class Initialized
INFO - 2020-02-02 19:20:36 --> Config Class Initialized
INFO - 2020-02-02 19:20:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:36 --> Config Class Initialized
INFO - 2020-02-02 19:20:36 --> Config Class Initialized
INFO - 2020-02-02 19:20:36 --> Config Class Initialized
INFO - 2020-02-02 19:20:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:36 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:36 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:36 --> URI Class Initialized
INFO - 2020-02-02 19:20:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:36 --> URI Class Initialized
INFO - 2020-02-02 19:20:36 --> URI Class Initialized
INFO - 2020-02-02 19:20:36 --> URI Class Initialized
INFO - 2020-02-02 19:20:36 --> URI Class Initialized
INFO - 2020-02-02 19:20:36 --> Router Class Initialized
INFO - 2020-02-02 19:20:36 --> Router Class Initialized
INFO - 2020-02-02 19:20:36 --> Router Class Initialized
INFO - 2020-02-02 19:20:36 --> URI Class Initialized
INFO - 2020-02-02 19:20:36 --> Router Class Initialized
INFO - 2020-02-02 19:20:36 --> Router Class Initialized
INFO - 2020-02-02 19:20:36 --> Output Class Initialized
INFO - 2020-02-02 19:20:36 --> Output Class Initialized
INFO - 2020-02-02 19:20:36 --> Router Class Initialized
INFO - 2020-02-02 19:20:36 --> Output Class Initialized
INFO - 2020-02-02 19:20:36 --> Security Class Initialized
INFO - 2020-02-02 19:20:36 --> Output Class Initialized
INFO - 2020-02-02 19:20:36 --> Output Class Initialized
INFO - 2020-02-02 19:20:36 --> Output Class Initialized
INFO - 2020-02-02 19:20:36 --> Security Class Initialized
INFO - 2020-02-02 19:20:36 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:36 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:36 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:36 --> Security Class Initialized
INFO - 2020-02-02 19:20:36 --> Input Class Initialized
INFO - 2020-02-02 19:20:36 --> Input Class Initialized
DEBUG - 2020-02-02 19:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:36 --> Input Class Initialized
DEBUG - 2020-02-02 19:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:36 --> Input Class Initialized
INFO - 2020-02-02 19:20:36 --> Input Class Initialized
INFO - 2020-02-02 19:20:36 --> Input Class Initialized
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
ERROR - 2020-02-02 19:20:36 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
ERROR - 2020-02-02 19:20:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:20:36 --> Loader Class Initialized
ERROR - 2020-02-02 19:20:36 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-02 19:20:36 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:20:36 --> Helper loaded: url_helper
ERROR - 2020-02-02 19:20:36 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:20:36 --> Config Class Initialized
INFO - 2020-02-02 19:20:36 --> Config Class Initialized
INFO - 2020-02-02 19:20:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:36 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:20:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:20:36 --> Controller Class Initialized
INFO - 2020-02-02 19:20:36 --> URI Class Initialized
INFO - 2020-02-02 19:20:36 --> URI Class Initialized
INFO - 2020-02-02 19:20:36 --> Model "M_login" initialized
INFO - 2020-02-02 19:20:36 --> Router Class Initialized
INFO - 2020-02-02 19:20:36 --> Router Class Initialized
INFO - 2020-02-02 19:20:36 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:20:36 --> Output Class Initialized
INFO - 2020-02-02 19:20:36 --> Output Class Initialized
INFO - 2020-02-02 19:20:36 --> Security Class Initialized
INFO - 2020-02-02 19:20:36 --> Security Class Initialized
INFO - 2020-02-02 19:20:36 --> Helper loaded: form_helper
INFO - 2020-02-02 19:20:36 --> Form Validation Class Initialized
DEBUG - 2020-02-02 19:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:36 --> Input Class Initialized
INFO - 2020-02-02 19:20:36 --> Input Class Initialized
ERROR - 2020-02-02 19:20:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
ERROR - 2020-02-02 19:20:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
ERROR - 2020-02-02 19:20:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-02-02 19:20:36 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:20:36 --> Loader Class Initialized
INFO - 2020-02-02 19:20:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:20:36 --> Helper loaded: url_helper
INFO - 2020-02-02 19:20:36 --> Final output sent to browser
INFO - 2020-02-02 19:20:36 --> Config Class Initialized
INFO - 2020-02-02 19:20:36 --> Database Driver Class Initialized
INFO - 2020-02-02 19:20:36 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:36 --> Total execution time: 0.6078
DEBUG - 2020-02-02 19:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:20:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-02 19:20:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:36 --> Controller Class Initialized
INFO - 2020-02-02 19:20:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:36 --> Model "M_login" initialized
INFO - 2020-02-02 19:20:36 --> URI Class Initialized
INFO - 2020-02-02 19:20:36 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:20:36 --> Router Class Initialized
INFO - 2020-02-02 19:20:36 --> Output Class Initialized
INFO - 2020-02-02 19:20:36 --> Helper loaded: form_helper
INFO - 2020-02-02 19:20:36 --> Form Validation Class Initialized
INFO - 2020-02-02 19:20:36 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 19:20:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:20:36 --> Input Class Initialized
ERROR - 2020-02-02 19:20:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-02 19:20:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2020-02-02 19:20:36 --> Language Class Initialized
INFO - 2020-02-02 19:20:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-02 19:20:36 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:20:36 --> Final output sent to browser
DEBUG - 2020-02-02 19:20:36 --> Total execution time: 0.5283
INFO - 2020-02-02 19:20:36 --> Config Class Initialized
INFO - 2020-02-02 19:20:36 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:37 --> URI Class Initialized
INFO - 2020-02-02 19:20:37 --> Router Class Initialized
INFO - 2020-02-02 19:20:37 --> Output Class Initialized
INFO - 2020-02-02 19:20:37 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:37 --> Input Class Initialized
INFO - 2020-02-02 19:20:37 --> Language Class Initialized
ERROR - 2020-02-02 19:20:37 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:20:37 --> Config Class Initialized
INFO - 2020-02-02 19:20:37 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:37 --> URI Class Initialized
INFO - 2020-02-02 19:20:37 --> Router Class Initialized
INFO - 2020-02-02 19:20:37 --> Output Class Initialized
INFO - 2020-02-02 19:20:37 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:37 --> Input Class Initialized
INFO - 2020-02-02 19:20:37 --> Language Class Initialized
ERROR - 2020-02-02 19:20:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:20:37 --> Config Class Initialized
INFO - 2020-02-02 19:20:37 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:37 --> URI Class Initialized
INFO - 2020-02-02 19:20:37 --> Router Class Initialized
INFO - 2020-02-02 19:20:37 --> Output Class Initialized
INFO - 2020-02-02 19:20:37 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:37 --> Input Class Initialized
INFO - 2020-02-02 19:20:37 --> Language Class Initialized
ERROR - 2020-02-02 19:20:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:20:37 --> Config Class Initialized
INFO - 2020-02-02 19:20:37 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:37 --> URI Class Initialized
INFO - 2020-02-02 19:20:37 --> Router Class Initialized
INFO - 2020-02-02 19:20:37 --> Output Class Initialized
INFO - 2020-02-02 19:20:37 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:37 --> Input Class Initialized
INFO - 2020-02-02 19:20:37 --> Language Class Initialized
ERROR - 2020-02-02 19:20:37 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:20:38 --> Config Class Initialized
INFO - 2020-02-02 19:20:38 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:38 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:38 --> URI Class Initialized
INFO - 2020-02-02 19:20:38 --> Router Class Initialized
INFO - 2020-02-02 19:20:38 --> Output Class Initialized
INFO - 2020-02-02 19:20:38 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:38 --> Input Class Initialized
INFO - 2020-02-02 19:20:38 --> Language Class Initialized
ERROR - 2020-02-02 19:20:38 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:20:38 --> Config Class Initialized
INFO - 2020-02-02 19:20:38 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:38 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:38 --> URI Class Initialized
INFO - 2020-02-02 19:20:38 --> Router Class Initialized
INFO - 2020-02-02 19:20:38 --> Output Class Initialized
INFO - 2020-02-02 19:20:38 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:38 --> Input Class Initialized
INFO - 2020-02-02 19:20:38 --> Language Class Initialized
ERROR - 2020-02-02 19:20:38 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:20:38 --> Config Class Initialized
INFO - 2020-02-02 19:20:38 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:38 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:38 --> URI Class Initialized
INFO - 2020-02-02 19:20:38 --> Router Class Initialized
INFO - 2020-02-02 19:20:38 --> Output Class Initialized
INFO - 2020-02-02 19:20:38 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:38 --> Input Class Initialized
INFO - 2020-02-02 19:20:38 --> Language Class Initialized
ERROR - 2020-02-02 19:20:38 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:20:56 --> Config Class Initialized
INFO - 2020-02-02 19:20:56 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:56 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:56 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:56 --> URI Class Initialized
INFO - 2020-02-02 19:20:57 --> Router Class Initialized
INFO - 2020-02-02 19:20:57 --> Output Class Initialized
INFO - 2020-02-02 19:20:57 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:57 --> Input Class Initialized
INFO - 2020-02-02 19:20:57 --> Language Class Initialized
INFO - 2020-02-02 19:20:57 --> Loader Class Initialized
INFO - 2020-02-02 19:20:57 --> Helper loaded: url_helper
INFO - 2020-02-02 19:20:57 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:20:57 --> Controller Class Initialized
INFO - 2020-02-02 19:20:57 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:20:57 --> Helper loaded: form_helper
INFO - 2020-02-02 19:20:57 --> Form Validation Class Initialized
INFO - 2020-02-02 19:20:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:20:57 --> Final output sent to browser
DEBUG - 2020-02-02 19:20:57 --> Total execution time: 0.8283
INFO - 2020-02-02 19:20:57 --> Config Class Initialized
INFO - 2020-02-02 19:20:57 --> Config Class Initialized
INFO - 2020-02-02 19:20:57 --> Config Class Initialized
INFO - 2020-02-02 19:20:57 --> Config Class Initialized
INFO - 2020-02-02 19:20:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:57 --> Config Class Initialized
INFO - 2020-02-02 19:20:57 --> Config Class Initialized
INFO - 2020-02-02 19:20:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:57 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:57 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:57 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:20:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:57 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:57 --> URI Class Initialized
INFO - 2020-02-02 19:20:57 --> URI Class Initialized
INFO - 2020-02-02 19:20:57 --> URI Class Initialized
INFO - 2020-02-02 19:20:57 --> URI Class Initialized
INFO - 2020-02-02 19:20:57 --> URI Class Initialized
INFO - 2020-02-02 19:20:57 --> Router Class Initialized
INFO - 2020-02-02 19:20:57 --> Router Class Initialized
INFO - 2020-02-02 19:20:57 --> Router Class Initialized
INFO - 2020-02-02 19:20:57 --> Router Class Initialized
INFO - 2020-02-02 19:20:57 --> URI Class Initialized
INFO - 2020-02-02 19:20:57 --> Router Class Initialized
INFO - 2020-02-02 19:20:57 --> Output Class Initialized
INFO - 2020-02-02 19:20:57 --> Router Class Initialized
INFO - 2020-02-02 19:20:57 --> Output Class Initialized
INFO - 2020-02-02 19:20:57 --> Output Class Initialized
INFO - 2020-02-02 19:20:57 --> Output Class Initialized
INFO - 2020-02-02 19:20:57 --> Security Class Initialized
INFO - 2020-02-02 19:20:57 --> Security Class Initialized
INFO - 2020-02-02 19:20:57 --> Security Class Initialized
INFO - 2020-02-02 19:20:57 --> Output Class Initialized
INFO - 2020-02-02 19:20:57 --> Security Class Initialized
INFO - 2020-02-02 19:20:57 --> Output Class Initialized
DEBUG - 2020-02-02 19:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:57 --> Security Class Initialized
INFO - 2020-02-02 19:20:57 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:57 --> Input Class Initialized
INFO - 2020-02-02 19:20:57 --> Input Class Initialized
INFO - 2020-02-02 19:20:57 --> Input Class Initialized
INFO - 2020-02-02 19:20:57 --> Input Class Initialized
DEBUG - 2020-02-02 19:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:57 --> Input Class Initialized
INFO - 2020-02-02 19:20:57 --> Language Class Initialized
INFO - 2020-02-02 19:20:57 --> Language Class Initialized
INFO - 2020-02-02 19:20:57 --> Language Class Initialized
INFO - 2020-02-02 19:20:57 --> Input Class Initialized
INFO - 2020-02-02 19:20:57 --> Language Class Initialized
INFO - 2020-02-02 19:20:57 --> Language Class Initialized
INFO - 2020-02-02 19:20:57 --> Language Class Initialized
ERROR - 2020-02-02 19:20:57 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:20:57 --> Loader Class Initialized
ERROR - 2020-02-02 19:20:57 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-02 19:20:57 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 19:20:57 --> Helper loaded: url_helper
ERROR - 2020-02-02 19:20:57 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:20:57 --> Config Class Initialized
INFO - 2020-02-02 19:20:57 --> Loader Class Initialized
INFO - 2020-02-02 19:20:57 --> Config Class Initialized
INFO - 2020-02-02 19:20:57 --> Config Class Initialized
INFO - 2020-02-02 19:20:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:57 --> Helper loaded: url_helper
INFO - 2020-02-02 19:20:57 --> Database Driver Class Initialized
INFO - 2020-02-02 19:20:57 --> Config Class Initialized
DEBUG - 2020-02-02 19:20:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:57 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:57 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:20:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:20:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:20:57 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:20:57 --> Controller Class Initialized
INFO - 2020-02-02 19:20:57 --> URI Class Initialized
INFO - 2020-02-02 19:20:57 --> URI Class Initialized
INFO - 2020-02-02 19:20:57 --> URI Class Initialized
DEBUG - 2020-02-02 19:20:57 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:58 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:58 --> Router Class Initialized
INFO - 2020-02-02 19:20:58 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:20:58 --> Router Class Initialized
INFO - 2020-02-02 19:20:58 --> Router Class Initialized
INFO - 2020-02-02 19:20:58 --> URI Class Initialized
INFO - 2020-02-02 19:20:58 --> Output Class Initialized
INFO - 2020-02-02 19:20:58 --> Output Class Initialized
INFO - 2020-02-02 19:20:58 --> Helper loaded: form_helper
INFO - 2020-02-02 19:20:58 --> Output Class Initialized
INFO - 2020-02-02 19:20:58 --> Form Validation Class Initialized
INFO - 2020-02-02 19:20:58 --> Security Class Initialized
INFO - 2020-02-02 19:20:58 --> Security Class Initialized
INFO - 2020-02-02 19:20:58 --> Router Class Initialized
INFO - 2020-02-02 19:20:58 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:58 --> Output Class Initialized
DEBUG - 2020-02-02 19:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 19:20:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:20:58 --> Input Class Initialized
INFO - 2020-02-02 19:20:58 --> Input Class Initialized
INFO - 2020-02-02 19:20:58 --> Input Class Initialized
ERROR - 2020-02-02 19:20:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:20:58 --> Security Class Initialized
ERROR - 2020-02-02 19:20:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2020-02-02 19:20:58 --> Language Class Initialized
INFO - 2020-02-02 19:20:58 --> Language Class Initialized
DEBUG - 2020-02-02 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:58 --> Language Class Initialized
INFO - 2020-02-02 19:20:58 --> Input Class Initialized
INFO - 2020-02-02 19:20:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-02 19:20:58 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 19:20:58 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 19:20:58 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:20:58 --> Final output sent to browser
INFO - 2020-02-02 19:20:58 --> Language Class Initialized
INFO - 2020-02-02 19:20:58 --> Config Class Initialized
INFO - 2020-02-02 19:20:58 --> Config Class Initialized
INFO - 2020-02-02 19:20:58 --> Config Class Initialized
INFO - 2020-02-02 19:20:58 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:58 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:58 --> Total execution time: 0.6059
ERROR - 2020-02-02 19:20:58 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:20:58 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-02 19:20:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:20:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:58 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:58 --> Controller Class Initialized
INFO - 2020-02-02 19:20:58 --> Config Class Initialized
INFO - 2020-02-02 19:20:58 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:20:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:58 --> Hooks Class Initialized
INFO - 2020-02-02 19:20:58 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:58 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:20:58 --> URI Class Initialized
INFO - 2020-02-02 19:20:58 --> URI Class Initialized
INFO - 2020-02-02 19:20:58 --> URI Class Initialized
INFO - 2020-02-02 19:20:58 --> Router Class Initialized
DEBUG - 2020-02-02 19:20:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:58 --> Router Class Initialized
INFO - 2020-02-02 19:20:58 --> Helper loaded: form_helper
INFO - 2020-02-02 19:20:58 --> Form Validation Class Initialized
INFO - 2020-02-02 19:20:58 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:58 --> Router Class Initialized
INFO - 2020-02-02 19:20:58 --> Output Class Initialized
INFO - 2020-02-02 19:20:58 --> Output Class Initialized
INFO - 2020-02-02 19:20:58 --> URI Class Initialized
INFO - 2020-02-02 19:20:58 --> Security Class Initialized
INFO - 2020-02-02 19:20:58 --> Output Class Initialized
ERROR - 2020-02-02 19:20:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:20:58 --> Security Class Initialized
ERROR - 2020-02-02 19:20:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-02 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:58 --> Router Class Initialized
INFO - 2020-02-02 19:20:58 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:58 --> Input Class Initialized
INFO - 2020-02-02 19:20:58 --> Input Class Initialized
ERROR - 2020-02-02 19:20:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 59
DEBUG - 2020-02-02 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:58 --> Output Class Initialized
INFO - 2020-02-02 19:20:58 --> Input Class Initialized
INFO - 2020-02-02 19:20:58 --> Language Class Initialized
INFO - 2020-02-02 19:20:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:20:58 --> Language Class Initialized
INFO - 2020-02-02 19:20:58 --> Security Class Initialized
INFO - 2020-02-02 19:20:58 --> Final output sent to browser
INFO - 2020-02-02 19:20:58 --> Language Class Initialized
ERROR - 2020-02-02 19:20:58 --> 404 Page Not Found: Bower_components/jquery-i18next
DEBUG - 2020-02-02 19:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 19:20:58 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-02 19:20:58 --> Total execution time: 0.8502
INFO - 2020-02-02 19:20:58 --> Input Class Initialized
ERROR - 2020-02-02 19:20:58 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:20:58 --> Language Class Initialized
ERROR - 2020-02-02 19:20:58 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:20:58 --> Config Class Initialized
INFO - 2020-02-02 19:20:58 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:58 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:58 --> URI Class Initialized
INFO - 2020-02-02 19:20:58 --> Router Class Initialized
INFO - 2020-02-02 19:20:58 --> Output Class Initialized
INFO - 2020-02-02 19:20:58 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:58 --> Input Class Initialized
INFO - 2020-02-02 19:20:58 --> Language Class Initialized
ERROR - 2020-02-02 19:20:58 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:20:58 --> Config Class Initialized
INFO - 2020-02-02 19:20:58 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:58 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:58 --> URI Class Initialized
INFO - 2020-02-02 19:20:58 --> Router Class Initialized
INFO - 2020-02-02 19:20:58 --> Output Class Initialized
INFO - 2020-02-02 19:20:58 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:59 --> Input Class Initialized
INFO - 2020-02-02 19:20:59 --> Language Class Initialized
ERROR - 2020-02-02 19:20:59 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:20:59 --> Config Class Initialized
INFO - 2020-02-02 19:20:59 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:59 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:59 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:59 --> URI Class Initialized
INFO - 2020-02-02 19:20:59 --> Router Class Initialized
INFO - 2020-02-02 19:20:59 --> Output Class Initialized
INFO - 2020-02-02 19:20:59 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:59 --> Input Class Initialized
INFO - 2020-02-02 19:20:59 --> Language Class Initialized
ERROR - 2020-02-02 19:20:59 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:20:59 --> Config Class Initialized
INFO - 2020-02-02 19:20:59 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:59 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:59 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:59 --> URI Class Initialized
INFO - 2020-02-02 19:20:59 --> Router Class Initialized
INFO - 2020-02-02 19:20:59 --> Output Class Initialized
INFO - 2020-02-02 19:20:59 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:59 --> Input Class Initialized
INFO - 2020-02-02 19:20:59 --> Language Class Initialized
ERROR - 2020-02-02 19:20:59 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:20:59 --> Config Class Initialized
INFO - 2020-02-02 19:20:59 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:59 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:59 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:59 --> URI Class Initialized
INFO - 2020-02-02 19:20:59 --> Router Class Initialized
INFO - 2020-02-02 19:20:59 --> Output Class Initialized
INFO - 2020-02-02 19:20:59 --> Security Class Initialized
DEBUG - 2020-02-02 19:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:20:59 --> Input Class Initialized
INFO - 2020-02-02 19:20:59 --> Language Class Initialized
ERROR - 2020-02-02 19:20:59 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:20:59 --> Config Class Initialized
INFO - 2020-02-02 19:20:59 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:20:59 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:20:59 --> Utf8 Class Initialized
INFO - 2020-02-02 19:20:59 --> URI Class Initialized
INFO - 2020-02-02 19:21:00 --> Router Class Initialized
INFO - 2020-02-02 19:21:00 --> Output Class Initialized
INFO - 2020-02-02 19:21:00 --> Security Class Initialized
DEBUG - 2020-02-02 19:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:21:00 --> Input Class Initialized
INFO - 2020-02-02 19:21:00 --> Language Class Initialized
ERROR - 2020-02-02 19:21:00 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:21:00 --> Config Class Initialized
INFO - 2020-02-02 19:21:00 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:21:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:21:00 --> Utf8 Class Initialized
INFO - 2020-02-02 19:21:00 --> URI Class Initialized
INFO - 2020-02-02 19:21:00 --> Router Class Initialized
INFO - 2020-02-02 19:21:00 --> Output Class Initialized
INFO - 2020-02-02 19:21:00 --> Security Class Initialized
DEBUG - 2020-02-02 19:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:21:00 --> Input Class Initialized
INFO - 2020-02-02 19:21:00 --> Language Class Initialized
ERROR - 2020-02-02 19:21:00 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:21:00 --> Config Class Initialized
INFO - 2020-02-02 19:21:00 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:21:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:21:00 --> Utf8 Class Initialized
INFO - 2020-02-02 19:21:00 --> URI Class Initialized
INFO - 2020-02-02 19:21:00 --> Router Class Initialized
INFO - 2020-02-02 19:21:00 --> Output Class Initialized
INFO - 2020-02-02 19:21:00 --> Security Class Initialized
DEBUG - 2020-02-02 19:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:21:00 --> Input Class Initialized
INFO - 2020-02-02 19:21:00 --> Language Class Initialized
ERROR - 2020-02-02 19:21:00 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:21:00 --> Config Class Initialized
INFO - 2020-02-02 19:21:00 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:21:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:21:00 --> Utf8 Class Initialized
INFO - 2020-02-02 19:21:00 --> URI Class Initialized
INFO - 2020-02-02 19:21:00 --> Router Class Initialized
INFO - 2020-02-02 19:21:00 --> Output Class Initialized
INFO - 2020-02-02 19:21:00 --> Security Class Initialized
DEBUG - 2020-02-02 19:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:21:00 --> Input Class Initialized
INFO - 2020-02-02 19:21:00 --> Language Class Initialized
ERROR - 2020-02-02 19:21:00 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:22:02 --> Config Class Initialized
INFO - 2020-02-02 19:22:02 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:22:03 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:03 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:03 --> URI Class Initialized
INFO - 2020-02-02 19:22:03 --> Router Class Initialized
INFO - 2020-02-02 19:22:03 --> Output Class Initialized
INFO - 2020-02-02 19:22:03 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:03 --> Input Class Initialized
INFO - 2020-02-02 19:22:03 --> Language Class Initialized
INFO - 2020-02-02 19:22:03 --> Loader Class Initialized
INFO - 2020-02-02 19:22:03 --> Helper loaded: url_helper
INFO - 2020-02-02 19:22:03 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:22:03 --> Controller Class Initialized
INFO - 2020-02-02 19:22:03 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:22:03 --> Helper loaded: form_helper
INFO - 2020-02-02 19:22:03 --> Form Validation Class Initialized
INFO - 2020-02-02 19:22:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:22:03 --> Final output sent to browser
DEBUG - 2020-02-02 19:22:03 --> Total execution time: 0.9925
INFO - 2020-02-02 19:22:03 --> Config Class Initialized
INFO - 2020-02-02 19:22:03 --> Config Class Initialized
INFO - 2020-02-02 19:22:03 --> Config Class Initialized
INFO - 2020-02-02 19:22:03 --> Config Class Initialized
INFO - 2020-02-02 19:22:03 --> Hooks Class Initialized
INFO - 2020-02-02 19:22:03 --> Hooks Class Initialized
INFO - 2020-02-02 19:22:03 --> Hooks Class Initialized
INFO - 2020-02-02 19:22:03 --> Hooks Class Initialized
INFO - 2020-02-02 19:22:04 --> Config Class Initialized
INFO - 2020-02-02 19:22:04 --> Config Class Initialized
INFO - 2020-02-02 19:22:04 --> Hooks Class Initialized
INFO - 2020-02-02 19:22:04 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
ERROR - 2020-02-02 19:22:04 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-02 19:22:04 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 19:22:04 --> Loader Class Initialized
INFO - 2020-02-02 19:22:04 --> Loader Class Initialized
ERROR - 2020-02-02 19:22:04 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-02 19:22:04 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:22:04 --> Helper loaded: url_helper
INFO - 2020-02-02 19:22:04 --> Helper loaded: url_helper
INFO - 2020-02-02 19:22:04 --> Config Class Initialized
INFO - 2020-02-02 19:22:04 --> Config Class Initialized
INFO - 2020-02-02 19:22:04 --> Hooks Class Initialized
INFO - 2020-02-02 19:22:04 --> Hooks Class Initialized
INFO - 2020-02-02 19:22:04 --> Database Driver Class Initialized
INFO - 2020-02-02 19:22:04 --> Database Driver Class Initialized
INFO - 2020-02-02 19:22:04 --> Config Class Initialized
INFO - 2020-02-02 19:22:04 --> Config Class Initialized
INFO - 2020-02-02 19:22:04 --> Hooks Class Initialized
INFO - 2020-02-02 19:22:04 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-02 19:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:04 --> Controller Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
INFO - 2020-02-02 19:22:04 --> Helper loaded: form_helper
INFO - 2020-02-02 19:22:04 --> Form Validation Class Initialized
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
ERROR - 2020-02-02 19:22:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
ERROR - 2020-02-02 19:22:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
INFO - 2020-02-02 19:22:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
INFO - 2020-02-02 19:22:04 --> Final output sent to browser
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
ERROR - 2020-02-02 19:22:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
ERROR - 2020-02-02 19:22:04 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-02 19:22:04 --> Total execution time: 0.6369
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
ERROR - 2020-02-02 19:22:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:22:04 --> Config Class Initialized
INFO - 2020-02-02 19:22:04 --> Config Class Initialized
INFO - 2020-02-02 19:22:04 --> Hooks Class Initialized
INFO - 2020-02-02 19:22:04 --> Hooks Class Initialized
INFO - 2020-02-02 19:22:04 --> Session: Class initialized using 'files' driver.
ERROR - 2020-02-02 19:22:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:22:04 --> Config Class Initialized
INFO - 2020-02-02 19:22:04 --> Config Class Initialized
INFO - 2020-02-02 19:22:04 --> Hooks Class Initialized
INFO - 2020-02-02 19:22:04 --> Controller Class Initialized
INFO - 2020-02-02 19:22:04 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:04 --> Model "M_tiket" initialized
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:22:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:04 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> Helper loaded: form_helper
INFO - 2020-02-02 19:22:04 --> Form Validation Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> URI Class Initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
INFO - 2020-02-02 19:22:04 --> Router Class Initialized
ERROR - 2020-02-02 19:22:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
ERROR - 2020-02-02 19:22:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
INFO - 2020-02-02 19:22:04 --> Output Class Initialized
INFO - 2020-02-02 19:22:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
INFO - 2020-02-02 19:22:04 --> Security Class Initialized
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
INFO - 2020-02-02 19:22:04 --> Final output sent to browser
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
INFO - 2020-02-02 19:22:04 --> Input Class Initialized
DEBUG - 2020-02-02 19:22:04 --> Total execution time: 0.9580
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
ERROR - 2020-02-02 19:22:04 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
INFO - 2020-02-02 19:22:04 --> Language Class Initialized
ERROR - 2020-02-02 19:22:05 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-02 19:22:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-02 19:22:05 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:22:05 --> Config Class Initialized
INFO - 2020-02-02 19:22:05 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:22:05 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:05 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:05 --> URI Class Initialized
INFO - 2020-02-02 19:22:05 --> Router Class Initialized
INFO - 2020-02-02 19:22:05 --> Output Class Initialized
INFO - 2020-02-02 19:22:05 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:05 --> Input Class Initialized
INFO - 2020-02-02 19:22:05 --> Language Class Initialized
ERROR - 2020-02-02 19:22:05 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:22:05 --> Config Class Initialized
INFO - 2020-02-02 19:22:05 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:22:05 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:05 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:05 --> URI Class Initialized
INFO - 2020-02-02 19:22:05 --> Router Class Initialized
INFO - 2020-02-02 19:22:05 --> Output Class Initialized
INFO - 2020-02-02 19:22:05 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:05 --> Input Class Initialized
INFO - 2020-02-02 19:22:05 --> Language Class Initialized
ERROR - 2020-02-02 19:22:05 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:22:05 --> Config Class Initialized
INFO - 2020-02-02 19:22:05 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:22:05 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:05 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:05 --> URI Class Initialized
INFO - 2020-02-02 19:22:05 --> Router Class Initialized
INFO - 2020-02-02 19:22:05 --> Output Class Initialized
INFO - 2020-02-02 19:22:05 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:05 --> Input Class Initialized
INFO - 2020-02-02 19:22:06 --> Language Class Initialized
ERROR - 2020-02-02 19:22:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:22:06 --> Config Class Initialized
INFO - 2020-02-02 19:22:06 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:22:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:06 --> URI Class Initialized
INFO - 2020-02-02 19:22:06 --> Router Class Initialized
INFO - 2020-02-02 19:22:06 --> Output Class Initialized
INFO - 2020-02-02 19:22:06 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:06 --> Input Class Initialized
INFO - 2020-02-02 19:22:06 --> Language Class Initialized
ERROR - 2020-02-02 19:22:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:22:06 --> Config Class Initialized
INFO - 2020-02-02 19:22:06 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:22:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:06 --> URI Class Initialized
INFO - 2020-02-02 19:22:06 --> Router Class Initialized
INFO - 2020-02-02 19:22:06 --> Output Class Initialized
INFO - 2020-02-02 19:22:06 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:06 --> Input Class Initialized
INFO - 2020-02-02 19:22:06 --> Language Class Initialized
ERROR - 2020-02-02 19:22:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:22:06 --> Config Class Initialized
INFO - 2020-02-02 19:22:06 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:22:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:06 --> URI Class Initialized
INFO - 2020-02-02 19:22:06 --> Router Class Initialized
INFO - 2020-02-02 19:22:06 --> Output Class Initialized
INFO - 2020-02-02 19:22:06 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:06 --> Input Class Initialized
INFO - 2020-02-02 19:22:06 --> Language Class Initialized
ERROR - 2020-02-02 19:22:06 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:22:06 --> Config Class Initialized
INFO - 2020-02-02 19:22:06 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:22:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:06 --> URI Class Initialized
INFO - 2020-02-02 19:22:07 --> Router Class Initialized
INFO - 2020-02-02 19:22:07 --> Output Class Initialized
INFO - 2020-02-02 19:22:07 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:07 --> Input Class Initialized
INFO - 2020-02-02 19:22:07 --> Language Class Initialized
ERROR - 2020-02-02 19:22:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:22:07 --> Config Class Initialized
INFO - 2020-02-02 19:22:07 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:22:07 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:07 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:07 --> URI Class Initialized
INFO - 2020-02-02 19:22:07 --> Router Class Initialized
INFO - 2020-02-02 19:22:07 --> Output Class Initialized
INFO - 2020-02-02 19:22:07 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:07 --> Input Class Initialized
INFO - 2020-02-02 19:22:07 --> Language Class Initialized
ERROR - 2020-02-02 19:22:07 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:22:07 --> Config Class Initialized
INFO - 2020-02-02 19:22:07 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:22:07 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:22:07 --> Utf8 Class Initialized
INFO - 2020-02-02 19:22:07 --> URI Class Initialized
INFO - 2020-02-02 19:22:07 --> Router Class Initialized
INFO - 2020-02-02 19:22:07 --> Output Class Initialized
INFO - 2020-02-02 19:22:07 --> Security Class Initialized
DEBUG - 2020-02-02 19:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:22:07 --> Input Class Initialized
INFO - 2020-02-02 19:22:07 --> Language Class Initialized
ERROR - 2020-02-02 19:22:07 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:23:20 --> Config Class Initialized
INFO - 2020-02-02 19:23:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:20 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:20 --> URI Class Initialized
INFO - 2020-02-02 19:23:21 --> Router Class Initialized
INFO - 2020-02-02 19:23:21 --> Output Class Initialized
INFO - 2020-02-02 19:23:21 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:21 --> Input Class Initialized
INFO - 2020-02-02 19:23:21 --> Language Class Initialized
INFO - 2020-02-02 19:23:21 --> Loader Class Initialized
INFO - 2020-02-02 19:23:21 --> Helper loaded: url_helper
INFO - 2020-02-02 19:23:21 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:23:21 --> Controller Class Initialized
INFO - 2020-02-02 19:23:21 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:23:21 --> Helper loaded: form_helper
INFO - 2020-02-02 19:23:21 --> Form Validation Class Initialized
INFO - 2020-02-02 19:23:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:23:21 --> Final output sent to browser
DEBUG - 2020-02-02 19:23:21 --> Total execution time: 1.2751
INFO - 2020-02-02 19:23:21 --> Config Class Initialized
INFO - 2020-02-02 19:23:21 --> Config Class Initialized
INFO - 2020-02-02 19:23:21 --> Config Class Initialized
INFO - 2020-02-02 19:23:21 --> Config Class Initialized
INFO - 2020-02-02 19:23:21 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:21 --> Config Class Initialized
INFO - 2020-02-02 19:23:21 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:21 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:21 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:21 --> Config Class Initialized
INFO - 2020-02-02 19:23:21 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:21 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:21 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:21 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:21 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:21 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:21 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:21 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:23:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:21 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
ERROR - 2020-02-02 19:23:22 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-02 19:23:22 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
ERROR - 2020-02-02 19:23:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
ERROR - 2020-02-02 19:23:22 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-02 19:23:22 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:23:22 --> Config Class Initialized
INFO - 2020-02-02 19:23:22 --> Config Class Initialized
INFO - 2020-02-02 19:23:22 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:22 --> Hooks Class Initialized
ERROR - 2020-02-02 19:23:22 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:23:22 --> Config Class Initialized
INFO - 2020-02-02 19:23:22 --> Config Class Initialized
INFO - 2020-02-02 19:23:22 --> Config Class Initialized
INFO - 2020-02-02 19:23:22 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:22 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:22 --> Config Class Initialized
INFO - 2020-02-02 19:23:22 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:22 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:23:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
DEBUG - 2020-02-02 19:23:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
INFO - 2020-02-02 19:23:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
ERROR - 2020-02-02 19:23:22 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-02 19:23:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
ERROR - 2020-02-02 19:23:22 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
ERROR - 2020-02-02 19:23:22 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:23:22 --> Loader Class Initialized
INFO - 2020-02-02 19:23:22 --> Config Class Initialized
INFO - 2020-02-02 19:23:22 --> Config Class Initialized
INFO - 2020-02-02 19:23:22 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:22 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:22 --> Helper loaded: url_helper
INFO - 2020-02-02 19:23:22 --> Loader Class Initialized
INFO - 2020-02-02 19:23:22 --> Helper loaded: url_helper
DEBUG - 2020-02-02 19:23:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:22 --> Database Driver Class Initialized
INFO - 2020-02-02 19:23:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:22 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:23:22 --> Database Driver Class Initialized
INFO - 2020-02-02 19:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
DEBUG - 2020-02-02 19:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:23:22 --> Controller Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
INFO - 2020-02-02 19:23:22 --> Output Class Initialized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
INFO - 2020-02-02 19:23:22 --> Security Class Initialized
INFO - 2020-02-02 19:23:22 --> Helper loaded: form_helper
INFO - 2020-02-02 19:23:22 --> Form Validation Class Initialized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
INFO - 2020-02-02 19:23:22 --> Input Class Initialized
ERROR - 2020-02-02 19:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 19:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
INFO - 2020-02-02 19:23:22 --> Language Class Initialized
INFO - 2020-02-02 19:23:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-02 19:23:22 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-02 19:23:22 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:23:22 --> Final output sent to browser
INFO - 2020-02-02 19:23:22 --> Config Class Initialized
INFO - 2020-02-02 19:23:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:22 --> Total execution time: 0.5652
INFO - 2020-02-02 19:23:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-02 19:23:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:22 --> Controller Class Initialized
INFO - 2020-02-02 19:23:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:22 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:23:22 --> URI Class Initialized
INFO - 2020-02-02 19:23:22 --> Router Class Initialized
INFO - 2020-02-02 19:23:22 --> Helper loaded: form_helper
INFO - 2020-02-02 19:23:22 --> Form Validation Class Initialized
INFO - 2020-02-02 19:23:23 --> Output Class Initialized
INFO - 2020-02-02 19:23:23 --> Security Class Initialized
ERROR - 2020-02-02 19:23:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 19:23:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-02 19:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:23 --> Input Class Initialized
INFO - 2020-02-02 19:23:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:23:23 --> Final output sent to browser
INFO - 2020-02-02 19:23:23 --> Language Class Initialized
DEBUG - 2020-02-02 19:23:23 --> Total execution time: 0.7702
ERROR - 2020-02-02 19:23:23 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:23:23 --> Config Class Initialized
INFO - 2020-02-02 19:23:23 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:23 --> URI Class Initialized
INFO - 2020-02-02 19:23:23 --> Router Class Initialized
INFO - 2020-02-02 19:23:23 --> Output Class Initialized
INFO - 2020-02-02 19:23:23 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:23 --> Input Class Initialized
INFO - 2020-02-02 19:23:23 --> Language Class Initialized
ERROR - 2020-02-02 19:23:23 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:23:23 --> Config Class Initialized
INFO - 2020-02-02 19:23:23 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:23 --> URI Class Initialized
INFO - 2020-02-02 19:23:23 --> Router Class Initialized
INFO - 2020-02-02 19:23:23 --> Output Class Initialized
INFO - 2020-02-02 19:23:23 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:23 --> Input Class Initialized
INFO - 2020-02-02 19:23:23 --> Language Class Initialized
ERROR - 2020-02-02 19:23:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:23:23 --> Config Class Initialized
INFO - 2020-02-02 19:23:23 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:23 --> URI Class Initialized
INFO - 2020-02-02 19:23:23 --> Router Class Initialized
INFO - 2020-02-02 19:23:23 --> Output Class Initialized
INFO - 2020-02-02 19:23:23 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:24 --> Input Class Initialized
INFO - 2020-02-02 19:23:24 --> Language Class Initialized
ERROR - 2020-02-02 19:23:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:23:24 --> Config Class Initialized
INFO - 2020-02-02 19:23:24 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:24 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:24 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:24 --> URI Class Initialized
INFO - 2020-02-02 19:23:24 --> Router Class Initialized
INFO - 2020-02-02 19:23:24 --> Output Class Initialized
INFO - 2020-02-02 19:23:24 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:24 --> Input Class Initialized
INFO - 2020-02-02 19:23:24 --> Language Class Initialized
ERROR - 2020-02-02 19:23:24 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:23:24 --> Config Class Initialized
INFO - 2020-02-02 19:23:24 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:24 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:24 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:24 --> URI Class Initialized
INFO - 2020-02-02 19:23:24 --> Router Class Initialized
INFO - 2020-02-02 19:23:24 --> Output Class Initialized
INFO - 2020-02-02 19:23:24 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:24 --> Input Class Initialized
INFO - 2020-02-02 19:23:24 --> Language Class Initialized
ERROR - 2020-02-02 19:23:24 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:23:24 --> Config Class Initialized
INFO - 2020-02-02 19:23:24 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:24 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:24 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:24 --> URI Class Initialized
INFO - 2020-02-02 19:23:24 --> Router Class Initialized
INFO - 2020-02-02 19:23:24 --> Output Class Initialized
INFO - 2020-02-02 19:23:24 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:24 --> Input Class Initialized
INFO - 2020-02-02 19:23:24 --> Language Class Initialized
ERROR - 2020-02-02 19:23:24 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:23:24 --> Config Class Initialized
INFO - 2020-02-02 19:23:25 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:25 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:25 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:25 --> URI Class Initialized
INFO - 2020-02-02 19:23:25 --> Router Class Initialized
INFO - 2020-02-02 19:23:25 --> Output Class Initialized
INFO - 2020-02-02 19:23:25 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:25 --> Input Class Initialized
INFO - 2020-02-02 19:23:25 --> Language Class Initialized
ERROR - 2020-02-02 19:23:25 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:23:38 --> Config Class Initialized
INFO - 2020-02-02 19:23:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:39 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:39 --> URI Class Initialized
INFO - 2020-02-02 19:23:39 --> Router Class Initialized
INFO - 2020-02-02 19:23:39 --> Output Class Initialized
INFO - 2020-02-02 19:23:39 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:39 --> Input Class Initialized
INFO - 2020-02-02 19:23:39 --> Language Class Initialized
INFO - 2020-02-02 19:23:39 --> Loader Class Initialized
INFO - 2020-02-02 19:23:39 --> Helper loaded: url_helper
INFO - 2020-02-02 19:23:40 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:23:40 --> Controller Class Initialized
INFO - 2020-02-02 19:23:40 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:23:40 --> Helper loaded: form_helper
INFO - 2020-02-02 19:23:40 --> Form Validation Class Initialized
INFO - 2020-02-02 19:23:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:23:40 --> Final output sent to browser
DEBUG - 2020-02-02 19:23:40 --> Total execution time: 1.4275
INFO - 2020-02-02 19:23:40 --> Config Class Initialized
INFO - 2020-02-02 19:23:40 --> Config Class Initialized
INFO - 2020-02-02 19:23:40 --> Config Class Initialized
INFO - 2020-02-02 19:23:40 --> Config Class Initialized
INFO - 2020-02-02 19:23:40 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:40 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:40 --> Config Class Initialized
INFO - 2020-02-02 19:23:40 --> Config Class Initialized
INFO - 2020-02-02 19:23:40 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:40 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:40 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:40 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:40 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:23:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:40 --> URI Class Initialized
INFO - 2020-02-02 19:23:40 --> URI Class Initialized
INFO - 2020-02-02 19:23:40 --> URI Class Initialized
INFO - 2020-02-02 19:23:40 --> URI Class Initialized
INFO - 2020-02-02 19:23:40 --> URI Class Initialized
INFO - 2020-02-02 19:23:40 --> Router Class Initialized
INFO - 2020-02-02 19:23:40 --> URI Class Initialized
INFO - 2020-02-02 19:23:40 --> Router Class Initialized
INFO - 2020-02-02 19:23:40 --> Router Class Initialized
INFO - 2020-02-02 19:23:40 --> Router Class Initialized
INFO - 2020-02-02 19:23:40 --> Output Class Initialized
INFO - 2020-02-02 19:23:40 --> Output Class Initialized
INFO - 2020-02-02 19:23:40 --> Output Class Initialized
INFO - 2020-02-02 19:23:40 --> Router Class Initialized
INFO - 2020-02-02 19:23:40 --> Output Class Initialized
INFO - 2020-02-02 19:23:40 --> Router Class Initialized
INFO - 2020-02-02 19:23:40 --> Security Class Initialized
INFO - 2020-02-02 19:23:40 --> Security Class Initialized
INFO - 2020-02-02 19:23:40 --> Security Class Initialized
INFO - 2020-02-02 19:23:40 --> Output Class Initialized
INFO - 2020-02-02 19:23:40 --> Security Class Initialized
INFO - 2020-02-02 19:23:40 --> Output Class Initialized
INFO - 2020-02-02 19:23:40 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:40 --> Security Class Initialized
INFO - 2020-02-02 19:23:40 --> Input Class Initialized
INFO - 2020-02-02 19:23:40 --> Input Class Initialized
INFO - 2020-02-02 19:23:40 --> Input Class Initialized
INFO - 2020-02-02 19:23:40 --> Input Class Initialized
DEBUG - 2020-02-02 19:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:40 --> Input Class Initialized
INFO - 2020-02-02 19:23:40 --> Input Class Initialized
INFO - 2020-02-02 19:23:40 --> Language Class Initialized
INFO - 2020-02-02 19:23:40 --> Language Class Initialized
INFO - 2020-02-02 19:23:40 --> Language Class Initialized
INFO - 2020-02-02 19:23:40 --> Language Class Initialized
INFO - 2020-02-02 19:23:40 --> Language Class Initialized
INFO - 2020-02-02 19:23:40 --> Language Class Initialized
ERROR - 2020-02-02 19:23:40 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-02 19:23:40 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:23:40 --> Loader Class Initialized
INFO - 2020-02-02 19:23:40 --> Loader Class Initialized
INFO - 2020-02-02 19:23:40 --> Helper loaded: url_helper
ERROR - 2020-02-02 19:23:40 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-02 19:23:40 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:23:40 --> Helper loaded: url_helper
INFO - 2020-02-02 19:23:40 --> Config Class Initialized
INFO - 2020-02-02 19:23:40 --> Config Class Initialized
INFO - 2020-02-02 19:23:40 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:40 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:40 --> Database Driver Class Initialized
INFO - 2020-02-02 19:23:40 --> Config Class Initialized
INFO - 2020-02-02 19:23:40 --> Config Class Initialized
INFO - 2020-02-02 19:23:40 --> Database Driver Class Initialized
INFO - 2020-02-02 19:23:40 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:40 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-02 19:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:23:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:23:40 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:23:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:40 --> Controller Class Initialized
INFO - 2020-02-02 19:23:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:40 --> URI Class Initialized
INFO - 2020-02-02 19:23:40 --> URI Class Initialized
INFO - 2020-02-02 19:23:40 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:23:40 --> URI Class Initialized
INFO - 2020-02-02 19:23:40 --> Router Class Initialized
INFO - 2020-02-02 19:23:40 --> Router Class Initialized
INFO - 2020-02-02 19:23:40 --> URI Class Initialized
INFO - 2020-02-02 19:23:41 --> Router Class Initialized
INFO - 2020-02-02 19:23:41 --> Output Class Initialized
INFO - 2020-02-02 19:23:41 --> Output Class Initialized
INFO - 2020-02-02 19:23:41 --> Router Class Initialized
INFO - 2020-02-02 19:23:41 --> Helper loaded: form_helper
INFO - 2020-02-02 19:23:41 --> Form Validation Class Initialized
INFO - 2020-02-02 19:23:41 --> Security Class Initialized
INFO - 2020-02-02 19:23:41 --> Output Class Initialized
INFO - 2020-02-02 19:23:41 --> Output Class Initialized
INFO - 2020-02-02 19:23:41 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:41 --> Security Class Initialized
ERROR - 2020-02-02 19:23:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:23:41 --> Security Class Initialized
INFO - 2020-02-02 19:23:41 --> Input Class Initialized
INFO - 2020-02-02 19:23:41 --> Input Class Initialized
ERROR - 2020-02-02 19:23:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-02 19:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:41 --> Input Class Initialized
INFO - 2020-02-02 19:23:41 --> Language Class Initialized
INFO - 2020-02-02 19:23:41 --> Input Class Initialized
INFO - 2020-02-02 19:23:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:23:41 --> Language Class Initialized
INFO - 2020-02-02 19:23:41 --> Language Class Initialized
INFO - 2020-02-02 19:23:41 --> Language Class Initialized
ERROR - 2020-02-02 19:23:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:23:41 --> Final output sent to browser
ERROR - 2020-02-02 19:23:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-02 19:23:41 --> Total execution time: 0.6416
ERROR - 2020-02-02 19:23:41 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-02 19:23:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:23:41 --> Config Class Initialized
INFO - 2020-02-02 19:23:41 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:41 --> Config Class Initialized
INFO - 2020-02-02 19:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:23:41 --> Config Class Initialized
INFO - 2020-02-02 19:23:41 --> Config Class Initialized
INFO - 2020-02-02 19:23:41 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:41 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:41 --> Hooks Class Initialized
INFO - 2020-02-02 19:23:41 --> Controller Class Initialized
DEBUG - 2020-02-02 19:23:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:41 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:41 --> Model "M_tiket" initialized
DEBUG - 2020-02-02 19:23:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:23:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:41 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:41 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:41 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:41 --> URI Class Initialized
INFO - 2020-02-02 19:23:41 --> Helper loaded: form_helper
INFO - 2020-02-02 19:23:41 --> Form Validation Class Initialized
INFO - 2020-02-02 19:23:41 --> URI Class Initialized
INFO - 2020-02-02 19:23:41 --> URI Class Initialized
INFO - 2020-02-02 19:23:41 --> URI Class Initialized
INFO - 2020-02-02 19:23:41 --> Router Class Initialized
INFO - 2020-02-02 19:23:41 --> Router Class Initialized
INFO - 2020-02-02 19:23:41 --> Router Class Initialized
INFO - 2020-02-02 19:23:41 --> Router Class Initialized
INFO - 2020-02-02 19:23:41 --> Output Class Initialized
ERROR - 2020-02-02 19:23:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 19:23:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:23:41 --> Security Class Initialized
INFO - 2020-02-02 19:23:41 --> Output Class Initialized
INFO - 2020-02-02 19:23:41 --> Output Class Initialized
INFO - 2020-02-02 19:23:41 --> Output Class Initialized
INFO - 2020-02-02 19:23:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-02 19:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:41 --> Security Class Initialized
INFO - 2020-02-02 19:23:41 --> Security Class Initialized
INFO - 2020-02-02 19:23:41 --> Security Class Initialized
INFO - 2020-02-02 19:23:41 --> Input Class Initialized
INFO - 2020-02-02 19:23:41 --> Final output sent to browser
DEBUG - 2020-02-02 19:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:41 --> Input Class Initialized
DEBUG - 2020-02-02 19:23:41 --> Total execution time: 0.9315
INFO - 2020-02-02 19:23:41 --> Input Class Initialized
INFO - 2020-02-02 19:23:41 --> Input Class Initialized
INFO - 2020-02-02 19:23:41 --> Language Class Initialized
INFO - 2020-02-02 19:23:41 --> Language Class Initialized
INFO - 2020-02-02 19:23:41 --> Language Class Initialized
INFO - 2020-02-02 19:23:41 --> Language Class Initialized
ERROR - 2020-02-02 19:23:41 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-02 19:23:41 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-02 19:23:41 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-02 19:23:41 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:23:41 --> Config Class Initialized
INFO - 2020-02-02 19:23:41 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:41 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:41 --> URI Class Initialized
INFO - 2020-02-02 19:23:41 --> Router Class Initialized
INFO - 2020-02-02 19:23:41 --> Output Class Initialized
INFO - 2020-02-02 19:23:41 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:41 --> Input Class Initialized
INFO - 2020-02-02 19:23:41 --> Language Class Initialized
ERROR - 2020-02-02 19:23:41 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:23:41 --> Config Class Initialized
INFO - 2020-02-02 19:23:41 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:41 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:41 --> URI Class Initialized
INFO - 2020-02-02 19:23:41 --> Router Class Initialized
INFO - 2020-02-02 19:23:41 --> Output Class Initialized
INFO - 2020-02-02 19:23:41 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:42 --> Input Class Initialized
INFO - 2020-02-02 19:23:42 --> Language Class Initialized
ERROR - 2020-02-02 19:23:42 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:23:42 --> Config Class Initialized
INFO - 2020-02-02 19:23:42 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:42 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:42 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:42 --> URI Class Initialized
INFO - 2020-02-02 19:23:42 --> Router Class Initialized
INFO - 2020-02-02 19:23:42 --> Output Class Initialized
INFO - 2020-02-02 19:23:42 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:42 --> Input Class Initialized
INFO - 2020-02-02 19:23:42 --> Language Class Initialized
ERROR - 2020-02-02 19:23:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:23:42 --> Config Class Initialized
INFO - 2020-02-02 19:23:42 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:42 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:42 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:42 --> URI Class Initialized
INFO - 2020-02-02 19:23:42 --> Router Class Initialized
INFO - 2020-02-02 19:23:42 --> Output Class Initialized
INFO - 2020-02-02 19:23:42 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:42 --> Input Class Initialized
INFO - 2020-02-02 19:23:42 --> Language Class Initialized
ERROR - 2020-02-02 19:23:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:23:42 --> Config Class Initialized
INFO - 2020-02-02 19:23:42 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:42 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:42 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:42 --> URI Class Initialized
INFO - 2020-02-02 19:23:42 --> Router Class Initialized
INFO - 2020-02-02 19:23:42 --> Output Class Initialized
INFO - 2020-02-02 19:23:42 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:42 --> Input Class Initialized
INFO - 2020-02-02 19:23:42 --> Language Class Initialized
ERROR - 2020-02-02 19:23:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:23:42 --> Config Class Initialized
INFO - 2020-02-02 19:23:43 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:43 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:43 --> URI Class Initialized
INFO - 2020-02-02 19:23:43 --> Router Class Initialized
INFO - 2020-02-02 19:23:43 --> Output Class Initialized
INFO - 2020-02-02 19:23:43 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:43 --> Input Class Initialized
INFO - 2020-02-02 19:23:43 --> Language Class Initialized
ERROR - 2020-02-02 19:23:43 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:23:43 --> Config Class Initialized
INFO - 2020-02-02 19:23:43 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:43 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:43 --> URI Class Initialized
INFO - 2020-02-02 19:23:43 --> Router Class Initialized
INFO - 2020-02-02 19:23:43 --> Output Class Initialized
INFO - 2020-02-02 19:23:43 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:43 --> Input Class Initialized
INFO - 2020-02-02 19:23:43 --> Language Class Initialized
ERROR - 2020-02-02 19:23:43 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:23:43 --> Config Class Initialized
INFO - 2020-02-02 19:23:43 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:43 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:43 --> URI Class Initialized
INFO - 2020-02-02 19:23:43 --> Router Class Initialized
INFO - 2020-02-02 19:23:43 --> Output Class Initialized
INFO - 2020-02-02 19:23:43 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:43 --> Input Class Initialized
INFO - 2020-02-02 19:23:43 --> Language Class Initialized
ERROR - 2020-02-02 19:23:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:23:43 --> Config Class Initialized
INFO - 2020-02-02 19:23:43 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:23:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:23:43 --> Utf8 Class Initialized
INFO - 2020-02-02 19:23:43 --> URI Class Initialized
INFO - 2020-02-02 19:23:43 --> Router Class Initialized
INFO - 2020-02-02 19:23:44 --> Output Class Initialized
INFO - 2020-02-02 19:23:44 --> Security Class Initialized
DEBUG - 2020-02-02 19:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:23:44 --> Input Class Initialized
INFO - 2020-02-02 19:23:44 --> Language Class Initialized
ERROR - 2020-02-02 19:23:44 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:24:05 --> Config Class Initialized
INFO - 2020-02-02 19:24:05 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:05 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:05 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:05 --> URI Class Initialized
INFO - 2020-02-02 19:24:05 --> Router Class Initialized
INFO - 2020-02-02 19:24:05 --> Output Class Initialized
INFO - 2020-02-02 19:24:05 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:05 --> Input Class Initialized
INFO - 2020-02-02 19:24:05 --> Language Class Initialized
INFO - 2020-02-02 19:24:05 --> Loader Class Initialized
INFO - 2020-02-02 19:24:05 --> Helper loaded: url_helper
INFO - 2020-02-02 19:24:05 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:24:05 --> Controller Class Initialized
INFO - 2020-02-02 19:24:05 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:24:05 --> Helper loaded: form_helper
INFO - 2020-02-02 19:24:06 --> Form Validation Class Initialized
INFO - 2020-02-02 19:24:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:24:06 --> Final output sent to browser
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
DEBUG - 2020-02-02 19:24:06 --> Total execution time: 0.8369
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:06 --> URI Class Initialized
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:06 --> URI Class Initialized
INFO - 2020-02-02 19:24:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:06 --> Router Class Initialized
INFO - 2020-02-02 19:24:06 --> URI Class Initialized
INFO - 2020-02-02 19:24:06 --> URI Class Initialized
INFO - 2020-02-02 19:24:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:06 --> Router Class Initialized
INFO - 2020-02-02 19:24:06 --> Router Class Initialized
INFO - 2020-02-02 19:24:06 --> Router Class Initialized
INFO - 2020-02-02 19:24:06 --> URI Class Initialized
INFO - 2020-02-02 19:24:06 --> Output Class Initialized
INFO - 2020-02-02 19:24:06 --> Output Class Initialized
INFO - 2020-02-02 19:24:06 --> Output Class Initialized
INFO - 2020-02-02 19:24:06 --> Router Class Initialized
INFO - 2020-02-02 19:24:06 --> Output Class Initialized
INFO - 2020-02-02 19:24:06 --> URI Class Initialized
INFO - 2020-02-02 19:24:06 --> Security Class Initialized
INFO - 2020-02-02 19:24:06 --> Security Class Initialized
INFO - 2020-02-02 19:24:06 --> Security Class Initialized
INFO - 2020-02-02 19:24:06 --> Router Class Initialized
INFO - 2020-02-02 19:24:06 --> Output Class Initialized
INFO - 2020-02-02 19:24:06 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:06 --> Input Class Initialized
DEBUG - 2020-02-02 19:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:06 --> Output Class Initialized
DEBUG - 2020-02-02 19:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:06 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:06 --> Input Class Initialized
INFO - 2020-02-02 19:24:06 --> Input Class Initialized
DEBUG - 2020-02-02 19:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:06 --> Language Class Initialized
INFO - 2020-02-02 19:24:06 --> Input Class Initialized
INFO - 2020-02-02 19:24:06 --> Security Class Initialized
INFO - 2020-02-02 19:24:06 --> Language Class Initialized
INFO - 2020-02-02 19:24:06 --> Language Class Initialized
DEBUG - 2020-02-02 19:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:06 --> Input Class Initialized
INFO - 2020-02-02 19:24:06 --> Language Class Initialized
INFO - 2020-02-02 19:24:06 --> Loader Class Initialized
INFO - 2020-02-02 19:24:06 --> Input Class Initialized
INFO - 2020-02-02 19:24:06 --> Language Class Initialized
ERROR - 2020-02-02 19:24:06 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-02 19:24:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:24:06 --> Helper loaded: url_helper
INFO - 2020-02-02 19:24:06 --> Loader Class Initialized
INFO - 2020-02-02 19:24:06 --> Language Class Initialized
INFO - 2020-02-02 19:24:06 --> Helper loaded: url_helper
ERROR - 2020-02-02 19:24:06 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
INFO - 2020-02-02 19:24:06 --> Database Driver Class Initialized
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
ERROR - 2020-02-02 19:24:06 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-02 19:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:24:06 --> Database Driver Class Initialized
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:06 --> Controller Class Initialized
INFO - 2020-02-02 19:24:06 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:06 --> URI Class Initialized
INFO - 2020-02-02 19:24:06 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:24:06 --> URI Class Initialized
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:06 --> Router Class Initialized
INFO - 2020-02-02 19:24:06 --> Router Class Initialized
INFO - 2020-02-02 19:24:06 --> URI Class Initialized
INFO - 2020-02-02 19:24:06 --> Helper loaded: form_helper
INFO - 2020-02-02 19:24:06 --> Form Validation Class Initialized
INFO - 2020-02-02 19:24:06 --> URI Class Initialized
INFO - 2020-02-02 19:24:06 --> Router Class Initialized
INFO - 2020-02-02 19:24:06 --> Output Class Initialized
INFO - 2020-02-02 19:24:06 --> Output Class Initialized
INFO - 2020-02-02 19:24:06 --> Router Class Initialized
INFO - 2020-02-02 19:24:06 --> Security Class Initialized
INFO - 2020-02-02 19:24:06 --> Output Class Initialized
INFO - 2020-02-02 19:24:06 --> Security Class Initialized
ERROR - 2020-02-02 19:24:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 19:24:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:24:06 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:06 --> Output Class Initialized
DEBUG - 2020-02-02 19:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:06 --> Input Class Initialized
INFO - 2020-02-02 19:24:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:24:06 --> Input Class Initialized
DEBUG - 2020-02-02 19:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:06 --> Security Class Initialized
INFO - 2020-02-02 19:24:06 --> Input Class Initialized
INFO - 2020-02-02 19:24:06 --> Final output sent to browser
INFO - 2020-02-02 19:24:06 --> Language Class Initialized
INFO - 2020-02-02 19:24:06 --> Language Class Initialized
DEBUG - 2020-02-02 19:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:06 --> Input Class Initialized
INFO - 2020-02-02 19:24:06 --> Language Class Initialized
DEBUG - 2020-02-02 19:24:06 --> Total execution time: 0.6760
ERROR - 2020-02-02 19:24:06 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 19:24:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:24:06 --> Language Class Initialized
ERROR - 2020-02-02 19:24:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:06 --> Controller Class Initialized
ERROR - 2020-02-02 19:24:06 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:24:06 --> Config Class Initialized
INFO - 2020-02-02 19:24:06 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:06 --> Model "M_tiket" initialized
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:06 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:06 --> Helper loaded: form_helper
DEBUG - 2020-02-02 19:24:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:07 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:07 --> Form Validation Class Initialized
INFO - 2020-02-02 19:24:07 --> URI Class Initialized
INFO - 2020-02-02 19:24:07 --> URI Class Initialized
INFO - 2020-02-02 19:24:07 --> URI Class Initialized
INFO - 2020-02-02 19:24:07 --> Router Class Initialized
INFO - 2020-02-02 19:24:07 --> URI Class Initialized
INFO - 2020-02-02 19:24:07 --> Router Class Initialized
INFO - 2020-02-02 19:24:07 --> Router Class Initialized
ERROR - 2020-02-02 19:24:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 19:24:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:24:07 --> Router Class Initialized
INFO - 2020-02-02 19:24:07 --> Output Class Initialized
INFO - 2020-02-02 19:24:07 --> Output Class Initialized
INFO - 2020-02-02 19:24:07 --> Output Class Initialized
INFO - 2020-02-02 19:24:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:24:07 --> Security Class Initialized
INFO - 2020-02-02 19:24:07 --> Security Class Initialized
INFO - 2020-02-02 19:24:07 --> Output Class Initialized
INFO - 2020-02-02 19:24:07 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:07 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:07 --> Final output sent to browser
DEBUG - 2020-02-02 19:24:07 --> Total execution time: 0.9777
INFO - 2020-02-02 19:24:07 --> Input Class Initialized
INFO - 2020-02-02 19:24:07 --> Input Class Initialized
INFO - 2020-02-02 19:24:07 --> Input Class Initialized
DEBUG - 2020-02-02 19:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:07 --> Language Class Initialized
INFO - 2020-02-02 19:24:07 --> Input Class Initialized
INFO - 2020-02-02 19:24:07 --> Language Class Initialized
INFO - 2020-02-02 19:24:07 --> Language Class Initialized
INFO - 2020-02-02 19:24:07 --> Language Class Initialized
ERROR - 2020-02-02 19:24:07 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-02 19:24:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-02 19:24:07 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-02 19:24:07 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:24:07 --> Config Class Initialized
INFO - 2020-02-02 19:24:07 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:07 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:07 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:07 --> URI Class Initialized
INFO - 2020-02-02 19:24:07 --> Router Class Initialized
INFO - 2020-02-02 19:24:07 --> Output Class Initialized
INFO - 2020-02-02 19:24:07 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:07 --> Input Class Initialized
INFO - 2020-02-02 19:24:07 --> Language Class Initialized
ERROR - 2020-02-02 19:24:07 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:24:07 --> Config Class Initialized
INFO - 2020-02-02 19:24:07 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:07 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:07 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:07 --> URI Class Initialized
INFO - 2020-02-02 19:24:07 --> Router Class Initialized
INFO - 2020-02-02 19:24:07 --> Output Class Initialized
INFO - 2020-02-02 19:24:07 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:07 --> Input Class Initialized
INFO - 2020-02-02 19:24:07 --> Language Class Initialized
ERROR - 2020-02-02 19:24:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:24:07 --> Config Class Initialized
INFO - 2020-02-02 19:24:07 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:07 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:07 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:07 --> URI Class Initialized
INFO - 2020-02-02 19:24:07 --> Router Class Initialized
INFO - 2020-02-02 19:24:08 --> Output Class Initialized
INFO - 2020-02-02 19:24:08 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:08 --> Input Class Initialized
INFO - 2020-02-02 19:24:08 --> Language Class Initialized
ERROR - 2020-02-02 19:24:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:24:08 --> Config Class Initialized
INFO - 2020-02-02 19:24:08 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:08 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:08 --> URI Class Initialized
INFO - 2020-02-02 19:24:08 --> Router Class Initialized
INFO - 2020-02-02 19:24:08 --> Output Class Initialized
INFO - 2020-02-02 19:24:08 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:08 --> Input Class Initialized
INFO - 2020-02-02 19:24:08 --> Language Class Initialized
ERROR - 2020-02-02 19:24:08 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:24:08 --> Config Class Initialized
INFO - 2020-02-02 19:24:08 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:08 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:08 --> URI Class Initialized
INFO - 2020-02-02 19:24:08 --> Router Class Initialized
INFO - 2020-02-02 19:24:08 --> Output Class Initialized
INFO - 2020-02-02 19:24:08 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:08 --> Input Class Initialized
INFO - 2020-02-02 19:24:08 --> Language Class Initialized
ERROR - 2020-02-02 19:24:08 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:24:08 --> Config Class Initialized
INFO - 2020-02-02 19:24:08 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:08 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:08 --> URI Class Initialized
INFO - 2020-02-02 19:24:08 --> Router Class Initialized
INFO - 2020-02-02 19:24:08 --> Output Class Initialized
INFO - 2020-02-02 19:24:08 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:08 --> Input Class Initialized
INFO - 2020-02-02 19:24:09 --> Language Class Initialized
ERROR - 2020-02-02 19:24:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:24:09 --> Config Class Initialized
INFO - 2020-02-02 19:24:09 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:09 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:09 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:09 --> URI Class Initialized
INFO - 2020-02-02 19:24:09 --> Router Class Initialized
INFO - 2020-02-02 19:24:09 --> Output Class Initialized
INFO - 2020-02-02 19:24:09 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:09 --> Input Class Initialized
INFO - 2020-02-02 19:24:09 --> Language Class Initialized
ERROR - 2020-02-02 19:24:09 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:24:21 --> Config Class Initialized
INFO - 2020-02-02 19:24:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:22 --> URI Class Initialized
INFO - 2020-02-02 19:24:22 --> Router Class Initialized
INFO - 2020-02-02 19:24:22 --> Output Class Initialized
INFO - 2020-02-02 19:24:22 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:22 --> Input Class Initialized
INFO - 2020-02-02 19:24:22 --> Language Class Initialized
INFO - 2020-02-02 19:24:22 --> Loader Class Initialized
INFO - 2020-02-02 19:24:23 --> Helper loaded: url_helper
INFO - 2020-02-02 19:24:23 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:24:23 --> Controller Class Initialized
INFO - 2020-02-02 19:24:23 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:24:23 --> Helper loaded: form_helper
INFO - 2020-02-02 19:24:23 --> Form Validation Class Initialized
INFO - 2020-02-02 19:24:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:24:23 --> Final output sent to browser
INFO - 2020-02-02 19:24:23 --> Config Class Initialized
INFO - 2020-02-02 19:24:23 --> Config Class Initialized
INFO - 2020-02-02 19:24:23 --> Config Class Initialized
INFO - 2020-02-02 19:24:23 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:23 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:23 --> Total execution time: 1.4013
INFO - 2020-02-02 19:24:23 --> Config Class Initialized
INFO - 2020-02-02 19:24:23 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:23 --> Config Class Initialized
INFO - 2020-02-02 19:24:23 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:23 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:23 --> Config Class Initialized
INFO - 2020-02-02 19:24:23 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:23 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:23 --> URI Class Initialized
INFO - 2020-02-02 19:24:23 --> URI Class Initialized
INFO - 2020-02-02 19:24:23 --> URI Class Initialized
DEBUG - 2020-02-02 19:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:23 --> URI Class Initialized
INFO - 2020-02-02 19:24:23 --> Router Class Initialized
INFO - 2020-02-02 19:24:23 --> URI Class Initialized
INFO - 2020-02-02 19:24:23 --> Router Class Initialized
INFO - 2020-02-02 19:24:23 --> Router Class Initialized
INFO - 2020-02-02 19:24:23 --> URI Class Initialized
INFO - 2020-02-02 19:24:23 --> Router Class Initialized
INFO - 2020-02-02 19:24:23 --> Output Class Initialized
INFO - 2020-02-02 19:24:23 --> Output Class Initialized
INFO - 2020-02-02 19:24:23 --> Output Class Initialized
INFO - 2020-02-02 19:24:23 --> Router Class Initialized
INFO - 2020-02-02 19:24:23 --> Output Class Initialized
INFO - 2020-02-02 19:24:23 --> Router Class Initialized
INFO - 2020-02-02 19:24:23 --> Output Class Initialized
INFO - 2020-02-02 19:24:23 --> Security Class Initialized
INFO - 2020-02-02 19:24:23 --> Security Class Initialized
INFO - 2020-02-02 19:24:23 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:23 --> Security Class Initialized
INFO - 2020-02-02 19:24:23 --> Security Class Initialized
INFO - 2020-02-02 19:24:23 --> Output Class Initialized
DEBUG - 2020-02-02 19:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:23 --> Input Class Initialized
INFO - 2020-02-02 19:24:23 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:23 --> Input Class Initialized
INFO - 2020-02-02 19:24:23 --> Input Class Initialized
DEBUG - 2020-02-02 19:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:23 --> Input Class Initialized
INFO - 2020-02-02 19:24:23 --> Language Class Initialized
INFO - 2020-02-02 19:24:23 --> Language Class Initialized
INFO - 2020-02-02 19:24:23 --> Input Class Initialized
DEBUG - 2020-02-02 19:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:23 --> Language Class Initialized
INFO - 2020-02-02 19:24:23 --> Input Class Initialized
INFO - 2020-02-02 19:24:23 --> Language Class Initialized
ERROR - 2020-02-02 19:24:23 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-02 19:24:23 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:24:23 --> Language Class Initialized
ERROR - 2020-02-02 19:24:23 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 19:24:23 --> Language Class Initialized
ERROR - 2020-02-02 19:24:23 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-02 19:24:23 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:24:23 --> Config Class Initialized
INFO - 2020-02-02 19:24:23 --> Config Class Initialized
INFO - 2020-02-02 19:24:23 --> Config Class Initialized
INFO - 2020-02-02 19:24:23 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:23 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:23 --> Hooks Class Initialized
ERROR - 2020-02-02 19:24:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:24:23 --> Config Class Initialized
INFO - 2020-02-02 19:24:23 --> Config Class Initialized
INFO - 2020-02-02 19:24:23 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:23 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:23 --> Config Class Initialized
INFO - 2020-02-02 19:24:23 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:23 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:23 --> URI Class Initialized
INFO - 2020-02-02 19:24:23 --> URI Class Initialized
INFO - 2020-02-02 19:24:23 --> URI Class Initialized
DEBUG - 2020-02-02 19:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:23 --> Router Class Initialized
INFO - 2020-02-02 19:24:23 --> URI Class Initialized
INFO - 2020-02-02 19:24:23 --> Router Class Initialized
INFO - 2020-02-02 19:24:23 --> URI Class Initialized
INFO - 2020-02-02 19:24:23 --> Router Class Initialized
INFO - 2020-02-02 19:24:24 --> Router Class Initialized
INFO - 2020-02-02 19:24:24 --> URI Class Initialized
INFO - 2020-02-02 19:24:24 --> Router Class Initialized
INFO - 2020-02-02 19:24:24 --> Output Class Initialized
INFO - 2020-02-02 19:24:24 --> Output Class Initialized
INFO - 2020-02-02 19:24:24 --> Output Class Initialized
INFO - 2020-02-02 19:24:24 --> Security Class Initialized
INFO - 2020-02-02 19:24:24 --> Security Class Initialized
INFO - 2020-02-02 19:24:24 --> Security Class Initialized
INFO - 2020-02-02 19:24:24 --> Output Class Initialized
INFO - 2020-02-02 19:24:24 --> Router Class Initialized
INFO - 2020-02-02 19:24:24 --> Output Class Initialized
DEBUG - 2020-02-02 19:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:24 --> Output Class Initialized
INFO - 2020-02-02 19:24:24 --> Security Class Initialized
INFO - 2020-02-02 19:24:24 --> Security Class Initialized
INFO - 2020-02-02 19:24:24 --> Input Class Initialized
DEBUG - 2020-02-02 19:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:24 --> Security Class Initialized
INFO - 2020-02-02 19:24:24 --> Input Class Initialized
INFO - 2020-02-02 19:24:24 --> Input Class Initialized
DEBUG - 2020-02-02 19:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:24 --> Input Class Initialized
INFO - 2020-02-02 19:24:24 --> Input Class Initialized
INFO - 2020-02-02 19:24:24 --> Language Class Initialized
INFO - 2020-02-02 19:24:24 --> Language Class Initialized
INFO - 2020-02-02 19:24:24 --> Language Class Initialized
DEBUG - 2020-02-02 19:24:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 19:24:24 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-02 19:24:24 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:24:24 --> Language Class Initialized
ERROR - 2020-02-02 19:24:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:24:24 --> Language Class Initialized
INFO - 2020-02-02 19:24:24 --> Input Class Initialized
INFO - 2020-02-02 19:24:24 --> Language Class Initialized
ERROR - 2020-02-02 19:24:24 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-02 19:24:24 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:24:24 --> Config Class Initialized
INFO - 2020-02-02 19:24:24 --> Config Class Initialized
INFO - 2020-02-02 19:24:24 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:24 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:24 --> Loader Class Initialized
INFO - 2020-02-02 19:24:24 --> Helper loaded: url_helper
DEBUG - 2020-02-02 19:24:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:24 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:24 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:24 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:24 --> Database Driver Class Initialized
INFO - 2020-02-02 19:24:24 --> URI Class Initialized
INFO - 2020-02-02 19:24:24 --> URI Class Initialized
DEBUG - 2020-02-02 19:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:24:24 --> Router Class Initialized
INFO - 2020-02-02 19:24:24 --> Router Class Initialized
INFO - 2020-02-02 19:24:24 --> Controller Class Initialized
INFO - 2020-02-02 19:24:24 --> Output Class Initialized
INFO - 2020-02-02 19:24:24 --> Output Class Initialized
INFO - 2020-02-02 19:24:24 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:24:24 --> Security Class Initialized
INFO - 2020-02-02 19:24:24 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:24 --> Helper loaded: form_helper
INFO - 2020-02-02 19:24:24 --> Input Class Initialized
INFO - 2020-02-02 19:24:24 --> Input Class Initialized
INFO - 2020-02-02 19:24:24 --> Form Validation Class Initialized
INFO - 2020-02-02 19:24:24 --> Language Class Initialized
INFO - 2020-02-02 19:24:24 --> Language Class Initialized
ERROR - 2020-02-02 19:24:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 19:24:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-02 19:24:24 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:24:24 --> Loader Class Initialized
INFO - 2020-02-02 19:24:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:24:24 --> Helper loaded: url_helper
INFO - 2020-02-02 19:24:24 --> Config Class Initialized
INFO - 2020-02-02 19:24:24 --> Hooks Class Initialized
INFO - 2020-02-02 19:24:24 --> Final output sent to browser
INFO - 2020-02-02 19:24:24 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:24:24 --> Total execution time: 0.6211
DEBUG - 2020-02-02 19:24:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:24:24 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:24:24 --> Controller Class Initialized
INFO - 2020-02-02 19:24:24 --> URI Class Initialized
INFO - 2020-02-02 19:24:24 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:24:24 --> Router Class Initialized
INFO - 2020-02-02 19:24:24 --> Output Class Initialized
INFO - 2020-02-02 19:24:24 --> Helper loaded: form_helper
INFO - 2020-02-02 19:24:24 --> Form Validation Class Initialized
INFO - 2020-02-02 19:24:24 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 19:24:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:24:24 --> Input Class Initialized
ERROR - 2020-02-02 19:24:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:24:24 --> Language Class Initialized
INFO - 2020-02-02 19:24:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:24:24 --> Final output sent to browser
ERROR - 2020-02-02 19:24:24 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-02 19:24:24 --> Total execution time: 0.5898
INFO - 2020-02-02 19:24:24 --> Config Class Initialized
INFO - 2020-02-02 19:24:24 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:24 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:24 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:24 --> URI Class Initialized
INFO - 2020-02-02 19:24:24 --> Router Class Initialized
INFO - 2020-02-02 19:24:24 --> Output Class Initialized
INFO - 2020-02-02 19:24:24 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:25 --> Input Class Initialized
INFO - 2020-02-02 19:24:25 --> Language Class Initialized
ERROR - 2020-02-02 19:24:25 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:24:25 --> Config Class Initialized
INFO - 2020-02-02 19:24:25 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:25 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:25 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:25 --> URI Class Initialized
INFO - 2020-02-02 19:24:25 --> Router Class Initialized
INFO - 2020-02-02 19:24:25 --> Output Class Initialized
INFO - 2020-02-02 19:24:25 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:25 --> Input Class Initialized
INFO - 2020-02-02 19:24:25 --> Language Class Initialized
ERROR - 2020-02-02 19:24:25 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:24:25 --> Config Class Initialized
INFO - 2020-02-02 19:24:25 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:25 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:25 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:25 --> URI Class Initialized
INFO - 2020-02-02 19:24:25 --> Router Class Initialized
INFO - 2020-02-02 19:24:25 --> Output Class Initialized
INFO - 2020-02-02 19:24:25 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:25 --> Input Class Initialized
INFO - 2020-02-02 19:24:25 --> Language Class Initialized
ERROR - 2020-02-02 19:24:25 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:24:25 --> Config Class Initialized
INFO - 2020-02-02 19:24:25 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:25 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:25 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:25 --> URI Class Initialized
INFO - 2020-02-02 19:24:25 --> Router Class Initialized
INFO - 2020-02-02 19:24:25 --> Output Class Initialized
INFO - 2020-02-02 19:24:25 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:25 --> Input Class Initialized
INFO - 2020-02-02 19:24:25 --> Language Class Initialized
ERROR - 2020-02-02 19:24:26 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:24:26 --> Config Class Initialized
INFO - 2020-02-02 19:24:26 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:26 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:26 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:26 --> URI Class Initialized
INFO - 2020-02-02 19:24:26 --> Router Class Initialized
INFO - 2020-02-02 19:24:26 --> Output Class Initialized
INFO - 2020-02-02 19:24:26 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:26 --> Input Class Initialized
INFO - 2020-02-02 19:24:26 --> Language Class Initialized
ERROR - 2020-02-02 19:24:26 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:24:26 --> Config Class Initialized
INFO - 2020-02-02 19:24:26 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:26 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:26 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:26 --> URI Class Initialized
INFO - 2020-02-02 19:24:26 --> Router Class Initialized
INFO - 2020-02-02 19:24:26 --> Output Class Initialized
INFO - 2020-02-02 19:24:26 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:26 --> Input Class Initialized
INFO - 2020-02-02 19:24:26 --> Language Class Initialized
ERROR - 2020-02-02 19:24:26 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:24:26 --> Config Class Initialized
INFO - 2020-02-02 19:24:26 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:24:26 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:24:26 --> Utf8 Class Initialized
INFO - 2020-02-02 19:24:26 --> URI Class Initialized
INFO - 2020-02-02 19:24:26 --> Router Class Initialized
INFO - 2020-02-02 19:24:26 --> Output Class Initialized
INFO - 2020-02-02 19:24:26 --> Security Class Initialized
DEBUG - 2020-02-02 19:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:24:26 --> Input Class Initialized
INFO - 2020-02-02 19:24:26 --> Language Class Initialized
ERROR - 2020-02-02 19:24:26 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:26:18 --> Config Class Initialized
INFO - 2020-02-02 19:26:19 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:19 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:19 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:19 --> URI Class Initialized
INFO - 2020-02-02 19:26:19 --> Router Class Initialized
INFO - 2020-02-02 19:26:19 --> Output Class Initialized
INFO - 2020-02-02 19:26:19 --> Security Class Initialized
DEBUG - 2020-02-02 19:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:19 --> Input Class Initialized
INFO - 2020-02-02 19:26:19 --> Language Class Initialized
INFO - 2020-02-02 19:26:19 --> Loader Class Initialized
INFO - 2020-02-02 19:26:19 --> Helper loaded: url_helper
INFO - 2020-02-02 19:26:19 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:26:19 --> Controller Class Initialized
INFO - 2020-02-02 19:26:19 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:26:19 --> Helper loaded: form_helper
INFO - 2020-02-02 19:26:19 --> Form Validation Class Initialized
INFO - 2020-02-02 19:26:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:26:19 --> Final output sent to browser
DEBUG - 2020-02-02 19:26:19 --> Total execution time: 0.7442
INFO - 2020-02-02 19:26:19 --> Config Class Initialized
INFO - 2020-02-02 19:26:19 --> Config Class Initialized
INFO - 2020-02-02 19:26:19 --> Config Class Initialized
INFO - 2020-02-02 19:26:19 --> Config Class Initialized
INFO - 2020-02-02 19:26:19 --> Config Class Initialized
INFO - 2020-02-02 19:26:19 --> Hooks Class Initialized
INFO - 2020-02-02 19:26:19 --> Hooks Class Initialized
INFO - 2020-02-02 19:26:19 --> Hooks Class Initialized
INFO - 2020-02-02 19:26:19 --> Hooks Class Initialized
INFO - 2020-02-02 19:26:19 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:19 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:19 --> Config Class Initialized
INFO - 2020-02-02 19:26:19 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:19 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:26:19 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:19 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:19 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:19 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:19 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:19 --> URI Class Initialized
DEBUG - 2020-02-02 19:26:19 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:19 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:19 --> URI Class Initialized
INFO - 2020-02-02 19:26:19 --> Router Class Initialized
INFO - 2020-02-02 19:26:19 --> URI Class Initialized
INFO - 2020-02-02 19:26:19 --> URI Class Initialized
INFO - 2020-02-02 19:26:19 --> URI Class Initialized
INFO - 2020-02-02 19:26:19 --> URI Class Initialized
INFO - 2020-02-02 19:26:19 --> Router Class Initialized
INFO - 2020-02-02 19:26:19 --> Output Class Initialized
INFO - 2020-02-02 19:26:19 --> Router Class Initialized
INFO - 2020-02-02 19:26:19 --> Router Class Initialized
INFO - 2020-02-02 19:26:19 --> Router Class Initialized
INFO - 2020-02-02 19:26:19 --> Output Class Initialized
INFO - 2020-02-02 19:26:19 --> Output Class Initialized
INFO - 2020-02-02 19:26:19 --> Output Class Initialized
INFO - 2020-02-02 19:26:19 --> Security Class Initialized
INFO - 2020-02-02 19:26:19 --> Output Class Initialized
INFO - 2020-02-02 19:26:19 --> Router Class Initialized
DEBUG - 2020-02-02 19:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:19 --> Security Class Initialized
INFO - 2020-02-02 19:26:19 --> Security Class Initialized
INFO - 2020-02-02 19:26:19 --> Output Class Initialized
INFO - 2020-02-02 19:26:19 --> Security Class Initialized
INFO - 2020-02-02 19:26:19 --> Security Class Initialized
INFO - 2020-02-02 19:26:19 --> Input Class Initialized
DEBUG - 2020-02-02 19:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:20 --> Security Class Initialized
INFO - 2020-02-02 19:26:20 --> Input Class Initialized
INFO - 2020-02-02 19:26:20 --> Input Class Initialized
INFO - 2020-02-02 19:26:20 --> Input Class Initialized
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
INFO - 2020-02-02 19:26:20 --> Input Class Initialized
DEBUG - 2020-02-02 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
INFO - 2020-02-02 19:26:20 --> Input Class Initialized
ERROR - 2020-02-02 19:26:20 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
ERROR - 2020-02-02 19:26:20 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-02 19:26:20 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:26:20 --> Loader Class Initialized
ERROR - 2020-02-02 19:26:20 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:26:20 --> Config Class Initialized
INFO - 2020-02-02 19:26:20 --> Hooks Class Initialized
ERROR - 2020-02-02 19:26:20 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:26:20 --> Helper loaded: url_helper
INFO - 2020-02-02 19:26:20 --> Config Class Initialized
INFO - 2020-02-02 19:26:20 --> Config Class Initialized
INFO - 2020-02-02 19:26:20 --> Config Class Initialized
INFO - 2020-02-02 19:26:20 --> Hooks Class Initialized
INFO - 2020-02-02 19:26:20 --> Hooks Class Initialized
INFO - 2020-02-02 19:26:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:20 --> Database Driver Class Initialized
INFO - 2020-02-02 19:26:20 --> Config Class Initialized
INFO - 2020-02-02 19:26:20 --> Hooks Class Initialized
INFO - 2020-02-02 19:26:20 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:26:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:26:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:26:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:26:20 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:26:20 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:20 --> URI Class Initialized
INFO - 2020-02-02 19:26:20 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:26:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:20 --> Controller Class Initialized
INFO - 2020-02-02 19:26:20 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:20 --> URI Class Initialized
INFO - 2020-02-02 19:26:20 --> URI Class Initialized
INFO - 2020-02-02 19:26:20 --> URI Class Initialized
INFO - 2020-02-02 19:26:20 --> Router Class Initialized
INFO - 2020-02-02 19:26:20 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:26:20 --> Router Class Initialized
INFO - 2020-02-02 19:26:20 --> URI Class Initialized
INFO - 2020-02-02 19:26:20 --> Router Class Initialized
INFO - 2020-02-02 19:26:20 --> Router Class Initialized
INFO - 2020-02-02 19:26:20 --> Output Class Initialized
INFO - 2020-02-02 19:26:20 --> Security Class Initialized
INFO - 2020-02-02 19:26:20 --> Output Class Initialized
INFO - 2020-02-02 19:26:20 --> Helper loaded: form_helper
INFO - 2020-02-02 19:26:20 --> Output Class Initialized
INFO - 2020-02-02 19:26:20 --> Output Class Initialized
INFO - 2020-02-02 19:26:20 --> Router Class Initialized
INFO - 2020-02-02 19:26:20 --> Form Validation Class Initialized
INFO - 2020-02-02 19:26:20 --> Output Class Initialized
INFO - 2020-02-02 19:26:20 --> Security Class Initialized
INFO - 2020-02-02 19:26:20 --> Security Class Initialized
INFO - 2020-02-02 19:26:20 --> Security Class Initialized
DEBUG - 2020-02-02 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:20 --> Input Class Initialized
INFO - 2020-02-02 19:26:20 --> Security Class Initialized
DEBUG - 2020-02-02 19:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:26:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 19:26:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:26:20 --> Input Class Initialized
ERROR - 2020-02-02 19:26:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
INFO - 2020-02-02 19:26:20 --> Input Class Initialized
DEBUG - 2020-02-02 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:20 --> Input Class Initialized
INFO - 2020-02-02 19:26:20 --> Input Class Initialized
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
INFO - 2020-02-02 19:26:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
ERROR - 2020-02-02 19:26:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:26:20 --> Final output sent to browser
ERROR - 2020-02-02 19:26:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
ERROR - 2020-02-02 19:26:20 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:26:20 --> Loader Class Initialized
INFO - 2020-02-02 19:26:20 --> Config Class Initialized
INFO - 2020-02-02 19:26:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:20 --> Total execution time: 0.7660
INFO - 2020-02-02 19:26:20 --> Helper loaded: url_helper
ERROR - 2020-02-02 19:26:20 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:26:20 --> Config Class Initialized
INFO - 2020-02-02 19:26:20 --> Config Class Initialized
INFO - 2020-02-02 19:26:20 --> Hooks Class Initialized
INFO - 2020-02-02 19:26:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:20 --> Database Driver Class Initialized
INFO - 2020-02-02 19:26:20 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:26:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:26:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:26:20 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:20 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:26:20 --> URI Class Initialized
INFO - 2020-02-02 19:26:20 --> Controller Class Initialized
INFO - 2020-02-02 19:26:20 --> URI Class Initialized
INFO - 2020-02-02 19:26:20 --> URI Class Initialized
INFO - 2020-02-02 19:26:20 --> Router Class Initialized
INFO - 2020-02-02 19:26:20 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:26:20 --> Router Class Initialized
INFO - 2020-02-02 19:26:20 --> Router Class Initialized
INFO - 2020-02-02 19:26:20 --> Output Class Initialized
INFO - 2020-02-02 19:26:20 --> Security Class Initialized
INFO - 2020-02-02 19:26:20 --> Output Class Initialized
INFO - 2020-02-02 19:26:20 --> Output Class Initialized
INFO - 2020-02-02 19:26:20 --> Helper loaded: form_helper
INFO - 2020-02-02 19:26:20 --> Form Validation Class Initialized
INFO - 2020-02-02 19:26:20 --> Security Class Initialized
INFO - 2020-02-02 19:26:20 --> Security Class Initialized
DEBUG - 2020-02-02 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:20 --> Input Class Initialized
DEBUG - 2020-02-02 19:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:26:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 19:26:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:26:20 --> Input Class Initialized
INFO - 2020-02-02 19:26:20 --> Input Class Initialized
ERROR - 2020-02-02 19:26:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
INFO - 2020-02-02 19:26:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
INFO - 2020-02-02 19:26:20 --> Language Class Initialized
ERROR - 2020-02-02 19:26:20 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:26:20 --> Final output sent to browser
ERROR - 2020-02-02 19:26:20 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-02 19:26:20 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-02 19:26:20 --> Total execution time: 0.6928
INFO - 2020-02-02 19:26:20 --> Config Class Initialized
INFO - 2020-02-02 19:26:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:20 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:20 --> URI Class Initialized
INFO - 2020-02-02 19:26:20 --> Router Class Initialized
INFO - 2020-02-02 19:26:21 --> Output Class Initialized
INFO - 2020-02-02 19:26:21 --> Security Class Initialized
DEBUG - 2020-02-02 19:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:21 --> Input Class Initialized
INFO - 2020-02-02 19:26:21 --> Language Class Initialized
ERROR - 2020-02-02 19:26:21 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:26:21 --> Config Class Initialized
INFO - 2020-02-02 19:26:21 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:21 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:21 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:21 --> URI Class Initialized
INFO - 2020-02-02 19:26:21 --> Router Class Initialized
INFO - 2020-02-02 19:26:21 --> Output Class Initialized
INFO - 2020-02-02 19:26:21 --> Security Class Initialized
DEBUG - 2020-02-02 19:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:21 --> Input Class Initialized
INFO - 2020-02-02 19:26:21 --> Language Class Initialized
ERROR - 2020-02-02 19:26:21 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:26:21 --> Config Class Initialized
INFO - 2020-02-02 19:26:21 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:21 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:21 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:21 --> URI Class Initialized
INFO - 2020-02-02 19:26:21 --> Router Class Initialized
INFO - 2020-02-02 19:26:21 --> Output Class Initialized
INFO - 2020-02-02 19:26:21 --> Security Class Initialized
DEBUG - 2020-02-02 19:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:21 --> Input Class Initialized
INFO - 2020-02-02 19:26:21 --> Language Class Initialized
ERROR - 2020-02-02 19:26:21 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:26:21 --> Config Class Initialized
INFO - 2020-02-02 19:26:21 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:21 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:21 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:22 --> URI Class Initialized
INFO - 2020-02-02 19:26:22 --> Router Class Initialized
INFO - 2020-02-02 19:26:22 --> Output Class Initialized
INFO - 2020-02-02 19:26:22 --> Security Class Initialized
DEBUG - 2020-02-02 19:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:22 --> Input Class Initialized
INFO - 2020-02-02 19:26:22 --> Language Class Initialized
ERROR - 2020-02-02 19:26:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:26:22 --> Config Class Initialized
INFO - 2020-02-02 19:26:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:22 --> URI Class Initialized
INFO - 2020-02-02 19:26:22 --> Router Class Initialized
INFO - 2020-02-02 19:26:22 --> Output Class Initialized
INFO - 2020-02-02 19:26:22 --> Security Class Initialized
DEBUG - 2020-02-02 19:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:22 --> Input Class Initialized
INFO - 2020-02-02 19:26:22 --> Language Class Initialized
ERROR - 2020-02-02 19:26:22 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:26:22 --> Config Class Initialized
INFO - 2020-02-02 19:26:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:22 --> URI Class Initialized
INFO - 2020-02-02 19:26:22 --> Router Class Initialized
INFO - 2020-02-02 19:26:22 --> Output Class Initialized
INFO - 2020-02-02 19:26:22 --> Security Class Initialized
DEBUG - 2020-02-02 19:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:22 --> Input Class Initialized
INFO - 2020-02-02 19:26:22 --> Language Class Initialized
ERROR - 2020-02-02 19:26:22 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:26:22 --> Config Class Initialized
INFO - 2020-02-02 19:26:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:23 --> URI Class Initialized
INFO - 2020-02-02 19:26:23 --> Router Class Initialized
INFO - 2020-02-02 19:26:23 --> Output Class Initialized
INFO - 2020-02-02 19:26:23 --> Security Class Initialized
DEBUG - 2020-02-02 19:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:23 --> Input Class Initialized
INFO - 2020-02-02 19:26:23 --> Language Class Initialized
ERROR - 2020-02-02 19:26:23 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:26:23 --> Config Class Initialized
INFO - 2020-02-02 19:26:23 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:26:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:26:23 --> Utf8 Class Initialized
INFO - 2020-02-02 19:26:23 --> URI Class Initialized
INFO - 2020-02-02 19:26:23 --> Router Class Initialized
INFO - 2020-02-02 19:26:23 --> Output Class Initialized
INFO - 2020-02-02 19:26:23 --> Security Class Initialized
DEBUG - 2020-02-02 19:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:26:23 --> Input Class Initialized
INFO - 2020-02-02 19:26:23 --> Language Class Initialized
ERROR - 2020-02-02 19:26:23 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:27:52 --> Config Class Initialized
INFO - 2020-02-02 19:27:52 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:27:52 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:52 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:52 --> URI Class Initialized
INFO - 2020-02-02 19:27:53 --> Router Class Initialized
INFO - 2020-02-02 19:27:53 --> Output Class Initialized
INFO - 2020-02-02 19:27:53 --> Security Class Initialized
DEBUG - 2020-02-02 19:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:53 --> Input Class Initialized
INFO - 2020-02-02 19:27:53 --> Language Class Initialized
INFO - 2020-02-02 19:27:53 --> Loader Class Initialized
INFO - 2020-02-02 19:27:53 --> Helper loaded: url_helper
INFO - 2020-02-02 19:27:53 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:27:53 --> Controller Class Initialized
INFO - 2020-02-02 19:27:53 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:27:53 --> Helper loaded: form_helper
INFO - 2020-02-02 19:27:53 --> Form Validation Class Initialized
INFO - 2020-02-02 19:27:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:27:53 --> Final output sent to browser
DEBUG - 2020-02-02 19:27:53 --> Total execution time: 1.1433
INFO - 2020-02-02 19:27:53 --> Config Class Initialized
INFO - 2020-02-02 19:27:53 --> Config Class Initialized
INFO - 2020-02-02 19:27:53 --> Config Class Initialized
INFO - 2020-02-02 19:27:53 --> Config Class Initialized
INFO - 2020-02-02 19:27:53 --> Hooks Class Initialized
INFO - 2020-02-02 19:27:53 --> Hooks Class Initialized
INFO - 2020-02-02 19:27:53 --> Config Class Initialized
INFO - 2020-02-02 19:27:53 --> Config Class Initialized
INFO - 2020-02-02 19:27:53 --> Hooks Class Initialized
INFO - 2020-02-02 19:27:53 --> Hooks Class Initialized
INFO - 2020-02-02 19:27:53 --> Hooks Class Initialized
INFO - 2020-02-02 19:27:53 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:27:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:27:53 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:53 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:53 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:27:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:27:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:27:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:27:53 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:53 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:53 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:53 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:53 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:53 --> URI Class Initialized
INFO - 2020-02-02 19:27:53 --> URI Class Initialized
INFO - 2020-02-02 19:27:54 --> URI Class Initialized
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> URI Class Initialized
INFO - 2020-02-02 19:27:54 --> URI Class Initialized
INFO - 2020-02-02 19:27:54 --> URI Class Initialized
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
ERROR - 2020-02-02 19:27:54 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-02 19:27:54 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
ERROR - 2020-02-02 19:27:54 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-02 19:27:54 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:27:54 --> Loader Class Initialized
ERROR - 2020-02-02 19:27:54 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 19:27:54 --> Config Class Initialized
INFO - 2020-02-02 19:27:54 --> Config Class Initialized
INFO - 2020-02-02 19:27:54 --> Hooks Class Initialized
INFO - 2020-02-02 19:27:54 --> Hooks Class Initialized
INFO - 2020-02-02 19:27:54 --> Helper loaded: url_helper
INFO - 2020-02-02 19:27:54 --> Config Class Initialized
INFO - 2020-02-02 19:27:54 --> Config Class Initialized
INFO - 2020-02-02 19:27:54 --> Config Class Initialized
INFO - 2020-02-02 19:27:54 --> Hooks Class Initialized
INFO - 2020-02-02 19:27:54 --> Hooks Class Initialized
INFO - 2020-02-02 19:27:54 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:27:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:27:54 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:54 --> Database Driver Class Initialized
INFO - 2020-02-02 19:27:54 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:54 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:54 --> URI Class Initialized
INFO - 2020-02-02 19:27:54 --> URI Class Initialized
DEBUG - 2020-02-02 19:27:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:27:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:27:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:27:54 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:54 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:54 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> Controller Class Initialized
INFO - 2020-02-02 19:27:54 --> URI Class Initialized
INFO - 2020-02-02 19:27:54 --> URI Class Initialized
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
INFO - 2020-02-02 19:27:54 --> URI Class Initialized
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
INFO - 2020-02-02 19:27:54 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:54 --> Helper loaded: form_helper
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
INFO - 2020-02-02 19:27:54 --> Form Validation Class Initialized
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
ERROR - 2020-02-02 19:27:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
ERROR - 2020-02-02 19:27:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-02 19:27:54 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:27:54 --> Loader Class Initialized
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
INFO - 2020-02-02 19:27:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:27:54 --> Helper loaded: url_helper
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
INFO - 2020-02-02 19:27:54 --> Config Class Initialized
INFO - 2020-02-02 19:27:54 --> Hooks Class Initialized
ERROR - 2020-02-02 19:27:54 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:27:54 --> Final output sent to browser
ERROR - 2020-02-02 19:27:54 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 19:27:54 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:27:54 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:27:54 --> Total execution time: 0.7052
DEBUG - 2020-02-02 19:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-02 19:27:54 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:54 --> Config Class Initialized
INFO - 2020-02-02 19:27:54 --> Config Class Initialized
INFO - 2020-02-02 19:27:54 --> Hooks Class Initialized
INFO - 2020-02-02 19:27:54 --> Hooks Class Initialized
INFO - 2020-02-02 19:27:54 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:27:54 --> Controller Class Initialized
INFO - 2020-02-02 19:27:54 --> URI Class Initialized
DEBUG - 2020-02-02 19:27:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:27:54 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:54 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:54 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:27:54 --> URI Class Initialized
INFO - 2020-02-02 19:27:54 --> URI Class Initialized
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
INFO - 2020-02-02 19:27:54 --> Helper loaded: form_helper
INFO - 2020-02-02 19:27:54 --> Form Validation Class Initialized
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> Router Class Initialized
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:54 --> Output Class Initialized
ERROR - 2020-02-02 19:27:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
ERROR - 2020-02-02 19:27:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
INFO - 2020-02-02 19:27:54 --> Security Class Initialized
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
INFO - 2020-02-02 19:27:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:54 --> Final output sent to browser
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
ERROR - 2020-02-02 19:27:54 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:27:54 --> Input Class Initialized
DEBUG - 2020-02-02 19:27:54 --> Total execution time: 0.6730
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
INFO - 2020-02-02 19:27:54 --> Language Class Initialized
ERROR - 2020-02-02 19:27:54 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-02 19:27:54 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:27:55 --> Config Class Initialized
INFO - 2020-02-02 19:27:55 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:27:55 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:55 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:55 --> URI Class Initialized
INFO - 2020-02-02 19:27:55 --> Router Class Initialized
INFO - 2020-02-02 19:27:55 --> Output Class Initialized
INFO - 2020-02-02 19:27:55 --> Security Class Initialized
DEBUG - 2020-02-02 19:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:55 --> Input Class Initialized
INFO - 2020-02-02 19:27:55 --> Language Class Initialized
ERROR - 2020-02-02 19:27:55 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:27:55 --> Config Class Initialized
INFO - 2020-02-02 19:27:55 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:27:55 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:55 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:55 --> URI Class Initialized
INFO - 2020-02-02 19:27:55 --> Router Class Initialized
INFO - 2020-02-02 19:27:55 --> Output Class Initialized
INFO - 2020-02-02 19:27:55 --> Security Class Initialized
DEBUG - 2020-02-02 19:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:55 --> Input Class Initialized
INFO - 2020-02-02 19:27:55 --> Language Class Initialized
ERROR - 2020-02-02 19:27:55 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:27:55 --> Config Class Initialized
INFO - 2020-02-02 19:27:55 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:27:55 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:55 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:55 --> URI Class Initialized
INFO - 2020-02-02 19:27:55 --> Router Class Initialized
INFO - 2020-02-02 19:27:55 --> Output Class Initialized
INFO - 2020-02-02 19:27:55 --> Security Class Initialized
DEBUG - 2020-02-02 19:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:55 --> Input Class Initialized
INFO - 2020-02-02 19:27:55 --> Language Class Initialized
ERROR - 2020-02-02 19:27:55 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:27:55 --> Config Class Initialized
INFO - 2020-02-02 19:27:56 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:27:56 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:56 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:56 --> URI Class Initialized
INFO - 2020-02-02 19:27:56 --> Router Class Initialized
INFO - 2020-02-02 19:27:56 --> Output Class Initialized
INFO - 2020-02-02 19:27:56 --> Security Class Initialized
DEBUG - 2020-02-02 19:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:56 --> Input Class Initialized
INFO - 2020-02-02 19:27:56 --> Language Class Initialized
ERROR - 2020-02-02 19:27:56 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:27:56 --> Config Class Initialized
INFO - 2020-02-02 19:27:56 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:27:56 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:56 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:56 --> URI Class Initialized
INFO - 2020-02-02 19:27:56 --> Router Class Initialized
INFO - 2020-02-02 19:27:56 --> Output Class Initialized
INFO - 2020-02-02 19:27:56 --> Security Class Initialized
DEBUG - 2020-02-02 19:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:56 --> Input Class Initialized
INFO - 2020-02-02 19:27:56 --> Language Class Initialized
ERROR - 2020-02-02 19:27:56 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:27:56 --> Config Class Initialized
INFO - 2020-02-02 19:27:56 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:27:56 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:56 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:56 --> URI Class Initialized
INFO - 2020-02-02 19:27:56 --> Router Class Initialized
INFO - 2020-02-02 19:27:56 --> Output Class Initialized
INFO - 2020-02-02 19:27:56 --> Security Class Initialized
DEBUG - 2020-02-02 19:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:56 --> Input Class Initialized
INFO - 2020-02-02 19:27:56 --> Language Class Initialized
ERROR - 2020-02-02 19:27:56 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:27:57 --> Config Class Initialized
INFO - 2020-02-02 19:27:57 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:27:57 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:57 --> URI Class Initialized
INFO - 2020-02-02 19:27:57 --> Router Class Initialized
INFO - 2020-02-02 19:27:57 --> Output Class Initialized
INFO - 2020-02-02 19:27:57 --> Security Class Initialized
DEBUG - 2020-02-02 19:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:57 --> Input Class Initialized
INFO - 2020-02-02 19:27:57 --> Language Class Initialized
ERROR - 2020-02-02 19:27:57 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:27:57 --> Config Class Initialized
INFO - 2020-02-02 19:27:57 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:27:57 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:27:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:27:57 --> URI Class Initialized
INFO - 2020-02-02 19:27:57 --> Router Class Initialized
INFO - 2020-02-02 19:27:57 --> Output Class Initialized
INFO - 2020-02-02 19:27:57 --> Security Class Initialized
DEBUG - 2020-02-02 19:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:27:57 --> Input Class Initialized
INFO - 2020-02-02 19:27:57 --> Language Class Initialized
ERROR - 2020-02-02 19:27:57 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:28:38 --> Config Class Initialized
INFO - 2020-02-02 19:28:38 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:28:38 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:38 --> URI Class Initialized
INFO - 2020-02-02 19:28:38 --> Router Class Initialized
INFO - 2020-02-02 19:28:38 --> Output Class Initialized
INFO - 2020-02-02 19:28:38 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:38 --> Input Class Initialized
INFO - 2020-02-02 19:28:38 --> Language Class Initialized
INFO - 2020-02-02 19:28:38 --> Loader Class Initialized
INFO - 2020-02-02 19:28:38 --> Helper loaded: url_helper
INFO - 2020-02-02 19:28:39 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:28:39 --> Controller Class Initialized
INFO - 2020-02-02 19:28:39 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:28:39 --> Helper loaded: form_helper
INFO - 2020-02-02 19:28:39 --> Form Validation Class Initialized
INFO - 2020-02-02 19:28:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:28:39 --> Final output sent to browser
INFO - 2020-02-02 19:28:39 --> Config Class Initialized
INFO - 2020-02-02 19:28:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:28:39 --> Total execution time: 1.3477
INFO - 2020-02-02 19:28:39 --> Config Class Initialized
INFO - 2020-02-02 19:28:39 --> Config Class Initialized
INFO - 2020-02-02 19:28:39 --> Hooks Class Initialized
INFO - 2020-02-02 19:28:39 --> Config Class Initialized
DEBUG - 2020-02-02 19:28:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:39 --> Config Class Initialized
INFO - 2020-02-02 19:28:39 --> Hooks Class Initialized
INFO - 2020-02-02 19:28:39 --> Config Class Initialized
INFO - 2020-02-02 19:28:39 --> Hooks Class Initialized
INFO - 2020-02-02 19:28:39 --> Hooks Class Initialized
INFO - 2020-02-02 19:28:39 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:28:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:28:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:39 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:39 --> URI Class Initialized
INFO - 2020-02-02 19:28:39 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:28:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:28:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:28:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:39 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:39 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:39 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:39 --> URI Class Initialized
INFO - 2020-02-02 19:28:39 --> URI Class Initialized
INFO - 2020-02-02 19:28:39 --> Router Class Initialized
INFO - 2020-02-02 19:28:39 --> URI Class Initialized
INFO - 2020-02-02 19:28:39 --> URI Class Initialized
INFO - 2020-02-02 19:28:39 --> URI Class Initialized
INFO - 2020-02-02 19:28:39 --> Router Class Initialized
INFO - 2020-02-02 19:28:39 --> Router Class Initialized
INFO - 2020-02-02 19:28:39 --> Output Class Initialized
INFO - 2020-02-02 19:28:39 --> Router Class Initialized
INFO - 2020-02-02 19:28:39 --> Router Class Initialized
INFO - 2020-02-02 19:28:39 --> Output Class Initialized
INFO - 2020-02-02 19:28:39 --> Router Class Initialized
INFO - 2020-02-02 19:28:39 --> Output Class Initialized
INFO - 2020-02-02 19:28:39 --> Security Class Initialized
INFO - 2020-02-02 19:28:39 --> Security Class Initialized
INFO - 2020-02-02 19:28:39 --> Output Class Initialized
INFO - 2020-02-02 19:28:39 --> Output Class Initialized
INFO - 2020-02-02 19:28:39 --> Output Class Initialized
INFO - 2020-02-02 19:28:39 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:39 --> Input Class Initialized
INFO - 2020-02-02 19:28:39 --> Security Class Initialized
INFO - 2020-02-02 19:28:39 --> Security Class Initialized
INFO - 2020-02-02 19:28:39 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:39 --> Input Class Initialized
INFO - 2020-02-02 19:28:39 --> Language Class Initialized
INFO - 2020-02-02 19:28:39 --> Input Class Initialized
INFO - 2020-02-02 19:28:39 --> Input Class Initialized
INFO - 2020-02-02 19:28:39 --> Input Class Initialized
INFO - 2020-02-02 19:28:39 --> Input Class Initialized
INFO - 2020-02-02 19:28:39 --> Language Class Initialized
ERROR - 2020-02-02 19:28:39 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 19:28:39 --> Language Class Initialized
INFO - 2020-02-02 19:28:39 --> Language Class Initialized
INFO - 2020-02-02 19:28:39 --> Language Class Initialized
ERROR - 2020-02-02 19:28:39 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:28:39 --> Language Class Initialized
ERROR - 2020-02-02 19:28:39 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:28:39 --> Config Class Initialized
INFO - 2020-02-02 19:28:39 --> Hooks Class Initialized
ERROR - 2020-02-02 19:28:39 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 19:28:39 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-02 19:28:39 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:28:39 --> Config Class Initialized
INFO - 2020-02-02 19:28:39 --> Config Class Initialized
INFO - 2020-02-02 19:28:39 --> Hooks Class Initialized
INFO - 2020-02-02 19:28:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:28:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:39 --> Config Class Initialized
INFO - 2020-02-02 19:28:39 --> Config Class Initialized
INFO - 2020-02-02 19:28:39 --> Config Class Initialized
INFO - 2020-02-02 19:28:39 --> Hooks Class Initialized
INFO - 2020-02-02 19:28:39 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:39 --> Hooks Class Initialized
INFO - 2020-02-02 19:28:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:28:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:28:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:40 --> URI Class Initialized
DEBUG - 2020-02-02 19:28:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:28:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:28:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:40 --> URI Class Initialized
INFO - 2020-02-02 19:28:40 --> URI Class Initialized
INFO - 2020-02-02 19:28:40 --> Router Class Initialized
INFO - 2020-02-02 19:28:40 --> URI Class Initialized
INFO - 2020-02-02 19:28:40 --> Router Class Initialized
INFO - 2020-02-02 19:28:40 --> Router Class Initialized
INFO - 2020-02-02 19:28:40 --> Output Class Initialized
INFO - 2020-02-02 19:28:40 --> URI Class Initialized
INFO - 2020-02-02 19:28:40 --> URI Class Initialized
INFO - 2020-02-02 19:28:40 --> Output Class Initialized
INFO - 2020-02-02 19:28:40 --> Router Class Initialized
INFO - 2020-02-02 19:28:40 --> Router Class Initialized
INFO - 2020-02-02 19:28:40 --> Router Class Initialized
INFO - 2020-02-02 19:28:40 --> Security Class Initialized
INFO - 2020-02-02 19:28:40 --> Output Class Initialized
INFO - 2020-02-02 19:28:40 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:40 --> Output Class Initialized
INFO - 2020-02-02 19:28:40 --> Output Class Initialized
INFO - 2020-02-02 19:28:40 --> Security Class Initialized
INFO - 2020-02-02 19:28:40 --> Output Class Initialized
INFO - 2020-02-02 19:28:40 --> Input Class Initialized
INFO - 2020-02-02 19:28:40 --> Security Class Initialized
INFO - 2020-02-02 19:28:40 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:40 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:40 --> Input Class Initialized
INFO - 2020-02-02 19:28:40 --> Input Class Initialized
INFO - 2020-02-02 19:28:40 --> Language Class Initialized
DEBUG - 2020-02-02 19:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:40 --> Input Class Initialized
INFO - 2020-02-02 19:28:40 --> Input Class Initialized
INFO - 2020-02-02 19:28:40 --> Input Class Initialized
INFO - 2020-02-02 19:28:40 --> Language Class Initialized
INFO - 2020-02-02 19:28:40 --> Language Class Initialized
ERROR - 2020-02-02 19:28:40 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:28:40 --> Language Class Initialized
INFO - 2020-02-02 19:28:40 --> Language Class Initialized
INFO - 2020-02-02 19:28:40 --> Language Class Initialized
ERROR - 2020-02-02 19:28:40 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-02 19:28:40 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:28:40 --> Config Class Initialized
INFO - 2020-02-02 19:28:40 --> Hooks Class Initialized
ERROR - 2020-02-02 19:28:40 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:28:40 --> Loader Class Initialized
INFO - 2020-02-02 19:28:40 --> Loader Class Initialized
INFO - 2020-02-02 19:28:40 --> Config Class Initialized
INFO - 2020-02-02 19:28:40 --> Hooks Class Initialized
INFO - 2020-02-02 19:28:40 --> Helper loaded: url_helper
INFO - 2020-02-02 19:28:40 --> Helper loaded: url_helper
DEBUG - 2020-02-02 19:28:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:40 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:28:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:40 --> Database Driver Class Initialized
INFO - 2020-02-02 19:28:40 --> Database Driver Class Initialized
INFO - 2020-02-02 19:28:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:40 --> URI Class Initialized
DEBUG - 2020-02-02 19:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-02 19:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:28:40 --> URI Class Initialized
INFO - 2020-02-02 19:28:40 --> Router Class Initialized
INFO - 2020-02-02 19:28:40 --> Controller Class Initialized
INFO - 2020-02-02 19:28:40 --> Router Class Initialized
INFO - 2020-02-02 19:28:40 --> Output Class Initialized
INFO - 2020-02-02 19:28:40 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:28:40 --> Security Class Initialized
INFO - 2020-02-02 19:28:40 --> Output Class Initialized
INFO - 2020-02-02 19:28:40 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:40 --> Helper loaded: form_helper
INFO - 2020-02-02 19:28:40 --> Form Validation Class Initialized
INFO - 2020-02-02 19:28:40 --> Input Class Initialized
DEBUG - 2020-02-02 19:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:40 --> Input Class Initialized
INFO - 2020-02-02 19:28:40 --> Language Class Initialized
ERROR - 2020-02-02 19:28:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 19:28:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:28:40 --> Language Class Initialized
ERROR - 2020-02-02 19:28:40 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:28:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-02 19:28:40 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:28:40 --> Final output sent to browser
INFO - 2020-02-02 19:28:40 --> Config Class Initialized
INFO - 2020-02-02 19:28:40 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:28:40 --> Total execution time: 0.6548
INFO - 2020-02-02 19:28:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-02 19:28:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:40 --> Controller Class Initialized
INFO - 2020-02-02 19:28:40 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:28:40 --> URI Class Initialized
INFO - 2020-02-02 19:28:40 --> Router Class Initialized
INFO - 2020-02-02 19:28:40 --> Helper loaded: form_helper
INFO - 2020-02-02 19:28:40 --> Form Validation Class Initialized
INFO - 2020-02-02 19:28:40 --> Output Class Initialized
INFO - 2020-02-02 19:28:40 --> Security Class Initialized
ERROR - 2020-02-02 19:28:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 19:28:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-02 19:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:40 --> Input Class Initialized
INFO - 2020-02-02 19:28:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:28:40 --> Final output sent to browser
INFO - 2020-02-02 19:28:40 --> Language Class Initialized
DEBUG - 2020-02-02 19:28:40 --> Total execution time: 0.8981
ERROR - 2020-02-02 19:28:40 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:28:40 --> Config Class Initialized
INFO - 2020-02-02 19:28:40 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:28:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:41 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:41 --> URI Class Initialized
INFO - 2020-02-02 19:28:41 --> Router Class Initialized
INFO - 2020-02-02 19:28:41 --> Output Class Initialized
INFO - 2020-02-02 19:28:41 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:41 --> Input Class Initialized
INFO - 2020-02-02 19:28:41 --> Language Class Initialized
ERROR - 2020-02-02 19:28:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:28:41 --> Config Class Initialized
INFO - 2020-02-02 19:28:41 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:28:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:41 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:41 --> URI Class Initialized
INFO - 2020-02-02 19:28:41 --> Router Class Initialized
INFO - 2020-02-02 19:28:41 --> Output Class Initialized
INFO - 2020-02-02 19:28:41 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:41 --> Input Class Initialized
INFO - 2020-02-02 19:28:41 --> Language Class Initialized
ERROR - 2020-02-02 19:28:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:28:41 --> Config Class Initialized
INFO - 2020-02-02 19:28:41 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:28:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:41 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:41 --> URI Class Initialized
INFO - 2020-02-02 19:28:41 --> Router Class Initialized
INFO - 2020-02-02 19:28:41 --> Output Class Initialized
INFO - 2020-02-02 19:28:41 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:41 --> Input Class Initialized
INFO - 2020-02-02 19:28:41 --> Language Class Initialized
ERROR - 2020-02-02 19:28:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:28:42 --> Config Class Initialized
INFO - 2020-02-02 19:28:42 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:28:42 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:42 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:42 --> URI Class Initialized
INFO - 2020-02-02 19:28:42 --> Router Class Initialized
INFO - 2020-02-02 19:28:42 --> Output Class Initialized
INFO - 2020-02-02 19:28:42 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:42 --> Input Class Initialized
INFO - 2020-02-02 19:28:42 --> Language Class Initialized
ERROR - 2020-02-02 19:28:42 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:28:42 --> Config Class Initialized
INFO - 2020-02-02 19:28:42 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:28:42 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:42 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:42 --> URI Class Initialized
INFO - 2020-02-02 19:28:42 --> Router Class Initialized
INFO - 2020-02-02 19:28:42 --> Output Class Initialized
INFO - 2020-02-02 19:28:42 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:42 --> Input Class Initialized
INFO - 2020-02-02 19:28:42 --> Language Class Initialized
ERROR - 2020-02-02 19:28:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:28:42 --> Config Class Initialized
INFO - 2020-02-02 19:28:42 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:28:42 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:42 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:42 --> URI Class Initialized
INFO - 2020-02-02 19:28:42 --> Router Class Initialized
INFO - 2020-02-02 19:28:42 --> Output Class Initialized
INFO - 2020-02-02 19:28:42 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:42 --> Input Class Initialized
INFO - 2020-02-02 19:28:42 --> Language Class Initialized
ERROR - 2020-02-02 19:28:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:28:43 --> Config Class Initialized
INFO - 2020-02-02 19:28:43 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:28:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:28:43 --> Utf8 Class Initialized
INFO - 2020-02-02 19:28:43 --> URI Class Initialized
INFO - 2020-02-02 19:28:43 --> Router Class Initialized
INFO - 2020-02-02 19:28:43 --> Output Class Initialized
INFO - 2020-02-02 19:28:43 --> Security Class Initialized
DEBUG - 2020-02-02 19:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:28:43 --> Input Class Initialized
INFO - 2020-02-02 19:28:43 --> Language Class Initialized
ERROR - 2020-02-02 19:28:43 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:29:15 --> Config Class Initialized
INFO - 2020-02-02 19:29:15 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:29:15 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:16 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:16 --> URI Class Initialized
INFO - 2020-02-02 19:29:16 --> Router Class Initialized
INFO - 2020-02-02 19:29:16 --> Output Class Initialized
INFO - 2020-02-02 19:29:16 --> Security Class Initialized
DEBUG - 2020-02-02 19:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:16 --> Input Class Initialized
INFO - 2020-02-02 19:29:16 --> Language Class Initialized
INFO - 2020-02-02 19:29:16 --> Loader Class Initialized
INFO - 2020-02-02 19:29:16 --> Helper loaded: url_helper
INFO - 2020-02-02 19:29:16 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:29:16 --> Controller Class Initialized
INFO - 2020-02-02 19:29:16 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:29:16 --> Helper loaded: form_helper
INFO - 2020-02-02 19:29:16 --> Form Validation Class Initialized
INFO - 2020-02-02 19:29:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:29:16 --> Final output sent to browser
DEBUG - 2020-02-02 19:29:16 --> Total execution time: 1.1635
INFO - 2020-02-02 19:29:16 --> Config Class Initialized
INFO - 2020-02-02 19:29:16 --> Config Class Initialized
INFO - 2020-02-02 19:29:17 --> Config Class Initialized
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
INFO - 2020-02-02 19:29:17 --> Config Class Initialized
INFO - 2020-02-02 19:29:17 --> Config Class Initialized
INFO - 2020-02-02 19:29:17 --> Config Class Initialized
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:17 --> URI Class Initialized
INFO - 2020-02-02 19:29:17 --> URI Class Initialized
INFO - 2020-02-02 19:29:17 --> URI Class Initialized
INFO - 2020-02-02 19:29:17 --> URI Class Initialized
INFO - 2020-02-02 19:29:17 --> URI Class Initialized
INFO - 2020-02-02 19:29:17 --> Router Class Initialized
INFO - 2020-02-02 19:29:17 --> Router Class Initialized
INFO - 2020-02-02 19:29:17 --> Router Class Initialized
INFO - 2020-02-02 19:29:17 --> URI Class Initialized
INFO - 2020-02-02 19:29:17 --> Router Class Initialized
INFO - 2020-02-02 19:29:17 --> Output Class Initialized
INFO - 2020-02-02 19:29:17 --> Router Class Initialized
INFO - 2020-02-02 19:29:17 --> Output Class Initialized
INFO - 2020-02-02 19:29:17 --> Output Class Initialized
INFO - 2020-02-02 19:29:17 --> Router Class Initialized
INFO - 2020-02-02 19:29:17 --> Security Class Initialized
INFO - 2020-02-02 19:29:17 --> Output Class Initialized
INFO - 2020-02-02 19:29:17 --> Security Class Initialized
INFO - 2020-02-02 19:29:17 --> Output Class Initialized
INFO - 2020-02-02 19:29:17 --> Security Class Initialized
INFO - 2020-02-02 19:29:17 --> Output Class Initialized
DEBUG - 2020-02-02 19:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:17 --> Security Class Initialized
INFO - 2020-02-02 19:29:17 --> Security Class Initialized
INFO - 2020-02-02 19:29:17 --> Security Class Initialized
INFO - 2020-02-02 19:29:17 --> Input Class Initialized
INFO - 2020-02-02 19:29:17 --> Input Class Initialized
INFO - 2020-02-02 19:29:17 --> Input Class Initialized
DEBUG - 2020-02-02 19:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:17 --> Input Class Initialized
INFO - 2020-02-02 19:29:17 --> Input Class Initialized
INFO - 2020-02-02 19:29:17 --> Input Class Initialized
INFO - 2020-02-02 19:29:17 --> Language Class Initialized
INFO - 2020-02-02 19:29:17 --> Language Class Initialized
INFO - 2020-02-02 19:29:17 --> Language Class Initialized
INFO - 2020-02-02 19:29:17 --> Language Class Initialized
INFO - 2020-02-02 19:29:17 --> Language Class Initialized
ERROR - 2020-02-02 19:29:17 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:29:17 --> Loader Class Initialized
INFO - 2020-02-02 19:29:17 --> Language Class Initialized
INFO - 2020-02-02 19:29:17 --> Loader Class Initialized
ERROR - 2020-02-02 19:29:17 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-02 19:29:17 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-02 19:29:17 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 19:29:17 --> Helper loaded: url_helper
INFO - 2020-02-02 19:29:17 --> Helper loaded: url_helper
INFO - 2020-02-02 19:29:17 --> Config Class Initialized
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
INFO - 2020-02-02 19:29:17 --> Database Driver Class Initialized
INFO - 2020-02-02 19:29:17 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:17 --> Config Class Initialized
INFO - 2020-02-02 19:29:17 --> Config Class Initialized
INFO - 2020-02-02 19:29:17 --> Config Class Initialized
DEBUG - 2020-02-02 19:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
INFO - 2020-02-02 19:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:29:17 --> Controller Class Initialized
INFO - 2020-02-02 19:29:17 --> URI Class Initialized
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:17 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:29:17 --> Router Class Initialized
INFO - 2020-02-02 19:29:17 --> URI Class Initialized
INFO - 2020-02-02 19:29:17 --> URI Class Initialized
INFO - 2020-02-02 19:29:17 --> Output Class Initialized
INFO - 2020-02-02 19:29:17 --> URI Class Initialized
INFO - 2020-02-02 19:29:17 --> Helper loaded: form_helper
INFO - 2020-02-02 19:29:17 --> Form Validation Class Initialized
INFO - 2020-02-02 19:29:17 --> Router Class Initialized
INFO - 2020-02-02 19:29:17 --> Security Class Initialized
INFO - 2020-02-02 19:29:17 --> Router Class Initialized
INFO - 2020-02-02 19:29:17 --> Router Class Initialized
DEBUG - 2020-02-02 19:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:17 --> Output Class Initialized
INFO - 2020-02-02 19:29:17 --> Output Class Initialized
INFO - 2020-02-02 19:29:17 --> Output Class Initialized
ERROR - 2020-02-02 19:29:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:29:17 --> Input Class Initialized
INFO - 2020-02-02 19:29:17 --> Security Class Initialized
INFO - 2020-02-02 19:29:17 --> Security Class Initialized
INFO - 2020-02-02 19:29:17 --> Security Class Initialized
ERROR - 2020-02-02 19:29:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:29:17 --> Language Class Initialized
INFO - 2020-02-02 19:29:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-02 19:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:17 --> Input Class Initialized
INFO - 2020-02-02 19:29:17 --> Input Class Initialized
INFO - 2020-02-02 19:29:17 --> Input Class Initialized
INFO - 2020-02-02 19:29:17 --> Final output sent to browser
ERROR - 2020-02-02 19:29:17 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-02 19:29:17 --> Total execution time: 0.7562
INFO - 2020-02-02 19:29:17 --> Language Class Initialized
INFO - 2020-02-02 19:29:17 --> Language Class Initialized
INFO - 2020-02-02 19:29:17 --> Language Class Initialized
INFO - 2020-02-02 19:29:17 --> Config Class Initialized
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
INFO - 2020-02-02 19:29:17 --> Session: Class initialized using 'files' driver.
ERROR - 2020-02-02 19:29:17 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 19:29:17 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-02 19:29:17 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:29:17 --> Config Class Initialized
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
INFO - 2020-02-02 19:29:17 --> Controller Class Initialized
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:17 --> Config Class Initialized
INFO - 2020-02-02 19:29:17 --> Config Class Initialized
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:17 --> Hooks Class Initialized
INFO - 2020-02-02 19:29:17 --> Model "M_tiket" initialized
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:17 --> URI Class Initialized
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:17 --> Helper loaded: form_helper
DEBUG - 2020-02-02 19:29:17 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:17 --> Form Validation Class Initialized
INFO - 2020-02-02 19:29:17 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:17 --> URI Class Initialized
INFO - 2020-02-02 19:29:17 --> Router Class Initialized
INFO - 2020-02-02 19:29:17 --> URI Class Initialized
INFO - 2020-02-02 19:29:17 --> Router Class Initialized
INFO - 2020-02-02 19:29:18 --> Output Class Initialized
INFO - 2020-02-02 19:29:18 --> URI Class Initialized
ERROR - 2020-02-02 19:29:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:29:18 --> Security Class Initialized
INFO - 2020-02-02 19:29:18 --> Router Class Initialized
ERROR - 2020-02-02 19:29:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:29:18 --> Output Class Initialized
INFO - 2020-02-02 19:29:18 --> Router Class Initialized
DEBUG - 2020-02-02 19:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:18 --> Output Class Initialized
INFO - 2020-02-02 19:29:18 --> Output Class Initialized
INFO - 2020-02-02 19:29:18 --> Security Class Initialized
INFO - 2020-02-02 19:29:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:29:18 --> Input Class Initialized
INFO - 2020-02-02 19:29:18 --> Final output sent to browser
INFO - 2020-02-02 19:29:18 --> Security Class Initialized
INFO - 2020-02-02 19:29:18 --> Security Class Initialized
DEBUG - 2020-02-02 19:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:18 --> Input Class Initialized
DEBUG - 2020-02-02 19:29:18 --> Total execution time: 1.1047
INFO - 2020-02-02 19:29:18 --> Language Class Initialized
DEBUG - 2020-02-02 19:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:18 --> Input Class Initialized
INFO - 2020-02-02 19:29:18 --> Input Class Initialized
ERROR - 2020-02-02 19:29:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:29:18 --> Language Class Initialized
INFO - 2020-02-02 19:29:18 --> Language Class Initialized
INFO - 2020-02-02 19:29:18 --> Language Class Initialized
ERROR - 2020-02-02 19:29:18 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-02 19:29:18 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-02 19:29:18 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:29:18 --> Config Class Initialized
INFO - 2020-02-02 19:29:18 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:29:18 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:18 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:18 --> URI Class Initialized
INFO - 2020-02-02 19:29:18 --> Router Class Initialized
INFO - 2020-02-02 19:29:18 --> Output Class Initialized
INFO - 2020-02-02 19:29:18 --> Security Class Initialized
DEBUG - 2020-02-02 19:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:18 --> Input Class Initialized
INFO - 2020-02-02 19:29:19 --> Language Class Initialized
ERROR - 2020-02-02 19:29:19 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:29:19 --> Config Class Initialized
INFO - 2020-02-02 19:29:19 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:29:19 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:19 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:19 --> URI Class Initialized
INFO - 2020-02-02 19:29:19 --> Router Class Initialized
INFO - 2020-02-02 19:29:19 --> Output Class Initialized
INFO - 2020-02-02 19:29:19 --> Security Class Initialized
DEBUG - 2020-02-02 19:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:19 --> Input Class Initialized
INFO - 2020-02-02 19:29:19 --> Language Class Initialized
ERROR - 2020-02-02 19:29:19 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:29:19 --> Config Class Initialized
INFO - 2020-02-02 19:29:19 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:29:19 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:19 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:19 --> URI Class Initialized
INFO - 2020-02-02 19:29:20 --> Router Class Initialized
INFO - 2020-02-02 19:29:20 --> Output Class Initialized
INFO - 2020-02-02 19:29:20 --> Security Class Initialized
DEBUG - 2020-02-02 19:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:20 --> Input Class Initialized
INFO - 2020-02-02 19:29:20 --> Language Class Initialized
ERROR - 2020-02-02 19:29:20 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:29:20 --> Config Class Initialized
INFO - 2020-02-02 19:29:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:29:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:20 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:20 --> URI Class Initialized
INFO - 2020-02-02 19:29:20 --> Router Class Initialized
INFO - 2020-02-02 19:29:20 --> Output Class Initialized
INFO - 2020-02-02 19:29:20 --> Security Class Initialized
DEBUG - 2020-02-02 19:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:20 --> Input Class Initialized
INFO - 2020-02-02 19:29:20 --> Language Class Initialized
ERROR - 2020-02-02 19:29:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:29:20 --> Config Class Initialized
INFO - 2020-02-02 19:29:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:29:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:20 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:20 --> URI Class Initialized
INFO - 2020-02-02 19:29:20 --> Router Class Initialized
INFO - 2020-02-02 19:29:20 --> Output Class Initialized
INFO - 2020-02-02 19:29:20 --> Security Class Initialized
DEBUG - 2020-02-02 19:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:20 --> Input Class Initialized
INFO - 2020-02-02 19:29:20 --> Language Class Initialized
ERROR - 2020-02-02 19:29:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:29:20 --> Config Class Initialized
INFO - 2020-02-02 19:29:21 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:29:21 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:21 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:21 --> URI Class Initialized
INFO - 2020-02-02 19:29:21 --> Router Class Initialized
INFO - 2020-02-02 19:29:21 --> Output Class Initialized
INFO - 2020-02-02 19:29:21 --> Security Class Initialized
DEBUG - 2020-02-02 19:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:21 --> Input Class Initialized
INFO - 2020-02-02 19:29:21 --> Language Class Initialized
ERROR - 2020-02-02 19:29:21 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:29:21 --> Config Class Initialized
INFO - 2020-02-02 19:29:21 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:29:21 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:21 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:21 --> URI Class Initialized
INFO - 2020-02-02 19:29:21 --> Router Class Initialized
INFO - 2020-02-02 19:29:21 --> Output Class Initialized
INFO - 2020-02-02 19:29:21 --> Security Class Initialized
DEBUG - 2020-02-02 19:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:21 --> Input Class Initialized
INFO - 2020-02-02 19:29:21 --> Language Class Initialized
ERROR - 2020-02-02 19:29:21 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:29:21 --> Config Class Initialized
INFO - 2020-02-02 19:29:21 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:29:21 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:21 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:21 --> URI Class Initialized
INFO - 2020-02-02 19:29:21 --> Router Class Initialized
INFO - 2020-02-02 19:29:21 --> Output Class Initialized
INFO - 2020-02-02 19:29:21 --> Security Class Initialized
DEBUG - 2020-02-02 19:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:21 --> Input Class Initialized
INFO - 2020-02-02 19:29:21 --> Language Class Initialized
ERROR - 2020-02-02 19:29:22 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:29:22 --> Config Class Initialized
INFO - 2020-02-02 19:29:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:29:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:29:22 --> Utf8 Class Initialized
INFO - 2020-02-02 19:29:22 --> URI Class Initialized
INFO - 2020-02-02 19:29:22 --> Router Class Initialized
INFO - 2020-02-02 19:29:22 --> Output Class Initialized
INFO - 2020-02-02 19:29:22 --> Security Class Initialized
DEBUG - 2020-02-02 19:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:29:22 --> Input Class Initialized
INFO - 2020-02-02 19:29:22 --> Language Class Initialized
ERROR - 2020-02-02 19:29:22 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:50:35 --> Config Class Initialized
INFO - 2020-02-02 19:50:35 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:50:35 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:35 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:35 --> URI Class Initialized
INFO - 2020-02-02 19:50:35 --> Router Class Initialized
INFO - 2020-02-02 19:50:35 --> Output Class Initialized
INFO - 2020-02-02 19:50:35 --> Security Class Initialized
DEBUG - 2020-02-02 19:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:36 --> Input Class Initialized
INFO - 2020-02-02 19:50:36 --> Language Class Initialized
INFO - 2020-02-02 19:50:36 --> Loader Class Initialized
INFO - 2020-02-02 19:50:36 --> Helper loaded: url_helper
INFO - 2020-02-02 19:50:36 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:50:36 --> Controller Class Initialized
INFO - 2020-02-02 19:50:36 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:50:36 --> Helper loaded: form_helper
INFO - 2020-02-02 19:50:36 --> Form Validation Class Initialized
INFO - 2020-02-02 19:50:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:50:36 --> Final output sent to browser
INFO - 2020-02-02 19:50:36 --> Config Class Initialized
INFO - 2020-02-02 19:50:36 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:50:36 --> Total execution time: 0.9108
INFO - 2020-02-02 19:50:36 --> Config Class Initialized
INFO - 2020-02-02 19:50:36 --> Config Class Initialized
INFO - 2020-02-02 19:50:36 --> Config Class Initialized
DEBUG - 2020-02-02 19:50:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:36 --> Config Class Initialized
INFO - 2020-02-02 19:50:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:50:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:50:36 --> Config Class Initialized
INFO - 2020-02-02 19:50:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:50:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:50:36 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:50:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:36 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:50:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:50:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:50:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:36 --> URI Class Initialized
DEBUG - 2020-02-02 19:50:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:36 --> URI Class Initialized
INFO - 2020-02-02 19:50:36 --> URI Class Initialized
INFO - 2020-02-02 19:50:36 --> URI Class Initialized
INFO - 2020-02-02 19:50:36 --> Router Class Initialized
INFO - 2020-02-02 19:50:36 --> URI Class Initialized
INFO - 2020-02-02 19:50:36 --> Router Class Initialized
INFO - 2020-02-02 19:50:36 --> Router Class Initialized
INFO - 2020-02-02 19:50:36 --> Router Class Initialized
INFO - 2020-02-02 19:50:36 --> URI Class Initialized
INFO - 2020-02-02 19:50:36 --> Router Class Initialized
INFO - 2020-02-02 19:50:36 --> Output Class Initialized
INFO - 2020-02-02 19:50:36 --> Router Class Initialized
INFO - 2020-02-02 19:50:36 --> Output Class Initialized
INFO - 2020-02-02 19:50:36 --> Output Class Initialized
INFO - 2020-02-02 19:50:36 --> Output Class Initialized
INFO - 2020-02-02 19:50:36 --> Security Class Initialized
INFO - 2020-02-02 19:50:36 --> Output Class Initialized
INFO - 2020-02-02 19:50:36 --> Security Class Initialized
DEBUG - 2020-02-02 19:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:36 --> Security Class Initialized
INFO - 2020-02-02 19:50:36 --> Security Class Initialized
INFO - 2020-02-02 19:50:36 --> Security Class Initialized
INFO - 2020-02-02 19:50:36 --> Output Class Initialized
DEBUG - 2020-02-02 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:37 --> Security Class Initialized
DEBUG - 2020-02-02 19:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:37 --> Input Class Initialized
DEBUG - 2020-02-02 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:37 --> Input Class Initialized
INFO - 2020-02-02 19:50:37 --> Input Class Initialized
INFO - 2020-02-02 19:50:37 --> Input Class Initialized
DEBUG - 2020-02-02 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:37 --> Input Class Initialized
INFO - 2020-02-02 19:50:37 --> Language Class Initialized
INFO - 2020-02-02 19:50:37 --> Language Class Initialized
INFO - 2020-02-02 19:50:37 --> Language Class Initialized
INFO - 2020-02-02 19:50:37 --> Language Class Initialized
INFO - 2020-02-02 19:50:37 --> Input Class Initialized
ERROR - 2020-02-02 19:50:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:50:37 --> Language Class Initialized
ERROR - 2020-02-02 19:50:37 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-02 19:50:37 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-02 19:50:37 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-02 19:50:37 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:50:37 --> Language Class Initialized
INFO - 2020-02-02 19:50:37 --> Config Class Initialized
INFO - 2020-02-02 19:50:37 --> Hooks Class Initialized
ERROR - 2020-02-02 19:50:37 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:50:37 --> Config Class Initialized
INFO - 2020-02-02 19:50:37 --> Config Class Initialized
INFO - 2020-02-02 19:50:37 --> Config Class Initialized
INFO - 2020-02-02 19:50:37 --> Config Class Initialized
INFO - 2020-02-02 19:50:37 --> Hooks Class Initialized
INFO - 2020-02-02 19:50:37 --> Hooks Class Initialized
INFO - 2020-02-02 19:50:37 --> Hooks Class Initialized
INFO - 2020-02-02 19:50:37 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:50:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:37 --> Config Class Initialized
INFO - 2020-02-02 19:50:37 --> Hooks Class Initialized
INFO - 2020-02-02 19:50:37 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:50:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:50:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:50:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:50:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:37 --> URI Class Initialized
DEBUG - 2020-02-02 19:50:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:37 --> URI Class Initialized
INFO - 2020-02-02 19:50:37 --> Router Class Initialized
INFO - 2020-02-02 19:50:37 --> URI Class Initialized
INFO - 2020-02-02 19:50:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:37 --> URI Class Initialized
INFO - 2020-02-02 19:50:37 --> URI Class Initialized
INFO - 2020-02-02 19:50:37 --> URI Class Initialized
INFO - 2020-02-02 19:50:37 --> Router Class Initialized
INFO - 2020-02-02 19:50:37 --> Router Class Initialized
INFO - 2020-02-02 19:50:37 --> Output Class Initialized
INFO - 2020-02-02 19:50:37 --> Router Class Initialized
INFO - 2020-02-02 19:50:37 --> Router Class Initialized
INFO - 2020-02-02 19:50:37 --> Output Class Initialized
INFO - 2020-02-02 19:50:37 --> Output Class Initialized
INFO - 2020-02-02 19:50:37 --> Security Class Initialized
INFO - 2020-02-02 19:50:37 --> Router Class Initialized
INFO - 2020-02-02 19:50:37 --> Output Class Initialized
INFO - 2020-02-02 19:50:37 --> Output Class Initialized
INFO - 2020-02-02 19:50:37 --> Security Class Initialized
INFO - 2020-02-02 19:50:37 --> Security Class Initialized
DEBUG - 2020-02-02 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:37 --> Security Class Initialized
DEBUG - 2020-02-02 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:37 --> Security Class Initialized
INFO - 2020-02-02 19:50:37 --> Output Class Initialized
INFO - 2020-02-02 19:50:37 --> Input Class Initialized
INFO - 2020-02-02 19:50:37 --> Security Class Initialized
DEBUG - 2020-02-02 19:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:37 --> Input Class Initialized
DEBUG - 2020-02-02 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:37 --> Input Class Initialized
INFO - 2020-02-02 19:50:37 --> Input Class Initialized
INFO - 2020-02-02 19:50:37 --> Language Class Initialized
INFO - 2020-02-02 19:50:37 --> Input Class Initialized
INFO - 2020-02-02 19:50:37 --> Language Class Initialized
DEBUG - 2020-02-02 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:37 --> Input Class Initialized
INFO - 2020-02-02 19:50:37 --> Language Class Initialized
ERROR - 2020-02-02 19:50:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:50:37 --> Language Class Initialized
INFO - 2020-02-02 19:50:37 --> Language Class Initialized
INFO - 2020-02-02 19:50:37 --> Loader Class Initialized
INFO - 2020-02-02 19:50:37 --> Language Class Initialized
ERROR - 2020-02-02 19:50:37 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-02 19:50:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-02 19:50:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:50:37 --> Helper loaded: url_helper
INFO - 2020-02-02 19:50:37 --> Config Class Initialized
INFO - 2020-02-02 19:50:37 --> Hooks Class Initialized
ERROR - 2020-02-02 19:50:37 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:50:37 --> Config Class Initialized
INFO - 2020-02-02 19:50:37 --> Database Driver Class Initialized
INFO - 2020-02-02 19:50:37 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:50:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:50:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-02 19:50:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:37 --> Controller Class Initialized
INFO - 2020-02-02 19:50:37 --> URI Class Initialized
INFO - 2020-02-02 19:50:37 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:50:37 --> URI Class Initialized
INFO - 2020-02-02 19:50:37 --> Router Class Initialized
INFO - 2020-02-02 19:50:37 --> Router Class Initialized
INFO - 2020-02-02 19:50:37 --> Output Class Initialized
INFO - 2020-02-02 19:50:37 --> Helper loaded: form_helper
INFO - 2020-02-02 19:50:37 --> Form Validation Class Initialized
INFO - 2020-02-02 19:50:37 --> Security Class Initialized
INFO - 2020-02-02 19:50:37 --> Output Class Initialized
DEBUG - 2020-02-02 19:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:38 --> Security Class Initialized
ERROR - 2020-02-02 19:50:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:50:38 --> Input Class Initialized
ERROR - 2020-02-02 19:50:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-02 19:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:38 --> Input Class Initialized
INFO - 2020-02-02 19:50:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:50:38 --> Language Class Initialized
INFO - 2020-02-02 19:50:38 --> Final output sent to browser
INFO - 2020-02-02 19:50:38 --> Language Class Initialized
INFO - 2020-02-02 19:50:38 --> Loader Class Initialized
DEBUG - 2020-02-02 19:50:38 --> Total execution time: 0.9233
INFO - 2020-02-02 19:50:38 --> Helper loaded: url_helper
ERROR - 2020-02-02 19:50:38 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:50:38 --> Database Driver Class Initialized
INFO - 2020-02-02 19:50:38 --> Config Class Initialized
INFO - 2020-02-02 19:50:38 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:50:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-02 19:50:38 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:38 --> Controller Class Initialized
INFO - 2020-02-02 19:50:38 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:50:38 --> URI Class Initialized
INFO - 2020-02-02 19:50:38 --> Router Class Initialized
INFO - 2020-02-02 19:50:38 --> Helper loaded: form_helper
INFO - 2020-02-02 19:50:38 --> Form Validation Class Initialized
INFO - 2020-02-02 19:50:38 --> Output Class Initialized
INFO - 2020-02-02 19:50:38 --> Security Class Initialized
ERROR - 2020-02-02 19:50:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 19:50:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-02 19:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:38 --> Input Class Initialized
INFO - 2020-02-02 19:50:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:50:38 --> Final output sent to browser
INFO - 2020-02-02 19:50:38 --> Language Class Initialized
DEBUG - 2020-02-02 19:50:38 --> Total execution time: 0.8782
ERROR - 2020-02-02 19:50:38 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:50:38 --> Config Class Initialized
INFO - 2020-02-02 19:50:38 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:50:38 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:38 --> URI Class Initialized
INFO - 2020-02-02 19:50:38 --> Router Class Initialized
INFO - 2020-02-02 19:50:38 --> Output Class Initialized
INFO - 2020-02-02 19:50:38 --> Security Class Initialized
DEBUG - 2020-02-02 19:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:38 --> Input Class Initialized
INFO - 2020-02-02 19:50:39 --> Language Class Initialized
ERROR - 2020-02-02 19:50:39 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:50:39 --> Config Class Initialized
INFO - 2020-02-02 19:50:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:50:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:39 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:39 --> URI Class Initialized
INFO - 2020-02-02 19:50:39 --> Router Class Initialized
INFO - 2020-02-02 19:50:39 --> Output Class Initialized
INFO - 2020-02-02 19:50:39 --> Security Class Initialized
DEBUG - 2020-02-02 19:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:39 --> Input Class Initialized
INFO - 2020-02-02 19:50:39 --> Language Class Initialized
ERROR - 2020-02-02 19:50:39 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:50:39 --> Config Class Initialized
INFO - 2020-02-02 19:50:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:50:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:39 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:39 --> URI Class Initialized
INFO - 2020-02-02 19:50:39 --> Router Class Initialized
INFO - 2020-02-02 19:50:39 --> Output Class Initialized
INFO - 2020-02-02 19:50:39 --> Security Class Initialized
DEBUG - 2020-02-02 19:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:39 --> Input Class Initialized
INFO - 2020-02-02 19:50:39 --> Language Class Initialized
ERROR - 2020-02-02 19:50:39 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:50:39 --> Config Class Initialized
INFO - 2020-02-02 19:50:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:50:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:40 --> URI Class Initialized
INFO - 2020-02-02 19:50:40 --> Router Class Initialized
INFO - 2020-02-02 19:50:40 --> Output Class Initialized
INFO - 2020-02-02 19:50:40 --> Security Class Initialized
DEBUG - 2020-02-02 19:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:40 --> Input Class Initialized
INFO - 2020-02-02 19:50:40 --> Language Class Initialized
ERROR - 2020-02-02 19:50:40 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:50:40 --> Config Class Initialized
INFO - 2020-02-02 19:50:40 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:50:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:40 --> URI Class Initialized
INFO - 2020-02-02 19:50:40 --> Router Class Initialized
INFO - 2020-02-02 19:50:40 --> Output Class Initialized
INFO - 2020-02-02 19:50:40 --> Security Class Initialized
DEBUG - 2020-02-02 19:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:40 --> Input Class Initialized
INFO - 2020-02-02 19:50:40 --> Language Class Initialized
ERROR - 2020-02-02 19:50:40 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:50:40 --> Config Class Initialized
INFO - 2020-02-02 19:50:40 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:50:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:50:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:50:40 --> URI Class Initialized
INFO - 2020-02-02 19:50:40 --> Router Class Initialized
INFO - 2020-02-02 19:50:40 --> Output Class Initialized
INFO - 2020-02-02 19:50:41 --> Security Class Initialized
DEBUG - 2020-02-02 19:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:50:41 --> Input Class Initialized
INFO - 2020-02-02 19:50:41 --> Language Class Initialized
ERROR - 2020-02-02 19:50:41 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:52:34 --> Config Class Initialized
INFO - 2020-02-02 19:52:34 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:52:34 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:52:34 --> Utf8 Class Initialized
INFO - 2020-02-02 19:52:34 --> URI Class Initialized
INFO - 2020-02-02 19:52:34 --> Router Class Initialized
INFO - 2020-02-02 19:52:34 --> Output Class Initialized
INFO - 2020-02-02 19:52:35 --> Security Class Initialized
DEBUG - 2020-02-02 19:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:52:35 --> Input Class Initialized
INFO - 2020-02-02 19:52:35 --> Language Class Initialized
INFO - 2020-02-02 19:52:35 --> Loader Class Initialized
INFO - 2020-02-02 19:52:35 --> Helper loaded: url_helper
INFO - 2020-02-02 19:52:35 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:52:35 --> Controller Class Initialized
INFO - 2020-02-02 19:52:35 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:52:35 --> Helper loaded: form_helper
INFO - 2020-02-02 19:52:35 --> Form Validation Class Initialized
INFO - 2020-02-02 19:52:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:52:35 --> Final output sent to browser
INFO - 2020-02-02 19:52:35 --> Config Class Initialized
INFO - 2020-02-02 19:52:35 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:52:35 --> Total execution time: 0.8665
INFO - 2020-02-02 19:52:35 --> Config Class Initialized
INFO - 2020-02-02 19:52:35 --> Config Class Initialized
INFO - 2020-02-02 19:52:35 --> Config Class Initialized
INFO - 2020-02-02 19:52:35 --> Config Class Initialized
DEBUG - 2020-02-02 19:52:35 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:52:35 --> Hooks Class Initialized
INFO - 2020-02-02 19:52:35 --> Hooks Class Initialized
INFO - 2020-02-02 19:52:35 --> Hooks Class Initialized
INFO - 2020-02-02 19:52:35 --> Config Class Initialized
INFO - 2020-02-02 19:52:35 --> Hooks Class Initialized
INFO - 2020-02-02 19:52:35 --> Hooks Class Initialized
INFO - 2020-02-02 19:52:35 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:52:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:52:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:52:35 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:52:35 --> Utf8 Class Initialized
INFO - 2020-02-02 19:52:35 --> Utf8 Class Initialized
INFO - 2020-02-02 19:52:35 --> Utf8 Class Initialized
INFO - 2020-02-02 19:52:35 --> URI Class Initialized
DEBUG - 2020-02-02 19:52:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:52:35 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:52:35 --> Utf8 Class Initialized
INFO - 2020-02-02 19:52:35 --> Utf8 Class Initialized
INFO - 2020-02-02 19:52:35 --> Router Class Initialized
INFO - 2020-02-02 19:52:35 --> URI Class Initialized
INFO - 2020-02-02 19:52:35 --> URI Class Initialized
INFO - 2020-02-02 19:52:35 --> URI Class Initialized
INFO - 2020-02-02 19:52:35 --> Router Class Initialized
INFO - 2020-02-02 19:52:35 --> Router Class Initialized
INFO - 2020-02-02 19:52:35 --> Router Class Initialized
INFO - 2020-02-02 19:52:35 --> URI Class Initialized
INFO - 2020-02-02 19:52:35 --> Output Class Initialized
INFO - 2020-02-02 19:52:35 --> URI Class Initialized
INFO - 2020-02-02 19:52:35 --> Security Class Initialized
INFO - 2020-02-02 19:52:35 --> Router Class Initialized
INFO - 2020-02-02 19:52:35 --> Router Class Initialized
INFO - 2020-02-02 19:52:35 --> Output Class Initialized
INFO - 2020-02-02 19:52:35 --> Output Class Initialized
INFO - 2020-02-02 19:52:35 --> Output Class Initialized
DEBUG - 2020-02-02 19:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:52:35 --> Security Class Initialized
INFO - 2020-02-02 19:52:35 --> Security Class Initialized
INFO - 2020-02-02 19:52:35 --> Output Class Initialized
INFO - 2020-02-02 19:52:35 --> Output Class Initialized
INFO - 2020-02-02 19:52:35 --> Security Class Initialized
INFO - 2020-02-02 19:52:35 --> Input Class Initialized
DEBUG - 2020-02-02 19:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:52:35 --> Security Class Initialized
DEBUG - 2020-02-02 19:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:52:35 --> Security Class Initialized
INFO - 2020-02-02 19:52:35 --> Input Class Initialized
INFO - 2020-02-02 19:52:35 --> Input Class Initialized
INFO - 2020-02-02 19:52:35 --> Language Class Initialized
INFO - 2020-02-02 19:52:36 --> Input Class Initialized
DEBUG - 2020-02-02 19:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:52:36 --> Input Class Initialized
INFO - 2020-02-02 19:52:36 --> Input Class Initialized
INFO - 2020-02-02 19:52:36 --> Language Class Initialized
INFO - 2020-02-02 19:52:36 --> Language Class Initialized
ERROR - 2020-02-02 19:52:36 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 19:52:36 --> Language Class Initialized
INFO - 2020-02-02 19:52:36 --> Language Class Initialized
ERROR - 2020-02-02 19:52:36 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:52:36 --> Loader Class Initialized
INFO - 2020-02-02 19:52:36 --> Language Class Initialized
ERROR - 2020-02-02 19:52:36 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:52:36 --> Config Class Initialized
INFO - 2020-02-02 19:52:36 --> Hooks Class Initialized
ERROR - 2020-02-02 19:52:36 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:52:36 --> Helper loaded: url_helper
INFO - 2020-02-02 19:52:36 --> Loader Class Initialized
INFO - 2020-02-02 19:52:36 --> Config Class Initialized
INFO - 2020-02-02 19:52:36 --> Config Class Initialized
INFO - 2020-02-02 19:52:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:52:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:52:36 --> Helper loaded: url_helper
DEBUG - 2020-02-02 19:52:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:52:36 --> Config Class Initialized
INFO - 2020-02-02 19:52:36 --> Database Driver Class Initialized
INFO - 2020-02-02 19:52:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:52:36 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:52:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:52:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:52:36 --> Database Driver Class Initialized
INFO - 2020-02-02 19:52:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:52:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:52:36 --> URI Class Initialized
DEBUG - 2020-02-02 19:52:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:52:36 --> Controller Class Initialized
INFO - 2020-02-02 19:52:36 --> URI Class Initialized
INFO - 2020-02-02 19:52:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:52:36 --> Router Class Initialized
INFO - 2020-02-02 19:52:36 --> URI Class Initialized
INFO - 2020-02-02 19:52:36 --> Router Class Initialized
INFO - 2020-02-02 19:52:36 --> Router Class Initialized
INFO - 2020-02-02 19:52:36 --> Output Class Initialized
INFO - 2020-02-02 19:52:36 --> URI Class Initialized
INFO - 2020-02-02 19:52:36 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:52:36 --> Security Class Initialized
INFO - 2020-02-02 19:52:36 --> Router Class Initialized
INFO - 2020-02-02 19:52:36 --> Output Class Initialized
INFO - 2020-02-02 19:52:36 --> Helper loaded: form_helper
INFO - 2020-02-02 19:52:36 --> Output Class Initialized
INFO - 2020-02-02 19:52:36 --> Form Validation Class Initialized
INFO - 2020-02-02 19:52:36 --> Security Class Initialized
INFO - 2020-02-02 19:52:36 --> Security Class Initialized
DEBUG - 2020-02-02 19:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:52:36 --> Output Class Initialized
INFO - 2020-02-02 19:52:36 --> Input Class Initialized
DEBUG - 2020-02-02 19:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:52:36 --> Security Class Initialized
ERROR - 2020-02-02 19:52:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:52:36 --> Input Class Initialized
INFO - 2020-02-02 19:52:36 --> Input Class Initialized
ERROR - 2020-02-02 19:52:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-02 19:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:52:36 --> Language Class Initialized
INFO - 2020-02-02 19:52:36 --> Input Class Initialized
INFO - 2020-02-02 19:52:36 --> Language Class Initialized
INFO - 2020-02-02 19:52:36 --> Language Class Initialized
ERROR - 2020-02-02 19:52:36 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:52:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:52:36 --> Final output sent to browser
INFO - 2020-02-02 19:52:36 --> Language Class Initialized
ERROR - 2020-02-02 19:52:36 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 19:52:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:52:36 --> Config Class Initialized
INFO - 2020-02-02 19:52:36 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:52:36 --> Total execution time: 0.8417
ERROR - 2020-02-02 19:52:36 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:52:36 --> Config Class Initialized
INFO - 2020-02-02 19:52:36 --> Config Class Initialized
INFO - 2020-02-02 19:52:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:52:36 --> Hooks Class Initialized
INFO - 2020-02-02 19:52:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-02 19:52:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:52:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:52:36 --> Controller Class Initialized
DEBUG - 2020-02-02 19:52:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:52:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:52:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:52:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:52:36 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:52:36 --> URI Class Initialized
INFO - 2020-02-02 19:52:36 --> URI Class Initialized
INFO - 2020-02-02 19:52:36 --> URI Class Initialized
INFO - 2020-02-02 19:52:36 --> Router Class Initialized
INFO - 2020-02-02 19:52:36 --> Helper loaded: form_helper
INFO - 2020-02-02 19:52:36 --> Form Validation Class Initialized
INFO - 2020-02-02 19:52:36 --> Router Class Initialized
INFO - 2020-02-02 19:52:36 --> Router Class Initialized
INFO - 2020-02-02 19:52:36 --> Output Class Initialized
INFO - 2020-02-02 19:52:36 --> Security Class Initialized
INFO - 2020-02-02 19:52:36 --> Output Class Initialized
INFO - 2020-02-02 19:52:36 --> Output Class Initialized
ERROR - 2020-02-02 19:52:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 19:52:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:52:36 --> Security Class Initialized
DEBUG - 2020-02-02 19:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:52:36 --> Security Class Initialized
INFO - 2020-02-02 19:52:36 --> Input Class Initialized
INFO - 2020-02-02 19:52:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-02 19:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:52:36 --> Input Class Initialized
INFO - 2020-02-02 19:52:36 --> Final output sent to browser
INFO - 2020-02-02 19:52:36 --> Input Class Initialized
INFO - 2020-02-02 19:52:36 --> Language Class Initialized
DEBUG - 2020-02-02 19:52:36 --> Total execution time: 1.1830
INFO - 2020-02-02 19:52:36 --> Language Class Initialized
INFO - 2020-02-02 19:52:36 --> Language Class Initialized
ERROR - 2020-02-02 19:52:36 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-02 19:52:36 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-02 19:52:36 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:53:36 --> Config Class Initialized
INFO - 2020-02-02 19:53:36 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:36 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:36 --> URI Class Initialized
INFO - 2020-02-02 19:53:36 --> Router Class Initialized
INFO - 2020-02-02 19:53:36 --> Output Class Initialized
INFO - 2020-02-02 19:53:36 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:37 --> Input Class Initialized
INFO - 2020-02-02 19:53:37 --> Language Class Initialized
INFO - 2020-02-02 19:53:37 --> Loader Class Initialized
INFO - 2020-02-02 19:53:37 --> Helper loaded: url_helper
INFO - 2020-02-02 19:53:37 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:53:37 --> Controller Class Initialized
INFO - 2020-02-02 19:53:37 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:53:37 --> Helper loaded: form_helper
INFO - 2020-02-02 19:53:37 --> Form Validation Class Initialized
INFO - 2020-02-02 19:53:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:53:37 --> Final output sent to browser
INFO - 2020-02-02 19:53:37 --> Config Class Initialized
INFO - 2020-02-02 19:53:37 --> Config Class Initialized
INFO - 2020-02-02 19:53:37 --> Config Class Initialized
INFO - 2020-02-02 19:53:37 --> Config Class Initialized
INFO - 2020-02-02 19:53:37 --> Config Class Initialized
INFO - 2020-02-02 19:53:37 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:37 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:37 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:37 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:37 --> Total execution time: 0.9557
INFO - 2020-02-02 19:53:37 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:37 --> Config Class Initialized
INFO - 2020-02-02 19:53:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:37 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:37 --> URI Class Initialized
INFO - 2020-02-02 19:53:37 --> URI Class Initialized
INFO - 2020-02-02 19:53:37 --> URI Class Initialized
INFO - 2020-02-02 19:53:37 --> URI Class Initialized
INFO - 2020-02-02 19:53:37 --> URI Class Initialized
DEBUG - 2020-02-02 19:53:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:37 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:37 --> Router Class Initialized
INFO - 2020-02-02 19:53:37 --> Router Class Initialized
INFO - 2020-02-02 19:53:37 --> Router Class Initialized
INFO - 2020-02-02 19:53:37 --> Router Class Initialized
INFO - 2020-02-02 19:53:37 --> Router Class Initialized
INFO - 2020-02-02 19:53:37 --> URI Class Initialized
INFO - 2020-02-02 19:53:37 --> Output Class Initialized
INFO - 2020-02-02 19:53:37 --> Output Class Initialized
INFO - 2020-02-02 19:53:37 --> Output Class Initialized
INFO - 2020-02-02 19:53:37 --> Output Class Initialized
INFO - 2020-02-02 19:53:37 --> Output Class Initialized
INFO - 2020-02-02 19:53:37 --> Security Class Initialized
INFO - 2020-02-02 19:53:37 --> Security Class Initialized
INFO - 2020-02-02 19:53:37 --> Router Class Initialized
INFO - 2020-02-02 19:53:37 --> Security Class Initialized
INFO - 2020-02-02 19:53:37 --> Security Class Initialized
INFO - 2020-02-02 19:53:37 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:37 --> Output Class Initialized
DEBUG - 2020-02-02 19:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:37 --> Input Class Initialized
INFO - 2020-02-02 19:53:37 --> Input Class Initialized
INFO - 2020-02-02 19:53:37 --> Input Class Initialized
INFO - 2020-02-02 19:53:37 --> Input Class Initialized
INFO - 2020-02-02 19:53:37 --> Input Class Initialized
INFO - 2020-02-02 19:53:37 --> Security Class Initialized
INFO - 2020-02-02 19:53:37 --> Language Class Initialized
INFO - 2020-02-02 19:53:37 --> Language Class Initialized
DEBUG - 2020-02-02 19:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:37 --> Language Class Initialized
INFO - 2020-02-02 19:53:37 --> Language Class Initialized
INFO - 2020-02-02 19:53:37 --> Language Class Initialized
ERROR - 2020-02-02 19:53:38 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-02 19:53:38 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:53:38 --> Input Class Initialized
ERROR - 2020-02-02 19:53:38 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-02 19:53:38 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-02 19:53:38 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:53:38 --> Language Class Initialized
INFO - 2020-02-02 19:53:38 --> Config Class Initialized
INFO - 2020-02-02 19:53:38 --> Config Class Initialized
INFO - 2020-02-02 19:53:38 --> Config Class Initialized
INFO - 2020-02-02 19:53:38 --> Config Class Initialized
INFO - 2020-02-02 19:53:38 --> Config Class Initialized
INFO - 2020-02-02 19:53:38 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:38 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:38 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:38 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:38 --> Hooks Class Initialized
ERROR - 2020-02-02 19:53:38 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-02 19:53:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:38 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:38 --> Config Class Initialized
INFO - 2020-02-02 19:53:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:38 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:38 --> URI Class Initialized
INFO - 2020-02-02 19:53:38 --> URI Class Initialized
INFO - 2020-02-02 19:53:38 --> URI Class Initialized
INFO - 2020-02-02 19:53:38 --> URI Class Initialized
INFO - 2020-02-02 19:53:38 --> URI Class Initialized
DEBUG - 2020-02-02 19:53:38 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:38 --> Router Class Initialized
INFO - 2020-02-02 19:53:38 --> Router Class Initialized
INFO - 2020-02-02 19:53:38 --> Router Class Initialized
INFO - 2020-02-02 19:53:38 --> Router Class Initialized
INFO - 2020-02-02 19:53:38 --> Router Class Initialized
INFO - 2020-02-02 19:53:38 --> URI Class Initialized
INFO - 2020-02-02 19:53:38 --> Output Class Initialized
INFO - 2020-02-02 19:53:38 --> Output Class Initialized
INFO - 2020-02-02 19:53:38 --> Output Class Initialized
INFO - 2020-02-02 19:53:38 --> Output Class Initialized
INFO - 2020-02-02 19:53:38 --> Output Class Initialized
INFO - 2020-02-02 19:53:38 --> Security Class Initialized
INFO - 2020-02-02 19:53:38 --> Router Class Initialized
INFO - 2020-02-02 19:53:38 --> Security Class Initialized
INFO - 2020-02-02 19:53:38 --> Security Class Initialized
INFO - 2020-02-02 19:53:38 --> Security Class Initialized
INFO - 2020-02-02 19:53:38 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:38 --> Output Class Initialized
INFO - 2020-02-02 19:53:38 --> Input Class Initialized
INFO - 2020-02-02 19:53:38 --> Input Class Initialized
INFO - 2020-02-02 19:53:38 --> Input Class Initialized
INFO - 2020-02-02 19:53:38 --> Input Class Initialized
INFO - 2020-02-02 19:53:38 --> Input Class Initialized
INFO - 2020-02-02 19:53:38 --> Security Class Initialized
INFO - 2020-02-02 19:53:38 --> Language Class Initialized
INFO - 2020-02-02 19:53:38 --> Language Class Initialized
INFO - 2020-02-02 19:53:38 --> Language Class Initialized
INFO - 2020-02-02 19:53:38 --> Language Class Initialized
INFO - 2020-02-02 19:53:38 --> Language Class Initialized
DEBUG - 2020-02-02 19:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:38 --> Input Class Initialized
ERROR - 2020-02-02 19:53:38 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 19:53:38 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-02 19:53:38 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-02 19:53:38 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:53:38 --> Loader Class Initialized
INFO - 2020-02-02 19:53:38 --> Helper loaded: url_helper
INFO - 2020-02-02 19:53:38 --> Language Class Initialized
INFO - 2020-02-02 19:53:38 --> Config Class Initialized
INFO - 2020-02-02 19:53:38 --> Config Class Initialized
INFO - 2020-02-02 19:53:38 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:38 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:38 --> Loader Class Initialized
INFO - 2020-02-02 19:53:38 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:53:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:38 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:38 --> Helper loaded: url_helper
DEBUG - 2020-02-02 19:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:53:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:38 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:53:38 --> Database Driver Class Initialized
INFO - 2020-02-02 19:53:38 --> Controller Class Initialized
INFO - 2020-02-02 19:53:38 --> URI Class Initialized
INFO - 2020-02-02 19:53:38 --> URI Class Initialized
DEBUG - 2020-02-02 19:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:53:38 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:53:38 --> Router Class Initialized
INFO - 2020-02-02 19:53:38 --> Router Class Initialized
INFO - 2020-02-02 19:53:38 --> Output Class Initialized
INFO - 2020-02-02 19:53:38 --> Output Class Initialized
INFO - 2020-02-02 19:53:38 --> Helper loaded: form_helper
INFO - 2020-02-02 19:53:38 --> Form Validation Class Initialized
INFO - 2020-02-02 19:53:38 --> Security Class Initialized
INFO - 2020-02-02 19:53:38 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:53:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 19:53:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:53:38 --> Input Class Initialized
INFO - 2020-02-02 19:53:38 --> Input Class Initialized
ERROR - 2020-02-02 19:53:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:53:38 --> Language Class Initialized
INFO - 2020-02-02 19:53:38 --> Language Class Initialized
INFO - 2020-02-02 19:53:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:53:38 --> Final output sent to browser
ERROR - 2020-02-02 19:53:38 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-02 19:53:38 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-02 19:53:39 --> Total execution time: 0.8833
INFO - 2020-02-02 19:53:39 --> Config Class Initialized
INFO - 2020-02-02 19:53:39 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:53:39 --> Controller Class Initialized
DEBUG - 2020-02-02 19:53:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:39 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:39 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:53:39 --> URI Class Initialized
INFO - 2020-02-02 19:53:39 --> Helper loaded: form_helper
INFO - 2020-02-02 19:53:39 --> Form Validation Class Initialized
INFO - 2020-02-02 19:53:39 --> Router Class Initialized
INFO - 2020-02-02 19:53:39 --> Output Class Initialized
ERROR - 2020-02-02 19:53:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 19:53:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:53:39 --> Security Class Initialized
INFO - 2020-02-02 19:53:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-02 19:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:39 --> Input Class Initialized
INFO - 2020-02-02 19:53:39 --> Final output sent to browser
DEBUG - 2020-02-02 19:53:39 --> Total execution time: 1.1893
INFO - 2020-02-02 19:53:39 --> Language Class Initialized
ERROR - 2020-02-02 19:53:39 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:53:39 --> Config Class Initialized
INFO - 2020-02-02 19:53:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:39 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:39 --> URI Class Initialized
INFO - 2020-02-02 19:53:39 --> Router Class Initialized
INFO - 2020-02-02 19:53:39 --> Output Class Initialized
INFO - 2020-02-02 19:53:39 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:39 --> Input Class Initialized
INFO - 2020-02-02 19:53:39 --> Language Class Initialized
ERROR - 2020-02-02 19:53:39 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:53:39 --> Config Class Initialized
INFO - 2020-02-02 19:53:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:40 --> URI Class Initialized
INFO - 2020-02-02 19:53:40 --> Router Class Initialized
INFO - 2020-02-02 19:53:40 --> Output Class Initialized
INFO - 2020-02-02 19:53:40 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:40 --> Input Class Initialized
INFO - 2020-02-02 19:53:40 --> Language Class Initialized
ERROR - 2020-02-02 19:53:40 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:53:40 --> Config Class Initialized
INFO - 2020-02-02 19:53:40 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:40 --> URI Class Initialized
INFO - 2020-02-02 19:53:40 --> Router Class Initialized
INFO - 2020-02-02 19:53:40 --> Output Class Initialized
INFO - 2020-02-02 19:53:40 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:40 --> Input Class Initialized
INFO - 2020-02-02 19:53:40 --> Language Class Initialized
ERROR - 2020-02-02 19:53:40 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:53:40 --> Config Class Initialized
INFO - 2020-02-02 19:53:40 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:40 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:40 --> URI Class Initialized
INFO - 2020-02-02 19:53:41 --> Router Class Initialized
INFO - 2020-02-02 19:53:41 --> Output Class Initialized
INFO - 2020-02-02 19:53:41 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:41 --> Input Class Initialized
INFO - 2020-02-02 19:53:41 --> Language Class Initialized
ERROR - 2020-02-02 19:53:41 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:53:41 --> Config Class Initialized
INFO - 2020-02-02 19:53:41 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:41 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:41 --> URI Class Initialized
INFO - 2020-02-02 19:53:41 --> Router Class Initialized
INFO - 2020-02-02 19:53:41 --> Output Class Initialized
INFO - 2020-02-02 19:53:41 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:41 --> Input Class Initialized
INFO - 2020-02-02 19:53:41 --> Language Class Initialized
ERROR - 2020-02-02 19:53:41 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:53:41 --> Config Class Initialized
INFO - 2020-02-02 19:53:41 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:41 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:41 --> URI Class Initialized
INFO - 2020-02-02 19:53:41 --> Router Class Initialized
INFO - 2020-02-02 19:53:41 --> Output Class Initialized
INFO - 2020-02-02 19:53:41 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:42 --> Input Class Initialized
INFO - 2020-02-02 19:53:42 --> Language Class Initialized
ERROR - 2020-02-02 19:53:42 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:53:42 --> Config Class Initialized
INFO - 2020-02-02 19:53:42 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:42 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:42 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:42 --> URI Class Initialized
INFO - 2020-02-02 19:53:42 --> Router Class Initialized
INFO - 2020-02-02 19:53:42 --> Output Class Initialized
INFO - 2020-02-02 19:53:42 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:42 --> Input Class Initialized
INFO - 2020-02-02 19:53:42 --> Language Class Initialized
ERROR - 2020-02-02 19:53:42 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 19:53:55 --> Config Class Initialized
INFO - 2020-02-02 19:53:55 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:56 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:56 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:56 --> URI Class Initialized
INFO - 2020-02-02 19:53:56 --> Router Class Initialized
INFO - 2020-02-02 19:53:56 --> Output Class Initialized
INFO - 2020-02-02 19:53:56 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:56 --> Input Class Initialized
INFO - 2020-02-02 19:53:56 --> Language Class Initialized
INFO - 2020-02-02 19:53:56 --> Loader Class Initialized
INFO - 2020-02-02 19:53:56 --> Helper loaded: url_helper
INFO - 2020-02-02 19:53:56 --> Database Driver Class Initialized
DEBUG - 2020-02-02 19:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:53:56 --> Controller Class Initialized
INFO - 2020-02-02 19:53:56 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:53:56 --> Helper loaded: form_helper
INFO - 2020-02-02 19:53:56 --> Form Validation Class Initialized
INFO - 2020-02-02 19:53:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:53:56 --> Final output sent to browser
INFO - 2020-02-02 19:53:56 --> Config Class Initialized
INFO - 2020-02-02 19:53:56 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:56 --> Total execution time: 0.8032
INFO - 2020-02-02 19:53:56 --> Config Class Initialized
INFO - 2020-02-02 19:53:56 --> Config Class Initialized
INFO - 2020-02-02 19:53:56 --> Config Class Initialized
INFO - 2020-02-02 19:53:56 --> Config Class Initialized
INFO - 2020-02-02 19:53:56 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:56 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:56 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:56 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:56 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:56 --> Config Class Initialized
INFO - 2020-02-02 19:53:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:57 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:57 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:57 --> URI Class Initialized
INFO - 2020-02-02 19:53:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:57 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:53:57 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:57 --> URI Class Initialized
INFO - 2020-02-02 19:53:57 --> URI Class Initialized
INFO - 2020-02-02 19:53:57 --> URI Class Initialized
INFO - 2020-02-02 19:53:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:57 --> URI Class Initialized
INFO - 2020-02-02 19:53:57 --> Router Class Initialized
INFO - 2020-02-02 19:53:57 --> Router Class Initialized
INFO - 2020-02-02 19:53:57 --> Router Class Initialized
INFO - 2020-02-02 19:53:57 --> Output Class Initialized
INFO - 2020-02-02 19:53:57 --> URI Class Initialized
INFO - 2020-02-02 19:53:57 --> Router Class Initialized
INFO - 2020-02-02 19:53:57 --> Router Class Initialized
INFO - 2020-02-02 19:53:57 --> Router Class Initialized
INFO - 2020-02-02 19:53:57 --> Output Class Initialized
INFO - 2020-02-02 19:53:57 --> Output Class Initialized
INFO - 2020-02-02 19:53:57 --> Output Class Initialized
INFO - 2020-02-02 19:53:57 --> Output Class Initialized
INFO - 2020-02-02 19:53:57 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:57 --> Security Class Initialized
INFO - 2020-02-02 19:53:57 --> Security Class Initialized
INFO - 2020-02-02 19:53:57 --> Output Class Initialized
INFO - 2020-02-02 19:53:57 --> Security Class Initialized
INFO - 2020-02-02 19:53:57 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:57 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:57 --> Input Class Initialized
DEBUG - 2020-02-02 19:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:57 --> Input Class Initialized
INFO - 2020-02-02 19:53:57 --> Input Class Initialized
INFO - 2020-02-02 19:53:57 --> Input Class Initialized
INFO - 2020-02-02 19:53:57 --> Language Class Initialized
INFO - 2020-02-02 19:53:57 --> Input Class Initialized
DEBUG - 2020-02-02 19:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:57 --> Input Class Initialized
INFO - 2020-02-02 19:53:57 --> Language Class Initialized
INFO - 2020-02-02 19:53:57 --> Language Class Initialized
INFO - 2020-02-02 19:53:57 --> Language Class Initialized
ERROR - 2020-02-02 19:53:57 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:53:57 --> Language Class Initialized
ERROR - 2020-02-02 19:53:57 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-02 19:53:57 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:53:57 --> Language Class Initialized
INFO - 2020-02-02 19:53:57 --> Loader Class Initialized
INFO - 2020-02-02 19:53:57 --> Loader Class Initialized
INFO - 2020-02-02 19:53:57 --> Config Class Initialized
INFO - 2020-02-02 19:53:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:57 --> Helper loaded: url_helper
INFO - 2020-02-02 19:53:57 --> Helper loaded: url_helper
ERROR - 2020-02-02 19:53:57 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:53:57 --> Config Class Initialized
INFO - 2020-02-02 19:53:57 --> Config Class Initialized
INFO - 2020-02-02 19:53:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:57 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:57 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:57 --> Database Driver Class Initialized
INFO - 2020-02-02 19:53:57 --> Database Driver Class Initialized
INFO - 2020-02-02 19:53:57 --> Config Class Initialized
INFO - 2020-02-02 19:53:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:57 --> Utf8 Class Initialized
DEBUG - 2020-02-02 19:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-02 19:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 19:53:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:53:57 --> URI Class Initialized
DEBUG - 2020-02-02 19:53:57 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:57 --> Controller Class Initialized
INFO - 2020-02-02 19:53:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:57 --> URI Class Initialized
INFO - 2020-02-02 19:53:57 --> URI Class Initialized
INFO - 2020-02-02 19:53:57 --> Router Class Initialized
INFO - 2020-02-02 19:53:57 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:53:57 --> Router Class Initialized
INFO - 2020-02-02 19:53:57 --> Router Class Initialized
INFO - 2020-02-02 19:53:57 --> URI Class Initialized
INFO - 2020-02-02 19:53:57 --> Output Class Initialized
INFO - 2020-02-02 19:53:57 --> Router Class Initialized
INFO - 2020-02-02 19:53:57 --> Output Class Initialized
INFO - 2020-02-02 19:53:57 --> Output Class Initialized
INFO - 2020-02-02 19:53:57 --> Security Class Initialized
INFO - 2020-02-02 19:53:57 --> Helper loaded: form_helper
INFO - 2020-02-02 19:53:57 --> Form Validation Class Initialized
DEBUG - 2020-02-02 19:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:57 --> Security Class Initialized
INFO - 2020-02-02 19:53:57 --> Output Class Initialized
INFO - 2020-02-02 19:53:57 --> Security Class Initialized
INFO - 2020-02-02 19:53:57 --> Input Class Initialized
INFO - 2020-02-02 19:53:57 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 19:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 19:53:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:53:57 --> Input Class Initialized
INFO - 2020-02-02 19:53:57 --> Input Class Initialized
ERROR - 2020-02-02 19:53:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:53:57 --> Language Class Initialized
DEBUG - 2020-02-02 19:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:57 --> Input Class Initialized
INFO - 2020-02-02 19:53:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:53:57 --> Language Class Initialized
INFO - 2020-02-02 19:53:57 --> Language Class Initialized
ERROR - 2020-02-02 19:53:57 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-02 19:53:57 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 19:53:57 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:53:57 --> Final output sent to browser
INFO - 2020-02-02 19:53:57 --> Language Class Initialized
INFO - 2020-02-02 19:53:57 --> Config Class Initialized
DEBUG - 2020-02-02 19:53:57 --> Total execution time: 0.8956
INFO - 2020-02-02 19:53:57 --> Hooks Class Initialized
ERROR - 2020-02-02 19:53:57 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:53:57 --> Config Class Initialized
INFO - 2020-02-02 19:53:57 --> Config Class Initialized
INFO - 2020-02-02 19:53:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 19:53:57 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:57 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:57 --> Config Class Initialized
INFO - 2020-02-02 19:53:57 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:57 --> Hooks Class Initialized
INFO - 2020-02-02 19:53:57 --> Controller Class Initialized
DEBUG - 2020-02-02 19:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 19:53:57 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:58 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:58 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:58 --> Model "M_tiket" initialized
INFO - 2020-02-02 19:53:58 --> URI Class Initialized
DEBUG - 2020-02-02 19:53:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:58 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:58 --> URI Class Initialized
INFO - 2020-02-02 19:53:58 --> Router Class Initialized
INFO - 2020-02-02 19:53:58 --> URI Class Initialized
INFO - 2020-02-02 19:53:58 --> Helper loaded: form_helper
INFO - 2020-02-02 19:53:58 --> Form Validation Class Initialized
INFO - 2020-02-02 19:53:58 --> URI Class Initialized
INFO - 2020-02-02 19:53:58 --> Router Class Initialized
INFO - 2020-02-02 19:53:58 --> Output Class Initialized
INFO - 2020-02-02 19:53:58 --> Router Class Initialized
INFO - 2020-02-02 19:53:58 --> Router Class Initialized
INFO - 2020-02-02 19:53:58 --> Security Class Initialized
INFO - 2020-02-02 19:53:58 --> Output Class Initialized
ERROR - 2020-02-02 19:53:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 19:53:58 --> Output Class Initialized
ERROR - 2020-02-02 19:53:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 19:53:58 --> Security Class Initialized
INFO - 2020-02-02 19:53:58 --> Output Class Initialized
DEBUG - 2020-02-02 19:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:58 --> Security Class Initialized
INFO - 2020-02-02 19:53:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 19:53:58 --> Input Class Initialized
DEBUG - 2020-02-02 19:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:58 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:58 --> Final output sent to browser
INFO - 2020-02-02 19:53:58 --> Input Class Initialized
INFO - 2020-02-02 19:53:58 --> Input Class Initialized
DEBUG - 2020-02-02 19:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:58 --> Language Class Initialized
INFO - 2020-02-02 19:53:58 --> Input Class Initialized
DEBUG - 2020-02-02 19:53:58 --> Total execution time: 1.3858
INFO - 2020-02-02 19:53:58 --> Language Class Initialized
INFO - 2020-02-02 19:53:58 --> Language Class Initialized
ERROR - 2020-02-02 19:53:58 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:53:58 --> Language Class Initialized
ERROR - 2020-02-02 19:53:58 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-02 19:53:58 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-02 19:53:58 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 19:53:58 --> Config Class Initialized
INFO - 2020-02-02 19:53:58 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:58 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:58 --> URI Class Initialized
INFO - 2020-02-02 19:53:58 --> Router Class Initialized
INFO - 2020-02-02 19:53:58 --> Output Class Initialized
INFO - 2020-02-02 19:53:58 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:58 --> Input Class Initialized
INFO - 2020-02-02 19:53:58 --> Language Class Initialized
ERROR - 2020-02-02 19:53:58 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 19:53:58 --> Config Class Initialized
INFO - 2020-02-02 19:53:59 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:59 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:59 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:59 --> URI Class Initialized
INFO - 2020-02-02 19:53:59 --> Router Class Initialized
INFO - 2020-02-02 19:53:59 --> Output Class Initialized
INFO - 2020-02-02 19:53:59 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:59 --> Input Class Initialized
INFO - 2020-02-02 19:53:59 --> Language Class Initialized
ERROR - 2020-02-02 19:53:59 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 19:53:59 --> Config Class Initialized
INFO - 2020-02-02 19:53:59 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:59 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:59 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:59 --> URI Class Initialized
INFO - 2020-02-02 19:53:59 --> Router Class Initialized
INFO - 2020-02-02 19:53:59 --> Output Class Initialized
INFO - 2020-02-02 19:53:59 --> Security Class Initialized
DEBUG - 2020-02-02 19:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:53:59 --> Input Class Initialized
INFO - 2020-02-02 19:53:59 --> Language Class Initialized
ERROR - 2020-02-02 19:53:59 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 19:53:59 --> Config Class Initialized
INFO - 2020-02-02 19:53:59 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:53:59 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:53:59 --> Utf8 Class Initialized
INFO - 2020-02-02 19:53:59 --> URI Class Initialized
INFO - 2020-02-02 19:54:00 --> Router Class Initialized
INFO - 2020-02-02 19:54:00 --> Output Class Initialized
INFO - 2020-02-02 19:54:00 --> Security Class Initialized
DEBUG - 2020-02-02 19:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:54:00 --> Input Class Initialized
INFO - 2020-02-02 19:54:00 --> Language Class Initialized
ERROR - 2020-02-02 19:54:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:54:00 --> Config Class Initialized
INFO - 2020-02-02 19:54:00 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:54:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:54:00 --> Utf8 Class Initialized
INFO - 2020-02-02 19:54:00 --> URI Class Initialized
INFO - 2020-02-02 19:54:00 --> Router Class Initialized
INFO - 2020-02-02 19:54:00 --> Output Class Initialized
INFO - 2020-02-02 19:54:00 --> Security Class Initialized
DEBUG - 2020-02-02 19:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:54:00 --> Input Class Initialized
INFO - 2020-02-02 19:54:00 --> Language Class Initialized
ERROR - 2020-02-02 19:54:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 19:54:00 --> Config Class Initialized
INFO - 2020-02-02 19:54:00 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:54:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:54:00 --> Utf8 Class Initialized
INFO - 2020-02-02 19:54:00 --> URI Class Initialized
INFO - 2020-02-02 19:54:00 --> Router Class Initialized
INFO - 2020-02-02 19:54:00 --> Output Class Initialized
INFO - 2020-02-02 19:54:00 --> Security Class Initialized
DEBUG - 2020-02-02 19:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:54:01 --> Input Class Initialized
INFO - 2020-02-02 19:54:01 --> Language Class Initialized
ERROR - 2020-02-02 19:54:01 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 19:54:01 --> Config Class Initialized
INFO - 2020-02-02 19:54:01 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:54:01 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:54:01 --> Utf8 Class Initialized
INFO - 2020-02-02 19:54:01 --> URI Class Initialized
INFO - 2020-02-02 19:54:01 --> Router Class Initialized
INFO - 2020-02-02 19:54:01 --> Output Class Initialized
INFO - 2020-02-02 19:54:01 --> Security Class Initialized
DEBUG - 2020-02-02 19:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:54:01 --> Input Class Initialized
INFO - 2020-02-02 19:54:01 --> Language Class Initialized
ERROR - 2020-02-02 19:54:01 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 19:54:01 --> Config Class Initialized
INFO - 2020-02-02 19:54:01 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:54:01 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:54:01 --> Utf8 Class Initialized
INFO - 2020-02-02 19:54:01 --> URI Class Initialized
INFO - 2020-02-02 19:54:01 --> Router Class Initialized
INFO - 2020-02-02 19:54:01 --> Output Class Initialized
INFO - 2020-02-02 19:54:01 --> Security Class Initialized
DEBUG - 2020-02-02 19:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:54:01 --> Input Class Initialized
INFO - 2020-02-02 19:54:01 --> Language Class Initialized
ERROR - 2020-02-02 19:54:01 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 19:54:01 --> Config Class Initialized
INFO - 2020-02-02 19:54:01 --> Hooks Class Initialized
DEBUG - 2020-02-02 19:54:02 --> UTF-8 Support Enabled
INFO - 2020-02-02 19:54:02 --> Utf8 Class Initialized
INFO - 2020-02-02 19:54:02 --> URI Class Initialized
INFO - 2020-02-02 19:54:02 --> Router Class Initialized
INFO - 2020-02-02 19:54:02 --> Output Class Initialized
INFO - 2020-02-02 19:54:02 --> Security Class Initialized
DEBUG - 2020-02-02 19:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 19:54:02 --> Input Class Initialized
INFO - 2020-02-02 19:54:02 --> Language Class Initialized
ERROR - 2020-02-02 19:54:02 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 20:00:27 --> Config Class Initialized
INFO - 2020-02-02 20:00:27 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:00:27 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:00:27 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:27 --> URI Class Initialized
INFO - 2020-02-02 20:00:27 --> Router Class Initialized
INFO - 2020-02-02 20:00:27 --> Output Class Initialized
INFO - 2020-02-02 20:00:27 --> Security Class Initialized
DEBUG - 2020-02-02 20:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:00:27 --> Input Class Initialized
INFO - 2020-02-02 20:00:27 --> Language Class Initialized
INFO - 2020-02-02 20:00:27 --> Loader Class Initialized
INFO - 2020-02-02 20:00:27 --> Helper loaded: url_helper
INFO - 2020-02-02 20:00:27 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:00:27 --> Controller Class Initialized
INFO - 2020-02-02 20:00:27 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:00:27 --> Helper loaded: form_helper
INFO - 2020-02-02 20:00:28 --> Form Validation Class Initialized
INFO - 2020-02-02 20:00:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:00:28 --> Final output sent to browser
DEBUG - 2020-02-02 20:00:28 --> Total execution time: 0.5632
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:28 --> Hooks Class Initialized
INFO - 2020-02-02 20:00:28 --> Hooks Class Initialized
INFO - 2020-02-02 20:00:28 --> Hooks Class Initialized
INFO - 2020-02-02 20:00:28 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:00:28 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:00:28 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:00:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:00:28 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:00:28 --> Hooks Class Initialized
INFO - 2020-02-02 20:00:28 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:28 --> Utf8 Class Initialized
DEBUG - 2020-02-02 20:00:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:00:28 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:00:28 --> Utf8 Class Initialized
DEBUG - 2020-02-02 20:00:28 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:00:28 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:28 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:28 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:28 --> URI Class Initialized
INFO - 2020-02-02 20:00:28 --> URI Class Initialized
INFO - 2020-02-02 20:00:28 --> URI Class Initialized
INFO - 2020-02-02 20:00:28 --> URI Class Initialized
INFO - 2020-02-02 20:00:28 --> Router Class Initialized
INFO - 2020-02-02 20:00:28 --> Router Class Initialized
INFO - 2020-02-02 20:00:28 --> Router Class Initialized
INFO - 2020-02-02 20:00:28 --> URI Class Initialized
INFO - 2020-02-02 20:00:28 --> URI Class Initialized
INFO - 2020-02-02 20:00:28 --> Router Class Initialized
INFO - 2020-02-02 20:00:28 --> Output Class Initialized
INFO - 2020-02-02 20:00:28 --> Output Class Initialized
INFO - 2020-02-02 20:00:28 --> Router Class Initialized
INFO - 2020-02-02 20:00:28 --> Router Class Initialized
INFO - 2020-02-02 20:00:28 --> Output Class Initialized
INFO - 2020-02-02 20:00:28 --> Security Class Initialized
INFO - 2020-02-02 20:00:28 --> Output Class Initialized
INFO - 2020-02-02 20:00:28 --> Output Class Initialized
INFO - 2020-02-02 20:00:28 --> Security Class Initialized
INFO - 2020-02-02 20:00:28 --> Output Class Initialized
INFO - 2020-02-02 20:00:28 --> Security Class Initialized
DEBUG - 2020-02-02 20:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:00:28 --> Security Class Initialized
INFO - 2020-02-02 20:00:28 --> Security Class Initialized
DEBUG - 2020-02-02 20:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:00:28 --> Security Class Initialized
INFO - 2020-02-02 20:00:28 --> Input Class Initialized
INFO - 2020-02-02 20:00:28 --> Input Class Initialized
INFO - 2020-02-02 20:00:28 --> Input Class Initialized
DEBUG - 2020-02-02 20:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:00:28 --> Input Class Initialized
INFO - 2020-02-02 20:00:28 --> Input Class Initialized
INFO - 2020-02-02 20:00:28 --> Input Class Initialized
INFO - 2020-02-02 20:00:28 --> Language Class Initialized
INFO - 2020-02-02 20:00:28 --> Language Class Initialized
INFO - 2020-02-02 20:00:28 --> Language Class Initialized
INFO - 2020-02-02 20:00:28 --> Language Class Initialized
INFO - 2020-02-02 20:00:28 --> Language Class Initialized
INFO - 2020-02-02 20:00:28 --> Language Class Initialized
ERROR - 2020-02-02 20:00:28 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-02 20:00:28 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-02 20:00:28 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 20:00:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-02 20:00:28 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-02 20:00:28 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:28 --> Hooks Class Initialized
INFO - 2020-02-02 20:00:28 --> Hooks Class Initialized
INFO - 2020-02-02 20:00:28 --> Hooks Class Initialized
INFO - 2020-02-02 20:00:28 --> Hooks Class Initialized
INFO - 2020-02-02 20:00:28 --> Hooks Class Initialized
INFO - 2020-02-02 20:00:28 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:00:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:00:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:00:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:00:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:00:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:00:28 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:00:28 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:28 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:28 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:28 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:28 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:28 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:28 --> URI Class Initialized
INFO - 2020-02-02 20:00:28 --> URI Class Initialized
INFO - 2020-02-02 20:00:28 --> URI Class Initialized
INFO - 2020-02-02 20:00:28 --> URI Class Initialized
INFO - 2020-02-02 20:00:28 --> URI Class Initialized
INFO - 2020-02-02 20:00:28 --> URI Class Initialized
INFO - 2020-02-02 20:00:28 --> Router Class Initialized
INFO - 2020-02-02 20:00:28 --> Router Class Initialized
INFO - 2020-02-02 20:00:28 --> Router Class Initialized
INFO - 2020-02-02 20:00:28 --> Router Class Initialized
INFO - 2020-02-02 20:00:28 --> Router Class Initialized
INFO - 2020-02-02 20:00:28 --> Router Class Initialized
INFO - 2020-02-02 20:00:28 --> Output Class Initialized
INFO - 2020-02-02 20:00:28 --> Output Class Initialized
INFO - 2020-02-02 20:00:28 --> Output Class Initialized
INFO - 2020-02-02 20:00:28 --> Output Class Initialized
INFO - 2020-02-02 20:00:28 --> Output Class Initialized
INFO - 2020-02-02 20:00:28 --> Output Class Initialized
INFO - 2020-02-02 20:00:28 --> Security Class Initialized
INFO - 2020-02-02 20:00:28 --> Security Class Initialized
INFO - 2020-02-02 20:00:28 --> Security Class Initialized
INFO - 2020-02-02 20:00:28 --> Security Class Initialized
INFO - 2020-02-02 20:00:28 --> Security Class Initialized
INFO - 2020-02-02 20:00:28 --> Security Class Initialized
DEBUG - 2020-02-02 20:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:00:28 --> Input Class Initialized
INFO - 2020-02-02 20:00:28 --> Input Class Initialized
INFO - 2020-02-02 20:00:28 --> Input Class Initialized
INFO - 2020-02-02 20:00:28 --> Input Class Initialized
INFO - 2020-02-02 20:00:28 --> Input Class Initialized
INFO - 2020-02-02 20:00:28 --> Input Class Initialized
INFO - 2020-02-02 20:00:28 --> Language Class Initialized
INFO - 2020-02-02 20:00:28 --> Language Class Initialized
INFO - 2020-02-02 20:00:28 --> Language Class Initialized
INFO - 2020-02-02 20:00:28 --> Language Class Initialized
INFO - 2020-02-02 20:00:28 --> Language Class Initialized
INFO - 2020-02-02 20:00:28 --> Language Class Initialized
ERROR - 2020-02-02 20:00:28 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-02 20:00:28 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-02 20:00:28 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-02 20:00:28 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 20:00:28 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 20:00:28 --> Loader Class Initialized
INFO - 2020-02-02 20:00:28 --> Helper loaded: url_helper
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:28 --> Config Class Initialized
INFO - 2020-02-02 20:00:29 --> Hooks Class Initialized
INFO - 2020-02-02 20:00:29 --> Hooks Class Initialized
INFO - 2020-02-02 20:00:29 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:00:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:00:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:00:29 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:29 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:00:29 --> Controller Class Initialized
INFO - 2020-02-02 20:00:29 --> URI Class Initialized
INFO - 2020-02-02 20:00:29 --> URI Class Initialized
INFO - 2020-02-02 20:00:29 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:00:29 --> Router Class Initialized
INFO - 2020-02-02 20:00:29 --> Router Class Initialized
INFO - 2020-02-02 20:00:29 --> Output Class Initialized
INFO - 2020-02-02 20:00:29 --> Output Class Initialized
INFO - 2020-02-02 20:00:29 --> Helper loaded: form_helper
INFO - 2020-02-02 20:00:29 --> Form Validation Class Initialized
INFO - 2020-02-02 20:00:29 --> Security Class Initialized
INFO - 2020-02-02 20:00:29 --> Security Class Initialized
DEBUG - 2020-02-02 20:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:00:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 20:00:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 20:00:29 --> Input Class Initialized
INFO - 2020-02-02 20:00:29 --> Input Class Initialized
INFO - 2020-02-02 20:00:29 --> Language Class Initialized
INFO - 2020-02-02 20:00:29 --> Language Class Initialized
ERROR - 2020-02-02 20:00:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-02 20:00:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 20:00:29 --> Loader Class Initialized
INFO - 2020-02-02 20:00:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:00:29 --> Helper loaded: url_helper
INFO - 2020-02-02 20:00:29 --> Config Class Initialized
INFO - 2020-02-02 20:00:29 --> Hooks Class Initialized
INFO - 2020-02-02 20:00:29 --> Final output sent to browser
INFO - 2020-02-02 20:00:29 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:00:29 --> Total execution time: 0.6508
DEBUG - 2020-02-02 20:00:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:00:29 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:00:29 --> Controller Class Initialized
INFO - 2020-02-02 20:00:29 --> URI Class Initialized
INFO - 2020-02-02 20:00:29 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:00:29 --> Router Class Initialized
INFO - 2020-02-02 20:00:29 --> Output Class Initialized
INFO - 2020-02-02 20:00:29 --> Helper loaded: form_helper
INFO - 2020-02-02 20:00:29 --> Form Validation Class Initialized
INFO - 2020-02-02 20:00:29 --> Security Class Initialized
DEBUG - 2020-02-02 20:00:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 20:00:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 20:00:29 --> Input Class Initialized
ERROR - 2020-02-02 20:00:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 20:00:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:00:29 --> Language Class Initialized
INFO - 2020-02-02 20:00:29 --> Final output sent to browser
ERROR - 2020-02-02 20:00:29 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-02 20:00:29 --> Total execution time: 0.5435
INFO - 2020-02-02 20:00:29 --> Config Class Initialized
INFO - 2020-02-02 20:00:29 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:00:29 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:00:29 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:29 --> URI Class Initialized
INFO - 2020-02-02 20:00:29 --> Router Class Initialized
INFO - 2020-02-02 20:00:29 --> Output Class Initialized
INFO - 2020-02-02 20:00:29 --> Security Class Initialized
DEBUG - 2020-02-02 20:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:00:29 --> Input Class Initialized
INFO - 2020-02-02 20:00:29 --> Language Class Initialized
ERROR - 2020-02-02 20:00:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 20:00:29 --> Config Class Initialized
INFO - 2020-02-02 20:00:30 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:00:30 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:00:30 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:30 --> URI Class Initialized
INFO - 2020-02-02 20:00:30 --> Router Class Initialized
INFO - 2020-02-02 20:00:30 --> Output Class Initialized
INFO - 2020-02-02 20:00:30 --> Security Class Initialized
DEBUG - 2020-02-02 20:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:00:30 --> Input Class Initialized
INFO - 2020-02-02 20:00:30 --> Language Class Initialized
ERROR - 2020-02-02 20:00:30 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 20:00:30 --> Config Class Initialized
INFO - 2020-02-02 20:00:30 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:00:30 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:00:30 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:30 --> URI Class Initialized
INFO - 2020-02-02 20:00:30 --> Router Class Initialized
INFO - 2020-02-02 20:00:30 --> Output Class Initialized
INFO - 2020-02-02 20:00:30 --> Security Class Initialized
DEBUG - 2020-02-02 20:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:00:30 --> Input Class Initialized
INFO - 2020-02-02 20:00:30 --> Language Class Initialized
ERROR - 2020-02-02 20:00:30 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 20:00:30 --> Config Class Initialized
INFO - 2020-02-02 20:00:30 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:00:30 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:00:30 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:30 --> URI Class Initialized
INFO - 2020-02-02 20:00:30 --> Router Class Initialized
INFO - 2020-02-02 20:00:30 --> Output Class Initialized
INFO - 2020-02-02 20:00:30 --> Security Class Initialized
DEBUG - 2020-02-02 20:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:00:30 --> Input Class Initialized
INFO - 2020-02-02 20:00:30 --> Language Class Initialized
ERROR - 2020-02-02 20:00:30 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 20:00:30 --> Config Class Initialized
INFO - 2020-02-02 20:00:30 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:00:30 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:00:30 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:31 --> URI Class Initialized
INFO - 2020-02-02 20:00:31 --> Router Class Initialized
INFO - 2020-02-02 20:00:31 --> Output Class Initialized
INFO - 2020-02-02 20:00:31 --> Security Class Initialized
DEBUG - 2020-02-02 20:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:00:31 --> Input Class Initialized
INFO - 2020-02-02 20:00:31 --> Language Class Initialized
ERROR - 2020-02-02 20:00:31 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 20:00:36 --> Config Class Initialized
INFO - 2020-02-02 20:00:36 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:00:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:00:36 --> Utf8 Class Initialized
INFO - 2020-02-02 20:00:36 --> URI Class Initialized
INFO - 2020-02-02 20:00:36 --> Router Class Initialized
INFO - 2020-02-02 20:00:36 --> Output Class Initialized
INFO - 2020-02-02 20:00:36 --> Security Class Initialized
DEBUG - 2020-02-02 20:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:00:36 --> Input Class Initialized
INFO - 2020-02-02 20:00:36 --> Language Class Initialized
INFO - 2020-02-02 20:00:36 --> Loader Class Initialized
INFO - 2020-02-02 20:00:36 --> Helper loaded: url_helper
INFO - 2020-02-02 20:00:36 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:00:36 --> Controller Class Initialized
INFO - 2020-02-02 20:00:36 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:00:36 --> Helper loaded: form_helper
INFO - 2020-02-02 20:00:36 --> Form Validation Class Initialized
INFO - 2020-02-02 20:00:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\component/menu.php
ERROR - 2020-02-02 20:00:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\edit_form.php 57
ERROR - 2020-02-02 20:00:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\edit_form.php 60
ERROR - 2020-02-02 20:00:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\edit_form.php 61
ERROR - 2020-02-02 20:00:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\edit_form.php 65
ERROR - 2020-02-02 20:00:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\edit_form.php 70
ERROR - 2020-02-02 20:00:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\edit_form.php 74
ERROR - 2020-02-02 20:00:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\edit_form.php 78
ERROR - 2020-02-02 20:00:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\edit_form.php 83
INFO - 2020-02-02 20:00:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/edit_form.php
INFO - 2020-02-02 20:00:37 --> Final output sent to browser
DEBUG - 2020-02-02 20:00:37 --> Total execution time: 1.1526
INFO - 2020-02-02 20:01:07 --> Config Class Initialized
INFO - 2020-02-02 20:01:07 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:01:07 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:01:07 --> Utf8 Class Initialized
INFO - 2020-02-02 20:01:07 --> URI Class Initialized
INFO - 2020-02-02 20:01:07 --> Router Class Initialized
INFO - 2020-02-02 20:01:07 --> Output Class Initialized
INFO - 2020-02-02 20:01:07 --> Security Class Initialized
DEBUG - 2020-02-02 20:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:01:07 --> Input Class Initialized
INFO - 2020-02-02 20:01:07 --> Language Class Initialized
INFO - 2020-02-02 20:01:07 --> Loader Class Initialized
INFO - 2020-02-02 20:01:07 --> Helper loaded: url_helper
INFO - 2020-02-02 20:01:07 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:01:07 --> Controller Class Initialized
INFO - 2020-02-02 20:01:07 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:01:08 --> Helper loaded: form_helper
INFO - 2020-02-02 20:01:08 --> Form Validation Class Initialized
INFO - 2020-02-02 20:01:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:01:08 --> Final output sent to browser
DEBUG - 2020-02-02 20:01:08 --> Total execution time: 0.5714
INFO - 2020-02-02 20:01:08 --> Config Class Initialized
INFO - 2020-02-02 20:01:08 --> Config Class Initialized
INFO - 2020-02-02 20:01:08 --> Hooks Class Initialized
INFO - 2020-02-02 20:01:08 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:01:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:01:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:01:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:01:08 --> URI Class Initialized
INFO - 2020-02-02 20:01:08 --> URI Class Initialized
INFO - 2020-02-02 20:01:08 --> Router Class Initialized
INFO - 2020-02-02 20:01:08 --> Router Class Initialized
INFO - 2020-02-02 20:01:08 --> Output Class Initialized
INFO - 2020-02-02 20:01:08 --> Output Class Initialized
INFO - 2020-02-02 20:01:08 --> Security Class Initialized
INFO - 2020-02-02 20:01:08 --> Security Class Initialized
DEBUG - 2020-02-02 20:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:01:08 --> Input Class Initialized
INFO - 2020-02-02 20:01:08 --> Input Class Initialized
INFO - 2020-02-02 20:01:08 --> Language Class Initialized
INFO - 2020-02-02 20:01:08 --> Language Class Initialized
INFO - 2020-02-02 20:01:08 --> Loader Class Initialized
INFO - 2020-02-02 20:01:08 --> Loader Class Initialized
INFO - 2020-02-02 20:01:08 --> Helper loaded: url_helper
INFO - 2020-02-02 20:01:08 --> Helper loaded: url_helper
INFO - 2020-02-02 20:01:08 --> Database Driver Class Initialized
INFO - 2020-02-02 20:01:08 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-02 20:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:01:08 --> Controller Class Initialized
INFO - 2020-02-02 20:01:08 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:01:08 --> Helper loaded: form_helper
INFO - 2020-02-02 20:01:08 --> Form Validation Class Initialized
ERROR - 2020-02-02 20:01:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 20:01:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 20:01:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:01:08 --> Final output sent to browser
DEBUG - 2020-02-02 20:01:08 --> Total execution time: 0.5925
INFO - 2020-02-02 20:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:01:08 --> Controller Class Initialized
INFO - 2020-02-02 20:01:08 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:01:08 --> Helper loaded: form_helper
INFO - 2020-02-02 20:01:08 --> Form Validation Class Initialized
ERROR - 2020-02-02 20:01:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 20:01:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 20:01:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:01:09 --> Final output sent to browser
DEBUG - 2020-02-02 20:01:09 --> Total execution time: 0.8433
INFO - 2020-02-02 20:02:59 --> Config Class Initialized
INFO - 2020-02-02 20:02:59 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:02:59 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:02:59 --> Utf8 Class Initialized
INFO - 2020-02-02 20:02:59 --> URI Class Initialized
INFO - 2020-02-02 20:02:59 --> Router Class Initialized
INFO - 2020-02-02 20:02:59 --> Output Class Initialized
INFO - 2020-02-02 20:02:59 --> Security Class Initialized
DEBUG - 2020-02-02 20:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:02:59 --> Input Class Initialized
INFO - 2020-02-02 20:02:59 --> Language Class Initialized
INFO - 2020-02-02 20:02:59 --> Loader Class Initialized
INFO - 2020-02-02 20:02:59 --> Helper loaded: url_helper
INFO - 2020-02-02 20:02:59 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:02:59 --> Controller Class Initialized
INFO - 2020-02-02 20:02:59 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:02:59 --> Helper loaded: form_helper
INFO - 2020-02-02 20:02:59 --> Form Validation Class Initialized
INFO - 2020-02-02 20:02:59 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:02:59 --> Final output sent to browser
INFO - 2020-02-02 20:02:59 --> Config Class Initialized
INFO - 2020-02-02 20:02:59 --> Config Class Initialized
INFO - 2020-02-02 20:02:59 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:02:59 --> Total execution time: 0.5340
INFO - 2020-02-02 20:02:59 --> Hooks Class Initialized
INFO - 2020-02-02 20:02:59 --> Config Class Initialized
INFO - 2020-02-02 20:02:59 --> Config Class Initialized
INFO - 2020-02-02 20:02:59 --> Config Class Initialized
INFO - 2020-02-02 20:02:59 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:02:59 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:02:59 --> Hooks Class Initialized
INFO - 2020-02-02 20:02:59 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:02:59 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:02:59 --> Config Class Initialized
INFO - 2020-02-02 20:02:59 --> Utf8 Class Initialized
DEBUG - 2020-02-02 20:02:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:02:59 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:02:59 --> Utf8 Class Initialized
INFO - 2020-02-02 20:02:59 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:02:59 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:02:59 --> Utf8 Class Initialized
INFO - 2020-02-02 20:02:59 --> Utf8 Class Initialized
INFO - 2020-02-02 20:02:59 --> Utf8 Class Initialized
INFO - 2020-02-02 20:02:59 --> URI Class Initialized
INFO - 2020-02-02 20:02:59 --> URI Class Initialized
DEBUG - 2020-02-02 20:02:59 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:00 --> URI Class Initialized
INFO - 2020-02-02 20:03:00 --> URI Class Initialized
INFO - 2020-02-02 20:03:00 --> URI Class Initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
INFO - 2020-02-02 20:03:00 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
INFO - 2020-02-02 20:03:00 --> URI Class Initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
ERROR - 2020-02-02 20:03:00 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
ERROR - 2020-02-02 20:03:00 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 20:03:00 --> Config Class Initialized
INFO - 2020-02-02 20:03:00 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
ERROR - 2020-02-02 20:03:00 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-02 20:03:00 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-02 20:03:00 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 20:03:00 --> Config Class Initialized
INFO - 2020-02-02 20:03:00 --> Hooks Class Initialized
ERROR - 2020-02-02 20:03:00 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-02 20:03:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:00 --> Config Class Initialized
INFO - 2020-02-02 20:03:00 --> Config Class Initialized
INFO - 2020-02-02 20:03:00 --> Config Class Initialized
INFO - 2020-02-02 20:03:00 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:00 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:00 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:00 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:00 --> Config Class Initialized
INFO - 2020-02-02 20:03:00 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:00 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:00 --> URI Class Initialized
DEBUG - 2020-02-02 20:03:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:03:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:03:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:00 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:00 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:00 --> URI Class Initialized
INFO - 2020-02-02 20:03:00 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
DEBUG - 2020-02-02 20:03:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:00 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:00 --> URI Class Initialized
INFO - 2020-02-02 20:03:00 --> URI Class Initialized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
INFO - 2020-02-02 20:03:00 --> URI Class Initialized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
INFO - 2020-02-02 20:03:00 --> URI Class Initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
ERROR - 2020-02-02 20:03:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
INFO - 2020-02-02 20:03:00 --> Loader Class Initialized
INFO - 2020-02-02 20:03:00 --> Config Class Initialized
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
ERROR - 2020-02-02 20:03:00 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 20:03:00 --> Helper loaded: url_helper
INFO - 2020-02-02 20:03:00 --> Hooks Class Initialized
ERROR - 2020-02-02 20:03:00 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 20:03:00 --> Loader Class Initialized
INFO - 2020-02-02 20:03:00 --> Config Class Initialized
INFO - 2020-02-02 20:03:00 --> Hooks Class Initialized
ERROR - 2020-02-02 20:03:00 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 20:03:00 --> Helper loaded: url_helper
DEBUG - 2020-02-02 20:03:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:00 --> Database Driver Class Initialized
INFO - 2020-02-02 20:03:00 --> Utf8 Class Initialized
DEBUG - 2020-02-02 20:03:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:03:00 --> Database Driver Class Initialized
INFO - 2020-02-02 20:03:00 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:03:00 --> URI Class Initialized
DEBUG - 2020-02-02 20:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:03:00 --> Controller Class Initialized
INFO - 2020-02-02 20:03:00 --> URI Class Initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
INFO - 2020-02-02 20:03:00 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:03:00 --> Router Class Initialized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
INFO - 2020-02-02 20:03:00 --> Output Class Initialized
INFO - 2020-02-02 20:03:00 --> Helper loaded: form_helper
INFO - 2020-02-02 20:03:00 --> Form Validation Class Initialized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:00 --> Security Class Initialized
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
DEBUG - 2020-02-02 20:03:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 20:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 20:03:00 --> Input Class Initialized
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
ERROR - 2020-02-02 20:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 20:03:00 --> Language Class Initialized
INFO - 2020-02-02 20:03:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-02 20:03:00 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 20:03:00 --> Final output sent to browser
ERROR - 2020-02-02 20:03:00 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-02 20:03:00 --> Total execution time: 0.6527
INFO - 2020-02-02 20:03:00 --> Config Class Initialized
INFO - 2020-02-02 20:03:00 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:03:01 --> Controller Class Initialized
DEBUG - 2020-02-02 20:03:01 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:01 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:01 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:03:01 --> URI Class Initialized
INFO - 2020-02-02 20:03:01 --> Helper loaded: form_helper
INFO - 2020-02-02 20:03:01 --> Form Validation Class Initialized
INFO - 2020-02-02 20:03:01 --> Router Class Initialized
INFO - 2020-02-02 20:03:01 --> Output Class Initialized
ERROR - 2020-02-02 20:03:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 20:03:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 20:03:01 --> Security Class Initialized
INFO - 2020-02-02 20:03:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-02 20:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:01 --> Input Class Initialized
INFO - 2020-02-02 20:03:01 --> Final output sent to browser
DEBUG - 2020-02-02 20:03:01 --> Total execution time: 0.8900
INFO - 2020-02-02 20:03:01 --> Language Class Initialized
ERROR - 2020-02-02 20:03:01 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 20:03:01 --> Config Class Initialized
INFO - 2020-02-02 20:03:01 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:01 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:01 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:01 --> URI Class Initialized
INFO - 2020-02-02 20:03:01 --> Router Class Initialized
INFO - 2020-02-02 20:03:01 --> Output Class Initialized
INFO - 2020-02-02 20:03:01 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:01 --> Input Class Initialized
INFO - 2020-02-02 20:03:01 --> Language Class Initialized
ERROR - 2020-02-02 20:03:01 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 20:03:01 --> Config Class Initialized
INFO - 2020-02-02 20:03:01 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:01 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:01 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:01 --> URI Class Initialized
INFO - 2020-02-02 20:03:01 --> Router Class Initialized
INFO - 2020-02-02 20:03:01 --> Output Class Initialized
INFO - 2020-02-02 20:03:01 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:01 --> Input Class Initialized
INFO - 2020-02-02 20:03:01 --> Language Class Initialized
ERROR - 2020-02-02 20:03:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 20:03:01 --> Config Class Initialized
INFO - 2020-02-02 20:03:02 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:02 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:02 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:02 --> URI Class Initialized
INFO - 2020-02-02 20:03:02 --> Router Class Initialized
INFO - 2020-02-02 20:03:02 --> Output Class Initialized
INFO - 2020-02-02 20:03:02 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:02 --> Input Class Initialized
INFO - 2020-02-02 20:03:02 --> Language Class Initialized
ERROR - 2020-02-02 20:03:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 20:03:03 --> Config Class Initialized
INFO - 2020-02-02 20:03:03 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:04 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:04 --> URI Class Initialized
INFO - 2020-02-02 20:03:04 --> Router Class Initialized
INFO - 2020-02-02 20:03:04 --> Output Class Initialized
INFO - 2020-02-02 20:03:04 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:04 --> Input Class Initialized
INFO - 2020-02-02 20:03:04 --> Language Class Initialized
ERROR - 2020-02-02 20:03:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 20:03:04 --> Config Class Initialized
INFO - 2020-02-02 20:03:04 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:04 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:04 --> URI Class Initialized
INFO - 2020-02-02 20:03:04 --> Router Class Initialized
INFO - 2020-02-02 20:03:04 --> Output Class Initialized
INFO - 2020-02-02 20:03:04 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:04 --> Input Class Initialized
INFO - 2020-02-02 20:03:04 --> Language Class Initialized
ERROR - 2020-02-02 20:03:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 20:03:04 --> Config Class Initialized
INFO - 2020-02-02 20:03:04 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:04 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:04 --> URI Class Initialized
INFO - 2020-02-02 20:03:04 --> Router Class Initialized
INFO - 2020-02-02 20:03:04 --> Output Class Initialized
INFO - 2020-02-02 20:03:04 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:04 --> Input Class Initialized
INFO - 2020-02-02 20:03:04 --> Language Class Initialized
ERROR - 2020-02-02 20:03:04 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 20:03:05 --> Config Class Initialized
INFO - 2020-02-02 20:03:05 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:05 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:05 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:05 --> URI Class Initialized
INFO - 2020-02-02 20:03:05 --> Router Class Initialized
INFO - 2020-02-02 20:03:05 --> Output Class Initialized
INFO - 2020-02-02 20:03:05 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:05 --> Input Class Initialized
INFO - 2020-02-02 20:03:05 --> Language Class Initialized
ERROR - 2020-02-02 20:03:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 20:03:05 --> Config Class Initialized
INFO - 2020-02-02 20:03:05 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:05 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:05 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:05 --> URI Class Initialized
INFO - 2020-02-02 20:03:05 --> Router Class Initialized
INFO - 2020-02-02 20:03:05 --> Output Class Initialized
INFO - 2020-02-02 20:03:05 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:05 --> Input Class Initialized
INFO - 2020-02-02 20:03:05 --> Language Class Initialized
ERROR - 2020-02-02 20:03:05 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 20:03:09 --> Config Class Initialized
INFO - 2020-02-02 20:03:09 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:09 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:09 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:09 --> URI Class Initialized
INFO - 2020-02-02 20:03:09 --> Router Class Initialized
INFO - 2020-02-02 20:03:09 --> Output Class Initialized
INFO - 2020-02-02 20:03:09 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:09 --> Input Class Initialized
INFO - 2020-02-02 20:03:09 --> Language Class Initialized
INFO - 2020-02-02 20:03:09 --> Loader Class Initialized
INFO - 2020-02-02 20:03:09 --> Helper loaded: url_helper
INFO - 2020-02-02 20:03:09 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:03:10 --> Controller Class Initialized
INFO - 2020-02-02 20:03:10 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:03:10 --> Helper loaded: form_helper
INFO - 2020-02-02 20:03:10 --> Form Validation Class Initialized
INFO - 2020-02-02 20:03:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\component/menu.php
INFO - 2020-02-02 20:03:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/edit_form.php
INFO - 2020-02-02 20:03:10 --> Final output sent to browser
DEBUG - 2020-02-02 20:03:10 --> Total execution time: 0.5399
INFO - 2020-02-02 20:03:42 --> Config Class Initialized
INFO - 2020-02-02 20:03:42 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:43 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:43 --> URI Class Initialized
INFO - 2020-02-02 20:03:43 --> Router Class Initialized
INFO - 2020-02-02 20:03:43 --> Output Class Initialized
INFO - 2020-02-02 20:03:43 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:43 --> Input Class Initialized
INFO - 2020-02-02 20:03:43 --> Language Class Initialized
INFO - 2020-02-02 20:03:43 --> Loader Class Initialized
INFO - 2020-02-02 20:03:43 --> Helper loaded: url_helper
INFO - 2020-02-02 20:03:43 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:03:43 --> Controller Class Initialized
INFO - 2020-02-02 20:03:43 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:03:43 --> Helper loaded: form_helper
INFO - 2020-02-02 20:03:43 --> Form Validation Class Initialized
INFO - 2020-02-02 20:03:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:03:43 --> Final output sent to browser
INFO - 2020-02-02 20:03:43 --> Config Class Initialized
INFO - 2020-02-02 20:03:43 --> Config Class Initialized
INFO - 2020-02-02 20:03:43 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:43 --> Total execution time: 0.5476
INFO - 2020-02-02 20:03:43 --> Config Class Initialized
INFO - 2020-02-02 20:03:43 --> Config Class Initialized
INFO - 2020-02-02 20:03:43 --> Config Class Initialized
INFO - 2020-02-02 20:03:43 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:43 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:43 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:43 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:43 --> Config Class Initialized
INFO - 2020-02-02 20:03:43 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:03:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:43 --> Utf8 Class Initialized
DEBUG - 2020-02-02 20:03:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:43 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:43 --> URI Class Initialized
INFO - 2020-02-02 20:03:43 --> Utf8 Class Initialized
DEBUG - 2020-02-02 20:03:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:43 --> Utf8 Class Initialized
DEBUG - 2020-02-02 20:03:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:43 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:43 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:43 --> Router Class Initialized
INFO - 2020-02-02 20:03:43 --> URI Class Initialized
INFO - 2020-02-02 20:03:43 --> URI Class Initialized
INFO - 2020-02-02 20:03:43 --> URI Class Initialized
INFO - 2020-02-02 20:03:43 --> Router Class Initialized
INFO - 2020-02-02 20:03:43 --> Router Class Initialized
INFO - 2020-02-02 20:03:43 --> URI Class Initialized
INFO - 2020-02-02 20:03:43 --> Output Class Initialized
INFO - 2020-02-02 20:03:43 --> URI Class Initialized
INFO - 2020-02-02 20:03:43 --> Router Class Initialized
INFO - 2020-02-02 20:03:43 --> Security Class Initialized
INFO - 2020-02-02 20:03:43 --> Output Class Initialized
INFO - 2020-02-02 20:03:43 --> Router Class Initialized
INFO - 2020-02-02 20:03:43 --> Output Class Initialized
INFO - 2020-02-02 20:03:43 --> Output Class Initialized
INFO - 2020-02-02 20:03:43 --> Router Class Initialized
INFO - 2020-02-02 20:03:43 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:43 --> Output Class Initialized
INFO - 2020-02-02 20:03:43 --> Output Class Initialized
INFO - 2020-02-02 20:03:43 --> Security Class Initialized
INFO - 2020-02-02 20:03:43 --> Security Class Initialized
INFO - 2020-02-02 20:03:43 --> Input Class Initialized
DEBUG - 2020-02-02 20:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:43 --> Security Class Initialized
INFO - 2020-02-02 20:03:43 --> Security Class Initialized
INFO - 2020-02-02 20:03:43 --> Input Class Initialized
INFO - 2020-02-02 20:03:43 --> Input Class Initialized
INFO - 2020-02-02 20:03:43 --> Input Class Initialized
INFO - 2020-02-02 20:03:43 --> Language Class Initialized
DEBUG - 2020-02-02 20:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:43 --> Input Class Initialized
INFO - 2020-02-02 20:03:43 --> Language Class Initialized
INFO - 2020-02-02 20:03:43 --> Language Class Initialized
INFO - 2020-02-02 20:03:43 --> Input Class Initialized
INFO - 2020-02-02 20:03:43 --> Language Class Initialized
INFO - 2020-02-02 20:03:43 --> Loader Class Initialized
INFO - 2020-02-02 20:03:43 --> Language Class Initialized
ERROR - 2020-02-02 20:03:43 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-02 20:03:43 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 20:03:43 --> Helper loaded: url_helper
INFO - 2020-02-02 20:03:43 --> Language Class Initialized
ERROR - 2020-02-02 20:03:43 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 20:03:44 --> Loader Class Initialized
ERROR - 2020-02-02 20:03:44 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 20:03:44 --> Config Class Initialized
INFO - 2020-02-02 20:03:44 --> Database Driver Class Initialized
INFO - 2020-02-02 20:03:44 --> Config Class Initialized
INFO - 2020-02-02 20:03:44 --> Config Class Initialized
INFO - 2020-02-02 20:03:44 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:44 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:44 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:44 --> Helper loaded: url_helper
DEBUG - 2020-02-02 20:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:03:44 --> Config Class Initialized
INFO - 2020-02-02 20:03:44 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-02 20:03:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:03:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:03:44 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:44 --> Database Driver Class Initialized
INFO - 2020-02-02 20:03:44 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:44 --> Controller Class Initialized
INFO - 2020-02-02 20:03:44 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:44 --> Utf8 Class Initialized
DEBUG - 2020-02-02 20:03:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:03:44 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:44 --> URI Class Initialized
INFO - 2020-02-02 20:03:44 --> URI Class Initialized
INFO - 2020-02-02 20:03:44 --> URI Class Initialized
INFO - 2020-02-02 20:03:44 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:03:44 --> URI Class Initialized
INFO - 2020-02-02 20:03:44 --> Router Class Initialized
INFO - 2020-02-02 20:03:44 --> Router Class Initialized
INFO - 2020-02-02 20:03:44 --> Router Class Initialized
INFO - 2020-02-02 20:03:44 --> Helper loaded: form_helper
INFO - 2020-02-02 20:03:44 --> Router Class Initialized
INFO - 2020-02-02 20:03:44 --> Form Validation Class Initialized
INFO - 2020-02-02 20:03:44 --> Output Class Initialized
INFO - 2020-02-02 20:03:44 --> Output Class Initialized
INFO - 2020-02-02 20:03:44 --> Output Class Initialized
INFO - 2020-02-02 20:03:44 --> Security Class Initialized
INFO - 2020-02-02 20:03:44 --> Security Class Initialized
INFO - 2020-02-02 20:03:44 --> Output Class Initialized
ERROR - 2020-02-02 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 20:03:44 --> Security Class Initialized
ERROR - 2020-02-02 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-02 20:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:44 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:44 --> Input Class Initialized
INFO - 2020-02-02 20:03:44 --> Input Class Initialized
INFO - 2020-02-02 20:03:44 --> Input Class Initialized
INFO - 2020-02-02 20:03:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-02 20:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:44 --> Final output sent to browser
INFO - 2020-02-02 20:03:44 --> Input Class Initialized
INFO - 2020-02-02 20:03:44 --> Language Class Initialized
INFO - 2020-02-02 20:03:44 --> Language Class Initialized
INFO - 2020-02-02 20:03:44 --> Language Class Initialized
DEBUG - 2020-02-02 20:03:44 --> Total execution time: 0.6680
INFO - 2020-02-02 20:03:44 --> Language Class Initialized
ERROR - 2020-02-02 20:03:44 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-02 20:03:44 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 20:03:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 20:03:44 --> Session: Class initialized using 'files' driver.
ERROR - 2020-02-02 20:03:44 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 20:03:44 --> Config Class Initialized
INFO - 2020-02-02 20:03:44 --> Config Class Initialized
INFO - 2020-02-02 20:03:44 --> Config Class Initialized
INFO - 2020-02-02 20:03:44 --> Config Class Initialized
INFO - 2020-02-02 20:03:44 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:44 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:44 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:44 --> Hooks Class Initialized
INFO - 2020-02-02 20:03:44 --> Controller Class Initialized
INFO - 2020-02-02 20:03:44 --> Model "M_tiket" initialized
DEBUG - 2020-02-02 20:03:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:03:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:03:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:03:44 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:44 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:44 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:44 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:44 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:44 --> Helper loaded: form_helper
INFO - 2020-02-02 20:03:44 --> Form Validation Class Initialized
INFO - 2020-02-02 20:03:44 --> URI Class Initialized
INFO - 2020-02-02 20:03:44 --> URI Class Initialized
INFO - 2020-02-02 20:03:44 --> URI Class Initialized
INFO - 2020-02-02 20:03:44 --> URI Class Initialized
INFO - 2020-02-02 20:03:44 --> Router Class Initialized
INFO - 2020-02-02 20:03:44 --> Router Class Initialized
INFO - 2020-02-02 20:03:44 --> Router Class Initialized
INFO - 2020-02-02 20:03:44 --> Router Class Initialized
ERROR - 2020-02-02 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 20:03:44 --> Output Class Initialized
INFO - 2020-02-02 20:03:44 --> Output Class Initialized
INFO - 2020-02-02 20:03:44 --> Output Class Initialized
INFO - 2020-02-02 20:03:44 --> Output Class Initialized
INFO - 2020-02-02 20:03:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:03:44 --> Security Class Initialized
INFO - 2020-02-02 20:03:44 --> Security Class Initialized
INFO - 2020-02-02 20:03:44 --> Security Class Initialized
INFO - 2020-02-02 20:03:44 --> Security Class Initialized
INFO - 2020-02-02 20:03:44 --> Final output sent to browser
DEBUG - 2020-02-02 20:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:44 --> Input Class Initialized
INFO - 2020-02-02 20:03:44 --> Input Class Initialized
DEBUG - 2020-02-02 20:03:44 --> Total execution time: 1.0138
INFO - 2020-02-02 20:03:44 --> Input Class Initialized
INFO - 2020-02-02 20:03:44 --> Input Class Initialized
INFO - 2020-02-02 20:03:44 --> Language Class Initialized
INFO - 2020-02-02 20:03:44 --> Language Class Initialized
INFO - 2020-02-02 20:03:44 --> Language Class Initialized
INFO - 2020-02-02 20:03:44 --> Language Class Initialized
ERROR - 2020-02-02 20:03:44 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-02 20:03:44 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-02 20:03:44 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-02 20:03:44 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 20:03:44 --> Config Class Initialized
INFO - 2020-02-02 20:03:44 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:44 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:44 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:44 --> URI Class Initialized
INFO - 2020-02-02 20:03:44 --> Router Class Initialized
INFO - 2020-02-02 20:03:44 --> Output Class Initialized
INFO - 2020-02-02 20:03:44 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:44 --> Input Class Initialized
INFO - 2020-02-02 20:03:44 --> Language Class Initialized
ERROR - 2020-02-02 20:03:44 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 20:03:45 --> Config Class Initialized
INFO - 2020-02-02 20:03:45 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:45 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:45 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:45 --> URI Class Initialized
INFO - 2020-02-02 20:03:45 --> Router Class Initialized
INFO - 2020-02-02 20:03:45 --> Output Class Initialized
INFO - 2020-02-02 20:03:45 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:45 --> Input Class Initialized
INFO - 2020-02-02 20:03:45 --> Language Class Initialized
ERROR - 2020-02-02 20:03:45 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 20:03:45 --> Config Class Initialized
INFO - 2020-02-02 20:03:45 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:45 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:45 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:45 --> URI Class Initialized
INFO - 2020-02-02 20:03:45 --> Router Class Initialized
INFO - 2020-02-02 20:03:45 --> Output Class Initialized
INFO - 2020-02-02 20:03:45 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:45 --> Input Class Initialized
INFO - 2020-02-02 20:03:45 --> Language Class Initialized
ERROR - 2020-02-02 20:03:45 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 20:03:45 --> Config Class Initialized
INFO - 2020-02-02 20:03:45 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:45 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:45 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:45 --> URI Class Initialized
INFO - 2020-02-02 20:03:45 --> Router Class Initialized
INFO - 2020-02-02 20:03:45 --> Output Class Initialized
INFO - 2020-02-02 20:03:45 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:45 --> Input Class Initialized
INFO - 2020-02-02 20:03:45 --> Language Class Initialized
ERROR - 2020-02-02 20:03:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 20:03:46 --> Config Class Initialized
INFO - 2020-02-02 20:03:46 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:46 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:46 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:46 --> URI Class Initialized
INFO - 2020-02-02 20:03:46 --> Router Class Initialized
INFO - 2020-02-02 20:03:46 --> Output Class Initialized
INFO - 2020-02-02 20:03:46 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:46 --> Input Class Initialized
INFO - 2020-02-02 20:03:46 --> Language Class Initialized
ERROR - 2020-02-02 20:03:46 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 20:03:46 --> Config Class Initialized
INFO - 2020-02-02 20:03:46 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:46 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:46 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:46 --> URI Class Initialized
INFO - 2020-02-02 20:03:46 --> Router Class Initialized
INFO - 2020-02-02 20:03:46 --> Output Class Initialized
INFO - 2020-02-02 20:03:46 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:46 --> Input Class Initialized
INFO - 2020-02-02 20:03:46 --> Language Class Initialized
ERROR - 2020-02-02 20:03:46 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 20:03:46 --> Config Class Initialized
INFO - 2020-02-02 20:03:46 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:46 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:46 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:46 --> URI Class Initialized
INFO - 2020-02-02 20:03:46 --> Router Class Initialized
INFO - 2020-02-02 20:03:46 --> Output Class Initialized
INFO - 2020-02-02 20:03:46 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:46 --> Input Class Initialized
INFO - 2020-02-02 20:03:46 --> Language Class Initialized
ERROR - 2020-02-02 20:03:46 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 20:03:46 --> Config Class Initialized
INFO - 2020-02-02 20:03:46 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:47 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:47 --> URI Class Initialized
INFO - 2020-02-02 20:03:47 --> Router Class Initialized
INFO - 2020-02-02 20:03:47 --> Output Class Initialized
INFO - 2020-02-02 20:03:47 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:47 --> Input Class Initialized
INFO - 2020-02-02 20:03:47 --> Language Class Initialized
ERROR - 2020-02-02 20:03:47 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 20:03:47 --> Config Class Initialized
INFO - 2020-02-02 20:03:47 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:03:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:03:47 --> Utf8 Class Initialized
INFO - 2020-02-02 20:03:47 --> URI Class Initialized
INFO - 2020-02-02 20:03:47 --> Router Class Initialized
INFO - 2020-02-02 20:03:47 --> Output Class Initialized
INFO - 2020-02-02 20:03:47 --> Security Class Initialized
DEBUG - 2020-02-02 20:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:03:47 --> Input Class Initialized
INFO - 2020-02-02 20:03:47 --> Language Class Initialized
ERROR - 2020-02-02 20:03:47 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 20:04:07 --> Config Class Initialized
INFO - 2020-02-02 20:04:07 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:07 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:07 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:07 --> URI Class Initialized
INFO - 2020-02-02 20:04:07 --> Router Class Initialized
INFO - 2020-02-02 20:04:07 --> Output Class Initialized
INFO - 2020-02-02 20:04:07 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:07 --> Input Class Initialized
INFO - 2020-02-02 20:04:07 --> Language Class Initialized
INFO - 2020-02-02 20:04:07 --> Loader Class Initialized
INFO - 2020-02-02 20:04:07 --> Helper loaded: url_helper
INFO - 2020-02-02 20:04:07 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:04:07 --> Controller Class Initialized
INFO - 2020-02-02 20:04:08 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:04:08 --> Helper loaded: form_helper
INFO - 2020-02-02 20:04:08 --> Form Validation Class Initialized
INFO - 2020-02-02 20:04:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:04:08 --> Final output sent to browser
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:08 --> Total execution time: 0.5272
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:08 --> URI Class Initialized
INFO - 2020-02-02 20:04:08 --> URI Class Initialized
INFO - 2020-02-02 20:04:08 --> URI Class Initialized
INFO - 2020-02-02 20:04:08 --> URI Class Initialized
INFO - 2020-02-02 20:04:08 --> URI Class Initialized
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:08 --> Router Class Initialized
INFO - 2020-02-02 20:04:08 --> Router Class Initialized
INFO - 2020-02-02 20:04:08 --> Router Class Initialized
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:08 --> Router Class Initialized
INFO - 2020-02-02 20:04:08 --> Router Class Initialized
INFO - 2020-02-02 20:04:08 --> Output Class Initialized
INFO - 2020-02-02 20:04:08 --> Output Class Initialized
INFO - 2020-02-02 20:04:08 --> URI Class Initialized
INFO - 2020-02-02 20:04:08 --> Output Class Initialized
INFO - 2020-02-02 20:04:08 --> Output Class Initialized
INFO - 2020-02-02 20:04:08 --> Output Class Initialized
INFO - 2020-02-02 20:04:08 --> Security Class Initialized
INFO - 2020-02-02 20:04:08 --> Security Class Initialized
INFO - 2020-02-02 20:04:08 --> Security Class Initialized
INFO - 2020-02-02 20:04:08 --> Security Class Initialized
INFO - 2020-02-02 20:04:08 --> Router Class Initialized
DEBUG - 2020-02-02 20:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:08 --> Security Class Initialized
INFO - 2020-02-02 20:04:08 --> Input Class Initialized
INFO - 2020-02-02 20:04:08 --> Input Class Initialized
INFO - 2020-02-02 20:04:08 --> Input Class Initialized
DEBUG - 2020-02-02 20:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:08 --> Output Class Initialized
DEBUG - 2020-02-02 20:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:08 --> Input Class Initialized
INFO - 2020-02-02 20:04:08 --> Language Class Initialized
INFO - 2020-02-02 20:04:08 --> Language Class Initialized
INFO - 2020-02-02 20:04:08 --> Input Class Initialized
INFO - 2020-02-02 20:04:08 --> Security Class Initialized
INFO - 2020-02-02 20:04:08 --> Language Class Initialized
INFO - 2020-02-02 20:04:08 --> Language Class Initialized
ERROR - 2020-02-02 20:04:08 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 20:04:08 --> Language Class Initialized
DEBUG - 2020-02-02 20:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:08 --> Loader Class Initialized
ERROR - 2020-02-02 20:04:08 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 20:04:08 --> Input Class Initialized
INFO - 2020-02-02 20:04:08 --> Helper loaded: url_helper
ERROR - 2020-02-02 20:04:08 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 20:04:08 --> Loader Class Initialized
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
INFO - 2020-02-02 20:04:08 --> Helper loaded: url_helper
INFO - 2020-02-02 20:04:08 --> Language Class Initialized
INFO - 2020-02-02 20:04:08 --> Database Driver Class Initialized
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
ERROR - 2020-02-02 20:04:08 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:08 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
INFO - 2020-02-02 20:04:08 --> Controller Class Initialized
INFO - 2020-02-02 20:04:08 --> URI Class Initialized
INFO - 2020-02-02 20:04:08 --> URI Class Initialized
INFO - 2020-02-02 20:04:08 --> Router Class Initialized
INFO - 2020-02-02 20:04:08 --> URI Class Initialized
INFO - 2020-02-02 20:04:08 --> Router Class Initialized
INFO - 2020-02-02 20:04:08 --> Model "M_tiket" initialized
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:08 --> Output Class Initialized
INFO - 2020-02-02 20:04:08 --> Output Class Initialized
INFO - 2020-02-02 20:04:08 --> Router Class Initialized
INFO - 2020-02-02 20:04:08 --> Helper loaded: form_helper
INFO - 2020-02-02 20:04:08 --> URI Class Initialized
INFO - 2020-02-02 20:04:08 --> Security Class Initialized
INFO - 2020-02-02 20:04:08 --> Form Validation Class Initialized
INFO - 2020-02-02 20:04:08 --> Output Class Initialized
INFO - 2020-02-02 20:04:08 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:08 --> Security Class Initialized
INFO - 2020-02-02 20:04:08 --> Router Class Initialized
DEBUG - 2020-02-02 20:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 20:04:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-02 20:04:08 --> Input Class Initialized
INFO - 2020-02-02 20:04:08 --> Input Class Initialized
DEBUG - 2020-02-02 20:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-02 20:04:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 20:04:08 --> Output Class Initialized
INFO - 2020-02-02 20:04:08 --> Input Class Initialized
INFO - 2020-02-02 20:04:08 --> Language Class Initialized
INFO - 2020-02-02 20:04:08 --> Language Class Initialized
INFO - 2020-02-02 20:04:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:04:08 --> Security Class Initialized
INFO - 2020-02-02 20:04:08 --> Language Class Initialized
ERROR - 2020-02-02 20:04:08 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-02 20:04:08 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-02 20:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:08 --> Final output sent to browser
DEBUG - 2020-02-02 20:04:08 --> Total execution time: 0.6658
INFO - 2020-02-02 20:04:08 --> Input Class Initialized
ERROR - 2020-02-02 20:04:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
INFO - 2020-02-02 20:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
INFO - 2020-02-02 20:04:08 --> Language Class Initialized
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Config Class Initialized
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
INFO - 2020-02-02 20:04:08 --> Controller Class Initialized
ERROR - 2020-02-02 20:04:08 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 20:04:08 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:08 --> Model "M_tiket" initialized
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:04:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:08 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:08 --> URI Class Initialized
INFO - 2020-02-02 20:04:08 --> URI Class Initialized
INFO - 2020-02-02 20:04:08 --> Helper loaded: form_helper
INFO - 2020-02-02 20:04:09 --> Form Validation Class Initialized
INFO - 2020-02-02 20:04:09 --> URI Class Initialized
INFO - 2020-02-02 20:04:09 --> URI Class Initialized
INFO - 2020-02-02 20:04:09 --> Router Class Initialized
INFO - 2020-02-02 20:04:09 --> Router Class Initialized
INFO - 2020-02-02 20:04:09 --> Router Class Initialized
INFO - 2020-02-02 20:04:09 --> Output Class Initialized
INFO - 2020-02-02 20:04:09 --> Output Class Initialized
INFO - 2020-02-02 20:04:09 --> Router Class Initialized
ERROR - 2020-02-02 20:04:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 20:04:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 20:04:09 --> Security Class Initialized
INFO - 2020-02-02 20:04:09 --> Output Class Initialized
INFO - 2020-02-02 20:04:09 --> Security Class Initialized
INFO - 2020-02-02 20:04:09 --> Output Class Initialized
INFO - 2020-02-02 20:04:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-02 20:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:09 --> Security Class Initialized
INFO - 2020-02-02 20:04:09 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:09 --> Input Class Initialized
INFO - 2020-02-02 20:04:09 --> Final output sent to browser
DEBUG - 2020-02-02 20:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:09 --> Input Class Initialized
DEBUG - 2020-02-02 20:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:09 --> Input Class Initialized
INFO - 2020-02-02 20:04:09 --> Input Class Initialized
DEBUG - 2020-02-02 20:04:09 --> Total execution time: 0.9410
INFO - 2020-02-02 20:04:09 --> Language Class Initialized
INFO - 2020-02-02 20:04:09 --> Language Class Initialized
INFO - 2020-02-02 20:04:09 --> Language Class Initialized
ERROR - 2020-02-02 20:04:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 20:04:09 --> Language Class Initialized
ERROR - 2020-02-02 20:04:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-02 20:04:09 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-02 20:04:09 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-02 20:04:09 --> Config Class Initialized
INFO - 2020-02-02 20:04:09 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:09 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:09 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:09 --> URI Class Initialized
INFO - 2020-02-02 20:04:09 --> Router Class Initialized
INFO - 2020-02-02 20:04:09 --> Output Class Initialized
INFO - 2020-02-02 20:04:09 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:09 --> Input Class Initialized
INFO - 2020-02-02 20:04:09 --> Language Class Initialized
ERROR - 2020-02-02 20:04:09 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-02 20:04:09 --> Config Class Initialized
INFO - 2020-02-02 20:04:09 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:09 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:09 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:09 --> URI Class Initialized
INFO - 2020-02-02 20:04:09 --> Router Class Initialized
INFO - 2020-02-02 20:04:09 --> Output Class Initialized
INFO - 2020-02-02 20:04:09 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:09 --> Input Class Initialized
INFO - 2020-02-02 20:04:09 --> Language Class Initialized
ERROR - 2020-02-02 20:04:09 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-02 20:04:09 --> Config Class Initialized
INFO - 2020-02-02 20:04:09 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:09 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:09 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:09 --> URI Class Initialized
INFO - 2020-02-02 20:04:09 --> Router Class Initialized
INFO - 2020-02-02 20:04:09 --> Output Class Initialized
INFO - 2020-02-02 20:04:10 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:10 --> Input Class Initialized
INFO - 2020-02-02 20:04:10 --> Language Class Initialized
ERROR - 2020-02-02 20:04:10 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-02 20:04:10 --> Config Class Initialized
INFO - 2020-02-02 20:04:10 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:10 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:10 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:10 --> URI Class Initialized
INFO - 2020-02-02 20:04:10 --> Router Class Initialized
INFO - 2020-02-02 20:04:10 --> Output Class Initialized
INFO - 2020-02-02 20:04:10 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:10 --> Input Class Initialized
INFO - 2020-02-02 20:04:10 --> Language Class Initialized
ERROR - 2020-02-02 20:04:10 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 20:04:10 --> Config Class Initialized
INFO - 2020-02-02 20:04:10 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:10 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:10 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:10 --> URI Class Initialized
INFO - 2020-02-02 20:04:10 --> Router Class Initialized
INFO - 2020-02-02 20:04:10 --> Output Class Initialized
INFO - 2020-02-02 20:04:10 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:10 --> Input Class Initialized
INFO - 2020-02-02 20:04:10 --> Language Class Initialized
ERROR - 2020-02-02 20:04:10 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-02 20:04:10 --> Config Class Initialized
INFO - 2020-02-02 20:04:10 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:10 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:10 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:10 --> URI Class Initialized
INFO - 2020-02-02 20:04:10 --> Router Class Initialized
INFO - 2020-02-02 20:04:10 --> Output Class Initialized
INFO - 2020-02-02 20:04:10 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:10 --> Input Class Initialized
INFO - 2020-02-02 20:04:11 --> Language Class Initialized
ERROR - 2020-02-02 20:04:11 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-02 20:04:11 --> Config Class Initialized
INFO - 2020-02-02 20:04:11 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:11 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:11 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:11 --> URI Class Initialized
INFO - 2020-02-02 20:04:11 --> Router Class Initialized
INFO - 2020-02-02 20:04:11 --> Output Class Initialized
INFO - 2020-02-02 20:04:11 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:11 --> Input Class Initialized
INFO - 2020-02-02 20:04:11 --> Language Class Initialized
ERROR - 2020-02-02 20:04:11 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-02 20:04:11 --> Config Class Initialized
INFO - 2020-02-02 20:04:11 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:11 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:11 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:11 --> URI Class Initialized
INFO - 2020-02-02 20:04:11 --> Router Class Initialized
INFO - 2020-02-02 20:04:11 --> Output Class Initialized
INFO - 2020-02-02 20:04:11 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:11 --> Input Class Initialized
INFO - 2020-02-02 20:04:11 --> Language Class Initialized
ERROR - 2020-02-02 20:04:11 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-02 20:04:11 --> Config Class Initialized
INFO - 2020-02-02 20:04:11 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:11 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:11 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:11 --> URI Class Initialized
INFO - 2020-02-02 20:04:11 --> Router Class Initialized
INFO - 2020-02-02 20:04:11 --> Output Class Initialized
INFO - 2020-02-02 20:04:12 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:12 --> Input Class Initialized
INFO - 2020-02-02 20:04:12 --> Language Class Initialized
ERROR - 2020-02-02 20:04:12 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-02 20:04:21 --> Config Class Initialized
INFO - 2020-02-02 20:04:21 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:21 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:21 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:21 --> URI Class Initialized
INFO - 2020-02-02 20:04:21 --> Router Class Initialized
INFO - 2020-02-02 20:04:21 --> Output Class Initialized
INFO - 2020-02-02 20:04:21 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:21 --> Input Class Initialized
INFO - 2020-02-02 20:04:21 --> Language Class Initialized
INFO - 2020-02-02 20:04:21 --> Loader Class Initialized
INFO - 2020-02-02 20:04:21 --> Helper loaded: url_helper
INFO - 2020-02-02 20:04:21 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:04:21 --> Controller Class Initialized
INFO - 2020-02-02 20:04:21 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:04:21 --> Helper loaded: form_helper
INFO - 2020-02-02 20:04:21 --> Form Validation Class Initialized
INFO - 2020-02-02 20:04:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\component/menu.php
INFO - 2020-02-02 20:04:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/edit_form.php
INFO - 2020-02-02 20:04:21 --> Final output sent to browser
DEBUG - 2020-02-02 20:04:21 --> Total execution time: 0.6509
INFO - 2020-02-02 20:04:23 --> Config Class Initialized
INFO - 2020-02-02 20:04:23 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:23 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:23 --> URI Class Initialized
INFO - 2020-02-02 20:04:23 --> Router Class Initialized
INFO - 2020-02-02 20:04:23 --> Output Class Initialized
INFO - 2020-02-02 20:04:23 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:23 --> Input Class Initialized
INFO - 2020-02-02 20:04:23 --> Language Class Initialized
INFO - 2020-02-02 20:04:23 --> Loader Class Initialized
INFO - 2020-02-02 20:04:23 --> Helper loaded: url_helper
INFO - 2020-02-02 20:04:23 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:04:24 --> Controller Class Initialized
INFO - 2020-02-02 20:04:24 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:04:24 --> Helper loaded: form_helper
INFO - 2020-02-02 20:04:24 --> Form Validation Class Initialized
INFO - 2020-02-02 20:04:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:04:24 --> Final output sent to browser
INFO - 2020-02-02 20:04:24 --> Config Class Initialized
INFO - 2020-02-02 20:04:24 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:24 --> Total execution time: 0.6492
INFO - 2020-02-02 20:04:24 --> Config Class Initialized
INFO - 2020-02-02 20:04:24 --> Config Class Initialized
INFO - 2020-02-02 20:04:24 --> Hooks Class Initialized
INFO - 2020-02-02 20:04:24 --> Hooks Class Initialized
DEBUG - 2020-02-02 20:04:24 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:24 --> Utf8 Class Initialized
DEBUG - 2020-02-02 20:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-02 20:04:24 --> UTF-8 Support Enabled
INFO - 2020-02-02 20:04:24 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:24 --> Utf8 Class Initialized
INFO - 2020-02-02 20:04:24 --> URI Class Initialized
INFO - 2020-02-02 20:04:24 --> URI Class Initialized
INFO - 2020-02-02 20:04:24 --> Router Class Initialized
INFO - 2020-02-02 20:04:24 --> URI Class Initialized
INFO - 2020-02-02 20:04:24 --> Router Class Initialized
INFO - 2020-02-02 20:04:24 --> Router Class Initialized
INFO - 2020-02-02 20:04:24 --> Output Class Initialized
INFO - 2020-02-02 20:04:24 --> Security Class Initialized
INFO - 2020-02-02 20:04:24 --> Output Class Initialized
INFO - 2020-02-02 20:04:24 --> Output Class Initialized
INFO - 2020-02-02 20:04:24 --> Security Class Initialized
INFO - 2020-02-02 20:04:24 --> Security Class Initialized
DEBUG - 2020-02-02 20:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:24 --> Input Class Initialized
DEBUG - 2020-02-02 20:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-02 20:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 20:04:24 --> Input Class Initialized
INFO - 2020-02-02 20:04:24 --> Input Class Initialized
INFO - 2020-02-02 20:04:24 --> Language Class Initialized
INFO - 2020-02-02 20:04:24 --> Language Class Initialized
INFO - 2020-02-02 20:04:24 --> Language Class Initialized
ERROR - 2020-02-02 20:04:24 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-02 20:04:24 --> Loader Class Initialized
INFO - 2020-02-02 20:04:24 --> Loader Class Initialized
INFO - 2020-02-02 20:04:24 --> Helper loaded: url_helper
INFO - 2020-02-02 20:04:24 --> Helper loaded: url_helper
INFO - 2020-02-02 20:04:24 --> Database Driver Class Initialized
INFO - 2020-02-02 20:04:24 --> Database Driver Class Initialized
DEBUG - 2020-02-02 20:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-02 20:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 20:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:04:24 --> Controller Class Initialized
INFO - 2020-02-02 20:04:24 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:04:24 --> Helper loaded: form_helper
INFO - 2020-02-02 20:04:24 --> Form Validation Class Initialized
ERROR - 2020-02-02 20:04:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 20:04:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 20:04:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:04:24 --> Final output sent to browser
DEBUG - 2020-02-02 20:04:24 --> Total execution time: 0.6714
INFO - 2020-02-02 20:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 20:04:25 --> Controller Class Initialized
INFO - 2020-02-02 20:04:25 --> Model "M_tiket" initialized
INFO - 2020-02-02 20:04:25 --> Helper loaded: form_helper
INFO - 2020-02-02 20:04:25 --> Form Validation Class Initialized
ERROR - 2020-02-02 20:04:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-02 20:04:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-02 20:04:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-02 20:04:25 --> Final output sent to browser
DEBUG - 2020-02-02 20:04:25 --> Total execution time: 0.9702
