<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-03 07:34:33 --> Config Class Initialized
INFO - 2020-01-03 07:34:33 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:34:33 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:34:33 --> Utf8 Class Initialized
INFO - 2020-01-03 07:34:34 --> URI Class Initialized
DEBUG - 2020-01-03 07:34:34 --> No URI present. Default controller set.
INFO - 2020-01-03 07:34:34 --> Router Class Initialized
INFO - 2020-01-03 07:34:34 --> Output Class Initialized
INFO - 2020-01-03 07:34:34 --> Security Class Initialized
DEBUG - 2020-01-03 07:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:34:34 --> Input Class Initialized
INFO - 2020-01-03 07:34:35 --> Language Class Initialized
INFO - 2020-01-03 07:34:35 --> Loader Class Initialized
INFO - 2020-01-03 07:34:35 --> Helper loaded: url_helper
INFO - 2020-01-03 07:34:35 --> Database Driver Class Initialized
DEBUG - 2020-01-03 07:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-03 07:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-03 07:34:36 --> Controller Class Initialized
INFO - 2020-01-03 07:34:36 --> Model "M_login" initialized
INFO - 2020-01-03 07:34:36 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2020-01-03 07:34:36 --> Final output sent to browser
DEBUG - 2020-01-03 07:34:36 --> Total execution time: 3.1758
INFO - 2020-01-03 07:34:41 --> Config Class Initialized
INFO - 2020-01-03 07:34:41 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:34:42 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:34:42 --> Utf8 Class Initialized
INFO - 2020-01-03 07:34:42 --> URI Class Initialized
INFO - 2020-01-03 07:34:42 --> Router Class Initialized
INFO - 2020-01-03 07:34:42 --> Output Class Initialized
INFO - 2020-01-03 07:34:42 --> Security Class Initialized
DEBUG - 2020-01-03 07:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:34:42 --> Input Class Initialized
INFO - 2020-01-03 07:34:42 --> Language Class Initialized
INFO - 2020-01-03 07:34:42 --> Loader Class Initialized
INFO - 2020-01-03 07:34:42 --> Helper loaded: url_helper
INFO - 2020-01-03 07:34:42 --> Database Driver Class Initialized
DEBUG - 2020-01-03 07:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-03 07:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-03 07:34:42 --> Controller Class Initialized
INFO - 2020-01-03 07:34:42 --> Model "M_login" initialized
INFO - 2020-01-03 07:34:42 --> Config Class Initialized
INFO - 2020-01-03 07:34:42 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:34:42 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:34:42 --> Utf8 Class Initialized
INFO - 2020-01-03 07:34:42 --> URI Class Initialized
INFO - 2020-01-03 07:34:42 --> Router Class Initialized
INFO - 2020-01-03 07:34:42 --> Output Class Initialized
INFO - 2020-01-03 07:34:42 --> Security Class Initialized
DEBUG - 2020-01-03 07:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:34:42 --> Input Class Initialized
INFO - 2020-01-03 07:34:42 --> Language Class Initialized
INFO - 2020-01-03 07:34:42 --> Loader Class Initialized
INFO - 2020-01-03 07:34:42 --> Helper loaded: url_helper
INFO - 2020-01-03 07:34:42 --> Database Driver Class Initialized
DEBUG - 2020-01-03 07:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-03 07:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-03 07:34:43 --> Controller Class Initialized
INFO - 2020-01-03 07:34:43 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-03 07:34:43 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2020-01-03 07:34:43 --> Final output sent to browser
DEBUG - 2020-01-03 07:34:43 --> Total execution time: 0.6904
INFO - 2020-01-03 07:34:43 --> Config Class Initialized
INFO - 2020-01-03 07:34:43 --> Config Class Initialized
INFO - 2020-01-03 07:34:43 --> Hooks Class Initialized
INFO - 2020-01-03 07:34:43 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-01-03 07:34:43 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:34:43 --> Utf8 Class Initialized
INFO - 2020-01-03 07:34:43 --> Utf8 Class Initialized
INFO - 2020-01-03 07:34:43 --> URI Class Initialized
INFO - 2020-01-03 07:34:43 --> URI Class Initialized
INFO - 2020-01-03 07:34:43 --> Router Class Initialized
INFO - 2020-01-03 07:34:43 --> Router Class Initialized
INFO - 2020-01-03 07:34:43 --> Output Class Initialized
INFO - 2020-01-03 07:34:43 --> Output Class Initialized
INFO - 2020-01-03 07:34:43 --> Security Class Initialized
INFO - 2020-01-03 07:34:43 --> Security Class Initialized
DEBUG - 2020-01-03 07:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-03 07:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:34:43 --> Input Class Initialized
INFO - 2020-01-03 07:34:43 --> Input Class Initialized
INFO - 2020-01-03 07:34:43 --> Language Class Initialized
INFO - 2020-01-03 07:34:43 --> Language Class Initialized
ERROR - 2020-01-03 07:34:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-03 07:34:43 --> 404 Page Not Found: Assets/js
INFO - 2020-01-03 07:34:43 --> Config Class Initialized
INFO - 2020-01-03 07:34:43 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:34:43 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:34:43 --> Utf8 Class Initialized
INFO - 2020-01-03 07:34:43 --> URI Class Initialized
INFO - 2020-01-03 07:34:43 --> Router Class Initialized
INFO - 2020-01-03 07:34:43 --> Output Class Initialized
INFO - 2020-01-03 07:34:43 --> Security Class Initialized
DEBUG - 2020-01-03 07:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:34:44 --> Input Class Initialized
INFO - 2020-01-03 07:34:44 --> Language Class Initialized
ERROR - 2020-01-03 07:34:44 --> 404 Page Not Found: Assets/js
INFO - 2020-01-03 07:34:46 --> Config Class Initialized
INFO - 2020-01-03 07:34:47 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:34:47 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:34:47 --> Utf8 Class Initialized
INFO - 2020-01-03 07:34:47 --> URI Class Initialized
INFO - 2020-01-03 07:34:47 --> Router Class Initialized
INFO - 2020-01-03 07:34:47 --> Output Class Initialized
INFO - 2020-01-03 07:34:47 --> Security Class Initialized
DEBUG - 2020-01-03 07:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:34:47 --> Input Class Initialized
INFO - 2020-01-03 07:34:47 --> Language Class Initialized
INFO - 2020-01-03 07:34:47 --> Loader Class Initialized
INFO - 2020-01-03 07:34:47 --> Helper loaded: url_helper
INFO - 2020-01-03 07:34:47 --> Database Driver Class Initialized
DEBUG - 2020-01-03 07:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-03 07:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-03 07:34:47 --> Controller Class Initialized
INFO - 2020-01-03 07:34:47 --> Model "M_login" initialized
INFO - 2020-01-03 07:34:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-03 07:34:47 --> Pagination Class Initialized
INFO - 2020-01-03 07:34:47 --> Model "M_show" initialized
INFO - 2020-01-03 07:34:47 --> Helper loaded: form_helper
INFO - 2020-01-03 07:34:47 --> Form Validation Class Initialized
INFO - 2020-01-03 07:34:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-03 07:34:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-03 07:34:48 --> Final output sent to browser
DEBUG - 2020-01-03 07:34:48 --> Total execution time: 1.1505
INFO - 2020-01-03 07:34:48 --> Config Class Initialized
INFO - 2020-01-03 07:34:48 --> Config Class Initialized
INFO - 2020-01-03 07:34:48 --> Hooks Class Initialized
INFO - 2020-01-03 07:34:48 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:34:48 --> UTF-8 Support Enabled
DEBUG - 2020-01-03 07:34:48 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:34:48 --> Utf8 Class Initialized
INFO - 2020-01-03 07:34:48 --> Utf8 Class Initialized
INFO - 2020-01-03 07:34:48 --> URI Class Initialized
INFO - 2020-01-03 07:34:48 --> URI Class Initialized
INFO - 2020-01-03 07:34:48 --> Router Class Initialized
INFO - 2020-01-03 07:34:48 --> Router Class Initialized
INFO - 2020-01-03 07:34:48 --> Output Class Initialized
INFO - 2020-01-03 07:34:48 --> Output Class Initialized
INFO - 2020-01-03 07:34:48 --> Security Class Initialized
INFO - 2020-01-03 07:34:48 --> Security Class Initialized
DEBUG - 2020-01-03 07:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-03 07:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:34:48 --> Input Class Initialized
INFO - 2020-01-03 07:34:48 --> Input Class Initialized
INFO - 2020-01-03 07:34:48 --> Language Class Initialized
INFO - 2020-01-03 07:34:48 --> Language Class Initialized
ERROR - 2020-01-03 07:34:48 --> 404 Page Not Found: Show/assets
ERROR - 2020-01-03 07:34:48 --> 404 Page Not Found: Show/assets
INFO - 2020-01-03 07:34:48 --> Config Class Initialized
INFO - 2020-01-03 07:34:48 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:34:48 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:34:48 --> Utf8 Class Initialized
INFO - 2020-01-03 07:34:48 --> URI Class Initialized
INFO - 2020-01-03 07:34:48 --> Router Class Initialized
INFO - 2020-01-03 07:34:48 --> Output Class Initialized
INFO - 2020-01-03 07:34:48 --> Security Class Initialized
DEBUG - 2020-01-03 07:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:34:48 --> Input Class Initialized
INFO - 2020-01-03 07:34:48 --> Language Class Initialized
ERROR - 2020-01-03 07:34:48 --> 404 Page Not Found: Show/assets
INFO - 2020-01-03 07:35:26 --> Config Class Initialized
INFO - 2020-01-03 07:35:26 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:35:26 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:26 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:27 --> URI Class Initialized
INFO - 2020-01-03 07:35:27 --> Router Class Initialized
INFO - 2020-01-03 07:35:27 --> Output Class Initialized
INFO - 2020-01-03 07:35:27 --> Security Class Initialized
DEBUG - 2020-01-03 07:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:27 --> Input Class Initialized
INFO - 2020-01-03 07:35:27 --> Language Class Initialized
INFO - 2020-01-03 07:35:27 --> Loader Class Initialized
INFO - 2020-01-03 07:35:27 --> Helper loaded: url_helper
INFO - 2020-01-03 07:35:27 --> Database Driver Class Initialized
DEBUG - 2020-01-03 07:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-03 07:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-03 07:35:27 --> Controller Class Initialized
INFO - 2020-01-03 07:35:27 --> Model "M_login" initialized
INFO - 2020-01-03 07:35:27 --> Model "M_tiket" initialized
INFO - 2020-01-03 07:35:27 --> Helper loaded: form_helper
INFO - 2020-01-03 07:35:27 --> Form Validation Class Initialized
INFO - 2020-01-03 07:35:27 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-03 07:35:27 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-03 07:35:27 --> Final output sent to browser
DEBUG - 2020-01-03 07:35:27 --> Total execution time: 0.6662
INFO - 2020-01-03 07:35:27 --> Config Class Initialized
INFO - 2020-01-03 07:35:27 --> Config Class Initialized
INFO - 2020-01-03 07:35:27 --> Config Class Initialized
INFO - 2020-01-03 07:35:27 --> Config Class Initialized
INFO - 2020-01-03 07:35:27 --> Hooks Class Initialized
INFO - 2020-01-03 07:35:27 --> Hooks Class Initialized
INFO - 2020-01-03 07:35:27 --> Hooks Class Initialized
INFO - 2020-01-03 07:35:27 --> Config Class Initialized
INFO - 2020-01-03 07:35:27 --> Hooks Class Initialized
INFO - 2020-01-03 07:35:27 --> Config Class Initialized
INFO - 2020-01-03 07:35:27 --> Hooks Class Initialized
INFO - 2020-01-03 07:35:27 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-01-03 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-01-03 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-01-03 07:35:27 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:27 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:27 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:27 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:27 --> Utf8 Class Initialized
DEBUG - 2020-01-03 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-01-03 07:35:27 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:27 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:27 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:27 --> URI Class Initialized
INFO - 2020-01-03 07:35:27 --> URI Class Initialized
INFO - 2020-01-03 07:35:27 --> URI Class Initialized
INFO - 2020-01-03 07:35:27 --> URI Class Initialized
INFO - 2020-01-03 07:35:27 --> URI Class Initialized
INFO - 2020-01-03 07:35:27 --> Router Class Initialized
INFO - 2020-01-03 07:35:27 --> Router Class Initialized
INFO - 2020-01-03 07:35:27 --> URI Class Initialized
INFO - 2020-01-03 07:35:27 --> Router Class Initialized
INFO - 2020-01-03 07:35:27 --> Router Class Initialized
INFO - 2020-01-03 07:35:27 --> Router Class Initialized
INFO - 2020-01-03 07:35:27 --> Router Class Initialized
INFO - 2020-01-03 07:35:27 --> Output Class Initialized
INFO - 2020-01-03 07:35:27 --> Output Class Initialized
INFO - 2020-01-03 07:35:27 --> Output Class Initialized
INFO - 2020-01-03 07:35:27 --> Output Class Initialized
INFO - 2020-01-03 07:35:27 --> Security Class Initialized
INFO - 2020-01-03 07:35:27 --> Security Class Initialized
INFO - 2020-01-03 07:35:27 --> Output Class Initialized
INFO - 2020-01-03 07:35:27 --> Output Class Initialized
INFO - 2020-01-03 07:35:27 --> Security Class Initialized
INFO - 2020-01-03 07:35:27 --> Security Class Initialized
DEBUG - 2020-01-03 07:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:27 --> Security Class Initialized
INFO - 2020-01-03 07:35:27 --> Security Class Initialized
DEBUG - 2020-01-03 07:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-03 07:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-03 07:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:27 --> Input Class Initialized
INFO - 2020-01-03 07:35:27 --> Input Class Initialized
INFO - 2020-01-03 07:35:27 --> Input Class Initialized
INFO - 2020-01-03 07:35:27 --> Input Class Initialized
DEBUG - 2020-01-03 07:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-03 07:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:27 --> Input Class Initialized
INFO - 2020-01-03 07:35:27 --> Language Class Initialized
INFO - 2020-01-03 07:35:27 --> Language Class Initialized
INFO - 2020-01-03 07:35:27 --> Language Class Initialized
INFO - 2020-01-03 07:35:27 --> Input Class Initialized
INFO - 2020-01-03 07:35:27 --> Language Class Initialized
INFO - 2020-01-03 07:35:27 --> Language Class Initialized
INFO - 2020-01-03 07:35:27 --> Language Class Initialized
ERROR - 2020-01-03 07:35:27 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-03 07:35:27 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-03 07:35:27 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-01-03 07:35:27 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-01-03 07:35:27 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-01-03 07:35:27 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-01-03 07:35:27 --> Config Class Initialized
INFO - 2020-01-03 07:35:27 --> Config Class Initialized
INFO - 2020-01-03 07:35:27 --> Config Class Initialized
INFO - 2020-01-03 07:35:27 --> Config Class Initialized
INFO - 2020-01-03 07:35:27 --> Hooks Class Initialized
INFO - 2020-01-03 07:35:27 --> Hooks Class Initialized
INFO - 2020-01-03 07:35:27 --> Hooks Class Initialized
INFO - 2020-01-03 07:35:27 --> Hooks Class Initialized
INFO - 2020-01-03 07:35:27 --> Config Class Initialized
INFO - 2020-01-03 07:35:27 --> Hooks Class Initialized
INFO - 2020-01-03 07:35:27 --> Config Class Initialized
DEBUG - 2020-01-03 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-01-03 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-01-03 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-01-03 07:35:27 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:28 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:28 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:28 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:28 --> Hooks Class Initialized
INFO - 2020-01-03 07:35:28 --> Utf8 Class Initialized
DEBUG - 2020-01-03 07:35:28 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:28 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:28 --> URI Class Initialized
INFO - 2020-01-03 07:35:28 --> URI Class Initialized
INFO - 2020-01-03 07:35:28 --> URI Class Initialized
INFO - 2020-01-03 07:35:28 --> URI Class Initialized
DEBUG - 2020-01-03 07:35:28 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:28 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:28 --> Router Class Initialized
INFO - 2020-01-03 07:35:28 --> Router Class Initialized
INFO - 2020-01-03 07:35:28 --> Router Class Initialized
INFO - 2020-01-03 07:35:28 --> Router Class Initialized
INFO - 2020-01-03 07:35:28 --> URI Class Initialized
INFO - 2020-01-03 07:35:28 --> URI Class Initialized
INFO - 2020-01-03 07:35:28 --> Output Class Initialized
INFO - 2020-01-03 07:35:28 --> Output Class Initialized
INFO - 2020-01-03 07:35:28 --> Output Class Initialized
INFO - 2020-01-03 07:35:28 --> Output Class Initialized
INFO - 2020-01-03 07:35:28 --> Router Class Initialized
INFO - 2020-01-03 07:35:28 --> Router Class Initialized
INFO - 2020-01-03 07:35:28 --> Security Class Initialized
INFO - 2020-01-03 07:35:28 --> Output Class Initialized
INFO - 2020-01-03 07:35:28 --> Security Class Initialized
INFO - 2020-01-03 07:35:28 --> Security Class Initialized
INFO - 2020-01-03 07:35:28 --> Security Class Initialized
DEBUG - 2020-01-03 07:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-03 07:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:28 --> Security Class Initialized
DEBUG - 2020-01-03 07:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-03 07:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:28 --> Output Class Initialized
INFO - 2020-01-03 07:35:28 --> Input Class Initialized
INFO - 2020-01-03 07:35:28 --> Input Class Initialized
INFO - 2020-01-03 07:35:28 --> Input Class Initialized
INFO - 2020-01-03 07:35:28 --> Input Class Initialized
DEBUG - 2020-01-03 07:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:28 --> Security Class Initialized
INFO - 2020-01-03 07:35:28 --> Input Class Initialized
INFO - 2020-01-03 07:35:28 --> Language Class Initialized
INFO - 2020-01-03 07:35:28 --> Language Class Initialized
INFO - 2020-01-03 07:35:28 --> Language Class Initialized
INFO - 2020-01-03 07:35:28 --> Language Class Initialized
DEBUG - 2020-01-03 07:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:28 --> Input Class Initialized
INFO - 2020-01-03 07:35:28 --> Language Class Initialized
ERROR - 2020-01-03 07:35:28 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-03 07:35:28 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-01-03 07:35:28 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-01-03 07:35:28 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-03 07:35:28 --> Language Class Initialized
ERROR - 2020-01-03 07:35:28 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-03 07:35:28 --> Config Class Initialized
INFO - 2020-01-03 07:35:28 --> Config Class Initialized
INFO - 2020-01-03 07:35:28 --> Hooks Class Initialized
INFO - 2020-01-03 07:35:28 --> Hooks Class Initialized
INFO - 2020-01-03 07:35:28 --> Loader Class Initialized
INFO - 2020-01-03 07:35:28 --> Helper loaded: url_helper
DEBUG - 2020-01-03 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2020-01-03 07:35:28 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:28 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:28 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:28 --> Database Driver Class Initialized
INFO - 2020-01-03 07:35:28 --> URI Class Initialized
INFO - 2020-01-03 07:35:28 --> URI Class Initialized
DEBUG - 2020-01-03 07:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-03 07:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-03 07:35:28 --> Router Class Initialized
INFO - 2020-01-03 07:35:28 --> Router Class Initialized
INFO - 2020-01-03 07:35:28 --> Controller Class Initialized
INFO - 2020-01-03 07:35:28 --> Output Class Initialized
INFO - 2020-01-03 07:35:28 --> Output Class Initialized
INFO - 2020-01-03 07:35:28 --> Model "M_login" initialized
INFO - 2020-01-03 07:35:28 --> Security Class Initialized
INFO - 2020-01-03 07:35:28 --> Security Class Initialized
INFO - 2020-01-03 07:35:28 --> Model "M_tiket" initialized
DEBUG - 2020-01-03 07:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-03 07:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:28 --> Input Class Initialized
INFO - 2020-01-03 07:35:28 --> Input Class Initialized
INFO - 2020-01-03 07:35:28 --> Helper loaded: form_helper
INFO - 2020-01-03 07:35:28 --> Form Validation Class Initialized
INFO - 2020-01-03 07:35:28 --> Language Class Initialized
INFO - 2020-01-03 07:35:28 --> Language Class Initialized
ERROR - 2020-01-03 07:35:28 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-01-03 07:35:28 --> Loader Class Initialized
INFO - 2020-01-03 07:35:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-03 07:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-03 07:35:28 --> Helper loaded: url_helper
INFO - 2020-01-03 07:35:28 --> Config Class Initialized
INFO - 2020-01-03 07:35:28 --> Database Driver Class Initialized
INFO - 2020-01-03 07:35:28 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-01-03 07:35:28 --> UTF-8 Support Enabled
ERROR - 2020-01-03 07:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2020-01-03 07:35:28 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-03 07:35:28 --> Final output sent to browser
INFO - 2020-01-03 07:35:28 --> URI Class Initialized
DEBUG - 2020-01-03 07:35:28 --> Total execution time: 0.5406
INFO - 2020-01-03 07:35:28 --> Router Class Initialized
INFO - 2020-01-03 07:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-03 07:35:28 --> Output Class Initialized
INFO - 2020-01-03 07:35:28 --> Controller Class Initialized
INFO - 2020-01-03 07:35:28 --> Security Class Initialized
INFO - 2020-01-03 07:35:28 --> Model "M_login" initialized
DEBUG - 2020-01-03 07:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:28 --> Input Class Initialized
INFO - 2020-01-03 07:35:28 --> Model "M_tiket" initialized
INFO - 2020-01-03 07:35:28 --> Language Class Initialized
INFO - 2020-01-03 07:35:28 --> Helper loaded: form_helper
INFO - 2020-01-03 07:35:28 --> Form Validation Class Initialized
ERROR - 2020-01-03 07:35:28 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-01-03 07:35:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-03 07:35:28 --> Config Class Initialized
INFO - 2020-01-03 07:35:28 --> Hooks Class Initialized
ERROR - 2020-01-03 07:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-01-03 07:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
DEBUG - 2020-01-03 07:35:28 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:28 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-03 07:35:28 --> Final output sent to browser
INFO - 2020-01-03 07:35:28 --> URI Class Initialized
DEBUG - 2020-01-03 07:35:28 --> Total execution time: 0.5116
INFO - 2020-01-03 07:35:28 --> Router Class Initialized
INFO - 2020-01-03 07:35:28 --> Output Class Initialized
INFO - 2020-01-03 07:35:28 --> Security Class Initialized
DEBUG - 2020-01-03 07:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:28 --> Input Class Initialized
INFO - 2020-01-03 07:35:28 --> Language Class Initialized
ERROR - 2020-01-03 07:35:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-01-03 07:35:28 --> Config Class Initialized
INFO - 2020-01-03 07:35:28 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:35:28 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:28 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:28 --> URI Class Initialized
INFO - 2020-01-03 07:35:28 --> Router Class Initialized
INFO - 2020-01-03 07:35:28 --> Output Class Initialized
INFO - 2020-01-03 07:35:28 --> Security Class Initialized
DEBUG - 2020-01-03 07:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:29 --> Input Class Initialized
INFO - 2020-01-03 07:35:29 --> Language Class Initialized
ERROR - 2020-01-03 07:35:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-03 07:35:29 --> Config Class Initialized
INFO - 2020-01-03 07:35:29 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:35:29 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:29 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:29 --> URI Class Initialized
INFO - 2020-01-03 07:35:29 --> Router Class Initialized
INFO - 2020-01-03 07:35:29 --> Output Class Initialized
INFO - 2020-01-03 07:35:29 --> Security Class Initialized
DEBUG - 2020-01-03 07:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:29 --> Input Class Initialized
INFO - 2020-01-03 07:35:29 --> Language Class Initialized
ERROR - 2020-01-03 07:35:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-03 07:35:29 --> Config Class Initialized
INFO - 2020-01-03 07:35:29 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:35:29 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:29 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:29 --> URI Class Initialized
INFO - 2020-01-03 07:35:29 --> Router Class Initialized
INFO - 2020-01-03 07:35:29 --> Output Class Initialized
INFO - 2020-01-03 07:35:29 --> Security Class Initialized
DEBUG - 2020-01-03 07:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:29 --> Input Class Initialized
INFO - 2020-01-03 07:35:29 --> Language Class Initialized
ERROR - 2020-01-03 07:35:29 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-03 07:35:29 --> Config Class Initialized
INFO - 2020-01-03 07:35:29 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:35:29 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:29 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:29 --> URI Class Initialized
INFO - 2020-01-03 07:35:29 --> Router Class Initialized
INFO - 2020-01-03 07:35:29 --> Output Class Initialized
INFO - 2020-01-03 07:35:29 --> Security Class Initialized
DEBUG - 2020-01-03 07:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:29 --> Input Class Initialized
INFO - 2020-01-03 07:35:29 --> Language Class Initialized
ERROR - 2020-01-03 07:35:29 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-03 07:35:29 --> Config Class Initialized
INFO - 2020-01-03 07:35:29 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:35:29 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:29 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:29 --> URI Class Initialized
INFO - 2020-01-03 07:35:29 --> Router Class Initialized
INFO - 2020-01-03 07:35:29 --> Output Class Initialized
INFO - 2020-01-03 07:35:29 --> Security Class Initialized
DEBUG - 2020-01-03 07:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:29 --> Input Class Initialized
INFO - 2020-01-03 07:35:29 --> Language Class Initialized
ERROR - 2020-01-03 07:35:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-03 07:35:29 --> Config Class Initialized
INFO - 2020-01-03 07:35:29 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:35:29 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:35:29 --> Utf8 Class Initialized
INFO - 2020-01-03 07:35:30 --> URI Class Initialized
INFO - 2020-01-03 07:35:30 --> Router Class Initialized
INFO - 2020-01-03 07:35:30 --> Output Class Initialized
INFO - 2020-01-03 07:35:30 --> Security Class Initialized
DEBUG - 2020-01-03 07:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:35:30 --> Input Class Initialized
INFO - 2020-01-03 07:35:30 --> Language Class Initialized
ERROR - 2020-01-03 07:35:30 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-03 07:45:18 --> Config Class Initialized
INFO - 2020-01-03 07:45:18 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:45:18 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:45:18 --> Utf8 Class Initialized
INFO - 2020-01-03 07:45:18 --> URI Class Initialized
INFO - 2020-01-03 07:45:18 --> Router Class Initialized
INFO - 2020-01-03 07:45:18 --> Output Class Initialized
INFO - 2020-01-03 07:45:18 --> Security Class Initialized
DEBUG - 2020-01-03 07:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:45:18 --> Input Class Initialized
INFO - 2020-01-03 07:45:19 --> Language Class Initialized
INFO - 2020-01-03 07:45:19 --> Loader Class Initialized
INFO - 2020-01-03 07:45:19 --> Helper loaded: url_helper
INFO - 2020-01-03 07:45:19 --> Database Driver Class Initialized
DEBUG - 2020-01-03 07:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-03 07:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-03 07:45:19 --> Controller Class Initialized
INFO - 2020-01-03 07:45:19 --> Model "M_login" initialized
INFO - 2020-01-03 07:45:19 --> Model "M_tiket" initialized
INFO - 2020-01-03 07:45:19 --> Helper loaded: form_helper
INFO - 2020-01-03 07:45:19 --> Form Validation Class Initialized
ERROR - 2020-01-03 07:45:19 --> Severity: error --> Exception: Too few arguments to function Tiket::add(), 0 passed in C:\xampp\htdocs\Musikologi-1\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\Musikologi-1\application\controllers\Tiket.php 18
INFO - 2020-01-03 07:45:22 --> Config Class Initialized
INFO - 2020-01-03 07:45:22 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:45:22 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:45:22 --> Utf8 Class Initialized
INFO - 2020-01-03 07:45:22 --> URI Class Initialized
INFO - 2020-01-03 07:45:22 --> Router Class Initialized
INFO - 2020-01-03 07:45:22 --> Output Class Initialized
INFO - 2020-01-03 07:45:22 --> Security Class Initialized
DEBUG - 2020-01-03 07:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:45:22 --> Input Class Initialized
INFO - 2020-01-03 07:45:22 --> Language Class Initialized
INFO - 2020-01-03 07:45:22 --> Loader Class Initialized
INFO - 2020-01-03 07:45:22 --> Helper loaded: url_helper
INFO - 2020-01-03 07:45:22 --> Database Driver Class Initialized
DEBUG - 2020-01-03 07:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-03 07:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-03 07:45:22 --> Controller Class Initialized
INFO - 2020-01-03 07:45:22 --> Model "M_login" initialized
INFO - 2020-01-03 07:45:22 --> Model "M_tiket" initialized
INFO - 2020-01-03 07:45:22 --> Helper loaded: form_helper
INFO - 2020-01-03 07:45:22 --> Form Validation Class Initialized
INFO - 2020-01-03 07:45:22 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-03 07:45:22 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-03 07:45:22 --> Final output sent to browser
DEBUG - 2020-01-03 07:45:22 --> Total execution time: 0.5473
INFO - 2020-01-03 07:45:22 --> Config Class Initialized
INFO - 2020-01-03 07:45:22 --> Config Class Initialized
INFO - 2020-01-03 07:45:22 --> Hooks Class Initialized
INFO - 2020-01-03 07:45:22 --> Hooks Class Initialized
DEBUG - 2020-01-03 07:45:22 --> UTF-8 Support Enabled
DEBUG - 2020-01-03 07:45:22 --> UTF-8 Support Enabled
INFO - 2020-01-03 07:45:22 --> Utf8 Class Initialized
INFO - 2020-01-03 07:45:22 --> Utf8 Class Initialized
INFO - 2020-01-03 07:45:22 --> URI Class Initialized
INFO - 2020-01-03 07:45:22 --> URI Class Initialized
INFO - 2020-01-03 07:45:22 --> Router Class Initialized
INFO - 2020-01-03 07:45:22 --> Router Class Initialized
INFO - 2020-01-03 07:45:22 --> Output Class Initialized
INFO - 2020-01-03 07:45:22 --> Output Class Initialized
INFO - 2020-01-03 07:45:22 --> Security Class Initialized
INFO - 2020-01-03 07:45:22 --> Security Class Initialized
DEBUG - 2020-01-03 07:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-03 07:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-03 07:45:23 --> Input Class Initialized
INFO - 2020-01-03 07:45:23 --> Input Class Initialized
INFO - 2020-01-03 07:45:23 --> Language Class Initialized
INFO - 2020-01-03 07:45:23 --> Language Class Initialized
ERROR - 2020-01-03 07:45:23 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-01-03 07:45:23 --> 404 Page Not Found: Bower_components/jquery
