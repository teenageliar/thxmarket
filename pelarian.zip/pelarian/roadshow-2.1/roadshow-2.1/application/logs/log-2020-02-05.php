<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-05 17:34:25 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-05 17:34:25 --> Config Class Initialized
INFO - 2020-02-05 17:34:25 --> Hooks Class Initialized
INFO - 2020-02-05 17:34:25 --> Hooks Class Initialized
DEBUG - 2020-02-05 17:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 17:34:26 --> UTF-8 Support Enabled
INFO - 2020-02-05 17:34:26 --> Utf8 Class Initialized
INFO - 2020-02-05 17:34:26 --> Utf8 Class Initialized
INFO - 2020-02-05 17:34:26 --> URI Class Initialized
INFO - 2020-02-05 17:34:26 --> URI Class Initialized
DEBUG - 2020-02-05 17:34:27 --> No URI present. Default controller set.
DEBUG - 2020-02-05 17:34:27 --> No URI present. Default controller set.
INFO - 2020-02-05 17:34:27 --> Router Class Initialized
INFO - 2020-02-05 17:34:27 --> Router Class Initialized
INFO - 2020-02-05 17:34:27 --> Output Class Initialized
INFO - 2020-02-05 17:34:27 --> Output Class Initialized
INFO - 2020-02-05 17:34:27 --> Security Class Initialized
INFO - 2020-02-05 17:34:27 --> Security Class Initialized
DEBUG - 2020-02-05 17:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 17:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 17:34:27 --> Input Class Initialized
INFO - 2020-02-05 17:34:27 --> Input Class Initialized
INFO - 2020-02-05 17:34:27 --> Language Class Initialized
INFO - 2020-02-05 17:34:27 --> Language Class Initialized
INFO - 2020-02-05 17:34:27 --> Loader Class Initialized
INFO - 2020-02-05 17:34:27 --> Loader Class Initialized
INFO - 2020-02-05 17:34:27 --> Helper loaded: url_helper
INFO - 2020-02-05 17:34:27 --> Helper loaded: url_helper
INFO - 2020-02-05 17:34:28 --> Database Driver Class Initialized
INFO - 2020-02-05 17:34:28 --> Database Driver Class Initialized
DEBUG - 2020-02-05 17:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 17:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 17:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 17:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 17:34:29 --> Controller Class Initialized
INFO - 2020-02-05 17:34:29 --> Controller Class Initialized
INFO - 2020-02-05 17:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-05 17:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-05 17:34:29 --> Pagination Class Initialized
INFO - 2020-02-05 17:34:29 --> Pagination Class Initialized
INFO - 2020-02-05 17:34:29 --> Model "M_show" initialized
INFO - 2020-02-05 17:34:29 --> Model "M_show" initialized
INFO - 2020-02-05 17:34:29 --> Helper loaded: form_helper
INFO - 2020-02-05 17:34:29 --> Helper loaded: form_helper
INFO - 2020-02-05 17:34:29 --> Form Validation Class Initialized
INFO - 2020-02-05 17:34:29 --> Form Validation Class Initialized
INFO - 2020-02-05 17:34:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-05 17:34:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-05 17:34:30 --> Final output sent to browser
INFO - 2020-02-05 17:34:30 --> Final output sent to browser
DEBUG - 2020-02-05 17:34:30 --> Total execution time: 5.3454
DEBUG - 2020-02-05 17:34:30 --> Total execution time: 5.3455
INFO - 2020-02-05 17:35:18 --> Config Class Initialized
INFO - 2020-02-05 17:35:18 --> Hooks Class Initialized
DEBUG - 2020-02-05 17:35:18 --> UTF-8 Support Enabled
INFO - 2020-02-05 17:35:18 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:18 --> URI Class Initialized
INFO - 2020-02-05 17:35:18 --> Router Class Initialized
INFO - 2020-02-05 17:35:18 --> Output Class Initialized
INFO - 2020-02-05 17:35:18 --> Security Class Initialized
DEBUG - 2020-02-05 17:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 17:35:18 --> Input Class Initialized
INFO - 2020-02-05 17:35:18 --> Language Class Initialized
INFO - 2020-02-05 17:35:18 --> Loader Class Initialized
INFO - 2020-02-05 17:35:18 --> Helper loaded: url_helper
INFO - 2020-02-05 17:35:18 --> Database Driver Class Initialized
DEBUG - 2020-02-05 17:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 17:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 17:35:18 --> Controller Class Initialized
INFO - 2020-02-05 17:35:18 --> Model "M_tiket" initialized
INFO - 2020-02-05 17:35:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 17:35:19 --> Model "M_pesan" initialized
INFO - 2020-02-05 17:35:19 --> Helper loaded: form_helper
INFO - 2020-02-05 17:35:19 --> Form Validation Class Initialized
INFO - 2020-02-05 17:35:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 17:35:19 --> Final output sent to browser
DEBUG - 2020-02-05 17:35:19 --> Total execution time: 1.0325
INFO - 2020-02-05 17:35:19 --> Config Class Initialized
INFO - 2020-02-05 17:35:19 --> Config Class Initialized
INFO - 2020-02-05 17:35:19 --> Config Class Initialized
INFO - 2020-02-05 17:35:19 --> Config Class Initialized
INFO - 2020-02-05 17:35:19 --> Hooks Class Initialized
INFO - 2020-02-05 17:35:19 --> Hooks Class Initialized
INFO - 2020-02-05 17:35:19 --> Config Class Initialized
INFO - 2020-02-05 17:35:19 --> Hooks Class Initialized
INFO - 2020-02-05 17:35:19 --> Config Class Initialized
INFO - 2020-02-05 17:35:19 --> Hooks Class Initialized
INFO - 2020-02-05 17:35:19 --> Hooks Class Initialized
DEBUG - 2020-02-05 17:35:19 --> UTF-8 Support Enabled
INFO - 2020-02-05 17:35:19 --> Hooks Class Initialized
INFO - 2020-02-05 17:35:19 --> Utf8 Class Initialized
DEBUG - 2020-02-05 17:35:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 17:35:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 17:35:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 17:35:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 17:35:19 --> UTF-8 Support Enabled
INFO - 2020-02-05 17:35:19 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:19 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:19 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:19 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:19 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:19 --> URI Class Initialized
INFO - 2020-02-05 17:35:19 --> URI Class Initialized
INFO - 2020-02-05 17:35:19 --> URI Class Initialized
INFO - 2020-02-05 17:35:19 --> URI Class Initialized
INFO - 2020-02-05 17:35:19 --> URI Class Initialized
INFO - 2020-02-05 17:35:19 --> URI Class Initialized
INFO - 2020-02-05 17:35:19 --> Router Class Initialized
INFO - 2020-02-05 17:35:19 --> Router Class Initialized
INFO - 2020-02-05 17:35:19 --> Router Class Initialized
INFO - 2020-02-05 17:35:19 --> Output Class Initialized
INFO - 2020-02-05 17:35:19 --> Router Class Initialized
INFO - 2020-02-05 17:35:19 --> Router Class Initialized
INFO - 2020-02-05 17:35:19 --> Router Class Initialized
INFO - 2020-02-05 17:35:19 --> Security Class Initialized
INFO - 2020-02-05 17:35:19 --> Output Class Initialized
INFO - 2020-02-05 17:35:19 --> Output Class Initialized
INFO - 2020-02-05 17:35:19 --> Output Class Initialized
INFO - 2020-02-05 17:35:19 --> Output Class Initialized
INFO - 2020-02-05 17:35:19 --> Output Class Initialized
DEBUG - 2020-02-05 17:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 17:35:19 --> Security Class Initialized
INFO - 2020-02-05 17:35:19 --> Security Class Initialized
INFO - 2020-02-05 17:35:19 --> Security Class Initialized
INFO - 2020-02-05 17:35:19 --> Security Class Initialized
INFO - 2020-02-05 17:35:19 --> Security Class Initialized
INFO - 2020-02-05 17:35:19 --> Input Class Initialized
DEBUG - 2020-02-05 17:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 17:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 17:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 17:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 17:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 17:35:19 --> Input Class Initialized
INFO - 2020-02-05 17:35:19 --> Input Class Initialized
INFO - 2020-02-05 17:35:19 --> Input Class Initialized
INFO - 2020-02-05 17:35:19 --> Input Class Initialized
INFO - 2020-02-05 17:35:19 --> Input Class Initialized
INFO - 2020-02-05 17:35:19 --> Language Class Initialized
INFO - 2020-02-05 17:35:19 --> Language Class Initialized
INFO - 2020-02-05 17:35:19 --> Language Class Initialized
INFO - 2020-02-05 17:35:19 --> Language Class Initialized
INFO - 2020-02-05 17:35:19 --> Language Class Initialized
INFO - 2020-02-05 17:35:19 --> Language Class Initialized
ERROR - 2020-02-05 17:35:19 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 17:35:19 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-05 17:35:19 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 17:35:19 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-05 17:35:19 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 17:35:19 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 17:35:19 --> Config Class Initialized
INFO - 2020-02-05 17:35:19 --> Config Class Initialized
INFO - 2020-02-05 17:35:19 --> Config Class Initialized
INFO - 2020-02-05 17:35:20 --> Config Class Initialized
INFO - 2020-02-05 17:35:20 --> Config Class Initialized
INFO - 2020-02-05 17:35:20 --> Config Class Initialized
INFO - 2020-02-05 17:35:20 --> Hooks Class Initialized
INFO - 2020-02-05 17:35:20 --> Hooks Class Initialized
INFO - 2020-02-05 17:35:20 --> Hooks Class Initialized
INFO - 2020-02-05 17:35:20 --> Hooks Class Initialized
INFO - 2020-02-05 17:35:20 --> Hooks Class Initialized
INFO - 2020-02-05 17:35:20 --> Hooks Class Initialized
DEBUG - 2020-02-05 17:35:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 17:35:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 17:35:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 17:35:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 17:35:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 17:35:20 --> UTF-8 Support Enabled
INFO - 2020-02-05 17:35:20 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:20 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:20 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:20 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:20 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:20 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:20 --> URI Class Initialized
INFO - 2020-02-05 17:35:20 --> URI Class Initialized
INFO - 2020-02-05 17:35:20 --> URI Class Initialized
INFO - 2020-02-05 17:35:20 --> URI Class Initialized
INFO - 2020-02-05 17:35:20 --> URI Class Initialized
INFO - 2020-02-05 17:35:20 --> URI Class Initialized
INFO - 2020-02-05 17:35:20 --> Router Class Initialized
INFO - 2020-02-05 17:35:20 --> Router Class Initialized
INFO - 2020-02-05 17:35:20 --> Router Class Initialized
INFO - 2020-02-05 17:35:20 --> Router Class Initialized
INFO - 2020-02-05 17:35:20 --> Router Class Initialized
INFO - 2020-02-05 17:35:20 --> Router Class Initialized
INFO - 2020-02-05 17:35:20 --> Output Class Initialized
INFO - 2020-02-05 17:35:20 --> Output Class Initialized
INFO - 2020-02-05 17:35:20 --> Output Class Initialized
INFO - 2020-02-05 17:35:20 --> Output Class Initialized
INFO - 2020-02-05 17:35:20 --> Output Class Initialized
INFO - 2020-02-05 17:35:20 --> Output Class Initialized
INFO - 2020-02-05 17:35:20 --> Security Class Initialized
INFO - 2020-02-05 17:35:20 --> Security Class Initialized
INFO - 2020-02-05 17:35:20 --> Security Class Initialized
INFO - 2020-02-05 17:35:20 --> Security Class Initialized
INFO - 2020-02-05 17:35:20 --> Security Class Initialized
INFO - 2020-02-05 17:35:20 --> Security Class Initialized
DEBUG - 2020-02-05 17:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 17:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 17:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 17:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 17:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 17:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 17:35:20 --> Input Class Initialized
INFO - 2020-02-05 17:35:20 --> Input Class Initialized
INFO - 2020-02-05 17:35:20 --> Input Class Initialized
INFO - 2020-02-05 17:35:20 --> Input Class Initialized
INFO - 2020-02-05 17:35:20 --> Input Class Initialized
INFO - 2020-02-05 17:35:20 --> Input Class Initialized
INFO - 2020-02-05 17:35:20 --> Language Class Initialized
INFO - 2020-02-05 17:35:20 --> Language Class Initialized
INFO - 2020-02-05 17:35:20 --> Language Class Initialized
INFO - 2020-02-05 17:35:20 --> Language Class Initialized
INFO - 2020-02-05 17:35:20 --> Language Class Initialized
INFO - 2020-02-05 17:35:20 --> Language Class Initialized
ERROR - 2020-02-05 17:35:20 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-05 17:35:20 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 17:35:20 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 17:35:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 17:35:20 --> Loader Class Initialized
INFO - 2020-02-05 17:35:20 --> Loader Class Initialized
INFO - 2020-02-05 17:35:20 --> Helper loaded: url_helper
INFO - 2020-02-05 17:35:20 --> Helper loaded: url_helper
INFO - 2020-02-05 17:35:20 --> Database Driver Class Initialized
INFO - 2020-02-05 17:35:20 --> Database Driver Class Initialized
INFO - 2020-02-05 17:35:20 --> Config Class Initialized
INFO - 2020-02-05 17:35:20 --> Config Class Initialized
INFO - 2020-02-05 17:35:20 --> Hooks Class Initialized
INFO - 2020-02-05 17:35:20 --> Hooks Class Initialized
DEBUG - 2020-02-05 17:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 17:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 17:35:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 17:35:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 17:35:20 --> UTF-8 Support Enabled
INFO - 2020-02-05 17:35:20 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:20 --> Controller Class Initialized
INFO - 2020-02-05 17:35:20 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:20 --> Model "M_tiket" initialized
INFO - 2020-02-05 17:35:20 --> URI Class Initialized
INFO - 2020-02-05 17:35:20 --> URI Class Initialized
INFO - 2020-02-05 17:35:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 17:35:20 --> Router Class Initialized
INFO - 2020-02-05 17:35:20 --> Router Class Initialized
INFO - 2020-02-05 17:35:20 --> Model "M_pesan" initialized
INFO - 2020-02-05 17:35:20 --> Output Class Initialized
INFO - 2020-02-05 17:35:20 --> Output Class Initialized
INFO - 2020-02-05 17:35:20 --> Security Class Initialized
INFO - 2020-02-05 17:35:20 --> Security Class Initialized
INFO - 2020-02-05 17:35:20 --> Helper loaded: form_helper
INFO - 2020-02-05 17:35:20 --> Form Validation Class Initialized
DEBUG - 2020-02-05 17:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 17:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 17:35:20 --> Input Class Initialized
INFO - 2020-02-05 17:35:20 --> Input Class Initialized
ERROR - 2020-02-05 17:35:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 17:35:20 --> Language Class Initialized
INFO - 2020-02-05 17:35:20 --> Language Class Initialized
ERROR - 2020-02-05 17:35:20 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 17:35:20 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 17:35:20 --> Config Class Initialized
INFO - 2020-02-05 17:35:20 --> Hooks Class Initialized
ERROR - 2020-02-05 17:35:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 17:35:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-05 17:35:20 --> UTF-8 Support Enabled
INFO - 2020-02-05 17:35:20 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:20 --> Final output sent to browser
DEBUG - 2020-02-05 17:35:20 --> Total execution time: 0.6060
INFO - 2020-02-05 17:35:20 --> URI Class Initialized
INFO - 2020-02-05 17:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 17:35:20 --> Router Class Initialized
INFO - 2020-02-05 17:35:20 --> Controller Class Initialized
INFO - 2020-02-05 17:35:20 --> Output Class Initialized
INFO - 2020-02-05 17:35:20 --> Model "M_tiket" initialized
INFO - 2020-02-05 17:35:20 --> Security Class Initialized
INFO - 2020-02-05 17:35:20 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-05 17:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 17:35:20 --> Input Class Initialized
INFO - 2020-02-05 17:35:20 --> Model "M_pesan" initialized
INFO - 2020-02-05 17:35:20 --> Language Class Initialized
INFO - 2020-02-05 17:35:20 --> Helper loaded: form_helper
INFO - 2020-02-05 17:35:20 --> Form Validation Class Initialized
ERROR - 2020-02-05 17:35:20 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 17:35:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 17:35:20 --> Config Class Initialized
INFO - 2020-02-05 17:35:20 --> Hooks Class Initialized
ERROR - 2020-02-05 17:35:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 17:35:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-05 17:35:20 --> UTF-8 Support Enabled
INFO - 2020-02-05 17:35:20 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:20 --> Final output sent to browser
DEBUG - 2020-02-05 17:35:20 --> Total execution time: 0.8201
INFO - 2020-02-05 17:35:20 --> URI Class Initialized
INFO - 2020-02-05 17:35:20 --> Router Class Initialized
INFO - 2020-02-05 17:35:20 --> Output Class Initialized
INFO - 2020-02-05 17:35:20 --> Security Class Initialized
DEBUG - 2020-02-05 17:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 17:35:20 --> Input Class Initialized
INFO - 2020-02-05 17:35:20 --> Language Class Initialized
ERROR - 2020-02-05 17:35:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 17:35:21 --> Config Class Initialized
INFO - 2020-02-05 17:35:21 --> Hooks Class Initialized
DEBUG - 2020-02-05 17:35:21 --> UTF-8 Support Enabled
INFO - 2020-02-05 17:35:21 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:21 --> URI Class Initialized
INFO - 2020-02-05 17:35:21 --> Router Class Initialized
INFO - 2020-02-05 17:35:21 --> Output Class Initialized
INFO - 2020-02-05 17:35:21 --> Security Class Initialized
DEBUG - 2020-02-05 17:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 17:35:21 --> Input Class Initialized
INFO - 2020-02-05 17:35:21 --> Language Class Initialized
ERROR - 2020-02-05 17:35:21 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 17:35:21 --> Config Class Initialized
INFO - 2020-02-05 17:35:21 --> Hooks Class Initialized
DEBUG - 2020-02-05 17:35:21 --> UTF-8 Support Enabled
INFO - 2020-02-05 17:35:21 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:21 --> URI Class Initialized
INFO - 2020-02-05 17:35:21 --> Router Class Initialized
INFO - 2020-02-05 17:35:21 --> Output Class Initialized
INFO - 2020-02-05 17:35:21 --> Security Class Initialized
DEBUG - 2020-02-05 17:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 17:35:21 --> Input Class Initialized
INFO - 2020-02-05 17:35:21 --> Language Class Initialized
ERROR - 2020-02-05 17:35:21 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 17:35:21 --> Config Class Initialized
INFO - 2020-02-05 17:35:21 --> Hooks Class Initialized
DEBUG - 2020-02-05 17:35:21 --> UTF-8 Support Enabled
INFO - 2020-02-05 17:35:21 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:21 --> URI Class Initialized
INFO - 2020-02-05 17:35:21 --> Router Class Initialized
INFO - 2020-02-05 17:35:21 --> Output Class Initialized
INFO - 2020-02-05 17:35:21 --> Security Class Initialized
DEBUG - 2020-02-05 17:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 17:35:21 --> Input Class Initialized
INFO - 2020-02-05 17:35:21 --> Language Class Initialized
ERROR - 2020-02-05 17:35:21 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 17:35:21 --> Config Class Initialized
INFO - 2020-02-05 17:35:21 --> Hooks Class Initialized
DEBUG - 2020-02-05 17:35:21 --> UTF-8 Support Enabled
INFO - 2020-02-05 17:35:21 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:21 --> URI Class Initialized
INFO - 2020-02-05 17:35:21 --> Router Class Initialized
INFO - 2020-02-05 17:35:21 --> Output Class Initialized
INFO - 2020-02-05 17:35:21 --> Security Class Initialized
DEBUG - 2020-02-05 17:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 17:35:21 --> Input Class Initialized
INFO - 2020-02-05 17:35:21 --> Language Class Initialized
ERROR - 2020-02-05 17:35:21 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 17:35:21 --> Config Class Initialized
INFO - 2020-02-05 17:35:22 --> Hooks Class Initialized
DEBUG - 2020-02-05 17:35:22 --> UTF-8 Support Enabled
INFO - 2020-02-05 17:35:22 --> Utf8 Class Initialized
INFO - 2020-02-05 17:35:22 --> URI Class Initialized
INFO - 2020-02-05 17:35:22 --> Router Class Initialized
INFO - 2020-02-05 17:35:22 --> Output Class Initialized
INFO - 2020-02-05 17:35:22 --> Security Class Initialized
DEBUG - 2020-02-05 17:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 17:35:22 --> Input Class Initialized
INFO - 2020-02-05 17:35:22 --> Language Class Initialized
ERROR - 2020-02-05 17:35:22 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 18:48:39 --> Config Class Initialized
INFO - 2020-02-05 18:48:39 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:40 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:40 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:40 --> URI Class Initialized
INFO - 2020-02-05 18:48:40 --> Router Class Initialized
INFO - 2020-02-05 18:48:40 --> Output Class Initialized
INFO - 2020-02-05 18:48:40 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:40 --> Input Class Initialized
INFO - 2020-02-05 18:48:40 --> Language Class Initialized
INFO - 2020-02-05 18:48:40 --> Loader Class Initialized
INFO - 2020-02-05 18:48:40 --> Helper loaded: url_helper
INFO - 2020-02-05 18:48:41 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:48:41 --> Controller Class Initialized
INFO - 2020-02-05 18:48:41 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:48:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:48:41 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:48:42 --> Helper loaded: form_helper
INFO - 2020-02-05 18:48:42 --> Form Validation Class Initialized
INFO - 2020-02-05 18:48:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:48:42 --> Final output sent to browser
DEBUG - 2020-02-05 18:48:42 --> Total execution time: 3.1600
INFO - 2020-02-05 18:48:42 --> Config Class Initialized
INFO - 2020-02-05 18:48:42 --> Config Class Initialized
INFO - 2020-02-05 18:48:42 --> Config Class Initialized
INFO - 2020-02-05 18:48:42 --> Config Class Initialized
INFO - 2020-02-05 18:48:42 --> Config Class Initialized
INFO - 2020-02-05 18:48:42 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:42 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:42 --> Config Class Initialized
INFO - 2020-02-05 18:48:42 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:42 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:42 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:42 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:48:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:42 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:48:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:48:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:42 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:48:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:48:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:42 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:42 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:42 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:42 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:42 --> URI Class Initialized
INFO - 2020-02-05 18:48:42 --> URI Class Initialized
INFO - 2020-02-05 18:48:43 --> URI Class Initialized
INFO - 2020-02-05 18:48:43 --> Router Class Initialized
INFO - 2020-02-05 18:48:43 --> URI Class Initialized
INFO - 2020-02-05 18:48:43 --> URI Class Initialized
INFO - 2020-02-05 18:48:43 --> Router Class Initialized
INFO - 2020-02-05 18:48:43 --> URI Class Initialized
INFO - 2020-02-05 18:48:43 --> Router Class Initialized
INFO - 2020-02-05 18:48:43 --> Router Class Initialized
INFO - 2020-02-05 18:48:43 --> Output Class Initialized
INFO - 2020-02-05 18:48:43 --> Router Class Initialized
INFO - 2020-02-05 18:48:43 --> Router Class Initialized
INFO - 2020-02-05 18:48:43 --> Output Class Initialized
INFO - 2020-02-05 18:48:43 --> Output Class Initialized
INFO - 2020-02-05 18:48:43 --> Output Class Initialized
INFO - 2020-02-05 18:48:43 --> Security Class Initialized
INFO - 2020-02-05 18:48:43 --> Security Class Initialized
INFO - 2020-02-05 18:48:43 --> Output Class Initialized
INFO - 2020-02-05 18:48:43 --> Output Class Initialized
DEBUG - 2020-02-05 18:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:43 --> Security Class Initialized
INFO - 2020-02-05 18:48:43 --> Security Class Initialized
INFO - 2020-02-05 18:48:43 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:43 --> Security Class Initialized
INFO - 2020-02-05 18:48:43 --> Input Class Initialized
DEBUG - 2020-02-05 18:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:43 --> Input Class Initialized
DEBUG - 2020-02-05 18:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:43 --> Input Class Initialized
INFO - 2020-02-05 18:48:43 --> Input Class Initialized
INFO - 2020-02-05 18:48:43 --> Input Class Initialized
INFO - 2020-02-05 18:48:43 --> Input Class Initialized
INFO - 2020-02-05 18:48:43 --> Language Class Initialized
INFO - 2020-02-05 18:48:43 --> Language Class Initialized
INFO - 2020-02-05 18:48:43 --> Language Class Initialized
INFO - 2020-02-05 18:48:43 --> Language Class Initialized
INFO - 2020-02-05 18:48:43 --> Language Class Initialized
INFO - 2020-02-05 18:48:43 --> Language Class Initialized
INFO - 2020-02-05 18:48:43 --> Loader Class Initialized
INFO - 2020-02-05 18:48:43 --> Helper loaded: url_helper
INFO - 2020-02-05 18:48:43 --> Loader Class Initialized
ERROR - 2020-02-05 18:48:43 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-05 18:48:43 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-05 18:48:43 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 18:48:43 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 18:48:43 --> Helper loaded: url_helper
INFO - 2020-02-05 18:48:43 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:48:43 --> Config Class Initialized
INFO - 2020-02-05 18:48:43 --> Config Class Initialized
INFO - 2020-02-05 18:48:43 --> Database Driver Class Initialized
INFO - 2020-02-05 18:48:43 --> Config Class Initialized
INFO - 2020-02-05 18:48:43 --> Config Class Initialized
INFO - 2020-02-05 18:48:43 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:43 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:43 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:43 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 18:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:48:43 --> Controller Class Initialized
DEBUG - 2020-02-05 18:48:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:48:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:48:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:48:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:43 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:43 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:43 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:43 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:43 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:48:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:48:43 --> URI Class Initialized
INFO - 2020-02-05 18:48:43 --> URI Class Initialized
INFO - 2020-02-05 18:48:43 --> URI Class Initialized
INFO - 2020-02-05 18:48:43 --> URI Class Initialized
INFO - 2020-02-05 18:48:43 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:48:43 --> Router Class Initialized
INFO - 2020-02-05 18:48:43 --> Router Class Initialized
INFO - 2020-02-05 18:48:43 --> Router Class Initialized
INFO - 2020-02-05 18:48:43 --> Router Class Initialized
INFO - 2020-02-05 18:48:43 --> Output Class Initialized
INFO - 2020-02-05 18:48:43 --> Output Class Initialized
INFO - 2020-02-05 18:48:43 --> Output Class Initialized
INFO - 2020-02-05 18:48:43 --> Output Class Initialized
INFO - 2020-02-05 18:48:43 --> Helper loaded: form_helper
INFO - 2020-02-05 18:48:43 --> Security Class Initialized
INFO - 2020-02-05 18:48:43 --> Security Class Initialized
INFO - 2020-02-05 18:48:43 --> Security Class Initialized
INFO - 2020-02-05 18:48:43 --> Security Class Initialized
INFO - 2020-02-05 18:48:43 --> Form Validation Class Initialized
DEBUG - 2020-02-05 18:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:48:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 18:48:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
DEBUG - 2020-02-05 18:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:43 --> Input Class Initialized
INFO - 2020-02-05 18:48:43 --> Input Class Initialized
INFO - 2020-02-05 18:48:43 --> Input Class Initialized
INFO - 2020-02-05 18:48:43 --> Input Class Initialized
ERROR - 2020-02-05 18:48:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 18:48:43 --> Language Class Initialized
INFO - 2020-02-05 18:48:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:48:43 --> Language Class Initialized
INFO - 2020-02-05 18:48:43 --> Language Class Initialized
INFO - 2020-02-05 18:48:43 --> Language Class Initialized
INFO - 2020-02-05 18:48:43 --> Final output sent to browser
ERROR - 2020-02-05 18:48:43 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 18:48:43 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 18:48:43 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 18:48:43 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-05 18:48:43 --> Total execution time: 1.0716
INFO - 2020-02-05 18:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:48:43 --> Config Class Initialized
INFO - 2020-02-05 18:48:43 --> Config Class Initialized
INFO - 2020-02-05 18:48:43 --> Config Class Initialized
INFO - 2020-02-05 18:48:43 --> Config Class Initialized
INFO - 2020-02-05 18:48:43 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:43 --> Controller Class Initialized
INFO - 2020-02-05 18:48:43 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:43 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:43 --> Model "M_tiket" initialized
DEBUG - 2020-02-05 18:48:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:48:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:48:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:43 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:43 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:43 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:43 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:48:43 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:48:44 --> URI Class Initialized
INFO - 2020-02-05 18:48:44 --> URI Class Initialized
INFO - 2020-02-05 18:48:44 --> URI Class Initialized
INFO - 2020-02-05 18:48:44 --> URI Class Initialized
INFO - 2020-02-05 18:48:44 --> Router Class Initialized
INFO - 2020-02-05 18:48:44 --> Router Class Initialized
INFO - 2020-02-05 18:48:44 --> Router Class Initialized
INFO - 2020-02-05 18:48:44 --> Router Class Initialized
INFO - 2020-02-05 18:48:44 --> Helper loaded: form_helper
INFO - 2020-02-05 18:48:44 --> Form Validation Class Initialized
INFO - 2020-02-05 18:48:44 --> Output Class Initialized
INFO - 2020-02-05 18:48:44 --> Output Class Initialized
INFO - 2020-02-05 18:48:44 --> Output Class Initialized
INFO - 2020-02-05 18:48:44 --> Output Class Initialized
INFO - 2020-02-05 18:48:44 --> Security Class Initialized
INFO - 2020-02-05 18:48:44 --> Security Class Initialized
INFO - 2020-02-05 18:48:44 --> Security Class Initialized
INFO - 2020-02-05 18:48:44 --> Security Class Initialized
ERROR - 2020-02-05 18:48:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
DEBUG - 2020-02-05 18:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 18:48:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 18:48:44 --> Input Class Initialized
INFO - 2020-02-05 18:48:44 --> Input Class Initialized
INFO - 2020-02-05 18:48:44 --> Input Class Initialized
INFO - 2020-02-05 18:48:44 --> Input Class Initialized
INFO - 2020-02-05 18:48:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:48:44 --> Final output sent to browser
INFO - 2020-02-05 18:48:44 --> Language Class Initialized
INFO - 2020-02-05 18:48:44 --> Language Class Initialized
INFO - 2020-02-05 18:48:44 --> Language Class Initialized
INFO - 2020-02-05 18:48:44 --> Language Class Initialized
DEBUG - 2020-02-05 18:48:44 --> Total execution time: 1.4833
ERROR - 2020-02-05 18:48:44 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-05 18:48:44 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 18:48:44 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 18:48:44 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 18:48:44 --> Config Class Initialized
INFO - 2020-02-05 18:48:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:44 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:44 --> URI Class Initialized
INFO - 2020-02-05 18:48:44 --> Router Class Initialized
INFO - 2020-02-05 18:48:44 --> Output Class Initialized
INFO - 2020-02-05 18:48:44 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:44 --> Input Class Initialized
INFO - 2020-02-05 18:48:44 --> Language Class Initialized
ERROR - 2020-02-05 18:48:44 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 18:48:44 --> Config Class Initialized
INFO - 2020-02-05 18:48:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:44 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:44 --> URI Class Initialized
INFO - 2020-02-05 18:48:44 --> Router Class Initialized
INFO - 2020-02-05 18:48:44 --> Output Class Initialized
INFO - 2020-02-05 18:48:44 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:44 --> Input Class Initialized
INFO - 2020-02-05 18:48:44 --> Language Class Initialized
ERROR - 2020-02-05 18:48:44 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 18:48:44 --> Config Class Initialized
INFO - 2020-02-05 18:48:45 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:45 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:45 --> URI Class Initialized
INFO - 2020-02-05 18:48:45 --> Router Class Initialized
INFO - 2020-02-05 18:48:45 --> Output Class Initialized
INFO - 2020-02-05 18:48:45 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:45 --> Input Class Initialized
INFO - 2020-02-05 18:48:45 --> Language Class Initialized
ERROR - 2020-02-05 18:48:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 18:48:45 --> Config Class Initialized
INFO - 2020-02-05 18:48:45 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:45 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:45 --> URI Class Initialized
INFO - 2020-02-05 18:48:45 --> Router Class Initialized
INFO - 2020-02-05 18:48:45 --> Output Class Initialized
INFO - 2020-02-05 18:48:45 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:45 --> Input Class Initialized
INFO - 2020-02-05 18:48:45 --> Language Class Initialized
ERROR - 2020-02-05 18:48:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 18:48:45 --> Config Class Initialized
INFO - 2020-02-05 18:48:45 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:45 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:45 --> URI Class Initialized
INFO - 2020-02-05 18:48:45 --> Router Class Initialized
INFO - 2020-02-05 18:48:45 --> Output Class Initialized
INFO - 2020-02-05 18:48:45 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:45 --> Input Class Initialized
INFO - 2020-02-05 18:48:45 --> Language Class Initialized
ERROR - 2020-02-05 18:48:45 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 18:48:45 --> Config Class Initialized
INFO - 2020-02-05 18:48:45 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:45 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:46 --> URI Class Initialized
INFO - 2020-02-05 18:48:46 --> Router Class Initialized
INFO - 2020-02-05 18:48:46 --> Output Class Initialized
INFO - 2020-02-05 18:48:46 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:46 --> Input Class Initialized
INFO - 2020-02-05 18:48:46 --> Language Class Initialized
ERROR - 2020-02-05 18:48:46 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 18:48:46 --> Config Class Initialized
INFO - 2020-02-05 18:48:46 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:46 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:46 --> URI Class Initialized
INFO - 2020-02-05 18:48:46 --> Router Class Initialized
INFO - 2020-02-05 18:48:46 --> Output Class Initialized
INFO - 2020-02-05 18:48:46 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:46 --> Input Class Initialized
INFO - 2020-02-05 18:48:46 --> Language Class Initialized
ERROR - 2020-02-05 18:48:46 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 18:48:46 --> Config Class Initialized
INFO - 2020-02-05 18:48:46 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:46 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:46 --> URI Class Initialized
INFO - 2020-02-05 18:48:46 --> Router Class Initialized
INFO - 2020-02-05 18:48:46 --> Output Class Initialized
INFO - 2020-02-05 18:48:46 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:46 --> Input Class Initialized
INFO - 2020-02-05 18:48:46 --> Language Class Initialized
ERROR - 2020-02-05 18:48:46 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 18:48:57 --> Config Class Initialized
INFO - 2020-02-05 18:48:57 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:57 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:57 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:57 --> URI Class Initialized
INFO - 2020-02-05 18:48:57 --> Router Class Initialized
INFO - 2020-02-05 18:48:57 --> Output Class Initialized
INFO - 2020-02-05 18:48:57 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:57 --> Input Class Initialized
INFO - 2020-02-05 18:48:57 --> Language Class Initialized
INFO - 2020-02-05 18:48:57 --> Loader Class Initialized
INFO - 2020-02-05 18:48:57 --> Helper loaded: url_helper
INFO - 2020-02-05 18:48:57 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:48:57 --> Controller Class Initialized
INFO - 2020-02-05 18:48:57 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:48:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:48:57 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:48:57 --> Helper loaded: form_helper
INFO - 2020-02-05 18:48:57 --> Form Validation Class Initialized
INFO - 2020-02-05 18:48:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:48:57 --> Final output sent to browser
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:58 --> Total execution time: 0.6842
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:58 --> Output Class Initialized
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:58 --> Output Class Initialized
INFO - 2020-02-05 18:48:58 --> Output Class Initialized
INFO - 2020-02-05 18:48:58 --> Security Class Initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:58 --> Output Class Initialized
INFO - 2020-02-05 18:48:58 --> Security Class Initialized
INFO - 2020-02-05 18:48:58 --> Security Class Initialized
INFO - 2020-02-05 18:48:58 --> Output Class Initialized
INFO - 2020-02-05 18:48:58 --> Output Class Initialized
DEBUG - 2020-02-05 18:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:58 --> Security Class Initialized
INFO - 2020-02-05 18:48:58 --> Input Class Initialized
DEBUG - 2020-02-05 18:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:58 --> Security Class Initialized
INFO - 2020-02-05 18:48:58 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:58 --> Input Class Initialized
INFO - 2020-02-05 18:48:58 --> Input Class Initialized
INFO - 2020-02-05 18:48:58 --> Input Class Initialized
DEBUG - 2020-02-05 18:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:58 --> Language Class Initialized
DEBUG - 2020-02-05 18:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:58 --> Input Class Initialized
INFO - 2020-02-05 18:48:58 --> Input Class Initialized
INFO - 2020-02-05 18:48:58 --> Language Class Initialized
INFO - 2020-02-05 18:48:58 --> Language Class Initialized
ERROR - 2020-02-05 18:48:58 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 18:48:58 --> Language Class Initialized
INFO - 2020-02-05 18:48:58 --> Language Class Initialized
INFO - 2020-02-05 18:48:58 --> Language Class Initialized
ERROR - 2020-02-05 18:48:58 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 18:48:58 --> Loader Class Initialized
INFO - 2020-02-05 18:48:58 --> Loader Class Initialized
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
ERROR - 2020-02-05 18:48:58 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 18:48:58 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 18:48:58 --> Helper loaded: url_helper
INFO - 2020-02-05 18:48:58 --> Helper loaded: url_helper
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:58 --> Database Driver Class Initialized
INFO - 2020-02-05 18:48:58 --> Database Driver Class Initialized
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 18:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:58 --> Controller Class Initialized
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
INFO - 2020-02-05 18:48:58 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:48:58 --> Output Class Initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
INFO - 2020-02-05 18:48:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:58 --> Output Class Initialized
INFO - 2020-02-05 18:48:58 --> Security Class Initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:58 --> Security Class Initialized
INFO - 2020-02-05 18:48:58 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:48:58 --> Output Class Initialized
INFO - 2020-02-05 18:48:58 --> Output Class Initialized
DEBUG - 2020-02-05 18:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:58 --> Input Class Initialized
DEBUG - 2020-02-05 18:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:58 --> Security Class Initialized
INFO - 2020-02-05 18:48:58 --> Security Class Initialized
INFO - 2020-02-05 18:48:58 --> Helper loaded: form_helper
INFO - 2020-02-05 18:48:58 --> Form Validation Class Initialized
INFO - 2020-02-05 18:48:58 --> Input Class Initialized
INFO - 2020-02-05 18:48:58 --> Language Class Initialized
DEBUG - 2020-02-05 18:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:58 --> Input Class Initialized
INFO - 2020-02-05 18:48:58 --> Input Class Initialized
INFO - 2020-02-05 18:48:58 --> Language Class Initialized
ERROR - 2020-02-05 18:48:58 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 18:48:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:48:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 18:48:58 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 18:48:58 --> Language Class Initialized
INFO - 2020-02-05 18:48:58 --> Language Class Initialized
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 18:48:58 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-05 18:48:58 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:58 --> Final output sent to browser
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
INFO - 2020-02-05 18:48:58 --> Config Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:48:58 --> Total execution time: 0.7795
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
INFO - 2020-02-05 18:48:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:48:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:58 --> Controller Class Initialized
INFO - 2020-02-05 18:48:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
INFO - 2020-02-05 18:48:58 --> Output Class Initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:58 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:48:58 --> URI Class Initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:58 --> Security Class Initialized
INFO - 2020-02-05 18:48:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:48:58 --> Output Class Initialized
INFO - 2020-02-05 18:48:58 --> Router Class Initialized
INFO - 2020-02-05 18:48:59 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:48:59 --> Security Class Initialized
INFO - 2020-02-05 18:48:59 --> Output Class Initialized
DEBUG - 2020-02-05 18:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:59 --> Output Class Initialized
INFO - 2020-02-05 18:48:59 --> Input Class Initialized
INFO - 2020-02-05 18:48:59 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:59 --> Security Class Initialized
INFO - 2020-02-05 18:48:59 --> Helper loaded: form_helper
INFO - 2020-02-05 18:48:59 --> Form Validation Class Initialized
INFO - 2020-02-05 18:48:59 --> Input Class Initialized
INFO - 2020-02-05 18:48:59 --> Language Class Initialized
DEBUG - 2020-02-05 18:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:59 --> Input Class Initialized
INFO - 2020-02-05 18:48:59 --> Input Class Initialized
INFO - 2020-02-05 18:48:59 --> Language Class Initialized
ERROR - 2020-02-05 18:48:59 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-05 18:48:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 18:48:59 --> Language Class Initialized
ERROR - 2020-02-05 18:48:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 18:48:59 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 18:48:59 --> Language Class Initialized
INFO - 2020-02-05 18:48:59 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 18:48:59 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 18:48:59 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 18:48:59 --> Final output sent to browser
INFO - 2020-02-05 18:48:59 --> Config Class Initialized
INFO - 2020-02-05 18:48:59 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:59 --> Total execution time: 1.1204
DEBUG - 2020-02-05 18:48:59 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:59 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:59 --> URI Class Initialized
INFO - 2020-02-05 18:48:59 --> Router Class Initialized
INFO - 2020-02-05 18:48:59 --> Output Class Initialized
INFO - 2020-02-05 18:48:59 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:59 --> Input Class Initialized
INFO - 2020-02-05 18:48:59 --> Language Class Initialized
ERROR - 2020-02-05 18:48:59 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 18:48:59 --> Config Class Initialized
INFO - 2020-02-05 18:48:59 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:59 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:59 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:59 --> URI Class Initialized
INFO - 2020-02-05 18:48:59 --> Router Class Initialized
INFO - 2020-02-05 18:48:59 --> Output Class Initialized
INFO - 2020-02-05 18:48:59 --> Security Class Initialized
DEBUG - 2020-02-05 18:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:48:59 --> Input Class Initialized
INFO - 2020-02-05 18:48:59 --> Language Class Initialized
ERROR - 2020-02-05 18:48:59 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 18:48:59 --> Config Class Initialized
INFO - 2020-02-05 18:48:59 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:48:59 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:48:59 --> Utf8 Class Initialized
INFO - 2020-02-05 18:48:59 --> URI Class Initialized
INFO - 2020-02-05 18:48:59 --> Router Class Initialized
INFO - 2020-02-05 18:48:59 --> Output Class Initialized
INFO - 2020-02-05 18:48:59 --> Security Class Initialized
DEBUG - 2020-02-05 18:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:00 --> Input Class Initialized
INFO - 2020-02-05 18:49:00 --> Language Class Initialized
ERROR - 2020-02-05 18:49:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 18:49:00 --> Config Class Initialized
INFO - 2020-02-05 18:49:00 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:49:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:00 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:00 --> URI Class Initialized
INFO - 2020-02-05 18:49:00 --> Router Class Initialized
INFO - 2020-02-05 18:49:00 --> Output Class Initialized
INFO - 2020-02-05 18:49:00 --> Security Class Initialized
DEBUG - 2020-02-05 18:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:00 --> Input Class Initialized
INFO - 2020-02-05 18:49:00 --> Language Class Initialized
ERROR - 2020-02-05 18:49:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 18:49:00 --> Config Class Initialized
INFO - 2020-02-05 18:49:00 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:49:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:00 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:00 --> URI Class Initialized
INFO - 2020-02-05 18:49:00 --> Router Class Initialized
INFO - 2020-02-05 18:49:00 --> Output Class Initialized
INFO - 2020-02-05 18:49:00 --> Security Class Initialized
DEBUG - 2020-02-05 18:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:00 --> Input Class Initialized
INFO - 2020-02-05 18:49:00 --> Language Class Initialized
ERROR - 2020-02-05 18:49:00 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 18:49:00 --> Config Class Initialized
INFO - 2020-02-05 18:49:00 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:49:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:00 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:00 --> URI Class Initialized
INFO - 2020-02-05 18:49:00 --> Router Class Initialized
INFO - 2020-02-05 18:49:01 --> Output Class Initialized
INFO - 2020-02-05 18:49:01 --> Security Class Initialized
DEBUG - 2020-02-05 18:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:01 --> Input Class Initialized
INFO - 2020-02-05 18:49:01 --> Language Class Initialized
ERROR - 2020-02-05 18:49:01 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 18:49:01 --> Config Class Initialized
INFO - 2020-02-05 18:49:01 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:49:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:01 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:01 --> URI Class Initialized
INFO - 2020-02-05 18:49:01 --> Router Class Initialized
INFO - 2020-02-05 18:49:01 --> Output Class Initialized
INFO - 2020-02-05 18:49:01 --> Security Class Initialized
DEBUG - 2020-02-05 18:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:01 --> Input Class Initialized
INFO - 2020-02-05 18:49:01 --> Language Class Initialized
ERROR - 2020-02-05 18:49:01 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 18:49:01 --> Config Class Initialized
INFO - 2020-02-05 18:49:01 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:49:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:01 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:01 --> URI Class Initialized
INFO - 2020-02-05 18:49:01 --> Router Class Initialized
INFO - 2020-02-05 18:49:01 --> Output Class Initialized
INFO - 2020-02-05 18:49:01 --> Security Class Initialized
DEBUG - 2020-02-05 18:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:01 --> Input Class Initialized
INFO - 2020-02-05 18:49:01 --> Language Class Initialized
ERROR - 2020-02-05 18:49:01 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 18:49:35 --> Config Class Initialized
INFO - 2020-02-05 18:49:35 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:49:35 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:35 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:35 --> URI Class Initialized
INFO - 2020-02-05 18:49:36 --> Router Class Initialized
INFO - 2020-02-05 18:49:36 --> Output Class Initialized
INFO - 2020-02-05 18:49:36 --> Security Class Initialized
DEBUG - 2020-02-05 18:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:36 --> Input Class Initialized
INFO - 2020-02-05 18:49:36 --> Language Class Initialized
INFO - 2020-02-05 18:49:36 --> Loader Class Initialized
INFO - 2020-02-05 18:49:36 --> Helper loaded: url_helper
INFO - 2020-02-05 18:49:36 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:49:36 --> Controller Class Initialized
INFO - 2020-02-05 18:49:36 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:49:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:49:36 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:49:36 --> Helper loaded: form_helper
INFO - 2020-02-05 18:49:36 --> Form Validation Class Initialized
INFO - 2020-02-05 18:49:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:49:36 --> Final output sent to browser
INFO - 2020-02-05 18:49:36 --> Config Class Initialized
INFO - 2020-02-05 18:49:36 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:49:36 --> Total execution time: 0.6923
INFO - 2020-02-05 18:49:36 --> Config Class Initialized
INFO - 2020-02-05 18:49:36 --> Config Class Initialized
INFO - 2020-02-05 18:49:36 --> Config Class Initialized
INFO - 2020-02-05 18:49:36 --> Config Class Initialized
INFO - 2020-02-05 18:49:36 --> Hooks Class Initialized
INFO - 2020-02-05 18:49:36 --> Hooks Class Initialized
INFO - 2020-02-05 18:49:36 --> Hooks Class Initialized
INFO - 2020-02-05 18:49:36 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:49:36 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:36 --> Config Class Initialized
INFO - 2020-02-05 18:49:36 --> Hooks Class Initialized
INFO - 2020-02-05 18:49:36 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:49:36 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:36 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:36 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:36 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:36 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:36 --> URI Class Initialized
DEBUG - 2020-02-05 18:49:36 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:36 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:36 --> Router Class Initialized
INFO - 2020-02-05 18:49:36 --> URI Class Initialized
INFO - 2020-02-05 18:49:36 --> URI Class Initialized
INFO - 2020-02-05 18:49:36 --> URI Class Initialized
INFO - 2020-02-05 18:49:36 --> URI Class Initialized
INFO - 2020-02-05 18:49:36 --> Router Class Initialized
INFO - 2020-02-05 18:49:36 --> Router Class Initialized
INFO - 2020-02-05 18:49:36 --> URI Class Initialized
INFO - 2020-02-05 18:49:36 --> Router Class Initialized
INFO - 2020-02-05 18:49:36 --> Output Class Initialized
INFO - 2020-02-05 18:49:36 --> Router Class Initialized
INFO - 2020-02-05 18:49:36 --> Security Class Initialized
INFO - 2020-02-05 18:49:36 --> Output Class Initialized
INFO - 2020-02-05 18:49:36 --> Output Class Initialized
INFO - 2020-02-05 18:49:36 --> Output Class Initialized
INFO - 2020-02-05 18:49:36 --> Output Class Initialized
INFO - 2020-02-05 18:49:36 --> Router Class Initialized
INFO - 2020-02-05 18:49:36 --> Security Class Initialized
INFO - 2020-02-05 18:49:36 --> Security Class Initialized
INFO - 2020-02-05 18:49:36 --> Output Class Initialized
INFO - 2020-02-05 18:49:36 --> Security Class Initialized
DEBUG - 2020-02-05 18:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:36 --> Security Class Initialized
DEBUG - 2020-02-05 18:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:36 --> Input Class Initialized
DEBUG - 2020-02-05 18:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:36 --> Security Class Initialized
DEBUG - 2020-02-05 18:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:36 --> Input Class Initialized
INFO - 2020-02-05 18:49:36 --> Input Class Initialized
INFO - 2020-02-05 18:49:36 --> Input Class Initialized
INFO - 2020-02-05 18:49:36 --> Input Class Initialized
INFO - 2020-02-05 18:49:36 --> Language Class Initialized
DEBUG - 2020-02-05 18:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:36 --> Input Class Initialized
INFO - 2020-02-05 18:49:36 --> Language Class Initialized
INFO - 2020-02-05 18:49:36 --> Language Class Initialized
ERROR - 2020-02-05 18:49:36 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 18:49:36 --> Language Class Initialized
INFO - 2020-02-05 18:49:36 --> Language Class Initialized
INFO - 2020-02-05 18:49:36 --> Language Class Initialized
ERROR - 2020-02-05 18:49:36 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 18:49:36 --> Loader Class Initialized
ERROR - 2020-02-05 18:49:36 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 18:49:36 --> Loader Class Initialized
INFO - 2020-02-05 18:49:36 --> Config Class Initialized
INFO - 2020-02-05 18:49:37 --> Hooks Class Initialized
ERROR - 2020-02-05 18:49:37 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 18:49:37 --> Helper loaded: url_helper
INFO - 2020-02-05 18:49:37 --> Helper loaded: url_helper
INFO - 2020-02-05 18:49:37 --> Config Class Initialized
INFO - 2020-02-05 18:49:37 --> Config Class Initialized
INFO - 2020-02-05 18:49:37 --> Hooks Class Initialized
INFO - 2020-02-05 18:49:37 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:37 --> Database Driver Class Initialized
INFO - 2020-02-05 18:49:37 --> Database Driver Class Initialized
INFO - 2020-02-05 18:49:37 --> Config Class Initialized
INFO - 2020-02-05 18:49:37 --> Hooks Class Initialized
INFO - 2020-02-05 18:49:37 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:49:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:49:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 18:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:49:37 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:49:37 --> URI Class Initialized
INFO - 2020-02-05 18:49:37 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:37 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:37 --> URI Class Initialized
INFO - 2020-02-05 18:49:37 --> URI Class Initialized
INFO - 2020-02-05 18:49:37 --> Controller Class Initialized
INFO - 2020-02-05 18:49:37 --> Router Class Initialized
INFO - 2020-02-05 18:49:37 --> URI Class Initialized
INFO - 2020-02-05 18:49:37 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:49:37 --> Output Class Initialized
INFO - 2020-02-05 18:49:37 --> Router Class Initialized
INFO - 2020-02-05 18:49:37 --> Router Class Initialized
INFO - 2020-02-05 18:49:37 --> Router Class Initialized
INFO - 2020-02-05 18:49:37 --> Security Class Initialized
INFO - 2020-02-05 18:49:37 --> Output Class Initialized
INFO - 2020-02-05 18:49:37 --> Output Class Initialized
INFO - 2020-02-05 18:49:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:49:37 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:49:37 --> Security Class Initialized
INFO - 2020-02-05 18:49:37 --> Security Class Initialized
INFO - 2020-02-05 18:49:37 --> Output Class Initialized
DEBUG - 2020-02-05 18:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:37 --> Input Class Initialized
DEBUG - 2020-02-05 18:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:37 --> Security Class Initialized
DEBUG - 2020-02-05 18:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:37 --> Helper loaded: form_helper
INFO - 2020-02-05 18:49:37 --> Form Validation Class Initialized
INFO - 2020-02-05 18:49:37 --> Input Class Initialized
INFO - 2020-02-05 18:49:37 --> Input Class Initialized
INFO - 2020-02-05 18:49:37 --> Language Class Initialized
DEBUG - 2020-02-05 18:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:37 --> Input Class Initialized
INFO - 2020-02-05 18:49:37 --> Language Class Initialized
INFO - 2020-02-05 18:49:37 --> Language Class Initialized
ERROR - 2020-02-05 18:49:37 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 18:49:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 18:49:37 --> Language Class Initialized
ERROR - 2020-02-05 18:49:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 18:49:37 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 18:49:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 18:49:37 --> Config Class Initialized
INFO - 2020-02-05 18:49:37 --> Hooks Class Initialized
INFO - 2020-02-05 18:49:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 18:49:37 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 18:49:37 --> Config Class Initialized
INFO - 2020-02-05 18:49:37 --> Config Class Initialized
INFO - 2020-02-05 18:49:37 --> Hooks Class Initialized
INFO - 2020-02-05 18:49:37 --> Hooks Class Initialized
INFO - 2020-02-05 18:49:37 --> Final output sent to browser
DEBUG - 2020-02-05 18:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:37 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:49:37 --> Total execution time: 0.7876
DEBUG - 2020-02-05 18:49:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:37 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:37 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:49:37 --> URI Class Initialized
INFO - 2020-02-05 18:49:37 --> Controller Class Initialized
INFO - 2020-02-05 18:49:37 --> URI Class Initialized
INFO - 2020-02-05 18:49:37 --> URI Class Initialized
INFO - 2020-02-05 18:49:37 --> Router Class Initialized
INFO - 2020-02-05 18:49:37 --> Router Class Initialized
INFO - 2020-02-05 18:49:37 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:49:37 --> Output Class Initialized
INFO - 2020-02-05 18:49:37 --> Router Class Initialized
INFO - 2020-02-05 18:49:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:49:37 --> Output Class Initialized
INFO - 2020-02-05 18:49:37 --> Output Class Initialized
INFO - 2020-02-05 18:49:37 --> Security Class Initialized
INFO - 2020-02-05 18:49:37 --> Model "M_pesan" initialized
DEBUG - 2020-02-05 18:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:37 --> Security Class Initialized
INFO - 2020-02-05 18:49:37 --> Security Class Initialized
INFO - 2020-02-05 18:49:37 --> Input Class Initialized
DEBUG - 2020-02-05 18:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:37 --> Helper loaded: form_helper
INFO - 2020-02-05 18:49:37 --> Input Class Initialized
INFO - 2020-02-05 18:49:37 --> Form Validation Class Initialized
INFO - 2020-02-05 18:49:37 --> Input Class Initialized
INFO - 2020-02-05 18:49:37 --> Language Class Initialized
INFO - 2020-02-05 18:49:37 --> Language Class Initialized
INFO - 2020-02-05 18:49:37 --> Language Class Initialized
ERROR - 2020-02-05 18:49:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-05 18:49:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:49:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 18:49:37 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 18:49:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 18:49:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:49:37 --> Config Class Initialized
INFO - 2020-02-05 18:49:37 --> Hooks Class Initialized
INFO - 2020-02-05 18:49:37 --> Final output sent to browser
DEBUG - 2020-02-05 18:49:37 --> Total execution time: 1.1024
DEBUG - 2020-02-05 18:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:37 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:37 --> URI Class Initialized
INFO - 2020-02-05 18:49:37 --> Router Class Initialized
INFO - 2020-02-05 18:49:37 --> Output Class Initialized
INFO - 2020-02-05 18:49:37 --> Security Class Initialized
DEBUG - 2020-02-05 18:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:37 --> Input Class Initialized
INFO - 2020-02-05 18:49:38 --> Language Class Initialized
ERROR - 2020-02-05 18:49:38 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 18:49:58 --> Config Class Initialized
INFO - 2020-02-05 18:49:58 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:49:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:49:59 --> Utf8 Class Initialized
INFO - 2020-02-05 18:49:59 --> URI Class Initialized
INFO - 2020-02-05 18:49:59 --> Router Class Initialized
INFO - 2020-02-05 18:49:59 --> Output Class Initialized
INFO - 2020-02-05 18:49:59 --> Security Class Initialized
DEBUG - 2020-02-05 18:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:49:59 --> Input Class Initialized
INFO - 2020-02-05 18:49:59 --> Language Class Initialized
INFO - 2020-02-05 18:49:59 --> Loader Class Initialized
INFO - 2020-02-05 18:49:59 --> Helper loaded: url_helper
INFO - 2020-02-05 18:49:59 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:49:59 --> Controller Class Initialized
INFO - 2020-02-05 18:49:59 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:49:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:49:59 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:49:59 --> Helper loaded: form_helper
INFO - 2020-02-05 18:49:59 --> Form Validation Class Initialized
ERROR - 2020-02-05 18:49:59 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 41
INFO - 2020-02-05 18:49:59 --> Final output sent to browser
DEBUG - 2020-02-05 18:49:59 --> Total execution time: 0.8729
INFO - 2020-02-05 18:53:16 --> Config Class Initialized
INFO - 2020-02-05 18:53:16 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:53:16 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:53:16 --> Utf8 Class Initialized
INFO - 2020-02-05 18:53:16 --> URI Class Initialized
INFO - 2020-02-05 18:53:16 --> Router Class Initialized
INFO - 2020-02-05 18:53:16 --> Output Class Initialized
INFO - 2020-02-05 18:53:16 --> Security Class Initialized
DEBUG - 2020-02-05 18:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:53:17 --> Input Class Initialized
INFO - 2020-02-05 18:53:17 --> Language Class Initialized
INFO - 2020-02-05 18:53:17 --> Loader Class Initialized
INFO - 2020-02-05 18:53:17 --> Helper loaded: url_helper
INFO - 2020-02-05 18:53:17 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:53:17 --> Controller Class Initialized
INFO - 2020-02-05 18:53:17 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:53:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:53:17 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:53:17 --> Helper loaded: form_helper
INFO - 2020-02-05 18:53:17 --> Form Validation Class Initialized
INFO - 2020-02-05 18:53:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:53:17 --> Final output sent to browser
INFO - 2020-02-05 18:53:17 --> Config Class Initialized
DEBUG - 2020-02-05 18:53:17 --> Total execution time: 1.5854
INFO - 2020-02-05 18:53:17 --> Config Class Initialized
INFO - 2020-02-05 18:53:17 --> Config Class Initialized
INFO - 2020-02-05 18:53:17 --> Hooks Class Initialized
INFO - 2020-02-05 18:53:17 --> Config Class Initialized
INFO - 2020-02-05 18:53:17 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:53:17 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:53:17 --> Hooks Class Initialized
INFO - 2020-02-05 18:53:17 --> Utf8 Class Initialized
INFO - 2020-02-05 18:53:17 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:53:17 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:53:17 --> Utf8 Class Initialized
INFO - 2020-02-05 18:53:17 --> URI Class Initialized
DEBUG - 2020-02-05 18:53:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:53:17 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:53:18 --> Utf8 Class Initialized
INFO - 2020-02-05 18:53:18 --> Utf8 Class Initialized
INFO - 2020-02-05 18:53:18 --> URI Class Initialized
INFO - 2020-02-05 18:53:18 --> Router Class Initialized
INFO - 2020-02-05 18:53:18 --> URI Class Initialized
INFO - 2020-02-05 18:53:18 --> Router Class Initialized
INFO - 2020-02-05 18:53:18 --> Output Class Initialized
INFO - 2020-02-05 18:53:18 --> URI Class Initialized
INFO - 2020-02-05 18:53:18 --> Security Class Initialized
INFO - 2020-02-05 18:53:18 --> Output Class Initialized
INFO - 2020-02-05 18:53:18 --> Router Class Initialized
INFO - 2020-02-05 18:53:18 --> Router Class Initialized
DEBUG - 2020-02-05 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:53:18 --> Output Class Initialized
INFO - 2020-02-05 18:53:18 --> Output Class Initialized
INFO - 2020-02-05 18:53:18 --> Security Class Initialized
INFO - 2020-02-05 18:53:18 --> Input Class Initialized
INFO - 2020-02-05 18:53:18 --> Security Class Initialized
INFO - 2020-02-05 18:53:18 --> Security Class Initialized
DEBUG - 2020-02-05 18:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:53:18 --> Input Class Initialized
INFO - 2020-02-05 18:53:18 --> Input Class Initialized
INFO - 2020-02-05 18:53:18 --> Language Class Initialized
DEBUG - 2020-02-05 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:53:18 --> Input Class Initialized
INFO - 2020-02-05 18:53:18 --> Language Class Initialized
INFO - 2020-02-05 18:53:18 --> Language Class Initialized
ERROR - 2020-02-05 18:53:18 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 18:53:18 --> Language Class Initialized
ERROR - 2020-02-05 18:53:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 18:53:18 --> Loader Class Initialized
INFO - 2020-02-05 18:53:18 --> Helper loaded: url_helper
INFO - 2020-02-05 18:53:18 --> Loader Class Initialized
INFO - 2020-02-05 18:53:18 --> Helper loaded: url_helper
INFO - 2020-02-05 18:53:18 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:53:18 --> Database Driver Class Initialized
INFO - 2020-02-05 18:53:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 18:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:53:18 --> Controller Class Initialized
INFO - 2020-02-05 18:53:18 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:53:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:53:18 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:53:18 --> Helper loaded: form_helper
INFO - 2020-02-05 18:53:18 --> Form Validation Class Initialized
ERROR - 2020-02-05 18:53:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:53:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 18:53:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:53:18 --> Final output sent to browser
DEBUG - 2020-02-05 18:53:18 --> Total execution time: 0.7775
INFO - 2020-02-05 18:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:53:18 --> Controller Class Initialized
INFO - 2020-02-05 18:53:18 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:53:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:53:18 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:53:18 --> Helper loaded: form_helper
INFO - 2020-02-05 18:53:18 --> Form Validation Class Initialized
ERROR - 2020-02-05 18:53:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:53:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 18:53:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:53:18 --> Final output sent to browser
DEBUG - 2020-02-05 18:53:18 --> Total execution time: 1.1044
INFO - 2020-02-05 18:53:28 --> Config Class Initialized
INFO - 2020-02-05 18:53:28 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:53:28 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:53:28 --> Utf8 Class Initialized
INFO - 2020-02-05 18:53:28 --> URI Class Initialized
INFO - 2020-02-05 18:53:28 --> Router Class Initialized
INFO - 2020-02-05 18:53:28 --> Output Class Initialized
INFO - 2020-02-05 18:53:28 --> Security Class Initialized
DEBUG - 2020-02-05 18:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:53:28 --> Input Class Initialized
INFO - 2020-02-05 18:53:28 --> Language Class Initialized
INFO - 2020-02-05 18:53:28 --> Loader Class Initialized
INFO - 2020-02-05 18:53:28 --> Helper loaded: url_helper
INFO - 2020-02-05 18:53:28 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:53:29 --> Controller Class Initialized
INFO - 2020-02-05 18:53:29 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:53:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:53:29 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:53:29 --> Helper loaded: form_helper
INFO - 2020-02-05 18:53:29 --> Form Validation Class Initialized
ERROR - 2020-02-05 18:53:29 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 41
INFO - 2020-02-05 18:53:29 --> Final output sent to browser
DEBUG - 2020-02-05 18:53:29 --> Total execution time: 0.8877
INFO - 2020-02-05 18:54:13 --> Config Class Initialized
INFO - 2020-02-05 18:54:13 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:13 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:13 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:13 --> URI Class Initialized
INFO - 2020-02-05 18:54:13 --> Router Class Initialized
INFO - 2020-02-05 18:54:13 --> Output Class Initialized
INFO - 2020-02-05 18:54:13 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:13 --> Input Class Initialized
INFO - 2020-02-05 18:54:13 --> Language Class Initialized
INFO - 2020-02-05 18:54:13 --> Loader Class Initialized
INFO - 2020-02-05 18:54:13 --> Helper loaded: url_helper
INFO - 2020-02-05 18:54:13 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:54:13 --> Controller Class Initialized
INFO - 2020-02-05 18:54:13 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:54:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:54:13 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:54:13 --> Helper loaded: form_helper
INFO - 2020-02-05 18:54:13 --> Form Validation Class Initialized
INFO - 2020-02-05 18:54:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:54:13 --> Final output sent to browser
INFO - 2020-02-05 18:54:14 --> Config Class Initialized
INFO - 2020-02-05 18:54:14 --> Config Class Initialized
INFO - 2020-02-05 18:54:14 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:14 --> Total execution time: 0.7584
INFO - 2020-02-05 18:54:14 --> Config Class Initialized
INFO - 2020-02-05 18:54:14 --> Hooks Class Initialized
INFO - 2020-02-05 18:54:14 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:54:14 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:14 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:14 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:54:14 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:14 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:14 --> URI Class Initialized
INFO - 2020-02-05 18:54:14 --> URI Class Initialized
INFO - 2020-02-05 18:54:14 --> URI Class Initialized
INFO - 2020-02-05 18:54:14 --> Router Class Initialized
INFO - 2020-02-05 18:54:14 --> Router Class Initialized
INFO - 2020-02-05 18:54:14 --> Output Class Initialized
INFO - 2020-02-05 18:54:14 --> Output Class Initialized
INFO - 2020-02-05 18:54:14 --> Router Class Initialized
INFO - 2020-02-05 18:54:14 --> Security Class Initialized
INFO - 2020-02-05 18:54:14 --> Security Class Initialized
INFO - 2020-02-05 18:54:14 --> Output Class Initialized
INFO - 2020-02-05 18:54:14 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:14 --> Input Class Initialized
INFO - 2020-02-05 18:54:14 --> Input Class Initialized
DEBUG - 2020-02-05 18:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:14 --> Input Class Initialized
INFO - 2020-02-05 18:54:14 --> Language Class Initialized
INFO - 2020-02-05 18:54:14 --> Language Class Initialized
INFO - 2020-02-05 18:54:14 --> Language Class Initialized
ERROR - 2020-02-05 18:54:14 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 18:54:14 --> Loader Class Initialized
INFO - 2020-02-05 18:54:14 --> Helper loaded: url_helper
INFO - 2020-02-05 18:54:14 --> Loader Class Initialized
INFO - 2020-02-05 18:54:14 --> Helper loaded: url_helper
INFO - 2020-02-05 18:54:14 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:54:14 --> Database Driver Class Initialized
INFO - 2020-02-05 18:54:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 18:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:54:14 --> Controller Class Initialized
INFO - 2020-02-05 18:54:14 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:54:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:54:14 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:54:14 --> Helper loaded: form_helper
INFO - 2020-02-05 18:54:14 --> Form Validation Class Initialized
ERROR - 2020-02-05 18:54:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:54:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 18:54:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:54:14 --> Final output sent to browser
DEBUG - 2020-02-05 18:54:14 --> Total execution time: 0.7665
INFO - 2020-02-05 18:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:54:14 --> Controller Class Initialized
INFO - 2020-02-05 18:54:14 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:54:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:54:14 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:54:14 --> Helper loaded: form_helper
INFO - 2020-02-05 18:54:15 --> Form Validation Class Initialized
ERROR - 2020-02-05 18:54:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:54:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 18:54:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:54:15 --> Final output sent to browser
DEBUG - 2020-02-05 18:54:15 --> Total execution time: 1.0502
INFO - 2020-02-05 18:54:19 --> Config Class Initialized
INFO - 2020-02-05 18:54:19 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:20 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:20 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:20 --> URI Class Initialized
INFO - 2020-02-05 18:54:20 --> Router Class Initialized
INFO - 2020-02-05 18:54:20 --> Output Class Initialized
INFO - 2020-02-05 18:54:20 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:20 --> Input Class Initialized
INFO - 2020-02-05 18:54:20 --> Language Class Initialized
INFO - 2020-02-05 18:54:20 --> Loader Class Initialized
INFO - 2020-02-05 18:54:20 --> Helper loaded: url_helper
INFO - 2020-02-05 18:54:20 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:54:20 --> Controller Class Initialized
INFO - 2020-02-05 18:54:20 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:54:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:54:20 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:54:20 --> Helper loaded: form_helper
INFO - 2020-02-05 18:54:20 --> Form Validation Class Initialized
INFO - 2020-02-05 18:54:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:54:20 --> Final output sent to browser
INFO - 2020-02-05 18:54:20 --> Config Class Initialized
INFO - 2020-02-05 18:54:20 --> Config Class Initialized
INFO - 2020-02-05 18:54:20 --> Config Class Initialized
INFO - 2020-02-05 18:54:20 --> Hooks Class Initialized
INFO - 2020-02-05 18:54:20 --> Hooks Class Initialized
INFO - 2020-02-05 18:54:20 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:20 --> Total execution time: 0.6403
INFO - 2020-02-05 18:54:20 --> Config Class Initialized
INFO - 2020-02-05 18:54:20 --> Config Class Initialized
INFO - 2020-02-05 18:54:20 --> Hooks Class Initialized
INFO - 2020-02-05 18:54:20 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:54:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:54:20 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:20 --> Config Class Initialized
INFO - 2020-02-05 18:54:20 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:20 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:20 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:20 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:20 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:20 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:54:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:54:20 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:20 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:20 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:20 --> URI Class Initialized
INFO - 2020-02-05 18:54:20 --> URI Class Initialized
INFO - 2020-02-05 18:54:20 --> URI Class Initialized
INFO - 2020-02-05 18:54:20 --> URI Class Initialized
INFO - 2020-02-05 18:54:20 --> URI Class Initialized
INFO - 2020-02-05 18:54:20 --> Router Class Initialized
INFO - 2020-02-05 18:54:20 --> Router Class Initialized
INFO - 2020-02-05 18:54:20 --> URI Class Initialized
INFO - 2020-02-05 18:54:20 --> Router Class Initialized
INFO - 2020-02-05 18:54:20 --> Router Class Initialized
INFO - 2020-02-05 18:54:20 --> Router Class Initialized
INFO - 2020-02-05 18:54:20 --> Output Class Initialized
INFO - 2020-02-05 18:54:20 --> Output Class Initialized
INFO - 2020-02-05 18:54:20 --> Output Class Initialized
INFO - 2020-02-05 18:54:20 --> Router Class Initialized
INFO - 2020-02-05 18:54:20 --> Output Class Initialized
INFO - 2020-02-05 18:54:20 --> Security Class Initialized
INFO - 2020-02-05 18:54:20 --> Security Class Initialized
INFO - 2020-02-05 18:54:20 --> Security Class Initialized
INFO - 2020-02-05 18:54:20 --> Output Class Initialized
INFO - 2020-02-05 18:54:20 --> Output Class Initialized
INFO - 2020-02-05 18:54:20 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:20 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:20 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:20 --> Input Class Initialized
INFO - 2020-02-05 18:54:20 --> Input Class Initialized
INFO - 2020-02-05 18:54:20 --> Input Class Initialized
INFO - 2020-02-05 18:54:20 --> Input Class Initialized
DEBUG - 2020-02-05 18:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:21 --> Input Class Initialized
INFO - 2020-02-05 18:54:21 --> Input Class Initialized
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
ERROR - 2020-02-05 18:54:21 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 18:54:21 --> Loader Class Initialized
INFO - 2020-02-05 18:54:21 --> Loader Class Initialized
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
ERROR - 2020-02-05 18:54:21 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 18:54:21 --> Helper loaded: url_helper
INFO - 2020-02-05 18:54:21 --> Helper loaded: url_helper
ERROR - 2020-02-05 18:54:21 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-05 18:54:21 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 18:54:21 --> Config Class Initialized
INFO - 2020-02-05 18:54:21 --> Config Class Initialized
INFO - 2020-02-05 18:54:21 --> Hooks Class Initialized
INFO - 2020-02-05 18:54:21 --> Hooks Class Initialized
INFO - 2020-02-05 18:54:21 --> Database Driver Class Initialized
INFO - 2020-02-05 18:54:21 --> Config Class Initialized
INFO - 2020-02-05 18:54:21 --> Config Class Initialized
INFO - 2020-02-05 18:54:21 --> Database Driver Class Initialized
INFO - 2020-02-05 18:54:21 --> Hooks Class Initialized
INFO - 2020-02-05 18:54:21 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 18:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 18:54:21 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:21 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:21 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 18:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:54:21 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:21 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:21 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:21 --> Controller Class Initialized
INFO - 2020-02-05 18:54:21 --> URI Class Initialized
INFO - 2020-02-05 18:54:21 --> URI Class Initialized
INFO - 2020-02-05 18:54:21 --> URI Class Initialized
INFO - 2020-02-05 18:54:21 --> Router Class Initialized
INFO - 2020-02-05 18:54:21 --> Router Class Initialized
INFO - 2020-02-05 18:54:21 --> URI Class Initialized
INFO - 2020-02-05 18:54:21 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:54:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:54:21 --> Router Class Initialized
INFO - 2020-02-05 18:54:21 --> Output Class Initialized
INFO - 2020-02-05 18:54:21 --> Output Class Initialized
INFO - 2020-02-05 18:54:21 --> Router Class Initialized
INFO - 2020-02-05 18:54:21 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:54:21 --> Security Class Initialized
INFO - 2020-02-05 18:54:21 --> Output Class Initialized
INFO - 2020-02-05 18:54:21 --> Output Class Initialized
INFO - 2020-02-05 18:54:21 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:21 --> Security Class Initialized
INFO - 2020-02-05 18:54:21 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:21 --> Helper loaded: form_helper
INFO - 2020-02-05 18:54:21 --> Form Validation Class Initialized
INFO - 2020-02-05 18:54:21 --> Input Class Initialized
INFO - 2020-02-05 18:54:21 --> Input Class Initialized
DEBUG - 2020-02-05 18:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:21 --> Input Class Initialized
INFO - 2020-02-05 18:54:21 --> Input Class Initialized
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
ERROR - 2020-02-05 18:54:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
ERROR - 2020-02-05 18:54:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 18:54:21 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 18:54:21 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 18:54:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 18:54:21 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 18:54:21 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 18:54:21 --> Config Class Initialized
INFO - 2020-02-05 18:54:21 --> Config Class Initialized
INFO - 2020-02-05 18:54:21 --> Hooks Class Initialized
INFO - 2020-02-05 18:54:21 --> Hooks Class Initialized
INFO - 2020-02-05 18:54:21 --> Final output sent to browser
INFO - 2020-02-05 18:54:21 --> Config Class Initialized
INFO - 2020-02-05 18:54:21 --> Config Class Initialized
INFO - 2020-02-05 18:54:21 --> Hooks Class Initialized
INFO - 2020-02-05 18:54:21 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:21 --> Total execution time: 0.8637
DEBUG - 2020-02-05 18:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:54:21 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:21 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:21 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 18:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:54:21 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:21 --> Controller Class Initialized
INFO - 2020-02-05 18:54:21 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:21 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:21 --> URI Class Initialized
INFO - 2020-02-05 18:54:21 --> URI Class Initialized
INFO - 2020-02-05 18:54:21 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:54:21 --> URI Class Initialized
INFO - 2020-02-05 18:54:21 --> Router Class Initialized
INFO - 2020-02-05 18:54:21 --> Router Class Initialized
INFO - 2020-02-05 18:54:21 --> URI Class Initialized
INFO - 2020-02-05 18:54:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:54:21 --> Router Class Initialized
INFO - 2020-02-05 18:54:21 --> Router Class Initialized
INFO - 2020-02-05 18:54:21 --> Output Class Initialized
INFO - 2020-02-05 18:54:21 --> Output Class Initialized
INFO - 2020-02-05 18:54:21 --> Security Class Initialized
INFO - 2020-02-05 18:54:21 --> Security Class Initialized
INFO - 2020-02-05 18:54:21 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:54:21 --> Output Class Initialized
INFO - 2020-02-05 18:54:21 --> Output Class Initialized
DEBUG - 2020-02-05 18:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:21 --> Security Class Initialized
INFO - 2020-02-05 18:54:21 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:21 --> Helper loaded: form_helper
INFO - 2020-02-05 18:54:21 --> Form Validation Class Initialized
INFO - 2020-02-05 18:54:21 --> Input Class Initialized
INFO - 2020-02-05 18:54:21 --> Input Class Initialized
DEBUG - 2020-02-05 18:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:21 --> Input Class Initialized
INFO - 2020-02-05 18:54:21 --> Input Class Initialized
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
ERROR - 2020-02-05 18:54:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
ERROR - 2020-02-05 18:54:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 18:54:21 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-05 18:54:21 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 18:54:21 --> Language Class Initialized
INFO - 2020-02-05 18:54:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 18:54:21 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 18:54:21 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 18:54:21 --> Final output sent to browser
DEBUG - 2020-02-05 18:54:21 --> Total execution time: 1.2476
INFO - 2020-02-05 18:54:22 --> Config Class Initialized
INFO - 2020-02-05 18:54:22 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:22 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:22 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:22 --> URI Class Initialized
INFO - 2020-02-05 18:54:22 --> Router Class Initialized
INFO - 2020-02-05 18:54:22 --> Output Class Initialized
INFO - 2020-02-05 18:54:22 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:22 --> Input Class Initialized
INFO - 2020-02-05 18:54:22 --> Language Class Initialized
ERROR - 2020-02-05 18:54:22 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 18:54:22 --> Config Class Initialized
INFO - 2020-02-05 18:54:22 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:22 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:22 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:22 --> URI Class Initialized
INFO - 2020-02-05 18:54:22 --> Router Class Initialized
INFO - 2020-02-05 18:54:22 --> Output Class Initialized
INFO - 2020-02-05 18:54:22 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:22 --> Input Class Initialized
INFO - 2020-02-05 18:54:22 --> Language Class Initialized
ERROR - 2020-02-05 18:54:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 18:54:22 --> Config Class Initialized
INFO - 2020-02-05 18:54:22 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:22 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:22 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:22 --> URI Class Initialized
INFO - 2020-02-05 18:54:22 --> Router Class Initialized
INFO - 2020-02-05 18:54:22 --> Output Class Initialized
INFO - 2020-02-05 18:54:22 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:22 --> Input Class Initialized
INFO - 2020-02-05 18:54:22 --> Language Class Initialized
ERROR - 2020-02-05 18:54:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 18:54:23 --> Config Class Initialized
INFO - 2020-02-05 18:54:23 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:23 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:23 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:23 --> URI Class Initialized
INFO - 2020-02-05 18:54:23 --> Router Class Initialized
INFO - 2020-02-05 18:54:23 --> Output Class Initialized
INFO - 2020-02-05 18:54:23 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:23 --> Input Class Initialized
INFO - 2020-02-05 18:54:23 --> Language Class Initialized
ERROR - 2020-02-05 18:54:23 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 18:54:23 --> Config Class Initialized
INFO - 2020-02-05 18:54:23 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:23 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:23 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:23 --> URI Class Initialized
INFO - 2020-02-05 18:54:23 --> Router Class Initialized
INFO - 2020-02-05 18:54:23 --> Output Class Initialized
INFO - 2020-02-05 18:54:23 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:23 --> Input Class Initialized
INFO - 2020-02-05 18:54:23 --> Language Class Initialized
ERROR - 2020-02-05 18:54:23 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 18:54:23 --> Config Class Initialized
INFO - 2020-02-05 18:54:23 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:23 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:23 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:23 --> URI Class Initialized
INFO - 2020-02-05 18:54:23 --> Router Class Initialized
INFO - 2020-02-05 18:54:23 --> Output Class Initialized
INFO - 2020-02-05 18:54:23 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:23 --> Input Class Initialized
INFO - 2020-02-05 18:54:23 --> Language Class Initialized
ERROR - 2020-02-05 18:54:24 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 18:54:24 --> Config Class Initialized
INFO - 2020-02-05 18:54:24 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:24 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:24 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:24 --> URI Class Initialized
INFO - 2020-02-05 18:54:24 --> Router Class Initialized
INFO - 2020-02-05 18:54:24 --> Output Class Initialized
INFO - 2020-02-05 18:54:24 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:24 --> Input Class Initialized
INFO - 2020-02-05 18:54:24 --> Language Class Initialized
ERROR - 2020-02-05 18:54:24 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 18:54:50 --> Config Class Initialized
INFO - 2020-02-05 18:54:50 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:54:50 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:54:50 --> Utf8 Class Initialized
INFO - 2020-02-05 18:54:51 --> URI Class Initialized
INFO - 2020-02-05 18:54:51 --> Router Class Initialized
INFO - 2020-02-05 18:54:51 --> Output Class Initialized
INFO - 2020-02-05 18:54:51 --> Security Class Initialized
DEBUG - 2020-02-05 18:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:54:51 --> Input Class Initialized
INFO - 2020-02-05 18:54:51 --> Language Class Initialized
INFO - 2020-02-05 18:54:51 --> Loader Class Initialized
INFO - 2020-02-05 18:54:51 --> Helper loaded: url_helper
INFO - 2020-02-05 18:54:51 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:54:51 --> Controller Class Initialized
INFO - 2020-02-05 18:54:51 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:54:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:54:51 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:54:51 --> Helper loaded: form_helper
INFO - 2020-02-05 18:54:51 --> Form Validation Class Initialized
ERROR - 2020-02-05 18:54:51 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 41
INFO - 2020-02-05 18:54:51 --> Final output sent to browser
DEBUG - 2020-02-05 18:54:51 --> Total execution time: 0.9088
INFO - 2020-02-05 18:55:50 --> Config Class Initialized
INFO - 2020-02-05 18:55:50 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:55:50 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:55:50 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:50 --> URI Class Initialized
INFO - 2020-02-05 18:55:50 --> Router Class Initialized
INFO - 2020-02-05 18:55:50 --> Output Class Initialized
INFO - 2020-02-05 18:55:50 --> Security Class Initialized
DEBUG - 2020-02-05 18:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:51 --> Input Class Initialized
INFO - 2020-02-05 18:55:51 --> Language Class Initialized
INFO - 2020-02-05 18:55:51 --> Loader Class Initialized
INFO - 2020-02-05 18:55:51 --> Helper loaded: url_helper
INFO - 2020-02-05 18:55:51 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:55:51 --> Controller Class Initialized
INFO - 2020-02-05 18:55:51 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:55:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:55:51 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:55:51 --> Helper loaded: form_helper
INFO - 2020-02-05 18:55:51 --> Form Validation Class Initialized
INFO - 2020-02-05 18:55:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:55:51 --> Final output sent to browser
INFO - 2020-02-05 18:55:51 --> Config Class Initialized
DEBUG - 2020-02-05 18:55:51 --> Total execution time: 1.2251
INFO - 2020-02-05 18:55:51 --> Config Class Initialized
INFO - 2020-02-05 18:55:51 --> Config Class Initialized
INFO - 2020-02-05 18:55:52 --> Hooks Class Initialized
INFO - 2020-02-05 18:55:52 --> Hooks Class Initialized
INFO - 2020-02-05 18:55:52 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:55:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:55:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:55:52 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:55:52 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:52 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:52 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:52 --> URI Class Initialized
INFO - 2020-02-05 18:55:52 --> URI Class Initialized
INFO - 2020-02-05 18:55:52 --> URI Class Initialized
INFO - 2020-02-05 18:55:52 --> Router Class Initialized
INFO - 2020-02-05 18:55:52 --> Router Class Initialized
INFO - 2020-02-05 18:55:52 --> Router Class Initialized
INFO - 2020-02-05 18:55:52 --> Output Class Initialized
INFO - 2020-02-05 18:55:52 --> Output Class Initialized
INFO - 2020-02-05 18:55:52 --> Output Class Initialized
INFO - 2020-02-05 18:55:52 --> Security Class Initialized
INFO - 2020-02-05 18:55:52 --> Security Class Initialized
INFO - 2020-02-05 18:55:52 --> Security Class Initialized
DEBUG - 2020-02-05 18:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:52 --> Input Class Initialized
INFO - 2020-02-05 18:55:52 --> Input Class Initialized
INFO - 2020-02-05 18:55:52 --> Input Class Initialized
INFO - 2020-02-05 18:55:52 --> Language Class Initialized
INFO - 2020-02-05 18:55:52 --> Language Class Initialized
INFO - 2020-02-05 18:55:52 --> Language Class Initialized
ERROR - 2020-02-05 18:55:52 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 18:55:52 --> Loader Class Initialized
INFO - 2020-02-05 18:55:52 --> Loader Class Initialized
INFO - 2020-02-05 18:55:52 --> Helper loaded: url_helper
INFO - 2020-02-05 18:55:52 --> Helper loaded: url_helper
INFO - 2020-02-05 18:55:52 --> Database Driver Class Initialized
INFO - 2020-02-05 18:55:52 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 18:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:55:52 --> Controller Class Initialized
INFO - 2020-02-05 18:55:52 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:55:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:55:52 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:55:52 --> Helper loaded: form_helper
INFO - 2020-02-05 18:55:52 --> Form Validation Class Initialized
ERROR - 2020-02-05 18:55:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:55:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 18:55:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:55:52 --> Final output sent to browser
DEBUG - 2020-02-05 18:55:52 --> Total execution time: 0.9554
INFO - 2020-02-05 18:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:55:53 --> Controller Class Initialized
INFO - 2020-02-05 18:55:53 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:55:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:55:53 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:55:53 --> Helper loaded: form_helper
INFO - 2020-02-05 18:55:53 --> Form Validation Class Initialized
ERROR - 2020-02-05 18:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 18:55:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:55:53 --> Final output sent to browser
DEBUG - 2020-02-05 18:55:53 --> Total execution time: 1.3539
INFO - 2020-02-05 18:55:56 --> Config Class Initialized
INFO - 2020-02-05 18:55:57 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:55:57 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:55:57 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:57 --> URI Class Initialized
INFO - 2020-02-05 18:55:57 --> Router Class Initialized
INFO - 2020-02-05 18:55:57 --> Output Class Initialized
INFO - 2020-02-05 18:55:57 --> Security Class Initialized
DEBUG - 2020-02-05 18:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:57 --> Input Class Initialized
INFO - 2020-02-05 18:55:57 --> Language Class Initialized
INFO - 2020-02-05 18:55:57 --> Loader Class Initialized
INFO - 2020-02-05 18:55:57 --> Helper loaded: url_helper
INFO - 2020-02-05 18:55:57 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:55:57 --> Controller Class Initialized
INFO - 2020-02-05 18:55:57 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:55:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:55:57 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:55:57 --> Helper loaded: form_helper
INFO - 2020-02-05 18:55:57 --> Form Validation Class Initialized
INFO - 2020-02-05 18:55:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:55:57 --> Final output sent to browser
INFO - 2020-02-05 18:55:57 --> Config Class Initialized
INFO - 2020-02-05 18:55:57 --> Config Class Initialized
INFO - 2020-02-05 18:55:57 --> Config Class Initialized
INFO - 2020-02-05 18:55:57 --> Hooks Class Initialized
INFO - 2020-02-05 18:55:57 --> Hooks Class Initialized
INFO - 2020-02-05 18:55:57 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:55:57 --> Total execution time: 0.7534
INFO - 2020-02-05 18:55:57 --> Config Class Initialized
INFO - 2020-02-05 18:55:57 --> Config Class Initialized
INFO - 2020-02-05 18:55:57 --> Hooks Class Initialized
INFO - 2020-02-05 18:55:57 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:55:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:55:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:55:57 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:55:57 --> Config Class Initialized
INFO - 2020-02-05 18:55:57 --> Hooks Class Initialized
INFO - 2020-02-05 18:55:57 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:57 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:57 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:55:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:55:57 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:55:57 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:57 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:57 --> URI Class Initialized
INFO - 2020-02-05 18:55:57 --> URI Class Initialized
INFO - 2020-02-05 18:55:57 --> URI Class Initialized
DEBUG - 2020-02-05 18:55:57 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:55:57 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:57 --> URI Class Initialized
INFO - 2020-02-05 18:55:57 --> Router Class Initialized
INFO - 2020-02-05 18:55:57 --> URI Class Initialized
INFO - 2020-02-05 18:55:57 --> Router Class Initialized
INFO - 2020-02-05 18:55:57 --> Router Class Initialized
INFO - 2020-02-05 18:55:57 --> URI Class Initialized
INFO - 2020-02-05 18:55:57 --> Output Class Initialized
INFO - 2020-02-05 18:55:57 --> Output Class Initialized
INFO - 2020-02-05 18:55:57 --> Router Class Initialized
INFO - 2020-02-05 18:55:57 --> Router Class Initialized
INFO - 2020-02-05 18:55:57 --> Output Class Initialized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
INFO - 2020-02-05 18:55:58 --> Output Class Initialized
INFO - 2020-02-05 18:55:58 --> Router Class Initialized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
INFO - 2020-02-05 18:55:58 --> Output Class Initialized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:58 --> Output Class Initialized
INFO - 2020-02-05 18:55:58 --> Input Class Initialized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:58 --> Input Class Initialized
INFO - 2020-02-05 18:55:58 --> Input Class Initialized
INFO - 2020-02-05 18:55:58 --> Language Class Initialized
INFO - 2020-02-05 18:55:58 --> Language Class Initialized
INFO - 2020-02-05 18:55:58 --> Input Class Initialized
INFO - 2020-02-05 18:55:58 --> Input Class Initialized
INFO - 2020-02-05 18:55:58 --> Language Class Initialized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:58 --> Input Class Initialized
INFO - 2020-02-05 18:55:58 --> Language Class Initialized
ERROR - 2020-02-05 18:55:58 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 18:55:58 --> Loader Class Initialized
INFO - 2020-02-05 18:55:58 --> Language Class Initialized
INFO - 2020-02-05 18:55:58 --> Loader Class Initialized
ERROR - 2020-02-05 18:55:58 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 18:55:58 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 18:55:58 --> Helper loaded: url_helper
INFO - 2020-02-05 18:55:58 --> Language Class Initialized
INFO - 2020-02-05 18:55:58 --> Helper loaded: url_helper
INFO - 2020-02-05 18:55:58 --> Config Class Initialized
INFO - 2020-02-05 18:55:58 --> Hooks Class Initialized
ERROR - 2020-02-05 18:55:58 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 18:55:58 --> Database Driver Class Initialized
INFO - 2020-02-05 18:55:58 --> Config Class Initialized
INFO - 2020-02-05 18:55:58 --> Config Class Initialized
INFO - 2020-02-05 18:55:58 --> Database Driver Class Initialized
INFO - 2020-02-05 18:55:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:55:58 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:55:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 18:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:55:58 --> Config Class Initialized
INFO - 2020-02-05 18:55:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:55:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 18:55:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:55:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:55:58 --> Controller Class Initialized
INFO - 2020-02-05 18:55:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:58 --> URI Class Initialized
DEBUG - 2020-02-05 18:55:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:55:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:58 --> URI Class Initialized
INFO - 2020-02-05 18:55:58 --> URI Class Initialized
INFO - 2020-02-05 18:55:58 --> Router Class Initialized
INFO - 2020-02-05 18:55:58 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:55:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:55:58 --> Router Class Initialized
INFO - 2020-02-05 18:55:58 --> Output Class Initialized
INFO - 2020-02-05 18:55:58 --> URI Class Initialized
INFO - 2020-02-05 18:55:58 --> Router Class Initialized
INFO - 2020-02-05 18:55:58 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:55:58 --> Output Class Initialized
INFO - 2020-02-05 18:55:58 --> Output Class Initialized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
INFO - 2020-02-05 18:55:58 --> Router Class Initialized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
INFO - 2020-02-05 18:55:58 --> Output Class Initialized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:58 --> Helper loaded: form_helper
INFO - 2020-02-05 18:55:58 --> Form Validation Class Initialized
INFO - 2020-02-05 18:55:58 --> Input Class Initialized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
INFO - 2020-02-05 18:55:58 --> Input Class Initialized
INFO - 2020-02-05 18:55:58 --> Input Class Initialized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:58 --> Language Class Initialized
ERROR - 2020-02-05 18:55:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 18:55:58 --> Input Class Initialized
INFO - 2020-02-05 18:55:58 --> Language Class Initialized
INFO - 2020-02-05 18:55:58 --> Language Class Initialized
ERROR - 2020-02-05 18:55:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 18:55:58 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 18:55:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:55:58 --> Language Class Initialized
ERROR - 2020-02-05 18:55:58 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 18:55:58 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 18:55:58 --> Config Class Initialized
INFO - 2020-02-05 18:55:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:55:58 --> Final output sent to browser
ERROR - 2020-02-05 18:55:58 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 18:55:58 --> Config Class Initialized
INFO - 2020-02-05 18:55:58 --> Config Class Initialized
INFO - 2020-02-05 18:55:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:55:58 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:55:58 --> Total execution time: 0.8632
DEBUG - 2020-02-05 18:55:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:55:58 --> Config Class Initialized
INFO - 2020-02-05 18:55:58 --> Hooks Class Initialized
INFO - 2020-02-05 18:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:55:58 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:55:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:55:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:55:58 --> Controller Class Initialized
INFO - 2020-02-05 18:55:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:58 --> URI Class Initialized
DEBUG - 2020-02-05 18:55:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:55:58 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:58 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:55:58 --> URI Class Initialized
INFO - 2020-02-05 18:55:58 --> URI Class Initialized
INFO - 2020-02-05 18:55:58 --> Router Class Initialized
INFO - 2020-02-05 18:55:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:55:58 --> URI Class Initialized
INFO - 2020-02-05 18:55:58 --> Output Class Initialized
INFO - 2020-02-05 18:55:58 --> Router Class Initialized
INFO - 2020-02-05 18:55:58 --> Router Class Initialized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
INFO - 2020-02-05 18:55:58 --> Router Class Initialized
INFO - 2020-02-05 18:55:58 --> Output Class Initialized
INFO - 2020-02-05 18:55:58 --> Output Class Initialized
INFO - 2020-02-05 18:55:58 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
INFO - 2020-02-05 18:55:58 --> Output Class Initialized
INFO - 2020-02-05 18:55:58 --> Helper loaded: form_helper
INFO - 2020-02-05 18:55:58 --> Input Class Initialized
INFO - 2020-02-05 18:55:58 --> Form Validation Class Initialized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:58 --> Security Class Initialized
INFO - 2020-02-05 18:55:58 --> Input Class Initialized
INFO - 2020-02-05 18:55:58 --> Input Class Initialized
INFO - 2020-02-05 18:55:58 --> Language Class Initialized
DEBUG - 2020-02-05 18:55:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 18:55:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 18:55:59 --> Language Class Initialized
ERROR - 2020-02-05 18:55:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 18:55:59 --> Input Class Initialized
INFO - 2020-02-05 18:55:59 --> Language Class Initialized
ERROR - 2020-02-05 18:55:59 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 18:55:59 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:55:59 --> Language Class Initialized
ERROR - 2020-02-05 18:55:59 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 18:55:59 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 18:55:59 --> Final output sent to browser
ERROR - 2020-02-05 18:55:59 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-05 18:55:59 --> Total execution time: 1.4484
INFO - 2020-02-05 18:55:59 --> Config Class Initialized
INFO - 2020-02-05 18:55:59 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:55:59 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:55:59 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:59 --> URI Class Initialized
INFO - 2020-02-05 18:55:59 --> Router Class Initialized
INFO - 2020-02-05 18:55:59 --> Output Class Initialized
INFO - 2020-02-05 18:55:59 --> Security Class Initialized
DEBUG - 2020-02-05 18:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:55:59 --> Input Class Initialized
INFO - 2020-02-05 18:55:59 --> Language Class Initialized
ERROR - 2020-02-05 18:55:59 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 18:55:59 --> Config Class Initialized
INFO - 2020-02-05 18:55:59 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:55:59 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:55:59 --> Utf8 Class Initialized
INFO - 2020-02-05 18:55:59 --> URI Class Initialized
INFO - 2020-02-05 18:55:59 --> Router Class Initialized
INFO - 2020-02-05 18:55:59 --> Output Class Initialized
INFO - 2020-02-05 18:55:59 --> Security Class Initialized
DEBUG - 2020-02-05 18:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:56:00 --> Input Class Initialized
INFO - 2020-02-05 18:56:00 --> Language Class Initialized
ERROR - 2020-02-05 18:56:00 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 18:56:00 --> Config Class Initialized
INFO - 2020-02-05 18:56:00 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:56:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:56:00 --> Utf8 Class Initialized
INFO - 2020-02-05 18:56:00 --> URI Class Initialized
INFO - 2020-02-05 18:56:00 --> Router Class Initialized
INFO - 2020-02-05 18:56:00 --> Output Class Initialized
INFO - 2020-02-05 18:56:00 --> Security Class Initialized
DEBUG - 2020-02-05 18:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:56:00 --> Input Class Initialized
INFO - 2020-02-05 18:56:00 --> Language Class Initialized
ERROR - 2020-02-05 18:56:00 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 18:56:00 --> Config Class Initialized
INFO - 2020-02-05 18:56:00 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:56:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:56:00 --> Utf8 Class Initialized
INFO - 2020-02-05 18:56:00 --> URI Class Initialized
INFO - 2020-02-05 18:56:00 --> Router Class Initialized
INFO - 2020-02-05 18:56:00 --> Output Class Initialized
INFO - 2020-02-05 18:56:00 --> Security Class Initialized
DEBUG - 2020-02-05 18:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:56:00 --> Input Class Initialized
INFO - 2020-02-05 18:56:00 --> Language Class Initialized
ERROR - 2020-02-05 18:56:00 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 18:56:14 --> Config Class Initialized
INFO - 2020-02-05 18:56:14 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:56:15 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:56:15 --> Utf8 Class Initialized
INFO - 2020-02-05 18:56:15 --> URI Class Initialized
INFO - 2020-02-05 18:56:15 --> Router Class Initialized
INFO - 2020-02-05 18:56:15 --> Output Class Initialized
INFO - 2020-02-05 18:56:15 --> Security Class Initialized
DEBUG - 2020-02-05 18:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:56:15 --> Input Class Initialized
INFO - 2020-02-05 18:56:15 --> Language Class Initialized
INFO - 2020-02-05 18:56:15 --> Loader Class Initialized
INFO - 2020-02-05 18:56:15 --> Helper loaded: url_helper
INFO - 2020-02-05 18:56:15 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:56:15 --> Controller Class Initialized
INFO - 2020-02-05 18:56:15 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:56:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:56:15 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:56:15 --> Helper loaded: form_helper
INFO - 2020-02-05 18:56:15 --> Form Validation Class Initialized
INFO - 2020-02-05 18:56:15 --> Final output sent to browser
DEBUG - 2020-02-05 18:56:15 --> Total execution time: 0.8386
INFO - 2020-02-05 18:57:27 --> Config Class Initialized
INFO - 2020-02-05 18:57:27 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:57:27 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:27 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:27 --> URI Class Initialized
INFO - 2020-02-05 18:57:27 --> Router Class Initialized
INFO - 2020-02-05 18:57:28 --> Output Class Initialized
INFO - 2020-02-05 18:57:28 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:28 --> Input Class Initialized
INFO - 2020-02-05 18:57:28 --> Language Class Initialized
INFO - 2020-02-05 18:57:28 --> Loader Class Initialized
INFO - 2020-02-05 18:57:28 --> Helper loaded: url_helper
INFO - 2020-02-05 18:57:28 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:57:28 --> Controller Class Initialized
INFO - 2020-02-05 18:57:28 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:57:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:57:28 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:57:28 --> Helper loaded: form_helper
INFO - 2020-02-05 18:57:28 --> Form Validation Class Initialized
INFO - 2020-02-05 18:57:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:57:28 --> Final output sent to browser
INFO - 2020-02-05 18:57:28 --> Config Class Initialized
INFO - 2020-02-05 18:57:28 --> Config Class Initialized
DEBUG - 2020-02-05 18:57:28 --> Total execution time: 0.9823
INFO - 2020-02-05 18:57:28 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:28 --> Config Class Initialized
INFO - 2020-02-05 18:57:28 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:28 --> Config Class Initialized
INFO - 2020-02-05 18:57:28 --> Config Class Initialized
INFO - 2020-02-05 18:57:28 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:28 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:28 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:57:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:57:29 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:29 --> Config Class Initialized
INFO - 2020-02-05 18:57:29 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:57:29 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:29 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:29 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:57:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:57:29 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:29 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:57:29 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:29 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:29 --> URI Class Initialized
INFO - 2020-02-05 18:57:29 --> URI Class Initialized
INFO - 2020-02-05 18:57:29 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:29 --> URI Class Initialized
INFO - 2020-02-05 18:57:29 --> Router Class Initialized
INFO - 2020-02-05 18:57:29 --> Router Class Initialized
INFO - 2020-02-05 18:57:29 --> URI Class Initialized
INFO - 2020-02-05 18:57:29 --> URI Class Initialized
INFO - 2020-02-05 18:57:29 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:29 --> Router Class Initialized
INFO - 2020-02-05 18:57:29 --> URI Class Initialized
INFO - 2020-02-05 18:57:29 --> Output Class Initialized
INFO - 2020-02-05 18:57:29 --> Output Class Initialized
INFO - 2020-02-05 18:57:29 --> Router Class Initialized
INFO - 2020-02-05 18:57:29 --> Router Class Initialized
INFO - 2020-02-05 18:57:29 --> Output Class Initialized
INFO - 2020-02-05 18:57:29 --> Output Class Initialized
INFO - 2020-02-05 18:57:29 --> Security Class Initialized
INFO - 2020-02-05 18:57:29 --> Router Class Initialized
INFO - 2020-02-05 18:57:29 --> Security Class Initialized
INFO - 2020-02-05 18:57:29 --> Output Class Initialized
DEBUG - 2020-02-05 18:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:29 --> Security Class Initialized
INFO - 2020-02-05 18:57:29 --> Security Class Initialized
INFO - 2020-02-05 18:57:29 --> Output Class Initialized
INFO - 2020-02-05 18:57:29 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:29 --> Input Class Initialized
INFO - 2020-02-05 18:57:29 --> Input Class Initialized
DEBUG - 2020-02-05 18:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:29 --> Security Class Initialized
INFO - 2020-02-05 18:57:29 --> Input Class Initialized
INFO - 2020-02-05 18:57:29 --> Input Class Initialized
INFO - 2020-02-05 18:57:29 --> Input Class Initialized
INFO - 2020-02-05 18:57:29 --> Language Class Initialized
INFO - 2020-02-05 18:57:29 --> Language Class Initialized
DEBUG - 2020-02-05 18:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:29 --> Input Class Initialized
INFO - 2020-02-05 18:57:29 --> Language Class Initialized
INFO - 2020-02-05 18:57:29 --> Language Class Initialized
ERROR - 2020-02-05 18:57:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 18:57:29 --> Language Class Initialized
ERROR - 2020-02-05 18:57:29 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 18:57:29 --> Language Class Initialized
ERROR - 2020-02-05 18:57:29 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 18:57:29 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 18:57:29 --> Loader Class Initialized
INFO - 2020-02-05 18:57:29 --> Loader Class Initialized
INFO - 2020-02-05 18:57:29 --> Config Class Initialized
INFO - 2020-02-05 18:57:29 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:29 --> Helper loaded: url_helper
INFO - 2020-02-05 18:57:29 --> Helper loaded: url_helper
DEBUG - 2020-02-05 18:57:29 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:29 --> Database Driver Class Initialized
INFO - 2020-02-05 18:57:29 --> Database Driver Class Initialized
INFO - 2020-02-05 18:57:29 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 18:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:57:29 --> URI Class Initialized
INFO - 2020-02-05 18:57:29 --> Controller Class Initialized
INFO - 2020-02-05 18:57:29 --> Router Class Initialized
INFO - 2020-02-05 18:57:29 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:57:29 --> Output Class Initialized
INFO - 2020-02-05 18:57:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:57:29 --> Security Class Initialized
INFO - 2020-02-05 18:57:29 --> Model "M_pesan" initialized
DEBUG - 2020-02-05 18:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:29 --> Input Class Initialized
INFO - 2020-02-05 18:57:29 --> Helper loaded: form_helper
INFO - 2020-02-05 18:57:29 --> Form Validation Class Initialized
INFO - 2020-02-05 18:57:29 --> Language Class Initialized
ERROR - 2020-02-05 18:57:29 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 18:57:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:57:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 18:57:30 --> Config Class Initialized
INFO - 2020-02-05 18:57:30 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:57:30 --> Final output sent to browser
DEBUG - 2020-02-05 18:57:30 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:57:30 --> Total execution time: 1.0749
INFO - 2020-02-05 18:57:30 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:57:30 --> Controller Class Initialized
INFO - 2020-02-05 18:57:30 --> URI Class Initialized
INFO - 2020-02-05 18:57:30 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:57:30 --> Router Class Initialized
INFO - 2020-02-05 18:57:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:57:30 --> Output Class Initialized
INFO - 2020-02-05 18:57:30 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:57:30 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:30 --> Helper loaded: form_helper
INFO - 2020-02-05 18:57:30 --> Form Validation Class Initialized
INFO - 2020-02-05 18:57:30 --> Input Class Initialized
INFO - 2020-02-05 18:57:30 --> Language Class Initialized
ERROR - 2020-02-05 18:57:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:57:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 18:57:30 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 18:57:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:57:30 --> Config Class Initialized
INFO - 2020-02-05 18:57:30 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:30 --> Final output sent to browser
DEBUG - 2020-02-05 18:57:30 --> Total execution time: 1.6486
DEBUG - 2020-02-05 18:57:30 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:30 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:30 --> URI Class Initialized
INFO - 2020-02-05 18:57:30 --> Router Class Initialized
INFO - 2020-02-05 18:57:30 --> Output Class Initialized
INFO - 2020-02-05 18:57:30 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:30 --> Input Class Initialized
INFO - 2020-02-05 18:57:30 --> Language Class Initialized
ERROR - 2020-02-05 18:57:30 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 18:57:48 --> Config Class Initialized
INFO - 2020-02-05 18:57:48 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:57:48 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:48 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:48 --> URI Class Initialized
INFO - 2020-02-05 18:57:48 --> Router Class Initialized
INFO - 2020-02-05 18:57:48 --> Output Class Initialized
INFO - 2020-02-05 18:57:48 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:48 --> Input Class Initialized
INFO - 2020-02-05 18:57:48 --> Language Class Initialized
INFO - 2020-02-05 18:57:48 --> Loader Class Initialized
INFO - 2020-02-05 18:57:48 --> Helper loaded: url_helper
INFO - 2020-02-05 18:57:48 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:57:48 --> Controller Class Initialized
INFO - 2020-02-05 18:57:48 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:57:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:57:48 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:57:49 --> Helper loaded: form_helper
INFO - 2020-02-05 18:57:49 --> Form Validation Class Initialized
INFO - 2020-02-05 18:57:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:57:49 --> Final output sent to browser
DEBUG - 2020-02-05 18:57:49 --> Total execution time: 0.7011
INFO - 2020-02-05 18:57:49 --> Config Class Initialized
INFO - 2020-02-05 18:57:49 --> Config Class Initialized
INFO - 2020-02-05 18:57:49 --> Config Class Initialized
INFO - 2020-02-05 18:57:49 --> Config Class Initialized
INFO - 2020-02-05 18:57:49 --> Config Class Initialized
INFO - 2020-02-05 18:57:49 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:49 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:49 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:49 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:49 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:49 --> Config Class Initialized
INFO - 2020-02-05 18:57:49 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:57:49 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:49 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:49 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:49 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:49 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:49 --> Utf8 Class Initialized
DEBUG - 2020-02-05 18:57:49 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:49 --> URI Class Initialized
INFO - 2020-02-05 18:57:49 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:49 --> URI Class Initialized
INFO - 2020-02-05 18:57:49 --> URI Class Initialized
INFO - 2020-02-05 18:57:49 --> URI Class Initialized
INFO - 2020-02-05 18:57:49 --> URI Class Initialized
INFO - 2020-02-05 18:57:49 --> Router Class Initialized
INFO - 2020-02-05 18:57:49 --> Router Class Initialized
INFO - 2020-02-05 18:57:49 --> Router Class Initialized
INFO - 2020-02-05 18:57:49 --> Router Class Initialized
INFO - 2020-02-05 18:57:49 --> URI Class Initialized
INFO - 2020-02-05 18:57:49 --> Router Class Initialized
INFO - 2020-02-05 18:57:49 --> Output Class Initialized
INFO - 2020-02-05 18:57:49 --> Output Class Initialized
INFO - 2020-02-05 18:57:49 --> Output Class Initialized
INFO - 2020-02-05 18:57:49 --> Router Class Initialized
INFO - 2020-02-05 18:57:49 --> Output Class Initialized
INFO - 2020-02-05 18:57:49 --> Output Class Initialized
INFO - 2020-02-05 18:57:49 --> Security Class Initialized
INFO - 2020-02-05 18:57:49 --> Security Class Initialized
INFO - 2020-02-05 18:57:49 --> Security Class Initialized
INFO - 2020-02-05 18:57:49 --> Security Class Initialized
INFO - 2020-02-05 18:57:49 --> Output Class Initialized
INFO - 2020-02-05 18:57:49 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:49 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:49 --> Input Class Initialized
INFO - 2020-02-05 18:57:49 --> Input Class Initialized
INFO - 2020-02-05 18:57:49 --> Input Class Initialized
INFO - 2020-02-05 18:57:49 --> Input Class Initialized
INFO - 2020-02-05 18:57:49 --> Input Class Initialized
DEBUG - 2020-02-05 18:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:49 --> Input Class Initialized
INFO - 2020-02-05 18:57:49 --> Language Class Initialized
INFO - 2020-02-05 18:57:49 --> Language Class Initialized
INFO - 2020-02-05 18:57:49 --> Language Class Initialized
INFO - 2020-02-05 18:57:49 --> Language Class Initialized
INFO - 2020-02-05 18:57:49 --> Language Class Initialized
ERROR - 2020-02-05 18:57:49 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 18:57:49 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 18:57:49 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 18:57:49 --> Language Class Initialized
INFO - 2020-02-05 18:57:49 --> Loader Class Initialized
ERROR - 2020-02-05 18:57:49 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 18:57:49 --> Loader Class Initialized
INFO - 2020-02-05 18:57:49 --> Helper loaded: url_helper
INFO - 2020-02-05 18:57:49 --> Config Class Initialized
INFO - 2020-02-05 18:57:49 --> Config Class Initialized
INFO - 2020-02-05 18:57:49 --> Config Class Initialized
INFO - 2020-02-05 18:57:49 --> Config Class Initialized
INFO - 2020-02-05 18:57:49 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:49 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:49 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:49 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:49 --> Helper loaded: url_helper
INFO - 2020-02-05 18:57:49 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:57:49 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:49 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 18:57:49 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:49 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:49 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:49 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:49 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 18:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:57:49 --> Controller Class Initialized
INFO - 2020-02-05 18:57:49 --> URI Class Initialized
INFO - 2020-02-05 18:57:49 --> URI Class Initialized
INFO - 2020-02-05 18:57:49 --> URI Class Initialized
INFO - 2020-02-05 18:57:49 --> URI Class Initialized
INFO - 2020-02-05 18:57:49 --> Router Class Initialized
INFO - 2020-02-05 18:57:49 --> Router Class Initialized
INFO - 2020-02-05 18:57:49 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:57:49 --> Router Class Initialized
INFO - 2020-02-05 18:57:49 --> Router Class Initialized
INFO - 2020-02-05 18:57:49 --> Output Class Initialized
INFO - 2020-02-05 18:57:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:57:49 --> Output Class Initialized
INFO - 2020-02-05 18:57:49 --> Output Class Initialized
INFO - 2020-02-05 18:57:49 --> Output Class Initialized
INFO - 2020-02-05 18:57:49 --> Security Class Initialized
INFO - 2020-02-05 18:57:49 --> Security Class Initialized
INFO - 2020-02-05 18:57:49 --> Security Class Initialized
INFO - 2020-02-05 18:57:49 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:57:49 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:49 --> Helper loaded: form_helper
INFO - 2020-02-05 18:57:49 --> Input Class Initialized
INFO - 2020-02-05 18:57:49 --> Input Class Initialized
INFO - 2020-02-05 18:57:49 --> Input Class Initialized
INFO - 2020-02-05 18:57:49 --> Input Class Initialized
INFO - 2020-02-05 18:57:49 --> Form Validation Class Initialized
INFO - 2020-02-05 18:57:49 --> Language Class Initialized
INFO - 2020-02-05 18:57:49 --> Language Class Initialized
INFO - 2020-02-05 18:57:49 --> Language Class Initialized
INFO - 2020-02-05 18:57:49 --> Language Class Initialized
ERROR - 2020-02-05 18:57:50 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 18:57:50 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-05 18:57:50 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 18:57:50 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 18:57:50 --> Config Class Initialized
INFO - 2020-02-05 18:57:50 --> Config Class Initialized
INFO - 2020-02-05 18:57:50 --> Config Class Initialized
INFO - 2020-02-05 18:57:50 --> Config Class Initialized
INFO - 2020-02-05 18:57:50 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:50 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:50 --> Hooks Class Initialized
INFO - 2020-02-05 18:57:50 --> Hooks Class Initialized
ERROR - 2020-02-05 18:57:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:57:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-05 18:57:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:57:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:57:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:57:50 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:50 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:50 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:50 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:50 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:57:50 --> Final output sent to browser
INFO - 2020-02-05 18:57:50 --> URI Class Initialized
INFO - 2020-02-05 18:57:50 --> URI Class Initialized
INFO - 2020-02-05 18:57:50 --> URI Class Initialized
INFO - 2020-02-05 18:57:50 --> URI Class Initialized
DEBUG - 2020-02-05 18:57:50 --> Total execution time: 0.9779
INFO - 2020-02-05 18:57:50 --> Router Class Initialized
INFO - 2020-02-05 18:57:50 --> Router Class Initialized
INFO - 2020-02-05 18:57:50 --> Router Class Initialized
INFO - 2020-02-05 18:57:50 --> Router Class Initialized
INFO - 2020-02-05 18:57:50 --> Output Class Initialized
INFO - 2020-02-05 18:57:50 --> Output Class Initialized
INFO - 2020-02-05 18:57:50 --> Output Class Initialized
INFO - 2020-02-05 18:57:50 --> Output Class Initialized
INFO - 2020-02-05 18:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:57:50 --> Controller Class Initialized
INFO - 2020-02-05 18:57:50 --> Security Class Initialized
INFO - 2020-02-05 18:57:50 --> Security Class Initialized
INFO - 2020-02-05 18:57:50 --> Security Class Initialized
INFO - 2020-02-05 18:57:50 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:50 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:57:50 --> Input Class Initialized
INFO - 2020-02-05 18:57:50 --> Input Class Initialized
INFO - 2020-02-05 18:57:50 --> Input Class Initialized
INFO - 2020-02-05 18:57:50 --> Input Class Initialized
INFO - 2020-02-05 18:57:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:57:50 --> Language Class Initialized
INFO - 2020-02-05 18:57:50 --> Language Class Initialized
INFO - 2020-02-05 18:57:50 --> Language Class Initialized
INFO - 2020-02-05 18:57:50 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:57:50 --> Language Class Initialized
ERROR - 2020-02-05 18:57:50 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 18:57:50 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 18:57:50 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 18:57:50 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 18:57:50 --> Helper loaded: form_helper
INFO - 2020-02-05 18:57:50 --> Form Validation Class Initialized
INFO - 2020-02-05 18:57:50 --> Config Class Initialized
INFO - 2020-02-05 18:57:50 --> Hooks Class Initialized
ERROR - 2020-02-05 18:57:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:57:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-05 18:57:50 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:50 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:57:50 --> Final output sent to browser
INFO - 2020-02-05 18:57:50 --> URI Class Initialized
DEBUG - 2020-02-05 18:57:50 --> Total execution time: 1.3461
INFO - 2020-02-05 18:57:50 --> Router Class Initialized
INFO - 2020-02-05 18:57:50 --> Output Class Initialized
INFO - 2020-02-05 18:57:50 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:50 --> Input Class Initialized
INFO - 2020-02-05 18:57:50 --> Language Class Initialized
ERROR - 2020-02-05 18:57:50 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 18:57:50 --> Config Class Initialized
INFO - 2020-02-05 18:57:50 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:57:50 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:50 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:51 --> URI Class Initialized
INFO - 2020-02-05 18:57:51 --> Router Class Initialized
INFO - 2020-02-05 18:57:51 --> Output Class Initialized
INFO - 2020-02-05 18:57:51 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:51 --> Input Class Initialized
INFO - 2020-02-05 18:57:51 --> Language Class Initialized
ERROR - 2020-02-05 18:57:51 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 18:57:51 --> Config Class Initialized
INFO - 2020-02-05 18:57:51 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:57:51 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:51 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:51 --> URI Class Initialized
INFO - 2020-02-05 18:57:51 --> Router Class Initialized
INFO - 2020-02-05 18:57:51 --> Output Class Initialized
INFO - 2020-02-05 18:57:51 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:51 --> Input Class Initialized
INFO - 2020-02-05 18:57:51 --> Language Class Initialized
ERROR - 2020-02-05 18:57:51 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 18:57:51 --> Config Class Initialized
INFO - 2020-02-05 18:57:51 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:57:51 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:51 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:51 --> URI Class Initialized
INFO - 2020-02-05 18:57:51 --> Router Class Initialized
INFO - 2020-02-05 18:57:51 --> Output Class Initialized
INFO - 2020-02-05 18:57:51 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:51 --> Input Class Initialized
INFO - 2020-02-05 18:57:51 --> Language Class Initialized
ERROR - 2020-02-05 18:57:51 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 18:57:52 --> Config Class Initialized
INFO - 2020-02-05 18:57:52 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:57:52 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:52 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:52 --> URI Class Initialized
INFO - 2020-02-05 18:57:52 --> Router Class Initialized
INFO - 2020-02-05 18:57:52 --> Output Class Initialized
INFO - 2020-02-05 18:57:52 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:52 --> Input Class Initialized
INFO - 2020-02-05 18:57:52 --> Language Class Initialized
ERROR - 2020-02-05 18:57:52 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 18:57:52 --> Config Class Initialized
INFO - 2020-02-05 18:57:52 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:57:52 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:52 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:52 --> URI Class Initialized
INFO - 2020-02-05 18:57:52 --> Router Class Initialized
INFO - 2020-02-05 18:57:52 --> Output Class Initialized
INFO - 2020-02-05 18:57:52 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:52 --> Input Class Initialized
INFO - 2020-02-05 18:57:52 --> Language Class Initialized
ERROR - 2020-02-05 18:57:52 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 18:57:52 --> Config Class Initialized
INFO - 2020-02-05 18:57:52 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:57:52 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:52 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:52 --> URI Class Initialized
INFO - 2020-02-05 18:57:52 --> Router Class Initialized
INFO - 2020-02-05 18:57:52 --> Output Class Initialized
INFO - 2020-02-05 18:57:52 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:53 --> Input Class Initialized
INFO - 2020-02-05 18:57:53 --> Language Class Initialized
ERROR - 2020-02-05 18:57:53 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 18:57:53 --> Config Class Initialized
INFO - 2020-02-05 18:57:53 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:57:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:53 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:53 --> URI Class Initialized
INFO - 2020-02-05 18:57:53 --> Router Class Initialized
INFO - 2020-02-05 18:57:53 --> Output Class Initialized
INFO - 2020-02-05 18:57:53 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:53 --> Input Class Initialized
INFO - 2020-02-05 18:57:53 --> Language Class Initialized
ERROR - 2020-02-05 18:57:53 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 18:57:53 --> Config Class Initialized
INFO - 2020-02-05 18:57:53 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:57:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:57:53 --> Utf8 Class Initialized
INFO - 2020-02-05 18:57:53 --> URI Class Initialized
INFO - 2020-02-05 18:57:53 --> Router Class Initialized
INFO - 2020-02-05 18:57:53 --> Output Class Initialized
INFO - 2020-02-05 18:57:53 --> Security Class Initialized
DEBUG - 2020-02-05 18:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:57:53 --> Input Class Initialized
INFO - 2020-02-05 18:57:53 --> Language Class Initialized
ERROR - 2020-02-05 18:57:53 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 18:58:10 --> Config Class Initialized
INFO - 2020-02-05 18:58:10 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:58:10 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:58:10 --> Utf8 Class Initialized
INFO - 2020-02-05 18:58:10 --> URI Class Initialized
INFO - 2020-02-05 18:58:10 --> Router Class Initialized
INFO - 2020-02-05 18:58:10 --> Output Class Initialized
INFO - 2020-02-05 18:58:10 --> Security Class Initialized
DEBUG - 2020-02-05 18:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:58:10 --> Input Class Initialized
INFO - 2020-02-05 18:58:10 --> Language Class Initialized
INFO - 2020-02-05 18:58:10 --> Loader Class Initialized
INFO - 2020-02-05 18:58:10 --> Helper loaded: url_helper
INFO - 2020-02-05 18:58:10 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:58:11 --> Controller Class Initialized
INFO - 2020-02-05 18:58:11 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:58:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:58:11 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:58:11 --> Helper loaded: form_helper
INFO - 2020-02-05 18:58:11 --> Form Validation Class Initialized
INFO - 2020-02-05 18:58:11 --> Final output sent to browser
DEBUG - 2020-02-05 18:58:11 --> Total execution time: 0.8414
INFO - 2020-02-05 18:59:54 --> Config Class Initialized
INFO - 2020-02-05 18:59:54 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:59:54 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:59:54 --> Utf8 Class Initialized
INFO - 2020-02-05 18:59:54 --> URI Class Initialized
INFO - 2020-02-05 18:59:54 --> Router Class Initialized
INFO - 2020-02-05 18:59:54 --> Output Class Initialized
INFO - 2020-02-05 18:59:54 --> Security Class Initialized
DEBUG - 2020-02-05 18:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:59:54 --> Input Class Initialized
INFO - 2020-02-05 18:59:54 --> Language Class Initialized
INFO - 2020-02-05 18:59:54 --> Loader Class Initialized
INFO - 2020-02-05 18:59:55 --> Helper loaded: url_helper
INFO - 2020-02-05 18:59:55 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:59:55 --> Controller Class Initialized
INFO - 2020-02-05 18:59:55 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:59:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:59:55 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:59:55 --> Helper loaded: form_helper
INFO - 2020-02-05 18:59:55 --> Form Validation Class Initialized
INFO - 2020-02-05 18:59:55 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:59:55 --> Final output sent to browser
INFO - 2020-02-05 18:59:56 --> Config Class Initialized
INFO - 2020-02-05 18:59:56 --> Config Class Initialized
INFO - 2020-02-05 18:59:56 --> Config Class Initialized
INFO - 2020-02-05 18:59:56 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:59:56 --> Total execution time: 1.4259
INFO - 2020-02-05 18:59:56 --> Hooks Class Initialized
INFO - 2020-02-05 18:59:56 --> Hooks Class Initialized
DEBUG - 2020-02-05 18:59:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:59:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 18:59:56 --> UTF-8 Support Enabled
INFO - 2020-02-05 18:59:56 --> Utf8 Class Initialized
INFO - 2020-02-05 18:59:56 --> Utf8 Class Initialized
INFO - 2020-02-05 18:59:56 --> Utf8 Class Initialized
INFO - 2020-02-05 18:59:56 --> URI Class Initialized
INFO - 2020-02-05 18:59:56 --> URI Class Initialized
INFO - 2020-02-05 18:59:56 --> URI Class Initialized
INFO - 2020-02-05 18:59:56 --> Router Class Initialized
INFO - 2020-02-05 18:59:56 --> Router Class Initialized
INFO - 2020-02-05 18:59:56 --> Router Class Initialized
INFO - 2020-02-05 18:59:56 --> Output Class Initialized
INFO - 2020-02-05 18:59:56 --> Output Class Initialized
INFO - 2020-02-05 18:59:56 --> Output Class Initialized
INFO - 2020-02-05 18:59:56 --> Security Class Initialized
INFO - 2020-02-05 18:59:56 --> Security Class Initialized
INFO - 2020-02-05 18:59:56 --> Security Class Initialized
DEBUG - 2020-02-05 18:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 18:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 18:59:56 --> Input Class Initialized
INFO - 2020-02-05 18:59:56 --> Input Class Initialized
INFO - 2020-02-05 18:59:56 --> Input Class Initialized
INFO - 2020-02-05 18:59:56 --> Language Class Initialized
INFO - 2020-02-05 18:59:56 --> Language Class Initialized
INFO - 2020-02-05 18:59:56 --> Language Class Initialized
ERROR - 2020-02-05 18:59:56 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 18:59:56 --> Loader Class Initialized
INFO - 2020-02-05 18:59:56 --> Loader Class Initialized
INFO - 2020-02-05 18:59:56 --> Helper loaded: url_helper
INFO - 2020-02-05 18:59:56 --> Helper loaded: url_helper
INFO - 2020-02-05 18:59:56 --> Database Driver Class Initialized
INFO - 2020-02-05 18:59:56 --> Database Driver Class Initialized
DEBUG - 2020-02-05 18:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 18:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 18:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:59:56 --> Controller Class Initialized
INFO - 2020-02-05 18:59:56 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:59:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:59:56 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:59:56 --> Helper loaded: form_helper
INFO - 2020-02-05 18:59:57 --> Form Validation Class Initialized
ERROR - 2020-02-05 18:59:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:59:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 18:59:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:59:57 --> Final output sent to browser
DEBUG - 2020-02-05 18:59:57 --> Total execution time: 0.9668
INFO - 2020-02-05 18:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 18:59:57 --> Controller Class Initialized
INFO - 2020-02-05 18:59:57 --> Model "M_tiket" initialized
INFO - 2020-02-05 18:59:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 18:59:57 --> Model "M_pesan" initialized
INFO - 2020-02-05 18:59:57 --> Helper loaded: form_helper
INFO - 2020-02-05 18:59:57 --> Form Validation Class Initialized
ERROR - 2020-02-05 18:59:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 18:59:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 18:59:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 18:59:57 --> Final output sent to browser
DEBUG - 2020-02-05 18:59:57 --> Total execution time: 1.2986
INFO - 2020-02-05 19:00:00 --> Config Class Initialized
INFO - 2020-02-05 19:00:00 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:00 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:00 --> URI Class Initialized
INFO - 2020-02-05 19:00:00 --> Router Class Initialized
INFO - 2020-02-05 19:00:00 --> Output Class Initialized
INFO - 2020-02-05 19:00:00 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:00 --> Input Class Initialized
INFO - 2020-02-05 19:00:00 --> Language Class Initialized
INFO - 2020-02-05 19:00:00 --> Loader Class Initialized
INFO - 2020-02-05 19:00:00 --> Helper loaded: url_helper
INFO - 2020-02-05 19:00:00 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:00:00 --> Controller Class Initialized
INFO - 2020-02-05 19:00:00 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:00:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:00:00 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:00:00 --> Helper loaded: form_helper
INFO - 2020-02-05 19:00:00 --> Form Validation Class Initialized
INFO - 2020-02-05 19:00:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:00:00 --> Final output sent to browser
INFO - 2020-02-05 19:00:00 --> Config Class Initialized
INFO - 2020-02-05 19:00:00 --> Config Class Initialized
INFO - 2020-02-05 19:00:00 --> Config Class Initialized
INFO - 2020-02-05 19:00:00 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:00 --> Total execution time: 0.7290
INFO - 2020-02-05 19:00:00 --> Config Class Initialized
INFO - 2020-02-05 19:00:00 --> Config Class Initialized
INFO - 2020-02-05 19:00:00 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:00 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:00 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:00 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:00 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:00 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:00 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:01 --> URI Class Initialized
INFO - 2020-02-05 19:00:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:01 --> URI Class Initialized
INFO - 2020-02-05 19:00:01 --> URI Class Initialized
INFO - 2020-02-05 19:00:01 --> URI Class Initialized
INFO - 2020-02-05 19:00:01 --> Router Class Initialized
INFO - 2020-02-05 19:00:01 --> URI Class Initialized
INFO - 2020-02-05 19:00:01 --> Router Class Initialized
INFO - 2020-02-05 19:00:01 --> Router Class Initialized
INFO - 2020-02-05 19:00:01 --> Router Class Initialized
INFO - 2020-02-05 19:00:01 --> Output Class Initialized
INFO - 2020-02-05 19:00:01 --> Output Class Initialized
INFO - 2020-02-05 19:00:01 --> Router Class Initialized
INFO - 2020-02-05 19:00:01 --> Output Class Initialized
INFO - 2020-02-05 19:00:01 --> Output Class Initialized
INFO - 2020-02-05 19:00:01 --> Security Class Initialized
INFO - 2020-02-05 19:00:01 --> Security Class Initialized
INFO - 2020-02-05 19:00:01 --> Output Class Initialized
DEBUG - 2020-02-05 19:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:01 --> Security Class Initialized
INFO - 2020-02-05 19:00:01 --> Security Class Initialized
INFO - 2020-02-05 19:00:01 --> Security Class Initialized
INFO - 2020-02-05 19:00:01 --> Input Class Initialized
INFO - 2020-02-05 19:00:01 --> Input Class Initialized
DEBUG - 2020-02-05 19:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:01 --> Input Class Initialized
INFO - 2020-02-05 19:00:01 --> Input Class Initialized
INFO - 2020-02-05 19:00:01 --> Input Class Initialized
INFO - 2020-02-05 19:00:01 --> Language Class Initialized
INFO - 2020-02-05 19:00:01 --> Language Class Initialized
INFO - 2020-02-05 19:00:01 --> Language Class Initialized
INFO - 2020-02-05 19:00:01 --> Language Class Initialized
INFO - 2020-02-05 19:00:01 --> Language Class Initialized
ERROR - 2020-02-05 19:00:01 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:00:01 --> Loader Class Initialized
ERROR - 2020-02-05 19:00:01 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:00:01 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:00:01 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 19:00:01 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:00:01 --> Config Class Initialized
INFO - 2020-02-05 19:00:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:01 --> Config Class Initialized
INFO - 2020-02-05 19:00:01 --> Database Driver Class Initialized
INFO - 2020-02-05 19:00:01 --> Config Class Initialized
INFO - 2020-02-05 19:00:01 --> Config Class Initialized
INFO - 2020-02-05 19:00:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:01 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:00:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:01 --> Controller Class Initialized
INFO - 2020-02-05 19:00:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:01 --> URI Class Initialized
INFO - 2020-02-05 19:00:01 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:00:01 --> URI Class Initialized
INFO - 2020-02-05 19:00:01 --> URI Class Initialized
INFO - 2020-02-05 19:00:01 --> Router Class Initialized
INFO - 2020-02-05 19:00:01 --> URI Class Initialized
INFO - 2020-02-05 19:00:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:00:01 --> Router Class Initialized
INFO - 2020-02-05 19:00:01 --> Router Class Initialized
INFO - 2020-02-05 19:00:01 --> Router Class Initialized
INFO - 2020-02-05 19:00:01 --> Output Class Initialized
INFO - 2020-02-05 19:00:01 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:00:01 --> Security Class Initialized
INFO - 2020-02-05 19:00:01 --> Output Class Initialized
INFO - 2020-02-05 19:00:01 --> Output Class Initialized
INFO - 2020-02-05 19:00:01 --> Output Class Initialized
DEBUG - 2020-02-05 19:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:01 --> Security Class Initialized
INFO - 2020-02-05 19:00:01 --> Security Class Initialized
INFO - 2020-02-05 19:00:01 --> Security Class Initialized
INFO - 2020-02-05 19:00:01 --> Helper loaded: form_helper
INFO - 2020-02-05 19:00:01 --> Input Class Initialized
INFO - 2020-02-05 19:00:01 --> Form Validation Class Initialized
DEBUG - 2020-02-05 19:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:01 --> Input Class Initialized
INFO - 2020-02-05 19:00:01 --> Input Class Initialized
INFO - 2020-02-05 19:00:01 --> Input Class Initialized
INFO - 2020-02-05 19:00:01 --> Language Class Initialized
ERROR - 2020-02-05 19:00:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:00:01 --> Language Class Initialized
ERROR - 2020-02-05 19:00:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:00:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:00:01 --> Language Class Initialized
INFO - 2020-02-05 19:00:01 --> Language Class Initialized
INFO - 2020-02-05 19:00:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:00:01 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-05 19:00:01 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:00:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:00:01 --> Config Class Initialized
INFO - 2020-02-05 19:00:01 --> Final output sent to browser
INFO - 2020-02-05 19:00:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:01 --> Config Class Initialized
INFO - 2020-02-05 19:00:01 --> Config Class Initialized
INFO - 2020-02-05 19:00:01 --> Config Class Initialized
INFO - 2020-02-05 19:00:02 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:02 --> Total execution time: 1.1051
INFO - 2020-02-05 19:00:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:02 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:02 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:02 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:02 --> Config Class Initialized
INFO - 2020-02-05 19:00:02 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:02 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:02 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:02 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:02 --> URI Class Initialized
INFO - 2020-02-05 19:00:02 --> URI Class Initialized
INFO - 2020-02-05 19:00:02 --> URI Class Initialized
INFO - 2020-02-05 19:00:02 --> URI Class Initialized
INFO - 2020-02-05 19:00:02 --> Router Class Initialized
DEBUG - 2020-02-05 19:00:02 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:02 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:02 --> Router Class Initialized
INFO - 2020-02-05 19:00:02 --> Output Class Initialized
INFO - 2020-02-05 19:00:02 --> Router Class Initialized
INFO - 2020-02-05 19:00:02 --> Router Class Initialized
INFO - 2020-02-05 19:00:02 --> Security Class Initialized
INFO - 2020-02-05 19:00:02 --> Output Class Initialized
INFO - 2020-02-05 19:00:02 --> Output Class Initialized
INFO - 2020-02-05 19:00:02 --> URI Class Initialized
INFO - 2020-02-05 19:00:02 --> Output Class Initialized
DEBUG - 2020-02-05 19:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:02 --> Security Class Initialized
INFO - 2020-02-05 19:00:02 --> Security Class Initialized
INFO - 2020-02-05 19:00:02 --> Security Class Initialized
INFO - 2020-02-05 19:00:02 --> Router Class Initialized
INFO - 2020-02-05 19:00:02 --> Input Class Initialized
INFO - 2020-02-05 19:00:02 --> Language Class Initialized
DEBUG - 2020-02-05 19:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:02 --> Output Class Initialized
DEBUG - 2020-02-05 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:15 --> Input Class Initialized
INFO - 2020-02-05 19:00:15 --> Input Class Initialized
INFO - 2020-02-05 19:00:15 --> Input Class Initialized
INFO - 2020-02-05 19:00:15 --> Security Class Initialized
ERROR - 2020-02-05 19:00:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:00:21 --> Config Class Initialized
INFO - 2020-02-05 19:00:21 --> Config Class Initialized
INFO - 2020-02-05 19:00:21 --> Config Class Initialized
INFO - 2020-02-05 19:00:21 --> Config Class Initialized
INFO - 2020-02-05 19:00:21 --> Config Class Initialized
INFO - 2020-02-05 19:00:21 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:21 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:21 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:21 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:21 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:21 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:21 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:21 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:21 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:21 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:21 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:21 --> URI Class Initialized
INFO - 2020-02-05 19:00:21 --> URI Class Initialized
INFO - 2020-02-05 19:00:21 --> URI Class Initialized
INFO - 2020-02-05 19:00:21 --> URI Class Initialized
INFO - 2020-02-05 19:00:21 --> URI Class Initialized
INFO - 2020-02-05 19:00:21 --> Router Class Initialized
INFO - 2020-02-05 19:00:21 --> Router Class Initialized
INFO - 2020-02-05 19:00:21 --> Router Class Initialized
INFO - 2020-02-05 19:00:21 --> Router Class Initialized
INFO - 2020-02-05 19:00:21 --> Router Class Initialized
INFO - 2020-02-05 19:00:21 --> Output Class Initialized
INFO - 2020-02-05 19:00:21 --> Output Class Initialized
INFO - 2020-02-05 19:00:21 --> Output Class Initialized
INFO - 2020-02-05 19:00:21 --> Output Class Initialized
INFO - 2020-02-05 19:00:21 --> Output Class Initialized
INFO - 2020-02-05 19:00:21 --> Security Class Initialized
INFO - 2020-02-05 19:00:21 --> Security Class Initialized
INFO - 2020-02-05 19:00:21 --> Security Class Initialized
INFO - 2020-02-05 19:00:21 --> Security Class Initialized
INFO - 2020-02-05 19:00:21 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:21 --> Input Class Initialized
INFO - 2020-02-05 19:00:21 --> Input Class Initialized
INFO - 2020-02-05 19:00:21 --> Input Class Initialized
INFO - 2020-02-05 19:00:21 --> Input Class Initialized
INFO - 2020-02-05 19:00:21 --> Input Class Initialized
INFO - 2020-02-05 19:00:21 --> Language Class Initialized
INFO - 2020-02-05 19:00:21 --> Language Class Initialized
INFO - 2020-02-05 19:00:21 --> Language Class Initialized
INFO - 2020-02-05 19:00:21 --> Language Class Initialized
INFO - 2020-02-05 19:00:21 --> Language Class Initialized
ERROR - 2020-02-05 19:00:21 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 19:00:21 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-05 19:00:21 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 19:00:21 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:00:21 --> Loader Class Initialized
INFO - 2020-02-05 19:00:21 --> Helper loaded: url_helper
INFO - 2020-02-05 19:00:21 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:00:21 --> Controller Class Initialized
INFO - 2020-02-05 19:00:21 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:00:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:00:21 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:00:21 --> Helper loaded: form_helper
INFO - 2020-02-05 19:00:21 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:00:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:00:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:00:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:00:21 --> Final output sent to browser
DEBUG - 2020-02-05 19:00:22 --> Total execution time: 0.8787
INFO - 2020-02-05 19:00:40 --> Config Class Initialized
INFO - 2020-02-05 19:00:41 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:41 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:41 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:41 --> URI Class Initialized
INFO - 2020-02-05 19:00:41 --> Router Class Initialized
INFO - 2020-02-05 19:00:41 --> Output Class Initialized
INFO - 2020-02-05 19:00:41 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:41 --> Input Class Initialized
INFO - 2020-02-05 19:00:41 --> Language Class Initialized
INFO - 2020-02-05 19:00:41 --> Loader Class Initialized
INFO - 2020-02-05 19:00:41 --> Helper loaded: url_helper
INFO - 2020-02-05 19:00:41 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:00:41 --> Controller Class Initialized
INFO - 2020-02-05 19:00:41 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:00:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:00:42 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:00:42 --> Helper loaded: form_helper
INFO - 2020-02-05 19:00:42 --> Form Validation Class Initialized
INFO - 2020-02-05 19:00:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:00:42 --> Final output sent to browser
INFO - 2020-02-05 19:00:42 --> Config Class Initialized
INFO - 2020-02-05 19:00:42 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:42 --> Total execution time: 1.1674
INFO - 2020-02-05 19:00:42 --> Config Class Initialized
INFO - 2020-02-05 19:00:42 --> Config Class Initialized
INFO - 2020-02-05 19:00:42 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:42 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:42 --> Config Class Initialized
DEBUG - 2020-02-05 19:00:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:42 --> Config Class Initialized
INFO - 2020-02-05 19:00:42 --> Config Class Initialized
INFO - 2020-02-05 19:00:42 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:42 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:42 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:42 --> URI Class Initialized
INFO - 2020-02-05 19:00:42 --> URI Class Initialized
INFO - 2020-02-05 19:00:42 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:00:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:42 --> Router Class Initialized
INFO - 2020-02-05 19:00:42 --> Router Class Initialized
INFO - 2020-02-05 19:00:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:42 --> URI Class Initialized
INFO - 2020-02-05 19:00:42 --> URI Class Initialized
INFO - 2020-02-05 19:00:42 --> Router Class Initialized
INFO - 2020-02-05 19:00:42 --> URI Class Initialized
INFO - 2020-02-05 19:00:42 --> URI Class Initialized
INFO - 2020-02-05 19:00:42 --> Output Class Initialized
INFO - 2020-02-05 19:00:42 --> Output Class Initialized
INFO - 2020-02-05 19:00:42 --> Router Class Initialized
INFO - 2020-02-05 19:00:42 --> Security Class Initialized
INFO - 2020-02-05 19:00:42 --> Security Class Initialized
INFO - 2020-02-05 19:00:42 --> Router Class Initialized
INFO - 2020-02-05 19:00:42 --> Output Class Initialized
INFO - 2020-02-05 19:00:42 --> Router Class Initialized
INFO - 2020-02-05 19:00:42 --> Security Class Initialized
INFO - 2020-02-05 19:00:42 --> Output Class Initialized
DEBUG - 2020-02-05 19:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:42 --> Output Class Initialized
INFO - 2020-02-05 19:00:42 --> Output Class Initialized
DEBUG - 2020-02-05 19:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:42 --> Security Class Initialized
INFO - 2020-02-05 19:00:42 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:42 --> Security Class Initialized
INFO - 2020-02-05 19:00:42 --> Input Class Initialized
INFO - 2020-02-05 19:00:42 --> Input Class Initialized
INFO - 2020-02-05 19:00:42 --> Input Class Initialized
INFO - 2020-02-05 19:00:42 --> Language Class Initialized
DEBUG - 2020-02-05 19:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:42 --> Language Class Initialized
DEBUG - 2020-02-05 19:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:42 --> Input Class Initialized
INFO - 2020-02-05 19:00:42 --> Input Class Initialized
INFO - 2020-02-05 19:00:42 --> Input Class Initialized
ERROR - 2020-02-05 19:00:42 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:00:42 --> Language Class Initialized
INFO - 2020-02-05 19:00:42 --> Loader Class Initialized
INFO - 2020-02-05 19:00:42 --> Language Class Initialized
INFO - 2020-02-05 19:00:42 --> Language Class Initialized
INFO - 2020-02-05 19:00:42 --> Helper loaded: url_helper
INFO - 2020-02-05 19:00:42 --> Language Class Initialized
ERROR - 2020-02-05 19:00:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:00:42 --> Config Class Initialized
INFO - 2020-02-05 19:00:42 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:42 --> Loader Class Initialized
ERROR - 2020-02-05 19:00:42 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 19:00:42 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:00:42 --> Database Driver Class Initialized
INFO - 2020-02-05 19:00:42 --> Config Class Initialized
INFO - 2020-02-05 19:00:42 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:42 --> Helper loaded: url_helper
DEBUG - 2020-02-05 19:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:00:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:42 --> Config Class Initialized
INFO - 2020-02-05 19:00:42 --> Config Class Initialized
INFO - 2020-02-05 19:00:42 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:42 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:00:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:42 --> Database Driver Class Initialized
INFO - 2020-02-05 19:00:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:42 --> Controller Class Initialized
INFO - 2020-02-05 19:00:42 --> URI Class Initialized
DEBUG - 2020-02-05 19:00:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:00:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:42 --> URI Class Initialized
INFO - 2020-02-05 19:00:42 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:00:42 --> Router Class Initialized
INFO - 2020-02-05 19:00:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:00:42 --> URI Class Initialized
INFO - 2020-02-05 19:00:42 --> Router Class Initialized
INFO - 2020-02-05 19:00:42 --> Output Class Initialized
INFO - 2020-02-05 19:00:42 --> URI Class Initialized
INFO - 2020-02-05 19:00:42 --> Security Class Initialized
INFO - 2020-02-05 19:00:42 --> Router Class Initialized
INFO - 2020-02-05 19:00:42 --> Router Class Initialized
INFO - 2020-02-05 19:00:42 --> Output Class Initialized
INFO - 2020-02-05 19:00:42 --> Model "M_pesan" initialized
DEBUG - 2020-02-05 19:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:43 --> Security Class Initialized
INFO - 2020-02-05 19:00:43 --> Output Class Initialized
INFO - 2020-02-05 19:00:43 --> Output Class Initialized
INFO - 2020-02-05 19:00:43 --> Helper loaded: form_helper
INFO - 2020-02-05 19:00:43 --> Form Validation Class Initialized
INFO - 2020-02-05 19:00:43 --> Input Class Initialized
INFO - 2020-02-05 19:00:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:43 --> Security Class Initialized
INFO - 2020-02-05 19:00:43 --> Input Class Initialized
DEBUG - 2020-02-05 19:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:43 --> Language Class Initialized
DEBUG - 2020-02-05 19:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 19:00:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:00:43 --> Input Class Initialized
INFO - 2020-02-05 19:00:43 --> Input Class Initialized
ERROR - 2020-02-05 19:00:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:00:43 --> Language Class Initialized
ERROR - 2020-02-05 19:00:43 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:00:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:00:43 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:00:43 --> Language Class Initialized
INFO - 2020-02-05 19:00:43 --> Language Class Initialized
INFO - 2020-02-05 19:00:43 --> Config Class Initialized
INFO - 2020-02-05 19:00:43 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:43 --> Final output sent to browser
ERROR - 2020-02-05 19:00:43 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:00:43 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:00:43 --> Config Class Initialized
INFO - 2020-02-05 19:00:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:43 --> Total execution time: 0.9653
DEBUG - 2020-02-05 19:00:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:43 --> Config Class Initialized
INFO - 2020-02-05 19:00:43 --> Config Class Initialized
INFO - 2020-02-05 19:00:43 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:43 --> Hooks Class Initialized
INFO - 2020-02-05 19:00:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:00:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:43 --> Controller Class Initialized
INFO - 2020-02-05 19:00:43 --> URI Class Initialized
DEBUG - 2020-02-05 19:00:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:00:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:43 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:00:43 --> Router Class Initialized
INFO - 2020-02-05 19:00:43 --> URI Class Initialized
INFO - 2020-02-05 19:00:43 --> URI Class Initialized
INFO - 2020-02-05 19:00:43 --> Router Class Initialized
INFO - 2020-02-05 19:00:43 --> URI Class Initialized
INFO - 2020-02-05 19:00:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:00:43 --> Output Class Initialized
INFO - 2020-02-05 19:00:43 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:00:43 --> Router Class Initialized
INFO - 2020-02-05 19:00:43 --> Security Class Initialized
INFO - 2020-02-05 19:00:43 --> Router Class Initialized
INFO - 2020-02-05 19:00:43 --> Output Class Initialized
INFO - 2020-02-05 19:00:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:43 --> Output Class Initialized
INFO - 2020-02-05 19:00:43 --> Output Class Initialized
INFO - 2020-02-05 19:00:43 --> Helper loaded: form_helper
INFO - 2020-02-05 19:00:43 --> Input Class Initialized
INFO - 2020-02-05 19:00:43 --> Form Validation Class Initialized
INFO - 2020-02-05 19:00:43 --> Security Class Initialized
INFO - 2020-02-05 19:00:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:43 --> Language Class Initialized
INFO - 2020-02-05 19:00:43 --> Input Class Initialized
DEBUG - 2020-02-05 19:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 19:00:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:00:43 --> Input Class Initialized
INFO - 2020-02-05 19:00:43 --> Language Class Initialized
ERROR - 2020-02-05 19:00:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:00:43 --> Input Class Initialized
ERROR - 2020-02-05 19:00:43 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:00:43 --> Language Class Initialized
INFO - 2020-02-05 19:00:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:00:43 --> Language Class Initialized
ERROR - 2020-02-05 19:00:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:00:43 --> Final output sent to browser
ERROR - 2020-02-05 19:00:43 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 19:00:43 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-05 19:00:43 --> Total execution time: 1.3209
INFO - 2020-02-05 19:00:43 --> Config Class Initialized
INFO - 2020-02-05 19:00:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:43 --> URI Class Initialized
INFO - 2020-02-05 19:00:43 --> Router Class Initialized
INFO - 2020-02-05 19:00:43 --> Output Class Initialized
INFO - 2020-02-05 19:00:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:43 --> Input Class Initialized
INFO - 2020-02-05 19:00:44 --> Language Class Initialized
ERROR - 2020-02-05 19:00:44 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:00:44 --> Config Class Initialized
INFO - 2020-02-05 19:00:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:44 --> URI Class Initialized
INFO - 2020-02-05 19:00:44 --> Router Class Initialized
INFO - 2020-02-05 19:00:44 --> Output Class Initialized
INFO - 2020-02-05 19:00:44 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:44 --> Input Class Initialized
INFO - 2020-02-05 19:00:44 --> Language Class Initialized
ERROR - 2020-02-05 19:00:44 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:00:44 --> Config Class Initialized
INFO - 2020-02-05 19:00:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:44 --> URI Class Initialized
INFO - 2020-02-05 19:00:44 --> Router Class Initialized
INFO - 2020-02-05 19:00:44 --> Output Class Initialized
INFO - 2020-02-05 19:00:44 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:44 --> Input Class Initialized
INFO - 2020-02-05 19:00:44 --> Language Class Initialized
ERROR - 2020-02-05 19:00:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:00:44 --> Config Class Initialized
INFO - 2020-02-05 19:00:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:45 --> URI Class Initialized
INFO - 2020-02-05 19:00:45 --> Router Class Initialized
INFO - 2020-02-05 19:00:45 --> Output Class Initialized
INFO - 2020-02-05 19:00:45 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:45 --> Input Class Initialized
INFO - 2020-02-05 19:00:45 --> Language Class Initialized
ERROR - 2020-02-05 19:00:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:00:45 --> Config Class Initialized
INFO - 2020-02-05 19:00:45 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:45 --> URI Class Initialized
INFO - 2020-02-05 19:00:45 --> Router Class Initialized
INFO - 2020-02-05 19:00:45 --> Output Class Initialized
INFO - 2020-02-05 19:00:45 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:45 --> Input Class Initialized
INFO - 2020-02-05 19:00:45 --> Language Class Initialized
ERROR - 2020-02-05 19:00:45 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:00:45 --> Config Class Initialized
INFO - 2020-02-05 19:00:45 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:45 --> URI Class Initialized
INFO - 2020-02-05 19:00:45 --> Router Class Initialized
INFO - 2020-02-05 19:00:45 --> Output Class Initialized
INFO - 2020-02-05 19:00:45 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:45 --> Input Class Initialized
INFO - 2020-02-05 19:00:46 --> Language Class Initialized
ERROR - 2020-02-05 19:00:46 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:00:46 --> Config Class Initialized
INFO - 2020-02-05 19:00:46 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:46 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:46 --> URI Class Initialized
INFO - 2020-02-05 19:00:46 --> Router Class Initialized
INFO - 2020-02-05 19:00:46 --> Output Class Initialized
INFO - 2020-02-05 19:00:46 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:46 --> Input Class Initialized
INFO - 2020-02-05 19:00:46 --> Language Class Initialized
ERROR - 2020-02-05 19:00:46 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:00:46 --> Config Class Initialized
INFO - 2020-02-05 19:00:46 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:00:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:00:46 --> Utf8 Class Initialized
INFO - 2020-02-05 19:00:46 --> URI Class Initialized
INFO - 2020-02-05 19:00:46 --> Router Class Initialized
INFO - 2020-02-05 19:00:46 --> Output Class Initialized
INFO - 2020-02-05 19:00:46 --> Security Class Initialized
DEBUG - 2020-02-05 19:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:00:46 --> Input Class Initialized
INFO - 2020-02-05 19:00:46 --> Language Class Initialized
ERROR - 2020-02-05 19:00:46 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:01:00 --> Config Class Initialized
INFO - 2020-02-05 19:01:00 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:00 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:00 --> URI Class Initialized
INFO - 2020-02-05 19:01:00 --> Router Class Initialized
INFO - 2020-02-05 19:01:00 --> Output Class Initialized
INFO - 2020-02-05 19:01:00 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:00 --> Input Class Initialized
INFO - 2020-02-05 19:01:00 --> Language Class Initialized
INFO - 2020-02-05 19:01:00 --> Loader Class Initialized
INFO - 2020-02-05 19:01:00 --> Helper loaded: url_helper
INFO - 2020-02-05 19:01:00 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:01:00 --> Controller Class Initialized
INFO - 2020-02-05 19:01:00 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:01:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:01:00 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:01:00 --> Helper loaded: form_helper
INFO - 2020-02-05 19:01:00 --> Form Validation Class Initialized
INFO - 2020-02-05 19:01:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:01:00 --> Final output sent to browser
INFO - 2020-02-05 19:01:01 --> Config Class Initialized
INFO - 2020-02-05 19:01:01 --> Config Class Initialized
INFO - 2020-02-05 19:01:01 --> Config Class Initialized
INFO - 2020-02-05 19:01:01 --> Config Class Initialized
INFO - 2020-02-05 19:01:01 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:01 --> Total execution time: 0.9513
INFO - 2020-02-05 19:01:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:01:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:01:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:01:01 --> Config Class Initialized
DEBUG - 2020-02-05 19:01:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:01:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:01 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:01:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:01 --> Config Class Initialized
INFO - 2020-02-05 19:01:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:01:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:01 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:01:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:01 --> URI Class Initialized
INFO - 2020-02-05 19:01:01 --> URI Class Initialized
DEBUG - 2020-02-05 19:01:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:01 --> URI Class Initialized
INFO - 2020-02-05 19:01:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:01 --> URI Class Initialized
INFO - 2020-02-05 19:01:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:01 --> URI Class Initialized
INFO - 2020-02-05 19:01:01 --> Router Class Initialized
INFO - 2020-02-05 19:01:01 --> Router Class Initialized
INFO - 2020-02-05 19:01:01 --> Router Class Initialized
INFO - 2020-02-05 19:01:01 --> Router Class Initialized
INFO - 2020-02-05 19:01:01 --> Output Class Initialized
INFO - 2020-02-05 19:01:01 --> URI Class Initialized
INFO - 2020-02-05 19:01:01 --> Output Class Initialized
INFO - 2020-02-05 19:01:01 --> Output Class Initialized
INFO - 2020-02-05 19:01:01 --> Router Class Initialized
INFO - 2020-02-05 19:01:01 --> Output Class Initialized
INFO - 2020-02-05 19:01:01 --> Security Class Initialized
INFO - 2020-02-05 19:01:01 --> Output Class Initialized
INFO - 2020-02-05 19:01:01 --> Security Class Initialized
INFO - 2020-02-05 19:01:01 --> Security Class Initialized
INFO - 2020-02-05 19:01:01 --> Router Class Initialized
DEBUG - 2020-02-05 19:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:01 --> Security Class Initialized
INFO - 2020-02-05 19:01:01 --> Output Class Initialized
INFO - 2020-02-05 19:01:01 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:01 --> Input Class Initialized
INFO - 2020-02-05 19:01:01 --> Input Class Initialized
INFO - 2020-02-05 19:01:01 --> Input Class Initialized
INFO - 2020-02-05 19:01:01 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:01 --> Input Class Initialized
INFO - 2020-02-05 19:01:01 --> Input Class Initialized
INFO - 2020-02-05 19:01:01 --> Language Class Initialized
INFO - 2020-02-05 19:01:01 --> Language Class Initialized
DEBUG - 2020-02-05 19:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:01 --> Language Class Initialized
INFO - 2020-02-05 19:01:01 --> Language Class Initialized
INFO - 2020-02-05 19:01:01 --> Input Class Initialized
ERROR - 2020-02-05 19:01:01 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-05 19:01:01 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:01:01 --> Language Class Initialized
ERROR - 2020-02-05 19:01:01 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:01:01 --> Language Class Initialized
ERROR - 2020-02-05 19:01:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 19:01:01 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:01:01 --> Config Class Initialized
INFO - 2020-02-05 19:01:01 --> Config Class Initialized
INFO - 2020-02-05 19:01:01 --> Config Class Initialized
INFO - 2020-02-05 19:01:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:01:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:01:01 --> Hooks Class Initialized
ERROR - 2020-02-05 19:01:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:01:01 --> Config Class Initialized
INFO - 2020-02-05 19:01:01 --> Config Class Initialized
INFO - 2020-02-05 19:01:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:01:01 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:01:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:01:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:01 --> Config Class Initialized
INFO - 2020-02-05 19:01:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:01:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:01 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:01:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:01:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:01 --> URI Class Initialized
INFO - 2020-02-05 19:01:01 --> URI Class Initialized
DEBUG - 2020-02-05 19:01:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:01 --> URI Class Initialized
INFO - 2020-02-05 19:01:01 --> Router Class Initialized
INFO - 2020-02-05 19:01:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:01 --> URI Class Initialized
INFO - 2020-02-05 19:01:01 --> URI Class Initialized
INFO - 2020-02-05 19:01:01 --> Router Class Initialized
INFO - 2020-02-05 19:01:01 --> Router Class Initialized
INFO - 2020-02-05 19:01:02 --> URI Class Initialized
INFO - 2020-02-05 19:01:02 --> Router Class Initialized
INFO - 2020-02-05 19:01:02 --> Output Class Initialized
INFO - 2020-02-05 19:01:02 --> Output Class Initialized
INFO - 2020-02-05 19:01:02 --> Router Class Initialized
INFO - 2020-02-05 19:01:02 --> Output Class Initialized
INFO - 2020-02-05 19:01:02 --> Router Class Initialized
INFO - 2020-02-05 19:01:02 --> Security Class Initialized
INFO - 2020-02-05 19:01:02 --> Security Class Initialized
INFO - 2020-02-05 19:01:02 --> Output Class Initialized
INFO - 2020-02-05 19:01:02 --> Output Class Initialized
INFO - 2020-02-05 19:01:02 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:02 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:02 --> Security Class Initialized
INFO - 2020-02-05 19:01:02 --> Output Class Initialized
INFO - 2020-02-05 19:01:02 --> Input Class Initialized
INFO - 2020-02-05 19:01:02 --> Input Class Initialized
INFO - 2020-02-05 19:01:02 --> Input Class Initialized
INFO - 2020-02-05 19:01:02 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:02 --> Input Class Initialized
INFO - 2020-02-05 19:01:02 --> Input Class Initialized
INFO - 2020-02-05 19:01:02 --> Language Class Initialized
INFO - 2020-02-05 19:01:02 --> Language Class Initialized
DEBUG - 2020-02-05 19:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:02 --> Language Class Initialized
INFO - 2020-02-05 19:01:02 --> Input Class Initialized
INFO - 2020-02-05 19:01:02 --> Loader Class Initialized
ERROR - 2020-02-05 19:01:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:01:02 --> Language Class Initialized
INFO - 2020-02-05 19:01:02 --> Language Class Initialized
INFO - 2020-02-05 19:01:02 --> Loader Class Initialized
INFO - 2020-02-05 19:01:02 --> Helper loaded: url_helper
INFO - 2020-02-05 19:01:02 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:01:02 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:01:02 --> Language Class Initialized
ERROR - 2020-02-05 19:01:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:01:02 --> Config Class Initialized
INFO - 2020-02-05 19:01:02 --> Hooks Class Initialized
ERROR - 2020-02-05 19:01:02 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:01:02 --> Database Driver Class Initialized
INFO - 2020-02-05 19:01:02 --> Database Driver Class Initialized
INFO - 2020-02-05 19:01:02 --> Config Class Initialized
INFO - 2020-02-05 19:01:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:01:02 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:01:02 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:02 --> Controller Class Initialized
INFO - 2020-02-05 19:01:02 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:02 --> URI Class Initialized
INFO - 2020-02-05 19:01:02 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:01:02 --> Router Class Initialized
INFO - 2020-02-05 19:01:02 --> URI Class Initialized
INFO - 2020-02-05 19:01:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:01:02 --> Router Class Initialized
INFO - 2020-02-05 19:01:02 --> Output Class Initialized
INFO - 2020-02-05 19:01:02 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:01:02 --> Security Class Initialized
INFO - 2020-02-05 19:01:02 --> Output Class Initialized
DEBUG - 2020-02-05 19:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:02 --> Security Class Initialized
INFO - 2020-02-05 19:01:02 --> Helper loaded: form_helper
INFO - 2020-02-05 19:01:02 --> Form Validation Class Initialized
INFO - 2020-02-05 19:01:02 --> Input Class Initialized
DEBUG - 2020-02-05 19:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:02 --> Input Class Initialized
INFO - 2020-02-05 19:01:02 --> Language Class Initialized
ERROR - 2020-02-05 19:01:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:01:02 --> Language Class Initialized
ERROR - 2020-02-05 19:01:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:01:02 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:01:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:01:02 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:01:02 --> Final output sent to browser
INFO - 2020-02-05 19:01:02 --> Config Class Initialized
INFO - 2020-02-05 19:01:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:02 --> Total execution time: 1.1624
INFO - 2020-02-05 19:01:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:01:02 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:02 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:02 --> Controller Class Initialized
INFO - 2020-02-05 19:01:03 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:01:03 --> URI Class Initialized
INFO - 2020-02-05 19:01:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:01:03 --> Router Class Initialized
INFO - 2020-02-05 19:01:03 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:01:03 --> Output Class Initialized
INFO - 2020-02-05 19:01:03 --> Security Class Initialized
INFO - 2020-02-05 19:01:03 --> Helper loaded: form_helper
INFO - 2020-02-05 19:01:03 --> Form Validation Class Initialized
DEBUG - 2020-02-05 19:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:03 --> Input Class Initialized
ERROR - 2020-02-05 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:01:03 --> Language Class Initialized
ERROR - 2020-02-05 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:01:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:01:03 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:01:03 --> Final output sent to browser
INFO - 2020-02-05 19:01:03 --> Config Class Initialized
DEBUG - 2020-02-05 19:01:03 --> Total execution time: 1.6063
INFO - 2020-02-05 19:01:03 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:03 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:03 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:03 --> URI Class Initialized
INFO - 2020-02-05 19:01:03 --> Router Class Initialized
INFO - 2020-02-05 19:01:03 --> Output Class Initialized
INFO - 2020-02-05 19:01:03 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:03 --> Input Class Initialized
INFO - 2020-02-05 19:01:03 --> Language Class Initialized
ERROR - 2020-02-05 19:01:03 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:01:03 --> Config Class Initialized
INFO - 2020-02-05 19:01:03 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:03 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:03 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:03 --> URI Class Initialized
INFO - 2020-02-05 19:01:03 --> Router Class Initialized
INFO - 2020-02-05 19:01:03 --> Output Class Initialized
INFO - 2020-02-05 19:01:03 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:04 --> Input Class Initialized
INFO - 2020-02-05 19:01:04 --> Language Class Initialized
ERROR - 2020-02-05 19:01:04 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:01:04 --> Config Class Initialized
INFO - 2020-02-05 19:01:04 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:04 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:04 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:04 --> URI Class Initialized
INFO - 2020-02-05 19:01:04 --> Router Class Initialized
INFO - 2020-02-05 19:01:04 --> Output Class Initialized
INFO - 2020-02-05 19:01:04 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:04 --> Input Class Initialized
INFO - 2020-02-05 19:01:04 --> Language Class Initialized
ERROR - 2020-02-05 19:01:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:01:04 --> Config Class Initialized
INFO - 2020-02-05 19:01:04 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:04 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:04 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:04 --> URI Class Initialized
INFO - 2020-02-05 19:01:04 --> Router Class Initialized
INFO - 2020-02-05 19:01:04 --> Output Class Initialized
INFO - 2020-02-05 19:01:04 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:04 --> Input Class Initialized
INFO - 2020-02-05 19:01:04 --> Language Class Initialized
ERROR - 2020-02-05 19:01:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:01:05 --> Config Class Initialized
INFO - 2020-02-05 19:01:05 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:05 --> URI Class Initialized
INFO - 2020-02-05 19:01:05 --> Router Class Initialized
INFO - 2020-02-05 19:01:05 --> Output Class Initialized
INFO - 2020-02-05 19:01:05 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:05 --> Input Class Initialized
INFO - 2020-02-05 19:01:05 --> Language Class Initialized
ERROR - 2020-02-05 19:01:05 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:01:05 --> Config Class Initialized
INFO - 2020-02-05 19:01:05 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:05 --> URI Class Initialized
INFO - 2020-02-05 19:01:05 --> Router Class Initialized
INFO - 2020-02-05 19:01:05 --> Output Class Initialized
INFO - 2020-02-05 19:01:05 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:06 --> Input Class Initialized
INFO - 2020-02-05 19:01:06 --> Language Class Initialized
ERROR - 2020-02-05 19:01:06 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:01:06 --> Config Class Initialized
INFO - 2020-02-05 19:01:06 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:06 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:06 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:06 --> URI Class Initialized
INFO - 2020-02-05 19:01:06 --> Router Class Initialized
INFO - 2020-02-05 19:01:06 --> Output Class Initialized
INFO - 2020-02-05 19:01:06 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:06 --> Input Class Initialized
INFO - 2020-02-05 19:01:06 --> Language Class Initialized
ERROR - 2020-02-05 19:01:06 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:01:06 --> Config Class Initialized
INFO - 2020-02-05 19:01:06 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:01:06 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:01:06 --> Utf8 Class Initialized
INFO - 2020-02-05 19:01:06 --> URI Class Initialized
INFO - 2020-02-05 19:01:06 --> Router Class Initialized
INFO - 2020-02-05 19:01:07 --> Output Class Initialized
INFO - 2020-02-05 19:01:07 --> Security Class Initialized
DEBUG - 2020-02-05 19:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:01:07 --> Input Class Initialized
INFO - 2020-02-05 19:01:07 --> Language Class Initialized
ERROR - 2020-02-05 19:01:07 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:02:03 --> Config Class Initialized
INFO - 2020-02-05 19:02:03 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:03 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:03 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:03 --> URI Class Initialized
INFO - 2020-02-05 19:02:03 --> Router Class Initialized
INFO - 2020-02-05 19:02:04 --> Output Class Initialized
INFO - 2020-02-05 19:02:04 --> Security Class Initialized
DEBUG - 2020-02-05 19:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:04 --> Input Class Initialized
INFO - 2020-02-05 19:02:04 --> Language Class Initialized
INFO - 2020-02-05 19:02:04 --> Loader Class Initialized
INFO - 2020-02-05 19:02:04 --> Helper loaded: url_helper
INFO - 2020-02-05 19:02:04 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:02:04 --> Controller Class Initialized
INFO - 2020-02-05 19:02:04 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:02:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:02:04 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:02:04 --> Helper loaded: form_helper
INFO - 2020-02-05 19:02:04 --> Form Validation Class Initialized
INFO - 2020-02-05 19:02:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:02:04 --> Final output sent to browser
INFO - 2020-02-05 19:02:04 --> Config Class Initialized
INFO - 2020-02-05 19:02:04 --> Config Class Initialized
INFO - 2020-02-05 19:02:04 --> Hooks Class Initialized
INFO - 2020-02-05 19:02:04 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:04 --> Total execution time: 1.3917
INFO - 2020-02-05 19:02:04 --> Config Class Initialized
INFO - 2020-02-05 19:02:04 --> Config Class Initialized
INFO - 2020-02-05 19:02:04 --> Config Class Initialized
INFO - 2020-02-05 19:02:04 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:02:04 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:04 --> Hooks Class Initialized
INFO - 2020-02-05 19:02:04 --> Hooks Class Initialized
INFO - 2020-02-05 19:02:04 --> Config Class Initialized
INFO - 2020-02-05 19:02:05 --> Hooks Class Initialized
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:02:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:02:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:02:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:05 --> URI Class Initialized
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:05 --> URI Class Initialized
DEBUG - 2020-02-05 19:02:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:05 --> URI Class Initialized
INFO - 2020-02-05 19:02:05 --> Router Class Initialized
INFO - 2020-02-05 19:02:05 --> URI Class Initialized
INFO - 2020-02-05 19:02:05 --> Router Class Initialized
INFO - 2020-02-05 19:02:05 --> Router Class Initialized
INFO - 2020-02-05 19:02:05 --> URI Class Initialized
INFO - 2020-02-05 19:02:05 --> URI Class Initialized
INFO - 2020-02-05 19:02:05 --> Output Class Initialized
INFO - 2020-02-05 19:02:05 --> Security Class Initialized
INFO - 2020-02-05 19:02:05 --> Output Class Initialized
INFO - 2020-02-05 19:02:05 --> Router Class Initialized
INFO - 2020-02-05 19:02:05 --> Output Class Initialized
INFO - 2020-02-05 19:02:05 --> Router Class Initialized
INFO - 2020-02-05 19:02:05 --> Router Class Initialized
INFO - 2020-02-05 19:02:05 --> Security Class Initialized
INFO - 2020-02-05 19:02:05 --> Output Class Initialized
INFO - 2020-02-05 19:02:05 --> Output Class Initialized
DEBUG - 2020-02-05 19:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:05 --> Security Class Initialized
INFO - 2020-02-05 19:02:05 --> Output Class Initialized
INFO - 2020-02-05 19:02:05 --> Input Class Initialized
DEBUG - 2020-02-05 19:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:05 --> Security Class Initialized
INFO - 2020-02-05 19:02:05 --> Security Class Initialized
INFO - 2020-02-05 19:02:05 --> Security Class Initialized
INFO - 2020-02-05 19:02:05 --> Input Class Initialized
INFO - 2020-02-05 19:02:05 --> Input Class Initialized
INFO - 2020-02-05 19:02:05 --> Language Class Initialized
DEBUG - 2020-02-05 19:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:05 --> Input Class Initialized
INFO - 2020-02-05 19:02:05 --> Input Class Initialized
INFO - 2020-02-05 19:02:05 --> Language Class Initialized
INFO - 2020-02-05 19:02:05 --> Language Class Initialized
INFO - 2020-02-05 19:02:05 --> Input Class Initialized
ERROR - 2020-02-05 19:02:05 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:02:05 --> Language Class Initialized
INFO - 2020-02-05 19:02:05 --> Language Class Initialized
INFO - 2020-02-05 19:02:05 --> Language Class Initialized
ERROR - 2020-02-05 19:02:05 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 19:02:05 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:02:05 --> Config Class Initialized
INFO - 2020-02-05 19:02:05 --> Hooks Class Initialized
ERROR - 2020-02-05 19:02:05 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-05 19:02:05 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:02:05 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:02:05 --> Config Class Initialized
INFO - 2020-02-05 19:02:05 --> Config Class Initialized
INFO - 2020-02-05 19:02:05 --> Hooks Class Initialized
INFO - 2020-02-05 19:02:05 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:05 --> Config Class Initialized
INFO - 2020-02-05 19:02:05 --> Config Class Initialized
INFO - 2020-02-05 19:02:05 --> Config Class Initialized
INFO - 2020-02-05 19:02:05 --> Hooks Class Initialized
INFO - 2020-02-05 19:02:05 --> Hooks Class Initialized
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:05 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:02:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:05 --> URI Class Initialized
DEBUG - 2020-02-05 19:02:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:02:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:02:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:05 --> URI Class Initialized
INFO - 2020-02-05 19:02:05 --> URI Class Initialized
INFO - 2020-02-05 19:02:05 --> Router Class Initialized
INFO - 2020-02-05 19:02:05 --> URI Class Initialized
INFO - 2020-02-05 19:02:05 --> Router Class Initialized
INFO - 2020-02-05 19:02:05 --> URI Class Initialized
INFO - 2020-02-05 19:02:05 --> URI Class Initialized
INFO - 2020-02-05 19:02:05 --> Router Class Initialized
INFO - 2020-02-05 19:02:05 --> Output Class Initialized
INFO - 2020-02-05 19:02:05 --> Router Class Initialized
INFO - 2020-02-05 19:02:05 --> Security Class Initialized
INFO - 2020-02-05 19:02:05 --> Router Class Initialized
INFO - 2020-02-05 19:02:05 --> Output Class Initialized
INFO - 2020-02-05 19:02:05 --> Router Class Initialized
INFO - 2020-02-05 19:02:05 --> Output Class Initialized
DEBUG - 2020-02-05 19:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:05 --> Output Class Initialized
INFO - 2020-02-05 19:02:05 --> Security Class Initialized
INFO - 2020-02-05 19:02:05 --> Output Class Initialized
INFO - 2020-02-05 19:02:05 --> Output Class Initialized
INFO - 2020-02-05 19:02:05 --> Security Class Initialized
INFO - 2020-02-05 19:02:05 --> Input Class Initialized
DEBUG - 2020-02-05 19:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:05 --> Security Class Initialized
INFO - 2020-02-05 19:02:05 --> Security Class Initialized
INFO - 2020-02-05 19:02:05 --> Security Class Initialized
DEBUG - 2020-02-05 19:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:05 --> Input Class Initialized
INFO - 2020-02-05 19:02:05 --> Input Class Initialized
DEBUG - 2020-02-05 19:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:05 --> Language Class Initialized
DEBUG - 2020-02-05 19:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:05 --> Input Class Initialized
INFO - 2020-02-05 19:02:05 --> Input Class Initialized
INFO - 2020-02-05 19:02:05 --> Language Class Initialized
INFO - 2020-02-05 19:02:05 --> Input Class Initialized
ERROR - 2020-02-05 19:02:05 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:02:05 --> Language Class Initialized
INFO - 2020-02-05 19:02:05 --> Language Class Initialized
INFO - 2020-02-05 19:02:05 --> Language Class Initialized
ERROR - 2020-02-05 19:02:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:02:05 --> Language Class Initialized
ERROR - 2020-02-05 19:02:05 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:02:05 --> Config Class Initialized
INFO - 2020-02-05 19:02:05 --> Hooks Class Initialized
ERROR - 2020-02-05 19:02:05 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 19:02:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:02:05 --> Loader Class Initialized
INFO - 2020-02-05 19:02:05 --> Config Class Initialized
INFO - 2020-02-05 19:02:05 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:05 --> Helper loaded: url_helper
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:02:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:05 --> Database Driver Class Initialized
INFO - 2020-02-05 19:02:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:05 --> URI Class Initialized
DEBUG - 2020-02-05 19:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:02:06 --> URI Class Initialized
INFO - 2020-02-05 19:02:06 --> Router Class Initialized
INFO - 2020-02-05 19:02:06 --> Controller Class Initialized
INFO - 2020-02-05 19:02:06 --> Router Class Initialized
INFO - 2020-02-05 19:02:06 --> Output Class Initialized
INFO - 2020-02-05 19:02:06 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:02:06 --> Security Class Initialized
INFO - 2020-02-05 19:02:06 --> Output Class Initialized
INFO - 2020-02-05 19:02:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:02:06 --> Security Class Initialized
DEBUG - 2020-02-05 19:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:06 --> Input Class Initialized
INFO - 2020-02-05 19:02:06 --> Model "M_pesan" initialized
DEBUG - 2020-02-05 19:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:06 --> Input Class Initialized
INFO - 2020-02-05 19:02:06 --> Language Class Initialized
INFO - 2020-02-05 19:02:06 --> Helper loaded: form_helper
INFO - 2020-02-05 19:02:06 --> Form Validation Class Initialized
INFO - 2020-02-05 19:02:06 --> Language Class Initialized
INFO - 2020-02-05 19:02:06 --> Loader Class Initialized
ERROR - 2020-02-05 19:02:06 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:02:06 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:02:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:02:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:02:06 --> Database Driver Class Initialized
INFO - 2020-02-05 19:02:06 --> Config Class Initialized
INFO - 2020-02-05 19:02:06 --> Hooks Class Initialized
INFO - 2020-02-05 19:02:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-05 19:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:02:06 --> Final output sent to browser
DEBUG - 2020-02-05 19:02:06 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:06 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:02:06 --> Total execution time: 0.9381
INFO - 2020-02-05 19:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:02:06 --> URI Class Initialized
INFO - 2020-02-05 19:02:06 --> Controller Class Initialized
INFO - 2020-02-05 19:02:06 --> Router Class Initialized
INFO - 2020-02-05 19:02:06 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:02:06 --> Output Class Initialized
INFO - 2020-02-05 19:02:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:02:06 --> Security Class Initialized
INFO - 2020-02-05 19:02:06 --> Model "M_pesan" initialized
DEBUG - 2020-02-05 19:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:06 --> Input Class Initialized
INFO - 2020-02-05 19:02:06 --> Helper loaded: form_helper
INFO - 2020-02-05 19:02:06 --> Form Validation Class Initialized
INFO - 2020-02-05 19:02:06 --> Language Class Initialized
ERROR - 2020-02-05 19:02:06 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 19:02:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:02:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:02:06 --> Config Class Initialized
INFO - 2020-02-05 19:02:06 --> Hooks Class Initialized
INFO - 2020-02-05 19:02:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:02:06 --> Final output sent to browser
DEBUG - 2020-02-05 19:02:06 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:06 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:02:06 --> Total execution time: 0.9969
INFO - 2020-02-05 19:02:06 --> URI Class Initialized
INFO - 2020-02-05 19:02:06 --> Router Class Initialized
INFO - 2020-02-05 19:02:06 --> Output Class Initialized
INFO - 2020-02-05 19:02:07 --> Security Class Initialized
DEBUG - 2020-02-05 19:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:07 --> Input Class Initialized
INFO - 2020-02-05 19:02:07 --> Language Class Initialized
ERROR - 2020-02-05 19:02:07 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:02:07 --> Config Class Initialized
INFO - 2020-02-05 19:02:07 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:07 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:07 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:07 --> URI Class Initialized
INFO - 2020-02-05 19:02:07 --> Router Class Initialized
INFO - 2020-02-05 19:02:07 --> Output Class Initialized
INFO - 2020-02-05 19:02:07 --> Security Class Initialized
DEBUG - 2020-02-05 19:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:07 --> Input Class Initialized
INFO - 2020-02-05 19:02:07 --> Language Class Initialized
ERROR - 2020-02-05 19:02:07 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:02:07 --> Config Class Initialized
INFO - 2020-02-05 19:02:07 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:07 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:07 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:07 --> URI Class Initialized
INFO - 2020-02-05 19:02:07 --> Router Class Initialized
INFO - 2020-02-05 19:02:07 --> Output Class Initialized
INFO - 2020-02-05 19:02:07 --> Security Class Initialized
DEBUG - 2020-02-05 19:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:07 --> Input Class Initialized
INFO - 2020-02-05 19:02:08 --> Language Class Initialized
ERROR - 2020-02-05 19:02:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:02:08 --> Config Class Initialized
INFO - 2020-02-05 19:02:08 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:08 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:08 --> URI Class Initialized
INFO - 2020-02-05 19:02:08 --> Router Class Initialized
INFO - 2020-02-05 19:02:08 --> Output Class Initialized
INFO - 2020-02-05 19:02:08 --> Security Class Initialized
DEBUG - 2020-02-05 19:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:08 --> Input Class Initialized
INFO - 2020-02-05 19:02:08 --> Language Class Initialized
ERROR - 2020-02-05 19:02:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:02:08 --> Config Class Initialized
INFO - 2020-02-05 19:02:08 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:08 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:08 --> URI Class Initialized
INFO - 2020-02-05 19:02:08 --> Router Class Initialized
INFO - 2020-02-05 19:02:08 --> Output Class Initialized
INFO - 2020-02-05 19:02:08 --> Security Class Initialized
DEBUG - 2020-02-05 19:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:09 --> Input Class Initialized
INFO - 2020-02-05 19:02:09 --> Language Class Initialized
ERROR - 2020-02-05 19:02:09 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:02:09 --> Config Class Initialized
INFO - 2020-02-05 19:02:09 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:09 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:09 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:09 --> URI Class Initialized
INFO - 2020-02-05 19:02:09 --> Router Class Initialized
INFO - 2020-02-05 19:02:09 --> Output Class Initialized
INFO - 2020-02-05 19:02:09 --> Security Class Initialized
DEBUG - 2020-02-05 19:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:09 --> Input Class Initialized
INFO - 2020-02-05 19:02:09 --> Language Class Initialized
ERROR - 2020-02-05 19:02:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:02:09 --> Config Class Initialized
INFO - 2020-02-05 19:02:09 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:09 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:09 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:09 --> URI Class Initialized
INFO - 2020-02-05 19:02:09 --> Router Class Initialized
INFO - 2020-02-05 19:02:09 --> Output Class Initialized
INFO - 2020-02-05 19:02:09 --> Security Class Initialized
DEBUG - 2020-02-05 19:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:09 --> Input Class Initialized
INFO - 2020-02-05 19:02:09 --> Language Class Initialized
ERROR - 2020-02-05 19:02:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:02:09 --> Config Class Initialized
INFO - 2020-02-05 19:02:10 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:10 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:10 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:10 --> URI Class Initialized
INFO - 2020-02-05 19:02:10 --> Router Class Initialized
INFO - 2020-02-05 19:02:10 --> Output Class Initialized
INFO - 2020-02-05 19:02:10 --> Security Class Initialized
DEBUG - 2020-02-05 19:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:10 --> Input Class Initialized
INFO - 2020-02-05 19:02:10 --> Language Class Initialized
ERROR - 2020-02-05 19:02:10 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:02:27 --> Config Class Initialized
INFO - 2020-02-05 19:02:27 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:02:27 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:02:27 --> Utf8 Class Initialized
INFO - 2020-02-05 19:02:27 --> URI Class Initialized
INFO - 2020-02-05 19:02:27 --> Router Class Initialized
INFO - 2020-02-05 19:02:27 --> Output Class Initialized
INFO - 2020-02-05 19:02:27 --> Security Class Initialized
DEBUG - 2020-02-05 19:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:02:27 --> Input Class Initialized
INFO - 2020-02-05 19:02:27 --> Language Class Initialized
INFO - 2020-02-05 19:02:27 --> Loader Class Initialized
INFO - 2020-02-05 19:02:27 --> Helper loaded: url_helper
INFO - 2020-02-05 19:02:27 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:02:27 --> Controller Class Initialized
INFO - 2020-02-05 19:02:27 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:02:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:02:27 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:02:27 --> Helper loaded: form_helper
INFO - 2020-02-05 19:02:27 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:02:28 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 41
INFO - 2020-02-05 19:02:28 --> Final output sent to browser
DEBUG - 2020-02-05 19:02:28 --> Total execution time: 1.0629
INFO - 2020-02-05 19:04:09 --> Config Class Initialized
INFO - 2020-02-05 19:04:09 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:10 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:10 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:10 --> URI Class Initialized
INFO - 2020-02-05 19:04:10 --> Router Class Initialized
INFO - 2020-02-05 19:04:10 --> Output Class Initialized
INFO - 2020-02-05 19:04:10 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:10 --> Input Class Initialized
INFO - 2020-02-05 19:04:10 --> Language Class Initialized
INFO - 2020-02-05 19:04:10 --> Loader Class Initialized
INFO - 2020-02-05 19:04:10 --> Helper loaded: url_helper
INFO - 2020-02-05 19:04:10 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:04:10 --> Controller Class Initialized
INFO - 2020-02-05 19:04:10 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:04:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:04:10 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:04:10 --> Helper loaded: form_helper
INFO - 2020-02-05 19:04:10 --> Form Validation Class Initialized
INFO - 2020-02-05 19:04:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:04:11 --> Final output sent to browser
INFO - 2020-02-05 19:04:11 --> Config Class Initialized
INFO - 2020-02-05 19:04:11 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:11 --> Total execution time: 1.2041
INFO - 2020-02-05 19:04:11 --> Config Class Initialized
INFO - 2020-02-05 19:04:11 --> Config Class Initialized
INFO - 2020-02-05 19:04:11 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:11 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:11 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:11 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:04:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:11 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:11 --> URI Class Initialized
INFO - 2020-02-05 19:04:11 --> URI Class Initialized
INFO - 2020-02-05 19:04:11 --> URI Class Initialized
INFO - 2020-02-05 19:04:11 --> Router Class Initialized
INFO - 2020-02-05 19:04:11 --> Router Class Initialized
INFO - 2020-02-05 19:04:11 --> Output Class Initialized
INFO - 2020-02-05 19:04:11 --> Router Class Initialized
INFO - 2020-02-05 19:04:11 --> Security Class Initialized
INFO - 2020-02-05 19:04:11 --> Output Class Initialized
INFO - 2020-02-05 19:04:11 --> Output Class Initialized
INFO - 2020-02-05 19:04:11 --> Security Class Initialized
INFO - 2020-02-05 19:04:11 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:11 --> Input Class Initialized
DEBUG - 2020-02-05 19:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:11 --> Input Class Initialized
INFO - 2020-02-05 19:04:11 --> Input Class Initialized
INFO - 2020-02-05 19:04:11 --> Language Class Initialized
INFO - 2020-02-05 19:04:11 --> Language Class Initialized
INFO - 2020-02-05 19:04:11 --> Language Class Initialized
ERROR - 2020-02-05 19:04:11 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:04:11 --> Loader Class Initialized
INFO - 2020-02-05 19:04:11 --> Loader Class Initialized
INFO - 2020-02-05 19:04:11 --> Helper loaded: url_helper
INFO - 2020-02-05 19:04:11 --> Helper loaded: url_helper
INFO - 2020-02-05 19:04:11 --> Database Driver Class Initialized
INFO - 2020-02-05 19:04:11 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:04:11 --> Controller Class Initialized
INFO - 2020-02-05 19:04:11 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:04:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:04:11 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:04:12 --> Helper loaded: form_helper
INFO - 2020-02-05 19:04:12 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:04:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:04:12 --> Final output sent to browser
DEBUG - 2020-02-05 19:04:12 --> Total execution time: 0.9754
INFO - 2020-02-05 19:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:04:12 --> Controller Class Initialized
INFO - 2020-02-05 19:04:12 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:04:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:04:12 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:04:12 --> Helper loaded: form_helper
INFO - 2020-02-05 19:04:12 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:04:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:04:12 --> Final output sent to browser
DEBUG - 2020-02-05 19:04:12 --> Total execution time: 1.4066
INFO - 2020-02-05 19:04:13 --> Config Class Initialized
INFO - 2020-02-05 19:04:13 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:13 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:13 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:13 --> URI Class Initialized
INFO - 2020-02-05 19:04:13 --> Router Class Initialized
INFO - 2020-02-05 19:04:13 --> Output Class Initialized
INFO - 2020-02-05 19:04:13 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:13 --> Input Class Initialized
INFO - 2020-02-05 19:04:13 --> Language Class Initialized
INFO - 2020-02-05 19:04:13 --> Loader Class Initialized
INFO - 2020-02-05 19:04:13 --> Helper loaded: url_helper
INFO - 2020-02-05 19:04:13 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:04:14 --> Controller Class Initialized
INFO - 2020-02-05 19:04:14 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:04:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:04:14 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:04:14 --> Helper loaded: form_helper
INFO - 2020-02-05 19:04:14 --> Form Validation Class Initialized
INFO - 2020-02-05 19:04:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:04:14 --> Final output sent to browser
INFO - 2020-02-05 19:04:14 --> Config Class Initialized
INFO - 2020-02-05 19:04:14 --> Config Class Initialized
INFO - 2020-02-05 19:04:14 --> Config Class Initialized
INFO - 2020-02-05 19:04:14 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:14 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:14 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:14 --> Total execution time: 0.7868
INFO - 2020-02-05 19:04:14 --> Config Class Initialized
INFO - 2020-02-05 19:04:14 --> Config Class Initialized
INFO - 2020-02-05 19:04:14 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:14 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:14 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:14 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:14 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:04:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:14 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:14 --> Config Class Initialized
INFO - 2020-02-05 19:04:14 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:14 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:14 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:14 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:14 --> URI Class Initialized
INFO - 2020-02-05 19:04:14 --> URI Class Initialized
INFO - 2020-02-05 19:04:14 --> Router Class Initialized
INFO - 2020-02-05 19:04:14 --> Router Class Initialized
INFO - 2020-02-05 19:04:14 --> URI Class Initialized
INFO - 2020-02-05 19:04:14 --> URI Class Initialized
INFO - 2020-02-05 19:04:14 --> URI Class Initialized
DEBUG - 2020-02-05 19:04:14 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:14 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:14 --> Router Class Initialized
INFO - 2020-02-05 19:04:14 --> Output Class Initialized
INFO - 2020-02-05 19:04:14 --> Output Class Initialized
INFO - 2020-02-05 19:04:14 --> Router Class Initialized
INFO - 2020-02-05 19:04:14 --> Router Class Initialized
INFO - 2020-02-05 19:04:14 --> Security Class Initialized
INFO - 2020-02-05 19:04:14 --> Output Class Initialized
INFO - 2020-02-05 19:04:14 --> Output Class Initialized
INFO - 2020-02-05 19:04:14 --> Output Class Initialized
INFO - 2020-02-05 19:04:14 --> URI Class Initialized
INFO - 2020-02-05 19:04:14 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:14 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:14 --> Router Class Initialized
INFO - 2020-02-05 19:04:14 --> Security Class Initialized
INFO - 2020-02-05 19:04:14 --> Security Class Initialized
INFO - 2020-02-05 19:04:14 --> Input Class Initialized
INFO - 2020-02-05 19:04:14 --> Input Class Initialized
DEBUG - 2020-02-05 19:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:14 --> Output Class Initialized
INFO - 2020-02-05 19:04:14 --> Input Class Initialized
INFO - 2020-02-05 19:04:14 --> Input Class Initialized
INFO - 2020-02-05 19:04:14 --> Language Class Initialized
INFO - 2020-02-05 19:04:14 --> Input Class Initialized
INFO - 2020-02-05 19:04:14 --> Security Class Initialized
INFO - 2020-02-05 19:04:14 --> Language Class Initialized
INFO - 2020-02-05 19:04:14 --> Language Class Initialized
DEBUG - 2020-02-05 19:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:14 --> Language Class Initialized
INFO - 2020-02-05 19:04:14 --> Language Class Initialized
INFO - 2020-02-05 19:04:14 --> Loader Class Initialized
INFO - 2020-02-05 19:04:14 --> Loader Class Initialized
ERROR - 2020-02-05 19:04:14 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:04:14 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:04:14 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 19:04:14 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:04:14 --> Input Class Initialized
INFO - 2020-02-05 19:04:14 --> Helper loaded: url_helper
INFO - 2020-02-05 19:04:14 --> Language Class Initialized
INFO - 2020-02-05 19:04:14 --> Database Driver Class Initialized
INFO - 2020-02-05 19:04:14 --> Database Driver Class Initialized
INFO - 2020-02-05 19:04:14 --> Config Class Initialized
INFO - 2020-02-05 19:04:14 --> Config Class Initialized
INFO - 2020-02-05 19:04:14 --> Config Class Initialized
INFO - 2020-02-05 19:04:14 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:14 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:14 --> Hooks Class Initialized
ERROR - 2020-02-05 19:04:14 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-05 19:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:04:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:04:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:14 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:15 --> Config Class Initialized
INFO - 2020-02-05 19:04:15 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:15 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:15 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:15 --> Controller Class Initialized
INFO - 2020-02-05 19:04:15 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:15 --> URI Class Initialized
INFO - 2020-02-05 19:04:15 --> URI Class Initialized
INFO - 2020-02-05 19:04:15 --> URI Class Initialized
INFO - 2020-02-05 19:04:15 --> Model "M_tiket" initialized
DEBUG - 2020-02-05 19:04:15 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:15 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:04:15 --> Router Class Initialized
INFO - 2020-02-05 19:04:15 --> Router Class Initialized
INFO - 2020-02-05 19:04:15 --> Router Class Initialized
INFO - 2020-02-05 19:04:15 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:04:15 --> URI Class Initialized
INFO - 2020-02-05 19:04:15 --> Output Class Initialized
INFO - 2020-02-05 19:04:15 --> Output Class Initialized
INFO - 2020-02-05 19:04:15 --> Output Class Initialized
INFO - 2020-02-05 19:04:15 --> Security Class Initialized
INFO - 2020-02-05 19:04:15 --> Security Class Initialized
INFO - 2020-02-05 19:04:15 --> Router Class Initialized
INFO - 2020-02-05 19:04:15 --> Security Class Initialized
INFO - 2020-02-05 19:04:15 --> Helper loaded: form_helper
INFO - 2020-02-05 19:04:15 --> Form Validation Class Initialized
DEBUG - 2020-02-05 19:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:15 --> Output Class Initialized
DEBUG - 2020-02-05 19:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:15 --> Input Class Initialized
INFO - 2020-02-05 19:04:15 --> Input Class Initialized
INFO - 2020-02-05 19:04:15 --> Input Class Initialized
INFO - 2020-02-05 19:04:15 --> Security Class Initialized
ERROR - 2020-02-05 19:04:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:04:15 --> Language Class Initialized
ERROR - 2020-02-05 19:04:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:04:15 --> Language Class Initialized
INFO - 2020-02-05 19:04:15 --> Language Class Initialized
DEBUG - 2020-02-05 19:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:15 --> Input Class Initialized
INFO - 2020-02-05 19:04:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:04:15 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:04:15 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:04:15 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:04:15 --> Final output sent to browser
INFO - 2020-02-05 19:04:15 --> Language Class Initialized
INFO - 2020-02-05 19:04:15 --> Config Class Initialized
INFO - 2020-02-05 19:04:15 --> Config Class Initialized
INFO - 2020-02-05 19:04:15 --> Config Class Initialized
INFO - 2020-02-05 19:04:15 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:15 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:15 --> Total execution time: 0.9196
INFO - 2020-02-05 19:04:15 --> Hooks Class Initialized
ERROR - 2020-02-05 19:04:15 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:04:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:15 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:15 --> Config Class Initialized
INFO - 2020-02-05 19:04:15 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:15 --> Controller Class Initialized
INFO - 2020-02-05 19:04:15 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:15 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:15 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:15 --> URI Class Initialized
INFO - 2020-02-05 19:04:15 --> URI Class Initialized
INFO - 2020-02-05 19:04:15 --> URI Class Initialized
INFO - 2020-02-05 19:04:15 --> Model "M_tiket" initialized
DEBUG - 2020-02-05 19:04:15 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:15 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:04:15 --> Router Class Initialized
INFO - 2020-02-05 19:04:15 --> Router Class Initialized
INFO - 2020-02-05 19:04:15 --> Router Class Initialized
INFO - 2020-02-05 19:04:15 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:04:15 --> Output Class Initialized
INFO - 2020-02-05 19:04:15 --> Output Class Initialized
INFO - 2020-02-05 19:04:15 --> URI Class Initialized
INFO - 2020-02-05 19:04:15 --> Output Class Initialized
INFO - 2020-02-05 19:04:15 --> Security Class Initialized
INFO - 2020-02-05 19:04:15 --> Security Class Initialized
INFO - 2020-02-05 19:04:15 --> Router Class Initialized
INFO - 2020-02-05 19:04:15 --> Security Class Initialized
INFO - 2020-02-05 19:04:15 --> Helper loaded: form_helper
INFO - 2020-02-05 19:04:15 --> Form Validation Class Initialized
DEBUG - 2020-02-05 19:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:15 --> Output Class Initialized
INFO - 2020-02-05 19:04:15 --> Input Class Initialized
INFO - 2020-02-05 19:04:15 --> Input Class Initialized
INFO - 2020-02-05 19:04:15 --> Input Class Initialized
INFO - 2020-02-05 19:04:15 --> Security Class Initialized
ERROR - 2020-02-05 19:04:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:04:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:04:15 --> Language Class Initialized
INFO - 2020-02-05 19:04:15 --> Language Class Initialized
INFO - 2020-02-05 19:04:15 --> Language Class Initialized
DEBUG - 2020-02-05 19:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:15 --> Input Class Initialized
INFO - 2020-02-05 19:04:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:04:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 19:04:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-05 19:04:15 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:04:15 --> Final output sent to browser
INFO - 2020-02-05 19:04:15 --> Language Class Initialized
DEBUG - 2020-02-05 19:04:15 --> Total execution time: 1.3559
ERROR - 2020-02-05 19:04:15 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:04:15 --> Config Class Initialized
INFO - 2020-02-05 19:04:15 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:15 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:15 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:15 --> URI Class Initialized
INFO - 2020-02-05 19:04:16 --> Router Class Initialized
INFO - 2020-02-05 19:04:16 --> Output Class Initialized
INFO - 2020-02-05 19:04:16 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:16 --> Input Class Initialized
INFO - 2020-02-05 19:04:16 --> Language Class Initialized
ERROR - 2020-02-05 19:04:16 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:04:16 --> Config Class Initialized
INFO - 2020-02-05 19:04:16 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:16 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:16 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:16 --> URI Class Initialized
INFO - 2020-02-05 19:04:16 --> Router Class Initialized
INFO - 2020-02-05 19:04:16 --> Output Class Initialized
INFO - 2020-02-05 19:04:16 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:16 --> Input Class Initialized
INFO - 2020-02-05 19:04:16 --> Language Class Initialized
ERROR - 2020-02-05 19:04:16 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:04:16 --> Config Class Initialized
INFO - 2020-02-05 19:04:16 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:16 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:16 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:16 --> URI Class Initialized
INFO - 2020-02-05 19:04:16 --> Router Class Initialized
INFO - 2020-02-05 19:04:16 --> Output Class Initialized
INFO - 2020-02-05 19:04:17 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:17 --> Input Class Initialized
INFO - 2020-02-05 19:04:17 --> Language Class Initialized
ERROR - 2020-02-05 19:04:17 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:04:17 --> Config Class Initialized
INFO - 2020-02-05 19:04:17 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:17 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:17 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:17 --> URI Class Initialized
INFO - 2020-02-05 19:04:17 --> Router Class Initialized
INFO - 2020-02-05 19:04:17 --> Output Class Initialized
INFO - 2020-02-05 19:04:17 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:17 --> Input Class Initialized
INFO - 2020-02-05 19:04:17 --> Language Class Initialized
ERROR - 2020-02-05 19:04:17 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:04:17 --> Config Class Initialized
INFO - 2020-02-05 19:04:17 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:17 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:17 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:17 --> URI Class Initialized
INFO - 2020-02-05 19:04:17 --> Router Class Initialized
INFO - 2020-02-05 19:04:18 --> Output Class Initialized
INFO - 2020-02-05 19:04:18 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:18 --> Input Class Initialized
INFO - 2020-02-05 19:04:18 --> Language Class Initialized
ERROR - 2020-02-05 19:04:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:04:18 --> Config Class Initialized
INFO - 2020-02-05 19:04:18 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:18 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:18 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:18 --> URI Class Initialized
INFO - 2020-02-05 19:04:18 --> Router Class Initialized
INFO - 2020-02-05 19:04:18 --> Output Class Initialized
INFO - 2020-02-05 19:04:18 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:18 --> Input Class Initialized
INFO - 2020-02-05 19:04:18 --> Language Class Initialized
ERROR - 2020-02-05 19:04:18 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:04:18 --> Config Class Initialized
INFO - 2020-02-05 19:04:18 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:18 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:18 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:18 --> URI Class Initialized
INFO - 2020-02-05 19:04:18 --> Router Class Initialized
INFO - 2020-02-05 19:04:18 --> Output Class Initialized
INFO - 2020-02-05 19:04:18 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:18 --> Input Class Initialized
INFO - 2020-02-05 19:04:18 --> Language Class Initialized
ERROR - 2020-02-05 19:04:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:04:19 --> Config Class Initialized
INFO - 2020-02-05 19:04:19 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:19 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:19 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:19 --> URI Class Initialized
INFO - 2020-02-05 19:04:19 --> Router Class Initialized
INFO - 2020-02-05 19:04:19 --> Output Class Initialized
INFO - 2020-02-05 19:04:19 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:19 --> Input Class Initialized
INFO - 2020-02-05 19:04:19 --> Language Class Initialized
ERROR - 2020-02-05 19:04:19 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:04:19 --> Config Class Initialized
INFO - 2020-02-05 19:04:19 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:19 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:19 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:19 --> URI Class Initialized
INFO - 2020-02-05 19:04:19 --> Router Class Initialized
INFO - 2020-02-05 19:04:19 --> Output Class Initialized
INFO - 2020-02-05 19:04:19 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:19 --> Input Class Initialized
INFO - 2020-02-05 19:04:19 --> Language Class Initialized
ERROR - 2020-02-05 19:04:19 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:04:23 --> Config Class Initialized
INFO - 2020-02-05 19:04:23 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:23 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:23 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:23 --> URI Class Initialized
INFO - 2020-02-05 19:04:23 --> Router Class Initialized
INFO - 2020-02-05 19:04:23 --> Output Class Initialized
INFO - 2020-02-05 19:04:23 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:23 --> Input Class Initialized
INFO - 2020-02-05 19:04:23 --> Language Class Initialized
INFO - 2020-02-05 19:04:23 --> Loader Class Initialized
INFO - 2020-02-05 19:04:23 --> Helper loaded: url_helper
INFO - 2020-02-05 19:04:23 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:04:23 --> Controller Class Initialized
INFO - 2020-02-05 19:04:23 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:04:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:04:23 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:04:23 --> Helper loaded: form_helper
INFO - 2020-02-05 19:04:23 --> Form Validation Class Initialized
INFO - 2020-02-05 19:04:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:04:24 --> Final output sent to browser
INFO - 2020-02-05 19:04:24 --> Config Class Initialized
INFO - 2020-02-05 19:04:24 --> Config Class Initialized
INFO - 2020-02-05 19:04:24 --> Config Class Initialized
INFO - 2020-02-05 19:04:24 --> Config Class Initialized
INFO - 2020-02-05 19:04:24 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:24 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:24 --> Config Class Initialized
DEBUG - 2020-02-05 19:04:24 --> Total execution time: 0.9469
INFO - 2020-02-05 19:04:24 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:24 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:24 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:24 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:24 --> Config Class Initialized
INFO - 2020-02-05 19:04:24 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:24 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:04:24 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:24 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:24 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:24 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:24 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:24 --> URI Class Initialized
DEBUG - 2020-02-05 19:04:24 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:24 --> URI Class Initialized
INFO - 2020-02-05 19:04:24 --> URI Class Initialized
INFO - 2020-02-05 19:04:24 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:24 --> URI Class Initialized
INFO - 2020-02-05 19:04:24 --> Router Class Initialized
INFO - 2020-02-05 19:04:24 --> URI Class Initialized
INFO - 2020-02-05 19:04:24 --> Router Class Initialized
INFO - 2020-02-05 19:04:24 --> Router Class Initialized
INFO - 2020-02-05 19:04:24 --> Output Class Initialized
INFO - 2020-02-05 19:04:24 --> URI Class Initialized
INFO - 2020-02-05 19:04:24 --> Router Class Initialized
INFO - 2020-02-05 19:04:24 --> Router Class Initialized
INFO - 2020-02-05 19:04:24 --> Output Class Initialized
INFO - 2020-02-05 19:04:24 --> Output Class Initialized
INFO - 2020-02-05 19:04:24 --> Output Class Initialized
INFO - 2020-02-05 19:04:24 --> Router Class Initialized
INFO - 2020-02-05 19:04:24 --> Security Class Initialized
INFO - 2020-02-05 19:04:24 --> Output Class Initialized
DEBUG - 2020-02-05 19:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:24 --> Security Class Initialized
INFO - 2020-02-05 19:04:24 --> Security Class Initialized
INFO - 2020-02-05 19:04:24 --> Output Class Initialized
INFO - 2020-02-05 19:04:24 --> Security Class Initialized
INFO - 2020-02-05 19:04:24 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:24 --> Input Class Initialized
INFO - 2020-02-05 19:04:24 --> Security Class Initialized
INFO - 2020-02-05 19:04:24 --> Input Class Initialized
INFO - 2020-02-05 19:04:24 --> Input Class Initialized
INFO - 2020-02-05 19:04:24 --> Input Class Initialized
INFO - 2020-02-05 19:04:24 --> Language Class Initialized
DEBUG - 2020-02-05 19:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:24 --> Input Class Initialized
INFO - 2020-02-05 19:04:24 --> Input Class Initialized
INFO - 2020-02-05 19:04:24 --> Language Class Initialized
INFO - 2020-02-05 19:04:24 --> Language Class Initialized
INFO - 2020-02-05 19:04:24 --> Language Class Initialized
ERROR - 2020-02-05 19:04:24 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:04:24 --> Language Class Initialized
INFO - 2020-02-05 19:04:24 --> Language Class Initialized
ERROR - 2020-02-05 19:04:24 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 19:04:24 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:04:24 --> Loader Class Initialized
INFO - 2020-02-05 19:04:24 --> Loader Class Initialized
INFO - 2020-02-05 19:04:24 --> Config Class Initialized
INFO - 2020-02-05 19:04:24 --> Hooks Class Initialized
ERROR - 2020-02-05 19:04:24 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:04:24 --> Helper loaded: url_helper
INFO - 2020-02-05 19:04:24 --> Helper loaded: url_helper
INFO - 2020-02-05 19:04:24 --> Config Class Initialized
INFO - 2020-02-05 19:04:24 --> Config Class Initialized
INFO - 2020-02-05 19:04:24 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:24 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:24 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:24 --> Database Driver Class Initialized
INFO - 2020-02-05 19:04:24 --> Database Driver Class Initialized
INFO - 2020-02-05 19:04:24 --> Config Class Initialized
INFO - 2020-02-05 19:04:24 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:24 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:04:24 --> URI Class Initialized
INFO - 2020-02-05 19:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:04:24 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:24 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:04:24 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:24 --> Controller Class Initialized
INFO - 2020-02-05 19:04:24 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:24 --> URI Class Initialized
INFO - 2020-02-05 19:04:24 --> URI Class Initialized
INFO - 2020-02-05 19:04:24 --> Router Class Initialized
INFO - 2020-02-05 19:04:24 --> URI Class Initialized
INFO - 2020-02-05 19:04:24 --> Output Class Initialized
INFO - 2020-02-05 19:04:24 --> Router Class Initialized
INFO - 2020-02-05 19:04:24 --> Router Class Initialized
INFO - 2020-02-05 19:04:24 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:04:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:04:24 --> Security Class Initialized
INFO - 2020-02-05 19:04:24 --> Output Class Initialized
INFO - 2020-02-05 19:04:24 --> Router Class Initialized
INFO - 2020-02-05 19:04:24 --> Output Class Initialized
INFO - 2020-02-05 19:04:24 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:24 --> Security Class Initialized
INFO - 2020-02-05 19:04:24 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:04:24 --> Output Class Initialized
INFO - 2020-02-05 19:04:24 --> Input Class Initialized
DEBUG - 2020-02-05 19:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:24 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:24 --> Helper loaded: form_helper
INFO - 2020-02-05 19:04:24 --> Input Class Initialized
INFO - 2020-02-05 19:04:24 --> Input Class Initialized
INFO - 2020-02-05 19:04:24 --> Form Validation Class Initialized
INFO - 2020-02-05 19:04:24 --> Language Class Initialized
DEBUG - 2020-02-05 19:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:24 --> Input Class Initialized
ERROR - 2020-02-05 19:04:24 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:04:24 --> Language Class Initialized
INFO - 2020-02-05 19:04:24 --> Language Class Initialized
ERROR - 2020-02-05 19:04:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:04:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:04:25 --> Language Class Initialized
ERROR - 2020-02-05 19:04:25 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:04:25 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:04:25 --> Config Class Initialized
INFO - 2020-02-05 19:04:25 --> Hooks Class Initialized
ERROR - 2020-02-05 19:04:25 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:04:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:04:25 --> Config Class Initialized
INFO - 2020-02-05 19:04:25 --> Config Class Initialized
INFO - 2020-02-05 19:04:25 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:25 --> Hooks Class Initialized
INFO - 2020-02-05 19:04:25 --> Final output sent to browser
DEBUG - 2020-02-05 19:04:25 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:25 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:04:25 --> Total execution time: 1.0151
DEBUG - 2020-02-05 19:04:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:04:25 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:25 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:25 --> URI Class Initialized
INFO - 2020-02-05 19:04:25 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:25 --> Router Class Initialized
INFO - 2020-02-05 19:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:04:25 --> URI Class Initialized
INFO - 2020-02-05 19:04:25 --> Controller Class Initialized
INFO - 2020-02-05 19:04:25 --> URI Class Initialized
INFO - 2020-02-05 19:04:25 --> Router Class Initialized
INFO - 2020-02-05 19:04:25 --> Output Class Initialized
INFO - 2020-02-05 19:04:25 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:04:25 --> Security Class Initialized
INFO - 2020-02-05 19:04:25 --> Router Class Initialized
INFO - 2020-02-05 19:04:25 --> Output Class Initialized
INFO - 2020-02-05 19:04:25 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-05 19:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:25 --> Output Class Initialized
INFO - 2020-02-05 19:04:25 --> Security Class Initialized
INFO - 2020-02-05 19:04:25 --> Input Class Initialized
INFO - 2020-02-05 19:04:25 --> Model "M_pesan" initialized
DEBUG - 2020-02-05 19:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:25 --> Security Class Initialized
INFO - 2020-02-05 19:04:25 --> Input Class Initialized
INFO - 2020-02-05 19:04:25 --> Language Class Initialized
DEBUG - 2020-02-05 19:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:25 --> Helper loaded: form_helper
INFO - 2020-02-05 19:04:25 --> Input Class Initialized
INFO - 2020-02-05 19:04:25 --> Form Validation Class Initialized
INFO - 2020-02-05 19:04:25 --> Language Class Initialized
ERROR - 2020-02-05 19:04:25 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:04:25 --> Language Class Initialized
ERROR - 2020-02-05 19:04:25 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 19:04:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:04:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:04:25 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:04:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:04:25 --> Final output sent to browser
DEBUG - 2020-02-05 19:04:25 --> Total execution time: 1.5226
INFO - 2020-02-05 19:04:42 --> Config Class Initialized
INFO - 2020-02-05 19:04:42 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:04:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:04:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:04:42 --> URI Class Initialized
INFO - 2020-02-05 19:04:42 --> Router Class Initialized
INFO - 2020-02-05 19:04:42 --> Output Class Initialized
INFO - 2020-02-05 19:04:42 --> Security Class Initialized
DEBUG - 2020-02-05 19:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:04:42 --> Input Class Initialized
INFO - 2020-02-05 19:04:43 --> Language Class Initialized
INFO - 2020-02-05 19:04:43 --> Loader Class Initialized
INFO - 2020-02-05 19:04:43 --> Helper loaded: url_helper
INFO - 2020-02-05 19:04:43 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:04:43 --> Controller Class Initialized
INFO - 2020-02-05 19:04:43 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:04:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:04:43 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:04:43 --> Helper loaded: form_helper
INFO - 2020-02-05 19:04:43 --> Form Validation Class Initialized
INFO - 2020-02-05 19:04:43 --> Final output sent to browser
DEBUG - 2020-02-05 19:04:43 --> Total execution time: 0.9440
INFO - 2020-02-05 19:06:38 --> Config Class Initialized
INFO - 2020-02-05 19:06:38 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:38 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:38 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:38 --> URI Class Initialized
INFO - 2020-02-05 19:06:38 --> Router Class Initialized
INFO - 2020-02-05 19:06:38 --> Output Class Initialized
INFO - 2020-02-05 19:06:38 --> Security Class Initialized
DEBUG - 2020-02-05 19:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:38 --> Input Class Initialized
INFO - 2020-02-05 19:06:38 --> Language Class Initialized
INFO - 2020-02-05 19:06:38 --> Loader Class Initialized
INFO - 2020-02-05 19:06:38 --> Helper loaded: url_helper
INFO - 2020-02-05 19:06:38 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:06:39 --> Controller Class Initialized
INFO - 2020-02-05 19:06:39 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:06:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:06:39 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:06:39 --> Helper loaded: form_helper
INFO - 2020-02-05 19:06:39 --> Form Validation Class Initialized
INFO - 2020-02-05 19:06:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:06:39 --> Final output sent to browser
INFO - 2020-02-05 19:06:39 --> Config Class Initialized
INFO - 2020-02-05 19:06:39 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:39 --> Total execution time: 1.2039
INFO - 2020-02-05 19:06:39 --> Config Class Initialized
INFO - 2020-02-05 19:06:39 --> Config Class Initialized
INFO - 2020-02-05 19:06:39 --> Config Class Initialized
INFO - 2020-02-05 19:06:39 --> Config Class Initialized
INFO - 2020-02-05 19:06:39 --> Hooks Class Initialized
INFO - 2020-02-05 19:06:39 --> Hooks Class Initialized
INFO - 2020-02-05 19:06:39 --> Hooks Class Initialized
INFO - 2020-02-05 19:06:39 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:39 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:39 --> Config Class Initialized
INFO - 2020-02-05 19:06:39 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:39 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:39 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:06:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:06:39 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:39 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:06:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:06:39 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:39 --> URI Class Initialized
INFO - 2020-02-05 19:06:39 --> URI Class Initialized
INFO - 2020-02-05 19:06:39 --> Router Class Initialized
INFO - 2020-02-05 19:06:39 --> Router Class Initialized
INFO - 2020-02-05 19:06:39 --> URI Class Initialized
INFO - 2020-02-05 19:06:39 --> URI Class Initialized
INFO - 2020-02-05 19:06:39 --> URI Class Initialized
INFO - 2020-02-05 19:06:39 --> URI Class Initialized
INFO - 2020-02-05 19:06:39 --> Router Class Initialized
INFO - 2020-02-05 19:06:39 --> Output Class Initialized
INFO - 2020-02-05 19:06:39 --> Security Class Initialized
INFO - 2020-02-05 19:06:39 --> Router Class Initialized
INFO - 2020-02-05 19:06:39 --> Output Class Initialized
INFO - 2020-02-05 19:06:39 --> Router Class Initialized
INFO - 2020-02-05 19:06:39 --> Router Class Initialized
INFO - 2020-02-05 19:06:39 --> Output Class Initialized
INFO - 2020-02-05 19:06:39 --> Security Class Initialized
DEBUG - 2020-02-05 19:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:39 --> Output Class Initialized
INFO - 2020-02-05 19:06:39 --> Output Class Initialized
INFO - 2020-02-05 19:06:39 --> Output Class Initialized
INFO - 2020-02-05 19:06:39 --> Security Class Initialized
INFO - 2020-02-05 19:06:39 --> Input Class Initialized
DEBUG - 2020-02-05 19:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:39 --> Security Class Initialized
DEBUG - 2020-02-05 19:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:39 --> Security Class Initialized
INFO - 2020-02-05 19:06:39 --> Security Class Initialized
INFO - 2020-02-05 19:06:39 --> Input Class Initialized
INFO - 2020-02-05 19:06:39 --> Language Class Initialized
DEBUG - 2020-02-05 19:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:39 --> Input Class Initialized
DEBUG - 2020-02-05 19:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:39 --> Input Class Initialized
INFO - 2020-02-05 19:06:39 --> Input Class Initialized
INFO - 2020-02-05 19:06:39 --> Input Class Initialized
INFO - 2020-02-05 19:06:39 --> Language Class Initialized
INFO - 2020-02-05 19:06:39 --> Language Class Initialized
INFO - 2020-02-05 19:06:39 --> Loader Class Initialized
INFO - 2020-02-05 19:06:39 --> Language Class Initialized
INFO - 2020-02-05 19:06:39 --> Helper loaded: url_helper
INFO - 2020-02-05 19:06:39 --> Language Class Initialized
ERROR - 2020-02-05 19:06:39 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:06:39 --> Language Class Initialized
ERROR - 2020-02-05 19:06:39 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-05 19:06:39 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:06:39 --> Loader Class Initialized
ERROR - 2020-02-05 19:06:39 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:06:39 --> Database Driver Class Initialized
INFO - 2020-02-05 19:06:39 --> Helper loaded: url_helper
DEBUG - 2020-02-05 19:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:06:40 --> Database Driver Class Initialized
INFO - 2020-02-05 19:06:40 --> Controller Class Initialized
DEBUG - 2020-02-05 19:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:06:40 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:06:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:06:40 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:06:40 --> Helper loaded: form_helper
INFO - 2020-02-05 19:06:40 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:06:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:06:40 --> Final output sent to browser
DEBUG - 2020-02-05 19:06:40 --> Total execution time: 0.9034
INFO - 2020-02-05 19:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:06:40 --> Controller Class Initialized
INFO - 2020-02-05 19:06:40 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:06:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:06:40 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:06:40 --> Helper loaded: form_helper
INFO - 2020-02-05 19:06:40 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:06:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:06:40 --> Final output sent to browser
DEBUG - 2020-02-05 19:06:40 --> Total execution time: 1.2739
INFO - 2020-02-05 19:06:42 --> Config Class Initialized
INFO - 2020-02-05 19:06:42 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:43 --> URI Class Initialized
INFO - 2020-02-05 19:06:43 --> Router Class Initialized
INFO - 2020-02-05 19:06:43 --> Output Class Initialized
INFO - 2020-02-05 19:06:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:43 --> Input Class Initialized
INFO - 2020-02-05 19:06:43 --> Language Class Initialized
INFO - 2020-02-05 19:06:43 --> Loader Class Initialized
INFO - 2020-02-05 19:06:43 --> Helper loaded: url_helper
INFO - 2020-02-05 19:06:43 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:06:43 --> Controller Class Initialized
INFO - 2020-02-05 19:06:43 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:06:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:06:43 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:06:43 --> Helper loaded: form_helper
INFO - 2020-02-05 19:06:43 --> Form Validation Class Initialized
INFO - 2020-02-05 19:06:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:06:43 --> Final output sent to browser
INFO - 2020-02-05 19:06:43 --> Config Class Initialized
INFO - 2020-02-05 19:06:43 --> Config Class Initialized
INFO - 2020-02-05 19:06:43 --> Config Class Initialized
INFO - 2020-02-05 19:06:43 --> Hooks Class Initialized
INFO - 2020-02-05 19:06:43 --> Hooks Class Initialized
INFO - 2020-02-05 19:06:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:43 --> Total execution time: 0.8014
INFO - 2020-02-05 19:06:43 --> Config Class Initialized
INFO - 2020-02-05 19:06:43 --> Config Class Initialized
INFO - 2020-02-05 19:06:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:06:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:43 --> Config Class Initialized
INFO - 2020-02-05 19:06:43 --> Hooks Class Initialized
INFO - 2020-02-05 19:06:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:43 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:06:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:06:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:43 --> URI Class Initialized
INFO - 2020-02-05 19:06:43 --> URI Class Initialized
INFO - 2020-02-05 19:06:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:43 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:06:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:43 --> URI Class Initialized
INFO - 2020-02-05 19:06:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:43 --> URI Class Initialized
INFO - 2020-02-05 19:06:43 --> Router Class Initialized
INFO - 2020-02-05 19:06:43 --> URI Class Initialized
INFO - 2020-02-05 19:06:43 --> Router Class Initialized
INFO - 2020-02-05 19:06:43 --> Router Class Initialized
INFO - 2020-02-05 19:06:44 --> URI Class Initialized
INFO - 2020-02-05 19:06:44 --> Output Class Initialized
INFO - 2020-02-05 19:06:44 --> Output Class Initialized
INFO - 2020-02-05 19:06:44 --> Router Class Initialized
INFO - 2020-02-05 19:06:44 --> Router Class Initialized
INFO - 2020-02-05 19:06:44 --> Output Class Initialized
INFO - 2020-02-05 19:06:44 --> Security Class Initialized
INFO - 2020-02-05 19:06:44 --> Security Class Initialized
INFO - 2020-02-05 19:06:44 --> Output Class Initialized
INFO - 2020-02-05 19:06:44 --> Output Class Initialized
INFO - 2020-02-05 19:06:44 --> Router Class Initialized
INFO - 2020-02-05 19:06:44 --> Security Class Initialized
DEBUG - 2020-02-05 19:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:44 --> Security Class Initialized
DEBUG - 2020-02-05 19:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:44 --> Security Class Initialized
INFO - 2020-02-05 19:06:44 --> Output Class Initialized
INFO - 2020-02-05 19:06:44 --> Input Class Initialized
INFO - 2020-02-05 19:06:44 --> Input Class Initialized
INFO - 2020-02-05 19:06:44 --> Input Class Initialized
DEBUG - 2020-02-05 19:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:44 --> Security Class Initialized
DEBUG - 2020-02-05 19:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:44 --> Input Class Initialized
INFO - 2020-02-05 19:06:44 --> Input Class Initialized
INFO - 2020-02-05 19:06:44 --> Language Class Initialized
INFO - 2020-02-05 19:06:44 --> Language Class Initialized
DEBUG - 2020-02-05 19:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:44 --> Language Class Initialized
INFO - 2020-02-05 19:06:44 --> Input Class Initialized
INFO - 2020-02-05 19:06:44 --> Language Class Initialized
INFO - 2020-02-05 19:06:44 --> Language Class Initialized
ERROR - 2020-02-05 19:06:44 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:06:44 --> Loader Class Initialized
INFO - 2020-02-05 19:06:44 --> Loader Class Initialized
INFO - 2020-02-05 19:06:44 --> Language Class Initialized
INFO - 2020-02-05 19:06:44 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:06:44 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-05 19:06:44 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:06:44 --> Helper loaded: url_helper
INFO - 2020-02-05 19:06:44 --> Config Class Initialized
INFO - 2020-02-05 19:06:44 --> Hooks Class Initialized
ERROR - 2020-02-05 19:06:44 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:06:44 --> Database Driver Class Initialized
INFO - 2020-02-05 19:06:44 --> Config Class Initialized
INFO - 2020-02-05 19:06:44 --> Database Driver Class Initialized
INFO - 2020-02-05 19:06:44 --> Config Class Initialized
INFO - 2020-02-05 19:06:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:06:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:06:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:44 --> Config Class Initialized
INFO - 2020-02-05 19:06:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:06:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:06:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:06:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:44 --> Controller Class Initialized
INFO - 2020-02-05 19:06:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:44 --> URI Class Initialized
DEBUG - 2020-02-05 19:06:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:44 --> URI Class Initialized
INFO - 2020-02-05 19:06:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:44 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:06:44 --> URI Class Initialized
INFO - 2020-02-05 19:06:44 --> Router Class Initialized
INFO - 2020-02-05 19:06:44 --> Router Class Initialized
INFO - 2020-02-05 19:06:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:06:44 --> URI Class Initialized
INFO - 2020-02-05 19:06:44 --> Output Class Initialized
INFO - 2020-02-05 19:06:44 --> Output Class Initialized
INFO - 2020-02-05 19:06:44 --> Router Class Initialized
INFO - 2020-02-05 19:06:44 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:06:44 --> Security Class Initialized
INFO - 2020-02-05 19:06:44 --> Security Class Initialized
INFO - 2020-02-05 19:06:44 --> Output Class Initialized
INFO - 2020-02-05 19:06:44 --> Router Class Initialized
DEBUG - 2020-02-05 19:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:44 --> Output Class Initialized
INFO - 2020-02-05 19:06:44 --> Security Class Initialized
INFO - 2020-02-05 19:06:44 --> Helper loaded: form_helper
INFO - 2020-02-05 19:06:44 --> Form Validation Class Initialized
INFO - 2020-02-05 19:06:44 --> Input Class Initialized
INFO - 2020-02-05 19:06:44 --> Input Class Initialized
DEBUG - 2020-02-05 19:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:44 --> Security Class Initialized
INFO - 2020-02-05 19:06:44 --> Input Class Initialized
INFO - 2020-02-05 19:06:44 --> Language Class Initialized
DEBUG - 2020-02-05 19:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:44 --> Language Class Initialized
ERROR - 2020-02-05 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:06:44 --> Input Class Initialized
ERROR - 2020-02-05 19:06:44 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-05 19:06:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:06:44 --> Language Class Initialized
INFO - 2020-02-05 19:06:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:06:44 --> Language Class Initialized
ERROR - 2020-02-05 19:06:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:06:44 --> Config Class Initialized
INFO - 2020-02-05 19:06:44 --> Config Class Initialized
INFO - 2020-02-05 19:06:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:06:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:06:44 --> Final output sent to browser
ERROR - 2020-02-05 19:06:44 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:06:44 --> Config Class Initialized
INFO - 2020-02-05 19:06:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:44 --> Total execution time: 1.0255
DEBUG - 2020-02-05 19:06:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:06:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:44 --> Config Class Initialized
INFO - 2020-02-05 19:06:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:06:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:06:44 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:06:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:44 --> Controller Class Initialized
INFO - 2020-02-05 19:06:44 --> URI Class Initialized
INFO - 2020-02-05 19:06:44 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:06:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:44 --> URI Class Initialized
INFO - 2020-02-05 19:06:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:44 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:06:44 --> URI Class Initialized
INFO - 2020-02-05 19:06:44 --> Router Class Initialized
INFO - 2020-02-05 19:06:44 --> Router Class Initialized
INFO - 2020-02-05 19:06:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:06:45 --> URI Class Initialized
INFO - 2020-02-05 19:06:45 --> Output Class Initialized
INFO - 2020-02-05 19:06:45 --> Router Class Initialized
INFO - 2020-02-05 19:06:45 --> Output Class Initialized
INFO - 2020-02-05 19:06:45 --> Security Class Initialized
INFO - 2020-02-05 19:06:45 --> Router Class Initialized
INFO - 2020-02-05 19:06:45 --> Security Class Initialized
INFO - 2020-02-05 19:06:45 --> Output Class Initialized
INFO - 2020-02-05 19:06:45 --> Model "M_pesan" initialized
DEBUG - 2020-02-05 19:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:45 --> Output Class Initialized
INFO - 2020-02-05 19:06:45 --> Helper loaded: form_helper
INFO - 2020-02-05 19:06:45 --> Security Class Initialized
INFO - 2020-02-05 19:06:45 --> Input Class Initialized
INFO - 2020-02-05 19:06:45 --> Form Validation Class Initialized
INFO - 2020-02-05 19:06:45 --> Input Class Initialized
DEBUG - 2020-02-05 19:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:45 --> Security Class Initialized
INFO - 2020-02-05 19:06:45 --> Input Class Initialized
INFO - 2020-02-05 19:06:45 --> Language Class Initialized
DEBUG - 2020-02-05 19:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:45 --> Language Class Initialized
ERROR - 2020-02-05 19:06:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:06:45 --> Input Class Initialized
ERROR - 2020-02-05 19:06:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:06:45 --> Language Class Initialized
ERROR - 2020-02-05 19:06:45 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-05 19:06:45 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:06:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:06:45 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:06:45 --> Language Class Initialized
INFO - 2020-02-05 19:06:45 --> Final output sent to browser
ERROR - 2020-02-05 19:06:45 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-05 19:06:45 --> Total execution time: 1.4692
INFO - 2020-02-05 19:06:45 --> Config Class Initialized
INFO - 2020-02-05 19:06:45 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:45 --> URI Class Initialized
INFO - 2020-02-05 19:06:45 --> Router Class Initialized
INFO - 2020-02-05 19:06:45 --> Output Class Initialized
INFO - 2020-02-05 19:06:45 --> Security Class Initialized
DEBUG - 2020-02-05 19:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:45 --> Input Class Initialized
INFO - 2020-02-05 19:06:45 --> Language Class Initialized
ERROR - 2020-02-05 19:06:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:06:45 --> Config Class Initialized
INFO - 2020-02-05 19:06:45 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:45 --> URI Class Initialized
INFO - 2020-02-05 19:06:45 --> Router Class Initialized
INFO - 2020-02-05 19:06:45 --> Output Class Initialized
INFO - 2020-02-05 19:06:45 --> Security Class Initialized
DEBUG - 2020-02-05 19:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:46 --> Input Class Initialized
INFO - 2020-02-05 19:06:46 --> Language Class Initialized
ERROR - 2020-02-05 19:06:46 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:06:46 --> Config Class Initialized
INFO - 2020-02-05 19:06:46 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:46 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:46 --> URI Class Initialized
INFO - 2020-02-05 19:06:46 --> Router Class Initialized
INFO - 2020-02-05 19:06:46 --> Output Class Initialized
INFO - 2020-02-05 19:06:46 --> Security Class Initialized
DEBUG - 2020-02-05 19:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:46 --> Input Class Initialized
INFO - 2020-02-05 19:06:46 --> Language Class Initialized
ERROR - 2020-02-05 19:06:46 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:06:46 --> Config Class Initialized
INFO - 2020-02-05 19:06:46 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:46 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:46 --> URI Class Initialized
INFO - 2020-02-05 19:06:46 --> Router Class Initialized
INFO - 2020-02-05 19:06:46 --> Output Class Initialized
INFO - 2020-02-05 19:06:46 --> Security Class Initialized
DEBUG - 2020-02-05 19:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:46 --> Input Class Initialized
INFO - 2020-02-05 19:06:47 --> Language Class Initialized
ERROR - 2020-02-05 19:06:47 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:06:47 --> Config Class Initialized
INFO - 2020-02-05 19:06:47 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:47 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:47 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:47 --> URI Class Initialized
INFO - 2020-02-05 19:06:47 --> Router Class Initialized
INFO - 2020-02-05 19:06:47 --> Output Class Initialized
INFO - 2020-02-05 19:06:47 --> Security Class Initialized
DEBUG - 2020-02-05 19:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:47 --> Input Class Initialized
INFO - 2020-02-05 19:06:47 --> Language Class Initialized
ERROR - 2020-02-05 19:06:47 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:06:47 --> Config Class Initialized
INFO - 2020-02-05 19:06:47 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:06:47 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:06:47 --> Utf8 Class Initialized
INFO - 2020-02-05 19:06:47 --> URI Class Initialized
INFO - 2020-02-05 19:06:47 --> Router Class Initialized
INFO - 2020-02-05 19:06:47 --> Output Class Initialized
INFO - 2020-02-05 19:06:47 --> Security Class Initialized
DEBUG - 2020-02-05 19:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:06:47 --> Input Class Initialized
INFO - 2020-02-05 19:06:47 --> Language Class Initialized
ERROR - 2020-02-05 19:06:47 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:07:01 --> Config Class Initialized
INFO - 2020-02-05 19:07:01 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:01 --> URI Class Initialized
INFO - 2020-02-05 19:07:01 --> Router Class Initialized
INFO - 2020-02-05 19:07:01 --> Output Class Initialized
INFO - 2020-02-05 19:07:01 --> Security Class Initialized
DEBUG - 2020-02-05 19:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:01 --> Input Class Initialized
INFO - 2020-02-05 19:07:01 --> Language Class Initialized
INFO - 2020-02-05 19:07:01 --> Loader Class Initialized
INFO - 2020-02-05 19:07:01 --> Helper loaded: url_helper
INFO - 2020-02-05 19:07:01 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:07:01 --> Controller Class Initialized
INFO - 2020-02-05 19:07:01 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:07:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:07:01 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:07:01 --> Helper loaded: form_helper
INFO - 2020-02-05 19:07:01 --> Form Validation Class Initialized
INFO - 2020-02-05 19:07:01 --> Final output sent to browser
DEBUG - 2020-02-05 19:07:02 --> Total execution time: 0.9119
INFO - 2020-02-05 19:07:46 --> Config Class Initialized
INFO - 2020-02-05 19:07:46 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:46 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:46 --> URI Class Initialized
INFO - 2020-02-05 19:07:46 --> Router Class Initialized
INFO - 2020-02-05 19:07:46 --> Output Class Initialized
INFO - 2020-02-05 19:07:46 --> Security Class Initialized
DEBUG - 2020-02-05 19:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:46 --> Input Class Initialized
INFO - 2020-02-05 19:07:47 --> Language Class Initialized
INFO - 2020-02-05 19:07:47 --> Loader Class Initialized
INFO - 2020-02-05 19:07:47 --> Helper loaded: url_helper
INFO - 2020-02-05 19:07:47 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:07:47 --> Controller Class Initialized
INFO - 2020-02-05 19:07:47 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:07:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:07:47 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:07:47 --> Helper loaded: form_helper
INFO - 2020-02-05 19:07:47 --> Form Validation Class Initialized
INFO - 2020-02-05 19:07:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:07:47 --> Final output sent to browser
INFO - 2020-02-05 19:07:47 --> Config Class Initialized
DEBUG - 2020-02-05 19:07:47 --> Total execution time: 1.2001
INFO - 2020-02-05 19:07:47 --> Hooks Class Initialized
INFO - 2020-02-05 19:07:47 --> Config Class Initialized
INFO - 2020-02-05 19:07:47 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:47 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:47 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:07:47 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:47 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:47 --> URI Class Initialized
INFO - 2020-02-05 19:07:47 --> Router Class Initialized
INFO - 2020-02-05 19:07:47 --> URI Class Initialized
INFO - 2020-02-05 19:07:47 --> Output Class Initialized
INFO - 2020-02-05 19:07:47 --> Router Class Initialized
INFO - 2020-02-05 19:07:48 --> Security Class Initialized
INFO - 2020-02-05 19:07:48 --> Output Class Initialized
DEBUG - 2020-02-05 19:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:48 --> Security Class Initialized
INFO - 2020-02-05 19:07:48 --> Input Class Initialized
DEBUG - 2020-02-05 19:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:48 --> Input Class Initialized
INFO - 2020-02-05 19:07:48 --> Language Class Initialized
INFO - 2020-02-05 19:07:48 --> Language Class Initialized
ERROR - 2020-02-05 19:07:48 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-05 19:07:48 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:07:51 --> Config Class Initialized
INFO - 2020-02-05 19:07:51 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:51 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:51 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:51 --> URI Class Initialized
INFO - 2020-02-05 19:07:51 --> Router Class Initialized
INFO - 2020-02-05 19:07:51 --> Output Class Initialized
INFO - 2020-02-05 19:07:51 --> Security Class Initialized
DEBUG - 2020-02-05 19:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:51 --> Input Class Initialized
INFO - 2020-02-05 19:07:51 --> Language Class Initialized
INFO - 2020-02-05 19:07:51 --> Loader Class Initialized
INFO - 2020-02-05 19:07:51 --> Helper loaded: url_helper
INFO - 2020-02-05 19:07:51 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:07:51 --> Controller Class Initialized
INFO - 2020-02-05 19:07:51 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:07:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:07:52 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:07:52 --> Helper loaded: form_helper
INFO - 2020-02-05 19:07:52 --> Form Validation Class Initialized
INFO - 2020-02-05 19:07:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:07:52 --> Final output sent to browser
INFO - 2020-02-05 19:07:52 --> Config Class Initialized
INFO - 2020-02-05 19:07:52 --> Config Class Initialized
INFO - 2020-02-05 19:07:52 --> Config Class Initialized
INFO - 2020-02-05 19:07:52 --> Config Class Initialized
INFO - 2020-02-05 19:07:52 --> Config Class Initialized
INFO - 2020-02-05 19:07:52 --> Hooks Class Initialized
INFO - 2020-02-05 19:07:52 --> Hooks Class Initialized
INFO - 2020-02-05 19:07:52 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:52 --> Total execution time: 1.0664
INFO - 2020-02-05 19:07:52 --> Hooks Class Initialized
INFO - 2020-02-05 19:07:52 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:07:52 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:52 --> Config Class Initialized
INFO - 2020-02-05 19:07:52 --> Hooks Class Initialized
INFO - 2020-02-05 19:07:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:52 --> URI Class Initialized
INFO - 2020-02-05 19:07:52 --> URI Class Initialized
INFO - 2020-02-05 19:07:52 --> URI Class Initialized
DEBUG - 2020-02-05 19:07:52 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:52 --> URI Class Initialized
INFO - 2020-02-05 19:07:52 --> URI Class Initialized
INFO - 2020-02-05 19:07:52 --> Router Class Initialized
INFO - 2020-02-05 19:07:52 --> Router Class Initialized
INFO - 2020-02-05 19:07:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:52 --> Router Class Initialized
INFO - 2020-02-05 19:07:52 --> Router Class Initialized
INFO - 2020-02-05 19:07:52 --> Router Class Initialized
INFO - 2020-02-05 19:07:52 --> Output Class Initialized
INFO - 2020-02-05 19:07:52 --> Output Class Initialized
INFO - 2020-02-05 19:07:52 --> URI Class Initialized
INFO - 2020-02-05 19:07:52 --> Output Class Initialized
INFO - 2020-02-05 19:07:52 --> Output Class Initialized
INFO - 2020-02-05 19:07:52 --> Output Class Initialized
INFO - 2020-02-05 19:07:52 --> Security Class Initialized
INFO - 2020-02-05 19:07:52 --> Security Class Initialized
INFO - 2020-02-05 19:07:52 --> Security Class Initialized
INFO - 2020-02-05 19:07:52 --> Router Class Initialized
INFO - 2020-02-05 19:07:52 --> Security Class Initialized
INFO - 2020-02-05 19:07:52 --> Security Class Initialized
DEBUG - 2020-02-05 19:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:52 --> Output Class Initialized
INFO - 2020-02-05 19:07:52 --> Input Class Initialized
INFO - 2020-02-05 19:07:52 --> Input Class Initialized
INFO - 2020-02-05 19:07:52 --> Input Class Initialized
INFO - 2020-02-05 19:07:52 --> Security Class Initialized
INFO - 2020-02-05 19:07:52 --> Language Class Initialized
INFO - 2020-02-05 19:07:52 --> Input Class Initialized
INFO - 2020-02-05 19:07:52 --> Input Class Initialized
INFO - 2020-02-05 19:07:52 --> Language Class Initialized
INFO - 2020-02-05 19:07:52 --> Language Class Initialized
INFO - 2020-02-05 19:07:52 --> Language Class Initialized
INFO - 2020-02-05 19:07:52 --> Loader Class Initialized
DEBUG - 2020-02-05 19:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:52 --> Language Class Initialized
INFO - 2020-02-05 19:07:52 --> Input Class Initialized
INFO - 2020-02-05 19:07:52 --> Loader Class Initialized
ERROR - 2020-02-05 19:07:52 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-05 19:07:52 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:07:52 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:07:52 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:07:52 --> Language Class Initialized
INFO - 2020-02-05 19:07:52 --> Helper loaded: url_helper
INFO - 2020-02-05 19:07:53 --> Config Class Initialized
INFO - 2020-02-05 19:07:53 --> Database Driver Class Initialized
INFO - 2020-02-05 19:07:53 --> Config Class Initialized
INFO - 2020-02-05 19:07:53 --> Config Class Initialized
INFO - 2020-02-05 19:07:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:07:53 --> Hooks Class Initialized
ERROR - 2020-02-05 19:07:53 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:07:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:07:53 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:07:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:07:53 --> Config Class Initialized
INFO - 2020-02-05 19:07:53 --> Controller Class Initialized
INFO - 2020-02-05 19:07:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:07:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:53 --> URI Class Initialized
INFO - 2020-02-05 19:07:53 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:07:53 --> URI Class Initialized
INFO - 2020-02-05 19:07:53 --> URI Class Initialized
DEBUG - 2020-02-05 19:07:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:53 --> Router Class Initialized
INFO - 2020-02-05 19:07:53 --> Router Class Initialized
INFO - 2020-02-05 19:07:53 --> Router Class Initialized
INFO - 2020-02-05 19:07:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:07:53 --> URI Class Initialized
INFO - 2020-02-05 19:07:53 --> Output Class Initialized
INFO - 2020-02-05 19:07:53 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:07:53 --> Output Class Initialized
INFO - 2020-02-05 19:07:53 --> Output Class Initialized
INFO - 2020-02-05 19:07:53 --> Security Class Initialized
INFO - 2020-02-05 19:07:53 --> Security Class Initialized
INFO - 2020-02-05 19:07:53 --> Security Class Initialized
INFO - 2020-02-05 19:07:53 --> Router Class Initialized
INFO - 2020-02-05 19:07:53 --> Helper loaded: form_helper
DEBUG - 2020-02-05 19:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:53 --> Form Validation Class Initialized
DEBUG - 2020-02-05 19:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:53 --> Output Class Initialized
INFO - 2020-02-05 19:07:53 --> Input Class Initialized
INFO - 2020-02-05 19:07:53 --> Input Class Initialized
INFO - 2020-02-05 19:07:53 --> Input Class Initialized
INFO - 2020-02-05 19:07:53 --> Security Class Initialized
ERROR - 2020-02-05 19:07:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:07:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-05 19:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:53 --> Language Class Initialized
INFO - 2020-02-05 19:07:53 --> Language Class Initialized
INFO - 2020-02-05 19:07:53 --> Language Class Initialized
INFO - 2020-02-05 19:07:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:07:53 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:07:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:07:53 --> Input Class Initialized
ERROR - 2020-02-05 19:07:53 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:07:53 --> Final output sent to browser
INFO - 2020-02-05 19:07:53 --> Language Class Initialized
INFO - 2020-02-05 19:07:53 --> Config Class Initialized
INFO - 2020-02-05 19:07:53 --> Config Class Initialized
INFO - 2020-02-05 19:07:53 --> Config Class Initialized
INFO - 2020-02-05 19:07:53 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:53 --> Total execution time: 1.2323
INFO - 2020-02-05 19:07:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:07:53 --> Hooks Class Initialized
ERROR - 2020-02-05 19:07:53 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:07:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:07:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:53 --> Config Class Initialized
INFO - 2020-02-05 19:07:53 --> Controller Class Initialized
INFO - 2020-02-05 19:07:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:07:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:53 --> URI Class Initialized
INFO - 2020-02-05 19:07:53 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:07:53 --> URI Class Initialized
INFO - 2020-02-05 19:07:53 --> URI Class Initialized
DEBUG - 2020-02-05 19:07:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:53 --> Router Class Initialized
INFO - 2020-02-05 19:07:53 --> Router Class Initialized
INFO - 2020-02-05 19:07:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:07:53 --> Router Class Initialized
INFO - 2020-02-05 19:07:53 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:07:53 --> URI Class Initialized
INFO - 2020-02-05 19:07:53 --> Output Class Initialized
INFO - 2020-02-05 19:07:53 --> Output Class Initialized
INFO - 2020-02-05 19:07:53 --> Output Class Initialized
INFO - 2020-02-05 19:07:53 --> Security Class Initialized
INFO - 2020-02-05 19:07:53 --> Router Class Initialized
INFO - 2020-02-05 19:07:53 --> Security Class Initialized
INFO - 2020-02-05 19:07:53 --> Security Class Initialized
INFO - 2020-02-05 19:07:53 --> Helper loaded: form_helper
DEBUG - 2020-02-05 19:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:54 --> Form Validation Class Initialized
INFO - 2020-02-05 19:07:54 --> Output Class Initialized
DEBUG - 2020-02-05 19:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:54 --> Input Class Initialized
INFO - 2020-02-05 19:07:54 --> Input Class Initialized
INFO - 2020-02-05 19:07:54 --> Input Class Initialized
INFO - 2020-02-05 19:07:54 --> Security Class Initialized
ERROR - 2020-02-05 19:07:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:07:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:07:54 --> Language Class Initialized
DEBUG - 2020-02-05 19:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:54 --> Language Class Initialized
INFO - 2020-02-05 19:07:54 --> Language Class Initialized
INFO - 2020-02-05 19:07:54 --> Input Class Initialized
INFO - 2020-02-05 19:07:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:07:54 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-05 19:07:54 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 19:07:54 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:07:54 --> Language Class Initialized
INFO - 2020-02-05 19:07:54 --> Final output sent to browser
DEBUG - 2020-02-05 19:07:54 --> Total execution time: 1.8593
ERROR - 2020-02-05 19:07:54 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:07:54 --> Config Class Initialized
INFO - 2020-02-05 19:07:54 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:54 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:54 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:54 --> URI Class Initialized
INFO - 2020-02-05 19:07:54 --> Router Class Initialized
INFO - 2020-02-05 19:07:54 --> Output Class Initialized
INFO - 2020-02-05 19:07:54 --> Security Class Initialized
DEBUG - 2020-02-05 19:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:54 --> Input Class Initialized
INFO - 2020-02-05 19:07:54 --> Language Class Initialized
ERROR - 2020-02-05 19:07:54 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:07:54 --> Config Class Initialized
INFO - 2020-02-05 19:07:54 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:54 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:54 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:55 --> URI Class Initialized
INFO - 2020-02-05 19:07:55 --> Router Class Initialized
INFO - 2020-02-05 19:07:55 --> Output Class Initialized
INFO - 2020-02-05 19:07:55 --> Security Class Initialized
DEBUG - 2020-02-05 19:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:55 --> Input Class Initialized
INFO - 2020-02-05 19:07:55 --> Language Class Initialized
ERROR - 2020-02-05 19:07:55 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:07:55 --> Config Class Initialized
INFO - 2020-02-05 19:07:55 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:55 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:55 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:55 --> URI Class Initialized
INFO - 2020-02-05 19:07:55 --> Router Class Initialized
INFO - 2020-02-05 19:07:55 --> Output Class Initialized
INFO - 2020-02-05 19:07:55 --> Security Class Initialized
DEBUG - 2020-02-05 19:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:55 --> Input Class Initialized
INFO - 2020-02-05 19:07:55 --> Language Class Initialized
ERROR - 2020-02-05 19:07:55 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:07:55 --> Config Class Initialized
INFO - 2020-02-05 19:07:55 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:55 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:55 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:55 --> URI Class Initialized
INFO - 2020-02-05 19:07:55 --> Router Class Initialized
INFO - 2020-02-05 19:07:55 --> Output Class Initialized
INFO - 2020-02-05 19:07:56 --> Security Class Initialized
DEBUG - 2020-02-05 19:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:56 --> Input Class Initialized
INFO - 2020-02-05 19:07:56 --> Language Class Initialized
ERROR - 2020-02-05 19:07:56 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:07:56 --> Config Class Initialized
INFO - 2020-02-05 19:07:56 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:56 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:56 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:56 --> URI Class Initialized
INFO - 2020-02-05 19:07:56 --> Router Class Initialized
INFO - 2020-02-05 19:07:56 --> Output Class Initialized
INFO - 2020-02-05 19:07:56 --> Security Class Initialized
DEBUG - 2020-02-05 19:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:56 --> Input Class Initialized
INFO - 2020-02-05 19:07:56 --> Language Class Initialized
ERROR - 2020-02-05 19:07:56 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:07:56 --> Config Class Initialized
INFO - 2020-02-05 19:07:56 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:56 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:56 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:56 --> URI Class Initialized
INFO - 2020-02-05 19:07:56 --> Router Class Initialized
INFO - 2020-02-05 19:07:56 --> Output Class Initialized
INFO - 2020-02-05 19:07:56 --> Security Class Initialized
DEBUG - 2020-02-05 19:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:56 --> Input Class Initialized
INFO - 2020-02-05 19:07:57 --> Language Class Initialized
ERROR - 2020-02-05 19:07:57 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:07:57 --> Config Class Initialized
INFO - 2020-02-05 19:07:57 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:57 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:57 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:57 --> URI Class Initialized
INFO - 2020-02-05 19:07:57 --> Router Class Initialized
INFO - 2020-02-05 19:07:57 --> Output Class Initialized
INFO - 2020-02-05 19:07:57 --> Security Class Initialized
DEBUG - 2020-02-05 19:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:57 --> Input Class Initialized
INFO - 2020-02-05 19:07:57 --> Language Class Initialized
ERROR - 2020-02-05 19:07:57 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:07:57 --> Config Class Initialized
INFO - 2020-02-05 19:07:57 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:07:57 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:07:57 --> Utf8 Class Initialized
INFO - 2020-02-05 19:07:57 --> URI Class Initialized
INFO - 2020-02-05 19:07:57 --> Router Class Initialized
INFO - 2020-02-05 19:07:57 --> Output Class Initialized
INFO - 2020-02-05 19:07:57 --> Security Class Initialized
DEBUG - 2020-02-05 19:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:07:57 --> Input Class Initialized
INFO - 2020-02-05 19:07:57 --> Language Class Initialized
ERROR - 2020-02-05 19:07:57 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:08:58 --> Config Class Initialized
INFO - 2020-02-05 19:08:58 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:08:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:08:58 --> Utf8 Class Initialized
INFO - 2020-02-05 19:08:58 --> URI Class Initialized
INFO - 2020-02-05 19:08:59 --> Router Class Initialized
INFO - 2020-02-05 19:08:59 --> Output Class Initialized
INFO - 2020-02-05 19:08:59 --> Security Class Initialized
DEBUG - 2020-02-05 19:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:08:59 --> Input Class Initialized
INFO - 2020-02-05 19:08:59 --> Language Class Initialized
INFO - 2020-02-05 19:08:59 --> Loader Class Initialized
INFO - 2020-02-05 19:08:59 --> Helper loaded: url_helper
INFO - 2020-02-05 19:08:59 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:08:59 --> Controller Class Initialized
INFO - 2020-02-05 19:08:59 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:08:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:08:59 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:08:59 --> Helper loaded: form_helper
INFO - 2020-02-05 19:08:59 --> Form Validation Class Initialized
INFO - 2020-02-05 19:08:59 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:08:59 --> Final output sent to browser
INFO - 2020-02-05 19:08:59 --> Config Class Initialized
INFO - 2020-02-05 19:08:59 --> Config Class Initialized
INFO - 2020-02-05 19:08:59 --> Config Class Initialized
INFO - 2020-02-05 19:08:59 --> Config Class Initialized
INFO - 2020-02-05 19:09:00 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:00 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:00 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:00 --> Total execution time: 1.0941
INFO - 2020-02-05 19:09:00 --> Config Class Initialized
INFO - 2020-02-05 19:09:00 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:00 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:00 --> Config Class Initialized
DEBUG - 2020-02-05 19:09:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:00 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:00 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:00 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:00 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:00 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:09:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:00 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:00 --> URI Class Initialized
INFO - 2020-02-05 19:09:00 --> URI Class Initialized
INFO - 2020-02-05 19:09:00 --> URI Class Initialized
INFO - 2020-02-05 19:09:00 --> URI Class Initialized
DEBUG - 2020-02-05 19:09:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:00 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:00 --> Router Class Initialized
INFO - 2020-02-05 19:09:00 --> Router Class Initialized
INFO - 2020-02-05 19:09:00 --> Router Class Initialized
INFO - 2020-02-05 19:09:00 --> URI Class Initialized
INFO - 2020-02-05 19:09:00 --> Router Class Initialized
INFO - 2020-02-05 19:09:00 --> URI Class Initialized
INFO - 2020-02-05 19:09:00 --> Router Class Initialized
INFO - 2020-02-05 19:09:00 --> Output Class Initialized
INFO - 2020-02-05 19:09:00 --> Output Class Initialized
INFO - 2020-02-05 19:09:00 --> Output Class Initialized
INFO - 2020-02-05 19:09:00 --> Output Class Initialized
INFO - 2020-02-05 19:09:00 --> Security Class Initialized
INFO - 2020-02-05 19:09:00 --> Security Class Initialized
INFO - 2020-02-05 19:09:00 --> Security Class Initialized
INFO - 2020-02-05 19:09:00 --> Security Class Initialized
INFO - 2020-02-05 19:09:00 --> Router Class Initialized
INFO - 2020-02-05 19:09:00 --> Output Class Initialized
DEBUG - 2020-02-05 19:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:00 --> Security Class Initialized
INFO - 2020-02-05 19:09:00 --> Output Class Initialized
DEBUG - 2020-02-05 19:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:00 --> Input Class Initialized
INFO - 2020-02-05 19:09:00 --> Input Class Initialized
INFO - 2020-02-05 19:09:00 --> Input Class Initialized
INFO - 2020-02-05 19:09:00 --> Input Class Initialized
DEBUG - 2020-02-05 19:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:00 --> Security Class Initialized
INFO - 2020-02-05 19:09:00 --> Input Class Initialized
INFO - 2020-02-05 19:09:00 --> Language Class Initialized
INFO - 2020-02-05 19:09:00 --> Language Class Initialized
INFO - 2020-02-05 19:09:00 --> Language Class Initialized
INFO - 2020-02-05 19:09:00 --> Language Class Initialized
DEBUG - 2020-02-05 19:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:00 --> Input Class Initialized
INFO - 2020-02-05 19:09:00 --> Language Class Initialized
ERROR - 2020-02-05 19:09:00 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 19:09:00 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:09:00 --> Loader Class Initialized
INFO - 2020-02-05 19:09:00 --> Loader Class Initialized
INFO - 2020-02-05 19:09:00 --> Language Class Initialized
INFO - 2020-02-05 19:09:00 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:09:00 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:09:00 --> Helper loaded: url_helper
INFO - 2020-02-05 19:09:00 --> Config Class Initialized
INFO - 2020-02-05 19:09:00 --> Config Class Initialized
INFO - 2020-02-05 19:09:00 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:00 --> Hooks Class Initialized
ERROR - 2020-02-05 19:09:00 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:09:00 --> Database Driver Class Initialized
INFO - 2020-02-05 19:09:00 --> Database Driver Class Initialized
INFO - 2020-02-05 19:09:00 --> Config Class Initialized
INFO - 2020-02-05 19:09:00 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:09:00 --> Config Class Initialized
INFO - 2020-02-05 19:09:00 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:00 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:09:00 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:09:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:00 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:00 --> Controller Class Initialized
INFO - 2020-02-05 19:09:00 --> URI Class Initialized
INFO - 2020-02-05 19:09:00 --> URI Class Initialized
DEBUG - 2020-02-05 19:09:00 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:00 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:00 --> URI Class Initialized
INFO - 2020-02-05 19:09:00 --> Router Class Initialized
INFO - 2020-02-05 19:09:00 --> Router Class Initialized
INFO - 2020-02-05 19:09:00 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:09:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:09:00 --> URI Class Initialized
INFO - 2020-02-05 19:09:00 --> Output Class Initialized
INFO - 2020-02-05 19:09:00 --> Output Class Initialized
INFO - 2020-02-05 19:09:00 --> Router Class Initialized
INFO - 2020-02-05 19:09:00 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:09:00 --> Security Class Initialized
INFO - 2020-02-05 19:09:00 --> Security Class Initialized
INFO - 2020-02-05 19:09:00 --> Output Class Initialized
INFO - 2020-02-05 19:09:00 --> Router Class Initialized
DEBUG - 2020-02-05 19:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:00 --> Output Class Initialized
DEBUG - 2020-02-05 19:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:00 --> Security Class Initialized
INFO - 2020-02-05 19:09:00 --> Helper loaded: form_helper
INFO - 2020-02-05 19:09:00 --> Form Validation Class Initialized
INFO - 2020-02-05 19:09:00 --> Input Class Initialized
INFO - 2020-02-05 19:09:00 --> Input Class Initialized
DEBUG - 2020-02-05 19:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:00 --> Security Class Initialized
INFO - 2020-02-05 19:09:00 --> Input Class Initialized
INFO - 2020-02-05 19:09:00 --> Language Class Initialized
DEBUG - 2020-02-05 19:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:00 --> Language Class Initialized
ERROR - 2020-02-05 19:09:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:09:00 --> Input Class Initialized
INFO - 2020-02-05 19:09:00 --> Language Class Initialized
ERROR - 2020-02-05 19:09:00 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 19:09:00 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:09:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:09:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:09:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:09:00 --> Language Class Initialized
INFO - 2020-02-05 19:09:00 --> Config Class Initialized
INFO - 2020-02-05 19:09:00 --> Config Class Initialized
INFO - 2020-02-05 19:09:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:01 --> Final output sent to browser
INFO - 2020-02-05 19:09:01 --> Hooks Class Initialized
ERROR - 2020-02-05 19:09:01 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:09:01 --> Config Class Initialized
INFO - 2020-02-05 19:09:01 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:01 --> Total execution time: 1.0169
DEBUG - 2020-02-05 19:09:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:01 --> Config Class Initialized
INFO - 2020-02-05 19:09:01 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:09:01 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:09:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:01 --> Controller Class Initialized
INFO - 2020-02-05 19:09:01 --> URI Class Initialized
INFO - 2020-02-05 19:09:01 --> URI Class Initialized
DEBUG - 2020-02-05 19:09:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:01 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:09:01 --> Router Class Initialized
INFO - 2020-02-05 19:09:01 --> URI Class Initialized
INFO - 2020-02-05 19:09:01 --> Router Class Initialized
INFO - 2020-02-05 19:09:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:09:01 --> Router Class Initialized
INFO - 2020-02-05 19:09:01 --> Output Class Initialized
INFO - 2020-02-05 19:09:01 --> URI Class Initialized
INFO - 2020-02-05 19:09:01 --> Output Class Initialized
INFO - 2020-02-05 19:09:01 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:09:01 --> Security Class Initialized
INFO - 2020-02-05 19:09:01 --> Router Class Initialized
INFO - 2020-02-05 19:09:01 --> Output Class Initialized
INFO - 2020-02-05 19:09:01 --> Security Class Initialized
INFO - 2020-02-05 19:09:01 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:01 --> Helper loaded: form_helper
INFO - 2020-02-05 19:09:01 --> Output Class Initialized
INFO - 2020-02-05 19:09:01 --> Input Class Initialized
INFO - 2020-02-05 19:09:01 --> Input Class Initialized
INFO - 2020-02-05 19:09:01 --> Form Validation Class Initialized
DEBUG - 2020-02-05 19:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:01 --> Security Class Initialized
INFO - 2020-02-05 19:09:01 --> Input Class Initialized
INFO - 2020-02-05 19:09:01 --> Language Class Initialized
INFO - 2020-02-05 19:09:01 --> Language Class Initialized
DEBUG - 2020-02-05 19:09:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 19:09:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:09:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:09:01 --> Language Class Initialized
INFO - 2020-02-05 19:09:01 --> Input Class Initialized
ERROR - 2020-02-05 19:09:01 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-05 19:09:01 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:09:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:09:01 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:09:01 --> Language Class Initialized
INFO - 2020-02-05 19:09:01 --> Final output sent to browser
ERROR - 2020-02-05 19:09:01 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-05 19:09:01 --> Total execution time: 1.5041
INFO - 2020-02-05 19:09:01 --> Config Class Initialized
INFO - 2020-02-05 19:09:01 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:01 --> URI Class Initialized
INFO - 2020-02-05 19:09:01 --> Router Class Initialized
INFO - 2020-02-05 19:09:01 --> Output Class Initialized
INFO - 2020-02-05 19:09:01 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:01 --> Input Class Initialized
INFO - 2020-02-05 19:09:01 --> Language Class Initialized
ERROR - 2020-02-05 19:09:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:09:01 --> Config Class Initialized
INFO - 2020-02-05 19:09:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:02 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:02 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:02 --> URI Class Initialized
INFO - 2020-02-05 19:09:02 --> Router Class Initialized
INFO - 2020-02-05 19:09:02 --> Output Class Initialized
INFO - 2020-02-05 19:09:02 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:02 --> Input Class Initialized
INFO - 2020-02-05 19:09:02 --> Language Class Initialized
ERROR - 2020-02-05 19:09:02 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:09:02 --> Config Class Initialized
INFO - 2020-02-05 19:09:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:02 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:02 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:02 --> URI Class Initialized
INFO - 2020-02-05 19:09:02 --> Router Class Initialized
INFO - 2020-02-05 19:09:02 --> Output Class Initialized
INFO - 2020-02-05 19:09:02 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:02 --> Input Class Initialized
INFO - 2020-02-05 19:09:02 --> Language Class Initialized
ERROR - 2020-02-05 19:09:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:09:02 --> Config Class Initialized
INFO - 2020-02-05 19:09:03 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:03 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:03 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:03 --> URI Class Initialized
INFO - 2020-02-05 19:09:03 --> Router Class Initialized
INFO - 2020-02-05 19:09:03 --> Output Class Initialized
INFO - 2020-02-05 19:09:03 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:03 --> Input Class Initialized
INFO - 2020-02-05 19:09:03 --> Language Class Initialized
ERROR - 2020-02-05 19:09:03 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:09:03 --> Config Class Initialized
INFO - 2020-02-05 19:09:03 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:03 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:03 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:03 --> URI Class Initialized
INFO - 2020-02-05 19:09:03 --> Router Class Initialized
INFO - 2020-02-05 19:09:03 --> Output Class Initialized
INFO - 2020-02-05 19:09:03 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:03 --> Input Class Initialized
INFO - 2020-02-05 19:09:03 --> Language Class Initialized
ERROR - 2020-02-05 19:09:03 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:09:09 --> Config Class Initialized
INFO - 2020-02-05 19:09:09 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:09 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:09 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:09 --> URI Class Initialized
INFO - 2020-02-05 19:09:09 --> Router Class Initialized
INFO - 2020-02-05 19:09:09 --> Output Class Initialized
INFO - 2020-02-05 19:09:09 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:09 --> Input Class Initialized
INFO - 2020-02-05 19:09:09 --> Language Class Initialized
INFO - 2020-02-05 19:09:09 --> Loader Class Initialized
INFO - 2020-02-05 19:09:09 --> Helper loaded: url_helper
INFO - 2020-02-05 19:09:09 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:09:10 --> Controller Class Initialized
INFO - 2020-02-05 19:09:10 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:09:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:09:10 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:09:10 --> Helper loaded: form_helper
INFO - 2020-02-05 19:09:10 --> Form Validation Class Initialized
INFO - 2020-02-05 19:09:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:09:10 --> Final output sent to browser
INFO - 2020-02-05 19:09:10 --> Config Class Initialized
INFO - 2020-02-05 19:09:10 --> Config Class Initialized
INFO - 2020-02-05 19:09:10 --> Config Class Initialized
INFO - 2020-02-05 19:09:10 --> Config Class Initialized
INFO - 2020-02-05 19:09:10 --> Config Class Initialized
INFO - 2020-02-05 19:09:10 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:10 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:10 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:10 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:10 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:10 --> Total execution time: 0.8286
DEBUG - 2020-02-05 19:09:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:10 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:10 --> Config Class Initialized
INFO - 2020-02-05 19:09:10 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:10 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:10 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:10 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:10 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:10 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:10 --> URI Class Initialized
INFO - 2020-02-05 19:09:10 --> URI Class Initialized
INFO - 2020-02-05 19:09:10 --> URI Class Initialized
DEBUG - 2020-02-05 19:09:10 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:10 --> URI Class Initialized
INFO - 2020-02-05 19:09:10 --> URI Class Initialized
INFO - 2020-02-05 19:09:10 --> Router Class Initialized
INFO - 2020-02-05 19:09:10 --> Router Class Initialized
INFO - 2020-02-05 19:09:10 --> Router Class Initialized
INFO - 2020-02-05 19:09:10 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:10 --> Router Class Initialized
INFO - 2020-02-05 19:09:10 --> Router Class Initialized
INFO - 2020-02-05 19:09:10 --> URI Class Initialized
INFO - 2020-02-05 19:09:10 --> Output Class Initialized
INFO - 2020-02-05 19:09:10 --> Output Class Initialized
INFO - 2020-02-05 19:09:10 --> Output Class Initialized
INFO - 2020-02-05 19:09:10 --> Output Class Initialized
INFO - 2020-02-05 19:09:10 --> Output Class Initialized
INFO - 2020-02-05 19:09:10 --> Security Class Initialized
INFO - 2020-02-05 19:09:10 --> Security Class Initialized
INFO - 2020-02-05 19:09:10 --> Security Class Initialized
INFO - 2020-02-05 19:09:10 --> Security Class Initialized
INFO - 2020-02-05 19:09:10 --> Security Class Initialized
INFO - 2020-02-05 19:09:10 --> Router Class Initialized
DEBUG - 2020-02-05 19:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:10 --> Output Class Initialized
DEBUG - 2020-02-05 19:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:10 --> Input Class Initialized
INFO - 2020-02-05 19:09:10 --> Input Class Initialized
INFO - 2020-02-05 19:09:10 --> Input Class Initialized
INFO - 2020-02-05 19:09:10 --> Input Class Initialized
INFO - 2020-02-05 19:09:10 --> Input Class Initialized
INFO - 2020-02-05 19:09:10 --> Security Class Initialized
INFO - 2020-02-05 19:09:10 --> Language Class Initialized
INFO - 2020-02-05 19:09:10 --> Language Class Initialized
INFO - 2020-02-05 19:09:10 --> Language Class Initialized
DEBUG - 2020-02-05 19:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:10 --> Language Class Initialized
INFO - 2020-02-05 19:09:10 --> Language Class Initialized
ERROR - 2020-02-05 19:09:10 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:09:10 --> Input Class Initialized
ERROR - 2020-02-05 19:09:10 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:09:10 --> Loader Class Initialized
ERROR - 2020-02-05 19:09:10 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:09:10 --> Loader Class Initialized
INFO - 2020-02-05 19:09:10 --> Language Class Initialized
INFO - 2020-02-05 19:09:10 --> Helper loaded: url_helper
INFO - 2020-02-05 19:09:10 --> Helper loaded: url_helper
INFO - 2020-02-05 19:09:10 --> Config Class Initialized
INFO - 2020-02-05 19:09:10 --> Config Class Initialized
INFO - 2020-02-05 19:09:10 --> Config Class Initialized
INFO - 2020-02-05 19:09:10 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:10 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:10 --> Hooks Class Initialized
ERROR - 2020-02-05 19:09:10 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:09:10 --> Database Driver Class Initialized
INFO - 2020-02-05 19:09:10 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:09:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:09:11 --> Config Class Initialized
INFO - 2020-02-05 19:09:11 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:09:11 --> Controller Class Initialized
INFO - 2020-02-05 19:09:11 --> URI Class Initialized
INFO - 2020-02-05 19:09:11 --> URI Class Initialized
INFO - 2020-02-05 19:09:11 --> URI Class Initialized
DEBUG - 2020-02-05 19:09:11 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:11 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:09:11 --> Router Class Initialized
INFO - 2020-02-05 19:09:11 --> Router Class Initialized
INFO - 2020-02-05 19:09:11 --> Router Class Initialized
INFO - 2020-02-05 19:09:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:09:11 --> URI Class Initialized
INFO - 2020-02-05 19:09:11 --> Output Class Initialized
INFO - 2020-02-05 19:09:11 --> Output Class Initialized
INFO - 2020-02-05 19:09:11 --> Output Class Initialized
INFO - 2020-02-05 19:09:11 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:09:11 --> Security Class Initialized
INFO - 2020-02-05 19:09:11 --> Security Class Initialized
INFO - 2020-02-05 19:09:11 --> Security Class Initialized
INFO - 2020-02-05 19:09:11 --> Router Class Initialized
DEBUG - 2020-02-05 19:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:11 --> Output Class Initialized
DEBUG - 2020-02-05 19:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:11 --> Helper loaded: form_helper
INFO - 2020-02-05 19:09:11 --> Form Validation Class Initialized
INFO - 2020-02-05 19:09:11 --> Input Class Initialized
INFO - 2020-02-05 19:09:11 --> Input Class Initialized
INFO - 2020-02-05 19:09:11 --> Input Class Initialized
INFO - 2020-02-05 19:09:11 --> Security Class Initialized
INFO - 2020-02-05 19:09:11 --> Language Class Initialized
INFO - 2020-02-05 19:09:11 --> Language Class Initialized
INFO - 2020-02-05 19:09:11 --> Language Class Initialized
DEBUG - 2020-02-05 19:09:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 19:09:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:09:11 --> Input Class Initialized
ERROR - 2020-02-05 19:09:11 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:09:11 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:09:11 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 19:09:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:09:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:09:11 --> Language Class Initialized
INFO - 2020-02-05 19:09:11 --> Config Class Initialized
INFO - 2020-02-05 19:09:11 --> Config Class Initialized
INFO - 2020-02-05 19:09:11 --> Config Class Initialized
INFO - 2020-02-05 19:09:11 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:11 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:11 --> Final output sent to browser
INFO - 2020-02-05 19:09:11 --> Hooks Class Initialized
ERROR - 2020-02-05 19:09:11 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-05 19:09:11 --> Total execution time: 1.0877
DEBUG - 2020-02-05 19:09:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:09:11 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:11 --> Config Class Initialized
INFO - 2020-02-05 19:09:11 --> Hooks Class Initialized
INFO - 2020-02-05 19:09:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:09:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:11 --> Controller Class Initialized
INFO - 2020-02-05 19:09:11 --> URI Class Initialized
INFO - 2020-02-05 19:09:11 --> URI Class Initialized
INFO - 2020-02-05 19:09:11 --> URI Class Initialized
DEBUG - 2020-02-05 19:09:11 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:11 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:09:11 --> Router Class Initialized
INFO - 2020-02-05 19:09:11 --> Router Class Initialized
INFO - 2020-02-05 19:09:11 --> Router Class Initialized
INFO - 2020-02-05 19:09:11 --> URI Class Initialized
INFO - 2020-02-05 19:09:11 --> Output Class Initialized
INFO - 2020-02-05 19:09:11 --> Output Class Initialized
INFO - 2020-02-05 19:09:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:09:11 --> Output Class Initialized
INFO - 2020-02-05 19:09:11 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:09:11 --> Security Class Initialized
INFO - 2020-02-05 19:09:11 --> Router Class Initialized
INFO - 2020-02-05 19:09:11 --> Security Class Initialized
INFO - 2020-02-05 19:09:11 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:11 --> Output Class Initialized
INFO - 2020-02-05 19:09:11 --> Helper loaded: form_helper
DEBUG - 2020-02-05 19:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:11 --> Input Class Initialized
INFO - 2020-02-05 19:09:11 --> Input Class Initialized
INFO - 2020-02-05 19:09:11 --> Input Class Initialized
INFO - 2020-02-05 19:09:11 --> Form Validation Class Initialized
INFO - 2020-02-05 19:09:11 --> Security Class Initialized
INFO - 2020-02-05 19:09:11 --> Language Class Initialized
DEBUG - 2020-02-05 19:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:11 --> Language Class Initialized
INFO - 2020-02-05 19:09:11 --> Language Class Initialized
ERROR - 2020-02-05 19:09:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:09:11 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 19:09:11 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:09:11 --> Input Class Initialized
ERROR - 2020-02-05 19:09:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:09:11 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:09:11 --> Language Class Initialized
INFO - 2020-02-05 19:09:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:09:12 --> Final output sent to browser
ERROR - 2020-02-05 19:09:12 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-05 19:09:12 --> Total execution time: 1.6006
INFO - 2020-02-05 19:09:12 --> Config Class Initialized
INFO - 2020-02-05 19:09:12 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:12 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:12 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:12 --> URI Class Initialized
INFO - 2020-02-05 19:09:12 --> Router Class Initialized
INFO - 2020-02-05 19:09:12 --> Output Class Initialized
INFO - 2020-02-05 19:09:12 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:12 --> Input Class Initialized
INFO - 2020-02-05 19:09:12 --> Language Class Initialized
ERROR - 2020-02-05 19:09:12 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:09:12 --> Config Class Initialized
INFO - 2020-02-05 19:09:12 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:12 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:12 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:12 --> URI Class Initialized
INFO - 2020-02-05 19:09:12 --> Router Class Initialized
INFO - 2020-02-05 19:09:12 --> Output Class Initialized
INFO - 2020-02-05 19:09:12 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:12 --> Input Class Initialized
INFO - 2020-02-05 19:09:12 --> Language Class Initialized
ERROR - 2020-02-05 19:09:12 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:09:12 --> Config Class Initialized
INFO - 2020-02-05 19:09:13 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:13 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:13 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:13 --> URI Class Initialized
INFO - 2020-02-05 19:09:13 --> Router Class Initialized
INFO - 2020-02-05 19:09:13 --> Output Class Initialized
INFO - 2020-02-05 19:09:13 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:13 --> Input Class Initialized
INFO - 2020-02-05 19:09:13 --> Language Class Initialized
ERROR - 2020-02-05 19:09:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:09:13 --> Config Class Initialized
INFO - 2020-02-05 19:09:13 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:13 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:13 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:13 --> URI Class Initialized
INFO - 2020-02-05 19:09:13 --> Router Class Initialized
INFO - 2020-02-05 19:09:13 --> Output Class Initialized
INFO - 2020-02-05 19:09:13 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:13 --> Input Class Initialized
INFO - 2020-02-05 19:09:13 --> Language Class Initialized
ERROR - 2020-02-05 19:09:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:09:13 --> Config Class Initialized
INFO - 2020-02-05 19:09:13 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:13 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:14 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:14 --> URI Class Initialized
INFO - 2020-02-05 19:09:14 --> Router Class Initialized
INFO - 2020-02-05 19:09:14 --> Output Class Initialized
INFO - 2020-02-05 19:09:14 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:14 --> Input Class Initialized
INFO - 2020-02-05 19:09:14 --> Language Class Initialized
ERROR - 2020-02-05 19:09:14 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:09:14 --> Config Class Initialized
INFO - 2020-02-05 19:09:14 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:14 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:14 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:14 --> URI Class Initialized
INFO - 2020-02-05 19:09:14 --> Router Class Initialized
INFO - 2020-02-05 19:09:14 --> Output Class Initialized
INFO - 2020-02-05 19:09:14 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:14 --> Input Class Initialized
INFO - 2020-02-05 19:09:14 --> Language Class Initialized
ERROR - 2020-02-05 19:09:14 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:09:14 --> Config Class Initialized
INFO - 2020-02-05 19:09:14 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:14 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:14 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:14 --> URI Class Initialized
INFO - 2020-02-05 19:09:14 --> Router Class Initialized
INFO - 2020-02-05 19:09:15 --> Output Class Initialized
INFO - 2020-02-05 19:09:15 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:15 --> Input Class Initialized
INFO - 2020-02-05 19:09:15 --> Language Class Initialized
ERROR - 2020-02-05 19:09:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:09:15 --> Config Class Initialized
INFO - 2020-02-05 19:09:15 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:09:15 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:09:15 --> Utf8 Class Initialized
INFO - 2020-02-05 19:09:15 --> URI Class Initialized
INFO - 2020-02-05 19:09:15 --> Router Class Initialized
INFO - 2020-02-05 19:09:15 --> Output Class Initialized
INFO - 2020-02-05 19:09:15 --> Security Class Initialized
DEBUG - 2020-02-05 19:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:09:15 --> Input Class Initialized
INFO - 2020-02-05 19:09:15 --> Language Class Initialized
ERROR - 2020-02-05 19:09:15 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:11:37 --> Config Class Initialized
INFO - 2020-02-05 19:11:37 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:11:37 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:11:37 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:38 --> URI Class Initialized
INFO - 2020-02-05 19:11:38 --> Router Class Initialized
INFO - 2020-02-05 19:11:38 --> Output Class Initialized
INFO - 2020-02-05 19:11:38 --> Security Class Initialized
DEBUG - 2020-02-05 19:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:38 --> Input Class Initialized
INFO - 2020-02-05 19:11:38 --> Language Class Initialized
INFO - 2020-02-05 19:11:38 --> Loader Class Initialized
INFO - 2020-02-05 19:11:38 --> Helper loaded: url_helper
INFO - 2020-02-05 19:11:38 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:11:38 --> Controller Class Initialized
INFO - 2020-02-05 19:11:38 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:11:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:11:38 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:11:38 --> Helper loaded: form_helper
INFO - 2020-02-05 19:11:39 --> Form Validation Class Initialized
INFO - 2020-02-05 19:11:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:11:39 --> Final output sent to browser
INFO - 2020-02-05 19:11:39 --> Config Class Initialized
DEBUG - 2020-02-05 19:11:39 --> Total execution time: 1.6516
INFO - 2020-02-05 19:11:39 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:11:39 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:11:39 --> Config Class Initialized
INFO - 2020-02-05 19:11:39 --> Config Class Initialized
INFO - 2020-02-05 19:11:39 --> Config Class Initialized
INFO - 2020-02-05 19:11:39 --> Config Class Initialized
INFO - 2020-02-05 19:11:39 --> Config Class Initialized
INFO - 2020-02-05 19:11:39 --> Hooks Class Initialized
INFO - 2020-02-05 19:11:39 --> Hooks Class Initialized
INFO - 2020-02-05 19:11:39 --> Hooks Class Initialized
INFO - 2020-02-05 19:11:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:39 --> Hooks Class Initialized
INFO - 2020-02-05 19:11:39 --> Hooks Class Initialized
INFO - 2020-02-05 19:11:39 --> URI Class Initialized
DEBUG - 2020-02-05 19:11:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:11:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:11:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:11:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:11:39 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:11:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:39 --> Router Class Initialized
INFO - 2020-02-05 19:11:39 --> URI Class Initialized
INFO - 2020-02-05 19:11:39 --> URI Class Initialized
INFO - 2020-02-05 19:11:39 --> URI Class Initialized
INFO - 2020-02-05 19:11:39 --> Output Class Initialized
INFO - 2020-02-05 19:11:39 --> URI Class Initialized
INFO - 2020-02-05 19:11:39 --> URI Class Initialized
INFO - 2020-02-05 19:11:39 --> Router Class Initialized
INFO - 2020-02-05 19:11:39 --> Router Class Initialized
INFO - 2020-02-05 19:11:39 --> Router Class Initialized
INFO - 2020-02-05 19:11:39 --> Router Class Initialized
INFO - 2020-02-05 19:11:39 --> Router Class Initialized
INFO - 2020-02-05 19:11:39 --> Security Class Initialized
DEBUG - 2020-02-05 19:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:39 --> Output Class Initialized
INFO - 2020-02-05 19:11:39 --> Output Class Initialized
INFO - 2020-02-05 19:11:39 --> Output Class Initialized
INFO - 2020-02-05 19:11:39 --> Output Class Initialized
INFO - 2020-02-05 19:11:39 --> Output Class Initialized
INFO - 2020-02-05 19:11:39 --> Input Class Initialized
INFO - 2020-02-05 19:11:39 --> Security Class Initialized
INFO - 2020-02-05 19:11:39 --> Security Class Initialized
INFO - 2020-02-05 19:11:39 --> Security Class Initialized
INFO - 2020-02-05 19:11:39 --> Security Class Initialized
INFO - 2020-02-05 19:11:39 --> Security Class Initialized
DEBUG - 2020-02-05 19:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:39 --> Language Class Initialized
INFO - 2020-02-05 19:11:39 --> Input Class Initialized
INFO - 2020-02-05 19:11:39 --> Input Class Initialized
INFO - 2020-02-05 19:11:39 --> Input Class Initialized
ERROR - 2020-02-05 19:11:39 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:11:39 --> Input Class Initialized
INFO - 2020-02-05 19:11:39 --> Input Class Initialized
INFO - 2020-02-05 19:11:39 --> Language Class Initialized
INFO - 2020-02-05 19:11:39 --> Language Class Initialized
INFO - 2020-02-05 19:11:39 --> Language Class Initialized
INFO - 2020-02-05 19:11:39 --> Language Class Initialized
INFO - 2020-02-05 19:11:39 --> Language Class Initialized
INFO - 2020-02-05 19:11:39 --> Config Class Initialized
INFO - 2020-02-05 19:11:39 --> Hooks Class Initialized
ERROR - 2020-02-05 19:11:39 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 19:11:39 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-05 19:11:39 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:11:39 --> Loader Class Initialized
INFO - 2020-02-05 19:11:39 --> Loader Class Initialized
INFO - 2020-02-05 19:11:39 --> Helper loaded: url_helper
INFO - 2020-02-05 19:11:39 --> Helper loaded: url_helper
DEBUG - 2020-02-05 19:11:39 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:11:39 --> Config Class Initialized
INFO - 2020-02-05 19:11:39 --> Config Class Initialized
INFO - 2020-02-05 19:11:39 --> Config Class Initialized
INFO - 2020-02-05 19:11:39 --> Hooks Class Initialized
INFO - 2020-02-05 19:11:39 --> Hooks Class Initialized
INFO - 2020-02-05 19:11:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:39 --> Hooks Class Initialized
INFO - 2020-02-05 19:11:39 --> Database Driver Class Initialized
INFO - 2020-02-05 19:11:39 --> Database Driver Class Initialized
INFO - 2020-02-05 19:11:39 --> URI Class Initialized
DEBUG - 2020-02-05 19:11:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:11:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:11:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:11:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:11:39 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:39 --> Router Class Initialized
INFO - 2020-02-05 19:11:40 --> Controller Class Initialized
INFO - 2020-02-05 19:11:40 --> URI Class Initialized
INFO - 2020-02-05 19:11:40 --> URI Class Initialized
INFO - 2020-02-05 19:11:40 --> Output Class Initialized
INFO - 2020-02-05 19:11:40 --> URI Class Initialized
INFO - 2020-02-05 19:11:40 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:11:40 --> Router Class Initialized
INFO - 2020-02-05 19:11:40 --> Router Class Initialized
INFO - 2020-02-05 19:11:40 --> Router Class Initialized
INFO - 2020-02-05 19:11:40 --> Security Class Initialized
INFO - 2020-02-05 19:11:40 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-05 19:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:40 --> Output Class Initialized
INFO - 2020-02-05 19:11:40 --> Output Class Initialized
INFO - 2020-02-05 19:11:40 --> Output Class Initialized
INFO - 2020-02-05 19:11:40 --> Input Class Initialized
INFO - 2020-02-05 19:11:40 --> Security Class Initialized
INFO - 2020-02-05 19:11:40 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:11:40 --> Security Class Initialized
INFO - 2020-02-05 19:11:40 --> Security Class Initialized
INFO - 2020-02-05 19:11:40 --> Language Class Initialized
DEBUG - 2020-02-05 19:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:40 --> Helper loaded: form_helper
INFO - 2020-02-05 19:11:40 --> Input Class Initialized
INFO - 2020-02-05 19:11:40 --> Form Validation Class Initialized
INFO - 2020-02-05 19:11:40 --> Input Class Initialized
INFO - 2020-02-05 19:11:40 --> Input Class Initialized
ERROR - 2020-02-05 19:11:40 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:11:40 --> Language Class Initialized
INFO - 2020-02-05 19:11:40 --> Language Class Initialized
INFO - 2020-02-05 19:11:40 --> Language Class Initialized
ERROR - 2020-02-05 19:11:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:11:40 --> Config Class Initialized
INFO - 2020-02-05 19:11:40 --> Hooks Class Initialized
ERROR - 2020-02-05 19:11:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:11:40 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-05 19:11:40 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:11:40 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:11:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-05 19:11:40 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:11:40 --> Config Class Initialized
INFO - 2020-02-05 19:11:40 --> Config Class Initialized
INFO - 2020-02-05 19:11:40 --> Config Class Initialized
INFO - 2020-02-05 19:11:40 --> Hooks Class Initialized
INFO - 2020-02-05 19:11:40 --> Hooks Class Initialized
INFO - 2020-02-05 19:11:40 --> Hooks Class Initialized
INFO - 2020-02-05 19:11:40 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:40 --> Final output sent to browser
DEBUG - 2020-02-05 19:11:40 --> Total execution time: 1.1700
INFO - 2020-02-05 19:11:40 --> URI Class Initialized
DEBUG - 2020-02-05 19:11:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:11:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:11:40 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:11:40 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:40 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:40 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:40 --> Router Class Initialized
INFO - 2020-02-05 19:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:11:40 --> Controller Class Initialized
INFO - 2020-02-05 19:11:40 --> URI Class Initialized
INFO - 2020-02-05 19:11:40 --> URI Class Initialized
INFO - 2020-02-05 19:11:40 --> Output Class Initialized
INFO - 2020-02-05 19:11:40 --> URI Class Initialized
INFO - 2020-02-05 19:11:40 --> Security Class Initialized
INFO - 2020-02-05 19:11:40 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:11:40 --> Router Class Initialized
INFO - 2020-02-05 19:11:40 --> Router Class Initialized
INFO - 2020-02-05 19:11:40 --> Router Class Initialized
DEBUG - 2020-02-05 19:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:40 --> Output Class Initialized
INFO - 2020-02-05 19:11:40 --> Output Class Initialized
INFO - 2020-02-05 19:11:40 --> Output Class Initialized
INFO - 2020-02-05 19:11:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:11:40 --> Input Class Initialized
INFO - 2020-02-05 19:11:40 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:11:40 --> Security Class Initialized
INFO - 2020-02-05 19:11:40 --> Security Class Initialized
INFO - 2020-02-05 19:11:40 --> Security Class Initialized
INFO - 2020-02-05 19:11:40 --> Language Class Initialized
DEBUG - 2020-02-05 19:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:40 --> Helper loaded: form_helper
INFO - 2020-02-05 19:11:40 --> Form Validation Class Initialized
INFO - 2020-02-05 19:11:40 --> Input Class Initialized
INFO - 2020-02-05 19:11:40 --> Input Class Initialized
INFO - 2020-02-05 19:11:40 --> Input Class Initialized
ERROR - 2020-02-05 19:11:40 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:11:40 --> Language Class Initialized
INFO - 2020-02-05 19:11:40 --> Language Class Initialized
INFO - 2020-02-05 19:11:40 --> Language Class Initialized
ERROR - 2020-02-05 19:11:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:11:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:11:40 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 19:11:40 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-05 19:11:40 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:11:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:11:40 --> Config Class Initialized
INFO - 2020-02-05 19:11:40 --> Hooks Class Initialized
INFO - 2020-02-05 19:11:40 --> Final output sent to browser
DEBUG - 2020-02-05 19:11:40 --> Total execution time: 1.6801
DEBUG - 2020-02-05 19:11:40 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:11:41 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:41 --> URI Class Initialized
INFO - 2020-02-05 19:11:41 --> Router Class Initialized
INFO - 2020-02-05 19:11:41 --> Output Class Initialized
INFO - 2020-02-05 19:11:41 --> Security Class Initialized
DEBUG - 2020-02-05 19:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:41 --> Input Class Initialized
INFO - 2020-02-05 19:11:41 --> Language Class Initialized
ERROR - 2020-02-05 19:11:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:11:41 --> Config Class Initialized
INFO - 2020-02-05 19:11:41 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:11:41 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:11:41 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:41 --> URI Class Initialized
INFO - 2020-02-05 19:11:41 --> Router Class Initialized
INFO - 2020-02-05 19:11:41 --> Output Class Initialized
INFO - 2020-02-05 19:11:41 --> Security Class Initialized
DEBUG - 2020-02-05 19:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:41 --> Input Class Initialized
INFO - 2020-02-05 19:11:41 --> Language Class Initialized
ERROR - 2020-02-05 19:11:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:11:41 --> Config Class Initialized
INFO - 2020-02-05 19:11:41 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:11:41 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:11:41 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:41 --> URI Class Initialized
INFO - 2020-02-05 19:11:41 --> Router Class Initialized
INFO - 2020-02-05 19:11:42 --> Output Class Initialized
INFO - 2020-02-05 19:11:42 --> Security Class Initialized
DEBUG - 2020-02-05 19:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:42 --> Input Class Initialized
INFO - 2020-02-05 19:11:42 --> Language Class Initialized
ERROR - 2020-02-05 19:11:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:11:42 --> Config Class Initialized
INFO - 2020-02-05 19:11:42 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:11:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:11:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:42 --> URI Class Initialized
INFO - 2020-02-05 19:11:42 --> Router Class Initialized
INFO - 2020-02-05 19:11:42 --> Output Class Initialized
INFO - 2020-02-05 19:11:42 --> Security Class Initialized
DEBUG - 2020-02-05 19:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:42 --> Input Class Initialized
INFO - 2020-02-05 19:11:42 --> Language Class Initialized
ERROR - 2020-02-05 19:11:42 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:11:42 --> Config Class Initialized
INFO - 2020-02-05 19:11:42 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:11:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:11:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:42 --> URI Class Initialized
INFO - 2020-02-05 19:11:42 --> Router Class Initialized
INFO - 2020-02-05 19:11:43 --> Output Class Initialized
INFO - 2020-02-05 19:11:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:43 --> Input Class Initialized
INFO - 2020-02-05 19:11:43 --> Language Class Initialized
ERROR - 2020-02-05 19:11:43 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:11:43 --> Config Class Initialized
INFO - 2020-02-05 19:11:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:11:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:11:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:43 --> URI Class Initialized
INFO - 2020-02-05 19:11:43 --> Router Class Initialized
INFO - 2020-02-05 19:11:43 --> Output Class Initialized
INFO - 2020-02-05 19:11:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:43 --> Input Class Initialized
INFO - 2020-02-05 19:11:43 --> Language Class Initialized
ERROR - 2020-02-05 19:11:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:11:43 --> Config Class Initialized
INFO - 2020-02-05 19:11:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:11:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:11:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:11:44 --> URI Class Initialized
INFO - 2020-02-05 19:11:44 --> Router Class Initialized
INFO - 2020-02-05 19:11:44 --> Output Class Initialized
INFO - 2020-02-05 19:11:44 --> Security Class Initialized
DEBUG - 2020-02-05 19:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:11:44 --> Input Class Initialized
INFO - 2020-02-05 19:11:44 --> Language Class Initialized
ERROR - 2020-02-05 19:11:44 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:12:03 --> Config Class Initialized
INFO - 2020-02-05 19:12:03 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:03 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:03 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:03 --> URI Class Initialized
INFO - 2020-02-05 19:12:03 --> Router Class Initialized
INFO - 2020-02-05 19:12:03 --> Output Class Initialized
INFO - 2020-02-05 19:12:03 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:03 --> Input Class Initialized
INFO - 2020-02-05 19:12:03 --> Language Class Initialized
INFO - 2020-02-05 19:12:03 --> Loader Class Initialized
INFO - 2020-02-05 19:12:03 --> Helper loaded: url_helper
INFO - 2020-02-05 19:12:03 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:12:03 --> Controller Class Initialized
INFO - 2020-02-05 19:12:04 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:12:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:12:04 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:12:04 --> Helper loaded: form_helper
INFO - 2020-02-05 19:12:04 --> Form Validation Class Initialized
INFO - 2020-02-05 19:12:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:12:04 --> Final output sent to browser
INFO - 2020-02-05 19:12:04 --> Config Class Initialized
INFO - 2020-02-05 19:12:04 --> Config Class Initialized
INFO - 2020-02-05 19:12:04 --> Config Class Initialized
INFO - 2020-02-05 19:12:04 --> Config Class Initialized
INFO - 2020-02-05 19:12:04 --> Config Class Initialized
INFO - 2020-02-05 19:12:04 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:04 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:04 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:04 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:04 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:04 --> Total execution time: 1.0357
DEBUG - 2020-02-05 19:12:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:04 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:04 --> Config Class Initialized
DEBUG - 2020-02-05 19:12:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:04 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:04 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:04 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:04 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:04 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:04 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:04 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:04 --> URI Class Initialized
INFO - 2020-02-05 19:12:04 --> URI Class Initialized
DEBUG - 2020-02-05 19:12:04 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:04 --> URI Class Initialized
INFO - 2020-02-05 19:12:04 --> URI Class Initialized
INFO - 2020-02-05 19:12:04 --> URI Class Initialized
INFO - 2020-02-05 19:12:04 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:04 --> Router Class Initialized
INFO - 2020-02-05 19:12:04 --> Router Class Initialized
INFO - 2020-02-05 19:12:04 --> Router Class Initialized
INFO - 2020-02-05 19:12:04 --> Router Class Initialized
INFO - 2020-02-05 19:12:04 --> Router Class Initialized
INFO - 2020-02-05 19:12:04 --> Output Class Initialized
INFO - 2020-02-05 19:12:04 --> Output Class Initialized
INFO - 2020-02-05 19:12:04 --> Output Class Initialized
INFO - 2020-02-05 19:12:04 --> Output Class Initialized
INFO - 2020-02-05 19:12:04 --> URI Class Initialized
INFO - 2020-02-05 19:12:04 --> Output Class Initialized
INFO - 2020-02-05 19:12:04 --> Security Class Initialized
INFO - 2020-02-05 19:12:04 --> Security Class Initialized
INFO - 2020-02-05 19:12:04 --> Security Class Initialized
INFO - 2020-02-05 19:12:04 --> Security Class Initialized
INFO - 2020-02-05 19:12:04 --> Router Class Initialized
INFO - 2020-02-05 19:12:04 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:04 --> Output Class Initialized
DEBUG - 2020-02-05 19:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:04 --> Input Class Initialized
INFO - 2020-02-05 19:12:04 --> Input Class Initialized
INFO - 2020-02-05 19:12:04 --> Input Class Initialized
INFO - 2020-02-05 19:12:04 --> Input Class Initialized
INFO - 2020-02-05 19:12:04 --> Input Class Initialized
INFO - 2020-02-05 19:12:04 --> Security Class Initialized
INFO - 2020-02-05 19:12:04 --> Language Class Initialized
INFO - 2020-02-05 19:12:04 --> Language Class Initialized
DEBUG - 2020-02-05 19:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:04 --> Language Class Initialized
INFO - 2020-02-05 19:12:04 --> Language Class Initialized
INFO - 2020-02-05 19:12:04 --> Language Class Initialized
INFO - 2020-02-05 19:12:04 --> Input Class Initialized
ERROR - 2020-02-05 19:12:04 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 19:12:04 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:12:04 --> Loader Class Initialized
ERROR - 2020-02-05 19:12:04 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:12:04 --> Loader Class Initialized
INFO - 2020-02-05 19:12:04 --> Language Class Initialized
INFO - 2020-02-05 19:12:04 --> Helper loaded: url_helper
INFO - 2020-02-05 19:12:04 --> Helper loaded: url_helper
INFO - 2020-02-05 19:12:04 --> Config Class Initialized
INFO - 2020-02-05 19:12:04 --> Config Class Initialized
INFO - 2020-02-05 19:12:04 --> Config Class Initialized
INFO - 2020-02-05 19:12:04 --> Hooks Class Initialized
ERROR - 2020-02-05 19:12:04 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:12:04 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:04 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:05 --> Database Driver Class Initialized
INFO - 2020-02-05 19:12:05 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:12:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:12:05 --> Config Class Initialized
INFO - 2020-02-05 19:12:05 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:12:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:05 --> Controller Class Initialized
INFO - 2020-02-05 19:12:05 --> URI Class Initialized
INFO - 2020-02-05 19:12:05 --> URI Class Initialized
INFO - 2020-02-05 19:12:05 --> URI Class Initialized
DEBUG - 2020-02-05 19:12:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:05 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:12:05 --> Router Class Initialized
INFO - 2020-02-05 19:12:05 --> Router Class Initialized
INFO - 2020-02-05 19:12:05 --> Router Class Initialized
INFO - 2020-02-05 19:12:05 --> URI Class Initialized
INFO - 2020-02-05 19:12:05 --> Output Class Initialized
INFO - 2020-02-05 19:12:05 --> Output Class Initialized
INFO - 2020-02-05 19:12:05 --> Output Class Initialized
INFO - 2020-02-05 19:12:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:12:05 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:12:05 --> Security Class Initialized
INFO - 2020-02-05 19:12:05 --> Security Class Initialized
INFO - 2020-02-05 19:12:05 --> Security Class Initialized
INFO - 2020-02-05 19:12:05 --> Router Class Initialized
DEBUG - 2020-02-05 19:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:05 --> Output Class Initialized
DEBUG - 2020-02-05 19:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:05 --> Helper loaded: form_helper
INFO - 2020-02-05 19:12:05 --> Form Validation Class Initialized
INFO - 2020-02-05 19:12:05 --> Input Class Initialized
INFO - 2020-02-05 19:12:05 --> Input Class Initialized
INFO - 2020-02-05 19:12:05 --> Input Class Initialized
INFO - 2020-02-05 19:12:05 --> Security Class Initialized
INFO - 2020-02-05 19:12:05 --> Language Class Initialized
INFO - 2020-02-05 19:12:05 --> Language Class Initialized
INFO - 2020-02-05 19:12:05 --> Language Class Initialized
DEBUG - 2020-02-05 19:12:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 19:12:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:12:05 --> Input Class Initialized
ERROR - 2020-02-05 19:12:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:12:05 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:12:05 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 19:12:05 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:12:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:12:05 --> Language Class Initialized
INFO - 2020-02-05 19:12:05 --> Config Class Initialized
INFO - 2020-02-05 19:12:05 --> Config Class Initialized
INFO - 2020-02-05 19:12:05 --> Config Class Initialized
INFO - 2020-02-05 19:12:05 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:05 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:05 --> Final output sent to browser
INFO - 2020-02-05 19:12:05 --> Hooks Class Initialized
ERROR - 2020-02-05 19:12:05 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-05 19:12:05 --> Total execution time: 1.1805
DEBUG - 2020-02-05 19:12:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:05 --> Config Class Initialized
INFO - 2020-02-05 19:12:05 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:12:05 --> Controller Class Initialized
INFO - 2020-02-05 19:12:05 --> URI Class Initialized
DEBUG - 2020-02-05 19:12:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:05 --> URI Class Initialized
INFO - 2020-02-05 19:12:05 --> URI Class Initialized
INFO - 2020-02-05 19:12:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:05 --> Router Class Initialized
INFO - 2020-02-05 19:12:05 --> Router Class Initialized
INFO - 2020-02-05 19:12:05 --> Router Class Initialized
INFO - 2020-02-05 19:12:05 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:12:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:12:05 --> Output Class Initialized
INFO - 2020-02-05 19:12:05 --> Output Class Initialized
INFO - 2020-02-05 19:12:05 --> URI Class Initialized
INFO - 2020-02-05 19:12:05 --> Output Class Initialized
INFO - 2020-02-05 19:12:05 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:12:05 --> Security Class Initialized
INFO - 2020-02-05 19:12:05 --> Security Class Initialized
INFO - 2020-02-05 19:12:05 --> Security Class Initialized
INFO - 2020-02-05 19:12:05 --> Router Class Initialized
DEBUG - 2020-02-05 19:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:05 --> Output Class Initialized
INFO - 2020-02-05 19:12:05 --> Helper loaded: form_helper
INFO - 2020-02-05 19:12:05 --> Form Validation Class Initialized
INFO - 2020-02-05 19:12:05 --> Input Class Initialized
INFO - 2020-02-05 19:12:05 --> Input Class Initialized
INFO - 2020-02-05 19:12:05 --> Input Class Initialized
INFO - 2020-02-05 19:12:05 --> Security Class Initialized
INFO - 2020-02-05 19:12:05 --> Language Class Initialized
INFO - 2020-02-05 19:12:05 --> Language Class Initialized
INFO - 2020-02-05 19:12:05 --> Language Class Initialized
DEBUG - 2020-02-05 19:12:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 19:12:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:12:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:12:05 --> Input Class Initialized
ERROR - 2020-02-05 19:12:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 19:12:05 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 19:12:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:12:05 --> Language Class Initialized
INFO - 2020-02-05 19:12:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:12:06 --> Final output sent to browser
ERROR - 2020-02-05 19:12:06 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-05 19:12:06 --> Total execution time: 1.6516
INFO - 2020-02-05 19:12:06 --> Config Class Initialized
INFO - 2020-02-05 19:12:06 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:06 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:06 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:06 --> URI Class Initialized
INFO - 2020-02-05 19:12:06 --> Router Class Initialized
INFO - 2020-02-05 19:12:06 --> Output Class Initialized
INFO - 2020-02-05 19:12:06 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:06 --> Input Class Initialized
INFO - 2020-02-05 19:12:06 --> Language Class Initialized
ERROR - 2020-02-05 19:12:06 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:12:06 --> Config Class Initialized
INFO - 2020-02-05 19:12:06 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:06 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:06 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:06 --> URI Class Initialized
INFO - 2020-02-05 19:12:06 --> Router Class Initialized
INFO - 2020-02-05 19:12:06 --> Output Class Initialized
INFO - 2020-02-05 19:12:06 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:06 --> Input Class Initialized
INFO - 2020-02-05 19:12:06 --> Language Class Initialized
ERROR - 2020-02-05 19:12:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:12:07 --> Config Class Initialized
INFO - 2020-02-05 19:12:07 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:07 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:07 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:07 --> URI Class Initialized
INFO - 2020-02-05 19:12:07 --> Router Class Initialized
INFO - 2020-02-05 19:12:07 --> Output Class Initialized
INFO - 2020-02-05 19:12:07 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:07 --> Input Class Initialized
INFO - 2020-02-05 19:12:07 --> Language Class Initialized
ERROR - 2020-02-05 19:12:07 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:12:07 --> Config Class Initialized
INFO - 2020-02-05 19:12:07 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:07 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:07 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:07 --> URI Class Initialized
INFO - 2020-02-05 19:12:07 --> Router Class Initialized
INFO - 2020-02-05 19:12:07 --> Output Class Initialized
INFO - 2020-02-05 19:12:07 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:07 --> Input Class Initialized
INFO - 2020-02-05 19:12:07 --> Language Class Initialized
ERROR - 2020-02-05 19:12:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:12:07 --> Config Class Initialized
INFO - 2020-02-05 19:12:08 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:08 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:08 --> URI Class Initialized
INFO - 2020-02-05 19:12:08 --> Router Class Initialized
INFO - 2020-02-05 19:12:08 --> Output Class Initialized
INFO - 2020-02-05 19:12:08 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:08 --> Input Class Initialized
INFO - 2020-02-05 19:12:08 --> Language Class Initialized
ERROR - 2020-02-05 19:12:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:12:08 --> Config Class Initialized
INFO - 2020-02-05 19:12:08 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:08 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:08 --> URI Class Initialized
INFO - 2020-02-05 19:12:08 --> Router Class Initialized
INFO - 2020-02-05 19:12:08 --> Output Class Initialized
INFO - 2020-02-05 19:12:08 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:08 --> Input Class Initialized
INFO - 2020-02-05 19:12:08 --> Language Class Initialized
ERROR - 2020-02-05 19:12:08 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:12:08 --> Config Class Initialized
INFO - 2020-02-05 19:12:08 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:09 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:09 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:09 --> URI Class Initialized
INFO - 2020-02-05 19:12:09 --> Router Class Initialized
INFO - 2020-02-05 19:12:09 --> Output Class Initialized
INFO - 2020-02-05 19:12:09 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:09 --> Input Class Initialized
INFO - 2020-02-05 19:12:09 --> Language Class Initialized
ERROR - 2020-02-05 19:12:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:12:09 --> Config Class Initialized
INFO - 2020-02-05 19:12:09 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:09 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:09 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:09 --> URI Class Initialized
INFO - 2020-02-05 19:12:09 --> Router Class Initialized
INFO - 2020-02-05 19:12:09 --> Output Class Initialized
INFO - 2020-02-05 19:12:09 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:09 --> Input Class Initialized
INFO - 2020-02-05 19:12:09 --> Language Class Initialized
ERROR - 2020-02-05 19:12:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:12:09 --> Config Class Initialized
INFO - 2020-02-05 19:12:09 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:09 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:10 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:10 --> URI Class Initialized
INFO - 2020-02-05 19:12:10 --> Router Class Initialized
INFO - 2020-02-05 19:12:10 --> Output Class Initialized
INFO - 2020-02-05 19:12:10 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:10 --> Input Class Initialized
INFO - 2020-02-05 19:12:10 --> Language Class Initialized
ERROR - 2020-02-05 19:12:10 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:12:31 --> Config Class Initialized
INFO - 2020-02-05 19:12:31 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:31 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:31 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:31 --> URI Class Initialized
INFO - 2020-02-05 19:12:31 --> Router Class Initialized
INFO - 2020-02-05 19:12:31 --> Output Class Initialized
INFO - 2020-02-05 19:12:31 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:31 --> Input Class Initialized
INFO - 2020-02-05 19:12:31 --> Language Class Initialized
INFO - 2020-02-05 19:12:31 --> Loader Class Initialized
INFO - 2020-02-05 19:12:31 --> Helper loaded: url_helper
INFO - 2020-02-05 19:12:31 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:12:32 --> Controller Class Initialized
INFO - 2020-02-05 19:12:32 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:12:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:12:32 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:12:32 --> Helper loaded: form_helper
INFO - 2020-02-05 19:12:32 --> Form Validation Class Initialized
INFO - 2020-02-05 19:12:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:12:32 --> Final output sent to browser
INFO - 2020-02-05 19:12:32 --> Config Class Initialized
INFO - 2020-02-05 19:12:32 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:32 --> Total execution time: 1.3109
INFO - 2020-02-05 19:12:32 --> Config Class Initialized
INFO - 2020-02-05 19:12:32 --> Config Class Initialized
INFO - 2020-02-05 19:12:32 --> Config Class Initialized
INFO - 2020-02-05 19:12:32 --> Config Class Initialized
INFO - 2020-02-05 19:12:32 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:32 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:32 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:32 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:32 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:32 --> Config Class Initialized
INFO - 2020-02-05 19:12:32 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:32 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:12:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:32 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:32 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:32 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:32 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:32 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:32 --> URI Class Initialized
DEBUG - 2020-02-05 19:12:32 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:32 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:32 --> URI Class Initialized
INFO - 2020-02-05 19:12:32 --> URI Class Initialized
INFO - 2020-02-05 19:12:32 --> Router Class Initialized
INFO - 2020-02-05 19:12:32 --> URI Class Initialized
INFO - 2020-02-05 19:12:32 --> URI Class Initialized
INFO - 2020-02-05 19:12:32 --> Router Class Initialized
INFO - 2020-02-05 19:12:32 --> Router Class Initialized
INFO - 2020-02-05 19:12:32 --> URI Class Initialized
INFO - 2020-02-05 19:12:32 --> Router Class Initialized
INFO - 2020-02-05 19:12:32 --> Router Class Initialized
INFO - 2020-02-05 19:12:32 --> Output Class Initialized
INFO - 2020-02-05 19:12:32 --> Security Class Initialized
INFO - 2020-02-05 19:12:32 --> Output Class Initialized
INFO - 2020-02-05 19:12:32 --> Output Class Initialized
INFO - 2020-02-05 19:12:32 --> Output Class Initialized
INFO - 2020-02-05 19:12:32 --> Router Class Initialized
INFO - 2020-02-05 19:12:32 --> Output Class Initialized
INFO - 2020-02-05 19:12:32 --> Security Class Initialized
INFO - 2020-02-05 19:12:32 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:32 --> Output Class Initialized
INFO - 2020-02-05 19:12:32 --> Security Class Initialized
INFO - 2020-02-05 19:12:32 --> Security Class Initialized
INFO - 2020-02-05 19:12:32 --> Input Class Initialized
DEBUG - 2020-02-05 19:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:32 --> Security Class Initialized
INFO - 2020-02-05 19:12:32 --> Input Class Initialized
INFO - 2020-02-05 19:12:32 --> Input Class Initialized
INFO - 2020-02-05 19:12:32 --> Language Class Initialized
INFO - 2020-02-05 19:12:32 --> Input Class Initialized
INFO - 2020-02-05 19:12:32 --> Input Class Initialized
DEBUG - 2020-02-05 19:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:32 --> Input Class Initialized
INFO - 2020-02-05 19:12:32 --> Language Class Initialized
ERROR - 2020-02-05 19:12:32 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:12:32 --> Language Class Initialized
INFO - 2020-02-05 19:12:32 --> Language Class Initialized
INFO - 2020-02-05 19:12:32 --> Language Class Initialized
ERROR - 2020-02-05 19:12:32 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 19:12:32 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:12:32 --> Loader Class Initialized
INFO - 2020-02-05 19:12:32 --> Language Class Initialized
INFO - 2020-02-05 19:12:32 --> Loader Class Initialized
INFO - 2020-02-05 19:12:32 --> Config Class Initialized
INFO - 2020-02-05 19:12:32 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:32 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:12:32 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:12:32 --> Config Class Initialized
INFO - 2020-02-05 19:12:32 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:33 --> Helper loaded: url_helper
DEBUG - 2020-02-05 19:12:33 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:33 --> Database Driver Class Initialized
INFO - 2020-02-05 19:12:33 --> Config Class Initialized
INFO - 2020-02-05 19:12:33 --> Config Class Initialized
INFO - 2020-02-05 19:12:33 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:33 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:33 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:12:33 --> Database Driver Class Initialized
INFO - 2020-02-05 19:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:12:33 --> URI Class Initialized
INFO - 2020-02-05 19:12:33 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:12:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:12:33 --> Controller Class Initialized
INFO - 2020-02-05 19:12:33 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:33 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:33 --> Router Class Initialized
INFO - 2020-02-05 19:12:33 --> URI Class Initialized
INFO - 2020-02-05 19:12:33 --> URI Class Initialized
INFO - 2020-02-05 19:12:33 --> URI Class Initialized
INFO - 2020-02-05 19:12:33 --> Output Class Initialized
INFO - 2020-02-05 19:12:33 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:12:33 --> Router Class Initialized
INFO - 2020-02-05 19:12:33 --> Security Class Initialized
INFO - 2020-02-05 19:12:33 --> Router Class Initialized
INFO - 2020-02-05 19:12:33 --> Router Class Initialized
INFO - 2020-02-05 19:12:33 --> Output Class Initialized
INFO - 2020-02-05 19:12:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:12:33 --> Model "M_pesan" initialized
DEBUG - 2020-02-05 19:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:33 --> Security Class Initialized
INFO - 2020-02-05 19:12:33 --> Output Class Initialized
INFO - 2020-02-05 19:12:33 --> Output Class Initialized
INFO - 2020-02-05 19:12:33 --> Input Class Initialized
DEBUG - 2020-02-05 19:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:33 --> Security Class Initialized
INFO - 2020-02-05 19:12:33 --> Security Class Initialized
INFO - 2020-02-05 19:12:33 --> Helper loaded: form_helper
INFO - 2020-02-05 19:12:33 --> Form Validation Class Initialized
INFO - 2020-02-05 19:12:33 --> Input Class Initialized
INFO - 2020-02-05 19:12:33 --> Language Class Initialized
DEBUG - 2020-02-05 19:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:33 --> Input Class Initialized
INFO - 2020-02-05 19:12:33 --> Language Class Initialized
INFO - 2020-02-05 19:12:33 --> Input Class Initialized
ERROR - 2020-02-05 19:12:33 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 19:12:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:12:33 --> Language Class Initialized
ERROR - 2020-02-05 19:12:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:12:33 --> Language Class Initialized
ERROR - 2020-02-05 19:12:33 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:12:33 --> Config Class Initialized
INFO - 2020-02-05 19:12:33 --> Hooks Class Initialized
ERROR - 2020-02-05 19:12:33 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-05 19:12:33 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:12:33 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:12:33 --> Config Class Initialized
INFO - 2020-02-05 19:12:33 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:33 --> Final output sent to browser
DEBUG - 2020-02-05 19:12:33 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:33 --> Config Class Initialized
INFO - 2020-02-05 19:12:33 --> Config Class Initialized
INFO - 2020-02-05 19:12:33 --> Hooks Class Initialized
INFO - 2020-02-05 19:12:33 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:33 --> Total execution time: 1.1048
INFO - 2020-02-05 19:12:33 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:12:33 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:12:33 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:12:33 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:33 --> URI Class Initialized
DEBUG - 2020-02-05 19:12:33 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:33 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:33 --> Controller Class Initialized
INFO - 2020-02-05 19:12:33 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:33 --> URI Class Initialized
INFO - 2020-02-05 19:12:33 --> Router Class Initialized
INFO - 2020-02-05 19:12:33 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:12:33 --> URI Class Initialized
INFO - 2020-02-05 19:12:33 --> Router Class Initialized
INFO - 2020-02-05 19:12:33 --> Output Class Initialized
INFO - 2020-02-05 19:12:33 --> URI Class Initialized
INFO - 2020-02-05 19:12:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:12:33 --> Security Class Initialized
INFO - 2020-02-05 19:12:33 --> Router Class Initialized
INFO - 2020-02-05 19:12:33 --> Output Class Initialized
INFO - 2020-02-05 19:12:33 --> Router Class Initialized
INFO - 2020-02-05 19:12:33 --> Model "M_pesan" initialized
DEBUG - 2020-02-05 19:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:33 --> Security Class Initialized
INFO - 2020-02-05 19:12:33 --> Output Class Initialized
INFO - 2020-02-05 19:12:33 --> Output Class Initialized
DEBUG - 2020-02-05 19:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:33 --> Security Class Initialized
INFO - 2020-02-05 19:12:33 --> Security Class Initialized
INFO - 2020-02-05 19:12:33 --> Input Class Initialized
INFO - 2020-02-05 19:12:33 --> Helper loaded: form_helper
INFO - 2020-02-05 19:12:33 --> Form Validation Class Initialized
INFO - 2020-02-05 19:12:33 --> Language Class Initialized
INFO - 2020-02-05 19:12:33 --> Input Class Initialized
DEBUG - 2020-02-05 19:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:33 --> Input Class Initialized
INFO - 2020-02-05 19:12:33 --> Input Class Initialized
INFO - 2020-02-05 19:12:33 --> Language Class Initialized
ERROR - 2020-02-05 19:12:33 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-05 19:12:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:12:33 --> Language Class Initialized
ERROR - 2020-02-05 19:12:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:12:33 --> Language Class Initialized
ERROR - 2020-02-05 19:12:33 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:12:33 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:12:33 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 19:12:33 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:12:34 --> Final output sent to browser
INFO - 2020-02-05 19:12:34 --> Config Class Initialized
INFO - 2020-02-05 19:12:34 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:34 --> Total execution time: 1.5705
DEBUG - 2020-02-05 19:12:34 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:34 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:34 --> URI Class Initialized
INFO - 2020-02-05 19:12:34 --> Router Class Initialized
INFO - 2020-02-05 19:12:34 --> Output Class Initialized
INFO - 2020-02-05 19:12:34 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:34 --> Input Class Initialized
INFO - 2020-02-05 19:12:34 --> Language Class Initialized
ERROR - 2020-02-05 19:12:34 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:12:34 --> Config Class Initialized
INFO - 2020-02-05 19:12:34 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:34 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:34 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:34 --> URI Class Initialized
INFO - 2020-02-05 19:12:34 --> Router Class Initialized
INFO - 2020-02-05 19:12:34 --> Output Class Initialized
INFO - 2020-02-05 19:12:34 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:34 --> Input Class Initialized
INFO - 2020-02-05 19:12:34 --> Language Class Initialized
ERROR - 2020-02-05 19:12:34 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:12:34 --> Config Class Initialized
INFO - 2020-02-05 19:12:34 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:35 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:35 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:35 --> URI Class Initialized
INFO - 2020-02-05 19:12:35 --> Router Class Initialized
INFO - 2020-02-05 19:12:35 --> Output Class Initialized
INFO - 2020-02-05 19:12:35 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:35 --> Input Class Initialized
INFO - 2020-02-05 19:12:35 --> Language Class Initialized
ERROR - 2020-02-05 19:12:35 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:12:35 --> Config Class Initialized
INFO - 2020-02-05 19:12:35 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:35 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:35 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:35 --> URI Class Initialized
INFO - 2020-02-05 19:12:35 --> Router Class Initialized
INFO - 2020-02-05 19:12:35 --> Output Class Initialized
INFO - 2020-02-05 19:12:35 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:35 --> Input Class Initialized
INFO - 2020-02-05 19:12:35 --> Language Class Initialized
ERROR - 2020-02-05 19:12:35 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:12:35 --> Config Class Initialized
INFO - 2020-02-05 19:12:35 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:35 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:35 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:36 --> URI Class Initialized
INFO - 2020-02-05 19:12:36 --> Router Class Initialized
INFO - 2020-02-05 19:12:36 --> Output Class Initialized
INFO - 2020-02-05 19:12:36 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:36 --> Input Class Initialized
INFO - 2020-02-05 19:12:36 --> Language Class Initialized
ERROR - 2020-02-05 19:12:36 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:12:36 --> Config Class Initialized
INFO - 2020-02-05 19:12:36 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:36 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:36 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:36 --> URI Class Initialized
INFO - 2020-02-05 19:12:36 --> Router Class Initialized
INFO - 2020-02-05 19:12:36 --> Output Class Initialized
INFO - 2020-02-05 19:12:36 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:36 --> Input Class Initialized
INFO - 2020-02-05 19:12:36 --> Language Class Initialized
ERROR - 2020-02-05 19:12:36 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:12:36 --> Config Class Initialized
INFO - 2020-02-05 19:12:36 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:36 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:36 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:36 --> URI Class Initialized
INFO - 2020-02-05 19:12:37 --> Router Class Initialized
INFO - 2020-02-05 19:12:37 --> Output Class Initialized
INFO - 2020-02-05 19:12:37 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:37 --> Input Class Initialized
INFO - 2020-02-05 19:12:37 --> Language Class Initialized
ERROR - 2020-02-05 19:12:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:12:37 --> Config Class Initialized
INFO - 2020-02-05 19:12:37 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:12:37 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:12:37 --> Utf8 Class Initialized
INFO - 2020-02-05 19:12:37 --> URI Class Initialized
INFO - 2020-02-05 19:12:37 --> Router Class Initialized
INFO - 2020-02-05 19:12:37 --> Output Class Initialized
INFO - 2020-02-05 19:12:37 --> Security Class Initialized
DEBUG - 2020-02-05 19:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:12:37 --> Input Class Initialized
INFO - 2020-02-05 19:12:37 --> Language Class Initialized
ERROR - 2020-02-05 19:12:37 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:13:02 --> Config Class Initialized
INFO - 2020-02-05 19:13:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:13:02 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:13:02 --> Utf8 Class Initialized
INFO - 2020-02-05 19:13:02 --> URI Class Initialized
INFO - 2020-02-05 19:13:02 --> Router Class Initialized
INFO - 2020-02-05 19:13:02 --> Output Class Initialized
INFO - 2020-02-05 19:13:02 --> Security Class Initialized
DEBUG - 2020-02-05 19:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:13:03 --> Input Class Initialized
INFO - 2020-02-05 19:13:03 --> Language Class Initialized
INFO - 2020-02-05 19:13:03 --> Loader Class Initialized
INFO - 2020-02-05 19:13:03 --> Helper loaded: url_helper
INFO - 2020-02-05 19:13:03 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:13:03 --> Controller Class Initialized
INFO - 2020-02-05 19:13:03 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:13:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:13:03 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:13:03 --> Helper loaded: form_helper
INFO - 2020-02-05 19:13:03 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:13:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 43
ERROR - 2020-02-05 19:13:03 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('33', '1', NULL)
INFO - 2020-02-05 19:13:04 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-05 19:14:35 --> Config Class Initialized
INFO - 2020-02-05 19:14:35 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:35 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:35 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:35 --> URI Class Initialized
INFO - 2020-02-05 19:14:35 --> Router Class Initialized
INFO - 2020-02-05 19:14:35 --> Output Class Initialized
INFO - 2020-02-05 19:14:35 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:35 --> Input Class Initialized
INFO - 2020-02-05 19:14:35 --> Language Class Initialized
INFO - 2020-02-05 19:14:35 --> Loader Class Initialized
INFO - 2020-02-05 19:14:35 --> Helper loaded: url_helper
INFO - 2020-02-05 19:14:35 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:14:36 --> Controller Class Initialized
INFO - 2020-02-05 19:14:36 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:14:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:14:36 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:14:36 --> Helper loaded: form_helper
INFO - 2020-02-05 19:14:36 --> Form Validation Class Initialized
INFO - 2020-02-05 19:14:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:14:36 --> Final output sent to browser
INFO - 2020-02-05 19:14:36 --> Config Class Initialized
INFO - 2020-02-05 19:14:36 --> Config Class Initialized
INFO - 2020-02-05 19:14:36 --> Config Class Initialized
INFO - 2020-02-05 19:14:36 --> Hooks Class Initialized
INFO - 2020-02-05 19:14:36 --> Hooks Class Initialized
INFO - 2020-02-05 19:14:36 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:36 --> Total execution time: 1.4455
DEBUG - 2020-02-05 19:14:36 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:36 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:14:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:14:36 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:36 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:36 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:36 --> URI Class Initialized
INFO - 2020-02-05 19:14:36 --> URI Class Initialized
INFO - 2020-02-05 19:14:36 --> Router Class Initialized
INFO - 2020-02-05 19:14:36 --> URI Class Initialized
INFO - 2020-02-05 19:14:36 --> Router Class Initialized
INFO - 2020-02-05 19:14:36 --> Router Class Initialized
INFO - 2020-02-05 19:14:36 --> Output Class Initialized
INFO - 2020-02-05 19:14:36 --> Security Class Initialized
INFO - 2020-02-05 19:14:36 --> Output Class Initialized
INFO - 2020-02-05 19:14:36 --> Output Class Initialized
INFO - 2020-02-05 19:14:37 --> Security Class Initialized
INFO - 2020-02-05 19:14:37 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:37 --> Input Class Initialized
DEBUG - 2020-02-05 19:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:37 --> Input Class Initialized
INFO - 2020-02-05 19:14:37 --> Input Class Initialized
INFO - 2020-02-05 19:14:37 --> Language Class Initialized
INFO - 2020-02-05 19:14:37 --> Language Class Initialized
INFO - 2020-02-05 19:14:37 --> Language Class Initialized
ERROR - 2020-02-05 19:14:37 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:14:37 --> Loader Class Initialized
INFO - 2020-02-05 19:14:37 --> Loader Class Initialized
INFO - 2020-02-05 19:14:37 --> Helper loaded: url_helper
INFO - 2020-02-05 19:14:37 --> Helper loaded: url_helper
INFO - 2020-02-05 19:14:37 --> Database Driver Class Initialized
INFO - 2020-02-05 19:14:37 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:14:37 --> Controller Class Initialized
INFO - 2020-02-05 19:14:37 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:14:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:14:37 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:14:37 --> Helper loaded: form_helper
INFO - 2020-02-05 19:14:37 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:14:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:14:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:14:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:14:37 --> Final output sent to browser
DEBUG - 2020-02-05 19:14:37 --> Total execution time: 1.1776
INFO - 2020-02-05 19:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:14:37 --> Controller Class Initialized
INFO - 2020-02-05 19:14:37 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:14:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:14:38 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:14:38 --> Helper loaded: form_helper
INFO - 2020-02-05 19:14:38 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:14:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:14:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:14:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:14:38 --> Final output sent to browser
DEBUG - 2020-02-05 19:14:38 --> Total execution time: 1.6728
INFO - 2020-02-05 19:14:43 --> Config Class Initialized
INFO - 2020-02-05 19:14:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:43 --> URI Class Initialized
INFO - 2020-02-05 19:14:43 --> Router Class Initialized
INFO - 2020-02-05 19:14:43 --> Output Class Initialized
INFO - 2020-02-05 19:14:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:43 --> Input Class Initialized
INFO - 2020-02-05 19:14:43 --> Language Class Initialized
INFO - 2020-02-05 19:14:43 --> Loader Class Initialized
INFO - 2020-02-05 19:14:43 --> Helper loaded: url_helper
INFO - 2020-02-05 19:14:44 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:14:44 --> Controller Class Initialized
INFO - 2020-02-05 19:14:44 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:14:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:14:44 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:14:44 --> Helper loaded: form_helper
INFO - 2020-02-05 19:14:44 --> Form Validation Class Initialized
INFO - 2020-02-05 19:14:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:14:44 --> Final output sent to browser
INFO - 2020-02-05 19:14:44 --> Config Class Initialized
INFO - 2020-02-05 19:14:44 --> Config Class Initialized
INFO - 2020-02-05 19:14:44 --> Config Class Initialized
INFO - 2020-02-05 19:14:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:14:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:14:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:44 --> Total execution time: 0.9166
INFO - 2020-02-05 19:14:44 --> Config Class Initialized
INFO - 2020-02-05 19:14:44 --> Config Class Initialized
INFO - 2020-02-05 19:14:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:14:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:14:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:14:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:44 --> Config Class Initialized
INFO - 2020-02-05 19:14:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:14:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:44 --> URI Class Initialized
INFO - 2020-02-05 19:14:44 --> URI Class Initialized
INFO - 2020-02-05 19:14:44 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:14:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:44 --> URI Class Initialized
INFO - 2020-02-05 19:14:44 --> URI Class Initialized
INFO - 2020-02-05 19:14:44 --> Router Class Initialized
INFO - 2020-02-05 19:14:44 --> Router Class Initialized
INFO - 2020-02-05 19:14:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:44 --> Router Class Initialized
INFO - 2020-02-05 19:14:44 --> URI Class Initialized
INFO - 2020-02-05 19:14:44 --> Router Class Initialized
INFO - 2020-02-05 19:14:44 --> Output Class Initialized
INFO - 2020-02-05 19:14:44 --> Router Class Initialized
INFO - 2020-02-05 19:14:44 --> URI Class Initialized
INFO - 2020-02-05 19:14:44 --> Output Class Initialized
INFO - 2020-02-05 19:14:44 --> Output Class Initialized
INFO - 2020-02-05 19:14:44 --> Security Class Initialized
INFO - 2020-02-05 19:14:44 --> Router Class Initialized
INFO - 2020-02-05 19:14:44 --> Output Class Initialized
INFO - 2020-02-05 19:14:44 --> Security Class Initialized
INFO - 2020-02-05 19:14:44 --> Security Class Initialized
INFO - 2020-02-05 19:14:44 --> Output Class Initialized
DEBUG - 2020-02-05 19:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:44 --> Security Class Initialized
INFO - 2020-02-05 19:14:44 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:44 --> Output Class Initialized
INFO - 2020-02-05 19:14:44 --> Input Class Initialized
INFO - 2020-02-05 19:14:44 --> Input Class Initialized
DEBUG - 2020-02-05 19:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:44 --> Input Class Initialized
DEBUG - 2020-02-05 19:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:44 --> Security Class Initialized
INFO - 2020-02-05 19:14:44 --> Language Class Initialized
INFO - 2020-02-05 19:14:44 --> Language Class Initialized
INFO - 2020-02-05 19:14:44 --> Language Class Initialized
INFO - 2020-02-05 19:14:44 --> Input Class Initialized
INFO - 2020-02-05 19:14:44 --> Input Class Initialized
DEBUG - 2020-02-05 19:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:44 --> Input Class Initialized
INFO - 2020-02-05 19:14:44 --> Language Class Initialized
INFO - 2020-02-05 19:14:44 --> Language Class Initialized
ERROR - 2020-02-05 19:14:44 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 19:14:44 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:14:44 --> Loader Class Initialized
ERROR - 2020-02-05 19:14:45 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:14:45 --> Helper loaded: url_helper
INFO - 2020-02-05 19:14:45 --> Language Class Initialized
INFO - 2020-02-05 19:14:45 --> Loader Class Initialized
INFO - 2020-02-05 19:14:45 --> Config Class Initialized
INFO - 2020-02-05 19:14:45 --> Config Class Initialized
INFO - 2020-02-05 19:14:45 --> Hooks Class Initialized
INFO - 2020-02-05 19:14:45 --> Hooks Class Initialized
ERROR - 2020-02-05 19:14:45 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:14:45 --> Helper loaded: url_helper
INFO - 2020-02-05 19:14:45 --> Database Driver Class Initialized
INFO - 2020-02-05 19:14:45 --> Config Class Initialized
INFO - 2020-02-05 19:14:45 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:14:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:14:45 --> Database Driver Class Initialized
INFO - 2020-02-05 19:14:45 --> Config Class Initialized
INFO - 2020-02-05 19:14:45 --> Hooks Class Initialized
INFO - 2020-02-05 19:14:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:14:45 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:14:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:14:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:45 --> URI Class Initialized
INFO - 2020-02-05 19:14:45 --> Controller Class Initialized
INFO - 2020-02-05 19:14:45 --> URI Class Initialized
DEBUG - 2020-02-05 19:14:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:45 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:14:45 --> Router Class Initialized
INFO - 2020-02-05 19:14:45 --> URI Class Initialized
INFO - 2020-02-05 19:14:45 --> Router Class Initialized
INFO - 2020-02-05 19:14:45 --> URI Class Initialized
INFO - 2020-02-05 19:14:45 --> Router Class Initialized
INFO - 2020-02-05 19:14:45 --> Output Class Initialized
INFO - 2020-02-05 19:14:45 --> Output Class Initialized
INFO - 2020-02-05 19:14:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:14:45 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:14:45 --> Security Class Initialized
INFO - 2020-02-05 19:14:45 --> Router Class Initialized
INFO - 2020-02-05 19:14:45 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:45 --> Output Class Initialized
INFO - 2020-02-05 19:14:45 --> Output Class Initialized
DEBUG - 2020-02-05 19:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:45 --> Helper loaded: form_helper
INFO - 2020-02-05 19:14:45 --> Form Validation Class Initialized
INFO - 2020-02-05 19:14:45 --> Input Class Initialized
INFO - 2020-02-05 19:14:45 --> Input Class Initialized
INFO - 2020-02-05 19:14:45 --> Security Class Initialized
INFO - 2020-02-05 19:14:45 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:45 --> Language Class Initialized
ERROR - 2020-02-05 19:14:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:14:45 --> Language Class Initialized
INFO - 2020-02-05 19:14:45 --> Input Class Initialized
ERROR - 2020-02-05 19:14:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:14:45 --> Input Class Initialized
ERROR - 2020-02-05 19:14:45 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 19:14:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:14:45 --> Language Class Initialized
INFO - 2020-02-05 19:14:45 --> Language Class Initialized
INFO - 2020-02-05 19:14:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:14:45 --> Config Class Initialized
INFO - 2020-02-05 19:14:45 --> Config Class Initialized
INFO - 2020-02-05 19:14:45 --> Hooks Class Initialized
INFO - 2020-02-05 19:14:45 --> Hooks Class Initialized
INFO - 2020-02-05 19:14:45 --> Final output sent to browser
ERROR - 2020-02-05 19:14:45 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-05 19:14:45 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-05 19:14:45 --> Total execution time: 1.1046
DEBUG - 2020-02-05 19:14:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:14:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:45 --> Config Class Initialized
INFO - 2020-02-05 19:14:45 --> Config Class Initialized
INFO - 2020-02-05 19:14:45 --> Hooks Class Initialized
INFO - 2020-02-05 19:14:45 --> Hooks Class Initialized
INFO - 2020-02-05 19:14:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:14:45 --> Controller Class Initialized
INFO - 2020-02-05 19:14:45 --> URI Class Initialized
INFO - 2020-02-05 19:14:45 --> URI Class Initialized
DEBUG - 2020-02-05 19:14:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:14:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:45 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:14:45 --> Router Class Initialized
INFO - 2020-02-05 19:14:45 --> Router Class Initialized
INFO - 2020-02-05 19:14:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:14:45 --> URI Class Initialized
INFO - 2020-02-05 19:14:45 --> URI Class Initialized
INFO - 2020-02-05 19:14:45 --> Output Class Initialized
INFO - 2020-02-05 19:14:45 --> Output Class Initialized
INFO - 2020-02-05 19:14:45 --> Security Class Initialized
INFO - 2020-02-05 19:14:45 --> Security Class Initialized
INFO - 2020-02-05 19:14:45 --> Router Class Initialized
INFO - 2020-02-05 19:14:45 --> Router Class Initialized
INFO - 2020-02-05 19:14:45 --> Model "M_pesan" initialized
DEBUG - 2020-02-05 19:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:45 --> Output Class Initialized
INFO - 2020-02-05 19:14:45 --> Output Class Initialized
INFO - 2020-02-05 19:14:45 --> Helper loaded: form_helper
INFO - 2020-02-05 19:14:46 --> Input Class Initialized
INFO - 2020-02-05 19:14:46 --> Form Validation Class Initialized
INFO - 2020-02-05 19:14:46 --> Security Class Initialized
INFO - 2020-02-05 19:14:46 --> Input Class Initialized
INFO - 2020-02-05 19:14:46 --> Security Class Initialized
INFO - 2020-02-05 19:14:46 --> Language Class Initialized
INFO - 2020-02-05 19:14:46 --> Language Class Initialized
DEBUG - 2020-02-05 19:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:14:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 19:14:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:14:46 --> Input Class Initialized
ERROR - 2020-02-05 19:14:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:14:46 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:14:46 --> Input Class Initialized
ERROR - 2020-02-05 19:14:46 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:14:46 --> Language Class Initialized
INFO - 2020-02-05 19:14:46 --> Language Class Initialized
INFO - 2020-02-05 19:14:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:14:46 --> Final output sent to browser
ERROR - 2020-02-05 19:14:46 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 19:14:46 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-05 19:14:46 --> Total execution time: 1.6566
INFO - 2020-02-05 19:14:46 --> Config Class Initialized
INFO - 2020-02-05 19:14:46 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:46 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:46 --> URI Class Initialized
INFO - 2020-02-05 19:14:46 --> Router Class Initialized
INFO - 2020-02-05 19:14:46 --> Output Class Initialized
INFO - 2020-02-05 19:14:46 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:46 --> Input Class Initialized
INFO - 2020-02-05 19:14:46 --> Language Class Initialized
ERROR - 2020-02-05 19:14:46 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:14:46 --> Config Class Initialized
INFO - 2020-02-05 19:14:46 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:46 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:46 --> URI Class Initialized
INFO - 2020-02-05 19:14:46 --> Router Class Initialized
INFO - 2020-02-05 19:14:46 --> Output Class Initialized
INFO - 2020-02-05 19:14:46 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:47 --> Input Class Initialized
INFO - 2020-02-05 19:14:47 --> Language Class Initialized
ERROR - 2020-02-05 19:14:47 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:14:47 --> Config Class Initialized
INFO - 2020-02-05 19:14:47 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:47 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:47 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:47 --> URI Class Initialized
INFO - 2020-02-05 19:14:47 --> Router Class Initialized
INFO - 2020-02-05 19:14:47 --> Output Class Initialized
INFO - 2020-02-05 19:14:47 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:47 --> Input Class Initialized
INFO - 2020-02-05 19:14:47 --> Language Class Initialized
ERROR - 2020-02-05 19:14:47 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:14:47 --> Config Class Initialized
INFO - 2020-02-05 19:14:47 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:47 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:47 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:47 --> URI Class Initialized
INFO - 2020-02-05 19:14:47 --> Router Class Initialized
INFO - 2020-02-05 19:14:47 --> Output Class Initialized
INFO - 2020-02-05 19:14:48 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:48 --> Input Class Initialized
INFO - 2020-02-05 19:14:48 --> Language Class Initialized
ERROR - 2020-02-05 19:14:48 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:14:48 --> Config Class Initialized
INFO - 2020-02-05 19:14:48 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:48 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:48 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:48 --> URI Class Initialized
INFO - 2020-02-05 19:14:48 --> Router Class Initialized
INFO - 2020-02-05 19:14:48 --> Output Class Initialized
INFO - 2020-02-05 19:14:48 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:48 --> Input Class Initialized
INFO - 2020-02-05 19:14:48 --> Language Class Initialized
ERROR - 2020-02-05 19:14:48 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:14:48 --> Config Class Initialized
INFO - 2020-02-05 19:14:48 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:48 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:48 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:48 --> URI Class Initialized
INFO - 2020-02-05 19:14:48 --> Router Class Initialized
INFO - 2020-02-05 19:14:48 --> Output Class Initialized
INFO - 2020-02-05 19:14:49 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:49 --> Input Class Initialized
INFO - 2020-02-05 19:14:49 --> Language Class Initialized
ERROR - 2020-02-05 19:14:49 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:14:49 --> Config Class Initialized
INFO - 2020-02-05 19:14:49 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:49 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:49 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:49 --> URI Class Initialized
INFO - 2020-02-05 19:14:49 --> Router Class Initialized
INFO - 2020-02-05 19:14:49 --> Output Class Initialized
INFO - 2020-02-05 19:14:49 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:49 --> Input Class Initialized
INFO - 2020-02-05 19:14:49 --> Language Class Initialized
ERROR - 2020-02-05 19:14:49 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:14:49 --> Config Class Initialized
INFO - 2020-02-05 19:14:49 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:49 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:49 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:49 --> URI Class Initialized
INFO - 2020-02-05 19:14:49 --> Router Class Initialized
INFO - 2020-02-05 19:14:49 --> Output Class Initialized
INFO - 2020-02-05 19:14:50 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:50 --> Input Class Initialized
INFO - 2020-02-05 19:14:50 --> Language Class Initialized
ERROR - 2020-02-05 19:14:50 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:14:50 --> Config Class Initialized
INFO - 2020-02-05 19:14:50 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:50 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:50 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:50 --> URI Class Initialized
INFO - 2020-02-05 19:14:50 --> Router Class Initialized
INFO - 2020-02-05 19:14:50 --> Output Class Initialized
INFO - 2020-02-05 19:14:50 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:50 --> Input Class Initialized
INFO - 2020-02-05 19:14:50 --> Language Class Initialized
ERROR - 2020-02-05 19:14:50 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:14:56 --> Config Class Initialized
INFO - 2020-02-05 19:14:57 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:14:57 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:14:57 --> Utf8 Class Initialized
INFO - 2020-02-05 19:14:57 --> URI Class Initialized
INFO - 2020-02-05 19:14:57 --> Router Class Initialized
INFO - 2020-02-05 19:14:57 --> Output Class Initialized
INFO - 2020-02-05 19:14:57 --> Security Class Initialized
DEBUG - 2020-02-05 19:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:14:57 --> Input Class Initialized
INFO - 2020-02-05 19:14:57 --> Language Class Initialized
INFO - 2020-02-05 19:14:57 --> Loader Class Initialized
INFO - 2020-02-05 19:14:57 --> Helper loaded: url_helper
INFO - 2020-02-05 19:14:57 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:14:57 --> Controller Class Initialized
INFO - 2020-02-05 19:14:57 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:14:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:14:57 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:14:57 --> Helper loaded: form_helper
INFO - 2020-02-05 19:14:57 --> Form Validation Class Initialized
INFO - 2020-02-05 19:14:58 --> Final output sent to browser
DEBUG - 2020-02-05 19:14:58 --> Total execution time: 1.0423
INFO - 2020-02-05 19:17:45 --> Config Class Initialized
INFO - 2020-02-05 19:17:45 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:17:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:17:46 --> Utf8 Class Initialized
INFO - 2020-02-05 19:17:46 --> URI Class Initialized
INFO - 2020-02-05 19:17:46 --> Router Class Initialized
INFO - 2020-02-05 19:17:46 --> Output Class Initialized
INFO - 2020-02-05 19:17:46 --> Security Class Initialized
DEBUG - 2020-02-05 19:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:17:46 --> Input Class Initialized
INFO - 2020-02-05 19:17:46 --> Language Class Initialized
INFO - 2020-02-05 19:17:46 --> Loader Class Initialized
INFO - 2020-02-05 19:17:46 --> Helper loaded: url_helper
INFO - 2020-02-05 19:17:46 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:17:47 --> Controller Class Initialized
INFO - 2020-02-05 19:17:47 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:17:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:17:47 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:17:47 --> Helper loaded: form_helper
INFO - 2020-02-05 19:17:47 --> Form Validation Class Initialized
INFO - 2020-02-05 19:17:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:17:47 --> Final output sent to browser
INFO - 2020-02-05 19:17:47 --> Config Class Initialized
INFO - 2020-02-05 19:17:47 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:17:47 --> Total execution time: 1.6373
DEBUG - 2020-02-05 19:17:47 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:17:47 --> Utf8 Class Initialized
INFO - 2020-02-05 19:17:47 --> URI Class Initialized
INFO - 2020-02-05 19:17:47 --> Router Class Initialized
INFO - 2020-02-05 19:17:47 --> Output Class Initialized
INFO - 2020-02-05 19:17:47 --> Security Class Initialized
DEBUG - 2020-02-05 19:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:17:47 --> Input Class Initialized
INFO - 2020-02-05 19:17:47 --> Language Class Initialized
ERROR - 2020-02-05 19:17:47 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:17:53 --> Config Class Initialized
INFO - 2020-02-05 19:17:54 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:17:54 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:17:54 --> Utf8 Class Initialized
INFO - 2020-02-05 19:17:54 --> URI Class Initialized
INFO - 2020-02-05 19:17:54 --> Router Class Initialized
INFO - 2020-02-05 19:17:54 --> Output Class Initialized
INFO - 2020-02-05 19:17:54 --> Security Class Initialized
DEBUG - 2020-02-05 19:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:17:54 --> Input Class Initialized
INFO - 2020-02-05 19:17:54 --> Language Class Initialized
INFO - 2020-02-05 19:17:54 --> Loader Class Initialized
INFO - 2020-02-05 19:17:54 --> Helper loaded: url_helper
INFO - 2020-02-05 19:17:54 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:17:54 --> Controller Class Initialized
INFO - 2020-02-05 19:17:54 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:17:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:17:54 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:17:54 --> Helper loaded: form_helper
INFO - 2020-02-05 19:17:54 --> Form Validation Class Initialized
INFO - 2020-02-05 19:17:55 --> Final output sent to browser
DEBUG - 2020-02-05 19:17:55 --> Total execution time: 1.1482
INFO - 2020-02-05 19:18:09 --> Config Class Initialized
INFO - 2020-02-05 19:18:09 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:18:09 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:18:09 --> Utf8 Class Initialized
INFO - 2020-02-05 19:18:09 --> URI Class Initialized
INFO - 2020-02-05 19:18:09 --> Router Class Initialized
INFO - 2020-02-05 19:18:09 --> Output Class Initialized
INFO - 2020-02-05 19:18:09 --> Security Class Initialized
DEBUG - 2020-02-05 19:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:18:10 --> Input Class Initialized
INFO - 2020-02-05 19:18:10 --> Language Class Initialized
INFO - 2020-02-05 19:18:10 --> Loader Class Initialized
INFO - 2020-02-05 19:18:10 --> Helper loaded: url_helper
INFO - 2020-02-05 19:18:10 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:18:10 --> Controller Class Initialized
INFO - 2020-02-05 19:18:10 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:18:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:18:10 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:18:10 --> Helper loaded: form_helper
INFO - 2020-02-05 19:18:10 --> Form Validation Class Initialized
INFO - 2020-02-05 19:18:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:18:10 --> Final output sent to browser
INFO - 2020-02-05 19:18:11 --> Config Class Initialized
INFO - 2020-02-05 19:18:11 --> Config Class Initialized
INFO - 2020-02-05 19:18:11 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:18:11 --> Total execution time: 1.3380
INFO - 2020-02-05 19:18:11 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:18:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:18:11 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:18:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:18:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:18:11 --> URI Class Initialized
INFO - 2020-02-05 19:18:11 --> URI Class Initialized
INFO - 2020-02-05 19:18:11 --> Router Class Initialized
INFO - 2020-02-05 19:18:11 --> Router Class Initialized
INFO - 2020-02-05 19:18:11 --> Output Class Initialized
INFO - 2020-02-05 19:18:11 --> Output Class Initialized
INFO - 2020-02-05 19:18:11 --> Security Class Initialized
INFO - 2020-02-05 19:18:11 --> Security Class Initialized
DEBUG - 2020-02-05 19:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:18:11 --> Input Class Initialized
INFO - 2020-02-05 19:18:11 --> Input Class Initialized
INFO - 2020-02-05 19:18:11 --> Language Class Initialized
INFO - 2020-02-05 19:18:11 --> Language Class Initialized
INFO - 2020-02-05 19:18:11 --> Loader Class Initialized
INFO - 2020-02-05 19:18:11 --> Loader Class Initialized
INFO - 2020-02-05 19:18:11 --> Helper loaded: url_helper
INFO - 2020-02-05 19:18:11 --> Helper loaded: url_helper
INFO - 2020-02-05 19:18:11 --> Database Driver Class Initialized
INFO - 2020-02-05 19:18:11 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:18:11 --> Controller Class Initialized
INFO - 2020-02-05 19:18:12 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:18:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:18:12 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:18:12 --> Helper loaded: form_helper
INFO - 2020-02-05 19:18:12 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:18:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:18:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:18:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:18:12 --> Final output sent to browser
DEBUG - 2020-02-05 19:18:12 --> Total execution time: 1.5364
INFO - 2020-02-05 19:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:18:12 --> Controller Class Initialized
INFO - 2020-02-05 19:18:12 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:18:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:18:12 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:18:12 --> Helper loaded: form_helper
INFO - 2020-02-05 19:18:13 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:18:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:18:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:18:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:18:13 --> Final output sent to browser
DEBUG - 2020-02-05 19:18:13 --> Total execution time: 2.2326
INFO - 2020-02-05 19:20:51 --> Config Class Initialized
INFO - 2020-02-05 19:20:51 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:51 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:51 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:51 --> URI Class Initialized
INFO - 2020-02-05 19:20:51 --> Router Class Initialized
INFO - 2020-02-05 19:20:52 --> Output Class Initialized
INFO - 2020-02-05 19:20:52 --> Security Class Initialized
DEBUG - 2020-02-05 19:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:52 --> Input Class Initialized
INFO - 2020-02-05 19:20:52 --> Language Class Initialized
INFO - 2020-02-05 19:20:52 --> Loader Class Initialized
INFO - 2020-02-05 19:20:52 --> Helper loaded: url_helper
INFO - 2020-02-05 19:20:52 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:20:52 --> Controller Class Initialized
INFO - 2020-02-05 19:20:52 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:20:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:20:52 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:20:52 --> Helper loaded: form_helper
INFO - 2020-02-05 19:20:52 --> Form Validation Class Initialized
INFO - 2020-02-05 19:20:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:20:52 --> Final output sent to browser
INFO - 2020-02-05 19:20:53 --> Config Class Initialized
INFO - 2020-02-05 19:20:53 --> Config Class Initialized
INFO - 2020-02-05 19:20:53 --> Config Class Initialized
INFO - 2020-02-05 19:20:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:20:53 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:53 --> Total execution time: 1.4602
INFO - 2020-02-05 19:20:53 --> Config Class Initialized
INFO - 2020-02-05 19:20:53 --> Config Class Initialized
INFO - 2020-02-05 19:20:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:20:53 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:20:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:53 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:53 --> Config Class Initialized
INFO - 2020-02-05 19:20:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:20:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:53 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:20:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:20:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:53 --> URI Class Initialized
INFO - 2020-02-05 19:20:53 --> URI Class Initialized
INFO - 2020-02-05 19:20:53 --> URI Class Initialized
DEBUG - 2020-02-05 19:20:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:53 --> URI Class Initialized
INFO - 2020-02-05 19:20:53 --> Router Class Initialized
INFO - 2020-02-05 19:20:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:53 --> Router Class Initialized
INFO - 2020-02-05 19:20:53 --> URI Class Initialized
INFO - 2020-02-05 19:20:53 --> Router Class Initialized
INFO - 2020-02-05 19:20:53 --> Router Class Initialized
INFO - 2020-02-05 19:20:53 --> URI Class Initialized
INFO - 2020-02-05 19:20:53 --> Output Class Initialized
INFO - 2020-02-05 19:20:53 --> Output Class Initialized
INFO - 2020-02-05 19:20:53 --> Router Class Initialized
INFO - 2020-02-05 19:20:53 --> Output Class Initialized
INFO - 2020-02-05 19:20:53 --> Security Class Initialized
INFO - 2020-02-05 19:20:53 --> Output Class Initialized
INFO - 2020-02-05 19:20:53 --> Security Class Initialized
INFO - 2020-02-05 19:20:53 --> Router Class Initialized
INFO - 2020-02-05 19:20:53 --> Security Class Initialized
INFO - 2020-02-05 19:20:53 --> Output Class Initialized
DEBUG - 2020-02-05 19:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:53 --> Security Class Initialized
INFO - 2020-02-05 19:20:53 --> Output Class Initialized
INFO - 2020-02-05 19:20:53 --> Security Class Initialized
DEBUG - 2020-02-05 19:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:53 --> Input Class Initialized
INFO - 2020-02-05 19:20:53 --> Input Class Initialized
INFO - 2020-02-05 19:20:53 --> Input Class Initialized
DEBUG - 2020-02-05 19:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:53 --> Security Class Initialized
INFO - 2020-02-05 19:20:53 --> Input Class Initialized
INFO - 2020-02-05 19:20:53 --> Input Class Initialized
INFO - 2020-02-05 19:20:53 --> Language Class Initialized
INFO - 2020-02-05 19:20:53 --> Language Class Initialized
DEBUG - 2020-02-05 19:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:53 --> Language Class Initialized
INFO - 2020-02-05 19:20:53 --> Input Class Initialized
INFO - 2020-02-05 19:20:53 --> Language Class Initialized
INFO - 2020-02-05 19:20:53 --> Language Class Initialized
ERROR - 2020-02-05 19:20:53 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:20:53 --> Loader Class Initialized
ERROR - 2020-02-05 19:20:53 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:20:53 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:20:53 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:20:53 --> Language Class Initialized
INFO - 2020-02-05 19:20:53 --> Loader Class Initialized
INFO - 2020-02-05 19:20:53 --> Config Class Initialized
INFO - 2020-02-05 19:20:53 --> Config Class Initialized
INFO - 2020-02-05 19:20:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:20:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:20:53 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:20:53 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:20:53 --> Database Driver Class Initialized
INFO - 2020-02-05 19:20:53 --> Config Class Initialized
INFO - 2020-02-05 19:20:53 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:20:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:53 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:20:53 --> Config Class Initialized
INFO - 2020-02-05 19:20:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:20:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:53 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:20:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:20:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:53 --> Controller Class Initialized
INFO - 2020-02-05 19:20:53 --> URI Class Initialized
DEBUG - 2020-02-05 19:20:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:53 --> URI Class Initialized
INFO - 2020-02-05 19:20:54 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:54 --> URI Class Initialized
INFO - 2020-02-05 19:20:54 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:20:54 --> Router Class Initialized
INFO - 2020-02-05 19:20:54 --> Router Class Initialized
INFO - 2020-02-05 19:20:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:20:54 --> Output Class Initialized
INFO - 2020-02-05 19:20:54 --> Router Class Initialized
INFO - 2020-02-05 19:20:54 --> Output Class Initialized
INFO - 2020-02-05 19:20:54 --> URI Class Initialized
INFO - 2020-02-05 19:20:54 --> Security Class Initialized
INFO - 2020-02-05 19:20:54 --> Router Class Initialized
INFO - 2020-02-05 19:20:54 --> Security Class Initialized
INFO - 2020-02-05 19:20:54 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:20:54 --> Output Class Initialized
DEBUG - 2020-02-05 19:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:54 --> Security Class Initialized
INFO - 2020-02-05 19:20:54 --> Output Class Initialized
INFO - 2020-02-05 19:20:54 --> Helper loaded: form_helper
INFO - 2020-02-05 19:20:54 --> Form Validation Class Initialized
INFO - 2020-02-05 19:20:54 --> Input Class Initialized
INFO - 2020-02-05 19:20:54 --> Input Class Initialized
INFO - 2020-02-05 19:20:54 --> Security Class Initialized
DEBUG - 2020-02-05 19:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:54 --> Input Class Initialized
INFO - 2020-02-05 19:20:54 --> Language Class Initialized
INFO - 2020-02-05 19:20:54 --> Language Class Initialized
DEBUG - 2020-02-05 19:20:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 19:20:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:20:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:20:54 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:20:54 --> Input Class Initialized
INFO - 2020-02-05 19:20:54 --> Language Class Initialized
ERROR - 2020-02-05 19:20:54 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:20:54 --> Language Class Initialized
INFO - 2020-02-05 19:20:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:20:54 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:20:54 --> Config Class Initialized
INFO - 2020-02-05 19:20:54 --> Config Class Initialized
INFO - 2020-02-05 19:20:54 --> Hooks Class Initialized
INFO - 2020-02-05 19:20:54 --> Final output sent to browser
ERROR - 2020-02-05 19:20:54 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:20:54 --> Hooks Class Initialized
INFO - 2020-02-05 19:20:54 --> Config Class Initialized
INFO - 2020-02-05 19:20:54 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:54 --> Total execution time: 1.4714
DEBUG - 2020-02-05 19:20:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:20:54 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:54 --> Config Class Initialized
INFO - 2020-02-05 19:20:54 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:54 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:54 --> Hooks Class Initialized
INFO - 2020-02-05 19:20:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:20:54 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:54 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:54 --> URI Class Initialized
INFO - 2020-02-05 19:20:54 --> Controller Class Initialized
INFO - 2020-02-05 19:20:54 --> URI Class Initialized
DEBUG - 2020-02-05 19:20:54 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:54 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:54 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:20:54 --> URI Class Initialized
INFO - 2020-02-05 19:20:54 --> Router Class Initialized
INFO - 2020-02-05 19:20:54 --> Router Class Initialized
INFO - 2020-02-05 19:20:54 --> URI Class Initialized
INFO - 2020-02-05 19:20:54 --> Router Class Initialized
INFO - 2020-02-05 19:20:54 --> Output Class Initialized
INFO - 2020-02-05 19:20:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:20:54 --> Output Class Initialized
INFO - 2020-02-05 19:20:54 --> Security Class Initialized
INFO - 2020-02-05 19:20:54 --> Security Class Initialized
INFO - 2020-02-05 19:20:54 --> Output Class Initialized
INFO - 2020-02-05 19:20:54 --> Router Class Initialized
INFO - 2020-02-05 19:20:54 --> Model "M_pesan" initialized
DEBUG - 2020-02-05 19:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:54 --> Output Class Initialized
INFO - 2020-02-05 19:20:54 --> Helper loaded: form_helper
INFO - 2020-02-05 19:20:54 --> Security Class Initialized
INFO - 2020-02-05 19:20:54 --> Input Class Initialized
INFO - 2020-02-05 19:20:54 --> Form Validation Class Initialized
INFO - 2020-02-05 19:20:54 --> Input Class Initialized
DEBUG - 2020-02-05 19:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:54 --> Security Class Initialized
INFO - 2020-02-05 19:20:54 --> Input Class Initialized
INFO - 2020-02-05 19:20:54 --> Language Class Initialized
DEBUG - 2020-02-05 19:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:54 --> Language Class Initialized
ERROR - 2020-02-05 19:20:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:20:54 --> Input Class Initialized
INFO - 2020-02-05 19:20:54 --> Language Class Initialized
ERROR - 2020-02-05 19:20:54 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 19:20:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:20:54 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:20:55 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:20:55 --> Language Class Initialized
ERROR - 2020-02-05 19:20:55 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:20:55 --> Final output sent to browser
ERROR - 2020-02-05 19:20:55 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-05 19:20:55 --> Total execution time: 2.1013
INFO - 2020-02-05 19:20:55 --> Config Class Initialized
INFO - 2020-02-05 19:20:55 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:55 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:55 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:55 --> URI Class Initialized
INFO - 2020-02-05 19:20:55 --> Router Class Initialized
INFO - 2020-02-05 19:20:55 --> Output Class Initialized
INFO - 2020-02-05 19:20:55 --> Security Class Initialized
DEBUG - 2020-02-05 19:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:55 --> Input Class Initialized
INFO - 2020-02-05 19:20:55 --> Language Class Initialized
ERROR - 2020-02-05 19:20:55 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:20:55 --> Config Class Initialized
INFO - 2020-02-05 19:20:55 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:55 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:55 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:55 --> URI Class Initialized
INFO - 2020-02-05 19:20:56 --> Router Class Initialized
INFO - 2020-02-05 19:20:56 --> Output Class Initialized
INFO - 2020-02-05 19:20:56 --> Security Class Initialized
DEBUG - 2020-02-05 19:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:56 --> Input Class Initialized
INFO - 2020-02-05 19:20:56 --> Language Class Initialized
ERROR - 2020-02-05 19:20:56 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:20:56 --> Config Class Initialized
INFO - 2020-02-05 19:20:56 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:56 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:56 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:56 --> URI Class Initialized
INFO - 2020-02-05 19:20:56 --> Router Class Initialized
INFO - 2020-02-05 19:20:56 --> Output Class Initialized
INFO - 2020-02-05 19:20:56 --> Security Class Initialized
DEBUG - 2020-02-05 19:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:56 --> Input Class Initialized
INFO - 2020-02-05 19:20:56 --> Language Class Initialized
ERROR - 2020-02-05 19:20:56 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:20:56 --> Config Class Initialized
INFO - 2020-02-05 19:20:57 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:57 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:57 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:57 --> URI Class Initialized
INFO - 2020-02-05 19:20:57 --> Router Class Initialized
INFO - 2020-02-05 19:20:57 --> Output Class Initialized
INFO - 2020-02-05 19:20:57 --> Security Class Initialized
DEBUG - 2020-02-05 19:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:57 --> Input Class Initialized
INFO - 2020-02-05 19:20:57 --> Language Class Initialized
ERROR - 2020-02-05 19:20:57 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:20:57 --> Config Class Initialized
INFO - 2020-02-05 19:20:57 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:57 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:57 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:57 --> URI Class Initialized
INFO - 2020-02-05 19:20:57 --> Router Class Initialized
INFO - 2020-02-05 19:20:57 --> Output Class Initialized
INFO - 2020-02-05 19:20:57 --> Security Class Initialized
DEBUG - 2020-02-05 19:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:57 --> Input Class Initialized
INFO - 2020-02-05 19:20:57 --> Language Class Initialized
ERROR - 2020-02-05 19:20:57 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:20:58 --> Config Class Initialized
INFO - 2020-02-05 19:20:58 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:58 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:58 --> URI Class Initialized
INFO - 2020-02-05 19:20:58 --> Router Class Initialized
INFO - 2020-02-05 19:20:58 --> Output Class Initialized
INFO - 2020-02-05 19:20:58 --> Security Class Initialized
DEBUG - 2020-02-05 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:58 --> Input Class Initialized
INFO - 2020-02-05 19:20:58 --> Language Class Initialized
ERROR - 2020-02-05 19:20:58 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:20:58 --> Config Class Initialized
INFO - 2020-02-05 19:20:58 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:58 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:58 --> URI Class Initialized
INFO - 2020-02-05 19:20:58 --> Router Class Initialized
INFO - 2020-02-05 19:20:58 --> Output Class Initialized
INFO - 2020-02-05 19:20:58 --> Security Class Initialized
DEBUG - 2020-02-05 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:58 --> Input Class Initialized
INFO - 2020-02-05 19:20:58 --> Language Class Initialized
ERROR - 2020-02-05 19:20:59 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:20:59 --> Config Class Initialized
INFO - 2020-02-05 19:20:59 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:20:59 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:20:59 --> Utf8 Class Initialized
INFO - 2020-02-05 19:20:59 --> URI Class Initialized
INFO - 2020-02-05 19:20:59 --> Router Class Initialized
INFO - 2020-02-05 19:20:59 --> Output Class Initialized
INFO - 2020-02-05 19:20:59 --> Security Class Initialized
DEBUG - 2020-02-05 19:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:20:59 --> Input Class Initialized
INFO - 2020-02-05 19:20:59 --> Language Class Initialized
ERROR - 2020-02-05 19:20:59 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:21:20 --> Config Class Initialized
INFO - 2020-02-05 19:21:20 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:21:20 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:21:20 --> Utf8 Class Initialized
INFO - 2020-02-05 19:21:20 --> URI Class Initialized
INFO - 2020-02-05 19:21:21 --> Router Class Initialized
INFO - 2020-02-05 19:21:21 --> Output Class Initialized
INFO - 2020-02-05 19:21:21 --> Security Class Initialized
DEBUG - 2020-02-05 19:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:21:21 --> Input Class Initialized
INFO - 2020-02-05 19:21:21 --> Language Class Initialized
INFO - 2020-02-05 19:21:21 --> Loader Class Initialized
INFO - 2020-02-05 19:21:21 --> Helper loaded: url_helper
INFO - 2020-02-05 19:21:21 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:21:21 --> Controller Class Initialized
INFO - 2020-02-05 19:21:21 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:21:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:21:21 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:21:21 --> Helper loaded: form_helper
INFO - 2020-02-05 19:21:21 --> Form Validation Class Initialized
INFO - 2020-02-05 19:21:22 --> Final output sent to browser
DEBUG - 2020-02-05 19:21:22 --> Total execution time: 1.6872
INFO - 2020-02-05 19:23:36 --> Config Class Initialized
INFO - 2020-02-05 19:23:36 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:36 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:36 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:36 --> URI Class Initialized
INFO - 2020-02-05 19:23:36 --> Router Class Initialized
INFO - 2020-02-05 19:23:36 --> Output Class Initialized
INFO - 2020-02-05 19:23:36 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:36 --> Input Class Initialized
INFO - 2020-02-05 19:23:36 --> Language Class Initialized
INFO - 2020-02-05 19:23:36 --> Loader Class Initialized
INFO - 2020-02-05 19:23:36 --> Helper loaded: url_helper
INFO - 2020-02-05 19:23:36 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:23:37 --> Controller Class Initialized
INFO - 2020-02-05 19:23:37 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:23:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:23:37 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:23:37 --> Helper loaded: form_helper
INFO - 2020-02-05 19:23:37 --> Form Validation Class Initialized
INFO - 2020-02-05 19:23:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:23:37 --> Final output sent to browser
DEBUG - 2020-02-05 19:23:37 --> Total execution time: 1.2261
INFO - 2020-02-05 19:23:42 --> Config Class Initialized
INFO - 2020-02-05 19:23:42 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:42 --> URI Class Initialized
INFO - 2020-02-05 19:23:42 --> Router Class Initialized
INFO - 2020-02-05 19:23:42 --> Output Class Initialized
INFO - 2020-02-05 19:23:42 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:42 --> Input Class Initialized
INFO - 2020-02-05 19:23:42 --> Language Class Initialized
INFO - 2020-02-05 19:23:42 --> Loader Class Initialized
INFO - 2020-02-05 19:23:43 --> Helper loaded: url_helper
INFO - 2020-02-05 19:23:43 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:23:43 --> Controller Class Initialized
INFO - 2020-02-05 19:23:43 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:23:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:23:43 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:23:43 --> Helper loaded: form_helper
INFO - 2020-02-05 19:23:43 --> Form Validation Class Initialized
INFO - 2020-02-05 19:23:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:23:43 --> Final output sent to browser
INFO - 2020-02-05 19:23:43 --> Config Class Initialized
INFO - 2020-02-05 19:23:43 --> Config Class Initialized
INFO - 2020-02-05 19:23:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:43 --> Total execution time: 1.1383
INFO - 2020-02-05 19:23:43 --> Hooks Class Initialized
INFO - 2020-02-05 19:23:43 --> Config Class Initialized
INFO - 2020-02-05 19:23:43 --> Config Class Initialized
INFO - 2020-02-05 19:23:43 --> Config Class Initialized
INFO - 2020-02-05 19:23:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:43 --> Hooks Class Initialized
INFO - 2020-02-05 19:23:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:43 --> Config Class Initialized
INFO - 2020-02-05 19:23:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:43 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:23:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:23:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:43 --> URI Class Initialized
INFO - 2020-02-05 19:23:43 --> URI Class Initialized
DEBUG - 2020-02-05 19:23:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:43 --> URI Class Initialized
INFO - 2020-02-05 19:23:43 --> URI Class Initialized
INFO - 2020-02-05 19:23:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:43 --> Router Class Initialized
INFO - 2020-02-05 19:23:43 --> Router Class Initialized
INFO - 2020-02-05 19:23:43 --> URI Class Initialized
INFO - 2020-02-05 19:23:44 --> Router Class Initialized
INFO - 2020-02-05 19:23:44 --> Output Class Initialized
INFO - 2020-02-05 19:23:44 --> URI Class Initialized
INFO - 2020-02-05 19:23:44 --> Output Class Initialized
INFO - 2020-02-05 19:23:44 --> Router Class Initialized
INFO - 2020-02-05 19:23:44 --> Router Class Initialized
INFO - 2020-02-05 19:23:44 --> Output Class Initialized
INFO - 2020-02-05 19:23:44 --> Output Class Initialized
INFO - 2020-02-05 19:23:44 --> Security Class Initialized
INFO - 2020-02-05 19:23:44 --> Router Class Initialized
INFO - 2020-02-05 19:23:44 --> Output Class Initialized
INFO - 2020-02-05 19:23:44 --> Security Class Initialized
INFO - 2020-02-05 19:23:44 --> Security Class Initialized
INFO - 2020-02-05 19:23:44 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:44 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:44 --> Output Class Initialized
DEBUG - 2020-02-05 19:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:44 --> Security Class Initialized
INFO - 2020-02-05 19:23:44 --> Input Class Initialized
DEBUG - 2020-02-05 19:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:44 --> Input Class Initialized
DEBUG - 2020-02-05 19:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:44 --> Input Class Initialized
INFO - 2020-02-05 19:23:44 --> Input Class Initialized
INFO - 2020-02-05 19:23:44 --> Input Class Initialized
INFO - 2020-02-05 19:23:44 --> Language Class Initialized
INFO - 2020-02-05 19:23:44 --> Language Class Initialized
DEBUG - 2020-02-05 19:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:44 --> Language Class Initialized
INFO - 2020-02-05 19:23:44 --> Input Class Initialized
INFO - 2020-02-05 19:23:44 --> Language Class Initialized
INFO - 2020-02-05 19:23:44 --> Loader Class Initialized
INFO - 2020-02-05 19:23:44 --> Loader Class Initialized
INFO - 2020-02-05 19:23:44 --> Language Class Initialized
INFO - 2020-02-05 19:23:44 --> Language Class Initialized
ERROR - 2020-02-05 19:23:44 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 19:23:44 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:23:44 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:23:44 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:23:44 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:23:44 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:23:44 --> Database Driver Class Initialized
INFO - 2020-02-05 19:23:44 --> Database Driver Class Initialized
INFO - 2020-02-05 19:23:44 --> Config Class Initialized
INFO - 2020-02-05 19:23:44 --> Config Class Initialized
INFO - 2020-02-05 19:23:44 --> Config Class Initialized
INFO - 2020-02-05 19:23:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:23:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:23:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:23:44 --> Config Class Initialized
INFO - 2020-02-05 19:23:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:23:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:23:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:23:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:23:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:44 --> Controller Class Initialized
DEBUG - 2020-02-05 19:23:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:44 --> URI Class Initialized
INFO - 2020-02-05 19:23:44 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:23:44 --> URI Class Initialized
INFO - 2020-02-05 19:23:44 --> URI Class Initialized
INFO - 2020-02-05 19:23:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:23:44 --> URI Class Initialized
INFO - 2020-02-05 19:23:44 --> Router Class Initialized
INFO - 2020-02-05 19:23:44 --> Router Class Initialized
INFO - 2020-02-05 19:23:44 --> Router Class Initialized
INFO - 2020-02-05 19:23:45 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:23:45 --> Output Class Initialized
INFO - 2020-02-05 19:23:45 --> Output Class Initialized
INFO - 2020-02-05 19:23:45 --> Router Class Initialized
INFO - 2020-02-05 19:23:45 --> Output Class Initialized
INFO - 2020-02-05 19:23:45 --> Security Class Initialized
INFO - 2020-02-05 19:23:45 --> Output Class Initialized
INFO - 2020-02-05 19:23:45 --> Security Class Initialized
INFO - 2020-02-05 19:23:45 --> Helper loaded: form_helper
INFO - 2020-02-05 19:23:45 --> Form Validation Class Initialized
DEBUG - 2020-02-05 19:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:45 --> Security Class Initialized
INFO - 2020-02-05 19:23:45 --> Security Class Initialized
INFO - 2020-02-05 19:23:45 --> Input Class Initialized
INFO - 2020-02-05 19:23:45 --> Input Class Initialized
DEBUG - 2020-02-05 19:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:23:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 19:23:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:23:45 --> Input Class Initialized
INFO - 2020-02-05 19:23:45 --> Language Class Initialized
ERROR - 2020-02-05 19:23:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:23:45 --> Input Class Initialized
INFO - 2020-02-05 19:23:45 --> Language Class Initialized
INFO - 2020-02-05 19:23:45 --> Language Class Initialized
INFO - 2020-02-05 19:23:45 --> Language Class Initialized
ERROR - 2020-02-05 19:23:45 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:23:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:23:45 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:23:45 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:23:45 --> Final output sent to browser
ERROR - 2020-02-05 19:23:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:23:45 --> Config Class Initialized
INFO - 2020-02-05 19:23:45 --> Config Class Initialized
INFO - 2020-02-05 19:23:45 --> Hooks Class Initialized
INFO - 2020-02-05 19:23:45 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:45 --> Total execution time: 1.7091
INFO - 2020-02-05 19:23:45 --> Config Class Initialized
INFO - 2020-02-05 19:23:45 --> Config Class Initialized
INFO - 2020-02-05 19:23:45 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:45 --> Hooks Class Initialized
INFO - 2020-02-05 19:23:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:23:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:23:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:45 --> Controller Class Initialized
INFO - 2020-02-05 19:23:45 --> URI Class Initialized
INFO - 2020-02-05 19:23:45 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:23:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:45 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:23:45 --> URI Class Initialized
INFO - 2020-02-05 19:23:45 --> URI Class Initialized
INFO - 2020-02-05 19:23:45 --> Router Class Initialized
INFO - 2020-02-05 19:23:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:23:45 --> Router Class Initialized
INFO - 2020-02-05 19:23:45 --> URI Class Initialized
INFO - 2020-02-05 19:23:45 --> Output Class Initialized
INFO - 2020-02-05 19:23:45 --> Router Class Initialized
INFO - 2020-02-05 19:23:45 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:23:45 --> Router Class Initialized
INFO - 2020-02-05 19:23:45 --> Output Class Initialized
INFO - 2020-02-05 19:23:45 --> Output Class Initialized
INFO - 2020-02-05 19:23:45 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:45 --> Security Class Initialized
INFO - 2020-02-05 19:23:45 --> Output Class Initialized
INFO - 2020-02-05 19:23:45 --> Security Class Initialized
INFO - 2020-02-05 19:23:45 --> Helper loaded: form_helper
INFO - 2020-02-05 19:23:45 --> Form Validation Class Initialized
DEBUG - 2020-02-05 19:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:45 --> Input Class Initialized
INFO - 2020-02-05 19:23:45 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:46 --> Input Class Initialized
INFO - 2020-02-05 19:23:46 --> Input Class Initialized
INFO - 2020-02-05 19:23:46 --> Language Class Initialized
ERROR - 2020-02-05 19:23:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
DEBUG - 2020-02-05 19:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:46 --> Input Class Initialized
INFO - 2020-02-05 19:23:46 --> Language Class Initialized
ERROR - 2020-02-05 19:23:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:23:46 --> Language Class Initialized
ERROR - 2020-02-05 19:23:46 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:23:46 --> Language Class Initialized
INFO - 2020-02-05 19:23:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:23:46 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 19:23:46 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 19:23:46 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:23:46 --> Final output sent to browser
INFO - 2020-02-05 19:23:46 --> Config Class Initialized
DEBUG - 2020-02-05 19:23:46 --> Total execution time: 2.6844
INFO - 2020-02-05 19:23:46 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:46 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:46 --> URI Class Initialized
INFO - 2020-02-05 19:23:46 --> Router Class Initialized
INFO - 2020-02-05 19:23:46 --> Output Class Initialized
INFO - 2020-02-05 19:23:46 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:46 --> Input Class Initialized
INFO - 2020-02-05 19:23:46 --> Language Class Initialized
ERROR - 2020-02-05 19:23:46 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:23:47 --> Config Class Initialized
INFO - 2020-02-05 19:23:47 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:47 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:47 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:47 --> URI Class Initialized
INFO - 2020-02-05 19:23:47 --> Router Class Initialized
INFO - 2020-02-05 19:23:47 --> Output Class Initialized
INFO - 2020-02-05 19:23:47 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:47 --> Input Class Initialized
INFO - 2020-02-05 19:23:47 --> Language Class Initialized
ERROR - 2020-02-05 19:23:47 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:23:47 --> Config Class Initialized
INFO - 2020-02-05 19:23:47 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:47 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:47 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:47 --> URI Class Initialized
INFO - 2020-02-05 19:23:48 --> Router Class Initialized
INFO - 2020-02-05 19:23:48 --> Output Class Initialized
INFO - 2020-02-05 19:23:48 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:48 --> Input Class Initialized
INFO - 2020-02-05 19:23:48 --> Language Class Initialized
ERROR - 2020-02-05 19:23:48 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:23:48 --> Config Class Initialized
INFO - 2020-02-05 19:23:48 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:48 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:48 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:48 --> URI Class Initialized
INFO - 2020-02-05 19:23:48 --> Router Class Initialized
INFO - 2020-02-05 19:23:48 --> Output Class Initialized
INFO - 2020-02-05 19:23:48 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:48 --> Input Class Initialized
INFO - 2020-02-05 19:23:48 --> Language Class Initialized
ERROR - 2020-02-05 19:23:49 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:23:49 --> Config Class Initialized
INFO - 2020-02-05 19:23:49 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:49 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:49 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:49 --> URI Class Initialized
INFO - 2020-02-05 19:23:49 --> Router Class Initialized
INFO - 2020-02-05 19:23:49 --> Output Class Initialized
INFO - 2020-02-05 19:23:49 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:49 --> Input Class Initialized
INFO - 2020-02-05 19:23:49 --> Language Class Initialized
ERROR - 2020-02-05 19:23:49 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:23:49 --> Config Class Initialized
INFO - 2020-02-05 19:23:49 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:49 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:49 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:50 --> URI Class Initialized
INFO - 2020-02-05 19:23:50 --> Router Class Initialized
INFO - 2020-02-05 19:23:50 --> Output Class Initialized
INFO - 2020-02-05 19:23:50 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:50 --> Input Class Initialized
INFO - 2020-02-05 19:23:50 --> Language Class Initialized
ERROR - 2020-02-05 19:23:50 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:23:50 --> Config Class Initialized
INFO - 2020-02-05 19:23:50 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:50 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:50 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:50 --> URI Class Initialized
INFO - 2020-02-05 19:23:50 --> Router Class Initialized
INFO - 2020-02-05 19:23:50 --> Output Class Initialized
INFO - 2020-02-05 19:23:50 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:51 --> Input Class Initialized
INFO - 2020-02-05 19:23:51 --> Language Class Initialized
ERROR - 2020-02-05 19:23:51 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:23:51 --> Config Class Initialized
INFO - 2020-02-05 19:23:51 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:51 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:51 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:51 --> URI Class Initialized
INFO - 2020-02-05 19:23:51 --> Router Class Initialized
INFO - 2020-02-05 19:23:51 --> Output Class Initialized
INFO - 2020-02-05 19:23:51 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:51 --> Input Class Initialized
INFO - 2020-02-05 19:23:51 --> Language Class Initialized
ERROR - 2020-02-05 19:23:51 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:23:51 --> Config Class Initialized
INFO - 2020-02-05 19:23:51 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:23:52 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:23:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:23:52 --> URI Class Initialized
INFO - 2020-02-05 19:23:52 --> Router Class Initialized
INFO - 2020-02-05 19:23:52 --> Output Class Initialized
INFO - 2020-02-05 19:23:52 --> Security Class Initialized
DEBUG - 2020-02-05 19:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:23:52 --> Input Class Initialized
INFO - 2020-02-05 19:23:52 --> Language Class Initialized
ERROR - 2020-02-05 19:23:52 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:24:19 --> Config Class Initialized
INFO - 2020-02-05 19:24:19 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:24:19 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:24:19 --> Utf8 Class Initialized
INFO - 2020-02-05 19:24:19 --> URI Class Initialized
INFO - 2020-02-05 19:24:19 --> Router Class Initialized
INFO - 2020-02-05 19:24:19 --> Output Class Initialized
INFO - 2020-02-05 19:24:19 --> Security Class Initialized
DEBUG - 2020-02-05 19:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:24:19 --> Input Class Initialized
INFO - 2020-02-05 19:24:20 --> Language Class Initialized
INFO - 2020-02-05 19:24:20 --> Loader Class Initialized
INFO - 2020-02-05 19:24:20 --> Helper loaded: url_helper
INFO - 2020-02-05 19:24:20 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:24:20 --> Controller Class Initialized
INFO - 2020-02-05 19:24:20 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:24:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:24:20 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:24:20 --> Helper loaded: form_helper
INFO - 2020-02-05 19:24:20 --> Form Validation Class Initialized
INFO - 2020-02-05 19:24:20 --> Final output sent to browser
DEBUG - 2020-02-05 19:24:20 --> Total execution time: 1.3205
INFO - 2020-02-05 19:28:13 --> Config Class Initialized
INFO - 2020-02-05 19:28:13 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:28:13 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:28:13 --> Utf8 Class Initialized
INFO - 2020-02-05 19:28:13 --> URI Class Initialized
INFO - 2020-02-05 19:28:14 --> Router Class Initialized
INFO - 2020-02-05 19:28:14 --> Output Class Initialized
INFO - 2020-02-05 19:28:14 --> Security Class Initialized
DEBUG - 2020-02-05 19:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:28:14 --> Input Class Initialized
INFO - 2020-02-05 19:28:14 --> Language Class Initialized
INFO - 2020-02-05 19:28:14 --> Loader Class Initialized
INFO - 2020-02-05 19:28:14 --> Helper loaded: url_helper
INFO - 2020-02-05 19:28:14 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:28:14 --> Controller Class Initialized
INFO - 2020-02-05 19:28:14 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:28:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:28:14 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:28:14 --> Helper loaded: form_helper
INFO - 2020-02-05 19:28:14 --> Form Validation Class Initialized
INFO - 2020-02-05 19:28:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:28:15 --> Final output sent to browser
INFO - 2020-02-05 19:28:15 --> Config Class Initialized
INFO - 2020-02-05 19:28:15 --> Config Class Initialized
INFO - 2020-02-05 19:28:15 --> Hooks Class Initialized
INFO - 2020-02-05 19:28:15 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:28:15 --> Total execution time: 1.3254
DEBUG - 2020-02-05 19:28:15 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:28:15 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:28:15 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:28:15 --> Utf8 Class Initialized
INFO - 2020-02-05 19:28:15 --> URI Class Initialized
INFO - 2020-02-05 19:28:15 --> URI Class Initialized
INFO - 2020-02-05 19:28:15 --> Router Class Initialized
INFO - 2020-02-05 19:28:15 --> Output Class Initialized
INFO - 2020-02-05 19:28:15 --> Router Class Initialized
INFO - 2020-02-05 19:28:15 --> Security Class Initialized
INFO - 2020-02-05 19:28:15 --> Output Class Initialized
INFO - 2020-02-05 19:28:15 --> Security Class Initialized
DEBUG - 2020-02-05 19:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:28:15 --> Input Class Initialized
DEBUG - 2020-02-05 19:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:28:15 --> Input Class Initialized
INFO - 2020-02-05 19:28:15 --> Language Class Initialized
INFO - 2020-02-05 19:28:15 --> Language Class Initialized
INFO - 2020-02-05 19:28:15 --> Loader Class Initialized
INFO - 2020-02-05 19:28:15 --> Helper loaded: url_helper
INFO - 2020-02-05 19:28:15 --> Loader Class Initialized
INFO - 2020-02-05 19:28:15 --> Helper loaded: url_helper
INFO - 2020-02-05 19:28:15 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:28:15 --> Database Driver Class Initialized
INFO - 2020-02-05 19:28:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:28:15 --> Controller Class Initialized
INFO - 2020-02-05 19:28:16 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:28:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:28:16 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:28:16 --> Helper loaded: form_helper
INFO - 2020-02-05 19:28:16 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:28:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:28:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:28:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:28:16 --> Final output sent to browser
DEBUG - 2020-02-05 19:28:16 --> Total execution time: 1.3676
INFO - 2020-02-05 19:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:28:16 --> Controller Class Initialized
INFO - 2020-02-05 19:28:16 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:28:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:28:16 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:28:16 --> Helper loaded: form_helper
INFO - 2020-02-05 19:28:16 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:28:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:28:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:28:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:28:17 --> Final output sent to browser
DEBUG - 2020-02-05 19:28:17 --> Total execution time: 1.9580
INFO - 2020-02-05 19:28:24 --> Config Class Initialized
INFO - 2020-02-05 19:28:24 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:28:24 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:28:24 --> Utf8 Class Initialized
INFO - 2020-02-05 19:28:24 --> URI Class Initialized
DEBUG - 2020-02-05 19:28:24 --> No URI present. Default controller set.
INFO - 2020-02-05 19:28:24 --> Router Class Initialized
INFO - 2020-02-05 19:28:25 --> Output Class Initialized
INFO - 2020-02-05 19:28:25 --> Security Class Initialized
DEBUG - 2020-02-05 19:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:28:25 --> Input Class Initialized
INFO - 2020-02-05 19:28:25 --> Language Class Initialized
INFO - 2020-02-05 19:28:25 --> Loader Class Initialized
INFO - 2020-02-05 19:28:25 --> Helper loaded: url_helper
INFO - 2020-02-05 19:28:25 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:28:25 --> Controller Class Initialized
INFO - 2020-02-05 19:28:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-05 19:28:25 --> Pagination Class Initialized
INFO - 2020-02-05 19:28:25 --> Model "M_show" initialized
INFO - 2020-02-05 19:28:25 --> Helper loaded: form_helper
INFO - 2020-02-05 19:28:25 --> Form Validation Class Initialized
INFO - 2020-02-05 19:28:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-05 19:28:26 --> Final output sent to browser
DEBUG - 2020-02-05 19:28:26 --> Total execution time: 1.5811
INFO - 2020-02-05 19:29:00 --> Config Class Initialized
INFO - 2020-02-05 19:29:01 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:29:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:01 --> URI Class Initialized
INFO - 2020-02-05 19:29:01 --> Router Class Initialized
INFO - 2020-02-05 19:29:01 --> Output Class Initialized
INFO - 2020-02-05 19:29:01 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:01 --> Input Class Initialized
INFO - 2020-02-05 19:29:01 --> Language Class Initialized
INFO - 2020-02-05 19:29:01 --> Loader Class Initialized
INFO - 2020-02-05 19:29:01 --> Helper loaded: url_helper
INFO - 2020-02-05 19:29:01 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:29:01 --> Controller Class Initialized
INFO - 2020-02-05 19:29:01 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:29:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:29:01 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:29:01 --> Helper loaded: form_helper
INFO - 2020-02-05 19:29:02 --> Form Validation Class Initialized
INFO - 2020-02-05 19:29:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:29:02 --> Final output sent to browser
INFO - 2020-02-05 19:29:02 --> Config Class Initialized
INFO - 2020-02-05 19:29:02 --> Config Class Initialized
INFO - 2020-02-05 19:29:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:29:02 --> Total execution time: 1.1516
INFO - 2020-02-05 19:29:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:29:02 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:02 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:02 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:02 --> URI Class Initialized
INFO - 2020-02-05 19:29:02 --> URI Class Initialized
INFO - 2020-02-05 19:29:02 --> Router Class Initialized
INFO - 2020-02-05 19:29:02 --> Router Class Initialized
INFO - 2020-02-05 19:29:02 --> Output Class Initialized
INFO - 2020-02-05 19:29:02 --> Output Class Initialized
INFO - 2020-02-05 19:29:02 --> Security Class Initialized
INFO - 2020-02-05 19:29:02 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:02 --> Input Class Initialized
INFO - 2020-02-05 19:29:02 --> Input Class Initialized
INFO - 2020-02-05 19:29:02 --> Language Class Initialized
INFO - 2020-02-05 19:29:02 --> Language Class Initialized
INFO - 2020-02-05 19:29:02 --> Loader Class Initialized
INFO - 2020-02-05 19:29:02 --> Loader Class Initialized
INFO - 2020-02-05 19:29:02 --> Helper loaded: url_helper
INFO - 2020-02-05 19:29:02 --> Helper loaded: url_helper
INFO - 2020-02-05 19:29:02 --> Database Driver Class Initialized
INFO - 2020-02-05 19:29:02 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:29:03 --> Controller Class Initialized
INFO - 2020-02-05 19:29:03 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:29:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:29:03 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:29:03 --> Helper loaded: form_helper
INFO - 2020-02-05 19:29:03 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:29:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:29:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:29:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:29:03 --> Final output sent to browser
DEBUG - 2020-02-05 19:29:03 --> Total execution time: 1.2405
INFO - 2020-02-05 19:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:29:03 --> Controller Class Initialized
INFO - 2020-02-05 19:29:03 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:29:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:29:03 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:29:03 --> Helper loaded: form_helper
INFO - 2020-02-05 19:29:03 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:29:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:29:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:29:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:29:04 --> Final output sent to browser
DEBUG - 2020-02-05 19:29:04 --> Total execution time: 1.8053
INFO - 2020-02-05 19:29:51 --> Config Class Initialized
INFO - 2020-02-05 19:29:51 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:29:51 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:52 --> URI Class Initialized
INFO - 2020-02-05 19:29:52 --> Router Class Initialized
INFO - 2020-02-05 19:29:52 --> Output Class Initialized
INFO - 2020-02-05 19:29:52 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:52 --> Input Class Initialized
INFO - 2020-02-05 19:29:52 --> Language Class Initialized
INFO - 2020-02-05 19:29:52 --> Loader Class Initialized
INFO - 2020-02-05 19:29:52 --> Helper loaded: url_helper
INFO - 2020-02-05 19:29:52 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:29:52 --> Controller Class Initialized
INFO - 2020-02-05 19:29:52 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:29:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:29:52 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:29:52 --> Helper loaded: form_helper
INFO - 2020-02-05 19:29:52 --> Form Validation Class Initialized
INFO - 2020-02-05 19:29:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:29:52 --> Final output sent to browser
INFO - 2020-02-05 19:29:53 --> Config Class Initialized
INFO - 2020-02-05 19:29:53 --> Config Class Initialized
INFO - 2020-02-05 19:29:53 --> Config Class Initialized
INFO - 2020-02-05 19:29:53 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:29:53 --> Total execution time: 1.2732
INFO - 2020-02-05 19:29:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:29:53 --> Config Class Initialized
INFO - 2020-02-05 19:29:53 --> Config Class Initialized
INFO - 2020-02-05 19:29:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:29:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:29:53 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:29:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:29:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:53 --> Config Class Initialized
INFO - 2020-02-05 19:29:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:29:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:53 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:29:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:29:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:29:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:53 --> URI Class Initialized
INFO - 2020-02-05 19:29:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:53 --> URI Class Initialized
DEBUG - 2020-02-05 19:29:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:53 --> URI Class Initialized
INFO - 2020-02-05 19:29:53 --> URI Class Initialized
INFO - 2020-02-05 19:29:53 --> Router Class Initialized
INFO - 2020-02-05 19:29:53 --> URI Class Initialized
INFO - 2020-02-05 19:29:53 --> Router Class Initialized
INFO - 2020-02-05 19:29:53 --> Router Class Initialized
INFO - 2020-02-05 19:29:53 --> Output Class Initialized
INFO - 2020-02-05 19:29:53 --> Router Class Initialized
INFO - 2020-02-05 19:29:53 --> Output Class Initialized
INFO - 2020-02-05 19:29:53 --> Router Class Initialized
INFO - 2020-02-05 19:29:53 --> URI Class Initialized
INFO - 2020-02-05 19:29:53 --> Security Class Initialized
INFO - 2020-02-05 19:29:53 --> Output Class Initialized
INFO - 2020-02-05 19:29:53 --> Security Class Initialized
INFO - 2020-02-05 19:29:53 --> Output Class Initialized
INFO - 2020-02-05 19:29:53 --> Output Class Initialized
INFO - 2020-02-05 19:29:53 --> Router Class Initialized
INFO - 2020-02-05 19:29:53 --> Security Class Initialized
INFO - 2020-02-05 19:29:53 --> Security Class Initialized
INFO - 2020-02-05 19:29:53 --> Output Class Initialized
DEBUG - 2020-02-05 19:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:53 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:53 --> Input Class Initialized
INFO - 2020-02-05 19:29:53 --> Input Class Initialized
DEBUG - 2020-02-05 19:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:53 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:53 --> Input Class Initialized
INFO - 2020-02-05 19:29:53 --> Input Class Initialized
INFO - 2020-02-05 19:29:53 --> Input Class Initialized
INFO - 2020-02-05 19:29:53 --> Language Class Initialized
INFO - 2020-02-05 19:29:53 --> Language Class Initialized
DEBUG - 2020-02-05 19:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:53 --> Input Class Initialized
INFO - 2020-02-05 19:29:53 --> Language Class Initialized
ERROR - 2020-02-05 19:29:53 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:29:53 --> Language Class Initialized
INFO - 2020-02-05 19:29:53 --> Language Class Initialized
ERROR - 2020-02-05 19:29:53 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:29:53 --> Language Class Initialized
ERROR - 2020-02-05 19:29:53 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 19:29:53 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 19:29:53 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:29:53 --> Config Class Initialized
INFO - 2020-02-05 19:29:53 --> Config Class Initialized
INFO - 2020-02-05 19:29:53 --> Hooks Class Initialized
ERROR - 2020-02-05 19:29:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:29:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:29:53 --> Config Class Initialized
INFO - 2020-02-05 19:29:53 --> Config Class Initialized
INFO - 2020-02-05 19:29:53 --> Config Class Initialized
INFO - 2020-02-05 19:29:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:29:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:29:53 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:29:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:29:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:53 --> Config Class Initialized
INFO - 2020-02-05 19:29:53 --> Hooks Class Initialized
INFO - 2020-02-05 19:29:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:53 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:29:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:29:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:29:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:53 --> URI Class Initialized
INFO - 2020-02-05 19:29:53 --> URI Class Initialized
DEBUG - 2020-02-05 19:29:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:53 --> URI Class Initialized
INFO - 2020-02-05 19:29:53 --> URI Class Initialized
INFO - 2020-02-05 19:29:53 --> URI Class Initialized
INFO - 2020-02-05 19:29:53 --> Router Class Initialized
INFO - 2020-02-05 19:29:53 --> Router Class Initialized
INFO - 2020-02-05 19:29:53 --> URI Class Initialized
INFO - 2020-02-05 19:29:53 --> Router Class Initialized
INFO - 2020-02-05 19:29:53 --> Router Class Initialized
INFO - 2020-02-05 19:29:53 --> Output Class Initialized
INFO - 2020-02-05 19:29:53 --> Router Class Initialized
INFO - 2020-02-05 19:29:53 --> Output Class Initialized
INFO - 2020-02-05 19:29:53 --> Output Class Initialized
INFO - 2020-02-05 19:29:53 --> Router Class Initialized
INFO - 2020-02-05 19:29:53 --> Output Class Initialized
INFO - 2020-02-05 19:29:53 --> Security Class Initialized
INFO - 2020-02-05 19:29:53 --> Output Class Initialized
INFO - 2020-02-05 19:29:53 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:53 --> Security Class Initialized
INFO - 2020-02-05 19:29:53 --> Output Class Initialized
INFO - 2020-02-05 19:29:53 --> Security Class Initialized
INFO - 2020-02-05 19:29:53 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:53 --> Input Class Initialized
INFO - 2020-02-05 19:29:53 --> Input Class Initialized
DEBUG - 2020-02-05 19:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:53 --> Security Class Initialized
INFO - 2020-02-05 19:29:54 --> Input Class Initialized
INFO - 2020-02-05 19:29:54 --> Language Class Initialized
DEBUG - 2020-02-05 19:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:54 --> Input Class Initialized
INFO - 2020-02-05 19:29:54 --> Input Class Initialized
INFO - 2020-02-05 19:29:54 --> Language Class Initialized
INFO - 2020-02-05 19:29:54 --> Language Class Initialized
INFO - 2020-02-05 19:29:54 --> Language Class Initialized
INFO - 2020-02-05 19:29:54 --> Language Class Initialized
INFO - 2020-02-05 19:29:54 --> Input Class Initialized
ERROR - 2020-02-05 19:29:54 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-05 19:29:54 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:29:54 --> Language Class Initialized
ERROR - 2020-02-05 19:29:54 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:29:54 --> Loader Class Initialized
INFO - 2020-02-05 19:29:54 --> Loader Class Initialized
INFO - 2020-02-05 19:29:54 --> Config Class Initialized
INFO - 2020-02-05 19:29:54 --> Config Class Initialized
INFO - 2020-02-05 19:29:54 --> Hooks Class Initialized
INFO - 2020-02-05 19:29:54 --> Hooks Class Initialized
INFO - 2020-02-05 19:29:54 --> Helper loaded: url_helper
INFO - 2020-02-05 19:29:54 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:29:54 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-05 19:29:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:29:54 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:54 --> Database Driver Class Initialized
INFO - 2020-02-05 19:29:54 --> Database Driver Class Initialized
INFO - 2020-02-05 19:29:54 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:54 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:29:54 --> URI Class Initialized
INFO - 2020-02-05 19:29:54 --> URI Class Initialized
INFO - 2020-02-05 19:29:54 --> Controller Class Initialized
INFO - 2020-02-05 19:29:54 --> Router Class Initialized
INFO - 2020-02-05 19:29:54 --> Router Class Initialized
INFO - 2020-02-05 19:29:54 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:29:54 --> Output Class Initialized
INFO - 2020-02-05 19:29:54 --> Output Class Initialized
INFO - 2020-02-05 19:29:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:29:54 --> Security Class Initialized
INFO - 2020-02-05 19:29:54 --> Security Class Initialized
INFO - 2020-02-05 19:29:54 --> Model "M_pesan" initialized
DEBUG - 2020-02-05 19:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:54 --> Input Class Initialized
INFO - 2020-02-05 19:29:54 --> Input Class Initialized
INFO - 2020-02-05 19:29:54 --> Helper loaded: form_helper
INFO - 2020-02-05 19:29:54 --> Form Validation Class Initialized
INFO - 2020-02-05 19:29:54 --> Language Class Initialized
INFO - 2020-02-05 19:29:54 --> Language Class Initialized
ERROR - 2020-02-05 19:29:54 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 19:29:54 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 19:29:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:29:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:29:54 --> Config Class Initialized
INFO - 2020-02-05 19:29:54 --> Hooks Class Initialized
INFO - 2020-02-05 19:29:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:29:54 --> Final output sent to browser
DEBUG - 2020-02-05 19:29:54 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:54 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:29:54 --> Total execution time: 1.1022
INFO - 2020-02-05 19:29:54 --> URI Class Initialized
INFO - 2020-02-05 19:29:54 --> Router Class Initialized
INFO - 2020-02-05 19:29:54 --> Output Class Initialized
INFO - 2020-02-05 19:29:55 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:55 --> Input Class Initialized
INFO - 2020-02-05 19:29:55 --> Language Class Initialized
ERROR - 2020-02-05 19:29:55 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:29:55 --> Config Class Initialized
INFO - 2020-02-05 19:29:55 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:29:55 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:55 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:55 --> URI Class Initialized
INFO - 2020-02-05 19:29:55 --> Router Class Initialized
INFO - 2020-02-05 19:29:55 --> Output Class Initialized
INFO - 2020-02-05 19:29:55 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:55 --> Input Class Initialized
INFO - 2020-02-05 19:29:55 --> Language Class Initialized
ERROR - 2020-02-05 19:29:55 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:29:55 --> Config Class Initialized
INFO - 2020-02-05 19:29:55 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:29:55 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:55 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:55 --> URI Class Initialized
INFO - 2020-02-05 19:29:56 --> Router Class Initialized
INFO - 2020-02-05 19:29:56 --> Output Class Initialized
INFO - 2020-02-05 19:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:29:56 --> Controller Class Initialized
INFO - 2020-02-05 19:29:56 --> Security Class Initialized
INFO - 2020-02-05 19:29:56 --> Model "M_tiket" initialized
DEBUG - 2020-02-05 19:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:56 --> Input Class Initialized
INFO - 2020-02-05 19:29:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:29:56 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:29:56 --> Language Class Initialized
ERROR - 2020-02-05 19:29:56 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:29:56 --> Helper loaded: form_helper
INFO - 2020-02-05 19:29:56 --> Form Validation Class Initialized
INFO - 2020-02-05 19:29:56 --> Config Class Initialized
INFO - 2020-02-05 19:29:56 --> Hooks Class Initialized
ERROR - 2020-02-05 19:29:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:29:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-05 19:29:56 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:56 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:29:56 --> Final output sent to browser
INFO - 2020-02-05 19:29:56 --> URI Class Initialized
DEBUG - 2020-02-05 19:29:56 --> Total execution time: 2.8800
INFO - 2020-02-05 19:29:56 --> Router Class Initialized
INFO - 2020-02-05 19:29:56 --> Output Class Initialized
INFO - 2020-02-05 19:29:56 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:56 --> Input Class Initialized
INFO - 2020-02-05 19:29:56 --> Language Class Initialized
ERROR - 2020-02-05 19:29:56 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:29:56 --> Config Class Initialized
INFO - 2020-02-05 19:29:56 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:29:56 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:56 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:57 --> URI Class Initialized
INFO - 2020-02-05 19:29:57 --> Router Class Initialized
INFO - 2020-02-05 19:29:57 --> Output Class Initialized
INFO - 2020-02-05 19:29:57 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:57 --> Input Class Initialized
INFO - 2020-02-05 19:29:57 --> Language Class Initialized
ERROR - 2020-02-05 19:29:57 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:29:57 --> Config Class Initialized
INFO - 2020-02-05 19:29:57 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:29:57 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:57 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:57 --> URI Class Initialized
INFO - 2020-02-05 19:29:57 --> Router Class Initialized
INFO - 2020-02-05 19:29:57 --> Output Class Initialized
INFO - 2020-02-05 19:29:57 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:57 --> Input Class Initialized
INFO - 2020-02-05 19:29:57 --> Language Class Initialized
ERROR - 2020-02-05 19:29:57 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:29:58 --> Config Class Initialized
INFO - 2020-02-05 19:29:58 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:29:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:58 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:58 --> URI Class Initialized
INFO - 2020-02-05 19:29:58 --> Router Class Initialized
INFO - 2020-02-05 19:29:58 --> Output Class Initialized
INFO - 2020-02-05 19:29:58 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:58 --> Input Class Initialized
INFO - 2020-02-05 19:29:58 --> Language Class Initialized
ERROR - 2020-02-05 19:29:58 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:29:58 --> Config Class Initialized
INFO - 2020-02-05 19:29:58 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:29:58 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:29:58 --> Utf8 Class Initialized
INFO - 2020-02-05 19:29:58 --> URI Class Initialized
INFO - 2020-02-05 19:29:58 --> Router Class Initialized
INFO - 2020-02-05 19:29:58 --> Output Class Initialized
INFO - 2020-02-05 19:29:58 --> Security Class Initialized
DEBUG - 2020-02-05 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:29:58 --> Input Class Initialized
INFO - 2020-02-05 19:29:58 --> Language Class Initialized
ERROR - 2020-02-05 19:29:59 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:30:04 --> Config Class Initialized
INFO - 2020-02-05 19:30:05 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:30:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:05 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:05 --> URI Class Initialized
INFO - 2020-02-05 19:30:05 --> Router Class Initialized
INFO - 2020-02-05 19:30:05 --> Output Class Initialized
INFO - 2020-02-05 19:30:05 --> Security Class Initialized
DEBUG - 2020-02-05 19:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:06 --> Input Class Initialized
INFO - 2020-02-05 19:30:06 --> Language Class Initialized
INFO - 2020-02-05 19:30:06 --> Loader Class Initialized
INFO - 2020-02-05 19:30:06 --> Helper loaded: url_helper
INFO - 2020-02-05 19:30:06 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:30:07 --> Controller Class Initialized
INFO - 2020-02-05 19:30:07 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:30:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:30:07 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:30:07 --> Helper loaded: form_helper
INFO - 2020-02-05 19:30:07 --> Form Validation Class Initialized
INFO - 2020-02-05 19:30:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:30:07 --> Final output sent to browser
INFO - 2020-02-05 19:30:08 --> Config Class Initialized
INFO - 2020-02-05 19:30:08 --> Config Class Initialized
INFO - 2020-02-05 19:30:08 --> Config Class Initialized
INFO - 2020-02-05 19:30:08 --> Config Class Initialized
INFO - 2020-02-05 19:30:08 --> Config Class Initialized
INFO - 2020-02-05 19:30:08 --> Hooks Class Initialized
INFO - 2020-02-05 19:30:08 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:30:08 --> Total execution time: 3.0932
INFO - 2020-02-05 19:30:08 --> Hooks Class Initialized
INFO - 2020-02-05 19:30:08 --> Hooks Class Initialized
INFO - 2020-02-05 19:30:08 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:30:08 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:08 --> Config Class Initialized
DEBUG - 2020-02-05 19:30:08 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:08 --> Hooks Class Initialized
INFO - 2020-02-05 19:30:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:08 --> URI Class Initialized
INFO - 2020-02-05 19:30:08 --> URI Class Initialized
INFO - 2020-02-05 19:30:08 --> URI Class Initialized
INFO - 2020-02-05 19:30:08 --> URI Class Initialized
INFO - 2020-02-05 19:30:08 --> URI Class Initialized
DEBUG - 2020-02-05 19:30:08 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:08 --> Router Class Initialized
INFO - 2020-02-05 19:30:08 --> Router Class Initialized
INFO - 2020-02-05 19:30:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:08 --> Router Class Initialized
INFO - 2020-02-05 19:30:08 --> Router Class Initialized
INFO - 2020-02-05 19:30:08 --> Router Class Initialized
INFO - 2020-02-05 19:30:08 --> Output Class Initialized
INFO - 2020-02-05 19:30:08 --> Output Class Initialized
INFO - 2020-02-05 19:30:08 --> Output Class Initialized
INFO - 2020-02-05 19:30:08 --> Output Class Initialized
INFO - 2020-02-05 19:30:08 --> URI Class Initialized
INFO - 2020-02-05 19:30:08 --> Output Class Initialized
INFO - 2020-02-05 19:30:08 --> Security Class Initialized
INFO - 2020-02-05 19:30:08 --> Security Class Initialized
INFO - 2020-02-05 19:30:08 --> Security Class Initialized
INFO - 2020-02-05 19:30:08 --> Router Class Initialized
INFO - 2020-02-05 19:30:08 --> Security Class Initialized
INFO - 2020-02-05 19:30:08 --> Security Class Initialized
DEBUG - 2020-02-05 19:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:08 --> Output Class Initialized
DEBUG - 2020-02-05 19:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:08 --> Input Class Initialized
INFO - 2020-02-05 19:30:08 --> Input Class Initialized
INFO - 2020-02-05 19:30:08 --> Input Class Initialized
INFO - 2020-02-05 19:30:08 --> Input Class Initialized
INFO - 2020-02-05 19:30:08 --> Input Class Initialized
INFO - 2020-02-05 19:30:08 --> Security Class Initialized
INFO - 2020-02-05 19:30:08 --> Language Class Initialized
INFO - 2020-02-05 19:30:08 --> Language Class Initialized
INFO - 2020-02-05 19:30:08 --> Language Class Initialized
INFO - 2020-02-05 19:30:08 --> Language Class Initialized
INFO - 2020-02-05 19:30:08 --> Language Class Initialized
DEBUG - 2020-02-05 19:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:08 --> Input Class Initialized
ERROR - 2020-02-05 19:30:08 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 19:30:08 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 19:30:08 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:30:08 --> Loader Class Initialized
INFO - 2020-02-05 19:30:08 --> Loader Class Initialized
INFO - 2020-02-05 19:30:08 --> Helper loaded: url_helper
INFO - 2020-02-05 19:30:08 --> Language Class Initialized
INFO - 2020-02-05 19:30:08 --> Helper loaded: url_helper
INFO - 2020-02-05 19:30:08 --> Config Class Initialized
INFO - 2020-02-05 19:30:08 --> Config Class Initialized
INFO - 2020-02-05 19:30:08 --> Config Class Initialized
INFO - 2020-02-05 19:30:08 --> Hooks Class Initialized
INFO - 2020-02-05 19:30:08 --> Hooks Class Initialized
INFO - 2020-02-05 19:30:08 --> Hooks Class Initialized
ERROR - 2020-02-05 19:30:08 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:30:08 --> Database Driver Class Initialized
INFO - 2020-02-05 19:30:08 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:30:08 --> Config Class Initialized
INFO - 2020-02-05 19:30:08 --> Hooks Class Initialized
INFO - 2020-02-05 19:30:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:30:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:08 --> URI Class Initialized
INFO - 2020-02-05 19:30:08 --> URI Class Initialized
INFO - 2020-02-05 19:30:08 --> URI Class Initialized
INFO - 2020-02-05 19:30:08 --> Controller Class Initialized
DEBUG - 2020-02-05 19:30:08 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:08 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:08 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:30:08 --> Router Class Initialized
INFO - 2020-02-05 19:30:08 --> Router Class Initialized
INFO - 2020-02-05 19:30:08 --> Router Class Initialized
INFO - 2020-02-05 19:30:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:30:09 --> URI Class Initialized
INFO - 2020-02-05 19:30:09 --> Output Class Initialized
INFO - 2020-02-05 19:30:09 --> Output Class Initialized
INFO - 2020-02-05 19:30:09 --> Output Class Initialized
INFO - 2020-02-05 19:30:09 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:30:09 --> Security Class Initialized
INFO - 2020-02-05 19:30:09 --> Security Class Initialized
INFO - 2020-02-05 19:30:09 --> Security Class Initialized
INFO - 2020-02-05 19:30:09 --> Router Class Initialized
DEBUG - 2020-02-05 19:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:09 --> Output Class Initialized
DEBUG - 2020-02-05 19:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:09 --> Helper loaded: form_helper
INFO - 2020-02-05 19:30:09 --> Form Validation Class Initialized
INFO - 2020-02-05 19:30:09 --> Input Class Initialized
INFO - 2020-02-05 19:30:09 --> Input Class Initialized
INFO - 2020-02-05 19:30:09 --> Input Class Initialized
INFO - 2020-02-05 19:30:09 --> Security Class Initialized
INFO - 2020-02-05 19:30:09 --> Language Class Initialized
INFO - 2020-02-05 19:30:09 --> Language Class Initialized
DEBUG - 2020-02-05 19:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:09 --> Language Class Initialized
ERROR - 2020-02-05 19:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:30:09 --> Input Class Initialized
ERROR - 2020-02-05 19:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:30:09 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:30:09 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:30:09 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:30:09 --> Language Class Initialized
INFO - 2020-02-05 19:30:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:30:09 --> Config Class Initialized
INFO - 2020-02-05 19:30:09 --> Config Class Initialized
INFO - 2020-02-05 19:30:09 --> Config Class Initialized
INFO - 2020-02-05 19:30:09 --> Hooks Class Initialized
INFO - 2020-02-05 19:30:09 --> Hooks Class Initialized
INFO - 2020-02-05 19:30:09 --> Hooks Class Initialized
INFO - 2020-02-05 19:30:09 --> Final output sent to browser
ERROR - 2020-02-05 19:30:09 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-05 19:30:09 --> Total execution time: 1.2206
DEBUG - 2020-02-05 19:30:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:30:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:30:09 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:09 --> Config Class Initialized
INFO - 2020-02-05 19:30:09 --> Hooks Class Initialized
INFO - 2020-02-05 19:30:09 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:09 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:09 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:30:09 --> URI Class Initialized
INFO - 2020-02-05 19:30:09 --> URI Class Initialized
DEBUG - 2020-02-05 19:30:09 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:09 --> Controller Class Initialized
INFO - 2020-02-05 19:30:09 --> URI Class Initialized
INFO - 2020-02-05 19:30:09 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:09 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:30:09 --> Router Class Initialized
INFO - 2020-02-05 19:30:09 --> Router Class Initialized
INFO - 2020-02-05 19:30:09 --> Router Class Initialized
INFO - 2020-02-05 19:30:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:30:09 --> URI Class Initialized
INFO - 2020-02-05 19:30:09 --> Output Class Initialized
INFO - 2020-02-05 19:30:09 --> Output Class Initialized
INFO - 2020-02-05 19:30:09 --> Output Class Initialized
INFO - 2020-02-05 19:30:09 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:30:09 --> Security Class Initialized
INFO - 2020-02-05 19:30:09 --> Security Class Initialized
INFO - 2020-02-05 19:30:09 --> Router Class Initialized
INFO - 2020-02-05 19:30:09 --> Security Class Initialized
DEBUG - 2020-02-05 19:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:09 --> Output Class Initialized
DEBUG - 2020-02-05 19:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:09 --> Helper loaded: form_helper
INFO - 2020-02-05 19:30:09 --> Input Class Initialized
INFO - 2020-02-05 19:30:09 --> Input Class Initialized
INFO - 2020-02-05 19:30:09 --> Form Validation Class Initialized
INFO - 2020-02-05 19:30:09 --> Input Class Initialized
INFO - 2020-02-05 19:30:09 --> Security Class Initialized
INFO - 2020-02-05 19:30:09 --> Language Class Initialized
DEBUG - 2020-02-05 19:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:09 --> Language Class Initialized
INFO - 2020-02-05 19:30:09 --> Language Class Initialized
ERROR - 2020-02-05 19:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:30:09 --> Input Class Initialized
ERROR - 2020-02-05 19:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:30:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 19:30:09 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 19:30:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:30:09 --> Language Class Initialized
INFO - 2020-02-05 19:30:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:30:09 --> Final output sent to browser
ERROR - 2020-02-05 19:30:09 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-05 19:30:09 --> Total execution time: 1.7841
INFO - 2020-02-05 19:30:09 --> Config Class Initialized
INFO - 2020-02-05 19:30:10 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:30:10 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:10 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:10 --> URI Class Initialized
INFO - 2020-02-05 19:30:10 --> Router Class Initialized
INFO - 2020-02-05 19:30:10 --> Output Class Initialized
INFO - 2020-02-05 19:30:10 --> Security Class Initialized
DEBUG - 2020-02-05 19:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:10 --> Input Class Initialized
INFO - 2020-02-05 19:30:10 --> Language Class Initialized
ERROR - 2020-02-05 19:30:10 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:30:10 --> Config Class Initialized
INFO - 2020-02-05 19:30:10 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:30:10 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:10 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:10 --> URI Class Initialized
INFO - 2020-02-05 19:30:10 --> Router Class Initialized
INFO - 2020-02-05 19:30:10 --> Output Class Initialized
INFO - 2020-02-05 19:30:10 --> Security Class Initialized
DEBUG - 2020-02-05 19:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:10 --> Input Class Initialized
INFO - 2020-02-05 19:30:11 --> Language Class Initialized
ERROR - 2020-02-05 19:30:11 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:30:11 --> Config Class Initialized
INFO - 2020-02-05 19:30:11 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:30:11 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:11 --> URI Class Initialized
INFO - 2020-02-05 19:30:11 --> Router Class Initialized
INFO - 2020-02-05 19:30:11 --> Output Class Initialized
INFO - 2020-02-05 19:30:11 --> Security Class Initialized
DEBUG - 2020-02-05 19:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:11 --> Input Class Initialized
INFO - 2020-02-05 19:30:11 --> Language Class Initialized
ERROR - 2020-02-05 19:30:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:30:11 --> Config Class Initialized
INFO - 2020-02-05 19:30:11 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:30:11 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:11 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:11 --> URI Class Initialized
INFO - 2020-02-05 19:30:11 --> Router Class Initialized
INFO - 2020-02-05 19:30:12 --> Output Class Initialized
INFO - 2020-02-05 19:30:12 --> Security Class Initialized
DEBUG - 2020-02-05 19:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:12 --> Input Class Initialized
INFO - 2020-02-05 19:30:12 --> Language Class Initialized
ERROR - 2020-02-05 19:30:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:30:12 --> Config Class Initialized
INFO - 2020-02-05 19:30:12 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:30:12 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:12 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:12 --> URI Class Initialized
INFO - 2020-02-05 19:30:12 --> Router Class Initialized
INFO - 2020-02-05 19:30:12 --> Output Class Initialized
INFO - 2020-02-05 19:30:12 --> Security Class Initialized
DEBUG - 2020-02-05 19:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:12 --> Input Class Initialized
INFO - 2020-02-05 19:30:12 --> Language Class Initialized
ERROR - 2020-02-05 19:30:12 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:30:12 --> Config Class Initialized
INFO - 2020-02-05 19:30:12 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:30:12 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:12 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:13 --> URI Class Initialized
INFO - 2020-02-05 19:30:13 --> Router Class Initialized
INFO - 2020-02-05 19:30:13 --> Output Class Initialized
INFO - 2020-02-05 19:30:13 --> Security Class Initialized
DEBUG - 2020-02-05 19:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:13 --> Input Class Initialized
INFO - 2020-02-05 19:30:13 --> Language Class Initialized
ERROR - 2020-02-05 19:30:13 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:30:13 --> Config Class Initialized
INFO - 2020-02-05 19:30:13 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:30:13 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:13 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:13 --> URI Class Initialized
INFO - 2020-02-05 19:30:13 --> Router Class Initialized
INFO - 2020-02-05 19:30:13 --> Output Class Initialized
INFO - 2020-02-05 19:30:13 --> Security Class Initialized
DEBUG - 2020-02-05 19:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:13 --> Input Class Initialized
INFO - 2020-02-05 19:30:13 --> Language Class Initialized
ERROR - 2020-02-05 19:30:13 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:30:13 --> Config Class Initialized
INFO - 2020-02-05 19:30:13 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:30:14 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:30:14 --> Utf8 Class Initialized
INFO - 2020-02-05 19:30:14 --> URI Class Initialized
INFO - 2020-02-05 19:30:14 --> Router Class Initialized
INFO - 2020-02-05 19:30:14 --> Output Class Initialized
INFO - 2020-02-05 19:30:14 --> Security Class Initialized
DEBUG - 2020-02-05 19:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:30:14 --> Input Class Initialized
INFO - 2020-02-05 19:30:14 --> Language Class Initialized
ERROR - 2020-02-05 19:30:14 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:31:29 --> Config Class Initialized
INFO - 2020-02-05 19:31:29 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:29 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:29 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:29 --> URI Class Initialized
INFO - 2020-02-05 19:31:29 --> Router Class Initialized
INFO - 2020-02-05 19:31:29 --> Output Class Initialized
INFO - 2020-02-05 19:31:29 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:29 --> Input Class Initialized
INFO - 2020-02-05 19:31:29 --> Language Class Initialized
INFO - 2020-02-05 19:31:29 --> Loader Class Initialized
INFO - 2020-02-05 19:31:29 --> Helper loaded: url_helper
INFO - 2020-02-05 19:31:29 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:31:29 --> Controller Class Initialized
INFO - 2020-02-05 19:31:29 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:31:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:31:30 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:31:30 --> Helper loaded: form_helper
INFO - 2020-02-05 19:31:30 --> Form Validation Class Initialized
INFO - 2020-02-05 19:31:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:31:30 --> Final output sent to browser
INFO - 2020-02-05 19:31:30 --> Config Class Initialized
INFO - 2020-02-05 19:31:30 --> Config Class Initialized
INFO - 2020-02-05 19:31:30 --> Config Class Initialized
INFO - 2020-02-05 19:31:30 --> Config Class Initialized
INFO - 2020-02-05 19:31:30 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:30 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:30 --> Total execution time: 0.9966
INFO - 2020-02-05 19:31:30 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:30 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:30 --> Config Class Initialized
INFO - 2020-02-05 19:31:30 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:30 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:31:30 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:31:30 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:31:30 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:30 --> Config Class Initialized
INFO - 2020-02-05 19:31:30 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:30 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:30 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:30 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:30 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:31:30 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:30 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:30 --> URI Class Initialized
INFO - 2020-02-05 19:31:30 --> URI Class Initialized
INFO - 2020-02-05 19:31:30 --> URI Class Initialized
INFO - 2020-02-05 19:31:30 --> URI Class Initialized
DEBUG - 2020-02-05 19:31:30 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:30 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:30 --> URI Class Initialized
INFO - 2020-02-05 19:31:30 --> Router Class Initialized
INFO - 2020-02-05 19:31:30 --> Router Class Initialized
INFO - 2020-02-05 19:31:30 --> Router Class Initialized
INFO - 2020-02-05 19:31:30 --> Router Class Initialized
INFO - 2020-02-05 19:31:30 --> URI Class Initialized
INFO - 2020-02-05 19:31:30 --> Output Class Initialized
INFO - 2020-02-05 19:31:30 --> Router Class Initialized
INFO - 2020-02-05 19:31:30 --> Output Class Initialized
INFO - 2020-02-05 19:31:30 --> Output Class Initialized
INFO - 2020-02-05 19:31:30 --> Output Class Initialized
INFO - 2020-02-05 19:31:30 --> Security Class Initialized
INFO - 2020-02-05 19:31:30 --> Security Class Initialized
INFO - 2020-02-05 19:31:30 --> Output Class Initialized
INFO - 2020-02-05 19:31:30 --> Security Class Initialized
INFO - 2020-02-05 19:31:30 --> Security Class Initialized
INFO - 2020-02-05 19:31:30 --> Router Class Initialized
DEBUG - 2020-02-05 19:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:30 --> Security Class Initialized
INFO - 2020-02-05 19:31:30 --> Output Class Initialized
DEBUG - 2020-02-05 19:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:30 --> Input Class Initialized
INFO - 2020-02-05 19:31:30 --> Input Class Initialized
INFO - 2020-02-05 19:31:30 --> Input Class Initialized
INFO - 2020-02-05 19:31:30 --> Input Class Initialized
INFO - 2020-02-05 19:31:30 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:30 --> Input Class Initialized
INFO - 2020-02-05 19:31:30 --> Language Class Initialized
DEBUG - 2020-02-05 19:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:30 --> Language Class Initialized
INFO - 2020-02-05 19:31:30 --> Language Class Initialized
INFO - 2020-02-05 19:31:30 --> Language Class Initialized
INFO - 2020-02-05 19:31:30 --> Input Class Initialized
INFO - 2020-02-05 19:31:30 --> Language Class Initialized
ERROR - 2020-02-05 19:31:30 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 19:31:30 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-05 19:31:30 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:31:30 --> Loader Class Initialized
INFO - 2020-02-05 19:31:30 --> Language Class Initialized
INFO - 2020-02-05 19:31:30 --> Helper loaded: url_helper
INFO - 2020-02-05 19:31:30 --> Loader Class Initialized
INFO - 2020-02-05 19:31:30 --> Config Class Initialized
INFO - 2020-02-05 19:31:30 --> Config Class Initialized
INFO - 2020-02-05 19:31:30 --> Config Class Initialized
INFO - 2020-02-05 19:31:30 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:30 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:30 --> Hooks Class Initialized
ERROR - 2020-02-05 19:31:30 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:31:30 --> Helper loaded: url_helper
INFO - 2020-02-05 19:31:30 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:31:30 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:31:30 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:30 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:31:30 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:31 --> Config Class Initialized
INFO - 2020-02-05 19:31:31 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:31 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:31:31 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:31 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:31:31 --> Controller Class Initialized
INFO - 2020-02-05 19:31:31 --> URI Class Initialized
INFO - 2020-02-05 19:31:31 --> URI Class Initialized
INFO - 2020-02-05 19:31:31 --> URI Class Initialized
DEBUG - 2020-02-05 19:31:31 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:31 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:31 --> Router Class Initialized
INFO - 2020-02-05 19:31:31 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:31:31 --> Router Class Initialized
INFO - 2020-02-05 19:31:31 --> Router Class Initialized
INFO - 2020-02-05 19:31:31 --> URI Class Initialized
INFO - 2020-02-05 19:31:31 --> Output Class Initialized
INFO - 2020-02-05 19:31:31 --> Output Class Initialized
INFO - 2020-02-05 19:31:31 --> Output Class Initialized
INFO - 2020-02-05 19:31:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:31:31 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:31:31 --> Security Class Initialized
INFO - 2020-02-05 19:31:31 --> Security Class Initialized
INFO - 2020-02-05 19:31:31 --> Router Class Initialized
INFO - 2020-02-05 19:31:31 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:31 --> Output Class Initialized
INFO - 2020-02-05 19:31:31 --> Helper loaded: form_helper
INFO - 2020-02-05 19:31:31 --> Form Validation Class Initialized
INFO - 2020-02-05 19:31:31 --> Input Class Initialized
INFO - 2020-02-05 19:31:31 --> Input Class Initialized
INFO - 2020-02-05 19:31:31 --> Input Class Initialized
INFO - 2020-02-05 19:31:31 --> Security Class Initialized
INFO - 2020-02-05 19:31:31 --> Language Class Initialized
INFO - 2020-02-05 19:31:31 --> Language Class Initialized
DEBUG - 2020-02-05 19:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:31 --> Language Class Initialized
ERROR - 2020-02-05 19:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:31:31 --> Input Class Initialized
ERROR - 2020-02-05 19:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:31:31 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:31:31 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:31:31 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:31:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:31:31 --> Language Class Initialized
INFO - 2020-02-05 19:31:31 --> Config Class Initialized
INFO - 2020-02-05 19:31:31 --> Config Class Initialized
INFO - 2020-02-05 19:31:31 --> Config Class Initialized
INFO - 2020-02-05 19:31:31 --> Final output sent to browser
INFO - 2020-02-05 19:31:31 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:31 --> Hooks Class Initialized
ERROR - 2020-02-05 19:31:31 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:31:31 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:31 --> Total execution time: 1.1595
DEBUG - 2020-02-05 19:31:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:31:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:31:31 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:31 --> Config Class Initialized
INFO - 2020-02-05 19:31:31 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:31 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:31 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:31 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:31:31 --> Controller Class Initialized
INFO - 2020-02-05 19:31:31 --> URI Class Initialized
INFO - 2020-02-05 19:31:31 --> URI Class Initialized
INFO - 2020-02-05 19:31:31 --> URI Class Initialized
DEBUG - 2020-02-05 19:31:31 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:31 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:31 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:31:31 --> Router Class Initialized
INFO - 2020-02-05 19:31:31 --> Router Class Initialized
INFO - 2020-02-05 19:31:31 --> Router Class Initialized
INFO - 2020-02-05 19:31:31 --> Output Class Initialized
INFO - 2020-02-05 19:31:31 --> URI Class Initialized
INFO - 2020-02-05 19:31:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:31:31 --> Output Class Initialized
INFO - 2020-02-05 19:31:31 --> Output Class Initialized
INFO - 2020-02-05 19:31:31 --> Router Class Initialized
INFO - 2020-02-05 19:31:31 --> Security Class Initialized
INFO - 2020-02-05 19:31:31 --> Security Class Initialized
INFO - 2020-02-05 19:31:31 --> Security Class Initialized
INFO - 2020-02-05 19:31:31 --> Model "M_pesan" initialized
DEBUG - 2020-02-05 19:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:31 --> Output Class Initialized
INFO - 2020-02-05 19:31:31 --> Helper loaded: form_helper
INFO - 2020-02-05 19:31:31 --> Input Class Initialized
INFO - 2020-02-05 19:31:31 --> Form Validation Class Initialized
INFO - 2020-02-05 19:31:31 --> Input Class Initialized
INFO - 2020-02-05 19:31:31 --> Input Class Initialized
INFO - 2020-02-05 19:31:31 --> Security Class Initialized
INFO - 2020-02-05 19:31:31 --> Language Class Initialized
INFO - 2020-02-05 19:31:31 --> Language Class Initialized
INFO - 2020-02-05 19:31:31 --> Language Class Initialized
DEBUG - 2020-02-05 19:31:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 19:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:31:31 --> Input Class Initialized
ERROR - 2020-02-05 19:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-05 19:31:31 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:31:31 --> Language Class Initialized
ERROR - 2020-02-05 19:31:31 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-05 19:31:31 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 19:31:32 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-05 19:31:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:31:32 --> Final output sent to browser
INFO - 2020-02-05 19:31:32 --> Config Class Initialized
INFO - 2020-02-05 19:31:32 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:32 --> Total execution time: 1.7060
DEBUG - 2020-02-05 19:31:32 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:32 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:32 --> URI Class Initialized
INFO - 2020-02-05 19:31:32 --> Router Class Initialized
INFO - 2020-02-05 19:31:32 --> Output Class Initialized
INFO - 2020-02-05 19:31:32 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:32 --> Input Class Initialized
INFO - 2020-02-05 19:31:32 --> Language Class Initialized
ERROR - 2020-02-05 19:31:32 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:31:32 --> Config Class Initialized
INFO - 2020-02-05 19:31:32 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:32 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:32 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:32 --> URI Class Initialized
INFO - 2020-02-05 19:31:32 --> Router Class Initialized
INFO - 2020-02-05 19:31:32 --> Output Class Initialized
INFO - 2020-02-05 19:31:32 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:33 --> Input Class Initialized
INFO - 2020-02-05 19:31:33 --> Language Class Initialized
ERROR - 2020-02-05 19:31:33 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:31:33 --> Config Class Initialized
INFO - 2020-02-05 19:31:33 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:33 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:33 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:33 --> URI Class Initialized
INFO - 2020-02-05 19:31:33 --> Router Class Initialized
INFO - 2020-02-05 19:31:33 --> Output Class Initialized
INFO - 2020-02-05 19:31:33 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:33 --> Input Class Initialized
INFO - 2020-02-05 19:31:33 --> Language Class Initialized
ERROR - 2020-02-05 19:31:33 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:31:33 --> Config Class Initialized
INFO - 2020-02-05 19:31:33 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:34 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:34 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:34 --> URI Class Initialized
INFO - 2020-02-05 19:31:34 --> Router Class Initialized
INFO - 2020-02-05 19:31:34 --> Output Class Initialized
INFO - 2020-02-05 19:31:34 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:34 --> Input Class Initialized
INFO - 2020-02-05 19:31:34 --> Language Class Initialized
ERROR - 2020-02-05 19:31:34 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:31:34 --> Config Class Initialized
INFO - 2020-02-05 19:31:34 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:34 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:34 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:34 --> URI Class Initialized
INFO - 2020-02-05 19:31:34 --> Router Class Initialized
INFO - 2020-02-05 19:31:34 --> Output Class Initialized
INFO - 2020-02-05 19:31:34 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:34 --> Input Class Initialized
INFO - 2020-02-05 19:31:34 --> Language Class Initialized
ERROR - 2020-02-05 19:31:34 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:31:35 --> Config Class Initialized
INFO - 2020-02-05 19:31:35 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:35 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:35 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:35 --> URI Class Initialized
INFO - 2020-02-05 19:31:35 --> Router Class Initialized
INFO - 2020-02-05 19:31:35 --> Output Class Initialized
INFO - 2020-02-05 19:31:35 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:35 --> Input Class Initialized
INFO - 2020-02-05 19:31:35 --> Language Class Initialized
ERROR - 2020-02-05 19:31:35 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:31:35 --> Config Class Initialized
INFO - 2020-02-05 19:31:35 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:35 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:35 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:35 --> URI Class Initialized
INFO - 2020-02-05 19:31:35 --> Router Class Initialized
INFO - 2020-02-05 19:31:35 --> Output Class Initialized
INFO - 2020-02-05 19:31:35 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:35 --> Input Class Initialized
INFO - 2020-02-05 19:31:36 --> Language Class Initialized
ERROR - 2020-02-05 19:31:36 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:31:36 --> Config Class Initialized
INFO - 2020-02-05 19:31:36 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:36 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:36 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:36 --> URI Class Initialized
INFO - 2020-02-05 19:31:36 --> Router Class Initialized
INFO - 2020-02-05 19:31:36 --> Output Class Initialized
INFO - 2020-02-05 19:31:36 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:36 --> Input Class Initialized
INFO - 2020-02-05 19:31:36 --> Language Class Initialized
ERROR - 2020-02-05 19:31:36 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:31:36 --> Config Class Initialized
INFO - 2020-02-05 19:31:36 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:36 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:36 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:36 --> URI Class Initialized
INFO - 2020-02-05 19:31:36 --> Router Class Initialized
INFO - 2020-02-05 19:31:36 --> Output Class Initialized
INFO - 2020-02-05 19:31:36 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:37 --> Input Class Initialized
INFO - 2020-02-05 19:31:37 --> Language Class Initialized
ERROR - 2020-02-05 19:31:37 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:31:37 --> Config Class Initialized
INFO - 2020-02-05 19:31:37 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:37 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:37 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:37 --> URI Class Initialized
DEBUG - 2020-02-05 19:31:37 --> No URI present. Default controller set.
INFO - 2020-02-05 19:31:37 --> Router Class Initialized
INFO - 2020-02-05 19:31:37 --> Output Class Initialized
INFO - 2020-02-05 19:31:37 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:37 --> Input Class Initialized
INFO - 2020-02-05 19:31:37 --> Language Class Initialized
INFO - 2020-02-05 19:31:37 --> Loader Class Initialized
INFO - 2020-02-05 19:31:37 --> Helper loaded: url_helper
INFO - 2020-02-05 19:31:37 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:31:37 --> Controller Class Initialized
INFO - 2020-02-05 19:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-05 19:31:38 --> Pagination Class Initialized
INFO - 2020-02-05 19:31:38 --> Model "M_show" initialized
INFO - 2020-02-05 19:31:38 --> Helper loaded: form_helper
INFO - 2020-02-05 19:31:38 --> Form Validation Class Initialized
INFO - 2020-02-05 19:31:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-05 19:31:38 --> Final output sent to browser
DEBUG - 2020-02-05 19:31:38 --> Total execution time: 1.0914
INFO - 2020-02-05 19:31:40 --> Config Class Initialized
INFO - 2020-02-05 19:31:41 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:41 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:41 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:41 --> URI Class Initialized
INFO - 2020-02-05 19:31:41 --> Router Class Initialized
INFO - 2020-02-05 19:31:41 --> Output Class Initialized
INFO - 2020-02-05 19:31:41 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:42 --> Input Class Initialized
INFO - 2020-02-05 19:31:42 --> Language Class Initialized
INFO - 2020-02-05 19:31:42 --> Loader Class Initialized
INFO - 2020-02-05 19:31:42 --> Helper loaded: url_helper
INFO - 2020-02-05 19:31:42 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:31:42 --> Controller Class Initialized
INFO - 2020-02-05 19:31:42 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:31:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:31:42 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:31:42 --> Helper loaded: form_helper
INFO - 2020-02-05 19:31:42 --> Form Validation Class Initialized
INFO - 2020-02-05 19:31:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:31:42 --> Final output sent to browser
INFO - 2020-02-05 19:31:42 --> Config Class Initialized
INFO - 2020-02-05 19:31:42 --> Config Class Initialized
INFO - 2020-02-05 19:31:42 --> Config Class Initialized
INFO - 2020-02-05 19:31:42 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:42 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:42 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:42 --> Total execution time: 1.8915
DEBUG - 2020-02-05 19:31:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:42 --> Config Class Initialized
INFO - 2020-02-05 19:31:42 --> Config Class Initialized
INFO - 2020-02-05 19:31:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:42 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:31:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:42 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:42 --> Config Class Initialized
INFO - 2020-02-05 19:31:42 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:42 --> URI Class Initialized
DEBUG - 2020-02-05 19:31:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:42 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:42 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:31:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:43 --> URI Class Initialized
INFO - 2020-02-05 19:31:43 --> URI Class Initialized
INFO - 2020-02-05 19:31:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:43 --> Router Class Initialized
DEBUG - 2020-02-05 19:31:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:43 --> Router Class Initialized
INFO - 2020-02-05 19:31:43 --> Output Class Initialized
INFO - 2020-02-05 19:31:43 --> Router Class Initialized
INFO - 2020-02-05 19:31:43 --> URI Class Initialized
INFO - 2020-02-05 19:31:43 --> URI Class Initialized
INFO - 2020-02-05 19:31:43 --> Router Class Initialized
INFO - 2020-02-05 19:31:43 --> Output Class Initialized
INFO - 2020-02-05 19:31:43 --> Output Class Initialized
INFO - 2020-02-05 19:31:43 --> Router Class Initialized
INFO - 2020-02-05 19:31:43 --> URI Class Initialized
INFO - 2020-02-05 19:31:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:43 --> Output Class Initialized
INFO - 2020-02-05 19:31:43 --> Output Class Initialized
INFO - 2020-02-05 19:31:43 --> Security Class Initialized
INFO - 2020-02-05 19:31:43 --> Router Class Initialized
INFO - 2020-02-05 19:31:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:43 --> Security Class Initialized
INFO - 2020-02-05 19:31:43 --> Input Class Initialized
INFO - 2020-02-05 19:31:43 --> Output Class Initialized
INFO - 2020-02-05 19:31:43 --> Security Class Initialized
INFO - 2020-02-05 19:31:43 --> Input Class Initialized
INFO - 2020-02-05 19:31:43 --> Input Class Initialized
INFO - 2020-02-05 19:31:43 --> Language Class Initialized
DEBUG - 2020-02-05 19:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:43 --> Input Class Initialized
INFO - 2020-02-05 19:31:43 --> Language Class Initialized
INFO - 2020-02-05 19:31:43 --> Language Class Initialized
INFO - 2020-02-05 19:31:43 --> Input Class Initialized
ERROR - 2020-02-05 19:31:43 --> 404 Page Not Found: Bower_components/jquery
DEBUG - 2020-02-05 19:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:43 --> Input Class Initialized
INFO - 2020-02-05 19:31:43 --> Language Class Initialized
ERROR - 2020-02-05 19:31:43 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 19:31:43 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:31:43 --> Language Class Initialized
INFO - 2020-02-05 19:31:43 --> Config Class Initialized
INFO - 2020-02-05 19:31:43 --> Hooks Class Initialized
ERROR - 2020-02-05 19:31:43 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-05 19:31:43 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:31:43 --> Language Class Initialized
INFO - 2020-02-05 19:31:43 --> Config Class Initialized
INFO - 2020-02-05 19:31:43 --> Config Class Initialized
INFO - 2020-02-05 19:31:43 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:43 --> Hooks Class Initialized
ERROR - 2020-02-05 19:31:43 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-05 19:31:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:43 --> Config Class Initialized
INFO - 2020-02-05 19:31:43 --> Config Class Initialized
INFO - 2020-02-05 19:31:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:43 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:31:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:43 --> Config Class Initialized
INFO - 2020-02-05 19:31:43 --> Hooks Class Initialized
INFO - 2020-02-05 19:31:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:43 --> URI Class Initialized
INFO - 2020-02-05 19:31:43 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:31:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:31:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:43 --> URI Class Initialized
INFO - 2020-02-05 19:31:43 --> Router Class Initialized
INFO - 2020-02-05 19:31:43 --> URI Class Initialized
DEBUG - 2020-02-05 19:31:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:43 --> URI Class Initialized
INFO - 2020-02-05 19:31:43 --> Output Class Initialized
INFO - 2020-02-05 19:31:43 --> Router Class Initialized
INFO - 2020-02-05 19:31:43 --> URI Class Initialized
INFO - 2020-02-05 19:31:43 --> Router Class Initialized
INFO - 2020-02-05 19:31:43 --> Router Class Initialized
INFO - 2020-02-05 19:31:43 --> Router Class Initialized
INFO - 2020-02-05 19:31:43 --> Output Class Initialized
INFO - 2020-02-05 19:31:43 --> URI Class Initialized
INFO - 2020-02-05 19:31:43 --> Security Class Initialized
INFO - 2020-02-05 19:31:43 --> Output Class Initialized
INFO - 2020-02-05 19:31:43 --> Security Class Initialized
INFO - 2020-02-05 19:31:43 --> Security Class Initialized
INFO - 2020-02-05 19:31:43 --> Router Class Initialized
DEBUG - 2020-02-05 19:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:43 --> Output Class Initialized
INFO - 2020-02-05 19:31:43 --> Output Class Initialized
INFO - 2020-02-05 19:31:43 --> Input Class Initialized
DEBUG - 2020-02-05 19:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:43 --> Security Class Initialized
INFO - 2020-02-05 19:31:43 --> Security Class Initialized
INFO - 2020-02-05 19:31:43 --> Output Class Initialized
DEBUG - 2020-02-05 19:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:43 --> Input Class Initialized
DEBUG - 2020-02-05 19:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:43 --> Input Class Initialized
INFO - 2020-02-05 19:31:43 --> Security Class Initialized
INFO - 2020-02-05 19:31:43 --> Language Class Initialized
INFO - 2020-02-05 19:31:43 --> Input Class Initialized
INFO - 2020-02-05 19:31:43 --> Input Class Initialized
INFO - 2020-02-05 19:31:43 --> Language Class Initialized
INFO - 2020-02-05 19:31:43 --> Language Class Initialized
ERROR - 2020-02-05 19:31:43 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-05 19:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:43 --> Input Class Initialized
INFO - 2020-02-05 19:31:43 --> Language Class Initialized
INFO - 2020-02-05 19:31:43 --> Language Class Initialized
ERROR - 2020-02-05 19:31:43 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-05 19:31:43 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:31:43 --> Config Class Initialized
INFO - 2020-02-05 19:31:43 --> Hooks Class Initialized
ERROR - 2020-02-05 19:31:44 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 19:31:44 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:31:44 --> Language Class Initialized
INFO - 2020-02-05 19:31:44 --> Config Class Initialized
INFO - 2020-02-05 19:31:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:44 --> Loader Class Initialized
INFO - 2020-02-05 19:31:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:44 --> Helper loaded: url_helper
DEBUG - 2020-02-05 19:31:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:44 --> URI Class Initialized
INFO - 2020-02-05 19:31:44 --> Database Driver Class Initialized
INFO - 2020-02-05 19:31:44 --> URI Class Initialized
INFO - 2020-02-05 19:31:44 --> Router Class Initialized
DEBUG - 2020-02-05 19:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:31:44 --> Router Class Initialized
INFO - 2020-02-05 19:31:44 --> Output Class Initialized
INFO - 2020-02-05 19:31:44 --> Controller Class Initialized
INFO - 2020-02-05 19:31:44 --> Security Class Initialized
INFO - 2020-02-05 19:31:44 --> Output Class Initialized
INFO - 2020-02-05 19:31:44 --> Security Class Initialized
INFO - 2020-02-05 19:31:44 --> Model "M_tiket" initialized
DEBUG - 2020-02-05 19:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:44 --> Input Class Initialized
INFO - 2020-02-05 19:31:44 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-05 19:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:44 --> Input Class Initialized
INFO - 2020-02-05 19:31:44 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:31:44 --> Language Class Initialized
INFO - 2020-02-05 19:31:44 --> Language Class Initialized
INFO - 2020-02-05 19:31:44 --> Loader Class Initialized
INFO - 2020-02-05 19:31:44 --> Helper loaded: form_helper
INFO - 2020-02-05 19:31:44 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:31:44 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:31:44 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:31:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:31:44 --> Database Driver Class Initialized
INFO - 2020-02-05 19:31:44 --> Config Class Initialized
INFO - 2020-02-05 19:31:44 --> Hooks Class Initialized
ERROR - 2020-02-05 19:31:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-05 19:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:31:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-05 19:31:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:44 --> Final output sent to browser
DEBUG - 2020-02-05 19:31:44 --> Total execution time: 1.1674
INFO - 2020-02-05 19:31:44 --> URI Class Initialized
INFO - 2020-02-05 19:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:31:44 --> Router Class Initialized
INFO - 2020-02-05 19:31:44 --> Controller Class Initialized
INFO - 2020-02-05 19:31:44 --> Output Class Initialized
INFO - 2020-02-05 19:31:44 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:31:44 --> Security Class Initialized
INFO - 2020-02-05 19:31:44 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-05 19:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:44 --> Input Class Initialized
INFO - 2020-02-05 19:31:44 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:31:44 --> Language Class Initialized
INFO - 2020-02-05 19:31:44 --> Helper loaded: form_helper
INFO - 2020-02-05 19:31:45 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:31:45 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-05 19:31:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:31:45 --> Config Class Initialized
INFO - 2020-02-05 19:31:45 --> Hooks Class Initialized
ERROR - 2020-02-05 19:31:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:31:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-05 19:31:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:45 --> Final output sent to browser
DEBUG - 2020-02-05 19:31:45 --> Total execution time: 1.2722
INFO - 2020-02-05 19:31:45 --> URI Class Initialized
INFO - 2020-02-05 19:31:45 --> Router Class Initialized
INFO - 2020-02-05 19:31:45 --> Output Class Initialized
INFO - 2020-02-05 19:31:45 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:45 --> Input Class Initialized
INFO - 2020-02-05 19:31:45 --> Language Class Initialized
ERROR - 2020-02-05 19:31:45 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:31:45 --> Config Class Initialized
INFO - 2020-02-05 19:31:45 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:45 --> URI Class Initialized
INFO - 2020-02-05 19:31:45 --> Router Class Initialized
INFO - 2020-02-05 19:31:45 --> Output Class Initialized
INFO - 2020-02-05 19:31:45 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:46 --> Input Class Initialized
INFO - 2020-02-05 19:31:46 --> Language Class Initialized
ERROR - 2020-02-05 19:31:46 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:31:46 --> Config Class Initialized
INFO - 2020-02-05 19:31:46 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:46 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:46 --> URI Class Initialized
INFO - 2020-02-05 19:31:46 --> Router Class Initialized
INFO - 2020-02-05 19:31:46 --> Output Class Initialized
INFO - 2020-02-05 19:31:46 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:46 --> Input Class Initialized
INFO - 2020-02-05 19:31:46 --> Language Class Initialized
ERROR - 2020-02-05 19:31:46 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:31:46 --> Config Class Initialized
INFO - 2020-02-05 19:31:46 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:46 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:47 --> URI Class Initialized
INFO - 2020-02-05 19:31:47 --> Router Class Initialized
INFO - 2020-02-05 19:31:47 --> Output Class Initialized
INFO - 2020-02-05 19:31:47 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:47 --> Input Class Initialized
INFO - 2020-02-05 19:31:47 --> Language Class Initialized
ERROR - 2020-02-05 19:31:47 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:31:47 --> Config Class Initialized
INFO - 2020-02-05 19:31:47 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:47 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:47 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:47 --> URI Class Initialized
INFO - 2020-02-05 19:31:47 --> Router Class Initialized
INFO - 2020-02-05 19:31:47 --> Output Class Initialized
INFO - 2020-02-05 19:31:47 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:47 --> Input Class Initialized
INFO - 2020-02-05 19:31:47 --> Language Class Initialized
ERROR - 2020-02-05 19:31:47 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:31:47 --> Config Class Initialized
INFO - 2020-02-05 19:31:47 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:48 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:48 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:48 --> URI Class Initialized
INFO - 2020-02-05 19:31:48 --> Router Class Initialized
INFO - 2020-02-05 19:31:48 --> Output Class Initialized
INFO - 2020-02-05 19:31:48 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:48 --> Input Class Initialized
INFO - 2020-02-05 19:31:48 --> Language Class Initialized
ERROR - 2020-02-05 19:31:48 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:31:48 --> Config Class Initialized
INFO - 2020-02-05 19:31:48 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:31:48 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:31:48 --> Utf8 Class Initialized
INFO - 2020-02-05 19:31:48 --> URI Class Initialized
INFO - 2020-02-05 19:31:48 --> Router Class Initialized
INFO - 2020-02-05 19:31:48 --> Output Class Initialized
INFO - 2020-02-05 19:31:48 --> Security Class Initialized
DEBUG - 2020-02-05 19:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:31:48 --> Input Class Initialized
INFO - 2020-02-05 19:31:48 --> Language Class Initialized
ERROR - 2020-02-05 19:31:48 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:32:12 --> Config Class Initialized
INFO - 2020-02-05 19:32:12 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:32:12 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:32:12 --> Utf8 Class Initialized
INFO - 2020-02-05 19:32:12 --> URI Class Initialized
INFO - 2020-02-05 19:32:12 --> Router Class Initialized
INFO - 2020-02-05 19:32:12 --> Output Class Initialized
INFO - 2020-02-05 19:32:12 --> Security Class Initialized
DEBUG - 2020-02-05 19:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:32:13 --> Input Class Initialized
INFO - 2020-02-05 19:32:13 --> Language Class Initialized
INFO - 2020-02-05 19:32:13 --> Loader Class Initialized
INFO - 2020-02-05 19:32:13 --> Helper loaded: url_helper
INFO - 2020-02-05 19:32:13 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:32:13 --> Controller Class Initialized
INFO - 2020-02-05 19:32:13 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:32:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:32:13 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:32:13 --> Helper loaded: form_helper
INFO - 2020-02-05 19:32:13 --> Form Validation Class Initialized
INFO - 2020-02-05 19:32:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:32:13 --> Final output sent to browser
INFO - 2020-02-05 19:32:14 --> Config Class Initialized
INFO - 2020-02-05 19:32:14 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:32:14 --> Total execution time: 1.5541
INFO - 2020-02-05 19:32:14 --> Config Class Initialized
INFO - 2020-02-05 19:32:14 --> Config Class Initialized
DEBUG - 2020-02-05 19:32:14 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:32:14 --> Utf8 Class Initialized
INFO - 2020-02-05 19:32:14 --> Hooks Class Initialized
INFO - 2020-02-05 19:32:14 --> URI Class Initialized
INFO - 2020-02-05 19:32:14 --> Hooks Class Initialized
INFO - 2020-02-05 19:32:14 --> Router Class Initialized
DEBUG - 2020-02-05 19:32:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:32:14 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:32:14 --> Utf8 Class Initialized
INFO - 2020-02-05 19:32:14 --> Utf8 Class Initialized
INFO - 2020-02-05 19:32:14 --> Output Class Initialized
INFO - 2020-02-05 19:32:14 --> URI Class Initialized
INFO - 2020-02-05 19:32:14 --> Security Class Initialized
INFO - 2020-02-05 19:32:14 --> URI Class Initialized
DEBUG - 2020-02-05 19:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:32:14 --> Router Class Initialized
INFO - 2020-02-05 19:32:14 --> Router Class Initialized
INFO - 2020-02-05 19:32:14 --> Input Class Initialized
INFO - 2020-02-05 19:32:14 --> Output Class Initialized
INFO - 2020-02-05 19:32:14 --> Output Class Initialized
INFO - 2020-02-05 19:32:14 --> Language Class Initialized
INFO - 2020-02-05 19:32:14 --> Security Class Initialized
INFO - 2020-02-05 19:32:14 --> Security Class Initialized
DEBUG - 2020-02-05 19:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 19:32:14 --> 404 Page Not Found: Bower_components/jquery
DEBUG - 2020-02-05 19:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:32:14 --> Input Class Initialized
INFO - 2020-02-05 19:32:14 --> Input Class Initialized
INFO - 2020-02-05 19:32:14 --> Language Class Initialized
INFO - 2020-02-05 19:32:14 --> Language Class Initialized
INFO - 2020-02-05 19:32:14 --> Loader Class Initialized
INFO - 2020-02-05 19:32:14 --> Loader Class Initialized
INFO - 2020-02-05 19:32:15 --> Helper loaded: url_helper
INFO - 2020-02-05 19:32:15 --> Helper loaded: url_helper
INFO - 2020-02-05 19:32:15 --> Database Driver Class Initialized
INFO - 2020-02-05 19:32:15 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:32:15 --> Controller Class Initialized
INFO - 2020-02-05 19:32:15 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:32:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:32:15 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:32:15 --> Helper loaded: form_helper
INFO - 2020-02-05 19:32:15 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:32:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:32:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:32:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:32:15 --> Final output sent to browser
DEBUG - 2020-02-05 19:32:15 --> Total execution time: 1.7073
INFO - 2020-02-05 19:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:32:15 --> Controller Class Initialized
INFO - 2020-02-05 19:32:16 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:32:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:32:16 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:32:16 --> Helper loaded: form_helper
INFO - 2020-02-05 19:32:16 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:32:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:32:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:32:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:32:16 --> Final output sent to browser
DEBUG - 2020-02-05 19:32:16 --> Total execution time: 2.3377
INFO - 2020-02-05 19:33:28 --> Config Class Initialized
INFO - 2020-02-05 19:33:28 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:33:28 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:33:28 --> Utf8 Class Initialized
INFO - 2020-02-05 19:33:28 --> URI Class Initialized
INFO - 2020-02-05 19:33:28 --> Router Class Initialized
INFO - 2020-02-05 19:33:28 --> Output Class Initialized
INFO - 2020-02-05 19:33:28 --> Security Class Initialized
DEBUG - 2020-02-05 19:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:33:28 --> Input Class Initialized
INFO - 2020-02-05 19:33:28 --> Language Class Initialized
INFO - 2020-02-05 19:33:28 --> Loader Class Initialized
INFO - 2020-02-05 19:33:28 --> Helper loaded: url_helper
INFO - 2020-02-05 19:33:28 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:33:28 --> Controller Class Initialized
INFO - 2020-02-05 19:33:28 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:33:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:33:28 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:33:29 --> Helper loaded: form_helper
INFO - 2020-02-05 19:33:29 --> Form Validation Class Initialized
INFO - 2020-02-05 19:33:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:33:29 --> Final output sent to browser
DEBUG - 2020-02-05 19:33:29 --> Total execution time: 1.1929
INFO - 2020-02-05 19:33:57 --> Config Class Initialized
INFO - 2020-02-05 19:33:57 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:33:57 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:33:57 --> Utf8 Class Initialized
INFO - 2020-02-05 19:33:57 --> URI Class Initialized
INFO - 2020-02-05 19:33:57 --> Router Class Initialized
INFO - 2020-02-05 19:33:57 --> Output Class Initialized
INFO - 2020-02-05 19:33:57 --> Security Class Initialized
DEBUG - 2020-02-05 19:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:33:57 --> Input Class Initialized
INFO - 2020-02-05 19:33:57 --> Language Class Initialized
INFO - 2020-02-05 19:33:57 --> Loader Class Initialized
INFO - 2020-02-05 19:33:57 --> Helper loaded: url_helper
INFO - 2020-02-05 19:33:57 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:33:58 --> Controller Class Initialized
INFO - 2020-02-05 19:33:58 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:33:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:33:58 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:33:58 --> Helper loaded: form_helper
INFO - 2020-02-05 19:33:58 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:33:58 --> Severity: Notice --> Undefined variable: totalbayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-05 19:33:58 --> Final output sent to browser
DEBUG - 2020-02-05 19:33:58 --> Total execution time: 1.4426
INFO - 2020-02-05 19:37:54 --> Config Class Initialized
INFO - 2020-02-05 19:37:54 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:37:54 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:37:54 --> Utf8 Class Initialized
INFO - 2020-02-05 19:37:54 --> URI Class Initialized
INFO - 2020-02-05 19:37:54 --> Router Class Initialized
INFO - 2020-02-05 19:37:55 --> Output Class Initialized
INFO - 2020-02-05 19:37:55 --> Security Class Initialized
DEBUG - 2020-02-05 19:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:37:55 --> Input Class Initialized
INFO - 2020-02-05 19:37:55 --> Language Class Initialized
INFO - 2020-02-05 19:37:55 --> Loader Class Initialized
INFO - 2020-02-05 19:37:55 --> Helper loaded: url_helper
INFO - 2020-02-05 19:37:55 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:37:55 --> Controller Class Initialized
INFO - 2020-02-05 19:37:55 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:37:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:37:55 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:37:55 --> Helper loaded: form_helper
INFO - 2020-02-05 19:37:55 --> Form Validation Class Initialized
INFO - 2020-02-05 19:37:55 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:37:55 --> Final output sent to browser
INFO - 2020-02-05 19:37:55 --> Config Class Initialized
INFO - 2020-02-05 19:37:56 --> Config Class Initialized
INFO - 2020-02-05 19:37:56 --> Hooks Class Initialized
INFO - 2020-02-05 19:37:56 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:37:56 --> Total execution time: 1.3882
DEBUG - 2020-02-05 19:37:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:37:56 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:37:56 --> Utf8 Class Initialized
INFO - 2020-02-05 19:37:56 --> Utf8 Class Initialized
INFO - 2020-02-05 19:37:56 --> URI Class Initialized
INFO - 2020-02-05 19:37:56 --> URI Class Initialized
INFO - 2020-02-05 19:37:56 --> Router Class Initialized
INFO - 2020-02-05 19:37:56 --> Router Class Initialized
INFO - 2020-02-05 19:37:56 --> Output Class Initialized
INFO - 2020-02-05 19:37:56 --> Output Class Initialized
INFO - 2020-02-05 19:37:56 --> Security Class Initialized
INFO - 2020-02-05 19:37:56 --> Security Class Initialized
DEBUG - 2020-02-05 19:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:37:56 --> Input Class Initialized
INFO - 2020-02-05 19:37:56 --> Input Class Initialized
INFO - 2020-02-05 19:37:56 --> Language Class Initialized
INFO - 2020-02-05 19:37:56 --> Language Class Initialized
INFO - 2020-02-05 19:37:56 --> Loader Class Initialized
INFO - 2020-02-05 19:37:56 --> Loader Class Initialized
INFO - 2020-02-05 19:37:56 --> Helper loaded: url_helper
INFO - 2020-02-05 19:37:56 --> Helper loaded: url_helper
INFO - 2020-02-05 19:37:56 --> Database Driver Class Initialized
INFO - 2020-02-05 19:37:56 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:37:56 --> Controller Class Initialized
INFO - 2020-02-05 19:37:56 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:37:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:37:56 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:37:57 --> Helper loaded: form_helper
INFO - 2020-02-05 19:37:57 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:37:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:37:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:37:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:37:57 --> Final output sent to browser
DEBUG - 2020-02-05 19:37:57 --> Total execution time: 1.2672
INFO - 2020-02-05 19:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:37:57 --> Controller Class Initialized
INFO - 2020-02-05 19:37:57 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:37:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:37:57 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:37:57 --> Helper loaded: form_helper
INFO - 2020-02-05 19:37:57 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:37:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:37:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:37:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:37:57 --> Final output sent to browser
DEBUG - 2020-02-05 19:37:57 --> Total execution time: 1.7481
INFO - 2020-02-05 19:38:02 --> Config Class Initialized
INFO - 2020-02-05 19:38:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:38:02 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:38:02 --> Utf8 Class Initialized
INFO - 2020-02-05 19:38:02 --> URI Class Initialized
INFO - 2020-02-05 19:38:02 --> Router Class Initialized
INFO - 2020-02-05 19:38:02 --> Output Class Initialized
INFO - 2020-02-05 19:38:02 --> Security Class Initialized
DEBUG - 2020-02-05 19:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:38:02 --> Input Class Initialized
INFO - 2020-02-05 19:38:02 --> Language Class Initialized
INFO - 2020-02-05 19:38:02 --> Loader Class Initialized
INFO - 2020-02-05 19:38:02 --> Helper loaded: url_helper
INFO - 2020-02-05 19:38:02 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:38:03 --> Controller Class Initialized
INFO - 2020-02-05 19:38:03 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:38:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:38:03 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:38:03 --> Helper loaded: form_helper
INFO - 2020-02-05 19:38:03 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:38:03 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-05 19:38:03 --> Final output sent to browser
DEBUG - 2020-02-05 19:38:03 --> Total execution time: 1.3337
INFO - 2020-02-05 19:38:43 --> Config Class Initialized
INFO - 2020-02-05 19:38:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:38:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:38:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:38:43 --> URI Class Initialized
INFO - 2020-02-05 19:38:43 --> Router Class Initialized
INFO - 2020-02-05 19:38:43 --> Output Class Initialized
INFO - 2020-02-05 19:38:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:38:43 --> Input Class Initialized
INFO - 2020-02-05 19:38:44 --> Language Class Initialized
INFO - 2020-02-05 19:38:44 --> Loader Class Initialized
INFO - 2020-02-05 19:38:44 --> Helper loaded: url_helper
INFO - 2020-02-05 19:38:44 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:38:44 --> Controller Class Initialized
INFO - 2020-02-05 19:38:44 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:38:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:38:44 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:38:44 --> Helper loaded: form_helper
INFO - 2020-02-05 19:38:44 --> Form Validation Class Initialized
INFO - 2020-02-05 19:38:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:38:44 --> Final output sent to browser
INFO - 2020-02-05 19:38:44 --> Config Class Initialized
DEBUG - 2020-02-05 19:38:44 --> Total execution time: 1.2995
INFO - 2020-02-05 19:38:44 --> Config Class Initialized
INFO - 2020-02-05 19:38:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:38:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:38:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:38:44 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:38:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:38:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:38:44 --> URI Class Initialized
INFO - 2020-02-05 19:38:45 --> URI Class Initialized
INFO - 2020-02-05 19:38:45 --> Router Class Initialized
INFO - 2020-02-05 19:38:45 --> Router Class Initialized
INFO - 2020-02-05 19:38:45 --> Output Class Initialized
INFO - 2020-02-05 19:38:45 --> Security Class Initialized
INFO - 2020-02-05 19:38:45 --> Output Class Initialized
DEBUG - 2020-02-05 19:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:38:45 --> Security Class Initialized
INFO - 2020-02-05 19:38:45 --> Input Class Initialized
DEBUG - 2020-02-05 19:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:38:45 --> Input Class Initialized
INFO - 2020-02-05 19:38:45 --> Language Class Initialized
INFO - 2020-02-05 19:38:45 --> Language Class Initialized
INFO - 2020-02-05 19:38:45 --> Loader Class Initialized
INFO - 2020-02-05 19:38:45 --> Helper loaded: url_helper
INFO - 2020-02-05 19:38:45 --> Loader Class Initialized
INFO - 2020-02-05 19:38:45 --> Helper loaded: url_helper
INFO - 2020-02-05 19:38:45 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:38:45 --> Database Driver Class Initialized
INFO - 2020-02-05 19:38:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:38:45 --> Controller Class Initialized
INFO - 2020-02-05 19:38:45 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:38:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:38:45 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:38:45 --> Helper loaded: form_helper
INFO - 2020-02-05 19:38:45 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:38:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:38:46 --> Final output sent to browser
DEBUG - 2020-02-05 19:38:46 --> Total execution time: 1.3301
INFO - 2020-02-05 19:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:38:46 --> Controller Class Initialized
INFO - 2020-02-05 19:38:46 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:38:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:38:46 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:38:46 --> Helper loaded: form_helper
INFO - 2020-02-05 19:38:46 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:38:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:38:46 --> Final output sent to browser
DEBUG - 2020-02-05 19:38:46 --> Total execution time: 1.8979
INFO - 2020-02-05 19:38:51 --> Config Class Initialized
INFO - 2020-02-05 19:38:51 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:38:51 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:38:51 --> Utf8 Class Initialized
INFO - 2020-02-05 19:38:51 --> URI Class Initialized
INFO - 2020-02-05 19:38:51 --> Router Class Initialized
INFO - 2020-02-05 19:38:51 --> Output Class Initialized
INFO - 2020-02-05 19:38:51 --> Security Class Initialized
DEBUG - 2020-02-05 19:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:38:51 --> Input Class Initialized
INFO - 2020-02-05 19:38:51 --> Language Class Initialized
INFO - 2020-02-05 19:38:51 --> Loader Class Initialized
INFO - 2020-02-05 19:38:52 --> Helper loaded: url_helper
INFO - 2020-02-05 19:38:52 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:38:52 --> Controller Class Initialized
INFO - 2020-02-05 19:38:52 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:38:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:38:52 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:38:52 --> Helper loaded: form_helper
INFO - 2020-02-05 19:38:52 --> Form Validation Class Initialized
INFO - 2020-02-05 19:38:52 --> Final output sent to browser
DEBUG - 2020-02-05 19:38:52 --> Total execution time: 1.6425
INFO - 2020-02-05 19:39:01 --> Config Class Initialized
INFO - 2020-02-05 19:39:01 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:39:01 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:39:01 --> Utf8 Class Initialized
INFO - 2020-02-05 19:39:01 --> URI Class Initialized
INFO - 2020-02-05 19:39:01 --> Router Class Initialized
INFO - 2020-02-05 19:39:01 --> Output Class Initialized
INFO - 2020-02-05 19:39:01 --> Security Class Initialized
DEBUG - 2020-02-05 19:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:39:01 --> Input Class Initialized
INFO - 2020-02-05 19:39:02 --> Language Class Initialized
INFO - 2020-02-05 19:39:02 --> Loader Class Initialized
INFO - 2020-02-05 19:39:02 --> Helper loaded: url_helper
INFO - 2020-02-05 19:39:02 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:39:02 --> Controller Class Initialized
INFO - 2020-02-05 19:39:02 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:39:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:39:02 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:39:02 --> Helper loaded: form_helper
INFO - 2020-02-05 19:39:02 --> Form Validation Class Initialized
INFO - 2020-02-05 19:39:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:39:02 --> Final output sent to browser
INFO - 2020-02-05 19:39:02 --> Config Class Initialized
INFO - 2020-02-05 19:39:02 --> Config Class Initialized
INFO - 2020-02-05 19:39:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:39:02 --> Total execution time: 1.7224
INFO - 2020-02-05 19:39:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:39:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:39:02 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:39:03 --> Utf8 Class Initialized
INFO - 2020-02-05 19:39:03 --> Utf8 Class Initialized
INFO - 2020-02-05 19:39:03 --> URI Class Initialized
INFO - 2020-02-05 19:39:03 --> URI Class Initialized
INFO - 2020-02-05 19:39:03 --> Router Class Initialized
INFO - 2020-02-05 19:39:03 --> Router Class Initialized
INFO - 2020-02-05 19:39:03 --> Output Class Initialized
INFO - 2020-02-05 19:39:03 --> Output Class Initialized
INFO - 2020-02-05 19:39:03 --> Security Class Initialized
INFO - 2020-02-05 19:39:03 --> Security Class Initialized
DEBUG - 2020-02-05 19:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:39:03 --> Input Class Initialized
INFO - 2020-02-05 19:39:03 --> Input Class Initialized
INFO - 2020-02-05 19:39:03 --> Language Class Initialized
INFO - 2020-02-05 19:39:03 --> Language Class Initialized
INFO - 2020-02-05 19:39:03 --> Loader Class Initialized
INFO - 2020-02-05 19:39:03 --> Loader Class Initialized
INFO - 2020-02-05 19:39:03 --> Helper loaded: url_helper
INFO - 2020-02-05 19:39:03 --> Helper loaded: url_helper
INFO - 2020-02-05 19:39:03 --> Database Driver Class Initialized
INFO - 2020-02-05 19:39:03 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:39:03 --> Controller Class Initialized
INFO - 2020-02-05 19:39:03 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:39:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:39:03 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:39:03 --> Helper loaded: form_helper
INFO - 2020-02-05 19:39:03 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:39:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:39:04 --> Final output sent to browser
DEBUG - 2020-02-05 19:39:04 --> Total execution time: 1.2533
INFO - 2020-02-05 19:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:39:04 --> Controller Class Initialized
INFO - 2020-02-05 19:39:04 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:39:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:39:04 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:39:04 --> Helper loaded: form_helper
INFO - 2020-02-05 19:39:04 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-05 19:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:39:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:39:04 --> Final output sent to browser
DEBUG - 2020-02-05 19:39:04 --> Total execution time: 1.7913
INFO - 2020-02-05 19:43:43 --> Config Class Initialized
INFO - 2020-02-05 19:43:43 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:43 --> URI Class Initialized
INFO - 2020-02-05 19:43:43 --> Router Class Initialized
INFO - 2020-02-05 19:43:43 --> Output Class Initialized
INFO - 2020-02-05 19:43:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:43 --> Input Class Initialized
INFO - 2020-02-05 19:43:43 --> Language Class Initialized
INFO - 2020-02-05 19:43:43 --> Loader Class Initialized
INFO - 2020-02-05 19:43:43 --> Helper loaded: url_helper
INFO - 2020-02-05 19:43:43 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:43:44 --> Controller Class Initialized
INFO - 2020-02-05 19:43:44 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:43:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:43:44 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:43:44 --> Helper loaded: form_helper
INFO - 2020-02-05 19:43:44 --> Form Validation Class Initialized
INFO - 2020-02-05 19:43:44 --> Final output sent to browser
DEBUG - 2020-02-05 19:43:44 --> Total execution time: 1.7233
INFO - 2020-02-05 19:43:47 --> Config Class Initialized
INFO - 2020-02-05 19:43:47 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:47 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:47 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:47 --> URI Class Initialized
INFO - 2020-02-05 19:43:47 --> Router Class Initialized
INFO - 2020-02-05 19:43:47 --> Output Class Initialized
INFO - 2020-02-05 19:43:47 --> Security Class Initialized
DEBUG - 2020-02-05 19:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:48 --> Input Class Initialized
INFO - 2020-02-05 19:43:48 --> Language Class Initialized
INFO - 2020-02-05 19:43:48 --> Loader Class Initialized
INFO - 2020-02-05 19:43:48 --> Helper loaded: url_helper
INFO - 2020-02-05 19:43:48 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:43:48 --> Controller Class Initialized
INFO - 2020-02-05 19:43:48 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:43:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:43:48 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:43:48 --> Helper loaded: form_helper
INFO - 2020-02-05 19:43:48 --> Form Validation Class Initialized
INFO - 2020-02-05 19:43:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:43:48 --> Final output sent to browser
DEBUG - 2020-02-05 19:43:48 --> Total execution time: 1.3131
INFO - 2020-02-05 19:43:50 --> Config Class Initialized
INFO - 2020-02-05 19:43:50 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:50 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:50 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:50 --> URI Class Initialized
INFO - 2020-02-05 19:43:50 --> Router Class Initialized
INFO - 2020-02-05 19:43:50 --> Output Class Initialized
INFO - 2020-02-05 19:43:50 --> Security Class Initialized
DEBUG - 2020-02-05 19:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:50 --> Input Class Initialized
INFO - 2020-02-05 19:43:50 --> Language Class Initialized
INFO - 2020-02-05 19:43:50 --> Loader Class Initialized
INFO - 2020-02-05 19:43:50 --> Helper loaded: url_helper
INFO - 2020-02-05 19:43:50 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:43:50 --> Controller Class Initialized
INFO - 2020-02-05 19:43:50 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:43:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:43:50 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:43:50 --> Helper loaded: form_helper
INFO - 2020-02-05 19:43:51 --> Form Validation Class Initialized
INFO - 2020-02-05 19:43:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:43:51 --> Final output sent to browser
INFO - 2020-02-05 19:43:51 --> Config Class Initialized
INFO - 2020-02-05 19:43:51 --> Config Class Initialized
INFO - 2020-02-05 19:43:51 --> Config Class Initialized
INFO - 2020-02-05 19:43:51 --> Hooks Class Initialized
INFO - 2020-02-05 19:43:51 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:51 --> Total execution time: 1.0797
INFO - 2020-02-05 19:43:51 --> Hooks Class Initialized
INFO - 2020-02-05 19:43:51 --> Config Class Initialized
DEBUG - 2020-02-05 19:43:51 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:51 --> Config Class Initialized
INFO - 2020-02-05 19:43:51 --> Hooks Class Initialized
INFO - 2020-02-05 19:43:51 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:51 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:43:51 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:51 --> Config Class Initialized
INFO - 2020-02-05 19:43:51 --> Hooks Class Initialized
INFO - 2020-02-05 19:43:51 --> URI Class Initialized
INFO - 2020-02-05 19:43:51 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:51 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:43:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:43:51 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:51 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:51 --> URI Class Initialized
INFO - 2020-02-05 19:43:51 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:51 --> Router Class Initialized
DEBUG - 2020-02-05 19:43:51 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:51 --> URI Class Initialized
INFO - 2020-02-05 19:43:51 --> URI Class Initialized
INFO - 2020-02-05 19:43:51 --> URI Class Initialized
INFO - 2020-02-05 19:43:51 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:51 --> Router Class Initialized
INFO - 2020-02-05 19:43:51 --> Output Class Initialized
INFO - 2020-02-05 19:43:51 --> Router Class Initialized
INFO - 2020-02-05 19:43:51 --> Output Class Initialized
INFO - 2020-02-05 19:43:51 --> Security Class Initialized
INFO - 2020-02-05 19:43:51 --> Output Class Initialized
INFO - 2020-02-05 19:43:51 --> Router Class Initialized
INFO - 2020-02-05 19:43:51 --> URI Class Initialized
INFO - 2020-02-05 19:43:51 --> Router Class Initialized
DEBUG - 2020-02-05 19:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:51 --> Output Class Initialized
INFO - 2020-02-05 19:43:51 --> Security Class Initialized
INFO - 2020-02-05 19:43:51 --> Security Class Initialized
INFO - 2020-02-05 19:43:51 --> Output Class Initialized
INFO - 2020-02-05 19:43:51 --> Router Class Initialized
INFO - 2020-02-05 19:43:51 --> Input Class Initialized
DEBUG - 2020-02-05 19:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:51 --> Security Class Initialized
INFO - 2020-02-05 19:43:51 --> Output Class Initialized
DEBUG - 2020-02-05 19:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:51 --> Security Class Initialized
INFO - 2020-02-05 19:43:51 --> Input Class Initialized
DEBUG - 2020-02-05 19:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:51 --> Language Class Initialized
INFO - 2020-02-05 19:43:51 --> Security Class Initialized
INFO - 2020-02-05 19:43:51 --> Input Class Initialized
DEBUG - 2020-02-05 19:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:51 --> Input Class Initialized
INFO - 2020-02-05 19:43:51 --> Language Class Initialized
ERROR - 2020-02-05 19:43:51 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:43:51 --> Input Class Initialized
DEBUG - 2020-02-05 19:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:51 --> Language Class Initialized
INFO - 2020-02-05 19:43:51 --> Input Class Initialized
INFO - 2020-02-05 19:43:51 --> Language Class Initialized
INFO - 2020-02-05 19:43:51 --> Language Class Initialized
INFO - 2020-02-05 19:43:51 --> Loader Class Initialized
INFO - 2020-02-05 19:43:51 --> Loader Class Initialized
INFO - 2020-02-05 19:43:51 --> Config Class Initialized
INFO - 2020-02-05 19:43:51 --> Hooks Class Initialized
INFO - 2020-02-05 19:43:51 --> Language Class Initialized
INFO - 2020-02-05 19:43:51 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:43:51 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 19:43:51 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-05 19:43:51 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:43:51 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-05 19:43:51 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:51 --> Database Driver Class Initialized
INFO - 2020-02-05 19:43:51 --> Database Driver Class Initialized
INFO - 2020-02-05 19:43:51 --> Config Class Initialized
INFO - 2020-02-05 19:43:51 --> Config Class Initialized
INFO - 2020-02-05 19:43:51 --> Hooks Class Initialized
INFO - 2020-02-05 19:43:51 --> Hooks Class Initialized
INFO - 2020-02-05 19:43:51 --> Utf8 Class Initialized
DEBUG - 2020-02-05 19:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-05 19:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:43:51 --> Config Class Initialized
INFO - 2020-02-05 19:43:51 --> Hooks Class Initialized
INFO - 2020-02-05 19:43:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:43:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:43:51 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:51 --> URI Class Initialized
INFO - 2020-02-05 19:43:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:52 --> Controller Class Initialized
INFO - 2020-02-05 19:43:52 --> Router Class Initialized
DEBUG - 2020-02-05 19:43:52 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:52 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:43:52 --> URI Class Initialized
INFO - 2020-02-05 19:43:52 --> URI Class Initialized
INFO - 2020-02-05 19:43:52 --> Output Class Initialized
INFO - 2020-02-05 19:43:52 --> URI Class Initialized
INFO - 2020-02-05 19:43:52 --> Security Class Initialized
INFO - 2020-02-05 19:43:52 --> Router Class Initialized
INFO - 2020-02-05 19:43:52 --> Router Class Initialized
INFO - 2020-02-05 19:43:52 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-05 19:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:52 --> Router Class Initialized
INFO - 2020-02-05 19:43:52 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:43:52 --> Output Class Initialized
INFO - 2020-02-05 19:43:52 --> Output Class Initialized
INFO - 2020-02-05 19:43:52 --> Security Class Initialized
INFO - 2020-02-05 19:43:52 --> Security Class Initialized
INFO - 2020-02-05 19:43:52 --> Input Class Initialized
INFO - 2020-02-05 19:43:52 --> Output Class Initialized
INFO - 2020-02-05 19:43:52 --> Helper loaded: form_helper
INFO - 2020-02-05 19:43:52 --> Form Validation Class Initialized
INFO - 2020-02-05 19:43:52 --> Language Class Initialized
DEBUG - 2020-02-05 19:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:52 --> Security Class Initialized
INFO - 2020-02-05 19:43:52 --> Input Class Initialized
INFO - 2020-02-05 19:43:52 --> Input Class Initialized
ERROR - 2020-02-05 19:43:52 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-05 19:43:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 19:43:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:43:52 --> Language Class Initialized
ERROR - 2020-02-05 19:43:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:43:52 --> Input Class Initialized
INFO - 2020-02-05 19:43:52 --> Language Class Initialized
INFO - 2020-02-05 19:43:52 --> Config Class Initialized
INFO - 2020-02-05 19:43:52 --> Hooks Class Initialized
INFO - 2020-02-05 19:43:52 --> Language Class Initialized
INFO - 2020-02-05 19:43:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-05 19:43:52 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:43:52 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:43:52 --> Final output sent to browser
ERROR - 2020-02-05 19:43:52 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-05 19:43:52 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:52 --> Config Class Initialized
INFO - 2020-02-05 19:43:52 --> Config Class Initialized
INFO - 2020-02-05 19:43:52 --> Hooks Class Initialized
INFO - 2020-02-05 19:43:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:52 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:52 --> Total execution time: 1.2754
INFO - 2020-02-05 19:43:52 --> Config Class Initialized
INFO - 2020-02-05 19:43:52 --> Hooks Class Initialized
INFO - 2020-02-05 19:43:52 --> URI Class Initialized
INFO - 2020-02-05 19:43:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-05 19:43:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:43:52 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:52 --> Controller Class Initialized
INFO - 2020-02-05 19:43:52 --> Router Class Initialized
DEBUG - 2020-02-05 19:43:52 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:52 --> URI Class Initialized
INFO - 2020-02-05 19:43:52 --> URI Class Initialized
INFO - 2020-02-05 19:43:52 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:52 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:43:52 --> Output Class Initialized
INFO - 2020-02-05 19:43:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:43:52 --> URI Class Initialized
INFO - 2020-02-05 19:43:52 --> Router Class Initialized
INFO - 2020-02-05 19:43:52 --> Router Class Initialized
INFO - 2020-02-05 19:43:52 --> Security Class Initialized
INFO - 2020-02-05 19:43:52 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:43:52 --> Output Class Initialized
INFO - 2020-02-05 19:43:52 --> Output Class Initialized
DEBUG - 2020-02-05 19:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:52 --> Router Class Initialized
INFO - 2020-02-05 19:43:52 --> Input Class Initialized
INFO - 2020-02-05 19:43:52 --> Security Class Initialized
INFO - 2020-02-05 19:43:52 --> Output Class Initialized
INFO - 2020-02-05 19:43:52 --> Security Class Initialized
INFO - 2020-02-05 19:43:52 --> Helper loaded: form_helper
INFO - 2020-02-05 19:43:52 --> Form Validation Class Initialized
INFO - 2020-02-05 19:43:52 --> Language Class Initialized
INFO - 2020-02-05 19:43:52 --> Security Class Initialized
DEBUG - 2020-02-05 19:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:52 --> Input Class Initialized
INFO - 2020-02-05 19:43:52 --> Input Class Initialized
ERROR - 2020-02-05 19:43:52 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-05 19:43:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-05 19:43:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:43:53 --> Input Class Initialized
ERROR - 2020-02-05 19:43:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:43:53 --> Language Class Initialized
INFO - 2020-02-05 19:43:53 --> Language Class Initialized
INFO - 2020-02-05 19:43:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:43:53 --> Language Class Initialized
ERROR - 2020-02-05 19:43:53 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 19:43:53 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:43:53 --> Final output sent to browser
ERROR - 2020-02-05 19:43:53 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-05 19:43:53 --> Total execution time: 1.8819
INFO - 2020-02-05 19:43:53 --> Config Class Initialized
INFO - 2020-02-05 19:43:53 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:53 --> URI Class Initialized
INFO - 2020-02-05 19:43:53 --> Router Class Initialized
INFO - 2020-02-05 19:43:53 --> Output Class Initialized
INFO - 2020-02-05 19:43:53 --> Security Class Initialized
DEBUG - 2020-02-05 19:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:53 --> Input Class Initialized
INFO - 2020-02-05 19:43:53 --> Language Class Initialized
ERROR - 2020-02-05 19:43:53 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:43:53 --> Config Class Initialized
INFO - 2020-02-05 19:43:53 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:53 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:53 --> URI Class Initialized
INFO - 2020-02-05 19:43:53 --> Router Class Initialized
INFO - 2020-02-05 19:43:54 --> Output Class Initialized
INFO - 2020-02-05 19:43:54 --> Security Class Initialized
DEBUG - 2020-02-05 19:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:54 --> Input Class Initialized
INFO - 2020-02-05 19:43:54 --> Language Class Initialized
ERROR - 2020-02-05 19:43:54 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-05 19:43:54 --> Config Class Initialized
INFO - 2020-02-05 19:43:54 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:54 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:54 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:54 --> URI Class Initialized
INFO - 2020-02-05 19:43:54 --> Router Class Initialized
INFO - 2020-02-05 19:43:54 --> Output Class Initialized
INFO - 2020-02-05 19:43:54 --> Security Class Initialized
DEBUG - 2020-02-05 19:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:54 --> Input Class Initialized
INFO - 2020-02-05 19:43:54 --> Language Class Initialized
ERROR - 2020-02-05 19:43:54 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:43:54 --> Config Class Initialized
INFO - 2020-02-05 19:43:54 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:55 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:55 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:55 --> URI Class Initialized
INFO - 2020-02-05 19:43:55 --> Router Class Initialized
INFO - 2020-02-05 19:43:55 --> Output Class Initialized
INFO - 2020-02-05 19:43:55 --> Security Class Initialized
DEBUG - 2020-02-05 19:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:55 --> Input Class Initialized
INFO - 2020-02-05 19:43:55 --> Language Class Initialized
ERROR - 2020-02-05 19:43:55 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:43:55 --> Config Class Initialized
INFO - 2020-02-05 19:43:55 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:55 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:55 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:55 --> URI Class Initialized
INFO - 2020-02-05 19:43:55 --> Router Class Initialized
INFO - 2020-02-05 19:43:55 --> Output Class Initialized
INFO - 2020-02-05 19:43:55 --> Security Class Initialized
DEBUG - 2020-02-05 19:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:56 --> Input Class Initialized
INFO - 2020-02-05 19:43:56 --> Language Class Initialized
ERROR - 2020-02-05 19:43:56 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:43:56 --> Config Class Initialized
INFO - 2020-02-05 19:43:56 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:56 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:56 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:56 --> URI Class Initialized
INFO - 2020-02-05 19:43:56 --> Router Class Initialized
INFO - 2020-02-05 19:43:56 --> Output Class Initialized
INFO - 2020-02-05 19:43:56 --> Security Class Initialized
DEBUG - 2020-02-05 19:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:56 --> Input Class Initialized
INFO - 2020-02-05 19:43:56 --> Language Class Initialized
ERROR - 2020-02-05 19:43:56 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:43:56 --> Config Class Initialized
INFO - 2020-02-05 19:43:56 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:56 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:56 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:57 --> URI Class Initialized
INFO - 2020-02-05 19:43:57 --> Router Class Initialized
INFO - 2020-02-05 19:43:57 --> Output Class Initialized
INFO - 2020-02-05 19:43:57 --> Security Class Initialized
DEBUG - 2020-02-05 19:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:57 --> Input Class Initialized
INFO - 2020-02-05 19:43:57 --> Language Class Initialized
ERROR - 2020-02-05 19:43:57 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:43:57 --> Config Class Initialized
INFO - 2020-02-05 19:43:57 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:43:57 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:43:57 --> Utf8 Class Initialized
INFO - 2020-02-05 19:43:57 --> URI Class Initialized
INFO - 2020-02-05 19:43:57 --> Router Class Initialized
INFO - 2020-02-05 19:43:57 --> Output Class Initialized
INFO - 2020-02-05 19:43:57 --> Security Class Initialized
DEBUG - 2020-02-05 19:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:43:57 --> Input Class Initialized
INFO - 2020-02-05 19:43:58 --> Language Class Initialized
ERROR - 2020-02-05 19:43:58 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:44:42 --> Config Class Initialized
INFO - 2020-02-05 19:44:42 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:44:43 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:44:43 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:43 --> URI Class Initialized
INFO - 2020-02-05 19:44:43 --> Router Class Initialized
INFO - 2020-02-05 19:44:43 --> Output Class Initialized
INFO - 2020-02-05 19:44:43 --> Security Class Initialized
DEBUG - 2020-02-05 19:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:43 --> Input Class Initialized
INFO - 2020-02-05 19:44:43 --> Language Class Initialized
INFO - 2020-02-05 19:44:43 --> Loader Class Initialized
INFO - 2020-02-05 19:44:43 --> Helper loaded: url_helper
INFO - 2020-02-05 19:44:43 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:44:43 --> Controller Class Initialized
INFO - 2020-02-05 19:44:43 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:44:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:44:43 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:44:43 --> Helper loaded: form_helper
INFO - 2020-02-05 19:44:43 --> Form Validation Class Initialized
INFO - 2020-02-05 19:44:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:44:44 --> Final output sent to browser
INFO - 2020-02-05 19:44:44 --> Config Class Initialized
INFO - 2020-02-05 19:44:44 --> Config Class Initialized
INFO - 2020-02-05 19:44:44 --> Config Class Initialized
INFO - 2020-02-05 19:44:44 --> Config Class Initialized
INFO - 2020-02-05 19:44:44 --> Config Class Initialized
INFO - 2020-02-05 19:44:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:44:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:44:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:44:44 --> Total execution time: 1.3263
INFO - 2020-02-05 19:44:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:44:44 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:44:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:44:44 --> Config Class Initialized
INFO - 2020-02-05 19:44:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:44:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:44 --> URI Class Initialized
INFO - 2020-02-05 19:44:44 --> URI Class Initialized
INFO - 2020-02-05 19:44:44 --> URI Class Initialized
INFO - 2020-02-05 19:44:44 --> URI Class Initialized
INFO - 2020-02-05 19:44:44 --> URI Class Initialized
DEBUG - 2020-02-05 19:44:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:44:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:44 --> Router Class Initialized
INFO - 2020-02-05 19:44:44 --> Router Class Initialized
INFO - 2020-02-05 19:44:44 --> Router Class Initialized
INFO - 2020-02-05 19:44:44 --> Router Class Initialized
INFO - 2020-02-05 19:44:44 --> Router Class Initialized
INFO - 2020-02-05 19:44:44 --> URI Class Initialized
INFO - 2020-02-05 19:44:44 --> Output Class Initialized
INFO - 2020-02-05 19:44:44 --> Output Class Initialized
INFO - 2020-02-05 19:44:44 --> Output Class Initialized
INFO - 2020-02-05 19:44:44 --> Output Class Initialized
INFO - 2020-02-05 19:44:44 --> Output Class Initialized
INFO - 2020-02-05 19:44:44 --> Router Class Initialized
INFO - 2020-02-05 19:44:44 --> Security Class Initialized
INFO - 2020-02-05 19:44:44 --> Security Class Initialized
INFO - 2020-02-05 19:44:44 --> Security Class Initialized
INFO - 2020-02-05 19:44:44 --> Security Class Initialized
INFO - 2020-02-05 19:44:44 --> Security Class Initialized
DEBUG - 2020-02-05 19:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:44 --> Output Class Initialized
DEBUG - 2020-02-05 19:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:44 --> Input Class Initialized
INFO - 2020-02-05 19:44:44 --> Input Class Initialized
INFO - 2020-02-05 19:44:44 --> Input Class Initialized
INFO - 2020-02-05 19:44:44 --> Input Class Initialized
INFO - 2020-02-05 19:44:44 --> Input Class Initialized
INFO - 2020-02-05 19:44:44 --> Security Class Initialized
INFO - 2020-02-05 19:44:44 --> Language Class Initialized
INFO - 2020-02-05 19:44:44 --> Language Class Initialized
INFO - 2020-02-05 19:44:44 --> Language Class Initialized
DEBUG - 2020-02-05 19:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:44 --> Language Class Initialized
INFO - 2020-02-05 19:44:44 --> Language Class Initialized
ERROR - 2020-02-05 19:44:44 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-05 19:44:44 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 19:44:44 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 19:44:44 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-05 19:44:44 --> Input Class Initialized
ERROR - 2020-02-05 19:44:44 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:44:44 --> Language Class Initialized
INFO - 2020-02-05 19:44:44 --> Config Class Initialized
INFO - 2020-02-05 19:44:44 --> Config Class Initialized
INFO - 2020-02-05 19:44:44 --> Config Class Initialized
INFO - 2020-02-05 19:44:44 --> Config Class Initialized
INFO - 2020-02-05 19:44:44 --> Config Class Initialized
INFO - 2020-02-05 19:44:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:44:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:44:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:44:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:44:44 --> Hooks Class Initialized
ERROR - 2020-02-05 19:44:44 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-05 19:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:44:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:44:44 --> Config Class Initialized
INFO - 2020-02-05 19:44:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:44 --> Hooks Class Initialized
INFO - 2020-02-05 19:44:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:44 --> URI Class Initialized
INFO - 2020-02-05 19:44:44 --> URI Class Initialized
INFO - 2020-02-05 19:44:44 --> URI Class Initialized
INFO - 2020-02-05 19:44:44 --> URI Class Initialized
INFO - 2020-02-05 19:44:44 --> URI Class Initialized
DEBUG - 2020-02-05 19:44:44 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:44:44 --> Router Class Initialized
INFO - 2020-02-05 19:44:44 --> Router Class Initialized
INFO - 2020-02-05 19:44:44 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:44 --> Router Class Initialized
INFO - 2020-02-05 19:44:44 --> Router Class Initialized
INFO - 2020-02-05 19:44:44 --> Router Class Initialized
INFO - 2020-02-05 19:44:45 --> URI Class Initialized
INFO - 2020-02-05 19:44:45 --> Output Class Initialized
INFO - 2020-02-05 19:44:45 --> Output Class Initialized
INFO - 2020-02-05 19:44:45 --> Output Class Initialized
INFO - 2020-02-05 19:44:45 --> Output Class Initialized
INFO - 2020-02-05 19:44:45 --> Output Class Initialized
INFO - 2020-02-05 19:44:45 --> Security Class Initialized
INFO - 2020-02-05 19:44:45 --> Security Class Initialized
INFO - 2020-02-05 19:44:45 --> Router Class Initialized
INFO - 2020-02-05 19:44:45 --> Security Class Initialized
INFO - 2020-02-05 19:44:45 --> Security Class Initialized
INFO - 2020-02-05 19:44:45 --> Security Class Initialized
DEBUG - 2020-02-05 19:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:45 --> Output Class Initialized
DEBUG - 2020-02-05 19:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:45 --> Input Class Initialized
INFO - 2020-02-05 19:44:45 --> Input Class Initialized
INFO - 2020-02-05 19:44:45 --> Input Class Initialized
INFO - 2020-02-05 19:44:45 --> Input Class Initialized
INFO - 2020-02-05 19:44:45 --> Input Class Initialized
INFO - 2020-02-05 19:44:45 --> Security Class Initialized
INFO - 2020-02-05 19:44:45 --> Language Class Initialized
INFO - 2020-02-05 19:44:45 --> Language Class Initialized
INFO - 2020-02-05 19:44:45 --> Language Class Initialized
INFO - 2020-02-05 19:44:45 --> Language Class Initialized
DEBUG - 2020-02-05 19:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:45 --> Language Class Initialized
ERROR - 2020-02-05 19:44:45 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-05 19:44:45 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-05 19:44:45 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-05 19:44:45 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:44:45 --> Input Class Initialized
ERROR - 2020-02-05 19:44:45 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:44:45 --> Language Class Initialized
INFO - 2020-02-05 19:44:45 --> Config Class Initialized
INFO - 2020-02-05 19:44:45 --> Config Class Initialized
INFO - 2020-02-05 19:44:45 --> Hooks Class Initialized
INFO - 2020-02-05 19:44:45 --> Hooks Class Initialized
INFO - 2020-02-05 19:44:45 --> Loader Class Initialized
INFO - 2020-02-05 19:44:45 --> Helper loaded: url_helper
DEBUG - 2020-02-05 19:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:44:45 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:44:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:45 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:45 --> Database Driver Class Initialized
INFO - 2020-02-05 19:44:45 --> URI Class Initialized
INFO - 2020-02-05 19:44:45 --> URI Class Initialized
DEBUG - 2020-02-05 19:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:44:45 --> Router Class Initialized
INFO - 2020-02-05 19:44:45 --> Router Class Initialized
INFO - 2020-02-05 19:44:45 --> Controller Class Initialized
INFO - 2020-02-05 19:44:45 --> Output Class Initialized
INFO - 2020-02-05 19:44:45 --> Output Class Initialized
INFO - 2020-02-05 19:44:45 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:44:45 --> Security Class Initialized
INFO - 2020-02-05 19:44:45 --> Security Class Initialized
INFO - 2020-02-05 19:44:45 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-05 19:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:45 --> Input Class Initialized
INFO - 2020-02-05 19:44:45 --> Input Class Initialized
INFO - 2020-02-05 19:44:45 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:44:45 --> Language Class Initialized
INFO - 2020-02-05 19:44:45 --> Language Class Initialized
INFO - 2020-02-05 19:44:45 --> Helper loaded: form_helper
INFO - 2020-02-05 19:44:45 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:44:45 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-05 19:44:45 --> Loader Class Initialized
INFO - 2020-02-05 19:44:45 --> Helper loaded: url_helper
ERROR - 2020-02-05 19:44:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:44:45 --> Config Class Initialized
INFO - 2020-02-05 19:44:45 --> Hooks Class Initialized
ERROR - 2020-02-05 19:44:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:44:45 --> Database Driver Class Initialized
INFO - 2020-02-05 19:44:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-05 19:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:44:46 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:46 --> Final output sent to browser
DEBUG - 2020-02-05 19:44:46 --> Total execution time: 1.2008
INFO - 2020-02-05 19:44:46 --> URI Class Initialized
INFO - 2020-02-05 19:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:44:46 --> Router Class Initialized
INFO - 2020-02-05 19:44:46 --> Controller Class Initialized
INFO - 2020-02-05 19:44:46 --> Output Class Initialized
INFO - 2020-02-05 19:44:46 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:44:46 --> Security Class Initialized
INFO - 2020-02-05 19:44:46 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-05 19:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:46 --> Input Class Initialized
INFO - 2020-02-05 19:44:46 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:44:46 --> Language Class Initialized
INFO - 2020-02-05 19:44:46 --> Helper loaded: form_helper
INFO - 2020-02-05 19:44:46 --> Form Validation Class Initialized
ERROR - 2020-02-05 19:44:46 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-05 19:44:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-05 19:44:46 --> Config Class Initialized
INFO - 2020-02-05 19:44:46 --> Hooks Class Initialized
ERROR - 2020-02-05 19:44:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-05 19:44:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-05 19:44:46 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:44:46 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:46 --> Final output sent to browser
DEBUG - 2020-02-05 19:44:46 --> Total execution time: 1.2924
INFO - 2020-02-05 19:44:46 --> URI Class Initialized
INFO - 2020-02-05 19:44:46 --> Router Class Initialized
INFO - 2020-02-05 19:44:46 --> Output Class Initialized
INFO - 2020-02-05 19:44:46 --> Security Class Initialized
DEBUG - 2020-02-05 19:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:46 --> Input Class Initialized
INFO - 2020-02-05 19:44:46 --> Language Class Initialized
ERROR - 2020-02-05 19:44:47 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:44:47 --> Config Class Initialized
INFO - 2020-02-05 19:44:47 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:44:47 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:44:47 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:47 --> URI Class Initialized
INFO - 2020-02-05 19:44:47 --> Router Class Initialized
INFO - 2020-02-05 19:44:47 --> Output Class Initialized
INFO - 2020-02-05 19:44:47 --> Security Class Initialized
DEBUG - 2020-02-05 19:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:47 --> Input Class Initialized
INFO - 2020-02-05 19:44:47 --> Language Class Initialized
ERROR - 2020-02-05 19:44:47 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-05 19:44:47 --> Config Class Initialized
INFO - 2020-02-05 19:44:47 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:44:47 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:44:47 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:47 --> URI Class Initialized
INFO - 2020-02-05 19:44:47 --> Router Class Initialized
INFO - 2020-02-05 19:44:48 --> Output Class Initialized
INFO - 2020-02-05 19:44:48 --> Security Class Initialized
DEBUG - 2020-02-05 19:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:48 --> Input Class Initialized
INFO - 2020-02-05 19:44:48 --> Language Class Initialized
ERROR - 2020-02-05 19:44:48 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-05 19:44:48 --> Config Class Initialized
INFO - 2020-02-05 19:44:48 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:44:48 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:44:48 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:48 --> URI Class Initialized
INFO - 2020-02-05 19:44:48 --> Router Class Initialized
INFO - 2020-02-05 19:44:48 --> Output Class Initialized
INFO - 2020-02-05 19:44:48 --> Security Class Initialized
DEBUG - 2020-02-05 19:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:48 --> Input Class Initialized
INFO - 2020-02-05 19:44:48 --> Language Class Initialized
ERROR - 2020-02-05 19:44:48 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-05 19:44:48 --> Config Class Initialized
INFO - 2020-02-05 19:44:48 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:44:48 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:44:49 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:49 --> URI Class Initialized
INFO - 2020-02-05 19:44:49 --> Router Class Initialized
INFO - 2020-02-05 19:44:49 --> Output Class Initialized
INFO - 2020-02-05 19:44:49 --> Security Class Initialized
DEBUG - 2020-02-05 19:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:49 --> Input Class Initialized
INFO - 2020-02-05 19:44:49 --> Language Class Initialized
ERROR - 2020-02-05 19:44:49 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-05 19:44:49 --> Config Class Initialized
INFO - 2020-02-05 19:44:49 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:44:49 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:44:49 --> Utf8 Class Initialized
INFO - 2020-02-05 19:44:49 --> URI Class Initialized
INFO - 2020-02-05 19:44:49 --> Router Class Initialized
INFO - 2020-02-05 19:44:49 --> Output Class Initialized
INFO - 2020-02-05 19:44:49 --> Security Class Initialized
DEBUG - 2020-02-05 19:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:44:49 --> Input Class Initialized
INFO - 2020-02-05 19:44:49 --> Language Class Initialized
ERROR - 2020-02-05 19:44:49 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-05 19:45:03 --> Config Class Initialized
INFO - 2020-02-05 19:45:03 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:45:03 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:45:03 --> Utf8 Class Initialized
INFO - 2020-02-05 19:45:03 --> URI Class Initialized
INFO - 2020-02-05 19:45:03 --> Router Class Initialized
INFO - 2020-02-05 19:45:03 --> Output Class Initialized
INFO - 2020-02-05 19:45:03 --> Security Class Initialized
DEBUG - 2020-02-05 19:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:45:03 --> Input Class Initialized
INFO - 2020-02-05 19:45:03 --> Language Class Initialized
INFO - 2020-02-05 19:45:03 --> Loader Class Initialized
INFO - 2020-02-05 19:45:03 --> Helper loaded: url_helper
INFO - 2020-02-05 19:45:03 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:45:04 --> Controller Class Initialized
INFO - 2020-02-05 19:45:04 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:45:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:45:04 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:45:04 --> Helper loaded: form_helper
INFO - 2020-02-05 19:45:04 --> Form Validation Class Initialized
INFO - 2020-02-05 19:45:04 --> Final output sent to browser
DEBUG - 2020-02-05 19:45:04 --> Total execution time: 1.1936
INFO - 2020-02-05 19:46:36 --> Config Class Initialized
INFO - 2020-02-05 19:46:37 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:46:37 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:46:37 --> Utf8 Class Initialized
INFO - 2020-02-05 19:46:37 --> URI Class Initialized
INFO - 2020-02-05 19:46:37 --> Router Class Initialized
INFO - 2020-02-05 19:46:37 --> Output Class Initialized
INFO - 2020-02-05 19:46:37 --> Security Class Initialized
DEBUG - 2020-02-05 19:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:46:37 --> Input Class Initialized
INFO - 2020-02-05 19:46:37 --> Language Class Initialized
INFO - 2020-02-05 19:46:37 --> Loader Class Initialized
INFO - 2020-02-05 19:46:38 --> Helper loaded: url_helper
INFO - 2020-02-05 19:46:38 --> Database Driver Class Initialized
DEBUG - 2020-02-05 19:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 19:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 19:46:38 --> Controller Class Initialized
INFO - 2020-02-05 19:46:38 --> Model "M_tiket" initialized
INFO - 2020-02-05 19:46:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-05 19:46:38 --> Model "M_pesan" initialized
INFO - 2020-02-05 19:46:38 --> Helper loaded: form_helper
INFO - 2020-02-05 19:46:38 --> Form Validation Class Initialized
INFO - 2020-02-05 19:46:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-05 19:46:38 --> Final output sent to browser
INFO - 2020-02-05 19:46:38 --> Config Class Initialized
INFO - 2020-02-05 19:46:38 --> Config Class Initialized
INFO - 2020-02-05 19:46:38 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:46:38 --> Total execution time: 1.5624
INFO - 2020-02-05 19:46:38 --> Hooks Class Initialized
DEBUG - 2020-02-05 19:46:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-05 19:46:38 --> UTF-8 Support Enabled
INFO - 2020-02-05 19:46:38 --> Utf8 Class Initialized
INFO - 2020-02-05 19:46:38 --> Utf8 Class Initialized
INFO - 2020-02-05 19:46:38 --> URI Class Initialized
INFO - 2020-02-05 19:46:38 --> URI Class Initialized
INFO - 2020-02-05 19:46:38 --> Router Class Initialized
INFO - 2020-02-05 19:46:38 --> Router Class Initialized
INFO - 2020-02-05 19:46:38 --> Output Class Initialized
INFO - 2020-02-05 19:46:38 --> Output Class Initialized
INFO - 2020-02-05 19:46:38 --> Security Class Initialized
INFO - 2020-02-05 19:46:38 --> Security Class Initialized
DEBUG - 2020-02-05 19:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-05 19:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 19:46:39 --> Input Class Initialized
INFO - 2020-02-05 19:46:39 --> Input Class Initialized
INFO - 2020-02-05 19:46:39 --> Language Class Initialized
INFO - 2020-02-05 19:46:39 --> Language Class Initialized
ERROR - 2020-02-05 19:46:39 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-05 19:46:39 --> 404 Page Not Found: Bower_components/jquery
