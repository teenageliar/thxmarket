<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-08 03:09:18 --> Config Class Initialized
INFO - 2020-02-08 03:09:18 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:09:18 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:09:19 --> Utf8 Class Initialized
INFO - 2020-02-08 03:09:19 --> URI Class Initialized
INFO - 2020-02-08 03:09:19 --> Router Class Initialized
INFO - 2020-02-08 03:09:19 --> Output Class Initialized
INFO - 2020-02-08 03:09:20 --> Security Class Initialized
DEBUG - 2020-02-08 03:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:09:20 --> Input Class Initialized
INFO - 2020-02-08 03:09:20 --> Language Class Initialized
INFO - 2020-02-08 03:09:20 --> Loader Class Initialized
INFO - 2020-02-08 03:09:21 --> Helper loaded: url_helper
INFO - 2020-02-08 03:09:21 --> Database Driver Class Initialized
DEBUG - 2020-02-08 03:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 03:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-08 03:09:22 --> Controller Class Initialized
INFO - 2020-02-08 03:09:22 --> Model "M_tiket" initialized
INFO - 2020-02-08 03:09:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 03:09:22 --> Model "M_pesan" initialized
INFO - 2020-02-08 03:09:22 --> Helper loaded: form_helper
INFO - 2020-02-08 03:09:23 --> Form Validation Class Initialized
INFO - 2020-02-08 03:09:23 --> Config Class Initialized
INFO - 2020-02-08 03:09:23 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:09:23 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:09:23 --> Utf8 Class Initialized
INFO - 2020-02-08 03:09:23 --> URI Class Initialized
INFO - 2020-02-08 03:09:23 --> Router Class Initialized
INFO - 2020-02-08 03:09:23 --> Output Class Initialized
INFO - 2020-02-08 03:09:23 --> Security Class Initialized
ERROR - 2020-02-08 03:09:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
DEBUG - 2020-02-08 03:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:09:23 --> Input Class Initialized
INFO - 2020-02-08 03:09:23 --> Language Class Initialized
INFO - 2020-02-08 03:09:23 --> Loader Class Initialized
INFO - 2020-02-08 03:09:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-08 03:09:23 --> Helper loaded: url_helper
INFO - 2020-02-08 03:09:23 --> Final output sent to browser
INFO - 2020-02-08 03:09:23 --> Database Driver Class Initialized
DEBUG - 2020-02-08 03:09:23 --> Total execution time: 5.5402
DEBUG - 2020-02-08 03:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 03:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-08 03:09:24 --> Controller Class Initialized
INFO - 2020-02-08 03:09:24 --> Model "M_tiket" initialized
INFO - 2020-02-08 03:09:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 03:09:24 --> Model "M_pesan" initialized
INFO - 2020-02-08 03:09:24 --> Helper loaded: form_helper
INFO - 2020-02-08 03:09:24 --> Form Validation Class Initialized
ERROR - 2020-02-08 03:09:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-08 03:09:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-08 03:09:24 --> Final output sent to browser
DEBUG - 2020-02-08 03:09:24 --> Total execution time: 1.5711
INFO - 2020-02-08 03:09:27 --> Config Class Initialized
INFO - 2020-02-08 03:09:27 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:09:28 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:09:28 --> Utf8 Class Initialized
INFO - 2020-02-08 03:09:28 --> URI Class Initialized
INFO - 2020-02-08 03:09:28 --> Router Class Initialized
INFO - 2020-02-08 03:09:28 --> Output Class Initialized
INFO - 2020-02-08 03:09:28 --> Security Class Initialized
DEBUG - 2020-02-08 03:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:09:28 --> Input Class Initialized
INFO - 2020-02-08 03:09:28 --> Language Class Initialized
INFO - 2020-02-08 03:09:28 --> Loader Class Initialized
INFO - 2020-02-08 03:09:28 --> Helper loaded: url_helper
INFO - 2020-02-08 03:09:28 --> Database Driver Class Initialized
DEBUG - 2020-02-08 03:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 03:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-08 03:09:28 --> Controller Class Initialized
INFO - 2020-02-08 03:09:28 --> Model "M_tiket" initialized
INFO - 2020-02-08 03:09:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 03:09:28 --> Model "M_pesan" initialized
INFO - 2020-02-08 03:09:28 --> Helper loaded: form_helper
INFO - 2020-02-08 03:09:28 --> Form Validation Class Initialized
INFO - 2020-02-08 03:09:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-08 03:09:28 --> Final output sent to browser
DEBUG - 2020-02-08 03:09:28 --> Total execution time: 0.7118
INFO - 2020-02-08 03:52:18 --> Config Class Initialized
INFO - 2020-02-08 03:52:18 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:18 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:18 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:18 --> URI Class Initialized
INFO - 2020-02-08 03:52:19 --> Router Class Initialized
INFO - 2020-02-08 03:52:19 --> Output Class Initialized
INFO - 2020-02-08 03:52:19 --> Security Class Initialized
DEBUG - 2020-02-08 03:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:19 --> Input Class Initialized
INFO - 2020-02-08 03:52:19 --> Language Class Initialized
INFO - 2020-02-08 03:52:19 --> Loader Class Initialized
INFO - 2020-02-08 03:52:19 --> Helper loaded: url_helper
INFO - 2020-02-08 03:52:19 --> Database Driver Class Initialized
DEBUG - 2020-02-08 03:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 03:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-08 03:52:19 --> Controller Class Initialized
INFO - 2020-02-08 03:52:19 --> Model "M_tiket" initialized
INFO - 2020-02-08 03:52:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 03:52:19 --> Model "M_pesan" initialized
INFO - 2020-02-08 03:52:19 --> Helper loaded: form_helper
INFO - 2020-02-08 03:52:19 --> Form Validation Class Initialized
INFO - 2020-02-08 03:52:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-08 03:52:19 --> Final output sent to browser
DEBUG - 2020-02-08 03:52:19 --> Total execution time: 0.4772
INFO - 2020-02-08 03:52:19 --> Config Class Initialized
INFO - 2020-02-08 03:52:19 --> Config Class Initialized
INFO - 2020-02-08 03:52:19 --> Config Class Initialized
INFO - 2020-02-08 03:52:19 --> Config Class Initialized
INFO - 2020-02-08 03:52:19 --> Config Class Initialized
INFO - 2020-02-08 03:52:19 --> Config Class Initialized
INFO - 2020-02-08 03:52:19 --> Hooks Class Initialized
INFO - 2020-02-08 03:52:19 --> Hooks Class Initialized
INFO - 2020-02-08 03:52:19 --> Hooks Class Initialized
INFO - 2020-02-08 03:52:19 --> Hooks Class Initialized
INFO - 2020-02-08 03:52:19 --> Hooks Class Initialized
INFO - 2020-02-08 03:52:19 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 03:52:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 03:52:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 03:52:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 03:52:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 03:52:19 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:19 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:19 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:19 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:19 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:19 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:19 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:19 --> URI Class Initialized
INFO - 2020-02-08 03:52:19 --> URI Class Initialized
INFO - 2020-02-08 03:52:19 --> URI Class Initialized
INFO - 2020-02-08 03:52:19 --> URI Class Initialized
INFO - 2020-02-08 03:52:19 --> URI Class Initialized
INFO - 2020-02-08 03:52:19 --> URI Class Initialized
INFO - 2020-02-08 03:52:19 --> Router Class Initialized
INFO - 2020-02-08 03:52:19 --> Router Class Initialized
INFO - 2020-02-08 03:52:19 --> Router Class Initialized
INFO - 2020-02-08 03:52:19 --> Router Class Initialized
INFO - 2020-02-08 03:52:19 --> Router Class Initialized
INFO - 2020-02-08 03:52:19 --> Router Class Initialized
INFO - 2020-02-08 03:52:19 --> Output Class Initialized
INFO - 2020-02-08 03:52:19 --> Output Class Initialized
INFO - 2020-02-08 03:52:19 --> Output Class Initialized
INFO - 2020-02-08 03:52:19 --> Output Class Initialized
INFO - 2020-02-08 03:52:19 --> Output Class Initialized
INFO - 2020-02-08 03:52:19 --> Output Class Initialized
INFO - 2020-02-08 03:52:19 --> Security Class Initialized
INFO - 2020-02-08 03:52:19 --> Security Class Initialized
INFO - 2020-02-08 03:52:19 --> Security Class Initialized
INFO - 2020-02-08 03:52:19 --> Security Class Initialized
INFO - 2020-02-08 03:52:19 --> Security Class Initialized
INFO - 2020-02-08 03:52:19 --> Security Class Initialized
DEBUG - 2020-02-08 03:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 03:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 03:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 03:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 03:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 03:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:19 --> Input Class Initialized
INFO - 2020-02-08 03:52:19 --> Input Class Initialized
INFO - 2020-02-08 03:52:19 --> Input Class Initialized
INFO - 2020-02-08 03:52:19 --> Input Class Initialized
INFO - 2020-02-08 03:52:19 --> Input Class Initialized
INFO - 2020-02-08 03:52:19 --> Input Class Initialized
INFO - 2020-02-08 03:52:19 --> Language Class Initialized
INFO - 2020-02-08 03:52:19 --> Language Class Initialized
INFO - 2020-02-08 03:52:19 --> Language Class Initialized
INFO - 2020-02-08 03:52:19 --> Language Class Initialized
INFO - 2020-02-08 03:52:19 --> Language Class Initialized
INFO - 2020-02-08 03:52:19 --> Language Class Initialized
ERROR - 2020-02-08 03:52:19 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-08 03:52:19 --> Loader Class Initialized
ERROR - 2020-02-08 03:52:19 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-08 03:52:19 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-08 03:52:19 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-08 03:52:19 --> Helper loaded: url_helper
INFO - 2020-02-08 03:52:19 --> Loader Class Initialized
INFO - 2020-02-08 03:52:19 --> Helper loaded: url_helper
INFO - 2020-02-08 03:52:19 --> Database Driver Class Initialized
INFO - 2020-02-08 03:52:19 --> Config Class Initialized
INFO - 2020-02-08 03:52:20 --> Config Class Initialized
INFO - 2020-02-08 03:52:20 --> Hooks Class Initialized
INFO - 2020-02-08 03:52:20 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 03:52:20 --> Config Class Initialized
INFO - 2020-02-08 03:52:20 --> Config Class Initialized
INFO - 2020-02-08 03:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-08 03:52:20 --> Hooks Class Initialized
INFO - 2020-02-08 03:52:20 --> Hooks Class Initialized
INFO - 2020-02-08 03:52:20 --> Database Driver Class Initialized
DEBUG - 2020-02-08 03:52:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 03:52:20 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:20 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:20 --> Controller Class Initialized
INFO - 2020-02-08 03:52:20 --> Utf8 Class Initialized
DEBUG - 2020-02-08 03:52:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 03:52:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 03:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 03:52:20 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:20 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:20 --> Model "M_tiket" initialized
INFO - 2020-02-08 03:52:20 --> URI Class Initialized
INFO - 2020-02-08 03:52:20 --> URI Class Initialized
INFO - 2020-02-08 03:52:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 03:52:20 --> URI Class Initialized
INFO - 2020-02-08 03:52:20 --> Router Class Initialized
INFO - 2020-02-08 03:52:20 --> Router Class Initialized
INFO - 2020-02-08 03:52:20 --> URI Class Initialized
INFO - 2020-02-08 03:52:20 --> Model "M_pesan" initialized
INFO - 2020-02-08 03:52:20 --> Router Class Initialized
INFO - 2020-02-08 03:52:20 --> Router Class Initialized
INFO - 2020-02-08 03:52:20 --> Output Class Initialized
INFO - 2020-02-08 03:52:20 --> Output Class Initialized
INFO - 2020-02-08 03:52:20 --> Security Class Initialized
INFO - 2020-02-08 03:52:20 --> Output Class Initialized
INFO - 2020-02-08 03:52:20 --> Output Class Initialized
INFO - 2020-02-08 03:52:20 --> Helper loaded: form_helper
INFO - 2020-02-08 03:52:20 --> Security Class Initialized
INFO - 2020-02-08 03:52:20 --> Form Validation Class Initialized
DEBUG - 2020-02-08 03:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 03:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:20 --> Security Class Initialized
INFO - 2020-02-08 03:52:20 --> Security Class Initialized
INFO - 2020-02-08 03:52:20 --> Input Class Initialized
INFO - 2020-02-08 03:52:20 --> Input Class Initialized
DEBUG - 2020-02-08 03:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 03:52:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-08 03:52:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-08 03:52:20 --> Input Class Initialized
ERROR - 2020-02-08 03:52:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-08 03:52:20 --> Language Class Initialized
INFO - 2020-02-08 03:52:20 --> Input Class Initialized
INFO - 2020-02-08 03:52:20 --> Language Class Initialized
INFO - 2020-02-08 03:52:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-08 03:52:20 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-08 03:52:20 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-08 03:52:20 --> Language Class Initialized
INFO - 2020-02-08 03:52:20 --> Language Class Initialized
INFO - 2020-02-08 03:52:20 --> Final output sent to browser
ERROR - 2020-02-08 03:52:20 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-08 03:52:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-08 03:52:20 --> Config Class Initialized
INFO - 2020-02-08 03:52:20 --> Config Class Initialized
INFO - 2020-02-08 03:52:20 --> Hooks Class Initialized
INFO - 2020-02-08 03:52:20 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:20 --> Total execution time: 0.8467
INFO - 2020-02-08 03:52:20 --> Config Class Initialized
INFO - 2020-02-08 03:52:20 --> Hooks Class Initialized
INFO - 2020-02-08 03:52:20 --> Config Class Initialized
INFO - 2020-02-08 03:52:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-08 03:52:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 03:52:20 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:20 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:20 --> Controller Class Initialized
INFO - 2020-02-08 03:52:20 --> Hooks Class Initialized
INFO - 2020-02-08 03:52:20 --> Utf8 Class Initialized
DEBUG - 2020-02-08 03:52:20 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:20 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:20 --> Model "M_tiket" initialized
INFO - 2020-02-08 03:52:20 --> URI Class Initialized
INFO - 2020-02-08 03:52:20 --> URI Class Initialized
DEBUG - 2020-02-08 03:52:20 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:20 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 03:52:20 --> URI Class Initialized
INFO - 2020-02-08 03:52:20 --> Router Class Initialized
INFO - 2020-02-08 03:52:20 --> Router Class Initialized
INFO - 2020-02-08 03:52:20 --> Model "M_pesan" initialized
INFO - 2020-02-08 03:52:20 --> URI Class Initialized
INFO - 2020-02-08 03:52:20 --> Output Class Initialized
INFO - 2020-02-08 03:52:20 --> Router Class Initialized
INFO - 2020-02-08 03:52:20 --> Output Class Initialized
INFO - 2020-02-08 03:52:20 --> Security Class Initialized
INFO - 2020-02-08 03:52:20 --> Output Class Initialized
INFO - 2020-02-08 03:52:20 --> Security Class Initialized
INFO - 2020-02-08 03:52:20 --> Router Class Initialized
INFO - 2020-02-08 03:52:20 --> Helper loaded: form_helper
INFO - 2020-02-08 03:52:20 --> Form Validation Class Initialized
INFO - 2020-02-08 03:52:20 --> Security Class Initialized
DEBUG - 2020-02-08 03:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 03:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:20 --> Output Class Initialized
INFO - 2020-02-08 03:52:20 --> Input Class Initialized
INFO - 2020-02-08 03:52:20 --> Input Class Initialized
DEBUG - 2020-02-08 03:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:20 --> Security Class Initialized
ERROR - 2020-02-08 03:52:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-08 03:52:20 --> Input Class Initialized
INFO - 2020-02-08 03:52:20 --> Language Class Initialized
ERROR - 2020-02-08 03:52:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-08 03:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:20 --> Language Class Initialized
INFO - 2020-02-08 03:52:20 --> Input Class Initialized
INFO - 2020-02-08 03:52:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-08 03:52:20 --> Language Class Initialized
ERROR - 2020-02-08 03:52:20 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-08 03:52:20 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-08 03:52:20 --> Final output sent to browser
INFO - 2020-02-08 03:52:20 --> Language Class Initialized
ERROR - 2020-02-08 03:52:20 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-08 03:52:20 --> Total execution time: 1.1384
ERROR - 2020-02-08 03:52:20 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-08 03:52:20 --> Config Class Initialized
INFO - 2020-02-08 03:52:20 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:20 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:20 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:20 --> URI Class Initialized
INFO - 2020-02-08 03:52:20 --> Router Class Initialized
INFO - 2020-02-08 03:52:20 --> Output Class Initialized
INFO - 2020-02-08 03:52:20 --> Security Class Initialized
DEBUG - 2020-02-08 03:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:21 --> Input Class Initialized
INFO - 2020-02-08 03:52:21 --> Language Class Initialized
ERROR - 2020-02-08 03:52:21 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-08 03:52:21 --> Config Class Initialized
INFO - 2020-02-08 03:52:21 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:21 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:21 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:21 --> URI Class Initialized
INFO - 2020-02-08 03:52:21 --> Router Class Initialized
INFO - 2020-02-08 03:52:21 --> Output Class Initialized
INFO - 2020-02-08 03:52:21 --> Security Class Initialized
DEBUG - 2020-02-08 03:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:21 --> Input Class Initialized
INFO - 2020-02-08 03:52:21 --> Language Class Initialized
ERROR - 2020-02-08 03:52:21 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-08 03:52:21 --> Config Class Initialized
INFO - 2020-02-08 03:52:21 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:21 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:21 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:21 --> URI Class Initialized
INFO - 2020-02-08 03:52:21 --> Router Class Initialized
INFO - 2020-02-08 03:52:21 --> Output Class Initialized
INFO - 2020-02-08 03:52:21 --> Security Class Initialized
DEBUG - 2020-02-08 03:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:21 --> Input Class Initialized
INFO - 2020-02-08 03:52:21 --> Language Class Initialized
ERROR - 2020-02-08 03:52:21 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-08 03:52:21 --> Config Class Initialized
INFO - 2020-02-08 03:52:21 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:21 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:21 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:21 --> URI Class Initialized
INFO - 2020-02-08 03:52:21 --> Router Class Initialized
INFO - 2020-02-08 03:52:21 --> Output Class Initialized
INFO - 2020-02-08 03:52:21 --> Security Class Initialized
DEBUG - 2020-02-08 03:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:21 --> Input Class Initialized
INFO - 2020-02-08 03:52:21 --> Language Class Initialized
ERROR - 2020-02-08 03:52:21 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-08 03:52:21 --> Config Class Initialized
INFO - 2020-02-08 03:52:21 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:21 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:21 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:21 --> URI Class Initialized
INFO - 2020-02-08 03:52:21 --> Router Class Initialized
INFO - 2020-02-08 03:52:21 --> Output Class Initialized
INFO - 2020-02-08 03:52:22 --> Security Class Initialized
DEBUG - 2020-02-08 03:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:22 --> Input Class Initialized
INFO - 2020-02-08 03:52:22 --> Language Class Initialized
ERROR - 2020-02-08 03:52:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-08 03:52:22 --> Config Class Initialized
INFO - 2020-02-08 03:52:22 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:22 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:22 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:22 --> URI Class Initialized
INFO - 2020-02-08 03:52:22 --> Router Class Initialized
INFO - 2020-02-08 03:52:22 --> Output Class Initialized
INFO - 2020-02-08 03:52:22 --> Security Class Initialized
DEBUG - 2020-02-08 03:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:22 --> Input Class Initialized
INFO - 2020-02-08 03:52:22 --> Language Class Initialized
ERROR - 2020-02-08 03:52:22 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-08 03:52:22 --> Config Class Initialized
INFO - 2020-02-08 03:52:22 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:22 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:22 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:22 --> URI Class Initialized
INFO - 2020-02-08 03:52:22 --> Router Class Initialized
INFO - 2020-02-08 03:52:22 --> Output Class Initialized
INFO - 2020-02-08 03:52:22 --> Security Class Initialized
DEBUG - 2020-02-08 03:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:22 --> Input Class Initialized
INFO - 2020-02-08 03:52:22 --> Language Class Initialized
ERROR - 2020-02-08 03:52:22 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-08 03:52:22 --> Config Class Initialized
INFO - 2020-02-08 03:52:22 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:22 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:22 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:22 --> URI Class Initialized
INFO - 2020-02-08 03:52:22 --> Router Class Initialized
INFO - 2020-02-08 03:52:22 --> Output Class Initialized
INFO - 2020-02-08 03:52:22 --> Security Class Initialized
DEBUG - 2020-02-08 03:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:22 --> Input Class Initialized
INFO - 2020-02-08 03:52:22 --> Language Class Initialized
ERROR - 2020-02-08 03:52:22 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-08 03:52:22 --> Config Class Initialized
INFO - 2020-02-08 03:52:22 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:22 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:22 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:22 --> URI Class Initialized
INFO - 2020-02-08 03:52:22 --> Router Class Initialized
INFO - 2020-02-08 03:52:23 --> Output Class Initialized
INFO - 2020-02-08 03:52:23 --> Security Class Initialized
DEBUG - 2020-02-08 03:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:23 --> Input Class Initialized
INFO - 2020-02-08 03:52:23 --> Language Class Initialized
ERROR - 2020-02-08 03:52:23 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-08 03:52:46 --> Config Class Initialized
INFO - 2020-02-08 03:52:46 --> Hooks Class Initialized
DEBUG - 2020-02-08 03:52:46 --> UTF-8 Support Enabled
INFO - 2020-02-08 03:52:46 --> Utf8 Class Initialized
INFO - 2020-02-08 03:52:46 --> URI Class Initialized
INFO - 2020-02-08 03:52:46 --> Router Class Initialized
INFO - 2020-02-08 03:52:46 --> Output Class Initialized
INFO - 2020-02-08 03:52:46 --> Security Class Initialized
DEBUG - 2020-02-08 03:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 03:52:46 --> Input Class Initialized
INFO - 2020-02-08 03:52:46 --> Language Class Initialized
INFO - 2020-02-08 03:52:46 --> Loader Class Initialized
INFO - 2020-02-08 03:52:46 --> Helper loaded: url_helper
INFO - 2020-02-08 03:52:46 --> Database Driver Class Initialized
DEBUG - 2020-02-08 03:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 03:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-08 03:52:46 --> Controller Class Initialized
INFO - 2020-02-08 03:52:46 --> Model "M_tiket" initialized
INFO - 2020-02-08 03:52:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 03:52:46 --> Model "M_pesan" initialized
INFO - 2020-02-08 03:52:46 --> Helper loaded: form_helper
INFO - 2020-02-08 03:52:46 --> Form Validation Class Initialized
ERROR - 2020-02-08 03:52:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 47
ERROR - 2020-02-08 03:52:47 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('33', '200000', '1', '2', NULL)
INFO - 2020-02-08 03:52:47 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-08 04:40:42 --> Config Class Initialized
INFO - 2020-02-08 04:40:42 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:43 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:43 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:43 --> URI Class Initialized
INFO - 2020-02-08 04:40:43 --> Router Class Initialized
INFO - 2020-02-08 04:40:43 --> Output Class Initialized
INFO - 2020-02-08 04:40:43 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:43 --> Input Class Initialized
INFO - 2020-02-08 04:40:43 --> Language Class Initialized
INFO - 2020-02-08 04:40:43 --> Loader Class Initialized
INFO - 2020-02-08 04:40:43 --> Helper loaded: url_helper
INFO - 2020-02-08 04:40:43 --> Database Driver Class Initialized
DEBUG - 2020-02-08 04:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 04:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-08 04:40:43 --> Controller Class Initialized
INFO - 2020-02-08 04:40:43 --> Model "M_tiket" initialized
INFO - 2020-02-08 04:40:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 04:40:43 --> Model "M_pesan" initialized
INFO - 2020-02-08 04:40:43 --> Helper loaded: form_helper
INFO - 2020-02-08 04:40:43 --> Form Validation Class Initialized
INFO - 2020-02-08 04:40:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-08 04:40:43 --> Final output sent to browser
DEBUG - 2020-02-08 04:40:43 --> Total execution time: 0.8873
INFO - 2020-02-08 04:40:43 --> Config Class Initialized
INFO - 2020-02-08 04:40:43 --> Config Class Initialized
INFO - 2020-02-08 04:40:44 --> Config Class Initialized
INFO - 2020-02-08 04:40:44 --> Config Class Initialized
INFO - 2020-02-08 04:40:44 --> Hooks Class Initialized
INFO - 2020-02-08 04:40:44 --> Hooks Class Initialized
INFO - 2020-02-08 04:40:44 --> Hooks Class Initialized
INFO - 2020-02-08 04:40:44 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 04:40:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 04:40:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 04:40:44 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:44 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:44 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:44 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:44 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:44 --> URI Class Initialized
INFO - 2020-02-08 04:40:44 --> URI Class Initialized
INFO - 2020-02-08 04:40:44 --> URI Class Initialized
INFO - 2020-02-08 04:40:44 --> URI Class Initialized
INFO - 2020-02-08 04:40:44 --> Router Class Initialized
INFO - 2020-02-08 04:40:44 --> Router Class Initialized
INFO - 2020-02-08 04:40:44 --> Router Class Initialized
INFO - 2020-02-08 04:40:44 --> Router Class Initialized
INFO - 2020-02-08 04:40:44 --> Output Class Initialized
INFO - 2020-02-08 04:40:44 --> Output Class Initialized
INFO - 2020-02-08 04:40:44 --> Output Class Initialized
INFO - 2020-02-08 04:40:44 --> Output Class Initialized
INFO - 2020-02-08 04:40:44 --> Security Class Initialized
INFO - 2020-02-08 04:40:44 --> Security Class Initialized
INFO - 2020-02-08 04:40:44 --> Security Class Initialized
INFO - 2020-02-08 04:40:44 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:44 --> Input Class Initialized
DEBUG - 2020-02-08 04:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 04:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 04:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:44 --> Input Class Initialized
INFO - 2020-02-08 04:40:44 --> Input Class Initialized
INFO - 2020-02-08 04:40:44 --> Input Class Initialized
INFO - 2020-02-08 04:40:44 --> Language Class Initialized
INFO - 2020-02-08 04:40:44 --> Language Class Initialized
ERROR - 2020-02-08 04:40:44 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-08 04:40:44 --> Language Class Initialized
INFO - 2020-02-08 04:40:44 --> Language Class Initialized
ERROR - 2020-02-08 04:40:44 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-08 04:40:44 --> Loader Class Initialized
INFO - 2020-02-08 04:40:44 --> Loader Class Initialized
INFO - 2020-02-08 04:40:44 --> Helper loaded: url_helper
INFO - 2020-02-08 04:40:44 --> Helper loaded: url_helper
INFO - 2020-02-08 04:40:44 --> Database Driver Class Initialized
INFO - 2020-02-08 04:40:44 --> Database Driver Class Initialized
DEBUG - 2020-02-08 04:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 04:40:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-08 04:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 04:40:44 --> Controller Class Initialized
INFO - 2020-02-08 04:40:44 --> Model "M_tiket" initialized
INFO - 2020-02-08 04:40:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 04:40:44 --> Model "M_pesan" initialized
INFO - 2020-02-08 04:40:44 --> Helper loaded: form_helper
INFO - 2020-02-08 04:40:44 --> Form Validation Class Initialized
ERROR - 2020-02-08 04:40:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-08 04:40:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-08 04:40:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-08 04:40:44 --> Final output sent to browser
DEBUG - 2020-02-08 04:40:44 --> Total execution time: 0.7808
INFO - 2020-02-08 04:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-08 04:40:44 --> Controller Class Initialized
INFO - 2020-02-08 04:40:44 --> Model "M_tiket" initialized
INFO - 2020-02-08 04:40:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 04:40:44 --> Model "M_pesan" initialized
INFO - 2020-02-08 04:40:44 --> Helper loaded: form_helper
INFO - 2020-02-08 04:40:44 --> Form Validation Class Initialized
ERROR - 2020-02-08 04:40:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-08 04:40:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-08 04:40:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-08 04:40:45 --> Final output sent to browser
DEBUG - 2020-02-08 04:40:45 --> Total execution time: 1.0087
INFO - 2020-02-08 04:40:50 --> Config Class Initialized
INFO - 2020-02-08 04:40:50 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:50 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:50 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:50 --> URI Class Initialized
INFO - 2020-02-08 04:40:50 --> Router Class Initialized
INFO - 2020-02-08 04:40:50 --> Output Class Initialized
INFO - 2020-02-08 04:40:50 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:50 --> Input Class Initialized
INFO - 2020-02-08 04:40:50 --> Language Class Initialized
INFO - 2020-02-08 04:40:50 --> Loader Class Initialized
INFO - 2020-02-08 04:40:50 --> Helper loaded: url_helper
INFO - 2020-02-08 04:40:50 --> Database Driver Class Initialized
DEBUG - 2020-02-08 04:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 04:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-08 04:40:51 --> Controller Class Initialized
INFO - 2020-02-08 04:40:51 --> Model "M_tiket" initialized
INFO - 2020-02-08 04:40:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 04:40:51 --> Model "M_pesan" initialized
INFO - 2020-02-08 04:40:51 --> Helper loaded: form_helper
INFO - 2020-02-08 04:40:51 --> Form Validation Class Initialized
INFO - 2020-02-08 04:40:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-08 04:40:51 --> Final output sent to browser
DEBUG - 2020-02-08 04:40:51 --> Total execution time: 0.5218
INFO - 2020-02-08 04:40:51 --> Config Class Initialized
INFO - 2020-02-08 04:40:51 --> Config Class Initialized
INFO - 2020-02-08 04:40:51 --> Config Class Initialized
INFO - 2020-02-08 04:40:51 --> Config Class Initialized
INFO - 2020-02-08 04:40:51 --> Hooks Class Initialized
INFO - 2020-02-08 04:40:51 --> Hooks Class Initialized
INFO - 2020-02-08 04:40:51 --> Hooks Class Initialized
INFO - 2020-02-08 04:40:51 --> Hooks Class Initialized
INFO - 2020-02-08 04:40:51 --> Config Class Initialized
INFO - 2020-02-08 04:40:51 --> Config Class Initialized
INFO - 2020-02-08 04:40:51 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 04:40:51 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:51 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:51 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:51 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:51 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:51 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:51 --> Utf8 Class Initialized
DEBUG - 2020-02-08 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 04:40:51 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:51 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:51 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:51 --> URI Class Initialized
INFO - 2020-02-08 04:40:51 --> URI Class Initialized
INFO - 2020-02-08 04:40:51 --> URI Class Initialized
INFO - 2020-02-08 04:40:51 --> URI Class Initialized
INFO - 2020-02-08 04:40:51 --> URI Class Initialized
INFO - 2020-02-08 04:40:51 --> Router Class Initialized
INFO - 2020-02-08 04:40:51 --> Router Class Initialized
INFO - 2020-02-08 04:40:51 --> Router Class Initialized
INFO - 2020-02-08 04:40:51 --> URI Class Initialized
INFO - 2020-02-08 04:40:51 --> Router Class Initialized
INFO - 2020-02-08 04:40:51 --> Output Class Initialized
INFO - 2020-02-08 04:40:51 --> Output Class Initialized
INFO - 2020-02-08 04:40:51 --> Router Class Initialized
INFO - 2020-02-08 04:40:51 --> Router Class Initialized
INFO - 2020-02-08 04:40:51 --> Output Class Initialized
INFO - 2020-02-08 04:40:51 --> Output Class Initialized
INFO - 2020-02-08 04:40:51 --> Security Class Initialized
INFO - 2020-02-08 04:40:51 --> Output Class Initialized
INFO - 2020-02-08 04:40:51 --> Security Class Initialized
INFO - 2020-02-08 04:40:51 --> Security Class Initialized
INFO - 2020-02-08 04:40:51 --> Security Class Initialized
INFO - 2020-02-08 04:40:51 --> Output Class Initialized
DEBUG - 2020-02-08 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:51 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 04:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:51 --> Security Class Initialized
INFO - 2020-02-08 04:40:51 --> Input Class Initialized
INFO - 2020-02-08 04:40:51 --> Input Class Initialized
INFO - 2020-02-08 04:40:51 --> Input Class Initialized
INFO - 2020-02-08 04:40:51 --> Input Class Initialized
DEBUG - 2020-02-08 04:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:51 --> Input Class Initialized
INFO - 2020-02-08 04:40:51 --> Input Class Initialized
INFO - 2020-02-08 04:40:51 --> Language Class Initialized
INFO - 2020-02-08 04:40:51 --> Language Class Initialized
INFO - 2020-02-08 04:40:51 --> Language Class Initialized
INFO - 2020-02-08 04:40:51 --> Language Class Initialized
INFO - 2020-02-08 04:40:51 --> Language Class Initialized
INFO - 2020-02-08 04:40:51 --> Language Class Initialized
ERROR - 2020-02-08 04:40:51 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-08 04:40:51 --> Loader Class Initialized
ERROR - 2020-02-08 04:40:51 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-08 04:40:51 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-08 04:40:51 --> Helper loaded: url_helper
ERROR - 2020-02-08 04:40:51 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-08 04:40:51 --> Loader Class Initialized
INFO - 2020-02-08 04:40:51 --> Config Class Initialized
INFO - 2020-02-08 04:40:51 --> Config Class Initialized
INFO - 2020-02-08 04:40:51 --> Config Class Initialized
INFO - 2020-02-08 04:40:51 --> Hooks Class Initialized
INFO - 2020-02-08 04:40:51 --> Hooks Class Initialized
INFO - 2020-02-08 04:40:51 --> Hooks Class Initialized
INFO - 2020-02-08 04:40:51 --> Helper loaded: url_helper
INFO - 2020-02-08 04:40:51 --> Database Driver Class Initialized
INFO - 2020-02-08 04:40:51 --> Config Class Initialized
INFO - 2020-02-08 04:40:51 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 04:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 04:40:51 --> Database Driver Class Initialized
INFO - 2020-02-08 04:40:51 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:51 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-08 04:40:51 --> Utf8 Class Initialized
DEBUG - 2020-02-08 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 04:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 04:40:51 --> Controller Class Initialized
INFO - 2020-02-08 04:40:51 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:51 --> URI Class Initialized
INFO - 2020-02-08 04:40:51 --> URI Class Initialized
INFO - 2020-02-08 04:40:51 --> URI Class Initialized
INFO - 2020-02-08 04:40:51 --> Model "M_tiket" initialized
INFO - 2020-02-08 04:40:51 --> Router Class Initialized
INFO - 2020-02-08 04:40:51 --> URI Class Initialized
INFO - 2020-02-08 04:40:51 --> Router Class Initialized
INFO - 2020-02-08 04:40:51 --> Router Class Initialized
INFO - 2020-02-08 04:40:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 04:40:51 --> Router Class Initialized
INFO - 2020-02-08 04:40:51 --> Output Class Initialized
INFO - 2020-02-08 04:40:51 --> Output Class Initialized
INFO - 2020-02-08 04:40:51 --> Output Class Initialized
INFO - 2020-02-08 04:40:51 --> Model "M_pesan" initialized
INFO - 2020-02-08 04:40:51 --> Security Class Initialized
INFO - 2020-02-08 04:40:51 --> Security Class Initialized
INFO - 2020-02-08 04:40:51 --> Security Class Initialized
INFO - 2020-02-08 04:40:51 --> Output Class Initialized
DEBUG - 2020-02-08 04:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 04:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:51 --> Helper loaded: form_helper
INFO - 2020-02-08 04:40:51 --> Security Class Initialized
INFO - 2020-02-08 04:40:51 --> Form Validation Class Initialized
INFO - 2020-02-08 04:40:51 --> Input Class Initialized
INFO - 2020-02-08 04:40:51 --> Input Class Initialized
INFO - 2020-02-08 04:40:51 --> Input Class Initialized
DEBUG - 2020-02-08 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:51 --> Input Class Initialized
INFO - 2020-02-08 04:40:51 --> Language Class Initialized
INFO - 2020-02-08 04:40:51 --> Language Class Initialized
INFO - 2020-02-08 04:40:51 --> Language Class Initialized
ERROR - 2020-02-08 04:40:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-08 04:40:51 --> Language Class Initialized
ERROR - 2020-02-08 04:40:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-08 04:40:51 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-08 04:40:51 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-08 04:40:51 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-08 04:40:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-08 04:40:51 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-08 04:40:51 --> Config Class Initialized
INFO - 2020-02-08 04:40:51 --> Config Class Initialized
INFO - 2020-02-08 04:40:51 --> Config Class Initialized
INFO - 2020-02-08 04:40:51 --> Hooks Class Initialized
INFO - 2020-02-08 04:40:51 --> Final output sent to browser
INFO - 2020-02-08 04:40:51 --> Hooks Class Initialized
INFO - 2020-02-08 04:40:51 --> Hooks Class Initialized
INFO - 2020-02-08 04:40:52 --> Config Class Initialized
INFO - 2020-02-08 04:40:52 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:52 --> Total execution time: 0.6668
DEBUG - 2020-02-08 04:40:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 04:40:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-08 04:40:52 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:52 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:52 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:52 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-08 04:40:52 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:52 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:52 --> Controller Class Initialized
INFO - 2020-02-08 04:40:52 --> URI Class Initialized
INFO - 2020-02-08 04:40:52 --> URI Class Initialized
INFO - 2020-02-08 04:40:52 --> URI Class Initialized
INFO - 2020-02-08 04:40:52 --> URI Class Initialized
INFO - 2020-02-08 04:40:52 --> Router Class Initialized
INFO - 2020-02-08 04:40:52 --> Router Class Initialized
INFO - 2020-02-08 04:40:52 --> Model "M_tiket" initialized
INFO - 2020-02-08 04:40:52 --> Router Class Initialized
INFO - 2020-02-08 04:40:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 04:40:52 --> Router Class Initialized
INFO - 2020-02-08 04:40:52 --> Output Class Initialized
INFO - 2020-02-08 04:40:52 --> Output Class Initialized
INFO - 2020-02-08 04:40:52 --> Output Class Initialized
INFO - 2020-02-08 04:40:52 --> Model "M_pesan" initialized
INFO - 2020-02-08 04:40:52 --> Security Class Initialized
INFO - 2020-02-08 04:40:52 --> Security Class Initialized
INFO - 2020-02-08 04:40:52 --> Output Class Initialized
INFO - 2020-02-08 04:40:52 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-08 04:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:52 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:52 --> Helper loaded: form_helper
INFO - 2020-02-08 04:40:52 --> Input Class Initialized
INFO - 2020-02-08 04:40:52 --> Input Class Initialized
INFO - 2020-02-08 04:40:52 --> Input Class Initialized
INFO - 2020-02-08 04:40:52 --> Form Validation Class Initialized
DEBUG - 2020-02-08 04:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:52 --> Input Class Initialized
INFO - 2020-02-08 04:40:52 --> Language Class Initialized
INFO - 2020-02-08 04:40:52 --> Language Class Initialized
INFO - 2020-02-08 04:40:52 --> Language Class Initialized
ERROR - 2020-02-08 04:40:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-08 04:40:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-08 04:40:52 --> Language Class Initialized
ERROR - 2020-02-08 04:40:52 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-08 04:40:52 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-08 04:40:52 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-08 04:40:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-08 04:40:52 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-08 04:40:52 --> Final output sent to browser
DEBUG - 2020-02-08 04:40:52 --> Total execution time: 0.9249
INFO - 2020-02-08 04:40:52 --> Config Class Initialized
INFO - 2020-02-08 04:40:52 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:52 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:52 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:52 --> URI Class Initialized
INFO - 2020-02-08 04:40:52 --> Router Class Initialized
INFO - 2020-02-08 04:40:52 --> Output Class Initialized
INFO - 2020-02-08 04:40:52 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:52 --> Input Class Initialized
INFO - 2020-02-08 04:40:52 --> Language Class Initialized
ERROR - 2020-02-08 04:40:52 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-08 04:40:52 --> Config Class Initialized
INFO - 2020-02-08 04:40:52 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:52 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:52 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:52 --> URI Class Initialized
INFO - 2020-02-08 04:40:52 --> Router Class Initialized
INFO - 2020-02-08 04:40:52 --> Output Class Initialized
INFO - 2020-02-08 04:40:52 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:52 --> Input Class Initialized
INFO - 2020-02-08 04:40:52 --> Language Class Initialized
ERROR - 2020-02-08 04:40:52 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-08 04:40:52 --> Config Class Initialized
INFO - 2020-02-08 04:40:52 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:52 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:52 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:52 --> URI Class Initialized
INFO - 2020-02-08 04:40:52 --> Router Class Initialized
INFO - 2020-02-08 04:40:52 --> Output Class Initialized
INFO - 2020-02-08 04:40:52 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:53 --> Input Class Initialized
INFO - 2020-02-08 04:40:53 --> Language Class Initialized
ERROR - 2020-02-08 04:40:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-08 04:40:53 --> Config Class Initialized
INFO - 2020-02-08 04:40:53 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:53 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:53 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:53 --> URI Class Initialized
INFO - 2020-02-08 04:40:53 --> Router Class Initialized
INFO - 2020-02-08 04:40:53 --> Output Class Initialized
INFO - 2020-02-08 04:40:53 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:53 --> Input Class Initialized
INFO - 2020-02-08 04:40:53 --> Language Class Initialized
ERROR - 2020-02-08 04:40:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-08 04:40:53 --> Config Class Initialized
INFO - 2020-02-08 04:40:53 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:53 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:53 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:53 --> URI Class Initialized
INFO - 2020-02-08 04:40:53 --> Router Class Initialized
INFO - 2020-02-08 04:40:53 --> Output Class Initialized
INFO - 2020-02-08 04:40:53 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:53 --> Input Class Initialized
INFO - 2020-02-08 04:40:53 --> Language Class Initialized
ERROR - 2020-02-08 04:40:53 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-08 04:40:53 --> Config Class Initialized
INFO - 2020-02-08 04:40:53 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:53 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:53 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:53 --> URI Class Initialized
INFO - 2020-02-08 04:40:53 --> Router Class Initialized
INFO - 2020-02-08 04:40:53 --> Output Class Initialized
INFO - 2020-02-08 04:40:53 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:53 --> Input Class Initialized
INFO - 2020-02-08 04:40:53 --> Language Class Initialized
ERROR - 2020-02-08 04:40:53 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-08 04:40:53 --> Config Class Initialized
INFO - 2020-02-08 04:40:53 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:53 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:53 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:53 --> URI Class Initialized
INFO - 2020-02-08 04:40:53 --> Router Class Initialized
INFO - 2020-02-08 04:40:53 --> Output Class Initialized
INFO - 2020-02-08 04:40:54 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:54 --> Input Class Initialized
INFO - 2020-02-08 04:40:54 --> Language Class Initialized
ERROR - 2020-02-08 04:40:54 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-08 04:40:54 --> Config Class Initialized
INFO - 2020-02-08 04:40:54 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:40:54 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:40:54 --> Utf8 Class Initialized
INFO - 2020-02-08 04:40:54 --> URI Class Initialized
INFO - 2020-02-08 04:40:54 --> Router Class Initialized
INFO - 2020-02-08 04:40:54 --> Output Class Initialized
INFO - 2020-02-08 04:40:54 --> Security Class Initialized
DEBUG - 2020-02-08 04:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:40:54 --> Input Class Initialized
INFO - 2020-02-08 04:40:54 --> Language Class Initialized
ERROR - 2020-02-08 04:40:54 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-08 04:41:14 --> Config Class Initialized
INFO - 2020-02-08 04:41:14 --> Hooks Class Initialized
DEBUG - 2020-02-08 04:41:14 --> UTF-8 Support Enabled
INFO - 2020-02-08 04:41:14 --> Utf8 Class Initialized
INFO - 2020-02-08 04:41:14 --> URI Class Initialized
INFO - 2020-02-08 04:41:14 --> Router Class Initialized
INFO - 2020-02-08 04:41:14 --> Output Class Initialized
INFO - 2020-02-08 04:41:15 --> Security Class Initialized
DEBUG - 2020-02-08 04:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-08 04:41:15 --> Input Class Initialized
INFO - 2020-02-08 04:41:15 --> Language Class Initialized
INFO - 2020-02-08 04:41:15 --> Loader Class Initialized
INFO - 2020-02-08 04:41:15 --> Helper loaded: url_helper
INFO - 2020-02-08 04:41:15 --> Database Driver Class Initialized
DEBUG - 2020-02-08 04:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-08 04:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-08 04:41:15 --> Controller Class Initialized
INFO - 2020-02-08 04:41:15 --> Model "M_tiket" initialized
INFO - 2020-02-08 04:41:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-08 04:41:15 --> Model "M_pesan" initialized
INFO - 2020-02-08 04:41:15 --> Helper loaded: form_helper
INFO - 2020-02-08 04:41:15 --> Form Validation Class Initialized
INFO - 2020-02-08 04:41:15 --> Final output sent to browser
DEBUG - 2020-02-08 04:41:15 --> Total execution time: 0.7633
