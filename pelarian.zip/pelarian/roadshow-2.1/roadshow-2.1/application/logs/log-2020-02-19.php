<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-19 07:57:59 --> Config Class Initialized
INFO - 2020-02-19 07:58:00 --> Hooks Class Initialized
DEBUG - 2020-02-19 07:58:00 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:00 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:00 --> URI Class Initialized
INFO - 2020-02-19 07:58:01 --> Router Class Initialized
INFO - 2020-02-19 07:58:01 --> Output Class Initialized
INFO - 2020-02-19 07:58:01 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:01 --> Input Class Initialized
INFO - 2020-02-19 07:58:01 --> Language Class Initialized
INFO - 2020-02-19 07:58:01 --> Loader Class Initialized
INFO - 2020-02-19 07:58:01 --> Helper loaded: url_helper
INFO - 2020-02-19 07:58:02 --> Helper loaded: string_helper
INFO - 2020-02-19 07:58:02 --> Database Driver Class Initialized
DEBUG - 2020-02-19 07:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 07:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 07:58:03 --> Controller Class Initialized
INFO - 2020-02-19 07:58:04 --> Model "M_tiket" initialized
INFO - 2020-02-19 07:58:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 07:58:04 --> Model "M_pesan" initialized
INFO - 2020-02-19 07:58:04 --> Helper loaded: form_helper
INFO - 2020-02-19 07:58:04 --> Form Validation Class Initialized
INFO - 2020-02-19 07:58:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 07:58:07 --> Final output sent to browser
DEBUG - 2020-02-19 07:58:07 --> Total execution time: 7.9526
INFO - 2020-02-19 07:58:07 --> Config Class Initialized
INFO - 2020-02-19 07:58:07 --> Config Class Initialized
INFO - 2020-02-19 07:58:07 --> Config Class Initialized
INFO - 2020-02-19 07:58:07 --> Config Class Initialized
INFO - 2020-02-19 07:58:07 --> Config Class Initialized
INFO - 2020-02-19 07:58:07 --> Hooks Class Initialized
INFO - 2020-02-19 07:58:07 --> Hooks Class Initialized
INFO - 2020-02-19 07:58:07 --> Hooks Class Initialized
INFO - 2020-02-19 07:58:07 --> Hooks Class Initialized
INFO - 2020-02-19 07:58:07 --> Hooks Class Initialized
DEBUG - 2020-02-19 07:58:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 07:58:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 07:58:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 07:58:07 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:07 --> Config Class Initialized
INFO - 2020-02-19 07:58:07 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:07 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:07 --> Hooks Class Initialized
INFO - 2020-02-19 07:58:07 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:07 --> Utf8 Class Initialized
DEBUG - 2020-02-19 07:58:07 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:07 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:07 --> URI Class Initialized
INFO - 2020-02-19 07:58:07 --> URI Class Initialized
INFO - 2020-02-19 07:58:07 --> URI Class Initialized
INFO - 2020-02-19 07:58:07 --> URI Class Initialized
DEBUG - 2020-02-19 07:58:07 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:07 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:07 --> URI Class Initialized
INFO - 2020-02-19 07:58:07 --> Router Class Initialized
INFO - 2020-02-19 07:58:07 --> Router Class Initialized
INFO - 2020-02-19 07:58:07 --> Router Class Initialized
INFO - 2020-02-19 07:58:07 --> Router Class Initialized
INFO - 2020-02-19 07:58:07 --> Router Class Initialized
INFO - 2020-02-19 07:58:07 --> Output Class Initialized
INFO - 2020-02-19 07:58:07 --> Output Class Initialized
INFO - 2020-02-19 07:58:07 --> Output Class Initialized
INFO - 2020-02-19 07:58:07 --> URI Class Initialized
INFO - 2020-02-19 07:58:07 --> Output Class Initialized
INFO - 2020-02-19 07:58:07 --> Security Class Initialized
INFO - 2020-02-19 07:58:07 --> Security Class Initialized
INFO - 2020-02-19 07:58:07 --> Router Class Initialized
INFO - 2020-02-19 07:58:07 --> Security Class Initialized
INFO - 2020-02-19 07:58:07 --> Output Class Initialized
INFO - 2020-02-19 07:58:07 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:07 --> Security Class Initialized
INFO - 2020-02-19 07:58:07 --> Output Class Initialized
DEBUG - 2020-02-19 07:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 07:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 07:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:07 --> Input Class Initialized
INFO - 2020-02-19 07:58:07 --> Input Class Initialized
INFO - 2020-02-19 07:58:07 --> Input Class Initialized
DEBUG - 2020-02-19 07:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:07 --> Input Class Initialized
INFO - 2020-02-19 07:58:07 --> Security Class Initialized
INFO - 2020-02-19 07:58:07 --> Input Class Initialized
INFO - 2020-02-19 07:58:07 --> Language Class Initialized
INFO - 2020-02-19 07:58:07 --> Language Class Initialized
DEBUG - 2020-02-19 07:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:07 --> Language Class Initialized
INFO - 2020-02-19 07:58:07 --> Language Class Initialized
INFO - 2020-02-19 07:58:07 --> Input Class Initialized
INFO - 2020-02-19 07:58:07 --> Language Class Initialized
INFO - 2020-02-19 07:58:07 --> Loader Class Initialized
INFO - 2020-02-19 07:58:07 --> Loader Class Initialized
INFO - 2020-02-19 07:58:08 --> Language Class Initialized
INFO - 2020-02-19 07:58:08 --> Helper loaded: url_helper
INFO - 2020-02-19 07:58:08 --> Helper loaded: string_helper
INFO - 2020-02-19 07:58:08 --> Helper loaded: url_helper
ERROR - 2020-02-19 07:58:08 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-19 07:58:08 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-19 07:58:08 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-19 07:58:08 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-19 07:58:08 --> Helper loaded: string_helper
INFO - 2020-02-19 07:58:08 --> Database Driver Class Initialized
DEBUG - 2020-02-19 07:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 07:58:08 --> Database Driver Class Initialized
INFO - 2020-02-19 07:58:08 --> Config Class Initialized
INFO - 2020-02-19 07:58:08 --> Config Class Initialized
INFO - 2020-02-19 07:58:08 --> Config Class Initialized
INFO - 2020-02-19 07:58:08 --> Config Class Initialized
INFO - 2020-02-19 07:58:08 --> Hooks Class Initialized
INFO - 2020-02-19 07:58:08 --> Hooks Class Initialized
INFO - 2020-02-19 07:58:08 --> Hooks Class Initialized
INFO - 2020-02-19 07:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 07:58:08 --> Hooks Class Initialized
DEBUG - 2020-02-19 07:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 07:58:08 --> Controller Class Initialized
DEBUG - 2020-02-19 07:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 07:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 07:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 07:58:08 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:08 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:08 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:08 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:08 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:08 --> Model "M_tiket" initialized
INFO - 2020-02-19 07:58:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 07:58:08 --> URI Class Initialized
INFO - 2020-02-19 07:58:08 --> URI Class Initialized
INFO - 2020-02-19 07:58:08 --> URI Class Initialized
INFO - 2020-02-19 07:58:08 --> URI Class Initialized
INFO - 2020-02-19 07:58:08 --> Model "M_pesan" initialized
INFO - 2020-02-19 07:58:08 --> Router Class Initialized
INFO - 2020-02-19 07:58:08 --> Router Class Initialized
INFO - 2020-02-19 07:58:08 --> Router Class Initialized
INFO - 2020-02-19 07:58:08 --> Router Class Initialized
INFO - 2020-02-19 07:58:08 --> Output Class Initialized
INFO - 2020-02-19 07:58:08 --> Output Class Initialized
INFO - 2020-02-19 07:58:08 --> Helper loaded: form_helper
INFO - 2020-02-19 07:58:08 --> Output Class Initialized
INFO - 2020-02-19 07:58:08 --> Output Class Initialized
INFO - 2020-02-19 07:58:08 --> Form Validation Class Initialized
INFO - 2020-02-19 07:58:08 --> Security Class Initialized
INFO - 2020-02-19 07:58:08 --> Security Class Initialized
INFO - 2020-02-19 07:58:08 --> Security Class Initialized
INFO - 2020-02-19 07:58:08 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 07:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 07:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 07:58:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-19 07:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-19 07:58:08 --> Input Class Initialized
INFO - 2020-02-19 07:58:08 --> Input Class Initialized
INFO - 2020-02-19 07:58:08 --> Input Class Initialized
INFO - 2020-02-19 07:58:08 --> Input Class Initialized
ERROR - 2020-02-19 07:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 07:58:08 --> Language Class Initialized
INFO - 2020-02-19 07:58:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 07:58:08 --> Language Class Initialized
INFO - 2020-02-19 07:58:08 --> Language Class Initialized
INFO - 2020-02-19 07:58:08 --> Language Class Initialized
ERROR - 2020-02-19 07:58:08 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-19 07:58:08 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-19 07:58:08 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-19 07:58:08 --> Final output sent to browser
ERROR - 2020-02-19 07:58:08 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-19 07:58:08 --> Total execution time: 0.9872
INFO - 2020-02-19 07:58:08 --> Config Class Initialized
INFO - 2020-02-19 07:58:08 --> Config Class Initialized
INFO - 2020-02-19 07:58:08 --> Hooks Class Initialized
INFO - 2020-02-19 07:58:08 --> Hooks Class Initialized
INFO - 2020-02-19 07:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 07:58:08 --> Config Class Initialized
INFO - 2020-02-19 07:58:08 --> Config Class Initialized
INFO - 2020-02-19 07:58:08 --> Hooks Class Initialized
INFO - 2020-02-19 07:58:08 --> Hooks Class Initialized
INFO - 2020-02-19 07:58:08 --> Controller Class Initialized
DEBUG - 2020-02-19 07:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 07:58:08 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:08 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:08 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:08 --> Model "M_tiket" initialized
DEBUG - 2020-02-19 07:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 07:58:08 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:08 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:08 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 07:58:08 --> URI Class Initialized
INFO - 2020-02-19 07:58:08 --> URI Class Initialized
INFO - 2020-02-19 07:58:08 --> URI Class Initialized
INFO - 2020-02-19 07:58:08 --> Router Class Initialized
INFO - 2020-02-19 07:58:08 --> Router Class Initialized
INFO - 2020-02-19 07:58:08 --> Model "M_pesan" initialized
INFO - 2020-02-19 07:58:08 --> URI Class Initialized
INFO - 2020-02-19 07:58:08 --> Router Class Initialized
INFO - 2020-02-19 07:58:08 --> Router Class Initialized
INFO - 2020-02-19 07:58:08 --> Output Class Initialized
INFO - 2020-02-19 07:58:08 --> Output Class Initialized
INFO - 2020-02-19 07:58:08 --> Helper loaded: form_helper
INFO - 2020-02-19 07:58:08 --> Form Validation Class Initialized
INFO - 2020-02-19 07:58:08 --> Security Class Initialized
INFO - 2020-02-19 07:58:08 --> Output Class Initialized
INFO - 2020-02-19 07:58:08 --> Output Class Initialized
INFO - 2020-02-19 07:58:08 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:08 --> Security Class Initialized
INFO - 2020-02-19 07:58:08 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-19 07:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-19 07:58:08 --> Input Class Initialized
ERROR - 2020-02-19 07:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 07:58:08 --> Input Class Initialized
DEBUG - 2020-02-19 07:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 07:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:08 --> Input Class Initialized
INFO - 2020-02-19 07:58:08 --> Input Class Initialized
INFO - 2020-02-19 07:58:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 07:58:08 --> Language Class Initialized
INFO - 2020-02-19 07:58:08 --> Language Class Initialized
INFO - 2020-02-19 07:58:08 --> Final output sent to browser
INFO - 2020-02-19 07:58:08 --> Language Class Initialized
INFO - 2020-02-19 07:58:08 --> Language Class Initialized
ERROR - 2020-02-19 07:58:08 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-19 07:58:08 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-19 07:58:08 --> Total execution time: 1.2582
ERROR - 2020-02-19 07:58:08 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-19 07:58:08 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-19 07:58:08 --> Config Class Initialized
INFO - 2020-02-19 07:58:08 --> Hooks Class Initialized
DEBUG - 2020-02-19 07:58:08 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:08 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:08 --> URI Class Initialized
INFO - 2020-02-19 07:58:08 --> Router Class Initialized
INFO - 2020-02-19 07:58:08 --> Output Class Initialized
INFO - 2020-02-19 07:58:08 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:08 --> Input Class Initialized
INFO - 2020-02-19 07:58:08 --> Language Class Initialized
ERROR - 2020-02-19 07:58:08 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-19 07:58:08 --> Config Class Initialized
INFO - 2020-02-19 07:58:09 --> Hooks Class Initialized
DEBUG - 2020-02-19 07:58:09 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:09 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:09 --> URI Class Initialized
INFO - 2020-02-19 07:58:09 --> Router Class Initialized
INFO - 2020-02-19 07:58:09 --> Output Class Initialized
INFO - 2020-02-19 07:58:09 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:09 --> Input Class Initialized
INFO - 2020-02-19 07:58:09 --> Language Class Initialized
ERROR - 2020-02-19 07:58:09 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-19 07:58:09 --> Config Class Initialized
INFO - 2020-02-19 07:58:09 --> Hooks Class Initialized
DEBUG - 2020-02-19 07:58:09 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:09 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:09 --> URI Class Initialized
INFO - 2020-02-19 07:58:09 --> Router Class Initialized
INFO - 2020-02-19 07:58:09 --> Output Class Initialized
INFO - 2020-02-19 07:58:09 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:09 --> Input Class Initialized
INFO - 2020-02-19 07:58:09 --> Language Class Initialized
ERROR - 2020-02-19 07:58:09 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-19 07:58:09 --> Config Class Initialized
INFO - 2020-02-19 07:58:09 --> Hooks Class Initialized
DEBUG - 2020-02-19 07:58:09 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:09 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:09 --> URI Class Initialized
INFO - 2020-02-19 07:58:09 --> Router Class Initialized
INFO - 2020-02-19 07:58:09 --> Output Class Initialized
INFO - 2020-02-19 07:58:09 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:09 --> Input Class Initialized
INFO - 2020-02-19 07:58:09 --> Language Class Initialized
ERROR - 2020-02-19 07:58:09 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-19 07:58:09 --> Config Class Initialized
INFO - 2020-02-19 07:58:09 --> Hooks Class Initialized
DEBUG - 2020-02-19 07:58:09 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:09 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:09 --> URI Class Initialized
INFO - 2020-02-19 07:58:10 --> Router Class Initialized
INFO - 2020-02-19 07:58:10 --> Output Class Initialized
INFO - 2020-02-19 07:58:10 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:10 --> Input Class Initialized
INFO - 2020-02-19 07:58:10 --> Language Class Initialized
ERROR - 2020-02-19 07:58:10 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-19 07:58:10 --> Config Class Initialized
INFO - 2020-02-19 07:58:10 --> Hooks Class Initialized
DEBUG - 2020-02-19 07:58:10 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:10 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:10 --> URI Class Initialized
INFO - 2020-02-19 07:58:10 --> Router Class Initialized
INFO - 2020-02-19 07:58:10 --> Output Class Initialized
INFO - 2020-02-19 07:58:10 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:10 --> Input Class Initialized
INFO - 2020-02-19 07:58:10 --> Language Class Initialized
ERROR - 2020-02-19 07:58:10 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-19 07:58:10 --> Config Class Initialized
INFO - 2020-02-19 07:58:10 --> Hooks Class Initialized
DEBUG - 2020-02-19 07:58:10 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:10 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:10 --> URI Class Initialized
INFO - 2020-02-19 07:58:10 --> Router Class Initialized
INFO - 2020-02-19 07:58:10 --> Output Class Initialized
INFO - 2020-02-19 07:58:10 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:10 --> Input Class Initialized
INFO - 2020-02-19 07:58:10 --> Language Class Initialized
ERROR - 2020-02-19 07:58:10 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-19 07:58:10 --> Config Class Initialized
INFO - 2020-02-19 07:58:10 --> Hooks Class Initialized
DEBUG - 2020-02-19 07:58:10 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:10 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:10 --> URI Class Initialized
INFO - 2020-02-19 07:58:10 --> Router Class Initialized
INFO - 2020-02-19 07:58:10 --> Output Class Initialized
INFO - 2020-02-19 07:58:10 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:10 --> Input Class Initialized
INFO - 2020-02-19 07:58:10 --> Language Class Initialized
ERROR - 2020-02-19 07:58:10 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-19 07:58:11 --> Config Class Initialized
INFO - 2020-02-19 07:58:11 --> Hooks Class Initialized
DEBUG - 2020-02-19 07:58:11 --> UTF-8 Support Enabled
INFO - 2020-02-19 07:58:11 --> Utf8 Class Initialized
INFO - 2020-02-19 07:58:11 --> URI Class Initialized
INFO - 2020-02-19 07:58:11 --> Router Class Initialized
INFO - 2020-02-19 07:58:11 --> Output Class Initialized
INFO - 2020-02-19 07:58:11 --> Security Class Initialized
DEBUG - 2020-02-19 07:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 07:58:11 --> Input Class Initialized
INFO - 2020-02-19 07:58:11 --> Language Class Initialized
ERROR - 2020-02-19 07:58:11 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-19 14:54:42 --> Config Class Initialized
INFO - 2020-02-19 14:54:42 --> Hooks Class Initialized
DEBUG - 2020-02-19 14:54:43 --> UTF-8 Support Enabled
INFO - 2020-02-19 14:54:43 --> Utf8 Class Initialized
INFO - 2020-02-19 14:54:43 --> URI Class Initialized
INFO - 2020-02-19 14:54:43 --> Router Class Initialized
INFO - 2020-02-19 14:54:44 --> Output Class Initialized
INFO - 2020-02-19 14:54:45 --> Security Class Initialized
DEBUG - 2020-02-19 14:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 14:54:45 --> Input Class Initialized
INFO - 2020-02-19 14:54:46 --> Language Class Initialized
INFO - 2020-02-19 14:54:48 --> Loader Class Initialized
INFO - 2020-02-19 14:54:49 --> Helper loaded: url_helper
INFO - 2020-02-19 14:54:49 --> Helper loaded: string_helper
INFO - 2020-02-19 14:54:50 --> Database Driver Class Initialized
DEBUG - 2020-02-19 14:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 14:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 14:54:51 --> Controller Class Initialized
INFO - 2020-02-19 14:54:52 --> Model "M_tiket" initialized
INFO - 2020-02-19 14:54:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 14:54:52 --> Model "M_pesan" initialized
INFO - 2020-02-19 14:54:52 --> Helper loaded: form_helper
INFO - 2020-02-19 14:54:52 --> Form Validation Class Initialized
INFO - 2020-02-19 14:54:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 14:54:53 --> Final output sent to browser
DEBUG - 2020-02-19 14:54:53 --> Total execution time: 12.0764
INFO - 2020-02-19 14:54:54 --> Config Class Initialized
INFO - 2020-02-19 14:54:54 --> Hooks Class Initialized
INFO - 2020-02-19 14:54:54 --> Config Class Initialized
DEBUG - 2020-02-19 14:54:54 --> UTF-8 Support Enabled
INFO - 2020-02-19 14:54:54 --> Utf8 Class Initialized
INFO - 2020-02-19 14:54:54 --> Hooks Class Initialized
INFO - 2020-02-19 14:54:54 --> URI Class Initialized
DEBUG - 2020-02-19 14:54:54 --> UTF-8 Support Enabled
INFO - 2020-02-19 14:54:54 --> Utf8 Class Initialized
INFO - 2020-02-19 14:54:54 --> Router Class Initialized
INFO - 2020-02-19 14:54:54 --> URI Class Initialized
INFO - 2020-02-19 14:54:54 --> Output Class Initialized
INFO - 2020-02-19 14:54:54 --> Router Class Initialized
INFO - 2020-02-19 14:54:54 --> Security Class Initialized
INFO - 2020-02-19 14:54:54 --> Output Class Initialized
DEBUG - 2020-02-19 14:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 14:54:54 --> Input Class Initialized
INFO - 2020-02-19 14:54:54 --> Security Class Initialized
INFO - 2020-02-19 14:54:54 --> Language Class Initialized
DEBUG - 2020-02-19 14:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 14:54:54 --> Input Class Initialized
INFO - 2020-02-19 14:54:54 --> Loader Class Initialized
INFO - 2020-02-19 14:54:54 --> Language Class Initialized
INFO - 2020-02-19 14:54:54 --> Helper loaded: url_helper
INFO - 2020-02-19 14:54:54 --> Helper loaded: string_helper
INFO - 2020-02-19 14:54:54 --> Loader Class Initialized
INFO - 2020-02-19 14:54:55 --> Database Driver Class Initialized
INFO - 2020-02-19 14:54:55 --> Helper loaded: url_helper
INFO - 2020-02-19 14:54:55 --> Helper loaded: string_helper
DEBUG - 2020-02-19 14:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 14:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 14:54:55 --> Database Driver Class Initialized
INFO - 2020-02-19 14:54:55 --> Controller Class Initialized
DEBUG - 2020-02-19 14:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 14:54:55 --> Model "M_tiket" initialized
INFO - 2020-02-19 14:54:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 14:54:55 --> Model "M_pesan" initialized
INFO - 2020-02-19 14:54:55 --> Helper loaded: form_helper
INFO - 2020-02-19 14:54:55 --> Form Validation Class Initialized
ERROR - 2020-02-19 14:54:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-19 14:54:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 14:54:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 14:54:56 --> Final output sent to browser
DEBUG - 2020-02-19 14:54:56 --> Total execution time: 1.7333
INFO - 2020-02-19 14:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 14:54:56 --> Controller Class Initialized
INFO - 2020-02-19 14:54:56 --> Model "M_tiket" initialized
INFO - 2020-02-19 14:54:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 14:54:56 --> Model "M_pesan" initialized
INFO - 2020-02-19 14:54:57 --> Helper loaded: form_helper
INFO - 2020-02-19 14:54:57 --> Form Validation Class Initialized
ERROR - 2020-02-19 14:54:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-19 14:54:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 14:54:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 14:54:57 --> Final output sent to browser
DEBUG - 2020-02-19 14:54:57 --> Total execution time: 3.1572
INFO - 2020-02-19 16:30:18 --> Config Class Initialized
INFO - 2020-02-19 16:30:18 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:30:18 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:30:18 --> Utf8 Class Initialized
INFO - 2020-02-19 16:30:19 --> URI Class Initialized
INFO - 2020-02-19 16:30:19 --> Router Class Initialized
INFO - 2020-02-19 16:30:19 --> Output Class Initialized
INFO - 2020-02-19 16:30:19 --> Security Class Initialized
DEBUG - 2020-02-19 16:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:30:19 --> Input Class Initialized
INFO - 2020-02-19 16:30:19 --> Language Class Initialized
INFO - 2020-02-19 16:30:19 --> Loader Class Initialized
INFO - 2020-02-19 16:30:19 --> Helper loaded: url_helper
INFO - 2020-02-19 16:30:19 --> Helper loaded: string_helper
INFO - 2020-02-19 16:30:20 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:30:20 --> Controller Class Initialized
INFO - 2020-02-19 16:30:20 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:30:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:30:20 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:30:20 --> Helper loaded: form_helper
INFO - 2020-02-19 16:30:20 --> Form Validation Class Initialized
INFO - 2020-02-19 16:30:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-19 16:30:21 --> Final output sent to browser
DEBUG - 2020-02-19 16:30:21 --> Total execution time: 3.1593
INFO - 2020-02-19 16:30:29 --> Config Class Initialized
INFO - 2020-02-19 16:30:29 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:30:29 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:30:30 --> Utf8 Class Initialized
INFO - 2020-02-19 16:30:30 --> URI Class Initialized
INFO - 2020-02-19 16:30:30 --> Router Class Initialized
INFO - 2020-02-19 16:30:30 --> Output Class Initialized
INFO - 2020-02-19 16:30:30 --> Security Class Initialized
DEBUG - 2020-02-19 16:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:30:30 --> Input Class Initialized
INFO - 2020-02-19 16:30:30 --> Language Class Initialized
INFO - 2020-02-19 16:30:30 --> Loader Class Initialized
INFO - 2020-02-19 16:30:30 --> Helper loaded: url_helper
INFO - 2020-02-19 16:30:30 --> Helper loaded: string_helper
INFO - 2020-02-19 16:30:30 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:30:30 --> Controller Class Initialized
INFO - 2020-02-19 16:30:30 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:30:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:30:30 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:30:30 --> Helper loaded: form_helper
INFO - 2020-02-19 16:30:30 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:30:30 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-19 16:33:17 --> Config Class Initialized
INFO - 2020-02-19 16:33:17 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:33:17 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:33:17 --> Utf8 Class Initialized
INFO - 2020-02-19 16:33:17 --> URI Class Initialized
INFO - 2020-02-19 16:33:17 --> Router Class Initialized
INFO - 2020-02-19 16:33:17 --> Output Class Initialized
INFO - 2020-02-19 16:33:17 --> Security Class Initialized
DEBUG - 2020-02-19 16:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:33:17 --> Input Class Initialized
INFO - 2020-02-19 16:33:17 --> Language Class Initialized
INFO - 2020-02-19 16:33:17 --> Loader Class Initialized
INFO - 2020-02-19 16:33:17 --> Helper loaded: url_helper
INFO - 2020-02-19 16:33:17 --> Helper loaded: string_helper
INFO - 2020-02-19 16:33:17 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:33:17 --> Controller Class Initialized
INFO - 2020-02-19 16:33:17 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:33:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:33:17 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:33:17 --> Helper loaded: form_helper
INFO - 2020-02-19 16:33:17 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:33:17 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-19 16:33:22 --> Config Class Initialized
INFO - 2020-02-19 16:33:22 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:33:22 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:33:22 --> Utf8 Class Initialized
INFO - 2020-02-19 16:33:22 --> URI Class Initialized
INFO - 2020-02-19 16:33:22 --> Router Class Initialized
INFO - 2020-02-19 16:33:22 --> Output Class Initialized
INFO - 2020-02-19 16:33:22 --> Security Class Initialized
DEBUG - 2020-02-19 16:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:33:22 --> Input Class Initialized
INFO - 2020-02-19 16:33:23 --> Language Class Initialized
INFO - 2020-02-19 16:33:23 --> Loader Class Initialized
INFO - 2020-02-19 16:33:23 --> Helper loaded: url_helper
INFO - 2020-02-19 16:33:23 --> Helper loaded: string_helper
INFO - 2020-02-19 16:33:23 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:33:23 --> Controller Class Initialized
INFO - 2020-02-19 16:33:23 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:33:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:33:23 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:33:23 --> Helper loaded: form_helper
INFO - 2020-02-19 16:33:23 --> Form Validation Class Initialized
INFO - 2020-02-19 16:33:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 16:33:23 --> Final output sent to browser
DEBUG - 2020-02-19 16:33:23 --> Total execution time: 1.3591
INFO - 2020-02-19 16:33:24 --> Config Class Initialized
INFO - 2020-02-19 16:33:24 --> Config Class Initialized
INFO - 2020-02-19 16:33:24 --> Hooks Class Initialized
INFO - 2020-02-19 16:33:24 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 16:33:24 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:33:24 --> Utf8 Class Initialized
INFO - 2020-02-19 16:33:24 --> Utf8 Class Initialized
INFO - 2020-02-19 16:33:24 --> URI Class Initialized
INFO - 2020-02-19 16:33:24 --> URI Class Initialized
INFO - 2020-02-19 16:33:24 --> Router Class Initialized
INFO - 2020-02-19 16:33:24 --> Router Class Initialized
INFO - 2020-02-19 16:33:24 --> Output Class Initialized
INFO - 2020-02-19 16:33:24 --> Output Class Initialized
INFO - 2020-02-19 16:33:24 --> Security Class Initialized
INFO - 2020-02-19 16:33:24 --> Security Class Initialized
DEBUG - 2020-02-19 16:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 16:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:33:24 --> Input Class Initialized
INFO - 2020-02-19 16:33:24 --> Input Class Initialized
INFO - 2020-02-19 16:33:24 --> Language Class Initialized
INFO - 2020-02-19 16:33:24 --> Language Class Initialized
INFO - 2020-02-19 16:33:24 --> Loader Class Initialized
INFO - 2020-02-19 16:33:24 --> Loader Class Initialized
INFO - 2020-02-19 16:33:24 --> Helper loaded: url_helper
INFO - 2020-02-19 16:33:24 --> Helper loaded: url_helper
INFO - 2020-02-19 16:33:24 --> Helper loaded: string_helper
INFO - 2020-02-19 16:33:24 --> Helper loaded: string_helper
INFO - 2020-02-19 16:33:24 --> Database Driver Class Initialized
INFO - 2020-02-19 16:33:24 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-19 16:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:33:24 --> Controller Class Initialized
INFO - 2020-02-19 16:33:24 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:33:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:33:24 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:33:24 --> Helper loaded: form_helper
INFO - 2020-02-19 16:33:24 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-19 16:33:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 16:33:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 16:33:25 --> Final output sent to browser
DEBUG - 2020-02-19 16:33:25 --> Total execution time: 0.9987
INFO - 2020-02-19 16:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:33:25 --> Controller Class Initialized
INFO - 2020-02-19 16:33:25 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:33:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:33:25 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:33:25 --> Helper loaded: form_helper
INFO - 2020-02-19 16:33:25 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:33:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-19 16:33:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 16:33:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 16:33:25 --> Final output sent to browser
DEBUG - 2020-02-19 16:33:25 --> Total execution time: 1.5407
INFO - 2020-02-19 16:34:15 --> Config Class Initialized
INFO - 2020-02-19 16:34:15 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:34:15 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:34:15 --> Utf8 Class Initialized
INFO - 2020-02-19 16:34:15 --> URI Class Initialized
INFO - 2020-02-19 16:34:15 --> Router Class Initialized
INFO - 2020-02-19 16:34:15 --> Output Class Initialized
INFO - 2020-02-19 16:34:15 --> Security Class Initialized
DEBUG - 2020-02-19 16:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:34:15 --> Input Class Initialized
INFO - 2020-02-19 16:34:15 --> Language Class Initialized
INFO - 2020-02-19 16:34:15 --> Loader Class Initialized
INFO - 2020-02-19 16:34:15 --> Helper loaded: url_helper
INFO - 2020-02-19 16:34:15 --> Helper loaded: string_helper
INFO - 2020-02-19 16:34:15 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:34:15 --> Controller Class Initialized
INFO - 2020-02-19 16:34:15 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:34:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:34:15 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:34:15 --> Helper loaded: form_helper
INFO - 2020-02-19 16:34:15 --> Form Validation Class Initialized
INFO - 2020-02-19 16:34:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-19 16:34:16 --> Final output sent to browser
DEBUG - 2020-02-19 16:34:16 --> Total execution time: 1.0940
INFO - 2020-02-19 16:34:24 --> Config Class Initialized
INFO - 2020-02-19 16:34:24 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:34:24 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:34:24 --> Utf8 Class Initialized
INFO - 2020-02-19 16:34:24 --> URI Class Initialized
INFO - 2020-02-19 16:34:24 --> Router Class Initialized
INFO - 2020-02-19 16:34:24 --> Output Class Initialized
INFO - 2020-02-19 16:34:24 --> Security Class Initialized
DEBUG - 2020-02-19 16:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:34:24 --> Input Class Initialized
INFO - 2020-02-19 16:34:24 --> Language Class Initialized
INFO - 2020-02-19 16:34:24 --> Loader Class Initialized
INFO - 2020-02-19 16:34:24 --> Helper loaded: url_helper
INFO - 2020-02-19 16:34:24 --> Helper loaded: string_helper
INFO - 2020-02-19 16:34:24 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:34:24 --> Controller Class Initialized
INFO - 2020-02-19 16:34:24 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:34:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:34:24 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:34:24 --> Helper loaded: form_helper
INFO - 2020-02-19 16:34:24 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:34:24 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-19 16:44:46 --> Config Class Initialized
INFO - 2020-02-19 16:44:46 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:44:46 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:44:46 --> Utf8 Class Initialized
INFO - 2020-02-19 16:44:46 --> URI Class Initialized
INFO - 2020-02-19 16:44:46 --> Router Class Initialized
INFO - 2020-02-19 16:44:46 --> Output Class Initialized
INFO - 2020-02-19 16:44:46 --> Security Class Initialized
DEBUG - 2020-02-19 16:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:44:46 --> Input Class Initialized
INFO - 2020-02-19 16:44:46 --> Language Class Initialized
INFO - 2020-02-19 16:44:46 --> Loader Class Initialized
INFO - 2020-02-19 16:44:46 --> Helper loaded: url_helper
INFO - 2020-02-19 16:44:46 --> Helper loaded: string_helper
INFO - 2020-02-19 16:44:46 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:44:47 --> Controller Class Initialized
INFO - 2020-02-19 16:44:47 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:44:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:44:47 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:44:47 --> Helper loaded: form_helper
INFO - 2020-02-19 16:44:47 --> Form Validation Class Initialized
INFO - 2020-02-19 16:44:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 16:44:47 --> Final output sent to browser
DEBUG - 2020-02-19 16:44:47 --> Total execution time: 0.5565
INFO - 2020-02-19 16:44:47 --> Config Class Initialized
INFO - 2020-02-19 16:44:47 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:44:47 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:44:47 --> Utf8 Class Initialized
INFO - 2020-02-19 16:44:47 --> URI Class Initialized
INFO - 2020-02-19 16:44:47 --> Router Class Initialized
INFO - 2020-02-19 16:44:47 --> Output Class Initialized
INFO - 2020-02-19 16:44:47 --> Security Class Initialized
DEBUG - 2020-02-19 16:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:44:47 --> Config Class Initialized
INFO - 2020-02-19 16:44:47 --> Hooks Class Initialized
INFO - 2020-02-19 16:44:47 --> Input Class Initialized
INFO - 2020-02-19 16:44:47 --> Language Class Initialized
DEBUG - 2020-02-19 16:44:47 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:44:47 --> Utf8 Class Initialized
INFO - 2020-02-19 16:44:47 --> Loader Class Initialized
INFO - 2020-02-19 16:44:47 --> URI Class Initialized
INFO - 2020-02-19 16:44:47 --> Helper loaded: url_helper
INFO - 2020-02-19 16:44:47 --> Helper loaded: string_helper
INFO - 2020-02-19 16:44:47 --> Router Class Initialized
INFO - 2020-02-19 16:44:47 --> Output Class Initialized
INFO - 2020-02-19 16:44:47 --> Database Driver Class Initialized
INFO - 2020-02-19 16:44:47 --> Security Class Initialized
DEBUG - 2020-02-19 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:44:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-19 16:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:44:47 --> Input Class Initialized
INFO - 2020-02-19 16:44:47 --> Controller Class Initialized
INFO - 2020-02-19 16:44:47 --> Language Class Initialized
INFO - 2020-02-19 16:44:47 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:44:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:44:47 --> Loader Class Initialized
INFO - 2020-02-19 16:44:47 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:44:47 --> Helper loaded: url_helper
INFO - 2020-02-19 16:44:47 --> Helper loaded: string_helper
INFO - 2020-02-19 16:44:47 --> Helper loaded: form_helper
INFO - 2020-02-19 16:44:47 --> Form Validation Class Initialized
INFO - 2020-02-19 16:44:47 --> Database Driver Class Initialized
ERROR - 2020-02-19 16:44:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
DEBUG - 2020-02-19 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-02-19 16:44:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 16:44:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 16:44:47 --> Final output sent to browser
DEBUG - 2020-02-19 16:44:47 --> Total execution time: 0.5973
INFO - 2020-02-19 16:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:44:47 --> Controller Class Initialized
INFO - 2020-02-19 16:44:47 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:44:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:44:48 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:44:48 --> Helper loaded: form_helper
INFO - 2020-02-19 16:44:48 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:44:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-19 16:44:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 16:44:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 16:44:48 --> Final output sent to browser
DEBUG - 2020-02-19 16:44:48 --> Total execution time: 0.5140
INFO - 2020-02-19 16:44:49 --> Config Class Initialized
INFO - 2020-02-19 16:44:49 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:44:49 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:44:49 --> Utf8 Class Initialized
INFO - 2020-02-19 16:44:49 --> URI Class Initialized
INFO - 2020-02-19 16:44:49 --> Router Class Initialized
INFO - 2020-02-19 16:44:49 --> Output Class Initialized
INFO - 2020-02-19 16:44:49 --> Security Class Initialized
DEBUG - 2020-02-19 16:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:44:49 --> Input Class Initialized
INFO - 2020-02-19 16:44:49 --> Language Class Initialized
INFO - 2020-02-19 16:44:49 --> Loader Class Initialized
INFO - 2020-02-19 16:44:49 --> Helper loaded: url_helper
INFO - 2020-02-19 16:44:49 --> Helper loaded: string_helper
INFO - 2020-02-19 16:44:49 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:44:49 --> Controller Class Initialized
INFO - 2020-02-19 16:44:49 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:44:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:44:49 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:44:50 --> Helper loaded: form_helper
INFO - 2020-02-19 16:44:50 --> Form Validation Class Initialized
INFO - 2020-02-19 16:44:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-19 16:44:50 --> Final output sent to browser
DEBUG - 2020-02-19 16:44:50 --> Total execution time: 0.5606
INFO - 2020-02-19 16:44:53 --> Config Class Initialized
INFO - 2020-02-19 16:44:53 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:44:53 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:44:53 --> Utf8 Class Initialized
INFO - 2020-02-19 16:44:53 --> URI Class Initialized
INFO - 2020-02-19 16:44:53 --> Router Class Initialized
INFO - 2020-02-19 16:44:53 --> Output Class Initialized
INFO - 2020-02-19 16:44:53 --> Security Class Initialized
DEBUG - 2020-02-19 16:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:44:53 --> Input Class Initialized
INFO - 2020-02-19 16:44:53 --> Language Class Initialized
INFO - 2020-02-19 16:44:53 --> Loader Class Initialized
INFO - 2020-02-19 16:44:53 --> Helper loaded: url_helper
INFO - 2020-02-19 16:44:53 --> Helper loaded: string_helper
INFO - 2020-02-19 16:44:54 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:44:54 --> Controller Class Initialized
INFO - 2020-02-19 16:44:54 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:44:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:44:54 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:44:54 --> Helper loaded: form_helper
INFO - 2020-02-19 16:44:54 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:44:54 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-19 16:46:36 --> Config Class Initialized
INFO - 2020-02-19 16:46:36 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:46:36 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:46:37 --> Utf8 Class Initialized
INFO - 2020-02-19 16:46:37 --> URI Class Initialized
INFO - 2020-02-19 16:46:37 --> Router Class Initialized
INFO - 2020-02-19 16:46:37 --> Output Class Initialized
INFO - 2020-02-19 16:46:37 --> Security Class Initialized
DEBUG - 2020-02-19 16:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:46:37 --> Input Class Initialized
INFO - 2020-02-19 16:46:37 --> Language Class Initialized
INFO - 2020-02-19 16:46:37 --> Loader Class Initialized
INFO - 2020-02-19 16:46:37 --> Helper loaded: url_helper
INFO - 2020-02-19 16:46:37 --> Helper loaded: string_helper
INFO - 2020-02-19 16:46:37 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:46:37 --> Controller Class Initialized
INFO - 2020-02-19 16:46:37 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:46:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:46:37 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:46:37 --> Helper loaded: form_helper
INFO - 2020-02-19 16:46:37 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:46:37 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-19 16:46:41 --> Config Class Initialized
INFO - 2020-02-19 16:46:41 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:46:41 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:46:41 --> Utf8 Class Initialized
INFO - 2020-02-19 16:46:41 --> URI Class Initialized
INFO - 2020-02-19 16:46:41 --> Router Class Initialized
INFO - 2020-02-19 16:46:41 --> Output Class Initialized
INFO - 2020-02-19 16:46:41 --> Security Class Initialized
DEBUG - 2020-02-19 16:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:46:41 --> Input Class Initialized
INFO - 2020-02-19 16:46:41 --> Language Class Initialized
INFO - 2020-02-19 16:46:41 --> Loader Class Initialized
INFO - 2020-02-19 16:46:41 --> Helper loaded: url_helper
INFO - 2020-02-19 16:46:41 --> Helper loaded: string_helper
INFO - 2020-02-19 16:46:41 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:46:41 --> Controller Class Initialized
INFO - 2020-02-19 16:46:41 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:46:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:46:41 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:46:41 --> Helper loaded: form_helper
INFO - 2020-02-19 16:46:41 --> Form Validation Class Initialized
INFO - 2020-02-19 16:46:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 16:46:41 --> Final output sent to browser
DEBUG - 2020-02-19 16:46:41 --> Total execution time: 0.4003
INFO - 2020-02-19 16:46:41 --> Config Class Initialized
INFO - 2020-02-19 16:46:41 --> Config Class Initialized
INFO - 2020-02-19 16:46:41 --> Hooks Class Initialized
INFO - 2020-02-19 16:46:41 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:46:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 16:46:41 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:46:41 --> Utf8 Class Initialized
INFO - 2020-02-19 16:46:41 --> Utf8 Class Initialized
INFO - 2020-02-19 16:46:41 --> URI Class Initialized
INFO - 2020-02-19 16:46:41 --> URI Class Initialized
INFO - 2020-02-19 16:46:41 --> Router Class Initialized
INFO - 2020-02-19 16:46:41 --> Router Class Initialized
INFO - 2020-02-19 16:46:41 --> Output Class Initialized
INFO - 2020-02-19 16:46:41 --> Output Class Initialized
INFO - 2020-02-19 16:46:41 --> Security Class Initialized
INFO - 2020-02-19 16:46:41 --> Security Class Initialized
DEBUG - 2020-02-19 16:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 16:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:46:41 --> Input Class Initialized
INFO - 2020-02-19 16:46:41 --> Input Class Initialized
INFO - 2020-02-19 16:46:41 --> Language Class Initialized
INFO - 2020-02-19 16:46:41 --> Language Class Initialized
INFO - 2020-02-19 16:46:41 --> Loader Class Initialized
INFO - 2020-02-19 16:46:41 --> Loader Class Initialized
INFO - 2020-02-19 16:46:41 --> Helper loaded: url_helper
INFO - 2020-02-19 16:46:41 --> Helper loaded: url_helper
INFO - 2020-02-19 16:46:41 --> Helper loaded: string_helper
INFO - 2020-02-19 16:46:41 --> Helper loaded: string_helper
INFO - 2020-02-19 16:46:41 --> Database Driver Class Initialized
INFO - 2020-02-19 16:46:41 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-19 16:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:46:41 --> Controller Class Initialized
INFO - 2020-02-19 16:46:41 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:46:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:46:41 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:46:42 --> Helper loaded: form_helper
INFO - 2020-02-19 16:46:42 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:46:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-19 16:46:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 16:46:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 16:46:42 --> Final output sent to browser
DEBUG - 2020-02-19 16:46:42 --> Total execution time: 0.5664
INFO - 2020-02-19 16:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:46:42 --> Controller Class Initialized
INFO - 2020-02-19 16:46:42 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:46:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:46:42 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:46:42 --> Helper loaded: form_helper
INFO - 2020-02-19 16:46:42 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:46:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-19 16:46:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 16:46:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 16:46:42 --> Final output sent to browser
DEBUG - 2020-02-19 16:46:42 --> Total execution time: 0.7657
INFO - 2020-02-19 16:46:46 --> Config Class Initialized
INFO - 2020-02-19 16:46:46 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:46:46 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:46:46 --> Utf8 Class Initialized
INFO - 2020-02-19 16:46:46 --> URI Class Initialized
INFO - 2020-02-19 16:46:46 --> Router Class Initialized
INFO - 2020-02-19 16:46:47 --> Output Class Initialized
INFO - 2020-02-19 16:46:47 --> Security Class Initialized
DEBUG - 2020-02-19 16:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:46:47 --> Input Class Initialized
INFO - 2020-02-19 16:46:47 --> Language Class Initialized
INFO - 2020-02-19 16:46:47 --> Loader Class Initialized
INFO - 2020-02-19 16:46:47 --> Helper loaded: url_helper
INFO - 2020-02-19 16:46:47 --> Helper loaded: string_helper
INFO - 2020-02-19 16:46:47 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:46:47 --> Controller Class Initialized
INFO - 2020-02-19 16:46:47 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:46:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:46:47 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:46:47 --> Helper loaded: form_helper
INFO - 2020-02-19 16:46:47 --> Form Validation Class Initialized
INFO - 2020-02-19 16:46:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-19 16:46:47 --> Final output sent to browser
DEBUG - 2020-02-19 16:46:47 --> Total execution time: 0.5493
INFO - 2020-02-19 16:46:49 --> Config Class Initialized
INFO - 2020-02-19 16:46:49 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:46:49 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:46:49 --> Utf8 Class Initialized
INFO - 2020-02-19 16:46:49 --> URI Class Initialized
INFO - 2020-02-19 16:46:49 --> Router Class Initialized
INFO - 2020-02-19 16:46:49 --> Output Class Initialized
INFO - 2020-02-19 16:46:49 --> Security Class Initialized
DEBUG - 2020-02-19 16:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:46:50 --> Input Class Initialized
INFO - 2020-02-19 16:46:50 --> Language Class Initialized
INFO - 2020-02-19 16:46:50 --> Loader Class Initialized
INFO - 2020-02-19 16:46:50 --> Helper loaded: url_helper
INFO - 2020-02-19 16:46:50 --> Helper loaded: string_helper
INFO - 2020-02-19 16:46:50 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:46:50 --> Controller Class Initialized
INFO - 2020-02-19 16:46:50 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:46:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:46:50 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:46:50 --> Helper loaded: form_helper
INFO - 2020-02-19 16:46:50 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:46:50 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-19 16:47:21 --> Config Class Initialized
INFO - 2020-02-19 16:47:21 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:47:21 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:47:21 --> Utf8 Class Initialized
INFO - 2020-02-19 16:47:21 --> URI Class Initialized
INFO - 2020-02-19 16:47:21 --> Router Class Initialized
INFO - 2020-02-19 16:47:21 --> Output Class Initialized
INFO - 2020-02-19 16:47:21 --> Security Class Initialized
DEBUG - 2020-02-19 16:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:47:21 --> Input Class Initialized
INFO - 2020-02-19 16:47:21 --> Language Class Initialized
INFO - 2020-02-19 16:47:21 --> Loader Class Initialized
INFO - 2020-02-19 16:47:21 --> Helper loaded: url_helper
INFO - 2020-02-19 16:47:21 --> Helper loaded: string_helper
INFO - 2020-02-19 16:47:21 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:47:21 --> Controller Class Initialized
INFO - 2020-02-19 16:47:21 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:47:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:47:21 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:47:21 --> Helper loaded: form_helper
INFO - 2020-02-19 16:47:21 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:47:21 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-19 16:47:24 --> Config Class Initialized
INFO - 2020-02-19 16:47:24 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:47:24 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:47:24 --> Utf8 Class Initialized
INFO - 2020-02-19 16:47:24 --> URI Class Initialized
INFO - 2020-02-19 16:47:24 --> Router Class Initialized
INFO - 2020-02-19 16:47:24 --> Output Class Initialized
INFO - 2020-02-19 16:47:24 --> Security Class Initialized
DEBUG - 2020-02-19 16:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:47:24 --> Input Class Initialized
INFO - 2020-02-19 16:47:24 --> Language Class Initialized
INFO - 2020-02-19 16:47:24 --> Loader Class Initialized
INFO - 2020-02-19 16:47:24 --> Helper loaded: url_helper
INFO - 2020-02-19 16:47:24 --> Helper loaded: string_helper
INFO - 2020-02-19 16:47:25 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:47:25 --> Controller Class Initialized
INFO - 2020-02-19 16:47:25 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:47:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:47:25 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:47:25 --> Helper loaded: form_helper
INFO - 2020-02-19 16:47:25 --> Form Validation Class Initialized
INFO - 2020-02-19 16:47:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 16:47:25 --> Final output sent to browser
DEBUG - 2020-02-19 16:47:25 --> Total execution time: 0.5559
INFO - 2020-02-19 16:47:25 --> Config Class Initialized
INFO - 2020-02-19 16:47:25 --> Config Class Initialized
INFO - 2020-02-19 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-19 16:47:25 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:47:25 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:47:25 --> Utf8 Class Initialized
DEBUG - 2020-02-19 16:47:25 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:47:25 --> URI Class Initialized
INFO - 2020-02-19 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-19 16:47:25 --> URI Class Initialized
INFO - 2020-02-19 16:47:25 --> Router Class Initialized
INFO - 2020-02-19 16:47:25 --> Router Class Initialized
INFO - 2020-02-19 16:47:25 --> Output Class Initialized
INFO - 2020-02-19 16:47:25 --> Security Class Initialized
INFO - 2020-02-19 16:47:25 --> Output Class Initialized
DEBUG - 2020-02-19 16:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:47:25 --> Security Class Initialized
INFO - 2020-02-19 16:47:25 --> Input Class Initialized
DEBUG - 2020-02-19 16:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:47:25 --> Input Class Initialized
INFO - 2020-02-19 16:47:25 --> Language Class Initialized
INFO - 2020-02-19 16:47:25 --> Language Class Initialized
INFO - 2020-02-19 16:47:25 --> Loader Class Initialized
INFO - 2020-02-19 16:47:25 --> Helper loaded: url_helper
INFO - 2020-02-19 16:47:25 --> Loader Class Initialized
INFO - 2020-02-19 16:47:25 --> Helper loaded: string_helper
INFO - 2020-02-19 16:47:25 --> Helper loaded: url_helper
INFO - 2020-02-19 16:47:25 --> Helper loaded: string_helper
INFO - 2020-02-19 16:47:25 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:47:25 --> Database Driver Class Initialized
INFO - 2020-02-19 16:47:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-19 16:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:47:25 --> Controller Class Initialized
INFO - 2020-02-19 16:47:25 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:47:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:47:25 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:47:25 --> Helper loaded: form_helper
INFO - 2020-02-19 16:47:25 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:47:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-19 16:47:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 16:47:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 16:47:25 --> Final output sent to browser
DEBUG - 2020-02-19 16:47:26 --> Total execution time: 0.5926
INFO - 2020-02-19 16:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:47:26 --> Controller Class Initialized
INFO - 2020-02-19 16:47:26 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:47:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:47:26 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:47:26 --> Helper loaded: form_helper
INFO - 2020-02-19 16:47:26 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:47:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-19 16:47:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 16:47:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 16:47:26 --> Final output sent to browser
DEBUG - 2020-02-19 16:47:26 --> Total execution time: 0.7755
INFO - 2020-02-19 16:47:37 --> Config Class Initialized
INFO - 2020-02-19 16:47:37 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:47:37 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:47:37 --> Utf8 Class Initialized
INFO - 2020-02-19 16:47:37 --> URI Class Initialized
INFO - 2020-02-19 16:47:37 --> Router Class Initialized
INFO - 2020-02-19 16:47:38 --> Output Class Initialized
INFO - 2020-02-19 16:47:38 --> Security Class Initialized
DEBUG - 2020-02-19 16:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:47:38 --> Input Class Initialized
INFO - 2020-02-19 16:47:38 --> Language Class Initialized
INFO - 2020-02-19 16:47:38 --> Loader Class Initialized
INFO - 2020-02-19 16:47:38 --> Helper loaded: url_helper
INFO - 2020-02-19 16:47:38 --> Helper loaded: string_helper
INFO - 2020-02-19 16:47:38 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:47:38 --> Controller Class Initialized
INFO - 2020-02-19 16:47:38 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:47:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:47:38 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:47:38 --> Helper loaded: form_helper
INFO - 2020-02-19 16:47:38 --> Form Validation Class Initialized
INFO - 2020-02-19 16:47:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-19 16:47:38 --> Final output sent to browser
DEBUG - 2020-02-19 16:47:38 --> Total execution time: 0.6451
INFO - 2020-02-19 16:47:42 --> Config Class Initialized
INFO - 2020-02-19 16:47:42 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:47:42 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:47:42 --> Utf8 Class Initialized
INFO - 2020-02-19 16:47:42 --> URI Class Initialized
INFO - 2020-02-19 16:47:42 --> Router Class Initialized
INFO - 2020-02-19 16:47:42 --> Output Class Initialized
INFO - 2020-02-19 16:47:42 --> Security Class Initialized
DEBUG - 2020-02-19 16:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:47:42 --> Input Class Initialized
INFO - 2020-02-19 16:47:42 --> Language Class Initialized
INFO - 2020-02-19 16:47:42 --> Loader Class Initialized
INFO - 2020-02-19 16:47:42 --> Helper loaded: url_helper
INFO - 2020-02-19 16:47:42 --> Helper loaded: string_helper
INFO - 2020-02-19 16:47:42 --> Database Driver Class Initialized
DEBUG - 2020-02-19 16:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 16:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 16:47:42 --> Controller Class Initialized
INFO - 2020-02-19 16:47:42 --> Model "M_tiket" initialized
INFO - 2020-02-19 16:47:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 16:47:42 --> Model "M_pesan" initialized
INFO - 2020-02-19 16:47:42 --> Helper loaded: form_helper
INFO - 2020-02-19 16:47:42 --> Form Validation Class Initialized
ERROR - 2020-02-19 16:47:42 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-19 17:09:28 --> Config Class Initialized
INFO - 2020-02-19 17:09:28 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:09:28 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:09:28 --> Utf8 Class Initialized
INFO - 2020-02-19 17:09:28 --> URI Class Initialized
INFO - 2020-02-19 17:09:28 --> Router Class Initialized
INFO - 2020-02-19 17:09:28 --> Output Class Initialized
INFO - 2020-02-19 17:09:28 --> Security Class Initialized
DEBUG - 2020-02-19 17:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:09:28 --> Input Class Initialized
INFO - 2020-02-19 17:09:28 --> Language Class Initialized
INFO - 2020-02-19 17:09:28 --> Loader Class Initialized
INFO - 2020-02-19 17:09:28 --> Helper loaded: url_helper
INFO - 2020-02-19 17:09:28 --> Helper loaded: string_helper
INFO - 2020-02-19 17:09:28 --> Database Driver Class Initialized
DEBUG - 2020-02-19 17:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 17:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 17:09:28 --> Controller Class Initialized
INFO - 2020-02-19 17:09:28 --> Model "M_tiket" initialized
INFO - 2020-02-19 17:09:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 17:09:28 --> Model "M_pesan" initialized
INFO - 2020-02-19 17:09:28 --> Helper loaded: form_helper
INFO - 2020-02-19 17:09:28 --> Form Validation Class Initialized
ERROR - 2020-02-19 17:09:29 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-19 17:09:32 --> Config Class Initialized
INFO - 2020-02-19 17:09:32 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:09:32 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:09:32 --> Utf8 Class Initialized
INFO - 2020-02-19 17:09:32 --> URI Class Initialized
INFO - 2020-02-19 17:09:32 --> Router Class Initialized
INFO - 2020-02-19 17:09:32 --> Output Class Initialized
INFO - 2020-02-19 17:09:32 --> Security Class Initialized
DEBUG - 2020-02-19 17:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:09:32 --> Input Class Initialized
INFO - 2020-02-19 17:09:32 --> Language Class Initialized
INFO - 2020-02-19 17:09:32 --> Loader Class Initialized
INFO - 2020-02-19 17:09:32 --> Helper loaded: url_helper
INFO - 2020-02-19 17:09:32 --> Helper loaded: string_helper
INFO - 2020-02-19 17:09:32 --> Database Driver Class Initialized
DEBUG - 2020-02-19 17:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 17:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 17:09:32 --> Controller Class Initialized
INFO - 2020-02-19 17:09:32 --> Model "M_tiket" initialized
INFO - 2020-02-19 17:09:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 17:09:32 --> Model "M_pesan" initialized
INFO - 2020-02-19 17:09:33 --> Helper loaded: form_helper
INFO - 2020-02-19 17:09:33 --> Form Validation Class Initialized
INFO - 2020-02-19 17:09:33 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 17:09:33 --> Final output sent to browser
DEBUG - 2020-02-19 17:09:33 --> Total execution time: 0.5025
INFO - 2020-02-19 17:09:33 --> Config Class Initialized
INFO - 2020-02-19 17:09:33 --> Config Class Initialized
INFO - 2020-02-19 17:09:33 --> Hooks Class Initialized
INFO - 2020-02-19 17:09:33 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:09:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 17:09:33 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:09:33 --> Utf8 Class Initialized
INFO - 2020-02-19 17:09:33 --> Utf8 Class Initialized
INFO - 2020-02-19 17:09:33 --> URI Class Initialized
INFO - 2020-02-19 17:09:33 --> URI Class Initialized
INFO - 2020-02-19 17:09:33 --> Router Class Initialized
INFO - 2020-02-19 17:09:33 --> Output Class Initialized
INFO - 2020-02-19 17:09:33 --> Router Class Initialized
INFO - 2020-02-19 17:09:33 --> Security Class Initialized
INFO - 2020-02-19 17:09:33 --> Output Class Initialized
DEBUG - 2020-02-19 17:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:09:33 --> Security Class Initialized
INFO - 2020-02-19 17:09:33 --> Input Class Initialized
DEBUG - 2020-02-19 17:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:09:33 --> Input Class Initialized
INFO - 2020-02-19 17:09:33 --> Language Class Initialized
INFO - 2020-02-19 17:09:33 --> Language Class Initialized
INFO - 2020-02-19 17:09:33 --> Loader Class Initialized
INFO - 2020-02-19 17:09:33 --> Helper loaded: url_helper
INFO - 2020-02-19 17:09:33 --> Loader Class Initialized
INFO - 2020-02-19 17:09:33 --> Helper loaded: string_helper
INFO - 2020-02-19 17:09:33 --> Helper loaded: url_helper
INFO - 2020-02-19 17:09:33 --> Helper loaded: string_helper
INFO - 2020-02-19 17:09:33 --> Database Driver Class Initialized
DEBUG - 2020-02-19 17:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 17:09:33 --> Database Driver Class Initialized
INFO - 2020-02-19 17:09:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-19 17:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 17:09:34 --> Controller Class Initialized
INFO - 2020-02-19 17:09:34 --> Model "M_tiket" initialized
INFO - 2020-02-19 17:09:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 17:09:34 --> Model "M_pesan" initialized
INFO - 2020-02-19 17:09:34 --> Helper loaded: form_helper
INFO - 2020-02-19 17:09:34 --> Form Validation Class Initialized
ERROR - 2020-02-19 17:09:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-19 17:09:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 17:09:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 17:09:34 --> Final output sent to browser
DEBUG - 2020-02-19 17:09:34 --> Total execution time: 0.6906
INFO - 2020-02-19 17:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 17:09:34 --> Controller Class Initialized
INFO - 2020-02-19 17:09:34 --> Model "M_tiket" initialized
INFO - 2020-02-19 17:09:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 17:09:34 --> Model "M_pesan" initialized
INFO - 2020-02-19 17:09:34 --> Helper loaded: form_helper
INFO - 2020-02-19 17:09:34 --> Form Validation Class Initialized
ERROR - 2020-02-19 17:09:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-19 17:09:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 17:09:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 17:09:34 --> Final output sent to browser
DEBUG - 2020-02-19 17:09:34 --> Total execution time: 0.8833
INFO - 2020-02-19 17:09:38 --> Config Class Initialized
INFO - 2020-02-19 17:09:38 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:09:38 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:09:38 --> Utf8 Class Initialized
INFO - 2020-02-19 17:09:38 --> URI Class Initialized
INFO - 2020-02-19 17:09:38 --> Router Class Initialized
INFO - 2020-02-19 17:09:38 --> Output Class Initialized
INFO - 2020-02-19 17:09:38 --> Security Class Initialized
DEBUG - 2020-02-19 17:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:09:38 --> Input Class Initialized
INFO - 2020-02-19 17:09:38 --> Language Class Initialized
INFO - 2020-02-19 17:09:38 --> Loader Class Initialized
INFO - 2020-02-19 17:09:38 --> Helper loaded: url_helper
INFO - 2020-02-19 17:09:38 --> Helper loaded: string_helper
INFO - 2020-02-19 17:09:38 --> Database Driver Class Initialized
DEBUG - 2020-02-19 17:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 17:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 17:09:38 --> Controller Class Initialized
INFO - 2020-02-19 17:09:38 --> Model "M_tiket" initialized
INFO - 2020-02-19 17:09:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 17:09:38 --> Model "M_pesan" initialized
INFO - 2020-02-19 17:09:38 --> Helper loaded: form_helper
INFO - 2020-02-19 17:09:38 --> Form Validation Class Initialized
INFO - 2020-02-19 17:09:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-19 17:09:38 --> Final output sent to browser
DEBUG - 2020-02-19 17:09:38 --> Total execution time: 0.5681
INFO - 2020-02-19 17:10:39 --> Config Class Initialized
INFO - 2020-02-19 17:10:40 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:10:40 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:10:40 --> Utf8 Class Initialized
INFO - 2020-02-19 17:10:40 --> URI Class Initialized
INFO - 2020-02-19 17:10:40 --> Router Class Initialized
INFO - 2020-02-19 17:10:40 --> Output Class Initialized
INFO - 2020-02-19 17:10:40 --> Security Class Initialized
DEBUG - 2020-02-19 17:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:10:40 --> Input Class Initialized
INFO - 2020-02-19 17:10:40 --> Language Class Initialized
INFO - 2020-02-19 17:10:40 --> Loader Class Initialized
INFO - 2020-02-19 17:10:40 --> Helper loaded: url_helper
INFO - 2020-02-19 17:10:40 --> Helper loaded: string_helper
INFO - 2020-02-19 17:10:40 --> Database Driver Class Initialized
DEBUG - 2020-02-19 17:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 17:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 17:10:40 --> Controller Class Initialized
INFO - 2020-02-19 17:10:40 --> Model "M_tiket" initialized
INFO - 2020-02-19 17:10:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 17:10:40 --> Model "M_pesan" initialized
INFO - 2020-02-19 17:10:40 --> Helper loaded: form_helper
INFO - 2020-02-19 17:10:40 --> Form Validation Class Initialized
ERROR - 2020-02-19 17:10:40 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-19 17:12:10 --> Config Class Initialized
INFO - 2020-02-19 17:12:10 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:12:10 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:12:10 --> Utf8 Class Initialized
INFO - 2020-02-19 17:12:10 --> URI Class Initialized
INFO - 2020-02-19 17:12:10 --> Router Class Initialized
INFO - 2020-02-19 17:12:10 --> Output Class Initialized
INFO - 2020-02-19 17:12:10 --> Security Class Initialized
DEBUG - 2020-02-19 17:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:12:10 --> Input Class Initialized
INFO - 2020-02-19 17:12:10 --> Language Class Initialized
INFO - 2020-02-19 17:12:10 --> Loader Class Initialized
INFO - 2020-02-19 17:12:10 --> Helper loaded: url_helper
INFO - 2020-02-19 17:12:10 --> Helper loaded: string_helper
INFO - 2020-02-19 17:12:10 --> Database Driver Class Initialized
DEBUG - 2020-02-19 17:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 17:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 17:12:10 --> Controller Class Initialized
INFO - 2020-02-19 17:12:10 --> Model "M_tiket" initialized
INFO - 2020-02-19 17:12:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 17:12:10 --> Model "M_pesan" initialized
INFO - 2020-02-19 17:12:10 --> Helper loaded: form_helper
INFO - 2020-02-19 17:12:10 --> Form Validation Class Initialized
INFO - 2020-02-19 17:12:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 17:12:10 --> Final output sent to browser
DEBUG - 2020-02-19 17:12:10 --> Total execution time: 0.4294
INFO - 2020-02-19 17:12:11 --> Config Class Initialized
INFO - 2020-02-19 17:12:11 --> Config Class Initialized
INFO - 2020-02-19 17:12:11 --> Hooks Class Initialized
INFO - 2020-02-19 17:12:11 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:12:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 17:12:11 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:12:11 --> Utf8 Class Initialized
INFO - 2020-02-19 17:12:11 --> Utf8 Class Initialized
INFO - 2020-02-19 17:12:11 --> URI Class Initialized
INFO - 2020-02-19 17:12:11 --> URI Class Initialized
INFO - 2020-02-19 17:12:11 --> Router Class Initialized
INFO - 2020-02-19 17:12:11 --> Router Class Initialized
INFO - 2020-02-19 17:12:11 --> Output Class Initialized
INFO - 2020-02-19 17:12:11 --> Output Class Initialized
INFO - 2020-02-19 17:12:11 --> Security Class Initialized
INFO - 2020-02-19 17:12:11 --> Security Class Initialized
DEBUG - 2020-02-19 17:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 17:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:12:11 --> Input Class Initialized
INFO - 2020-02-19 17:12:11 --> Input Class Initialized
INFO - 2020-02-19 17:12:11 --> Language Class Initialized
INFO - 2020-02-19 17:12:11 --> Language Class Initialized
INFO - 2020-02-19 17:12:11 --> Loader Class Initialized
INFO - 2020-02-19 17:12:11 --> Helper loaded: url_helper
INFO - 2020-02-19 17:12:11 --> Loader Class Initialized
INFO - 2020-02-19 17:12:11 --> Helper loaded: string_helper
INFO - 2020-02-19 17:12:11 --> Helper loaded: url_helper
INFO - 2020-02-19 17:12:11 --> Helper loaded: string_helper
INFO - 2020-02-19 17:12:11 --> Database Driver Class Initialized
DEBUG - 2020-02-19 17:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 17:12:11 --> Database Driver Class Initialized
INFO - 2020-02-19 17:12:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-19 17:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-19 17:12:11 --> Controller Class Initialized
INFO - 2020-02-19 17:12:11 --> Model "M_tiket" initialized
INFO - 2020-02-19 17:12:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 17:12:11 --> Model "M_pesan" initialized
INFO - 2020-02-19 17:12:11 --> Helper loaded: form_helper
INFO - 2020-02-19 17:12:12 --> Form Validation Class Initialized
ERROR - 2020-02-19 17:12:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-19 17:12:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 17:12:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 17:12:12 --> Final output sent to browser
DEBUG - 2020-02-19 17:12:12 --> Total execution time: 0.5428
INFO - 2020-02-19 17:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-19 17:12:12 --> Controller Class Initialized
INFO - 2020-02-19 17:12:12 --> Model "M_tiket" initialized
INFO - 2020-02-19 17:12:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-19 17:12:12 --> Model "M_pesan" initialized
INFO - 2020-02-19 17:12:12 --> Helper loaded: form_helper
INFO - 2020-02-19 17:12:12 --> Form Validation Class Initialized
ERROR - 2020-02-19 17:12:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-19 17:12:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-19 17:12:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-19 17:12:12 --> Final output sent to browser
DEBUG - 2020-02-19 17:12:12 --> Total execution time: 0.7546
