<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-08 16:47:44 --> Config Class Initialized
INFO - 2020-03-08 16:47:44 --> Hooks Class Initialized
DEBUG - 2020-03-08 16:47:44 --> UTF-8 Support Enabled
INFO - 2020-03-08 16:47:44 --> Utf8 Class Initialized
INFO - 2020-03-08 16:47:44 --> URI Class Initialized
DEBUG - 2020-03-08 16:47:44 --> No URI present. Default controller set.
INFO - 2020-03-08 16:47:44 --> Router Class Initialized
INFO - 2020-03-08 16:47:44 --> Output Class Initialized
INFO - 2020-03-08 16:47:44 --> Security Class Initialized
DEBUG - 2020-03-08 16:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-08 16:47:44 --> Input Class Initialized
INFO - 2020-03-08 16:47:44 --> Language Class Initialized
INFO - 2020-03-08 16:47:44 --> Loader Class Initialized
INFO - 2020-03-08 16:47:44 --> Helper loaded: url_helper
INFO - 2020-03-08 16:47:44 --> Helper loaded: string_helper
INFO - 2020-03-08 16:47:44 --> Database Driver Class Initialized
ERROR - 2020-03-08 16:47:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/u107185497/domains/musikologifest.com/public_html/pelarian/roadshow-2.1/roadshow-2.1/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-03-08 16:47:44 --> Unable to connect to the database
INFO - 2020-03-08 16:47:44 --> Language file loaded: language/english/db_lang.php
INFO - 2020-03-08 16:56:47 --> Config Class Initialized
INFO - 2020-03-08 16:56:47 --> Hooks Class Initialized
DEBUG - 2020-03-08 16:56:47 --> UTF-8 Support Enabled
INFO - 2020-03-08 16:56:47 --> Utf8 Class Initialized
INFO - 2020-03-08 16:56:47 --> URI Class Initialized
DEBUG - 2020-03-08 16:56:47 --> No URI present. Default controller set.
INFO - 2020-03-08 16:56:47 --> Router Class Initialized
INFO - 2020-03-08 16:56:47 --> Output Class Initialized
INFO - 2020-03-08 16:56:47 --> Security Class Initialized
DEBUG - 2020-03-08 16:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-08 16:56:47 --> Input Class Initialized
INFO - 2020-03-08 16:56:47 --> Language Class Initialized
INFO - 2020-03-08 16:56:47 --> Loader Class Initialized
INFO - 2020-03-08 16:56:47 --> Helper loaded: url_helper
INFO - 2020-03-08 16:56:47 --> Helper loaded: string_helper
INFO - 2020-03-08 16:56:47 --> Database Driver Class Initialized
ERROR - 2020-03-08 16:56:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'u107185497_Ayasy_89'@'localhost' to database 'musikologi-v4' /home/u107185497/domains/musikologifest.com/public_html/pelarian/roadshow-2.1/roadshow-2.1/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-03-08 16:56:47 --> Unable to connect to the database
INFO - 2020-03-08 16:56:47 --> Language file loaded: language/english/db_lang.php
INFO - 2020-03-08 16:59:02 --> Config Class Initialized
INFO - 2020-03-08 16:59:02 --> Hooks Class Initialized
DEBUG - 2020-03-08 16:59:02 --> UTF-8 Support Enabled
INFO - 2020-03-08 16:59:02 --> Utf8 Class Initialized
INFO - 2020-03-08 16:59:02 --> URI Class Initialized
DEBUG - 2020-03-08 16:59:02 --> No URI present. Default controller set.
INFO - 2020-03-08 16:59:02 --> Router Class Initialized
INFO - 2020-03-08 16:59:02 --> Output Class Initialized
INFO - 2020-03-08 16:59:02 --> Security Class Initialized
DEBUG - 2020-03-08 16:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-08 16:59:02 --> Input Class Initialized
INFO - 2020-03-08 16:59:02 --> Language Class Initialized
INFO - 2020-03-08 16:59:02 --> Loader Class Initialized
INFO - 2020-03-08 16:59:02 --> Helper loaded: url_helper
INFO - 2020-03-08 16:59:02 --> Helper loaded: string_helper
INFO - 2020-03-08 16:59:02 --> Database Driver Class Initialized
ERROR - 2020-03-08 16:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'u107185497_Ayasy_89'@'localhost' to database 'musikologi-v3' /home/u107185497/domains/musikologifest.com/public_html/pelarian/roadshow-2.1/roadshow-2.1/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-03-08 16:59:02 --> Unable to connect to the database
INFO - 2020-03-08 16:59:02 --> Language file loaded: language/english/db_lang.php
INFO - 2020-03-08 16:59:15 --> Config Class Initialized
INFO - 2020-03-08 16:59:15 --> Hooks Class Initialized
DEBUG - 2020-03-08 16:59:15 --> UTF-8 Support Enabled
INFO - 2020-03-08 16:59:15 --> Utf8 Class Initialized
INFO - 2020-03-08 16:59:15 --> URI Class Initialized
DEBUG - 2020-03-08 16:59:15 --> No URI present. Default controller set.
INFO - 2020-03-08 16:59:15 --> Router Class Initialized
INFO - 2020-03-08 16:59:15 --> Output Class Initialized
INFO - 2020-03-08 16:59:15 --> Security Class Initialized
DEBUG - 2020-03-08 16:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-08 16:59:15 --> Input Class Initialized
INFO - 2020-03-08 16:59:15 --> Language Class Initialized
INFO - 2020-03-08 16:59:15 --> Loader Class Initialized
INFO - 2020-03-08 16:59:15 --> Helper loaded: url_helper
INFO - 2020-03-08 16:59:15 --> Helper loaded: string_helper
INFO - 2020-03-08 16:59:15 --> Database Driver Class Initialized
ERROR - 2020-03-08 16:59:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'u107185497_Ayasy_89'@'localhost' to database 'musikologi-v3' /home/u107185497/domains/musikologifest.com/public_html/pelarian/roadshow-2.1/roadshow-2.1/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-03-08 16:59:15 --> Unable to connect to the database
INFO - 2020-03-08 16:59:15 --> Language file loaded: language/english/db_lang.php
