<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-27 00:05:52 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `bukti_bayar`, `id_pengunjung`) VALUES ('34', '120000', '1', '1', '20-02-27 12:05:52', '2020-02-28 12:05:52', NULL, 'PM173', NULL, 'default.jpg', NULL)
INFO - 2020-02-27 00:05:52 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-27 00:06:46 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `bukti_bayar`, `id_pengunjung`) VALUES ('34', '120000', '1', '1', '20-02-27 12:06:46', '2020-02-28 12:06:46', NULL, 'PM173', NULL, 'default.jpg', NULL)
INFO - 2020-02-27 00:06:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-27 00:07:32 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `bukti_bayar`, `id_pengunjung`) VALUES ('34', '120000', '1', '1', '20-02-27 12:07:32', '2020-02-28 12:07:32', NULL, 'PM173', NULL, 'default.jpg', NULL)
INFO - 2020-02-27 00:07:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-27 00:07:38 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `bukti_bayar`, `id_pengunjung`) VALUES ('34', '120000', '1', '1', '20-02-27 12:07:38', '2020-02-28 12:07:38', NULL, 'PM173', NULL, 'default.jpg', NULL)
INFO - 2020-02-27 00:07:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-27 00:07:44 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `bukti_bayar`, `id_pengunjung`) VALUES ('34', '120000', '1', '1', '20-02-27 12:07:44', '2020-02-28 12:07:44', NULL, 'PM173', NULL, 'default.jpg', NULL)
INFO - 2020-02-27 00:07:44 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-27 00:08:18 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 00:08:18 --> Final output sent to browser
DEBUG - 2020-02-27 00:08:18 --> Total execution time: 0.9662
INFO - 2020-02-27 00:39:14 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 00:39:14 --> Final output sent to browser
DEBUG - 2020-02-27 00:39:14 --> Total execution time: 1.1218
INFO - 2020-02-27 00:44:28 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 00:44:28 --> Final output sent to browser
DEBUG - 2020-02-27 00:44:28 --> Total execution time: 1.2026
INFO - 2020-02-27 00:45:12 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 00:45:12 --> Final output sent to browser
DEBUG - 2020-02-27 00:45:12 --> Total execution time: 1.3385
INFO - 2020-02-27 00:48:20 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 00:48:20 --> Final output sent to browser
DEBUG - 2020-02-27 00:48:20 --> Total execution time: 1.1068
INFO - 2020-02-27 04:11:00 --> Config Class Initialized
INFO - 2020-02-27 04:11:00 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:00 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:00 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:01 --> URI Class Initialized
DEBUG - 2020-02-27 04:11:01 --> No URI present. Default controller set.
INFO - 2020-02-27 04:11:01 --> Router Class Initialized
INFO - 2020-02-27 04:11:01 --> Output Class Initialized
INFO - 2020-02-27 04:11:01 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:01 --> Input Class Initialized
INFO - 2020-02-27 04:11:01 --> Language Class Initialized
INFO - 2020-02-27 04:11:01 --> Loader Class Initialized
INFO - 2020-02-27 04:11:01 --> Helper loaded: url_helper
INFO - 2020-02-27 04:11:01 --> Helper loaded: string_helper
INFO - 2020-02-27 04:11:01 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:11:01 --> Controller Class Initialized
INFO - 2020-02-27 04:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 04:11:01 --> Pagination Class Initialized
INFO - 2020-02-27 04:11:01 --> Model "M_show" initialized
INFO - 2020-02-27 04:11:01 --> Helper loaded: form_helper
INFO - 2020-02-27 04:11:01 --> Form Validation Class Initialized
INFO - 2020-02-27 04:11:01 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 04:11:01 --> Final output sent to browser
DEBUG - 2020-02-27 04:11:01 --> Total execution time: 0.5189
INFO - 2020-02-27 04:11:05 --> Config Class Initialized
INFO - 2020-02-27 04:11:05 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:06 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:06 --> URI Class Initialized
DEBUG - 2020-02-27 04:11:06 --> No URI present. Default controller set.
INFO - 2020-02-27 04:11:06 --> Router Class Initialized
INFO - 2020-02-27 04:11:06 --> Output Class Initialized
INFO - 2020-02-27 04:11:06 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:06 --> Input Class Initialized
INFO - 2020-02-27 04:11:06 --> Language Class Initialized
INFO - 2020-02-27 04:11:06 --> Loader Class Initialized
INFO - 2020-02-27 04:11:06 --> Helper loaded: url_helper
INFO - 2020-02-27 04:11:06 --> Helper loaded: string_helper
INFO - 2020-02-27 04:11:06 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:11:07 --> Controller Class Initialized
INFO - 2020-02-27 04:11:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 04:11:07 --> Pagination Class Initialized
INFO - 2020-02-27 04:11:07 --> Model "M_show" initialized
INFO - 2020-02-27 04:11:07 --> Helper loaded: form_helper
INFO - 2020-02-27 04:11:07 --> Form Validation Class Initialized
INFO - 2020-02-27 04:11:07 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 04:11:07 --> Final output sent to browser
DEBUG - 2020-02-27 04:11:07 --> Total execution time: 1.5045
INFO - 2020-02-27 04:11:11 --> Config Class Initialized
INFO - 2020-02-27 04:11:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:11 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:11 --> URI Class Initialized
INFO - 2020-02-27 04:11:11 --> Router Class Initialized
INFO - 2020-02-27 04:11:11 --> Output Class Initialized
INFO - 2020-02-27 04:11:11 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:11 --> Input Class Initialized
INFO - 2020-02-27 04:11:11 --> Language Class Initialized
INFO - 2020-02-27 04:11:11 --> Loader Class Initialized
INFO - 2020-02-27 04:11:11 --> Helper loaded: url_helper
INFO - 2020-02-27 04:11:11 --> Helper loaded: string_helper
INFO - 2020-02-27 04:11:11 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:11:11 --> Controller Class Initialized
INFO - 2020-02-27 04:11:11 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:11:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:11:11 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:11:11 --> Helper loaded: form_helper
INFO - 2020-02-27 04:11:11 --> Form Validation Class Initialized
INFO - 2020-02-27 04:11:11 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:11:11 --> Final output sent to browser
DEBUG - 2020-02-27 04:11:11 --> Total execution time: 0.5873
INFO - 2020-02-27 04:11:11 --> Config Class Initialized
INFO - 2020-02-27 04:11:11 --> Config Class Initialized
INFO - 2020-02-27 04:11:11 --> Config Class Initialized
INFO - 2020-02-27 04:11:11 --> Config Class Initialized
INFO - 2020-02-27 04:11:11 --> Hooks Class Initialized
INFO - 2020-02-27 04:11:11 --> Hooks Class Initialized
INFO - 2020-02-27 04:11:11 --> Hooks Class Initialized
INFO - 2020-02-27 04:11:11 --> Config Class Initialized
INFO - 2020-02-27 04:11:11 --> Config Class Initialized
INFO - 2020-02-27 04:11:11 --> Hooks Class Initialized
INFO - 2020-02-27 04:11:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:11:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:11 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:11 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:11 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:11:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:11:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:11:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:11 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:11 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:11 --> URI Class Initialized
INFO - 2020-02-27 04:11:11 --> URI Class Initialized
INFO - 2020-02-27 04:11:11 --> URI Class Initialized
INFO - 2020-02-27 04:11:11 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:11 --> URI Class Initialized
INFO - 2020-02-27 04:11:11 --> Router Class Initialized
INFO - 2020-02-27 04:11:11 --> Router Class Initialized
INFO - 2020-02-27 04:11:11 --> Router Class Initialized
INFO - 2020-02-27 04:11:11 --> URI Class Initialized
INFO - 2020-02-27 04:11:11 --> URI Class Initialized
INFO - 2020-02-27 04:11:11 --> Router Class Initialized
INFO - 2020-02-27 04:11:11 --> Output Class Initialized
INFO - 2020-02-27 04:11:11 --> Output Class Initialized
INFO - 2020-02-27 04:11:11 --> Output Class Initialized
INFO - 2020-02-27 04:11:11 --> Router Class Initialized
INFO - 2020-02-27 04:11:11 --> Router Class Initialized
INFO - 2020-02-27 04:11:11 --> Security Class Initialized
INFO - 2020-02-27 04:11:11 --> Output Class Initialized
INFO - 2020-02-27 04:11:11 --> Security Class Initialized
INFO - 2020-02-27 04:11:11 --> Output Class Initialized
INFO - 2020-02-27 04:11:11 --> Security Class Initialized
INFO - 2020-02-27 04:11:11 --> Output Class Initialized
INFO - 2020-02-27 04:11:11 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:11 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:11 --> Security Class Initialized
INFO - 2020-02-27 04:11:11 --> Input Class Initialized
DEBUG - 2020-02-27 04:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
DEBUG - 2020-02-27 04:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
DEBUG - 2020-02-27 04:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
ERROR - 2020-02-27 04:11:12 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
ERROR - 2020-02-27 04:11:12 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
INFO - 2020-02-27 04:11:12 --> Loader Class Initialized
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
ERROR - 2020-02-27 04:11:12 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 04:11:12 --> Helper loaded: url_helper
INFO - 2020-02-27 04:11:12 --> Config Class Initialized
INFO - 2020-02-27 04:11:12 --> Helper loaded: string_helper
ERROR - 2020-02-27 04:11:12 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-27 04:11:12 --> Loader Class Initialized
INFO - 2020-02-27 04:11:12 --> Config Class Initialized
INFO - 2020-02-27 04:11:12 --> Config Class Initialized
INFO - 2020-02-27 04:11:12 --> Hooks Class Initialized
INFO - 2020-02-27 04:11:12 --> Helper loaded: url_helper
INFO - 2020-02-27 04:11:12 --> Database Driver Class Initialized
INFO - 2020-02-27 04:11:12 --> Config Class Initialized
INFO - 2020-02-27 04:11:12 --> Hooks Class Initialized
INFO - 2020-02-27 04:11:12 --> Hooks Class Initialized
INFO - 2020-02-27 04:11:12 --> Hooks Class Initialized
INFO - 2020-02-27 04:11:12 --> Helper loaded: string_helper
DEBUG - 2020-02-27 04:11:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:11:12 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-27 04:11:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:11:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:12 --> Database Driver Class Initialized
INFO - 2020-02-27 04:11:12 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:12 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:12 --> URI Class Initialized
DEBUG - 2020-02-27 04:11:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:12 --> Controller Class Initialized
DEBUG - 2020-02-27 04:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:11:12 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:12 --> URI Class Initialized
INFO - 2020-02-27 04:11:12 --> Router Class Initialized
INFO - 2020-02-27 04:11:12 --> URI Class Initialized
INFO - 2020-02-27 04:11:12 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:11:12 --> Router Class Initialized
INFO - 2020-02-27 04:11:12 --> Router Class Initialized
INFO - 2020-02-27 04:11:12 --> URI Class Initialized
INFO - 2020-02-27 04:11:12 --> Output Class Initialized
INFO - 2020-02-27 04:11:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:11:12 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:11:12 --> Router Class Initialized
INFO - 2020-02-27 04:11:12 --> Security Class Initialized
INFO - 2020-02-27 04:11:12 --> Output Class Initialized
INFO - 2020-02-27 04:11:12 --> Output Class Initialized
DEBUG - 2020-02-27 04:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:12 --> Output Class Initialized
INFO - 2020-02-27 04:11:12 --> Security Class Initialized
INFO - 2020-02-27 04:11:12 --> Security Class Initialized
INFO - 2020-02-27 04:11:12 --> Helper loaded: form_helper
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
INFO - 2020-02-27 04:11:12 --> Form Validation Class Initialized
DEBUG - 2020-02-27 04:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:12 --> Security Class Initialized
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
DEBUG - 2020-02-27 04:11:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-27 04:11:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
ERROR - 2020-02-27 04:11:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
ERROR - 2020-02-27 04:11:12 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 04:11:12 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-27 04:11:12 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-27 04:11:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
INFO - 2020-02-27 04:11:12 --> Config Class Initialized
INFO - 2020-02-27 04:11:12 --> Final output sent to browser
INFO - 2020-02-27 04:11:12 --> Hooks Class Initialized
ERROR - 2020-02-27 04:11:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:11:12 --> Config Class Initialized
INFO - 2020-02-27 04:11:12 --> Config Class Initialized
INFO - 2020-02-27 04:11:12 --> Hooks Class Initialized
INFO - 2020-02-27 04:11:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:12 --> Total execution time: 0.6731
DEBUG - 2020-02-27 04:11:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:12 --> Config Class Initialized
INFO - 2020-02-27 04:11:12 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-27 04:11:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:11:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:12 --> Hooks Class Initialized
INFO - 2020-02-27 04:11:12 --> Controller Class Initialized
INFO - 2020-02-27 04:11:12 --> URI Class Initialized
INFO - 2020-02-27 04:11:12 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:12 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:11:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:12 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:12 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:11:12 --> URI Class Initialized
INFO - 2020-02-27 04:11:12 --> Router Class Initialized
INFO - 2020-02-27 04:11:12 --> URI Class Initialized
INFO - 2020-02-27 04:11:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:11:12 --> URI Class Initialized
INFO - 2020-02-27 04:11:12 --> Router Class Initialized
INFO - 2020-02-27 04:11:12 --> Output Class Initialized
INFO - 2020-02-27 04:11:12 --> Router Class Initialized
INFO - 2020-02-27 04:11:12 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:11:12 --> Security Class Initialized
INFO - 2020-02-27 04:11:12 --> Router Class Initialized
INFO - 2020-02-27 04:11:12 --> Output Class Initialized
INFO - 2020-02-27 04:11:12 --> Output Class Initialized
DEBUG - 2020-02-27 04:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:12 --> Security Class Initialized
INFO - 2020-02-27 04:11:12 --> Output Class Initialized
INFO - 2020-02-27 04:11:12 --> Security Class Initialized
INFO - 2020-02-27 04:11:12 --> Helper loaded: form_helper
INFO - 2020-02-27 04:11:12 --> Form Validation Class Initialized
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
DEBUG - 2020-02-27 04:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:12 --> Security Class Initialized
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
DEBUG - 2020-02-27 04:11:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-27 04:11:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
ERROR - 2020-02-27 04:11:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-27 04:11:12 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
INFO - 2020-02-27 04:11:12 --> Language Class Initialized
INFO - 2020-02-27 04:11:12 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-27 04:11:12 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-27 04:11:12 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 04:11:12 --> Final output sent to browser
ERROR - 2020-02-27 04:11:12 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-27 04:11:12 --> Total execution time: 0.9453
INFO - 2020-02-27 04:11:12 --> Config Class Initialized
INFO - 2020-02-27 04:11:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:12 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:12 --> URI Class Initialized
INFO - 2020-02-27 04:11:12 --> Router Class Initialized
INFO - 2020-02-27 04:11:12 --> Output Class Initialized
INFO - 2020-02-27 04:11:12 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:12 --> Input Class Initialized
INFO - 2020-02-27 04:11:13 --> Language Class Initialized
ERROR - 2020-02-27 04:11:13 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 04:11:13 --> Config Class Initialized
INFO - 2020-02-27 04:11:13 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:13 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:13 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:13 --> URI Class Initialized
INFO - 2020-02-27 04:11:13 --> Router Class Initialized
INFO - 2020-02-27 04:11:13 --> Output Class Initialized
INFO - 2020-02-27 04:11:13 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:13 --> Input Class Initialized
INFO - 2020-02-27 04:11:13 --> Language Class Initialized
ERROR - 2020-02-27 04:11:13 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 04:11:13 --> Config Class Initialized
INFO - 2020-02-27 04:11:13 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:13 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:13 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:13 --> URI Class Initialized
INFO - 2020-02-27 04:11:13 --> Router Class Initialized
INFO - 2020-02-27 04:11:13 --> Output Class Initialized
INFO - 2020-02-27 04:11:13 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:13 --> Input Class Initialized
INFO - 2020-02-27 04:11:13 --> Language Class Initialized
ERROR - 2020-02-27 04:11:13 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 04:11:13 --> Config Class Initialized
INFO - 2020-02-27 04:11:13 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:13 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:13 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:13 --> URI Class Initialized
INFO - 2020-02-27 04:11:13 --> Router Class Initialized
INFO - 2020-02-27 04:11:13 --> Output Class Initialized
INFO - 2020-02-27 04:11:13 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:13 --> Input Class Initialized
INFO - 2020-02-27 04:11:13 --> Language Class Initialized
ERROR - 2020-02-27 04:11:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:11:13 --> Config Class Initialized
INFO - 2020-02-27 04:11:13 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:13 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:13 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:13 --> URI Class Initialized
INFO - 2020-02-27 04:11:14 --> Router Class Initialized
INFO - 2020-02-27 04:11:14 --> Output Class Initialized
INFO - 2020-02-27 04:11:14 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:14 --> Input Class Initialized
INFO - 2020-02-27 04:11:14 --> Language Class Initialized
ERROR - 2020-02-27 04:11:14 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:11:14 --> Config Class Initialized
INFO - 2020-02-27 04:11:14 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:14 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:14 --> URI Class Initialized
INFO - 2020-02-27 04:11:14 --> Router Class Initialized
INFO - 2020-02-27 04:11:14 --> Output Class Initialized
INFO - 2020-02-27 04:11:14 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:14 --> Input Class Initialized
INFO - 2020-02-27 04:11:14 --> Language Class Initialized
ERROR - 2020-02-27 04:11:14 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 04:11:14 --> Config Class Initialized
INFO - 2020-02-27 04:11:14 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:14 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:14 --> URI Class Initialized
INFO - 2020-02-27 04:11:14 --> Router Class Initialized
INFO - 2020-02-27 04:11:14 --> Output Class Initialized
INFO - 2020-02-27 04:11:14 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:14 --> Input Class Initialized
INFO - 2020-02-27 04:11:14 --> Language Class Initialized
ERROR - 2020-02-27 04:11:14 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 04:11:14 --> Config Class Initialized
INFO - 2020-02-27 04:11:14 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:14 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:14 --> URI Class Initialized
INFO - 2020-02-27 04:11:14 --> Router Class Initialized
INFO - 2020-02-27 04:11:14 --> Output Class Initialized
INFO - 2020-02-27 04:11:14 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:14 --> Input Class Initialized
INFO - 2020-02-27 04:11:14 --> Language Class Initialized
ERROR - 2020-02-27 04:11:14 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 04:11:14 --> Config Class Initialized
INFO - 2020-02-27 04:11:14 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:15 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:15 --> URI Class Initialized
INFO - 2020-02-27 04:11:15 --> Router Class Initialized
INFO - 2020-02-27 04:11:15 --> Output Class Initialized
INFO - 2020-02-27 04:11:15 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:15 --> Input Class Initialized
INFO - 2020-02-27 04:11:15 --> Language Class Initialized
ERROR - 2020-02-27 04:11:15 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 04:11:33 --> Config Class Initialized
INFO - 2020-02-27 04:11:33 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:11:33 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:11:33 --> Utf8 Class Initialized
INFO - 2020-02-27 04:11:33 --> URI Class Initialized
INFO - 2020-02-27 04:11:33 --> Router Class Initialized
INFO - 2020-02-27 04:11:33 --> Output Class Initialized
INFO - 2020-02-27 04:11:33 --> Security Class Initialized
DEBUG - 2020-02-27 04:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:11:33 --> Input Class Initialized
INFO - 2020-02-27 04:11:33 --> Language Class Initialized
INFO - 2020-02-27 04:11:33 --> Loader Class Initialized
INFO - 2020-02-27 04:11:33 --> Helper loaded: url_helper
INFO - 2020-02-27 04:11:33 --> Helper loaded: string_helper
INFO - 2020-02-27 04:11:33 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:11:33 --> Controller Class Initialized
INFO - 2020-02-27 04:11:33 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:11:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:11:33 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:11:33 --> Helper loaded: form_helper
INFO - 2020-02-27 04:11:33 --> Form Validation Class Initialized
INFO - 2020-02-27 10:11:33 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 10:11:34 --> Final output sent to browser
DEBUG - 2020-02-27 10:11:34 --> Total execution time: 0.7140
INFO - 2020-02-27 04:13:21 --> Config Class Initialized
INFO - 2020-02-27 04:13:21 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:13:21 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:13:21 --> Utf8 Class Initialized
INFO - 2020-02-27 04:13:21 --> URI Class Initialized
INFO - 2020-02-27 04:13:21 --> Router Class Initialized
INFO - 2020-02-27 04:13:21 --> Output Class Initialized
INFO - 2020-02-27 04:13:21 --> Security Class Initialized
DEBUG - 2020-02-27 04:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:13:21 --> Input Class Initialized
INFO - 2020-02-27 04:13:21 --> Language Class Initialized
INFO - 2020-02-27 04:13:21 --> Loader Class Initialized
INFO - 2020-02-27 04:13:21 --> Helper loaded: url_helper
INFO - 2020-02-27 04:13:21 --> Helper loaded: string_helper
INFO - 2020-02-27 04:13:22 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:13:22 --> Controller Class Initialized
INFO - 2020-02-27 04:13:22 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:13:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:13:22 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:13:22 --> Helper loaded: form_helper
INFO - 2020-02-27 04:13:22 --> Form Validation Class Initialized
ERROR - 2020-02-27 04:13:22 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 04:13:22 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 04:13:22 --> Final output sent to browser
DEBUG - 2020-02-27 04:13:22 --> Total execution time: 0.6553
INFO - 2020-02-27 04:13:36 --> Config Class Initialized
INFO - 2020-02-27 04:13:36 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:13:36 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:13:36 --> Utf8 Class Initialized
INFO - 2020-02-27 04:13:36 --> URI Class Initialized
INFO - 2020-02-27 04:13:36 --> Router Class Initialized
INFO - 2020-02-27 04:13:36 --> Output Class Initialized
INFO - 2020-02-27 04:13:36 --> Security Class Initialized
DEBUG - 2020-02-27 04:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:13:36 --> Input Class Initialized
INFO - 2020-02-27 04:13:36 --> Language Class Initialized
INFO - 2020-02-27 04:13:36 --> Loader Class Initialized
INFO - 2020-02-27 04:13:36 --> Helper loaded: url_helper
INFO - 2020-02-27 04:13:36 --> Helper loaded: string_helper
INFO - 2020-02-27 04:13:36 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:13:36 --> Controller Class Initialized
INFO - 2020-02-27 04:13:36 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:13:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:13:36 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:13:36 --> Helper loaded: form_helper
INFO - 2020-02-27 04:13:37 --> Form Validation Class Initialized
INFO - 2020-02-27 04:13:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-27 04:13:37 --> Config Class Initialized
INFO - 2020-02-27 04:13:37 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:13:37 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:13:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:13:37 --> URI Class Initialized
INFO - 2020-02-27 04:13:37 --> Router Class Initialized
INFO - 2020-02-27 04:13:37 --> Output Class Initialized
INFO - 2020-02-27 04:13:37 --> Security Class Initialized
DEBUG - 2020-02-27 04:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:13:37 --> Input Class Initialized
INFO - 2020-02-27 04:13:37 --> Language Class Initialized
INFO - 2020-02-27 04:13:37 --> Loader Class Initialized
INFO - 2020-02-27 04:13:37 --> Helper loaded: url_helper
INFO - 2020-02-27 04:13:37 --> Helper loaded: string_helper
INFO - 2020-02-27 04:13:37 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:13:37 --> Controller Class Initialized
INFO - 2020-02-27 04:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 04:13:37 --> Pagination Class Initialized
INFO - 2020-02-27 04:13:37 --> Model "M_show" initialized
INFO - 2020-02-27 04:13:37 --> Helper loaded: form_helper
INFO - 2020-02-27 04:13:37 --> Form Validation Class Initialized
INFO - 2020-02-27 04:13:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 04:13:37 --> Final output sent to browser
DEBUG - 2020-02-27 04:13:37 --> Total execution time: 0.5313
INFO - 2020-02-27 04:13:37 --> Config Class Initialized
INFO - 2020-02-27 04:13:37 --> Config Class Initialized
INFO - 2020-02-27 04:13:37 --> Hooks Class Initialized
INFO - 2020-02-27 04:13:37 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:13:37 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:13:37 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:13:37 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:13:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:13:37 --> URI Class Initialized
INFO - 2020-02-27 04:13:37 --> URI Class Initialized
INFO - 2020-02-27 04:13:37 --> Router Class Initialized
INFO - 2020-02-27 04:13:38 --> Router Class Initialized
INFO - 2020-02-27 04:13:38 --> Output Class Initialized
INFO - 2020-02-27 04:13:38 --> Security Class Initialized
INFO - 2020-02-27 04:13:38 --> Output Class Initialized
DEBUG - 2020-02-27 04:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:13:38 --> Security Class Initialized
INFO - 2020-02-27 04:13:38 --> Input Class Initialized
DEBUG - 2020-02-27 04:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:13:38 --> Input Class Initialized
INFO - 2020-02-27 04:13:38 --> Language Class Initialized
INFO - 2020-02-27 04:13:38 --> Language Class Initialized
ERROR - 2020-02-27 04:13:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 04:13:38 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:13:38 --> Config Class Initialized
INFO - 2020-02-27 04:13:38 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:13:38 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:13:38 --> Utf8 Class Initialized
INFO - 2020-02-27 04:13:38 --> URI Class Initialized
INFO - 2020-02-27 04:13:38 --> Router Class Initialized
INFO - 2020-02-27 04:13:38 --> Output Class Initialized
INFO - 2020-02-27 04:13:38 --> Security Class Initialized
DEBUG - 2020-02-27 04:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:13:38 --> Input Class Initialized
INFO - 2020-02-27 04:13:38 --> Language Class Initialized
ERROR - 2020-02-27 04:13:38 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:13:38 --> Config Class Initialized
INFO - 2020-02-27 04:13:38 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:13:38 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:13:38 --> Utf8 Class Initialized
INFO - 2020-02-27 04:13:38 --> URI Class Initialized
INFO - 2020-02-27 04:13:38 --> Router Class Initialized
INFO - 2020-02-27 04:13:38 --> Output Class Initialized
INFO - 2020-02-27 04:13:38 --> Security Class Initialized
DEBUG - 2020-02-27 04:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:13:38 --> Input Class Initialized
INFO - 2020-02-27 04:13:38 --> Language Class Initialized
ERROR - 2020-02-27 04:13:38 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:24:50 --> Config Class Initialized
INFO - 2020-02-27 04:24:50 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:24:50 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:50 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:50 --> URI Class Initialized
INFO - 2020-02-27 04:24:50 --> Router Class Initialized
INFO - 2020-02-27 04:24:50 --> Output Class Initialized
INFO - 2020-02-27 04:24:50 --> Security Class Initialized
DEBUG - 2020-02-27 04:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:50 --> Input Class Initialized
INFO - 2020-02-27 04:24:50 --> Language Class Initialized
INFO - 2020-02-27 04:24:50 --> Loader Class Initialized
INFO - 2020-02-27 04:24:50 --> Helper loaded: url_helper
INFO - 2020-02-27 04:24:50 --> Helper loaded: string_helper
INFO - 2020-02-27 04:24:50 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:24:50 --> Controller Class Initialized
INFO - 2020-02-27 04:24:50 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:24:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:24:50 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:24:50 --> Helper loaded: form_helper
INFO - 2020-02-27 04:24:50 --> Form Validation Class Initialized
INFO - 2020-02-27 04:24:51 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:24:51 --> Final output sent to browser
DEBUG - 2020-02-27 04:24:51 --> Total execution time: 0.5674
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
INFO - 2020-02-27 04:24:51 --> Language Class Initialized
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:51 --> Language Class Initialized
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-27 04:24:51 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 04:24:51 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
INFO - 2020-02-27 04:24:51 --> Language Class Initialized
INFO - 2020-02-27 04:24:51 --> Language Class Initialized
INFO - 2020-02-27 04:24:51 --> Language Class Initialized
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:24:51 --> Language Class Initialized
ERROR - 2020-02-27 04:24:51 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-27 04:24:51 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 04:24:51 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
ERROR - 2020-02-27 04:24:51 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
INFO - 2020-02-27 04:24:51 --> Language Class Initialized
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:51 --> Language Class Initialized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
ERROR - 2020-02-27 04:24:51 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
ERROR - 2020-02-27 04:24:51 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
INFO - 2020-02-27 04:24:51 --> Language Class Initialized
INFO - 2020-02-27 04:24:51 --> Language Class Initialized
INFO - 2020-02-27 04:24:51 --> Language Class Initialized
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:24:51 --> Config Class Initialized
ERROR - 2020-02-27 04:24:51 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 04:24:51 --> Language Class Initialized
INFO - 2020-02-27 04:24:51 --> Loader Class Initialized
INFO - 2020-02-27 04:24:51 --> Loader Class Initialized
INFO - 2020-02-27 04:24:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:24:51 --> Helper loaded: url_helper
INFO - 2020-02-27 04:24:51 --> Helper loaded: url_helper
ERROR - 2020-02-27 04:24:51 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:51 --> Helper loaded: string_helper
INFO - 2020-02-27 04:24:51 --> Helper loaded: string_helper
DEBUG - 2020-02-27 04:24:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
INFO - 2020-02-27 04:24:51 --> Database Driver Class Initialized
INFO - 2020-02-27 04:24:51 --> Database Driver Class Initialized
INFO - 2020-02-27 04:24:51 --> URI Class Initialized
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
DEBUG - 2020-02-27 04:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-27 04:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:24:51 --> Router Class Initialized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
INFO - 2020-02-27 04:24:51 --> Controller Class Initialized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
INFO - 2020-02-27 04:24:51 --> Output Class Initialized
INFO - 2020-02-27 04:24:51 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:24:51 --> Security Class Initialized
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
INFO - 2020-02-27 04:24:51 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-27 04:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:51 --> Input Class Initialized
INFO - 2020-02-27 04:24:51 --> Language Class Initialized
INFO - 2020-02-27 04:24:51 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:24:52 --> Language Class Initialized
ERROR - 2020-02-27 04:24:52 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 04:24:52 --> Helper loaded: form_helper
INFO - 2020-02-27 04:24:52 --> Form Validation Class Initialized
ERROR - 2020-02-27 04:24:52 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 04:24:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-27 04:24:52 --> Config Class Initialized
INFO - 2020-02-27 04:24:52 --> Hooks Class Initialized
ERROR - 2020-02-27 04:24:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 04:24:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-27 04:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:52 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:52 --> Final output sent to browser
DEBUG - 2020-02-27 04:24:52 --> Total execution time: 0.6502
INFO - 2020-02-27 04:24:52 --> URI Class Initialized
INFO - 2020-02-27 04:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:24:52 --> Router Class Initialized
INFO - 2020-02-27 04:24:52 --> Controller Class Initialized
INFO - 2020-02-27 04:24:52 --> Output Class Initialized
INFO - 2020-02-27 04:24:52 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:24:52 --> Security Class Initialized
INFO - 2020-02-27 04:24:52 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-27 04:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:52 --> Input Class Initialized
INFO - 2020-02-27 04:24:52 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:24:52 --> Language Class Initialized
INFO - 2020-02-27 04:24:52 --> Helper loaded: form_helper
INFO - 2020-02-27 04:24:52 --> Form Validation Class Initialized
ERROR - 2020-02-27 04:24:52 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 04:24:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-27 04:24:52 --> Config Class Initialized
INFO - 2020-02-27 04:24:52 --> Hooks Class Initialized
ERROR - 2020-02-27 04:24:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 04:24:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-27 04:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:52 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:52 --> Final output sent to browser
DEBUG - 2020-02-27 04:24:52 --> Total execution time: 0.9196
INFO - 2020-02-27 04:24:52 --> URI Class Initialized
INFO - 2020-02-27 04:24:52 --> Router Class Initialized
INFO - 2020-02-27 04:24:52 --> Output Class Initialized
INFO - 2020-02-27 04:24:52 --> Security Class Initialized
DEBUG - 2020-02-27 04:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:52 --> Input Class Initialized
INFO - 2020-02-27 04:24:52 --> Language Class Initialized
ERROR - 2020-02-27 04:24:52 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 04:24:52 --> Config Class Initialized
INFO - 2020-02-27 04:24:52 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:52 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:52 --> URI Class Initialized
INFO - 2020-02-27 04:24:52 --> Router Class Initialized
INFO - 2020-02-27 04:24:52 --> Output Class Initialized
INFO - 2020-02-27 04:24:52 --> Security Class Initialized
DEBUG - 2020-02-27 04:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:52 --> Input Class Initialized
INFO - 2020-02-27 04:24:52 --> Language Class Initialized
ERROR - 2020-02-27 04:24:52 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 04:24:52 --> Config Class Initialized
INFO - 2020-02-27 04:24:52 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:52 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:52 --> URI Class Initialized
INFO - 2020-02-27 04:24:53 --> Router Class Initialized
INFO - 2020-02-27 04:24:53 --> Output Class Initialized
INFO - 2020-02-27 04:24:53 --> Security Class Initialized
DEBUG - 2020-02-27 04:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:53 --> Input Class Initialized
INFO - 2020-02-27 04:24:53 --> Language Class Initialized
ERROR - 2020-02-27 04:24:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:24:53 --> Config Class Initialized
INFO - 2020-02-27 04:24:53 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:24:53 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:53 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:53 --> URI Class Initialized
INFO - 2020-02-27 04:24:53 --> Router Class Initialized
INFO - 2020-02-27 04:24:53 --> Output Class Initialized
INFO - 2020-02-27 04:24:53 --> Security Class Initialized
DEBUG - 2020-02-27 04:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:53 --> Input Class Initialized
INFO - 2020-02-27 04:24:53 --> Language Class Initialized
ERROR - 2020-02-27 04:24:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:24:53 --> Config Class Initialized
INFO - 2020-02-27 04:24:53 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:24:53 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:53 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:53 --> URI Class Initialized
INFO - 2020-02-27 04:24:53 --> Router Class Initialized
INFO - 2020-02-27 04:24:53 --> Output Class Initialized
INFO - 2020-02-27 04:24:53 --> Security Class Initialized
DEBUG - 2020-02-27 04:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:53 --> Input Class Initialized
INFO - 2020-02-27 04:24:53 --> Language Class Initialized
ERROR - 2020-02-27 04:24:53 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 04:24:53 --> Config Class Initialized
INFO - 2020-02-27 04:24:53 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:24:53 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:53 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:53 --> URI Class Initialized
INFO - 2020-02-27 04:24:53 --> Router Class Initialized
INFO - 2020-02-27 04:24:53 --> Output Class Initialized
INFO - 2020-02-27 04:24:53 --> Security Class Initialized
DEBUG - 2020-02-27 04:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:53 --> Input Class Initialized
INFO - 2020-02-27 04:24:53 --> Language Class Initialized
ERROR - 2020-02-27 04:24:54 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 04:24:54 --> Config Class Initialized
INFO - 2020-02-27 04:24:54 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:24:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:54 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:54 --> URI Class Initialized
INFO - 2020-02-27 04:24:54 --> Router Class Initialized
INFO - 2020-02-27 04:24:54 --> Output Class Initialized
INFO - 2020-02-27 04:24:54 --> Security Class Initialized
DEBUG - 2020-02-27 04:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:54 --> Input Class Initialized
INFO - 2020-02-27 04:24:54 --> Language Class Initialized
ERROR - 2020-02-27 04:24:54 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 04:24:54 --> Config Class Initialized
INFO - 2020-02-27 04:24:54 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:24:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:24:54 --> Utf8 Class Initialized
INFO - 2020-02-27 04:24:54 --> URI Class Initialized
INFO - 2020-02-27 04:24:54 --> Router Class Initialized
INFO - 2020-02-27 04:24:54 --> Output Class Initialized
INFO - 2020-02-27 04:24:54 --> Security Class Initialized
DEBUG - 2020-02-27 04:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:24:54 --> Input Class Initialized
INFO - 2020-02-27 04:24:54 --> Language Class Initialized
ERROR - 2020-02-27 04:24:54 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 04:25:20 --> Config Class Initialized
INFO - 2020-02-27 04:25:20 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:25:20 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:25:20 --> Utf8 Class Initialized
INFO - 2020-02-27 04:25:20 --> URI Class Initialized
INFO - 2020-02-27 04:25:20 --> Router Class Initialized
INFO - 2020-02-27 04:25:20 --> Output Class Initialized
INFO - 2020-02-27 04:25:20 --> Security Class Initialized
DEBUG - 2020-02-27 04:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:25:20 --> Input Class Initialized
INFO - 2020-02-27 04:25:20 --> Language Class Initialized
INFO - 2020-02-27 04:25:20 --> Loader Class Initialized
INFO - 2020-02-27 04:25:20 --> Helper loaded: url_helper
INFO - 2020-02-27 04:25:20 --> Helper loaded: string_helper
INFO - 2020-02-27 04:25:20 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:25:21 --> Controller Class Initialized
INFO - 2020-02-27 04:25:21 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:25:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:25:21 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:25:21 --> Helper loaded: form_helper
INFO - 2020-02-27 04:25:21 --> Form Validation Class Initialized
INFO - 2020-02-27 10:25:21 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 10:25:21 --> Final output sent to browser
DEBUG - 2020-02-27 10:25:21 --> Total execution time: 0.9743
INFO - 2020-02-27 04:25:26 --> Config Class Initialized
INFO - 2020-02-27 04:25:26 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:25:26 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:25:26 --> Utf8 Class Initialized
INFO - 2020-02-27 04:25:26 --> URI Class Initialized
INFO - 2020-02-27 04:25:26 --> Router Class Initialized
INFO - 2020-02-27 04:25:26 --> Output Class Initialized
INFO - 2020-02-27 04:25:26 --> Security Class Initialized
DEBUG - 2020-02-27 04:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:25:26 --> Input Class Initialized
INFO - 2020-02-27 04:25:26 --> Language Class Initialized
INFO - 2020-02-27 04:25:27 --> Loader Class Initialized
INFO - 2020-02-27 04:25:27 --> Helper loaded: url_helper
INFO - 2020-02-27 04:25:27 --> Helper loaded: string_helper
INFO - 2020-02-27 04:25:27 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:25:27 --> Controller Class Initialized
INFO - 2020-02-27 04:25:27 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:25:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:25:27 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:25:27 --> Helper loaded: form_helper
INFO - 2020-02-27 04:25:27 --> Form Validation Class Initialized
ERROR - 2020-02-27 04:25:27 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 04:25:27 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 04:25:27 --> Final output sent to browser
DEBUG - 2020-02-27 04:25:27 --> Total execution time: 1.6290
INFO - 2020-02-27 04:25:41 --> Config Class Initialized
INFO - 2020-02-27 04:25:41 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:25:41 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:25:41 --> Utf8 Class Initialized
INFO - 2020-02-27 04:25:41 --> URI Class Initialized
INFO - 2020-02-27 04:25:41 --> Router Class Initialized
INFO - 2020-02-27 04:25:41 --> Output Class Initialized
INFO - 2020-02-27 04:25:41 --> Security Class Initialized
DEBUG - 2020-02-27 04:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:25:42 --> Input Class Initialized
INFO - 2020-02-27 04:25:42 --> Language Class Initialized
INFO - 2020-02-27 04:25:42 --> Loader Class Initialized
INFO - 2020-02-27 04:25:42 --> Helper loaded: url_helper
INFO - 2020-02-27 04:25:42 --> Helper loaded: string_helper
INFO - 2020-02-27 04:25:42 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:25:42 --> Controller Class Initialized
INFO - 2020-02-27 04:25:42 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:25:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:25:42 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:25:42 --> Helper loaded: form_helper
INFO - 2020-02-27 04:25:42 --> Form Validation Class Initialized
INFO - 2020-02-27 04:25:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-27 04:25:42 --> Config Class Initialized
INFO - 2020-02-27 04:25:42 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:25:42 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:25:42 --> Utf8 Class Initialized
INFO - 2020-02-27 04:25:42 --> URI Class Initialized
INFO - 2020-02-27 04:25:42 --> Router Class Initialized
INFO - 2020-02-27 04:25:42 --> Output Class Initialized
INFO - 2020-02-27 04:25:42 --> Security Class Initialized
DEBUG - 2020-02-27 04:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:25:42 --> Input Class Initialized
INFO - 2020-02-27 04:25:42 --> Language Class Initialized
INFO - 2020-02-27 04:25:42 --> Loader Class Initialized
INFO - 2020-02-27 04:25:42 --> Helper loaded: url_helper
INFO - 2020-02-27 04:25:42 --> Helper loaded: string_helper
INFO - 2020-02-27 04:25:42 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:25:42 --> Controller Class Initialized
INFO - 2020-02-27 04:25:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 04:25:42 --> Pagination Class Initialized
INFO - 2020-02-27 04:25:42 --> Model "M_show" initialized
INFO - 2020-02-27 04:25:42 --> Helper loaded: form_helper
INFO - 2020-02-27 04:25:42 --> Form Validation Class Initialized
INFO - 2020-02-27 04:25:42 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 04:25:42 --> Final output sent to browser
DEBUG - 2020-02-27 04:25:42 --> Total execution time: 0.5231
INFO - 2020-02-27 04:25:43 --> Config Class Initialized
INFO - 2020-02-27 04:25:43 --> Config Class Initialized
INFO - 2020-02-27 04:25:43 --> Hooks Class Initialized
INFO - 2020-02-27 04:25:43 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:25:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:25:43 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:25:43 --> Utf8 Class Initialized
INFO - 2020-02-27 04:25:43 --> Utf8 Class Initialized
INFO - 2020-02-27 04:25:43 --> URI Class Initialized
INFO - 2020-02-27 04:25:43 --> URI Class Initialized
INFO - 2020-02-27 04:25:43 --> Router Class Initialized
INFO - 2020-02-27 04:25:43 --> Output Class Initialized
INFO - 2020-02-27 04:25:43 --> Router Class Initialized
INFO - 2020-02-27 04:25:43 --> Output Class Initialized
INFO - 2020-02-27 04:25:43 --> Security Class Initialized
INFO - 2020-02-27 04:25:43 --> Security Class Initialized
DEBUG - 2020-02-27 04:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:25:43 --> Input Class Initialized
DEBUG - 2020-02-27 04:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:25:43 --> Input Class Initialized
INFO - 2020-02-27 04:25:43 --> Language Class Initialized
INFO - 2020-02-27 04:25:43 --> Language Class Initialized
ERROR - 2020-02-27 04:25:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 04:25:43 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:36:40 --> Config Class Initialized
INFO - 2020-02-27 04:36:40 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:40 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:40 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:40 --> URI Class Initialized
INFO - 2020-02-27 04:36:40 --> Router Class Initialized
INFO - 2020-02-27 04:36:40 --> Output Class Initialized
INFO - 2020-02-27 04:36:40 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:40 --> Input Class Initialized
INFO - 2020-02-27 04:36:40 --> Language Class Initialized
INFO - 2020-02-27 04:36:41 --> Loader Class Initialized
INFO - 2020-02-27 04:36:41 --> Helper loaded: url_helper
INFO - 2020-02-27 04:36:41 --> Helper loaded: string_helper
INFO - 2020-02-27 04:36:41 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:36:41 --> Controller Class Initialized
INFO - 2020-02-27 04:36:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 04:36:41 --> Pagination Class Initialized
INFO - 2020-02-27 04:36:41 --> Model "M_show" initialized
INFO - 2020-02-27 04:36:41 --> Helper loaded: form_helper
INFO - 2020-02-27 04:36:41 --> Form Validation Class Initialized
INFO - 2020-02-27 04:36:41 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 04:36:41 --> Final output sent to browser
DEBUG - 2020-02-27 04:36:41 --> Total execution time: 0.6226
INFO - 2020-02-27 04:36:41 --> Config Class Initialized
INFO - 2020-02-27 04:36:41 --> Config Class Initialized
INFO - 2020-02-27 04:36:41 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:41 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:41 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:41 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:41 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:41 --> URI Class Initialized
INFO - 2020-02-27 04:36:41 --> URI Class Initialized
INFO - 2020-02-27 04:36:41 --> Router Class Initialized
INFO - 2020-02-27 04:36:41 --> Router Class Initialized
INFO - 2020-02-27 04:36:41 --> Output Class Initialized
INFO - 2020-02-27 04:36:41 --> Output Class Initialized
INFO - 2020-02-27 04:36:41 --> Security Class Initialized
INFO - 2020-02-27 04:36:41 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:41 --> Input Class Initialized
INFO - 2020-02-27 04:36:41 --> Input Class Initialized
INFO - 2020-02-27 04:36:41 --> Language Class Initialized
INFO - 2020-02-27 04:36:41 --> Language Class Initialized
ERROR - 2020-02-27 04:36:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 04:36:41 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:36:41 --> Config Class Initialized
INFO - 2020-02-27 04:36:41 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:41 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:41 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:41 --> URI Class Initialized
INFO - 2020-02-27 04:36:41 --> Router Class Initialized
INFO - 2020-02-27 04:36:42 --> Output Class Initialized
INFO - 2020-02-27 04:36:42 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:42 --> Input Class Initialized
INFO - 2020-02-27 04:36:42 --> Language Class Initialized
ERROR - 2020-02-27 04:36:42 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:36:45 --> Config Class Initialized
INFO - 2020-02-27 04:36:45 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:45 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:45 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:45 --> URI Class Initialized
INFO - 2020-02-27 04:36:45 --> Router Class Initialized
INFO - 2020-02-27 04:36:45 --> Output Class Initialized
INFO - 2020-02-27 04:36:45 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:45 --> Input Class Initialized
INFO - 2020-02-27 04:36:45 --> Language Class Initialized
INFO - 2020-02-27 04:36:45 --> Loader Class Initialized
INFO - 2020-02-27 04:36:45 --> Helper loaded: url_helper
INFO - 2020-02-27 04:36:45 --> Helper loaded: string_helper
INFO - 2020-02-27 04:36:45 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:36:46 --> Controller Class Initialized
INFO - 2020-02-27 04:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 04:36:46 --> Pagination Class Initialized
INFO - 2020-02-27 04:36:46 --> Model "M_show" initialized
INFO - 2020-02-27 04:36:46 --> Helper loaded: form_helper
INFO - 2020-02-27 04:36:46 --> Form Validation Class Initialized
INFO - 2020-02-27 04:36:46 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 04:36:46 --> Final output sent to browser
DEBUG - 2020-02-27 04:36:46 --> Total execution time: 0.7494
INFO - 2020-02-27 04:36:46 --> Config Class Initialized
INFO - 2020-02-27 04:36:46 --> Config Class Initialized
INFO - 2020-02-27 04:36:46 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:46 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:46 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:46 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:36:46 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:46 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:46 --> URI Class Initialized
INFO - 2020-02-27 04:36:46 --> URI Class Initialized
INFO - 2020-02-27 04:36:46 --> Router Class Initialized
INFO - 2020-02-27 04:36:46 --> Router Class Initialized
INFO - 2020-02-27 04:36:46 --> Output Class Initialized
INFO - 2020-02-27 04:36:46 --> Security Class Initialized
INFO - 2020-02-27 04:36:46 --> Output Class Initialized
DEBUG - 2020-02-27 04:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:46 --> Security Class Initialized
INFO - 2020-02-27 04:36:46 --> Input Class Initialized
DEBUG - 2020-02-27 04:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:46 --> Input Class Initialized
INFO - 2020-02-27 04:36:46 --> Language Class Initialized
INFO - 2020-02-27 04:36:46 --> Language Class Initialized
ERROR - 2020-02-27 04:36:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 04:36:46 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:36:47 --> Config Class Initialized
INFO - 2020-02-27 04:36:47 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:47 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:47 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:47 --> URI Class Initialized
INFO - 2020-02-27 04:36:47 --> Router Class Initialized
INFO - 2020-02-27 04:36:47 --> Output Class Initialized
INFO - 2020-02-27 04:36:47 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:47 --> Input Class Initialized
INFO - 2020-02-27 04:36:47 --> Language Class Initialized
INFO - 2020-02-27 04:36:47 --> Loader Class Initialized
INFO - 2020-02-27 04:36:47 --> Helper loaded: url_helper
INFO - 2020-02-27 04:36:47 --> Helper loaded: string_helper
INFO - 2020-02-27 04:36:47 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:36:47 --> Controller Class Initialized
INFO - 2020-02-27 04:36:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 04:36:47 --> Pagination Class Initialized
INFO - 2020-02-27 04:36:48 --> Model "M_show" initialized
INFO - 2020-02-27 04:36:48 --> Helper loaded: form_helper
INFO - 2020-02-27 04:36:48 --> Form Validation Class Initialized
INFO - 2020-02-27 04:36:48 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 04:36:48 --> Final output sent to browser
DEBUG - 2020-02-27 04:36:48 --> Total execution time: 0.6858
INFO - 2020-02-27 04:36:48 --> Config Class Initialized
INFO - 2020-02-27 04:36:48 --> Config Class Initialized
INFO - 2020-02-27 04:36:48 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:48 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:48 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:48 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:48 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:48 --> URI Class Initialized
INFO - 2020-02-27 04:36:48 --> URI Class Initialized
INFO - 2020-02-27 04:36:48 --> Router Class Initialized
INFO - 2020-02-27 04:36:48 --> Router Class Initialized
INFO - 2020-02-27 04:36:48 --> Output Class Initialized
INFO - 2020-02-27 04:36:48 --> Security Class Initialized
INFO - 2020-02-27 04:36:48 --> Output Class Initialized
DEBUG - 2020-02-27 04:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:48 --> Security Class Initialized
INFO - 2020-02-27 04:36:48 --> Input Class Initialized
DEBUG - 2020-02-27 04:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:48 --> Input Class Initialized
INFO - 2020-02-27 04:36:48 --> Language Class Initialized
INFO - 2020-02-27 04:36:48 --> Language Class Initialized
ERROR - 2020-02-27 04:36:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 04:36:48 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:36:48 --> Config Class Initialized
INFO - 2020-02-27 04:36:48 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:48 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:48 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:48 --> URI Class Initialized
INFO - 2020-02-27 04:36:48 --> Router Class Initialized
INFO - 2020-02-27 04:36:48 --> Output Class Initialized
INFO - 2020-02-27 04:36:48 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:48 --> Input Class Initialized
INFO - 2020-02-27 04:36:48 --> Language Class Initialized
ERROR - 2020-02-27 04:36:48 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:36:50 --> Config Class Initialized
INFO - 2020-02-27 04:36:50 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:50 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:50 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:51 --> URI Class Initialized
INFO - 2020-02-27 04:36:51 --> Router Class Initialized
INFO - 2020-02-27 04:36:51 --> Output Class Initialized
INFO - 2020-02-27 04:36:51 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:51 --> Input Class Initialized
INFO - 2020-02-27 04:36:51 --> Language Class Initialized
INFO - 2020-02-27 04:36:51 --> Loader Class Initialized
INFO - 2020-02-27 04:36:51 --> Helper loaded: url_helper
INFO - 2020-02-27 04:36:51 --> Helper loaded: string_helper
INFO - 2020-02-27 04:36:51 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:36:51 --> Controller Class Initialized
INFO - 2020-02-27 04:36:51 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:36:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:36:51 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:36:51 --> Helper loaded: form_helper
INFO - 2020-02-27 04:36:51 --> Form Validation Class Initialized
INFO - 2020-02-27 04:36:51 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:36:51 --> Final output sent to browser
DEBUG - 2020-02-27 04:36:51 --> Total execution time: 0.7492
INFO - 2020-02-27 04:36:51 --> Config Class Initialized
INFO - 2020-02-27 04:36:51 --> Config Class Initialized
INFO - 2020-02-27 04:36:51 --> Config Class Initialized
INFO - 2020-02-27 04:36:51 --> Config Class Initialized
INFO - 2020-02-27 04:36:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:51 --> Config Class Initialized
INFO - 2020-02-27 04:36:51 --> Config Class Initialized
INFO - 2020-02-27 04:36:51 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:51 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:51 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:36:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:51 --> URI Class Initialized
INFO - 2020-02-27 04:36:51 --> URI Class Initialized
INFO - 2020-02-27 04:36:51 --> URI Class Initialized
INFO - 2020-02-27 04:36:51 --> URI Class Initialized
INFO - 2020-02-27 04:36:51 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:51 --> URI Class Initialized
INFO - 2020-02-27 04:36:51 --> Router Class Initialized
INFO - 2020-02-27 04:36:51 --> Router Class Initialized
INFO - 2020-02-27 04:36:51 --> Router Class Initialized
INFO - 2020-02-27 04:36:51 --> Router Class Initialized
INFO - 2020-02-27 04:36:51 --> URI Class Initialized
INFO - 2020-02-27 04:36:51 --> Router Class Initialized
INFO - 2020-02-27 04:36:51 --> Output Class Initialized
INFO - 2020-02-27 04:36:51 --> Output Class Initialized
INFO - 2020-02-27 04:36:51 --> Router Class Initialized
INFO - 2020-02-27 04:36:51 --> Output Class Initialized
INFO - 2020-02-27 04:36:51 --> Output Class Initialized
INFO - 2020-02-27 04:36:51 --> Security Class Initialized
INFO - 2020-02-27 04:36:51 --> Output Class Initialized
INFO - 2020-02-27 04:36:51 --> Output Class Initialized
INFO - 2020-02-27 04:36:51 --> Security Class Initialized
INFO - 2020-02-27 04:36:51 --> Security Class Initialized
INFO - 2020-02-27 04:36:51 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:51 --> Security Class Initialized
INFO - 2020-02-27 04:36:51 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
DEBUG - 2020-02-27 04:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
DEBUG - 2020-02-27 04:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
ERROR - 2020-02-27 04:36:52 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 04:36:52 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 04:36:52 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-27 04:36:52 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-27 04:36:52 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 04:36:52 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 04:36:52 --> Config Class Initialized
INFO - 2020-02-27 04:36:52 --> Config Class Initialized
INFO - 2020-02-27 04:36:52 --> Config Class Initialized
INFO - 2020-02-27 04:36:52 --> Config Class Initialized
INFO - 2020-02-27 04:36:52 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:52 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:52 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:52 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:52 --> Config Class Initialized
INFO - 2020-02-27 04:36:52 --> Config Class Initialized
INFO - 2020-02-27 04:36:52 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:52 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:52 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:52 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:52 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:52 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:36:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:52 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:52 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:52 --> URI Class Initialized
INFO - 2020-02-27 04:36:52 --> URI Class Initialized
INFO - 2020-02-27 04:36:52 --> URI Class Initialized
INFO - 2020-02-27 04:36:52 --> URI Class Initialized
INFO - 2020-02-27 04:36:52 --> URI Class Initialized
INFO - 2020-02-27 04:36:52 --> Router Class Initialized
INFO - 2020-02-27 04:36:52 --> Router Class Initialized
INFO - 2020-02-27 04:36:52 --> URI Class Initialized
INFO - 2020-02-27 04:36:52 --> Router Class Initialized
INFO - 2020-02-27 04:36:52 --> Router Class Initialized
INFO - 2020-02-27 04:36:52 --> Router Class Initialized
INFO - 2020-02-27 04:36:52 --> Output Class Initialized
INFO - 2020-02-27 04:36:52 --> Output Class Initialized
INFO - 2020-02-27 04:36:52 --> Output Class Initialized
INFO - 2020-02-27 04:36:52 --> Output Class Initialized
INFO - 2020-02-27 04:36:52 --> Router Class Initialized
INFO - 2020-02-27 04:36:52 --> Output Class Initialized
INFO - 2020-02-27 04:36:52 --> Output Class Initialized
INFO - 2020-02-27 04:36:52 --> Security Class Initialized
INFO - 2020-02-27 04:36:52 --> Security Class Initialized
INFO - 2020-02-27 04:36:52 --> Security Class Initialized
INFO - 2020-02-27 04:36:52 --> Security Class Initialized
INFO - 2020-02-27 04:36:52 --> Security Class Initialized
INFO - 2020-02-27 04:36:52 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
DEBUG - 2020-02-27 04:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
ERROR - 2020-02-27 04:36:52 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 04:36:52 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
INFO - 2020-02-27 04:36:52 --> Loader Class Initialized
INFO - 2020-02-27 04:36:52 --> Loader Class Initialized
ERROR - 2020-02-27 04:36:52 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 04:36:52 --> Helper loaded: url_helper
ERROR - 2020-02-27 04:36:52 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 04:36:52 --> Helper loaded: url_helper
INFO - 2020-02-27 04:36:52 --> Config Class Initialized
INFO - 2020-02-27 04:36:52 --> Config Class Initialized
INFO - 2020-02-27 04:36:52 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:52 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:52 --> Helper loaded: string_helper
INFO - 2020-02-27 04:36:52 --> Helper loaded: string_helper
DEBUG - 2020-02-27 04:36:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:52 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:36:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:52 --> Database Driver Class Initialized
INFO - 2020-02-27 04:36:52 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:52 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-27 04:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:36:52 --> URI Class Initialized
INFO - 2020-02-27 04:36:52 --> URI Class Initialized
INFO - 2020-02-27 04:36:52 --> Controller Class Initialized
INFO - 2020-02-27 04:36:52 --> Router Class Initialized
INFO - 2020-02-27 04:36:52 --> Router Class Initialized
INFO - 2020-02-27 04:36:52 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:36:52 --> Output Class Initialized
INFO - 2020-02-27 04:36:52 --> Output Class Initialized
INFO - 2020-02-27 04:36:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:36:52 --> Security Class Initialized
INFO - 2020-02-27 04:36:52 --> Security Class Initialized
INFO - 2020-02-27 04:36:52 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 04:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
INFO - 2020-02-27 04:36:52 --> Input Class Initialized
INFO - 2020-02-27 04:36:52 --> Helper loaded: form_helper
INFO - 2020-02-27 04:36:52 --> Form Validation Class Initialized
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
INFO - 2020-02-27 04:36:52 --> Language Class Initialized
ERROR - 2020-02-27 04:36:52 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 04:36:52 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 04:36:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 04:36:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 04:36:52 --> Config Class Initialized
INFO - 2020-02-27 04:36:52 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:36:52 --> Final output sent to browser
DEBUG - 2020-02-27 04:36:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:52 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:36:52 --> Total execution time: 0.6872
INFO - 2020-02-27 04:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:36:52 --> URI Class Initialized
INFO - 2020-02-27 04:36:52 --> Controller Class Initialized
INFO - 2020-02-27 04:36:52 --> Router Class Initialized
INFO - 2020-02-27 04:36:52 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:36:52 --> Output Class Initialized
INFO - 2020-02-27 04:36:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:36:52 --> Security Class Initialized
INFO - 2020-02-27 04:36:52 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 04:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:53 --> Input Class Initialized
INFO - 2020-02-27 04:36:53 --> Helper loaded: form_helper
INFO - 2020-02-27 04:36:53 --> Form Validation Class Initialized
INFO - 2020-02-27 04:36:53 --> Language Class Initialized
ERROR - 2020-02-27 04:36:53 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 04:36:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 04:36:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 04:36:53 --> Config Class Initialized
INFO - 2020-02-27 04:36:53 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:53 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:36:53 --> Final output sent to browser
DEBUG - 2020-02-27 04:36:53 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:53 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:36:53 --> Total execution time: 1.0306
INFO - 2020-02-27 04:36:53 --> URI Class Initialized
INFO - 2020-02-27 04:36:53 --> Router Class Initialized
INFO - 2020-02-27 04:36:53 --> Output Class Initialized
INFO - 2020-02-27 04:36:53 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:53 --> Input Class Initialized
INFO - 2020-02-27 04:36:53 --> Language Class Initialized
ERROR - 2020-02-27 04:36:53 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 04:36:53 --> Config Class Initialized
INFO - 2020-02-27 04:36:53 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:53 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:53 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:53 --> URI Class Initialized
INFO - 2020-02-27 04:36:53 --> Router Class Initialized
INFO - 2020-02-27 04:36:53 --> Output Class Initialized
INFO - 2020-02-27 04:36:53 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:53 --> Input Class Initialized
INFO - 2020-02-27 04:36:53 --> Language Class Initialized
ERROR - 2020-02-27 04:36:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:36:53 --> Config Class Initialized
INFO - 2020-02-27 04:36:53 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:53 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:53 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:53 --> URI Class Initialized
INFO - 2020-02-27 04:36:53 --> Router Class Initialized
INFO - 2020-02-27 04:36:53 --> Output Class Initialized
INFO - 2020-02-27 04:36:53 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:53 --> Input Class Initialized
INFO - 2020-02-27 04:36:54 --> Language Class Initialized
ERROR - 2020-02-27 04:36:54 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:36:54 --> Config Class Initialized
INFO - 2020-02-27 04:36:54 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:54 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:54 --> URI Class Initialized
INFO - 2020-02-27 04:36:54 --> Router Class Initialized
INFO - 2020-02-27 04:36:54 --> Output Class Initialized
INFO - 2020-02-27 04:36:54 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:54 --> Input Class Initialized
INFO - 2020-02-27 04:36:54 --> Language Class Initialized
ERROR - 2020-02-27 04:36:54 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 04:36:54 --> Config Class Initialized
INFO - 2020-02-27 04:36:54 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:54 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:54 --> URI Class Initialized
INFO - 2020-02-27 04:36:54 --> Router Class Initialized
INFO - 2020-02-27 04:36:54 --> Output Class Initialized
INFO - 2020-02-27 04:36:54 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:54 --> Input Class Initialized
INFO - 2020-02-27 04:36:54 --> Language Class Initialized
ERROR - 2020-02-27 04:36:54 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 04:36:54 --> Config Class Initialized
INFO - 2020-02-27 04:36:54 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:54 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:54 --> URI Class Initialized
INFO - 2020-02-27 04:36:54 --> Router Class Initialized
INFO - 2020-02-27 04:36:54 --> Output Class Initialized
INFO - 2020-02-27 04:36:54 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:55 --> Input Class Initialized
INFO - 2020-02-27 04:36:55 --> Language Class Initialized
ERROR - 2020-02-27 04:36:55 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 04:36:55 --> Config Class Initialized
INFO - 2020-02-27 04:36:55 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:55 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:55 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:55 --> URI Class Initialized
INFO - 2020-02-27 04:36:55 --> Router Class Initialized
INFO - 2020-02-27 04:36:55 --> Output Class Initialized
INFO - 2020-02-27 04:36:55 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:55 --> Input Class Initialized
INFO - 2020-02-27 04:36:55 --> Language Class Initialized
ERROR - 2020-02-27 04:36:55 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 04:36:57 --> Config Class Initialized
INFO - 2020-02-27 04:36:57 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:58 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:58 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:58 --> URI Class Initialized
INFO - 2020-02-27 04:36:58 --> Router Class Initialized
INFO - 2020-02-27 04:36:58 --> Output Class Initialized
INFO - 2020-02-27 04:36:58 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:58 --> Input Class Initialized
INFO - 2020-02-27 04:36:58 --> Language Class Initialized
INFO - 2020-02-27 04:36:58 --> Loader Class Initialized
INFO - 2020-02-27 04:36:58 --> Helper loaded: url_helper
INFO - 2020-02-27 04:36:58 --> Helper loaded: string_helper
INFO - 2020-02-27 04:36:58 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:36:59 --> Controller Class Initialized
INFO - 2020-02-27 04:36:59 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:36:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:36:59 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:36:59 --> Helper loaded: form_helper
INFO - 2020-02-27 04:36:59 --> Form Validation Class Initialized
INFO - 2020-02-27 04:36:59 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:36:59 --> Final output sent to browser
INFO - 2020-02-27 04:36:59 --> Config Class Initialized
INFO - 2020-02-27 04:36:59 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:59 --> Total execution time: 1.7348
INFO - 2020-02-27 04:36:59 --> Config Class Initialized
INFO - 2020-02-27 04:36:59 --> Config Class Initialized
INFO - 2020-02-27 04:36:59 --> Config Class Initialized
INFO - 2020-02-27 04:36:59 --> Config Class Initialized
INFO - 2020-02-27 04:36:59 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:59 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:59 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:59 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:59 --> Config Class Initialized
INFO - 2020-02-27 04:36:59 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:59 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:59 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:59 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:59 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:59 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:59 --> URI Class Initialized
DEBUG - 2020-02-27 04:36:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:59 --> Utf8 Class Initialized
INFO - 2020-02-27 04:36:59 --> URI Class Initialized
INFO - 2020-02-27 04:36:59 --> URI Class Initialized
INFO - 2020-02-27 04:36:59 --> URI Class Initialized
INFO - 2020-02-27 04:36:59 --> URI Class Initialized
INFO - 2020-02-27 04:36:59 --> Router Class Initialized
INFO - 2020-02-27 04:36:59 --> Router Class Initialized
INFO - 2020-02-27 04:36:59 --> Router Class Initialized
INFO - 2020-02-27 04:36:59 --> Output Class Initialized
INFO - 2020-02-27 04:36:59 --> URI Class Initialized
INFO - 2020-02-27 04:36:59 --> Router Class Initialized
INFO - 2020-02-27 04:36:59 --> Router Class Initialized
INFO - 2020-02-27 04:36:59 --> Router Class Initialized
INFO - 2020-02-27 04:36:59 --> Security Class Initialized
INFO - 2020-02-27 04:36:59 --> Output Class Initialized
INFO - 2020-02-27 04:36:59 --> Output Class Initialized
INFO - 2020-02-27 04:36:59 --> Output Class Initialized
INFO - 2020-02-27 04:36:59 --> Output Class Initialized
INFO - 2020-02-27 04:36:59 --> Security Class Initialized
INFO - 2020-02-27 04:36:59 --> Security Class Initialized
INFO - 2020-02-27 04:36:59 --> Security Class Initialized
INFO - 2020-02-27 04:36:59 --> Output Class Initialized
INFO - 2020-02-27 04:36:59 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:59 --> Input Class Initialized
INFO - 2020-02-27 04:36:59 --> Security Class Initialized
DEBUG - 2020-02-27 04:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:59 --> Input Class Initialized
INFO - 2020-02-27 04:36:59 --> Input Class Initialized
INFO - 2020-02-27 04:36:59 --> Input Class Initialized
INFO - 2020-02-27 04:36:59 --> Language Class Initialized
INFO - 2020-02-27 04:36:59 --> Input Class Initialized
DEBUG - 2020-02-27 04:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:36:59 --> Input Class Initialized
INFO - 2020-02-27 04:36:59 --> Language Class Initialized
INFO - 2020-02-27 04:36:59 --> Language Class Initialized
INFO - 2020-02-27 04:36:59 --> Language Class Initialized
INFO - 2020-02-27 04:36:59 --> Language Class Initialized
ERROR - 2020-02-27 04:36:59 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-27 04:36:59 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 04:36:59 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 04:36:59 --> Language Class Initialized
ERROR - 2020-02-27 04:36:59 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 04:36:59 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 04:36:59 --> Config Class Initialized
INFO - 2020-02-27 04:36:59 --> Hooks Class Initialized
ERROR - 2020-02-27 04:36:59 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:36:59 --> Config Class Initialized
INFO - 2020-02-27 04:36:59 --> Config Class Initialized
INFO - 2020-02-27 04:36:59 --> Config Class Initialized
INFO - 2020-02-27 04:36:59 --> Config Class Initialized
INFO - 2020-02-27 04:36:59 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:59 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:59 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:59 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:36:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:36:59 --> Config Class Initialized
INFO - 2020-02-27 04:36:59 --> Hooks Class Initialized
INFO - 2020-02-27 04:36:59 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:36:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:00 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:00 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:00 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:00 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:00 --> URI Class Initialized
DEBUG - 2020-02-27 04:37:00 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:00 --> URI Class Initialized
INFO - 2020-02-27 04:37:00 --> URI Class Initialized
INFO - 2020-02-27 04:37:00 --> Router Class Initialized
INFO - 2020-02-27 04:37:00 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:00 --> URI Class Initialized
INFO - 2020-02-27 04:37:00 --> Output Class Initialized
INFO - 2020-02-27 04:37:00 --> Router Class Initialized
INFO - 2020-02-27 04:37:00 --> Router Class Initialized
INFO - 2020-02-27 04:37:00 --> URI Class Initialized
INFO - 2020-02-27 04:37:00 --> URI Class Initialized
INFO - 2020-02-27 04:37:00 --> Router Class Initialized
INFO - 2020-02-27 04:37:00 --> Security Class Initialized
INFO - 2020-02-27 04:37:00 --> Router Class Initialized
INFO - 2020-02-27 04:37:00 --> Output Class Initialized
INFO - 2020-02-27 04:37:00 --> Output Class Initialized
INFO - 2020-02-27 04:37:00 --> Router Class Initialized
DEBUG - 2020-02-27 04:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:00 --> Security Class Initialized
INFO - 2020-02-27 04:37:00 --> Output Class Initialized
INFO - 2020-02-27 04:37:00 --> Security Class Initialized
INFO - 2020-02-27 04:37:00 --> Output Class Initialized
INFO - 2020-02-27 04:37:00 --> Output Class Initialized
DEBUG - 2020-02-27 04:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:00 --> Security Class Initialized
INFO - 2020-02-27 04:37:00 --> Security Class Initialized
INFO - 2020-02-27 04:37:00 --> Input Class Initialized
INFO - 2020-02-27 04:37:00 --> Security Class Initialized
INFO - 2020-02-27 04:37:00 --> Input Class Initialized
INFO - 2020-02-27 04:37:00 --> Input Class Initialized
INFO - 2020-02-27 04:37:00 --> Language Class Initialized
DEBUG - 2020-02-27 04:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:00 --> Input Class Initialized
INFO - 2020-02-27 04:37:00 --> Input Class Initialized
INFO - 2020-02-27 04:37:00 --> Input Class Initialized
INFO - 2020-02-27 04:37:00 --> Language Class Initialized
INFO - 2020-02-27 04:37:00 --> Language Class Initialized
ERROR - 2020-02-27 04:37:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:37:00 --> Language Class Initialized
ERROR - 2020-02-27 04:37:00 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 04:37:00 --> Language Class Initialized
INFO - 2020-02-27 04:37:00 --> Language Class Initialized
ERROR - 2020-02-27 04:37:00 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 04:37:00 --> Config Class Initialized
INFO - 2020-02-27 04:37:00 --> Hooks Class Initialized
ERROR - 2020-02-27 04:37:00 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 04:37:00 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 04:37:00 --> Loader Class Initialized
INFO - 2020-02-27 04:37:00 --> Config Class Initialized
INFO - 2020-02-27 04:37:00 --> Hooks Class Initialized
INFO - 2020-02-27 04:37:00 --> Helper loaded: url_helper
DEBUG - 2020-02-27 04:37:00 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:00 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:00 --> Helper loaded: string_helper
DEBUG - 2020-02-27 04:37:00 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:00 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:00 --> URI Class Initialized
INFO - 2020-02-27 04:37:00 --> Database Driver Class Initialized
INFO - 2020-02-27 04:37:00 --> URI Class Initialized
INFO - 2020-02-27 04:37:00 --> Router Class Initialized
DEBUG - 2020-02-27 04:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:37:00 --> Router Class Initialized
INFO - 2020-02-27 04:37:00 --> Output Class Initialized
INFO - 2020-02-27 04:37:00 --> Controller Class Initialized
INFO - 2020-02-27 04:37:00 --> Security Class Initialized
INFO - 2020-02-27 04:37:00 --> Output Class Initialized
INFO - 2020-02-27 04:37:00 --> Security Class Initialized
INFO - 2020-02-27 04:37:00 --> Model "M_tiket" initialized
DEBUG - 2020-02-27 04:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:00 --> Input Class Initialized
INFO - 2020-02-27 04:37:00 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-27 04:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:00 --> Input Class Initialized
INFO - 2020-02-27 04:37:00 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:37:00 --> Language Class Initialized
INFO - 2020-02-27 04:37:00 --> Language Class Initialized
INFO - 2020-02-27 04:37:00 --> Loader Class Initialized
INFO - 2020-02-27 04:37:00 --> Helper loaded: form_helper
INFO - 2020-02-27 04:37:00 --> Form Validation Class Initialized
INFO - 2020-02-27 04:37:00 --> Helper loaded: url_helper
ERROR - 2020-02-27 04:37:00 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 04:37:00 --> Helper loaded: string_helper
ERROR - 2020-02-27 04:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-27 04:37:00 --> Config Class Initialized
INFO - 2020-02-27 04:37:00 --> Hooks Class Initialized
ERROR - 2020-02-27 04:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 04:37:00 --> Database Driver Class Initialized
INFO - 2020-02-27 04:37:00 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-27 04:37:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:37:00 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:00 --> Final output sent to browser
DEBUG - 2020-02-27 04:37:00 --> Total execution time: 0.6921
INFO - 2020-02-27 04:37:00 --> URI Class Initialized
INFO - 2020-02-27 04:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:37:00 --> Router Class Initialized
INFO - 2020-02-27 04:37:00 --> Controller Class Initialized
INFO - 2020-02-27 04:37:00 --> Output Class Initialized
INFO - 2020-02-27 04:37:00 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:37:00 --> Security Class Initialized
INFO - 2020-02-27 04:37:00 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-27 04:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:00 --> Input Class Initialized
INFO - 2020-02-27 04:37:00 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:37:00 --> Language Class Initialized
INFO - 2020-02-27 04:37:00 --> Helper loaded: form_helper
INFO - 2020-02-27 04:37:00 --> Form Validation Class Initialized
ERROR - 2020-02-27 04:37:00 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 04:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-27 04:37:00 --> Config Class Initialized
INFO - 2020-02-27 04:37:00 --> Hooks Class Initialized
ERROR - 2020-02-27 04:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 04:37:00 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-27 04:37:00 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:00 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:00 --> Final output sent to browser
DEBUG - 2020-02-27 04:37:00 --> Total execution time: 0.6597
INFO - 2020-02-27 04:37:00 --> URI Class Initialized
INFO - 2020-02-27 04:37:00 --> Router Class Initialized
INFO - 2020-02-27 04:37:00 --> Output Class Initialized
INFO - 2020-02-27 04:37:00 --> Security Class Initialized
DEBUG - 2020-02-27 04:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:01 --> Input Class Initialized
INFO - 2020-02-27 04:37:01 --> Language Class Initialized
ERROR - 2020-02-27 04:37:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 04:37:01 --> Config Class Initialized
INFO - 2020-02-27 04:37:01 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:37:01 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:01 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:01 --> URI Class Initialized
INFO - 2020-02-27 04:37:01 --> Router Class Initialized
INFO - 2020-02-27 04:37:01 --> Output Class Initialized
INFO - 2020-02-27 04:37:01 --> Security Class Initialized
DEBUG - 2020-02-27 04:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:01 --> Input Class Initialized
INFO - 2020-02-27 04:37:01 --> Language Class Initialized
ERROR - 2020-02-27 04:37:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:37:01 --> Config Class Initialized
INFO - 2020-02-27 04:37:01 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:37:01 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:01 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:01 --> URI Class Initialized
INFO - 2020-02-27 04:37:01 --> Router Class Initialized
INFO - 2020-02-27 04:37:01 --> Output Class Initialized
INFO - 2020-02-27 04:37:01 --> Security Class Initialized
DEBUG - 2020-02-27 04:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:01 --> Input Class Initialized
INFO - 2020-02-27 04:37:01 --> Language Class Initialized
ERROR - 2020-02-27 04:37:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:37:01 --> Config Class Initialized
INFO - 2020-02-27 04:37:01 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:37:01 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:01 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:01 --> URI Class Initialized
INFO - 2020-02-27 04:37:01 --> Router Class Initialized
INFO - 2020-02-27 04:37:01 --> Output Class Initialized
INFO - 2020-02-27 04:37:01 --> Security Class Initialized
DEBUG - 2020-02-27 04:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:01 --> Input Class Initialized
INFO - 2020-02-27 04:37:01 --> Language Class Initialized
ERROR - 2020-02-27 04:37:01 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 04:37:02 --> Config Class Initialized
INFO - 2020-02-27 04:37:02 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:37:02 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:02 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:02 --> URI Class Initialized
INFO - 2020-02-27 04:37:02 --> Router Class Initialized
INFO - 2020-02-27 04:37:02 --> Output Class Initialized
INFO - 2020-02-27 04:37:02 --> Security Class Initialized
DEBUG - 2020-02-27 04:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:02 --> Input Class Initialized
INFO - 2020-02-27 04:37:02 --> Language Class Initialized
ERROR - 2020-02-27 04:37:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 04:37:02 --> Config Class Initialized
INFO - 2020-02-27 04:37:02 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:37:02 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:02 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:02 --> URI Class Initialized
INFO - 2020-02-27 04:37:02 --> Router Class Initialized
INFO - 2020-02-27 04:37:02 --> Output Class Initialized
INFO - 2020-02-27 04:37:02 --> Security Class Initialized
DEBUG - 2020-02-27 04:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:02 --> Input Class Initialized
INFO - 2020-02-27 04:37:02 --> Language Class Initialized
ERROR - 2020-02-27 04:37:02 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 04:37:02 --> Config Class Initialized
INFO - 2020-02-27 04:37:02 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:37:02 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:02 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:02 --> URI Class Initialized
INFO - 2020-02-27 04:37:02 --> Router Class Initialized
INFO - 2020-02-27 04:37:02 --> Output Class Initialized
INFO - 2020-02-27 04:37:02 --> Security Class Initialized
DEBUG - 2020-02-27 04:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:02 --> Input Class Initialized
INFO - 2020-02-27 04:37:02 --> Language Class Initialized
ERROR - 2020-02-27 04:37:02 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 04:37:24 --> Config Class Initialized
INFO - 2020-02-27 04:37:24 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:37:24 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:24 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:24 --> URI Class Initialized
INFO - 2020-02-27 04:37:25 --> Router Class Initialized
INFO - 2020-02-27 04:37:25 --> Output Class Initialized
INFO - 2020-02-27 04:37:25 --> Security Class Initialized
DEBUG - 2020-02-27 04:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:25 --> Input Class Initialized
INFO - 2020-02-27 04:37:25 --> Language Class Initialized
INFO - 2020-02-27 04:37:25 --> Loader Class Initialized
INFO - 2020-02-27 04:37:25 --> Helper loaded: url_helper
INFO - 2020-02-27 04:37:25 --> Helper loaded: string_helper
INFO - 2020-02-27 04:37:25 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:37:25 --> Controller Class Initialized
INFO - 2020-02-27 04:37:25 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:37:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:37:25 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:37:25 --> Helper loaded: form_helper
INFO - 2020-02-27 04:37:25 --> Form Validation Class Initialized
INFO - 2020-02-27 10:37:25 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 10:37:25 --> Final output sent to browser
DEBUG - 2020-02-27 10:37:25 --> Total execution time: 0.9264
INFO - 2020-02-27 04:37:29 --> Config Class Initialized
INFO - 2020-02-27 04:37:29 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:37:30 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:30 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:30 --> URI Class Initialized
INFO - 2020-02-27 04:37:30 --> Router Class Initialized
INFO - 2020-02-27 04:37:30 --> Output Class Initialized
INFO - 2020-02-27 04:37:30 --> Security Class Initialized
DEBUG - 2020-02-27 04:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:30 --> Input Class Initialized
INFO - 2020-02-27 04:37:30 --> Language Class Initialized
INFO - 2020-02-27 04:37:30 --> Loader Class Initialized
INFO - 2020-02-27 04:37:30 --> Helper loaded: url_helper
INFO - 2020-02-27 04:37:30 --> Helper loaded: string_helper
INFO - 2020-02-27 04:37:30 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:37:30 --> Controller Class Initialized
INFO - 2020-02-27 04:37:30 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:37:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:37:30 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:37:30 --> Helper loaded: form_helper
INFO - 2020-02-27 04:37:30 --> Form Validation Class Initialized
ERROR - 2020-02-27 04:37:30 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 04:37:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 04:37:30 --> Final output sent to browser
DEBUG - 2020-02-27 04:37:30 --> Total execution time: 0.9601
INFO - 2020-02-27 04:37:43 --> Config Class Initialized
INFO - 2020-02-27 04:37:43 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:37:43 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:43 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:43 --> URI Class Initialized
INFO - 2020-02-27 04:37:43 --> Router Class Initialized
INFO - 2020-02-27 04:37:43 --> Output Class Initialized
INFO - 2020-02-27 04:37:43 --> Security Class Initialized
DEBUG - 2020-02-27 04:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:44 --> Input Class Initialized
INFO - 2020-02-27 04:37:44 --> Language Class Initialized
INFO - 2020-02-27 04:37:44 --> Loader Class Initialized
INFO - 2020-02-27 04:37:44 --> Helper loaded: url_helper
INFO - 2020-02-27 04:37:44 --> Helper loaded: string_helper
INFO - 2020-02-27 04:37:44 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:37:44 --> Controller Class Initialized
INFO - 2020-02-27 04:37:44 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:37:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:37:44 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:37:44 --> Helper loaded: form_helper
INFO - 2020-02-27 04:37:44 --> Form Validation Class Initialized
INFO - 2020-02-27 04:37:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-27 04:37:44 --> Config Class Initialized
INFO - 2020-02-27 04:37:44 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:37:44 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:44 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:45 --> URI Class Initialized
INFO - 2020-02-27 04:37:45 --> Router Class Initialized
INFO - 2020-02-27 04:37:45 --> Output Class Initialized
INFO - 2020-02-27 04:37:45 --> Security Class Initialized
DEBUG - 2020-02-27 04:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:45 --> Input Class Initialized
INFO - 2020-02-27 04:37:45 --> Language Class Initialized
INFO - 2020-02-27 04:37:45 --> Loader Class Initialized
INFO - 2020-02-27 04:37:45 --> Helper loaded: url_helper
INFO - 2020-02-27 04:37:45 --> Helper loaded: string_helper
INFO - 2020-02-27 04:37:45 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:37:45 --> Controller Class Initialized
INFO - 2020-02-27 04:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 04:37:45 --> Pagination Class Initialized
INFO - 2020-02-27 04:37:45 --> Model "M_show" initialized
INFO - 2020-02-27 04:37:45 --> Helper loaded: form_helper
INFO - 2020-02-27 04:37:45 --> Form Validation Class Initialized
INFO - 2020-02-27 04:37:45 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 04:37:45 --> Final output sent to browser
DEBUG - 2020-02-27 04:37:45 --> Total execution time: 0.7549
INFO - 2020-02-27 04:37:45 --> Config Class Initialized
INFO - 2020-02-27 04:37:45 --> Config Class Initialized
INFO - 2020-02-27 04:37:45 --> Hooks Class Initialized
INFO - 2020-02-27 04:37:45 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:37:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:37:45 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:45 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:45 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:45 --> URI Class Initialized
INFO - 2020-02-27 04:37:45 --> URI Class Initialized
INFO - 2020-02-27 04:37:45 --> Router Class Initialized
INFO - 2020-02-27 04:37:45 --> Router Class Initialized
INFO - 2020-02-27 04:37:46 --> Output Class Initialized
INFO - 2020-02-27 04:37:46 --> Output Class Initialized
INFO - 2020-02-27 04:37:46 --> Security Class Initialized
INFO - 2020-02-27 04:37:46 --> Security Class Initialized
DEBUG - 2020-02-27 04:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:46 --> Input Class Initialized
INFO - 2020-02-27 04:37:46 --> Input Class Initialized
INFO - 2020-02-27 04:37:46 --> Language Class Initialized
INFO - 2020-02-27 04:37:46 --> Language Class Initialized
ERROR - 2020-02-27 04:37:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 04:37:46 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:37:46 --> Config Class Initialized
INFO - 2020-02-27 04:37:46 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:37:46 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:37:46 --> Utf8 Class Initialized
INFO - 2020-02-27 04:37:46 --> URI Class Initialized
INFO - 2020-02-27 04:37:46 --> Router Class Initialized
INFO - 2020-02-27 04:37:46 --> Output Class Initialized
INFO - 2020-02-27 04:37:46 --> Security Class Initialized
DEBUG - 2020-02-27 04:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:37:46 --> Input Class Initialized
INFO - 2020-02-27 04:37:46 --> Language Class Initialized
ERROR - 2020-02-27 04:37:46 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:40:14 --> Config Class Initialized
INFO - 2020-02-27 04:40:14 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:40:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:14 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:14 --> URI Class Initialized
INFO - 2020-02-27 04:40:14 --> Router Class Initialized
INFO - 2020-02-27 04:40:14 --> Output Class Initialized
INFO - 2020-02-27 04:40:14 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:14 --> Input Class Initialized
INFO - 2020-02-27 04:40:14 --> Language Class Initialized
INFO - 2020-02-27 04:40:14 --> Loader Class Initialized
INFO - 2020-02-27 04:40:14 --> Helper loaded: url_helper
INFO - 2020-02-27 04:40:14 --> Helper loaded: string_helper
INFO - 2020-02-27 04:40:14 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:40:15 --> Controller Class Initialized
INFO - 2020-02-27 04:40:15 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:40:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:40:15 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:40:15 --> Helper loaded: form_helper
INFO - 2020-02-27 04:40:15 --> Form Validation Class Initialized
INFO - 2020-02-27 04:40:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:40:15 --> Final output sent to browser
DEBUG - 2020-02-27 04:40:15 --> Total execution time: 0.7142
INFO - 2020-02-27 04:40:15 --> Config Class Initialized
INFO - 2020-02-27 04:40:15 --> Config Class Initialized
INFO - 2020-02-27 04:40:15 --> Config Class Initialized
INFO - 2020-02-27 04:40:15 --> Config Class Initialized
INFO - 2020-02-27 04:40:15 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:15 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:15 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:15 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:15 --> Config Class Initialized
INFO - 2020-02-27 04:40:15 --> Config Class Initialized
INFO - 2020-02-27 04:40:15 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:15 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:40:15 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:15 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:15 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:15 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:15 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:40:15 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:15 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:15 --> URI Class Initialized
INFO - 2020-02-27 04:40:15 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:15 --> URI Class Initialized
INFO - 2020-02-27 04:40:15 --> URI Class Initialized
INFO - 2020-02-27 04:40:15 --> URI Class Initialized
INFO - 2020-02-27 04:40:15 --> Router Class Initialized
INFO - 2020-02-27 04:40:15 --> URI Class Initialized
INFO - 2020-02-27 04:40:15 --> Router Class Initialized
INFO - 2020-02-27 04:40:15 --> Router Class Initialized
INFO - 2020-02-27 04:40:15 --> Router Class Initialized
INFO - 2020-02-27 04:40:15 --> Output Class Initialized
INFO - 2020-02-27 04:40:15 --> Router Class Initialized
INFO - 2020-02-27 04:40:15 --> URI Class Initialized
INFO - 2020-02-27 04:40:15 --> Security Class Initialized
INFO - 2020-02-27 04:40:15 --> Output Class Initialized
INFO - 2020-02-27 04:40:15 --> Output Class Initialized
INFO - 2020-02-27 04:40:15 --> Output Class Initialized
INFO - 2020-02-27 04:40:15 --> Router Class Initialized
INFO - 2020-02-27 04:40:15 --> Output Class Initialized
INFO - 2020-02-27 04:40:15 --> Security Class Initialized
INFO - 2020-02-27 04:40:15 --> Security Class Initialized
INFO - 2020-02-27 04:40:15 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:15 --> Security Class Initialized
INFO - 2020-02-27 04:40:15 --> Output Class Initialized
INFO - 2020-02-27 04:40:15 --> Input Class Initialized
DEBUG - 2020-02-27 04:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:15 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:15 --> Input Class Initialized
INFO - 2020-02-27 04:40:15 --> Input Class Initialized
INFO - 2020-02-27 04:40:15 --> Input Class Initialized
INFO - 2020-02-27 04:40:15 --> Input Class Initialized
INFO - 2020-02-27 04:40:15 --> Language Class Initialized
DEBUG - 2020-02-27 04:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:15 --> Input Class Initialized
INFO - 2020-02-27 04:40:15 --> Language Class Initialized
INFO - 2020-02-27 04:40:15 --> Language Class Initialized
INFO - 2020-02-27 04:40:15 --> Language Class Initialized
ERROR - 2020-02-27 04:40:15 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 04:40:15 --> Language Class Initialized
ERROR - 2020-02-27 04:40:15 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-27 04:40:15 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 04:40:15 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 04:40:15 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 04:40:15 --> Language Class Initialized
INFO - 2020-02-27 04:40:15 --> Config Class Initialized
INFO - 2020-02-27 04:40:15 --> Hooks Class Initialized
ERROR - 2020-02-27 04:40:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:40:15 --> Config Class Initialized
INFO - 2020-02-27 04:40:15 --> Config Class Initialized
INFO - 2020-02-27 04:40:15 --> Config Class Initialized
INFO - 2020-02-27 04:40:15 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:15 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:15 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:15 --> Config Class Initialized
DEBUG - 2020-02-27 04:40:15 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:15 --> Config Class Initialized
INFO - 2020-02-27 04:40:15 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:15 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:15 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:40:15 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:15 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:15 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:15 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:15 --> URI Class Initialized
DEBUG - 2020-02-27 04:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:40:15 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:15 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:15 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:15 --> URI Class Initialized
INFO - 2020-02-27 04:40:15 --> URI Class Initialized
INFO - 2020-02-27 04:40:15 --> URI Class Initialized
INFO - 2020-02-27 04:40:15 --> Router Class Initialized
INFO - 2020-02-27 04:40:15 --> Router Class Initialized
INFO - 2020-02-27 04:40:15 --> Output Class Initialized
INFO - 2020-02-27 04:40:15 --> Router Class Initialized
INFO - 2020-02-27 04:40:15 --> URI Class Initialized
INFO - 2020-02-27 04:40:15 --> Router Class Initialized
INFO - 2020-02-27 04:40:15 --> URI Class Initialized
INFO - 2020-02-27 04:40:15 --> Security Class Initialized
INFO - 2020-02-27 04:40:15 --> Router Class Initialized
INFO - 2020-02-27 04:40:15 --> Output Class Initialized
INFO - 2020-02-27 04:40:15 --> Output Class Initialized
INFO - 2020-02-27 04:40:15 --> Router Class Initialized
INFO - 2020-02-27 04:40:15 --> Output Class Initialized
DEBUG - 2020-02-27 04:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:15 --> Security Class Initialized
INFO - 2020-02-27 04:40:15 --> Output Class Initialized
INFO - 2020-02-27 04:40:15 --> Security Class Initialized
INFO - 2020-02-27 04:40:15 --> Security Class Initialized
INFO - 2020-02-27 04:40:15 --> Output Class Initialized
INFO - 2020-02-27 04:40:15 --> Input Class Initialized
DEBUG - 2020-02-27 04:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:15 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:16 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:16 --> Input Class Initialized
INFO - 2020-02-27 04:40:16 --> Input Class Initialized
INFO - 2020-02-27 04:40:16 --> Input Class Initialized
INFO - 2020-02-27 04:40:16 --> Language Class Initialized
DEBUG - 2020-02-27 04:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:16 --> Input Class Initialized
INFO - 2020-02-27 04:40:16 --> Language Class Initialized
INFO - 2020-02-27 04:40:16 --> Input Class Initialized
INFO - 2020-02-27 04:40:16 --> Language Class Initialized
INFO - 2020-02-27 04:40:16 --> Language Class Initialized
INFO - 2020-02-27 04:40:16 --> Loader Class Initialized
INFO - 2020-02-27 04:40:16 --> Language Class Initialized
INFO - 2020-02-27 04:40:16 --> Language Class Initialized
ERROR - 2020-02-27 04:40:16 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:40:16 --> Helper loaded: url_helper
ERROR - 2020-02-27 04:40:16 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 04:40:16 --> Loader Class Initialized
ERROR - 2020-02-27 04:40:16 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-27 04:40:16 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 04:40:16 --> Helper loaded: url_helper
INFO - 2020-02-27 04:40:16 --> Helper loaded: string_helper
INFO - 2020-02-27 04:40:16 --> Config Class Initialized
INFO - 2020-02-27 04:40:16 --> Config Class Initialized
INFO - 2020-02-27 04:40:16 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:16 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:16 --> Helper loaded: string_helper
INFO - 2020-02-27 04:40:16 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:40:16 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:40:16 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:40:16 --> Database Driver Class Initialized
INFO - 2020-02-27 04:40:16 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:16 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-27 04:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:40:16 --> Controller Class Initialized
INFO - 2020-02-27 04:40:16 --> URI Class Initialized
INFO - 2020-02-27 04:40:16 --> URI Class Initialized
INFO - 2020-02-27 04:40:16 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:40:16 --> Router Class Initialized
INFO - 2020-02-27 04:40:16 --> Router Class Initialized
INFO - 2020-02-27 04:40:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:40:16 --> Output Class Initialized
INFO - 2020-02-27 04:40:16 --> Output Class Initialized
INFO - 2020-02-27 04:40:16 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:40:16 --> Security Class Initialized
INFO - 2020-02-27 04:40:16 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:16 --> Helper loaded: form_helper
INFO - 2020-02-27 04:40:16 --> Form Validation Class Initialized
INFO - 2020-02-27 04:40:16 --> Input Class Initialized
INFO - 2020-02-27 04:40:16 --> Input Class Initialized
INFO - 2020-02-27 04:40:16 --> Language Class Initialized
INFO - 2020-02-27 04:40:16 --> Language Class Initialized
ERROR - 2020-02-27 04:40:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 04:40:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-27 04:40:16 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 04:40:16 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 04:40:16 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:40:16 --> Config Class Initialized
INFO - 2020-02-27 04:40:16 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:16 --> Final output sent to browser
DEBUG - 2020-02-27 04:40:16 --> Total execution time: 1.0873
DEBUG - 2020-02-27 04:40:16 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:16 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:40:17 --> Controller Class Initialized
INFO - 2020-02-27 04:40:17 --> URI Class Initialized
INFO - 2020-02-27 04:40:17 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:40:17 --> Router Class Initialized
INFO - 2020-02-27 04:40:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:40:17 --> Output Class Initialized
INFO - 2020-02-27 04:40:17 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:40:17 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:17 --> Helper loaded: form_helper
INFO - 2020-02-27 04:40:17 --> Input Class Initialized
INFO - 2020-02-27 04:40:17 --> Form Validation Class Initialized
INFO - 2020-02-27 04:40:17 --> Language Class Initialized
ERROR - 2020-02-27 04:40:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 04:40:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-27 04:40:17 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 04:40:17 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:40:17 --> Config Class Initialized
INFO - 2020-02-27 04:40:17 --> Hooks Class Initialized
INFO - 2020-02-27 04:40:17 --> Final output sent to browser
DEBUG - 2020-02-27 04:40:17 --> Total execution time: 1.8451
DEBUG - 2020-02-27 04:40:17 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:17 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:17 --> URI Class Initialized
INFO - 2020-02-27 04:40:17 --> Router Class Initialized
INFO - 2020-02-27 04:40:17 --> Output Class Initialized
INFO - 2020-02-27 04:40:17 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:18 --> Input Class Initialized
INFO - 2020-02-27 04:40:18 --> Language Class Initialized
ERROR - 2020-02-27 04:40:18 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 04:40:18 --> Config Class Initialized
INFO - 2020-02-27 04:40:18 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:40:18 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:18 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:18 --> URI Class Initialized
INFO - 2020-02-27 04:40:18 --> Router Class Initialized
INFO - 2020-02-27 04:40:18 --> Output Class Initialized
INFO - 2020-02-27 04:40:18 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:18 --> Input Class Initialized
INFO - 2020-02-27 04:40:18 --> Language Class Initialized
ERROR - 2020-02-27 04:40:18 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 04:40:18 --> Config Class Initialized
INFO - 2020-02-27 04:40:18 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:40:18 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:18 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:18 --> URI Class Initialized
INFO - 2020-02-27 04:40:18 --> Router Class Initialized
INFO - 2020-02-27 04:40:18 --> Output Class Initialized
INFO - 2020-02-27 04:40:19 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:19 --> Input Class Initialized
INFO - 2020-02-27 04:40:19 --> Language Class Initialized
ERROR - 2020-02-27 04:40:19 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:40:19 --> Config Class Initialized
INFO - 2020-02-27 04:40:19 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:40:19 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:19 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:19 --> URI Class Initialized
INFO - 2020-02-27 04:40:19 --> Router Class Initialized
INFO - 2020-02-27 04:40:19 --> Output Class Initialized
INFO - 2020-02-27 04:40:19 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:19 --> Input Class Initialized
INFO - 2020-02-27 04:40:19 --> Language Class Initialized
ERROR - 2020-02-27 04:40:19 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:40:19 --> Config Class Initialized
INFO - 2020-02-27 04:40:19 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:40:19 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:19 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:19 --> URI Class Initialized
INFO - 2020-02-27 04:40:19 --> Router Class Initialized
INFO - 2020-02-27 04:40:19 --> Output Class Initialized
INFO - 2020-02-27 04:40:19 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:19 --> Input Class Initialized
INFO - 2020-02-27 04:40:19 --> Language Class Initialized
ERROR - 2020-02-27 04:40:19 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 04:40:19 --> Config Class Initialized
INFO - 2020-02-27 04:40:19 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:40:19 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:19 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:19 --> URI Class Initialized
INFO - 2020-02-27 04:40:19 --> Router Class Initialized
INFO - 2020-02-27 04:40:19 --> Output Class Initialized
INFO - 2020-02-27 04:40:20 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:20 --> Input Class Initialized
INFO - 2020-02-27 04:40:20 --> Language Class Initialized
ERROR - 2020-02-27 04:40:20 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 04:40:20 --> Config Class Initialized
INFO - 2020-02-27 04:40:20 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:40:20 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:20 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:20 --> URI Class Initialized
INFO - 2020-02-27 04:40:20 --> Router Class Initialized
INFO - 2020-02-27 04:40:20 --> Output Class Initialized
INFO - 2020-02-27 04:40:20 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:20 --> Input Class Initialized
INFO - 2020-02-27 04:40:20 --> Language Class Initialized
ERROR - 2020-02-27 04:40:20 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 04:40:20 --> Config Class Initialized
INFO - 2020-02-27 04:40:20 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:40:20 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:40:20 --> Utf8 Class Initialized
INFO - 2020-02-27 04:40:20 --> URI Class Initialized
INFO - 2020-02-27 04:40:20 --> Router Class Initialized
INFO - 2020-02-27 04:40:20 --> Output Class Initialized
INFO - 2020-02-27 04:40:20 --> Security Class Initialized
DEBUG - 2020-02-27 04:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:40:20 --> Input Class Initialized
INFO - 2020-02-27 04:40:20 --> Language Class Initialized
ERROR - 2020-02-27 04:40:20 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 04:41:56 --> Config Class Initialized
INFO - 2020-02-27 04:41:56 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:41:56 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:41:56 --> Utf8 Class Initialized
INFO - 2020-02-27 04:41:56 --> URI Class Initialized
INFO - 2020-02-27 04:41:56 --> Router Class Initialized
INFO - 2020-02-27 04:41:56 --> Output Class Initialized
INFO - 2020-02-27 04:41:56 --> Security Class Initialized
DEBUG - 2020-02-27 04:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:41:56 --> Input Class Initialized
INFO - 2020-02-27 04:41:56 --> Language Class Initialized
INFO - 2020-02-27 04:41:56 --> Loader Class Initialized
INFO - 2020-02-27 04:41:56 --> Helper loaded: url_helper
INFO - 2020-02-27 04:41:56 --> Helper loaded: string_helper
INFO - 2020-02-27 04:41:56 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:41:56 --> Controller Class Initialized
INFO - 2020-02-27 04:41:56 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:41:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:41:56 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:41:56 --> Helper loaded: form_helper
INFO - 2020-02-27 04:41:56 --> Form Validation Class Initialized
INFO - 2020-02-27 10:41:56 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 10:41:57 --> Final output sent to browser
DEBUG - 2020-02-27 10:41:57 --> Total execution time: 0.9052
INFO - 2020-02-27 04:41:59 --> Config Class Initialized
INFO - 2020-02-27 04:41:59 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:41:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:41:59 --> Utf8 Class Initialized
INFO - 2020-02-27 04:41:59 --> URI Class Initialized
INFO - 2020-02-27 04:41:59 --> Router Class Initialized
INFO - 2020-02-27 04:41:59 --> Output Class Initialized
INFO - 2020-02-27 04:41:59 --> Security Class Initialized
DEBUG - 2020-02-27 04:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:41:59 --> Input Class Initialized
INFO - 2020-02-27 04:41:59 --> Language Class Initialized
INFO - 2020-02-27 04:41:59 --> Loader Class Initialized
INFO - 2020-02-27 04:42:00 --> Helper loaded: url_helper
INFO - 2020-02-27 04:42:00 --> Helper loaded: string_helper
INFO - 2020-02-27 04:42:00 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:42:00 --> Controller Class Initialized
INFO - 2020-02-27 04:42:00 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:42:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:42:00 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:42:00 --> Helper loaded: form_helper
INFO - 2020-02-27 04:42:00 --> Form Validation Class Initialized
ERROR - 2020-02-27 04:42:00 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 04:42:00 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 04:42:00 --> Final output sent to browser
DEBUG - 2020-02-27 04:42:00 --> Total execution time: 0.7246
INFO - 2020-02-27 04:42:12 --> Config Class Initialized
INFO - 2020-02-27 04:42:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:12 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:12 --> URI Class Initialized
INFO - 2020-02-27 04:42:12 --> Router Class Initialized
INFO - 2020-02-27 04:42:12 --> Output Class Initialized
INFO - 2020-02-27 04:42:12 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:12 --> Input Class Initialized
INFO - 2020-02-27 04:42:12 --> Language Class Initialized
INFO - 2020-02-27 04:42:12 --> Loader Class Initialized
INFO - 2020-02-27 04:42:12 --> Helper loaded: url_helper
INFO - 2020-02-27 04:42:12 --> Helper loaded: string_helper
INFO - 2020-02-27 04:42:12 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:42:12 --> Controller Class Initialized
INFO - 2020-02-27 04:42:12 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:42:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:42:12 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:42:13 --> Helper loaded: form_helper
INFO - 2020-02-27 04:42:13 --> Form Validation Class Initialized
INFO - 2020-02-27 04:42:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-27 04:42:13 --> Config Class Initialized
INFO - 2020-02-27 04:42:13 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:13 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:13 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:13 --> URI Class Initialized
INFO - 2020-02-27 04:42:13 --> Router Class Initialized
INFO - 2020-02-27 04:42:13 --> Output Class Initialized
INFO - 2020-02-27 04:42:13 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:13 --> Input Class Initialized
INFO - 2020-02-27 04:42:13 --> Language Class Initialized
INFO - 2020-02-27 04:42:13 --> Loader Class Initialized
INFO - 2020-02-27 04:42:13 --> Helper loaded: url_helper
INFO - 2020-02-27 04:42:13 --> Helper loaded: string_helper
INFO - 2020-02-27 04:42:13 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:42:13 --> Controller Class Initialized
INFO - 2020-02-27 04:42:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 04:42:13 --> Pagination Class Initialized
INFO - 2020-02-27 04:42:13 --> Model "M_show" initialized
INFO - 2020-02-27 04:42:13 --> Helper loaded: form_helper
INFO - 2020-02-27 04:42:13 --> Form Validation Class Initialized
INFO - 2020-02-27 04:42:13 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 04:42:13 --> Final output sent to browser
DEBUG - 2020-02-27 04:42:13 --> Total execution time: 0.5963
INFO - 2020-02-27 04:42:13 --> Config Class Initialized
INFO - 2020-02-27 04:42:13 --> Config Class Initialized
INFO - 2020-02-27 04:42:13 --> Hooks Class Initialized
INFO - 2020-02-27 04:42:13 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:42:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:14 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:14 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:14 --> URI Class Initialized
INFO - 2020-02-27 04:42:14 --> URI Class Initialized
INFO - 2020-02-27 04:42:14 --> Router Class Initialized
INFO - 2020-02-27 04:42:14 --> Router Class Initialized
INFO - 2020-02-27 04:42:14 --> Output Class Initialized
INFO - 2020-02-27 04:42:14 --> Output Class Initialized
INFO - 2020-02-27 04:42:14 --> Security Class Initialized
INFO - 2020-02-27 04:42:14 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:14 --> Input Class Initialized
INFO - 2020-02-27 04:42:14 --> Input Class Initialized
INFO - 2020-02-27 04:42:14 --> Language Class Initialized
INFO - 2020-02-27 04:42:14 --> Language Class Initialized
ERROR - 2020-02-27 04:42:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 04:42:14 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:42:14 --> Config Class Initialized
INFO - 2020-02-27 04:42:14 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:14 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:14 --> URI Class Initialized
INFO - 2020-02-27 04:42:14 --> Router Class Initialized
INFO - 2020-02-27 04:42:14 --> Output Class Initialized
INFO - 2020-02-27 04:42:14 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:14 --> Input Class Initialized
INFO - 2020-02-27 04:42:14 --> Language Class Initialized
ERROR - 2020-02-27 04:42:14 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:42:44 --> Config Class Initialized
INFO - 2020-02-27 04:42:44 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:44 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:44 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:44 --> URI Class Initialized
INFO - 2020-02-27 04:42:44 --> Router Class Initialized
INFO - 2020-02-27 04:42:44 --> Output Class Initialized
INFO - 2020-02-27 04:42:44 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:44 --> Input Class Initialized
INFO - 2020-02-27 04:42:44 --> Language Class Initialized
INFO - 2020-02-27 04:42:44 --> Loader Class Initialized
INFO - 2020-02-27 04:42:44 --> Helper loaded: url_helper
INFO - 2020-02-27 04:42:44 --> Helper loaded: string_helper
INFO - 2020-02-27 04:42:44 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:42:45 --> Controller Class Initialized
INFO - 2020-02-27 04:42:45 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:42:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:42:45 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:42:45 --> Helper loaded: form_helper
INFO - 2020-02-27 04:42:45 --> Form Validation Class Initialized
INFO - 2020-02-27 04:42:45 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:42:45 --> Final output sent to browser
DEBUG - 2020-02-27 04:42:45 --> Total execution time: 1.1495
INFO - 2020-02-27 04:42:45 --> Config Class Initialized
INFO - 2020-02-27 04:42:45 --> Config Class Initialized
INFO - 2020-02-27 04:42:45 --> Config Class Initialized
INFO - 2020-02-27 04:42:45 --> Config Class Initialized
INFO - 2020-02-27 04:42:45 --> Hooks Class Initialized
INFO - 2020-02-27 04:42:45 --> Hooks Class Initialized
INFO - 2020-02-27 04:42:45 --> Hooks Class Initialized
INFO - 2020-02-27 04:42:45 --> Config Class Initialized
INFO - 2020-02-27 04:42:45 --> Hooks Class Initialized
INFO - 2020-02-27 04:42:45 --> Config Class Initialized
INFO - 2020-02-27 04:42:45 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:42:45 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:45 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:42:45 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:45 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:45 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:45 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:45 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:42:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:42:45 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:45 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:45 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:45 --> URI Class Initialized
INFO - 2020-02-27 04:42:45 --> URI Class Initialized
INFO - 2020-02-27 04:42:45 --> URI Class Initialized
INFO - 2020-02-27 04:42:45 --> URI Class Initialized
INFO - 2020-02-27 04:42:45 --> URI Class Initialized
INFO - 2020-02-27 04:42:45 --> Router Class Initialized
INFO - 2020-02-27 04:42:45 --> Router Class Initialized
INFO - 2020-02-27 04:42:45 --> Router Class Initialized
INFO - 2020-02-27 04:42:45 --> URI Class Initialized
INFO - 2020-02-27 04:42:45 --> Router Class Initialized
INFO - 2020-02-27 04:42:45 --> Output Class Initialized
INFO - 2020-02-27 04:42:45 --> Output Class Initialized
INFO - 2020-02-27 04:42:45 --> Output Class Initialized
INFO - 2020-02-27 04:42:45 --> Output Class Initialized
INFO - 2020-02-27 04:42:45 --> Router Class Initialized
INFO - 2020-02-27 04:42:45 --> Router Class Initialized
INFO - 2020-02-27 04:42:45 --> Output Class Initialized
INFO - 2020-02-27 04:42:45 --> Output Class Initialized
INFO - 2020-02-27 04:42:45 --> Security Class Initialized
INFO - 2020-02-27 04:42:45 --> Security Class Initialized
INFO - 2020-02-27 04:42:45 --> Security Class Initialized
INFO - 2020-02-27 04:42:45 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:45 --> Security Class Initialized
INFO - 2020-02-27 04:42:45 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:45 --> Input Class Initialized
INFO - 2020-02-27 04:42:45 --> Input Class Initialized
INFO - 2020-02-27 04:42:45 --> Input Class Initialized
INFO - 2020-02-27 04:42:45 --> Input Class Initialized
DEBUG - 2020-02-27 04:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:45 --> Input Class Initialized
INFO - 2020-02-27 04:42:45 --> Input Class Initialized
INFO - 2020-02-27 04:42:45 --> Language Class Initialized
INFO - 2020-02-27 04:42:45 --> Language Class Initialized
INFO - 2020-02-27 04:42:45 --> Language Class Initialized
INFO - 2020-02-27 04:42:45 --> Language Class Initialized
INFO - 2020-02-27 04:42:45 --> Language Class Initialized
INFO - 2020-02-27 04:42:45 --> Language Class Initialized
ERROR - 2020-02-27 04:42:45 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 04:42:45 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-27 04:42:45 --> Loader Class Initialized
INFO - 2020-02-27 04:42:45 --> Loader Class Initialized
INFO - 2020-02-27 04:42:45 --> Helper loaded: url_helper
INFO - 2020-02-27 04:42:45 --> Helper loaded: url_helper
ERROR - 2020-02-27 04:42:45 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 04:42:45 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 04:42:45 --> Config Class Initialized
INFO - 2020-02-27 04:42:45 --> Config Class Initialized
INFO - 2020-02-27 04:42:45 --> Hooks Class Initialized
INFO - 2020-02-27 04:42:45 --> Hooks Class Initialized
INFO - 2020-02-27 04:42:45 --> Helper loaded: string_helper
INFO - 2020-02-27 04:42:45 --> Helper loaded: string_helper
INFO - 2020-02-27 04:42:45 --> Config Class Initialized
INFO - 2020-02-27 04:42:45 --> Config Class Initialized
INFO - 2020-02-27 04:42:45 --> Hooks Class Initialized
INFO - 2020-02-27 04:42:45 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:42:45 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:45 --> Database Driver Class Initialized
INFO - 2020-02-27 04:42:45 --> Database Driver Class Initialized
INFO - 2020-02-27 04:42:45 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:45 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:42:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:42:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-27 04:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:42:45 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:45 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:42:45 --> URI Class Initialized
INFO - 2020-02-27 04:42:45 --> URI Class Initialized
INFO - 2020-02-27 04:42:45 --> Controller Class Initialized
INFO - 2020-02-27 04:42:45 --> URI Class Initialized
INFO - 2020-02-27 04:42:45 --> URI Class Initialized
INFO - 2020-02-27 04:42:45 --> Router Class Initialized
INFO - 2020-02-27 04:42:45 --> Router Class Initialized
INFO - 2020-02-27 04:42:45 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:42:45 --> Router Class Initialized
INFO - 2020-02-27 04:42:45 --> Output Class Initialized
INFO - 2020-02-27 04:42:45 --> Output Class Initialized
INFO - 2020-02-27 04:42:45 --> Router Class Initialized
INFO - 2020-02-27 04:42:46 --> Security Class Initialized
INFO - 2020-02-27 04:42:46 --> Security Class Initialized
INFO - 2020-02-27 04:42:46 --> Output Class Initialized
INFO - 2020-02-27 04:42:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:42:46 --> Output Class Initialized
DEBUG - 2020-02-27 04:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:46 --> Security Class Initialized
INFO - 2020-02-27 04:42:46 --> Security Class Initialized
INFO - 2020-02-27 04:42:46 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:42:46 --> Input Class Initialized
INFO - 2020-02-27 04:42:46 --> Input Class Initialized
DEBUG - 2020-02-27 04:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:46 --> Helper loaded: form_helper
INFO - 2020-02-27 04:42:46 --> Form Validation Class Initialized
INFO - 2020-02-27 04:42:46 --> Input Class Initialized
INFO - 2020-02-27 04:42:46 --> Input Class Initialized
INFO - 2020-02-27 04:42:46 --> Language Class Initialized
INFO - 2020-02-27 04:42:46 --> Language Class Initialized
INFO - 2020-02-27 04:42:46 --> Language Class Initialized
INFO - 2020-02-27 04:42:46 --> Language Class Initialized
ERROR - 2020-02-27 04:42:46 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-27 04:42:46 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 04:42:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 04:42:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-27 04:42:46 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-27 04:42:46 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:42:46 --> Config Class Initialized
INFO - 2020-02-27 04:42:46 --> Config Class Initialized
INFO - 2020-02-27 04:42:46 --> Hooks Class Initialized
INFO - 2020-02-27 04:42:46 --> Hooks Class Initialized
INFO - 2020-02-27 04:42:46 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:42:46 --> Config Class Initialized
INFO - 2020-02-27 04:42:46 --> Config Class Initialized
INFO - 2020-02-27 04:42:46 --> Hooks Class Initialized
INFO - 2020-02-27 04:42:46 --> Final output sent to browser
INFO - 2020-02-27 04:42:46 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:42:46 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:46 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:42:46 --> Total execution time: 1.0240
INFO - 2020-02-27 04:42:46 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:42:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:42:46 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:46 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:42:46 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:46 --> URI Class Initialized
INFO - 2020-02-27 04:42:46 --> URI Class Initialized
INFO - 2020-02-27 04:42:46 --> URI Class Initialized
INFO - 2020-02-27 04:42:46 --> Router Class Initialized
INFO - 2020-02-27 04:42:46 --> URI Class Initialized
INFO - 2020-02-27 04:42:46 --> Router Class Initialized
INFO - 2020-02-27 04:42:46 --> Controller Class Initialized
INFO - 2020-02-27 04:42:46 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:42:46 --> Output Class Initialized
INFO - 2020-02-27 04:42:46 --> Output Class Initialized
INFO - 2020-02-27 04:42:46 --> Router Class Initialized
INFO - 2020-02-27 04:42:46 --> Router Class Initialized
INFO - 2020-02-27 04:42:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:42:46 --> Output Class Initialized
INFO - 2020-02-27 04:42:46 --> Output Class Initialized
INFO - 2020-02-27 04:42:46 --> Security Class Initialized
INFO - 2020-02-27 04:42:46 --> Security Class Initialized
INFO - 2020-02-27 04:42:46 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 04:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:46 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:46 --> Security Class Initialized
INFO - 2020-02-27 04:42:46 --> Input Class Initialized
INFO - 2020-02-27 04:42:46 --> Input Class Initialized
DEBUG - 2020-02-27 04:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:46 --> Helper loaded: form_helper
INFO - 2020-02-27 04:42:46 --> Form Validation Class Initialized
INFO - 2020-02-27 04:42:46 --> Input Class Initialized
INFO - 2020-02-27 04:42:46 --> Input Class Initialized
INFO - 2020-02-27 04:42:46 --> Language Class Initialized
INFO - 2020-02-27 04:42:46 --> Language Class Initialized
INFO - 2020-02-27 04:42:46 --> Language Class Initialized
INFO - 2020-02-27 04:42:46 --> Language Class Initialized
ERROR - 2020-02-27 04:42:46 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-27 04:42:46 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-27 04:42:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 04:42:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-27 04:42:46 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 04:42:46 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 04:42:46 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:42:46 --> Config Class Initialized
INFO - 2020-02-27 04:42:46 --> Hooks Class Initialized
INFO - 2020-02-27 04:42:46 --> Final output sent to browser
DEBUG - 2020-02-27 04:42:46 --> Total execution time: 1.3234
DEBUG - 2020-02-27 04:42:46 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:46 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:46 --> URI Class Initialized
INFO - 2020-02-27 04:42:46 --> Router Class Initialized
INFO - 2020-02-27 04:42:46 --> Output Class Initialized
INFO - 2020-02-27 04:42:46 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:46 --> Input Class Initialized
INFO - 2020-02-27 04:42:46 --> Language Class Initialized
ERROR - 2020-02-27 04:42:47 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 04:42:47 --> Config Class Initialized
INFO - 2020-02-27 04:42:47 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:47 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:47 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:47 --> URI Class Initialized
INFO - 2020-02-27 04:42:47 --> Router Class Initialized
INFO - 2020-02-27 04:42:47 --> Output Class Initialized
INFO - 2020-02-27 04:42:47 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:47 --> Input Class Initialized
INFO - 2020-02-27 04:42:47 --> Language Class Initialized
ERROR - 2020-02-27 04:42:47 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 04:42:47 --> Config Class Initialized
INFO - 2020-02-27 04:42:47 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:47 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:47 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:47 --> URI Class Initialized
INFO - 2020-02-27 04:42:47 --> Router Class Initialized
INFO - 2020-02-27 04:42:47 --> Output Class Initialized
INFO - 2020-02-27 04:42:47 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:47 --> Input Class Initialized
INFO - 2020-02-27 04:42:47 --> Language Class Initialized
ERROR - 2020-02-27 04:42:47 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 04:42:47 --> Config Class Initialized
INFO - 2020-02-27 04:42:47 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:47 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:47 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:47 --> URI Class Initialized
INFO - 2020-02-27 04:42:47 --> Router Class Initialized
INFO - 2020-02-27 04:42:47 --> Output Class Initialized
INFO - 2020-02-27 04:42:47 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:47 --> Input Class Initialized
INFO - 2020-02-27 04:42:48 --> Language Class Initialized
ERROR - 2020-02-27 04:42:48 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:42:48 --> Config Class Initialized
INFO - 2020-02-27 04:42:48 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:48 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:48 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:48 --> URI Class Initialized
INFO - 2020-02-27 04:42:48 --> Router Class Initialized
INFO - 2020-02-27 04:42:48 --> Output Class Initialized
INFO - 2020-02-27 04:42:48 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:48 --> Input Class Initialized
INFO - 2020-02-27 04:42:48 --> Language Class Initialized
ERROR - 2020-02-27 04:42:48 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:42:48 --> Config Class Initialized
INFO - 2020-02-27 04:42:48 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:48 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:48 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:48 --> URI Class Initialized
INFO - 2020-02-27 04:42:48 --> Router Class Initialized
INFO - 2020-02-27 04:42:48 --> Output Class Initialized
INFO - 2020-02-27 04:42:48 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:48 --> Input Class Initialized
INFO - 2020-02-27 04:42:48 --> Language Class Initialized
ERROR - 2020-02-27 04:42:48 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 04:42:48 --> Config Class Initialized
INFO - 2020-02-27 04:42:48 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:48 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:48 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:48 --> URI Class Initialized
INFO - 2020-02-27 04:42:48 --> Router Class Initialized
INFO - 2020-02-27 04:42:48 --> Output Class Initialized
INFO - 2020-02-27 04:42:48 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:48 --> Input Class Initialized
INFO - 2020-02-27 04:42:49 --> Language Class Initialized
ERROR - 2020-02-27 04:42:49 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 04:42:49 --> Config Class Initialized
INFO - 2020-02-27 04:42:49 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:49 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:49 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:49 --> URI Class Initialized
INFO - 2020-02-27 04:42:49 --> Router Class Initialized
INFO - 2020-02-27 04:42:49 --> Output Class Initialized
INFO - 2020-02-27 04:42:49 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:49 --> Input Class Initialized
INFO - 2020-02-27 04:42:49 --> Language Class Initialized
ERROR - 2020-02-27 04:42:49 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 04:42:49 --> Config Class Initialized
INFO - 2020-02-27 04:42:49 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:42:49 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:42:49 --> Utf8 Class Initialized
INFO - 2020-02-27 04:42:49 --> URI Class Initialized
INFO - 2020-02-27 04:42:49 --> Router Class Initialized
INFO - 2020-02-27 04:42:49 --> Output Class Initialized
INFO - 2020-02-27 04:42:49 --> Security Class Initialized
DEBUG - 2020-02-27 04:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:42:49 --> Input Class Initialized
INFO - 2020-02-27 04:42:49 --> Language Class Initialized
ERROR - 2020-02-27 04:42:49 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 04:43:05 --> Config Class Initialized
INFO - 2020-02-27 04:43:05 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:43:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:43:05 --> Utf8 Class Initialized
INFO - 2020-02-27 04:43:05 --> URI Class Initialized
INFO - 2020-02-27 04:43:05 --> Router Class Initialized
INFO - 2020-02-27 04:43:05 --> Output Class Initialized
INFO - 2020-02-27 04:43:05 --> Security Class Initialized
DEBUG - 2020-02-27 04:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:43:05 --> Input Class Initialized
INFO - 2020-02-27 04:43:05 --> Language Class Initialized
INFO - 2020-02-27 04:43:05 --> Loader Class Initialized
INFO - 2020-02-27 04:43:05 --> Helper loaded: url_helper
INFO - 2020-02-27 04:43:05 --> Helper loaded: string_helper
INFO - 2020-02-27 04:43:05 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:43:05 --> Controller Class Initialized
INFO - 2020-02-27 04:43:05 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:43:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:43:05 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:43:05 --> Helper loaded: form_helper
INFO - 2020-02-27 04:43:05 --> Form Validation Class Initialized
ERROR - 2020-02-27 04:43:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 99
ERROR - 2020-02-27 10:43:06 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `bukti_bayar`, `id_pengunjung`) VALUES ('33', '', '1', '1', '20-02-27 10:43:06', '2020-02-28 10:43:06', NULL, 'PM182', NULL, 'default.jpg', NULL)
INFO - 2020-02-27 10:43:06 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-27 04:44:32 --> Config Class Initialized
INFO - 2020-02-27 04:44:33 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:44:33 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:33 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:33 --> URI Class Initialized
INFO - 2020-02-27 04:44:33 --> Router Class Initialized
INFO - 2020-02-27 04:44:33 --> Output Class Initialized
INFO - 2020-02-27 04:44:33 --> Security Class Initialized
DEBUG - 2020-02-27 04:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:33 --> Input Class Initialized
INFO - 2020-02-27 04:44:33 --> Language Class Initialized
INFO - 2020-02-27 04:44:33 --> Loader Class Initialized
INFO - 2020-02-27 04:44:33 --> Helper loaded: url_helper
INFO - 2020-02-27 04:44:33 --> Helper loaded: string_helper
INFO - 2020-02-27 04:44:33 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:44:33 --> Controller Class Initialized
INFO - 2020-02-27 04:44:33 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:44:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:44:33 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:44:33 --> Helper loaded: form_helper
INFO - 2020-02-27 04:44:33 --> Form Validation Class Initialized
INFO - 2020-02-27 04:44:33 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:44:33 --> Final output sent to browser
DEBUG - 2020-02-27 04:44:33 --> Total execution time: 0.8846
INFO - 2020-02-27 04:44:35 --> Config Class Initialized
INFO - 2020-02-27 04:44:35 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:44:35 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:35 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:35 --> URI Class Initialized
INFO - 2020-02-27 04:44:36 --> Router Class Initialized
INFO - 2020-02-27 04:44:36 --> Output Class Initialized
INFO - 2020-02-27 04:44:36 --> Security Class Initialized
DEBUG - 2020-02-27 04:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:36 --> Input Class Initialized
INFO - 2020-02-27 04:44:36 --> Language Class Initialized
INFO - 2020-02-27 04:44:36 --> Loader Class Initialized
INFO - 2020-02-27 04:44:36 --> Helper loaded: url_helper
INFO - 2020-02-27 04:44:36 --> Helper loaded: string_helper
INFO - 2020-02-27 04:44:36 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:44:36 --> Controller Class Initialized
INFO - 2020-02-27 04:44:36 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:44:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:44:36 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:44:36 --> Helper loaded: form_helper
INFO - 2020-02-27 04:44:36 --> Form Validation Class Initialized
INFO - 2020-02-27 04:44:36 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:44:36 --> Final output sent to browser
DEBUG - 2020-02-27 04:44:36 --> Total execution time: 1.0975
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:37 --> URI Class Initialized
INFO - 2020-02-27 04:44:37 --> URI Class Initialized
INFO - 2020-02-27 04:44:37 --> URI Class Initialized
INFO - 2020-02-27 04:44:37 --> URI Class Initialized
INFO - 2020-02-27 04:44:37 --> URI Class Initialized
INFO - 2020-02-27 04:44:37 --> URI Class Initialized
INFO - 2020-02-27 04:44:37 --> Router Class Initialized
INFO - 2020-02-27 04:44:37 --> Router Class Initialized
INFO - 2020-02-27 04:44:37 --> Router Class Initialized
INFO - 2020-02-27 04:44:37 --> Router Class Initialized
INFO - 2020-02-27 04:44:37 --> Router Class Initialized
INFO - 2020-02-27 04:44:37 --> Router Class Initialized
INFO - 2020-02-27 04:44:37 --> Output Class Initialized
INFO - 2020-02-27 04:44:37 --> Output Class Initialized
INFO - 2020-02-27 04:44:37 --> Output Class Initialized
INFO - 2020-02-27 04:44:37 --> Output Class Initialized
INFO - 2020-02-27 04:44:37 --> Output Class Initialized
INFO - 2020-02-27 04:44:37 --> Output Class Initialized
INFO - 2020-02-27 04:44:37 --> Security Class Initialized
INFO - 2020-02-27 04:44:37 --> Security Class Initialized
INFO - 2020-02-27 04:44:37 --> Security Class Initialized
INFO - 2020-02-27 04:44:37 --> Security Class Initialized
INFO - 2020-02-27 04:44:37 --> Security Class Initialized
INFO - 2020-02-27 04:44:37 --> Security Class Initialized
DEBUG - 2020-02-27 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:37 --> Input Class Initialized
INFO - 2020-02-27 04:44:37 --> Input Class Initialized
INFO - 2020-02-27 04:44:37 --> Input Class Initialized
INFO - 2020-02-27 04:44:37 --> Input Class Initialized
INFO - 2020-02-27 04:44:37 --> Input Class Initialized
INFO - 2020-02-27 04:44:37 --> Input Class Initialized
INFO - 2020-02-27 04:44:37 --> Language Class Initialized
INFO - 2020-02-27 04:44:37 --> Language Class Initialized
INFO - 2020-02-27 04:44:37 --> Language Class Initialized
INFO - 2020-02-27 04:44:37 --> Language Class Initialized
INFO - 2020-02-27 04:44:37 --> Language Class Initialized
INFO - 2020-02-27 04:44:37 --> Language Class Initialized
ERROR - 2020-02-27 04:44:37 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 04:44:37 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 04:44:37 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-27 04:44:37 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-27 04:44:37 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 04:44:37 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:37 --> URI Class Initialized
INFO - 2020-02-27 04:44:37 --> URI Class Initialized
INFO - 2020-02-27 04:44:37 --> URI Class Initialized
INFO - 2020-02-27 04:44:37 --> URI Class Initialized
INFO - 2020-02-27 04:44:37 --> URI Class Initialized
INFO - 2020-02-27 04:44:37 --> URI Class Initialized
INFO - 2020-02-27 04:44:37 --> Router Class Initialized
INFO - 2020-02-27 04:44:37 --> Router Class Initialized
INFO - 2020-02-27 04:44:37 --> Router Class Initialized
INFO - 2020-02-27 04:44:37 --> Router Class Initialized
INFO - 2020-02-27 04:44:37 --> Router Class Initialized
INFO - 2020-02-27 04:44:37 --> Router Class Initialized
INFO - 2020-02-27 04:44:37 --> Output Class Initialized
INFO - 2020-02-27 04:44:37 --> Output Class Initialized
INFO - 2020-02-27 04:44:37 --> Output Class Initialized
INFO - 2020-02-27 04:44:37 --> Output Class Initialized
INFO - 2020-02-27 04:44:37 --> Output Class Initialized
INFO - 2020-02-27 04:44:37 --> Output Class Initialized
INFO - 2020-02-27 04:44:37 --> Security Class Initialized
INFO - 2020-02-27 04:44:37 --> Security Class Initialized
INFO - 2020-02-27 04:44:37 --> Security Class Initialized
INFO - 2020-02-27 04:44:37 --> Security Class Initialized
INFO - 2020-02-27 04:44:37 --> Security Class Initialized
INFO - 2020-02-27 04:44:37 --> Security Class Initialized
DEBUG - 2020-02-27 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:37 --> Input Class Initialized
INFO - 2020-02-27 04:44:37 --> Input Class Initialized
INFO - 2020-02-27 04:44:37 --> Input Class Initialized
INFO - 2020-02-27 04:44:37 --> Input Class Initialized
INFO - 2020-02-27 04:44:37 --> Input Class Initialized
INFO - 2020-02-27 04:44:37 --> Input Class Initialized
INFO - 2020-02-27 04:44:37 --> Language Class Initialized
INFO - 2020-02-27 04:44:37 --> Language Class Initialized
INFO - 2020-02-27 04:44:37 --> Language Class Initialized
INFO - 2020-02-27 04:44:37 --> Language Class Initialized
INFO - 2020-02-27 04:44:37 --> Language Class Initialized
INFO - 2020-02-27 04:44:37 --> Language Class Initialized
ERROR - 2020-02-27 04:44:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-27 04:44:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:44:37 --> Loader Class Initialized
INFO - 2020-02-27 04:44:37 --> Loader Class Initialized
ERROR - 2020-02-27 04:44:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-27 04:44:37 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 04:44:37 --> Helper loaded: url_helper
INFO - 2020-02-27 04:44:37 --> Helper loaded: url_helper
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Config Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:37 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:37 --> Helper loaded: string_helper
INFO - 2020-02-27 04:44:37 --> Helper loaded: string_helper
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:44:37 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:37 --> Database Driver Class Initialized
INFO - 2020-02-27 04:44:37 --> Database Driver Class Initialized
INFO - 2020-02-27 04:44:37 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:38 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-27 04:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:44:38 --> URI Class Initialized
INFO - 2020-02-27 04:44:38 --> URI Class Initialized
INFO - 2020-02-27 04:44:38 --> Controller Class Initialized
INFO - 2020-02-27 04:44:38 --> Router Class Initialized
INFO - 2020-02-27 04:44:38 --> Router Class Initialized
INFO - 2020-02-27 04:44:38 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:44:38 --> Output Class Initialized
INFO - 2020-02-27 04:44:38 --> Output Class Initialized
INFO - 2020-02-27 04:44:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:44:38 --> Security Class Initialized
INFO - 2020-02-27 04:44:38 --> Security Class Initialized
INFO - 2020-02-27 04:44:38 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 04:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:38 --> Input Class Initialized
INFO - 2020-02-27 04:44:38 --> Input Class Initialized
INFO - 2020-02-27 04:44:38 --> Helper loaded: form_helper
INFO - 2020-02-27 04:44:38 --> Form Validation Class Initialized
INFO - 2020-02-27 04:44:38 --> Language Class Initialized
INFO - 2020-02-27 04:44:38 --> Language Class Initialized
ERROR - 2020-02-27 04:44:38 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 04:44:38 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 04:44:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 04:44:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 04:44:38 --> Config Class Initialized
INFO - 2020-02-27 04:44:38 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:38 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:44:38 --> Final output sent to browser
DEBUG - 2020-02-27 04:44:38 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:38 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:44:38 --> Total execution time: 0.7315
INFO - 2020-02-27 04:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:44:38 --> URI Class Initialized
INFO - 2020-02-27 04:44:38 --> Controller Class Initialized
INFO - 2020-02-27 04:44:38 --> Router Class Initialized
INFO - 2020-02-27 04:44:38 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:44:38 --> Output Class Initialized
INFO - 2020-02-27 04:44:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:44:38 --> Security Class Initialized
INFO - 2020-02-27 04:44:38 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 04:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:38 --> Input Class Initialized
INFO - 2020-02-27 04:44:38 --> Helper loaded: form_helper
INFO - 2020-02-27 04:44:38 --> Form Validation Class Initialized
INFO - 2020-02-27 04:44:38 --> Language Class Initialized
ERROR - 2020-02-27 04:44:38 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 04:44:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 04:44:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 04:44:38 --> Config Class Initialized
INFO - 2020-02-27 04:44:38 --> Hooks Class Initialized
INFO - 2020-02-27 04:44:38 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 04:44:38 --> Final output sent to browser
DEBUG - 2020-02-27 04:44:38 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:38 --> Utf8 Class Initialized
DEBUG - 2020-02-27 04:44:38 --> Total execution time: 1.0622
INFO - 2020-02-27 04:44:38 --> URI Class Initialized
INFO - 2020-02-27 04:44:38 --> Router Class Initialized
INFO - 2020-02-27 04:44:38 --> Output Class Initialized
INFO - 2020-02-27 04:44:38 --> Security Class Initialized
DEBUG - 2020-02-27 04:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:38 --> Input Class Initialized
INFO - 2020-02-27 04:44:38 --> Language Class Initialized
ERROR - 2020-02-27 04:44:38 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 04:44:38 --> Config Class Initialized
INFO - 2020-02-27 04:44:38 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:44:38 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:38 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:39 --> URI Class Initialized
INFO - 2020-02-27 04:44:39 --> Router Class Initialized
INFO - 2020-02-27 04:44:39 --> Output Class Initialized
INFO - 2020-02-27 04:44:39 --> Security Class Initialized
DEBUG - 2020-02-27 04:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:39 --> Input Class Initialized
INFO - 2020-02-27 04:44:39 --> Language Class Initialized
ERROR - 2020-02-27 04:44:39 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:44:39 --> Config Class Initialized
INFO - 2020-02-27 04:44:39 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:44:39 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:39 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:39 --> URI Class Initialized
INFO - 2020-02-27 04:44:39 --> Router Class Initialized
INFO - 2020-02-27 04:44:39 --> Output Class Initialized
INFO - 2020-02-27 04:44:39 --> Security Class Initialized
DEBUG - 2020-02-27 04:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:39 --> Input Class Initialized
INFO - 2020-02-27 04:44:39 --> Language Class Initialized
ERROR - 2020-02-27 04:44:39 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 04:44:39 --> Config Class Initialized
INFO - 2020-02-27 04:44:39 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:44:39 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:39 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:39 --> URI Class Initialized
INFO - 2020-02-27 04:44:39 --> Router Class Initialized
INFO - 2020-02-27 04:44:39 --> Output Class Initialized
INFO - 2020-02-27 04:44:39 --> Security Class Initialized
DEBUG - 2020-02-27 04:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:39 --> Input Class Initialized
INFO - 2020-02-27 04:44:39 --> Language Class Initialized
ERROR - 2020-02-27 04:44:39 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 04:44:39 --> Config Class Initialized
INFO - 2020-02-27 04:44:39 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:44:39 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:39 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:39 --> URI Class Initialized
INFO - 2020-02-27 04:44:40 --> Router Class Initialized
INFO - 2020-02-27 04:44:40 --> Output Class Initialized
INFO - 2020-02-27 04:44:40 --> Security Class Initialized
DEBUG - 2020-02-27 04:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:40 --> Input Class Initialized
INFO - 2020-02-27 04:44:40 --> Language Class Initialized
ERROR - 2020-02-27 04:44:40 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 04:44:40 --> Config Class Initialized
INFO - 2020-02-27 04:44:40 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:44:40 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:40 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:40 --> URI Class Initialized
INFO - 2020-02-27 04:44:40 --> Router Class Initialized
INFO - 2020-02-27 04:44:40 --> Output Class Initialized
INFO - 2020-02-27 04:44:40 --> Security Class Initialized
DEBUG - 2020-02-27 04:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:40 --> Input Class Initialized
INFO - 2020-02-27 04:44:40 --> Language Class Initialized
ERROR - 2020-02-27 04:44:40 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 04:44:40 --> Config Class Initialized
INFO - 2020-02-27 04:44:40 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:44:40 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:40 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:40 --> URI Class Initialized
INFO - 2020-02-27 04:44:40 --> Router Class Initialized
INFO - 2020-02-27 04:44:40 --> Output Class Initialized
INFO - 2020-02-27 04:44:40 --> Security Class Initialized
DEBUG - 2020-02-27 04:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:40 --> Input Class Initialized
INFO - 2020-02-27 04:44:40 --> Language Class Initialized
ERROR - 2020-02-27 04:44:40 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 04:44:55 --> Config Class Initialized
INFO - 2020-02-27 04:44:55 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:44:55 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:44:55 --> Utf8 Class Initialized
INFO - 2020-02-27 04:44:55 --> URI Class Initialized
INFO - 2020-02-27 04:44:55 --> Router Class Initialized
INFO - 2020-02-27 04:44:55 --> Output Class Initialized
INFO - 2020-02-27 04:44:55 --> Security Class Initialized
DEBUG - 2020-02-27 04:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:44:55 --> Input Class Initialized
INFO - 2020-02-27 04:44:55 --> Language Class Initialized
INFO - 2020-02-27 04:44:55 --> Loader Class Initialized
INFO - 2020-02-27 04:44:55 --> Helper loaded: url_helper
INFO - 2020-02-27 04:44:55 --> Helper loaded: string_helper
INFO - 2020-02-27 04:44:55 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:44:55 --> Controller Class Initialized
INFO - 2020-02-27 04:44:55 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:44:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:44:55 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:44:55 --> Helper loaded: form_helper
INFO - 2020-02-27 04:44:55 --> Form Validation Class Initialized
INFO - 2020-02-27 10:44:56 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 10:44:56 --> Final output sent to browser
DEBUG - 2020-02-27 10:44:56 --> Total execution time: 0.8373
INFO - 2020-02-27 04:45:00 --> Config Class Initialized
INFO - 2020-02-27 04:45:00 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:45:00 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:45:00 --> Utf8 Class Initialized
INFO - 2020-02-27 04:45:00 --> URI Class Initialized
INFO - 2020-02-27 04:45:00 --> Router Class Initialized
INFO - 2020-02-27 04:45:00 --> Output Class Initialized
INFO - 2020-02-27 04:45:00 --> Security Class Initialized
DEBUG - 2020-02-27 04:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:45:00 --> Input Class Initialized
INFO - 2020-02-27 04:45:00 --> Language Class Initialized
INFO - 2020-02-27 04:45:00 --> Loader Class Initialized
INFO - 2020-02-27 04:45:00 --> Helper loaded: url_helper
INFO - 2020-02-27 04:45:00 --> Helper loaded: string_helper
INFO - 2020-02-27 04:45:00 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:45:00 --> Controller Class Initialized
INFO - 2020-02-27 04:45:00 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:45:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:45:00 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:45:00 --> Helper loaded: form_helper
INFO - 2020-02-27 04:45:00 --> Form Validation Class Initialized
ERROR - 2020-02-27 04:45:00 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 04:45:00 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 04:45:00 --> Final output sent to browser
DEBUG - 2020-02-27 04:45:00 --> Total execution time: 0.6700
INFO - 2020-02-27 04:45:25 --> Config Class Initialized
INFO - 2020-02-27 04:45:25 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:45:25 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:45:25 --> Utf8 Class Initialized
INFO - 2020-02-27 04:45:25 --> URI Class Initialized
INFO - 2020-02-27 04:45:25 --> Router Class Initialized
INFO - 2020-02-27 04:45:26 --> Output Class Initialized
INFO - 2020-02-27 04:45:26 --> Security Class Initialized
DEBUG - 2020-02-27 04:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:45:26 --> Input Class Initialized
INFO - 2020-02-27 04:45:26 --> Language Class Initialized
INFO - 2020-02-27 04:45:26 --> Loader Class Initialized
INFO - 2020-02-27 04:45:26 --> Helper loaded: url_helper
INFO - 2020-02-27 04:45:26 --> Helper loaded: string_helper
INFO - 2020-02-27 04:45:26 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:45:26 --> Controller Class Initialized
INFO - 2020-02-27 04:45:26 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:45:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:45:26 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:45:26 --> Helper loaded: form_helper
INFO - 2020-02-27 04:45:26 --> Form Validation Class Initialized
INFO - 2020-02-27 04:45:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-27 04:45:26 --> Config Class Initialized
INFO - 2020-02-27 04:45:26 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:45:26 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:45:26 --> Utf8 Class Initialized
INFO - 2020-02-27 04:45:26 --> URI Class Initialized
INFO - 2020-02-27 04:45:26 --> Router Class Initialized
INFO - 2020-02-27 04:45:26 --> Output Class Initialized
INFO - 2020-02-27 04:45:26 --> Security Class Initialized
DEBUG - 2020-02-27 04:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:45:26 --> Input Class Initialized
INFO - 2020-02-27 04:45:26 --> Language Class Initialized
INFO - 2020-02-27 04:45:26 --> Loader Class Initialized
INFO - 2020-02-27 04:45:26 --> Helper loaded: url_helper
INFO - 2020-02-27 04:45:26 --> Helper loaded: string_helper
INFO - 2020-02-27 04:45:26 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:45:26 --> Controller Class Initialized
INFO - 2020-02-27 04:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 04:45:27 --> Pagination Class Initialized
INFO - 2020-02-27 04:45:27 --> Model "M_show" initialized
INFO - 2020-02-27 04:45:27 --> Helper loaded: form_helper
INFO - 2020-02-27 04:45:27 --> Form Validation Class Initialized
INFO - 2020-02-27 04:45:27 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 04:45:27 --> Final output sent to browser
DEBUG - 2020-02-27 04:45:27 --> Total execution time: 0.6503
INFO - 2020-02-27 04:45:27 --> Config Class Initialized
INFO - 2020-02-27 04:45:27 --> Config Class Initialized
INFO - 2020-02-27 04:45:27 --> Hooks Class Initialized
INFO - 2020-02-27 04:45:27 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:45:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:45:27 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:45:27 --> Utf8 Class Initialized
INFO - 2020-02-27 04:45:27 --> Utf8 Class Initialized
INFO - 2020-02-27 04:45:27 --> URI Class Initialized
INFO - 2020-02-27 04:45:27 --> URI Class Initialized
INFO - 2020-02-27 04:45:27 --> Router Class Initialized
INFO - 2020-02-27 04:45:27 --> Router Class Initialized
INFO - 2020-02-27 04:45:27 --> Output Class Initialized
INFO - 2020-02-27 04:45:27 --> Output Class Initialized
INFO - 2020-02-27 04:45:27 --> Security Class Initialized
INFO - 2020-02-27 04:45:27 --> Security Class Initialized
DEBUG - 2020-02-27 04:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:45:27 --> Input Class Initialized
INFO - 2020-02-27 04:45:27 --> Input Class Initialized
INFO - 2020-02-27 04:45:27 --> Language Class Initialized
INFO - 2020-02-27 04:45:27 --> Language Class Initialized
ERROR - 2020-02-27 04:45:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 04:45:27 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 04:47:04 --> Config Class Initialized
INFO - 2020-02-27 04:47:04 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:47:04 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:47:04 --> Utf8 Class Initialized
INFO - 2020-02-27 04:47:04 --> URI Class Initialized
INFO - 2020-02-27 04:47:04 --> Router Class Initialized
INFO - 2020-02-27 04:47:04 --> Output Class Initialized
INFO - 2020-02-27 04:47:04 --> Security Class Initialized
DEBUG - 2020-02-27 04:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:47:04 --> Input Class Initialized
INFO - 2020-02-27 04:47:04 --> Language Class Initialized
INFO - 2020-02-27 04:47:04 --> Loader Class Initialized
INFO - 2020-02-27 04:47:04 --> Helper loaded: url_helper
INFO - 2020-02-27 04:47:04 --> Helper loaded: string_helper
INFO - 2020-02-27 04:47:05 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:47:05 --> Controller Class Initialized
INFO - 2020-02-27 04:47:05 --> Model "M_tiket" initialized
INFO - 2020-02-27 04:47:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 04:47:05 --> Model "M_pesan" initialized
INFO - 2020-02-27 04:47:05 --> Helper loaded: form_helper
INFO - 2020-02-27 04:47:05 --> Form Validation Class Initialized
INFO - 2020-02-27 04:47:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-27 04:47:05 --> Config Class Initialized
INFO - 2020-02-27 04:47:05 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:47:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:47:05 --> Utf8 Class Initialized
INFO - 2020-02-27 04:47:05 --> URI Class Initialized
INFO - 2020-02-27 04:47:05 --> Router Class Initialized
INFO - 2020-02-27 04:47:05 --> Output Class Initialized
INFO - 2020-02-27 04:47:05 --> Security Class Initialized
DEBUG - 2020-02-27 04:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:47:05 --> Input Class Initialized
INFO - 2020-02-27 04:47:05 --> Language Class Initialized
INFO - 2020-02-27 04:47:05 --> Loader Class Initialized
INFO - 2020-02-27 04:47:05 --> Helper loaded: url_helper
INFO - 2020-02-27 04:47:05 --> Helper loaded: string_helper
INFO - 2020-02-27 04:47:05 --> Database Driver Class Initialized
DEBUG - 2020-02-27 04:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 04:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 04:47:05 --> Controller Class Initialized
INFO - 2020-02-27 04:47:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 04:47:05 --> Pagination Class Initialized
INFO - 2020-02-27 04:47:05 --> Model "M_show" initialized
INFO - 2020-02-27 04:47:05 --> Helper loaded: form_helper
INFO - 2020-02-27 04:47:05 --> Form Validation Class Initialized
INFO - 2020-02-27 04:47:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 04:47:05 --> Final output sent to browser
DEBUG - 2020-02-27 04:47:05 --> Total execution time: 0.6393
INFO - 2020-02-27 04:47:06 --> Config Class Initialized
INFO - 2020-02-27 04:47:06 --> Config Class Initialized
INFO - 2020-02-27 04:47:06 --> Hooks Class Initialized
INFO - 2020-02-27 04:47:06 --> Hooks Class Initialized
DEBUG - 2020-02-27 04:47:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 04:47:06 --> UTF-8 Support Enabled
INFO - 2020-02-27 04:47:06 --> Utf8 Class Initialized
INFO - 2020-02-27 04:47:06 --> Utf8 Class Initialized
INFO - 2020-02-27 04:47:06 --> URI Class Initialized
INFO - 2020-02-27 04:47:06 --> URI Class Initialized
INFO - 2020-02-27 04:47:06 --> Router Class Initialized
INFO - 2020-02-27 04:47:06 --> Router Class Initialized
INFO - 2020-02-27 04:47:06 --> Output Class Initialized
INFO - 2020-02-27 04:47:06 --> Output Class Initialized
INFO - 2020-02-27 04:47:06 --> Security Class Initialized
INFO - 2020-02-27 04:47:06 --> Security Class Initialized
DEBUG - 2020-02-27 04:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 04:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 04:47:06 --> Input Class Initialized
INFO - 2020-02-27 04:47:06 --> Input Class Initialized
INFO - 2020-02-27 04:47:06 --> Language Class Initialized
INFO - 2020-02-27 04:47:06 --> Language Class Initialized
ERROR - 2020-02-27 04:47:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 04:47:06 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 05:01:05 --> Config Class Initialized
INFO - 2020-02-27 05:01:05 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:05 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:05 --> URI Class Initialized
INFO - 2020-02-27 05:01:05 --> Router Class Initialized
INFO - 2020-02-27 05:01:05 --> Output Class Initialized
INFO - 2020-02-27 05:01:05 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:05 --> Input Class Initialized
INFO - 2020-02-27 05:01:05 --> Language Class Initialized
INFO - 2020-02-27 05:01:06 --> Loader Class Initialized
INFO - 2020-02-27 05:01:06 --> Helper loaded: url_helper
INFO - 2020-02-27 05:01:06 --> Helper loaded: string_helper
INFO - 2020-02-27 05:01:06 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:01:06 --> Controller Class Initialized
INFO - 2020-02-27 05:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 05:01:06 --> Pagination Class Initialized
INFO - 2020-02-27 05:01:06 --> Model "M_show" initialized
INFO - 2020-02-27 05:01:06 --> Helper loaded: form_helper
INFO - 2020-02-27 05:01:06 --> Form Validation Class Initialized
INFO - 2020-02-27 05:01:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 05:01:06 --> Final output sent to browser
DEBUG - 2020-02-27 05:01:06 --> Total execution time: 0.6695
INFO - 2020-02-27 05:01:06 --> Config Class Initialized
INFO - 2020-02-27 05:01:06 --> Config Class Initialized
INFO - 2020-02-27 05:01:06 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:06 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:01:06 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:06 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:06 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:06 --> URI Class Initialized
INFO - 2020-02-27 05:01:06 --> URI Class Initialized
INFO - 2020-02-27 05:01:06 --> Router Class Initialized
INFO - 2020-02-27 05:01:06 --> Router Class Initialized
INFO - 2020-02-27 05:01:06 --> Output Class Initialized
INFO - 2020-02-27 05:01:06 --> Output Class Initialized
INFO - 2020-02-27 05:01:06 --> Security Class Initialized
INFO - 2020-02-27 05:01:06 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:06 --> Input Class Initialized
INFO - 2020-02-27 05:01:06 --> Input Class Initialized
INFO - 2020-02-27 05:01:07 --> Language Class Initialized
INFO - 2020-02-27 05:01:07 --> Language Class Initialized
ERROR - 2020-02-27 05:01:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 05:01:07 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 05:01:07 --> Config Class Initialized
INFO - 2020-02-27 05:01:07 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:07 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:07 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:07 --> URI Class Initialized
INFO - 2020-02-27 05:01:07 --> Router Class Initialized
INFO - 2020-02-27 05:01:07 --> Output Class Initialized
INFO - 2020-02-27 05:01:07 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:07 --> Input Class Initialized
INFO - 2020-02-27 05:01:07 --> Language Class Initialized
ERROR - 2020-02-27 05:01:07 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 05:01:10 --> Config Class Initialized
INFO - 2020-02-27 05:01:10 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:10 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:10 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:10 --> URI Class Initialized
INFO - 2020-02-27 05:01:10 --> Router Class Initialized
INFO - 2020-02-27 05:01:10 --> Output Class Initialized
INFO - 2020-02-27 05:01:10 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:11 --> Input Class Initialized
INFO - 2020-02-27 05:01:11 --> Language Class Initialized
INFO - 2020-02-27 05:01:11 --> Loader Class Initialized
INFO - 2020-02-27 05:01:11 --> Helper loaded: url_helper
INFO - 2020-02-27 05:01:11 --> Helper loaded: string_helper
INFO - 2020-02-27 05:01:11 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:01:11 --> Controller Class Initialized
INFO - 2020-02-27 05:01:11 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:01:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:01:11 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:01:11 --> Helper loaded: form_helper
INFO - 2020-02-27 05:01:11 --> Form Validation Class Initialized
INFO - 2020-02-27 05:01:11 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 05:01:11 --> Final output sent to browser
DEBUG - 2020-02-27 05:01:11 --> Total execution time: 1.1206
INFO - 2020-02-27 05:01:11 --> Config Class Initialized
INFO - 2020-02-27 05:01:11 --> Config Class Initialized
INFO - 2020-02-27 05:01:11 --> Config Class Initialized
INFO - 2020-02-27 05:01:11 --> Config Class Initialized
INFO - 2020-02-27 05:01:11 --> Config Class Initialized
INFO - 2020-02-27 05:01:11 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:11 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:11 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:11 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:11 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:11 --> Config Class Initialized
INFO - 2020-02-27 05:01:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:01:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:11 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:11 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:11 --> Utf8 Class Initialized
DEBUG - 2020-02-27 05:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:01:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:11 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:11 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:11 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:11 --> URI Class Initialized
INFO - 2020-02-27 05:01:11 --> URI Class Initialized
INFO - 2020-02-27 05:01:11 --> URI Class Initialized
INFO - 2020-02-27 05:01:11 --> URI Class Initialized
INFO - 2020-02-27 05:01:11 --> URI Class Initialized
INFO - 2020-02-27 05:01:11 --> URI Class Initialized
INFO - 2020-02-27 05:01:11 --> Router Class Initialized
INFO - 2020-02-27 05:01:11 --> Router Class Initialized
INFO - 2020-02-27 05:01:11 --> Router Class Initialized
INFO - 2020-02-27 05:01:11 --> Output Class Initialized
INFO - 2020-02-27 05:01:11 --> Output Class Initialized
INFO - 2020-02-27 05:01:11 --> Output Class Initialized
INFO - 2020-02-27 05:01:11 --> Router Class Initialized
INFO - 2020-02-27 05:01:11 --> Router Class Initialized
INFO - 2020-02-27 05:01:11 --> Router Class Initialized
INFO - 2020-02-27 05:01:11 --> Security Class Initialized
INFO - 2020-02-27 05:01:11 --> Output Class Initialized
INFO - 2020-02-27 05:01:11 --> Output Class Initialized
INFO - 2020-02-27 05:01:11 --> Security Class Initialized
INFO - 2020-02-27 05:01:11 --> Security Class Initialized
INFO - 2020-02-27 05:01:11 --> Output Class Initialized
DEBUG - 2020-02-27 05:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:11 --> Security Class Initialized
INFO - 2020-02-27 05:01:11 --> Security Class Initialized
INFO - 2020-02-27 05:01:11 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:11 --> Input Class Initialized
INFO - 2020-02-27 05:01:11 --> Input Class Initialized
INFO - 2020-02-27 05:01:11 --> Input Class Initialized
DEBUG - 2020-02-27 05:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:11 --> Input Class Initialized
INFO - 2020-02-27 05:01:11 --> Input Class Initialized
INFO - 2020-02-27 05:01:11 --> Input Class Initialized
INFO - 2020-02-27 05:01:11 --> Language Class Initialized
INFO - 2020-02-27 05:01:11 --> Language Class Initialized
INFO - 2020-02-27 05:01:11 --> Language Class Initialized
INFO - 2020-02-27 05:01:11 --> Language Class Initialized
INFO - 2020-02-27 05:01:11 --> Language Class Initialized
ERROR - 2020-02-27 05:01:11 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 05:01:11 --> Language Class Initialized
ERROR - 2020-02-27 05:01:11 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 05:01:11 --> Loader Class Initialized
ERROR - 2020-02-27 05:01:12 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-27 05:01:12 --> Helper loaded: url_helper
ERROR - 2020-02-27 05:01:12 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 05:01:12 --> Loader Class Initialized
INFO - 2020-02-27 05:01:12 --> Config Class Initialized
INFO - 2020-02-27 05:01:12 --> Config Class Initialized
INFO - 2020-02-27 05:01:12 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:12 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:12 --> Helper loaded: url_helper
INFO - 2020-02-27 05:01:12 --> Helper loaded: string_helper
INFO - 2020-02-27 05:01:12 --> Config Class Initialized
INFO - 2020-02-27 05:01:12 --> Config Class Initialized
INFO - 2020-02-27 05:01:12 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:12 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:12 --> Helper loaded: string_helper
DEBUG - 2020-02-27 05:01:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:01:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:12 --> Database Driver Class Initialized
INFO - 2020-02-27 05:01:12 --> Utf8 Class Initialized
DEBUG - 2020-02-27 05:01:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:01:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:12 --> Utf8 Class Initialized
DEBUG - 2020-02-27 05:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:01:12 --> Database Driver Class Initialized
INFO - 2020-02-27 05:01:12 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:01:12 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:12 --> URI Class Initialized
INFO - 2020-02-27 05:01:12 --> URI Class Initialized
DEBUG - 2020-02-27 05:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:01:12 --> Controller Class Initialized
INFO - 2020-02-27 05:01:12 --> URI Class Initialized
INFO - 2020-02-27 05:01:12 --> Router Class Initialized
INFO - 2020-02-27 05:01:12 --> URI Class Initialized
INFO - 2020-02-27 05:01:12 --> Router Class Initialized
INFO - 2020-02-27 05:01:12 --> Router Class Initialized
INFO - 2020-02-27 05:01:12 --> Router Class Initialized
INFO - 2020-02-27 05:01:12 --> Output Class Initialized
INFO - 2020-02-27 05:01:12 --> Output Class Initialized
INFO - 2020-02-27 05:01:12 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:01:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:01:12 --> Security Class Initialized
INFO - 2020-02-27 05:01:12 --> Security Class Initialized
INFO - 2020-02-27 05:01:12 --> Output Class Initialized
INFO - 2020-02-27 05:01:12 --> Output Class Initialized
INFO - 2020-02-27 05:01:12 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 05:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:12 --> Security Class Initialized
INFO - 2020-02-27 05:01:12 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:12 --> Input Class Initialized
DEBUG - 2020-02-27 05:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:12 --> Input Class Initialized
INFO - 2020-02-27 05:01:12 --> Helper loaded: form_helper
INFO - 2020-02-27 05:01:12 --> Input Class Initialized
INFO - 2020-02-27 05:01:12 --> Form Validation Class Initialized
INFO - 2020-02-27 05:01:12 --> Input Class Initialized
INFO - 2020-02-27 05:01:12 --> Language Class Initialized
INFO - 2020-02-27 05:01:12 --> Language Class Initialized
INFO - 2020-02-27 05:01:12 --> Language Class Initialized
ERROR - 2020-02-27 05:01:12 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-27 05:01:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 05:01:12 --> Language Class Initialized
ERROR - 2020-02-27 05:01:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 05:01:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-27 05:01:12 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 05:01:12 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 05:01:12 --> Config Class Initialized
INFO - 2020-02-27 05:01:12 --> Config Class Initialized
INFO - 2020-02-27 05:01:12 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:12 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:12 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-27 05:01:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:12 --> Config Class Initialized
INFO - 2020-02-27 05:01:12 --> Config Class Initialized
INFO - 2020-02-27 05:01:12 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:12 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:12 --> Final output sent to browser
INFO - 2020-02-27 05:01:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:12 --> Utf8 Class Initialized
DEBUG - 2020-02-27 05:01:12 --> Total execution time: 0.9012
INFO - 2020-02-27 05:01:12 --> URI Class Initialized
DEBUG - 2020-02-27 05:01:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:01:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:12 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:12 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:12 --> URI Class Initialized
INFO - 2020-02-27 05:01:12 --> Router Class Initialized
INFO - 2020-02-27 05:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:01:12 --> Controller Class Initialized
INFO - 2020-02-27 05:01:12 --> URI Class Initialized
INFO - 2020-02-27 05:01:12 --> Router Class Initialized
INFO - 2020-02-27 05:01:12 --> Output Class Initialized
INFO - 2020-02-27 05:01:12 --> URI Class Initialized
INFO - 2020-02-27 05:01:12 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:01:12 --> Router Class Initialized
INFO - 2020-02-27 05:01:12 --> Router Class Initialized
INFO - 2020-02-27 05:01:12 --> Output Class Initialized
INFO - 2020-02-27 05:01:12 --> Security Class Initialized
INFO - 2020-02-27 05:01:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:01:12 --> Output Class Initialized
DEBUG - 2020-02-27 05:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:12 --> Output Class Initialized
INFO - 2020-02-27 05:01:12 --> Security Class Initialized
INFO - 2020-02-27 05:01:12 --> Input Class Initialized
INFO - 2020-02-27 05:01:12 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:01:12 --> Security Class Initialized
INFO - 2020-02-27 05:01:12 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:12 --> Input Class Initialized
INFO - 2020-02-27 05:01:12 --> Language Class Initialized
DEBUG - 2020-02-27 05:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:12 --> Helper loaded: form_helper
INFO - 2020-02-27 05:01:12 --> Input Class Initialized
INFO - 2020-02-27 05:01:12 --> Input Class Initialized
INFO - 2020-02-27 05:01:12 --> Form Validation Class Initialized
ERROR - 2020-02-27 05:01:12 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 05:01:12 --> Language Class Initialized
INFO - 2020-02-27 05:01:12 --> Language Class Initialized
INFO - 2020-02-27 05:01:12 --> Language Class Initialized
ERROR - 2020-02-27 05:01:12 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-27 05:01:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 05:01:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-27 05:01:12 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 05:01:12 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 05:01:12 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 05:01:12 --> Config Class Initialized
INFO - 2020-02-27 05:01:12 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:12 --> Final output sent to browser
DEBUG - 2020-02-27 05:01:12 --> Total execution time: 1.2460
DEBUG - 2020-02-27 05:01:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:12 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:12 --> URI Class Initialized
INFO - 2020-02-27 05:01:12 --> Router Class Initialized
INFO - 2020-02-27 05:01:13 --> Output Class Initialized
INFO - 2020-02-27 05:01:13 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:13 --> Input Class Initialized
INFO - 2020-02-27 05:01:13 --> Language Class Initialized
ERROR - 2020-02-27 05:01:13 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 05:01:13 --> Config Class Initialized
INFO - 2020-02-27 05:01:13 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:13 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:13 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:13 --> URI Class Initialized
INFO - 2020-02-27 05:01:13 --> Router Class Initialized
INFO - 2020-02-27 05:01:13 --> Output Class Initialized
INFO - 2020-02-27 05:01:13 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:13 --> Input Class Initialized
INFO - 2020-02-27 05:01:13 --> Language Class Initialized
ERROR - 2020-02-27 05:01:13 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 05:01:13 --> Config Class Initialized
INFO - 2020-02-27 05:01:13 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:13 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:13 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:13 --> URI Class Initialized
INFO - 2020-02-27 05:01:13 --> Router Class Initialized
INFO - 2020-02-27 05:01:13 --> Output Class Initialized
INFO - 2020-02-27 05:01:13 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:13 --> Input Class Initialized
INFO - 2020-02-27 05:01:13 --> Language Class Initialized
ERROR - 2020-02-27 05:01:13 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 05:01:13 --> Config Class Initialized
INFO - 2020-02-27 05:01:13 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:13 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:13 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:13 --> URI Class Initialized
INFO - 2020-02-27 05:01:14 --> Router Class Initialized
INFO - 2020-02-27 05:01:14 --> Output Class Initialized
INFO - 2020-02-27 05:01:14 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:14 --> Input Class Initialized
INFO - 2020-02-27 05:01:14 --> Language Class Initialized
ERROR - 2020-02-27 05:01:14 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 05:01:14 --> Config Class Initialized
INFO - 2020-02-27 05:01:14 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:14 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:14 --> URI Class Initialized
INFO - 2020-02-27 05:01:14 --> Router Class Initialized
INFO - 2020-02-27 05:01:14 --> Output Class Initialized
INFO - 2020-02-27 05:01:14 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:14 --> Input Class Initialized
INFO - 2020-02-27 05:01:14 --> Language Class Initialized
ERROR - 2020-02-27 05:01:14 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 05:01:14 --> Config Class Initialized
INFO - 2020-02-27 05:01:14 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:14 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:14 --> URI Class Initialized
INFO - 2020-02-27 05:01:14 --> Router Class Initialized
INFO - 2020-02-27 05:01:14 --> Output Class Initialized
INFO - 2020-02-27 05:01:14 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:14 --> Input Class Initialized
INFO - 2020-02-27 05:01:14 --> Language Class Initialized
ERROR - 2020-02-27 05:01:14 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 05:01:14 --> Config Class Initialized
INFO - 2020-02-27 05:01:14 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:15 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:15 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:15 --> URI Class Initialized
INFO - 2020-02-27 05:01:15 --> Router Class Initialized
INFO - 2020-02-27 05:01:15 --> Output Class Initialized
INFO - 2020-02-27 05:01:15 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:15 --> Input Class Initialized
INFO - 2020-02-27 05:01:15 --> Language Class Initialized
ERROR - 2020-02-27 05:01:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 05:01:15 --> Config Class Initialized
INFO - 2020-02-27 05:01:15 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:15 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:15 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:15 --> URI Class Initialized
INFO - 2020-02-27 05:01:15 --> Router Class Initialized
INFO - 2020-02-27 05:01:15 --> Output Class Initialized
INFO - 2020-02-27 05:01:15 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:15 --> Input Class Initialized
INFO - 2020-02-27 05:01:15 --> Language Class Initialized
ERROR - 2020-02-27 05:01:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 05:01:15 --> Config Class Initialized
INFO - 2020-02-27 05:01:15 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:15 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:15 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:15 --> URI Class Initialized
INFO - 2020-02-27 05:01:15 --> Router Class Initialized
INFO - 2020-02-27 05:01:15 --> Output Class Initialized
INFO - 2020-02-27 05:01:15 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:15 --> Input Class Initialized
INFO - 2020-02-27 05:01:15 --> Language Class Initialized
ERROR - 2020-02-27 05:01:15 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 05:01:29 --> Config Class Initialized
INFO - 2020-02-27 05:01:29 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:29 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:29 --> URI Class Initialized
INFO - 2020-02-27 05:01:29 --> Router Class Initialized
INFO - 2020-02-27 05:01:29 --> Output Class Initialized
INFO - 2020-02-27 05:01:29 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:29 --> Input Class Initialized
INFO - 2020-02-27 05:01:29 --> Language Class Initialized
INFO - 2020-02-27 05:01:29 --> Loader Class Initialized
INFO - 2020-02-27 05:01:29 --> Helper loaded: url_helper
INFO - 2020-02-27 05:01:29 --> Helper loaded: string_helper
INFO - 2020-02-27 05:01:29 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:01:29 --> Controller Class Initialized
INFO - 2020-02-27 05:01:29 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:01:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:01:30 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:01:30 --> Helper loaded: form_helper
INFO - 2020-02-27 05:01:30 --> Form Validation Class Initialized
INFO - 2020-02-27 11:01:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 11:01:30 --> Final output sent to browser
DEBUG - 2020-02-27 11:01:30 --> Total execution time: 0.9753
INFO - 2020-02-27 05:01:36 --> Config Class Initialized
INFO - 2020-02-27 05:01:36 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:36 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:36 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:36 --> URI Class Initialized
INFO - 2020-02-27 05:01:36 --> Router Class Initialized
INFO - 2020-02-27 05:01:36 --> Output Class Initialized
INFO - 2020-02-27 05:01:37 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:37 --> Input Class Initialized
INFO - 2020-02-27 05:01:37 --> Language Class Initialized
INFO - 2020-02-27 05:01:37 --> Loader Class Initialized
INFO - 2020-02-27 05:01:37 --> Helper loaded: url_helper
INFO - 2020-02-27 05:01:37 --> Helper loaded: string_helper
INFO - 2020-02-27 05:01:37 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:01:37 --> Controller Class Initialized
INFO - 2020-02-27 05:01:37 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:01:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:01:37 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:01:37 --> Helper loaded: form_helper
INFO - 2020-02-27 05:01:37 --> Form Validation Class Initialized
ERROR - 2020-02-27 05:01:37 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 05:01:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 05:01:37 --> Final output sent to browser
DEBUG - 2020-02-27 05:01:37 --> Total execution time: 1.3289
INFO - 2020-02-27 05:01:51 --> Config Class Initialized
INFO - 2020-02-27 05:01:51 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:52 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:52 --> URI Class Initialized
INFO - 2020-02-27 05:01:52 --> Router Class Initialized
INFO - 2020-02-27 05:01:52 --> Output Class Initialized
INFO - 2020-02-27 05:01:52 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:52 --> Input Class Initialized
INFO - 2020-02-27 05:01:52 --> Language Class Initialized
INFO - 2020-02-27 05:01:52 --> Loader Class Initialized
INFO - 2020-02-27 05:01:52 --> Helper loaded: url_helper
INFO - 2020-02-27 05:01:52 --> Helper loaded: string_helper
INFO - 2020-02-27 05:01:52 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:01:52 --> Controller Class Initialized
INFO - 2020-02-27 05:01:52 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:01:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:01:52 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:01:52 --> Helper loaded: form_helper
INFO - 2020-02-27 05:01:52 --> Form Validation Class Initialized
ERROR - 2020-02-27 05:01:52 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
ERROR - 2020-02-27 05:01:52 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 110
INFO - 2020-02-27 05:01:52 --> Upload Class Initialized
ERROR - 2020-02-27 05:01:52 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 112
INFO - 2020-02-27 05:01:52 --> Config Class Initialized
INFO - 2020-02-27 05:01:52 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:52 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:52 --> URI Class Initialized
INFO - 2020-02-27 05:01:52 --> Router Class Initialized
INFO - 2020-02-27 05:01:53 --> Output Class Initialized
INFO - 2020-02-27 05:01:53 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:53 --> Input Class Initialized
INFO - 2020-02-27 05:01:53 --> Language Class Initialized
INFO - 2020-02-27 05:01:53 --> Loader Class Initialized
INFO - 2020-02-27 05:01:53 --> Helper loaded: url_helper
INFO - 2020-02-27 05:01:53 --> Helper loaded: string_helper
INFO - 2020-02-27 05:01:53 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:01:53 --> Controller Class Initialized
INFO - 2020-02-27 05:01:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 05:01:53 --> Pagination Class Initialized
INFO - 2020-02-27 05:01:53 --> Model "M_show" initialized
INFO - 2020-02-27 05:01:53 --> Helper loaded: form_helper
INFO - 2020-02-27 05:01:53 --> Form Validation Class Initialized
INFO - 2020-02-27 05:01:53 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 05:01:53 --> Final output sent to browser
DEBUG - 2020-02-27 05:01:53 --> Total execution time: 0.6651
INFO - 2020-02-27 05:01:53 --> Config Class Initialized
INFO - 2020-02-27 05:01:53 --> Config Class Initialized
INFO - 2020-02-27 05:01:53 --> Hooks Class Initialized
INFO - 2020-02-27 05:01:53 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:01:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:54 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:54 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:54 --> URI Class Initialized
INFO - 2020-02-27 05:01:54 --> URI Class Initialized
INFO - 2020-02-27 05:01:54 --> Router Class Initialized
INFO - 2020-02-27 05:01:54 --> Router Class Initialized
INFO - 2020-02-27 05:01:54 --> Output Class Initialized
INFO - 2020-02-27 05:01:54 --> Output Class Initialized
INFO - 2020-02-27 05:01:54 --> Security Class Initialized
INFO - 2020-02-27 05:01:54 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:54 --> Input Class Initialized
INFO - 2020-02-27 05:01:54 --> Input Class Initialized
INFO - 2020-02-27 05:01:54 --> Language Class Initialized
INFO - 2020-02-27 05:01:54 --> Language Class Initialized
ERROR - 2020-02-27 05:01:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 05:01:54 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 05:01:54 --> Config Class Initialized
INFO - 2020-02-27 05:01:54 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:01:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:01:54 --> Utf8 Class Initialized
INFO - 2020-02-27 05:01:54 --> URI Class Initialized
INFO - 2020-02-27 05:01:54 --> Router Class Initialized
INFO - 2020-02-27 05:01:54 --> Output Class Initialized
INFO - 2020-02-27 05:01:54 --> Security Class Initialized
DEBUG - 2020-02-27 05:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:01:54 --> Input Class Initialized
INFO - 2020-02-27 05:01:54 --> Language Class Initialized
ERROR - 2020-02-27 05:01:54 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 05:21:06 --> Config Class Initialized
INFO - 2020-02-27 05:21:06 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:07 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:07 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:07 --> URI Class Initialized
INFO - 2020-02-27 05:21:07 --> Router Class Initialized
INFO - 2020-02-27 05:21:07 --> Output Class Initialized
INFO - 2020-02-27 05:21:07 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:07 --> Input Class Initialized
INFO - 2020-02-27 05:21:07 --> Language Class Initialized
INFO - 2020-02-27 05:21:07 --> Loader Class Initialized
INFO - 2020-02-27 05:21:07 --> Helper loaded: url_helper
INFO - 2020-02-27 05:21:07 --> Helper loaded: string_helper
INFO - 2020-02-27 05:21:07 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:21:07 --> Controller Class Initialized
INFO - 2020-02-27 05:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 05:21:07 --> Pagination Class Initialized
INFO - 2020-02-27 05:21:07 --> Model "M_show" initialized
INFO - 2020-02-27 05:21:07 --> Helper loaded: form_helper
INFO - 2020-02-27 05:21:07 --> Form Validation Class Initialized
INFO - 2020-02-27 05:21:08 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 05:21:08 --> Final output sent to browser
DEBUG - 2020-02-27 05:21:08 --> Total execution time: 1.2445
INFO - 2020-02-27 05:21:08 --> Config Class Initialized
INFO - 2020-02-27 05:21:08 --> Config Class Initialized
INFO - 2020-02-27 05:21:08 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:08 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:21:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:08 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:08 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:08 --> URI Class Initialized
INFO - 2020-02-27 05:21:08 --> URI Class Initialized
INFO - 2020-02-27 05:21:08 --> Router Class Initialized
INFO - 2020-02-27 05:21:08 --> Router Class Initialized
INFO - 2020-02-27 05:21:08 --> Output Class Initialized
INFO - 2020-02-27 05:21:08 --> Output Class Initialized
INFO - 2020-02-27 05:21:08 --> Security Class Initialized
INFO - 2020-02-27 05:21:08 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:08 --> Input Class Initialized
INFO - 2020-02-27 05:21:08 --> Input Class Initialized
INFO - 2020-02-27 05:21:08 --> Language Class Initialized
INFO - 2020-02-27 05:21:08 --> Language Class Initialized
ERROR - 2020-02-27 05:21:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 05:21:08 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 05:21:24 --> Config Class Initialized
INFO - 2020-02-27 05:21:24 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:24 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:24 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:24 --> URI Class Initialized
INFO - 2020-02-27 05:21:24 --> Router Class Initialized
INFO - 2020-02-27 05:21:24 --> Output Class Initialized
INFO - 2020-02-27 05:21:24 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:24 --> Input Class Initialized
INFO - 2020-02-27 05:21:24 --> Language Class Initialized
INFO - 2020-02-27 05:21:24 --> Loader Class Initialized
INFO - 2020-02-27 05:21:24 --> Helper loaded: url_helper
INFO - 2020-02-27 05:21:24 --> Helper loaded: string_helper
INFO - 2020-02-27 05:21:24 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:21:24 --> Controller Class Initialized
INFO - 2020-02-27 05:21:24 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:21:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:21:24 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:21:24 --> Helper loaded: form_helper
INFO - 2020-02-27 05:21:24 --> Form Validation Class Initialized
INFO - 2020-02-27 05:21:24 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 05:21:24 --> Final output sent to browser
DEBUG - 2020-02-27 05:21:24 --> Total execution time: 0.7350
INFO - 2020-02-27 05:21:24 --> Config Class Initialized
INFO - 2020-02-27 05:21:24 --> Config Class Initialized
INFO - 2020-02-27 05:21:24 --> Config Class Initialized
INFO - 2020-02-27 05:21:25 --> Config Class Initialized
INFO - 2020-02-27 05:21:25 --> Config Class Initialized
INFO - 2020-02-27 05:21:25 --> Config Class Initialized
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> Router Class Initialized
INFO - 2020-02-27 05:21:25 --> Router Class Initialized
INFO - 2020-02-27 05:21:25 --> Router Class Initialized
INFO - 2020-02-27 05:21:25 --> Router Class Initialized
INFO - 2020-02-27 05:21:25 --> Router Class Initialized
INFO - 2020-02-27 05:21:25 --> Router Class Initialized
INFO - 2020-02-27 05:21:25 --> Output Class Initialized
INFO - 2020-02-27 05:21:25 --> Output Class Initialized
INFO - 2020-02-27 05:21:25 --> Output Class Initialized
INFO - 2020-02-27 05:21:25 --> Output Class Initialized
INFO - 2020-02-27 05:21:25 --> Output Class Initialized
INFO - 2020-02-27 05:21:25 --> Output Class Initialized
INFO - 2020-02-27 05:21:25 --> Security Class Initialized
INFO - 2020-02-27 05:21:25 --> Security Class Initialized
INFO - 2020-02-27 05:21:25 --> Security Class Initialized
INFO - 2020-02-27 05:21:25 --> Security Class Initialized
INFO - 2020-02-27 05:21:25 --> Security Class Initialized
INFO - 2020-02-27 05:21:25 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:25 --> Input Class Initialized
INFO - 2020-02-27 05:21:25 --> Input Class Initialized
INFO - 2020-02-27 05:21:25 --> Input Class Initialized
INFO - 2020-02-27 05:21:25 --> Input Class Initialized
INFO - 2020-02-27 05:21:25 --> Input Class Initialized
INFO - 2020-02-27 05:21:25 --> Input Class Initialized
INFO - 2020-02-27 05:21:25 --> Language Class Initialized
INFO - 2020-02-27 05:21:25 --> Language Class Initialized
INFO - 2020-02-27 05:21:25 --> Language Class Initialized
INFO - 2020-02-27 05:21:25 --> Language Class Initialized
INFO - 2020-02-27 05:21:25 --> Language Class Initialized
INFO - 2020-02-27 05:21:25 --> Language Class Initialized
ERROR - 2020-02-27 05:21:25 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-27 05:21:25 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 05:21:25 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 05:21:25 --> Loader Class Initialized
ERROR - 2020-02-27 05:21:25 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 05:21:25 --> Loader Class Initialized
INFO - 2020-02-27 05:21:25 --> Helper loaded: url_helper
INFO - 2020-02-27 05:21:25 --> Helper loaded: url_helper
INFO - 2020-02-27 05:21:25 --> Config Class Initialized
INFO - 2020-02-27 05:21:25 --> Config Class Initialized
INFO - 2020-02-27 05:21:25 --> Config Class Initialized
INFO - 2020-02-27 05:21:25 --> Config Class Initialized
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:25 --> Helper loaded: string_helper
INFO - 2020-02-27 05:21:25 --> Helper loaded: string_helper
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:25 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:25 --> Database Driver Class Initialized
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
DEBUG - 2020-02-27 05:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-27 05:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> Controller Class Initialized
INFO - 2020-02-27 05:21:25 --> Router Class Initialized
INFO - 2020-02-27 05:21:25 --> Router Class Initialized
INFO - 2020-02-27 05:21:25 --> Router Class Initialized
INFO - 2020-02-27 05:21:25 --> Router Class Initialized
INFO - 2020-02-27 05:21:25 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:21:25 --> Output Class Initialized
INFO - 2020-02-27 05:21:25 --> Output Class Initialized
INFO - 2020-02-27 05:21:25 --> Output Class Initialized
INFO - 2020-02-27 05:21:25 --> Output Class Initialized
INFO - 2020-02-27 05:21:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:21:25 --> Security Class Initialized
INFO - 2020-02-27 05:21:25 --> Security Class Initialized
INFO - 2020-02-27 05:21:25 --> Security Class Initialized
INFO - 2020-02-27 05:21:25 --> Security Class Initialized
INFO - 2020-02-27 05:21:25 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:25 --> Input Class Initialized
INFO - 2020-02-27 05:21:25 --> Input Class Initialized
INFO - 2020-02-27 05:21:25 --> Input Class Initialized
INFO - 2020-02-27 05:21:25 --> Input Class Initialized
INFO - 2020-02-27 05:21:25 --> Helper loaded: form_helper
INFO - 2020-02-27 05:21:25 --> Form Validation Class Initialized
INFO - 2020-02-27 05:21:25 --> Language Class Initialized
INFO - 2020-02-27 05:21:25 --> Language Class Initialized
INFO - 2020-02-27 05:21:25 --> Language Class Initialized
INFO - 2020-02-27 05:21:25 --> Language Class Initialized
ERROR - 2020-02-27 05:21:25 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-27 05:21:25 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 05:21:25 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 05:21:25 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-27 05:21:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 05:21:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 05:21:25 --> Config Class Initialized
INFO - 2020-02-27 05:21:25 --> Config Class Initialized
INFO - 2020-02-27 05:21:25 --> Config Class Initialized
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:25 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 05:21:25 --> Config Class Initialized
INFO - 2020-02-27 05:21:25 --> Final output sent to browser
INFO - 2020-02-27 05:21:25 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
DEBUG - 2020-02-27 05:21:25 --> Total execution time: 0.9357
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
DEBUG - 2020-02-27 05:21:25 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:25 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:21:25 --> Controller Class Initialized
INFO - 2020-02-27 05:21:25 --> URI Class Initialized
INFO - 2020-02-27 05:21:25 --> Router Class Initialized
INFO - 2020-02-27 05:21:25 --> Router Class Initialized
INFO - 2020-02-27 05:21:25 --> Router Class Initialized
INFO - 2020-02-27 05:21:26 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:21:26 --> Output Class Initialized
INFO - 2020-02-27 05:21:26 --> Output Class Initialized
INFO - 2020-02-27 05:21:26 --> Router Class Initialized
INFO - 2020-02-27 05:21:26 --> Output Class Initialized
INFO - 2020-02-27 05:21:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:21:26 --> Security Class Initialized
INFO - 2020-02-27 05:21:26 --> Security Class Initialized
INFO - 2020-02-27 05:21:26 --> Output Class Initialized
INFO - 2020-02-27 05:21:26 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:26 --> Security Class Initialized
INFO - 2020-02-27 05:21:26 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:21:26 --> Input Class Initialized
INFO - 2020-02-27 05:21:26 --> Input Class Initialized
INFO - 2020-02-27 05:21:26 --> Input Class Initialized
DEBUG - 2020-02-27 05:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:26 --> Helper loaded: form_helper
INFO - 2020-02-27 05:21:26 --> Form Validation Class Initialized
INFO - 2020-02-27 05:21:26 --> Input Class Initialized
INFO - 2020-02-27 05:21:26 --> Language Class Initialized
INFO - 2020-02-27 05:21:26 --> Language Class Initialized
INFO - 2020-02-27 05:21:26 --> Language Class Initialized
INFO - 2020-02-27 05:21:26 --> Language Class Initialized
ERROR - 2020-02-27 05:21:26 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 05:21:26 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 05:21:26 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-27 05:21:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 05:21:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-27 05:21:26 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 05:21:26 --> Config Class Initialized
INFO - 2020-02-27 05:21:26 --> Hooks Class Initialized
INFO - 2020-02-27 05:21:26 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 05:21:26 --> Final output sent to browser
DEBUG - 2020-02-27 05:21:26 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:26 --> Utf8 Class Initialized
DEBUG - 2020-02-27 05:21:26 --> Total execution time: 1.3116
INFO - 2020-02-27 05:21:26 --> URI Class Initialized
INFO - 2020-02-27 05:21:26 --> Router Class Initialized
INFO - 2020-02-27 05:21:26 --> Output Class Initialized
INFO - 2020-02-27 05:21:26 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:26 --> Input Class Initialized
INFO - 2020-02-27 05:21:26 --> Language Class Initialized
ERROR - 2020-02-27 05:21:26 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 05:21:26 --> Config Class Initialized
INFO - 2020-02-27 05:21:26 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:26 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:26 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:26 --> URI Class Initialized
INFO - 2020-02-27 05:21:26 --> Router Class Initialized
INFO - 2020-02-27 05:21:26 --> Output Class Initialized
INFO - 2020-02-27 05:21:26 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:26 --> Input Class Initialized
INFO - 2020-02-27 05:21:26 --> Language Class Initialized
ERROR - 2020-02-27 05:21:26 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 05:21:26 --> Config Class Initialized
INFO - 2020-02-27 05:21:27 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:27 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:27 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:27 --> URI Class Initialized
INFO - 2020-02-27 05:21:27 --> Router Class Initialized
INFO - 2020-02-27 05:21:27 --> Output Class Initialized
INFO - 2020-02-27 05:21:27 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:27 --> Input Class Initialized
INFO - 2020-02-27 05:21:27 --> Language Class Initialized
ERROR - 2020-02-27 05:21:27 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 05:21:27 --> Config Class Initialized
INFO - 2020-02-27 05:21:27 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:27 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:27 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:27 --> URI Class Initialized
INFO - 2020-02-27 05:21:27 --> Router Class Initialized
INFO - 2020-02-27 05:21:27 --> Output Class Initialized
INFO - 2020-02-27 05:21:27 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:27 --> Input Class Initialized
INFO - 2020-02-27 05:21:27 --> Language Class Initialized
ERROR - 2020-02-27 05:21:27 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 05:21:27 --> Config Class Initialized
INFO - 2020-02-27 05:21:27 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:27 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:27 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:27 --> URI Class Initialized
INFO - 2020-02-27 05:21:27 --> Router Class Initialized
INFO - 2020-02-27 05:21:27 --> Output Class Initialized
INFO - 2020-02-27 05:21:28 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:28 --> Input Class Initialized
INFO - 2020-02-27 05:21:28 --> Language Class Initialized
ERROR - 2020-02-27 05:21:28 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 05:21:28 --> Config Class Initialized
INFO - 2020-02-27 05:21:28 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:28 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:28 --> URI Class Initialized
INFO - 2020-02-27 05:21:28 --> Router Class Initialized
INFO - 2020-02-27 05:21:28 --> Output Class Initialized
INFO - 2020-02-27 05:21:28 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:28 --> Input Class Initialized
INFO - 2020-02-27 05:21:28 --> Language Class Initialized
ERROR - 2020-02-27 05:21:28 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 05:21:28 --> Config Class Initialized
INFO - 2020-02-27 05:21:28 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:28 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:28 --> URI Class Initialized
INFO - 2020-02-27 05:21:28 --> Router Class Initialized
INFO - 2020-02-27 05:21:28 --> Output Class Initialized
INFO - 2020-02-27 05:21:28 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:28 --> Input Class Initialized
INFO - 2020-02-27 05:21:28 --> Language Class Initialized
ERROR - 2020-02-27 05:21:28 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 05:21:28 --> Config Class Initialized
INFO - 2020-02-27 05:21:28 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:29 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:29 --> URI Class Initialized
INFO - 2020-02-27 05:21:29 --> Router Class Initialized
INFO - 2020-02-27 05:21:29 --> Output Class Initialized
INFO - 2020-02-27 05:21:29 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:29 --> Input Class Initialized
INFO - 2020-02-27 05:21:29 --> Language Class Initialized
ERROR - 2020-02-27 05:21:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 05:21:29 --> Config Class Initialized
INFO - 2020-02-27 05:21:29 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:29 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:29 --> URI Class Initialized
INFO - 2020-02-27 05:21:29 --> Router Class Initialized
INFO - 2020-02-27 05:21:29 --> Output Class Initialized
INFO - 2020-02-27 05:21:29 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:29 --> Input Class Initialized
INFO - 2020-02-27 05:21:29 --> Language Class Initialized
ERROR - 2020-02-27 05:21:29 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 05:21:46 --> Config Class Initialized
INFO - 2020-02-27 05:21:46 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:21:46 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:21:46 --> Utf8 Class Initialized
INFO - 2020-02-27 05:21:46 --> URI Class Initialized
INFO - 2020-02-27 05:21:46 --> Router Class Initialized
INFO - 2020-02-27 05:21:46 --> Output Class Initialized
INFO - 2020-02-27 05:21:46 --> Security Class Initialized
DEBUG - 2020-02-27 05:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:21:46 --> Input Class Initialized
INFO - 2020-02-27 05:21:46 --> Language Class Initialized
INFO - 2020-02-27 05:21:46 --> Loader Class Initialized
INFO - 2020-02-27 05:21:46 --> Helper loaded: url_helper
INFO - 2020-02-27 05:21:46 --> Helper loaded: string_helper
INFO - 2020-02-27 05:21:46 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:21:46 --> Controller Class Initialized
INFO - 2020-02-27 05:21:46 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:21:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:21:46 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:21:46 --> Helper loaded: form_helper
INFO - 2020-02-27 05:21:46 --> Form Validation Class Initialized
INFO - 2020-02-27 11:21:47 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 11:21:47 --> Final output sent to browser
DEBUG - 2020-02-27 11:21:47 --> Total execution time: 1.0596
INFO - 2020-02-27 05:22:01 --> Config Class Initialized
INFO - 2020-02-27 05:22:08 --> Config Class Initialized
INFO - 2020-02-27 05:22:08 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:22:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:22:08 --> Utf8 Class Initialized
INFO - 2020-02-27 05:22:08 --> URI Class Initialized
INFO - 2020-02-27 05:22:08 --> Router Class Initialized
INFO - 2020-02-27 05:22:08 --> Output Class Initialized
INFO - 2020-02-27 05:22:08 --> Security Class Initialized
DEBUG - 2020-02-27 05:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:22:08 --> Input Class Initialized
INFO - 2020-02-27 05:22:08 --> Language Class Initialized
INFO - 2020-02-27 05:22:08 --> Loader Class Initialized
INFO - 2020-02-27 05:22:08 --> Helper loaded: url_helper
INFO - 2020-02-27 05:22:08 --> Helper loaded: string_helper
INFO - 2020-02-27 05:22:08 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:22:09 --> Controller Class Initialized
INFO - 2020-02-27 05:22:09 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:22:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:22:09 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:22:09 --> Helper loaded: form_helper
INFO - 2020-02-27 05:22:09 --> Form Validation Class Initialized
INFO - 2020-02-27 11:22:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 11:22:09 --> Final output sent to browser
DEBUG - 2020-02-27 11:22:09 --> Total execution time: 1.0182
INFO - 2020-02-27 05:23:07 --> Config Class Initialized
INFO - 2020-02-27 05:23:07 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:23:07 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:23:07 --> Utf8 Class Initialized
INFO - 2020-02-27 05:23:07 --> URI Class Initialized
INFO - 2020-02-27 05:23:07 --> Router Class Initialized
INFO - 2020-02-27 05:23:07 --> Output Class Initialized
INFO - 2020-02-27 05:23:07 --> Security Class Initialized
DEBUG - 2020-02-27 05:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:23:07 --> Input Class Initialized
INFO - 2020-02-27 05:23:07 --> Language Class Initialized
INFO - 2020-02-27 05:23:07 --> Loader Class Initialized
INFO - 2020-02-27 05:23:07 --> Helper loaded: url_helper
INFO - 2020-02-27 05:23:07 --> Helper loaded: string_helper
INFO - 2020-02-27 05:23:07 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:23:07 --> Controller Class Initialized
INFO - 2020-02-27 05:23:07 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:23:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:23:07 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:23:07 --> Helper loaded: form_helper
INFO - 2020-02-27 05:23:07 --> Form Validation Class Initialized
ERROR - 2020-02-27 05:23:08 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 05:23:08 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 05:23:08 --> Final output sent to browser
DEBUG - 2020-02-27 05:23:08 --> Total execution time: 0.8976
INFO - 2020-02-27 05:23:21 --> Config Class Initialized
INFO - 2020-02-27 05:23:21 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:23:21 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:23:22 --> Utf8 Class Initialized
INFO - 2020-02-27 05:23:22 --> URI Class Initialized
INFO - 2020-02-27 05:23:22 --> Router Class Initialized
INFO - 2020-02-27 05:23:22 --> Output Class Initialized
INFO - 2020-02-27 05:23:22 --> Security Class Initialized
DEBUG - 2020-02-27 05:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:23:22 --> Input Class Initialized
INFO - 2020-02-27 05:23:22 --> Language Class Initialized
INFO - 2020-02-27 05:23:22 --> Loader Class Initialized
INFO - 2020-02-27 05:23:22 --> Helper loaded: url_helper
INFO - 2020-02-27 05:23:22 --> Helper loaded: string_helper
INFO - 2020-02-27 05:23:22 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:23:22 --> Controller Class Initialized
INFO - 2020-02-27 05:23:22 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:23:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:23:22 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:23:22 --> Helper loaded: form_helper
INFO - 2020-02-27 05:23:22 --> Form Validation Class Initialized
ERROR - 2020-02-27 05:23:22 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
ERROR - 2020-02-27 05:23:22 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 110
ERROR - 2020-02-27 05:23:22 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 112
INFO - 2020-02-27 05:23:22 --> Config Class Initialized
INFO - 2020-02-27 05:23:22 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:23:22 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:23:22 --> Utf8 Class Initialized
INFO - 2020-02-27 05:23:23 --> URI Class Initialized
INFO - 2020-02-27 05:23:23 --> Router Class Initialized
INFO - 2020-02-27 05:23:23 --> Output Class Initialized
INFO - 2020-02-27 05:23:23 --> Security Class Initialized
DEBUG - 2020-02-27 05:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:23:23 --> Input Class Initialized
INFO - 2020-02-27 05:23:23 --> Language Class Initialized
INFO - 2020-02-27 05:23:23 --> Loader Class Initialized
INFO - 2020-02-27 05:23:23 --> Helper loaded: url_helper
INFO - 2020-02-27 05:23:23 --> Helper loaded: string_helper
INFO - 2020-02-27 05:23:23 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:23:23 --> Controller Class Initialized
INFO - 2020-02-27 05:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 05:23:23 --> Pagination Class Initialized
INFO - 2020-02-27 05:23:23 --> Model "M_show" initialized
INFO - 2020-02-27 05:23:23 --> Helper loaded: form_helper
INFO - 2020-02-27 05:23:23 --> Form Validation Class Initialized
INFO - 2020-02-27 05:23:23 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 05:23:23 --> Final output sent to browser
DEBUG - 2020-02-27 05:23:23 --> Total execution time: 0.7021
INFO - 2020-02-27 05:23:23 --> Config Class Initialized
INFO - 2020-02-27 05:23:23 --> Config Class Initialized
INFO - 2020-02-27 05:23:23 --> Hooks Class Initialized
INFO - 2020-02-27 05:23:23 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:23:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:23:23 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:23:23 --> Utf8 Class Initialized
INFO - 2020-02-27 05:23:23 --> Utf8 Class Initialized
INFO - 2020-02-27 05:23:24 --> URI Class Initialized
INFO - 2020-02-27 05:23:24 --> URI Class Initialized
INFO - 2020-02-27 05:23:24 --> Router Class Initialized
INFO - 2020-02-27 05:23:24 --> Router Class Initialized
INFO - 2020-02-27 05:23:24 --> Output Class Initialized
INFO - 2020-02-27 05:23:24 --> Output Class Initialized
INFO - 2020-02-27 05:23:24 --> Security Class Initialized
INFO - 2020-02-27 05:23:24 --> Security Class Initialized
DEBUG - 2020-02-27 05:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:23:24 --> Input Class Initialized
INFO - 2020-02-27 05:23:24 --> Input Class Initialized
INFO - 2020-02-27 05:23:24 --> Language Class Initialized
INFO - 2020-02-27 05:23:24 --> Language Class Initialized
ERROR - 2020-02-27 05:23:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 05:23:24 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 05:23:24 --> Config Class Initialized
INFO - 2020-02-27 05:23:24 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:23:24 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:23:24 --> Utf8 Class Initialized
INFO - 2020-02-27 05:23:24 --> URI Class Initialized
INFO - 2020-02-27 05:23:24 --> Router Class Initialized
INFO - 2020-02-27 05:23:24 --> Output Class Initialized
INFO - 2020-02-27 05:23:24 --> Security Class Initialized
DEBUG - 2020-02-27 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:23:24 --> Input Class Initialized
INFO - 2020-02-27 05:23:24 --> Language Class Initialized
ERROR - 2020-02-27 05:23:24 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 05:58:58 --> Config Class Initialized
INFO - 2020-02-27 05:58:58 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:58:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:58:59 --> Utf8 Class Initialized
INFO - 2020-02-27 05:58:59 --> URI Class Initialized
INFO - 2020-02-27 05:58:59 --> Router Class Initialized
INFO - 2020-02-27 05:58:59 --> Output Class Initialized
INFO - 2020-02-27 05:58:59 --> Security Class Initialized
DEBUG - 2020-02-27 05:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:58:59 --> Input Class Initialized
INFO - 2020-02-27 05:58:59 --> Language Class Initialized
INFO - 2020-02-27 05:58:59 --> Loader Class Initialized
INFO - 2020-02-27 05:58:59 --> Helper loaded: url_helper
INFO - 2020-02-27 05:58:59 --> Helper loaded: string_helper
INFO - 2020-02-27 05:59:00 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:59:00 --> Controller Class Initialized
INFO - 2020-02-27 05:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 05:59:00 --> Pagination Class Initialized
INFO - 2020-02-27 05:59:00 --> Model "M_show" initialized
INFO - 2020-02-27 05:59:00 --> Helper loaded: form_helper
INFO - 2020-02-27 05:59:00 --> Form Validation Class Initialized
INFO - 2020-02-27 05:59:01 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 05:59:01 --> Final output sent to browser
DEBUG - 2020-02-27 05:59:01 --> Total execution time: 3.0382
INFO - 2020-02-27 05:59:02 --> Config Class Initialized
INFO - 2020-02-27 05:59:02 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:02 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:02 --> Config Class Initialized
INFO - 2020-02-27 05:59:02 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:02 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:02 --> URI Class Initialized
DEBUG - 2020-02-27 05:59:02 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:02 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:02 --> Router Class Initialized
INFO - 2020-02-27 05:59:02 --> URI Class Initialized
INFO - 2020-02-27 05:59:02 --> Output Class Initialized
INFO - 2020-02-27 05:59:02 --> Router Class Initialized
INFO - 2020-02-27 05:59:02 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:02 --> Output Class Initialized
INFO - 2020-02-27 05:59:02 --> Input Class Initialized
INFO - 2020-02-27 05:59:02 --> Security Class Initialized
INFO - 2020-02-27 05:59:02 --> Language Class Initialized
DEBUG - 2020-02-27 05:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:02 --> Input Class Initialized
ERROR - 2020-02-27 05:59:02 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 05:59:02 --> Language Class Initialized
ERROR - 2020-02-27 05:59:02 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 05:59:03 --> Config Class Initialized
INFO - 2020-02-27 05:59:03 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:03 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:03 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:03 --> URI Class Initialized
INFO - 2020-02-27 05:59:03 --> Router Class Initialized
INFO - 2020-02-27 05:59:03 --> Output Class Initialized
INFO - 2020-02-27 05:59:03 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:03 --> Input Class Initialized
INFO - 2020-02-27 05:59:03 --> Language Class Initialized
ERROR - 2020-02-27 05:59:03 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 05:59:03 --> Config Class Initialized
INFO - 2020-02-27 05:59:03 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:03 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:04 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:04 --> URI Class Initialized
INFO - 2020-02-27 05:59:04 --> Router Class Initialized
INFO - 2020-02-27 05:59:04 --> Output Class Initialized
INFO - 2020-02-27 05:59:04 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:04 --> Input Class Initialized
INFO - 2020-02-27 05:59:04 --> Language Class Initialized
ERROR - 2020-02-27 05:59:04 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 05:59:06 --> Config Class Initialized
INFO - 2020-02-27 05:59:06 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:06 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:06 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:06 --> URI Class Initialized
INFO - 2020-02-27 05:59:06 --> Router Class Initialized
INFO - 2020-02-27 05:59:06 --> Output Class Initialized
INFO - 2020-02-27 05:59:06 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:06 --> Input Class Initialized
INFO - 2020-02-27 05:59:06 --> Language Class Initialized
INFO - 2020-02-27 05:59:06 --> Loader Class Initialized
INFO - 2020-02-27 05:59:07 --> Helper loaded: url_helper
INFO - 2020-02-27 05:59:07 --> Helper loaded: string_helper
INFO - 2020-02-27 05:59:07 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:59:07 --> Controller Class Initialized
INFO - 2020-02-27 05:59:07 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:59:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:59:07 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:59:07 --> Helper loaded: form_helper
INFO - 2020-02-27 05:59:07 --> Form Validation Class Initialized
INFO - 2020-02-27 05:59:07 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 05:59:07 --> Final output sent to browser
DEBUG - 2020-02-27 05:59:07 --> Total execution time: 1.2476
INFO - 2020-02-27 05:59:07 --> Config Class Initialized
INFO - 2020-02-27 05:59:08 --> Config Class Initialized
INFO - 2020-02-27 05:59:08 --> Config Class Initialized
INFO - 2020-02-27 05:59:08 --> Config Class Initialized
INFO - 2020-02-27 05:59:08 --> Config Class Initialized
INFO - 2020-02-27 05:59:08 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:08 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:08 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:08 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:08 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:08 --> Config Class Initialized
INFO - 2020-02-27 05:59:08 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:59:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:08 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:08 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:08 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:08 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:08 --> Utf8 Class Initialized
DEBUG - 2020-02-27 05:59:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:08 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:08 --> URI Class Initialized
INFO - 2020-02-27 05:59:08 --> URI Class Initialized
INFO - 2020-02-27 05:59:08 --> URI Class Initialized
INFO - 2020-02-27 05:59:08 --> URI Class Initialized
INFO - 2020-02-27 05:59:08 --> URI Class Initialized
INFO - 2020-02-27 05:59:08 --> Router Class Initialized
INFO - 2020-02-27 05:59:08 --> Router Class Initialized
INFO - 2020-02-27 05:59:08 --> Router Class Initialized
INFO - 2020-02-27 05:59:08 --> Router Class Initialized
INFO - 2020-02-27 05:59:08 --> URI Class Initialized
INFO - 2020-02-27 05:59:08 --> Router Class Initialized
INFO - 2020-02-27 05:59:08 --> Router Class Initialized
INFO - 2020-02-27 05:59:08 --> Output Class Initialized
INFO - 2020-02-27 05:59:08 --> Output Class Initialized
INFO - 2020-02-27 05:59:08 --> Output Class Initialized
INFO - 2020-02-27 05:59:08 --> Output Class Initialized
INFO - 2020-02-27 05:59:08 --> Output Class Initialized
INFO - 2020-02-27 05:59:08 --> Security Class Initialized
INFO - 2020-02-27 05:59:08 --> Security Class Initialized
INFO - 2020-02-27 05:59:08 --> Security Class Initialized
INFO - 2020-02-27 05:59:08 --> Security Class Initialized
INFO - 2020-02-27 05:59:08 --> Security Class Initialized
INFO - 2020-02-27 05:59:08 --> Output Class Initialized
DEBUG - 2020-02-27 05:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:08 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:08 --> Input Class Initialized
INFO - 2020-02-27 05:59:08 --> Input Class Initialized
INFO - 2020-02-27 05:59:08 --> Input Class Initialized
INFO - 2020-02-27 05:59:08 --> Input Class Initialized
INFO - 2020-02-27 05:59:08 --> Input Class Initialized
DEBUG - 2020-02-27 05:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:08 --> Input Class Initialized
INFO - 2020-02-27 05:59:08 --> Language Class Initialized
INFO - 2020-02-27 05:59:08 --> Language Class Initialized
INFO - 2020-02-27 05:59:08 --> Language Class Initialized
INFO - 2020-02-27 05:59:08 --> Language Class Initialized
INFO - 2020-02-27 05:59:08 --> Language Class Initialized
INFO - 2020-02-27 05:59:08 --> Language Class Initialized
ERROR - 2020-02-27 05:59:08 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 05:59:08 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 05:59:08 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-27 05:59:08 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 05:59:08 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-27 05:59:08 --> Loader Class Initialized
INFO - 2020-02-27 05:59:08 --> Helper loaded: url_helper
INFO - 2020-02-27 05:59:08 --> Helper loaded: string_helper
INFO - 2020-02-27 05:59:08 --> Config Class Initialized
INFO - 2020-02-27 05:59:08 --> Config Class Initialized
INFO - 2020-02-27 05:59:08 --> Config Class Initialized
INFO - 2020-02-27 05:59:08 --> Config Class Initialized
INFO - 2020-02-27 05:59:08 --> Config Class Initialized
INFO - 2020-02-27 05:59:08 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:08 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:08 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:08 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:08 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:08 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:59:08 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:08 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:08 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:08 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:08 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:59:08 --> Controller Class Initialized
INFO - 2020-02-27 05:59:08 --> URI Class Initialized
INFO - 2020-02-27 05:59:08 --> URI Class Initialized
INFO - 2020-02-27 05:59:08 --> URI Class Initialized
INFO - 2020-02-27 05:59:08 --> URI Class Initialized
INFO - 2020-02-27 05:59:08 --> URI Class Initialized
INFO - 2020-02-27 05:59:08 --> Router Class Initialized
INFO - 2020-02-27 05:59:08 --> Router Class Initialized
INFO - 2020-02-27 05:59:08 --> Router Class Initialized
INFO - 2020-02-27 05:59:08 --> Router Class Initialized
INFO - 2020-02-27 05:59:08 --> Router Class Initialized
INFO - 2020-02-27 05:59:08 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:59:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:59:08 --> Output Class Initialized
INFO - 2020-02-27 05:59:08 --> Output Class Initialized
INFO - 2020-02-27 05:59:08 --> Output Class Initialized
INFO - 2020-02-27 05:59:08 --> Output Class Initialized
INFO - 2020-02-27 05:59:08 --> Output Class Initialized
INFO - 2020-02-27 05:59:08 --> Security Class Initialized
INFO - 2020-02-27 05:59:08 --> Security Class Initialized
INFO - 2020-02-27 05:59:08 --> Security Class Initialized
INFO - 2020-02-27 05:59:08 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:59:08 --> Security Class Initialized
INFO - 2020-02-27 05:59:08 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:08 --> Helper loaded: form_helper
INFO - 2020-02-27 05:59:08 --> Form Validation Class Initialized
INFO - 2020-02-27 05:59:08 --> Input Class Initialized
INFO - 2020-02-27 05:59:08 --> Input Class Initialized
INFO - 2020-02-27 05:59:08 --> Input Class Initialized
INFO - 2020-02-27 05:59:08 --> Input Class Initialized
INFO - 2020-02-27 05:59:08 --> Input Class Initialized
INFO - 2020-02-27 05:59:08 --> Language Class Initialized
INFO - 2020-02-27 05:59:08 --> Language Class Initialized
INFO - 2020-02-27 05:59:08 --> Language Class Initialized
INFO - 2020-02-27 05:59:08 --> Language Class Initialized
INFO - 2020-02-27 05:59:08 --> Language Class Initialized
ERROR - 2020-02-27 05:59:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 05:59:08 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 05:59:08 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-27 05:59:08 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 05:59:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 05:59:08 --> Loader Class Initialized
ERROR - 2020-02-27 05:59:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 05:59:08 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 05:59:08 --> Helper loaded: url_helper
INFO - 2020-02-27 05:59:08 --> Final output sent to browser
INFO - 2020-02-27 05:59:08 --> Helper loaded: string_helper
INFO - 2020-02-27 05:59:09 --> Config Class Initialized
INFO - 2020-02-27 05:59:09 --> Config Class Initialized
INFO - 2020-02-27 05:59:09 --> Config Class Initialized
INFO - 2020-02-27 05:59:09 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:09 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:09 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:09 --> Total execution time: 0.9062
INFO - 2020-02-27 05:59:09 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:59:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:59:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:59:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:09 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:09 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:09 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:09 --> URI Class Initialized
INFO - 2020-02-27 05:59:09 --> URI Class Initialized
INFO - 2020-02-27 05:59:09 --> URI Class Initialized
DEBUG - 2020-02-27 05:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:59:09 --> Router Class Initialized
INFO - 2020-02-27 05:59:09 --> Router Class Initialized
INFO - 2020-02-27 05:59:09 --> Router Class Initialized
INFO - 2020-02-27 05:59:09 --> Controller Class Initialized
INFO - 2020-02-27 05:59:09 --> Output Class Initialized
INFO - 2020-02-27 05:59:09 --> Output Class Initialized
INFO - 2020-02-27 05:59:09 --> Output Class Initialized
INFO - 2020-02-27 05:59:09 --> Security Class Initialized
INFO - 2020-02-27 05:59:09 --> Security Class Initialized
INFO - 2020-02-27 05:59:09 --> Security Class Initialized
INFO - 2020-02-27 05:59:09 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:59:09 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-27 05:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:09 --> Input Class Initialized
INFO - 2020-02-27 05:59:09 --> Input Class Initialized
INFO - 2020-02-27 05:59:09 --> Input Class Initialized
INFO - 2020-02-27 05:59:09 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:59:09 --> Language Class Initialized
INFO - 2020-02-27 05:59:09 --> Language Class Initialized
INFO - 2020-02-27 05:59:09 --> Language Class Initialized
INFO - 2020-02-27 05:59:09 --> Helper loaded: form_helper
INFO - 2020-02-27 05:59:09 --> Form Validation Class Initialized
ERROR - 2020-02-27 05:59:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-27 05:59:09 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-27 05:59:09 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 05:59:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-27 05:59:09 --> Config Class Initialized
INFO - 2020-02-27 05:59:09 --> Hooks Class Initialized
ERROR - 2020-02-27 05:59:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 05:59:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-27 05:59:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:09 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:09 --> Final output sent to browser
DEBUG - 2020-02-27 05:59:09 --> Total execution time: 0.9548
INFO - 2020-02-27 05:59:09 --> URI Class Initialized
INFO - 2020-02-27 05:59:09 --> Router Class Initialized
INFO - 2020-02-27 05:59:09 --> Output Class Initialized
INFO - 2020-02-27 05:59:09 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:09 --> Input Class Initialized
INFO - 2020-02-27 05:59:09 --> Language Class Initialized
ERROR - 2020-02-27 05:59:09 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 05:59:09 --> Config Class Initialized
INFO - 2020-02-27 05:59:09 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:09 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:09 --> URI Class Initialized
INFO - 2020-02-27 05:59:09 --> Router Class Initialized
INFO - 2020-02-27 05:59:09 --> Output Class Initialized
INFO - 2020-02-27 05:59:10 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:10 --> Input Class Initialized
INFO - 2020-02-27 05:59:10 --> Language Class Initialized
ERROR - 2020-02-27 05:59:10 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 05:59:10 --> Config Class Initialized
INFO - 2020-02-27 05:59:10 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:10 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:10 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:10 --> URI Class Initialized
INFO - 2020-02-27 05:59:10 --> Router Class Initialized
INFO - 2020-02-27 05:59:10 --> Output Class Initialized
INFO - 2020-02-27 05:59:10 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:10 --> Input Class Initialized
INFO - 2020-02-27 05:59:10 --> Language Class Initialized
ERROR - 2020-02-27 05:59:10 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 05:59:10 --> Config Class Initialized
INFO - 2020-02-27 05:59:10 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:10 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:10 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:10 --> URI Class Initialized
INFO - 2020-02-27 05:59:10 --> Router Class Initialized
INFO - 2020-02-27 05:59:10 --> Output Class Initialized
INFO - 2020-02-27 05:59:10 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:11 --> Input Class Initialized
INFO - 2020-02-27 05:59:11 --> Language Class Initialized
ERROR - 2020-02-27 05:59:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 05:59:11 --> Config Class Initialized
INFO - 2020-02-27 05:59:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:11 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:11 --> URI Class Initialized
INFO - 2020-02-27 05:59:11 --> Router Class Initialized
INFO - 2020-02-27 05:59:11 --> Output Class Initialized
INFO - 2020-02-27 05:59:11 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:11 --> Input Class Initialized
INFO - 2020-02-27 05:59:11 --> Language Class Initialized
ERROR - 2020-02-27 05:59:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 05:59:11 --> Config Class Initialized
INFO - 2020-02-27 05:59:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:11 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:11 --> URI Class Initialized
INFO - 2020-02-27 05:59:11 --> Router Class Initialized
INFO - 2020-02-27 05:59:11 --> Output Class Initialized
INFO - 2020-02-27 05:59:11 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:11 --> Input Class Initialized
INFO - 2020-02-27 05:59:11 --> Language Class Initialized
ERROR - 2020-02-27 05:59:11 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 05:59:11 --> Config Class Initialized
INFO - 2020-02-27 05:59:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:11 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:12 --> URI Class Initialized
INFO - 2020-02-27 05:59:12 --> Router Class Initialized
INFO - 2020-02-27 05:59:12 --> Output Class Initialized
INFO - 2020-02-27 05:59:12 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:12 --> Input Class Initialized
INFO - 2020-02-27 05:59:12 --> Language Class Initialized
ERROR - 2020-02-27 05:59:12 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 05:59:12 --> Config Class Initialized
INFO - 2020-02-27 05:59:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:12 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:12 --> URI Class Initialized
INFO - 2020-02-27 05:59:12 --> Router Class Initialized
INFO - 2020-02-27 05:59:12 --> Output Class Initialized
INFO - 2020-02-27 05:59:12 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:12 --> Input Class Initialized
INFO - 2020-02-27 05:59:12 --> Language Class Initialized
ERROR - 2020-02-27 05:59:12 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 05:59:12 --> Config Class Initialized
INFO - 2020-02-27 05:59:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:12 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:12 --> URI Class Initialized
INFO - 2020-02-27 05:59:12 --> Router Class Initialized
INFO - 2020-02-27 05:59:12 --> Output Class Initialized
INFO - 2020-02-27 05:59:12 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:12 --> Input Class Initialized
INFO - 2020-02-27 05:59:12 --> Language Class Initialized
ERROR - 2020-02-27 05:59:12 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 05:59:33 --> Config Class Initialized
INFO - 2020-02-27 05:59:33 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:34 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:34 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:34 --> URI Class Initialized
INFO - 2020-02-27 05:59:34 --> Router Class Initialized
INFO - 2020-02-27 05:59:34 --> Output Class Initialized
INFO - 2020-02-27 05:59:34 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:34 --> Input Class Initialized
INFO - 2020-02-27 05:59:34 --> Language Class Initialized
INFO - 2020-02-27 05:59:34 --> Loader Class Initialized
INFO - 2020-02-27 05:59:34 --> Helper loaded: url_helper
INFO - 2020-02-27 05:59:34 --> Helper loaded: string_helper
INFO - 2020-02-27 05:59:34 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:59:34 --> Controller Class Initialized
INFO - 2020-02-27 05:59:34 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:59:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:59:34 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:59:34 --> Helper loaded: form_helper
INFO - 2020-02-27 05:59:34 --> Form Validation Class Initialized
INFO - 2020-02-27 11:59:35 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 11:59:35 --> Final output sent to browser
DEBUG - 2020-02-27 11:59:35 --> Total execution time: 1.2684
INFO - 2020-02-27 05:59:42 --> Config Class Initialized
INFO - 2020-02-27 05:59:42 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:42 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:42 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:42 --> URI Class Initialized
INFO - 2020-02-27 05:59:42 --> Router Class Initialized
INFO - 2020-02-27 05:59:42 --> Output Class Initialized
INFO - 2020-02-27 05:59:42 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:42 --> Input Class Initialized
INFO - 2020-02-27 05:59:42 --> Language Class Initialized
INFO - 2020-02-27 05:59:42 --> Loader Class Initialized
INFO - 2020-02-27 05:59:42 --> Helper loaded: url_helper
INFO - 2020-02-27 05:59:42 --> Helper loaded: string_helper
INFO - 2020-02-27 05:59:42 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:59:42 --> Controller Class Initialized
INFO - 2020-02-27 05:59:42 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:59:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:59:42 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:59:42 --> Helper loaded: form_helper
INFO - 2020-02-27 05:59:42 --> Form Validation Class Initialized
ERROR - 2020-02-27 05:59:42 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 05:59:43 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 05:59:43 --> Final output sent to browser
DEBUG - 2020-02-27 05:59:43 --> Total execution time: 0.9258
INFO - 2020-02-27 05:59:51 --> Config Class Initialized
INFO - 2020-02-27 05:59:51 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:51 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:51 --> URI Class Initialized
INFO - 2020-02-27 05:59:51 --> Router Class Initialized
INFO - 2020-02-27 05:59:51 --> Output Class Initialized
INFO - 2020-02-27 05:59:51 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:51 --> Input Class Initialized
INFO - 2020-02-27 05:59:51 --> Language Class Initialized
INFO - 2020-02-27 05:59:51 --> Loader Class Initialized
INFO - 2020-02-27 05:59:51 --> Helper loaded: url_helper
INFO - 2020-02-27 05:59:51 --> Helper loaded: string_helper
INFO - 2020-02-27 05:59:51 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:59:52 --> Controller Class Initialized
INFO - 2020-02-27 05:59:52 --> Model "M_tiket" initialized
INFO - 2020-02-27 05:59:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 05:59:52 --> Model "M_pesan" initialized
INFO - 2020-02-27 05:59:52 --> Helper loaded: form_helper
INFO - 2020-02-27 05:59:52 --> Form Validation Class Initialized
ERROR - 2020-02-27 05:59:52 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 105
ERROR - 2020-02-27 05:59:52 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 107
ERROR - 2020-02-27 05:59:52 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
INFO - 2020-02-27 05:59:52 --> Config Class Initialized
INFO - 2020-02-27 05:59:52 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:52 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:52 --> URI Class Initialized
INFO - 2020-02-27 05:59:52 --> Router Class Initialized
INFO - 2020-02-27 05:59:52 --> Output Class Initialized
INFO - 2020-02-27 05:59:52 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:52 --> Input Class Initialized
INFO - 2020-02-27 05:59:52 --> Language Class Initialized
INFO - 2020-02-27 05:59:52 --> Loader Class Initialized
INFO - 2020-02-27 05:59:52 --> Helper loaded: url_helper
INFO - 2020-02-27 05:59:52 --> Helper loaded: string_helper
INFO - 2020-02-27 05:59:52 --> Database Driver Class Initialized
DEBUG - 2020-02-27 05:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 05:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 05:59:52 --> Controller Class Initialized
INFO - 2020-02-27 05:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 05:59:52 --> Pagination Class Initialized
INFO - 2020-02-27 05:59:53 --> Model "M_show" initialized
INFO - 2020-02-27 05:59:53 --> Helper loaded: form_helper
INFO - 2020-02-27 05:59:53 --> Form Validation Class Initialized
INFO - 2020-02-27 05:59:53 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 05:59:53 --> Final output sent to browser
DEBUG - 2020-02-27 05:59:53 --> Total execution time: 0.7520
INFO - 2020-02-27 05:59:53 --> Config Class Initialized
INFO - 2020-02-27 05:59:53 --> Config Class Initialized
INFO - 2020-02-27 05:59:53 --> Hooks Class Initialized
INFO - 2020-02-27 05:59:53 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 05:59:53 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:53 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:53 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:53 --> URI Class Initialized
INFO - 2020-02-27 05:59:53 --> URI Class Initialized
INFO - 2020-02-27 05:59:53 --> Router Class Initialized
INFO - 2020-02-27 05:59:53 --> Router Class Initialized
INFO - 2020-02-27 05:59:53 --> Output Class Initialized
INFO - 2020-02-27 05:59:53 --> Output Class Initialized
INFO - 2020-02-27 05:59:53 --> Security Class Initialized
INFO - 2020-02-27 05:59:53 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 05:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:53 --> Input Class Initialized
INFO - 2020-02-27 05:59:53 --> Input Class Initialized
INFO - 2020-02-27 05:59:53 --> Language Class Initialized
INFO - 2020-02-27 05:59:53 --> Language Class Initialized
ERROR - 2020-02-27 05:59:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 05:59:53 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 05:59:53 --> Config Class Initialized
INFO - 2020-02-27 05:59:53 --> Hooks Class Initialized
DEBUG - 2020-02-27 05:59:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 05:59:54 --> Utf8 Class Initialized
INFO - 2020-02-27 05:59:54 --> URI Class Initialized
INFO - 2020-02-27 05:59:54 --> Router Class Initialized
INFO - 2020-02-27 05:59:54 --> Output Class Initialized
INFO - 2020-02-27 05:59:54 --> Security Class Initialized
DEBUG - 2020-02-27 05:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 05:59:54 --> Input Class Initialized
INFO - 2020-02-27 05:59:54 --> Language Class Initialized
ERROR - 2020-02-27 05:59:54 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 06:03:54 --> Config Class Initialized
INFO - 2020-02-27 06:03:54 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:03:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:03:54 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:55 --> URI Class Initialized
INFO - 2020-02-27 06:03:55 --> Router Class Initialized
INFO - 2020-02-27 06:03:55 --> Output Class Initialized
INFO - 2020-02-27 06:03:55 --> Security Class Initialized
DEBUG - 2020-02-27 06:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:55 --> Input Class Initialized
INFO - 2020-02-27 06:03:55 --> Language Class Initialized
INFO - 2020-02-27 06:03:55 --> Loader Class Initialized
INFO - 2020-02-27 06:03:55 --> Helper loaded: url_helper
INFO - 2020-02-27 06:03:55 --> Helper loaded: string_helper
INFO - 2020-02-27 06:03:55 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:03:55 --> Controller Class Initialized
INFO - 2020-02-27 06:03:55 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:03:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:03:55 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:03:55 --> Helper loaded: form_helper
INFO - 2020-02-27 06:03:55 --> Form Validation Class Initialized
INFO - 2020-02-27 06:03:55 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 06:03:55 --> Final output sent to browser
DEBUG - 2020-02-27 06:03:55 --> Total execution time: 0.8911
INFO - 2020-02-27 06:03:55 --> Config Class Initialized
INFO - 2020-02-27 06:03:55 --> Config Class Initialized
INFO - 2020-02-27 06:03:55 --> Config Class Initialized
INFO - 2020-02-27 06:03:55 --> Config Class Initialized
INFO - 2020-02-27 06:03:55 --> Config Class Initialized
INFO - 2020-02-27 06:03:55 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:55 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:55 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:55 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:55 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:55 --> Config Class Initialized
INFO - 2020-02-27 06:03:55 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:03:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:03:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:03:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:03:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:03:55 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:03:55 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:55 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:55 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:55 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:55 --> Utf8 Class Initialized
DEBUG - 2020-02-27 06:03:55 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:03:55 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:55 --> URI Class Initialized
INFO - 2020-02-27 06:03:55 --> URI Class Initialized
INFO - 2020-02-27 06:03:55 --> URI Class Initialized
INFO - 2020-02-27 06:03:55 --> URI Class Initialized
INFO - 2020-02-27 06:03:55 --> URI Class Initialized
INFO - 2020-02-27 06:03:55 --> Router Class Initialized
INFO - 2020-02-27 06:03:55 --> Router Class Initialized
INFO - 2020-02-27 06:03:55 --> Router Class Initialized
INFO - 2020-02-27 06:03:55 --> Router Class Initialized
INFO - 2020-02-27 06:03:56 --> URI Class Initialized
INFO - 2020-02-27 06:03:56 --> Router Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
INFO - 2020-02-27 06:03:56 --> Router Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
INFO - 2020-02-27 06:03:56 --> Security Class Initialized
INFO - 2020-02-27 06:03:56 --> Security Class Initialized
INFO - 2020-02-27 06:03:56 --> Security Class Initialized
INFO - 2020-02-27 06:03:56 --> Security Class Initialized
INFO - 2020-02-27 06:03:56 --> Security Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
DEBUG - 2020-02-27 06:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:56 --> Security Class Initialized
DEBUG - 2020-02-27 06:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:56 --> Input Class Initialized
INFO - 2020-02-27 06:03:56 --> Input Class Initialized
INFO - 2020-02-27 06:03:56 --> Input Class Initialized
INFO - 2020-02-27 06:03:56 --> Input Class Initialized
INFO - 2020-02-27 06:03:56 --> Input Class Initialized
DEBUG - 2020-02-27 06:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:56 --> Input Class Initialized
INFO - 2020-02-27 06:03:56 --> Language Class Initialized
INFO - 2020-02-27 06:03:56 --> Language Class Initialized
INFO - 2020-02-27 06:03:56 --> Language Class Initialized
INFO - 2020-02-27 06:03:56 --> Language Class Initialized
INFO - 2020-02-27 06:03:56 --> Language Class Initialized
INFO - 2020-02-27 06:03:56 --> Language Class Initialized
ERROR - 2020-02-27 06:03:56 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 06:03:56 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 06:03:56 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-27 06:03:56 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-27 06:03:56 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 06:03:56 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 06:03:56 --> Config Class Initialized
INFO - 2020-02-27 06:03:56 --> Config Class Initialized
INFO - 2020-02-27 06:03:56 --> Config Class Initialized
INFO - 2020-02-27 06:03:56 --> Config Class Initialized
INFO - 2020-02-27 06:03:56 --> Config Class Initialized
INFO - 2020-02-27 06:03:56 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:56 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:56 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:56 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:56 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:56 --> Config Class Initialized
INFO - 2020-02-27 06:03:56 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:03:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:03:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:03:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:03:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:03:56 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:03:56 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:56 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:56 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:56 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:56 --> Utf8 Class Initialized
DEBUG - 2020-02-27 06:03:56 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:03:56 --> URI Class Initialized
INFO - 2020-02-27 06:03:56 --> URI Class Initialized
INFO - 2020-02-27 06:03:56 --> URI Class Initialized
INFO - 2020-02-27 06:03:56 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:56 --> URI Class Initialized
INFO - 2020-02-27 06:03:56 --> URI Class Initialized
INFO - 2020-02-27 06:03:56 --> URI Class Initialized
INFO - 2020-02-27 06:03:56 --> Router Class Initialized
INFO - 2020-02-27 06:03:56 --> Router Class Initialized
INFO - 2020-02-27 06:03:56 --> Router Class Initialized
INFO - 2020-02-27 06:03:56 --> Router Class Initialized
INFO - 2020-02-27 06:03:56 --> Router Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
INFO - 2020-02-27 06:03:56 --> Router Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
INFO - 2020-02-27 06:03:56 --> Security Class Initialized
INFO - 2020-02-27 06:03:56 --> Security Class Initialized
INFO - 2020-02-27 06:03:56 --> Security Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
INFO - 2020-02-27 06:03:56 --> Security Class Initialized
INFO - 2020-02-27 06:03:56 --> Security Class Initialized
DEBUG - 2020-02-27 06:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:56 --> Security Class Initialized
DEBUG - 2020-02-27 06:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:56 --> Input Class Initialized
INFO - 2020-02-27 06:03:56 --> Input Class Initialized
INFO - 2020-02-27 06:03:56 --> Input Class Initialized
INFO - 2020-02-27 06:03:56 --> Input Class Initialized
INFO - 2020-02-27 06:03:56 --> Input Class Initialized
DEBUG - 2020-02-27 06:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:56 --> Input Class Initialized
INFO - 2020-02-27 06:03:56 --> Language Class Initialized
INFO - 2020-02-27 06:03:56 --> Language Class Initialized
INFO - 2020-02-27 06:03:56 --> Language Class Initialized
INFO - 2020-02-27 06:03:56 --> Language Class Initialized
INFO - 2020-02-27 06:03:56 --> Language Class Initialized
INFO - 2020-02-27 06:03:56 --> Language Class Initialized
ERROR - 2020-02-27 06:03:56 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 06:03:56 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-27 06:03:56 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-27 06:03:56 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 06:03:56 --> Loader Class Initialized
INFO - 2020-02-27 06:03:56 --> Helper loaded: url_helper
INFO - 2020-02-27 06:03:56 --> Loader Class Initialized
INFO - 2020-02-27 06:03:56 --> Config Class Initialized
INFO - 2020-02-27 06:03:56 --> Config Class Initialized
INFO - 2020-02-27 06:03:56 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:56 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:56 --> Helper loaded: string_helper
INFO - 2020-02-27 06:03:56 --> Helper loaded: url_helper
INFO - 2020-02-27 06:03:56 --> Helper loaded: string_helper
DEBUG - 2020-02-27 06:03:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:03:56 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:03:56 --> Database Driver Class Initialized
INFO - 2020-02-27 06:03:56 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:56 --> Utf8 Class Initialized
DEBUG - 2020-02-27 06:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:03:56 --> Database Driver Class Initialized
INFO - 2020-02-27 06:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:03:56 --> URI Class Initialized
INFO - 2020-02-27 06:03:56 --> URI Class Initialized
DEBUG - 2020-02-27 06:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:03:56 --> Controller Class Initialized
INFO - 2020-02-27 06:03:56 --> Router Class Initialized
INFO - 2020-02-27 06:03:56 --> Router Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
INFO - 2020-02-27 06:03:56 --> Output Class Initialized
INFO - 2020-02-27 06:03:57 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:03:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:03:57 --> Security Class Initialized
INFO - 2020-02-27 06:03:57 --> Security Class Initialized
INFO - 2020-02-27 06:03:57 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 06:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:57 --> Input Class Initialized
INFO - 2020-02-27 06:03:57 --> Input Class Initialized
INFO - 2020-02-27 06:03:57 --> Helper loaded: form_helper
INFO - 2020-02-27 06:03:57 --> Form Validation Class Initialized
INFO - 2020-02-27 06:03:57 --> Language Class Initialized
INFO - 2020-02-27 06:03:57 --> Language Class Initialized
ERROR - 2020-02-27 06:03:57 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 06:03:57 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 06:03:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 06:03:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 06:03:57 --> Config Class Initialized
INFO - 2020-02-27 06:03:57 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:57 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 06:03:57 --> Final output sent to browser
DEBUG - 2020-02-27 06:03:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:03:57 --> Total execution time: 1.0812
INFO - 2020-02-27 06:03:57 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:03:57 --> URI Class Initialized
INFO - 2020-02-27 06:03:57 --> Controller Class Initialized
INFO - 2020-02-27 06:03:57 --> Router Class Initialized
INFO - 2020-02-27 06:03:57 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:03:57 --> Output Class Initialized
INFO - 2020-02-27 06:03:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:03:57 --> Security Class Initialized
INFO - 2020-02-27 06:03:57 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 06:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:57 --> Input Class Initialized
INFO - 2020-02-27 06:03:57 --> Helper loaded: form_helper
INFO - 2020-02-27 06:03:57 --> Form Validation Class Initialized
INFO - 2020-02-27 06:03:57 --> Language Class Initialized
ERROR - 2020-02-27 06:03:57 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-27 06:03:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 06:03:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 06:03:57 --> Config Class Initialized
INFO - 2020-02-27 06:03:57 --> Hooks Class Initialized
INFO - 2020-02-27 06:03:57 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 06:03:57 --> Final output sent to browser
DEBUG - 2020-02-27 06:03:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:03:57 --> Total execution time: 1.6333
INFO - 2020-02-27 06:03:57 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:58 --> URI Class Initialized
INFO - 2020-02-27 06:03:58 --> Router Class Initialized
INFO - 2020-02-27 06:03:58 --> Output Class Initialized
INFO - 2020-02-27 06:03:58 --> Security Class Initialized
DEBUG - 2020-02-27 06:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:58 --> Input Class Initialized
INFO - 2020-02-27 06:03:58 --> Language Class Initialized
ERROR - 2020-02-27 06:03:58 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 06:03:58 --> Config Class Initialized
INFO - 2020-02-27 06:03:58 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:03:58 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:03:58 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:58 --> URI Class Initialized
INFO - 2020-02-27 06:03:58 --> Router Class Initialized
INFO - 2020-02-27 06:03:58 --> Output Class Initialized
INFO - 2020-02-27 06:03:58 --> Security Class Initialized
DEBUG - 2020-02-27 06:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:58 --> Input Class Initialized
INFO - 2020-02-27 06:03:58 --> Language Class Initialized
ERROR - 2020-02-27 06:03:58 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 06:03:58 --> Config Class Initialized
INFO - 2020-02-27 06:03:58 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:03:58 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:03:58 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:58 --> URI Class Initialized
INFO - 2020-02-27 06:03:58 --> Router Class Initialized
INFO - 2020-02-27 06:03:58 --> Output Class Initialized
INFO - 2020-02-27 06:03:58 --> Security Class Initialized
DEBUG - 2020-02-27 06:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:58 --> Input Class Initialized
INFO - 2020-02-27 06:03:58 --> Language Class Initialized
ERROR - 2020-02-27 06:03:59 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 06:03:59 --> Config Class Initialized
INFO - 2020-02-27 06:03:59 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:03:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:03:59 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:59 --> URI Class Initialized
INFO - 2020-02-27 06:03:59 --> Router Class Initialized
INFO - 2020-02-27 06:03:59 --> Output Class Initialized
INFO - 2020-02-27 06:03:59 --> Security Class Initialized
DEBUG - 2020-02-27 06:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:59 --> Input Class Initialized
INFO - 2020-02-27 06:03:59 --> Language Class Initialized
ERROR - 2020-02-27 06:03:59 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 06:03:59 --> Config Class Initialized
INFO - 2020-02-27 06:03:59 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:03:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:03:59 --> Utf8 Class Initialized
INFO - 2020-02-27 06:03:59 --> URI Class Initialized
INFO - 2020-02-27 06:03:59 --> Router Class Initialized
INFO - 2020-02-27 06:03:59 --> Output Class Initialized
INFO - 2020-02-27 06:03:59 --> Security Class Initialized
DEBUG - 2020-02-27 06:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:03:59 --> Input Class Initialized
INFO - 2020-02-27 06:03:59 --> Language Class Initialized
ERROR - 2020-02-27 06:03:59 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 06:03:59 --> Config Class Initialized
INFO - 2020-02-27 06:03:59 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:04:00 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:04:00 --> Utf8 Class Initialized
INFO - 2020-02-27 06:04:00 --> URI Class Initialized
INFO - 2020-02-27 06:04:00 --> Router Class Initialized
INFO - 2020-02-27 06:04:00 --> Output Class Initialized
INFO - 2020-02-27 06:04:00 --> Security Class Initialized
DEBUG - 2020-02-27 06:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:04:00 --> Input Class Initialized
INFO - 2020-02-27 06:04:00 --> Language Class Initialized
ERROR - 2020-02-27 06:04:00 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 06:04:24 --> Config Class Initialized
INFO - 2020-02-27 06:04:24 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:04:24 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:04:24 --> Utf8 Class Initialized
INFO - 2020-02-27 06:04:24 --> URI Class Initialized
INFO - 2020-02-27 06:04:24 --> Router Class Initialized
INFO - 2020-02-27 06:04:24 --> Output Class Initialized
INFO - 2020-02-27 06:04:24 --> Security Class Initialized
DEBUG - 2020-02-27 06:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:04:24 --> Input Class Initialized
INFO - 2020-02-27 06:04:24 --> Language Class Initialized
INFO - 2020-02-27 06:04:24 --> Loader Class Initialized
INFO - 2020-02-27 06:04:24 --> Helper loaded: url_helper
INFO - 2020-02-27 06:04:24 --> Helper loaded: string_helper
INFO - 2020-02-27 06:04:24 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:04:24 --> Controller Class Initialized
INFO - 2020-02-27 06:04:24 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:04:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:04:24 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:04:24 --> Helper loaded: form_helper
INFO - 2020-02-27 06:04:24 --> Form Validation Class Initialized
INFO - 2020-02-27 12:04:25 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 12:04:25 --> Final output sent to browser
DEBUG - 2020-02-27 12:04:25 --> Total execution time: 1.0762
INFO - 2020-02-27 06:04:30 --> Config Class Initialized
INFO - 2020-02-27 06:04:30 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:04:30 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:04:30 --> Utf8 Class Initialized
INFO - 2020-02-27 06:04:30 --> URI Class Initialized
INFO - 2020-02-27 06:04:30 --> Router Class Initialized
INFO - 2020-02-27 06:04:30 --> Output Class Initialized
INFO - 2020-02-27 06:04:30 --> Security Class Initialized
DEBUG - 2020-02-27 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:04:30 --> Input Class Initialized
INFO - 2020-02-27 06:04:30 --> Language Class Initialized
INFO - 2020-02-27 06:04:30 --> Loader Class Initialized
INFO - 2020-02-27 06:04:30 --> Helper loaded: url_helper
INFO - 2020-02-27 06:04:30 --> Helper loaded: string_helper
INFO - 2020-02-27 06:04:30 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:04:31 --> Controller Class Initialized
INFO - 2020-02-27 06:04:31 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:04:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:04:31 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:04:31 --> Helper loaded: form_helper
INFO - 2020-02-27 06:04:31 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:04:31 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 06:04:31 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 06:04:31 --> Final output sent to browser
DEBUG - 2020-02-27 06:04:31 --> Total execution time: 0.9690
INFO - 2020-02-27 06:04:37 --> Config Class Initialized
INFO - 2020-02-27 06:04:37 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:04:37 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:04:37 --> Utf8 Class Initialized
INFO - 2020-02-27 06:04:37 --> URI Class Initialized
INFO - 2020-02-27 06:04:37 --> Router Class Initialized
INFO - 2020-02-27 06:04:37 --> Output Class Initialized
INFO - 2020-02-27 06:04:37 --> Security Class Initialized
DEBUG - 2020-02-27 06:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:04:38 --> Input Class Initialized
INFO - 2020-02-27 06:04:38 --> Language Class Initialized
INFO - 2020-02-27 06:04:38 --> Loader Class Initialized
INFO - 2020-02-27 06:04:38 --> Helper loaded: url_helper
INFO - 2020-02-27 06:04:38 --> Helper loaded: string_helper
INFO - 2020-02-27 06:04:38 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:04:38 --> Controller Class Initialized
INFO - 2020-02-27 06:04:38 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:04:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:04:38 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:04:38 --> Helper loaded: form_helper
INFO - 2020-02-27 06:04:38 --> Form Validation Class Initialized
INFO - 2020-02-27 06:04:38 --> Final output sent to browser
DEBUG - 2020-02-27 06:04:38 --> Total execution time: 1.5193
INFO - 2020-02-27 06:06:42 --> Config Class Initialized
INFO - 2020-02-27 06:06:42 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:06:42 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:06:42 --> Utf8 Class Initialized
INFO - 2020-02-27 06:06:42 --> URI Class Initialized
INFO - 2020-02-27 06:06:42 --> Router Class Initialized
INFO - 2020-02-27 06:06:42 --> Output Class Initialized
INFO - 2020-02-27 06:06:42 --> Security Class Initialized
DEBUG - 2020-02-27 06:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:06:42 --> Input Class Initialized
INFO - 2020-02-27 06:06:42 --> Language Class Initialized
INFO - 2020-02-27 06:06:42 --> Loader Class Initialized
INFO - 2020-02-27 06:06:42 --> Helper loaded: url_helper
INFO - 2020-02-27 06:06:42 --> Helper loaded: string_helper
INFO - 2020-02-27 06:06:42 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:06:42 --> Controller Class Initialized
INFO - 2020-02-27 06:06:42 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:06:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:06:43 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:06:43 --> Helper loaded: form_helper
INFO - 2020-02-27 06:06:43 --> Form Validation Class Initialized
INFO - 2020-02-27 06:06:43 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 06:06:43 --> Final output sent to browser
DEBUG - 2020-02-27 06:06:43 --> Total execution time: 0.8528
INFO - 2020-02-27 06:06:43 --> Config Class Initialized
INFO - 2020-02-27 06:06:43 --> Config Class Initialized
INFO - 2020-02-27 06:06:43 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:06:43 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:06:43 --> Hooks Class Initialized
INFO - 2020-02-27 06:06:43 --> Utf8 Class Initialized
INFO - 2020-02-27 06:06:43 --> URI Class Initialized
DEBUG - 2020-02-27 06:06:43 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:06:43 --> Utf8 Class Initialized
INFO - 2020-02-27 06:06:43 --> Router Class Initialized
INFO - 2020-02-27 06:06:43 --> URI Class Initialized
INFO - 2020-02-27 06:06:43 --> Output Class Initialized
INFO - 2020-02-27 06:06:43 --> Router Class Initialized
INFO - 2020-02-27 06:06:43 --> Security Class Initialized
DEBUG - 2020-02-27 06:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:06:43 --> Output Class Initialized
INFO - 2020-02-27 06:06:43 --> Input Class Initialized
INFO - 2020-02-27 06:06:43 --> Security Class Initialized
INFO - 2020-02-27 06:06:43 --> Language Class Initialized
DEBUG - 2020-02-27 06:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:06:43 --> Input Class Initialized
INFO - 2020-02-27 06:06:43 --> Loader Class Initialized
INFO - 2020-02-27 06:06:43 --> Language Class Initialized
INFO - 2020-02-27 06:06:43 --> Helper loaded: url_helper
INFO - 2020-02-27 06:06:43 --> Helper loaded: string_helper
INFO - 2020-02-27 06:06:43 --> Loader Class Initialized
INFO - 2020-02-27 06:06:43 --> Helper loaded: url_helper
INFO - 2020-02-27 06:06:43 --> Database Driver Class Initialized
INFO - 2020-02-27 06:06:44 --> Helper loaded: string_helper
DEBUG - 2020-02-27 06:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:06:44 --> Database Driver Class Initialized
INFO - 2020-02-27 06:06:44 --> Controller Class Initialized
DEBUG - 2020-02-27 06:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:06:44 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:06:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:06:44 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:06:44 --> Helper loaded: form_helper
INFO - 2020-02-27 06:06:44 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 06:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 06:06:44 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 06:06:44 --> Final output sent to browser
DEBUG - 2020-02-27 06:06:44 --> Total execution time: 1.0671
INFO - 2020-02-27 06:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:06:44 --> Controller Class Initialized
INFO - 2020-02-27 06:06:44 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:06:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:06:44 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:06:44 --> Helper loaded: form_helper
INFO - 2020-02-27 06:06:44 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 06:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 06:06:44 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 06:06:44 --> Final output sent to browser
DEBUG - 2020-02-27 06:06:44 --> Total execution time: 1.3900
INFO - 2020-02-27 06:06:51 --> Config Class Initialized
INFO - 2020-02-27 06:06:51 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:06:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:06:51 --> Utf8 Class Initialized
INFO - 2020-02-27 06:06:51 --> URI Class Initialized
INFO - 2020-02-27 06:06:51 --> Router Class Initialized
INFO - 2020-02-27 06:06:51 --> Output Class Initialized
INFO - 2020-02-27 06:06:51 --> Security Class Initialized
DEBUG - 2020-02-27 06:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:06:51 --> Input Class Initialized
INFO - 2020-02-27 06:06:51 --> Language Class Initialized
INFO - 2020-02-27 06:06:51 --> Loader Class Initialized
INFO - 2020-02-27 06:06:51 --> Helper loaded: url_helper
INFO - 2020-02-27 06:06:51 --> Helper loaded: string_helper
INFO - 2020-02-27 06:06:51 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:06:51 --> Controller Class Initialized
INFO - 2020-02-27 06:06:51 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:06:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:06:52 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:06:52 --> Helper loaded: form_helper
INFO - 2020-02-27 06:06:52 --> Form Validation Class Initialized
INFO - 2020-02-27 12:06:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 12:06:52 --> Final output sent to browser
DEBUG - 2020-02-27 12:06:52 --> Total execution time: 1.0099
INFO - 2020-02-27 06:06:57 --> Config Class Initialized
INFO - 2020-02-27 06:06:57 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:06:58 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:06:58 --> Utf8 Class Initialized
INFO - 2020-02-27 06:06:58 --> URI Class Initialized
INFO - 2020-02-27 06:06:58 --> Router Class Initialized
INFO - 2020-02-27 06:06:58 --> Output Class Initialized
INFO - 2020-02-27 06:06:58 --> Security Class Initialized
DEBUG - 2020-02-27 06:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:06:58 --> Input Class Initialized
INFO - 2020-02-27 06:06:58 --> Language Class Initialized
INFO - 2020-02-27 06:06:58 --> Loader Class Initialized
INFO - 2020-02-27 06:06:58 --> Helper loaded: url_helper
INFO - 2020-02-27 06:06:58 --> Helper loaded: string_helper
INFO - 2020-02-27 06:06:58 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:06:58 --> Controller Class Initialized
INFO - 2020-02-27 06:06:58 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:06:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:06:59 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:06:59 --> Helper loaded: form_helper
INFO - 2020-02-27 06:06:59 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:06:59 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 06:06:59 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 06:06:59 --> Final output sent to browser
DEBUG - 2020-02-27 06:06:59 --> Total execution time: 1.3139
INFO - 2020-02-27 06:07:12 --> Config Class Initialized
INFO - 2020-02-27 06:07:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:07:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:07:13 --> Utf8 Class Initialized
INFO - 2020-02-27 06:07:13 --> URI Class Initialized
INFO - 2020-02-27 06:07:13 --> Router Class Initialized
INFO - 2020-02-27 06:07:13 --> Output Class Initialized
INFO - 2020-02-27 06:07:13 --> Security Class Initialized
DEBUG - 2020-02-27 06:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:07:13 --> Input Class Initialized
INFO - 2020-02-27 06:07:13 --> Language Class Initialized
INFO - 2020-02-27 06:07:13 --> Loader Class Initialized
INFO - 2020-02-27 06:07:13 --> Helper loaded: url_helper
INFO - 2020-02-27 06:07:13 --> Helper loaded: string_helper
INFO - 2020-02-27 06:07:14 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:07:14 --> Controller Class Initialized
INFO - 2020-02-27 06:07:14 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:07:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:07:14 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:07:14 --> Helper loaded: form_helper
INFO - 2020-02-27 06:07:14 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:07:14 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 105
ERROR - 2020-02-27 06:07:14 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 107
ERROR - 2020-02-27 06:07:14 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
INFO - 2020-02-27 06:07:14 --> Final output sent to browser
DEBUG - 2020-02-27 06:07:14 --> Total execution time: 1.9776
INFO - 2020-02-27 06:08:46 --> Config Class Initialized
INFO - 2020-02-27 06:08:46 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:08:46 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:46 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:46 --> URI Class Initialized
DEBUG - 2020-02-27 06:08:46 --> No URI present. Default controller set.
INFO - 2020-02-27 06:08:46 --> Router Class Initialized
INFO - 2020-02-27 06:08:46 --> Output Class Initialized
INFO - 2020-02-27 06:08:46 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:46 --> Input Class Initialized
INFO - 2020-02-27 06:08:46 --> Language Class Initialized
INFO - 2020-02-27 06:08:47 --> Loader Class Initialized
INFO - 2020-02-27 06:08:47 --> Helper loaded: url_helper
INFO - 2020-02-27 06:08:47 --> Helper loaded: string_helper
INFO - 2020-02-27 06:08:47 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:08:47 --> Controller Class Initialized
INFO - 2020-02-27 06:08:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 06:08:47 --> Pagination Class Initialized
INFO - 2020-02-27 06:08:47 --> Model "M_show" initialized
INFO - 2020-02-27 06:08:47 --> Helper loaded: form_helper
INFO - 2020-02-27 06:08:47 --> Form Validation Class Initialized
INFO - 2020-02-27 06:08:47 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 06:08:47 --> Final output sent to browser
INFO - 2020-02-27 06:08:47 --> Config Class Initialized
INFO - 2020-02-27 06:08:47 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:08:47 --> Total execution time: 0.8953
DEBUG - 2020-02-27 06:08:47 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:47 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:47 --> URI Class Initialized
DEBUG - 2020-02-27 06:08:47 --> No URI present. Default controller set.
INFO - 2020-02-27 06:08:47 --> Router Class Initialized
INFO - 2020-02-27 06:08:47 --> Output Class Initialized
INFO - 2020-02-27 06:08:47 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:47 --> Input Class Initialized
INFO - 2020-02-27 06:08:47 --> Language Class Initialized
INFO - 2020-02-27 06:08:48 --> Loader Class Initialized
INFO - 2020-02-27 06:08:48 --> Helper loaded: url_helper
INFO - 2020-02-27 06:08:48 --> Helper loaded: string_helper
INFO - 2020-02-27 06:08:48 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:08:48 --> Controller Class Initialized
INFO - 2020-02-27 06:08:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 06:08:48 --> Pagination Class Initialized
INFO - 2020-02-27 06:08:48 --> Model "M_show" initialized
INFO - 2020-02-27 06:08:48 --> Helper loaded: form_helper
INFO - 2020-02-27 06:08:48 --> Form Validation Class Initialized
INFO - 2020-02-27 06:08:48 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 06:08:49 --> Final output sent to browser
DEBUG - 2020-02-27 06:08:49 --> Total execution time: 1.4765
INFO - 2020-02-27 06:08:52 --> Config Class Initialized
INFO - 2020-02-27 06:08:52 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:08:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:52 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:52 --> URI Class Initialized
INFO - 2020-02-27 06:08:52 --> Router Class Initialized
INFO - 2020-02-27 06:08:53 --> Output Class Initialized
INFO - 2020-02-27 06:08:53 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:53 --> Input Class Initialized
INFO - 2020-02-27 06:08:53 --> Language Class Initialized
INFO - 2020-02-27 06:08:53 --> Loader Class Initialized
INFO - 2020-02-27 06:08:53 --> Helper loaded: url_helper
INFO - 2020-02-27 06:08:53 --> Helper loaded: string_helper
INFO - 2020-02-27 06:08:53 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:08:53 --> Controller Class Initialized
INFO - 2020-02-27 06:08:53 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:08:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:08:53 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:08:53 --> Helper loaded: form_helper
INFO - 2020-02-27 06:08:53 --> Form Validation Class Initialized
INFO - 2020-02-27 06:08:53 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 06:08:53 --> Final output sent to browser
INFO - 2020-02-27 06:08:53 --> Config Class Initialized
INFO - 2020-02-27 06:08:53 --> Config Class Initialized
INFO - 2020-02-27 06:08:53 --> Config Class Initialized
INFO - 2020-02-27 06:08:53 --> Config Class Initialized
INFO - 2020-02-27 06:08:53 --> Hooks Class Initialized
INFO - 2020-02-27 06:08:53 --> Config Class Initialized
INFO - 2020-02-27 06:08:53 --> Hooks Class Initialized
INFO - 2020-02-27 06:08:53 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:08:53 --> Total execution time: 1.1407
INFO - 2020-02-27 06:08:53 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:08:53 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:53 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:53 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:08:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:08:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:08:53 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:53 --> Config Class Initialized
INFO - 2020-02-27 06:08:54 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:54 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
INFO - 2020-02-27 06:08:54 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:54 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:08:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
INFO - 2020-02-27 06:08:54 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:54 --> Router Class Initialized
DEBUG - 2020-02-27 06:08:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:54 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:54 --> Router Class Initialized
INFO - 2020-02-27 06:08:54 --> Router Class Initialized
INFO - 2020-02-27 06:08:54 --> Output Class Initialized
INFO - 2020-02-27 06:08:54 --> Router Class Initialized
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
INFO - 2020-02-27 06:08:54 --> Security Class Initialized
INFO - 2020-02-27 06:08:54 --> Router Class Initialized
INFO - 2020-02-27 06:08:54 --> Output Class Initialized
INFO - 2020-02-27 06:08:54 --> Output Class Initialized
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
INFO - 2020-02-27 06:08:54 --> Output Class Initialized
INFO - 2020-02-27 06:08:54 --> Security Class Initialized
INFO - 2020-02-27 06:08:54 --> Router Class Initialized
INFO - 2020-02-27 06:08:54 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:54 --> Security Class Initialized
INFO - 2020-02-27 06:08:54 --> Output Class Initialized
INFO - 2020-02-27 06:08:54 --> Input Class Initialized
DEBUG - 2020-02-27 06:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:54 --> Output Class Initialized
INFO - 2020-02-27 06:08:54 --> Security Class Initialized
INFO - 2020-02-27 06:08:54 --> Input Class Initialized
INFO - 2020-02-27 06:08:54 --> Input Class Initialized
INFO - 2020-02-27 06:08:54 --> Input Class Initialized
INFO - 2020-02-27 06:08:54 --> Language Class Initialized
INFO - 2020-02-27 06:08:54 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:54 --> Input Class Initialized
INFO - 2020-02-27 06:08:54 --> Language Class Initialized
INFO - 2020-02-27 06:08:54 --> Language Class Initialized
DEBUG - 2020-02-27 06:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:54 --> Language Class Initialized
ERROR - 2020-02-27 06:08:54 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-27 06:08:54 --> Input Class Initialized
ERROR - 2020-02-27 06:08:54 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 06:08:54 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 06:08:54 --> Language Class Initialized
ERROR - 2020-02-27 06:08:54 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 06:08:54 --> Config Class Initialized
INFO - 2020-02-27 06:08:54 --> Hooks Class Initialized
ERROR - 2020-02-27 06:08:54 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 06:08:54 --> Language Class Initialized
INFO - 2020-02-27 06:08:54 --> Config Class Initialized
INFO - 2020-02-27 06:08:54 --> Config Class Initialized
INFO - 2020-02-27 06:08:54 --> Config Class Initialized
INFO - 2020-02-27 06:08:54 --> Hooks Class Initialized
INFO - 2020-02-27 06:08:54 --> Hooks Class Initialized
INFO - 2020-02-27 06:08:54 --> Hooks Class Initialized
ERROR - 2020-02-27 06:08:54 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-27 06:08:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:54 --> Config Class Initialized
INFO - 2020-02-27 06:08:54 --> Hooks Class Initialized
INFO - 2020-02-27 06:08:54 --> Utf8 Class Initialized
DEBUG - 2020-02-27 06:08:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:08:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:08:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:54 --> Config Class Initialized
INFO - 2020-02-27 06:08:54 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:54 --> Hooks Class Initialized
INFO - 2020-02-27 06:08:54 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:54 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
DEBUG - 2020-02-27 06:08:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:54 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
INFO - 2020-02-27 06:08:54 --> Router Class Initialized
DEBUG - 2020-02-27 06:08:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:54 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:54 --> Router Class Initialized
INFO - 2020-02-27 06:08:54 --> Output Class Initialized
INFO - 2020-02-27 06:08:54 --> Router Class Initialized
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
INFO - 2020-02-27 06:08:54 --> Router Class Initialized
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
INFO - 2020-02-27 06:08:54 --> Output Class Initialized
INFO - 2020-02-27 06:08:54 --> Router Class Initialized
INFO - 2020-02-27 06:08:54 --> Output Class Initialized
INFO - 2020-02-27 06:08:54 --> Security Class Initialized
INFO - 2020-02-27 06:08:54 --> Output Class Initialized
DEBUG - 2020-02-27 06:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:54 --> Router Class Initialized
INFO - 2020-02-27 06:08:54 --> Security Class Initialized
INFO - 2020-02-27 06:08:54 --> Output Class Initialized
INFO - 2020-02-27 06:08:54 --> Security Class Initialized
INFO - 2020-02-27 06:08:54 --> Security Class Initialized
INFO - 2020-02-27 06:08:54 --> Input Class Initialized
DEBUG - 2020-02-27 06:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:54 --> Output Class Initialized
INFO - 2020-02-27 06:08:54 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:54 --> Input Class Initialized
INFO - 2020-02-27 06:08:54 --> Input Class Initialized
INFO - 2020-02-27 06:08:54 --> Input Class Initialized
INFO - 2020-02-27 06:08:54 --> Language Class Initialized
INFO - 2020-02-27 06:08:54 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:54 --> Input Class Initialized
INFO - 2020-02-27 06:08:54 --> Language Class Initialized
INFO - 2020-02-27 06:08:54 --> Language Class Initialized
DEBUG - 2020-02-27 06:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:54 --> Language Class Initialized
ERROR - 2020-02-27 06:08:54 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 06:08:54 --> Input Class Initialized
INFO - 2020-02-27 06:08:54 --> Language Class Initialized
ERROR - 2020-02-27 06:08:54 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-27 06:08:54 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 06:08:54 --> Loader Class Initialized
INFO - 2020-02-27 06:08:54 --> Config Class Initialized
INFO - 2020-02-27 06:08:54 --> Hooks Class Initialized
INFO - 2020-02-27 06:08:54 --> Helper loaded: url_helper
INFO - 2020-02-27 06:08:54 --> Language Class Initialized
INFO - 2020-02-27 06:08:54 --> Loader Class Initialized
INFO - 2020-02-27 06:08:54 --> Config Class Initialized
INFO - 2020-02-27 06:08:54 --> Hooks Class Initialized
INFO - 2020-02-27 06:08:54 --> Helper loaded: string_helper
INFO - 2020-02-27 06:08:54 --> Helper loaded: url_helper
ERROR - 2020-02-27 06:08:54 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-27 06:08:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:54 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:54 --> Helper loaded: string_helper
DEBUG - 2020-02-27 06:08:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:54 --> Database Driver Class Initialized
INFO - 2020-02-27 06:08:54 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
DEBUG - 2020-02-27 06:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:08:54 --> Database Driver Class Initialized
INFO - 2020-02-27 06:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:08:54 --> URI Class Initialized
INFO - 2020-02-27 06:08:54 --> Router Class Initialized
DEBUG - 2020-02-27 06:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:08:55 --> Controller Class Initialized
INFO - 2020-02-27 06:08:55 --> Router Class Initialized
INFO - 2020-02-27 06:08:55 --> Output Class Initialized
INFO - 2020-02-27 06:08:55 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:08:55 --> Security Class Initialized
INFO - 2020-02-27 06:08:55 --> Output Class Initialized
INFO - 2020-02-27 06:08:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:08:55 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:55 --> Input Class Initialized
INFO - 2020-02-27 06:08:55 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 06:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:55 --> Input Class Initialized
INFO - 2020-02-27 06:08:55 --> Language Class Initialized
INFO - 2020-02-27 06:08:55 --> Helper loaded: form_helper
INFO - 2020-02-27 06:08:55 --> Form Validation Class Initialized
INFO - 2020-02-27 06:08:55 --> Language Class Initialized
ERROR - 2020-02-27 06:08:55 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 06:08:55 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 06:08:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 06:08:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 06:08:55 --> Config Class Initialized
INFO - 2020-02-27 06:08:55 --> Hooks Class Initialized
INFO - 2020-02-27 06:08:55 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 06:08:55 --> Final output sent to browser
DEBUG - 2020-02-27 06:08:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:08:55 --> Total execution time: 1.2382
INFO - 2020-02-27 06:08:55 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:08:55 --> URI Class Initialized
INFO - 2020-02-27 06:08:55 --> Controller Class Initialized
INFO - 2020-02-27 06:08:55 --> Router Class Initialized
INFO - 2020-02-27 06:08:55 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:08:55 --> Output Class Initialized
INFO - 2020-02-27 06:08:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:08:55 --> Security Class Initialized
INFO - 2020-02-27 06:08:55 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 06:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:55 --> Input Class Initialized
INFO - 2020-02-27 06:08:55 --> Helper loaded: form_helper
INFO - 2020-02-27 06:08:55 --> Form Validation Class Initialized
INFO - 2020-02-27 06:08:55 --> Language Class Initialized
ERROR - 2020-02-27 06:08:55 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 06:08:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 06:08:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 06:08:55 --> Config Class Initialized
INFO - 2020-02-27 06:08:56 --> Hooks Class Initialized
INFO - 2020-02-27 06:08:56 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 06:08:56 --> Final output sent to browser
DEBUG - 2020-02-27 06:08:56 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:56 --> Utf8 Class Initialized
DEBUG - 2020-02-27 06:08:56 --> Total execution time: 1.6296
INFO - 2020-02-27 06:08:56 --> URI Class Initialized
INFO - 2020-02-27 06:08:56 --> Router Class Initialized
INFO - 2020-02-27 06:08:56 --> Output Class Initialized
INFO - 2020-02-27 06:08:56 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:56 --> Input Class Initialized
INFO - 2020-02-27 06:08:56 --> Language Class Initialized
ERROR - 2020-02-27 06:08:56 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 06:08:56 --> Config Class Initialized
INFO - 2020-02-27 06:08:56 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:08:56 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:56 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:56 --> URI Class Initialized
INFO - 2020-02-27 06:08:56 --> Router Class Initialized
INFO - 2020-02-27 06:08:56 --> Output Class Initialized
INFO - 2020-02-27 06:08:56 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:56 --> Input Class Initialized
INFO - 2020-02-27 06:08:56 --> Language Class Initialized
ERROR - 2020-02-27 06:08:56 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 06:08:56 --> Config Class Initialized
INFO - 2020-02-27 06:08:56 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:08:56 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:56 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:56 --> URI Class Initialized
INFO - 2020-02-27 06:08:57 --> Router Class Initialized
INFO - 2020-02-27 06:08:57 --> Output Class Initialized
INFO - 2020-02-27 06:08:57 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:57 --> Input Class Initialized
INFO - 2020-02-27 06:08:57 --> Language Class Initialized
ERROR - 2020-02-27 06:08:57 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 06:08:57 --> Config Class Initialized
INFO - 2020-02-27 06:08:57 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:08:57 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:57 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:57 --> URI Class Initialized
INFO - 2020-02-27 06:08:57 --> Router Class Initialized
INFO - 2020-02-27 06:08:57 --> Output Class Initialized
INFO - 2020-02-27 06:08:57 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:57 --> Input Class Initialized
INFO - 2020-02-27 06:08:57 --> Language Class Initialized
ERROR - 2020-02-27 06:08:57 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 06:08:57 --> Config Class Initialized
INFO - 2020-02-27 06:08:57 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:08:57 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:57 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:57 --> URI Class Initialized
INFO - 2020-02-27 06:08:57 --> Router Class Initialized
INFO - 2020-02-27 06:08:57 --> Output Class Initialized
INFO - 2020-02-27 06:08:57 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:58 --> Input Class Initialized
INFO - 2020-02-27 06:08:58 --> Language Class Initialized
ERROR - 2020-02-27 06:08:58 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 06:08:58 --> Config Class Initialized
INFO - 2020-02-27 06:08:58 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:08:58 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:58 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:58 --> URI Class Initialized
INFO - 2020-02-27 06:08:58 --> Router Class Initialized
INFO - 2020-02-27 06:08:58 --> Output Class Initialized
INFO - 2020-02-27 06:08:58 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:58 --> Input Class Initialized
INFO - 2020-02-27 06:08:58 --> Language Class Initialized
ERROR - 2020-02-27 06:08:58 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 06:08:58 --> Config Class Initialized
INFO - 2020-02-27 06:08:58 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:08:58 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:08:58 --> Utf8 Class Initialized
INFO - 2020-02-27 06:08:58 --> URI Class Initialized
INFO - 2020-02-27 06:08:58 --> Router Class Initialized
INFO - 2020-02-27 06:08:58 --> Output Class Initialized
INFO - 2020-02-27 06:08:58 --> Security Class Initialized
DEBUG - 2020-02-27 06:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:08:58 --> Input Class Initialized
INFO - 2020-02-27 06:08:58 --> Language Class Initialized
ERROR - 2020-02-27 06:08:58 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 06:09:23 --> Config Class Initialized
INFO - 2020-02-27 06:09:23 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:09:23 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:09:23 --> Utf8 Class Initialized
INFO - 2020-02-27 06:09:24 --> URI Class Initialized
INFO - 2020-02-27 06:09:24 --> Router Class Initialized
INFO - 2020-02-27 06:09:24 --> Output Class Initialized
INFO - 2020-02-27 06:09:24 --> Security Class Initialized
DEBUG - 2020-02-27 06:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:09:24 --> Input Class Initialized
INFO - 2020-02-27 06:09:24 --> Language Class Initialized
INFO - 2020-02-27 06:09:24 --> Loader Class Initialized
INFO - 2020-02-27 06:09:24 --> Helper loaded: url_helper
INFO - 2020-02-27 06:09:24 --> Helper loaded: string_helper
INFO - 2020-02-27 06:09:24 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:09:24 --> Controller Class Initialized
INFO - 2020-02-27 06:09:24 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:09:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:09:24 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:09:24 --> Helper loaded: form_helper
INFO - 2020-02-27 06:09:24 --> Form Validation Class Initialized
INFO - 2020-02-27 12:09:25 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 12:09:25 --> Final output sent to browser
DEBUG - 2020-02-27 12:09:25 --> Total execution time: 1.7683
INFO - 2020-02-27 06:09:28 --> Config Class Initialized
INFO - 2020-02-27 06:09:29 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:09:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:09:29 --> Utf8 Class Initialized
INFO - 2020-02-27 06:09:29 --> URI Class Initialized
INFO - 2020-02-27 06:09:29 --> Router Class Initialized
INFO - 2020-02-27 06:09:29 --> Output Class Initialized
INFO - 2020-02-27 06:09:29 --> Security Class Initialized
DEBUG - 2020-02-27 06:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:09:29 --> Input Class Initialized
INFO - 2020-02-27 06:09:29 --> Language Class Initialized
INFO - 2020-02-27 06:09:30 --> Loader Class Initialized
INFO - 2020-02-27 06:09:30 --> Helper loaded: url_helper
INFO - 2020-02-27 06:09:30 --> Helper loaded: string_helper
INFO - 2020-02-27 06:09:30 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:09:30 --> Controller Class Initialized
INFO - 2020-02-27 06:09:30 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:09:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:09:30 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:09:30 --> Helper loaded: form_helper
INFO - 2020-02-27 06:09:30 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:09:30 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 06:09:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 06:09:30 --> Final output sent to browser
DEBUG - 2020-02-27 06:09:30 --> Total execution time: 1.9210
INFO - 2020-02-27 06:09:37 --> Config Class Initialized
INFO - 2020-02-27 06:09:37 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:09:37 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:09:37 --> Utf8 Class Initialized
INFO - 2020-02-27 06:09:37 --> URI Class Initialized
INFO - 2020-02-27 06:09:37 --> Router Class Initialized
INFO - 2020-02-27 06:09:37 --> Output Class Initialized
INFO - 2020-02-27 06:09:37 --> Security Class Initialized
DEBUG - 2020-02-27 06:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:09:37 --> Input Class Initialized
INFO - 2020-02-27 06:09:37 --> Language Class Initialized
INFO - 2020-02-27 06:09:38 --> Loader Class Initialized
INFO - 2020-02-27 06:09:38 --> Helper loaded: url_helper
INFO - 2020-02-27 06:09:38 --> Helper loaded: string_helper
INFO - 2020-02-27 06:09:38 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:09:38 --> Controller Class Initialized
INFO - 2020-02-27 06:09:38 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:09:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:09:38 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:09:38 --> Helper loaded: form_helper
INFO - 2020-02-27 06:09:38 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:09:38 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 105
ERROR - 2020-02-27 06:09:38 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 107
ERROR - 2020-02-27 06:09:38 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
INFO - 2020-02-27 06:09:38 --> Final output sent to browser
DEBUG - 2020-02-27 06:09:38 --> Total execution time: 1.4632
INFO - 2020-02-27 06:12:48 --> Config Class Initialized
INFO - 2020-02-27 06:12:48 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:12:48 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:12:48 --> Utf8 Class Initialized
INFO - 2020-02-27 06:12:48 --> URI Class Initialized
INFO - 2020-02-27 06:12:48 --> Router Class Initialized
INFO - 2020-02-27 06:12:48 --> Output Class Initialized
INFO - 2020-02-27 06:12:48 --> Security Class Initialized
DEBUG - 2020-02-27 06:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:12:48 --> Input Class Initialized
INFO - 2020-02-27 06:12:48 --> Language Class Initialized
INFO - 2020-02-27 06:12:48 --> Loader Class Initialized
INFO - 2020-02-27 06:12:48 --> Helper loaded: url_helper
INFO - 2020-02-27 06:12:48 --> Helper loaded: string_helper
INFO - 2020-02-27 06:12:48 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:12:48 --> Controller Class Initialized
INFO - 2020-02-27 06:12:48 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:12:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:12:48 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:12:48 --> Helper loaded: form_helper
INFO - 2020-02-27 06:12:48 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:12:48 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 62
ERROR - 2020-02-27 06:12:48 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 63
ERROR - 2020-02-27 06:12:48 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 105
ERROR - 2020-02-27 06:12:48 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 107
ERROR - 2020-02-27 06:12:49 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
INFO - 2020-02-27 06:12:49 --> Final output sent to browser
DEBUG - 2020-02-27 06:12:49 --> Total execution time: 0.9296
INFO - 2020-02-27 06:12:59 --> Config Class Initialized
INFO - 2020-02-27 06:12:59 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:12:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:12:59 --> Config Class Initialized
INFO - 2020-02-27 06:12:59 --> Hooks Class Initialized
INFO - 2020-02-27 06:12:59 --> Utf8 Class Initialized
INFO - 2020-02-27 06:12:59 --> URI Class Initialized
DEBUG - 2020-02-27 06:12:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:12:59 --> Utf8 Class Initialized
INFO - 2020-02-27 06:12:59 --> Router Class Initialized
INFO - 2020-02-27 06:12:59 --> URI Class Initialized
INFO - 2020-02-27 06:12:59 --> Output Class Initialized
INFO - 2020-02-27 06:12:59 --> Security Class Initialized
DEBUG - 2020-02-27 06:12:59 --> No URI present. Default controller set.
INFO - 2020-02-27 06:12:59 --> Router Class Initialized
DEBUG - 2020-02-27 06:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:12:59 --> Input Class Initialized
INFO - 2020-02-27 06:12:59 --> Output Class Initialized
INFO - 2020-02-27 06:12:59 --> Language Class Initialized
INFO - 2020-02-27 06:12:59 --> Security Class Initialized
DEBUG - 2020-02-27 06:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:12:59 --> Loader Class Initialized
INFO - 2020-02-27 06:12:59 --> Input Class Initialized
INFO - 2020-02-27 06:12:59 --> Helper loaded: url_helper
INFO - 2020-02-27 06:12:59 --> Language Class Initialized
INFO - 2020-02-27 06:12:59 --> Helper loaded: string_helper
INFO - 2020-02-27 06:12:59 --> Loader Class Initialized
INFO - 2020-02-27 06:12:59 --> Database Driver Class Initialized
INFO - 2020-02-27 06:12:59 --> Helper loaded: url_helper
DEBUG - 2020-02-27 06:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:12:59 --> Helper loaded: string_helper
INFO - 2020-02-27 06:12:59 --> Controller Class Initialized
INFO - 2020-02-27 06:12:59 --> Database Driver Class Initialized
INFO - 2020-02-27 06:12:59 --> Model "M_tiket" initialized
DEBUG - 2020-02-27 06:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:12:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:12:59 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:12:59 --> Helper loaded: form_helper
INFO - 2020-02-27 06:12:59 --> Form Validation Class Initialized
INFO - 2020-02-27 06:12:59 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 06:13:00 --> Final output sent to browser
DEBUG - 2020-02-27 06:13:00 --> Total execution time: 0.8762
INFO - 2020-02-27 06:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:13:00 --> Controller Class Initialized
INFO - 2020-02-27 06:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 06:13:00 --> Pagination Class Initialized
INFO - 2020-02-27 06:13:00 --> Model "M_show" initialized
INFO - 2020-02-27 06:13:00 --> Helper loaded: form_helper
INFO - 2020-02-27 06:13:00 --> Form Validation Class Initialized
INFO - 2020-02-27 06:13:00 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 06:13:00 --> Final output sent to browser
DEBUG - 2020-02-27 06:13:00 --> Total execution time: 1.1979
INFO - 2020-02-27 06:13:05 --> Config Class Initialized
INFO - 2020-02-27 06:13:05 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:05 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:05 --> URI Class Initialized
DEBUG - 2020-02-27 06:13:05 --> No URI present. Default controller set.
INFO - 2020-02-27 06:13:05 --> Router Class Initialized
INFO - 2020-02-27 06:13:05 --> Output Class Initialized
INFO - 2020-02-27 06:13:05 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:05 --> Input Class Initialized
INFO - 2020-02-27 06:13:05 --> Language Class Initialized
INFO - 2020-02-27 06:13:05 --> Loader Class Initialized
INFO - 2020-02-27 06:13:05 --> Helper loaded: url_helper
INFO - 2020-02-27 06:13:05 --> Helper loaded: string_helper
INFO - 2020-02-27 06:13:05 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:13:05 --> Controller Class Initialized
INFO - 2020-02-27 06:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 06:13:06 --> Pagination Class Initialized
INFO - 2020-02-27 06:13:06 --> Model "M_show" initialized
INFO - 2020-02-27 06:13:06 --> Helper loaded: form_helper
INFO - 2020-02-27 06:13:06 --> Form Validation Class Initialized
INFO - 2020-02-27 06:13:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 06:13:06 --> Final output sent to browser
DEBUG - 2020-02-27 06:13:06 --> Total execution time: 0.9727
INFO - 2020-02-27 06:13:07 --> Config Class Initialized
INFO - 2020-02-27 06:13:07 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:07 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:07 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:07 --> URI Class Initialized
DEBUG - 2020-02-27 06:13:07 --> No URI present. Default controller set.
INFO - 2020-02-27 06:13:07 --> Router Class Initialized
INFO - 2020-02-27 06:13:07 --> Output Class Initialized
INFO - 2020-02-27 06:13:07 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:07 --> Input Class Initialized
INFO - 2020-02-27 06:13:07 --> Language Class Initialized
INFO - 2020-02-27 06:13:07 --> Loader Class Initialized
INFO - 2020-02-27 06:13:07 --> Helper loaded: url_helper
INFO - 2020-02-27 06:13:07 --> Helper loaded: string_helper
INFO - 2020-02-27 06:13:07 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:13:08 --> Controller Class Initialized
INFO - 2020-02-27 06:13:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 06:13:08 --> Pagination Class Initialized
INFO - 2020-02-27 06:13:08 --> Model "M_show" initialized
INFO - 2020-02-27 06:13:08 --> Helper loaded: form_helper
INFO - 2020-02-27 06:13:08 --> Form Validation Class Initialized
INFO - 2020-02-27 06:13:08 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 06:13:08 --> Final output sent to browser
DEBUG - 2020-02-27 06:13:08 --> Total execution time: 1.1594
INFO - 2020-02-27 06:13:12 --> Config Class Initialized
INFO - 2020-02-27 06:13:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:12 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:12 --> URI Class Initialized
INFO - 2020-02-27 06:13:13 --> Router Class Initialized
INFO - 2020-02-27 06:13:13 --> Output Class Initialized
INFO - 2020-02-27 06:13:13 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:13 --> Input Class Initialized
INFO - 2020-02-27 06:13:13 --> Language Class Initialized
INFO - 2020-02-27 06:13:13 --> Loader Class Initialized
INFO - 2020-02-27 06:13:13 --> Helper loaded: url_helper
INFO - 2020-02-27 06:13:13 --> Helper loaded: string_helper
INFO - 2020-02-27 06:13:13 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:13:13 --> Controller Class Initialized
INFO - 2020-02-27 06:13:13 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:13:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:13:13 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:13:14 --> Helper loaded: form_helper
INFO - 2020-02-27 06:13:14 --> Form Validation Class Initialized
INFO - 2020-02-27 06:13:14 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 06:13:14 --> Final output sent to browser
DEBUG - 2020-02-27 06:13:14 --> Total execution time: 1.6221
INFO - 2020-02-27 06:13:14 --> Config Class Initialized
INFO - 2020-02-27 06:13:14 --> Config Class Initialized
INFO - 2020-02-27 06:13:14 --> Config Class Initialized
INFO - 2020-02-27 06:13:14 --> Config Class Initialized
INFO - 2020-02-27 06:13:14 --> Config Class Initialized
INFO - 2020-02-27 06:13:14 --> Config Class Initialized
INFO - 2020-02-27 06:13:14 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:14 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:14 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:14 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:14 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:14 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:13:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:14 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:14 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:14 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:14 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:14 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:14 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:14 --> URI Class Initialized
INFO - 2020-02-27 06:13:14 --> URI Class Initialized
INFO - 2020-02-27 06:13:14 --> URI Class Initialized
INFO - 2020-02-27 06:13:14 --> URI Class Initialized
INFO - 2020-02-27 06:13:14 --> URI Class Initialized
INFO - 2020-02-27 06:13:14 --> URI Class Initialized
INFO - 2020-02-27 06:13:14 --> Router Class Initialized
INFO - 2020-02-27 06:13:14 --> Router Class Initialized
INFO - 2020-02-27 06:13:14 --> Router Class Initialized
INFO - 2020-02-27 06:13:14 --> Router Class Initialized
INFO - 2020-02-27 06:13:14 --> Router Class Initialized
INFO - 2020-02-27 06:13:14 --> Router Class Initialized
INFO - 2020-02-27 06:13:14 --> Output Class Initialized
INFO - 2020-02-27 06:13:14 --> Output Class Initialized
INFO - 2020-02-27 06:13:14 --> Output Class Initialized
INFO - 2020-02-27 06:13:14 --> Output Class Initialized
INFO - 2020-02-27 06:13:14 --> Output Class Initialized
INFO - 2020-02-27 06:13:14 --> Output Class Initialized
INFO - 2020-02-27 06:13:14 --> Security Class Initialized
INFO - 2020-02-27 06:13:14 --> Security Class Initialized
INFO - 2020-02-27 06:13:14 --> Security Class Initialized
INFO - 2020-02-27 06:13:14 --> Security Class Initialized
INFO - 2020-02-27 06:13:14 --> Security Class Initialized
INFO - 2020-02-27 06:13:14 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:14 --> Input Class Initialized
INFO - 2020-02-27 06:13:14 --> Input Class Initialized
INFO - 2020-02-27 06:13:14 --> Input Class Initialized
INFO - 2020-02-27 06:13:14 --> Input Class Initialized
INFO - 2020-02-27 06:13:14 --> Input Class Initialized
INFO - 2020-02-27 06:13:14 --> Input Class Initialized
INFO - 2020-02-27 06:13:14 --> Language Class Initialized
INFO - 2020-02-27 06:13:14 --> Language Class Initialized
INFO - 2020-02-27 06:13:14 --> Language Class Initialized
INFO - 2020-02-27 06:13:14 --> Language Class Initialized
INFO - 2020-02-27 06:13:14 --> Language Class Initialized
INFO - 2020-02-27 06:13:14 --> Language Class Initialized
ERROR - 2020-02-27 06:13:14 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 06:13:14 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-27 06:13:14 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 06:13:14 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-27 06:13:14 --> Loader Class Initialized
ERROR - 2020-02-27 06:13:14 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 06:13:14 --> Helper loaded: url_helper
INFO - 2020-02-27 06:13:14 --> Config Class Initialized
INFO - 2020-02-27 06:13:14 --> Config Class Initialized
INFO - 2020-02-27 06:13:14 --> Config Class Initialized
INFO - 2020-02-27 06:13:14 --> Config Class Initialized
INFO - 2020-02-27 06:13:14 --> Config Class Initialized
INFO - 2020-02-27 06:13:14 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:14 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:14 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:14 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:14 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:14 --> Helper loaded: string_helper
DEBUG - 2020-02-27 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:13:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:14 --> Database Driver Class Initialized
INFO - 2020-02-27 06:13:14 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:14 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:14 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:14 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:14 --> Utf8 Class Initialized
DEBUG - 2020-02-27 06:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:13:14 --> URI Class Initialized
INFO - 2020-02-27 06:13:14 --> URI Class Initialized
INFO - 2020-02-27 06:13:14 --> URI Class Initialized
INFO - 2020-02-27 06:13:14 --> URI Class Initialized
INFO - 2020-02-27 06:13:14 --> URI Class Initialized
INFO - 2020-02-27 06:13:14 --> Controller Class Initialized
INFO - 2020-02-27 06:13:14 --> Router Class Initialized
INFO - 2020-02-27 06:13:14 --> Router Class Initialized
INFO - 2020-02-27 06:13:14 --> Router Class Initialized
INFO - 2020-02-27 06:13:14 --> Router Class Initialized
INFO - 2020-02-27 06:13:14 --> Router Class Initialized
INFO - 2020-02-27 06:13:14 --> Output Class Initialized
INFO - 2020-02-27 06:13:14 --> Output Class Initialized
INFO - 2020-02-27 06:13:15 --> Output Class Initialized
INFO - 2020-02-27 06:13:15 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:13:15 --> Output Class Initialized
INFO - 2020-02-27 06:13:15 --> Output Class Initialized
INFO - 2020-02-27 06:13:15 --> Security Class Initialized
INFO - 2020-02-27 06:13:15 --> Security Class Initialized
INFO - 2020-02-27 06:13:15 --> Security Class Initialized
INFO - 2020-02-27 06:13:15 --> Security Class Initialized
INFO - 2020-02-27 06:13:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:13:15 --> Security Class Initialized
INFO - 2020-02-27 06:13:15 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 06:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:15 --> Input Class Initialized
INFO - 2020-02-27 06:13:15 --> Input Class Initialized
INFO - 2020-02-27 06:13:15 --> Input Class Initialized
INFO - 2020-02-27 06:13:15 --> Input Class Initialized
INFO - 2020-02-27 06:13:15 --> Input Class Initialized
INFO - 2020-02-27 06:13:15 --> Helper loaded: form_helper
INFO - 2020-02-27 06:13:15 --> Form Validation Class Initialized
INFO - 2020-02-27 06:13:15 --> Language Class Initialized
INFO - 2020-02-27 06:13:15 --> Language Class Initialized
INFO - 2020-02-27 06:13:15 --> Language Class Initialized
INFO - 2020-02-27 06:13:15 --> Language Class Initialized
INFO - 2020-02-27 06:13:15 --> Language Class Initialized
ERROR - 2020-02-27 06:13:15 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 06:13:15 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 06:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 06:13:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-27 06:13:15 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 06:13:15 --> Loader Class Initialized
ERROR - 2020-02-27 06:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 06:13:15 --> Helper loaded: url_helper
INFO - 2020-02-27 06:13:15 --> Config Class Initialized
INFO - 2020-02-27 06:13:15 --> Config Class Initialized
INFO - 2020-02-27 06:13:15 --> Config Class Initialized
INFO - 2020-02-27 06:13:15 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:15 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:15 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 06:13:15 --> Helper loaded: string_helper
INFO - 2020-02-27 06:13:15 --> Final output sent to browser
DEBUG - 2020-02-27 06:13:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:13:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 06:13:15 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:15 --> Database Driver Class Initialized
INFO - 2020-02-27 06:13:15 --> Utf8 Class Initialized
DEBUG - 2020-02-27 06:13:15 --> Total execution time: 1.0776
INFO - 2020-02-27 06:13:15 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:15 --> Utf8 Class Initialized
DEBUG - 2020-02-27 06:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:13:15 --> URI Class Initialized
INFO - 2020-02-27 06:13:15 --> URI Class Initialized
INFO - 2020-02-27 06:13:15 --> URI Class Initialized
INFO - 2020-02-27 06:13:15 --> Controller Class Initialized
INFO - 2020-02-27 06:13:15 --> Router Class Initialized
INFO - 2020-02-27 06:13:15 --> Router Class Initialized
INFO - 2020-02-27 06:13:15 --> Router Class Initialized
INFO - 2020-02-27 06:13:15 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:13:15 --> Output Class Initialized
INFO - 2020-02-27 06:13:15 --> Output Class Initialized
INFO - 2020-02-27 06:13:15 --> Output Class Initialized
INFO - 2020-02-27 06:13:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:13:15 --> Security Class Initialized
INFO - 2020-02-27 06:13:15 --> Security Class Initialized
INFO - 2020-02-27 06:13:15 --> Security Class Initialized
INFO - 2020-02-27 06:13:15 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 06:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 06:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:15 --> Input Class Initialized
INFO - 2020-02-27 06:13:15 --> Input Class Initialized
INFO - 2020-02-27 06:13:15 --> Input Class Initialized
INFO - 2020-02-27 06:13:15 --> Helper loaded: form_helper
INFO - 2020-02-27 06:13:15 --> Form Validation Class Initialized
INFO - 2020-02-27 06:13:15 --> Language Class Initialized
INFO - 2020-02-27 06:13:15 --> Language Class Initialized
INFO - 2020-02-27 06:13:15 --> Language Class Initialized
ERROR - 2020-02-27 06:13:15 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 06:13:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-27 06:13:15 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 06:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 06:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 06:13:16 --> Config Class Initialized
INFO - 2020-02-27 06:13:16 --> Hooks Class Initialized
INFO - 2020-02-27 06:13:16 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 06:13:16 --> Final output sent to browser
DEBUG - 2020-02-27 06:13:16 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:16 --> Utf8 Class Initialized
DEBUG - 2020-02-27 06:13:16 --> Total execution time: 1.3053
INFO - 2020-02-27 06:13:16 --> URI Class Initialized
INFO - 2020-02-27 06:13:16 --> Router Class Initialized
INFO - 2020-02-27 06:13:16 --> Output Class Initialized
INFO - 2020-02-27 06:13:16 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:16 --> Input Class Initialized
INFO - 2020-02-27 06:13:16 --> Language Class Initialized
ERROR - 2020-02-27 06:13:16 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 06:13:16 --> Config Class Initialized
INFO - 2020-02-27 06:13:16 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:17 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:17 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:17 --> URI Class Initialized
INFO - 2020-02-27 06:13:17 --> Router Class Initialized
INFO - 2020-02-27 06:13:17 --> Output Class Initialized
INFO - 2020-02-27 06:13:17 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:17 --> Input Class Initialized
INFO - 2020-02-27 06:13:17 --> Language Class Initialized
ERROR - 2020-02-27 06:13:17 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 06:13:17 --> Config Class Initialized
INFO - 2020-02-27 06:13:17 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:17 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:17 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:17 --> URI Class Initialized
INFO - 2020-02-27 06:13:17 --> Router Class Initialized
INFO - 2020-02-27 06:13:17 --> Output Class Initialized
INFO - 2020-02-27 06:13:17 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:17 --> Input Class Initialized
INFO - 2020-02-27 06:13:17 --> Language Class Initialized
ERROR - 2020-02-27 06:13:17 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 06:13:18 --> Config Class Initialized
INFO - 2020-02-27 06:13:18 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:18 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:18 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:18 --> URI Class Initialized
INFO - 2020-02-27 06:13:18 --> Router Class Initialized
INFO - 2020-02-27 06:13:18 --> Output Class Initialized
INFO - 2020-02-27 06:13:18 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:18 --> Input Class Initialized
INFO - 2020-02-27 06:13:18 --> Language Class Initialized
ERROR - 2020-02-27 06:13:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 06:13:18 --> Config Class Initialized
INFO - 2020-02-27 06:13:18 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:18 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:18 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:18 --> URI Class Initialized
INFO - 2020-02-27 06:13:18 --> Router Class Initialized
INFO - 2020-02-27 06:13:18 --> Output Class Initialized
INFO - 2020-02-27 06:13:18 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:18 --> Input Class Initialized
INFO - 2020-02-27 06:13:18 --> Language Class Initialized
ERROR - 2020-02-27 06:13:18 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 06:13:18 --> Config Class Initialized
INFO - 2020-02-27 06:13:18 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:18 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:18 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:18 --> URI Class Initialized
INFO - 2020-02-27 06:13:18 --> Router Class Initialized
INFO - 2020-02-27 06:13:19 --> Output Class Initialized
INFO - 2020-02-27 06:13:19 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:19 --> Input Class Initialized
INFO - 2020-02-27 06:13:19 --> Language Class Initialized
ERROR - 2020-02-27 06:13:19 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 06:13:19 --> Config Class Initialized
INFO - 2020-02-27 06:13:19 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:19 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:19 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:19 --> URI Class Initialized
INFO - 2020-02-27 06:13:19 --> Router Class Initialized
INFO - 2020-02-27 06:13:19 --> Output Class Initialized
INFO - 2020-02-27 06:13:19 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:19 --> Input Class Initialized
INFO - 2020-02-27 06:13:19 --> Language Class Initialized
ERROR - 2020-02-27 06:13:19 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 06:13:19 --> Config Class Initialized
INFO - 2020-02-27 06:13:19 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:19 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:19 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:19 --> URI Class Initialized
INFO - 2020-02-27 06:13:19 --> Router Class Initialized
INFO - 2020-02-27 06:13:19 --> Output Class Initialized
INFO - 2020-02-27 06:13:19 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:20 --> Input Class Initialized
INFO - 2020-02-27 06:13:20 --> Language Class Initialized
ERROR - 2020-02-27 06:13:20 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 06:13:38 --> Config Class Initialized
INFO - 2020-02-27 06:13:38 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:38 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:38 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:38 --> URI Class Initialized
INFO - 2020-02-27 06:13:38 --> Router Class Initialized
INFO - 2020-02-27 06:13:38 --> Output Class Initialized
INFO - 2020-02-27 06:13:38 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:38 --> Input Class Initialized
INFO - 2020-02-27 06:13:38 --> Language Class Initialized
INFO - 2020-02-27 06:13:38 --> Loader Class Initialized
INFO - 2020-02-27 06:13:38 --> Helper loaded: url_helper
INFO - 2020-02-27 06:13:38 --> Helper loaded: string_helper
INFO - 2020-02-27 06:13:38 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:13:38 --> Controller Class Initialized
INFO - 2020-02-27 06:13:38 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:13:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:13:38 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:13:38 --> Helper loaded: form_helper
INFO - 2020-02-27 06:13:38 --> Form Validation Class Initialized
INFO - 2020-02-27 12:13:39 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 12:13:39 --> Final output sent to browser
DEBUG - 2020-02-27 12:13:39 --> Total execution time: 1.0963
INFO - 2020-02-27 06:13:42 --> Config Class Initialized
INFO - 2020-02-27 06:13:42 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:42 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:42 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:42 --> URI Class Initialized
INFO - 2020-02-27 06:13:42 --> Router Class Initialized
INFO - 2020-02-27 06:13:42 --> Output Class Initialized
INFO - 2020-02-27 06:13:42 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:42 --> Input Class Initialized
INFO - 2020-02-27 06:13:42 --> Language Class Initialized
INFO - 2020-02-27 06:13:42 --> Loader Class Initialized
INFO - 2020-02-27 06:13:42 --> Helper loaded: url_helper
INFO - 2020-02-27 06:13:42 --> Helper loaded: string_helper
INFO - 2020-02-27 06:13:42 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:13:42 --> Controller Class Initialized
INFO - 2020-02-27 06:13:43 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:13:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:13:43 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:13:43 --> Helper loaded: form_helper
INFO - 2020-02-27 06:13:43 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:13:43 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 06:13:43 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 06:13:43 --> Final output sent to browser
DEBUG - 2020-02-27 06:13:43 --> Total execution time: 0.8941
INFO - 2020-02-27 06:13:49 --> Config Class Initialized
INFO - 2020-02-27 06:13:49 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:13:49 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:13:49 --> Utf8 Class Initialized
INFO - 2020-02-27 06:13:49 --> URI Class Initialized
INFO - 2020-02-27 06:13:49 --> Router Class Initialized
INFO - 2020-02-27 06:13:49 --> Output Class Initialized
INFO - 2020-02-27 06:13:49 --> Security Class Initialized
DEBUG - 2020-02-27 06:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:13:49 --> Input Class Initialized
INFO - 2020-02-27 06:13:49 --> Language Class Initialized
INFO - 2020-02-27 06:13:50 --> Loader Class Initialized
INFO - 2020-02-27 06:13:50 --> Helper loaded: url_helper
INFO - 2020-02-27 06:13:50 --> Helper loaded: string_helper
INFO - 2020-02-27 06:13:50 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:13:50 --> Controller Class Initialized
INFO - 2020-02-27 06:13:50 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:13:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:13:50 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:13:50 --> Helper loaded: form_helper
INFO - 2020-02-27 06:13:50 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:13:50 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 62
ERROR - 2020-02-27 06:13:50 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 63
ERROR - 2020-02-27 06:13:50 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 105
ERROR - 2020-02-27 06:13:50 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 107
ERROR - 2020-02-27 06:13:50 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
INFO - 2020-02-27 06:13:50 --> Final output sent to browser
DEBUG - 2020-02-27 06:13:50 --> Total execution time: 1.1917
INFO - 2020-02-27 06:16:59 --> Config Class Initialized
INFO - 2020-02-27 06:16:59 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:16:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:16:59 --> Utf8 Class Initialized
INFO - 2020-02-27 06:16:59 --> URI Class Initialized
INFO - 2020-02-27 06:16:59 --> Router Class Initialized
INFO - 2020-02-27 06:16:59 --> Output Class Initialized
INFO - 2020-02-27 06:16:59 --> Security Class Initialized
DEBUG - 2020-02-27 06:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:16:59 --> Input Class Initialized
INFO - 2020-02-27 06:16:59 --> Language Class Initialized
INFO - 2020-02-27 06:16:59 --> Loader Class Initialized
INFO - 2020-02-27 06:16:59 --> Helper loaded: url_helper
INFO - 2020-02-27 06:16:59 --> Helper loaded: string_helper
INFO - 2020-02-27 06:16:59 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:17:00 --> Controller Class Initialized
INFO - 2020-02-27 06:17:00 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:17:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:17:00 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:17:00 --> Helper loaded: form_helper
INFO - 2020-02-27 06:17:00 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:17:00 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 105
ERROR - 2020-02-27 06:17:00 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 107
ERROR - 2020-02-27 06:17:00 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
INFO - 2020-02-27 06:17:00 --> Final output sent to browser
DEBUG - 2020-02-27 06:17:00 --> Total execution time: 0.9190
INFO - 2020-02-27 06:20:30 --> Config Class Initialized
INFO - 2020-02-27 06:20:30 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:20:30 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:20:30 --> Utf8 Class Initialized
INFO - 2020-02-27 06:20:30 --> URI Class Initialized
INFO - 2020-02-27 06:20:30 --> Router Class Initialized
INFO - 2020-02-27 06:20:30 --> Output Class Initialized
INFO - 2020-02-27 06:20:30 --> Security Class Initialized
DEBUG - 2020-02-27 06:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:20:30 --> Input Class Initialized
INFO - 2020-02-27 06:20:30 --> Language Class Initialized
INFO - 2020-02-27 06:20:30 --> Loader Class Initialized
INFO - 2020-02-27 06:20:30 --> Helper loaded: url_helper
INFO - 2020-02-27 06:20:30 --> Helper loaded: string_helper
INFO - 2020-02-27 06:20:30 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:20:31 --> Controller Class Initialized
INFO - 2020-02-27 06:20:31 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:20:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:20:31 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:20:31 --> Helper loaded: form_helper
INFO - 2020-02-27 06:20:31 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:20:31 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 105
ERROR - 2020-02-27 06:20:31 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 107
ERROR - 2020-02-27 06:20:31 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
INFO - 2020-02-27 06:20:31 --> Final output sent to browser
DEBUG - 2020-02-27 06:20:31 --> Total execution time: 0.8923
INFO - 2020-02-27 06:27:37 --> Config Class Initialized
INFO - 2020-02-27 06:27:37 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:27:37 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:27:37 --> Utf8 Class Initialized
INFO - 2020-02-27 06:27:37 --> URI Class Initialized
INFO - 2020-02-27 06:27:37 --> Router Class Initialized
INFO - 2020-02-27 06:27:37 --> Output Class Initialized
INFO - 2020-02-27 06:27:37 --> Security Class Initialized
DEBUG - 2020-02-27 06:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:27:37 --> Input Class Initialized
INFO - 2020-02-27 06:27:37 --> Language Class Initialized
INFO - 2020-02-27 06:27:37 --> Loader Class Initialized
INFO - 2020-02-27 06:27:38 --> Helper loaded: url_helper
INFO - 2020-02-27 06:27:38 --> Helper loaded: string_helper
INFO - 2020-02-27 06:27:38 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:27:38 --> Controller Class Initialized
INFO - 2020-02-27 06:27:38 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:27:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:27:38 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:27:38 --> Helper loaded: form_helper
INFO - 2020-02-27 06:27:38 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:27:38 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
INFO - 2020-02-27 06:27:38 --> Final output sent to browser
DEBUG - 2020-02-27 06:27:38 --> Total execution time: 0.9085
INFO - 2020-02-27 06:27:57 --> Config Class Initialized
INFO - 2020-02-27 06:27:57 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:27:57 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:27:57 --> Utf8 Class Initialized
INFO - 2020-02-27 06:27:57 --> URI Class Initialized
INFO - 2020-02-27 06:27:57 --> Router Class Initialized
INFO - 2020-02-27 06:27:57 --> Output Class Initialized
INFO - 2020-02-27 06:27:57 --> Security Class Initialized
DEBUG - 2020-02-27 06:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:27:57 --> Input Class Initialized
INFO - 2020-02-27 06:27:57 --> Language Class Initialized
INFO - 2020-02-27 06:27:57 --> Loader Class Initialized
INFO - 2020-02-27 06:27:57 --> Helper loaded: url_helper
INFO - 2020-02-27 06:27:57 --> Helper loaded: string_helper
INFO - 2020-02-27 06:27:57 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:27:57 --> Controller Class Initialized
INFO - 2020-02-27 06:27:58 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:27:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:27:58 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:27:58 --> Helper loaded: form_helper
INFO - 2020-02-27 06:27:58 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:27:58 --> Severity: Notice --> Undefined variable: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
INFO - 2020-02-27 06:27:58 --> Final output sent to browser
DEBUG - 2020-02-27 06:27:58 --> Total execution time: 0.8200
INFO - 2020-02-27 06:29:09 --> Config Class Initialized
INFO - 2020-02-27 06:29:09 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:29:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:29:09 --> Utf8 Class Initialized
INFO - 2020-02-27 06:29:09 --> URI Class Initialized
INFO - 2020-02-27 06:29:09 --> Router Class Initialized
INFO - 2020-02-27 06:29:09 --> Output Class Initialized
INFO - 2020-02-27 06:29:09 --> Security Class Initialized
DEBUG - 2020-02-27 06:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:29:09 --> Input Class Initialized
INFO - 2020-02-27 06:29:09 --> Language Class Initialized
INFO - 2020-02-27 06:29:09 --> Loader Class Initialized
INFO - 2020-02-27 06:29:09 --> Helper loaded: url_helper
INFO - 2020-02-27 06:29:09 --> Helper loaded: string_helper
INFO - 2020-02-27 06:29:09 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:29:09 --> Controller Class Initialized
INFO - 2020-02-27 06:29:09 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:29:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 06:29:09 --> Model "M_pesan" initialized
INFO - 2020-02-27 06:29:09 --> Helper loaded: form_helper
INFO - 2020-02-27 06:29:09 --> Form Validation Class Initialized
ERROR - 2020-02-27 06:29:09 --> Severity: Notice --> Undefined variable: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
INFO - 2020-02-27 06:29:09 --> Final output sent to browser
DEBUG - 2020-02-27 06:29:09 --> Total execution time: 0.8230
INFO - 2020-02-27 06:30:16 --> Config Class Initialized
INFO - 2020-02-27 06:30:17 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:30:17 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:30:17 --> Utf8 Class Initialized
INFO - 2020-02-27 06:30:17 --> URI Class Initialized
INFO - 2020-02-27 06:30:17 --> Router Class Initialized
INFO - 2020-02-27 06:30:17 --> Output Class Initialized
INFO - 2020-02-27 06:30:17 --> Security Class Initialized
DEBUG - 2020-02-27 06:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:30:17 --> Input Class Initialized
INFO - 2020-02-27 06:30:17 --> Language Class Initialized
INFO - 2020-02-27 06:30:17 --> Loader Class Initialized
INFO - 2020-02-27 06:30:17 --> Helper loaded: url_helper
INFO - 2020-02-27 06:30:17 --> Helper loaded: string_helper
INFO - 2020-02-27 06:30:17 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:30:17 --> Controller Class Initialized
INFO - 2020-02-27 06:30:17 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:30:17 --> Model "M_pengunjung" initialized
ERROR - 2020-02-27 06:30:18 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 106
INFO - 2020-02-27 06:30:55 --> Config Class Initialized
INFO - 2020-02-27 06:30:55 --> Hooks Class Initialized
DEBUG - 2020-02-27 06:30:55 --> UTF-8 Support Enabled
INFO - 2020-02-27 06:30:55 --> Utf8 Class Initialized
INFO - 2020-02-27 06:30:55 --> URI Class Initialized
INFO - 2020-02-27 06:30:55 --> Router Class Initialized
INFO - 2020-02-27 06:30:55 --> Output Class Initialized
INFO - 2020-02-27 06:30:55 --> Security Class Initialized
DEBUG - 2020-02-27 06:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 06:30:55 --> Input Class Initialized
INFO - 2020-02-27 06:30:55 --> Language Class Initialized
INFO - 2020-02-27 06:30:55 --> Loader Class Initialized
INFO - 2020-02-27 06:30:55 --> Helper loaded: url_helper
INFO - 2020-02-27 06:30:55 --> Helper loaded: string_helper
INFO - 2020-02-27 06:30:55 --> Database Driver Class Initialized
DEBUG - 2020-02-27 06:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 06:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 06:30:55 --> Controller Class Initialized
INFO - 2020-02-27 06:30:55 --> Model "M_tiket" initialized
INFO - 2020-02-27 06:30:56 --> Model "M_pengunjung" initialized
ERROR - 2020-02-27 06:30:56 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 106
INFO - 2020-02-27 08:19:59 --> Config Class Initialized
INFO - 2020-02-27 08:19:59 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:19:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:19:59 --> Utf8 Class Initialized
INFO - 2020-02-27 08:19:59 --> URI Class Initialized
INFO - 2020-02-27 08:19:59 --> Router Class Initialized
INFO - 2020-02-27 08:19:59 --> Output Class Initialized
INFO - 2020-02-27 08:19:59 --> Security Class Initialized
DEBUG - 2020-02-27 08:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:19:59 --> Input Class Initialized
INFO - 2020-02-27 08:19:59 --> Language Class Initialized
INFO - 2020-02-27 08:19:59 --> Loader Class Initialized
INFO - 2020-02-27 08:19:59 --> Helper loaded: url_helper
INFO - 2020-02-27 08:19:59 --> Helper loaded: string_helper
INFO - 2020-02-27 08:19:59 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:19:59 --> Controller Class Initialized
INFO - 2020-02-27 08:19:59 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:19:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:19:59 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:19:59 --> Helper loaded: form_helper
INFO - 2020-02-27 08:19:59 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:20:00 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 105
ERROR - 2020-02-27 08:20:00 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 107
ERROR - 2020-02-27 08:20:00 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
INFO - 2020-02-27 08:20:00 --> Final output sent to browser
DEBUG - 2020-02-27 08:20:00 --> Total execution time: 0.7223
INFO - 2020-02-27 08:21:29 --> Config Class Initialized
INFO - 2020-02-27 08:21:29 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:21:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:21:29 --> Utf8 Class Initialized
INFO - 2020-02-27 08:21:29 --> URI Class Initialized
INFO - 2020-02-27 08:21:29 --> Router Class Initialized
INFO - 2020-02-27 08:21:29 --> Output Class Initialized
INFO - 2020-02-27 08:21:29 --> Security Class Initialized
DEBUG - 2020-02-27 08:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:21:29 --> Input Class Initialized
INFO - 2020-02-27 08:21:29 --> Language Class Initialized
INFO - 2020-02-27 08:21:29 --> Loader Class Initialized
INFO - 2020-02-27 08:21:29 --> Helper loaded: url_helper
INFO - 2020-02-27 08:21:29 --> Helper loaded: string_helper
INFO - 2020-02-27 08:21:29 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:21:29 --> Controller Class Initialized
INFO - 2020-02-27 08:21:29 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:21:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:21:29 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:21:29 --> Helper loaded: form_helper
INFO - 2020-02-27 08:21:29 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:21:29 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 105
ERROR - 2020-02-27 08:21:29 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 107
ERROR - 2020-02-27 08:21:29 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 109
INFO - 2020-02-27 08:21:30 --> Final output sent to browser
DEBUG - 2020-02-27 08:21:30 --> Total execution time: 0.7244
INFO - 2020-02-27 08:37:26 --> Config Class Initialized
INFO - 2020-02-27 08:37:26 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:37:26 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:37:26 --> Utf8 Class Initialized
INFO - 2020-02-27 08:37:26 --> URI Class Initialized
INFO - 2020-02-27 08:37:26 --> Router Class Initialized
INFO - 2020-02-27 08:37:26 --> Output Class Initialized
INFO - 2020-02-27 08:37:26 --> Security Class Initialized
DEBUG - 2020-02-27 08:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:37:26 --> Input Class Initialized
INFO - 2020-02-27 08:37:26 --> Language Class Initialized
INFO - 2020-02-27 08:37:26 --> Loader Class Initialized
INFO - 2020-02-27 08:37:26 --> Helper loaded: url_helper
INFO - 2020-02-27 08:37:26 --> Helper loaded: string_helper
INFO - 2020-02-27 08:37:26 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:37:26 --> Controller Class Initialized
INFO - 2020-02-27 08:37:26 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:37:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:37:26 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:37:26 --> Helper loaded: form_helper
INFO - 2020-02-27 08:37:26 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:37:26 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 62
INFO - 2020-02-27 08:37:26 --> Final output sent to browser
DEBUG - 2020-02-27 08:37:26 --> Total execution time: 0.6820
INFO - 2020-02-27 08:38:52 --> Config Class Initialized
INFO - 2020-02-27 08:38:52 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:38:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:38:52 --> Utf8 Class Initialized
INFO - 2020-02-27 08:38:52 --> URI Class Initialized
INFO - 2020-02-27 08:38:52 --> Router Class Initialized
INFO - 2020-02-27 08:38:52 --> Output Class Initialized
INFO - 2020-02-27 08:38:52 --> Security Class Initialized
DEBUG - 2020-02-27 08:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:38:52 --> Input Class Initialized
INFO - 2020-02-27 08:38:52 --> Language Class Initialized
INFO - 2020-02-27 08:38:52 --> Loader Class Initialized
INFO - 2020-02-27 08:38:52 --> Helper loaded: url_helper
INFO - 2020-02-27 08:38:52 --> Helper loaded: string_helper
INFO - 2020-02-27 08:38:52 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:38:52 --> Controller Class Initialized
INFO - 2020-02-27 08:38:52 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:38:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:38:52 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:38:52 --> Helper loaded: form_helper
INFO - 2020-02-27 08:38:52 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:38:52 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 62
INFO - 2020-02-27 08:38:52 --> Final output sent to browser
DEBUG - 2020-02-27 08:38:52 --> Total execution time: 0.6494
INFO - 2020-02-27 08:40:14 --> Config Class Initialized
INFO - 2020-02-27 08:40:14 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:14 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:14 --> URI Class Initialized
INFO - 2020-02-27 08:40:14 --> Router Class Initialized
INFO - 2020-02-27 08:40:14 --> Output Class Initialized
INFO - 2020-02-27 08:40:15 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:15 --> Input Class Initialized
INFO - 2020-02-27 08:40:15 --> Language Class Initialized
INFO - 2020-02-27 08:40:15 --> Loader Class Initialized
INFO - 2020-02-27 08:40:15 --> Helper loaded: url_helper
INFO - 2020-02-27 08:40:15 --> Helper loaded: string_helper
INFO - 2020-02-27 08:40:15 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:40:15 --> Controller Class Initialized
INFO - 2020-02-27 08:40:15 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:40:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:40:15 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:40:15 --> Helper loaded: form_helper
INFO - 2020-02-27 08:40:15 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:40:15 --> Severity: Notice --> Undefined index: kode_unik C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 62
INFO - 2020-02-27 08:40:15 --> Final output sent to browser
DEBUG - 2020-02-27 08:40:15 --> Total execution time: 0.6376
INFO - 2020-02-27 08:40:21 --> Config Class Initialized
INFO - 2020-02-27 08:40:21 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:21 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:21 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:21 --> URI Class Initialized
DEBUG - 2020-02-27 08:40:21 --> No URI present. Default controller set.
INFO - 2020-02-27 08:40:21 --> Router Class Initialized
INFO - 2020-02-27 08:40:21 --> Output Class Initialized
INFO - 2020-02-27 08:40:21 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:21 --> Input Class Initialized
INFO - 2020-02-27 08:40:21 --> Language Class Initialized
INFO - 2020-02-27 08:40:21 --> Loader Class Initialized
INFO - 2020-02-27 08:40:21 --> Helper loaded: url_helper
INFO - 2020-02-27 08:40:21 --> Helper loaded: string_helper
INFO - 2020-02-27 08:40:21 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:40:21 --> Controller Class Initialized
INFO - 2020-02-27 08:40:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 08:40:22 --> Pagination Class Initialized
INFO - 2020-02-27 08:40:22 --> Model "M_show" initialized
INFO - 2020-02-27 08:40:22 --> Helper loaded: form_helper
INFO - 2020-02-27 08:40:22 --> Form Validation Class Initialized
INFO - 2020-02-27 08:40:22 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 08:40:22 --> Final output sent to browser
INFO - 2020-02-27 08:40:22 --> Config Class Initialized
DEBUG - 2020-02-27 08:40:22 --> Total execution time: 1.1525
INFO - 2020-02-27 08:40:22 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:22 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:22 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:22 --> URI Class Initialized
DEBUG - 2020-02-27 08:40:22 --> No URI present. Default controller set.
INFO - 2020-02-27 08:40:22 --> Router Class Initialized
INFO - 2020-02-27 08:40:22 --> Output Class Initialized
INFO - 2020-02-27 08:40:22 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:22 --> Input Class Initialized
INFO - 2020-02-27 08:40:22 --> Language Class Initialized
INFO - 2020-02-27 08:40:22 --> Loader Class Initialized
INFO - 2020-02-27 08:40:22 --> Helper loaded: url_helper
INFO - 2020-02-27 08:40:22 --> Helper loaded: string_helper
INFO - 2020-02-27 08:40:22 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:40:22 --> Controller Class Initialized
INFO - 2020-02-27 08:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 08:40:23 --> Pagination Class Initialized
INFO - 2020-02-27 08:40:23 --> Model "M_show" initialized
INFO - 2020-02-27 08:40:23 --> Helper loaded: form_helper
INFO - 2020-02-27 08:40:23 --> Form Validation Class Initialized
INFO - 2020-02-27 08:40:23 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 08:40:23 --> Final output sent to browser
DEBUG - 2020-02-27 08:40:23 --> Total execution time: 0.6820
INFO - 2020-02-27 08:40:27 --> Config Class Initialized
INFO - 2020-02-27 08:40:28 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:28 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:28 --> URI Class Initialized
INFO - 2020-02-27 08:40:28 --> Router Class Initialized
INFO - 2020-02-27 08:40:28 --> Output Class Initialized
INFO - 2020-02-27 08:40:28 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:28 --> Input Class Initialized
INFO - 2020-02-27 08:40:28 --> Language Class Initialized
INFO - 2020-02-27 08:40:28 --> Loader Class Initialized
INFO - 2020-02-27 08:40:28 --> Helper loaded: url_helper
INFO - 2020-02-27 08:40:28 --> Helper loaded: string_helper
INFO - 2020-02-27 08:40:28 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:40:28 --> Controller Class Initialized
INFO - 2020-02-27 08:40:28 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:40:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:40:28 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:40:28 --> Helper loaded: form_helper
INFO - 2020-02-27 08:40:28 --> Form Validation Class Initialized
INFO - 2020-02-27 08:40:28 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 08:40:28 --> Final output sent to browser
DEBUG - 2020-02-27 08:40:28 --> Total execution time: 0.7765
INFO - 2020-02-27 08:40:28 --> Config Class Initialized
INFO - 2020-02-27 08:40:28 --> Config Class Initialized
INFO - 2020-02-27 08:40:28 --> Config Class Initialized
INFO - 2020-02-27 08:40:28 --> Hooks Class Initialized
INFO - 2020-02-27 08:40:28 --> Hooks Class Initialized
INFO - 2020-02-27 08:40:28 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 08:40:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 08:40:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:28 --> Config Class Initialized
INFO - 2020-02-27 08:40:28 --> Config Class Initialized
INFO - 2020-02-27 08:40:28 --> Config Class Initialized
INFO - 2020-02-27 08:40:28 --> Hooks Class Initialized
INFO - 2020-02-27 08:40:28 --> Hooks Class Initialized
INFO - 2020-02-27 08:40:28 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:28 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:28 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:28 --> Hooks Class Initialized
INFO - 2020-02-27 08:40:28 --> URI Class Initialized
INFO - 2020-02-27 08:40:28 --> URI Class Initialized
INFO - 2020-02-27 08:40:28 --> URI Class Initialized
DEBUG - 2020-02-27 08:40:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 08:40:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 08:40:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:29 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:29 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:29 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
INFO - 2020-02-27 08:40:29 --> Output Class Initialized
INFO - 2020-02-27 08:40:29 --> Output Class Initialized
INFO - 2020-02-27 08:40:29 --> URI Class Initialized
INFO - 2020-02-27 08:40:29 --> Output Class Initialized
INFO - 2020-02-27 08:40:29 --> URI Class Initialized
INFO - 2020-02-27 08:40:29 --> Security Class Initialized
INFO - 2020-02-27 08:40:29 --> Security Class Initialized
INFO - 2020-02-27 08:40:29 --> URI Class Initialized
INFO - 2020-02-27 08:40:29 --> Security Class Initialized
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
DEBUG - 2020-02-27 08:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
INFO - 2020-02-27 08:40:29 --> Output Class Initialized
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
DEBUG - 2020-02-27 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:29 --> Input Class Initialized
INFO - 2020-02-27 08:40:29 --> Input Class Initialized
INFO - 2020-02-27 08:40:29 --> Input Class Initialized
INFO - 2020-02-27 08:40:29 --> Security Class Initialized
INFO - 2020-02-27 08:40:29 --> Output Class Initialized
INFO - 2020-02-27 08:40:29 --> Output Class Initialized
INFO - 2020-02-27 08:40:29 --> Language Class Initialized
INFO - 2020-02-27 08:40:29 --> Language Class Initialized
INFO - 2020-02-27 08:40:29 --> Language Class Initialized
ERROR - 2020-02-27 08:40:29 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-27 08:40:29 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 08:40:29 --> Loader Class Initialized
INFO - 2020-02-27 08:40:29 --> Helper loaded: url_helper
DEBUG - 2020-02-27 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:29 --> Security Class Initialized
INFO - 2020-02-27 08:40:29 --> Security Class Initialized
INFO - 2020-02-27 08:40:29 --> Input Class Initialized
INFO - 2020-02-27 08:40:29 --> Helper loaded: string_helper
DEBUG - 2020-02-27 08:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:29 --> Config Class Initialized
INFO - 2020-02-27 08:40:29 --> Config Class Initialized
INFO - 2020-02-27 08:40:29 --> Hooks Class Initialized
INFO - 2020-02-27 08:40:29 --> Hooks Class Initialized
INFO - 2020-02-27 08:40:29 --> Input Class Initialized
INFO - 2020-02-27 08:40:29 --> Input Class Initialized
INFO - 2020-02-27 08:40:29 --> Language Class Initialized
INFO - 2020-02-27 08:40:29 --> Database Driver Class Initialized
INFO - 2020-02-27 08:40:29 --> Language Class Initialized
INFO - 2020-02-27 08:40:29 --> Language Class Initialized
DEBUG - 2020-02-27 08:40:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 08:40:29 --> UTF-8 Support Enabled
ERROR - 2020-02-27 08:40:29 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-27 08:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:40:29 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:29 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:29 --> Session: Class initialized using 'files' driver.
ERROR - 2020-02-27 08:40:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 08:40:29 --> Config Class Initialized
INFO - 2020-02-27 08:40:29 --> Loader Class Initialized
INFO - 2020-02-27 08:40:29 --> Hooks Class Initialized
INFO - 2020-02-27 08:40:29 --> Controller Class Initialized
INFO - 2020-02-27 08:40:29 --> URI Class Initialized
INFO - 2020-02-27 08:40:29 --> URI Class Initialized
INFO - 2020-02-27 08:40:29 --> Helper loaded: url_helper
INFO - 2020-02-27 08:40:29 --> Config Class Initialized
INFO - 2020-02-27 08:40:29 --> Hooks Class Initialized
INFO - 2020-02-27 08:40:29 --> Helper loaded: string_helper
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
INFO - 2020-02-27 08:40:29 --> Model "M_tiket" initialized
DEBUG - 2020-02-27 08:40:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:29 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:40:29 --> Output Class Initialized
INFO - 2020-02-27 08:40:29 --> Output Class Initialized
DEBUG - 2020-02-27 08:40:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:29 --> Database Driver Class Initialized
INFO - 2020-02-27 08:40:29 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:29 --> URI Class Initialized
INFO - 2020-02-27 08:40:29 --> Security Class Initialized
INFO - 2020-02-27 08:40:29 --> Security Class Initialized
INFO - 2020-02-27 08:40:29 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 08:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:40:29 --> URI Class Initialized
DEBUG - 2020-02-27 08:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
INFO - 2020-02-27 08:40:29 --> Helper loaded: form_helper
INFO - 2020-02-27 08:40:29 --> Input Class Initialized
INFO - 2020-02-27 08:40:29 --> Input Class Initialized
INFO - 2020-02-27 08:40:29 --> Form Validation Class Initialized
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
INFO - 2020-02-27 08:40:29 --> Output Class Initialized
INFO - 2020-02-27 08:40:29 --> Language Class Initialized
INFO - 2020-02-27 08:40:29 --> Language Class Initialized
ERROR - 2020-02-27 08:40:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-27 08:40:29 --> Output Class Initialized
INFO - 2020-02-27 08:40:29 --> Security Class Initialized
ERROR - 2020-02-27 08:40:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-27 08:40:29 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 08:40:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 08:40:29 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:29 --> Input Class Initialized
DEBUG - 2020-02-27 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:29 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 08:40:29 --> Config Class Initialized
INFO - 2020-02-27 08:40:29 --> Config Class Initialized
INFO - 2020-02-27 08:40:29 --> Hooks Class Initialized
INFO - 2020-02-27 08:40:29 --> Hooks Class Initialized
INFO - 2020-02-27 08:40:29 --> Input Class Initialized
INFO - 2020-02-27 08:40:29 --> Final output sent to browser
INFO - 2020-02-27 08:40:29 --> Language Class Initialized
DEBUG - 2020-02-27 08:40:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 08:40:29 --> Total execution time: 0.9685
INFO - 2020-02-27 08:40:29 --> Language Class Initialized
INFO - 2020-02-27 08:40:29 --> Utf8 Class Initialized
ERROR - 2020-02-27 08:40:29 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-27 08:40:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:29 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:29 --> Session: Class initialized using 'files' driver.
ERROR - 2020-02-27 08:40:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 08:40:29 --> URI Class Initialized
INFO - 2020-02-27 08:40:29 --> Config Class Initialized
INFO - 2020-02-27 08:40:29 --> Config Class Initialized
INFO - 2020-02-27 08:40:29 --> Hooks Class Initialized
INFO - 2020-02-27 08:40:29 --> Controller Class Initialized
INFO - 2020-02-27 08:40:29 --> Hooks Class Initialized
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
INFO - 2020-02-27 08:40:29 --> URI Class Initialized
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
INFO - 2020-02-27 08:40:29 --> Output Class Initialized
DEBUG - 2020-02-27 08:40:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 08:40:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:29 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:40:29 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:29 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:29 --> Security Class Initialized
INFO - 2020-02-27 08:40:29 --> Output Class Initialized
INFO - 2020-02-27 08:40:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:40:29 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:40:29 --> URI Class Initialized
INFO - 2020-02-27 08:40:29 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:29 --> URI Class Initialized
INFO - 2020-02-27 08:40:29 --> Input Class Initialized
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
DEBUG - 2020-02-27 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:29 --> Router Class Initialized
INFO - 2020-02-27 08:40:29 --> Helper loaded: form_helper
INFO - 2020-02-27 08:40:30 --> Form Validation Class Initialized
INFO - 2020-02-27 08:40:30 --> Input Class Initialized
INFO - 2020-02-27 08:40:30 --> Language Class Initialized
INFO - 2020-02-27 08:40:30 --> Output Class Initialized
INFO - 2020-02-27 08:40:30 --> Output Class Initialized
INFO - 2020-02-27 08:40:30 --> Language Class Initialized
INFO - 2020-02-27 08:40:30 --> Security Class Initialized
ERROR - 2020-02-27 08:40:30 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 08:40:30 --> Security Class Initialized
ERROR - 2020-02-27 08:40:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 08:40:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-27 08:40:30 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-27 08:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 08:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:30 --> Input Class Initialized
INFO - 2020-02-27 08:40:30 --> Input Class Initialized
INFO - 2020-02-27 08:40:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 08:40:30 --> Final output sent to browser
INFO - 2020-02-27 08:40:30 --> Language Class Initialized
INFO - 2020-02-27 08:40:30 --> Language Class Initialized
DEBUG - 2020-02-27 08:40:30 --> Total execution time: 1.2331
ERROR - 2020-02-27 08:40:30 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-27 08:40:30 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 08:40:30 --> Config Class Initialized
INFO - 2020-02-27 08:40:30 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:30 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:30 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:30 --> URI Class Initialized
INFO - 2020-02-27 08:40:30 --> Router Class Initialized
INFO - 2020-02-27 08:40:30 --> Output Class Initialized
INFO - 2020-02-27 08:40:30 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:30 --> Input Class Initialized
INFO - 2020-02-27 08:40:30 --> Language Class Initialized
ERROR - 2020-02-27 08:40:30 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 08:40:30 --> Config Class Initialized
INFO - 2020-02-27 08:40:30 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:30 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:30 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:30 --> URI Class Initialized
INFO - 2020-02-27 08:40:30 --> Router Class Initialized
INFO - 2020-02-27 08:40:30 --> Output Class Initialized
INFO - 2020-02-27 08:40:30 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:30 --> Input Class Initialized
INFO - 2020-02-27 08:40:30 --> Language Class Initialized
ERROR - 2020-02-27 08:40:30 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 08:40:30 --> Config Class Initialized
INFO - 2020-02-27 08:40:30 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:30 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:30 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:30 --> URI Class Initialized
INFO - 2020-02-27 08:40:31 --> Router Class Initialized
INFO - 2020-02-27 08:40:31 --> Output Class Initialized
INFO - 2020-02-27 08:40:31 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:31 --> Input Class Initialized
INFO - 2020-02-27 08:40:31 --> Language Class Initialized
ERROR - 2020-02-27 08:40:31 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 08:40:31 --> Config Class Initialized
INFO - 2020-02-27 08:40:31 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:31 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:31 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:31 --> URI Class Initialized
INFO - 2020-02-27 08:40:31 --> Router Class Initialized
INFO - 2020-02-27 08:40:31 --> Output Class Initialized
INFO - 2020-02-27 08:40:31 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:31 --> Input Class Initialized
INFO - 2020-02-27 08:40:31 --> Language Class Initialized
ERROR - 2020-02-27 08:40:31 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 08:40:31 --> Config Class Initialized
INFO - 2020-02-27 08:40:31 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:31 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:31 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:31 --> URI Class Initialized
INFO - 2020-02-27 08:40:31 --> Router Class Initialized
INFO - 2020-02-27 08:40:31 --> Output Class Initialized
INFO - 2020-02-27 08:40:31 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:31 --> Input Class Initialized
INFO - 2020-02-27 08:40:31 --> Language Class Initialized
ERROR - 2020-02-27 08:40:31 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 08:40:31 --> Config Class Initialized
INFO - 2020-02-27 08:40:31 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:31 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:31 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:31 --> URI Class Initialized
INFO - 2020-02-27 08:40:31 --> Router Class Initialized
INFO - 2020-02-27 08:40:32 --> Output Class Initialized
INFO - 2020-02-27 08:40:32 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:32 --> Input Class Initialized
INFO - 2020-02-27 08:40:32 --> Language Class Initialized
ERROR - 2020-02-27 08:40:32 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 08:40:32 --> Config Class Initialized
INFO - 2020-02-27 08:40:32 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:32 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:32 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:32 --> URI Class Initialized
INFO - 2020-02-27 08:40:32 --> Router Class Initialized
INFO - 2020-02-27 08:40:32 --> Output Class Initialized
INFO - 2020-02-27 08:40:32 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:32 --> Input Class Initialized
INFO - 2020-02-27 08:40:32 --> Language Class Initialized
ERROR - 2020-02-27 08:40:32 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 08:40:32 --> Config Class Initialized
INFO - 2020-02-27 08:40:32 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:32 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:32 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:32 --> URI Class Initialized
INFO - 2020-02-27 08:40:32 --> Router Class Initialized
INFO - 2020-02-27 08:40:32 --> Output Class Initialized
INFO - 2020-02-27 08:40:32 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:32 --> Input Class Initialized
INFO - 2020-02-27 08:40:32 --> Language Class Initialized
ERROR - 2020-02-27 08:40:32 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 08:40:32 --> Config Class Initialized
INFO - 2020-02-27 08:40:32 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:32 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:32 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:32 --> URI Class Initialized
INFO - 2020-02-27 08:40:32 --> Router Class Initialized
INFO - 2020-02-27 08:40:32 --> Output Class Initialized
INFO - 2020-02-27 08:40:33 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:33 --> Input Class Initialized
INFO - 2020-02-27 08:40:33 --> Language Class Initialized
ERROR - 2020-02-27 08:40:33 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 08:40:53 --> Config Class Initialized
INFO - 2020-02-27 08:40:53 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:53 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:53 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:53 --> URI Class Initialized
INFO - 2020-02-27 08:40:53 --> Router Class Initialized
INFO - 2020-02-27 08:40:53 --> Output Class Initialized
INFO - 2020-02-27 08:40:53 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:53 --> Input Class Initialized
INFO - 2020-02-27 08:40:53 --> Language Class Initialized
INFO - 2020-02-27 08:40:53 --> Loader Class Initialized
INFO - 2020-02-27 08:40:53 --> Helper loaded: url_helper
INFO - 2020-02-27 08:40:53 --> Helper loaded: string_helper
INFO - 2020-02-27 08:40:53 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:40:54 --> Controller Class Initialized
INFO - 2020-02-27 08:40:54 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:40:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:40:54 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:40:54 --> Helper loaded: form_helper
INFO - 2020-02-27 08:40:54 --> Form Validation Class Initialized
INFO - 2020-02-27 14:40:54 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 14:40:54 --> Final output sent to browser
DEBUG - 2020-02-27 14:40:54 --> Total execution time: 0.8792
INFO - 2020-02-27 08:40:58 --> Config Class Initialized
INFO - 2020-02-27 08:40:58 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:40:58 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:40:58 --> Utf8 Class Initialized
INFO - 2020-02-27 08:40:58 --> URI Class Initialized
INFO - 2020-02-27 08:40:58 --> Router Class Initialized
INFO - 2020-02-27 08:40:58 --> Output Class Initialized
INFO - 2020-02-27 08:40:58 --> Security Class Initialized
DEBUG - 2020-02-27 08:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:40:58 --> Input Class Initialized
INFO - 2020-02-27 08:40:58 --> Language Class Initialized
INFO - 2020-02-27 08:40:58 --> Loader Class Initialized
INFO - 2020-02-27 08:40:58 --> Helper loaded: url_helper
INFO - 2020-02-27 08:40:58 --> Helper loaded: string_helper
INFO - 2020-02-27 08:40:58 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:40:58 --> Controller Class Initialized
INFO - 2020-02-27 08:40:58 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:40:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:40:58 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:40:58 --> Helper loaded: form_helper
INFO - 2020-02-27 08:40:58 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:40:58 --> Severity: error --> Exception: Call to undefined method M_pesan::getTanggal() C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 35
INFO - 2020-02-27 08:41:51 --> Config Class Initialized
INFO - 2020-02-27 08:41:51 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:41:51 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:41:51 --> Utf8 Class Initialized
INFO - 2020-02-27 08:41:51 --> URI Class Initialized
INFO - 2020-02-27 08:41:51 --> Router Class Initialized
INFO - 2020-02-27 08:41:51 --> Output Class Initialized
INFO - 2020-02-27 08:41:51 --> Security Class Initialized
DEBUG - 2020-02-27 08:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:41:51 --> Input Class Initialized
INFO - 2020-02-27 08:41:51 --> Language Class Initialized
INFO - 2020-02-27 08:41:51 --> Loader Class Initialized
INFO - 2020-02-27 08:41:51 --> Helper loaded: url_helper
INFO - 2020-02-27 08:41:51 --> Helper loaded: string_helper
INFO - 2020-02-27 08:41:51 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:41:51 --> Controller Class Initialized
INFO - 2020-02-27 08:41:51 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:41:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:41:51 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:41:52 --> Helper loaded: form_helper
INFO - 2020-02-27 08:41:52 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:41:52 --> Severity: Notice --> Undefined variable: tanggalp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 08:41:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 08:41:52 --> Final output sent to browser
DEBUG - 2020-02-27 08:41:52 --> Total execution time: 0.7809
INFO - 2020-02-27 08:42:23 --> Config Class Initialized
INFO - 2020-02-27 08:42:23 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:42:23 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:42:23 --> Utf8 Class Initialized
INFO - 2020-02-27 08:42:23 --> URI Class Initialized
INFO - 2020-02-27 08:42:23 --> Router Class Initialized
INFO - 2020-02-27 08:42:23 --> Output Class Initialized
INFO - 2020-02-27 08:42:23 --> Security Class Initialized
DEBUG - 2020-02-27 08:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:42:23 --> Input Class Initialized
INFO - 2020-02-27 08:42:23 --> Language Class Initialized
INFO - 2020-02-27 08:42:23 --> Loader Class Initialized
INFO - 2020-02-27 08:42:23 --> Helper loaded: url_helper
INFO - 2020-02-27 08:42:23 --> Helper loaded: string_helper
INFO - 2020-02-27 08:42:23 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:42:24 --> Controller Class Initialized
INFO - 2020-02-27 08:42:24 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:42:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:42:24 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:42:24 --> Helper loaded: form_helper
INFO - 2020-02-27 08:42:24 --> Form Validation Class Initialized
INFO - 2020-02-27 08:42:24 --> Final output sent to browser
DEBUG - 2020-02-27 08:42:24 --> Total execution time: 0.6367
INFO - 2020-02-27 08:43:30 --> Config Class Initialized
INFO - 2020-02-27 08:43:30 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:43:30 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:43:30 --> Utf8 Class Initialized
INFO - 2020-02-27 08:43:30 --> URI Class Initialized
INFO - 2020-02-27 08:43:30 --> Router Class Initialized
INFO - 2020-02-27 08:43:30 --> Output Class Initialized
INFO - 2020-02-27 08:43:30 --> Security Class Initialized
DEBUG - 2020-02-27 08:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:43:31 --> Input Class Initialized
INFO - 2020-02-27 08:43:31 --> Language Class Initialized
INFO - 2020-02-27 08:43:31 --> Loader Class Initialized
INFO - 2020-02-27 08:43:31 --> Helper loaded: url_helper
INFO - 2020-02-27 08:43:31 --> Helper loaded: string_helper
INFO - 2020-02-27 08:43:31 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:43:31 --> Controller Class Initialized
INFO - 2020-02-27 08:43:31 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:43:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:43:31 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:43:31 --> Helper loaded: form_helper
INFO - 2020-02-27 08:43:31 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:43:31 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 63
INFO - 2020-02-27 08:43:31 --> Final output sent to browser
DEBUG - 2020-02-27 08:43:31 --> Total execution time: 0.7208
INFO - 2020-02-27 08:44:55 --> Config Class Initialized
INFO - 2020-02-27 08:44:55 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:44:55 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:44:55 --> Utf8 Class Initialized
INFO - 2020-02-27 08:44:55 --> URI Class Initialized
INFO - 2020-02-27 08:44:55 --> Router Class Initialized
INFO - 2020-02-27 08:44:55 --> Output Class Initialized
INFO - 2020-02-27 08:44:55 --> Security Class Initialized
DEBUG - 2020-02-27 08:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:44:55 --> Input Class Initialized
INFO - 2020-02-27 08:44:55 --> Language Class Initialized
INFO - 2020-02-27 08:44:55 --> Loader Class Initialized
INFO - 2020-02-27 08:44:55 --> Helper loaded: url_helper
INFO - 2020-02-27 08:44:55 --> Helper loaded: string_helper
INFO - 2020-02-27 08:44:55 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:44:56 --> Controller Class Initialized
INFO - 2020-02-27 08:44:56 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:44:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:44:56 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:44:56 --> Helper loaded: form_helper
INFO - 2020-02-27 08:44:56 --> Form Validation Class Initialized
INFO - 2020-02-27 08:44:56 --> Final output sent to browser
DEBUG - 2020-02-27 08:44:56 --> Total execution time: 0.6419
INFO - 2020-02-27 08:45:12 --> Config Class Initialized
INFO - 2020-02-27 08:45:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:45:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:45:12 --> Utf8 Class Initialized
INFO - 2020-02-27 08:45:12 --> URI Class Initialized
INFO - 2020-02-27 08:45:12 --> Router Class Initialized
INFO - 2020-02-27 08:45:12 --> Output Class Initialized
INFO - 2020-02-27 08:45:12 --> Security Class Initialized
DEBUG - 2020-02-27 08:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:45:12 --> Input Class Initialized
INFO - 2020-02-27 08:45:12 --> Language Class Initialized
INFO - 2020-02-27 08:45:12 --> Loader Class Initialized
INFO - 2020-02-27 08:45:12 --> Helper loaded: url_helper
INFO - 2020-02-27 08:45:12 --> Helper loaded: string_helper
INFO - 2020-02-27 08:45:12 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:45:13 --> Controller Class Initialized
INFO - 2020-02-27 08:45:13 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:45:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:45:13 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:45:13 --> Helper loaded: form_helper
INFO - 2020-02-27 08:45:13 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:45:13 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 63
INFO - 2020-02-27 08:45:13 --> Final output sent to browser
DEBUG - 2020-02-27 08:45:13 --> Total execution time: 0.7179
INFO - 2020-02-27 08:45:20 --> Config Class Initialized
INFO - 2020-02-27 08:45:20 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:45:20 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:45:20 --> Utf8 Class Initialized
INFO - 2020-02-27 08:45:20 --> URI Class Initialized
INFO - 2020-02-27 08:45:20 --> Router Class Initialized
INFO - 2020-02-27 08:45:20 --> Output Class Initialized
INFO - 2020-02-27 08:45:20 --> Security Class Initialized
DEBUG - 2020-02-27 08:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:45:20 --> Input Class Initialized
INFO - 2020-02-27 08:45:20 --> Language Class Initialized
INFO - 2020-02-27 08:45:20 --> Loader Class Initialized
INFO - 2020-02-27 08:45:20 --> Helper loaded: url_helper
INFO - 2020-02-27 08:45:20 --> Helper loaded: string_helper
INFO - 2020-02-27 08:45:20 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:45:20 --> Controller Class Initialized
INFO - 2020-02-27 08:45:20 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:45:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:45:20 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:45:20 --> Helper loaded: form_helper
INFO - 2020-02-27 08:45:20 --> Form Validation Class Initialized
INFO - 2020-02-27 08:45:20 --> Final output sent to browser
DEBUG - 2020-02-27 08:45:20 --> Total execution time: 0.6518
INFO - 2020-02-27 08:47:54 --> Config Class Initialized
INFO - 2020-02-27 08:47:54 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:47:54 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:47:54 --> Utf8 Class Initialized
INFO - 2020-02-27 08:47:54 --> URI Class Initialized
INFO - 2020-02-27 08:47:54 --> Router Class Initialized
INFO - 2020-02-27 08:47:54 --> Output Class Initialized
INFO - 2020-02-27 08:47:54 --> Security Class Initialized
DEBUG - 2020-02-27 08:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:47:54 --> Input Class Initialized
INFO - 2020-02-27 08:47:54 --> Language Class Initialized
INFO - 2020-02-27 08:47:55 --> Loader Class Initialized
INFO - 2020-02-27 08:47:55 --> Helper loaded: url_helper
INFO - 2020-02-27 08:47:55 --> Helper loaded: string_helper
INFO - 2020-02-27 08:47:55 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:47:55 --> Controller Class Initialized
INFO - 2020-02-27 08:47:55 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:47:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:47:55 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:47:55 --> Helper loaded: form_helper
INFO - 2020-02-27 08:47:55 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:47:55 --> Severity: Notice --> Undefined index: koderahasia C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 63
INFO - 2020-02-27 08:47:55 --> Final output sent to browser
DEBUG - 2020-02-27 08:47:55 --> Total execution time: 0.6570
INFO - 2020-02-27 08:48:26 --> Config Class Initialized
INFO - 2020-02-27 08:48:26 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:48:26 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:48:26 --> Utf8 Class Initialized
INFO - 2020-02-27 08:48:26 --> URI Class Initialized
INFO - 2020-02-27 08:48:26 --> Router Class Initialized
INFO - 2020-02-27 08:48:26 --> Output Class Initialized
INFO - 2020-02-27 08:48:26 --> Security Class Initialized
DEBUG - 2020-02-27 08:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:48:26 --> Input Class Initialized
INFO - 2020-02-27 08:48:26 --> Language Class Initialized
INFO - 2020-02-27 08:48:26 --> Loader Class Initialized
INFO - 2020-02-27 08:48:26 --> Helper loaded: url_helper
INFO - 2020-02-27 08:48:26 --> Helper loaded: string_helper
INFO - 2020-02-27 08:48:26 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:48:26 --> Controller Class Initialized
INFO - 2020-02-27 08:48:26 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:48:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:48:26 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:48:26 --> Helper loaded: form_helper
INFO - 2020-02-27 08:48:26 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:48:26 --> Severity: Notice --> Undefined index: koderahasia C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 63
INFO - 2020-02-27 08:48:26 --> Final output sent to browser
DEBUG - 2020-02-27 08:48:26 --> Total execution time: 0.7031
INFO - 2020-02-27 08:49:05 --> Config Class Initialized
INFO - 2020-02-27 08:49:05 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:49:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:49:05 --> Utf8 Class Initialized
INFO - 2020-02-27 08:49:06 --> URI Class Initialized
INFO - 2020-02-27 08:49:06 --> Router Class Initialized
INFO - 2020-02-27 08:49:06 --> Output Class Initialized
INFO - 2020-02-27 08:49:06 --> Security Class Initialized
DEBUG - 2020-02-27 08:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:49:06 --> Input Class Initialized
INFO - 2020-02-27 08:49:06 --> Language Class Initialized
INFO - 2020-02-27 08:49:06 --> Loader Class Initialized
INFO - 2020-02-27 08:49:06 --> Helper loaded: url_helper
INFO - 2020-02-27 08:49:06 --> Helper loaded: string_helper
INFO - 2020-02-27 08:49:06 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:49:06 --> Controller Class Initialized
INFO - 2020-02-27 08:49:06 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:49:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:49:06 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:49:06 --> Helper loaded: form_helper
INFO - 2020-02-27 08:49:06 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:49:06 --> Severity: Notice --> Undefined index: koderahasia C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 63
INFO - 2020-02-27 08:49:06 --> Final output sent to browser
DEBUG - 2020-02-27 08:49:06 --> Total execution time: 0.7786
INFO - 2020-02-27 08:53:06 --> Config Class Initialized
INFO - 2020-02-27 08:53:06 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:53:06 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:53:06 --> Utf8 Class Initialized
INFO - 2020-02-27 08:53:06 --> URI Class Initialized
INFO - 2020-02-27 08:53:06 --> Router Class Initialized
INFO - 2020-02-27 08:53:06 --> Output Class Initialized
INFO - 2020-02-27 08:53:06 --> Security Class Initialized
DEBUG - 2020-02-27 08:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:53:06 --> Input Class Initialized
INFO - 2020-02-27 08:53:06 --> Language Class Initialized
INFO - 2020-02-27 08:53:06 --> Loader Class Initialized
INFO - 2020-02-27 08:53:06 --> Helper loaded: url_helper
INFO - 2020-02-27 08:53:06 --> Helper loaded: string_helper
INFO - 2020-02-27 08:53:06 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:53:06 --> Controller Class Initialized
INFO - 2020-02-27 08:53:06 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:53:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:53:06 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:53:06 --> Helper loaded: form_helper
INFO - 2020-02-27 08:53:07 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:53:07 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 64
ERROR - 2020-02-27 08:53:07 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 65
ERROR - 2020-02-27 08:53:07 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 66
INFO - 2020-02-27 08:53:07 --> Final output sent to browser
DEBUG - 2020-02-27 08:53:07 --> Total execution time: 0.7911
INFO - 2020-02-27 08:54:22 --> Config Class Initialized
INFO - 2020-02-27 08:54:22 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:54:22 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:54:22 --> Utf8 Class Initialized
INFO - 2020-02-27 08:54:22 --> URI Class Initialized
INFO - 2020-02-27 08:54:22 --> Router Class Initialized
INFO - 2020-02-27 08:54:22 --> Output Class Initialized
INFO - 2020-02-27 08:54:22 --> Security Class Initialized
DEBUG - 2020-02-27 08:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:54:22 --> Input Class Initialized
INFO - 2020-02-27 08:54:22 --> Language Class Initialized
INFO - 2020-02-27 08:54:22 --> Loader Class Initialized
INFO - 2020-02-27 08:54:22 --> Helper loaded: url_helper
INFO - 2020-02-27 08:54:22 --> Helper loaded: string_helper
INFO - 2020-02-27 08:54:22 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:54:22 --> Controller Class Initialized
INFO - 2020-02-27 08:54:22 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:54:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:54:22 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:54:22 --> Helper loaded: form_helper
INFO - 2020-02-27 08:54:22 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:54:22 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 64
ERROR - 2020-02-27 08:54:22 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 65
ERROR - 2020-02-27 08:54:23 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 66
INFO - 2020-02-27 08:54:23 --> Final output sent to browser
DEBUG - 2020-02-27 08:54:23 --> Total execution time: 0.7413
INFO - 2020-02-27 08:55:30 --> Config Class Initialized
INFO - 2020-02-27 08:55:30 --> Hooks Class Initialized
DEBUG - 2020-02-27 08:55:30 --> UTF-8 Support Enabled
INFO - 2020-02-27 08:55:30 --> Utf8 Class Initialized
INFO - 2020-02-27 08:55:30 --> URI Class Initialized
INFO - 2020-02-27 08:55:30 --> Router Class Initialized
INFO - 2020-02-27 08:55:30 --> Output Class Initialized
INFO - 2020-02-27 08:55:31 --> Security Class Initialized
DEBUG - 2020-02-27 08:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 08:55:31 --> Input Class Initialized
INFO - 2020-02-27 08:55:31 --> Language Class Initialized
INFO - 2020-02-27 08:55:31 --> Loader Class Initialized
INFO - 2020-02-27 08:55:31 --> Helper loaded: url_helper
INFO - 2020-02-27 08:55:31 --> Helper loaded: string_helper
INFO - 2020-02-27 08:55:31 --> Database Driver Class Initialized
DEBUG - 2020-02-27 08:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 08:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 08:55:31 --> Controller Class Initialized
INFO - 2020-02-27 08:55:31 --> Model "M_tiket" initialized
INFO - 2020-02-27 08:55:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 08:55:31 --> Model "M_pesan" initialized
INFO - 2020-02-27 08:55:31 --> Helper loaded: form_helper
INFO - 2020-02-27 08:55:31 --> Form Validation Class Initialized
ERROR - 2020-02-27 08:55:31 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 64
ERROR - 2020-02-27 08:55:31 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 65
ERROR - 2020-02-27 08:55:31 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 66
INFO - 2020-02-27 08:55:31 --> Final output sent to browser
DEBUG - 2020-02-27 08:55:31 --> Total execution time: 0.7149
INFO - 2020-02-27 09:00:16 --> Config Class Initialized
INFO - 2020-02-27 09:00:16 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:00:16 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:00:16 --> Utf8 Class Initialized
INFO - 2020-02-27 09:00:16 --> URI Class Initialized
INFO - 2020-02-27 09:00:16 --> Router Class Initialized
INFO - 2020-02-27 09:00:16 --> Output Class Initialized
INFO - 2020-02-27 09:00:16 --> Security Class Initialized
DEBUG - 2020-02-27 09:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:00:16 --> Input Class Initialized
INFO - 2020-02-27 09:00:16 --> Language Class Initialized
INFO - 2020-02-27 09:00:16 --> Loader Class Initialized
INFO - 2020-02-27 09:00:16 --> Helper loaded: url_helper
INFO - 2020-02-27 09:00:16 --> Helper loaded: string_helper
INFO - 2020-02-27 09:00:16 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:00:16 --> Controller Class Initialized
INFO - 2020-02-27 09:00:16 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:00:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:00:17 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:00:17 --> Helper loaded: form_helper
INFO - 2020-02-27 09:00:17 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:00:17 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 64
ERROR - 2020-02-27 09:00:17 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 65
ERROR - 2020-02-27 09:00:17 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 66
INFO - 2020-02-27 09:00:17 --> Final output sent to browser
DEBUG - 2020-02-27 09:00:17 --> Total execution time: 0.8991
INFO - 2020-02-27 09:01:20 --> Config Class Initialized
INFO - 2020-02-27 09:01:20 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:20 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:21 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:21 --> URI Class Initialized
DEBUG - 2020-02-27 09:01:21 --> No URI present. Default controller set.
INFO - 2020-02-27 09:01:21 --> Router Class Initialized
INFO - 2020-02-27 09:01:21 --> Output Class Initialized
INFO - 2020-02-27 09:01:21 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:21 --> Input Class Initialized
INFO - 2020-02-27 09:01:21 --> Language Class Initialized
INFO - 2020-02-27 09:01:21 --> Loader Class Initialized
INFO - 2020-02-27 09:01:21 --> Helper loaded: url_helper
INFO - 2020-02-27 09:01:21 --> Helper loaded: string_helper
INFO - 2020-02-27 09:01:21 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:01:21 --> Controller Class Initialized
INFO - 2020-02-27 09:01:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 09:01:21 --> Pagination Class Initialized
INFO - 2020-02-27 09:01:21 --> Model "M_show" initialized
INFO - 2020-02-27 09:01:21 --> Helper loaded: form_helper
INFO - 2020-02-27 09:01:21 --> Form Validation Class Initialized
INFO - 2020-02-27 09:01:22 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 09:01:22 --> Final output sent to browser
INFO - 2020-02-27 09:01:22 --> Config Class Initialized
INFO - 2020-02-27 09:01:22 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:22 --> Total execution time: 1.2363
DEBUG - 2020-02-27 09:01:22 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:22 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:22 --> URI Class Initialized
DEBUG - 2020-02-27 09:01:22 --> No URI present. Default controller set.
INFO - 2020-02-27 09:01:22 --> Router Class Initialized
INFO - 2020-02-27 09:01:22 --> Output Class Initialized
INFO - 2020-02-27 09:01:22 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:22 --> Input Class Initialized
INFO - 2020-02-27 09:01:22 --> Language Class Initialized
INFO - 2020-02-27 09:01:22 --> Loader Class Initialized
INFO - 2020-02-27 09:01:22 --> Helper loaded: url_helper
INFO - 2020-02-27 09:01:22 --> Helper loaded: string_helper
INFO - 2020-02-27 09:01:22 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:01:22 --> Controller Class Initialized
INFO - 2020-02-27 09:01:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 09:01:22 --> Pagination Class Initialized
INFO - 2020-02-27 09:01:22 --> Model "M_show" initialized
INFO - 2020-02-27 09:01:22 --> Helper loaded: form_helper
INFO - 2020-02-27 09:01:22 --> Form Validation Class Initialized
INFO - 2020-02-27 09:01:22 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 09:01:22 --> Final output sent to browser
DEBUG - 2020-02-27 09:01:23 --> Total execution time: 0.8499
INFO - 2020-02-27 09:01:25 --> Config Class Initialized
INFO - 2020-02-27 09:01:26 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:26 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:26 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:26 --> URI Class Initialized
INFO - 2020-02-27 09:01:26 --> Router Class Initialized
INFO - 2020-02-27 09:01:26 --> Output Class Initialized
INFO - 2020-02-27 09:01:26 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:26 --> Input Class Initialized
INFO - 2020-02-27 09:01:26 --> Language Class Initialized
INFO - 2020-02-27 09:01:26 --> Loader Class Initialized
INFO - 2020-02-27 09:01:26 --> Helper loaded: url_helper
INFO - 2020-02-27 09:01:26 --> Helper loaded: string_helper
INFO - 2020-02-27 09:01:26 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:01:26 --> Controller Class Initialized
INFO - 2020-02-27 09:01:26 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:01:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:01:26 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:01:26 --> Helper loaded: form_helper
INFO - 2020-02-27 09:01:26 --> Form Validation Class Initialized
INFO - 2020-02-27 09:01:26 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:01:26 --> Final output sent to browser
DEBUG - 2020-02-27 09:01:26 --> Total execution time: 0.7521
INFO - 2020-02-27 09:01:26 --> Config Class Initialized
INFO - 2020-02-27 09:01:26 --> Config Class Initialized
INFO - 2020-02-27 09:01:26 --> Config Class Initialized
INFO - 2020-02-27 09:01:26 --> Hooks Class Initialized
INFO - 2020-02-27 09:01:26 --> Hooks Class Initialized
INFO - 2020-02-27 09:01:26 --> Config Class Initialized
INFO - 2020-02-27 09:01:26 --> Config Class Initialized
INFO - 2020-02-27 09:01:26 --> Hooks Class Initialized
INFO - 2020-02-27 09:01:26 --> Config Class Initialized
INFO - 2020-02-27 09:01:26 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:01:26 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:26 --> Hooks Class Initialized
INFO - 2020-02-27 09:01:26 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:26 --> Hooks Class Initialized
INFO - 2020-02-27 09:01:26 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:01:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:01:26 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:26 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:26 --> URI Class Initialized
INFO - 2020-02-27 09:01:26 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:26 --> URI Class Initialized
DEBUG - 2020-02-27 09:01:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:01:26 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:26 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:26 --> URI Class Initialized
INFO - 2020-02-27 09:01:26 --> URI Class Initialized
INFO - 2020-02-27 09:01:26 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:26 --> Router Class Initialized
INFO - 2020-02-27 09:01:26 --> Router Class Initialized
INFO - 2020-02-27 09:01:27 --> URI Class Initialized
INFO - 2020-02-27 09:01:27 --> Router Class Initialized
INFO - 2020-02-27 09:01:27 --> Output Class Initialized
INFO - 2020-02-27 09:01:27 --> Router Class Initialized
INFO - 2020-02-27 09:01:27 --> Router Class Initialized
INFO - 2020-02-27 09:01:27 --> Output Class Initialized
INFO - 2020-02-27 09:01:27 --> URI Class Initialized
INFO - 2020-02-27 09:01:27 --> Output Class Initialized
INFO - 2020-02-27 09:01:27 --> Router Class Initialized
INFO - 2020-02-27 09:01:27 --> Output Class Initialized
INFO - 2020-02-27 09:01:27 --> Security Class Initialized
INFO - 2020-02-27 09:01:27 --> Security Class Initialized
INFO - 2020-02-27 09:01:27 --> Security Class Initialized
INFO - 2020-02-27 09:01:27 --> Output Class Initialized
INFO - 2020-02-27 09:01:27 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:27 --> Security Class Initialized
INFO - 2020-02-27 09:01:27 --> Output Class Initialized
DEBUG - 2020-02-27 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:27 --> Input Class Initialized
INFO - 2020-02-27 09:01:27 --> Input Class Initialized
INFO - 2020-02-27 09:01:27 --> Input Class Initialized
DEBUG - 2020-02-27 09:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:27 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:27 --> Input Class Initialized
INFO - 2020-02-27 09:01:27 --> Input Class Initialized
INFO - 2020-02-27 09:01:27 --> Language Class Initialized
DEBUG - 2020-02-27 09:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:27 --> Language Class Initialized
INFO - 2020-02-27 09:01:27 --> Language Class Initialized
INFO - 2020-02-27 09:01:27 --> Input Class Initialized
INFO - 2020-02-27 09:01:27 --> Language Class Initialized
ERROR - 2020-02-27 09:01:27 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 09:01:27 --> Language Class Initialized
ERROR - 2020-02-27 09:01:27 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-27 09:01:27 --> Loader Class Initialized
INFO - 2020-02-27 09:01:27 --> Language Class Initialized
ERROR - 2020-02-27 09:01:27 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 09:01:27 --> Helper loaded: url_helper
ERROR - 2020-02-27 09:01:27 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 09:01:27 --> Loader Class Initialized
INFO - 2020-02-27 09:01:27 --> Helper loaded: string_helper
INFO - 2020-02-27 09:01:27 --> Helper loaded: url_helper
INFO - 2020-02-27 09:01:27 --> Config Class Initialized
INFO - 2020-02-27 09:01:27 --> Config Class Initialized
INFO - 2020-02-27 09:01:27 --> Config Class Initialized
INFO - 2020-02-27 09:01:27 --> Config Class Initialized
INFO - 2020-02-27 09:01:27 --> Hooks Class Initialized
INFO - 2020-02-27 09:01:27 --> Hooks Class Initialized
INFO - 2020-02-27 09:01:27 --> Hooks Class Initialized
INFO - 2020-02-27 09:01:27 --> Hooks Class Initialized
INFO - 2020-02-27 09:01:27 --> Helper loaded: string_helper
INFO - 2020-02-27 09:01:27 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-27 09:01:27 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:27 --> Database Driver Class Initialized
INFO - 2020-02-27 09:01:27 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:27 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:27 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:27 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-27 09:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:01:27 --> Controller Class Initialized
INFO - 2020-02-27 09:01:27 --> URI Class Initialized
INFO - 2020-02-27 09:01:27 --> URI Class Initialized
INFO - 2020-02-27 09:01:27 --> URI Class Initialized
INFO - 2020-02-27 09:01:27 --> URI Class Initialized
INFO - 2020-02-27 09:01:27 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:01:27 --> Router Class Initialized
INFO - 2020-02-27 09:01:27 --> Router Class Initialized
INFO - 2020-02-27 09:01:27 --> Router Class Initialized
INFO - 2020-02-27 09:01:27 --> Router Class Initialized
INFO - 2020-02-27 09:01:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:01:27 --> Output Class Initialized
INFO - 2020-02-27 09:01:27 --> Output Class Initialized
INFO - 2020-02-27 09:01:27 --> Output Class Initialized
INFO - 2020-02-27 09:01:27 --> Output Class Initialized
INFO - 2020-02-27 09:01:27 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:01:27 --> Security Class Initialized
INFO - 2020-02-27 09:01:27 --> Security Class Initialized
INFO - 2020-02-27 09:01:27 --> Security Class Initialized
INFO - 2020-02-27 09:01:27 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:27 --> Helper loaded: form_helper
INFO - 2020-02-27 09:01:27 --> Input Class Initialized
INFO - 2020-02-27 09:01:27 --> Form Validation Class Initialized
INFO - 2020-02-27 09:01:27 --> Input Class Initialized
INFO - 2020-02-27 09:01:27 --> Input Class Initialized
INFO - 2020-02-27 09:01:27 --> Input Class Initialized
INFO - 2020-02-27 09:01:27 --> Language Class Initialized
INFO - 2020-02-27 09:01:27 --> Language Class Initialized
INFO - 2020-02-27 09:01:27 --> Language Class Initialized
INFO - 2020-02-27 09:01:27 --> Language Class Initialized
ERROR - 2020-02-27 09:01:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:01:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-27 09:01:27 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-27 09:01:27 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 09:01:27 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 09:01:27 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:01:27 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:01:27 --> Final output sent to browser
INFO - 2020-02-27 09:01:27 --> Config Class Initialized
INFO - 2020-02-27 09:01:27 --> Config Class Initialized
INFO - 2020-02-27 09:01:27 --> Config Class Initialized
INFO - 2020-02-27 09:01:27 --> Hooks Class Initialized
INFO - 2020-02-27 09:01:27 --> Hooks Class Initialized
INFO - 2020-02-27 09:01:27 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:27 --> Total execution time: 0.8482
INFO - 2020-02-27 09:01:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-27 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:01:27 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:27 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:27 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:27 --> Controller Class Initialized
INFO - 2020-02-27 09:01:27 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:27 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:01:27 --> URI Class Initialized
INFO - 2020-02-27 09:01:27 --> URI Class Initialized
INFO - 2020-02-27 09:01:27 --> URI Class Initialized
INFO - 2020-02-27 09:01:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:01:27 --> Router Class Initialized
INFO - 2020-02-27 09:01:27 --> Router Class Initialized
INFO - 2020-02-27 09:01:27 --> Router Class Initialized
INFO - 2020-02-27 09:01:27 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:01:27 --> Output Class Initialized
INFO - 2020-02-27 09:01:27 --> Output Class Initialized
INFO - 2020-02-27 09:01:27 --> Output Class Initialized
INFO - 2020-02-27 09:01:27 --> Security Class Initialized
INFO - 2020-02-27 09:01:27 --> Security Class Initialized
INFO - 2020-02-27 09:01:27 --> Security Class Initialized
INFO - 2020-02-27 09:01:27 --> Helper loaded: form_helper
INFO - 2020-02-27 09:01:27 --> Form Validation Class Initialized
DEBUG - 2020-02-27 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:27 --> Input Class Initialized
INFO - 2020-02-27 09:01:27 --> Input Class Initialized
INFO - 2020-02-27 09:01:27 --> Input Class Initialized
ERROR - 2020-02-27 09:01:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:01:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:01:27 --> Language Class Initialized
INFO - 2020-02-27 09:01:27 --> Language Class Initialized
INFO - 2020-02-27 09:01:27 --> Language Class Initialized
INFO - 2020-02-27 09:01:28 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-27 09:01:28 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-27 09:01:28 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 09:01:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 09:01:28 --> Final output sent to browser
INFO - 2020-02-27 09:01:28 --> Config Class Initialized
INFO - 2020-02-27 09:01:28 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:28 --> Total execution time: 1.1777
DEBUG - 2020-02-27 09:01:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:28 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:28 --> URI Class Initialized
INFO - 2020-02-27 09:01:28 --> Router Class Initialized
INFO - 2020-02-27 09:01:28 --> Output Class Initialized
INFO - 2020-02-27 09:01:28 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:28 --> Input Class Initialized
INFO - 2020-02-27 09:01:28 --> Language Class Initialized
ERROR - 2020-02-27 09:01:28 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 09:01:28 --> Config Class Initialized
INFO - 2020-02-27 09:01:28 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:28 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:28 --> URI Class Initialized
INFO - 2020-02-27 09:01:28 --> Router Class Initialized
INFO - 2020-02-27 09:01:28 --> Output Class Initialized
INFO - 2020-02-27 09:01:28 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:28 --> Input Class Initialized
INFO - 2020-02-27 09:01:28 --> Language Class Initialized
ERROR - 2020-02-27 09:01:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 09:01:28 --> Config Class Initialized
INFO - 2020-02-27 09:01:28 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:28 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:28 --> URI Class Initialized
INFO - 2020-02-27 09:01:28 --> Router Class Initialized
INFO - 2020-02-27 09:01:28 --> Output Class Initialized
INFO - 2020-02-27 09:01:28 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:28 --> Input Class Initialized
INFO - 2020-02-27 09:01:29 --> Language Class Initialized
ERROR - 2020-02-27 09:01:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:01:29 --> Config Class Initialized
INFO - 2020-02-27 09:01:29 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:29 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:29 --> URI Class Initialized
INFO - 2020-02-27 09:01:29 --> Router Class Initialized
INFO - 2020-02-27 09:01:29 --> Output Class Initialized
INFO - 2020-02-27 09:01:29 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:29 --> Input Class Initialized
INFO - 2020-02-27 09:01:29 --> Language Class Initialized
ERROR - 2020-02-27 09:01:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:01:29 --> Config Class Initialized
INFO - 2020-02-27 09:01:29 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:29 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:29 --> URI Class Initialized
INFO - 2020-02-27 09:01:29 --> Router Class Initialized
INFO - 2020-02-27 09:01:29 --> Output Class Initialized
INFO - 2020-02-27 09:01:29 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:29 --> Input Class Initialized
INFO - 2020-02-27 09:01:29 --> Language Class Initialized
ERROR - 2020-02-27 09:01:29 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 09:01:29 --> Config Class Initialized
INFO - 2020-02-27 09:01:29 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:29 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:30 --> URI Class Initialized
INFO - 2020-02-27 09:01:30 --> Router Class Initialized
INFO - 2020-02-27 09:01:30 --> Output Class Initialized
INFO - 2020-02-27 09:01:30 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:30 --> Input Class Initialized
INFO - 2020-02-27 09:01:30 --> Language Class Initialized
ERROR - 2020-02-27 09:01:30 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 09:01:30 --> Config Class Initialized
INFO - 2020-02-27 09:01:30 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:30 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:30 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:30 --> URI Class Initialized
INFO - 2020-02-27 09:01:30 --> Router Class Initialized
INFO - 2020-02-27 09:01:30 --> Output Class Initialized
INFO - 2020-02-27 09:01:30 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:30 --> Input Class Initialized
INFO - 2020-02-27 09:01:30 --> Language Class Initialized
ERROR - 2020-02-27 09:01:30 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 09:01:30 --> Config Class Initialized
INFO - 2020-02-27 09:01:30 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:30 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:30 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:30 --> URI Class Initialized
INFO - 2020-02-27 09:01:30 --> Router Class Initialized
INFO - 2020-02-27 09:01:30 --> Output Class Initialized
INFO - 2020-02-27 09:01:30 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:30 --> Input Class Initialized
INFO - 2020-02-27 09:01:30 --> Language Class Initialized
ERROR - 2020-02-27 09:01:30 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 09:01:58 --> Config Class Initialized
INFO - 2020-02-27 09:01:58 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:01:58 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:01:58 --> Utf8 Class Initialized
INFO - 2020-02-27 09:01:58 --> URI Class Initialized
INFO - 2020-02-27 09:01:58 --> Router Class Initialized
INFO - 2020-02-27 09:01:58 --> Output Class Initialized
INFO - 2020-02-27 09:01:58 --> Security Class Initialized
DEBUG - 2020-02-27 09:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:01:58 --> Input Class Initialized
INFO - 2020-02-27 09:01:58 --> Language Class Initialized
INFO - 2020-02-27 09:01:58 --> Loader Class Initialized
INFO - 2020-02-27 09:01:58 --> Helper loaded: url_helper
INFO - 2020-02-27 09:01:58 --> Helper loaded: string_helper
INFO - 2020-02-27 09:01:58 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:01:58 --> Controller Class Initialized
INFO - 2020-02-27 09:01:58 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:01:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:01:58 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:01:59 --> Helper loaded: form_helper
INFO - 2020-02-27 09:01:59 --> Form Validation Class Initialized
INFO - 2020-02-27 15:01:59 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 15:01:59 --> Final output sent to browser
DEBUG - 2020-02-27 15:01:59 --> Total execution time: 0.9230
INFO - 2020-02-27 09:02:08 --> Config Class Initialized
INFO - 2020-02-27 09:02:08 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:02:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:02:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:02:08 --> URI Class Initialized
INFO - 2020-02-27 09:02:08 --> Router Class Initialized
INFO - 2020-02-27 09:02:08 --> Output Class Initialized
INFO - 2020-02-27 09:02:08 --> Security Class Initialized
DEBUG - 2020-02-27 09:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:02:08 --> Input Class Initialized
INFO - 2020-02-27 09:02:08 --> Language Class Initialized
INFO - 2020-02-27 09:02:08 --> Loader Class Initialized
INFO - 2020-02-27 09:02:08 --> Helper loaded: url_helper
INFO - 2020-02-27 09:02:08 --> Helper loaded: string_helper
INFO - 2020-02-27 09:02:08 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:02:08 --> Controller Class Initialized
INFO - 2020-02-27 09:02:08 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:02:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:02:08 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:02:08 --> Helper loaded: form_helper
INFO - 2020-02-27 09:02:08 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:02:08 --> Severity: Notice --> Undefined variable: tanggalp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 09:02:08 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 09:02:08 --> Final output sent to browser
DEBUG - 2020-02-27 09:02:08 --> Total execution time: 0.7956
INFO - 2020-02-27 09:02:23 --> Config Class Initialized
INFO - 2020-02-27 09:02:23 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:02:23 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:02:23 --> Utf8 Class Initialized
INFO - 2020-02-27 09:02:23 --> URI Class Initialized
INFO - 2020-02-27 09:02:23 --> Router Class Initialized
INFO - 2020-02-27 09:02:23 --> Output Class Initialized
INFO - 2020-02-27 09:02:23 --> Security Class Initialized
DEBUG - 2020-02-27 09:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:02:23 --> Input Class Initialized
INFO - 2020-02-27 09:02:23 --> Language Class Initialized
INFO - 2020-02-27 09:02:23 --> Loader Class Initialized
INFO - 2020-02-27 09:02:23 --> Helper loaded: url_helper
INFO - 2020-02-27 09:02:23 --> Helper loaded: string_helper
INFO - 2020-02-27 09:02:23 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:02:23 --> Controller Class Initialized
INFO - 2020-02-27 09:02:23 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:02:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:02:24 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:02:24 --> Helper loaded: form_helper
INFO - 2020-02-27 09:02:24 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:02:24 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 64
ERROR - 2020-02-27 09:02:24 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 65
ERROR - 2020-02-27 09:02:24 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 66
INFO - 2020-02-27 09:02:24 --> Final output sent to browser
DEBUG - 2020-02-27 09:02:24 --> Total execution time: 0.7149
INFO - 2020-02-27 09:03:11 --> Config Class Initialized
INFO - 2020-02-27 09:03:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:03:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:03:11 --> Utf8 Class Initialized
INFO - 2020-02-27 09:03:11 --> URI Class Initialized
INFO - 2020-02-27 09:03:11 --> Router Class Initialized
INFO - 2020-02-27 09:03:11 --> Output Class Initialized
INFO - 2020-02-27 09:03:11 --> Security Class Initialized
DEBUG - 2020-02-27 09:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:03:11 --> Input Class Initialized
INFO - 2020-02-27 09:03:11 --> Language Class Initialized
INFO - 2020-02-27 09:03:11 --> Loader Class Initialized
INFO - 2020-02-27 09:03:11 --> Helper loaded: url_helper
INFO - 2020-02-27 09:03:11 --> Helper loaded: string_helper
INFO - 2020-02-27 09:03:11 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:03:11 --> Controller Class Initialized
INFO - 2020-02-27 09:03:11 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:03:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:03:11 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:03:11 --> Helper loaded: form_helper
INFO - 2020-02-27 09:03:11 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:03:11 --> Severity: Notice --> Undefined index: total_bayar_kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 64
ERROR - 2020-02-27 09:03:11 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 65
ERROR - 2020-02-27 09:03:11 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 66
INFO - 2020-02-27 09:03:11 --> Final output sent to browser
DEBUG - 2020-02-27 09:03:12 --> Total execution time: 0.7184
INFO - 2020-02-27 09:04:21 --> Config Class Initialized
INFO - 2020-02-27 09:04:21 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:04:21 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:04:21 --> Utf8 Class Initialized
INFO - 2020-02-27 09:04:21 --> URI Class Initialized
INFO - 2020-02-27 09:04:21 --> Router Class Initialized
INFO - 2020-02-27 09:04:21 --> Output Class Initialized
INFO - 2020-02-27 09:04:21 --> Security Class Initialized
DEBUG - 2020-02-27 09:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:04:21 --> Input Class Initialized
INFO - 2020-02-27 09:04:21 --> Language Class Initialized
INFO - 2020-02-27 09:04:21 --> Loader Class Initialized
INFO - 2020-02-27 09:04:21 --> Helper loaded: url_helper
INFO - 2020-02-27 09:04:21 --> Helper loaded: string_helper
INFO - 2020-02-27 09:04:21 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:04:22 --> Controller Class Initialized
INFO - 2020-02-27 09:04:22 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:04:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:04:22 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:04:22 --> Helper loaded: form_helper
INFO - 2020-02-27 09:04:22 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:04:22 --> Severity: Notice --> Undefined index: totalbangsat C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 64
ERROR - 2020-02-27 09:04:22 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 65
ERROR - 2020-02-27 09:04:22 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 66
INFO - 2020-02-27 09:04:22 --> Final output sent to browser
DEBUG - 2020-02-27 09:04:22 --> Total execution time: 0.7529
INFO - 2020-02-27 09:04:26 --> Config Class Initialized
INFO - 2020-02-27 09:04:26 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:04:26 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:04:26 --> Utf8 Class Initialized
INFO - 2020-02-27 09:04:26 --> URI Class Initialized
INFO - 2020-02-27 09:04:26 --> Router Class Initialized
INFO - 2020-02-27 09:04:26 --> Output Class Initialized
INFO - 2020-02-27 09:04:26 --> Security Class Initialized
DEBUG - 2020-02-27 09:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:04:26 --> Input Class Initialized
INFO - 2020-02-27 09:04:26 --> Language Class Initialized
INFO - 2020-02-27 09:04:26 --> Loader Class Initialized
INFO - 2020-02-27 09:04:26 --> Helper loaded: url_helper
INFO - 2020-02-27 09:04:26 --> Helper loaded: string_helper
INFO - 2020-02-27 09:04:26 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:04:26 --> Controller Class Initialized
INFO - 2020-02-27 09:04:26 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:04:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:04:26 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:04:26 --> Helper loaded: form_helper
INFO - 2020-02-27 09:04:26 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:04:26 --> Severity: Notice --> Undefined index: totalbangsat C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 64
ERROR - 2020-02-27 09:04:26 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 65
ERROR - 2020-02-27 09:04:26 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 66
INFO - 2020-02-27 09:04:26 --> Final output sent to browser
DEBUG - 2020-02-27 09:04:26 --> Total execution time: 0.7946
INFO - 2020-02-27 09:05:38 --> Config Class Initialized
INFO - 2020-02-27 09:05:38 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:05:38 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:05:38 --> Utf8 Class Initialized
INFO - 2020-02-27 09:05:38 --> URI Class Initialized
INFO - 2020-02-27 09:05:39 --> Router Class Initialized
INFO - 2020-02-27 09:05:39 --> Output Class Initialized
INFO - 2020-02-27 09:05:39 --> Security Class Initialized
DEBUG - 2020-02-27 09:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:05:39 --> Input Class Initialized
INFO - 2020-02-27 09:05:39 --> Language Class Initialized
INFO - 2020-02-27 09:05:39 --> Loader Class Initialized
INFO - 2020-02-27 09:05:39 --> Helper loaded: url_helper
INFO - 2020-02-27 09:05:39 --> Helper loaded: string_helper
INFO - 2020-02-27 09:05:39 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:05:39 --> Controller Class Initialized
INFO - 2020-02-27 09:05:39 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:05:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:05:39 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:05:39 --> Helper loaded: form_helper
INFO - 2020-02-27 09:05:39 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:05:39 --> Severity: Notice --> Undefined index: totalbangsat C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 64
ERROR - 2020-02-27 09:05:39 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 65
ERROR - 2020-02-27 09:05:39 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 66
INFO - 2020-02-27 09:05:39 --> Final output sent to browser
DEBUG - 2020-02-27 09:05:39 --> Total execution time: 0.8202
INFO - 2020-02-27 09:06:01 --> Config Class Initialized
INFO - 2020-02-27 09:06:01 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:06:01 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:06:01 --> Utf8 Class Initialized
INFO - 2020-02-27 09:06:01 --> URI Class Initialized
INFO - 2020-02-27 09:06:01 --> Router Class Initialized
INFO - 2020-02-27 09:06:01 --> Output Class Initialized
INFO - 2020-02-27 09:06:01 --> Security Class Initialized
DEBUG - 2020-02-27 09:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:06:01 --> Input Class Initialized
INFO - 2020-02-27 09:06:01 --> Language Class Initialized
INFO - 2020-02-27 09:06:01 --> Loader Class Initialized
INFO - 2020-02-27 09:06:01 --> Helper loaded: url_helper
INFO - 2020-02-27 09:06:01 --> Helper loaded: string_helper
INFO - 2020-02-27 09:06:01 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:06:01 --> Controller Class Initialized
INFO - 2020-02-27 09:06:01 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:06:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:06:01 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:06:01 --> Helper loaded: form_helper
INFO - 2020-02-27 09:06:01 --> Form Validation Class Initialized
INFO - 2020-02-27 09:06:01 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:06:01 --> Final output sent to browser
DEBUG - 2020-02-27 09:06:01 --> Total execution time: 0.7803
INFO - 2020-02-27 09:06:01 --> Config Class Initialized
INFO - 2020-02-27 09:06:01 --> Config Class Initialized
INFO - 2020-02-27 09:06:01 --> Config Class Initialized
INFO - 2020-02-27 09:06:01 --> Hooks Class Initialized
INFO - 2020-02-27 09:06:01 --> Hooks Class Initialized
INFO - 2020-02-27 09:06:01 --> Config Class Initialized
INFO - 2020-02-27 09:06:02 --> Hooks Class Initialized
INFO - 2020-02-27 09:06:02 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:06:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:06:02 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:06:02 --> Utf8 Class Initialized
INFO - 2020-02-27 09:06:02 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:06:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:06:02 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:06:02 --> Utf8 Class Initialized
INFO - 2020-02-27 09:06:02 --> URI Class Initialized
INFO - 2020-02-27 09:06:02 --> URI Class Initialized
INFO - 2020-02-27 09:06:02 --> Utf8 Class Initialized
INFO - 2020-02-27 09:06:02 --> URI Class Initialized
INFO - 2020-02-27 09:06:02 --> Router Class Initialized
INFO - 2020-02-27 09:06:02 --> Router Class Initialized
INFO - 2020-02-27 09:06:02 --> URI Class Initialized
INFO - 2020-02-27 09:06:02 --> Router Class Initialized
INFO - 2020-02-27 09:06:02 --> Output Class Initialized
INFO - 2020-02-27 09:06:02 --> Output Class Initialized
INFO - 2020-02-27 09:06:02 --> Security Class Initialized
INFO - 2020-02-27 09:06:02 --> Security Class Initialized
INFO - 2020-02-27 09:06:02 --> Router Class Initialized
INFO - 2020-02-27 09:06:02 --> Output Class Initialized
DEBUG - 2020-02-27 09:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:06:02 --> Output Class Initialized
INFO - 2020-02-27 09:06:02 --> Security Class Initialized
INFO - 2020-02-27 09:06:02 --> Input Class Initialized
INFO - 2020-02-27 09:06:02 --> Input Class Initialized
INFO - 2020-02-27 09:06:02 --> Security Class Initialized
DEBUG - 2020-02-27 09:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:06:02 --> Input Class Initialized
INFO - 2020-02-27 09:06:02 --> Language Class Initialized
INFO - 2020-02-27 09:06:02 --> Language Class Initialized
DEBUG - 2020-02-27 09:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:06:02 --> Input Class Initialized
INFO - 2020-02-27 09:06:02 --> Language Class Initialized
ERROR - 2020-02-27 09:06:02 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-27 09:06:02 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 09:06:02 --> Language Class Initialized
INFO - 2020-02-27 09:06:02 --> Loader Class Initialized
INFO - 2020-02-27 09:06:02 --> Helper loaded: url_helper
INFO - 2020-02-27 09:06:02 --> Loader Class Initialized
INFO - 2020-02-27 09:06:02 --> Helper loaded: string_helper
INFO - 2020-02-27 09:06:02 --> Helper loaded: url_helper
INFO - 2020-02-27 09:06:02 --> Helper loaded: string_helper
INFO - 2020-02-27 09:06:02 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:06:02 --> Database Driver Class Initialized
INFO - 2020-02-27 09:06:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-27 09:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:06:02 --> Controller Class Initialized
INFO - 2020-02-27 09:06:02 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:06:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:06:02 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:06:02 --> Helper loaded: form_helper
INFO - 2020-02-27 09:06:02 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:06:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:06:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:06:02 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:06:02 --> Final output sent to browser
DEBUG - 2020-02-27 09:06:02 --> Total execution time: 0.8925
INFO - 2020-02-27 09:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:06:02 --> Controller Class Initialized
INFO - 2020-02-27 09:06:02 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:06:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:06:03 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:06:03 --> Helper loaded: form_helper
INFO - 2020-02-27 09:06:03 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:06:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:06:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:06:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:06:03 --> Final output sent to browser
DEBUG - 2020-02-27 09:06:03 --> Total execution time: 1.2198
INFO - 2020-02-27 09:06:05 --> Config Class Initialized
INFO - 2020-02-27 09:06:05 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:06:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:06:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:06:05 --> URI Class Initialized
INFO - 2020-02-27 09:06:05 --> Router Class Initialized
INFO - 2020-02-27 09:06:05 --> Output Class Initialized
INFO - 2020-02-27 09:06:05 --> Security Class Initialized
DEBUG - 2020-02-27 09:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:06:05 --> Input Class Initialized
INFO - 2020-02-27 09:06:05 --> Language Class Initialized
INFO - 2020-02-27 09:06:05 --> Loader Class Initialized
INFO - 2020-02-27 09:06:05 --> Helper loaded: url_helper
INFO - 2020-02-27 09:06:05 --> Helper loaded: string_helper
INFO - 2020-02-27 09:06:05 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:06:05 --> Controller Class Initialized
INFO - 2020-02-27 09:06:05 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:06:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:06:06 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:06:06 --> Helper loaded: form_helper
INFO - 2020-02-27 09:06:06 --> Form Validation Class Initialized
INFO - 2020-02-27 15:06:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 15:06:06 --> Final output sent to browser
DEBUG - 2020-02-27 15:06:06 --> Total execution time: 0.9094
INFO - 2020-02-27 09:06:15 --> Config Class Initialized
INFO - 2020-02-27 09:06:15 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:06:15 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:06:15 --> Utf8 Class Initialized
INFO - 2020-02-27 09:06:15 --> URI Class Initialized
INFO - 2020-02-27 09:06:15 --> Router Class Initialized
INFO - 2020-02-27 09:06:15 --> Output Class Initialized
INFO - 2020-02-27 09:06:15 --> Security Class Initialized
DEBUG - 2020-02-27 09:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:06:15 --> Input Class Initialized
INFO - 2020-02-27 09:06:15 --> Language Class Initialized
INFO - 2020-02-27 09:06:15 --> Loader Class Initialized
INFO - 2020-02-27 09:06:15 --> Helper loaded: url_helper
INFO - 2020-02-27 09:06:15 --> Helper loaded: string_helper
INFO - 2020-02-27 09:06:15 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:06:16 --> Controller Class Initialized
INFO - 2020-02-27 09:06:16 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:06:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:06:16 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:06:16 --> Helper loaded: form_helper
INFO - 2020-02-27 09:06:16 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:06:16 --> Severity: Notice --> Undefined variable: tanggalp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 09:06:16 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 09:06:16 --> Final output sent to browser
DEBUG - 2020-02-27 09:06:16 --> Total execution time: 0.8017
INFO - 2020-02-27 09:06:25 --> Config Class Initialized
INFO - 2020-02-27 09:06:25 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:06:25 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:06:25 --> Utf8 Class Initialized
INFO - 2020-02-27 09:06:25 --> URI Class Initialized
INFO - 2020-02-27 09:06:25 --> Router Class Initialized
INFO - 2020-02-27 09:06:25 --> Output Class Initialized
INFO - 2020-02-27 09:06:25 --> Security Class Initialized
DEBUG - 2020-02-27 09:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:06:25 --> Input Class Initialized
INFO - 2020-02-27 09:06:25 --> Language Class Initialized
INFO - 2020-02-27 09:06:25 --> Loader Class Initialized
INFO - 2020-02-27 09:06:25 --> Helper loaded: url_helper
INFO - 2020-02-27 09:06:25 --> Helper loaded: string_helper
INFO - 2020-02-27 09:06:25 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:06:25 --> Controller Class Initialized
INFO - 2020-02-27 09:06:26 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:06:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:06:26 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:06:26 --> Helper loaded: form_helper
INFO - 2020-02-27 09:06:26 --> Form Validation Class Initialized
INFO - 2020-02-27 09:06:26 --> Final output sent to browser
DEBUG - 2020-02-27 09:06:26 --> Total execution time: 0.6414
INFO - 2020-02-27 09:06:59 --> Config Class Initialized
INFO - 2020-02-27 09:06:59 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:06:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:06:59 --> Utf8 Class Initialized
INFO - 2020-02-27 09:06:59 --> URI Class Initialized
INFO - 2020-02-27 09:06:59 --> Router Class Initialized
INFO - 2020-02-27 09:06:59 --> Output Class Initialized
INFO - 2020-02-27 09:06:59 --> Security Class Initialized
DEBUG - 2020-02-27 09:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:06:59 --> Input Class Initialized
INFO - 2020-02-27 09:07:00 --> Language Class Initialized
INFO - 2020-02-27 09:07:00 --> Loader Class Initialized
INFO - 2020-02-27 09:07:00 --> Helper loaded: url_helper
INFO - 2020-02-27 09:07:00 --> Helper loaded: string_helper
INFO - 2020-02-27 09:07:00 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:07:00 --> Controller Class Initialized
INFO - 2020-02-27 09:07:00 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:07:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:07:00 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:07:00 --> Helper loaded: form_helper
INFO - 2020-02-27 09:07:00 --> Form Validation Class Initialized
INFO - 2020-02-27 09:07:00 --> Final output sent to browser
DEBUG - 2020-02-27 09:07:00 --> Total execution time: 0.6741
INFO - 2020-02-27 09:08:04 --> Config Class Initialized
INFO - 2020-02-27 09:08:04 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:08:04 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:08:04 --> Utf8 Class Initialized
INFO - 2020-02-27 09:08:04 --> URI Class Initialized
INFO - 2020-02-27 09:08:04 --> Router Class Initialized
INFO - 2020-02-27 09:08:04 --> Output Class Initialized
INFO - 2020-02-27 09:08:04 --> Security Class Initialized
DEBUG - 2020-02-27 09:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:08:04 --> Input Class Initialized
INFO - 2020-02-27 09:08:04 --> Language Class Initialized
ERROR - 2020-02-27 09:08:04 --> Severity: error --> Exception: syntax error, unexpected '"<br>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 68
INFO - 2020-02-27 09:08:20 --> Config Class Initialized
INFO - 2020-02-27 09:08:20 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:08:20 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:08:20 --> Utf8 Class Initialized
INFO - 2020-02-27 09:08:20 --> URI Class Initialized
INFO - 2020-02-27 09:08:20 --> Router Class Initialized
INFO - 2020-02-27 09:08:20 --> Output Class Initialized
INFO - 2020-02-27 09:08:20 --> Security Class Initialized
DEBUG - 2020-02-27 09:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:08:20 --> Input Class Initialized
INFO - 2020-02-27 09:08:20 --> Language Class Initialized
INFO - 2020-02-27 09:08:20 --> Loader Class Initialized
INFO - 2020-02-27 09:08:20 --> Helper loaded: url_helper
INFO - 2020-02-27 09:08:20 --> Helper loaded: string_helper
INFO - 2020-02-27 09:08:20 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:08:20 --> Controller Class Initialized
INFO - 2020-02-27 09:08:20 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:08:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:08:20 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:08:20 --> Helper loaded: form_helper
INFO - 2020-02-27 09:08:20 --> Form Validation Class Initialized
INFO - 2020-02-27 09:08:20 --> Final output sent to browser
DEBUG - 2020-02-27 09:08:20 --> Total execution time: 0.6850
INFO - 2020-02-27 09:08:34 --> Config Class Initialized
INFO - 2020-02-27 09:08:34 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:08:34 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:08:34 --> Utf8 Class Initialized
INFO - 2020-02-27 09:08:34 --> URI Class Initialized
INFO - 2020-02-27 09:08:34 --> Router Class Initialized
INFO - 2020-02-27 09:08:34 --> Output Class Initialized
INFO - 2020-02-27 09:08:34 --> Security Class Initialized
DEBUG - 2020-02-27 09:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:08:34 --> Input Class Initialized
INFO - 2020-02-27 09:08:34 --> Language Class Initialized
INFO - 2020-02-27 09:08:34 --> Loader Class Initialized
INFO - 2020-02-27 09:08:34 --> Helper loaded: url_helper
INFO - 2020-02-27 09:08:35 --> Helper loaded: string_helper
INFO - 2020-02-27 09:08:35 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:08:35 --> Controller Class Initialized
INFO - 2020-02-27 09:08:35 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:08:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:08:35 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:08:35 --> Helper loaded: form_helper
INFO - 2020-02-27 09:08:35 --> Form Validation Class Initialized
INFO - 2020-02-27 09:08:35 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:08:35 --> Final output sent to browser
DEBUG - 2020-02-27 09:08:35 --> Total execution time: 1.0780
INFO - 2020-02-27 09:08:35 --> Config Class Initialized
INFO - 2020-02-27 09:08:35 --> Hooks Class Initialized
INFO - 2020-02-27 09:08:35 --> Config Class Initialized
INFO - 2020-02-27 09:08:35 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:08:35 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:08:35 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:08:35 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:08:35 --> Utf8 Class Initialized
INFO - 2020-02-27 09:08:35 --> URI Class Initialized
INFO - 2020-02-27 09:08:35 --> URI Class Initialized
INFO - 2020-02-27 09:08:35 --> Router Class Initialized
INFO - 2020-02-27 09:08:35 --> Router Class Initialized
INFO - 2020-02-27 09:08:35 --> Output Class Initialized
INFO - 2020-02-27 09:08:35 --> Security Class Initialized
INFO - 2020-02-27 09:08:35 --> Output Class Initialized
DEBUG - 2020-02-27 09:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:08:36 --> Security Class Initialized
INFO - 2020-02-27 09:08:36 --> Input Class Initialized
DEBUG - 2020-02-27 09:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:08:36 --> Input Class Initialized
INFO - 2020-02-27 09:08:36 --> Language Class Initialized
INFO - 2020-02-27 09:08:36 --> Language Class Initialized
INFO - 2020-02-27 09:08:36 --> Loader Class Initialized
INFO - 2020-02-27 09:08:36 --> Helper loaded: url_helper
INFO - 2020-02-27 09:08:36 --> Loader Class Initialized
INFO - 2020-02-27 09:08:36 --> Helper loaded: string_helper
INFO - 2020-02-27 09:08:36 --> Helper loaded: url_helper
INFO - 2020-02-27 09:08:36 --> Helper loaded: string_helper
INFO - 2020-02-27 09:08:36 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:08:36 --> Database Driver Class Initialized
INFO - 2020-02-27 09:08:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-27 09:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:08:36 --> Controller Class Initialized
INFO - 2020-02-27 09:08:36 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:08:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:08:36 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:08:36 --> Helper loaded: form_helper
INFO - 2020-02-27 09:08:36 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:08:36 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:08:36 --> Final output sent to browser
DEBUG - 2020-02-27 09:08:36 --> Total execution time: 1.1137
INFO - 2020-02-27 09:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:08:36 --> Controller Class Initialized
INFO - 2020-02-27 09:08:36 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:08:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:08:36 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:08:36 --> Helper loaded: form_helper
INFO - 2020-02-27 09:08:36 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:08:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:08:37 --> Final output sent to browser
DEBUG - 2020-02-27 09:08:37 --> Total execution time: 1.3742
INFO - 2020-02-27 09:08:39 --> Config Class Initialized
INFO - 2020-02-27 09:08:39 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:08:39 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:08:39 --> Utf8 Class Initialized
INFO - 2020-02-27 09:08:39 --> URI Class Initialized
INFO - 2020-02-27 09:08:39 --> Router Class Initialized
INFO - 2020-02-27 09:08:39 --> Output Class Initialized
INFO - 2020-02-27 09:08:39 --> Security Class Initialized
DEBUG - 2020-02-27 09:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:08:39 --> Input Class Initialized
INFO - 2020-02-27 09:08:39 --> Language Class Initialized
INFO - 2020-02-27 09:08:39 --> Loader Class Initialized
INFO - 2020-02-27 09:08:39 --> Helper loaded: url_helper
INFO - 2020-02-27 09:08:39 --> Helper loaded: string_helper
INFO - 2020-02-27 09:08:39 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:08:39 --> Controller Class Initialized
INFO - 2020-02-27 09:08:39 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:08:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:08:39 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:08:39 --> Helper loaded: form_helper
INFO - 2020-02-27 09:08:39 --> Form Validation Class Initialized
INFO - 2020-02-27 15:08:39 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 15:08:39 --> Final output sent to browser
DEBUG - 2020-02-27 15:08:39 --> Total execution time: 0.8569
INFO - 2020-02-27 09:08:42 --> Config Class Initialized
INFO - 2020-02-27 09:08:42 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:08:42 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:08:42 --> Utf8 Class Initialized
INFO - 2020-02-27 09:08:42 --> URI Class Initialized
INFO - 2020-02-27 09:08:42 --> Router Class Initialized
INFO - 2020-02-27 09:08:42 --> Output Class Initialized
INFO - 2020-02-27 09:08:42 --> Security Class Initialized
DEBUG - 2020-02-27 09:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:08:42 --> Input Class Initialized
INFO - 2020-02-27 09:08:42 --> Language Class Initialized
INFO - 2020-02-27 09:08:42 --> Loader Class Initialized
INFO - 2020-02-27 09:08:42 --> Helper loaded: url_helper
INFO - 2020-02-27 09:08:42 --> Helper loaded: string_helper
INFO - 2020-02-27 09:08:43 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:08:43 --> Controller Class Initialized
INFO - 2020-02-27 09:08:43 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:08:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:08:43 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:08:43 --> Helper loaded: form_helper
INFO - 2020-02-27 09:08:43 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:08:43 --> Severity: Notice --> Undefined variable: tanggalp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 09:08:43 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 09:08:43 --> Final output sent to browser
DEBUG - 2020-02-27 09:08:43 --> Total execution time: 0.7751
INFO - 2020-02-27 09:08:50 --> Config Class Initialized
INFO - 2020-02-27 09:08:50 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:08:50 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:08:50 --> Utf8 Class Initialized
INFO - 2020-02-27 09:08:50 --> URI Class Initialized
INFO - 2020-02-27 09:08:50 --> Router Class Initialized
INFO - 2020-02-27 09:08:50 --> Output Class Initialized
INFO - 2020-02-27 09:08:50 --> Security Class Initialized
DEBUG - 2020-02-27 09:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:08:50 --> Input Class Initialized
INFO - 2020-02-27 09:08:50 --> Language Class Initialized
INFO - 2020-02-27 09:08:50 --> Loader Class Initialized
INFO - 2020-02-27 09:08:50 --> Helper loaded: url_helper
INFO - 2020-02-27 09:08:50 --> Helper loaded: string_helper
INFO - 2020-02-27 09:08:50 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:08:50 --> Controller Class Initialized
INFO - 2020-02-27 09:08:50 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:08:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:08:50 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:08:50 --> Helper loaded: form_helper
INFO - 2020-02-27 09:08:50 --> Form Validation Class Initialized
INFO - 2020-02-27 09:08:50 --> Final output sent to browser
DEBUG - 2020-02-27 09:08:50 --> Total execution time: 0.6658
INFO - 2020-02-27 09:10:17 --> Config Class Initialized
INFO - 2020-02-27 09:10:17 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:10:17 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:10:17 --> Utf8 Class Initialized
INFO - 2020-02-27 09:10:17 --> URI Class Initialized
INFO - 2020-02-27 09:10:18 --> Router Class Initialized
INFO - 2020-02-27 09:10:18 --> Output Class Initialized
INFO - 2020-02-27 09:10:18 --> Security Class Initialized
DEBUG - 2020-02-27 09:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:10:18 --> Input Class Initialized
INFO - 2020-02-27 09:10:18 --> Language Class Initialized
INFO - 2020-02-27 09:10:18 --> Loader Class Initialized
INFO - 2020-02-27 09:10:18 --> Helper loaded: url_helper
INFO - 2020-02-27 09:10:18 --> Helper loaded: string_helper
INFO - 2020-02-27 09:10:18 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:10:18 --> Controller Class Initialized
INFO - 2020-02-27 09:10:18 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:10:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:10:18 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:10:18 --> Helper loaded: form_helper
INFO - 2020-02-27 09:10:18 --> Form Validation Class Initialized
INFO - 2020-02-27 09:10:18 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:10:18 --> Final output sent to browser
DEBUG - 2020-02-27 09:10:18 --> Total execution time: 0.8791
INFO - 2020-02-27 09:10:18 --> Config Class Initialized
INFO - 2020-02-27 09:10:18 --> Config Class Initialized
INFO - 2020-02-27 09:10:18 --> Hooks Class Initialized
INFO - 2020-02-27 09:10:18 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:10:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:10:19 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:10:19 --> Utf8 Class Initialized
INFO - 2020-02-27 09:10:19 --> Utf8 Class Initialized
INFO - 2020-02-27 09:10:19 --> URI Class Initialized
INFO - 2020-02-27 09:10:19 --> URI Class Initialized
INFO - 2020-02-27 09:10:19 --> Router Class Initialized
INFO - 2020-02-27 09:10:19 --> Router Class Initialized
INFO - 2020-02-27 09:10:19 --> Output Class Initialized
INFO - 2020-02-27 09:10:19 --> Output Class Initialized
INFO - 2020-02-27 09:10:19 --> Security Class Initialized
INFO - 2020-02-27 09:10:19 --> Security Class Initialized
DEBUG - 2020-02-27 09:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:10:19 --> Input Class Initialized
INFO - 2020-02-27 09:10:19 --> Input Class Initialized
INFO - 2020-02-27 09:10:19 --> Language Class Initialized
INFO - 2020-02-27 09:10:19 --> Language Class Initialized
INFO - 2020-02-27 09:10:19 --> Loader Class Initialized
INFO - 2020-02-27 09:10:19 --> Loader Class Initialized
INFO - 2020-02-27 09:10:19 --> Helper loaded: url_helper
INFO - 2020-02-27 09:10:19 --> Helper loaded: url_helper
INFO - 2020-02-27 09:10:19 --> Helper loaded: string_helper
INFO - 2020-02-27 09:10:19 --> Helper loaded: string_helper
INFO - 2020-02-27 09:10:19 --> Database Driver Class Initialized
INFO - 2020-02-27 09:10:19 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-27 09:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:10:19 --> Controller Class Initialized
INFO - 2020-02-27 09:10:19 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:10:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:10:19 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:10:19 --> Helper loaded: form_helper
INFO - 2020-02-27 09:10:19 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:10:19 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:10:19 --> Final output sent to browser
DEBUG - 2020-02-27 09:10:19 --> Total execution time: 0.9060
INFO - 2020-02-27 09:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:10:19 --> Controller Class Initialized
INFO - 2020-02-27 09:10:19 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:10:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:10:19 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:10:19 --> Helper loaded: form_helper
INFO - 2020-02-27 09:10:20 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:10:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:10:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:10:20 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:10:20 --> Final output sent to browser
DEBUG - 2020-02-27 09:10:20 --> Total execution time: 1.2383
INFO - 2020-02-27 09:10:24 --> Config Class Initialized
INFO - 2020-02-27 09:10:24 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:10:24 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:10:24 --> Utf8 Class Initialized
INFO - 2020-02-27 09:10:24 --> URI Class Initialized
INFO - 2020-02-27 09:10:24 --> Router Class Initialized
INFO - 2020-02-27 09:10:24 --> Output Class Initialized
INFO - 2020-02-27 09:10:24 --> Security Class Initialized
DEBUG - 2020-02-27 09:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:10:25 --> Input Class Initialized
INFO - 2020-02-27 09:10:25 --> Language Class Initialized
INFO - 2020-02-27 09:10:25 --> Loader Class Initialized
INFO - 2020-02-27 09:10:25 --> Helper loaded: url_helper
INFO - 2020-02-27 09:10:25 --> Helper loaded: string_helper
INFO - 2020-02-27 09:10:25 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:10:25 --> Controller Class Initialized
INFO - 2020-02-27 09:10:25 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:10:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:10:25 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:10:25 --> Helper loaded: form_helper
INFO - 2020-02-27 09:10:25 --> Form Validation Class Initialized
INFO - 2020-02-27 15:10:25 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 15:10:25 --> Final output sent to browser
DEBUG - 2020-02-27 15:10:25 --> Total execution time: 0.9155
INFO - 2020-02-27 09:11:31 --> Config Class Initialized
INFO - 2020-02-27 09:11:31 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:11:31 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:11:31 --> Utf8 Class Initialized
INFO - 2020-02-27 09:11:31 --> URI Class Initialized
INFO - 2020-02-27 09:11:31 --> Router Class Initialized
INFO - 2020-02-27 09:11:31 --> Output Class Initialized
INFO - 2020-02-27 09:11:31 --> Security Class Initialized
DEBUG - 2020-02-27 09:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:11:31 --> Input Class Initialized
INFO - 2020-02-27 09:11:31 --> Language Class Initialized
INFO - 2020-02-27 09:11:31 --> Loader Class Initialized
INFO - 2020-02-27 09:11:31 --> Helper loaded: url_helper
INFO - 2020-02-27 09:11:31 --> Helper loaded: string_helper
INFO - 2020-02-27 09:11:31 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:11:32 --> Controller Class Initialized
INFO - 2020-02-27 09:11:32 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:11:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:11:32 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:11:32 --> Helper loaded: form_helper
INFO - 2020-02-27 09:11:32 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:11:32 --> Severity: Notice --> Undefined variable: tanggalp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 09:11:32 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 09:11:32 --> Final output sent to browser
DEBUG - 2020-02-27 09:11:32 --> Total execution time: 0.8214
INFO - 2020-02-27 09:11:40 --> Config Class Initialized
INFO - 2020-02-27 09:11:40 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:11:40 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:11:40 --> Utf8 Class Initialized
INFO - 2020-02-27 09:11:40 --> URI Class Initialized
INFO - 2020-02-27 09:11:40 --> Router Class Initialized
INFO - 2020-02-27 09:11:40 --> Output Class Initialized
INFO - 2020-02-27 09:11:41 --> Security Class Initialized
DEBUG - 2020-02-27 09:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:11:41 --> Input Class Initialized
INFO - 2020-02-27 09:11:41 --> Language Class Initialized
INFO - 2020-02-27 09:11:41 --> Loader Class Initialized
INFO - 2020-02-27 09:11:41 --> Helper loaded: url_helper
INFO - 2020-02-27 09:11:41 --> Helper loaded: string_helper
INFO - 2020-02-27 09:11:41 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:11:41 --> Controller Class Initialized
INFO - 2020-02-27 09:11:41 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:11:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:11:41 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:11:41 --> Helper loaded: form_helper
INFO - 2020-02-27 09:11:41 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:11:41 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`musikologi-v3`.`pemesanan`, CONSTRAINT `pemesanan_ibfk_2` FOREIGN KEY (`id_tiket`) REFERENCES `jenis_tiket` (`id_jenis`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: UPDATE `pemesanan` SET `id_tiket` = NULL, `totalbayar` = '240801', `status_pemesanan` = NULL, `jumlah_pesanan` = NULL, `tanggal_pesan` = NULL, `tanggal_exp` = NULL, `tanggal_approve` = NULL, `kode_unik` = 'PM195', `tanggal_penukaran` = NULL, `bukti_bayar` = 'default.jpg'
WHERE `kode_unik` = 'PM195'
INFO - 2020-02-27 09:11:41 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-27 09:21:49 --> Config Class Initialized
INFO - 2020-02-27 09:21:49 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:21:49 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:21:49 --> Utf8 Class Initialized
INFO - 2020-02-27 09:21:49 --> URI Class Initialized
INFO - 2020-02-27 09:21:49 --> Router Class Initialized
INFO - 2020-02-27 09:21:49 --> Output Class Initialized
INFO - 2020-02-27 09:21:49 --> Security Class Initialized
DEBUG - 2020-02-27 09:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:21:49 --> Input Class Initialized
INFO - 2020-02-27 09:21:49 --> Language Class Initialized
INFO - 2020-02-27 09:21:49 --> Loader Class Initialized
INFO - 2020-02-27 09:21:49 --> Helper loaded: url_helper
INFO - 2020-02-27 09:21:49 --> Helper loaded: string_helper
INFO - 2020-02-27 09:21:50 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:21:50 --> Controller Class Initialized
INFO - 2020-02-27 09:21:50 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:21:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:21:50 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:21:50 --> Helper loaded: form_helper
INFO - 2020-02-27 09:21:50 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:21:50 --> Query error: Unknown column 'status' in 'field list' - Invalid query: UPDATE `pemesanan` SET `status` = 'PM195'
WHERE `kode_unik` = 'PM195'
INFO - 2020-02-27 09:21:50 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-27 09:22:57 --> Config Class Initialized
INFO - 2020-02-27 09:22:57 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:22:57 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:22:57 --> Utf8 Class Initialized
INFO - 2020-02-27 09:22:57 --> URI Class Initialized
INFO - 2020-02-27 09:22:57 --> Router Class Initialized
INFO - 2020-02-27 09:22:57 --> Output Class Initialized
INFO - 2020-02-27 09:22:57 --> Security Class Initialized
DEBUG - 2020-02-27 09:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:22:57 --> Input Class Initialized
INFO - 2020-02-27 09:22:57 --> Language Class Initialized
INFO - 2020-02-27 09:22:57 --> Loader Class Initialized
INFO - 2020-02-27 09:22:57 --> Helper loaded: url_helper
INFO - 2020-02-27 09:22:57 --> Helper loaded: string_helper
INFO - 2020-02-27 09:22:57 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:22:57 --> Controller Class Initialized
INFO - 2020-02-27 09:22:57 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:22:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:22:57 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:22:57 --> Helper loaded: form_helper
INFO - 2020-02-27 09:22:58 --> Form Validation Class Initialized
INFO - 2020-02-27 09:22:58 --> Final output sent to browser
DEBUG - 2020-02-27 09:22:58 --> Total execution time: 0.7937
INFO - 2020-02-27 09:25:04 --> Config Class Initialized
INFO - 2020-02-27 09:25:04 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:04 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:04 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:04 --> URI Class Initialized
INFO - 2020-02-27 09:25:04 --> Router Class Initialized
INFO - 2020-02-27 09:25:04 --> Output Class Initialized
INFO - 2020-02-27 09:25:04 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:04 --> Input Class Initialized
INFO - 2020-02-27 09:25:04 --> Language Class Initialized
INFO - 2020-02-27 09:25:04 --> Loader Class Initialized
INFO - 2020-02-27 09:25:04 --> Helper loaded: url_helper
INFO - 2020-02-27 09:25:04 --> Helper loaded: string_helper
INFO - 2020-02-27 09:25:04 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:25:04 --> Controller Class Initialized
INFO - 2020-02-27 09:25:04 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:25:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:25:04 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:25:04 --> Helper loaded: form_helper
INFO - 2020-02-27 09:25:04 --> Form Validation Class Initialized
INFO - 2020-02-27 09:25:04 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:25:04 --> Final output sent to browser
DEBUG - 2020-02-27 09:25:04 --> Total execution time: 0.8224
INFO - 2020-02-27 09:25:04 --> Config Class Initialized
INFO - 2020-02-27 09:25:04 --> Config Class Initialized
INFO - 2020-02-27 09:25:05 --> Hooks Class Initialized
INFO - 2020-02-27 09:25:05 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:25:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:05 --> URI Class Initialized
INFO - 2020-02-27 09:25:05 --> URI Class Initialized
INFO - 2020-02-27 09:25:05 --> Router Class Initialized
INFO - 2020-02-27 09:25:05 --> Router Class Initialized
INFO - 2020-02-27 09:25:05 --> Output Class Initialized
INFO - 2020-02-27 09:25:05 --> Security Class Initialized
INFO - 2020-02-27 09:25:05 --> Output Class Initialized
INFO - 2020-02-27 09:25:05 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:05 --> Input Class Initialized
DEBUG - 2020-02-27 09:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:05 --> Input Class Initialized
INFO - 2020-02-27 09:25:05 --> Language Class Initialized
INFO - 2020-02-27 09:25:05 --> Language Class Initialized
INFO - 2020-02-27 09:25:05 --> Loader Class Initialized
INFO - 2020-02-27 09:25:05 --> Helper loaded: url_helper
INFO - 2020-02-27 09:25:05 --> Loader Class Initialized
INFO - 2020-02-27 09:25:05 --> Helper loaded: string_helper
INFO - 2020-02-27 09:25:05 --> Helper loaded: url_helper
INFO - 2020-02-27 09:25:05 --> Helper loaded: string_helper
INFO - 2020-02-27 09:25:05 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:25:05 --> Database Driver Class Initialized
INFO - 2020-02-27 09:25:05 --> Controller Class Initialized
DEBUG - 2020-02-27 09:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:25:05 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:25:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:25:05 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:25:05 --> Helper loaded: form_helper
INFO - 2020-02-27 09:25:05 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:25:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:25:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:25:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:25:05 --> Final output sent to browser
DEBUG - 2020-02-27 09:25:05 --> Total execution time: 0.9301
INFO - 2020-02-27 09:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:25:05 --> Controller Class Initialized
INFO - 2020-02-27 09:25:05 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:25:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:25:06 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:25:06 --> Helper loaded: form_helper
INFO - 2020-02-27 09:25:06 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:25:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:25:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:25:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:25:06 --> Final output sent to browser
DEBUG - 2020-02-27 09:25:06 --> Total execution time: 1.2964
INFO - 2020-02-27 09:25:07 --> Config Class Initialized
INFO - 2020-02-27 09:25:07 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:07 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:07 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:07 --> URI Class Initialized
INFO - 2020-02-27 09:25:07 --> Router Class Initialized
INFO - 2020-02-27 09:25:07 --> Output Class Initialized
INFO - 2020-02-27 09:25:07 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:08 --> Input Class Initialized
INFO - 2020-02-27 09:25:08 --> Language Class Initialized
INFO - 2020-02-27 09:25:08 --> Loader Class Initialized
INFO - 2020-02-27 09:25:08 --> Helper loaded: url_helper
INFO - 2020-02-27 09:25:08 --> Helper loaded: string_helper
INFO - 2020-02-27 09:25:08 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:25:08 --> Controller Class Initialized
INFO - 2020-02-27 09:25:08 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:25:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:25:08 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:25:08 --> Helper loaded: form_helper
INFO - 2020-02-27 09:25:08 --> Form Validation Class Initialized
INFO - 2020-02-27 09:25:08 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:25:08 --> Final output sent to browser
INFO - 2020-02-27 09:25:08 --> Config Class Initialized
INFO - 2020-02-27 09:25:08 --> Config Class Initialized
INFO - 2020-02-27 09:25:08 --> Config Class Initialized
INFO - 2020-02-27 09:25:08 --> Config Class Initialized
INFO - 2020-02-27 09:25:08 --> Hooks Class Initialized
INFO - 2020-02-27 09:25:08 --> Hooks Class Initialized
INFO - 2020-02-27 09:25:08 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:08 --> Total execution time: 0.7618
INFO - 2020-02-27 09:25:08 --> Hooks Class Initialized
INFO - 2020-02-27 09:25:08 --> Config Class Initialized
INFO - 2020-02-27 09:25:08 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:25:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:25:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:25:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:08 --> Config Class Initialized
INFO - 2020-02-27 09:25:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:08 --> Hooks Class Initialized
INFO - 2020-02-27 09:25:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:08 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:25:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:08 --> URI Class Initialized
INFO - 2020-02-27 09:25:08 --> URI Class Initialized
INFO - 2020-02-27 09:25:08 --> URI Class Initialized
INFO - 2020-02-27 09:25:08 --> URI Class Initialized
DEBUG - 2020-02-27 09:25:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:08 --> Router Class Initialized
INFO - 2020-02-27 09:25:08 --> Router Class Initialized
INFO - 2020-02-27 09:25:08 --> Router Class Initialized
INFO - 2020-02-27 09:25:08 --> Router Class Initialized
INFO - 2020-02-27 09:25:08 --> URI Class Initialized
INFO - 2020-02-27 09:25:08 --> URI Class Initialized
INFO - 2020-02-27 09:25:08 --> Router Class Initialized
INFO - 2020-02-27 09:25:08 --> Output Class Initialized
INFO - 2020-02-27 09:25:08 --> Output Class Initialized
INFO - 2020-02-27 09:25:08 --> Output Class Initialized
INFO - 2020-02-27 09:25:08 --> Output Class Initialized
INFO - 2020-02-27 09:25:08 --> Security Class Initialized
INFO - 2020-02-27 09:25:08 --> Router Class Initialized
INFO - 2020-02-27 09:25:08 --> Output Class Initialized
INFO - 2020-02-27 09:25:08 --> Security Class Initialized
INFO - 2020-02-27 09:25:08 --> Security Class Initialized
INFO - 2020-02-27 09:25:08 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:08 --> Security Class Initialized
INFO - 2020-02-27 09:25:08 --> Output Class Initialized
DEBUG - 2020-02-27 09:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:08 --> Input Class Initialized
INFO - 2020-02-27 09:25:08 --> Input Class Initialized
INFO - 2020-02-27 09:25:08 --> Input Class Initialized
INFO - 2020-02-27 09:25:08 --> Input Class Initialized
INFO - 2020-02-27 09:25:08 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:08 --> Language Class Initialized
INFO - 2020-02-27 09:25:08 --> Language Class Initialized
DEBUG - 2020-02-27 09:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:08 --> Input Class Initialized
INFO - 2020-02-27 09:25:08 --> Language Class Initialized
INFO - 2020-02-27 09:25:08 --> Language Class Initialized
INFO - 2020-02-27 09:25:08 --> Input Class Initialized
INFO - 2020-02-27 09:25:08 --> Language Class Initialized
ERROR - 2020-02-27 09:25:08 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 09:25:08 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 09:25:08 --> Loader Class Initialized
INFO - 2020-02-27 09:25:08 --> Loader Class Initialized
ERROR - 2020-02-27 09:25:08 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-27 09:25:08 --> Helper loaded: url_helper
INFO - 2020-02-27 09:25:08 --> Helper loaded: url_helper
INFO - 2020-02-27 09:25:08 --> Language Class Initialized
INFO - 2020-02-27 09:25:08 --> Config Class Initialized
INFO - 2020-02-27 09:25:08 --> Config Class Initialized
INFO - 2020-02-27 09:25:09 --> Hooks Class Initialized
INFO - 2020-02-27 09:25:09 --> Hooks Class Initialized
INFO - 2020-02-27 09:25:09 --> Helper loaded: string_helper
ERROR - 2020-02-27 09:25:09 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 09:25:09 --> Helper loaded: string_helper
INFO - 2020-02-27 09:25:09 --> Config Class Initialized
INFO - 2020-02-27 09:25:09 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:25:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:09 --> Database Driver Class Initialized
INFO - 2020-02-27 09:25:09 --> Database Driver Class Initialized
INFO - 2020-02-27 09:25:09 --> Config Class Initialized
INFO - 2020-02-27 09:25:09 --> Hooks Class Initialized
INFO - 2020-02-27 09:25:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:09 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-27 09:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-27 09:25:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:25:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:09 --> URI Class Initialized
INFO - 2020-02-27 09:25:09 --> URI Class Initialized
DEBUG - 2020-02-27 09:25:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:09 --> Controller Class Initialized
INFO - 2020-02-27 09:25:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:09 --> URI Class Initialized
INFO - 2020-02-27 09:25:09 --> Router Class Initialized
INFO - 2020-02-27 09:25:09 --> Router Class Initialized
INFO - 2020-02-27 09:25:09 --> Router Class Initialized
INFO - 2020-02-27 09:25:09 --> Output Class Initialized
INFO - 2020-02-27 09:25:09 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:25:09 --> Output Class Initialized
INFO - 2020-02-27 09:25:09 --> URI Class Initialized
INFO - 2020-02-27 09:25:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:25:09 --> Security Class Initialized
INFO - 2020-02-27 09:25:09 --> Output Class Initialized
INFO - 2020-02-27 09:25:09 --> Router Class Initialized
INFO - 2020-02-27 09:25:09 --> Security Class Initialized
INFO - 2020-02-27 09:25:09 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 09:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:09 --> Output Class Initialized
DEBUG - 2020-02-27 09:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:09 --> Security Class Initialized
INFO - 2020-02-27 09:25:09 --> Input Class Initialized
INFO - 2020-02-27 09:25:09 --> Security Class Initialized
INFO - 2020-02-27 09:25:09 --> Input Class Initialized
DEBUG - 2020-02-27 09:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:09 --> Helper loaded: form_helper
INFO - 2020-02-27 09:25:09 --> Input Class Initialized
INFO - 2020-02-27 09:25:09 --> Form Validation Class Initialized
INFO - 2020-02-27 09:25:09 --> Language Class Initialized
INFO - 2020-02-27 09:25:09 --> Language Class Initialized
DEBUG - 2020-02-27 09:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:09 --> Input Class Initialized
INFO - 2020-02-27 09:25:09 --> Language Class Initialized
ERROR - 2020-02-27 09:25:09 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 09:25:09 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-27 09:25:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-27 09:25:09 --> Language Class Initialized
ERROR - 2020-02-27 09:25:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-27 09:25:09 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:25:09 --> Config Class Initialized
INFO - 2020-02-27 09:25:09 --> Config Class Initialized
INFO - 2020-02-27 09:25:09 --> Hooks Class Initialized
INFO - 2020-02-27 09:25:09 --> Hooks Class Initialized
INFO - 2020-02-27 09:25:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-27 09:25:09 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 09:25:09 --> Config Class Initialized
INFO - 2020-02-27 09:25:09 --> Hooks Class Initialized
INFO - 2020-02-27 09:25:09 --> Final output sent to browser
DEBUG - 2020-02-27 09:25:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:25:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:09 --> Config Class Initialized
INFO - 2020-02-27 09:25:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:09 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:09 --> Total execution time: 0.8995
DEBUG - 2020-02-27 09:25:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:09 --> URI Class Initialized
INFO - 2020-02-27 09:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:25:09 --> URI Class Initialized
DEBUG - 2020-02-27 09:25:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:09 --> Controller Class Initialized
INFO - 2020-02-27 09:25:09 --> Router Class Initialized
INFO - 2020-02-27 09:25:09 --> Router Class Initialized
INFO - 2020-02-27 09:25:09 --> URI Class Initialized
INFO - 2020-02-27 09:25:09 --> URI Class Initialized
INFO - 2020-02-27 09:25:09 --> Router Class Initialized
INFO - 2020-02-27 09:25:09 --> Output Class Initialized
INFO - 2020-02-27 09:25:09 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:25:09 --> Output Class Initialized
INFO - 2020-02-27 09:25:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:25:09 --> Security Class Initialized
INFO - 2020-02-27 09:25:09 --> Output Class Initialized
INFO - 2020-02-27 09:25:09 --> Security Class Initialized
INFO - 2020-02-27 09:25:09 --> Router Class Initialized
INFO - 2020-02-27 09:25:09 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:09 --> Output Class Initialized
INFO - 2020-02-27 09:25:09 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:25:09 --> Input Class Initialized
INFO - 2020-02-27 09:25:09 --> Input Class Initialized
INFO - 2020-02-27 09:25:09 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:09 --> Helper loaded: form_helper
INFO - 2020-02-27 09:25:09 --> Input Class Initialized
INFO - 2020-02-27 09:25:09 --> Form Validation Class Initialized
INFO - 2020-02-27 09:25:09 --> Language Class Initialized
INFO - 2020-02-27 09:25:09 --> Language Class Initialized
DEBUG - 2020-02-27 09:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:09 --> Language Class Initialized
INFO - 2020-02-27 09:25:09 --> Input Class Initialized
ERROR - 2020-02-27 09:25:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-27 09:25:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-27 09:25:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-27 09:25:09 --> Language Class Initialized
ERROR - 2020-02-27 09:25:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-27 09:25:09 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 09:25:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-27 09:25:09 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 09:25:09 --> Final output sent to browser
INFO - 2020-02-27 09:25:09 --> Config Class Initialized
INFO - 2020-02-27 09:25:09 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:09 --> Total execution time: 1.2851
DEBUG - 2020-02-27 09:25:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:09 --> URI Class Initialized
INFO - 2020-02-27 09:25:10 --> Router Class Initialized
INFO - 2020-02-27 09:25:10 --> Output Class Initialized
INFO - 2020-02-27 09:25:10 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:10 --> Input Class Initialized
INFO - 2020-02-27 09:25:10 --> Language Class Initialized
ERROR - 2020-02-27 09:25:10 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 09:25:10 --> Config Class Initialized
INFO - 2020-02-27 09:25:10 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:10 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:10 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:10 --> URI Class Initialized
INFO - 2020-02-27 09:25:10 --> Router Class Initialized
INFO - 2020-02-27 09:25:10 --> Output Class Initialized
INFO - 2020-02-27 09:25:10 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:10 --> Input Class Initialized
INFO - 2020-02-27 09:25:10 --> Language Class Initialized
ERROR - 2020-02-27 09:25:10 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 09:25:10 --> Config Class Initialized
INFO - 2020-02-27 09:25:10 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:10 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:10 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:10 --> URI Class Initialized
INFO - 2020-02-27 09:25:10 --> Router Class Initialized
INFO - 2020-02-27 09:25:10 --> Output Class Initialized
INFO - 2020-02-27 09:25:10 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:10 --> Input Class Initialized
INFO - 2020-02-27 09:25:10 --> Language Class Initialized
ERROR - 2020-02-27 09:25:11 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 09:25:11 --> Config Class Initialized
INFO - 2020-02-27 09:25:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:11 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:11 --> URI Class Initialized
INFO - 2020-02-27 09:25:11 --> Router Class Initialized
INFO - 2020-02-27 09:25:11 --> Output Class Initialized
INFO - 2020-02-27 09:25:11 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:11 --> Input Class Initialized
INFO - 2020-02-27 09:25:11 --> Language Class Initialized
ERROR - 2020-02-27 09:25:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:25:11 --> Config Class Initialized
INFO - 2020-02-27 09:25:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:11 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:11 --> URI Class Initialized
INFO - 2020-02-27 09:25:11 --> Router Class Initialized
INFO - 2020-02-27 09:25:11 --> Output Class Initialized
INFO - 2020-02-27 09:25:11 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:11 --> Input Class Initialized
INFO - 2020-02-27 09:25:11 --> Language Class Initialized
ERROR - 2020-02-27 09:25:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:25:11 --> Config Class Initialized
INFO - 2020-02-27 09:25:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:11 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:11 --> URI Class Initialized
INFO - 2020-02-27 09:25:12 --> Router Class Initialized
INFO - 2020-02-27 09:25:12 --> Output Class Initialized
INFO - 2020-02-27 09:25:12 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:12 --> Input Class Initialized
INFO - 2020-02-27 09:25:12 --> Language Class Initialized
ERROR - 2020-02-27 09:25:12 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 09:25:12 --> Config Class Initialized
INFO - 2020-02-27 09:25:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:12 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:12 --> URI Class Initialized
INFO - 2020-02-27 09:25:12 --> Router Class Initialized
INFO - 2020-02-27 09:25:12 --> Output Class Initialized
INFO - 2020-02-27 09:25:12 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:12 --> Input Class Initialized
INFO - 2020-02-27 09:25:12 --> Language Class Initialized
ERROR - 2020-02-27 09:25:12 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 09:25:12 --> Config Class Initialized
INFO - 2020-02-27 09:25:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:12 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:12 --> URI Class Initialized
INFO - 2020-02-27 09:25:12 --> Router Class Initialized
INFO - 2020-02-27 09:25:13 --> Output Class Initialized
INFO - 2020-02-27 09:25:13 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:13 --> Input Class Initialized
INFO - 2020-02-27 09:25:13 --> Language Class Initialized
ERROR - 2020-02-27 09:25:13 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 09:25:13 --> Config Class Initialized
INFO - 2020-02-27 09:25:13 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:13 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:13 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:13 --> URI Class Initialized
INFO - 2020-02-27 09:25:13 --> Router Class Initialized
INFO - 2020-02-27 09:25:13 --> Output Class Initialized
INFO - 2020-02-27 09:25:13 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:13 --> Input Class Initialized
INFO - 2020-02-27 09:25:13 --> Language Class Initialized
ERROR - 2020-02-27 09:25:13 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 09:25:43 --> Config Class Initialized
INFO - 2020-02-27 09:25:43 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:44 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:44 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:44 --> URI Class Initialized
INFO - 2020-02-27 09:25:44 --> Router Class Initialized
INFO - 2020-02-27 09:25:44 --> Output Class Initialized
INFO - 2020-02-27 09:25:44 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:44 --> Input Class Initialized
INFO - 2020-02-27 09:25:44 --> Language Class Initialized
INFO - 2020-02-27 09:25:44 --> Loader Class Initialized
INFO - 2020-02-27 09:25:44 --> Helper loaded: url_helper
INFO - 2020-02-27 09:25:44 --> Helper loaded: string_helper
INFO - 2020-02-27 09:25:44 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:25:44 --> Controller Class Initialized
INFO - 2020-02-27 09:25:44 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:25:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:25:44 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:25:44 --> Helper loaded: form_helper
INFO - 2020-02-27 09:25:44 --> Form Validation Class Initialized
INFO - 2020-02-27 15:25:44 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 15:25:44 --> Final output sent to browser
DEBUG - 2020-02-27 15:25:44 --> Total execution time: 0.8712
INFO - 2020-02-27 09:25:47 --> Config Class Initialized
INFO - 2020-02-27 09:25:47 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:25:47 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:25:47 --> Utf8 Class Initialized
INFO - 2020-02-27 09:25:47 --> URI Class Initialized
INFO - 2020-02-27 09:25:47 --> Router Class Initialized
INFO - 2020-02-27 09:25:47 --> Output Class Initialized
INFO - 2020-02-27 09:25:47 --> Security Class Initialized
DEBUG - 2020-02-27 09:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:25:47 --> Input Class Initialized
INFO - 2020-02-27 09:25:47 --> Language Class Initialized
INFO - 2020-02-27 09:25:47 --> Loader Class Initialized
INFO - 2020-02-27 09:25:47 --> Helper loaded: url_helper
INFO - 2020-02-27 09:25:47 --> Helper loaded: string_helper
INFO - 2020-02-27 09:25:47 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:25:47 --> Controller Class Initialized
INFO - 2020-02-27 09:25:47 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:25:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:25:47 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:25:47 --> Helper loaded: form_helper
INFO - 2020-02-27 09:25:47 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:25:47 --> Severity: Notice --> Undefined variable: tanggalp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 09:25:47 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 09:25:47 --> Final output sent to browser
DEBUG - 2020-02-27 09:25:47 --> Total execution time: 0.7386
INFO - 2020-02-27 09:26:09 --> Config Class Initialized
INFO - 2020-02-27 09:26:09 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:26:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:26:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:26:09 --> URI Class Initialized
INFO - 2020-02-27 09:26:09 --> Router Class Initialized
INFO - 2020-02-27 09:26:09 --> Output Class Initialized
INFO - 2020-02-27 09:26:09 --> Security Class Initialized
DEBUG - 2020-02-27 09:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:26:10 --> Input Class Initialized
INFO - 2020-02-27 09:26:10 --> Language Class Initialized
INFO - 2020-02-27 09:26:10 --> Loader Class Initialized
INFO - 2020-02-27 09:26:10 --> Helper loaded: url_helper
INFO - 2020-02-27 09:26:10 --> Helper loaded: string_helper
INFO - 2020-02-27 09:26:10 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:26:10 --> Controller Class Initialized
INFO - 2020-02-27 09:26:10 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:26:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:26:10 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:26:10 --> Helper loaded: form_helper
INFO - 2020-02-27 09:26:10 --> Form Validation Class Initialized
INFO - 2020-02-27 09:26:10 --> Upload Class Initialized
INFO - 2020-02-27 09:26:10 --> Final output sent to browser
DEBUG - 2020-02-27 09:26:10 --> Total execution time: 1.2266
INFO - 2020-02-27 09:30:02 --> Config Class Initialized
INFO - 2020-02-27 09:30:02 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:02 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:02 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:02 --> URI Class Initialized
DEBUG - 2020-02-27 09:30:02 --> No URI present. Default controller set.
INFO - 2020-02-27 09:30:02 --> Router Class Initialized
INFO - 2020-02-27 09:30:02 --> Output Class Initialized
INFO - 2020-02-27 09:30:02 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:02 --> Input Class Initialized
INFO - 2020-02-27 09:30:02 --> Language Class Initialized
INFO - 2020-02-27 09:30:02 --> Loader Class Initialized
INFO - 2020-02-27 09:30:02 --> Helper loaded: url_helper
INFO - 2020-02-27 09:30:02 --> Helper loaded: string_helper
INFO - 2020-02-27 09:30:02 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:30:02 --> Controller Class Initialized
INFO - 2020-02-27 09:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 09:30:03 --> Pagination Class Initialized
INFO - 2020-02-27 09:30:03 --> Model "M_show" initialized
INFO - 2020-02-27 09:30:03 --> Helper loaded: form_helper
INFO - 2020-02-27 09:30:03 --> Form Validation Class Initialized
INFO - 2020-02-27 09:30:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 09:30:03 --> Final output sent to browser
INFO - 2020-02-27 09:30:03 --> Config Class Initialized
INFO - 2020-02-27 09:30:03 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:03 --> Total execution time: 0.8978
DEBUG - 2020-02-27 09:30:03 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:03 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:03 --> URI Class Initialized
DEBUG - 2020-02-27 09:30:03 --> No URI present. Default controller set.
INFO - 2020-02-27 09:30:03 --> Router Class Initialized
INFO - 2020-02-27 09:30:03 --> Output Class Initialized
INFO - 2020-02-27 09:30:03 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:03 --> Input Class Initialized
INFO - 2020-02-27 09:30:03 --> Language Class Initialized
INFO - 2020-02-27 09:30:03 --> Loader Class Initialized
INFO - 2020-02-27 09:30:03 --> Helper loaded: url_helper
INFO - 2020-02-27 09:30:03 --> Helper loaded: string_helper
INFO - 2020-02-27 09:30:03 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:30:03 --> Controller Class Initialized
INFO - 2020-02-27 09:30:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 09:30:03 --> Pagination Class Initialized
INFO - 2020-02-27 09:30:03 --> Model "M_show" initialized
INFO - 2020-02-27 09:30:03 --> Helper loaded: form_helper
INFO - 2020-02-27 09:30:04 --> Form Validation Class Initialized
INFO - 2020-02-27 09:30:04 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 09:30:04 --> Final output sent to browser
DEBUG - 2020-02-27 09:30:04 --> Total execution time: 0.8605
INFO - 2020-02-27 09:30:07 --> Config Class Initialized
INFO - 2020-02-27 09:30:07 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:07 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:07 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:07 --> URI Class Initialized
INFO - 2020-02-27 09:30:07 --> Router Class Initialized
INFO - 2020-02-27 09:30:07 --> Output Class Initialized
INFO - 2020-02-27 09:30:07 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:07 --> Input Class Initialized
INFO - 2020-02-27 09:30:07 --> Language Class Initialized
INFO - 2020-02-27 09:30:07 --> Loader Class Initialized
INFO - 2020-02-27 09:30:07 --> Helper loaded: url_helper
INFO - 2020-02-27 09:30:07 --> Helper loaded: string_helper
INFO - 2020-02-27 09:30:07 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:30:07 --> Controller Class Initialized
INFO - 2020-02-27 09:30:07 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:30:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:30:07 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:30:08 --> Helper loaded: form_helper
INFO - 2020-02-27 09:30:08 --> Form Validation Class Initialized
INFO - 2020-02-27 09:30:08 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:30:08 --> Final output sent to browser
INFO - 2020-02-27 09:30:08 --> Config Class Initialized
INFO - 2020-02-27 09:30:08 --> Config Class Initialized
INFO - 2020-02-27 09:30:08 --> Config Class Initialized
INFO - 2020-02-27 09:30:08 --> Config Class Initialized
INFO - 2020-02-27 09:30:08 --> Config Class Initialized
INFO - 2020-02-27 09:30:08 --> Hooks Class Initialized
INFO - 2020-02-27 09:30:08 --> Hooks Class Initialized
INFO - 2020-02-27 09:30:08 --> Hooks Class Initialized
INFO - 2020-02-27 09:30:08 --> Hooks Class Initialized
INFO - 2020-02-27 09:30:08 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:08 --> Total execution time: 0.7452
DEBUG - 2020-02-27 09:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:30:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:08 --> Config Class Initialized
INFO - 2020-02-27 09:30:08 --> Hooks Class Initialized
INFO - 2020-02-27 09:30:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:08 --> URI Class Initialized
INFO - 2020-02-27 09:30:08 --> URI Class Initialized
INFO - 2020-02-27 09:30:08 --> URI Class Initialized
INFO - 2020-02-27 09:30:08 --> URI Class Initialized
DEBUG - 2020-02-27 09:30:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:08 --> URI Class Initialized
INFO - 2020-02-27 09:30:08 --> Router Class Initialized
INFO - 2020-02-27 09:30:08 --> Router Class Initialized
INFO - 2020-02-27 09:30:08 --> Router Class Initialized
INFO - 2020-02-27 09:30:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:08 --> Router Class Initialized
INFO - 2020-02-27 09:30:08 --> Router Class Initialized
INFO - 2020-02-27 09:30:08 --> URI Class Initialized
INFO - 2020-02-27 09:30:08 --> Output Class Initialized
INFO - 2020-02-27 09:30:08 --> Output Class Initialized
INFO - 2020-02-27 09:30:08 --> Output Class Initialized
INFO - 2020-02-27 09:30:08 --> Output Class Initialized
INFO - 2020-02-27 09:30:08 --> Output Class Initialized
INFO - 2020-02-27 09:30:08 --> Router Class Initialized
INFO - 2020-02-27 09:30:08 --> Security Class Initialized
INFO - 2020-02-27 09:30:08 --> Security Class Initialized
INFO - 2020-02-27 09:30:08 --> Security Class Initialized
INFO - 2020-02-27 09:30:08 --> Security Class Initialized
INFO - 2020-02-27 09:30:08 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:08 --> Output Class Initialized
DEBUG - 2020-02-27 09:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:08 --> Input Class Initialized
INFO - 2020-02-27 09:30:08 --> Input Class Initialized
INFO - 2020-02-27 09:30:08 --> Input Class Initialized
INFO - 2020-02-27 09:30:08 --> Input Class Initialized
INFO - 2020-02-27 09:30:08 --> Input Class Initialized
INFO - 2020-02-27 09:30:08 --> Security Class Initialized
INFO - 2020-02-27 09:30:08 --> Language Class Initialized
DEBUG - 2020-02-27 09:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:08 --> Language Class Initialized
INFO - 2020-02-27 09:30:08 --> Language Class Initialized
INFO - 2020-02-27 09:30:08 --> Language Class Initialized
INFO - 2020-02-27 09:30:08 --> Input Class Initialized
ERROR - 2020-02-27 09:30:08 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 09:30:08 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-27 09:30:08 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 09:30:08 --> Language Class Initialized
INFO - 2020-02-27 09:30:08 --> Loader Class Initialized
INFO - 2020-02-27 09:30:08 --> Helper loaded: url_helper
INFO - 2020-02-27 09:30:08 --> Language Class Initialized
INFO - 2020-02-27 09:30:08 --> Loader Class Initialized
INFO - 2020-02-27 09:30:08 --> Config Class Initialized
INFO - 2020-02-27 09:30:08 --> Config Class Initialized
INFO - 2020-02-27 09:30:08 --> Config Class Initialized
INFO - 2020-02-27 09:30:08 --> Hooks Class Initialized
INFO - 2020-02-27 09:30:08 --> Hooks Class Initialized
INFO - 2020-02-27 09:30:08 --> Hooks Class Initialized
INFO - 2020-02-27 09:30:08 --> Helper loaded: url_helper
INFO - 2020-02-27 09:30:08 --> Helper loaded: string_helper
ERROR - 2020-02-27 09:30:08 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 09:30:08 --> Helper loaded: string_helper
DEBUG - 2020-02-27 09:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:30:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:08 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:30:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:08 --> Config Class Initialized
INFO - 2020-02-27 09:30:08 --> Hooks Class Initialized
INFO - 2020-02-27 09:30:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:08 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:30:08 --> Database Driver Class Initialized
INFO - 2020-02-27 09:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:30:08 --> URI Class Initialized
INFO - 2020-02-27 09:30:08 --> URI Class Initialized
DEBUG - 2020-02-27 09:30:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:08 --> URI Class Initialized
DEBUG - 2020-02-27 09:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:30:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:08 --> Controller Class Initialized
INFO - 2020-02-27 09:30:08 --> Router Class Initialized
INFO - 2020-02-27 09:30:08 --> Router Class Initialized
INFO - 2020-02-27 09:30:08 --> Router Class Initialized
INFO - 2020-02-27 09:30:08 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:30:08 --> Output Class Initialized
INFO - 2020-02-27 09:30:08 --> Output Class Initialized
INFO - 2020-02-27 09:30:08 --> URI Class Initialized
INFO - 2020-02-27 09:30:08 --> Output Class Initialized
INFO - 2020-02-27 09:30:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:30:08 --> Security Class Initialized
INFO - 2020-02-27 09:30:08 --> Security Class Initialized
INFO - 2020-02-27 09:30:08 --> Security Class Initialized
INFO - 2020-02-27 09:30:08 --> Router Class Initialized
INFO - 2020-02-27 09:30:08 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 09:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:08 --> Output Class Initialized
DEBUG - 2020-02-27 09:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:08 --> Input Class Initialized
INFO - 2020-02-27 09:30:08 --> Input Class Initialized
INFO - 2020-02-27 09:30:08 --> Input Class Initialized
INFO - 2020-02-27 09:30:08 --> Security Class Initialized
INFO - 2020-02-27 09:30:08 --> Helper loaded: form_helper
INFO - 2020-02-27 09:30:09 --> Form Validation Class Initialized
INFO - 2020-02-27 09:30:09 --> Language Class Initialized
INFO - 2020-02-27 09:30:09 --> Language Class Initialized
INFO - 2020-02-27 09:30:09 --> Language Class Initialized
DEBUG - 2020-02-27 09:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:09 --> Input Class Initialized
ERROR - 2020-02-27 09:30:09 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 09:30:09 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-27 09:30:09 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-27 09:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:30:09 --> Language Class Initialized
INFO - 2020-02-27 09:30:09 --> Config Class Initialized
INFO - 2020-02-27 09:30:09 --> Config Class Initialized
INFO - 2020-02-27 09:30:09 --> Config Class Initialized
INFO - 2020-02-27 09:30:09 --> Hooks Class Initialized
INFO - 2020-02-27 09:30:09 --> Hooks Class Initialized
INFO - 2020-02-27 09:30:09 --> Hooks Class Initialized
INFO - 2020-02-27 09:30:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-27 09:30:09 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 09:30:09 --> Final output sent to browser
DEBUG - 2020-02-27 09:30:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:30:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:30:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:09 --> Config Class Initialized
INFO - 2020-02-27 09:30:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:09 --> Hooks Class Initialized
INFO - 2020-02-27 09:30:09 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:30:09 --> Total execution time: 0.9994
INFO - 2020-02-27 09:30:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:30:09 --> URI Class Initialized
INFO - 2020-02-27 09:30:09 --> URI Class Initialized
DEBUG - 2020-02-27 09:30:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:09 --> URI Class Initialized
INFO - 2020-02-27 09:30:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:09 --> Controller Class Initialized
INFO - 2020-02-27 09:30:09 --> Router Class Initialized
INFO - 2020-02-27 09:30:09 --> Router Class Initialized
INFO - 2020-02-27 09:30:09 --> Router Class Initialized
INFO - 2020-02-27 09:30:09 --> Output Class Initialized
INFO - 2020-02-27 09:30:09 --> Output Class Initialized
INFO - 2020-02-27 09:30:09 --> Output Class Initialized
INFO - 2020-02-27 09:30:09 --> URI Class Initialized
INFO - 2020-02-27 09:30:09 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:30:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:30:09 --> Security Class Initialized
INFO - 2020-02-27 09:30:09 --> Security Class Initialized
INFO - 2020-02-27 09:30:09 --> Router Class Initialized
INFO - 2020-02-27 09:30:09 --> Security Class Initialized
INFO - 2020-02-27 09:30:09 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 09:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:09 --> Output Class Initialized
DEBUG - 2020-02-27 09:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:09 --> Input Class Initialized
INFO - 2020-02-27 09:30:09 --> Input Class Initialized
INFO - 2020-02-27 09:30:09 --> Input Class Initialized
INFO - 2020-02-27 09:30:09 --> Security Class Initialized
INFO - 2020-02-27 09:30:09 --> Helper loaded: form_helper
INFO - 2020-02-27 09:30:09 --> Form Validation Class Initialized
INFO - 2020-02-27 09:30:09 --> Language Class Initialized
INFO - 2020-02-27 09:30:09 --> Language Class Initialized
INFO - 2020-02-27 09:30:09 --> Language Class Initialized
DEBUG - 2020-02-27 09:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:09 --> Input Class Initialized
ERROR - 2020-02-27 09:30:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-27 09:30:09 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 09:30:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-27 09:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-27 09:30:09 --> Language Class Initialized
ERROR - 2020-02-27 09:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:30:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-27 09:30:09 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 09:30:09 --> Final output sent to browser
INFO - 2020-02-27 09:30:09 --> Config Class Initialized
INFO - 2020-02-27 09:30:09 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:09 --> Total execution time: 1.3777
DEBUG - 2020-02-27 09:30:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:09 --> URI Class Initialized
INFO - 2020-02-27 09:30:09 --> Router Class Initialized
INFO - 2020-02-27 09:30:09 --> Output Class Initialized
INFO - 2020-02-27 09:30:09 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:09 --> Input Class Initialized
INFO - 2020-02-27 09:30:09 --> Language Class Initialized
ERROR - 2020-02-27 09:30:09 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 09:30:09 --> Config Class Initialized
INFO - 2020-02-27 09:30:09 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:10 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:10 --> URI Class Initialized
INFO - 2020-02-27 09:30:10 --> Router Class Initialized
INFO - 2020-02-27 09:30:10 --> Output Class Initialized
INFO - 2020-02-27 09:30:10 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:10 --> Input Class Initialized
INFO - 2020-02-27 09:30:10 --> Language Class Initialized
ERROR - 2020-02-27 09:30:10 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 09:30:10 --> Config Class Initialized
INFO - 2020-02-27 09:30:10 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:10 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:10 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:10 --> URI Class Initialized
INFO - 2020-02-27 09:30:10 --> Router Class Initialized
INFO - 2020-02-27 09:30:10 --> Output Class Initialized
INFO - 2020-02-27 09:30:10 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:10 --> Input Class Initialized
INFO - 2020-02-27 09:30:10 --> Language Class Initialized
ERROR - 2020-02-27 09:30:10 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 09:30:10 --> Config Class Initialized
INFO - 2020-02-27 09:30:10 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:10 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:10 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:10 --> URI Class Initialized
INFO - 2020-02-27 09:30:10 --> Router Class Initialized
INFO - 2020-02-27 09:30:10 --> Output Class Initialized
INFO - 2020-02-27 09:30:10 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:11 --> Input Class Initialized
INFO - 2020-02-27 09:30:11 --> Language Class Initialized
ERROR - 2020-02-27 09:30:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:30:11 --> Config Class Initialized
INFO - 2020-02-27 09:30:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:11 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:11 --> URI Class Initialized
INFO - 2020-02-27 09:30:11 --> Router Class Initialized
INFO - 2020-02-27 09:30:11 --> Output Class Initialized
INFO - 2020-02-27 09:30:11 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:11 --> Input Class Initialized
INFO - 2020-02-27 09:30:11 --> Language Class Initialized
ERROR - 2020-02-27 09:30:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:30:11 --> Config Class Initialized
INFO - 2020-02-27 09:30:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:11 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:11 --> URI Class Initialized
INFO - 2020-02-27 09:30:11 --> Router Class Initialized
INFO - 2020-02-27 09:30:11 --> Output Class Initialized
INFO - 2020-02-27 09:30:11 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:11 --> Input Class Initialized
INFO - 2020-02-27 09:30:11 --> Language Class Initialized
ERROR - 2020-02-27 09:30:11 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 09:30:11 --> Config Class Initialized
INFO - 2020-02-27 09:30:11 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:11 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:11 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:11 --> URI Class Initialized
INFO - 2020-02-27 09:30:12 --> Router Class Initialized
INFO - 2020-02-27 09:30:12 --> Output Class Initialized
INFO - 2020-02-27 09:30:12 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:12 --> Input Class Initialized
INFO - 2020-02-27 09:30:12 --> Language Class Initialized
ERROR - 2020-02-27 09:30:12 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 09:30:12 --> Config Class Initialized
INFO - 2020-02-27 09:30:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:12 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:12 --> URI Class Initialized
INFO - 2020-02-27 09:30:12 --> Router Class Initialized
INFO - 2020-02-27 09:30:12 --> Output Class Initialized
INFO - 2020-02-27 09:30:12 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:12 --> Input Class Initialized
INFO - 2020-02-27 09:30:12 --> Language Class Initialized
ERROR - 2020-02-27 09:30:12 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 09:30:12 --> Config Class Initialized
INFO - 2020-02-27 09:30:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:12 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:12 --> URI Class Initialized
INFO - 2020-02-27 09:30:12 --> Router Class Initialized
INFO - 2020-02-27 09:30:12 --> Output Class Initialized
INFO - 2020-02-27 09:30:12 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:12 --> Input Class Initialized
INFO - 2020-02-27 09:30:12 --> Language Class Initialized
ERROR - 2020-02-27 09:30:12 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 09:30:44 --> Config Class Initialized
INFO - 2020-02-27 09:30:44 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:44 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:44 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:44 --> URI Class Initialized
INFO - 2020-02-27 09:30:44 --> Router Class Initialized
INFO - 2020-02-27 09:30:44 --> Output Class Initialized
INFO - 2020-02-27 09:30:44 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:45 --> Input Class Initialized
INFO - 2020-02-27 09:30:45 --> Language Class Initialized
INFO - 2020-02-27 09:30:45 --> Loader Class Initialized
INFO - 2020-02-27 09:30:45 --> Helper loaded: url_helper
INFO - 2020-02-27 09:30:45 --> Helper loaded: string_helper
INFO - 2020-02-27 09:30:45 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:30:45 --> Controller Class Initialized
INFO - 2020-02-27 09:30:45 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:30:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:30:45 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:30:45 --> Helper loaded: form_helper
INFO - 2020-02-27 09:30:45 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:30:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 99
ERROR - 2020-02-27 15:30:45 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `bukti_bayar`, `id_pengunjung`) VALUES ('34', '240000', '1', '2', '20-02-27 03:30:45', '2020-02-28 03:30:45', NULL, 'PM197', NULL, 'default.jpg', NULL)
INFO - 2020-02-27 15:30:45 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-27 09:30:55 --> Config Class Initialized
INFO - 2020-02-27 09:30:55 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:55 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:55 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:55 --> URI Class Initialized
INFO - 2020-02-27 09:30:55 --> Router Class Initialized
INFO - 2020-02-27 09:30:55 --> Output Class Initialized
INFO - 2020-02-27 09:30:55 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:55 --> Input Class Initialized
INFO - 2020-02-27 09:30:55 --> Language Class Initialized
INFO - 2020-02-27 09:30:55 --> Loader Class Initialized
INFO - 2020-02-27 09:30:55 --> Helper loaded: url_helper
INFO - 2020-02-27 09:30:55 --> Helper loaded: string_helper
INFO - 2020-02-27 09:30:55 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:30:55 --> Controller Class Initialized
INFO - 2020-02-27 09:30:55 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:30:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:30:56 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:30:56 --> Helper loaded: form_helper
INFO - 2020-02-27 09:30:56 --> Form Validation Class Initialized
INFO - 2020-02-27 09:30:56 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:30:56 --> Final output sent to browser
DEBUG - 2020-02-27 09:30:56 --> Total execution time: 0.7337
INFO - 2020-02-27 09:30:58 --> Config Class Initialized
INFO - 2020-02-27 09:30:58 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:30:58 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:30:58 --> Utf8 Class Initialized
INFO - 2020-02-27 09:30:58 --> URI Class Initialized
INFO - 2020-02-27 09:30:58 --> Router Class Initialized
INFO - 2020-02-27 09:30:58 --> Output Class Initialized
INFO - 2020-02-27 09:30:58 --> Security Class Initialized
DEBUG - 2020-02-27 09:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:30:58 --> Input Class Initialized
INFO - 2020-02-27 09:30:58 --> Language Class Initialized
INFO - 2020-02-27 09:30:58 --> Loader Class Initialized
INFO - 2020-02-27 09:30:58 --> Helper loaded: url_helper
INFO - 2020-02-27 09:30:58 --> Helper loaded: string_helper
INFO - 2020-02-27 09:30:58 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:30:58 --> Controller Class Initialized
INFO - 2020-02-27 09:30:58 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:30:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:30:58 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:30:58 --> Helper loaded: form_helper
INFO - 2020-02-27 09:30:58 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:30:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 99
ERROR - 2020-02-27 15:30:59 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `bukti_bayar`, `id_pengunjung`) VALUES ('34', '240000', '1', '2', '20-02-27 03:30:59', '2020-02-28 03:30:59', NULL, 'PM197', NULL, 'default.jpg', NULL)
INFO - 2020-02-27 15:30:59 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-27 09:31:01 --> Config Class Initialized
INFO - 2020-02-27 09:31:01 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:01 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:01 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:01 --> URI Class Initialized
INFO - 2020-02-27 09:31:02 --> Router Class Initialized
INFO - 2020-02-27 09:31:02 --> Output Class Initialized
INFO - 2020-02-27 09:31:02 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:02 --> Input Class Initialized
INFO - 2020-02-27 09:31:02 --> Language Class Initialized
INFO - 2020-02-27 09:31:02 --> Loader Class Initialized
INFO - 2020-02-27 09:31:02 --> Helper loaded: url_helper
INFO - 2020-02-27 09:31:02 --> Helper loaded: string_helper
INFO - 2020-02-27 09:31:02 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:31:02 --> Controller Class Initialized
INFO - 2020-02-27 09:31:02 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:31:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:31:02 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:31:02 --> Helper loaded: form_helper
INFO - 2020-02-27 09:31:02 --> Form Validation Class Initialized
INFO - 2020-02-27 09:31:02 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:31:02 --> Final output sent to browser
DEBUG - 2020-02-27 09:31:02 --> Total execution time: 0.7333
INFO - 2020-02-27 09:31:04 --> Config Class Initialized
INFO - 2020-02-27 09:31:04 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:04 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:04 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:04 --> URI Class Initialized
INFO - 2020-02-27 09:31:04 --> Router Class Initialized
INFO - 2020-02-27 09:31:04 --> Output Class Initialized
INFO - 2020-02-27 09:31:04 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:04 --> Input Class Initialized
INFO - 2020-02-27 09:31:04 --> Language Class Initialized
INFO - 2020-02-27 09:31:04 --> Loader Class Initialized
INFO - 2020-02-27 09:31:04 --> Helper loaded: url_helper
INFO - 2020-02-27 09:31:04 --> Helper loaded: string_helper
INFO - 2020-02-27 09:31:04 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:31:04 --> Controller Class Initialized
INFO - 2020-02-27 09:31:05 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:31:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:31:05 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:31:05 --> Helper loaded: form_helper
INFO - 2020-02-27 09:31:05 --> Form Validation Class Initialized
INFO - 2020-02-27 09:31:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:31:05 --> Final output sent to browser
INFO - 2020-02-27 09:31:05 --> Config Class Initialized
INFO - 2020-02-27 09:31:05 --> Config Class Initialized
INFO - 2020-02-27 09:31:05 --> Config Class Initialized
INFO - 2020-02-27 09:31:05 --> Config Class Initialized
INFO - 2020-02-27 09:31:05 --> Hooks Class Initialized
INFO - 2020-02-27 09:31:05 --> Hooks Class Initialized
INFO - 2020-02-27 09:31:05 --> Hooks Class Initialized
INFO - 2020-02-27 09:31:05 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:05 --> Total execution time: 0.7566
INFO - 2020-02-27 09:31:05 --> Config Class Initialized
INFO - 2020-02-27 09:31:05 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:31:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:31:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:31:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:05 --> Config Class Initialized
INFO - 2020-02-27 09:31:05 --> Hooks Class Initialized
INFO - 2020-02-27 09:31:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:05 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:31:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:05 --> URI Class Initialized
INFO - 2020-02-27 09:31:05 --> URI Class Initialized
DEBUG - 2020-02-27 09:31:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:05 --> URI Class Initialized
INFO - 2020-02-27 09:31:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:05 --> URI Class Initialized
INFO - 2020-02-27 09:31:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:05 --> Router Class Initialized
INFO - 2020-02-27 09:31:05 --> Router Class Initialized
INFO - 2020-02-27 09:31:05 --> Router Class Initialized
INFO - 2020-02-27 09:31:05 --> URI Class Initialized
INFO - 2020-02-27 09:31:05 --> Router Class Initialized
INFO - 2020-02-27 09:31:05 --> URI Class Initialized
INFO - 2020-02-27 09:31:05 --> Output Class Initialized
INFO - 2020-02-27 09:31:05 --> Router Class Initialized
INFO - 2020-02-27 09:31:05 --> Output Class Initialized
INFO - 2020-02-27 09:31:05 --> Output Class Initialized
INFO - 2020-02-27 09:31:05 --> Output Class Initialized
INFO - 2020-02-27 09:31:05 --> Security Class Initialized
INFO - 2020-02-27 09:31:05 --> Security Class Initialized
INFO - 2020-02-27 09:31:05 --> Security Class Initialized
INFO - 2020-02-27 09:31:05 --> Security Class Initialized
INFO - 2020-02-27 09:31:05 --> Router Class Initialized
INFO - 2020-02-27 09:31:05 --> Output Class Initialized
DEBUG - 2020-02-27 09:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:05 --> Output Class Initialized
INFO - 2020-02-27 09:31:05 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:05 --> Input Class Initialized
INFO - 2020-02-27 09:31:05 --> Input Class Initialized
INFO - 2020-02-27 09:31:05 --> Input Class Initialized
INFO - 2020-02-27 09:31:05 --> Input Class Initialized
DEBUG - 2020-02-27 09:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:05 --> Security Class Initialized
INFO - 2020-02-27 09:31:05 --> Input Class Initialized
INFO - 2020-02-27 09:31:05 --> Language Class Initialized
DEBUG - 2020-02-27 09:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:05 --> Language Class Initialized
INFO - 2020-02-27 09:31:05 --> Language Class Initialized
INFO - 2020-02-27 09:31:05 --> Language Class Initialized
INFO - 2020-02-27 09:31:05 --> Input Class Initialized
INFO - 2020-02-27 09:31:05 --> Language Class Initialized
ERROR - 2020-02-27 09:31:05 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-27 09:31:05 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 09:31:05 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 09:31:05 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 09:31:05 --> Language Class Initialized
ERROR - 2020-02-27 09:31:05 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 09:31:05 --> Config Class Initialized
INFO - 2020-02-27 09:31:05 --> Config Class Initialized
INFO - 2020-02-27 09:31:05 --> Config Class Initialized
INFO - 2020-02-27 09:31:05 --> Config Class Initialized
INFO - 2020-02-27 09:31:05 --> Hooks Class Initialized
INFO - 2020-02-27 09:31:05 --> Hooks Class Initialized
INFO - 2020-02-27 09:31:05 --> Hooks Class Initialized
INFO - 2020-02-27 09:31:05 --> Hooks Class Initialized
ERROR - 2020-02-27 09:31:05 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:31:05 --> Config Class Initialized
INFO - 2020-02-27 09:31:05 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:31:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:31:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:31:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:05 --> Config Class Initialized
INFO - 2020-02-27 09:31:05 --> Hooks Class Initialized
INFO - 2020-02-27 09:31:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:05 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:31:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:05 --> URI Class Initialized
INFO - 2020-02-27 09:31:05 --> URI Class Initialized
INFO - 2020-02-27 09:31:05 --> URI Class Initialized
DEBUG - 2020-02-27 09:31:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:05 --> URI Class Initialized
INFO - 2020-02-27 09:31:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:05 --> Router Class Initialized
INFO - 2020-02-27 09:31:05 --> Router Class Initialized
INFO - 2020-02-27 09:31:05 --> URI Class Initialized
INFO - 2020-02-27 09:31:05 --> Router Class Initialized
INFO - 2020-02-27 09:31:05 --> Router Class Initialized
INFO - 2020-02-27 09:31:05 --> URI Class Initialized
INFO - 2020-02-27 09:31:05 --> Router Class Initialized
INFO - 2020-02-27 09:31:05 --> Output Class Initialized
INFO - 2020-02-27 09:31:05 --> Output Class Initialized
INFO - 2020-02-27 09:31:05 --> Output Class Initialized
INFO - 2020-02-27 09:31:05 --> Output Class Initialized
INFO - 2020-02-27 09:31:05 --> Security Class Initialized
INFO - 2020-02-27 09:31:05 --> Router Class Initialized
INFO - 2020-02-27 09:31:05 --> Security Class Initialized
INFO - 2020-02-27 09:31:05 --> Security Class Initialized
INFO - 2020-02-27 09:31:05 --> Security Class Initialized
INFO - 2020-02-27 09:31:05 --> Output Class Initialized
INFO - 2020-02-27 09:31:05 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:05 --> Output Class Initialized
DEBUG - 2020-02-27 09:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:05 --> Input Class Initialized
INFO - 2020-02-27 09:31:05 --> Input Class Initialized
INFO - 2020-02-27 09:31:05 --> Input Class Initialized
INFO - 2020-02-27 09:31:05 --> Input Class Initialized
DEBUG - 2020-02-27 09:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:05 --> Security Class Initialized
INFO - 2020-02-27 09:31:06 --> Input Class Initialized
INFO - 2020-02-27 09:31:06 --> Language Class Initialized
INFO - 2020-02-27 09:31:06 --> Language Class Initialized
INFO - 2020-02-27 09:31:06 --> Language Class Initialized
INFO - 2020-02-27 09:31:06 --> Language Class Initialized
DEBUG - 2020-02-27 09:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:06 --> Language Class Initialized
INFO - 2020-02-27 09:31:06 --> Input Class Initialized
ERROR - 2020-02-27 09:31:06 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-27 09:31:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:31:06 --> Loader Class Initialized
INFO - 2020-02-27 09:31:06 --> Loader Class Initialized
INFO - 2020-02-27 09:31:06 --> Language Class Initialized
INFO - 2020-02-27 09:31:06 --> Helper loaded: url_helper
ERROR - 2020-02-27 09:31:06 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 09:31:06 --> Helper loaded: url_helper
INFO - 2020-02-27 09:31:06 --> Config Class Initialized
INFO - 2020-02-27 09:31:06 --> Config Class Initialized
INFO - 2020-02-27 09:31:06 --> Hooks Class Initialized
INFO - 2020-02-27 09:31:06 --> Hooks Class Initialized
INFO - 2020-02-27 09:31:06 --> Helper loaded: string_helper
INFO - 2020-02-27 09:31:06 --> Helper loaded: string_helper
ERROR - 2020-02-27 09:31:06 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-27 09:31:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:31:06 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:06 --> Database Driver Class Initialized
INFO - 2020-02-27 09:31:06 --> Database Driver Class Initialized
INFO - 2020-02-27 09:31:06 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:06 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-27 09:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:31:06 --> URI Class Initialized
INFO - 2020-02-27 09:31:06 --> URI Class Initialized
INFO - 2020-02-27 09:31:06 --> Controller Class Initialized
INFO - 2020-02-27 09:31:06 --> Router Class Initialized
INFO - 2020-02-27 09:31:06 --> Router Class Initialized
INFO - 2020-02-27 09:31:06 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:31:06 --> Output Class Initialized
INFO - 2020-02-27 09:31:06 --> Output Class Initialized
INFO - 2020-02-27 09:31:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:31:06 --> Security Class Initialized
INFO - 2020-02-27 09:31:06 --> Security Class Initialized
INFO - 2020-02-27 09:31:06 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 09:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:06 --> Input Class Initialized
INFO - 2020-02-27 09:31:06 --> Input Class Initialized
INFO - 2020-02-27 09:31:06 --> Helper loaded: form_helper
INFO - 2020-02-27 09:31:06 --> Form Validation Class Initialized
INFO - 2020-02-27 09:31:06 --> Language Class Initialized
INFO - 2020-02-27 09:31:06 --> Language Class Initialized
ERROR - 2020-02-27 09:31:06 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 09:31:06 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 09:31:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:31:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:31:06 --> Config Class Initialized
INFO - 2020-02-27 09:31:06 --> Hooks Class Initialized
INFO - 2020-02-27 09:31:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:31:06 --> Final output sent to browser
DEBUG - 2020-02-27 09:31:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:31:06 --> Total execution time: 0.8514
INFO - 2020-02-27 09:31:06 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:31:06 --> URI Class Initialized
INFO - 2020-02-27 09:31:06 --> Controller Class Initialized
INFO - 2020-02-27 09:31:06 --> Router Class Initialized
INFO - 2020-02-27 09:31:06 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:31:06 --> Output Class Initialized
INFO - 2020-02-27 09:31:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:31:06 --> Security Class Initialized
INFO - 2020-02-27 09:31:06 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 09:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:06 --> Input Class Initialized
INFO - 2020-02-27 09:31:06 --> Helper loaded: form_helper
INFO - 2020-02-27 09:31:06 --> Form Validation Class Initialized
INFO - 2020-02-27 09:31:06 --> Language Class Initialized
ERROR - 2020-02-27 09:31:06 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 09:31:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:31:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:31:06 --> Config Class Initialized
INFO - 2020-02-27 09:31:06 --> Hooks Class Initialized
INFO - 2020-02-27 09:31:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:31:06 --> Final output sent to browser
DEBUG - 2020-02-27 09:31:06 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:06 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:31:06 --> Total execution time: 1.2142
INFO - 2020-02-27 09:31:06 --> URI Class Initialized
INFO - 2020-02-27 09:31:06 --> Router Class Initialized
INFO - 2020-02-27 09:31:07 --> Output Class Initialized
INFO - 2020-02-27 09:31:07 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:07 --> Input Class Initialized
INFO - 2020-02-27 09:31:07 --> Language Class Initialized
ERROR - 2020-02-27 09:31:07 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 09:31:07 --> Config Class Initialized
INFO - 2020-02-27 09:31:07 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:07 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:07 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:07 --> URI Class Initialized
INFO - 2020-02-27 09:31:07 --> Router Class Initialized
INFO - 2020-02-27 09:31:07 --> Output Class Initialized
INFO - 2020-02-27 09:31:07 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:07 --> Input Class Initialized
INFO - 2020-02-27 09:31:07 --> Language Class Initialized
ERROR - 2020-02-27 09:31:07 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 09:31:07 --> Config Class Initialized
INFO - 2020-02-27 09:31:07 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:07 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:07 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:07 --> URI Class Initialized
INFO - 2020-02-27 09:31:07 --> Router Class Initialized
INFO - 2020-02-27 09:31:07 --> Output Class Initialized
INFO - 2020-02-27 09:31:08 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:08 --> Input Class Initialized
INFO - 2020-02-27 09:31:08 --> Language Class Initialized
ERROR - 2020-02-27 09:31:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:31:08 --> Config Class Initialized
INFO - 2020-02-27 09:31:08 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:08 --> URI Class Initialized
INFO - 2020-02-27 09:31:08 --> Router Class Initialized
INFO - 2020-02-27 09:31:08 --> Output Class Initialized
INFO - 2020-02-27 09:31:08 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:08 --> Input Class Initialized
INFO - 2020-02-27 09:31:08 --> Language Class Initialized
ERROR - 2020-02-27 09:31:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:31:08 --> Config Class Initialized
INFO - 2020-02-27 09:31:08 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:08 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:08 --> URI Class Initialized
INFO - 2020-02-27 09:31:08 --> Router Class Initialized
INFO - 2020-02-27 09:31:08 --> Output Class Initialized
INFO - 2020-02-27 09:31:08 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:08 --> Input Class Initialized
INFO - 2020-02-27 09:31:08 --> Language Class Initialized
ERROR - 2020-02-27 09:31:08 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 09:31:09 --> Config Class Initialized
INFO - 2020-02-27 09:31:09 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:09 --> URI Class Initialized
INFO - 2020-02-27 09:31:09 --> Router Class Initialized
INFO - 2020-02-27 09:31:09 --> Output Class Initialized
INFO - 2020-02-27 09:31:09 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:09 --> Input Class Initialized
INFO - 2020-02-27 09:31:09 --> Language Class Initialized
ERROR - 2020-02-27 09:31:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 09:31:09 --> Config Class Initialized
INFO - 2020-02-27 09:31:09 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:09 --> URI Class Initialized
INFO - 2020-02-27 09:31:09 --> Router Class Initialized
INFO - 2020-02-27 09:31:09 --> Output Class Initialized
INFO - 2020-02-27 09:31:09 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:09 --> Input Class Initialized
INFO - 2020-02-27 09:31:09 --> Language Class Initialized
ERROR - 2020-02-27 09:31:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 09:31:09 --> Config Class Initialized
INFO - 2020-02-27 09:31:09 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:10 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:10 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:10 --> URI Class Initialized
INFO - 2020-02-27 09:31:10 --> Router Class Initialized
INFO - 2020-02-27 09:31:10 --> Output Class Initialized
INFO - 2020-02-27 09:31:10 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:10 --> Input Class Initialized
INFO - 2020-02-27 09:31:10 --> Language Class Initialized
ERROR - 2020-02-27 09:31:10 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 09:31:38 --> Config Class Initialized
INFO - 2020-02-27 09:31:38 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:38 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:38 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:38 --> URI Class Initialized
INFO - 2020-02-27 09:31:38 --> Router Class Initialized
INFO - 2020-02-27 09:31:38 --> Output Class Initialized
INFO - 2020-02-27 09:31:38 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:38 --> Input Class Initialized
INFO - 2020-02-27 09:31:38 --> Language Class Initialized
INFO - 2020-02-27 09:31:38 --> Loader Class Initialized
INFO - 2020-02-27 09:31:39 --> Helper loaded: url_helper
INFO - 2020-02-27 09:31:39 --> Helper loaded: string_helper
INFO - 2020-02-27 09:31:39 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:31:39 --> Controller Class Initialized
INFO - 2020-02-27 09:31:39 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:31:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:31:39 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:31:39 --> Helper loaded: form_helper
INFO - 2020-02-27 09:31:39 --> Form Validation Class Initialized
INFO - 2020-02-27 15:31:39 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 15:31:39 --> Final output sent to browser
DEBUG - 2020-02-27 15:31:39 --> Total execution time: 1.0426
INFO - 2020-02-27 09:31:43 --> Config Class Initialized
INFO - 2020-02-27 09:31:43 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:43 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:43 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:43 --> URI Class Initialized
INFO - 2020-02-27 09:31:43 --> Router Class Initialized
INFO - 2020-02-27 09:31:43 --> Output Class Initialized
INFO - 2020-02-27 09:31:43 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:43 --> Input Class Initialized
INFO - 2020-02-27 09:31:43 --> Language Class Initialized
INFO - 2020-02-27 09:31:43 --> Loader Class Initialized
INFO - 2020-02-27 09:31:43 --> Helper loaded: url_helper
INFO - 2020-02-27 09:31:43 --> Helper loaded: string_helper
INFO - 2020-02-27 09:31:43 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:31:44 --> Controller Class Initialized
INFO - 2020-02-27 09:31:44 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:31:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:31:44 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:31:44 --> Helper loaded: form_helper
INFO - 2020-02-27 09:31:44 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:31:44 --> Severity: Notice --> Undefined variable: tanggalp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 09:31:44 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 09:31:44 --> Final output sent to browser
DEBUG - 2020-02-27 09:31:44 --> Total execution time: 0.8140
INFO - 2020-02-27 09:31:58 --> Config Class Initialized
INFO - 2020-02-27 09:31:58 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:58 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:58 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:58 --> URI Class Initialized
INFO - 2020-02-27 09:31:58 --> Router Class Initialized
INFO - 2020-02-27 09:31:58 --> Output Class Initialized
INFO - 2020-02-27 09:31:58 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:58 --> Input Class Initialized
INFO - 2020-02-27 09:31:58 --> Language Class Initialized
INFO - 2020-02-27 09:31:58 --> Loader Class Initialized
INFO - 2020-02-27 09:31:58 --> Helper loaded: url_helper
INFO - 2020-02-27 09:31:58 --> Helper loaded: string_helper
INFO - 2020-02-27 09:31:59 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:31:59 --> Controller Class Initialized
INFO - 2020-02-27 09:31:59 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:31:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:31:59 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:31:59 --> Helper loaded: form_helper
INFO - 2020-02-27 09:31:59 --> Form Validation Class Initialized
INFO - 2020-02-27 09:31:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-27 09:31:59 --> Config Class Initialized
INFO - 2020-02-27 09:31:59 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:31:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:31:59 --> Utf8 Class Initialized
INFO - 2020-02-27 09:31:59 --> URI Class Initialized
INFO - 2020-02-27 09:31:59 --> Router Class Initialized
INFO - 2020-02-27 09:31:59 --> Output Class Initialized
INFO - 2020-02-27 09:31:59 --> Security Class Initialized
DEBUG - 2020-02-27 09:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:31:59 --> Input Class Initialized
INFO - 2020-02-27 09:31:59 --> Language Class Initialized
INFO - 2020-02-27 09:31:59 --> Loader Class Initialized
INFO - 2020-02-27 09:31:59 --> Helper loaded: url_helper
INFO - 2020-02-27 09:31:59 --> Helper loaded: string_helper
INFO - 2020-02-27 09:31:59 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:31:59 --> Controller Class Initialized
INFO - 2020-02-27 09:31:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 09:32:00 --> Pagination Class Initialized
INFO - 2020-02-27 09:32:00 --> Model "M_show" initialized
INFO - 2020-02-27 09:32:00 --> Helper loaded: form_helper
INFO - 2020-02-27 09:32:00 --> Form Validation Class Initialized
INFO - 2020-02-27 09:32:00 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 09:32:00 --> Final output sent to browser
DEBUG - 2020-02-27 09:32:00 --> Total execution time: 0.8375
INFO - 2020-02-27 09:32:00 --> Config Class Initialized
INFO - 2020-02-27 09:32:00 --> Config Class Initialized
INFO - 2020-02-27 09:32:00 --> Hooks Class Initialized
INFO - 2020-02-27 09:32:00 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:32:00 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:32:00 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:32:00 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:32:00 --> URI Class Initialized
INFO - 2020-02-27 09:32:00 --> Utf8 Class Initialized
INFO - 2020-02-27 09:32:00 --> Router Class Initialized
INFO - 2020-02-27 09:32:00 --> URI Class Initialized
INFO - 2020-02-27 09:32:00 --> Output Class Initialized
INFO - 2020-02-27 09:32:00 --> Security Class Initialized
INFO - 2020-02-27 09:32:00 --> Router Class Initialized
DEBUG - 2020-02-27 09:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:32:00 --> Output Class Initialized
INFO - 2020-02-27 09:32:00 --> Input Class Initialized
INFO - 2020-02-27 09:32:00 --> Security Class Initialized
INFO - 2020-02-27 09:32:00 --> Language Class Initialized
DEBUG - 2020-02-27 09:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:32:00 --> Input Class Initialized
ERROR - 2020-02-27 09:32:00 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 09:32:00 --> Language Class Initialized
ERROR - 2020-02-27 09:32:00 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 09:34:52 --> Config Class Initialized
INFO - 2020-02-27 09:34:52 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:34:52 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:34:52 --> Utf8 Class Initialized
INFO - 2020-02-27 09:34:52 --> URI Class Initialized
INFO - 2020-02-27 09:34:52 --> Router Class Initialized
INFO - 2020-02-27 09:34:53 --> Output Class Initialized
INFO - 2020-02-27 09:34:53 --> Security Class Initialized
DEBUG - 2020-02-27 09:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:34:53 --> Input Class Initialized
INFO - 2020-02-27 09:34:53 --> Language Class Initialized
ERROR - 2020-02-27 09:34:53 --> Severity: error --> Exception: syntax error, unexpected 'redirect' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 65
INFO - 2020-02-27 09:34:59 --> Config Class Initialized
INFO - 2020-02-27 09:34:59 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:34:59 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:00 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:00 --> URI Class Initialized
INFO - 2020-02-27 09:35:00 --> Router Class Initialized
INFO - 2020-02-27 09:35:00 --> Output Class Initialized
INFO - 2020-02-27 09:35:00 --> Security Class Initialized
DEBUG - 2020-02-27 09:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:00 --> Input Class Initialized
INFO - 2020-02-27 09:35:00 --> Language Class Initialized
INFO - 2020-02-27 09:35:00 --> Loader Class Initialized
INFO - 2020-02-27 09:35:00 --> Helper loaded: url_helper
INFO - 2020-02-27 09:35:00 --> Helper loaded: string_helper
INFO - 2020-02-27 09:35:00 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:35:00 --> Controller Class Initialized
INFO - 2020-02-27 09:35:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 09:35:00 --> Pagination Class Initialized
INFO - 2020-02-27 09:35:00 --> Model "M_show" initialized
INFO - 2020-02-27 09:35:00 --> Helper loaded: form_helper
INFO - 2020-02-27 09:35:00 --> Form Validation Class Initialized
INFO - 2020-02-27 09:35:00 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 09:35:00 --> Final output sent to browser
DEBUG - 2020-02-27 09:35:00 --> Total execution time: 0.8364
INFO - 2020-02-27 09:35:02 --> Config Class Initialized
INFO - 2020-02-27 09:35:02 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:35:02 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:02 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:03 --> URI Class Initialized
INFO - 2020-02-27 09:35:03 --> Router Class Initialized
INFO - 2020-02-27 09:35:03 --> Output Class Initialized
INFO - 2020-02-27 09:35:03 --> Security Class Initialized
DEBUG - 2020-02-27 09:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:03 --> Input Class Initialized
INFO - 2020-02-27 09:35:03 --> Language Class Initialized
ERROR - 2020-02-27 09:35:03 --> Severity: error --> Exception: syntax error, unexpected 'redirect' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 65
INFO - 2020-02-27 09:35:04 --> Config Class Initialized
INFO - 2020-02-27 09:35:05 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:35:05 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:05 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:05 --> URI Class Initialized
INFO - 2020-02-27 09:35:05 --> Router Class Initialized
INFO - 2020-02-27 09:35:05 --> Output Class Initialized
INFO - 2020-02-27 09:35:05 --> Security Class Initialized
DEBUG - 2020-02-27 09:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:05 --> Input Class Initialized
INFO - 2020-02-27 09:35:05 --> Language Class Initialized
INFO - 2020-02-27 09:35:05 --> Loader Class Initialized
INFO - 2020-02-27 09:35:05 --> Helper loaded: url_helper
INFO - 2020-02-27 09:35:05 --> Helper loaded: string_helper
INFO - 2020-02-27 09:35:05 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:35:05 --> Controller Class Initialized
INFO - 2020-02-27 09:35:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 09:35:05 --> Pagination Class Initialized
INFO - 2020-02-27 09:35:05 --> Model "M_show" initialized
INFO - 2020-02-27 09:35:05 --> Helper loaded: form_helper
INFO - 2020-02-27 09:35:05 --> Form Validation Class Initialized
INFO - 2020-02-27 09:35:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 09:35:05 --> Final output sent to browser
DEBUG - 2020-02-27 09:35:06 --> Total execution time: 0.9280
INFO - 2020-02-27 09:35:07 --> Config Class Initialized
INFO - 2020-02-27 09:35:07 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:35:07 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:07 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:07 --> URI Class Initialized
INFO - 2020-02-27 09:35:07 --> Router Class Initialized
INFO - 2020-02-27 09:35:07 --> Output Class Initialized
INFO - 2020-02-27 09:35:07 --> Security Class Initialized
DEBUG - 2020-02-27 09:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:07 --> Input Class Initialized
INFO - 2020-02-27 09:35:07 --> Language Class Initialized
ERROR - 2020-02-27 09:35:07 --> Severity: error --> Exception: syntax error, unexpected 'redirect' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 65
INFO - 2020-02-27 09:35:09 --> Config Class Initialized
INFO - 2020-02-27 09:35:09 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:35:09 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:09 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:09 --> URI Class Initialized
INFO - 2020-02-27 09:35:10 --> Router Class Initialized
INFO - 2020-02-27 09:35:10 --> Output Class Initialized
INFO - 2020-02-27 09:35:10 --> Security Class Initialized
DEBUG - 2020-02-27 09:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:10 --> Input Class Initialized
INFO - 2020-02-27 09:35:10 --> Language Class Initialized
INFO - 2020-02-27 09:35:10 --> Loader Class Initialized
INFO - 2020-02-27 09:35:10 --> Helper loaded: url_helper
INFO - 2020-02-27 09:35:10 --> Helper loaded: string_helper
INFO - 2020-02-27 09:35:10 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:35:10 --> Controller Class Initialized
INFO - 2020-02-27 09:35:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 09:35:10 --> Pagination Class Initialized
INFO - 2020-02-27 09:35:10 --> Model "M_show" initialized
INFO - 2020-02-27 09:35:10 --> Helper loaded: form_helper
INFO - 2020-02-27 09:35:10 --> Form Validation Class Initialized
INFO - 2020-02-27 09:35:10 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 09:35:10 --> Final output sent to browser
DEBUG - 2020-02-27 09:35:10 --> Total execution time: 0.8189
INFO - 2020-02-27 09:35:36 --> Config Class Initialized
INFO - 2020-02-27 09:35:36 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:35:36 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:36 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:36 --> URI Class Initialized
INFO - 2020-02-27 09:35:36 --> Router Class Initialized
INFO - 2020-02-27 09:35:36 --> Output Class Initialized
INFO - 2020-02-27 09:35:36 --> Security Class Initialized
DEBUG - 2020-02-27 09:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:36 --> Input Class Initialized
INFO - 2020-02-27 09:35:36 --> Language Class Initialized
INFO - 2020-02-27 09:35:36 --> Loader Class Initialized
INFO - 2020-02-27 09:35:36 --> Helper loaded: url_helper
INFO - 2020-02-27 09:35:37 --> Helper loaded: string_helper
INFO - 2020-02-27 09:35:37 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:35:37 --> Controller Class Initialized
INFO - 2020-02-27 09:35:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 09:35:37 --> Pagination Class Initialized
INFO - 2020-02-27 09:35:37 --> Model "M_show" initialized
INFO - 2020-02-27 09:35:37 --> Helper loaded: form_helper
INFO - 2020-02-27 09:35:37 --> Form Validation Class Initialized
INFO - 2020-02-27 09:35:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 09:35:37 --> Final output sent to browser
DEBUG - 2020-02-27 09:35:37 --> Total execution time: 0.8639
INFO - 2020-02-27 09:35:37 --> Config Class Initialized
INFO - 2020-02-27 09:35:37 --> Config Class Initialized
INFO - 2020-02-27 09:35:37 --> Hooks Class Initialized
INFO - 2020-02-27 09:35:37 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:35:37 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:37 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:35:37 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:37 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:37 --> URI Class Initialized
INFO - 2020-02-27 09:35:37 --> URI Class Initialized
INFO - 2020-02-27 09:35:37 --> Router Class Initialized
INFO - 2020-02-27 09:35:37 --> Router Class Initialized
INFO - 2020-02-27 09:35:37 --> Output Class Initialized
INFO - 2020-02-27 09:35:37 --> Security Class Initialized
INFO - 2020-02-27 09:35:37 --> Output Class Initialized
DEBUG - 2020-02-27 09:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:37 --> Security Class Initialized
INFO - 2020-02-27 09:35:37 --> Input Class Initialized
DEBUG - 2020-02-27 09:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:37 --> Input Class Initialized
INFO - 2020-02-27 09:35:37 --> Language Class Initialized
INFO - 2020-02-27 09:35:37 --> Language Class Initialized
ERROR - 2020-02-27 09:35:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 09:35:38 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 09:35:40 --> Config Class Initialized
INFO - 2020-02-27 09:35:40 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:35:40 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:40 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:40 --> URI Class Initialized
INFO - 2020-02-27 09:35:40 --> Router Class Initialized
INFO - 2020-02-27 09:35:40 --> Output Class Initialized
INFO - 2020-02-27 09:35:40 --> Security Class Initialized
DEBUG - 2020-02-27 09:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:41 --> Input Class Initialized
INFO - 2020-02-27 09:35:41 --> Language Class Initialized
INFO - 2020-02-27 09:35:41 --> Loader Class Initialized
INFO - 2020-02-27 09:35:41 --> Helper loaded: url_helper
INFO - 2020-02-27 09:35:41 --> Helper loaded: string_helper
INFO - 2020-02-27 09:35:41 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:35:41 --> Controller Class Initialized
INFO - 2020-02-27 09:35:41 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:35:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:35:41 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:35:41 --> Helper loaded: form_helper
INFO - 2020-02-27 09:35:41 --> Form Validation Class Initialized
INFO - 2020-02-27 09:35:41 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:35:41 --> Final output sent to browser
INFO - 2020-02-27 09:35:41 --> Config Class Initialized
INFO - 2020-02-27 09:35:41 --> Config Class Initialized
INFO - 2020-02-27 09:35:41 --> Config Class Initialized
INFO - 2020-02-27 09:35:41 --> Hooks Class Initialized
INFO - 2020-02-27 09:35:41 --> Hooks Class Initialized
INFO - 2020-02-27 09:35:41 --> Config Class Initialized
INFO - 2020-02-27 09:35:41 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:35:41 --> Total execution time: 0.8027
INFO - 2020-02-27 09:35:41 --> Config Class Initialized
INFO - 2020-02-27 09:35:41 --> Hooks Class Initialized
INFO - 2020-02-27 09:35:41 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:35:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:35:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:35:41 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:41 --> Config Class Initialized
INFO - 2020-02-27 09:35:41 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:41 --> Hooks Class Initialized
INFO - 2020-02-27 09:35:41 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:41 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:41 --> URI Class Initialized
DEBUG - 2020-02-27 09:35:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:35:41 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:41 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:41 --> URI Class Initialized
INFO - 2020-02-27 09:35:41 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:41 --> Router Class Initialized
DEBUG - 2020-02-27 09:35:41 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:41 --> URI Class Initialized
INFO - 2020-02-27 09:35:41 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:41 --> URI Class Initialized
INFO - 2020-02-27 09:35:41 --> URI Class Initialized
INFO - 2020-02-27 09:35:41 --> Output Class Initialized
INFO - 2020-02-27 09:35:41 --> Router Class Initialized
INFO - 2020-02-27 09:35:41 --> Router Class Initialized
INFO - 2020-02-27 09:35:41 --> Security Class Initialized
INFO - 2020-02-27 09:35:41 --> Router Class Initialized
INFO - 2020-02-27 09:35:41 --> Output Class Initialized
INFO - 2020-02-27 09:35:41 --> Output Class Initialized
INFO - 2020-02-27 09:35:41 --> URI Class Initialized
INFO - 2020-02-27 09:35:41 --> Router Class Initialized
INFO - 2020-02-27 09:35:41 --> Security Class Initialized
INFO - 2020-02-27 09:35:41 --> Security Class Initialized
INFO - 2020-02-27 09:35:41 --> Output Class Initialized
INFO - 2020-02-27 09:35:41 --> Router Class Initialized
DEBUG - 2020-02-27 09:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:41 --> Output Class Initialized
INFO - 2020-02-27 09:35:41 --> Input Class Initialized
INFO - 2020-02-27 09:35:41 --> Security Class Initialized
INFO - 2020-02-27 09:35:41 --> Output Class Initialized
DEBUG - 2020-02-27 09:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:41 --> Security Class Initialized
DEBUG - 2020-02-27 09:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:41 --> Input Class Initialized
DEBUG - 2020-02-27 09:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:41 --> Security Class Initialized
INFO - 2020-02-27 09:35:41 --> Input Class Initialized
INFO - 2020-02-27 09:35:41 --> Language Class Initialized
INFO - 2020-02-27 09:35:41 --> Input Class Initialized
INFO - 2020-02-27 09:35:41 --> Language Class Initialized
INFO - 2020-02-27 09:35:41 --> Language Class Initialized
INFO - 2020-02-27 09:35:41 --> Input Class Initialized
ERROR - 2020-02-27 09:35:41 --> 404 Page Not Found: Bower_components/jquery
DEBUG - 2020-02-27 09:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:41 --> Input Class Initialized
INFO - 2020-02-27 09:35:41 --> Language Class Initialized
ERROR - 2020-02-27 09:35:41 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 09:35:41 --> Language Class Initialized
ERROR - 2020-02-27 09:35:41 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-27 09:35:42 --> Config Class Initialized
INFO - 2020-02-27 09:35:42 --> Hooks Class Initialized
INFO - 2020-02-27 09:35:42 --> Language Class Initialized
ERROR - 2020-02-27 09:35:42 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 09:35:42 --> Loader Class Initialized
INFO - 2020-02-27 09:35:42 --> Config Class Initialized
INFO - 2020-02-27 09:35:42 --> Config Class Initialized
INFO - 2020-02-27 09:35:42 --> Hooks Class Initialized
INFO - 2020-02-27 09:35:42 --> Hooks Class Initialized
INFO - 2020-02-27 09:35:42 --> Helper loaded: url_helper
ERROR - 2020-02-27 09:35:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-27 09:35:42 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:42 --> Config Class Initialized
INFO - 2020-02-27 09:35:42 --> Hooks Class Initialized
INFO - 2020-02-27 09:35:42 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:42 --> Helper loaded: string_helper
DEBUG - 2020-02-27 09:35:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:35:42 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:42 --> Config Class Initialized
INFO - 2020-02-27 09:35:42 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:42 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:42 --> URI Class Initialized
INFO - 2020-02-27 09:35:42 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:35:42 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:42 --> Database Driver Class Initialized
INFO - 2020-02-27 09:35:42 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:42 --> URI Class Initialized
INFO - 2020-02-27 09:35:42 --> Router Class Initialized
INFO - 2020-02-27 09:35:42 --> URI Class Initialized
DEBUG - 2020-02-27 09:35:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:35:42 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:35:42 --> Router Class Initialized
INFO - 2020-02-27 09:35:42 --> URI Class Initialized
INFO - 2020-02-27 09:35:42 --> Output Class Initialized
INFO - 2020-02-27 09:35:42 --> Router Class Initialized
INFO - 2020-02-27 09:35:42 --> URI Class Initialized
INFO - 2020-02-27 09:35:42 --> Security Class Initialized
INFO - 2020-02-27 09:35:42 --> Output Class Initialized
INFO - 2020-02-27 09:35:42 --> Controller Class Initialized
INFO - 2020-02-27 09:35:42 --> Output Class Initialized
INFO - 2020-02-27 09:35:42 --> Router Class Initialized
INFO - 2020-02-27 09:35:42 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:35:42 --> Security Class Initialized
INFO - 2020-02-27 09:35:42 --> Router Class Initialized
INFO - 2020-02-27 09:35:42 --> Security Class Initialized
INFO - 2020-02-27 09:35:42 --> Output Class Initialized
DEBUG - 2020-02-27 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:42 --> Input Class Initialized
INFO - 2020-02-27 09:35:42 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-27 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:42 --> Security Class Initialized
DEBUG - 2020-02-27 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:42 --> Output Class Initialized
INFO - 2020-02-27 09:35:42 --> Input Class Initialized
INFO - 2020-02-27 09:35:42 --> Input Class Initialized
INFO - 2020-02-27 09:35:42 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:35:42 --> Security Class Initialized
DEBUG - 2020-02-27 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:42 --> Language Class Initialized
INFO - 2020-02-27 09:35:42 --> Input Class Initialized
DEBUG - 2020-02-27 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:42 --> Language Class Initialized
INFO - 2020-02-27 09:35:42 --> Language Class Initialized
ERROR - 2020-02-27 09:35:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:35:42 --> Helper loaded: form_helper
INFO - 2020-02-27 09:35:42 --> Form Validation Class Initialized
INFO - 2020-02-27 09:35:42 --> Language Class Initialized
ERROR - 2020-02-27 09:35:42 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 09:35:42 --> Input Class Initialized
ERROR - 2020-02-27 09:35:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 09:35:42 --> Config Class Initialized
INFO - 2020-02-27 09:35:42 --> Hooks Class Initialized
INFO - 2020-02-27 09:35:42 --> Language Class Initialized
ERROR - 2020-02-27 09:35:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-27 09:35:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-27 09:35:42 --> Config Class Initialized
INFO - 2020-02-27 09:35:42 --> Config Class Initialized
INFO - 2020-02-27 09:35:42 --> Hooks Class Initialized
ERROR - 2020-02-27 09:35:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:35:42 --> Hooks Class Initialized
ERROR - 2020-02-27 09:35:42 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-27 09:35:42 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:42 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:42 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-27 09:35:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:35:42 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:42 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:42 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:42 --> Final output sent to browser
INFO - 2020-02-27 09:35:42 --> URI Class Initialized
DEBUG - 2020-02-27 09:35:42 --> Total execution time: 0.9317
INFO - 2020-02-27 09:35:42 --> URI Class Initialized
INFO - 2020-02-27 09:35:42 --> URI Class Initialized
INFO - 2020-02-27 09:35:42 --> Router Class Initialized
INFO - 2020-02-27 09:35:42 --> Router Class Initialized
INFO - 2020-02-27 09:35:42 --> Output Class Initialized
INFO - 2020-02-27 09:35:42 --> Router Class Initialized
INFO - 2020-02-27 09:35:42 --> Output Class Initialized
INFO - 2020-02-27 09:35:42 --> Output Class Initialized
INFO - 2020-02-27 09:35:42 --> Security Class Initialized
INFO - 2020-02-27 09:35:42 --> Security Class Initialized
DEBUG - 2020-02-27 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:42 --> Security Class Initialized
INFO - 2020-02-27 09:35:42 --> Input Class Initialized
DEBUG - 2020-02-27 09:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:42 --> Input Class Initialized
INFO - 2020-02-27 09:35:42 --> Input Class Initialized
INFO - 2020-02-27 09:35:42 --> Language Class Initialized
INFO - 2020-02-27 09:35:42 --> Language Class Initialized
INFO - 2020-02-27 09:35:42 --> Language Class Initialized
ERROR - 2020-02-27 09:35:42 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 09:35:42 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 09:35:42 --> Loader Class Initialized
INFO - 2020-02-27 09:35:42 --> Helper loaded: url_helper
INFO - 2020-02-27 09:35:42 --> Config Class Initialized
INFO - 2020-02-27 09:35:42 --> Hooks Class Initialized
INFO - 2020-02-27 09:35:42 --> Helper loaded: string_helper
DEBUG - 2020-02-27 09:35:42 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:42 --> Database Driver Class Initialized
INFO - 2020-02-27 09:35:43 --> Utf8 Class Initialized
DEBUG - 2020-02-27 09:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:35:43 --> URI Class Initialized
INFO - 2020-02-27 09:35:43 --> Controller Class Initialized
INFO - 2020-02-27 09:35:43 --> Router Class Initialized
INFO - 2020-02-27 09:35:43 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:35:43 --> Output Class Initialized
INFO - 2020-02-27 09:35:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:35:43 --> Security Class Initialized
INFO - 2020-02-27 09:35:43 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 09:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:43 --> Input Class Initialized
INFO - 2020-02-27 09:35:43 --> Helper loaded: form_helper
INFO - 2020-02-27 09:35:43 --> Form Validation Class Initialized
INFO - 2020-02-27 09:35:43 --> Language Class Initialized
ERROR - 2020-02-27 09:35:43 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-27 09:35:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 09:35:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 09:35:43 --> Config Class Initialized
INFO - 2020-02-27 09:35:43 --> Hooks Class Initialized
INFO - 2020-02-27 09:35:43 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 09:35:43 --> Final output sent to browser
DEBUG - 2020-02-27 09:35:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:35:43 --> Total execution time: 1.0125
INFO - 2020-02-27 09:35:43 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:43 --> URI Class Initialized
INFO - 2020-02-27 09:35:43 --> Router Class Initialized
INFO - 2020-02-27 09:35:43 --> Output Class Initialized
INFO - 2020-02-27 09:35:43 --> Security Class Initialized
DEBUG - 2020-02-27 09:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:43 --> Input Class Initialized
INFO - 2020-02-27 09:35:43 --> Language Class Initialized
ERROR - 2020-02-27 09:35:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 09:35:43 --> Config Class Initialized
INFO - 2020-02-27 09:35:43 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:35:43 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:35:43 --> Utf8 Class Initialized
INFO - 2020-02-27 09:35:43 --> URI Class Initialized
INFO - 2020-02-27 09:35:43 --> Router Class Initialized
INFO - 2020-02-27 09:35:43 --> Output Class Initialized
INFO - 2020-02-27 09:35:44 --> Security Class Initialized
DEBUG - 2020-02-27 09:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:35:44 --> Input Class Initialized
INFO - 2020-02-27 09:35:44 --> Language Class Initialized
ERROR - 2020-02-27 09:35:44 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 09:36:12 --> Config Class Initialized
INFO - 2020-02-27 09:36:13 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:36:13 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:36:13 --> Utf8 Class Initialized
INFO - 2020-02-27 09:36:13 --> URI Class Initialized
INFO - 2020-02-27 09:36:13 --> Router Class Initialized
INFO - 2020-02-27 09:36:13 --> Output Class Initialized
INFO - 2020-02-27 09:36:13 --> Security Class Initialized
DEBUG - 2020-02-27 09:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:36:13 --> Input Class Initialized
INFO - 2020-02-27 09:36:13 --> Language Class Initialized
INFO - 2020-02-27 09:36:13 --> Loader Class Initialized
INFO - 2020-02-27 09:36:13 --> Helper loaded: url_helper
INFO - 2020-02-27 09:36:13 --> Helper loaded: string_helper
INFO - 2020-02-27 09:36:13 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:36:13 --> Controller Class Initialized
INFO - 2020-02-27 09:36:13 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:36:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:36:13 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:36:13 --> Helper loaded: form_helper
INFO - 2020-02-27 09:36:13 --> Form Validation Class Initialized
INFO - 2020-02-27 15:36:13 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 15:36:13 --> Final output sent to browser
DEBUG - 2020-02-27 15:36:13 --> Total execution time: 0.9682
INFO - 2020-02-27 09:36:28 --> Config Class Initialized
INFO - 2020-02-27 09:36:28 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:36:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:36:28 --> Utf8 Class Initialized
INFO - 2020-02-27 09:36:28 --> URI Class Initialized
INFO - 2020-02-27 09:36:28 --> Router Class Initialized
INFO - 2020-02-27 09:36:28 --> Output Class Initialized
INFO - 2020-02-27 09:36:28 --> Security Class Initialized
DEBUG - 2020-02-27 09:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:36:28 --> Input Class Initialized
INFO - 2020-02-27 09:36:28 --> Language Class Initialized
INFO - 2020-02-27 09:36:29 --> Loader Class Initialized
INFO - 2020-02-27 09:36:29 --> Helper loaded: url_helper
INFO - 2020-02-27 09:36:29 --> Helper loaded: string_helper
INFO - 2020-02-27 09:36:29 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:36:29 --> Controller Class Initialized
INFO - 2020-02-27 09:36:29 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:36:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:36:29 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:36:29 --> Helper loaded: form_helper
INFO - 2020-02-27 09:36:29 --> Form Validation Class Initialized
ERROR - 2020-02-27 09:36:29 --> Severity: Notice --> Undefined variable: tanggalp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 09:36:29 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 09:36:29 --> Final output sent to browser
DEBUG - 2020-02-27 09:36:29 --> Total execution time: 0.8732
INFO - 2020-02-27 09:36:42 --> Config Class Initialized
INFO - 2020-02-27 09:36:42 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:36:42 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:36:42 --> Utf8 Class Initialized
INFO - 2020-02-27 09:36:42 --> URI Class Initialized
INFO - 2020-02-27 09:36:42 --> Router Class Initialized
INFO - 2020-02-27 09:36:42 --> Output Class Initialized
INFO - 2020-02-27 09:36:42 --> Security Class Initialized
DEBUG - 2020-02-27 09:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:36:42 --> Input Class Initialized
INFO - 2020-02-27 09:36:42 --> Language Class Initialized
INFO - 2020-02-27 09:36:42 --> Loader Class Initialized
INFO - 2020-02-27 09:36:42 --> Helper loaded: url_helper
INFO - 2020-02-27 09:36:42 --> Helper loaded: string_helper
INFO - 2020-02-27 09:36:43 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:36:43 --> Controller Class Initialized
INFO - 2020-02-27 09:36:43 --> Model "M_tiket" initialized
INFO - 2020-02-27 09:36:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 09:36:43 --> Model "M_pesan" initialized
INFO - 2020-02-27 09:36:43 --> Helper loaded: form_helper
INFO - 2020-02-27 09:36:43 --> Form Validation Class Initialized
INFO - 2020-02-27 09:36:43 --> Upload Class Initialized
INFO - 2020-02-27 09:36:43 --> Config Class Initialized
INFO - 2020-02-27 09:36:43 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:36:43 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:36:43 --> Utf8 Class Initialized
INFO - 2020-02-27 09:36:43 --> URI Class Initialized
INFO - 2020-02-27 09:36:43 --> Router Class Initialized
INFO - 2020-02-27 09:36:43 --> Output Class Initialized
INFO - 2020-02-27 09:36:43 --> Security Class Initialized
DEBUG - 2020-02-27 09:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:36:43 --> Input Class Initialized
INFO - 2020-02-27 09:36:43 --> Language Class Initialized
INFO - 2020-02-27 09:36:43 --> Loader Class Initialized
INFO - 2020-02-27 09:36:43 --> Helper loaded: url_helper
INFO - 2020-02-27 09:36:43 --> Helper loaded: string_helper
INFO - 2020-02-27 09:36:43 --> Database Driver Class Initialized
DEBUG - 2020-02-27 09:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 09:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 09:36:43 --> Controller Class Initialized
INFO - 2020-02-27 09:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 09:36:44 --> Pagination Class Initialized
INFO - 2020-02-27 09:36:44 --> Model "M_show" initialized
INFO - 2020-02-27 09:36:44 --> Helper loaded: form_helper
INFO - 2020-02-27 09:36:44 --> Form Validation Class Initialized
INFO - 2020-02-27 09:36:44 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 09:36:44 --> Final output sent to browser
DEBUG - 2020-02-27 09:36:44 --> Total execution time: 0.7682
INFO - 2020-02-27 09:36:44 --> Config Class Initialized
INFO - 2020-02-27 09:36:44 --> Config Class Initialized
INFO - 2020-02-27 09:36:44 --> Hooks Class Initialized
INFO - 2020-02-27 09:36:44 --> Hooks Class Initialized
DEBUG - 2020-02-27 09:36:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 09:36:44 --> UTF-8 Support Enabled
INFO - 2020-02-27 09:36:44 --> Utf8 Class Initialized
INFO - 2020-02-27 09:36:44 --> Utf8 Class Initialized
INFO - 2020-02-27 09:36:44 --> URI Class Initialized
INFO - 2020-02-27 09:36:44 --> URI Class Initialized
INFO - 2020-02-27 09:36:44 --> Router Class Initialized
INFO - 2020-02-27 09:36:44 --> Router Class Initialized
INFO - 2020-02-27 09:36:44 --> Output Class Initialized
INFO - 2020-02-27 09:36:44 --> Output Class Initialized
INFO - 2020-02-27 09:36:44 --> Security Class Initialized
INFO - 2020-02-27 09:36:44 --> Security Class Initialized
DEBUG - 2020-02-27 09:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 09:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 09:36:44 --> Input Class Initialized
INFO - 2020-02-27 09:36:44 --> Input Class Initialized
INFO - 2020-02-27 09:36:44 --> Language Class Initialized
INFO - 2020-02-27 09:36:44 --> Language Class Initialized
ERROR - 2020-02-27 09:36:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 09:36:44 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 17:52:17 --> Config Class Initialized
INFO - 2020-02-27 17:52:18 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:52:19 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:52:19 --> Utf8 Class Initialized
INFO - 2020-02-27 17:52:19 --> URI Class Initialized
DEBUG - 2020-02-27 17:52:19 --> No URI present. Default controller set.
INFO - 2020-02-27 17:52:20 --> Router Class Initialized
INFO - 2020-02-27 17:52:20 --> Config Class Initialized
INFO - 2020-02-27 17:52:20 --> Output Class Initialized
INFO - 2020-02-27 17:52:20 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:52:20 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:52:20 --> Security Class Initialized
INFO - 2020-02-27 17:52:20 --> Utf8 Class Initialized
INFO - 2020-02-27 17:52:20 --> URI Class Initialized
DEBUG - 2020-02-27 17:52:20 --> No URI present. Default controller set.
INFO - 2020-02-27 17:52:20 --> Router Class Initialized
DEBUG - 2020-02-27 17:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:52:20 --> Input Class Initialized
INFO - 2020-02-27 17:52:20 --> Output Class Initialized
INFO - 2020-02-27 17:52:20 --> Security Class Initialized
INFO - 2020-02-27 17:52:20 --> Language Class Initialized
DEBUG - 2020-02-27 17:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:52:20 --> Input Class Initialized
INFO - 2020-02-27 17:52:21 --> Language Class Initialized
INFO - 2020-02-27 17:52:21 --> Loader Class Initialized
INFO - 2020-02-27 17:52:21 --> Loader Class Initialized
INFO - 2020-02-27 17:52:21 --> Helper loaded: url_helper
INFO - 2020-02-27 17:52:21 --> Helper loaded: url_helper
INFO - 2020-02-27 17:52:21 --> Helper loaded: string_helper
INFO - 2020-02-27 17:52:21 --> Helper loaded: string_helper
INFO - 2020-02-27 17:52:23 --> Database Driver Class Initialized
INFO - 2020-02-27 17:52:23 --> Database Driver Class Initialized
DEBUG - 2020-02-27 17:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-27 17:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 17:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 17:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 17:52:24 --> Controller Class Initialized
INFO - 2020-02-27 17:52:24 --> Controller Class Initialized
INFO - 2020-02-27 17:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 17:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 17:52:24 --> Pagination Class Initialized
INFO - 2020-02-27 17:52:24 --> Pagination Class Initialized
INFO - 2020-02-27 17:52:24 --> Model "M_show" initialized
INFO - 2020-02-27 17:52:24 --> Model "M_show" initialized
INFO - 2020-02-27 17:52:24 --> Helper loaded: form_helper
INFO - 2020-02-27 17:52:24 --> Helper loaded: form_helper
INFO - 2020-02-27 17:52:24 --> Form Validation Class Initialized
INFO - 2020-02-27 17:52:24 --> Form Validation Class Initialized
INFO - 2020-02-27 17:52:25 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 17:52:25 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 17:52:25 --> Final output sent to browser
INFO - 2020-02-27 17:52:25 --> Final output sent to browser
DEBUG - 2020-02-27 17:52:26 --> Total execution time: 5.6256
DEBUG - 2020-02-27 17:52:26 --> Total execution time: 8.6835
INFO - 2020-02-27 17:53:25 --> Config Class Initialized
INFO - 2020-02-27 17:53:26 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:53:26 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:26 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:26 --> URI Class Initialized
INFO - 2020-02-27 17:53:26 --> Router Class Initialized
INFO - 2020-02-27 17:53:26 --> Output Class Initialized
INFO - 2020-02-27 17:53:26 --> Security Class Initialized
DEBUG - 2020-02-27 17:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:26 --> Input Class Initialized
INFO - 2020-02-27 17:53:26 --> Language Class Initialized
INFO - 2020-02-27 17:53:27 --> Loader Class Initialized
INFO - 2020-02-27 17:53:27 --> Helper loaded: url_helper
INFO - 2020-02-27 17:53:27 --> Helper loaded: string_helper
INFO - 2020-02-27 17:53:27 --> Database Driver Class Initialized
DEBUG - 2020-02-27 17:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 17:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 17:53:27 --> Controller Class Initialized
INFO - 2020-02-27 17:53:27 --> Model "M_tiket" initialized
INFO - 2020-02-27 17:53:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 17:53:27 --> Model "M_pesan" initialized
INFO - 2020-02-27 17:53:27 --> Helper loaded: form_helper
INFO - 2020-02-27 17:53:27 --> Form Validation Class Initialized
INFO - 2020-02-27 17:53:28 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 17:53:28 --> Final output sent to browser
DEBUG - 2020-02-27 17:53:28 --> Total execution time: 2.5100
INFO - 2020-02-27 17:53:28 --> Config Class Initialized
INFO - 2020-02-27 17:53:28 --> Config Class Initialized
INFO - 2020-02-27 17:53:28 --> Config Class Initialized
INFO - 2020-02-27 17:53:28 --> Config Class Initialized
INFO - 2020-02-27 17:53:28 --> Hooks Class Initialized
INFO - 2020-02-27 17:53:28 --> Hooks Class Initialized
INFO - 2020-02-27 17:53:28 --> Hooks Class Initialized
INFO - 2020-02-27 17:53:28 --> Hooks Class Initialized
INFO - 2020-02-27 17:53:28 --> Config Class Initialized
INFO - 2020-02-27 17:53:28 --> Config Class Initialized
DEBUG - 2020-02-27 17:53:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:28 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:53:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 17:53:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:28 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:53:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:28 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:28 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:28 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:28 --> Utf8 Class Initialized
DEBUG - 2020-02-27 17:53:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 17:53:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:28 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:28 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:28 --> URI Class Initialized
INFO - 2020-02-27 17:53:28 --> URI Class Initialized
INFO - 2020-02-27 17:53:28 --> URI Class Initialized
INFO - 2020-02-27 17:53:28 --> URI Class Initialized
INFO - 2020-02-27 17:53:28 --> Router Class Initialized
INFO - 2020-02-27 17:53:28 --> Router Class Initialized
INFO - 2020-02-27 17:53:28 --> Router Class Initialized
INFO - 2020-02-27 17:53:28 --> URI Class Initialized
INFO - 2020-02-27 17:53:28 --> URI Class Initialized
INFO - 2020-02-27 17:53:28 --> Router Class Initialized
INFO - 2020-02-27 17:53:28 --> Output Class Initialized
INFO - 2020-02-27 17:53:28 --> Output Class Initialized
INFO - 2020-02-27 17:53:28 --> Output Class Initialized
INFO - 2020-02-27 17:53:28 --> Output Class Initialized
INFO - 2020-02-27 17:53:28 --> Router Class Initialized
INFO - 2020-02-27 17:53:28 --> Router Class Initialized
INFO - 2020-02-27 17:53:28 --> Security Class Initialized
INFO - 2020-02-27 17:53:28 --> Security Class Initialized
INFO - 2020-02-27 17:53:28 --> Security Class Initialized
INFO - 2020-02-27 17:53:28 --> Security Class Initialized
INFO - 2020-02-27 17:53:28 --> Output Class Initialized
INFO - 2020-02-27 17:53:28 --> Output Class Initialized
DEBUG - 2020-02-27 17:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 17:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 17:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:28 --> Security Class Initialized
INFO - 2020-02-27 17:53:28 --> Security Class Initialized
DEBUG - 2020-02-27 17:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:28 --> Input Class Initialized
INFO - 2020-02-27 17:53:28 --> Input Class Initialized
INFO - 2020-02-27 17:53:28 --> Input Class Initialized
INFO - 2020-02-27 17:53:28 --> Input Class Initialized
DEBUG - 2020-02-27 17:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 17:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:29 --> Input Class Initialized
INFO - 2020-02-27 17:53:29 --> Language Class Initialized
INFO - 2020-02-27 17:53:29 --> Language Class Initialized
INFO - 2020-02-27 17:53:29 --> Language Class Initialized
INFO - 2020-02-27 17:53:29 --> Input Class Initialized
INFO - 2020-02-27 17:53:29 --> Language Class Initialized
INFO - 2020-02-27 17:53:29 --> Language Class Initialized
INFO - 2020-02-27 17:53:29 --> Language Class Initialized
ERROR - 2020-02-27 17:53:29 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-27 17:53:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-27 17:53:29 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-27 17:53:29 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 17:53:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 17:53:29 --> Loader Class Initialized
INFO - 2020-02-27 17:53:29 --> Config Class Initialized
INFO - 2020-02-27 17:53:29 --> Config Class Initialized
INFO - 2020-02-27 17:53:29 --> Config Class Initialized
INFO - 2020-02-27 17:53:29 --> Config Class Initialized
INFO - 2020-02-27 17:53:29 --> Hooks Class Initialized
INFO - 2020-02-27 17:53:29 --> Hooks Class Initialized
INFO - 2020-02-27 17:53:29 --> Hooks Class Initialized
INFO - 2020-02-27 17:53:29 --> Hooks Class Initialized
INFO - 2020-02-27 17:53:29 --> Helper loaded: url_helper
INFO - 2020-02-27 17:53:29 --> Config Class Initialized
INFO - 2020-02-27 17:53:29 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:53:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 17:53:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:29 --> Helper loaded: string_helper
DEBUG - 2020-02-27 17:53:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 17:53:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:29 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:29 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:29 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:29 --> Utf8 Class Initialized
DEBUG - 2020-02-27 17:53:29 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:29 --> Database Driver Class Initialized
INFO - 2020-02-27 17:53:29 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:29 --> URI Class Initialized
INFO - 2020-02-27 17:53:29 --> URI Class Initialized
INFO - 2020-02-27 17:53:29 --> URI Class Initialized
INFO - 2020-02-27 17:53:29 --> URI Class Initialized
DEBUG - 2020-02-27 17:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 17:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 17:53:29 --> Router Class Initialized
INFO - 2020-02-27 17:53:29 --> Router Class Initialized
INFO - 2020-02-27 17:53:29 --> Router Class Initialized
INFO - 2020-02-27 17:53:29 --> Router Class Initialized
INFO - 2020-02-27 17:53:29 --> URI Class Initialized
INFO - 2020-02-27 17:53:29 --> Output Class Initialized
INFO - 2020-02-27 17:53:29 --> Output Class Initialized
INFO - 2020-02-27 17:53:29 --> Router Class Initialized
INFO - 2020-02-27 17:53:29 --> Controller Class Initialized
INFO - 2020-02-27 17:53:29 --> Output Class Initialized
INFO - 2020-02-27 17:53:29 --> Output Class Initialized
INFO - 2020-02-27 17:53:30 --> Security Class Initialized
INFO - 2020-02-27 17:53:30 --> Model "M_tiket" initialized
INFO - 2020-02-27 17:53:30 --> Security Class Initialized
INFO - 2020-02-27 17:53:30 --> Output Class Initialized
INFO - 2020-02-27 17:53:30 --> Security Class Initialized
INFO - 2020-02-27 17:53:30 --> Security Class Initialized
INFO - 2020-02-27 17:53:30 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-27 17:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 17:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 17:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 17:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:30 --> Security Class Initialized
INFO - 2020-02-27 17:53:30 --> Input Class Initialized
INFO - 2020-02-27 17:53:30 --> Input Class Initialized
INFO - 2020-02-27 17:53:30 --> Input Class Initialized
INFO - 2020-02-27 17:53:30 --> Input Class Initialized
DEBUG - 2020-02-27 17:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:30 --> Model "M_pesan" initialized
INFO - 2020-02-27 17:53:30 --> Input Class Initialized
INFO - 2020-02-27 17:53:30 --> Language Class Initialized
INFO - 2020-02-27 17:53:30 --> Language Class Initialized
INFO - 2020-02-27 17:53:30 --> Language Class Initialized
INFO - 2020-02-27 17:53:30 --> Language Class Initialized
INFO - 2020-02-27 17:53:30 --> Helper loaded: form_helper
INFO - 2020-02-27 17:53:30 --> Form Validation Class Initialized
INFO - 2020-02-27 17:53:30 --> Language Class Initialized
ERROR - 2020-02-27 17:53:30 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-27 17:53:30 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-27 17:53:30 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-27 17:53:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 17:53:30 --> Loader Class Initialized
ERROR - 2020-02-27 17:53:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-27 17:53:30 --> Helper loaded: url_helper
ERROR - 2020-02-27 17:53:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 17:53:30 --> Config Class Initialized
INFO - 2020-02-27 17:53:30 --> Config Class Initialized
INFO - 2020-02-27 17:53:30 --> Config Class Initialized
INFO - 2020-02-27 17:53:30 --> Hooks Class Initialized
INFO - 2020-02-27 17:53:30 --> Hooks Class Initialized
INFO - 2020-02-27 17:53:30 --> Hooks Class Initialized
INFO - 2020-02-27 17:53:30 --> Helper loaded: string_helper
INFO - 2020-02-27 17:53:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-27 17:53:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 17:53:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 17:53:31 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:31 --> Final output sent to browser
INFO - 2020-02-27 17:53:31 --> Database Driver Class Initialized
INFO - 2020-02-27 17:53:31 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:31 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:31 --> URI Class Initialized
INFO - 2020-02-27 17:53:31 --> Utf8 Class Initialized
DEBUG - 2020-02-27 17:53:31 --> Total execution time: 2.9114
DEBUG - 2020-02-27 17:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 17:53:32 --> Router Class Initialized
INFO - 2020-02-27 17:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 17:53:32 --> URI Class Initialized
INFO - 2020-02-27 17:53:32 --> URI Class Initialized
INFO - 2020-02-27 17:53:32 --> Controller Class Initialized
INFO - 2020-02-27 17:53:32 --> Router Class Initialized
INFO - 2020-02-27 17:53:32 --> Output Class Initialized
INFO - 2020-02-27 17:53:32 --> Router Class Initialized
INFO - 2020-02-27 17:53:32 --> Output Class Initialized
INFO - 2020-02-27 17:53:32 --> Security Class Initialized
INFO - 2020-02-27 17:53:32 --> Model "M_tiket" initialized
INFO - 2020-02-27 17:53:32 --> Output Class Initialized
INFO - 2020-02-27 17:53:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 17:53:32 --> Security Class Initialized
INFO - 2020-02-27 17:53:32 --> Security Class Initialized
DEBUG - 2020-02-27 17:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:33 --> Input Class Initialized
INFO - 2020-02-27 17:53:33 --> Model "M_pesan" initialized
DEBUG - 2020-02-27 17:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 17:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:33 --> Input Class Initialized
INFO - 2020-02-27 17:53:33 --> Input Class Initialized
INFO - 2020-02-27 17:53:33 --> Language Class Initialized
INFO - 2020-02-27 17:53:33 --> Helper loaded: form_helper
INFO - 2020-02-27 17:53:33 --> Form Validation Class Initialized
INFO - 2020-02-27 17:53:33 --> Language Class Initialized
INFO - 2020-02-27 17:53:33 --> Language Class Initialized
ERROR - 2020-02-27 17:53:33 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-27 17:53:33 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-27 17:53:33 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-27 17:53:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 17:53:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 17:53:33 --> Config Class Initialized
INFO - 2020-02-27 17:53:33 --> Hooks Class Initialized
INFO - 2020-02-27 17:53:33 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 17:53:33 --> Final output sent to browser
DEBUG - 2020-02-27 17:53:33 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:33 --> Utf8 Class Initialized
DEBUG - 2020-02-27 17:53:33 --> Total execution time: 4.1819
INFO - 2020-02-27 17:53:33 --> URI Class Initialized
INFO - 2020-02-27 17:53:33 --> Router Class Initialized
INFO - 2020-02-27 17:53:33 --> Output Class Initialized
INFO - 2020-02-27 17:53:33 --> Security Class Initialized
DEBUG - 2020-02-27 17:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:33 --> Input Class Initialized
INFO - 2020-02-27 17:53:33 --> Language Class Initialized
ERROR - 2020-02-27 17:53:33 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-27 17:53:33 --> Config Class Initialized
INFO - 2020-02-27 17:53:33 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:53:34 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:34 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:34 --> URI Class Initialized
INFO - 2020-02-27 17:53:34 --> Router Class Initialized
INFO - 2020-02-27 17:53:34 --> Output Class Initialized
INFO - 2020-02-27 17:53:34 --> Security Class Initialized
DEBUG - 2020-02-27 17:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:34 --> Input Class Initialized
INFO - 2020-02-27 17:53:34 --> Language Class Initialized
ERROR - 2020-02-27 17:53:34 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-27 17:53:34 --> Config Class Initialized
INFO - 2020-02-27 17:53:35 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:53:35 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:35 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:35 --> URI Class Initialized
INFO - 2020-02-27 17:53:35 --> Router Class Initialized
INFO - 2020-02-27 17:53:35 --> Output Class Initialized
INFO - 2020-02-27 17:53:35 --> Security Class Initialized
DEBUG - 2020-02-27 17:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:35 --> Input Class Initialized
INFO - 2020-02-27 17:53:35 --> Language Class Initialized
ERROR - 2020-02-27 17:53:36 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-27 17:53:36 --> Config Class Initialized
INFO - 2020-02-27 17:53:36 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:53:36 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:36 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:36 --> URI Class Initialized
INFO - 2020-02-27 17:53:36 --> Router Class Initialized
INFO - 2020-02-27 17:53:36 --> Output Class Initialized
INFO - 2020-02-27 17:53:36 --> Security Class Initialized
DEBUG - 2020-02-27 17:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:36 --> Input Class Initialized
INFO - 2020-02-27 17:53:36 --> Language Class Initialized
ERROR - 2020-02-27 17:53:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 17:53:36 --> Config Class Initialized
INFO - 2020-02-27 17:53:36 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:53:36 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:37 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:37 --> URI Class Initialized
INFO - 2020-02-27 17:53:37 --> Router Class Initialized
INFO - 2020-02-27 17:53:37 --> Output Class Initialized
INFO - 2020-02-27 17:53:37 --> Security Class Initialized
DEBUG - 2020-02-27 17:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:37 --> Input Class Initialized
INFO - 2020-02-27 17:53:37 --> Language Class Initialized
ERROR - 2020-02-27 17:53:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-27 17:53:37 --> Config Class Initialized
INFO - 2020-02-27 17:53:37 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:53:37 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:37 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:37 --> URI Class Initialized
INFO - 2020-02-27 17:53:37 --> Router Class Initialized
INFO - 2020-02-27 17:53:37 --> Output Class Initialized
INFO - 2020-02-27 17:53:37 --> Security Class Initialized
DEBUG - 2020-02-27 17:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:38 --> Input Class Initialized
INFO - 2020-02-27 17:53:38 --> Language Class Initialized
ERROR - 2020-02-27 17:53:38 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-27 17:53:38 --> Config Class Initialized
INFO - 2020-02-27 17:53:38 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:53:38 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:38 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:38 --> URI Class Initialized
INFO - 2020-02-27 17:53:38 --> Router Class Initialized
INFO - 2020-02-27 17:53:38 --> Output Class Initialized
INFO - 2020-02-27 17:53:38 --> Security Class Initialized
DEBUG - 2020-02-27 17:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:38 --> Input Class Initialized
INFO - 2020-02-27 17:53:38 --> Language Class Initialized
ERROR - 2020-02-27 17:53:38 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-27 17:53:38 --> Config Class Initialized
INFO - 2020-02-27 17:53:38 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:53:38 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:39 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:39 --> URI Class Initialized
INFO - 2020-02-27 17:53:39 --> Router Class Initialized
INFO - 2020-02-27 17:53:39 --> Output Class Initialized
INFO - 2020-02-27 17:53:39 --> Security Class Initialized
DEBUG - 2020-02-27 17:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:39 --> Input Class Initialized
INFO - 2020-02-27 17:53:39 --> Language Class Initialized
ERROR - 2020-02-27 17:53:39 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-27 17:53:39 --> Config Class Initialized
INFO - 2020-02-27 17:53:39 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:53:39 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:53:39 --> Utf8 Class Initialized
INFO - 2020-02-27 17:53:39 --> URI Class Initialized
INFO - 2020-02-27 17:53:39 --> Router Class Initialized
INFO - 2020-02-27 17:53:39 --> Output Class Initialized
INFO - 2020-02-27 17:53:39 --> Security Class Initialized
DEBUG - 2020-02-27 17:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:53:39 --> Input Class Initialized
INFO - 2020-02-27 17:53:39 --> Language Class Initialized
ERROR - 2020-02-27 17:53:39 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-27 17:54:00 --> Config Class Initialized
INFO - 2020-02-27 17:54:01 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:54:01 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:54:01 --> Utf8 Class Initialized
INFO - 2020-02-27 17:54:01 --> URI Class Initialized
INFO - 2020-02-27 17:54:01 --> Router Class Initialized
INFO - 2020-02-27 17:54:01 --> Output Class Initialized
INFO - 2020-02-27 17:54:02 --> Security Class Initialized
DEBUG - 2020-02-27 17:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:54:02 --> Input Class Initialized
INFO - 2020-02-27 17:54:02 --> Language Class Initialized
INFO - 2020-02-27 17:54:02 --> Loader Class Initialized
INFO - 2020-02-27 17:54:02 --> Helper loaded: url_helper
INFO - 2020-02-27 17:54:02 --> Helper loaded: string_helper
INFO - 2020-02-27 17:54:02 --> Database Driver Class Initialized
DEBUG - 2020-02-27 17:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 17:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 17:54:02 --> Controller Class Initialized
INFO - 2020-02-27 17:54:02 --> Model "M_tiket" initialized
INFO - 2020-02-27 17:54:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 17:54:02 --> Model "M_pesan" initialized
INFO - 2020-02-27 17:54:02 --> Helper loaded: form_helper
INFO - 2020-02-27 17:54:02 --> Form Validation Class Initialized
INFO - 2020-02-27 23:54:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-27 23:54:03 --> Final output sent to browser
DEBUG - 2020-02-27 23:54:03 --> Total execution time: 2.8184
INFO - 2020-02-27 17:54:07 --> Config Class Initialized
INFO - 2020-02-27 17:54:08 --> Hooks Class Initialized
DEBUG - 2020-02-27 17:54:08 --> UTF-8 Support Enabled
INFO - 2020-02-27 17:54:08 --> Utf8 Class Initialized
INFO - 2020-02-27 17:54:08 --> URI Class Initialized
INFO - 2020-02-27 17:54:08 --> Router Class Initialized
INFO - 2020-02-27 17:54:09 --> Output Class Initialized
INFO - 2020-02-27 17:54:09 --> Security Class Initialized
DEBUG - 2020-02-27 17:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 17:54:09 --> Input Class Initialized
INFO - 2020-02-27 17:54:09 --> Language Class Initialized
INFO - 2020-02-27 17:54:09 --> Loader Class Initialized
INFO - 2020-02-27 17:54:09 --> Helper loaded: url_helper
INFO - 2020-02-27 17:54:09 --> Helper loaded: string_helper
INFO - 2020-02-27 17:54:10 --> Database Driver Class Initialized
DEBUG - 2020-02-27 17:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 17:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 17:54:10 --> Controller Class Initialized
INFO - 2020-02-27 17:54:10 --> Model "M_tiket" initialized
INFO - 2020-02-27 17:54:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 17:54:10 --> Model "M_pesan" initialized
INFO - 2020-02-27 17:54:10 --> Helper loaded: form_helper
INFO - 2020-02-27 17:54:11 --> Form Validation Class Initialized
ERROR - 2020-02-27 17:54:11 --> Severity: Notice --> Undefined variable: tanggalp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 17:54:11 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 17:54:11 --> Final output sent to browser
DEBUG - 2020-02-27 17:54:11 --> Total execution time: 3.5903
INFO - 2020-02-27 18:01:23 --> Config Class Initialized
INFO - 2020-02-27 18:01:23 --> Hooks Class Initialized
DEBUG - 2020-02-27 18:01:23 --> UTF-8 Support Enabled
INFO - 2020-02-27 18:01:24 --> Utf8 Class Initialized
INFO - 2020-02-27 18:01:24 --> URI Class Initialized
INFO - 2020-02-27 18:01:24 --> Router Class Initialized
INFO - 2020-02-27 18:01:24 --> Output Class Initialized
INFO - 2020-02-27 18:01:24 --> Security Class Initialized
DEBUG - 2020-02-27 18:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 18:01:24 --> Input Class Initialized
INFO - 2020-02-27 18:01:24 --> Language Class Initialized
INFO - 2020-02-27 18:01:24 --> Loader Class Initialized
INFO - 2020-02-27 18:01:24 --> Helper loaded: url_helper
INFO - 2020-02-27 18:01:24 --> Helper loaded: string_helper
INFO - 2020-02-27 18:01:24 --> Database Driver Class Initialized
DEBUG - 2020-02-27 18:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 18:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 18:01:25 --> Controller Class Initialized
INFO - 2020-02-27 18:01:25 --> Model "M_tiket" initialized
INFO - 2020-02-27 18:01:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 18:01:25 --> Model "M_pesan" initialized
INFO - 2020-02-27 18:01:25 --> Helper loaded: form_helper
INFO - 2020-02-27 18:01:25 --> Form Validation Class Initialized
INFO - 2020-02-27 18:01:25 --> Upload Class Initialized
INFO - 2020-02-27 18:01:25 --> Language file loaded: language/english/upload_lang.php
INFO - 2020-02-27 18:01:25 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
INFO - 2020-02-27 18:01:26 --> Config Class Initialized
INFO - 2020-02-27 18:01:26 --> Hooks Class Initialized
DEBUG - 2020-02-27 18:01:26 --> UTF-8 Support Enabled
INFO - 2020-02-27 18:01:26 --> Utf8 Class Initialized
INFO - 2020-02-27 18:01:26 --> URI Class Initialized
INFO - 2020-02-27 18:01:26 --> Router Class Initialized
INFO - 2020-02-27 18:01:26 --> Output Class Initialized
INFO - 2020-02-27 18:01:26 --> Security Class Initialized
DEBUG - 2020-02-27 18:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 18:01:27 --> Input Class Initialized
INFO - 2020-02-27 18:01:27 --> Language Class Initialized
INFO - 2020-02-27 18:01:27 --> Loader Class Initialized
INFO - 2020-02-27 18:01:27 --> Helper loaded: url_helper
INFO - 2020-02-27 18:01:27 --> Helper loaded: string_helper
INFO - 2020-02-27 18:01:27 --> Database Driver Class Initialized
DEBUG - 2020-02-27 18:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 18:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 18:01:27 --> Controller Class Initialized
INFO - 2020-02-27 18:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 18:01:27 --> Pagination Class Initialized
INFO - 2020-02-27 18:01:27 --> Model "M_show" initialized
INFO - 2020-02-27 18:01:27 --> Helper loaded: form_helper
INFO - 2020-02-27 18:01:27 --> Form Validation Class Initialized
INFO - 2020-02-27 18:01:27 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 18:01:27 --> Final output sent to browser
DEBUG - 2020-02-27 18:01:28 --> Total execution time: 1.6481
INFO - 2020-02-27 18:01:28 --> Config Class Initialized
INFO - 2020-02-27 18:01:28 --> Config Class Initialized
INFO - 2020-02-27 18:01:28 --> Hooks Class Initialized
INFO - 2020-02-27 18:01:28 --> Hooks Class Initialized
DEBUG - 2020-02-27 18:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 18:01:28 --> UTF-8 Support Enabled
INFO - 2020-02-27 18:01:28 --> Utf8 Class Initialized
INFO - 2020-02-27 18:01:28 --> Utf8 Class Initialized
INFO - 2020-02-27 18:01:28 --> URI Class Initialized
INFO - 2020-02-27 18:01:28 --> URI Class Initialized
INFO - 2020-02-27 18:01:28 --> Router Class Initialized
INFO - 2020-02-27 18:01:28 --> Router Class Initialized
INFO - 2020-02-27 18:01:28 --> Output Class Initialized
INFO - 2020-02-27 18:01:28 --> Output Class Initialized
INFO - 2020-02-27 18:01:28 --> Security Class Initialized
INFO - 2020-02-27 18:01:28 --> Security Class Initialized
DEBUG - 2020-02-27 18:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 18:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 18:01:29 --> Input Class Initialized
INFO - 2020-02-27 18:01:29 --> Input Class Initialized
INFO - 2020-02-27 18:01:29 --> Language Class Initialized
INFO - 2020-02-27 18:01:29 --> Language Class Initialized
ERROR - 2020-02-27 18:01:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 18:01:29 --> 404 Page Not Found: Assets/js
INFO - 2020-02-27 18:02:13 --> Config Class Initialized
INFO - 2020-02-27 18:02:13 --> Hooks Class Initialized
DEBUG - 2020-02-27 18:02:13 --> UTF-8 Support Enabled
INFO - 2020-02-27 18:02:14 --> Utf8 Class Initialized
INFO - 2020-02-27 18:02:14 --> URI Class Initialized
INFO - 2020-02-27 18:02:14 --> Router Class Initialized
INFO - 2020-02-27 18:02:14 --> Output Class Initialized
INFO - 2020-02-27 18:02:14 --> Security Class Initialized
DEBUG - 2020-02-27 18:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 18:02:14 --> Input Class Initialized
INFO - 2020-02-27 18:02:14 --> Language Class Initialized
INFO - 2020-02-27 18:02:14 --> Loader Class Initialized
INFO - 2020-02-27 18:02:14 --> Helper loaded: url_helper
INFO - 2020-02-27 18:02:15 --> Helper loaded: string_helper
INFO - 2020-02-27 18:02:15 --> Database Driver Class Initialized
DEBUG - 2020-02-27 18:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 18:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 18:02:15 --> Controller Class Initialized
INFO - 2020-02-27 18:02:15 --> Model "M_tiket" initialized
INFO - 2020-02-27 18:02:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 18:02:15 --> Model "M_pesan" initialized
INFO - 2020-02-27 18:02:15 --> Helper loaded: form_helper
INFO - 2020-02-27 18:02:15 --> Form Validation Class Initialized
INFO - 2020-02-27 18:02:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 18:02:16 --> Final output sent to browser
INFO - 2020-02-27 18:02:16 --> Config Class Initialized
INFO - 2020-02-27 18:02:16 --> Hooks Class Initialized
DEBUG - 2020-02-27 18:02:16 --> Total execution time: 2.9356
DEBUG - 2020-02-27 18:02:16 --> UTF-8 Support Enabled
INFO - 2020-02-27 18:02:16 --> Config Class Initialized
INFO - 2020-02-27 18:02:16 --> Config Class Initialized
INFO - 2020-02-27 18:02:16 --> Hooks Class Initialized
INFO - 2020-02-27 18:02:16 --> Utf8 Class Initialized
INFO - 2020-02-27 18:02:16 --> Hooks Class Initialized
INFO - 2020-02-27 18:02:16 --> URI Class Initialized
DEBUG - 2020-02-27 18:02:16 --> UTF-8 Support Enabled
DEBUG - 2020-02-27 18:02:16 --> UTF-8 Support Enabled
INFO - 2020-02-27 18:02:16 --> Utf8 Class Initialized
INFO - 2020-02-27 18:02:16 --> Utf8 Class Initialized
INFO - 2020-02-27 18:02:16 --> Router Class Initialized
INFO - 2020-02-27 18:02:16 --> URI Class Initialized
INFO - 2020-02-27 18:02:16 --> Output Class Initialized
INFO - 2020-02-27 18:02:16 --> URI Class Initialized
INFO - 2020-02-27 18:02:16 --> Router Class Initialized
INFO - 2020-02-27 18:02:16 --> Router Class Initialized
INFO - 2020-02-27 18:02:16 --> Security Class Initialized
DEBUG - 2020-02-27 18:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 18:02:16 --> Output Class Initialized
INFO - 2020-02-27 18:02:16 --> Output Class Initialized
INFO - 2020-02-27 18:02:16 --> Input Class Initialized
INFO - 2020-02-27 18:02:16 --> Security Class Initialized
INFO - 2020-02-27 18:02:16 --> Security Class Initialized
DEBUG - 2020-02-27 18:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-27 18:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 18:02:17 --> Language Class Initialized
INFO - 2020-02-27 18:02:17 --> Input Class Initialized
INFO - 2020-02-27 18:02:17 --> Input Class Initialized
ERROR - 2020-02-27 18:02:17 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-27 18:02:17 --> Language Class Initialized
INFO - 2020-02-27 18:02:17 --> Language Class Initialized
INFO - 2020-02-27 18:02:17 --> Loader Class Initialized
INFO - 2020-02-27 18:02:17 --> Loader Class Initialized
INFO - 2020-02-27 18:02:17 --> Helper loaded: url_helper
INFO - 2020-02-27 18:02:17 --> Helper loaded: url_helper
INFO - 2020-02-27 18:02:17 --> Helper loaded: string_helper
INFO - 2020-02-27 18:02:17 --> Helper loaded: string_helper
INFO - 2020-02-27 18:02:17 --> Database Driver Class Initialized
INFO - 2020-02-27 18:02:17 --> Database Driver Class Initialized
DEBUG - 2020-02-27 18:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-27 18:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 18:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 18:02:17 --> Controller Class Initialized
INFO - 2020-02-27 18:02:17 --> Model "M_tiket" initialized
INFO - 2020-02-27 18:02:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 18:02:17 --> Model "M_pesan" initialized
INFO - 2020-02-27 18:02:17 --> Helper loaded: form_helper
INFO - 2020-02-27 18:02:17 --> Form Validation Class Initialized
ERROR - 2020-02-27 18:02:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 18:02:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 18:02:18 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 18:02:18 --> Final output sent to browser
DEBUG - 2020-02-27 18:02:18 --> Total execution time: 1.7283
INFO - 2020-02-27 18:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 18:02:18 --> Controller Class Initialized
INFO - 2020-02-27 18:02:18 --> Model "M_tiket" initialized
INFO - 2020-02-27 18:02:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 18:02:18 --> Model "M_pesan" initialized
INFO - 2020-02-27 18:02:18 --> Helper loaded: form_helper
INFO - 2020-02-27 18:02:18 --> Form Validation Class Initialized
ERROR - 2020-02-27 18:02:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-27 18:02:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-27 18:02:18 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-27 18:02:18 --> Final output sent to browser
DEBUG - 2020-02-27 18:02:18 --> Total execution time: 2.3837
INFO - 2020-02-27 18:02:21 --> Config Class Initialized
INFO - 2020-02-27 18:02:21 --> Hooks Class Initialized
DEBUG - 2020-02-27 18:02:21 --> UTF-8 Support Enabled
INFO - 2020-02-27 18:02:21 --> Utf8 Class Initialized
INFO - 2020-02-27 18:02:21 --> URI Class Initialized
INFO - 2020-02-27 18:02:21 --> Router Class Initialized
INFO - 2020-02-27 18:02:21 --> Output Class Initialized
INFO - 2020-02-27 18:02:21 --> Security Class Initialized
DEBUG - 2020-02-27 18:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 18:02:21 --> Input Class Initialized
INFO - 2020-02-27 18:02:21 --> Language Class Initialized
INFO - 2020-02-27 18:02:21 --> Loader Class Initialized
INFO - 2020-02-27 18:02:21 --> Helper loaded: url_helper
INFO - 2020-02-27 18:02:21 --> Helper loaded: string_helper
INFO - 2020-02-27 18:02:21 --> Database Driver Class Initialized
DEBUG - 2020-02-27 18:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 18:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 18:02:22 --> Controller Class Initialized
INFO - 2020-02-27 18:02:22 --> Model "M_tiket" initialized
INFO - 2020-02-27 18:02:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 18:02:22 --> Model "M_pesan" initialized
INFO - 2020-02-27 18:02:22 --> Helper loaded: form_helper
INFO - 2020-02-27 18:02:22 --> Form Validation Class Initialized
INFO - 2020-02-27 18:03:13 --> Config Class Initialized
INFO - 2020-02-27 18:03:14 --> Hooks Class Initialized
DEBUG - 2020-02-27 18:03:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 18:03:14 --> Utf8 Class Initialized
INFO - 2020-02-27 18:03:14 --> URI Class Initialized
INFO - 2020-02-27 18:03:14 --> Router Class Initialized
INFO - 2020-02-27 18:03:15 --> Output Class Initialized
INFO - 2020-02-27 18:03:15 --> Security Class Initialized
DEBUG - 2020-02-27 18:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 18:03:15 --> Input Class Initialized
INFO - 2020-02-27 18:03:15 --> Language Class Initialized
INFO - 2020-02-27 18:03:15 --> Loader Class Initialized
INFO - 2020-02-27 18:03:15 --> Helper loaded: url_helper
INFO - 2020-02-27 18:03:15 --> Helper loaded: string_helper
INFO - 2020-02-27 18:03:15 --> Database Driver Class Initialized
DEBUG - 2020-02-27 18:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 18:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 18:03:15 --> Controller Class Initialized
INFO - 2020-02-27 18:03:15 --> Model "M_tiket" initialized
INFO - 2020-02-27 18:03:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 18:03:15 --> Model "M_pesan" initialized
INFO - 2020-02-27 18:03:15 --> Helper loaded: form_helper
INFO - 2020-02-27 18:03:15 --> Form Validation Class Initialized
ERROR - 2020-02-27 18:03:15 --> Severity: Notice --> Undefined variable: tanggalp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-27 18:03:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-27 18:03:15 --> Final output sent to browser
DEBUG - 2020-02-27 18:03:15 --> Total execution time: 2.0827
INFO - 2020-02-27 18:04:11 --> Config Class Initialized
INFO - 2020-02-27 18:04:12 --> Hooks Class Initialized
DEBUG - 2020-02-27 18:04:12 --> UTF-8 Support Enabled
INFO - 2020-02-27 18:04:12 --> Utf8 Class Initialized
INFO - 2020-02-27 18:04:12 --> URI Class Initialized
INFO - 2020-02-27 18:04:12 --> Router Class Initialized
INFO - 2020-02-27 18:04:12 --> Output Class Initialized
INFO - 2020-02-27 18:04:12 --> Security Class Initialized
DEBUG - 2020-02-27 18:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 18:04:13 --> Input Class Initialized
INFO - 2020-02-27 18:04:13 --> Language Class Initialized
INFO - 2020-02-27 18:04:13 --> Loader Class Initialized
INFO - 2020-02-27 18:04:13 --> Helper loaded: url_helper
INFO - 2020-02-27 18:04:13 --> Helper loaded: string_helper
INFO - 2020-02-27 18:04:13 --> Database Driver Class Initialized
DEBUG - 2020-02-27 18:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 18:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 18:04:13 --> Controller Class Initialized
INFO - 2020-02-27 18:04:13 --> Model "M_tiket" initialized
INFO - 2020-02-27 18:04:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-27 18:04:13 --> Model "M_pesan" initialized
INFO - 2020-02-27 18:04:13 --> Helper loaded: form_helper
INFO - 2020-02-27 18:04:13 --> Form Validation Class Initialized
INFO - 2020-02-27 18:04:13 --> Upload Class Initialized
INFO - 2020-02-27 18:04:14 --> Config Class Initialized
INFO - 2020-02-27 18:04:14 --> Hooks Class Initialized
DEBUG - 2020-02-27 18:04:14 --> UTF-8 Support Enabled
INFO - 2020-02-27 18:04:14 --> Utf8 Class Initialized
INFO - 2020-02-27 18:04:14 --> URI Class Initialized
INFO - 2020-02-27 18:04:14 --> Router Class Initialized
INFO - 2020-02-27 18:04:14 --> Output Class Initialized
INFO - 2020-02-27 18:04:14 --> Security Class Initialized
DEBUG - 2020-02-27 18:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 18:04:14 --> Input Class Initialized
INFO - 2020-02-27 18:04:14 --> Language Class Initialized
INFO - 2020-02-27 18:04:14 --> Loader Class Initialized
INFO - 2020-02-27 18:04:14 --> Helper loaded: url_helper
INFO - 2020-02-27 18:04:14 --> Helper loaded: string_helper
INFO - 2020-02-27 18:04:14 --> Database Driver Class Initialized
DEBUG - 2020-02-27 18:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-27 18:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-27 18:04:15 --> Controller Class Initialized
INFO - 2020-02-27 18:04:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-27 18:04:15 --> Pagination Class Initialized
INFO - 2020-02-27 18:04:15 --> Model "M_show" initialized
INFO - 2020-02-27 18:04:15 --> Helper loaded: form_helper
INFO - 2020-02-27 18:04:15 --> Form Validation Class Initialized
INFO - 2020-02-27 18:04:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-27 18:04:15 --> Final output sent to browser
DEBUG - 2020-02-27 18:04:15 --> Total execution time: 1.3543
INFO - 2020-02-27 18:04:15 --> Config Class Initialized
INFO - 2020-02-27 18:04:15 --> Config Class Initialized
INFO - 2020-02-27 18:04:15 --> Hooks Class Initialized
INFO - 2020-02-27 18:04:15 --> Hooks Class Initialized
DEBUG - 2020-02-27 18:04:15 --> UTF-8 Support Enabled
INFO - 2020-02-27 18:04:15 --> Utf8 Class Initialized
DEBUG - 2020-02-27 18:04:15 --> UTF-8 Support Enabled
INFO - 2020-02-27 18:04:16 --> Utf8 Class Initialized
INFO - 2020-02-27 18:04:16 --> URI Class Initialized
INFO - 2020-02-27 18:04:16 --> Router Class Initialized
INFO - 2020-02-27 18:04:16 --> URI Class Initialized
INFO - 2020-02-27 18:04:16 --> Router Class Initialized
INFO - 2020-02-27 18:04:16 --> Output Class Initialized
INFO - 2020-02-27 18:04:16 --> Security Class Initialized
INFO - 2020-02-27 18:04:16 --> Output Class Initialized
DEBUG - 2020-02-27 18:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 18:04:16 --> Security Class Initialized
INFO - 2020-02-27 18:04:16 --> Input Class Initialized
DEBUG - 2020-02-27 18:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-27 18:04:16 --> Input Class Initialized
INFO - 2020-02-27 18:04:16 --> Language Class Initialized
INFO - 2020-02-27 18:04:16 --> Language Class Initialized
ERROR - 2020-02-27 18:04:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-27 18:04:16 --> 404 Page Not Found: Assets/js
