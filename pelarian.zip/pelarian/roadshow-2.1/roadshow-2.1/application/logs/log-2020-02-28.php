<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-28 00:02:22 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-28 00:02:22 --> Final output sent to browser
DEBUG - 2020-02-28 00:02:22 --> Total execution time: 1.4611
INFO - 2020-02-28 10:06:28 --> Config Class Initialized
INFO - 2020-02-28 10:06:28 --> Hooks Class Initialized
DEBUG - 2020-02-28 10:06:28 --> UTF-8 Support Enabled
INFO - 2020-02-28 10:06:28 --> Utf8 Class Initialized
INFO - 2020-02-28 10:06:28 --> URI Class Initialized
INFO - 2020-02-28 10:06:28 --> Router Class Initialized
INFO - 2020-02-28 10:06:28 --> Output Class Initialized
INFO - 2020-02-28 10:06:28 --> Security Class Initialized
DEBUG - 2020-02-28 10:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-28 10:06:28 --> Input Class Initialized
INFO - 2020-02-28 10:06:28 --> Language Class Initialized
INFO - 2020-02-28 10:06:28 --> Loader Class Initialized
INFO - 2020-02-28 10:06:28 --> Helper loaded: url_helper
INFO - 2020-02-28 10:06:28 --> Helper loaded: string_helper
INFO - 2020-02-28 10:06:29 --> Database Driver Class Initialized
DEBUG - 2020-02-28 10:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-28 10:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-28 10:06:29 --> Controller Class Initialized
INFO - 2020-02-28 10:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-28 10:06:29 --> Pagination Class Initialized
INFO - 2020-02-28 10:06:29 --> Model "M_show" initialized
INFO - 2020-02-28 10:06:29 --> Helper loaded: form_helper
INFO - 2020-02-28 10:06:29 --> Form Validation Class Initialized
INFO - 2020-02-28 10:06:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-28 10:06:30 --> Final output sent to browser
DEBUG - 2020-02-28 10:06:30 --> Total execution time: 2.0045
INFO - 2020-02-28 10:06:30 --> Config Class Initialized
INFO - 2020-02-28 10:06:30 --> Config Class Initialized
INFO - 2020-02-28 10:06:30 --> Hooks Class Initialized
DEBUG - 2020-02-28 10:06:30 --> UTF-8 Support Enabled
INFO - 2020-02-28 10:06:30 --> Utf8 Class Initialized
INFO - 2020-02-28 10:06:31 --> URI Class Initialized
INFO - 2020-02-28 10:06:31 --> Router Class Initialized
INFO - 2020-02-28 10:06:31 --> Output Class Initialized
INFO - 2020-02-28 10:06:31 --> Security Class Initialized
INFO - 2020-02-28 10:06:31 --> Hooks Class Initialized
DEBUG - 2020-02-28 10:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-28 10:06:31 --> Input Class Initialized
DEBUG - 2020-02-28 10:06:31 --> UTF-8 Support Enabled
INFO - 2020-02-28 10:06:31 --> Utf8 Class Initialized
INFO - 2020-02-28 10:06:31 --> Language Class Initialized
INFO - 2020-02-28 10:06:31 --> URI Class Initialized
INFO - 2020-02-28 10:06:31 --> Router Class Initialized
ERROR - 2020-02-28 10:06:31 --> 404 Page Not Found: Assets/js
INFO - 2020-02-28 10:06:31 --> Output Class Initialized
INFO - 2020-02-28 10:06:31 --> Security Class Initialized
DEBUG - 2020-02-28 10:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-28 10:06:31 --> Input Class Initialized
INFO - 2020-02-28 10:06:31 --> Language Class Initialized
ERROR - 2020-02-28 10:06:31 --> 404 Page Not Found: Assets/js
INFO - 2020-02-28 11:10:35 --> Config Class Initialized
INFO - 2020-02-28 11:10:35 --> Hooks Class Initialized
DEBUG - 2020-02-28 11:10:35 --> UTF-8 Support Enabled
INFO - 2020-02-28 11:10:35 --> Utf8 Class Initialized
INFO - 2020-02-28 11:10:35 --> URI Class Initialized
INFO - 2020-02-28 11:10:35 --> Router Class Initialized
INFO - 2020-02-28 11:10:35 --> Output Class Initialized
INFO - 2020-02-28 11:10:35 --> Security Class Initialized
DEBUG - 2020-02-28 11:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-28 11:10:35 --> Input Class Initialized
INFO - 2020-02-28 11:10:35 --> Language Class Initialized
INFO - 2020-02-28 11:10:35 --> Loader Class Initialized
INFO - 2020-02-28 11:10:35 --> Helper loaded: url_helper
INFO - 2020-02-28 11:10:35 --> Helper loaded: string_helper
INFO - 2020-02-28 11:10:36 --> Database Driver Class Initialized
DEBUG - 2020-02-28 11:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-28 11:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-28 11:10:36 --> Controller Class Initialized
INFO - 2020-02-28 11:10:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-28 11:10:36 --> Pagination Class Initialized
INFO - 2020-02-28 11:10:36 --> Model "M_show" initialized
INFO - 2020-02-28 11:10:36 --> Helper loaded: form_helper
INFO - 2020-02-28 11:10:36 --> Form Validation Class Initialized
INFO - 2020-02-28 11:10:36 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-28 11:10:36 --> Final output sent to browser
DEBUG - 2020-02-28 11:10:36 --> Total execution time: 1.0846
INFO - 2020-02-28 11:10:36 --> Config Class Initialized
INFO - 2020-02-28 11:10:36 --> Config Class Initialized
INFO - 2020-02-28 11:10:36 --> Hooks Class Initialized
INFO - 2020-02-28 11:10:36 --> Hooks Class Initialized
DEBUG - 2020-02-28 11:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-28 11:10:36 --> UTF-8 Support Enabled
INFO - 2020-02-28 11:10:36 --> Utf8 Class Initialized
INFO - 2020-02-28 11:10:36 --> Utf8 Class Initialized
INFO - 2020-02-28 11:10:36 --> URI Class Initialized
INFO - 2020-02-28 11:10:36 --> URI Class Initialized
INFO - 2020-02-28 11:10:36 --> Router Class Initialized
INFO - 2020-02-28 11:10:36 --> Router Class Initialized
INFO - 2020-02-28 11:10:36 --> Output Class Initialized
INFO - 2020-02-28 11:10:36 --> Output Class Initialized
INFO - 2020-02-28 11:10:36 --> Security Class Initialized
INFO - 2020-02-28 11:10:36 --> Security Class Initialized
DEBUG - 2020-02-28 11:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-28 11:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-28 11:10:36 --> Input Class Initialized
INFO - 2020-02-28 11:10:36 --> Input Class Initialized
INFO - 2020-02-28 11:10:36 --> Language Class Initialized
INFO - 2020-02-28 11:10:36 --> Language Class Initialized
ERROR - 2020-02-28 11:10:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-28 11:10:36 --> 404 Page Not Found: Assets/js
INFO - 2020-02-28 11:10:37 --> Config Class Initialized
INFO - 2020-02-28 11:10:37 --> Hooks Class Initialized
DEBUG - 2020-02-28 11:10:37 --> UTF-8 Support Enabled
INFO - 2020-02-28 11:10:37 --> Utf8 Class Initialized
INFO - 2020-02-28 11:10:37 --> URI Class Initialized
INFO - 2020-02-28 11:10:37 --> Router Class Initialized
INFO - 2020-02-28 11:10:37 --> Output Class Initialized
INFO - 2020-02-28 11:10:37 --> Security Class Initialized
DEBUG - 2020-02-28 11:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-28 11:10:37 --> Input Class Initialized
INFO - 2020-02-28 11:10:37 --> Language Class Initialized
ERROR - 2020-02-28 11:10:37 --> 404 Page Not Found: Assets/js
INFO - 2020-02-28 11:10:37 --> Config Class Initialized
INFO - 2020-02-28 11:10:37 --> Hooks Class Initialized
DEBUG - 2020-02-28 11:10:37 --> UTF-8 Support Enabled
INFO - 2020-02-28 11:10:37 --> Utf8 Class Initialized
INFO - 2020-02-28 11:10:37 --> URI Class Initialized
INFO - 2020-02-28 11:10:37 --> Router Class Initialized
INFO - 2020-02-28 11:10:37 --> Output Class Initialized
INFO - 2020-02-28 11:10:37 --> Security Class Initialized
DEBUG - 2020-02-28 11:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-28 11:10:37 --> Input Class Initialized
INFO - 2020-02-28 11:10:37 --> Language Class Initialized
ERROR - 2020-02-28 11:10:37 --> 404 Page Not Found: Assets/js
INFO - 2020-02-28 11:24:12 --> Config Class Initialized
INFO - 2020-02-28 11:24:12 --> Hooks Class Initialized
DEBUG - 2020-02-28 11:24:12 --> UTF-8 Support Enabled
INFO - 2020-02-28 11:24:12 --> Utf8 Class Initialized
INFO - 2020-02-28 11:24:12 --> URI Class Initialized
INFO - 2020-02-28 11:24:12 --> Router Class Initialized
INFO - 2020-02-28 11:24:12 --> Output Class Initialized
INFO - 2020-02-28 11:24:12 --> Security Class Initialized
DEBUG - 2020-02-28 11:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-28 11:24:12 --> Input Class Initialized
INFO - 2020-02-28 11:24:12 --> Language Class Initialized
INFO - 2020-02-28 11:24:12 --> Loader Class Initialized
INFO - 2020-02-28 11:24:12 --> Helper loaded: url_helper
INFO - 2020-02-28 11:24:12 --> Helper loaded: string_helper
INFO - 2020-02-28 11:24:13 --> Database Driver Class Initialized
DEBUG - 2020-02-28 11:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-28 11:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-28 11:24:13 --> Controller Class Initialized
INFO - 2020-02-28 11:24:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-28 11:24:13 --> Pagination Class Initialized
INFO - 2020-02-28 11:24:13 --> Model "M_show" initialized
INFO - 2020-02-28 11:24:13 --> Helper loaded: form_helper
INFO - 2020-02-28 11:24:13 --> Form Validation Class Initialized
INFO - 2020-02-28 11:24:13 --> Config Class Initialized
INFO - 2020-02-28 11:24:13 --> Hooks Class Initialized
DEBUG - 2020-02-28 11:24:13 --> UTF-8 Support Enabled
INFO - 2020-02-28 11:24:13 --> Utf8 Class Initialized
INFO - 2020-02-28 11:24:13 --> URI Class Initialized
INFO - 2020-02-28 11:24:13 --> Router Class Initialized
INFO - 2020-02-28 11:24:13 --> Output Class Initialized
INFO - 2020-02-28 11:24:13 --> Security Class Initialized
DEBUG - 2020-02-28 11:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-28 11:24:13 --> Input Class Initialized
INFO - 2020-02-28 11:24:13 --> Language Class Initialized
ERROR - 2020-02-28 11:24:13 --> 404 Page Not Found: Show/show_list
INFO - 2020-02-28 11:25:08 --> Config Class Initialized
INFO - 2020-02-28 11:25:08 --> Hooks Class Initialized
DEBUG - 2020-02-28 11:25:08 --> UTF-8 Support Enabled
INFO - 2020-02-28 11:25:08 --> Utf8 Class Initialized
INFO - 2020-02-28 11:25:08 --> URI Class Initialized
INFO - 2020-02-28 11:25:08 --> Router Class Initialized
INFO - 2020-02-28 11:25:08 --> Output Class Initialized
INFO - 2020-02-28 11:25:09 --> Security Class Initialized
DEBUG - 2020-02-28 11:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-28 11:25:09 --> Input Class Initialized
INFO - 2020-02-28 11:25:09 --> Language Class Initialized
INFO - 2020-02-28 11:25:09 --> Loader Class Initialized
INFO - 2020-02-28 11:25:09 --> Helper loaded: url_helper
INFO - 2020-02-28 11:25:09 --> Helper loaded: string_helper
INFO - 2020-02-28 11:25:09 --> Database Driver Class Initialized
DEBUG - 2020-02-28 11:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-28 11:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-28 11:25:09 --> Controller Class Initialized
INFO - 2020-02-28 11:25:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-28 11:25:09 --> Pagination Class Initialized
INFO - 2020-02-28 11:25:09 --> Model "M_show" initialized
INFO - 2020-02-28 11:25:09 --> Helper loaded: form_helper
INFO - 2020-02-28 11:25:09 --> Form Validation Class Initialized
INFO - 2020-02-28 11:25:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\component/menu.php
INFO - 2020-02-28 11:25:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/tambah_show.php
INFO - 2020-02-28 11:25:09 --> Final output sent to browser
DEBUG - 2020-02-28 11:25:09 --> Total execution time: 0.4104
