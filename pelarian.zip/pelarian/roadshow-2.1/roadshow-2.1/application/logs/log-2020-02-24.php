<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-24 17:15:44 --> Config Class Initialized
INFO - 2020-02-24 17:15:44 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:15:44 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:15:44 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:44 --> URI Class Initialized
DEBUG - 2020-02-24 17:15:44 --> No URI present. Default controller set.
INFO - 2020-02-24 17:15:44 --> Router Class Initialized
INFO - 2020-02-24 17:15:44 --> Output Class Initialized
INFO - 2020-02-24 17:15:44 --> Security Class Initialized
DEBUG - 2020-02-24 17:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:44 --> Input Class Initialized
INFO - 2020-02-24 17:15:44 --> Language Class Initialized
INFO - 2020-02-24 17:15:44 --> Loader Class Initialized
INFO - 2020-02-24 17:15:44 --> Helper loaded: url_helper
INFO - 2020-02-24 17:15:44 --> Helper loaded: string_helper
INFO - 2020-02-24 17:15:45 --> Database Driver Class Initialized
DEBUG - 2020-02-24 17:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 17:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 17:15:45 --> Controller Class Initialized
INFO - 2020-02-24 17:15:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:15:45 --> Pagination Class Initialized
INFO - 2020-02-24 17:15:45 --> Model "M_show" initialized
INFO - 2020-02-24 17:15:46 --> Helper loaded: form_helper
INFO - 2020-02-24 17:15:46 --> Form Validation Class Initialized
INFO - 2020-02-24 17:15:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-24 17:15:46 --> Final output sent to browser
DEBUG - 2020-02-24 17:15:46 --> Total execution time: 2.7018
INFO - 2020-02-24 17:15:49 --> Config Class Initialized
INFO - 2020-02-24 17:15:49 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:15:49 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:15:49 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:49 --> URI Class Initialized
INFO - 2020-02-24 17:15:49 --> Router Class Initialized
INFO - 2020-02-24 17:15:49 --> Output Class Initialized
INFO - 2020-02-24 17:15:49 --> Security Class Initialized
DEBUG - 2020-02-24 17:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:49 --> Input Class Initialized
INFO - 2020-02-24 17:15:49 --> Language Class Initialized
INFO - 2020-02-24 17:15:49 --> Loader Class Initialized
INFO - 2020-02-24 17:15:49 --> Helper loaded: url_helper
INFO - 2020-02-24 17:15:49 --> Helper loaded: string_helper
INFO - 2020-02-24 17:15:49 --> Database Driver Class Initialized
DEBUG - 2020-02-24 17:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 17:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 17:15:49 --> Controller Class Initialized
INFO - 2020-02-24 17:15:49 --> Model "M_tiket" initialized
INFO - 2020-02-24 17:15:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 17:15:49 --> Model "M_pesan" initialized
INFO - 2020-02-24 17:15:49 --> Helper loaded: form_helper
INFO - 2020-02-24 17:15:49 --> Form Validation Class Initialized
INFO - 2020-02-24 17:15:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-24 17:15:49 --> Final output sent to browser
DEBUG - 2020-02-24 17:15:50 --> Total execution time: 0.8235
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-24 17:15:50 --> Loader Class Initialized
INFO - 2020-02-24 17:15:50 --> Helper loaded: url_helper
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Helper loaded: string_helper
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:15:50 --> Database Driver Class Initialized
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
DEBUG - 2020-02-24 17:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 17:15:50 --> Controller Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Model "M_tiket" initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
INFO - 2020-02-24 17:15:50 --> Model "M_pesan" initialized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Helper loaded: form_helper
INFO - 2020-02-24 17:15:50 --> Form Validation Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-24 17:15:50 --> Loader Class Initialized
ERROR - 2020-02-24 17:15:50 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-24 17:15:50 --> Helper loaded: url_helper
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Helper loaded: string_helper
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Database Driver Class Initialized
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
DEBUG - 2020-02-24 17:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
ERROR - 2020-02-24 17:15:50 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-24 17:15:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Final output sent to browser
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
DEBUG - 2020-02-24 17:15:50 --> Total execution time: 0.3022
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
INFO - 2020-02-24 17:15:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:50 --> Controller Class Initialized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
INFO - 2020-02-24 17:15:50 --> Model "M_tiket" initialized
INFO - 2020-02-24 17:15:50 --> Model "M_pengunjung" initialized
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-24 17:15:50 --> Model "M_pesan" initialized
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Helper loaded: form_helper
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
INFO - 2020-02-24 17:15:50 --> Form Validation Class Initialized
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
ERROR - 2020-02-24 17:15:50 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
ERROR - 2020-02-24 17:15:50 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-24 17:15:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> Final output sent to browser
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
DEBUG - 2020-02-24 17:15:50 --> Total execution time: 0.2712
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:50 --> Output Class Initialized
INFO - 2020-02-24 17:15:50 --> Security Class Initialized
DEBUG - 2020-02-24 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:50 --> Input Class Initialized
INFO - 2020-02-24 17:15:50 --> Language Class Initialized
ERROR - 2020-02-24 17:15:50 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-24 17:15:50 --> Config Class Initialized
INFO - 2020-02-24 17:15:50 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:15:50 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:15:50 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:50 --> URI Class Initialized
INFO - 2020-02-24 17:15:50 --> Router Class Initialized
INFO - 2020-02-24 17:15:51 --> Output Class Initialized
INFO - 2020-02-24 17:15:51 --> Security Class Initialized
DEBUG - 2020-02-24 17:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:51 --> Input Class Initialized
INFO - 2020-02-24 17:15:51 --> Language Class Initialized
ERROR - 2020-02-24 17:15:51 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-24 17:15:51 --> Config Class Initialized
INFO - 2020-02-24 17:15:51 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:15:51 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:15:51 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:51 --> URI Class Initialized
INFO - 2020-02-24 17:15:51 --> Router Class Initialized
INFO - 2020-02-24 17:15:51 --> Output Class Initialized
INFO - 2020-02-24 17:15:51 --> Security Class Initialized
DEBUG - 2020-02-24 17:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:51 --> Input Class Initialized
INFO - 2020-02-24 17:15:51 --> Language Class Initialized
ERROR - 2020-02-24 17:15:51 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-24 17:15:51 --> Config Class Initialized
INFO - 2020-02-24 17:15:51 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:15:51 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:15:51 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:51 --> URI Class Initialized
INFO - 2020-02-24 17:15:51 --> Router Class Initialized
INFO - 2020-02-24 17:15:51 --> Output Class Initialized
INFO - 2020-02-24 17:15:51 --> Security Class Initialized
DEBUG - 2020-02-24 17:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:51 --> Input Class Initialized
INFO - 2020-02-24 17:15:51 --> Language Class Initialized
ERROR - 2020-02-24 17:15:51 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-24 17:15:51 --> Config Class Initialized
INFO - 2020-02-24 17:15:51 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:15:51 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:15:51 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:51 --> URI Class Initialized
INFO - 2020-02-24 17:15:51 --> Router Class Initialized
INFO - 2020-02-24 17:15:51 --> Output Class Initialized
INFO - 2020-02-24 17:15:51 --> Security Class Initialized
DEBUG - 2020-02-24 17:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:51 --> Input Class Initialized
INFO - 2020-02-24 17:15:51 --> Language Class Initialized
ERROR - 2020-02-24 17:15:51 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-24 17:15:51 --> Config Class Initialized
INFO - 2020-02-24 17:15:51 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:15:51 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:15:51 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:51 --> URI Class Initialized
INFO - 2020-02-24 17:15:51 --> Router Class Initialized
INFO - 2020-02-24 17:15:51 --> Output Class Initialized
INFO - 2020-02-24 17:15:51 --> Security Class Initialized
DEBUG - 2020-02-24 17:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:51 --> Input Class Initialized
INFO - 2020-02-24 17:15:51 --> Language Class Initialized
ERROR - 2020-02-24 17:15:51 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-24 17:15:51 --> Config Class Initialized
INFO - 2020-02-24 17:15:51 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:15:51 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:15:51 --> Utf8 Class Initialized
INFO - 2020-02-24 17:15:51 --> URI Class Initialized
INFO - 2020-02-24 17:15:51 --> Router Class Initialized
INFO - 2020-02-24 17:15:51 --> Output Class Initialized
INFO - 2020-02-24 17:15:51 --> Security Class Initialized
DEBUG - 2020-02-24 17:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:15:51 --> Input Class Initialized
INFO - 2020-02-24 17:15:51 --> Language Class Initialized
ERROR - 2020-02-24 17:15:51 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-24 17:16:07 --> Config Class Initialized
INFO - 2020-02-24 17:16:07 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:16:07 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:16:07 --> Utf8 Class Initialized
INFO - 2020-02-24 17:16:07 --> URI Class Initialized
INFO - 2020-02-24 17:16:07 --> Router Class Initialized
INFO - 2020-02-24 17:16:07 --> Output Class Initialized
INFO - 2020-02-24 17:16:07 --> Security Class Initialized
DEBUG - 2020-02-24 17:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:16:07 --> Input Class Initialized
INFO - 2020-02-24 17:16:07 --> Language Class Initialized
INFO - 2020-02-24 17:16:07 --> Loader Class Initialized
INFO - 2020-02-24 17:16:07 --> Helper loaded: url_helper
INFO - 2020-02-24 17:16:07 --> Helper loaded: string_helper
INFO - 2020-02-24 17:16:07 --> Database Driver Class Initialized
DEBUG - 2020-02-24 17:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 17:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 17:16:07 --> Controller Class Initialized
INFO - 2020-02-24 17:16:07 --> Model "M_tiket" initialized
INFO - 2020-02-24 17:16:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 17:16:07 --> Model "M_pesan" initialized
INFO - 2020-02-24 17:16:07 --> Helper loaded: form_helper
INFO - 2020-02-24 17:16:07 --> Form Validation Class Initialized
ERROR - 2020-02-24 17:16:07 --> Query error: Column 'tanggal_approve' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `id_pengunjung`) VALUES ('33', '100000', '1', '1', '20-02-24 05:16:07', '2020-02-25 05:16:07', NULL, '129')
INFO - 2020-02-24 17:16:08 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-24 17:17:28 --> Config Class Initialized
INFO - 2020-02-24 17:17:28 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:17:28 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:17:28 --> Utf8 Class Initialized
INFO - 2020-02-24 17:17:28 --> URI Class Initialized
INFO - 2020-02-24 17:17:28 --> Router Class Initialized
INFO - 2020-02-24 17:17:28 --> Output Class Initialized
INFO - 2020-02-24 17:17:28 --> Security Class Initialized
DEBUG - 2020-02-24 17:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:17:28 --> Input Class Initialized
INFO - 2020-02-24 17:17:28 --> Language Class Initialized
INFO - 2020-02-24 17:17:28 --> Loader Class Initialized
INFO - 2020-02-24 17:17:28 --> Helper loaded: url_helper
INFO - 2020-02-24 17:17:28 --> Helper loaded: string_helper
INFO - 2020-02-24 17:17:28 --> Database Driver Class Initialized
DEBUG - 2020-02-24 17:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 17:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 17:17:28 --> Controller Class Initialized
INFO - 2020-02-24 17:17:28 --> Model "M_tiket" initialized
INFO - 2020-02-24 17:17:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 17:17:28 --> Model "M_pesan" initialized
INFO - 2020-02-24 17:17:28 --> Helper loaded: form_helper
INFO - 2020-02-24 17:17:28 --> Form Validation Class Initialized
INFO - 2020-02-24 17:17:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-24 17:17:28 --> Final output sent to browser
DEBUG - 2020-02-24 17:17:28 --> Total execution time: 0.4760
INFO - 2020-02-24 17:59:29 --> Config Class Initialized
INFO - 2020-02-24 17:59:29 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:29 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:29 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:29 --> URI Class Initialized
DEBUG - 2020-02-24 17:59:29 --> No URI present. Default controller set.
INFO - 2020-02-24 17:59:29 --> Router Class Initialized
INFO - 2020-02-24 17:59:29 --> Output Class Initialized
INFO - 2020-02-24 17:59:29 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:29 --> Input Class Initialized
INFO - 2020-02-24 17:59:29 --> Language Class Initialized
INFO - 2020-02-24 17:59:29 --> Loader Class Initialized
INFO - 2020-02-24 17:59:29 --> Helper loaded: url_helper
INFO - 2020-02-24 17:59:29 --> Helper loaded: string_helper
INFO - 2020-02-24 17:59:29 --> Database Driver Class Initialized
DEBUG - 2020-02-24 17:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 17:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 17:59:29 --> Controller Class Initialized
INFO - 2020-02-24 17:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:59:29 --> Pagination Class Initialized
INFO - 2020-02-24 17:59:29 --> Model "M_show" initialized
INFO - 2020-02-24 17:59:29 --> Helper loaded: form_helper
INFO - 2020-02-24 17:59:29 --> Form Validation Class Initialized
INFO - 2020-02-24 17:59:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-24 17:59:29 --> Final output sent to browser
DEBUG - 2020-02-24 17:59:29 --> Total execution time: 0.2562
INFO - 2020-02-24 17:59:31 --> Config Class Initialized
INFO - 2020-02-24 17:59:31 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:31 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:31 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:31 --> URI Class Initialized
INFO - 2020-02-24 17:59:31 --> Router Class Initialized
INFO - 2020-02-24 17:59:31 --> Output Class Initialized
INFO - 2020-02-24 17:59:31 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:31 --> Input Class Initialized
INFO - 2020-02-24 17:59:31 --> Language Class Initialized
INFO - 2020-02-24 17:59:31 --> Loader Class Initialized
INFO - 2020-02-24 17:59:31 --> Helper loaded: url_helper
INFO - 2020-02-24 17:59:31 --> Helper loaded: string_helper
INFO - 2020-02-24 17:59:31 --> Database Driver Class Initialized
DEBUG - 2020-02-24 17:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 17:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 17:59:31 --> Controller Class Initialized
INFO - 2020-02-24 17:59:31 --> Model "M_tiket" initialized
INFO - 2020-02-24 17:59:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 17:59:31 --> Model "M_pesan" initialized
INFO - 2020-02-24 17:59:31 --> Helper loaded: form_helper
INFO - 2020-02-24 17:59:31 --> Form Validation Class Initialized
INFO - 2020-02-24 17:59:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-24 17:59:31 --> Final output sent to browser
DEBUG - 2020-02-24 17:59:31 --> Total execution time: 0.2456
INFO - 2020-02-24 17:59:31 --> Config Class Initialized
INFO - 2020-02-24 17:59:31 --> Config Class Initialized
INFO - 2020-02-24 17:59:31 --> Config Class Initialized
INFO - 2020-02-24 17:59:31 --> Config Class Initialized
INFO - 2020-02-24 17:59:31 --> Hooks Class Initialized
INFO - 2020-02-24 17:59:31 --> Hooks Class Initialized
INFO - 2020-02-24 17:59:31 --> Hooks Class Initialized
INFO - 2020-02-24 17:59:31 --> Hooks Class Initialized
INFO - 2020-02-24 17:59:31 --> Config Class Initialized
INFO - 2020-02-24 17:59:31 --> Config Class Initialized
INFO - 2020-02-24 17:59:31 --> Hooks Class Initialized
INFO - 2020-02-24 17:59:31 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:59:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:59:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:59:31 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:31 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:31 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:31 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:31 --> Utf8 Class Initialized
DEBUG - 2020-02-24 17:59:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:59:31 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:31 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:31 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:31 --> URI Class Initialized
INFO - 2020-02-24 17:59:31 --> URI Class Initialized
INFO - 2020-02-24 17:59:31 --> URI Class Initialized
INFO - 2020-02-24 17:59:31 --> URI Class Initialized
INFO - 2020-02-24 17:59:31 --> URI Class Initialized
INFO - 2020-02-24 17:59:31 --> URI Class Initialized
INFO - 2020-02-24 17:59:31 --> Router Class Initialized
INFO - 2020-02-24 17:59:31 --> Router Class Initialized
INFO - 2020-02-24 17:59:31 --> Router Class Initialized
INFO - 2020-02-24 17:59:31 --> Router Class Initialized
INFO - 2020-02-24 17:59:31 --> Router Class Initialized
INFO - 2020-02-24 17:59:31 --> Router Class Initialized
INFO - 2020-02-24 17:59:31 --> Output Class Initialized
INFO - 2020-02-24 17:59:31 --> Output Class Initialized
INFO - 2020-02-24 17:59:31 --> Output Class Initialized
INFO - 2020-02-24 17:59:31 --> Output Class Initialized
INFO - 2020-02-24 17:59:31 --> Security Class Initialized
INFO - 2020-02-24 17:59:31 --> Security Class Initialized
INFO - 2020-02-24 17:59:31 --> Security Class Initialized
INFO - 2020-02-24 17:59:31 --> Security Class Initialized
INFO - 2020-02-24 17:59:31 --> Output Class Initialized
INFO - 2020-02-24 17:59:31 --> Output Class Initialized
DEBUG - 2020-02-24 17:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:31 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:31 --> Security Class Initialized
INFO - 2020-02-24 17:59:31 --> Input Class Initialized
INFO - 2020-02-24 17:59:31 --> Input Class Initialized
INFO - 2020-02-24 17:59:31 --> Input Class Initialized
INFO - 2020-02-24 17:59:31 --> Input Class Initialized
DEBUG - 2020-02-24 17:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:31 --> Input Class Initialized
INFO - 2020-02-24 17:59:31 --> Input Class Initialized
INFO - 2020-02-24 17:59:31 --> Language Class Initialized
INFO - 2020-02-24 17:59:31 --> Language Class Initialized
INFO - 2020-02-24 17:59:31 --> Language Class Initialized
INFO - 2020-02-24 17:59:31 --> Language Class Initialized
INFO - 2020-02-24 17:59:31 --> Language Class Initialized
INFO - 2020-02-24 17:59:31 --> Language Class Initialized
ERROR - 2020-02-24 17:59:31 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-24 17:59:31 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-24 17:59:31 --> Loader Class Initialized
INFO - 2020-02-24 17:59:31 --> Loader Class Initialized
ERROR - 2020-02-24 17:59:31 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-24 17:59:31 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-24 17:59:31 --> Helper loaded: url_helper
INFO - 2020-02-24 17:59:31 --> Helper loaded: url_helper
INFO - 2020-02-24 17:59:31 --> Config Class Initialized
INFO - 2020-02-24 17:59:31 --> Config Class Initialized
INFO - 2020-02-24 17:59:31 --> Helper loaded: string_helper
INFO - 2020-02-24 17:59:31 --> Helper loaded: string_helper
INFO - 2020-02-24 17:59:31 --> Hooks Class Initialized
INFO - 2020-02-24 17:59:31 --> Hooks Class Initialized
INFO - 2020-02-24 17:59:31 --> Config Class Initialized
INFO - 2020-02-24 17:59:31 --> Config Class Initialized
INFO - 2020-02-24 17:59:31 --> Database Driver Class Initialized
INFO - 2020-02-24 17:59:31 --> Database Driver Class Initialized
INFO - 2020-02-24 17:59:31 --> Hooks Class Initialized
INFO - 2020-02-24 17:59:31 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:59:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-24 17:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 17:59:31 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:31 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-24 17:59:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:59:31 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:31 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:31 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:31 --> Controller Class Initialized
INFO - 2020-02-24 17:59:31 --> URI Class Initialized
INFO - 2020-02-24 17:59:31 --> URI Class Initialized
INFO - 2020-02-24 17:59:31 --> URI Class Initialized
INFO - 2020-02-24 17:59:31 --> Model "M_tiket" initialized
INFO - 2020-02-24 17:59:31 --> Router Class Initialized
INFO - 2020-02-24 17:59:31 --> URI Class Initialized
INFO - 2020-02-24 17:59:31 --> Router Class Initialized
INFO - 2020-02-24 17:59:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 17:59:31 --> Router Class Initialized
INFO - 2020-02-24 17:59:31 --> Router Class Initialized
INFO - 2020-02-24 17:59:31 --> Output Class Initialized
INFO - 2020-02-24 17:59:31 --> Output Class Initialized
INFO - 2020-02-24 17:59:31 --> Model "M_pesan" initialized
INFO - 2020-02-24 17:59:31 --> Security Class Initialized
INFO - 2020-02-24 17:59:31 --> Security Class Initialized
INFO - 2020-02-24 17:59:31 --> Output Class Initialized
INFO - 2020-02-24 17:59:31 --> Output Class Initialized
INFO - 2020-02-24 17:59:31 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:31 --> Security Class Initialized
INFO - 2020-02-24 17:59:31 --> Helper loaded: form_helper
INFO - 2020-02-24 17:59:31 --> Input Class Initialized
INFO - 2020-02-24 17:59:31 --> Input Class Initialized
INFO - 2020-02-24 17:59:31 --> Form Validation Class Initialized
DEBUG - 2020-02-24 17:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:32 --> Input Class Initialized
INFO - 2020-02-24 17:59:32 --> Input Class Initialized
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
ERROR - 2020-02-24 17:59:32 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
ERROR - 2020-02-24 17:59:32 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-24 17:59:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-24 17:59:32 --> Config Class Initialized
INFO - 2020-02-24 17:59:32 --> Config Class Initialized
INFO - 2020-02-24 17:59:32 --> Hooks Class Initialized
INFO - 2020-02-24 17:59:32 --> Hooks Class Initialized
INFO - 2020-02-24 17:59:32 --> Final output sent to browser
INFO - 2020-02-24 17:59:32 --> Config Class Initialized
INFO - 2020-02-24 17:59:32 --> Config Class Initialized
DEBUG - 2020-02-24 17:59:32 --> Total execution time: 0.2928
INFO - 2020-02-24 17:59:32 --> Hooks Class Initialized
INFO - 2020-02-24 17:59:32 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:59:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:32 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:32 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-24 17:59:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:59:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:32 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:32 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:32 --> Controller Class Initialized
INFO - 2020-02-24 17:59:32 --> URI Class Initialized
INFO - 2020-02-24 17:59:32 --> URI Class Initialized
INFO - 2020-02-24 17:59:32 --> Model "M_tiket" initialized
INFO - 2020-02-24 17:59:32 --> URI Class Initialized
INFO - 2020-02-24 17:59:32 --> Router Class Initialized
INFO - 2020-02-24 17:59:32 --> URI Class Initialized
INFO - 2020-02-24 17:59:32 --> Router Class Initialized
INFO - 2020-02-24 17:59:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 17:59:32 --> Router Class Initialized
INFO - 2020-02-24 17:59:32 --> Router Class Initialized
INFO - 2020-02-24 17:59:32 --> Output Class Initialized
INFO - 2020-02-24 17:59:32 --> Output Class Initialized
INFO - 2020-02-24 17:59:32 --> Model "M_pesan" initialized
INFO - 2020-02-24 17:59:32 --> Security Class Initialized
INFO - 2020-02-24 17:59:32 --> Output Class Initialized
INFO - 2020-02-24 17:59:32 --> Output Class Initialized
INFO - 2020-02-24 17:59:32 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:32 --> Security Class Initialized
INFO - 2020-02-24 17:59:32 --> Security Class Initialized
INFO - 2020-02-24 17:59:32 --> Helper loaded: form_helper
INFO - 2020-02-24 17:59:32 --> Input Class Initialized
INFO - 2020-02-24 17:59:32 --> Form Validation Class Initialized
INFO - 2020-02-24 17:59:32 --> Input Class Initialized
DEBUG - 2020-02-24 17:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:32 --> Input Class Initialized
INFO - 2020-02-24 17:59:32 --> Input Class Initialized
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
ERROR - 2020-02-24 17:59:32 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
ERROR - 2020-02-24 17:59:32 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-24 17:59:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-24 17:59:32 --> Final output sent to browser
DEBUG - 2020-02-24 17:59:32 --> Total execution time: 0.4078
INFO - 2020-02-24 17:59:32 --> Config Class Initialized
INFO - 2020-02-24 17:59:32 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:32 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:32 --> URI Class Initialized
INFO - 2020-02-24 17:59:32 --> Router Class Initialized
INFO - 2020-02-24 17:59:32 --> Output Class Initialized
INFO - 2020-02-24 17:59:32 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:32 --> Input Class Initialized
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-24 17:59:32 --> Config Class Initialized
INFO - 2020-02-24 17:59:32 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:32 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:32 --> URI Class Initialized
INFO - 2020-02-24 17:59:32 --> Router Class Initialized
INFO - 2020-02-24 17:59:32 --> Output Class Initialized
INFO - 2020-02-24 17:59:32 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:32 --> Input Class Initialized
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-24 17:59:32 --> Config Class Initialized
INFO - 2020-02-24 17:59:32 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:32 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:32 --> URI Class Initialized
INFO - 2020-02-24 17:59:32 --> Router Class Initialized
INFO - 2020-02-24 17:59:32 --> Output Class Initialized
INFO - 2020-02-24 17:59:32 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:32 --> Input Class Initialized
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-24 17:59:32 --> Config Class Initialized
INFO - 2020-02-24 17:59:32 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:32 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:32 --> URI Class Initialized
INFO - 2020-02-24 17:59:32 --> Router Class Initialized
INFO - 2020-02-24 17:59:32 --> Output Class Initialized
INFO - 2020-02-24 17:59:32 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:32 --> Input Class Initialized
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-24 17:59:32 --> Config Class Initialized
INFO - 2020-02-24 17:59:32 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:32 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:32 --> URI Class Initialized
INFO - 2020-02-24 17:59:32 --> Router Class Initialized
INFO - 2020-02-24 17:59:32 --> Output Class Initialized
INFO - 2020-02-24 17:59:32 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:32 --> Input Class Initialized
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-24 17:59:32 --> Config Class Initialized
INFO - 2020-02-24 17:59:32 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:32 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:32 --> URI Class Initialized
INFO - 2020-02-24 17:59:32 --> Router Class Initialized
INFO - 2020-02-24 17:59:32 --> Output Class Initialized
INFO - 2020-02-24 17:59:32 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:32 --> Input Class Initialized
INFO - 2020-02-24 17:59:32 --> Language Class Initialized
ERROR - 2020-02-24 17:59:32 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-24 17:59:32 --> Config Class Initialized
INFO - 2020-02-24 17:59:32 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:32 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:32 --> URI Class Initialized
INFO - 2020-02-24 17:59:32 --> Router Class Initialized
INFO - 2020-02-24 17:59:32 --> Output Class Initialized
INFO - 2020-02-24 17:59:33 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:33 --> Input Class Initialized
INFO - 2020-02-24 17:59:33 --> Language Class Initialized
ERROR - 2020-02-24 17:59:33 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-24 17:59:33 --> Config Class Initialized
INFO - 2020-02-24 17:59:33 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:33 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:33 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:33 --> URI Class Initialized
INFO - 2020-02-24 17:59:33 --> Router Class Initialized
INFO - 2020-02-24 17:59:33 --> Output Class Initialized
INFO - 2020-02-24 17:59:33 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:33 --> Input Class Initialized
INFO - 2020-02-24 17:59:33 --> Language Class Initialized
ERROR - 2020-02-24 17:59:33 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-24 18:00:10 --> Config Class Initialized
INFO - 2020-02-24 18:00:10 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:00:10 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:00:10 --> Utf8 Class Initialized
INFO - 2020-02-24 18:00:10 --> URI Class Initialized
INFO - 2020-02-24 18:00:10 --> Router Class Initialized
INFO - 2020-02-24 18:00:10 --> Output Class Initialized
INFO - 2020-02-24 18:00:10 --> Security Class Initialized
DEBUG - 2020-02-24 18:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:00:10 --> Input Class Initialized
INFO - 2020-02-24 18:00:10 --> Language Class Initialized
INFO - 2020-02-24 18:00:10 --> Loader Class Initialized
INFO - 2020-02-24 18:00:10 --> Helper loaded: url_helper
INFO - 2020-02-24 18:00:10 --> Helper loaded: string_helper
INFO - 2020-02-24 18:00:10 --> Database Driver Class Initialized
DEBUG - 2020-02-24 18:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 18:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 18:00:10 --> Controller Class Initialized
INFO - 2020-02-24 18:00:10 --> Model "M_tiket" initialized
INFO - 2020-02-24 18:00:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 18:00:10 --> Model "M_pesan" initialized
INFO - 2020-02-24 18:00:10 --> Helper loaded: form_helper
INFO - 2020-02-24 18:00:10 --> Form Validation Class Initialized
INFO - 2020-02-24 18:01:11 --> Config Class Initialized
INFO - 2020-02-24 18:01:11 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:01:11 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:01:11 --> Utf8 Class Initialized
INFO - 2020-02-24 18:01:11 --> URI Class Initialized
INFO - 2020-02-24 18:01:11 --> Router Class Initialized
INFO - 2020-02-24 18:01:11 --> Output Class Initialized
INFO - 2020-02-24 18:01:11 --> Security Class Initialized
DEBUG - 2020-02-24 18:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:01:11 --> Input Class Initialized
INFO - 2020-02-24 18:01:11 --> Language Class Initialized
INFO - 2020-02-24 18:01:11 --> Loader Class Initialized
INFO - 2020-02-24 18:01:11 --> Helper loaded: url_helper
INFO - 2020-02-24 18:01:11 --> Helper loaded: string_helper
INFO - 2020-02-24 18:01:11 --> Database Driver Class Initialized
DEBUG - 2020-02-24 18:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 18:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 18:01:11 --> Controller Class Initialized
INFO - 2020-02-24 18:01:11 --> Model "M_tiket" initialized
INFO - 2020-02-24 18:01:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 18:01:11 --> Model "M_pesan" initialized
INFO - 2020-02-24 18:01:11 --> Helper loaded: form_helper
INFO - 2020-02-24 18:01:11 --> Form Validation Class Initialized
INFO - 2020-02-24 18:01:21 --> Config Class Initialized
INFO - 2020-02-24 18:01:21 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:01:21 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:01:21 --> Utf8 Class Initialized
INFO - 2020-02-24 18:01:21 --> URI Class Initialized
INFO - 2020-02-24 18:01:21 --> Router Class Initialized
INFO - 2020-02-24 18:01:21 --> Output Class Initialized
INFO - 2020-02-24 18:01:21 --> Security Class Initialized
DEBUG - 2020-02-24 18:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:01:21 --> Input Class Initialized
INFO - 2020-02-24 18:01:21 --> Language Class Initialized
INFO - 2020-02-24 18:01:21 --> Loader Class Initialized
INFO - 2020-02-24 18:01:21 --> Helper loaded: url_helper
INFO - 2020-02-24 18:01:21 --> Helper loaded: string_helper
INFO - 2020-02-24 18:01:21 --> Database Driver Class Initialized
DEBUG - 2020-02-24 18:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 18:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 18:01:21 --> Controller Class Initialized
INFO - 2020-02-24 18:01:21 --> Model "M_tiket" initialized
INFO - 2020-02-24 18:01:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 18:01:21 --> Model "M_pesan" initialized
INFO - 2020-02-24 18:01:21 --> Helper loaded: form_helper
INFO - 2020-02-24 18:01:21 --> Form Validation Class Initialized
INFO - 2020-02-24 18:01:25 --> Config Class Initialized
INFO - 2020-02-24 18:01:25 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:01:25 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:01:25 --> Utf8 Class Initialized
INFO - 2020-02-24 18:01:25 --> URI Class Initialized
INFO - 2020-02-24 18:01:25 --> Router Class Initialized
INFO - 2020-02-24 18:01:25 --> Output Class Initialized
INFO - 2020-02-24 18:01:25 --> Security Class Initialized
DEBUG - 2020-02-24 18:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:01:25 --> Input Class Initialized
INFO - 2020-02-24 18:01:25 --> Language Class Initialized
INFO - 2020-02-24 18:01:25 --> Loader Class Initialized
INFO - 2020-02-24 18:01:25 --> Helper loaded: url_helper
INFO - 2020-02-24 18:01:25 --> Helper loaded: string_helper
INFO - 2020-02-24 18:01:25 --> Database Driver Class Initialized
DEBUG - 2020-02-24 18:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 18:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 18:01:25 --> Controller Class Initialized
INFO - 2020-02-24 18:01:25 --> Model "M_tiket" initialized
INFO - 2020-02-24 18:01:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 18:01:25 --> Model "M_pesan" initialized
INFO - 2020-02-24 18:01:25 --> Helper loaded: form_helper
INFO - 2020-02-24 18:01:25 --> Form Validation Class Initialized
INFO - 2020-02-24 18:21:03 --> Config Class Initialized
INFO - 2020-02-24 18:21:03 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:21:03 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:21:03 --> Utf8 Class Initialized
INFO - 2020-02-24 18:21:03 --> URI Class Initialized
INFO - 2020-02-24 18:21:03 --> Router Class Initialized
INFO - 2020-02-24 18:21:03 --> Output Class Initialized
INFO - 2020-02-24 18:21:03 --> Security Class Initialized
DEBUG - 2020-02-24 18:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:21:03 --> Input Class Initialized
INFO - 2020-02-24 18:21:03 --> Language Class Initialized
INFO - 2020-02-24 18:21:03 --> Loader Class Initialized
INFO - 2020-02-24 18:21:03 --> Helper loaded: url_helper
INFO - 2020-02-24 18:21:03 --> Helper loaded: string_helper
INFO - 2020-02-24 18:21:03 --> Database Driver Class Initialized
DEBUG - 2020-02-24 18:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 18:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 18:21:03 --> Controller Class Initialized
INFO - 2020-02-24 18:21:03 --> Model "M_tiket" initialized
INFO - 2020-02-24 18:21:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 18:21:03 --> Model "M_pesan" initialized
INFO - 2020-02-24 18:21:03 --> Helper loaded: form_helper
INFO - 2020-02-24 18:21:03 --> Form Validation Class Initialized
ERROR - 2020-02-24 18:21:03 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-24 18:21:17 --> Config Class Initialized
INFO - 2020-02-24 18:21:17 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:21:17 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:21:17 --> Utf8 Class Initialized
INFO - 2020-02-24 18:21:17 --> URI Class Initialized
INFO - 2020-02-24 18:21:17 --> Router Class Initialized
INFO - 2020-02-24 18:21:17 --> Output Class Initialized
INFO - 2020-02-24 18:21:17 --> Security Class Initialized
DEBUG - 2020-02-24 18:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:21:17 --> Input Class Initialized
INFO - 2020-02-24 18:21:17 --> Language Class Initialized
INFO - 2020-02-24 18:21:17 --> Loader Class Initialized
INFO - 2020-02-24 18:21:17 --> Helper loaded: url_helper
INFO - 2020-02-24 18:21:17 --> Helper loaded: string_helper
INFO - 2020-02-24 18:21:17 --> Database Driver Class Initialized
DEBUG - 2020-02-24 18:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 18:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 18:21:17 --> Controller Class Initialized
INFO - 2020-02-24 18:21:17 --> Model "M_tiket" initialized
INFO - 2020-02-24 18:21:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 18:21:17 --> Model "M_pesan" initialized
INFO - 2020-02-24 18:21:17 --> Helper loaded: form_helper
INFO - 2020-02-24 18:21:17 --> Form Validation Class Initialized
ERROR - 2020-02-24 18:21:17 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-24 18:21:17 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-24 18:21:17 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-24 18:21:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '2'' at line 3 - Invalid query: SELECT *
FROM `pemesanan`
WHERE  = '2'
INFO - 2020-02-24 18:21:17 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-24 18:21:21 --> Config Class Initialized
INFO - 2020-02-24 18:21:21 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:21:21 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:21:21 --> Utf8 Class Initialized
INFO - 2020-02-24 18:21:21 --> URI Class Initialized
INFO - 2020-02-24 18:21:21 --> Router Class Initialized
INFO - 2020-02-24 18:21:21 --> Output Class Initialized
INFO - 2020-02-24 18:21:21 --> Security Class Initialized
DEBUG - 2020-02-24 18:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:21:21 --> Input Class Initialized
INFO - 2020-02-24 18:21:21 --> Language Class Initialized
INFO - 2020-02-24 18:21:21 --> Loader Class Initialized
INFO - 2020-02-24 18:21:21 --> Helper loaded: url_helper
INFO - 2020-02-24 18:21:21 --> Helper loaded: string_helper
INFO - 2020-02-24 18:21:21 --> Database Driver Class Initialized
DEBUG - 2020-02-24 18:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 18:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 18:21:21 --> Controller Class Initialized
INFO - 2020-02-24 18:21:21 --> Model "M_tiket" initialized
INFO - 2020-02-24 18:21:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 18:21:21 --> Model "M_pesan" initialized
INFO - 2020-02-24 18:21:21 --> Helper loaded: form_helper
INFO - 2020-02-24 18:21:21 --> Form Validation Class Initialized
ERROR - 2020-02-24 18:21:21 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-24 18:21:21 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-24 18:21:21 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-24 18:21:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '22'' at line 3 - Invalid query: SELECT *
FROM `pemesanan`
WHERE  = '22'
INFO - 2020-02-24 18:21:21 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-24 18:21:23 --> Config Class Initialized
INFO - 2020-02-24 18:21:23 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:21:23 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:21:23 --> Utf8 Class Initialized
INFO - 2020-02-24 18:21:23 --> URI Class Initialized
INFO - 2020-02-24 18:21:23 --> Router Class Initialized
INFO - 2020-02-24 18:21:23 --> Output Class Initialized
INFO - 2020-02-24 18:21:23 --> Security Class Initialized
DEBUG - 2020-02-24 18:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:21:23 --> Input Class Initialized
INFO - 2020-02-24 18:21:23 --> Language Class Initialized
INFO - 2020-02-24 18:21:23 --> Loader Class Initialized
INFO - 2020-02-24 18:21:23 --> Helper loaded: url_helper
INFO - 2020-02-24 18:21:23 --> Helper loaded: string_helper
INFO - 2020-02-24 18:21:23 --> Database Driver Class Initialized
DEBUG - 2020-02-24 18:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 18:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 18:21:23 --> Controller Class Initialized
INFO - 2020-02-24 18:21:23 --> Model "M_tiket" initialized
INFO - 2020-02-24 18:21:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 18:21:23 --> Model "M_pesan" initialized
INFO - 2020-02-24 18:21:23 --> Helper loaded: form_helper
INFO - 2020-02-24 18:21:23 --> Form Validation Class Initialized
ERROR - 2020-02-24 18:21:23 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-24 18:21:23 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-24 18:21:23 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-24 18:21:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '2'' at line 3 - Invalid query: SELECT *
FROM `pemesanan`
WHERE  = '2'
INFO - 2020-02-24 18:21:23 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-24 18:21:27 --> Config Class Initialized
INFO - 2020-02-24 18:21:27 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:21:27 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:21:27 --> Utf8 Class Initialized
INFO - 2020-02-24 18:21:27 --> URI Class Initialized
INFO - 2020-02-24 18:21:28 --> Router Class Initialized
INFO - 2020-02-24 18:21:28 --> Output Class Initialized
INFO - 2020-02-24 18:21:28 --> Security Class Initialized
DEBUG - 2020-02-24 18:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:21:28 --> Input Class Initialized
INFO - 2020-02-24 18:21:28 --> Language Class Initialized
INFO - 2020-02-24 18:21:28 --> Loader Class Initialized
INFO - 2020-02-24 18:21:28 --> Helper loaded: url_helper
INFO - 2020-02-24 18:21:28 --> Helper loaded: string_helper
INFO - 2020-02-24 18:21:28 --> Database Driver Class Initialized
DEBUG - 2020-02-24 18:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-24 18:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-24 18:21:28 --> Controller Class Initialized
INFO - 2020-02-24 18:21:28 --> Model "M_tiket" initialized
INFO - 2020-02-24 18:21:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-24 18:21:28 --> Model "M_pesan" initialized
INFO - 2020-02-24 18:21:28 --> Helper loaded: form_helper
INFO - 2020-02-24 18:21:28 --> Form Validation Class Initialized
