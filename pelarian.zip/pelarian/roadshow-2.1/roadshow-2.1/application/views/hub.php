   <div class="localP6">
                <div class="col-lg-12 col-md-12 col-sm-12" style="color: white; padding-top: 150px; text-align: center; font-size: 40px;">
                    KAMI SANGAT SENANG MENDAPATKAN PENGALAMAN BARU 
                    <H3>SILAHKAN HUBUNGI KAMI DISINI :</H3>
                </div>
            <div class="col-lg-12 col-md-12 col-sm-12" style="color: white; margin-top: 100px; text-align: center; font-size: 40px;">
                    HUBUNGIKAMI@MUSIKOLOGI.COM
                    <H3>SILAHKAN HUBUNGI KAMI DISINI :</H3>
                </div>
            </div>