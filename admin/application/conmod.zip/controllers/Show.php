<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Show extends CI_Controller {
   function __construct()
   {
   		parent::__construct();
		check_not_login();
		check_admin();
   		$this->load->model('M_show');
   		$this->load->library('form_validation');
   }

	public function index()
	{
		$this->load->model('M_show');
		$data['row'] = $this->M_show->get();
		$this->template->load('template','Show/show_data',$data);
	}
	public function add()
	{
		$show = new stdClass();
		$show->id_show=null;
		$show->nama =null;
		$show->kota =null;
		$show->lokasi =null;
		$show->tanggal =null;
		$show->foto =null;
		$show->keterangan =null;
		$show->keseluruhan_tiket =null;
		$data = array(
				'page' => 'add',
				'row' => $show
 			);
		$this->template->load('template','Show/form_show', $data);
	}
	public function proses()
	{
		$post= $this->input->post(null, TRUE);
		if(isset($_POST['add'])){
			$this->M_show->add($post);
		}elseif(isset($_POST['edit'])){
			$this->M_show->edit($post);
		}
		if($this->db->affected_rows() > 0){
			echo"<script>alert('Data berhasil disimpan');</script>";
		}
			echo "<script>window.location='".base_url('show')."';</script>";

	}
	public function del()
	{
		$id = $this->input->post('id_show');
		$this->M_show->del($id);

		if($this->db->affected_rows() > 0)
			{
				echo"<script>alert('Data terhapus');</script>";
			}
				echo "<script>window.location='".base_url('show')."';</script>";

	}
	public function edit($id)
	{
		$query = $this->M_show->get($id);
		if($query->num_rows() > 0)
		{
			$show = $query->row();
			$data = array(
					'page' => 'edit',
					'row' => $show 
				);
				$this->template->load('template','Show/form_show', $data);
		}else{
			echo"<script>alert('Data tidak ditemukan');";
			echo "window.location='".base_url('show')."';</script>";
		}
	}
}

		


