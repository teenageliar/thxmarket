<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_show extends CI_Model 
{
	public function get($id = null)
	{
		$this->db->from('roadshow');
		if($id !=null){
			$this->db->where('id_show', $id);
		}
		$query = $this->db->get();
		return $query;
	}
	public function add($post)
	{
		$params =[ 
			'nama' => $post['nama'],
			'kota' => $post['kota'],
			'lokasi' => $post['lokasi'],
			'tanggal' => $post['tanggal'],
			'foto' => $post['foto'],
			'keterangan' => $post['keterangan'],
			'keseluruhan_tiket' => $post['keseluruhan_tiket'],



		];
		
		$this->db->insert('roadshow', $params);
	}
		public function edit($post)
	{
		$params =[ 
			'nama' => $post['nama'],
			'kota' => $post['kota'],
			'lokasi' => $post['lokasi'],
			'tanggal' => $post['tanggal'],
			'foto' => $post['foto'],
			'keterangan' => $post['keterangan'],
			'keseluruhan_tiket' => $post['keseluruhan_tiket'],

		];
		$this->db->where('id_show', $post['id']);
		$this->db->update('roadshow', $params);
	}
	public function del($id)
	{
		$this->db->where('id_show', $id);
		$this->db->delete('roadshow');
	}
}
  