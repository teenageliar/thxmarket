<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-07 16:56:02 --> Config Class Initialized
INFO - 2020-01-07 16:56:02 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:02 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:02 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:02 --> URI Class Initialized
DEBUG - 2020-01-07 16:56:02 --> No URI present. Default controller set.
INFO - 2020-01-07 16:56:02 --> Router Class Initialized
INFO - 2020-01-07 16:56:02 --> Output Class Initialized
INFO - 2020-01-07 16:56:02 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:02 --> Input Class Initialized
INFO - 2020-01-07 16:56:02 --> Language Class Initialized
INFO - 2020-01-07 16:56:03 --> Loader Class Initialized
INFO - 2020-01-07 16:56:03 --> Helper loaded: url_helper
INFO - 2020-01-07 16:56:03 --> Database Driver Class Initialized
DEBUG - 2020-01-07 16:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 16:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 16:56:03 --> Controller Class Initialized
INFO - 2020-01-07 16:56:03 --> Model "M_login" initialized
INFO - 2020-01-07 16:56:03 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2020-01-07 16:56:03 --> Final output sent to browser
DEBUG - 2020-01-07 16:56:03 --> Total execution time: 1.7177
INFO - 2020-01-07 16:56:10 --> Config Class Initialized
INFO - 2020-01-07 16:56:10 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:10 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:10 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:10 --> URI Class Initialized
INFO - 2020-01-07 16:56:10 --> Router Class Initialized
INFO - 2020-01-07 16:56:10 --> Output Class Initialized
INFO - 2020-01-07 16:56:10 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:10 --> Input Class Initialized
INFO - 2020-01-07 16:56:10 --> Language Class Initialized
INFO - 2020-01-07 16:56:10 --> Loader Class Initialized
INFO - 2020-01-07 16:56:10 --> Helper loaded: url_helper
INFO - 2020-01-07 16:56:10 --> Database Driver Class Initialized
DEBUG - 2020-01-07 16:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 16:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 16:56:10 --> Controller Class Initialized
INFO - 2020-01-07 16:56:10 --> Model "M_login" initialized
INFO - 2020-01-07 16:56:10 --> Config Class Initialized
INFO - 2020-01-07 16:56:10 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:10 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:10 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:10 --> URI Class Initialized
INFO - 2020-01-07 16:56:10 --> Router Class Initialized
INFO - 2020-01-07 16:56:10 --> Output Class Initialized
INFO - 2020-01-07 16:56:10 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:10 --> Input Class Initialized
INFO - 2020-01-07 16:56:10 --> Language Class Initialized
INFO - 2020-01-07 16:56:10 --> Loader Class Initialized
INFO - 2020-01-07 16:56:11 --> Helper loaded: url_helper
INFO - 2020-01-07 16:56:11 --> Database Driver Class Initialized
DEBUG - 2020-01-07 16:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 16:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 16:56:11 --> Controller Class Initialized
INFO - 2020-01-07 16:56:11 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 16:56:11 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2020-01-07 16:56:11 --> Final output sent to browser
DEBUG - 2020-01-07 16:56:11 --> Total execution time: 0.6927
INFO - 2020-01-07 16:56:11 --> Config Class Initialized
INFO - 2020-01-07 16:56:11 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:11 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:11 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:11 --> URI Class Initialized
INFO - 2020-01-07 16:56:11 --> Router Class Initialized
INFO - 2020-01-07 16:56:11 --> Config Class Initialized
INFO - 2020-01-07 16:56:11 --> Hooks Class Initialized
INFO - 2020-01-07 16:56:11 --> Output Class Initialized
INFO - 2020-01-07 16:56:11 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:11 --> Input Class Initialized
DEBUG - 2020-01-07 16:56:11 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:11 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:11 --> Language Class Initialized
INFO - 2020-01-07 16:56:11 --> URI Class Initialized
ERROR - 2020-01-07 16:56:11 --> 404 Page Not Found: Assets/js
INFO - 2020-01-07 16:56:11 --> Router Class Initialized
INFO - 2020-01-07 16:56:11 --> Output Class Initialized
INFO - 2020-01-07 16:56:11 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:12 --> Input Class Initialized
INFO - 2020-01-07 16:56:12 --> Language Class Initialized
ERROR - 2020-01-07 16:56:12 --> 404 Page Not Found: Assets/js
INFO - 2020-01-07 16:56:14 --> Config Class Initialized
INFO - 2020-01-07 16:56:14 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:14 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:14 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:14 --> URI Class Initialized
INFO - 2020-01-07 16:56:14 --> Router Class Initialized
INFO - 2020-01-07 16:56:14 --> Output Class Initialized
INFO - 2020-01-07 16:56:14 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:14 --> Input Class Initialized
INFO - 2020-01-07 16:56:14 --> Language Class Initialized
INFO - 2020-01-07 16:56:14 --> Loader Class Initialized
INFO - 2020-01-07 16:56:14 --> Helper loaded: url_helper
INFO - 2020-01-07 16:56:14 --> Database Driver Class Initialized
DEBUG - 2020-01-07 16:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 16:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 16:56:14 --> Controller Class Initialized
INFO - 2020-01-07 16:56:14 --> Model "M_login" initialized
INFO - 2020-01-07 16:56:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 16:56:14 --> Pagination Class Initialized
INFO - 2020-01-07 16:56:14 --> Model "M_show" initialized
INFO - 2020-01-07 16:56:15 --> Helper loaded: form_helper
INFO - 2020-01-07 16:56:15 --> Form Validation Class Initialized
INFO - 2020-01-07 16:56:15 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 16:56:15 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-07 16:56:15 --> Final output sent to browser
DEBUG - 2020-01-07 16:56:15 --> Total execution time: 1.0666
INFO - 2020-01-07 16:56:15 --> Config Class Initialized
INFO - 2020-01-07 16:56:15 --> Config Class Initialized
INFO - 2020-01-07 16:56:15 --> Hooks Class Initialized
INFO - 2020-01-07 16:56:15 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:15 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 16:56:15 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:15 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:15 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:15 --> URI Class Initialized
INFO - 2020-01-07 16:56:15 --> URI Class Initialized
INFO - 2020-01-07 16:56:15 --> Router Class Initialized
INFO - 2020-01-07 16:56:15 --> Router Class Initialized
INFO - 2020-01-07 16:56:15 --> Output Class Initialized
INFO - 2020-01-07 16:56:15 --> Security Class Initialized
INFO - 2020-01-07 16:56:15 --> Output Class Initialized
INFO - 2020-01-07 16:56:15 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:15 --> Input Class Initialized
DEBUG - 2020-01-07 16:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:15 --> Input Class Initialized
INFO - 2020-01-07 16:56:15 --> Language Class Initialized
INFO - 2020-01-07 16:56:15 --> Language Class Initialized
ERROR - 2020-01-07 16:56:15 --> 404 Page Not Found: Show/assets
ERROR - 2020-01-07 16:56:15 --> 404 Page Not Found: Show/assets
INFO - 2020-01-07 16:56:15 --> Config Class Initialized
INFO - 2020-01-07 16:56:15 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:15 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:15 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:15 --> URI Class Initialized
INFO - 2020-01-07 16:56:15 --> Router Class Initialized
INFO - 2020-01-07 16:56:16 --> Output Class Initialized
INFO - 2020-01-07 16:56:16 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:16 --> Input Class Initialized
INFO - 2020-01-07 16:56:16 --> Language Class Initialized
ERROR - 2020-01-07 16:56:16 --> 404 Page Not Found: Show/assets
INFO - 2020-01-07 16:56:26 --> Config Class Initialized
INFO - 2020-01-07 16:56:26 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:26 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:26 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:26 --> URI Class Initialized
INFO - 2020-01-07 16:56:26 --> Router Class Initialized
INFO - 2020-01-07 16:56:26 --> Output Class Initialized
INFO - 2020-01-07 16:56:26 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:26 --> Input Class Initialized
INFO - 2020-01-07 16:56:26 --> Language Class Initialized
INFO - 2020-01-07 16:56:26 --> Loader Class Initialized
INFO - 2020-01-07 16:56:26 --> Helper loaded: url_helper
INFO - 2020-01-07 16:56:26 --> Database Driver Class Initialized
DEBUG - 2020-01-07 16:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 16:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 16:56:26 --> Controller Class Initialized
INFO - 2020-01-07 16:56:26 --> Model "M_login" initialized
INFO - 2020-01-07 16:56:26 --> Model "M_tiket" initialized
INFO - 2020-01-07 16:56:26 --> Helper loaded: form_helper
INFO - 2020-01-07 16:56:26 --> Form Validation Class Initialized
INFO - 2020-01-07 16:56:27 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 16:56:27 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 16:56:27 --> Final output sent to browser
DEBUG - 2020-01-07 16:56:27 --> Total execution time: 0.7407
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
INFO - 2020-01-07 16:56:27 --> Language Class Initialized
INFO - 2020-01-07 16:56:27 --> Language Class Initialized
INFO - 2020-01-07 16:56:27 --> Language Class Initialized
INFO - 2020-01-07 16:56:27 --> Language Class Initialized
INFO - 2020-01-07 16:56:27 --> Language Class Initialized
ERROR - 2020-01-07 16:56:27 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-07 16:56:27 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-01-07 16:56:27 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-01-07 16:56:27 --> Language Class Initialized
ERROR - 2020-01-07 16:56:27 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-07 16:56:27 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-07 16:56:27 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:27 --> Language Class Initialized
INFO - 2020-01-07 16:56:27 --> Language Class Initialized
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
INFO - 2020-01-07 16:56:27 --> Language Class Initialized
ERROR - 2020-01-07 16:56:27 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-01-07 16:56:27 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
ERROR - 2020-01-07 16:56:27 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Config Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
INFO - 2020-01-07 16:56:27 --> Hooks Class Initialized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 16:56:27 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
INFO - 2020-01-07 16:56:27 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:27 --> Language Class Initialized
INFO - 2020-01-07 16:56:27 --> Language Class Initialized
INFO - 2020-01-07 16:56:27 --> Language Class Initialized
ERROR - 2020-01-07 16:56:27 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
INFO - 2020-01-07 16:56:27 --> URI Class Initialized
ERROR - 2020-01-07 16:56:27 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
INFO - 2020-01-07 16:56:27 --> Loader Class Initialized
INFO - 2020-01-07 16:56:27 --> Router Class Initialized
INFO - 2020-01-07 16:56:27 --> Helper loaded: url_helper
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Output Class Initialized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
INFO - 2020-01-07 16:56:27 --> Security Class Initialized
INFO - 2020-01-07 16:56:27 --> Database Driver Class Initialized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 16:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 16:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
INFO - 2020-01-07 16:56:27 --> Input Class Initialized
INFO - 2020-01-07 16:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 16:56:28 --> Controller Class Initialized
INFO - 2020-01-07 16:56:28 --> Language Class Initialized
INFO - 2020-01-07 16:56:28 --> Language Class Initialized
INFO - 2020-01-07 16:56:28 --> Model "M_login" initialized
ERROR - 2020-01-07 16:56:28 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-01-07 16:56:28 --> Loader Class Initialized
INFO - 2020-01-07 16:56:28 --> Model "M_tiket" initialized
INFO - 2020-01-07 16:56:28 --> Helper loaded: url_helper
INFO - 2020-01-07 16:56:28 --> Config Class Initialized
INFO - 2020-01-07 16:56:28 --> Database Driver Class Initialized
INFO - 2020-01-07 16:56:28 --> Hooks Class Initialized
INFO - 2020-01-07 16:56:28 --> Helper loaded: form_helper
INFO - 2020-01-07 16:56:28 --> Form Validation Class Initialized
DEBUG - 2020-01-07 16:56:28 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:28 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
DEBUG - 2020-01-07 16:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-01-07 16:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-07 16:56:28 --> URI Class Initialized
INFO - 2020-01-07 16:56:28 --> Router Class Initialized
ERROR - 2020-01-07 16:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2020-01-07 16:56:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 16:56:28 --> Output Class Initialized
INFO - 2020-01-07 16:56:28 --> Final output sent to browser
INFO - 2020-01-07 16:56:28 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:28 --> Total execution time: 0.5472
DEBUG - 2020-01-07 16:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:28 --> Input Class Initialized
INFO - 2020-01-07 16:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 16:56:28 --> Controller Class Initialized
INFO - 2020-01-07 16:56:28 --> Language Class Initialized
INFO - 2020-01-07 16:56:28 --> Model "M_login" initialized
ERROR - 2020-01-07 16:56:28 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-01-07 16:56:28 --> Model "M_tiket" initialized
INFO - 2020-01-07 16:56:28 --> Config Class Initialized
INFO - 2020-01-07 16:56:28 --> Helper loaded: form_helper
INFO - 2020-01-07 16:56:28 --> Form Validation Class Initialized
INFO - 2020-01-07 16:56:28 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:28 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 16:56:28 --> Utf8 Class Initialized
ERROR - 2020-01-07 16:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-01-07 16:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2020-01-07 16:56:28 --> URI Class Initialized
INFO - 2020-01-07 16:56:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 16:56:28 --> Router Class Initialized
INFO - 2020-01-07 16:56:28 --> Final output sent to browser
INFO - 2020-01-07 16:56:28 --> Output Class Initialized
DEBUG - 2020-01-07 16:56:28 --> Total execution time: 0.6347
INFO - 2020-01-07 16:56:28 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:28 --> Input Class Initialized
INFO - 2020-01-07 16:56:28 --> Language Class Initialized
ERROR - 2020-01-07 16:56:28 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-01-07 16:56:28 --> Config Class Initialized
INFO - 2020-01-07 16:56:28 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:28 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:28 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:28 --> URI Class Initialized
INFO - 2020-01-07 16:56:28 --> Router Class Initialized
INFO - 2020-01-07 16:56:28 --> Output Class Initialized
INFO - 2020-01-07 16:56:28 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:28 --> Input Class Initialized
INFO - 2020-01-07 16:56:28 --> Language Class Initialized
ERROR - 2020-01-07 16:56:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-01-07 16:56:28 --> Config Class Initialized
INFO - 2020-01-07 16:56:28 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:28 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:28 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:28 --> URI Class Initialized
INFO - 2020-01-07 16:56:28 --> Router Class Initialized
INFO - 2020-01-07 16:56:28 --> Output Class Initialized
INFO - 2020-01-07 16:56:28 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:28 --> Input Class Initialized
INFO - 2020-01-07 16:56:28 --> Language Class Initialized
ERROR - 2020-01-07 16:56:28 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 16:56:29 --> Config Class Initialized
INFO - 2020-01-07 16:56:29 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:29 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:29 --> URI Class Initialized
INFO - 2020-01-07 16:56:29 --> Router Class Initialized
INFO - 2020-01-07 16:56:29 --> Output Class Initialized
INFO - 2020-01-07 16:56:29 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:29 --> Input Class Initialized
INFO - 2020-01-07 16:56:29 --> Language Class Initialized
ERROR - 2020-01-07 16:56:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 16:56:29 --> Config Class Initialized
INFO - 2020-01-07 16:56:29 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:29 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:29 --> URI Class Initialized
INFO - 2020-01-07 16:56:29 --> Router Class Initialized
INFO - 2020-01-07 16:56:29 --> Output Class Initialized
INFO - 2020-01-07 16:56:29 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:29 --> Input Class Initialized
INFO - 2020-01-07 16:56:29 --> Language Class Initialized
ERROR - 2020-01-07 16:56:29 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-07 16:56:29 --> Config Class Initialized
INFO - 2020-01-07 16:56:29 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:29 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:29 --> URI Class Initialized
INFO - 2020-01-07 16:56:29 --> Router Class Initialized
INFO - 2020-01-07 16:56:29 --> Output Class Initialized
INFO - 2020-01-07 16:56:29 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:29 --> Input Class Initialized
INFO - 2020-01-07 16:56:29 --> Language Class Initialized
ERROR - 2020-01-07 16:56:29 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-07 16:56:29 --> Config Class Initialized
INFO - 2020-01-07 16:56:29 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:29 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:29 --> URI Class Initialized
INFO - 2020-01-07 16:56:29 --> Router Class Initialized
INFO - 2020-01-07 16:56:29 --> Output Class Initialized
INFO - 2020-01-07 16:56:29 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:29 --> Input Class Initialized
INFO - 2020-01-07 16:56:29 --> Language Class Initialized
ERROR - 2020-01-07 16:56:30 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-07 16:56:30 --> Config Class Initialized
INFO - 2020-01-07 16:56:30 --> Hooks Class Initialized
DEBUG - 2020-01-07 16:56:30 --> UTF-8 Support Enabled
INFO - 2020-01-07 16:56:30 --> Utf8 Class Initialized
INFO - 2020-01-07 16:56:30 --> URI Class Initialized
INFO - 2020-01-07 16:56:30 --> Router Class Initialized
INFO - 2020-01-07 16:56:30 --> Output Class Initialized
INFO - 2020-01-07 16:56:30 --> Security Class Initialized
DEBUG - 2020-01-07 16:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 16:56:30 --> Input Class Initialized
INFO - 2020-01-07 16:56:30 --> Language Class Initialized
ERROR - 2020-01-07 16:56:30 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-07 17:11:27 --> Config Class Initialized
INFO - 2020-01-07 17:11:27 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:11:27 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:27 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:27 --> URI Class Initialized
INFO - 2020-01-07 17:11:27 --> Router Class Initialized
INFO - 2020-01-07 17:11:27 --> Output Class Initialized
INFO - 2020-01-07 17:11:27 --> Security Class Initialized
DEBUG - 2020-01-07 17:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:27 --> Input Class Initialized
INFO - 2020-01-07 17:11:27 --> Language Class Initialized
INFO - 2020-01-07 17:11:27 --> Loader Class Initialized
INFO - 2020-01-07 17:11:27 --> Helper loaded: url_helper
INFO - 2020-01-07 17:11:27 --> Database Driver Class Initialized
DEBUG - 2020-01-07 17:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 17:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:11:27 --> Controller Class Initialized
INFO - 2020-01-07 17:11:27 --> Model "M_login" initialized
INFO - 2020-01-07 17:11:27 --> Model "M_tiket" initialized
INFO - 2020-01-07 17:11:27 --> Helper loaded: form_helper
INFO - 2020-01-07 17:11:27 --> Form Validation Class Initialized
INFO - 2020-01-07 17:11:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 17:11:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 17:11:28 --> Final output sent to browser
DEBUG - 2020-01-07 17:11:28 --> Total execution time: 0.4665
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:28 --> URI Class Initialized
INFO - 2020-01-07 17:11:28 --> URI Class Initialized
INFO - 2020-01-07 17:11:28 --> URI Class Initialized
INFO - 2020-01-07 17:11:28 --> URI Class Initialized
INFO - 2020-01-07 17:11:28 --> URI Class Initialized
INFO - 2020-01-07 17:11:28 --> Router Class Initialized
INFO - 2020-01-07 17:11:28 --> Router Class Initialized
INFO - 2020-01-07 17:11:28 --> URI Class Initialized
INFO - 2020-01-07 17:11:28 --> Router Class Initialized
INFO - 2020-01-07 17:11:28 --> Output Class Initialized
INFO - 2020-01-07 17:11:28 --> Router Class Initialized
INFO - 2020-01-07 17:11:28 --> Output Class Initialized
INFO - 2020-01-07 17:11:28 --> Output Class Initialized
INFO - 2020-01-07 17:11:28 --> Router Class Initialized
INFO - 2020-01-07 17:11:28 --> Router Class Initialized
INFO - 2020-01-07 17:11:28 --> Security Class Initialized
INFO - 2020-01-07 17:11:28 --> Output Class Initialized
INFO - 2020-01-07 17:11:28 --> Output Class Initialized
INFO - 2020-01-07 17:11:28 --> Security Class Initialized
INFO - 2020-01-07 17:11:28 --> Output Class Initialized
INFO - 2020-01-07 17:11:28 --> Security Class Initialized
DEBUG - 2020-01-07 17:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:28 --> Security Class Initialized
INFO - 2020-01-07 17:11:28 --> Security Class Initialized
INFO - 2020-01-07 17:11:28 --> Security Class Initialized
DEBUG - 2020-01-07 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:28 --> Input Class Initialized
INFO - 2020-01-07 17:11:28 --> Input Class Initialized
INFO - 2020-01-07 17:11:28 --> Input Class Initialized
DEBUG - 2020-01-07 17:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 17:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:28 --> Input Class Initialized
INFO - 2020-01-07 17:11:28 --> Input Class Initialized
INFO - 2020-01-07 17:11:28 --> Input Class Initialized
INFO - 2020-01-07 17:11:28 --> Language Class Initialized
INFO - 2020-01-07 17:11:28 --> Language Class Initialized
INFO - 2020-01-07 17:11:28 --> Language Class Initialized
INFO - 2020-01-07 17:11:28 --> Language Class Initialized
INFO - 2020-01-07 17:11:28 --> Language Class Initialized
INFO - 2020-01-07 17:11:28 --> Language Class Initialized
ERROR - 2020-01-07 17:11:28 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-01-07 17:11:28 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-01-07 17:11:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-07 17:11:28 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-01-07 17:11:28 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-07 17:11:28 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:28 --> URI Class Initialized
INFO - 2020-01-07 17:11:28 --> URI Class Initialized
INFO - 2020-01-07 17:11:28 --> URI Class Initialized
INFO - 2020-01-07 17:11:28 --> URI Class Initialized
INFO - 2020-01-07 17:11:28 --> URI Class Initialized
INFO - 2020-01-07 17:11:28 --> URI Class Initialized
INFO - 2020-01-07 17:11:28 --> Router Class Initialized
INFO - 2020-01-07 17:11:28 --> Router Class Initialized
INFO - 2020-01-07 17:11:28 --> Router Class Initialized
INFO - 2020-01-07 17:11:28 --> Router Class Initialized
INFO - 2020-01-07 17:11:28 --> Router Class Initialized
INFO - 2020-01-07 17:11:28 --> Router Class Initialized
INFO - 2020-01-07 17:11:28 --> Output Class Initialized
INFO - 2020-01-07 17:11:28 --> Output Class Initialized
INFO - 2020-01-07 17:11:28 --> Output Class Initialized
INFO - 2020-01-07 17:11:28 --> Security Class Initialized
INFO - 2020-01-07 17:11:28 --> Security Class Initialized
INFO - 2020-01-07 17:11:28 --> Output Class Initialized
INFO - 2020-01-07 17:11:28 --> Output Class Initialized
INFO - 2020-01-07 17:11:28 --> Security Class Initialized
INFO - 2020-01-07 17:11:28 --> Output Class Initialized
DEBUG - 2020-01-07 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:28 --> Security Class Initialized
INFO - 2020-01-07 17:11:28 --> Security Class Initialized
INFO - 2020-01-07 17:11:28 --> Security Class Initialized
DEBUG - 2020-01-07 17:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:28 --> Input Class Initialized
INFO - 2020-01-07 17:11:28 --> Input Class Initialized
INFO - 2020-01-07 17:11:28 --> Input Class Initialized
DEBUG - 2020-01-07 17:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 17:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:28 --> Input Class Initialized
INFO - 2020-01-07 17:11:28 --> Input Class Initialized
INFO - 2020-01-07 17:11:28 --> Language Class Initialized
INFO - 2020-01-07 17:11:28 --> Language Class Initialized
INFO - 2020-01-07 17:11:28 --> Language Class Initialized
INFO - 2020-01-07 17:11:28 --> Input Class Initialized
INFO - 2020-01-07 17:11:28 --> Language Class Initialized
INFO - 2020-01-07 17:11:28 --> Language Class Initialized
ERROR - 2020-01-07 17:11:28 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 17:11:28 --> Language Class Initialized
ERROR - 2020-01-07 17:11:28 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-01-07 17:11:28 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-01-07 17:11:28 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-01-07 17:11:28 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-07 17:11:28 --> Loader Class Initialized
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:28 --> Helper loaded: url_helper
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:28 --> Database Driver Class Initialized
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:28 --> URI Class Initialized
INFO - 2020-01-07 17:11:28 --> Config Class Initialized
INFO - 2020-01-07 17:11:28 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:28 --> Router Class Initialized
INFO - 2020-01-07 17:11:28 --> Output Class Initialized
DEBUG - 2020-01-07 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 17:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 17:11:28 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:11:28 --> Security Class Initialized
INFO - 2020-01-07 17:11:29 --> Controller Class Initialized
INFO - 2020-01-07 17:11:29 --> URI Class Initialized
DEBUG - 2020-01-07 17:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:29 --> Input Class Initialized
INFO - 2020-01-07 17:11:29 --> Model "M_login" initialized
INFO - 2020-01-07 17:11:29 --> Router Class Initialized
INFO - 2020-01-07 17:11:29 --> Model "M_tiket" initialized
INFO - 2020-01-07 17:11:29 --> Language Class Initialized
INFO - 2020-01-07 17:11:29 --> Output Class Initialized
INFO - 2020-01-07 17:11:29 --> Security Class Initialized
INFO - 2020-01-07 17:11:29 --> Loader Class Initialized
INFO - 2020-01-07 17:11:29 --> Helper loaded: form_helper
INFO - 2020-01-07 17:11:29 --> Form Validation Class Initialized
INFO - 2020-01-07 17:11:29 --> Helper loaded: url_helper
DEBUG - 2020-01-07 17:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:29 --> Input Class Initialized
INFO - 2020-01-07 17:11:29 --> Database Driver Class Initialized
INFO - 2020-01-07 17:11:29 --> Language Class Initialized
INFO - 2020-01-07 17:11:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
DEBUG - 2020-01-07 17:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-01-07 17:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-01-07 17:11:29 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-01-07 17:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2020-01-07 17:11:29 --> Config Class Initialized
ERROR - 2020-01-07 17:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-07 17:11:29 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 17:11:29 --> Final output sent to browser
DEBUG - 2020-01-07 17:11:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:29 --> Utf8 Class Initialized
DEBUG - 2020-01-07 17:11:29 --> Total execution time: 0.6794
INFO - 2020-01-07 17:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:11:29 --> URI Class Initialized
INFO - 2020-01-07 17:11:29 --> Controller Class Initialized
INFO - 2020-01-07 17:11:29 --> Router Class Initialized
INFO - 2020-01-07 17:11:29 --> Model "M_login" initialized
INFO - 2020-01-07 17:11:29 --> Output Class Initialized
INFO - 2020-01-07 17:11:29 --> Model "M_tiket" initialized
INFO - 2020-01-07 17:11:29 --> Security Class Initialized
DEBUG - 2020-01-07 17:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:29 --> Helper loaded: form_helper
INFO - 2020-01-07 17:11:29 --> Form Validation Class Initialized
INFO - 2020-01-07 17:11:29 --> Input Class Initialized
INFO - 2020-01-07 17:11:29 --> Language Class Initialized
INFO - 2020-01-07 17:11:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-07 17:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-01-07 17:11:29 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-01-07 17:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2020-01-07 17:11:29 --> Config Class Initialized
ERROR - 2020-01-07 17:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-07 17:11:29 --> Hooks Class Initialized
INFO - 2020-01-07 17:11:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 17:11:29 --> Final output sent to browser
DEBUG - 2020-01-07 17:11:29 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 17:11:29 --> Total execution time: 0.6798
INFO - 2020-01-07 17:11:29 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:29 --> URI Class Initialized
INFO - 2020-01-07 17:11:29 --> Router Class Initialized
INFO - 2020-01-07 17:11:29 --> Output Class Initialized
INFO - 2020-01-07 17:11:29 --> Security Class Initialized
DEBUG - 2020-01-07 17:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:29 --> Input Class Initialized
INFO - 2020-01-07 17:11:29 --> Language Class Initialized
ERROR - 2020-01-07 17:11:29 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-01-07 17:11:29 --> Config Class Initialized
INFO - 2020-01-07 17:11:29 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:11:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:29 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:29 --> URI Class Initialized
INFO - 2020-01-07 17:11:29 --> Router Class Initialized
INFO - 2020-01-07 17:11:29 --> Output Class Initialized
INFO - 2020-01-07 17:11:29 --> Security Class Initialized
DEBUG - 2020-01-07 17:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:29 --> Input Class Initialized
INFO - 2020-01-07 17:11:29 --> Language Class Initialized
ERROR - 2020-01-07 17:11:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-01-07 17:11:29 --> Config Class Initialized
INFO - 2020-01-07 17:11:29 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:11:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:29 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:30 --> URI Class Initialized
INFO - 2020-01-07 17:11:30 --> Router Class Initialized
INFO - 2020-01-07 17:11:30 --> Output Class Initialized
INFO - 2020-01-07 17:11:30 --> Security Class Initialized
DEBUG - 2020-01-07 17:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:30 --> Input Class Initialized
INFO - 2020-01-07 17:11:30 --> Language Class Initialized
ERROR - 2020-01-07 17:11:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 17:11:30 --> Config Class Initialized
INFO - 2020-01-07 17:11:30 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:11:30 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:30 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:30 --> URI Class Initialized
INFO - 2020-01-07 17:11:30 --> Router Class Initialized
INFO - 2020-01-07 17:11:30 --> Output Class Initialized
INFO - 2020-01-07 17:11:30 --> Security Class Initialized
DEBUG - 2020-01-07 17:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:30 --> Input Class Initialized
INFO - 2020-01-07 17:11:30 --> Language Class Initialized
ERROR - 2020-01-07 17:11:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 17:11:30 --> Config Class Initialized
INFO - 2020-01-07 17:11:30 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:11:30 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:30 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:30 --> URI Class Initialized
INFO - 2020-01-07 17:11:30 --> Router Class Initialized
INFO - 2020-01-07 17:11:30 --> Output Class Initialized
INFO - 2020-01-07 17:11:30 --> Security Class Initialized
DEBUG - 2020-01-07 17:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:30 --> Input Class Initialized
INFO - 2020-01-07 17:11:30 --> Language Class Initialized
ERROR - 2020-01-07 17:11:30 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-07 17:11:30 --> Config Class Initialized
INFO - 2020-01-07 17:11:30 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:11:30 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:30 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:30 --> URI Class Initialized
INFO - 2020-01-07 17:11:30 --> Router Class Initialized
INFO - 2020-01-07 17:11:30 --> Output Class Initialized
INFO - 2020-01-07 17:11:30 --> Security Class Initialized
DEBUG - 2020-01-07 17:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:30 --> Input Class Initialized
INFO - 2020-01-07 17:11:30 --> Language Class Initialized
ERROR - 2020-01-07 17:11:30 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-07 17:11:30 --> Config Class Initialized
INFO - 2020-01-07 17:11:30 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:11:30 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:30 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:30 --> URI Class Initialized
INFO - 2020-01-07 17:11:31 --> Router Class Initialized
INFO - 2020-01-07 17:11:31 --> Output Class Initialized
INFO - 2020-01-07 17:11:31 --> Security Class Initialized
DEBUG - 2020-01-07 17:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:31 --> Input Class Initialized
INFO - 2020-01-07 17:11:31 --> Language Class Initialized
ERROR - 2020-01-07 17:11:31 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-07 17:11:31 --> Config Class Initialized
INFO - 2020-01-07 17:11:31 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:11:31 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:11:31 --> Utf8 Class Initialized
INFO - 2020-01-07 17:11:31 --> URI Class Initialized
INFO - 2020-01-07 17:11:31 --> Router Class Initialized
INFO - 2020-01-07 17:11:31 --> Output Class Initialized
INFO - 2020-01-07 17:11:31 --> Security Class Initialized
DEBUG - 2020-01-07 17:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:11:31 --> Input Class Initialized
INFO - 2020-01-07 17:11:31 --> Language Class Initialized
ERROR - 2020-01-07 17:11:31 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-07 17:27:58 --> Config Class Initialized
INFO - 2020-01-07 17:27:58 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:27:58 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:27:58 --> Utf8 Class Initialized
INFO - 2020-01-07 17:27:58 --> URI Class Initialized
INFO - 2020-01-07 17:27:58 --> Router Class Initialized
INFO - 2020-01-07 17:27:58 --> Output Class Initialized
INFO - 2020-01-07 17:27:58 --> Security Class Initialized
DEBUG - 2020-01-07 17:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:27:58 --> Input Class Initialized
INFO - 2020-01-07 17:27:58 --> Language Class Initialized
INFO - 2020-01-07 17:27:58 --> Loader Class Initialized
INFO - 2020-01-07 17:27:58 --> Helper loaded: url_helper
INFO - 2020-01-07 17:27:58 --> Database Driver Class Initialized
DEBUG - 2020-01-07 17:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 17:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:27:58 --> Controller Class Initialized
INFO - 2020-01-07 17:27:58 --> Model "M_login" initialized
INFO - 2020-01-07 17:27:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 17:27:58 --> Pagination Class Initialized
INFO - 2020-01-07 17:27:58 --> Model "M_show" initialized
INFO - 2020-01-07 17:27:58 --> Helper loaded: form_helper
INFO - 2020-01-07 17:27:58 --> Form Validation Class Initialized
INFO - 2020-01-07 17:27:58 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 17:27:58 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-07 17:27:58 --> Final output sent to browser
DEBUG - 2020-01-07 17:27:58 --> Total execution time: 0.7076
INFO - 2020-01-07 17:34:47 --> Config Class Initialized
INFO - 2020-01-07 17:34:47 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:34:47 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:34:47 --> Utf8 Class Initialized
INFO - 2020-01-07 17:34:47 --> URI Class Initialized
DEBUG - 2020-01-07 17:34:48 --> No URI present. Default controller set.
INFO - 2020-01-07 17:34:48 --> Router Class Initialized
INFO - 2020-01-07 17:34:48 --> Output Class Initialized
INFO - 2020-01-07 17:34:48 --> Security Class Initialized
DEBUG - 2020-01-07 17:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:34:48 --> Input Class Initialized
INFO - 2020-01-07 17:34:48 --> Language Class Initialized
INFO - 2020-01-07 17:34:48 --> Loader Class Initialized
INFO - 2020-01-07 17:34:48 --> Helper loaded: url_helper
INFO - 2020-01-07 17:34:48 --> Database Driver Class Initialized
DEBUG - 2020-01-07 17:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 17:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:34:48 --> Controller Class Initialized
INFO - 2020-01-07 17:34:48 --> Model "M_login" initialized
INFO - 2020-01-07 17:34:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2020-01-07 17:34:48 --> Final output sent to browser
DEBUG - 2020-01-07 17:34:48 --> Total execution time: 0.4947
INFO - 2020-01-07 17:34:52 --> Config Class Initialized
INFO - 2020-01-07 17:34:52 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:34:52 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:34:52 --> Utf8 Class Initialized
INFO - 2020-01-07 17:34:52 --> URI Class Initialized
INFO - 2020-01-07 17:34:52 --> Router Class Initialized
INFO - 2020-01-07 17:34:52 --> Output Class Initialized
INFO - 2020-01-07 17:34:52 --> Security Class Initialized
DEBUG - 2020-01-07 17:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:34:53 --> Input Class Initialized
INFO - 2020-01-07 17:34:53 --> Language Class Initialized
INFO - 2020-01-07 17:34:53 --> Loader Class Initialized
INFO - 2020-01-07 17:34:53 --> Helper loaded: url_helper
INFO - 2020-01-07 17:34:53 --> Database Driver Class Initialized
DEBUG - 2020-01-07 17:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 17:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:34:53 --> Controller Class Initialized
INFO - 2020-01-07 17:34:53 --> Model "M_login" initialized
INFO - 2020-01-07 17:34:53 --> Config Class Initialized
INFO - 2020-01-07 17:34:53 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:34:53 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:34:53 --> Utf8 Class Initialized
INFO - 2020-01-07 17:34:53 --> URI Class Initialized
INFO - 2020-01-07 17:34:53 --> Router Class Initialized
INFO - 2020-01-07 17:34:53 --> Output Class Initialized
INFO - 2020-01-07 17:34:53 --> Security Class Initialized
DEBUG - 2020-01-07 17:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:34:53 --> Input Class Initialized
INFO - 2020-01-07 17:34:53 --> Language Class Initialized
INFO - 2020-01-07 17:34:53 --> Loader Class Initialized
INFO - 2020-01-07 17:34:53 --> Helper loaded: url_helper
INFO - 2020-01-07 17:34:53 --> Database Driver Class Initialized
DEBUG - 2020-01-07 17:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 17:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:34:53 --> Controller Class Initialized
INFO - 2020-01-07 17:34:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 17:34:53 --> Pagination Class Initialized
INFO - 2020-01-07 17:34:53 --> Model "M_show" initialized
INFO - 2020-01-07 17:34:53 --> Helper loaded: form_helper
INFO - 2020-01-07 17:34:53 --> Form Validation Class Initialized
INFO - 2020-01-07 17:34:53 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-07 17:34:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Musikologi-1\application\views\admin\Beranda.php 84
ERROR - 2020-01-07 17:34:53 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\Musikologi-1\application\views\admin\Beranda.php 84
INFO - 2020-01-07 17:36:04 --> Config Class Initialized
INFO - 2020-01-07 17:36:04 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:36:04 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:36:04 --> Utf8 Class Initialized
INFO - 2020-01-07 17:36:04 --> URI Class Initialized
INFO - 2020-01-07 17:36:04 --> Router Class Initialized
INFO - 2020-01-07 17:36:04 --> Output Class Initialized
INFO - 2020-01-07 17:36:04 --> Security Class Initialized
DEBUG - 2020-01-07 17:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:36:04 --> Input Class Initialized
INFO - 2020-01-07 17:36:04 --> Language Class Initialized
INFO - 2020-01-07 17:36:05 --> Loader Class Initialized
INFO - 2020-01-07 17:36:05 --> Helper loaded: url_helper
INFO - 2020-01-07 17:36:05 --> Database Driver Class Initialized
DEBUG - 2020-01-07 17:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 17:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:36:05 --> Controller Class Initialized
INFO - 2020-01-07 17:36:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 17:36:05 --> Pagination Class Initialized
INFO - 2020-01-07 17:36:05 --> Model "M_show" initialized
INFO - 2020-01-07 17:36:05 --> Helper loaded: form_helper
INFO - 2020-01-07 17:36:05 --> Form Validation Class Initialized
ERROR - 2020-01-07 17:36:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Musikologi-1\application\controllers\Beranda.php 14
INFO - 2020-01-07 17:36:05 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-07 17:36:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Musikologi-1\application\views\admin\Beranda.php 84
ERROR - 2020-01-07 17:36:05 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\Musikologi-1\application\views\admin\Beranda.php 84
INFO - 2020-01-07 17:39:55 --> Config Class Initialized
INFO - 2020-01-07 17:39:55 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:39:55 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:39:55 --> Utf8 Class Initialized
INFO - 2020-01-07 17:39:55 --> URI Class Initialized
INFO - 2020-01-07 17:39:55 --> Router Class Initialized
INFO - 2020-01-07 17:39:55 --> Output Class Initialized
INFO - 2020-01-07 17:39:55 --> Security Class Initialized
DEBUG - 2020-01-07 17:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:39:55 --> Input Class Initialized
INFO - 2020-01-07 17:39:55 --> Language Class Initialized
INFO - 2020-01-07 17:39:55 --> Loader Class Initialized
INFO - 2020-01-07 17:39:55 --> Helper loaded: url_helper
INFO - 2020-01-07 17:39:55 --> Database Driver Class Initialized
DEBUG - 2020-01-07 17:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 17:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:39:55 --> Controller Class Initialized
INFO - 2020-01-07 17:39:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 17:39:55 --> Pagination Class Initialized
INFO - 2020-01-07 17:39:55 --> Model "M_show" initialized
INFO - 2020-01-07 17:39:55 --> Helper loaded: form_helper
INFO - 2020-01-07 17:39:56 --> Form Validation Class Initialized
INFO - 2020-01-07 17:39:56 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-07 17:39:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Musikologi-1\application\views\admin\Beranda.php 84
ERROR - 2020-01-07 17:39:56 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\Musikologi-1\application\views\admin\Beranda.php 84
INFO - 2020-01-07 17:40:12 --> Config Class Initialized
INFO - 2020-01-07 17:40:12 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:40:12 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:40:12 --> Utf8 Class Initialized
INFO - 2020-01-07 17:40:12 --> URI Class Initialized
INFO - 2020-01-07 17:40:12 --> Router Class Initialized
INFO - 2020-01-07 17:40:12 --> Output Class Initialized
INFO - 2020-01-07 17:40:12 --> Security Class Initialized
DEBUG - 2020-01-07 17:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:40:12 --> Input Class Initialized
INFO - 2020-01-07 17:40:12 --> Language Class Initialized
INFO - 2020-01-07 17:40:12 --> Loader Class Initialized
INFO - 2020-01-07 17:40:12 --> Helper loaded: url_helper
INFO - 2020-01-07 17:40:12 --> Database Driver Class Initialized
DEBUG - 2020-01-07 17:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 17:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:40:12 --> Controller Class Initialized
INFO - 2020-01-07 17:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 17:40:12 --> Pagination Class Initialized
INFO - 2020-01-07 17:40:12 --> Model "M_show" initialized
INFO - 2020-01-07 17:40:12 --> Helper loaded: form_helper
INFO - 2020-01-07 17:40:12 --> Form Validation Class Initialized
INFO - 2020-01-07 17:40:12 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-07 17:40:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Musikologi-1\application\views\admin\Beranda.php 84
ERROR - 2020-01-07 17:40:12 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\Musikologi-1\application\views\admin\Beranda.php 84
INFO - 2020-01-07 17:40:29 --> Config Class Initialized
INFO - 2020-01-07 17:40:29 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:40:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:40:29 --> Utf8 Class Initialized
INFO - 2020-01-07 17:40:29 --> URI Class Initialized
INFO - 2020-01-07 17:40:29 --> Router Class Initialized
INFO - 2020-01-07 17:40:29 --> Output Class Initialized
INFO - 2020-01-07 17:40:29 --> Security Class Initialized
DEBUG - 2020-01-07 17:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:40:29 --> Input Class Initialized
INFO - 2020-01-07 17:40:29 --> Language Class Initialized
INFO - 2020-01-07 17:40:29 --> Loader Class Initialized
INFO - 2020-01-07 17:40:29 --> Helper loaded: url_helper
INFO - 2020-01-07 17:40:29 --> Database Driver Class Initialized
DEBUG - 2020-01-07 17:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 17:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:40:29 --> Controller Class Initialized
INFO - 2020-01-07 17:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 17:40:29 --> Pagination Class Initialized
INFO - 2020-01-07 17:40:29 --> Model "M_show" initialized
INFO - 2020-01-07 17:40:29 --> Helper loaded: form_helper
INFO - 2020-01-07 17:40:29 --> Form Validation Class Initialized
ERROR - 2020-01-07 17:40:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Musikologi-1\application\controllers\Beranda.php 14
INFO - 2020-01-07 17:40:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-07 17:40:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Musikologi-1\application\views\admin\Beranda.php 84
ERROR - 2020-01-07 17:40:29 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\Musikologi-1\application\views\admin\Beranda.php 84
INFO - 2020-01-07 17:42:37 --> Config Class Initialized
INFO - 2020-01-07 17:42:37 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:42:37 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:42:37 --> Utf8 Class Initialized
INFO - 2020-01-07 17:42:37 --> URI Class Initialized
DEBUG - 2020-01-07 17:42:37 --> No URI present. Default controller set.
INFO - 2020-01-07 17:42:37 --> Router Class Initialized
INFO - 2020-01-07 17:42:37 --> Output Class Initialized
INFO - 2020-01-07 17:42:37 --> Security Class Initialized
DEBUG - 2020-01-07 17:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:42:38 --> Input Class Initialized
INFO - 2020-01-07 17:42:38 --> Language Class Initialized
INFO - 2020-01-07 17:42:38 --> Loader Class Initialized
INFO - 2020-01-07 17:42:38 --> Helper loaded: url_helper
INFO - 2020-01-07 17:42:38 --> Database Driver Class Initialized
DEBUG - 2020-01-07 17:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 17:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:42:38 --> Controller Class Initialized
INFO - 2020-01-07 17:42:38 --> Model "M_login" initialized
INFO - 2020-01-07 17:42:38 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2020-01-07 17:42:38 --> Final output sent to browser
DEBUG - 2020-01-07 17:42:38 --> Total execution time: 0.4768
INFO - 2020-01-07 17:42:41 --> Config Class Initialized
INFO - 2020-01-07 17:42:41 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:42:41 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:42:41 --> Utf8 Class Initialized
INFO - 2020-01-07 17:42:41 --> URI Class Initialized
INFO - 2020-01-07 17:42:41 --> Router Class Initialized
INFO - 2020-01-07 17:42:41 --> Output Class Initialized
INFO - 2020-01-07 17:42:41 --> Security Class Initialized
DEBUG - 2020-01-07 17:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:42:41 --> Input Class Initialized
INFO - 2020-01-07 17:42:41 --> Language Class Initialized
INFO - 2020-01-07 17:42:41 --> Loader Class Initialized
INFO - 2020-01-07 17:42:41 --> Helper loaded: url_helper
INFO - 2020-01-07 17:42:41 --> Database Driver Class Initialized
DEBUG - 2020-01-07 17:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 17:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:42:41 --> Controller Class Initialized
INFO - 2020-01-07 17:42:41 --> Model "M_login" initialized
INFO - 2020-01-07 17:42:41 --> Config Class Initialized
INFO - 2020-01-07 17:42:41 --> Hooks Class Initialized
DEBUG - 2020-01-07 17:42:41 --> UTF-8 Support Enabled
INFO - 2020-01-07 17:42:41 --> Utf8 Class Initialized
INFO - 2020-01-07 17:42:41 --> URI Class Initialized
INFO - 2020-01-07 17:42:42 --> Router Class Initialized
INFO - 2020-01-07 17:42:42 --> Output Class Initialized
INFO - 2020-01-07 17:42:42 --> Security Class Initialized
DEBUG - 2020-01-07 17:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 17:42:42 --> Input Class Initialized
INFO - 2020-01-07 17:42:42 --> Language Class Initialized
INFO - 2020-01-07 17:42:42 --> Loader Class Initialized
INFO - 2020-01-07 17:42:42 --> Helper loaded: url_helper
INFO - 2020-01-07 17:42:42 --> Database Driver Class Initialized
DEBUG - 2020-01-07 17:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 17:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 17:42:42 --> Controller Class Initialized
INFO - 2020-01-07 17:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 17:42:42 --> Pagination Class Initialized
INFO - 2020-01-07 17:42:42 --> Model "M_show" initialized
INFO - 2020-01-07 17:42:42 --> Helper loaded: form_helper
INFO - 2020-01-07 17:42:42 --> Form Validation Class Initialized
ERROR - 2020-01-07 17:42:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Musikologi-1\application\controllers\Beranda.php 14
INFO - 2020-01-07 17:42:42 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-07 17:42:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Musikologi-1\application\views\admin\Beranda.php 84
ERROR - 2020-01-07 17:42:42 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\Musikologi-1\application\views\admin\Beranda.php 84
INFO - 2020-01-07 18:00:06 --> Config Class Initialized
INFO - 2020-01-07 18:00:06 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:00:06 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:00:06 --> Utf8 Class Initialized
INFO - 2020-01-07 18:00:06 --> URI Class Initialized
INFO - 2020-01-07 18:00:06 --> Router Class Initialized
INFO - 2020-01-07 18:00:06 --> Output Class Initialized
INFO - 2020-01-07 18:00:06 --> Security Class Initialized
DEBUG - 2020-01-07 18:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:00:06 --> Input Class Initialized
INFO - 2020-01-07 18:00:06 --> Language Class Initialized
ERROR - 2020-01-07 18:00:06 --> 404 Page Not Found: Event/index
INFO - 2020-01-07 18:01:51 --> Config Class Initialized
INFO - 2020-01-07 18:01:52 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:01:52 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:01:52 --> Utf8 Class Initialized
INFO - 2020-01-07 18:01:52 --> URI Class Initialized
INFO - 2020-01-07 18:01:52 --> Router Class Initialized
INFO - 2020-01-07 18:01:52 --> Output Class Initialized
INFO - 2020-01-07 18:01:52 --> Security Class Initialized
DEBUG - 2020-01-07 18:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:01:52 --> Input Class Initialized
INFO - 2020-01-07 18:01:52 --> Language Class Initialized
ERROR - 2020-01-07 18:01:52 --> 404 Page Not Found: Event/event_list
INFO - 2020-01-07 18:04:21 --> Config Class Initialized
INFO - 2020-01-07 18:04:21 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:04:21 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:04:21 --> Utf8 Class Initialized
INFO - 2020-01-07 18:04:21 --> URI Class Initialized
INFO - 2020-01-07 18:04:21 --> Router Class Initialized
INFO - 2020-01-07 18:04:21 --> Output Class Initialized
INFO - 2020-01-07 18:04:21 --> Security Class Initialized
DEBUG - 2020-01-07 18:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:04:21 --> Input Class Initialized
INFO - 2020-01-07 18:04:21 --> Language Class Initialized
ERROR - 2020-01-07 18:04:21 --> 404 Page Not Found: Event/index
INFO - 2020-01-07 18:04:37 --> Config Class Initialized
INFO - 2020-01-07 18:04:37 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:04:37 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:04:37 --> Utf8 Class Initialized
INFO - 2020-01-07 18:04:37 --> URI Class Initialized
INFO - 2020-01-07 18:04:37 --> Router Class Initialized
INFO - 2020-01-07 18:04:37 --> Output Class Initialized
INFO - 2020-01-07 18:04:37 --> Security Class Initialized
DEBUG - 2020-01-07 18:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:04:37 --> Input Class Initialized
INFO - 2020-01-07 18:04:37 --> Language Class Initialized
INFO - 2020-01-07 18:04:37 --> Loader Class Initialized
INFO - 2020-01-07 18:04:37 --> Helper loaded: url_helper
INFO - 2020-01-07 18:04:37 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:04:38 --> Controller Class Initialized
INFO - 2020-01-07 18:04:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:04:38 --> Pagination Class Initialized
INFO - 2020-01-07 18:04:38 --> Model "M_event" initialized
INFO - 2020-01-07 18:04:38 --> Helper loaded: form_helper
INFO - 2020-01-07 18:04:38 --> Form Validation Class Initialized
INFO - 2020-01-07 18:04:38 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:04:38 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:04:38 --> Final output sent to browser
DEBUG - 2020-01-07 18:04:38 --> Total execution time: 0.5180
INFO - 2020-01-07 18:04:38 --> Config Class Initialized
INFO - 2020-01-07 18:04:38 --> Config Class Initialized
INFO - 2020-01-07 18:04:38 --> Hooks Class Initialized
INFO - 2020-01-07 18:04:38 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:04:38 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:04:38 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:04:38 --> Utf8 Class Initialized
INFO - 2020-01-07 18:04:38 --> Utf8 Class Initialized
INFO - 2020-01-07 18:04:38 --> URI Class Initialized
INFO - 2020-01-07 18:04:38 --> URI Class Initialized
INFO - 2020-01-07 18:04:38 --> Router Class Initialized
INFO - 2020-01-07 18:04:38 --> Router Class Initialized
INFO - 2020-01-07 18:04:38 --> Output Class Initialized
INFO - 2020-01-07 18:04:38 --> Output Class Initialized
INFO - 2020-01-07 18:04:38 --> Security Class Initialized
INFO - 2020-01-07 18:04:38 --> Security Class Initialized
DEBUG - 2020-01-07 18:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:04:38 --> Input Class Initialized
INFO - 2020-01-07 18:04:38 --> Input Class Initialized
INFO - 2020-01-07 18:04:38 --> Language Class Initialized
INFO - 2020-01-07 18:04:38 --> Language Class Initialized
ERROR - 2020-01-07 18:04:38 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:04:38 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:09:48 --> Config Class Initialized
INFO - 2020-01-07 18:09:48 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:09:48 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:48 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:48 --> URI Class Initialized
INFO - 2020-01-07 18:09:48 --> Router Class Initialized
INFO - 2020-01-07 18:09:48 --> Output Class Initialized
INFO - 2020-01-07 18:09:48 --> Security Class Initialized
DEBUG - 2020-01-07 18:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:48 --> Input Class Initialized
INFO - 2020-01-07 18:09:48 --> Language Class Initialized
INFO - 2020-01-07 18:09:48 --> Loader Class Initialized
INFO - 2020-01-07 18:09:48 --> Helper loaded: url_helper
INFO - 2020-01-07 18:09:48 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:09:48 --> Controller Class Initialized
INFO - 2020-01-07 18:09:48 --> Model "M_login" initialized
INFO - 2020-01-07 18:09:48 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:09:48 --> Helper loaded: form_helper
INFO - 2020-01-07 18:09:48 --> Form Validation Class Initialized
INFO - 2020-01-07 18:09:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:09:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:09:48 --> Final output sent to browser
DEBUG - 2020-01-07 18:09:48 --> Total execution time: 0.5897
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
INFO - 2020-01-07 18:09:49 --> Language Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-01-07 18:09:49 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
INFO - 2020-01-07 18:09:49 --> Language Class Initialized
INFO - 2020-01-07 18:09:49 --> Language Class Initialized
INFO - 2020-01-07 18:09:49 --> Language Class Initialized
INFO - 2020-01-07 18:09:49 --> Language Class Initialized
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
INFO - 2020-01-07 18:09:49 --> Language Class Initialized
ERROR - 2020-01-07 18:09:49 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-07 18:09:49 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-01-07 18:09:49 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-01-07 18:09:49 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
ERROR - 2020-01-07 18:09:49 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
INFO - 2020-01-07 18:09:49 --> Language Class Initialized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-01-07 18:09:49 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 18:09:49 --> Language Class Initialized
INFO - 2020-01-07 18:09:49 --> Language Class Initialized
INFO - 2020-01-07 18:09:49 --> Language Class Initialized
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
INFO - 2020-01-07 18:09:49 --> Language Class Initialized
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
ERROR - 2020-01-07 18:09:49 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-01-07 18:09:49 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-01-07 18:09:49 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-01-07 18:09:49 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-01-07 18:09:49 --> Language Class Initialized
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
ERROR - 2020-01-07 18:09:49 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Config Class Initialized
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
INFO - 2020-01-07 18:09:49 --> Hooks Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
DEBUG - 2020-01-07 18:09:49 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:49 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> URI Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
INFO - 2020-01-07 18:09:49 --> Router Class Initialized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
INFO - 2020-01-07 18:09:49 --> Output Class Initialized
INFO - 2020-01-07 18:09:49 --> Language Class Initialized
INFO - 2020-01-07 18:09:49 --> Security Class Initialized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:49 --> Input Class Initialized
DEBUG - 2020-01-07 18:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:49 --> Loader Class Initialized
INFO - 2020-01-07 18:09:50 --> Input Class Initialized
INFO - 2020-01-07 18:09:50 --> Language Class Initialized
INFO - 2020-01-07 18:09:50 --> Helper loaded: url_helper
INFO - 2020-01-07 18:09:50 --> Language Class Initialized
INFO - 2020-01-07 18:09:50 --> Loader Class Initialized
INFO - 2020-01-07 18:09:50 --> Database Driver Class Initialized
ERROR - 2020-01-07 18:09:50 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-01-07 18:09:50 --> Helper loaded: url_helper
DEBUG - 2020-01-07 18:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:09:50 --> Database Driver Class Initialized
INFO - 2020-01-07 18:09:50 --> Config Class Initialized
INFO - 2020-01-07 18:09:50 --> Controller Class Initialized
INFO - 2020-01-07 18:09:50 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:09:50 --> Model "M_login" initialized
DEBUG - 2020-01-07 18:09:50 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:50 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:50 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:09:50 --> URI Class Initialized
INFO - 2020-01-07 18:09:50 --> Helper loaded: form_helper
INFO - 2020-01-07 18:09:50 --> Form Validation Class Initialized
INFO - 2020-01-07 18:09:50 --> Router Class Initialized
INFO - 2020-01-07 18:09:50 --> Output Class Initialized
INFO - 2020-01-07 18:09:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-07 18:09:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-07 18:09:50 --> Security Class Initialized
ERROR - 2020-01-07 18:09:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
DEBUG - 2020-01-07 18:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:50 --> Input Class Initialized
ERROR - 2020-01-07 18:09:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-07 18:09:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:09:50 --> Language Class Initialized
INFO - 2020-01-07 18:09:50 --> Final output sent to browser
ERROR - 2020-01-07 18:09:50 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-01-07 18:09:50 --> Total execution time: 0.5930
INFO - 2020-01-07 18:09:50 --> Config Class Initialized
INFO - 2020-01-07 18:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:09:50 --> Controller Class Initialized
INFO - 2020-01-07 18:09:50 --> Hooks Class Initialized
INFO - 2020-01-07 18:09:50 --> Model "M_login" initialized
DEBUG - 2020-01-07 18:09:50 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:50 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:50 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:09:50 --> URI Class Initialized
INFO - 2020-01-07 18:09:50 --> Helper loaded: form_helper
INFO - 2020-01-07 18:09:50 --> Form Validation Class Initialized
INFO - 2020-01-07 18:09:50 --> Router Class Initialized
INFO - 2020-01-07 18:09:50 --> Output Class Initialized
INFO - 2020-01-07 18:09:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-07 18:09:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-07 18:09:50 --> Security Class Initialized
ERROR - 2020-01-07 18:09:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
DEBUG - 2020-01-07 18:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:50 --> Input Class Initialized
ERROR - 2020-01-07 18:09:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-07 18:09:50 --> Language Class Initialized
INFO - 2020-01-07 18:09:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:09:50 --> Final output sent to browser
ERROR - 2020-01-07 18:09:50 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-01-07 18:09:50 --> Total execution time: 0.8209
INFO - 2020-01-07 18:09:50 --> Config Class Initialized
INFO - 2020-01-07 18:09:50 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:09:50 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:50 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:50 --> URI Class Initialized
INFO - 2020-01-07 18:09:50 --> Router Class Initialized
INFO - 2020-01-07 18:09:50 --> Output Class Initialized
INFO - 2020-01-07 18:09:50 --> Security Class Initialized
DEBUG - 2020-01-07 18:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:50 --> Input Class Initialized
INFO - 2020-01-07 18:09:50 --> Language Class Initialized
ERROR - 2020-01-07 18:09:50 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 18:09:50 --> Config Class Initialized
INFO - 2020-01-07 18:09:50 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:09:50 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:51 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:51 --> URI Class Initialized
INFO - 2020-01-07 18:09:51 --> Router Class Initialized
INFO - 2020-01-07 18:09:51 --> Output Class Initialized
INFO - 2020-01-07 18:09:51 --> Security Class Initialized
DEBUG - 2020-01-07 18:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:51 --> Input Class Initialized
INFO - 2020-01-07 18:09:51 --> Language Class Initialized
ERROR - 2020-01-07 18:09:51 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-07 18:09:51 --> Config Class Initialized
INFO - 2020-01-07 18:09:51 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:09:51 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:51 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:51 --> URI Class Initialized
INFO - 2020-01-07 18:09:51 --> Router Class Initialized
INFO - 2020-01-07 18:09:51 --> Output Class Initialized
INFO - 2020-01-07 18:09:51 --> Security Class Initialized
DEBUG - 2020-01-07 18:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:51 --> Input Class Initialized
INFO - 2020-01-07 18:09:51 --> Language Class Initialized
ERROR - 2020-01-07 18:09:51 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-07 18:09:51 --> Config Class Initialized
INFO - 2020-01-07 18:09:51 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:09:51 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:51 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:51 --> URI Class Initialized
INFO - 2020-01-07 18:09:51 --> Router Class Initialized
INFO - 2020-01-07 18:09:51 --> Output Class Initialized
INFO - 2020-01-07 18:09:51 --> Security Class Initialized
DEBUG - 2020-01-07 18:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:51 --> Input Class Initialized
INFO - 2020-01-07 18:09:51 --> Language Class Initialized
ERROR - 2020-01-07 18:09:51 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-07 18:09:51 --> Config Class Initialized
INFO - 2020-01-07 18:09:51 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:09:51 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:51 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:51 --> URI Class Initialized
INFO - 2020-01-07 18:09:51 --> Router Class Initialized
INFO - 2020-01-07 18:09:51 --> Output Class Initialized
INFO - 2020-01-07 18:09:52 --> Security Class Initialized
DEBUG - 2020-01-07 18:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:52 --> Input Class Initialized
INFO - 2020-01-07 18:09:52 --> Language Class Initialized
ERROR - 2020-01-07 18:09:52 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-07 18:09:58 --> Config Class Initialized
INFO - 2020-01-07 18:09:58 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:09:58 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:09:58 --> Utf8 Class Initialized
INFO - 2020-01-07 18:09:58 --> URI Class Initialized
INFO - 2020-01-07 18:09:58 --> Router Class Initialized
INFO - 2020-01-07 18:09:58 --> Output Class Initialized
INFO - 2020-01-07 18:09:59 --> Security Class Initialized
DEBUG - 2020-01-07 18:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:09:59 --> Input Class Initialized
INFO - 2020-01-07 18:09:59 --> Language Class Initialized
INFO - 2020-01-07 18:09:59 --> Loader Class Initialized
INFO - 2020-01-07 18:09:59 --> Helper loaded: url_helper
INFO - 2020-01-07 18:09:59 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:09:59 --> Controller Class Initialized
INFO - 2020-01-07 18:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:09:59 --> Pagination Class Initialized
INFO - 2020-01-07 18:09:59 --> Model "M_event" initialized
INFO - 2020-01-07 18:09:59 --> Helper loaded: form_helper
INFO - 2020-01-07 18:09:59 --> Form Validation Class Initialized
INFO - 2020-01-07 18:09:59 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:09:59 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:09:59 --> Final output sent to browser
DEBUG - 2020-01-07 18:09:59 --> Total execution time: 0.6785
INFO - 2020-01-07 18:14:33 --> Config Class Initialized
INFO - 2020-01-07 18:14:33 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:14:34 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:14:34 --> Utf8 Class Initialized
INFO - 2020-01-07 18:14:34 --> URI Class Initialized
INFO - 2020-01-07 18:14:34 --> Router Class Initialized
INFO - 2020-01-07 18:14:34 --> Output Class Initialized
INFO - 2020-01-07 18:14:34 --> Security Class Initialized
DEBUG - 2020-01-07 18:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:14:34 --> Input Class Initialized
INFO - 2020-01-07 18:14:34 --> Language Class Initialized
INFO - 2020-01-07 18:14:34 --> Loader Class Initialized
INFO - 2020-01-07 18:14:34 --> Helper loaded: url_helper
INFO - 2020-01-07 18:14:34 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:14:34 --> Controller Class Initialized
INFO - 2020-01-07 18:14:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:14:34 --> Pagination Class Initialized
INFO - 2020-01-07 18:14:34 --> Model "M_event" initialized
INFO - 2020-01-07 18:14:34 --> Helper loaded: form_helper
INFO - 2020-01-07 18:14:34 --> Form Validation Class Initialized
INFO - 2020-01-07 18:14:34 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:14:34 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:14:34 --> Final output sent to browser
DEBUG - 2020-01-07 18:14:34 --> Total execution time: 0.5529
INFO - 2020-01-07 18:14:34 --> Config Class Initialized
INFO - 2020-01-07 18:14:34 --> Config Class Initialized
INFO - 2020-01-07 18:14:34 --> Hooks Class Initialized
INFO - 2020-01-07 18:14:34 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:14:34 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:14:34 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:14:34 --> Utf8 Class Initialized
INFO - 2020-01-07 18:14:34 --> Utf8 Class Initialized
INFO - 2020-01-07 18:14:34 --> URI Class Initialized
INFO - 2020-01-07 18:14:34 --> URI Class Initialized
INFO - 2020-01-07 18:14:34 --> Router Class Initialized
INFO - 2020-01-07 18:14:34 --> Router Class Initialized
INFO - 2020-01-07 18:14:34 --> Output Class Initialized
INFO - 2020-01-07 18:14:34 --> Output Class Initialized
INFO - 2020-01-07 18:14:34 --> Security Class Initialized
INFO - 2020-01-07 18:14:34 --> Security Class Initialized
DEBUG - 2020-01-07 18:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:14:34 --> Input Class Initialized
INFO - 2020-01-07 18:14:34 --> Input Class Initialized
INFO - 2020-01-07 18:14:34 --> Language Class Initialized
INFO - 2020-01-07 18:14:34 --> Language Class Initialized
ERROR - 2020-01-07 18:14:34 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:14:34 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:14:35 --> Config Class Initialized
INFO - 2020-01-07 18:14:35 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:14:35 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:14:35 --> Utf8 Class Initialized
INFO - 2020-01-07 18:14:35 --> URI Class Initialized
INFO - 2020-01-07 18:14:35 --> Router Class Initialized
INFO - 2020-01-07 18:14:35 --> Output Class Initialized
INFO - 2020-01-07 18:14:35 --> Security Class Initialized
DEBUG - 2020-01-07 18:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:14:35 --> Input Class Initialized
INFO - 2020-01-07 18:14:35 --> Language Class Initialized
ERROR - 2020-01-07 18:14:35 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:18:13 --> Config Class Initialized
INFO - 2020-01-07 18:18:13 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:18:13 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:18:13 --> Utf8 Class Initialized
INFO - 2020-01-07 18:18:13 --> URI Class Initialized
INFO - 2020-01-07 18:18:13 --> Router Class Initialized
INFO - 2020-01-07 18:18:13 --> Output Class Initialized
INFO - 2020-01-07 18:18:13 --> Security Class Initialized
DEBUG - 2020-01-07 18:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:18:13 --> Input Class Initialized
INFO - 2020-01-07 18:18:13 --> Language Class Initialized
INFO - 2020-01-07 18:18:13 --> Loader Class Initialized
INFO - 2020-01-07 18:18:13 --> Helper loaded: url_helper
INFO - 2020-01-07 18:18:13 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:18:13 --> Controller Class Initialized
INFO - 2020-01-07 18:18:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:18:13 --> Pagination Class Initialized
INFO - 2020-01-07 18:18:13 --> Model "M_event" initialized
INFO - 2020-01-07 18:18:13 --> Helper loaded: form_helper
INFO - 2020-01-07 18:18:13 --> Form Validation Class Initialized
INFO - 2020-01-07 18:18:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:18:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:18:13 --> Final output sent to browser
DEBUG - 2020-01-07 18:18:13 --> Total execution time: 0.5865
INFO - 2020-01-07 18:18:13 --> Config Class Initialized
INFO - 2020-01-07 18:18:13 --> Hooks Class Initialized
INFO - 2020-01-07 18:18:13 --> Config Class Initialized
DEBUG - 2020-01-07 18:18:13 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:18:13 --> Hooks Class Initialized
INFO - 2020-01-07 18:18:13 --> Utf8 Class Initialized
INFO - 2020-01-07 18:18:13 --> URI Class Initialized
DEBUG - 2020-01-07 18:18:13 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:18:14 --> Utf8 Class Initialized
INFO - 2020-01-07 18:18:14 --> Router Class Initialized
INFO - 2020-01-07 18:18:14 --> URI Class Initialized
INFO - 2020-01-07 18:18:14 --> Router Class Initialized
INFO - 2020-01-07 18:18:14 --> Output Class Initialized
INFO - 2020-01-07 18:18:14 --> Output Class Initialized
INFO - 2020-01-07 18:18:14 --> Security Class Initialized
INFO - 2020-01-07 18:18:14 --> Security Class Initialized
DEBUG - 2020-01-07 18:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:18:14 --> Input Class Initialized
DEBUG - 2020-01-07 18:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:18:14 --> Input Class Initialized
INFO - 2020-01-07 18:18:14 --> Language Class Initialized
INFO - 2020-01-07 18:18:14 --> Language Class Initialized
ERROR - 2020-01-07 18:18:14 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:18:14 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:18:52 --> Config Class Initialized
INFO - 2020-01-07 18:18:52 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:18:52 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:18:52 --> Utf8 Class Initialized
INFO - 2020-01-07 18:18:52 --> URI Class Initialized
INFO - 2020-01-07 18:18:52 --> Router Class Initialized
INFO - 2020-01-07 18:18:52 --> Output Class Initialized
INFO - 2020-01-07 18:18:52 --> Security Class Initialized
DEBUG - 2020-01-07 18:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:18:52 --> Input Class Initialized
INFO - 2020-01-07 18:18:52 --> Language Class Initialized
INFO - 2020-01-07 18:18:52 --> Loader Class Initialized
INFO - 2020-01-07 18:18:53 --> Helper loaded: url_helper
INFO - 2020-01-07 18:18:53 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:18:53 --> Controller Class Initialized
INFO - 2020-01-07 18:18:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:18:53 --> Pagination Class Initialized
INFO - 2020-01-07 18:18:53 --> Model "M_event" initialized
INFO - 2020-01-07 18:18:53 --> Helper loaded: form_helper
INFO - 2020-01-07 18:18:53 --> Form Validation Class Initialized
INFO - 2020-01-07 18:18:53 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:18:53 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:18:53 --> Final output sent to browser
DEBUG - 2020-01-07 18:18:53 --> Total execution time: 0.5572
INFO - 2020-01-07 18:18:53 --> Config Class Initialized
INFO - 2020-01-07 18:18:53 --> Config Class Initialized
INFO - 2020-01-07 18:18:53 --> Hooks Class Initialized
INFO - 2020-01-07 18:18:53 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:18:53 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:18:53 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:18:53 --> Utf8 Class Initialized
INFO - 2020-01-07 18:18:53 --> Utf8 Class Initialized
INFO - 2020-01-07 18:18:53 --> URI Class Initialized
INFO - 2020-01-07 18:18:53 --> URI Class Initialized
INFO - 2020-01-07 18:18:53 --> Router Class Initialized
INFO - 2020-01-07 18:18:53 --> Router Class Initialized
INFO - 2020-01-07 18:18:53 --> Output Class Initialized
INFO - 2020-01-07 18:18:53 --> Output Class Initialized
INFO - 2020-01-07 18:18:53 --> Security Class Initialized
INFO - 2020-01-07 18:18:53 --> Security Class Initialized
DEBUG - 2020-01-07 18:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:18:53 --> Input Class Initialized
INFO - 2020-01-07 18:18:53 --> Input Class Initialized
INFO - 2020-01-07 18:18:53 --> Language Class Initialized
INFO - 2020-01-07 18:18:53 --> Language Class Initialized
ERROR - 2020-01-07 18:18:53 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:18:53 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:23:11 --> Config Class Initialized
INFO - 2020-01-07 18:23:11 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:23:11 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:23:11 --> Utf8 Class Initialized
INFO - 2020-01-07 18:23:11 --> URI Class Initialized
INFO - 2020-01-07 18:23:11 --> Router Class Initialized
INFO - 2020-01-07 18:23:11 --> Output Class Initialized
INFO - 2020-01-07 18:23:11 --> Security Class Initialized
DEBUG - 2020-01-07 18:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:23:11 --> Input Class Initialized
INFO - 2020-01-07 18:23:11 --> Language Class Initialized
INFO - 2020-01-07 18:23:11 --> Loader Class Initialized
INFO - 2020-01-07 18:23:11 --> Helper loaded: url_helper
INFO - 2020-01-07 18:23:11 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:23:11 --> Controller Class Initialized
INFO - 2020-01-07 18:23:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:23:11 --> Pagination Class Initialized
INFO - 2020-01-07 18:23:11 --> Model "M_event" initialized
INFO - 2020-01-07 18:23:11 --> Helper loaded: form_helper
INFO - 2020-01-07 18:23:11 --> Form Validation Class Initialized
INFO - 2020-01-07 18:23:11 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:23:11 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:23:11 --> Final output sent to browser
DEBUG - 2020-01-07 18:23:11 --> Total execution time: 0.5363
INFO - 2020-01-07 18:23:11 --> Config Class Initialized
INFO - 2020-01-07 18:23:11 --> Config Class Initialized
INFO - 2020-01-07 18:23:11 --> Hooks Class Initialized
INFO - 2020-01-07 18:23:11 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:23:11 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:23:11 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:23:11 --> Utf8 Class Initialized
INFO - 2020-01-07 18:23:11 --> Utf8 Class Initialized
INFO - 2020-01-07 18:23:12 --> URI Class Initialized
INFO - 2020-01-07 18:23:12 --> URI Class Initialized
INFO - 2020-01-07 18:23:12 --> Router Class Initialized
INFO - 2020-01-07 18:23:12 --> Router Class Initialized
INFO - 2020-01-07 18:23:12 --> Output Class Initialized
INFO - 2020-01-07 18:23:12 --> Output Class Initialized
INFO - 2020-01-07 18:23:12 --> Security Class Initialized
INFO - 2020-01-07 18:23:12 --> Security Class Initialized
DEBUG - 2020-01-07 18:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:23:12 --> Input Class Initialized
INFO - 2020-01-07 18:23:12 --> Input Class Initialized
INFO - 2020-01-07 18:23:12 --> Language Class Initialized
INFO - 2020-01-07 18:23:12 --> Language Class Initialized
ERROR - 2020-01-07 18:23:12 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:23:12 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:25:50 --> Config Class Initialized
INFO - 2020-01-07 18:25:50 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:25:50 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:25:50 --> Utf8 Class Initialized
INFO - 2020-01-07 18:25:50 --> URI Class Initialized
INFO - 2020-01-07 18:25:50 --> Router Class Initialized
INFO - 2020-01-07 18:25:50 --> Output Class Initialized
INFO - 2020-01-07 18:25:50 --> Security Class Initialized
DEBUG - 2020-01-07 18:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:25:51 --> Input Class Initialized
INFO - 2020-01-07 18:25:51 --> Language Class Initialized
INFO - 2020-01-07 18:25:51 --> Loader Class Initialized
INFO - 2020-01-07 18:25:51 --> Helper loaded: url_helper
INFO - 2020-01-07 18:25:51 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:25:51 --> Controller Class Initialized
INFO - 2020-01-07 18:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:25:51 --> Pagination Class Initialized
INFO - 2020-01-07 18:25:51 --> Model "M_event" initialized
INFO - 2020-01-07 18:25:51 --> Helper loaded: form_helper
INFO - 2020-01-07 18:25:51 --> Form Validation Class Initialized
INFO - 2020-01-07 18:25:51 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:25:51 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:25:51 --> Final output sent to browser
DEBUG - 2020-01-07 18:25:51 --> Total execution time: 0.5603
INFO - 2020-01-07 18:25:51 --> Config Class Initialized
INFO - 2020-01-07 18:25:51 --> Config Class Initialized
INFO - 2020-01-07 18:25:51 --> Hooks Class Initialized
INFO - 2020-01-07 18:25:51 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:25:51 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:25:51 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:25:51 --> Utf8 Class Initialized
INFO - 2020-01-07 18:25:51 --> Utf8 Class Initialized
INFO - 2020-01-07 18:25:51 --> URI Class Initialized
INFO - 2020-01-07 18:25:51 --> URI Class Initialized
INFO - 2020-01-07 18:25:51 --> Router Class Initialized
INFO - 2020-01-07 18:25:51 --> Router Class Initialized
INFO - 2020-01-07 18:25:51 --> Output Class Initialized
INFO - 2020-01-07 18:25:51 --> Output Class Initialized
INFO - 2020-01-07 18:25:51 --> Security Class Initialized
INFO - 2020-01-07 18:25:51 --> Security Class Initialized
DEBUG - 2020-01-07 18:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:25:51 --> Input Class Initialized
INFO - 2020-01-07 18:25:51 --> Input Class Initialized
INFO - 2020-01-07 18:25:51 --> Language Class Initialized
INFO - 2020-01-07 18:25:51 --> Language Class Initialized
ERROR - 2020-01-07 18:25:51 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:25:51 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:26:05 --> Config Class Initialized
INFO - 2020-01-07 18:26:05 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:26:05 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:26:05 --> Utf8 Class Initialized
INFO - 2020-01-07 18:26:05 --> URI Class Initialized
INFO - 2020-01-07 18:26:05 --> Router Class Initialized
INFO - 2020-01-07 18:26:05 --> Output Class Initialized
INFO - 2020-01-07 18:26:05 --> Security Class Initialized
DEBUG - 2020-01-07 18:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:26:05 --> Input Class Initialized
INFO - 2020-01-07 18:26:05 --> Language Class Initialized
INFO - 2020-01-07 18:26:05 --> Loader Class Initialized
INFO - 2020-01-07 18:26:05 --> Helper loaded: url_helper
INFO - 2020-01-07 18:26:05 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:26:05 --> Controller Class Initialized
INFO - 2020-01-07 18:26:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:26:05 --> Pagination Class Initialized
INFO - 2020-01-07 18:26:05 --> Model "M_event" initialized
INFO - 2020-01-07 18:26:05 --> Helper loaded: form_helper
INFO - 2020-01-07 18:26:05 --> Form Validation Class Initialized
INFO - 2020-01-07 18:26:05 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:26:05 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:26:05 --> Final output sent to browser
DEBUG - 2020-01-07 18:26:06 --> Total execution time: 0.5359
INFO - 2020-01-07 18:26:06 --> Config Class Initialized
INFO - 2020-01-07 18:26:06 --> Config Class Initialized
INFO - 2020-01-07 18:26:06 --> Hooks Class Initialized
INFO - 2020-01-07 18:26:06 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:26:06 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:26:06 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:26:06 --> Utf8 Class Initialized
INFO - 2020-01-07 18:26:06 --> Utf8 Class Initialized
INFO - 2020-01-07 18:26:06 --> URI Class Initialized
INFO - 2020-01-07 18:26:06 --> URI Class Initialized
INFO - 2020-01-07 18:26:06 --> Router Class Initialized
INFO - 2020-01-07 18:26:06 --> Router Class Initialized
INFO - 2020-01-07 18:26:06 --> Output Class Initialized
INFO - 2020-01-07 18:26:06 --> Output Class Initialized
INFO - 2020-01-07 18:26:06 --> Security Class Initialized
INFO - 2020-01-07 18:26:06 --> Security Class Initialized
DEBUG - 2020-01-07 18:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:26:06 --> Input Class Initialized
INFO - 2020-01-07 18:26:06 --> Input Class Initialized
INFO - 2020-01-07 18:26:06 --> Language Class Initialized
INFO - 2020-01-07 18:26:06 --> Language Class Initialized
ERROR - 2020-01-07 18:26:06 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:26:06 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:26:06 --> Config Class Initialized
INFO - 2020-01-07 18:26:06 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:26:06 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:26:06 --> Utf8 Class Initialized
INFO - 2020-01-07 18:26:06 --> URI Class Initialized
INFO - 2020-01-07 18:26:06 --> Router Class Initialized
INFO - 2020-01-07 18:26:06 --> Output Class Initialized
INFO - 2020-01-07 18:26:06 --> Security Class Initialized
DEBUG - 2020-01-07 18:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:26:06 --> Input Class Initialized
INFO - 2020-01-07 18:26:06 --> Language Class Initialized
ERROR - 2020-01-07 18:26:06 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:27:37 --> Config Class Initialized
INFO - 2020-01-07 18:27:37 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:27:37 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:27:37 --> Utf8 Class Initialized
INFO - 2020-01-07 18:27:37 --> URI Class Initialized
INFO - 2020-01-07 18:27:37 --> Router Class Initialized
INFO - 2020-01-07 18:27:37 --> Output Class Initialized
INFO - 2020-01-07 18:27:37 --> Security Class Initialized
DEBUG - 2020-01-07 18:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:27:37 --> Input Class Initialized
INFO - 2020-01-07 18:27:37 --> Language Class Initialized
INFO - 2020-01-07 18:27:37 --> Loader Class Initialized
INFO - 2020-01-07 18:27:37 --> Helper loaded: url_helper
INFO - 2020-01-07 18:27:37 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:27:37 --> Controller Class Initialized
INFO - 2020-01-07 18:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:27:37 --> Pagination Class Initialized
INFO - 2020-01-07 18:27:37 --> Model "M_event" initialized
INFO - 2020-01-07 18:27:38 --> Helper loaded: form_helper
INFO - 2020-01-07 18:27:38 --> Form Validation Class Initialized
INFO - 2020-01-07 18:27:38 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:27:38 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:27:38 --> Final output sent to browser
DEBUG - 2020-01-07 18:27:38 --> Total execution time: 0.5616
INFO - 2020-01-07 18:27:38 --> Config Class Initialized
INFO - 2020-01-07 18:27:38 --> Config Class Initialized
INFO - 2020-01-07 18:27:38 --> Hooks Class Initialized
INFO - 2020-01-07 18:27:38 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:27:38 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:27:38 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:27:38 --> Utf8 Class Initialized
INFO - 2020-01-07 18:27:38 --> Utf8 Class Initialized
INFO - 2020-01-07 18:27:38 --> URI Class Initialized
INFO - 2020-01-07 18:27:38 --> URI Class Initialized
INFO - 2020-01-07 18:27:38 --> Router Class Initialized
INFO - 2020-01-07 18:27:38 --> Router Class Initialized
INFO - 2020-01-07 18:27:38 --> Output Class Initialized
INFO - 2020-01-07 18:27:38 --> Output Class Initialized
INFO - 2020-01-07 18:27:38 --> Security Class Initialized
INFO - 2020-01-07 18:27:38 --> Security Class Initialized
DEBUG - 2020-01-07 18:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:27:38 --> Input Class Initialized
INFO - 2020-01-07 18:27:38 --> Input Class Initialized
INFO - 2020-01-07 18:27:38 --> Language Class Initialized
INFO - 2020-01-07 18:27:38 --> Language Class Initialized
ERROR - 2020-01-07 18:27:38 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:27:38 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:27:38 --> Config Class Initialized
INFO - 2020-01-07 18:27:38 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:27:38 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:27:38 --> Utf8 Class Initialized
INFO - 2020-01-07 18:27:38 --> URI Class Initialized
INFO - 2020-01-07 18:27:38 --> Router Class Initialized
INFO - 2020-01-07 18:27:38 --> Output Class Initialized
INFO - 2020-01-07 18:27:38 --> Security Class Initialized
DEBUG - 2020-01-07 18:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:27:38 --> Input Class Initialized
INFO - 2020-01-07 18:27:38 --> Language Class Initialized
ERROR - 2020-01-07 18:27:38 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:27:38 --> Config Class Initialized
INFO - 2020-01-07 18:27:38 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:27:38 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:27:39 --> Utf8 Class Initialized
INFO - 2020-01-07 18:27:39 --> URI Class Initialized
INFO - 2020-01-07 18:27:39 --> Router Class Initialized
INFO - 2020-01-07 18:27:39 --> Output Class Initialized
INFO - 2020-01-07 18:27:39 --> Security Class Initialized
DEBUG - 2020-01-07 18:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:27:39 --> Input Class Initialized
INFO - 2020-01-07 18:27:39 --> Language Class Initialized
ERROR - 2020-01-07 18:27:39 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:28:19 --> Config Class Initialized
INFO - 2020-01-07 18:28:19 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:28:19 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:28:19 --> Utf8 Class Initialized
INFO - 2020-01-07 18:28:19 --> URI Class Initialized
INFO - 2020-01-07 18:28:19 --> Router Class Initialized
INFO - 2020-01-07 18:28:19 --> Output Class Initialized
INFO - 2020-01-07 18:28:19 --> Security Class Initialized
DEBUG - 2020-01-07 18:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:28:19 --> Input Class Initialized
INFO - 2020-01-07 18:28:19 --> Language Class Initialized
INFO - 2020-01-07 18:28:19 --> Loader Class Initialized
INFO - 2020-01-07 18:28:19 --> Helper loaded: url_helper
INFO - 2020-01-07 18:28:19 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:28:19 --> Controller Class Initialized
INFO - 2020-01-07 18:28:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:28:19 --> Pagination Class Initialized
INFO - 2020-01-07 18:28:19 --> Model "M_event" initialized
INFO - 2020-01-07 18:28:19 --> Helper loaded: form_helper
INFO - 2020-01-07 18:28:19 --> Form Validation Class Initialized
INFO - 2020-01-07 18:28:19 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:28:19 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:28:19 --> Final output sent to browser
DEBUG - 2020-01-07 18:28:19 --> Total execution time: 0.5291
INFO - 2020-01-07 18:28:19 --> Config Class Initialized
INFO - 2020-01-07 18:28:19 --> Config Class Initialized
INFO - 2020-01-07 18:28:19 --> Hooks Class Initialized
INFO - 2020-01-07 18:28:19 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:28:19 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:28:19 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:28:19 --> Utf8 Class Initialized
INFO - 2020-01-07 18:28:19 --> Utf8 Class Initialized
INFO - 2020-01-07 18:28:19 --> URI Class Initialized
INFO - 2020-01-07 18:28:19 --> URI Class Initialized
INFO - 2020-01-07 18:28:19 --> Router Class Initialized
INFO - 2020-01-07 18:28:19 --> Router Class Initialized
INFO - 2020-01-07 18:28:20 --> Output Class Initialized
INFO - 2020-01-07 18:28:20 --> Output Class Initialized
INFO - 2020-01-07 18:28:20 --> Security Class Initialized
INFO - 2020-01-07 18:28:20 --> Security Class Initialized
DEBUG - 2020-01-07 18:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:28:20 --> Input Class Initialized
INFO - 2020-01-07 18:28:20 --> Input Class Initialized
INFO - 2020-01-07 18:28:20 --> Language Class Initialized
INFO - 2020-01-07 18:28:20 --> Language Class Initialized
ERROR - 2020-01-07 18:28:20 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:28:20 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:28:20 --> Config Class Initialized
INFO - 2020-01-07 18:28:20 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:28:20 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:28:20 --> Utf8 Class Initialized
INFO - 2020-01-07 18:28:20 --> URI Class Initialized
INFO - 2020-01-07 18:28:20 --> Router Class Initialized
INFO - 2020-01-07 18:28:20 --> Output Class Initialized
INFO - 2020-01-07 18:28:20 --> Security Class Initialized
DEBUG - 2020-01-07 18:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:28:20 --> Input Class Initialized
INFO - 2020-01-07 18:28:20 --> Language Class Initialized
ERROR - 2020-01-07 18:28:20 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:28:25 --> Config Class Initialized
INFO - 2020-01-07 18:28:25 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:28:25 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:28:25 --> Utf8 Class Initialized
INFO - 2020-01-07 18:28:25 --> URI Class Initialized
INFO - 2020-01-07 18:28:25 --> Router Class Initialized
INFO - 2020-01-07 18:28:25 --> Output Class Initialized
INFO - 2020-01-07 18:28:25 --> Security Class Initialized
DEBUG - 2020-01-07 18:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:28:25 --> Input Class Initialized
INFO - 2020-01-07 18:28:25 --> Language Class Initialized
INFO - 2020-01-07 18:28:25 --> Loader Class Initialized
INFO - 2020-01-07 18:28:25 --> Helper loaded: url_helper
INFO - 2020-01-07 18:28:25 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:28:25 --> Controller Class Initialized
INFO - 2020-01-07 18:28:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:28:25 --> Pagination Class Initialized
INFO - 2020-01-07 18:28:25 --> Model "M_event" initialized
INFO - 2020-01-07 18:28:25 --> Helper loaded: form_helper
INFO - 2020-01-07 18:28:25 --> Form Validation Class Initialized
INFO - 2020-01-07 18:28:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:28:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:28:25 --> Final output sent to browser
DEBUG - 2020-01-07 18:28:25 --> Total execution time: 0.5640
INFO - 2020-01-07 18:28:25 --> Config Class Initialized
INFO - 2020-01-07 18:28:25 --> Config Class Initialized
INFO - 2020-01-07 18:28:25 --> Hooks Class Initialized
INFO - 2020-01-07 18:28:25 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:28:25 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:28:25 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:28:25 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:28:25 --> Utf8 Class Initialized
INFO - 2020-01-07 18:28:25 --> URI Class Initialized
INFO - 2020-01-07 18:28:26 --> Router Class Initialized
INFO - 2020-01-07 18:28:26 --> URI Class Initialized
INFO - 2020-01-07 18:28:26 --> Output Class Initialized
INFO - 2020-01-07 18:28:26 --> Router Class Initialized
INFO - 2020-01-07 18:28:26 --> Security Class Initialized
INFO - 2020-01-07 18:28:26 --> Output Class Initialized
DEBUG - 2020-01-07 18:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:28:26 --> Security Class Initialized
INFO - 2020-01-07 18:28:26 --> Input Class Initialized
DEBUG - 2020-01-07 18:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:28:26 --> Input Class Initialized
INFO - 2020-01-07 18:28:26 --> Language Class Initialized
INFO - 2020-01-07 18:28:26 --> Language Class Initialized
ERROR - 2020-01-07 18:28:26 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:28:26 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:28:26 --> Config Class Initialized
INFO - 2020-01-07 18:28:26 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:28:26 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:28:26 --> Utf8 Class Initialized
INFO - 2020-01-07 18:28:26 --> URI Class Initialized
INFO - 2020-01-07 18:28:26 --> Router Class Initialized
INFO - 2020-01-07 18:28:26 --> Output Class Initialized
INFO - 2020-01-07 18:28:26 --> Security Class Initialized
DEBUG - 2020-01-07 18:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:28:26 --> Input Class Initialized
INFO - 2020-01-07 18:28:26 --> Language Class Initialized
ERROR - 2020-01-07 18:28:26 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:28:47 --> Config Class Initialized
INFO - 2020-01-07 18:28:47 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:28:47 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:28:47 --> Utf8 Class Initialized
INFO - 2020-01-07 18:28:47 --> URI Class Initialized
INFO - 2020-01-07 18:28:47 --> Router Class Initialized
INFO - 2020-01-07 18:28:47 --> Output Class Initialized
INFO - 2020-01-07 18:28:47 --> Security Class Initialized
DEBUG - 2020-01-07 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:28:47 --> Input Class Initialized
INFO - 2020-01-07 18:28:48 --> Language Class Initialized
INFO - 2020-01-07 18:28:48 --> Loader Class Initialized
INFO - 2020-01-07 18:28:48 --> Helper loaded: url_helper
INFO - 2020-01-07 18:28:48 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:28:48 --> Controller Class Initialized
INFO - 2020-01-07 18:28:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:28:48 --> Pagination Class Initialized
INFO - 2020-01-07 18:28:48 --> Model "M_event" initialized
INFO - 2020-01-07 18:28:48 --> Helper loaded: form_helper
INFO - 2020-01-07 18:28:48 --> Form Validation Class Initialized
INFO - 2020-01-07 18:28:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:28:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:28:48 --> Final output sent to browser
DEBUG - 2020-01-07 18:28:48 --> Total execution time: 0.5605
INFO - 2020-01-07 18:28:48 --> Config Class Initialized
INFO - 2020-01-07 18:28:48 --> Config Class Initialized
INFO - 2020-01-07 18:28:48 --> Hooks Class Initialized
INFO - 2020-01-07 18:28:48 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:28:48 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:28:48 --> Utf8 Class Initialized
INFO - 2020-01-07 18:28:48 --> Utf8 Class Initialized
INFO - 2020-01-07 18:28:48 --> URI Class Initialized
INFO - 2020-01-07 18:28:48 --> URI Class Initialized
INFO - 2020-01-07 18:28:48 --> Router Class Initialized
INFO - 2020-01-07 18:28:48 --> Router Class Initialized
INFO - 2020-01-07 18:28:48 --> Output Class Initialized
INFO - 2020-01-07 18:28:48 --> Output Class Initialized
INFO - 2020-01-07 18:28:48 --> Security Class Initialized
INFO - 2020-01-07 18:28:48 --> Security Class Initialized
DEBUG - 2020-01-07 18:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:28:48 --> Input Class Initialized
INFO - 2020-01-07 18:28:48 --> Input Class Initialized
INFO - 2020-01-07 18:28:48 --> Language Class Initialized
INFO - 2020-01-07 18:28:48 --> Language Class Initialized
ERROR - 2020-01-07 18:28:48 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:28:48 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:29:02 --> Config Class Initialized
INFO - 2020-01-07 18:29:02 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:29:02 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:29:02 --> Utf8 Class Initialized
INFO - 2020-01-07 18:29:02 --> URI Class Initialized
INFO - 2020-01-07 18:29:02 --> Router Class Initialized
INFO - 2020-01-07 18:29:02 --> Output Class Initialized
INFO - 2020-01-07 18:29:02 --> Security Class Initialized
DEBUG - 2020-01-07 18:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:29:02 --> Input Class Initialized
INFO - 2020-01-07 18:29:02 --> Language Class Initialized
INFO - 2020-01-07 18:29:02 --> Loader Class Initialized
INFO - 2020-01-07 18:29:02 --> Helper loaded: url_helper
INFO - 2020-01-07 18:29:02 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:29:03 --> Controller Class Initialized
INFO - 2020-01-07 18:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:29:03 --> Pagination Class Initialized
INFO - 2020-01-07 18:29:03 --> Model "M_event" initialized
INFO - 2020-01-07 18:29:03 --> Helper loaded: form_helper
INFO - 2020-01-07 18:29:03 --> Form Validation Class Initialized
INFO - 2020-01-07 18:29:03 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:29:03 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:29:03 --> Final output sent to browser
DEBUG - 2020-01-07 18:29:03 --> Total execution time: 0.6682
INFO - 2020-01-07 18:29:06 --> Config Class Initialized
INFO - 2020-01-07 18:29:06 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:29:07 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:29:07 --> Utf8 Class Initialized
INFO - 2020-01-07 18:29:07 --> URI Class Initialized
INFO - 2020-01-07 18:29:07 --> Router Class Initialized
INFO - 2020-01-07 18:29:07 --> Output Class Initialized
INFO - 2020-01-07 18:29:07 --> Security Class Initialized
DEBUG - 2020-01-07 18:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:29:07 --> Input Class Initialized
INFO - 2020-01-07 18:29:07 --> Language Class Initialized
INFO - 2020-01-07 18:29:07 --> Loader Class Initialized
INFO - 2020-01-07 18:29:07 --> Helper loaded: url_helper
INFO - 2020-01-07 18:29:07 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:29:07 --> Controller Class Initialized
INFO - 2020-01-07 18:29:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:29:07 --> Pagination Class Initialized
INFO - 2020-01-07 18:29:07 --> Model "M_event" initialized
INFO - 2020-01-07 18:29:07 --> Helper loaded: form_helper
INFO - 2020-01-07 18:29:07 --> Form Validation Class Initialized
INFO - 2020-01-07 18:29:07 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:29:07 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:29:07 --> Final output sent to browser
DEBUG - 2020-01-07 18:29:07 --> Total execution time: 0.7401
INFO - 2020-01-07 18:32:33 --> Config Class Initialized
INFO - 2020-01-07 18:32:33 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:32:33 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:32:34 --> Utf8 Class Initialized
INFO - 2020-01-07 18:32:34 --> URI Class Initialized
INFO - 2020-01-07 18:32:34 --> Router Class Initialized
INFO - 2020-01-07 18:32:34 --> Output Class Initialized
INFO - 2020-01-07 18:32:34 --> Security Class Initialized
DEBUG - 2020-01-07 18:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:32:34 --> Input Class Initialized
INFO - 2020-01-07 18:32:34 --> Language Class Initialized
INFO - 2020-01-07 18:32:34 --> Loader Class Initialized
INFO - 2020-01-07 18:32:34 --> Helper loaded: url_helper
INFO - 2020-01-07 18:32:34 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:32:34 --> Controller Class Initialized
INFO - 2020-01-07 18:32:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:32:34 --> Pagination Class Initialized
INFO - 2020-01-07 18:32:34 --> Model "M_event" initialized
INFO - 2020-01-07 18:32:34 --> Helper loaded: form_helper
INFO - 2020-01-07 18:32:34 --> Form Validation Class Initialized
ERROR - 2020-01-07 18:32:34 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting end of file C:\xampp\htdocs\Musikologi-1\application\views\admin\event\event_list.php 104
INFO - 2020-01-07 18:33:47 --> Config Class Initialized
INFO - 2020-01-07 18:33:47 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:33:47 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:33:47 --> Utf8 Class Initialized
INFO - 2020-01-07 18:33:47 --> URI Class Initialized
INFO - 2020-01-07 18:33:47 --> Router Class Initialized
INFO - 2020-01-07 18:33:47 --> Output Class Initialized
INFO - 2020-01-07 18:33:47 --> Security Class Initialized
DEBUG - 2020-01-07 18:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:33:47 --> Input Class Initialized
INFO - 2020-01-07 18:33:47 --> Language Class Initialized
INFO - 2020-01-07 18:33:47 --> Loader Class Initialized
INFO - 2020-01-07 18:33:47 --> Helper loaded: url_helper
INFO - 2020-01-07 18:33:47 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:33:47 --> Controller Class Initialized
INFO - 2020-01-07 18:33:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:33:47 --> Pagination Class Initialized
INFO - 2020-01-07 18:33:47 --> Model "M_event" initialized
INFO - 2020-01-07 18:33:47 --> Helper loaded: form_helper
INFO - 2020-01-07 18:33:47 --> Form Validation Class Initialized
INFO - 2020-01-07 18:33:47 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:33:47 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:33:47 --> Final output sent to browser
DEBUG - 2020-01-07 18:33:47 --> Total execution time: 0.5498
INFO - 2020-01-07 18:33:47 --> Config Class Initialized
INFO - 2020-01-07 18:33:47 --> Config Class Initialized
INFO - 2020-01-07 18:33:48 --> Hooks Class Initialized
INFO - 2020-01-07 18:33:48 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:33:48 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:33:48 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:33:48 --> Utf8 Class Initialized
INFO - 2020-01-07 18:33:48 --> Utf8 Class Initialized
INFO - 2020-01-07 18:33:48 --> URI Class Initialized
INFO - 2020-01-07 18:33:48 --> URI Class Initialized
INFO - 2020-01-07 18:33:48 --> Router Class Initialized
INFO - 2020-01-07 18:33:48 --> Router Class Initialized
INFO - 2020-01-07 18:33:48 --> Output Class Initialized
INFO - 2020-01-07 18:33:48 --> Output Class Initialized
INFO - 2020-01-07 18:33:48 --> Security Class Initialized
INFO - 2020-01-07 18:33:48 --> Security Class Initialized
DEBUG - 2020-01-07 18:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:33:48 --> Input Class Initialized
INFO - 2020-01-07 18:33:48 --> Input Class Initialized
INFO - 2020-01-07 18:33:48 --> Language Class Initialized
INFO - 2020-01-07 18:33:48 --> Language Class Initialized
ERROR - 2020-01-07 18:33:48 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:33:48 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:36:06 --> Config Class Initialized
INFO - 2020-01-07 18:36:06 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:36:06 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:06 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:06 --> URI Class Initialized
INFO - 2020-01-07 18:36:06 --> Router Class Initialized
INFO - 2020-01-07 18:36:06 --> Output Class Initialized
INFO - 2020-01-07 18:36:06 --> Security Class Initialized
DEBUG - 2020-01-07 18:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:06 --> Input Class Initialized
INFO - 2020-01-07 18:36:06 --> Language Class Initialized
INFO - 2020-01-07 18:36:06 --> Loader Class Initialized
INFO - 2020-01-07 18:36:06 --> Helper loaded: url_helper
INFO - 2020-01-07 18:36:06 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:36:07 --> Controller Class Initialized
INFO - 2020-01-07 18:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:36:07 --> Pagination Class Initialized
INFO - 2020-01-07 18:36:07 --> Model "M_event" initialized
INFO - 2020-01-07 18:36:07 --> Helper loaded: form_helper
INFO - 2020-01-07 18:36:07 --> Form Validation Class Initialized
ERROR - 2020-01-07 18:36:07 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\xampp\htdocs\Musikologi-1\application\views\admin\event\event_list.php 76
INFO - 2020-01-07 18:36:27 --> Config Class Initialized
INFO - 2020-01-07 18:36:27 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:36:27 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:27 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:27 --> URI Class Initialized
INFO - 2020-01-07 18:36:27 --> Router Class Initialized
INFO - 2020-01-07 18:36:27 --> Output Class Initialized
INFO - 2020-01-07 18:36:27 --> Security Class Initialized
DEBUG - 2020-01-07 18:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:28 --> Input Class Initialized
INFO - 2020-01-07 18:36:28 --> Language Class Initialized
INFO - 2020-01-07 18:36:28 --> Loader Class Initialized
INFO - 2020-01-07 18:36:28 --> Helper loaded: url_helper
INFO - 2020-01-07 18:36:28 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:36:28 --> Controller Class Initialized
INFO - 2020-01-07 18:36:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:36:28 --> Pagination Class Initialized
INFO - 2020-01-07 18:36:28 --> Model "M_event" initialized
INFO - 2020-01-07 18:36:28 --> Helper loaded: form_helper
INFO - 2020-01-07 18:36:28 --> Form Validation Class Initialized
INFO - 2020-01-07 18:36:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:36:28 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:36:28 --> Final output sent to browser
DEBUG - 2020-01-07 18:36:28 --> Total execution time: 0.5423
INFO - 2020-01-07 18:36:28 --> Config Class Initialized
INFO - 2020-01-07 18:36:28 --> Config Class Initialized
INFO - 2020-01-07 18:36:28 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:28 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:36:28 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:36:28 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:28 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:28 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:28 --> URI Class Initialized
INFO - 2020-01-07 18:36:28 --> URI Class Initialized
INFO - 2020-01-07 18:36:28 --> Router Class Initialized
INFO - 2020-01-07 18:36:28 --> Router Class Initialized
INFO - 2020-01-07 18:36:28 --> Output Class Initialized
INFO - 2020-01-07 18:36:28 --> Output Class Initialized
INFO - 2020-01-07 18:36:28 --> Security Class Initialized
INFO - 2020-01-07 18:36:28 --> Security Class Initialized
DEBUG - 2020-01-07 18:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:28 --> Input Class Initialized
INFO - 2020-01-07 18:36:28 --> Input Class Initialized
INFO - 2020-01-07 18:36:28 --> Language Class Initialized
INFO - 2020-01-07 18:36:28 --> Language Class Initialized
ERROR - 2020-01-07 18:36:28 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:36:28 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:36:34 --> Config Class Initialized
INFO - 2020-01-07 18:36:34 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:36:34 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:34 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:34 --> URI Class Initialized
INFO - 2020-01-07 18:36:34 --> Router Class Initialized
INFO - 2020-01-07 18:36:34 --> Output Class Initialized
INFO - 2020-01-07 18:36:34 --> Security Class Initialized
DEBUG - 2020-01-07 18:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:34 --> Input Class Initialized
INFO - 2020-01-07 18:36:34 --> Language Class Initialized
INFO - 2020-01-07 18:36:34 --> Loader Class Initialized
INFO - 2020-01-07 18:36:34 --> Helper loaded: url_helper
INFO - 2020-01-07 18:36:34 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:36:34 --> Controller Class Initialized
INFO - 2020-01-07 18:36:34 --> Model "M_login" initialized
INFO - 2020-01-07 18:36:34 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:36:34 --> Helper loaded: form_helper
INFO - 2020-01-07 18:36:34 --> Form Validation Class Initialized
INFO - 2020-01-07 18:36:34 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:36:34 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:36:34 --> Final output sent to browser
DEBUG - 2020-01-07 18:36:34 --> Total execution time: 0.5827
INFO - 2020-01-07 18:36:34 --> Config Class Initialized
INFO - 2020-01-07 18:36:34 --> Config Class Initialized
INFO - 2020-01-07 18:36:34 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:34 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:34 --> Config Class Initialized
INFO - 2020-01-07 18:36:34 --> Config Class Initialized
INFO - 2020-01-07 18:36:34 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:34 --> Config Class Initialized
DEBUG - 2020-01-07 18:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:36:34 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:34 --> Config Class Initialized
INFO - 2020-01-07 18:36:34 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:34 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:34 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:34 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:34 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:36:34 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:34 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:34 --> URI Class Initialized
INFO - 2020-01-07 18:36:34 --> URI Class Initialized
DEBUG - 2020-01-07 18:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:36:34 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:34 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:34 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:34 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:34 --> Router Class Initialized
INFO - 2020-01-07 18:36:34 --> URI Class Initialized
INFO - 2020-01-07 18:36:34 --> Router Class Initialized
INFO - 2020-01-07 18:36:34 --> URI Class Initialized
INFO - 2020-01-07 18:36:34 --> URI Class Initialized
INFO - 2020-01-07 18:36:34 --> Router Class Initialized
INFO - 2020-01-07 18:36:34 --> URI Class Initialized
INFO - 2020-01-07 18:36:34 --> Output Class Initialized
INFO - 2020-01-07 18:36:34 --> Output Class Initialized
INFO - 2020-01-07 18:36:34 --> Security Class Initialized
INFO - 2020-01-07 18:36:34 --> Router Class Initialized
INFO - 2020-01-07 18:36:34 --> Output Class Initialized
INFO - 2020-01-07 18:36:34 --> Router Class Initialized
INFO - 2020-01-07 18:36:34 --> Security Class Initialized
INFO - 2020-01-07 18:36:34 --> Router Class Initialized
DEBUG - 2020-01-07 18:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:34 --> Security Class Initialized
INFO - 2020-01-07 18:36:34 --> Output Class Initialized
INFO - 2020-01-07 18:36:34 --> Output Class Initialized
INFO - 2020-01-07 18:36:34 --> Output Class Initialized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
INFO - 2020-01-07 18:36:35 --> Security Class Initialized
INFO - 2020-01-07 18:36:35 --> Security Class Initialized
INFO - 2020-01-07 18:36:35 --> Security Class Initialized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
DEBUG - 2020-01-07 18:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
DEBUG - 2020-01-07 18:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
ERROR - 2020-01-07 18:36:35 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-01-07 18:36:35 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
ERROR - 2020-01-07 18:36:35 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
INFO - 2020-01-07 18:36:35 --> Config Class Initialized
INFO - 2020-01-07 18:36:35 --> Config Class Initialized
INFO - 2020-01-07 18:36:35 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:35 --> Hooks Class Initialized
ERROR - 2020-01-07 18:36:35 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-07 18:36:35 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-07 18:36:35 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-01-07 18:36:35 --> Config Class Initialized
INFO - 2020-01-07 18:36:35 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:36:35 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:35 --> Config Class Initialized
INFO - 2020-01-07 18:36:35 --> Config Class Initialized
DEBUG - 2020-01-07 18:36:35 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:35 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:35 --> Config Class Initialized
INFO - 2020-01-07 18:36:35 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:35 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:35 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:35 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:35 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:35 --> URI Class Initialized
INFO - 2020-01-07 18:36:35 --> URI Class Initialized
INFO - 2020-01-07 18:36:35 --> URI Class Initialized
INFO - 2020-01-07 18:36:35 --> Router Class Initialized
INFO - 2020-01-07 18:36:35 --> Router Class Initialized
DEBUG - 2020-01-07 18:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:36:35 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:35 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:35 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:35 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:35 --> Router Class Initialized
INFO - 2020-01-07 18:36:35 --> Output Class Initialized
INFO - 2020-01-07 18:36:35 --> Output Class Initialized
INFO - 2020-01-07 18:36:35 --> URI Class Initialized
INFO - 2020-01-07 18:36:35 --> Security Class Initialized
INFO - 2020-01-07 18:36:35 --> Security Class Initialized
INFO - 2020-01-07 18:36:35 --> Output Class Initialized
INFO - 2020-01-07 18:36:35 --> URI Class Initialized
INFO - 2020-01-07 18:36:35 --> URI Class Initialized
INFO - 2020-01-07 18:36:35 --> Security Class Initialized
INFO - 2020-01-07 18:36:35 --> Router Class Initialized
INFO - 2020-01-07 18:36:35 --> Router Class Initialized
DEBUG - 2020-01-07 18:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:35 --> Router Class Initialized
DEBUG - 2020-01-07 18:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
DEBUG - 2020-01-07 18:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:35 --> Output Class Initialized
INFO - 2020-01-07 18:36:35 --> Output Class Initialized
INFO - 2020-01-07 18:36:35 --> Output Class Initialized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
INFO - 2020-01-07 18:36:35 --> Security Class Initialized
INFO - 2020-01-07 18:36:35 --> Security Class Initialized
INFO - 2020-01-07 18:36:35 --> Security Class Initialized
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
DEBUG - 2020-01-07 18:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-01-07 18:36:35 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-01-07 18:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-01-07 18:36:35 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
ERROR - 2020-01-07 18:36:35 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-07 18:36:35 --> Config Class Initialized
INFO - 2020-01-07 18:36:35 --> Config Class Initialized
INFO - 2020-01-07 18:36:35 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:35 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
ERROR - 2020-01-07 18:36:35 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-07 18:36:35 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-01-07 18:36:35 --> 404 Page Not Found: Bower_components/jquery-i18next
DEBUG - 2020-01-07 18:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:36:35 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:35 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:35 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:35 --> Config Class Initialized
INFO - 2020-01-07 18:36:35 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:35 --> URI Class Initialized
INFO - 2020-01-07 18:36:35 --> URI Class Initialized
INFO - 2020-01-07 18:36:35 --> Router Class Initialized
INFO - 2020-01-07 18:36:35 --> Router Class Initialized
DEBUG - 2020-01-07 18:36:35 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:35 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:35 --> Output Class Initialized
INFO - 2020-01-07 18:36:35 --> Output Class Initialized
INFO - 2020-01-07 18:36:35 --> URI Class Initialized
INFO - 2020-01-07 18:36:35 --> Security Class Initialized
INFO - 2020-01-07 18:36:35 --> Security Class Initialized
DEBUG - 2020-01-07 18:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:35 --> Router Class Initialized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
INFO - 2020-01-07 18:36:35 --> Output Class Initialized
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
INFO - 2020-01-07 18:36:35 --> Security Class Initialized
DEBUG - 2020-01-07 18:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:35 --> Loader Class Initialized
INFO - 2020-01-07 18:36:35 --> Loader Class Initialized
INFO - 2020-01-07 18:36:35 --> Input Class Initialized
INFO - 2020-01-07 18:36:35 --> Helper loaded: url_helper
INFO - 2020-01-07 18:36:35 --> Helper loaded: url_helper
INFO - 2020-01-07 18:36:35 --> Language Class Initialized
INFO - 2020-01-07 18:36:35 --> Database Driver Class Initialized
INFO - 2020-01-07 18:36:35 --> Database Driver Class Initialized
ERROR - 2020-01-07 18:36:35 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-01-07 18:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:36:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-01-07 18:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:36:35 --> Config Class Initialized
INFO - 2020-01-07 18:36:35 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:35 --> Controller Class Initialized
INFO - 2020-01-07 18:36:35 --> Model "M_login" initialized
DEBUG - 2020-01-07 18:36:35 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:35 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:35 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:36:35 --> URI Class Initialized
INFO - 2020-01-07 18:36:35 --> Helper loaded: form_helper
INFO - 2020-01-07 18:36:35 --> Form Validation Class Initialized
INFO - 2020-01-07 18:36:35 --> Router Class Initialized
INFO - 2020-01-07 18:36:35 --> Output Class Initialized
INFO - 2020-01-07 18:36:35 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-07 18:36:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-07 18:36:35 --> Security Class Initialized
ERROR - 2020-01-07 18:36:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
DEBUG - 2020-01-07 18:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:36 --> Input Class Initialized
ERROR - 2020-01-07 18:36:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-07 18:36:36 --> Language Class Initialized
INFO - 2020-01-07 18:36:36 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:36:36 --> Final output sent to browser
ERROR - 2020-01-07 18:36:36 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-01-07 18:36:36 --> Total execution time: 0.6371
INFO - 2020-01-07 18:36:36 --> Config Class Initialized
INFO - 2020-01-07 18:36:36 --> Hooks Class Initialized
INFO - 2020-01-07 18:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:36:36 --> Controller Class Initialized
DEBUG - 2020-01-07 18:36:36 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:36 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:36 --> Model "M_login" initialized
INFO - 2020-01-07 18:36:36 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:36:36 --> URI Class Initialized
INFO - 2020-01-07 18:36:36 --> Router Class Initialized
INFO - 2020-01-07 18:36:36 --> Helper loaded: form_helper
INFO - 2020-01-07 18:36:36 --> Form Validation Class Initialized
INFO - 2020-01-07 18:36:36 --> Output Class Initialized
INFO - 2020-01-07 18:36:36 --> Security Class Initialized
INFO - 2020-01-07 18:36:36 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-07 18:36:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-01-07 18:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:36 --> Input Class Initialized
ERROR - 2020-01-07 18:36:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-01-07 18:36:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-07 18:36:36 --> Language Class Initialized
INFO - 2020-01-07 18:36:36 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-01-07 18:36:36 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-07 18:36:36 --> Final output sent to browser
INFO - 2020-01-07 18:36:36 --> Config Class Initialized
INFO - 2020-01-07 18:36:36 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:36:36 --> Total execution time: 0.9270
DEBUG - 2020-01-07 18:36:36 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:36 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:36 --> URI Class Initialized
INFO - 2020-01-07 18:36:36 --> Router Class Initialized
INFO - 2020-01-07 18:36:36 --> Output Class Initialized
INFO - 2020-01-07 18:36:36 --> Security Class Initialized
DEBUG - 2020-01-07 18:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:36 --> Input Class Initialized
INFO - 2020-01-07 18:36:36 --> Language Class Initialized
ERROR - 2020-01-07 18:36:36 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-07 18:36:36 --> Config Class Initialized
INFO - 2020-01-07 18:36:36 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:36:36 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:36 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:36 --> URI Class Initialized
INFO - 2020-01-07 18:36:36 --> Router Class Initialized
INFO - 2020-01-07 18:36:36 --> Output Class Initialized
INFO - 2020-01-07 18:36:36 --> Security Class Initialized
DEBUG - 2020-01-07 18:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:36 --> Input Class Initialized
INFO - 2020-01-07 18:36:36 --> Language Class Initialized
ERROR - 2020-01-07 18:36:36 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-07 18:36:36 --> Config Class Initialized
INFO - 2020-01-07 18:36:36 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:36:37 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:36:37 --> Utf8 Class Initialized
INFO - 2020-01-07 18:36:37 --> URI Class Initialized
INFO - 2020-01-07 18:36:37 --> Router Class Initialized
INFO - 2020-01-07 18:36:37 --> Output Class Initialized
INFO - 2020-01-07 18:36:37 --> Security Class Initialized
DEBUG - 2020-01-07 18:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:36:37 --> Input Class Initialized
INFO - 2020-01-07 18:36:37 --> Language Class Initialized
ERROR - 2020-01-07 18:36:37 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-07 18:39:31 --> Config Class Initialized
INFO - 2020-01-07 18:39:31 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:39:31 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:39:31 --> Utf8 Class Initialized
INFO - 2020-01-07 18:39:31 --> URI Class Initialized
INFO - 2020-01-07 18:39:31 --> Router Class Initialized
INFO - 2020-01-07 18:39:31 --> Output Class Initialized
INFO - 2020-01-07 18:39:31 --> Security Class Initialized
DEBUG - 2020-01-07 18:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:39:31 --> Input Class Initialized
INFO - 2020-01-07 18:39:31 --> Language Class Initialized
INFO - 2020-01-07 18:39:31 --> Loader Class Initialized
INFO - 2020-01-07 18:39:31 --> Helper loaded: url_helper
INFO - 2020-01-07 18:39:31 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:39:31 --> Controller Class Initialized
INFO - 2020-01-07 18:39:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:39:32 --> Pagination Class Initialized
INFO - 2020-01-07 18:39:32 --> Model "M_event" initialized
INFO - 2020-01-07 18:39:32 --> Helper loaded: form_helper
INFO - 2020-01-07 18:39:32 --> Form Validation Class Initialized
INFO - 2020-01-07 18:39:32 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:39:32 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:39:32 --> Final output sent to browser
DEBUG - 2020-01-07 18:39:32 --> Total execution time: 0.7042
INFO - 2020-01-07 18:41:48 --> Config Class Initialized
INFO - 2020-01-07 18:41:48 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:41:48 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:41:48 --> Utf8 Class Initialized
INFO - 2020-01-07 18:41:48 --> URI Class Initialized
INFO - 2020-01-07 18:41:48 --> Router Class Initialized
INFO - 2020-01-07 18:41:48 --> Output Class Initialized
INFO - 2020-01-07 18:41:48 --> Security Class Initialized
DEBUG - 2020-01-07 18:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:41:48 --> Input Class Initialized
INFO - 2020-01-07 18:41:48 --> Language Class Initialized
INFO - 2020-01-07 18:41:48 --> Loader Class Initialized
INFO - 2020-01-07 18:41:48 --> Helper loaded: url_helper
INFO - 2020-01-07 18:41:48 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:41:48 --> Controller Class Initialized
INFO - 2020-01-07 18:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:41:48 --> Pagination Class Initialized
INFO - 2020-01-07 18:41:48 --> Model "M_event" initialized
INFO - 2020-01-07 18:41:48 --> Helper loaded: form_helper
INFO - 2020-01-07 18:41:48 --> Form Validation Class Initialized
INFO - 2020-01-07 18:41:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:41:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:41:48 --> Final output sent to browser
DEBUG - 2020-01-07 18:41:48 --> Total execution time: 0.5973
INFO - 2020-01-07 18:41:48 --> Config Class Initialized
INFO - 2020-01-07 18:41:48 --> Config Class Initialized
INFO - 2020-01-07 18:41:48 --> Hooks Class Initialized
INFO - 2020-01-07 18:41:48 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:41:48 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:41:48 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:41:48 --> Utf8 Class Initialized
INFO - 2020-01-07 18:41:48 --> Utf8 Class Initialized
INFO - 2020-01-07 18:41:48 --> URI Class Initialized
INFO - 2020-01-07 18:41:48 --> URI Class Initialized
INFO - 2020-01-07 18:41:49 --> Router Class Initialized
INFO - 2020-01-07 18:41:49 --> Router Class Initialized
INFO - 2020-01-07 18:41:49 --> Output Class Initialized
INFO - 2020-01-07 18:41:49 --> Output Class Initialized
INFO - 2020-01-07 18:41:49 --> Security Class Initialized
INFO - 2020-01-07 18:41:49 --> Security Class Initialized
DEBUG - 2020-01-07 18:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:41:49 --> Input Class Initialized
INFO - 2020-01-07 18:41:49 --> Input Class Initialized
INFO - 2020-01-07 18:41:49 --> Language Class Initialized
INFO - 2020-01-07 18:41:49 --> Language Class Initialized
ERROR - 2020-01-07 18:41:49 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:41:49 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:42:28 --> Config Class Initialized
INFO - 2020-01-07 18:42:28 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:42:28 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:42:28 --> Utf8 Class Initialized
INFO - 2020-01-07 18:42:28 --> URI Class Initialized
INFO - 2020-01-07 18:42:28 --> Router Class Initialized
INFO - 2020-01-07 18:42:28 --> Output Class Initialized
INFO - 2020-01-07 18:42:28 --> Security Class Initialized
DEBUG - 2020-01-07 18:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:42:28 --> Input Class Initialized
INFO - 2020-01-07 18:42:28 --> Language Class Initialized
INFO - 2020-01-07 18:42:28 --> Loader Class Initialized
INFO - 2020-01-07 18:42:28 --> Helper loaded: url_helper
INFO - 2020-01-07 18:42:28 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:42:29 --> Controller Class Initialized
INFO - 2020-01-07 18:42:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:42:29 --> Pagination Class Initialized
INFO - 2020-01-07 18:42:29 --> Model "M_event" initialized
INFO - 2020-01-07 18:42:29 --> Helper loaded: form_helper
INFO - 2020-01-07 18:42:29 --> Form Validation Class Initialized
INFO - 2020-01-07 18:42:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:42:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:42:29 --> Final output sent to browser
DEBUG - 2020-01-07 18:42:29 --> Total execution time: 0.5387
INFO - 2020-01-07 18:42:29 --> Config Class Initialized
INFO - 2020-01-07 18:42:29 --> Config Class Initialized
INFO - 2020-01-07 18:42:29 --> Hooks Class Initialized
INFO - 2020-01-07 18:42:29 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:42:29 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:42:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:42:29 --> Utf8 Class Initialized
INFO - 2020-01-07 18:42:29 --> Utf8 Class Initialized
INFO - 2020-01-07 18:42:29 --> URI Class Initialized
INFO - 2020-01-07 18:42:29 --> URI Class Initialized
INFO - 2020-01-07 18:42:29 --> Router Class Initialized
INFO - 2020-01-07 18:42:29 --> Router Class Initialized
INFO - 2020-01-07 18:42:29 --> Output Class Initialized
INFO - 2020-01-07 18:42:29 --> Output Class Initialized
INFO - 2020-01-07 18:42:29 --> Security Class Initialized
INFO - 2020-01-07 18:42:29 --> Security Class Initialized
DEBUG - 2020-01-07 18:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:42:29 --> Input Class Initialized
INFO - 2020-01-07 18:42:29 --> Input Class Initialized
INFO - 2020-01-07 18:42:29 --> Language Class Initialized
INFO - 2020-01-07 18:42:29 --> Language Class Initialized
ERROR - 2020-01-07 18:42:29 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:42:29 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:43:09 --> Config Class Initialized
INFO - 2020-01-07 18:43:09 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:43:09 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:43:09 --> Utf8 Class Initialized
INFO - 2020-01-07 18:43:09 --> URI Class Initialized
INFO - 2020-01-07 18:43:09 --> Router Class Initialized
INFO - 2020-01-07 18:43:09 --> Output Class Initialized
INFO - 2020-01-07 18:43:09 --> Security Class Initialized
DEBUG - 2020-01-07 18:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:43:09 --> Input Class Initialized
INFO - 2020-01-07 18:43:09 --> Language Class Initialized
INFO - 2020-01-07 18:43:09 --> Loader Class Initialized
INFO - 2020-01-07 18:43:09 --> Helper loaded: url_helper
INFO - 2020-01-07 18:43:09 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:43:09 --> Controller Class Initialized
INFO - 2020-01-07 18:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:43:09 --> Pagination Class Initialized
INFO - 2020-01-07 18:43:09 --> Model "M_event" initialized
INFO - 2020-01-07 18:43:09 --> Helper loaded: form_helper
INFO - 2020-01-07 18:43:09 --> Form Validation Class Initialized
INFO - 2020-01-07 18:43:09 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:43:09 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:43:09 --> Final output sent to browser
DEBUG - 2020-01-07 18:43:09 --> Total execution time: 0.5782
INFO - 2020-01-07 18:43:09 --> Config Class Initialized
INFO - 2020-01-07 18:43:09 --> Config Class Initialized
INFO - 2020-01-07 18:43:09 --> Hooks Class Initialized
INFO - 2020-01-07 18:43:09 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:43:10 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:43:10 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:43:10 --> Utf8 Class Initialized
INFO - 2020-01-07 18:43:10 --> Utf8 Class Initialized
INFO - 2020-01-07 18:43:10 --> URI Class Initialized
INFO - 2020-01-07 18:43:10 --> URI Class Initialized
INFO - 2020-01-07 18:43:10 --> Router Class Initialized
INFO - 2020-01-07 18:43:10 --> Router Class Initialized
INFO - 2020-01-07 18:43:10 --> Output Class Initialized
INFO - 2020-01-07 18:43:10 --> Output Class Initialized
INFO - 2020-01-07 18:43:10 --> Security Class Initialized
INFO - 2020-01-07 18:43:10 --> Security Class Initialized
DEBUG - 2020-01-07 18:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:43:10 --> Input Class Initialized
INFO - 2020-01-07 18:43:10 --> Input Class Initialized
INFO - 2020-01-07 18:43:10 --> Language Class Initialized
INFO - 2020-01-07 18:43:10 --> Language Class Initialized
ERROR - 2020-01-07 18:43:10 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:43:10 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:44:01 --> Config Class Initialized
INFO - 2020-01-07 18:44:01 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:44:01 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:44:01 --> Utf8 Class Initialized
INFO - 2020-01-07 18:44:01 --> URI Class Initialized
INFO - 2020-01-07 18:44:01 --> Router Class Initialized
INFO - 2020-01-07 18:44:01 --> Output Class Initialized
INFO - 2020-01-07 18:44:01 --> Security Class Initialized
DEBUG - 2020-01-07 18:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:44:01 --> Input Class Initialized
INFO - 2020-01-07 18:44:01 --> Language Class Initialized
INFO - 2020-01-07 18:44:01 --> Loader Class Initialized
INFO - 2020-01-07 18:44:01 --> Helper loaded: url_helper
INFO - 2020-01-07 18:44:01 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:44:01 --> Controller Class Initialized
INFO - 2020-01-07 18:44:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:44:01 --> Pagination Class Initialized
INFO - 2020-01-07 18:44:01 --> Model "M_event" initialized
INFO - 2020-01-07 18:44:01 --> Helper loaded: form_helper
INFO - 2020-01-07 18:44:01 --> Form Validation Class Initialized
INFO - 2020-01-07 18:44:01 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-07 18:44:01 --> Severity: Notice --> Undefined variable: alcohol C:\xampp\htdocs\Musikologi-1\application\views\admin\event\event_list.php 62
ERROR - 2020-01-07 18:44:01 --> Severity: Notice --> Undefined variable: alcohol C:\xampp\htdocs\Musikologi-1\application\views\admin\event\event_list.php 62
INFO - 2020-01-07 18:44:01 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:44:01 --> Final output sent to browser
DEBUG - 2020-01-07 18:44:01 --> Total execution time: 0.6191
INFO - 2020-01-07 18:44:01 --> Config Class Initialized
INFO - 2020-01-07 18:44:01 --> Config Class Initialized
INFO - 2020-01-07 18:44:01 --> Config Class Initialized
INFO - 2020-01-07 18:44:02 --> Hooks Class Initialized
INFO - 2020-01-07 18:44:02 --> Hooks Class Initialized
INFO - 2020-01-07 18:44:02 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:44:02 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:44:02 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:44:02 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:44:02 --> Utf8 Class Initialized
INFO - 2020-01-07 18:44:02 --> Utf8 Class Initialized
INFO - 2020-01-07 18:44:02 --> Utf8 Class Initialized
INFO - 2020-01-07 18:44:02 --> URI Class Initialized
INFO - 2020-01-07 18:44:02 --> URI Class Initialized
INFO - 2020-01-07 18:44:02 --> Router Class Initialized
INFO - 2020-01-07 18:44:02 --> Router Class Initialized
INFO - 2020-01-07 18:44:02 --> Output Class Initialized
INFO - 2020-01-07 18:44:02 --> Output Class Initialized
INFO - 2020-01-07 18:44:02 --> Security Class Initialized
INFO - 2020-01-07 18:44:02 --> Security Class Initialized
DEBUG - 2020-01-07 18:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:44:02 --> Input Class Initialized
INFO - 2020-01-07 18:44:02 --> Input Class Initialized
INFO - 2020-01-07 18:44:02 --> Language Class Initialized
INFO - 2020-01-07 18:44:02 --> Language Class Initialized
ERROR - 2020-01-07 18:44:02 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:44:02 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:44:02 --> Config Class Initialized
INFO - 2020-01-07 18:44:02 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:44:02 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:44:02 --> Utf8 Class Initialized
INFO - 2020-01-07 18:44:02 --> URI Class Initialized
INFO - 2020-01-07 18:44:02 --> Router Class Initialized
INFO - 2020-01-07 18:44:02 --> Output Class Initialized
INFO - 2020-01-07 18:44:02 --> Security Class Initialized
DEBUG - 2020-01-07 18:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:44:02 --> Input Class Initialized
INFO - 2020-01-07 18:44:02 --> Language Class Initialized
ERROR - 2020-01-07 18:44:02 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:44:29 --> Config Class Initialized
INFO - 2020-01-07 18:44:29 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:44:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:44:29 --> Utf8 Class Initialized
INFO - 2020-01-07 18:44:29 --> URI Class Initialized
INFO - 2020-01-07 18:44:29 --> Router Class Initialized
INFO - 2020-01-07 18:44:29 --> Output Class Initialized
INFO - 2020-01-07 18:44:29 --> Security Class Initialized
DEBUG - 2020-01-07 18:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:44:29 --> Input Class Initialized
INFO - 2020-01-07 18:44:29 --> Language Class Initialized
INFO - 2020-01-07 18:44:29 --> Loader Class Initialized
INFO - 2020-01-07 18:44:29 --> Helper loaded: url_helper
INFO - 2020-01-07 18:44:29 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:44:29 --> Controller Class Initialized
INFO - 2020-01-07 18:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:44:29 --> Pagination Class Initialized
INFO - 2020-01-07 18:44:29 --> Model "M_event" initialized
INFO - 2020-01-07 18:44:30 --> Helper loaded: form_helper
INFO - 2020-01-07 18:44:30 --> Form Validation Class Initialized
INFO - 2020-01-07 18:44:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:44:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:44:30 --> Final output sent to browser
DEBUG - 2020-01-07 18:44:30 --> Total execution time: 0.6081
INFO - 2020-01-07 18:44:30 --> Config Class Initialized
INFO - 2020-01-07 18:44:30 --> Config Class Initialized
INFO - 2020-01-07 18:44:30 --> Config Class Initialized
INFO - 2020-01-07 18:44:30 --> Hooks Class Initialized
INFO - 2020-01-07 18:44:30 --> Hooks Class Initialized
INFO - 2020-01-07 18:44:30 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:44:30 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:44:30 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:44:30 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:44:30 --> Utf8 Class Initialized
INFO - 2020-01-07 18:44:30 --> Utf8 Class Initialized
INFO - 2020-01-07 18:44:30 --> Utf8 Class Initialized
INFO - 2020-01-07 18:44:30 --> URI Class Initialized
INFO - 2020-01-07 18:44:30 --> URI Class Initialized
INFO - 2020-01-07 18:44:30 --> URI Class Initialized
INFO - 2020-01-07 18:44:30 --> Router Class Initialized
INFO - 2020-01-07 18:44:30 --> Router Class Initialized
INFO - 2020-01-07 18:44:30 --> Router Class Initialized
INFO - 2020-01-07 18:44:30 --> Output Class Initialized
INFO - 2020-01-07 18:44:30 --> Output Class Initialized
INFO - 2020-01-07 18:44:30 --> Output Class Initialized
INFO - 2020-01-07 18:44:30 --> Security Class Initialized
INFO - 2020-01-07 18:44:30 --> Security Class Initialized
INFO - 2020-01-07 18:44:30 --> Security Class Initialized
DEBUG - 2020-01-07 18:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:44:30 --> Input Class Initialized
INFO - 2020-01-07 18:44:30 --> Input Class Initialized
INFO - 2020-01-07 18:44:30 --> Input Class Initialized
INFO - 2020-01-07 18:44:30 --> Language Class Initialized
INFO - 2020-01-07 18:44:30 --> Language Class Initialized
INFO - 2020-01-07 18:44:30 --> Language Class Initialized
ERROR - 2020-01-07 18:44:30 --> 404 Page Not Found: Event/msklg.jpg
ERROR - 2020-01-07 18:44:30 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:44:30 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:44:43 --> Config Class Initialized
INFO - 2020-01-07 18:44:43 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:44:43 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:44:43 --> Utf8 Class Initialized
INFO - 2020-01-07 18:44:43 --> URI Class Initialized
INFO - 2020-01-07 18:44:43 --> Router Class Initialized
INFO - 2020-01-07 18:44:43 --> Output Class Initialized
INFO - 2020-01-07 18:44:43 --> Security Class Initialized
DEBUG - 2020-01-07 18:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:44:43 --> Input Class Initialized
INFO - 2020-01-07 18:44:43 --> Language Class Initialized
INFO - 2020-01-07 18:44:43 --> Loader Class Initialized
INFO - 2020-01-07 18:44:43 --> Helper loaded: url_helper
INFO - 2020-01-07 18:44:43 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:44:43 --> Controller Class Initialized
INFO - 2020-01-07 18:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:44:43 --> Pagination Class Initialized
INFO - 2020-01-07 18:44:43 --> Model "M_event" initialized
INFO - 2020-01-07 18:44:43 --> Helper loaded: form_helper
INFO - 2020-01-07 18:44:43 --> Form Validation Class Initialized
INFO - 2020-01-07 18:44:43 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:44:43 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:44:43 --> Final output sent to browser
DEBUG - 2020-01-07 18:44:43 --> Total execution time: 0.5961
INFO - 2020-01-07 18:44:44 --> Config Class Initialized
INFO - 2020-01-07 18:44:44 --> Config Class Initialized
INFO - 2020-01-07 18:44:44 --> Hooks Class Initialized
INFO - 2020-01-07 18:44:44 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:44:44 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:44:44 --> Utf8 Class Initialized
INFO - 2020-01-07 18:44:44 --> Utf8 Class Initialized
INFO - 2020-01-07 18:44:44 --> URI Class Initialized
INFO - 2020-01-07 18:44:44 --> URI Class Initialized
INFO - 2020-01-07 18:44:44 --> Router Class Initialized
INFO - 2020-01-07 18:44:44 --> Router Class Initialized
INFO - 2020-01-07 18:44:44 --> Output Class Initialized
INFO - 2020-01-07 18:44:44 --> Output Class Initialized
INFO - 2020-01-07 18:44:44 --> Security Class Initialized
INFO - 2020-01-07 18:44:44 --> Security Class Initialized
DEBUG - 2020-01-07 18:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:44:44 --> Input Class Initialized
INFO - 2020-01-07 18:44:44 --> Input Class Initialized
INFO - 2020-01-07 18:44:44 --> Language Class Initialized
INFO - 2020-01-07 18:44:44 --> Language Class Initialized
ERROR - 2020-01-07 18:44:44 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:44:44 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:44:55 --> Config Class Initialized
INFO - 2020-01-07 18:44:55 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:44:55 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:44:55 --> Utf8 Class Initialized
INFO - 2020-01-07 18:44:55 --> URI Class Initialized
INFO - 2020-01-07 18:44:55 --> Router Class Initialized
INFO - 2020-01-07 18:44:55 --> Output Class Initialized
INFO - 2020-01-07 18:44:55 --> Security Class Initialized
DEBUG - 2020-01-07 18:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:44:55 --> Input Class Initialized
INFO - 2020-01-07 18:44:55 --> Language Class Initialized
INFO - 2020-01-07 18:44:55 --> Loader Class Initialized
INFO - 2020-01-07 18:44:56 --> Helper loaded: url_helper
INFO - 2020-01-07 18:44:56 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:44:56 --> Controller Class Initialized
INFO - 2020-01-07 18:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:44:56 --> Pagination Class Initialized
INFO - 2020-01-07 18:44:56 --> Model "M_event" initialized
INFO - 2020-01-07 18:44:56 --> Helper loaded: form_helper
INFO - 2020-01-07 18:44:56 --> Form Validation Class Initialized
INFO - 2020-01-07 18:44:56 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:44:56 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:44:56 --> Final output sent to browser
DEBUG - 2020-01-07 18:44:56 --> Total execution time: 0.6932
INFO - 2020-01-07 18:45:55 --> Config Class Initialized
INFO - 2020-01-07 18:45:55 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:45:55 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:45:55 --> Utf8 Class Initialized
INFO - 2020-01-07 18:45:55 --> URI Class Initialized
INFO - 2020-01-07 18:45:55 --> Router Class Initialized
INFO - 2020-01-07 18:45:55 --> Output Class Initialized
INFO - 2020-01-07 18:45:55 --> Security Class Initialized
DEBUG - 2020-01-07 18:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:45:55 --> Input Class Initialized
INFO - 2020-01-07 18:45:55 --> Language Class Initialized
INFO - 2020-01-07 18:45:55 --> Loader Class Initialized
INFO - 2020-01-07 18:45:55 --> Helper loaded: url_helper
INFO - 2020-01-07 18:45:55 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:45:55 --> Controller Class Initialized
INFO - 2020-01-07 18:45:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:45:55 --> Pagination Class Initialized
INFO - 2020-01-07 18:45:55 --> Model "M_event" initialized
INFO - 2020-01-07 18:45:55 --> Helper loaded: form_helper
INFO - 2020-01-07 18:45:56 --> Form Validation Class Initialized
INFO - 2020-01-07 18:45:56 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:45:56 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:45:56 --> Final output sent to browser
DEBUG - 2020-01-07 18:45:56 --> Total execution time: 0.5907
INFO - 2020-01-07 18:45:56 --> Config Class Initialized
INFO - 2020-01-07 18:45:56 --> Config Class Initialized
INFO - 2020-01-07 18:45:56 --> Hooks Class Initialized
INFO - 2020-01-07 18:45:56 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:45:56 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:45:56 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:45:56 --> Utf8 Class Initialized
INFO - 2020-01-07 18:45:56 --> Utf8 Class Initialized
INFO - 2020-01-07 18:45:56 --> URI Class Initialized
INFO - 2020-01-07 18:45:56 --> URI Class Initialized
INFO - 2020-01-07 18:45:56 --> Router Class Initialized
INFO - 2020-01-07 18:45:56 --> Router Class Initialized
INFO - 2020-01-07 18:45:56 --> Output Class Initialized
INFO - 2020-01-07 18:45:56 --> Output Class Initialized
INFO - 2020-01-07 18:45:56 --> Security Class Initialized
INFO - 2020-01-07 18:45:56 --> Security Class Initialized
DEBUG - 2020-01-07 18:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:45:56 --> Input Class Initialized
INFO - 2020-01-07 18:45:56 --> Input Class Initialized
INFO - 2020-01-07 18:45:56 --> Language Class Initialized
INFO - 2020-01-07 18:45:56 --> Language Class Initialized
ERROR - 2020-01-07 18:45:56 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:45:56 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:46:28 --> Config Class Initialized
INFO - 2020-01-07 18:46:28 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:46:28 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:28 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:28 --> URI Class Initialized
INFO - 2020-01-07 18:46:28 --> Router Class Initialized
INFO - 2020-01-07 18:46:29 --> Output Class Initialized
INFO - 2020-01-07 18:46:29 --> Security Class Initialized
DEBUG - 2020-01-07 18:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:29 --> Input Class Initialized
INFO - 2020-01-07 18:46:29 --> Language Class Initialized
INFO - 2020-01-07 18:46:29 --> Loader Class Initialized
INFO - 2020-01-07 18:46:29 --> Helper loaded: url_helper
INFO - 2020-01-07 18:46:29 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:46:29 --> Controller Class Initialized
INFO - 2020-01-07 18:46:29 --> Model "M_login" initialized
INFO - 2020-01-07 18:46:29 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:46:29 --> Helper loaded: form_helper
INFO - 2020-01-07 18:46:29 --> Form Validation Class Initialized
INFO - 2020-01-07 18:46:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:46:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:46:29 --> Final output sent to browser
DEBUG - 2020-01-07 18:46:29 --> Total execution time: 0.6245
INFO - 2020-01-07 18:46:29 --> Config Class Initialized
INFO - 2020-01-07 18:46:29 --> Hooks Class Initialized
INFO - 2020-01-07 18:46:29 --> Config Class Initialized
INFO - 2020-01-07 18:46:29 --> Config Class Initialized
INFO - 2020-01-07 18:46:29 --> Config Class Initialized
INFO - 2020-01-07 18:46:29 --> Hooks Class Initialized
INFO - 2020-01-07 18:46:29 --> Config Class Initialized
INFO - 2020-01-07 18:46:29 --> Hooks Class Initialized
INFO - 2020-01-07 18:46:29 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:46:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:29 --> Config Class Initialized
INFO - 2020-01-07 18:46:29 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:29 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:46:29 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:46:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:29 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:46:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:29 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:29 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:29 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:29 --> URI Class Initialized
INFO - 2020-01-07 18:46:29 --> URI Class Initialized
INFO - 2020-01-07 18:46:29 --> URI Class Initialized
INFO - 2020-01-07 18:46:29 --> URI Class Initialized
DEBUG - 2020-01-07 18:46:29 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:46:29 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:29 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:29 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:29 --> Router Class Initialized
INFO - 2020-01-07 18:46:29 --> URI Class Initialized
INFO - 2020-01-07 18:46:29 --> URI Class Initialized
INFO - 2020-01-07 18:46:29 --> Router Class Initialized
INFO - 2020-01-07 18:46:29 --> Output Class Initialized
INFO - 2020-01-07 18:46:29 --> Router Class Initialized
INFO - 2020-01-07 18:46:29 --> Router Class Initialized
INFO - 2020-01-07 18:46:29 --> Output Class Initialized
INFO - 2020-01-07 18:46:29 --> Router Class Initialized
INFO - 2020-01-07 18:46:29 --> Router Class Initialized
INFO - 2020-01-07 18:46:29 --> Security Class Initialized
INFO - 2020-01-07 18:46:29 --> Output Class Initialized
INFO - 2020-01-07 18:46:29 --> Output Class Initialized
INFO - 2020-01-07 18:46:29 --> Output Class Initialized
INFO - 2020-01-07 18:46:29 --> Security Class Initialized
INFO - 2020-01-07 18:46:29 --> Output Class Initialized
DEBUG - 2020-01-07 18:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:29 --> Security Class Initialized
INFO - 2020-01-07 18:46:29 --> Security Class Initialized
INFO - 2020-01-07 18:46:29 --> Security Class Initialized
INFO - 2020-01-07 18:46:29 --> Security Class Initialized
DEBUG - 2020-01-07 18:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:29 --> Input Class Initialized
INFO - 2020-01-07 18:46:29 --> Input Class Initialized
DEBUG - 2020-01-07 18:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:29 --> Input Class Initialized
INFO - 2020-01-07 18:46:29 --> Input Class Initialized
INFO - 2020-01-07 18:46:29 --> Input Class Initialized
INFO - 2020-01-07 18:46:29 --> Language Class Initialized
INFO - 2020-01-07 18:46:29 --> Input Class Initialized
INFO - 2020-01-07 18:46:29 --> Language Class Initialized
INFO - 2020-01-07 18:46:29 --> Language Class Initialized
INFO - 2020-01-07 18:46:29 --> Language Class Initialized
INFO - 2020-01-07 18:46:29 --> Language Class Initialized
ERROR - 2020-01-07 18:46:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-01-07 18:46:29 --> Language Class Initialized
ERROR - 2020-01-07 18:46:29 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-01-07 18:46:29 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-01-07 18:46:29 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-07 18:46:29 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-07 18:46:29 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-01-07 18:46:29 --> Config Class Initialized
INFO - 2020-01-07 18:46:29 --> Config Class Initialized
INFO - 2020-01-07 18:46:29 --> Hooks Class Initialized
INFO - 2020-01-07 18:46:29 --> Hooks Class Initialized
INFO - 2020-01-07 18:46:29 --> Config Class Initialized
INFO - 2020-01-07 18:46:29 --> Config Class Initialized
INFO - 2020-01-07 18:46:29 --> Config Class Initialized
INFO - 2020-01-07 18:46:30 --> Config Class Initialized
INFO - 2020-01-07 18:46:30 --> Hooks Class Initialized
INFO - 2020-01-07 18:46:30 --> Hooks Class Initialized
INFO - 2020-01-07 18:46:30 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:46:30 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:46:30 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:30 --> Hooks Class Initialized
INFO - 2020-01-07 18:46:30 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:30 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:46:30 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:46:30 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:46:30 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:30 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:30 --> URI Class Initialized
INFO - 2020-01-07 18:46:30 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:30 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:30 --> URI Class Initialized
DEBUG - 2020-01-07 18:46:30 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:30 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:30 --> URI Class Initialized
INFO - 2020-01-07 18:46:30 --> URI Class Initialized
INFO - 2020-01-07 18:46:30 --> URI Class Initialized
INFO - 2020-01-07 18:46:30 --> Router Class Initialized
INFO - 2020-01-07 18:46:30 --> Router Class Initialized
INFO - 2020-01-07 18:46:30 --> Router Class Initialized
INFO - 2020-01-07 18:46:30 --> Output Class Initialized
INFO - 2020-01-07 18:46:30 --> Router Class Initialized
INFO - 2020-01-07 18:46:30 --> URI Class Initialized
INFO - 2020-01-07 18:46:30 --> Output Class Initialized
INFO - 2020-01-07 18:46:30 --> Router Class Initialized
INFO - 2020-01-07 18:46:30 --> Security Class Initialized
INFO - 2020-01-07 18:46:30 --> Security Class Initialized
INFO - 2020-01-07 18:46:30 --> Router Class Initialized
INFO - 2020-01-07 18:46:30 --> Output Class Initialized
INFO - 2020-01-07 18:46:30 --> Output Class Initialized
INFO - 2020-01-07 18:46:30 --> Output Class Initialized
INFO - 2020-01-07 18:46:30 --> Security Class Initialized
DEBUG - 2020-01-07 18:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:30 --> Output Class Initialized
INFO - 2020-01-07 18:46:30 --> Security Class Initialized
DEBUG - 2020-01-07 18:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:30 --> Security Class Initialized
INFO - 2020-01-07 18:46:30 --> Input Class Initialized
DEBUG - 2020-01-07 18:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:30 --> Security Class Initialized
DEBUG - 2020-01-07 18:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:30 --> Input Class Initialized
DEBUG - 2020-01-07 18:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:30 --> Input Class Initialized
INFO - 2020-01-07 18:46:30 --> Input Class Initialized
INFO - 2020-01-07 18:46:30 --> Input Class Initialized
INFO - 2020-01-07 18:46:30 --> Language Class Initialized
INFO - 2020-01-07 18:46:30 --> Language Class Initialized
DEBUG - 2020-01-07 18:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:30 --> Input Class Initialized
INFO - 2020-01-07 18:46:30 --> Language Class Initialized
INFO - 2020-01-07 18:46:30 --> Language Class Initialized
ERROR - 2020-01-07 18:46:30 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-07 18:46:30 --> Language Class Initialized
ERROR - 2020-01-07 18:46:30 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-07 18:46:30 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-01-07 18:46:30 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-01-07 18:46:30 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-07 18:46:30 --> Language Class Initialized
INFO - 2020-01-07 18:46:30 --> Config Class Initialized
INFO - 2020-01-07 18:46:30 --> Config Class Initialized
INFO - 2020-01-07 18:46:30 --> Hooks Class Initialized
INFO - 2020-01-07 18:46:30 --> Hooks Class Initialized
ERROR - 2020-01-07 18:46:30 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-07 18:46:30 --> Config Class Initialized
INFO - 2020-01-07 18:46:30 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:46:30 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:46:30 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:30 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:30 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:46:30 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:30 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:30 --> URI Class Initialized
INFO - 2020-01-07 18:46:30 --> URI Class Initialized
INFO - 2020-01-07 18:46:30 --> URI Class Initialized
INFO - 2020-01-07 18:46:30 --> Router Class Initialized
INFO - 2020-01-07 18:46:30 --> Router Class Initialized
INFO - 2020-01-07 18:46:30 --> Router Class Initialized
INFO - 2020-01-07 18:46:30 --> Output Class Initialized
INFO - 2020-01-07 18:46:30 --> Output Class Initialized
INFO - 2020-01-07 18:46:30 --> Security Class Initialized
INFO - 2020-01-07 18:46:30 --> Security Class Initialized
INFO - 2020-01-07 18:46:30 --> Output Class Initialized
DEBUG - 2020-01-07 18:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:30 --> Security Class Initialized
INFO - 2020-01-07 18:46:30 --> Input Class Initialized
INFO - 2020-01-07 18:46:30 --> Input Class Initialized
DEBUG - 2020-01-07 18:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:30 --> Input Class Initialized
INFO - 2020-01-07 18:46:30 --> Language Class Initialized
INFO - 2020-01-07 18:46:30 --> Language Class Initialized
INFO - 2020-01-07 18:46:30 --> Language Class Initialized
INFO - 2020-01-07 18:46:30 --> Loader Class Initialized
INFO - 2020-01-07 18:46:30 --> Loader Class Initialized
ERROR - 2020-01-07 18:46:30 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-01-07 18:46:30 --> Helper loaded: url_helper
INFO - 2020-01-07 18:46:30 --> Helper loaded: url_helper
INFO - 2020-01-07 18:46:30 --> Database Driver Class Initialized
INFO - 2020-01-07 18:46:30 --> Database Driver Class Initialized
INFO - 2020-01-07 18:46:30 --> Config Class Initialized
INFO - 2020-01-07 18:46:30 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-01-07 18:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:46:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-01-07 18:46:30 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:30 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:30 --> Controller Class Initialized
INFO - 2020-01-07 18:46:30 --> Model "M_login" initialized
INFO - 2020-01-07 18:46:30 --> URI Class Initialized
INFO - 2020-01-07 18:46:30 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:46:30 --> Router Class Initialized
INFO - 2020-01-07 18:46:30 --> Output Class Initialized
INFO - 2020-01-07 18:46:30 --> Helper loaded: form_helper
INFO - 2020-01-07 18:46:30 --> Form Validation Class Initialized
INFO - 2020-01-07 18:46:30 --> Security Class Initialized
DEBUG - 2020-01-07 18:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:46:30 --> Input Class Initialized
ERROR - 2020-01-07 18:46:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-07 18:46:30 --> Language Class Initialized
ERROR - 2020-01-07 18:46:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-01-07 18:46:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
ERROR - 2020-01-07 18:46:30 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-01-07 18:46:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:46:30 --> Config Class Initialized
INFO - 2020-01-07 18:46:30 --> Hooks Class Initialized
INFO - 2020-01-07 18:46:30 --> Final output sent to browser
DEBUG - 2020-01-07 18:46:30 --> Total execution time: 0.6738
DEBUG - 2020-01-07 18:46:31 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:31 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:46:31 --> Controller Class Initialized
INFO - 2020-01-07 18:46:31 --> URI Class Initialized
INFO - 2020-01-07 18:46:31 --> Model "M_login" initialized
INFO - 2020-01-07 18:46:31 --> Router Class Initialized
INFO - 2020-01-07 18:46:31 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:46:31 --> Output Class Initialized
INFO - 2020-01-07 18:46:31 --> Security Class Initialized
INFO - 2020-01-07 18:46:31 --> Helper loaded: form_helper
INFO - 2020-01-07 18:46:31 --> Form Validation Class Initialized
DEBUG - 2020-01-07 18:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:31 --> Input Class Initialized
INFO - 2020-01-07 18:46:31 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:46:31 --> Language Class Initialized
ERROR - 2020-01-07 18:46:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-01-07 18:46:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-01-07 18:46:31 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-07 18:46:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-07 18:46:31 --> Config Class Initialized
INFO - 2020-01-07 18:46:31 --> Hooks Class Initialized
INFO - 2020-01-07 18:46:31 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:46:31 --> Final output sent to browser
DEBUG - 2020-01-07 18:46:31 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:31 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:46:31 --> Total execution time: 0.9717
INFO - 2020-01-07 18:46:31 --> URI Class Initialized
INFO - 2020-01-07 18:46:31 --> Router Class Initialized
INFO - 2020-01-07 18:46:31 --> Output Class Initialized
INFO - 2020-01-07 18:46:31 --> Security Class Initialized
DEBUG - 2020-01-07 18:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:31 --> Input Class Initialized
INFO - 2020-01-07 18:46:31 --> Language Class Initialized
ERROR - 2020-01-07 18:46:31 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 18:46:31 --> Config Class Initialized
INFO - 2020-01-07 18:46:31 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:46:31 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:31 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:31 --> URI Class Initialized
INFO - 2020-01-07 18:46:31 --> Router Class Initialized
INFO - 2020-01-07 18:46:31 --> Output Class Initialized
INFO - 2020-01-07 18:46:31 --> Security Class Initialized
DEBUG - 2020-01-07 18:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:31 --> Input Class Initialized
INFO - 2020-01-07 18:46:31 --> Language Class Initialized
ERROR - 2020-01-07 18:46:31 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-07 18:46:31 --> Config Class Initialized
INFO - 2020-01-07 18:46:31 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:46:31 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:31 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:31 --> URI Class Initialized
INFO - 2020-01-07 18:46:32 --> Router Class Initialized
INFO - 2020-01-07 18:46:32 --> Output Class Initialized
INFO - 2020-01-07 18:46:32 --> Security Class Initialized
DEBUG - 2020-01-07 18:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:32 --> Input Class Initialized
INFO - 2020-01-07 18:46:32 --> Language Class Initialized
ERROR - 2020-01-07 18:46:32 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-07 18:46:32 --> Config Class Initialized
INFO - 2020-01-07 18:46:32 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:46:32 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:32 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:32 --> URI Class Initialized
INFO - 2020-01-07 18:46:32 --> Router Class Initialized
INFO - 2020-01-07 18:46:32 --> Output Class Initialized
INFO - 2020-01-07 18:46:32 --> Security Class Initialized
DEBUG - 2020-01-07 18:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:32 --> Input Class Initialized
INFO - 2020-01-07 18:46:32 --> Language Class Initialized
ERROR - 2020-01-07 18:46:32 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-07 18:46:32 --> Config Class Initialized
INFO - 2020-01-07 18:46:32 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:46:32 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:32 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:32 --> URI Class Initialized
INFO - 2020-01-07 18:46:32 --> Router Class Initialized
INFO - 2020-01-07 18:46:32 --> Output Class Initialized
INFO - 2020-01-07 18:46:32 --> Security Class Initialized
DEBUG - 2020-01-07 18:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:32 --> Input Class Initialized
INFO - 2020-01-07 18:46:32 --> Language Class Initialized
ERROR - 2020-01-07 18:46:32 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-07 18:46:33 --> Config Class Initialized
INFO - 2020-01-07 18:46:33 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:46:33 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:33 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:33 --> URI Class Initialized
INFO - 2020-01-07 18:46:33 --> Router Class Initialized
INFO - 2020-01-07 18:46:33 --> Output Class Initialized
INFO - 2020-01-07 18:46:33 --> Security Class Initialized
DEBUG - 2020-01-07 18:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:33 --> Input Class Initialized
INFO - 2020-01-07 18:46:33 --> Language Class Initialized
INFO - 2020-01-07 18:46:33 --> Loader Class Initialized
INFO - 2020-01-07 18:46:33 --> Helper loaded: url_helper
INFO - 2020-01-07 18:46:33 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:46:33 --> Controller Class Initialized
INFO - 2020-01-07 18:46:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:46:33 --> Pagination Class Initialized
INFO - 2020-01-07 18:46:33 --> Model "M_event" initialized
INFO - 2020-01-07 18:46:33 --> Helper loaded: form_helper
INFO - 2020-01-07 18:46:33 --> Form Validation Class Initialized
INFO - 2020-01-07 18:46:33 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:46:33 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:46:33 --> Final output sent to browser
DEBUG - 2020-01-07 18:46:33 --> Total execution time: 0.6660
INFO - 2020-01-07 18:46:33 --> Config Class Initialized
INFO - 2020-01-07 18:46:33 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:46:33 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:46:33 --> Utf8 Class Initialized
INFO - 2020-01-07 18:46:33 --> URI Class Initialized
INFO - 2020-01-07 18:46:33 --> Router Class Initialized
INFO - 2020-01-07 18:46:34 --> Output Class Initialized
INFO - 2020-01-07 18:46:34 --> Security Class Initialized
DEBUG - 2020-01-07 18:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:46:34 --> Input Class Initialized
INFO - 2020-01-07 18:46:34 --> Language Class Initialized
ERROR - 2020-01-07 18:46:34 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:47:12 --> Config Class Initialized
INFO - 2020-01-07 18:47:12 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:47:12 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:47:12 --> Utf8 Class Initialized
INFO - 2020-01-07 18:47:13 --> URI Class Initialized
INFO - 2020-01-07 18:47:13 --> Router Class Initialized
INFO - 2020-01-07 18:47:13 --> Output Class Initialized
INFO - 2020-01-07 18:47:13 --> Security Class Initialized
DEBUG - 2020-01-07 18:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:47:13 --> Input Class Initialized
INFO - 2020-01-07 18:47:13 --> Language Class Initialized
INFO - 2020-01-07 18:47:13 --> Loader Class Initialized
INFO - 2020-01-07 18:47:13 --> Helper loaded: url_helper
INFO - 2020-01-07 18:47:13 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:47:13 --> Controller Class Initialized
INFO - 2020-01-07 18:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:47:13 --> Pagination Class Initialized
INFO - 2020-01-07 18:47:13 --> Model "M_event" initialized
INFO - 2020-01-07 18:47:13 --> Helper loaded: form_helper
INFO - 2020-01-07 18:47:13 --> Form Validation Class Initialized
INFO - 2020-01-07 18:47:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:47:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:47:13 --> Final output sent to browser
DEBUG - 2020-01-07 18:47:13 --> Total execution time: 0.6177
INFO - 2020-01-07 18:47:13 --> Config Class Initialized
INFO - 2020-01-07 18:47:13 --> Config Class Initialized
INFO - 2020-01-07 18:47:13 --> Hooks Class Initialized
INFO - 2020-01-07 18:47:13 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:47:13 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:47:13 --> Utf8 Class Initialized
INFO - 2020-01-07 18:47:13 --> Utf8 Class Initialized
INFO - 2020-01-07 18:47:13 --> URI Class Initialized
INFO - 2020-01-07 18:47:13 --> URI Class Initialized
INFO - 2020-01-07 18:47:13 --> Router Class Initialized
INFO - 2020-01-07 18:47:13 --> Router Class Initialized
INFO - 2020-01-07 18:47:13 --> Output Class Initialized
INFO - 2020-01-07 18:47:13 --> Output Class Initialized
INFO - 2020-01-07 18:47:13 --> Security Class Initialized
INFO - 2020-01-07 18:47:13 --> Security Class Initialized
DEBUG - 2020-01-07 18:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:47:13 --> Input Class Initialized
INFO - 2020-01-07 18:47:13 --> Input Class Initialized
INFO - 2020-01-07 18:47:14 --> Language Class Initialized
INFO - 2020-01-07 18:47:14 --> Language Class Initialized
ERROR - 2020-01-07 18:47:14 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:47:14 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:47:14 --> Config Class Initialized
INFO - 2020-01-07 18:47:14 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:47:14 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:47:14 --> Utf8 Class Initialized
INFO - 2020-01-07 18:47:14 --> URI Class Initialized
INFO - 2020-01-07 18:47:14 --> Router Class Initialized
INFO - 2020-01-07 18:47:14 --> Output Class Initialized
INFO - 2020-01-07 18:47:14 --> Security Class Initialized
DEBUG - 2020-01-07 18:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:47:14 --> Input Class Initialized
INFO - 2020-01-07 18:47:14 --> Language Class Initialized
ERROR - 2020-01-07 18:47:14 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:47:54 --> Config Class Initialized
INFO - 2020-01-07 18:47:54 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:47:54 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:47:54 --> Utf8 Class Initialized
INFO - 2020-01-07 18:47:54 --> URI Class Initialized
INFO - 2020-01-07 18:47:54 --> Router Class Initialized
INFO - 2020-01-07 18:47:54 --> Output Class Initialized
INFO - 2020-01-07 18:47:54 --> Security Class Initialized
DEBUG - 2020-01-07 18:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:47:54 --> Input Class Initialized
INFO - 2020-01-07 18:47:54 --> Language Class Initialized
INFO - 2020-01-07 18:47:54 --> Loader Class Initialized
INFO - 2020-01-07 18:47:54 --> Helper loaded: url_helper
INFO - 2020-01-07 18:47:54 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:47:55 --> Controller Class Initialized
INFO - 2020-01-07 18:47:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:47:55 --> Pagination Class Initialized
INFO - 2020-01-07 18:47:55 --> Model "M_event" initialized
INFO - 2020-01-07 18:47:55 --> Helper loaded: form_helper
INFO - 2020-01-07 18:47:55 --> Form Validation Class Initialized
INFO - 2020-01-07 18:47:55 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:47:55 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:47:55 --> Final output sent to browser
DEBUG - 2020-01-07 18:47:55 --> Total execution time: 0.6112
INFO - 2020-01-07 18:47:55 --> Config Class Initialized
INFO - 2020-01-07 18:47:55 --> Config Class Initialized
INFO - 2020-01-07 18:47:55 --> Hooks Class Initialized
INFO - 2020-01-07 18:47:55 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:47:55 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:47:55 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:47:55 --> Utf8 Class Initialized
INFO - 2020-01-07 18:47:55 --> Utf8 Class Initialized
INFO - 2020-01-07 18:47:55 --> URI Class Initialized
INFO - 2020-01-07 18:47:55 --> URI Class Initialized
INFO - 2020-01-07 18:47:55 --> Router Class Initialized
INFO - 2020-01-07 18:47:55 --> Router Class Initialized
INFO - 2020-01-07 18:47:55 --> Output Class Initialized
INFO - 2020-01-07 18:47:55 --> Output Class Initialized
INFO - 2020-01-07 18:47:55 --> Security Class Initialized
INFO - 2020-01-07 18:47:55 --> Security Class Initialized
DEBUG - 2020-01-07 18:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:47:55 --> Input Class Initialized
INFO - 2020-01-07 18:47:55 --> Input Class Initialized
INFO - 2020-01-07 18:47:55 --> Language Class Initialized
INFO - 2020-01-07 18:47:55 --> Language Class Initialized
ERROR - 2020-01-07 18:47:55 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:47:55 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:47:55 --> Config Class Initialized
INFO - 2020-01-07 18:47:55 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:47:55 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:47:55 --> Utf8 Class Initialized
INFO - 2020-01-07 18:47:55 --> URI Class Initialized
INFO - 2020-01-07 18:47:55 --> Router Class Initialized
INFO - 2020-01-07 18:47:55 --> Output Class Initialized
INFO - 2020-01-07 18:47:56 --> Security Class Initialized
DEBUG - 2020-01-07 18:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:47:56 --> Input Class Initialized
INFO - 2020-01-07 18:47:56 --> Language Class Initialized
ERROR - 2020-01-07 18:47:56 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:47:59 --> Config Class Initialized
INFO - 2020-01-07 18:47:59 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:47:59 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:47:59 --> Utf8 Class Initialized
INFO - 2020-01-07 18:47:59 --> URI Class Initialized
INFO - 2020-01-07 18:47:59 --> Router Class Initialized
INFO - 2020-01-07 18:47:59 --> Output Class Initialized
INFO - 2020-01-07 18:47:59 --> Security Class Initialized
DEBUG - 2020-01-07 18:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:47:59 --> Input Class Initialized
INFO - 2020-01-07 18:47:59 --> Language Class Initialized
INFO - 2020-01-07 18:47:59 --> Loader Class Initialized
INFO - 2020-01-07 18:48:00 --> Helper loaded: url_helper
INFO - 2020-01-07 18:48:00 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:48:00 --> Controller Class Initialized
INFO - 2020-01-07 18:48:00 --> Model "M_login" initialized
INFO - 2020-01-07 18:48:00 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:48:00 --> Helper loaded: form_helper
INFO - 2020-01-07 18:48:00 --> Form Validation Class Initialized
INFO - 2020-01-07 18:48:00 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:48:00 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:48:00 --> Final output sent to browser
INFO - 2020-01-07 18:48:00 --> Config Class Initialized
DEBUG - 2020-01-07 18:48:00 --> Total execution time: 0.6923
INFO - 2020-01-07 18:48:00 --> Config Class Initialized
INFO - 2020-01-07 18:48:00 --> Config Class Initialized
INFO - 2020-01-07 18:48:00 --> Config Class Initialized
INFO - 2020-01-07 18:48:00 --> Config Class Initialized
INFO - 2020-01-07 18:48:00 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:00 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:00 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:00 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:00 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:00 --> Config Class Initialized
INFO - 2020-01-07 18:48:00 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:48:00 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:48:00 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:00 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:00 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:48:00 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:48:00 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:48:00 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:48:00 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:00 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:00 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:00 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:00 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:00 --> URI Class Initialized
INFO - 2020-01-07 18:48:00 --> URI Class Initialized
INFO - 2020-01-07 18:48:00 --> URI Class Initialized
INFO - 2020-01-07 18:48:00 --> URI Class Initialized
INFO - 2020-01-07 18:48:00 --> Router Class Initialized
INFO - 2020-01-07 18:48:00 --> Router Class Initialized
INFO - 2020-01-07 18:48:00 --> URI Class Initialized
INFO - 2020-01-07 18:48:00 --> URI Class Initialized
INFO - 2020-01-07 18:48:00 --> Router Class Initialized
INFO - 2020-01-07 18:48:00 --> Router Class Initialized
INFO - 2020-01-07 18:48:00 --> Output Class Initialized
INFO - 2020-01-07 18:48:00 --> Router Class Initialized
INFO - 2020-01-07 18:48:00 --> Router Class Initialized
INFO - 2020-01-07 18:48:00 --> Output Class Initialized
INFO - 2020-01-07 18:48:00 --> Security Class Initialized
INFO - 2020-01-07 18:48:00 --> Output Class Initialized
INFO - 2020-01-07 18:48:00 --> Security Class Initialized
INFO - 2020-01-07 18:48:00 --> Output Class Initialized
INFO - 2020-01-07 18:48:00 --> Output Class Initialized
INFO - 2020-01-07 18:48:00 --> Output Class Initialized
DEBUG - 2020-01-07 18:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:00 --> Security Class Initialized
INFO - 2020-01-07 18:48:00 --> Security Class Initialized
INFO - 2020-01-07 18:48:00 --> Security Class Initialized
DEBUG - 2020-01-07 18:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:00 --> Security Class Initialized
INFO - 2020-01-07 18:48:00 --> Input Class Initialized
INFO - 2020-01-07 18:48:00 --> Input Class Initialized
DEBUG - 2020-01-07 18:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:00 --> Input Class Initialized
INFO - 2020-01-07 18:48:00 --> Input Class Initialized
INFO - 2020-01-07 18:48:00 --> Input Class Initialized
INFO - 2020-01-07 18:48:00 --> Language Class Initialized
INFO - 2020-01-07 18:48:00 --> Language Class Initialized
INFO - 2020-01-07 18:48:00 --> Input Class Initialized
INFO - 2020-01-07 18:48:00 --> Language Class Initialized
INFO - 2020-01-07 18:48:00 --> Language Class Initialized
ERROR - 2020-01-07 18:48:00 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-07 18:48:00 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-01-07 18:48:00 --> Language Class Initialized
INFO - 2020-01-07 18:48:00 --> Language Class Initialized
ERROR - 2020-01-07 18:48:00 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-07 18:48:00 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-01-07 18:48:00 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-07 18:48:00 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-01-07 18:48:00 --> Config Class Initialized
INFO - 2020-01-07 18:48:00 --> Config Class Initialized
INFO - 2020-01-07 18:48:00 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:00 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:00 --> Config Class Initialized
INFO - 2020-01-07 18:48:00 --> Config Class Initialized
INFO - 2020-01-07 18:48:00 --> Config Class Initialized
INFO - 2020-01-07 18:48:00 --> Config Class Initialized
INFO - 2020-01-07 18:48:00 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:00 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:00 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:00 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:48:00 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:48:00 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:00 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:48:00 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:48:00 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:00 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:48:00 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:48:00 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:00 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:00 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:00 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:00 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:00 --> URI Class Initialized
INFO - 2020-01-07 18:48:00 --> URI Class Initialized
INFO - 2020-01-07 18:48:00 --> URI Class Initialized
INFO - 2020-01-07 18:48:00 --> URI Class Initialized
INFO - 2020-01-07 18:48:00 --> Router Class Initialized
INFO - 2020-01-07 18:48:00 --> Router Class Initialized
INFO - 2020-01-07 18:48:00 --> URI Class Initialized
INFO - 2020-01-07 18:48:00 --> URI Class Initialized
INFO - 2020-01-07 18:48:01 --> Router Class Initialized
INFO - 2020-01-07 18:48:01 --> Router Class Initialized
INFO - 2020-01-07 18:48:01 --> Router Class Initialized
INFO - 2020-01-07 18:48:01 --> Output Class Initialized
INFO - 2020-01-07 18:48:01 --> Router Class Initialized
INFO - 2020-01-07 18:48:01 --> Output Class Initialized
INFO - 2020-01-07 18:48:01 --> Security Class Initialized
INFO - 2020-01-07 18:48:01 --> Output Class Initialized
INFO - 2020-01-07 18:48:01 --> Output Class Initialized
INFO - 2020-01-07 18:48:01 --> Output Class Initialized
INFO - 2020-01-07 18:48:01 --> Security Class Initialized
INFO - 2020-01-07 18:48:01 --> Output Class Initialized
DEBUG - 2020-01-07 18:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:01 --> Security Class Initialized
INFO - 2020-01-07 18:48:01 --> Security Class Initialized
INFO - 2020-01-07 18:48:01 --> Security Class Initialized
INFO - 2020-01-07 18:48:01 --> Security Class Initialized
DEBUG - 2020-01-07 18:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:01 --> Input Class Initialized
INFO - 2020-01-07 18:48:01 --> Input Class Initialized
DEBUG - 2020-01-07 18:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:01 --> Input Class Initialized
INFO - 2020-01-07 18:48:01 --> Input Class Initialized
INFO - 2020-01-07 18:48:01 --> Input Class Initialized
INFO - 2020-01-07 18:48:01 --> Input Class Initialized
INFO - 2020-01-07 18:48:01 --> Language Class Initialized
INFO - 2020-01-07 18:48:01 --> Language Class Initialized
INFO - 2020-01-07 18:48:01 --> Language Class Initialized
INFO - 2020-01-07 18:48:01 --> Language Class Initialized
ERROR - 2020-01-07 18:48:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 18:48:01 --> Language Class Initialized
INFO - 2020-01-07 18:48:01 --> Language Class Initialized
ERROR - 2020-01-07 18:48:01 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-01-07 18:48:01 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-07 18:48:01 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-01-07 18:48:01 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-01-07 18:48:01 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-07 18:48:01 --> Config Class Initialized
INFO - 2020-01-07 18:48:01 --> Config Class Initialized
INFO - 2020-01-07 18:48:01 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:01 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:01 --> Config Class Initialized
INFO - 2020-01-07 18:48:01 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:48:01 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:48:01 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:01 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:01 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:48:01 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:01 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:01 --> URI Class Initialized
INFO - 2020-01-07 18:48:01 --> URI Class Initialized
INFO - 2020-01-07 18:48:01 --> URI Class Initialized
INFO - 2020-01-07 18:48:01 --> Router Class Initialized
INFO - 2020-01-07 18:48:01 --> Router Class Initialized
INFO - 2020-01-07 18:48:01 --> Router Class Initialized
INFO - 2020-01-07 18:48:01 --> Output Class Initialized
INFO - 2020-01-07 18:48:01 --> Output Class Initialized
INFO - 2020-01-07 18:48:01 --> Security Class Initialized
INFO - 2020-01-07 18:48:01 --> Security Class Initialized
INFO - 2020-01-07 18:48:01 --> Output Class Initialized
DEBUG - 2020-01-07 18:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:01 --> Security Class Initialized
INFO - 2020-01-07 18:48:01 --> Input Class Initialized
INFO - 2020-01-07 18:48:01 --> Input Class Initialized
DEBUG - 2020-01-07 18:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:01 --> Input Class Initialized
INFO - 2020-01-07 18:48:01 --> Language Class Initialized
INFO - 2020-01-07 18:48:01 --> Language Class Initialized
INFO - 2020-01-07 18:48:01 --> Language Class Initialized
INFO - 2020-01-07 18:48:01 --> Loader Class Initialized
INFO - 2020-01-07 18:48:01 --> Loader Class Initialized
ERROR - 2020-01-07 18:48:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-01-07 18:48:01 --> Helper loaded: url_helper
INFO - 2020-01-07 18:48:01 --> Helper loaded: url_helper
INFO - 2020-01-07 18:48:01 --> Database Driver Class Initialized
INFO - 2020-01-07 18:48:01 --> Database Driver Class Initialized
INFO - 2020-01-07 18:48:01 --> Config Class Initialized
INFO - 2020-01-07 18:48:01 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:48:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-01-07 18:48:01 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:01 --> Controller Class Initialized
INFO - 2020-01-07 18:48:01 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:48:01 --> Model "M_login" initialized
INFO - 2020-01-07 18:48:01 --> URI Class Initialized
INFO - 2020-01-07 18:48:01 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:48:01 --> Router Class Initialized
INFO - 2020-01-07 18:48:01 --> Output Class Initialized
INFO - 2020-01-07 18:48:01 --> Helper loaded: form_helper
INFO - 2020-01-07 18:48:01 --> Form Validation Class Initialized
INFO - 2020-01-07 18:48:01 --> Security Class Initialized
DEBUG - 2020-01-07 18:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:01 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:48:01 --> Input Class Initialized
ERROR - 2020-01-07 18:48:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-07 18:48:01 --> Language Class Initialized
ERROR - 2020-01-07 18:48:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-01-07 18:48:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
ERROR - 2020-01-07 18:48:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 18:48:01 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:48:01 --> Config Class Initialized
INFO - 2020-01-07 18:48:01 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:01 --> Final output sent to browser
DEBUG - 2020-01-07 18:48:01 --> Total execution time: 0.7151
DEBUG - 2020-01-07 18:48:01 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:01 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:48:01 --> Controller Class Initialized
INFO - 2020-01-07 18:48:01 --> URI Class Initialized
INFO - 2020-01-07 18:48:02 --> Model "M_login" initialized
INFO - 2020-01-07 18:48:02 --> Router Class Initialized
INFO - 2020-01-07 18:48:02 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:48:02 --> Output Class Initialized
INFO - 2020-01-07 18:48:02 --> Security Class Initialized
INFO - 2020-01-07 18:48:02 --> Helper loaded: form_helper
INFO - 2020-01-07 18:48:02 --> Form Validation Class Initialized
DEBUG - 2020-01-07 18:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:02 --> Input Class Initialized
INFO - 2020-01-07 18:48:02 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:48:02 --> Language Class Initialized
ERROR - 2020-01-07 18:48:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-01-07 18:48:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-01-07 18:48:02 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-07 18:48:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-07 18:48:02 --> Config Class Initialized
INFO - 2020-01-07 18:48:02 --> Hooks Class Initialized
INFO - 2020-01-07 18:48:02 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:48:02 --> Final output sent to browser
DEBUG - 2020-01-07 18:48:02 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:02 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:48:02 --> Total execution time: 1.0374
INFO - 2020-01-07 18:48:02 --> URI Class Initialized
INFO - 2020-01-07 18:48:02 --> Router Class Initialized
INFO - 2020-01-07 18:48:02 --> Output Class Initialized
INFO - 2020-01-07 18:48:02 --> Security Class Initialized
DEBUG - 2020-01-07 18:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:02 --> Input Class Initialized
INFO - 2020-01-07 18:48:02 --> Language Class Initialized
ERROR - 2020-01-07 18:48:02 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-07 18:48:02 --> Config Class Initialized
INFO - 2020-01-07 18:48:02 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:48:02 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:02 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:02 --> URI Class Initialized
INFO - 2020-01-07 18:48:02 --> Router Class Initialized
INFO - 2020-01-07 18:48:02 --> Output Class Initialized
INFO - 2020-01-07 18:48:02 --> Security Class Initialized
DEBUG - 2020-01-07 18:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:02 --> Input Class Initialized
INFO - 2020-01-07 18:48:02 --> Language Class Initialized
ERROR - 2020-01-07 18:48:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-07 18:48:02 --> Config Class Initialized
INFO - 2020-01-07 18:48:02 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:48:02 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:02 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:02 --> URI Class Initialized
INFO - 2020-01-07 18:48:02 --> Router Class Initialized
INFO - 2020-01-07 18:48:02 --> Output Class Initialized
INFO - 2020-01-07 18:48:02 --> Security Class Initialized
DEBUG - 2020-01-07 18:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:03 --> Input Class Initialized
INFO - 2020-01-07 18:48:03 --> Language Class Initialized
ERROR - 2020-01-07 18:48:03 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-07 18:48:03 --> Config Class Initialized
INFO - 2020-01-07 18:48:03 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:48:03 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:03 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:03 --> URI Class Initialized
INFO - 2020-01-07 18:48:03 --> Router Class Initialized
INFO - 2020-01-07 18:48:03 --> Output Class Initialized
INFO - 2020-01-07 18:48:03 --> Security Class Initialized
DEBUG - 2020-01-07 18:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:03 --> Input Class Initialized
INFO - 2020-01-07 18:48:03 --> Language Class Initialized
ERROR - 2020-01-07 18:48:03 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-07 18:48:05 --> Config Class Initialized
INFO - 2020-01-07 18:48:05 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:48:05 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:48:05 --> Utf8 Class Initialized
INFO - 2020-01-07 18:48:05 --> URI Class Initialized
INFO - 2020-01-07 18:48:05 --> Router Class Initialized
INFO - 2020-01-07 18:48:05 --> Output Class Initialized
INFO - 2020-01-07 18:48:05 --> Security Class Initialized
DEBUG - 2020-01-07 18:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:48:05 --> Input Class Initialized
INFO - 2020-01-07 18:48:05 --> Language Class Initialized
INFO - 2020-01-07 18:48:05 --> Loader Class Initialized
INFO - 2020-01-07 18:48:05 --> Helper loaded: url_helper
INFO - 2020-01-07 18:48:05 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:48:05 --> Controller Class Initialized
INFO - 2020-01-07 18:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:48:05 --> Pagination Class Initialized
INFO - 2020-01-07 18:48:05 --> Model "M_event" initialized
INFO - 2020-01-07 18:48:05 --> Helper loaded: form_helper
INFO - 2020-01-07 18:48:05 --> Form Validation Class Initialized
INFO - 2020-01-07 18:48:05 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:48:05 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:48:05 --> Final output sent to browser
DEBUG - 2020-01-07 18:48:05 --> Total execution time: 0.7618
INFO - 2020-01-07 18:53:12 --> Config Class Initialized
INFO - 2020-01-07 18:53:12 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:53:12 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:12 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:12 --> URI Class Initialized
INFO - 2020-01-07 18:53:12 --> Router Class Initialized
INFO - 2020-01-07 18:53:12 --> Output Class Initialized
INFO - 2020-01-07 18:53:12 --> Security Class Initialized
DEBUG - 2020-01-07 18:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:12 --> Input Class Initialized
INFO - 2020-01-07 18:53:12 --> Language Class Initialized
INFO - 2020-01-07 18:53:12 --> Loader Class Initialized
INFO - 2020-01-07 18:53:12 --> Helper loaded: url_helper
INFO - 2020-01-07 18:53:12 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:53:12 --> Controller Class Initialized
INFO - 2020-01-07 18:53:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:53:12 --> Pagination Class Initialized
INFO - 2020-01-07 18:53:12 --> Model "M_event" initialized
INFO - 2020-01-07 18:53:12 --> Helper loaded: form_helper
INFO - 2020-01-07 18:53:12 --> Form Validation Class Initialized
INFO - 2020-01-07 18:53:12 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:53:12 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:53:12 --> Final output sent to browser
DEBUG - 2020-01-07 18:53:12 --> Total execution time: 0.7686
INFO - 2020-01-07 18:53:13 --> Config Class Initialized
INFO - 2020-01-07 18:53:13 --> Config Class Initialized
INFO - 2020-01-07 18:53:13 --> Hooks Class Initialized
INFO - 2020-01-07 18:53:13 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:53:13 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:53:13 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:13 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:13 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:13 --> URI Class Initialized
INFO - 2020-01-07 18:53:13 --> URI Class Initialized
INFO - 2020-01-07 18:53:13 --> Router Class Initialized
INFO - 2020-01-07 18:53:13 --> Router Class Initialized
INFO - 2020-01-07 18:53:13 --> Output Class Initialized
INFO - 2020-01-07 18:53:13 --> Output Class Initialized
INFO - 2020-01-07 18:53:13 --> Security Class Initialized
INFO - 2020-01-07 18:53:13 --> Security Class Initialized
DEBUG - 2020-01-07 18:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:13 --> Input Class Initialized
INFO - 2020-01-07 18:53:13 --> Input Class Initialized
INFO - 2020-01-07 18:53:13 --> Language Class Initialized
INFO - 2020-01-07 18:53:13 --> Language Class Initialized
ERROR - 2020-01-07 18:53:13 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:53:13 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:53:13 --> Config Class Initialized
INFO - 2020-01-07 18:53:13 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:53:13 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:13 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:13 --> URI Class Initialized
INFO - 2020-01-07 18:53:13 --> Router Class Initialized
INFO - 2020-01-07 18:53:13 --> Output Class Initialized
INFO - 2020-01-07 18:53:13 --> Security Class Initialized
DEBUG - 2020-01-07 18:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:13 --> Input Class Initialized
INFO - 2020-01-07 18:53:13 --> Language Class Initialized
ERROR - 2020-01-07 18:53:13 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:53:16 --> Config Class Initialized
INFO - 2020-01-07 18:53:16 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:53:17 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:17 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:17 --> URI Class Initialized
INFO - 2020-01-07 18:53:17 --> Router Class Initialized
INFO - 2020-01-07 18:53:17 --> Output Class Initialized
INFO - 2020-01-07 18:53:17 --> Security Class Initialized
DEBUG - 2020-01-07 18:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:17 --> Input Class Initialized
INFO - 2020-01-07 18:53:17 --> Language Class Initialized
INFO - 2020-01-07 18:53:17 --> Loader Class Initialized
INFO - 2020-01-07 18:53:17 --> Helper loaded: url_helper
INFO - 2020-01-07 18:53:17 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:53:17 --> Controller Class Initialized
INFO - 2020-01-07 18:53:17 --> Model "M_login" initialized
INFO - 2020-01-07 18:53:17 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:53:17 --> Helper loaded: form_helper
INFO - 2020-01-07 18:53:17 --> Form Validation Class Initialized
INFO - 2020-01-07 18:53:17 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:53:17 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:53:17 --> Final output sent to browser
DEBUG - 2020-01-07 18:53:17 --> Total execution time: 0.7403
INFO - 2020-01-07 18:53:17 --> Config Class Initialized
INFO - 2020-01-07 18:53:17 --> Config Class Initialized
INFO - 2020-01-07 18:53:17 --> Config Class Initialized
INFO - 2020-01-07 18:53:17 --> Hooks Class Initialized
INFO - 2020-01-07 18:53:17 --> Hooks Class Initialized
INFO - 2020-01-07 18:53:17 --> Hooks Class Initialized
INFO - 2020-01-07 18:53:17 --> Config Class Initialized
INFO - 2020-01-07 18:53:17 --> Config Class Initialized
INFO - 2020-01-07 18:53:17 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:53:17 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:17 --> Config Class Initialized
DEBUG - 2020-01-07 18:53:17 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:17 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:53:17 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:17 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:17 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:17 --> Hooks Class Initialized
INFO - 2020-01-07 18:53:17 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:53:17 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:53:17 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:17 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:17 --> URI Class Initialized
INFO - 2020-01-07 18:53:17 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:17 --> URI Class Initialized
INFO - 2020-01-07 18:53:17 --> URI Class Initialized
INFO - 2020-01-07 18:53:17 --> Router Class Initialized
INFO - 2020-01-07 18:53:17 --> URI Class Initialized
DEBUG - 2020-01-07 18:53:17 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:17 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:17 --> Router Class Initialized
INFO - 2020-01-07 18:53:17 --> URI Class Initialized
INFO - 2020-01-07 18:53:17 --> Output Class Initialized
INFO - 2020-01-07 18:53:17 --> URI Class Initialized
INFO - 2020-01-07 18:53:17 --> Router Class Initialized
INFO - 2020-01-07 18:53:17 --> Router Class Initialized
INFO - 2020-01-07 18:53:17 --> Output Class Initialized
INFO - 2020-01-07 18:53:17 --> Router Class Initialized
INFO - 2020-01-07 18:53:17 --> Security Class Initialized
INFO - 2020-01-07 18:53:17 --> Router Class Initialized
INFO - 2020-01-07 18:53:17 --> Output Class Initialized
INFO - 2020-01-07 18:53:17 --> Output Class Initialized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
INFO - 2020-01-07 18:53:18 --> Output Class Initialized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:18 --> Output Class Initialized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
ERROR - 2020-01-07 18:53:18 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
ERROR - 2020-01-07 18:53:18 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
ERROR - 2020-01-07 18:53:18 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-07 18:53:18 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-01-07 18:53:18 --> Config Class Initialized
INFO - 2020-01-07 18:53:18 --> Hooks Class Initialized
ERROR - 2020-01-07 18:53:18 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-07 18:53:18 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-01-07 18:53:18 --> Config Class Initialized
INFO - 2020-01-07 18:53:18 --> Config Class Initialized
INFO - 2020-01-07 18:53:18 --> Config Class Initialized
INFO - 2020-01-07 18:53:18 --> Hooks Class Initialized
INFO - 2020-01-07 18:53:18 --> Hooks Class Initialized
INFO - 2020-01-07 18:53:18 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:53:18 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:18 --> Config Class Initialized
INFO - 2020-01-07 18:53:18 --> Config Class Initialized
INFO - 2020-01-07 18:53:18 --> Hooks Class Initialized
INFO - 2020-01-07 18:53:18 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:18 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:53:18 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:53:18 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:53:18 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:18 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:18 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:18 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:18 --> URI Class Initialized
DEBUG - 2020-01-07 18:53:18 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:53:18 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:18 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:18 --> URI Class Initialized
INFO - 2020-01-07 18:53:18 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:18 --> Router Class Initialized
INFO - 2020-01-07 18:53:18 --> URI Class Initialized
INFO - 2020-01-07 18:53:18 --> URI Class Initialized
INFO - 2020-01-07 18:53:18 --> Router Class Initialized
INFO - 2020-01-07 18:53:18 --> Router Class Initialized
INFO - 2020-01-07 18:53:18 --> Output Class Initialized
INFO - 2020-01-07 18:53:18 --> Router Class Initialized
INFO - 2020-01-07 18:53:18 --> URI Class Initialized
INFO - 2020-01-07 18:53:18 --> URI Class Initialized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
INFO - 2020-01-07 18:53:18 --> Output Class Initialized
INFO - 2020-01-07 18:53:18 --> Output Class Initialized
INFO - 2020-01-07 18:53:18 --> Output Class Initialized
INFO - 2020-01-07 18:53:18 --> Router Class Initialized
INFO - 2020-01-07 18:53:18 --> Router Class Initialized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:18 --> Output Class Initialized
INFO - 2020-01-07 18:53:18 --> Output Class Initialized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
ERROR - 2020-01-07 18:53:18 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-07 18:53:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-01-07 18:53:18 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-07 18:53:18 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
INFO - 2020-01-07 18:53:18 --> Config Class Initialized
INFO - 2020-01-07 18:53:18 --> Hooks Class Initialized
ERROR - 2020-01-07 18:53:18 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-01-07 18:53:18 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-07 18:53:18 --> Config Class Initialized
INFO - 2020-01-07 18:53:18 --> Config Class Initialized
INFO - 2020-01-07 18:53:18 --> Hooks Class Initialized
INFO - 2020-01-07 18:53:18 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:53:18 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:18 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:53:18 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:53:18 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:18 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:18 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:18 --> URI Class Initialized
INFO - 2020-01-07 18:53:18 --> URI Class Initialized
INFO - 2020-01-07 18:53:18 --> URI Class Initialized
INFO - 2020-01-07 18:53:18 --> Router Class Initialized
INFO - 2020-01-07 18:53:18 --> Router Class Initialized
INFO - 2020-01-07 18:53:18 --> Router Class Initialized
INFO - 2020-01-07 18:53:18 --> Output Class Initialized
INFO - 2020-01-07 18:53:18 --> Output Class Initialized
INFO - 2020-01-07 18:53:18 --> Output Class Initialized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
INFO - 2020-01-07 18:53:18 --> Security Class Initialized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
INFO - 2020-01-07 18:53:18 --> Input Class Initialized
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
INFO - 2020-01-07 18:53:18 --> Language Class Initialized
INFO - 2020-01-07 18:53:18 --> Loader Class Initialized
ERROR - 2020-01-07 18:53:18 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-01-07 18:53:18 --> Helper loaded: url_helper
INFO - 2020-01-07 18:53:18 --> Loader Class Initialized
INFO - 2020-01-07 18:53:18 --> Helper loaded: url_helper
INFO - 2020-01-07 18:53:18 --> Database Driver Class Initialized
INFO - 2020-01-07 18:53:18 --> Config Class Initialized
INFO - 2020-01-07 18:53:18 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:53:18 --> Database Driver Class Initialized
INFO - 2020-01-07 18:53:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-01-07 18:53:18 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:53:19 --> Controller Class Initialized
INFO - 2020-01-07 18:53:19 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:19 --> Model "M_login" initialized
INFO - 2020-01-07 18:53:19 --> URI Class Initialized
INFO - 2020-01-07 18:53:19 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:53:19 --> Router Class Initialized
INFO - 2020-01-07 18:53:19 --> Output Class Initialized
INFO - 2020-01-07 18:53:19 --> Helper loaded: form_helper
INFO - 2020-01-07 18:53:19 --> Form Validation Class Initialized
INFO - 2020-01-07 18:53:19 --> Security Class Initialized
DEBUG - 2020-01-07 18:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:19 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:53:19 --> Input Class Initialized
ERROR - 2020-01-07 18:53:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-07 18:53:19 --> Language Class Initialized
ERROR - 2020-01-07 18:53:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-01-07 18:53:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
ERROR - 2020-01-07 18:53:19 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 18:53:19 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:53:19 --> Config Class Initialized
INFO - 2020-01-07 18:53:19 --> Hooks Class Initialized
INFO - 2020-01-07 18:53:19 --> Final output sent to browser
DEBUG - 2020-01-07 18:53:19 --> Total execution time: 0.7427
DEBUG - 2020-01-07 18:53:19 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:19 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:53:19 --> Controller Class Initialized
INFO - 2020-01-07 18:53:19 --> URI Class Initialized
INFO - 2020-01-07 18:53:19 --> Model "M_login" initialized
INFO - 2020-01-07 18:53:19 --> Router Class Initialized
INFO - 2020-01-07 18:53:19 --> Model "M_tiket" initialized
INFO - 2020-01-07 18:53:19 --> Output Class Initialized
INFO - 2020-01-07 18:53:19 --> Security Class Initialized
INFO - 2020-01-07 18:53:19 --> Helper loaded: form_helper
INFO - 2020-01-07 18:53:19 --> Form Validation Class Initialized
DEBUG - 2020-01-07 18:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:19 --> Input Class Initialized
INFO - 2020-01-07 18:53:19 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:53:19 --> Language Class Initialized
ERROR - 2020-01-07 18:53:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-01-07 18:53:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-01-07 18:53:19 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-07 18:53:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-07 18:53:19 --> Config Class Initialized
INFO - 2020-01-07 18:53:19 --> Hooks Class Initialized
INFO - 2020-01-07 18:53:19 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-07 18:53:19 --> Final output sent to browser
DEBUG - 2020-01-07 18:53:19 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:19 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:53:19 --> Total execution time: 1.0621
INFO - 2020-01-07 18:53:19 --> URI Class Initialized
INFO - 2020-01-07 18:53:19 --> Router Class Initialized
INFO - 2020-01-07 18:53:19 --> Output Class Initialized
INFO - 2020-01-07 18:53:19 --> Security Class Initialized
DEBUG - 2020-01-07 18:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:19 --> Input Class Initialized
INFO - 2020-01-07 18:53:19 --> Language Class Initialized
ERROR - 2020-01-07 18:53:19 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-07 18:53:19 --> Config Class Initialized
INFO - 2020-01-07 18:53:19 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:53:19 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:19 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:20 --> URI Class Initialized
INFO - 2020-01-07 18:53:20 --> Router Class Initialized
INFO - 2020-01-07 18:53:20 --> Output Class Initialized
INFO - 2020-01-07 18:53:20 --> Security Class Initialized
DEBUG - 2020-01-07 18:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:20 --> Input Class Initialized
INFO - 2020-01-07 18:53:20 --> Language Class Initialized
ERROR - 2020-01-07 18:53:20 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-07 18:53:20 --> Config Class Initialized
INFO - 2020-01-07 18:53:20 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:53:20 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:20 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:20 --> URI Class Initialized
INFO - 2020-01-07 18:53:20 --> Router Class Initialized
INFO - 2020-01-07 18:53:20 --> Output Class Initialized
INFO - 2020-01-07 18:53:20 --> Security Class Initialized
DEBUG - 2020-01-07 18:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:20 --> Input Class Initialized
INFO - 2020-01-07 18:53:20 --> Language Class Initialized
ERROR - 2020-01-07 18:53:20 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-07 18:53:20 --> Config Class Initialized
INFO - 2020-01-07 18:53:20 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:53:20 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:53:20 --> Utf8 Class Initialized
INFO - 2020-01-07 18:53:20 --> URI Class Initialized
INFO - 2020-01-07 18:53:20 --> Router Class Initialized
INFO - 2020-01-07 18:53:20 --> Output Class Initialized
INFO - 2020-01-07 18:53:20 --> Security Class Initialized
DEBUG - 2020-01-07 18:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:53:20 --> Input Class Initialized
INFO - 2020-01-07 18:53:20 --> Language Class Initialized
ERROR - 2020-01-07 18:53:20 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-07 18:54:01 --> Config Class Initialized
INFO - 2020-01-07 18:54:01 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:54:01 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:54:01 --> Utf8 Class Initialized
INFO - 2020-01-07 18:54:01 --> URI Class Initialized
INFO - 2020-01-07 18:54:01 --> Router Class Initialized
INFO - 2020-01-07 18:54:01 --> Output Class Initialized
INFO - 2020-01-07 18:54:01 --> Security Class Initialized
DEBUG - 2020-01-07 18:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:54:01 --> Input Class Initialized
INFO - 2020-01-07 18:54:01 --> Language Class Initialized
INFO - 2020-01-07 18:54:01 --> Loader Class Initialized
INFO - 2020-01-07 18:54:01 --> Helper loaded: url_helper
INFO - 2020-01-07 18:54:01 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:54:01 --> Controller Class Initialized
INFO - 2020-01-07 18:54:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:54:01 --> Pagination Class Initialized
INFO - 2020-01-07 18:54:01 --> Model "M_event" initialized
INFO - 2020-01-07 18:54:01 --> Helper loaded: form_helper
INFO - 2020-01-07 18:54:01 --> Form Validation Class Initialized
INFO - 2020-01-07 18:54:02 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:54:02 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:54:02 --> Final output sent to browser
DEBUG - 2020-01-07 18:54:02 --> Total execution time: 0.8381
INFO - 2020-01-07 18:54:04 --> Config Class Initialized
INFO - 2020-01-07 18:54:04 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:54:04 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:54:04 --> Utf8 Class Initialized
INFO - 2020-01-07 18:54:04 --> URI Class Initialized
INFO - 2020-01-07 18:54:04 --> Router Class Initialized
INFO - 2020-01-07 18:54:04 --> Output Class Initialized
INFO - 2020-01-07 18:54:04 --> Security Class Initialized
DEBUG - 2020-01-07 18:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:54:04 --> Input Class Initialized
INFO - 2020-01-07 18:54:04 --> Language Class Initialized
ERROR - 2020-01-07 18:54:04 --> 404 Page Not Found: Event/event_list
INFO - 2020-01-07 18:54:59 --> Config Class Initialized
INFO - 2020-01-07 18:54:59 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:54:59 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:54:59 --> Utf8 Class Initialized
INFO - 2020-01-07 18:54:59 --> URI Class Initialized
INFO - 2020-01-07 18:54:59 --> Router Class Initialized
INFO - 2020-01-07 18:54:59 --> Output Class Initialized
INFO - 2020-01-07 18:54:59 --> Security Class Initialized
DEBUG - 2020-01-07 18:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:54:59 --> Input Class Initialized
INFO - 2020-01-07 18:54:59 --> Language Class Initialized
INFO - 2020-01-07 18:54:59 --> Loader Class Initialized
INFO - 2020-01-07 18:54:59 --> Helper loaded: url_helper
INFO - 2020-01-07 18:55:00 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:55:00 --> Controller Class Initialized
INFO - 2020-01-07 18:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:55:00 --> Pagination Class Initialized
INFO - 2020-01-07 18:55:00 --> Model "M_event" initialized
INFO - 2020-01-07 18:55:00 --> Helper loaded: form_helper
INFO - 2020-01-07 18:55:00 --> Form Validation Class Initialized
INFO - 2020-01-07 18:55:00 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:55:00 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:55:00 --> Final output sent to browser
DEBUG - 2020-01-07 18:55:00 --> Total execution time: 0.7593
INFO - 2020-01-07 18:55:10 --> Config Class Initialized
INFO - 2020-01-07 18:55:10 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:55:10 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:55:10 --> Utf8 Class Initialized
INFO - 2020-01-07 18:55:10 --> URI Class Initialized
INFO - 2020-01-07 18:55:10 --> Router Class Initialized
INFO - 2020-01-07 18:55:10 --> Output Class Initialized
INFO - 2020-01-07 18:55:10 --> Security Class Initialized
DEBUG - 2020-01-07 18:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:55:10 --> Input Class Initialized
INFO - 2020-01-07 18:55:10 --> Language Class Initialized
ERROR - 2020-01-07 18:55:10 --> 404 Page Not Found: Event/event_detail
INFO - 2020-01-07 18:57:50 --> Config Class Initialized
INFO - 2020-01-07 18:57:50 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:57:50 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:57:50 --> Utf8 Class Initialized
INFO - 2020-01-07 18:57:50 --> URI Class Initialized
INFO - 2020-01-07 18:57:50 --> Router Class Initialized
INFO - 2020-01-07 18:57:50 --> Output Class Initialized
INFO - 2020-01-07 18:57:50 --> Security Class Initialized
DEBUG - 2020-01-07 18:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:57:50 --> Input Class Initialized
INFO - 2020-01-07 18:57:50 --> Language Class Initialized
ERROR - 2020-01-07 18:57:51 --> 404 Page Not Found: Event/16
INFO - 2020-01-07 18:57:54 --> Config Class Initialized
INFO - 2020-01-07 18:57:54 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:57:54 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:57:54 --> Utf8 Class Initialized
INFO - 2020-01-07 18:57:54 --> URI Class Initialized
INFO - 2020-01-07 18:57:54 --> Router Class Initialized
INFO - 2020-01-07 18:57:54 --> Output Class Initialized
INFO - 2020-01-07 18:57:54 --> Security Class Initialized
DEBUG - 2020-01-07 18:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:57:54 --> Input Class Initialized
INFO - 2020-01-07 18:57:54 --> Language Class Initialized
ERROR - 2020-01-07 18:57:54 --> 404 Page Not Found: Event/index
INFO - 2020-01-07 18:57:57 --> Config Class Initialized
INFO - 2020-01-07 18:57:57 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:57:57 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:57:57 --> Utf8 Class Initialized
INFO - 2020-01-07 18:57:57 --> URI Class Initialized
DEBUG - 2020-01-07 18:57:57 --> No URI present. Default controller set.
INFO - 2020-01-07 18:57:57 --> Router Class Initialized
INFO - 2020-01-07 18:57:57 --> Output Class Initialized
INFO - 2020-01-07 18:57:57 --> Security Class Initialized
DEBUG - 2020-01-07 18:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:57:57 --> Input Class Initialized
INFO - 2020-01-07 18:57:57 --> Language Class Initialized
INFO - 2020-01-07 18:57:57 --> Loader Class Initialized
INFO - 2020-01-07 18:57:57 --> Helper loaded: url_helper
INFO - 2020-01-07 18:57:57 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:57:57 --> Controller Class Initialized
INFO - 2020-01-07 18:57:57 --> Model "M_login" initialized
INFO - 2020-01-07 18:57:57 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2020-01-07 18:57:57 --> Final output sent to browser
DEBUG - 2020-01-07 18:57:57 --> Total execution time: 0.5659
INFO - 2020-01-07 18:57:58 --> Config Class Initialized
INFO - 2020-01-07 18:57:58 --> Config Class Initialized
INFO - 2020-01-07 18:57:58 --> Hooks Class Initialized
INFO - 2020-01-07 18:57:58 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:57:58 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:57:58 --> Utf8 Class Initialized
DEBUG - 2020-01-07 18:57:58 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:57:58 --> Config Class Initialized
INFO - 2020-01-07 18:57:58 --> Config Class Initialized
INFO - 2020-01-07 18:57:58 --> Hooks Class Initialized
INFO - 2020-01-07 18:57:58 --> Utf8 Class Initialized
INFO - 2020-01-07 18:57:58 --> Hooks Class Initialized
INFO - 2020-01-07 18:57:58 --> URI Class Initialized
INFO - 2020-01-07 18:57:58 --> Router Class Initialized
DEBUG - 2020-01-07 18:57:58 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:57:58 --> Utf8 Class Initialized
INFO - 2020-01-07 18:57:58 --> URI Class Initialized
INFO - 2020-01-07 18:57:58 --> Output Class Initialized
DEBUG - 2020-01-07 18:57:58 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:57:58 --> Utf8 Class Initialized
INFO - 2020-01-07 18:57:58 --> Security Class Initialized
INFO - 2020-01-07 18:57:58 --> Router Class Initialized
INFO - 2020-01-07 18:57:58 --> URI Class Initialized
INFO - 2020-01-07 18:57:58 --> Router Class Initialized
INFO - 2020-01-07 18:57:58 --> Output Class Initialized
DEBUG - 2020-01-07 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:57:58 --> URI Class Initialized
INFO - 2020-01-07 18:57:58 --> Input Class Initialized
INFO - 2020-01-07 18:57:58 --> Router Class Initialized
INFO - 2020-01-07 18:57:58 --> Output Class Initialized
INFO - 2020-01-07 18:57:58 --> Security Class Initialized
INFO - 2020-01-07 18:57:58 --> Language Class Initialized
INFO - 2020-01-07 18:57:58 --> Output Class Initialized
INFO - 2020-01-07 18:57:58 --> Security Class Initialized
ERROR - 2020-01-07 18:57:58 --> 404 Page Not Found: Assets/js
DEBUG - 2020-01-07 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:57:58 --> Security Class Initialized
DEBUG - 2020-01-07 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:57:58 --> Input Class Initialized
INFO - 2020-01-07 18:57:58 --> Input Class Initialized
DEBUG - 2020-01-07 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:57:58 --> Input Class Initialized
INFO - 2020-01-07 18:57:58 --> Language Class Initialized
INFO - 2020-01-07 18:57:58 --> Language Class Initialized
INFO - 2020-01-07 18:57:58 --> Language Class Initialized
ERROR - 2020-01-07 18:57:58 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 18:57:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-07 18:57:58 --> 404 Page Not Found: Assets/images
INFO - 2020-01-07 18:57:58 --> Config Class Initialized
INFO - 2020-01-07 18:57:58 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:57:58 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:57:58 --> Utf8 Class Initialized
INFO - 2020-01-07 18:57:58 --> URI Class Initialized
INFO - 2020-01-07 18:57:58 --> Router Class Initialized
INFO - 2020-01-07 18:57:58 --> Output Class Initialized
INFO - 2020-01-07 18:57:58 --> Security Class Initialized
DEBUG - 2020-01-07 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:57:58 --> Input Class Initialized
INFO - 2020-01-07 18:57:58 --> Language Class Initialized
ERROR - 2020-01-07 18:57:58 --> 404 Page Not Found: Assets/js
INFO - 2020-01-07 18:58:05 --> Config Class Initialized
INFO - 2020-01-07 18:58:05 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:58:05 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:58:05 --> Utf8 Class Initialized
INFO - 2020-01-07 18:58:05 --> URI Class Initialized
INFO - 2020-01-07 18:58:05 --> Router Class Initialized
INFO - 2020-01-07 18:58:05 --> Output Class Initialized
INFO - 2020-01-07 18:58:05 --> Security Class Initialized
DEBUG - 2020-01-07 18:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:58:05 --> Input Class Initialized
INFO - 2020-01-07 18:58:05 --> Language Class Initialized
INFO - 2020-01-07 18:58:05 --> Loader Class Initialized
INFO - 2020-01-07 18:58:05 --> Helper loaded: url_helper
INFO - 2020-01-07 18:58:05 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:58:06 --> Controller Class Initialized
INFO - 2020-01-07 18:58:06 --> Model "M_login" initialized
INFO - 2020-01-07 18:58:06 --> Config Class Initialized
INFO - 2020-01-07 18:58:06 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:58:06 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:58:06 --> Utf8 Class Initialized
INFO - 2020-01-07 18:58:06 --> URI Class Initialized
INFO - 2020-01-07 18:58:06 --> Router Class Initialized
INFO - 2020-01-07 18:58:06 --> Output Class Initialized
INFO - 2020-01-07 18:58:06 --> Security Class Initialized
DEBUG - 2020-01-07 18:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:58:06 --> Input Class Initialized
INFO - 2020-01-07 18:58:06 --> Language Class Initialized
INFO - 2020-01-07 18:58:06 --> Loader Class Initialized
INFO - 2020-01-07 18:58:06 --> Helper loaded: url_helper
INFO - 2020-01-07 18:58:06 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:58:06 --> Controller Class Initialized
INFO - 2020-01-07 18:58:06 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:58:06 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2020-01-07 18:58:06 --> Final output sent to browser
DEBUG - 2020-01-07 18:58:06 --> Total execution time: 0.5196
INFO - 2020-01-07 18:58:06 --> Config Class Initialized
INFO - 2020-01-07 18:58:06 --> Config Class Initialized
INFO - 2020-01-07 18:58:06 --> Hooks Class Initialized
INFO - 2020-01-07 18:58:06 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:58:06 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:58:06 --> Utf8 Class Initialized
INFO - 2020-01-07 18:58:06 --> Utf8 Class Initialized
INFO - 2020-01-07 18:58:06 --> URI Class Initialized
INFO - 2020-01-07 18:58:06 --> URI Class Initialized
INFO - 2020-01-07 18:58:06 --> Router Class Initialized
INFO - 2020-01-07 18:58:06 --> Router Class Initialized
INFO - 2020-01-07 18:58:07 --> Output Class Initialized
INFO - 2020-01-07 18:58:07 --> Output Class Initialized
INFO - 2020-01-07 18:58:07 --> Security Class Initialized
INFO - 2020-01-07 18:58:07 --> Security Class Initialized
DEBUG - 2020-01-07 18:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:58:07 --> Input Class Initialized
INFO - 2020-01-07 18:58:07 --> Input Class Initialized
INFO - 2020-01-07 18:58:07 --> Language Class Initialized
INFO - 2020-01-07 18:58:07 --> Language Class Initialized
ERROR - 2020-01-07 18:58:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-07 18:58:07 --> 404 Page Not Found: Assets/js
INFO - 2020-01-07 18:58:07 --> Config Class Initialized
INFO - 2020-01-07 18:58:07 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:58:07 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:58:07 --> Utf8 Class Initialized
INFO - 2020-01-07 18:58:07 --> URI Class Initialized
INFO - 2020-01-07 18:58:07 --> Router Class Initialized
INFO - 2020-01-07 18:58:07 --> Output Class Initialized
INFO - 2020-01-07 18:58:07 --> Security Class Initialized
DEBUG - 2020-01-07 18:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:58:07 --> Input Class Initialized
INFO - 2020-01-07 18:58:07 --> Language Class Initialized
ERROR - 2020-01-07 18:58:07 --> 404 Page Not Found: Assets/js
INFO - 2020-01-07 18:58:16 --> Config Class Initialized
INFO - 2020-01-07 18:58:16 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:58:16 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:58:16 --> Utf8 Class Initialized
INFO - 2020-01-07 18:58:16 --> URI Class Initialized
INFO - 2020-01-07 18:58:16 --> Router Class Initialized
INFO - 2020-01-07 18:58:16 --> Output Class Initialized
INFO - 2020-01-07 18:58:16 --> Security Class Initialized
DEBUG - 2020-01-07 18:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:58:16 --> Input Class Initialized
INFO - 2020-01-07 18:58:16 --> Language Class Initialized
INFO - 2020-01-07 18:58:16 --> Loader Class Initialized
INFO - 2020-01-07 18:58:16 --> Helper loaded: url_helper
INFO - 2020-01-07 18:58:16 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:58:16 --> Controller Class Initialized
INFO - 2020-01-07 18:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:58:16 --> Pagination Class Initialized
INFO - 2020-01-07 18:58:16 --> Model "M_event" initialized
INFO - 2020-01-07 18:58:16 --> Helper loaded: form_helper
INFO - 2020-01-07 18:58:16 --> Form Validation Class Initialized
INFO - 2020-01-07 18:58:17 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:58:17 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:58:17 --> Final output sent to browser
DEBUG - 2020-01-07 18:58:17 --> Total execution time: 0.8007
INFO - 2020-01-07 18:58:17 --> Config Class Initialized
INFO - 2020-01-07 18:58:17 --> Config Class Initialized
INFO - 2020-01-07 18:58:17 --> Hooks Class Initialized
INFO - 2020-01-07 18:58:17 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 18:58:17 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:58:17 --> Utf8 Class Initialized
INFO - 2020-01-07 18:58:17 --> Utf8 Class Initialized
INFO - 2020-01-07 18:58:17 --> URI Class Initialized
INFO - 2020-01-07 18:58:17 --> URI Class Initialized
INFO - 2020-01-07 18:58:17 --> Router Class Initialized
INFO - 2020-01-07 18:58:17 --> Router Class Initialized
INFO - 2020-01-07 18:58:17 --> Output Class Initialized
INFO - 2020-01-07 18:58:17 --> Output Class Initialized
INFO - 2020-01-07 18:58:17 --> Security Class Initialized
INFO - 2020-01-07 18:58:17 --> Security Class Initialized
DEBUG - 2020-01-07 18:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 18:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:58:17 --> Input Class Initialized
INFO - 2020-01-07 18:58:17 --> Input Class Initialized
INFO - 2020-01-07 18:58:17 --> Language Class Initialized
INFO - 2020-01-07 18:58:17 --> Language Class Initialized
ERROR - 2020-01-07 18:58:17 --> 404 Page Not Found: Event/assets
ERROR - 2020-01-07 18:58:17 --> 404 Page Not Found: Event/assets
INFO - 2020-01-07 18:58:22 --> Config Class Initialized
INFO - 2020-01-07 18:58:22 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:58:22 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:58:23 --> Utf8 Class Initialized
INFO - 2020-01-07 18:58:23 --> URI Class Initialized
INFO - 2020-01-07 18:58:23 --> Router Class Initialized
INFO - 2020-01-07 18:58:23 --> Output Class Initialized
INFO - 2020-01-07 18:58:23 --> Security Class Initialized
DEBUG - 2020-01-07 18:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:58:23 --> Input Class Initialized
INFO - 2020-01-07 18:58:23 --> Language Class Initialized
ERROR - 2020-01-07 18:58:23 --> 404 Page Not Found: Event/event_detail
INFO - 2020-01-07 18:59:52 --> Config Class Initialized
INFO - 2020-01-07 18:59:53 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:59:53 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:59:53 --> Utf8 Class Initialized
INFO - 2020-01-07 18:59:53 --> URI Class Initialized
INFO - 2020-01-07 18:59:53 --> Router Class Initialized
INFO - 2020-01-07 18:59:53 --> Output Class Initialized
INFO - 2020-01-07 18:59:53 --> Security Class Initialized
DEBUG - 2020-01-07 18:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:59:53 --> Input Class Initialized
INFO - 2020-01-07 18:59:53 --> Language Class Initialized
INFO - 2020-01-07 18:59:53 --> Loader Class Initialized
INFO - 2020-01-07 18:59:53 --> Helper loaded: url_helper
INFO - 2020-01-07 18:59:53 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:59:53 --> Controller Class Initialized
INFO - 2020-01-07 18:59:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:59:53 --> Pagination Class Initialized
INFO - 2020-01-07 18:59:53 --> Model "M_event" initialized
INFO - 2020-01-07 18:59:53 --> Helper loaded: form_helper
INFO - 2020-01-07 18:59:53 --> Form Validation Class Initialized
INFO - 2020-01-07 18:59:53 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 18:59:53 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/Event/event_list.php
INFO - 2020-01-07 18:59:53 --> Final output sent to browser
DEBUG - 2020-01-07 18:59:53 --> Total execution time: 0.8117
INFO - 2020-01-07 18:59:55 --> Config Class Initialized
INFO - 2020-01-07 18:59:55 --> Hooks Class Initialized
DEBUG - 2020-01-07 18:59:55 --> UTF-8 Support Enabled
INFO - 2020-01-07 18:59:55 --> Utf8 Class Initialized
INFO - 2020-01-07 18:59:55 --> URI Class Initialized
INFO - 2020-01-07 18:59:55 --> Router Class Initialized
INFO - 2020-01-07 18:59:55 --> Output Class Initialized
INFO - 2020-01-07 18:59:55 --> Security Class Initialized
DEBUG - 2020-01-07 18:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 18:59:55 --> Input Class Initialized
INFO - 2020-01-07 18:59:55 --> Language Class Initialized
INFO - 2020-01-07 18:59:55 --> Loader Class Initialized
INFO - 2020-01-07 18:59:56 --> Helper loaded: url_helper
INFO - 2020-01-07 18:59:56 --> Database Driver Class Initialized
DEBUG - 2020-01-07 18:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 18:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 18:59:56 --> Controller Class Initialized
INFO - 2020-01-07 18:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 18:59:56 --> Pagination Class Initialized
INFO - 2020-01-07 18:59:56 --> Model "M_event" initialized
INFO - 2020-01-07 18:59:56 --> Helper loaded: form_helper
INFO - 2020-01-07 18:59:56 --> Form Validation Class Initialized
ERROR - 2020-01-07 18:59:56 --> Severity: Notice --> Undefined property: Event::$M_tiket C:\xampp\htdocs\Musikologi-1\application\controllers\Event.php 27
ERROR - 2020-01-07 18:59:56 --> Severity: error --> Exception: Call to a member function getByIdshow() on null C:\xampp\htdocs\Musikologi-1\application\controllers\Event.php 27
INFO - 2020-01-07 19:00:19 --> Config Class Initialized
INFO - 2020-01-07 19:00:19 --> Hooks Class Initialized
DEBUG - 2020-01-07 19:00:19 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:19 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:19 --> URI Class Initialized
INFO - 2020-01-07 19:00:19 --> Router Class Initialized
INFO - 2020-01-07 19:00:19 --> Output Class Initialized
INFO - 2020-01-07 19:00:19 --> Security Class Initialized
DEBUG - 2020-01-07 19:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:19 --> Input Class Initialized
INFO - 2020-01-07 19:00:19 --> Language Class Initialized
INFO - 2020-01-07 19:00:19 --> Loader Class Initialized
INFO - 2020-01-07 19:00:19 --> Helper loaded: url_helper
INFO - 2020-01-07 19:00:19 --> Database Driver Class Initialized
DEBUG - 2020-01-07 19:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 19:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 19:00:19 --> Controller Class Initialized
INFO - 2020-01-07 19:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 19:00:19 --> Pagination Class Initialized
INFO - 2020-01-07 19:00:19 --> Model "M_event" initialized
INFO - 2020-01-07 19:00:19 --> Model "M_tiket" initialized
INFO - 2020-01-07 19:00:19 --> Helper loaded: form_helper
INFO - 2020-01-07 19:00:19 --> Form Validation Class Initialized
INFO - 2020-01-07 19:00:19 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 19:00:19 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/event/event_detail.php
INFO - 2020-01-07 19:00:19 --> Final output sent to browser
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
DEBUG - 2020-01-07 19:00:20 --> Total execution time: 0.6972
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
DEBUG - 2020-01-07 19:00:20 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 19:00:20 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
DEBUG - 2020-01-07 19:00:20 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
INFO - 2020-01-07 19:00:20 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:20 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:20 --> Utf8 Class Initialized
DEBUG - 2020-01-07 19:00:20 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 19:00:20 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:20 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:20 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:20 --> URI Class Initialized
DEBUG - 2020-01-07 19:00:20 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:20 --> URI Class Initialized
INFO - 2020-01-07 19:00:20 --> URI Class Initialized
INFO - 2020-01-07 19:00:20 --> Router Class Initialized
INFO - 2020-01-07 19:00:20 --> Router Class Initialized
INFO - 2020-01-07 19:00:20 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:20 --> URI Class Initialized
INFO - 2020-01-07 19:00:20 --> URI Class Initialized
INFO - 2020-01-07 19:00:20 --> Router Class Initialized
INFO - 2020-01-07 19:00:20 --> Output Class Initialized
INFO - 2020-01-07 19:00:20 --> Output Class Initialized
INFO - 2020-01-07 19:00:20 --> Router Class Initialized
INFO - 2020-01-07 19:00:20 --> URI Class Initialized
INFO - 2020-01-07 19:00:20 --> Output Class Initialized
INFO - 2020-01-07 19:00:20 --> Router Class Initialized
INFO - 2020-01-07 19:00:20 --> Router Class Initialized
INFO - 2020-01-07 19:00:20 --> Security Class Initialized
INFO - 2020-01-07 19:00:20 --> Output Class Initialized
INFO - 2020-01-07 19:00:20 --> Security Class Initialized
INFO - 2020-01-07 19:00:20 --> Security Class Initialized
INFO - 2020-01-07 19:00:20 --> Output Class Initialized
DEBUG - 2020-01-07 19:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:20 --> Security Class Initialized
DEBUG - 2020-01-07 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:20 --> Output Class Initialized
INFO - 2020-01-07 19:00:20 --> Security Class Initialized
INFO - 2020-01-07 19:00:20 --> Input Class Initialized
INFO - 2020-01-07 19:00:20 --> Input Class Initialized
INFO - 2020-01-07 19:00:20 --> Security Class Initialized
DEBUG - 2020-01-07 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:20 --> Input Class Initialized
DEBUG - 2020-01-07 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:20 --> Input Class Initialized
INFO - 2020-01-07 19:00:20 --> Language Class Initialized
INFO - 2020-01-07 19:00:20 --> Language Class Initialized
INFO - 2020-01-07 19:00:20 --> Input Class Initialized
DEBUG - 2020-01-07 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:20 --> Language Class Initialized
INFO - 2020-01-07 19:00:20 --> Input Class Initialized
INFO - 2020-01-07 19:00:20 --> Language Class Initialized
ERROR - 2020-01-07 19:00:20 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-07 19:00:20 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-01-07 19:00:20 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-01-07 19:00:20 --> Language Class Initialized
INFO - 2020-01-07 19:00:20 --> Language Class Initialized
ERROR - 2020-01-07 19:00:20 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-07 19:00:20 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
ERROR - 2020-01-07 19:00:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
DEBUG - 2020-01-07 19:00:20 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 19:00:20 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 19:00:20 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:20 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:20 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
DEBUG - 2020-01-07 19:00:20 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 19:00:20 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:20 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:20 --> URI Class Initialized
INFO - 2020-01-07 19:00:20 --> URI Class Initialized
INFO - 2020-01-07 19:00:20 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:20 --> URI Class Initialized
DEBUG - 2020-01-07 19:00:20 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:20 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:20 --> URI Class Initialized
INFO - 2020-01-07 19:00:20 --> Router Class Initialized
INFO - 2020-01-07 19:00:20 --> Router Class Initialized
INFO - 2020-01-07 19:00:20 --> URI Class Initialized
INFO - 2020-01-07 19:00:20 --> Router Class Initialized
INFO - 2020-01-07 19:00:20 --> URI Class Initialized
INFO - 2020-01-07 19:00:20 --> Output Class Initialized
INFO - 2020-01-07 19:00:20 --> Router Class Initialized
INFO - 2020-01-07 19:00:20 --> Output Class Initialized
INFO - 2020-01-07 19:00:20 --> Output Class Initialized
INFO - 2020-01-07 19:00:20 --> Router Class Initialized
INFO - 2020-01-07 19:00:20 --> Security Class Initialized
INFO - 2020-01-07 19:00:20 --> Security Class Initialized
INFO - 2020-01-07 19:00:20 --> Router Class Initialized
INFO - 2020-01-07 19:00:20 --> Output Class Initialized
INFO - 2020-01-07 19:00:20 --> Security Class Initialized
INFO - 2020-01-07 19:00:20 --> Output Class Initialized
DEBUG - 2020-01-07 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:20 --> Security Class Initialized
INFO - 2020-01-07 19:00:20 --> Security Class Initialized
DEBUG - 2020-01-07 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:20 --> Output Class Initialized
DEBUG - 2020-01-07 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:20 --> Input Class Initialized
INFO - 2020-01-07 19:00:20 --> Input Class Initialized
DEBUG - 2020-01-07 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:20 --> Input Class Initialized
DEBUG - 2020-01-07 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:20 --> Security Class Initialized
INFO - 2020-01-07 19:00:20 --> Input Class Initialized
INFO - 2020-01-07 19:00:20 --> Language Class Initialized
INFO - 2020-01-07 19:00:20 --> Language Class Initialized
INFO - 2020-01-07 19:00:20 --> Language Class Initialized
INFO - 2020-01-07 19:00:20 --> Input Class Initialized
DEBUG - 2020-01-07 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:20 --> Input Class Initialized
INFO - 2020-01-07 19:00:20 --> Language Class Initialized
INFO - 2020-01-07 19:00:20 --> Language Class Initialized
ERROR - 2020-01-07 19:00:20 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-01-07 19:00:20 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-01-07 19:00:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 19:00:20 --> Language Class Initialized
ERROR - 2020-01-07 19:00:20 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-01-07 19:00:20 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Config Class Initialized
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
INFO - 2020-01-07 19:00:20 --> Hooks Class Initialized
ERROR - 2020-01-07 19:00:20 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-01-07 19:00:21 --> UTF-8 Support Enabled
DEBUG - 2020-01-07 19:00:21 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:21 --> Config Class Initialized
INFO - 2020-01-07 19:00:21 --> Hooks Class Initialized
INFO - 2020-01-07 19:00:21 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:21 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:21 --> URI Class Initialized
INFO - 2020-01-07 19:00:21 --> URI Class Initialized
DEBUG - 2020-01-07 19:00:21 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:21 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:21 --> Router Class Initialized
INFO - 2020-01-07 19:00:21 --> Router Class Initialized
INFO - 2020-01-07 19:00:21 --> URI Class Initialized
INFO - 2020-01-07 19:00:21 --> Output Class Initialized
INFO - 2020-01-07 19:00:21 --> Output Class Initialized
INFO - 2020-01-07 19:00:21 --> Security Class Initialized
INFO - 2020-01-07 19:00:21 --> Security Class Initialized
INFO - 2020-01-07 19:00:21 --> Router Class Initialized
DEBUG - 2020-01-07 19:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-07 19:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:21 --> Output Class Initialized
INFO - 2020-01-07 19:00:21 --> Input Class Initialized
INFO - 2020-01-07 19:00:21 --> Input Class Initialized
INFO - 2020-01-07 19:00:21 --> Security Class Initialized
INFO - 2020-01-07 19:00:21 --> Language Class Initialized
INFO - 2020-01-07 19:00:21 --> Language Class Initialized
DEBUG - 2020-01-07 19:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:21 --> Input Class Initialized
INFO - 2020-01-07 19:00:21 --> Loader Class Initialized
INFO - 2020-01-07 19:00:21 --> Loader Class Initialized
INFO - 2020-01-07 19:00:21 --> Language Class Initialized
INFO - 2020-01-07 19:00:21 --> Helper loaded: url_helper
INFO - 2020-01-07 19:00:21 --> Helper loaded: url_helper
ERROR - 2020-01-07 19:00:21 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-01-07 19:00:21 --> Database Driver Class Initialized
INFO - 2020-01-07 19:00:21 --> Database Driver Class Initialized
DEBUG - 2020-01-07 19:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-01-07 19:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-07 19:00:21 --> Config Class Initialized
INFO - 2020-01-07 19:00:21 --> Hooks Class Initialized
INFO - 2020-01-07 19:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 19:00:21 --> Controller Class Initialized
DEBUG - 2020-01-07 19:00:21 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:21 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 19:00:21 --> Pagination Class Initialized
INFO - 2020-01-07 19:00:21 --> URI Class Initialized
INFO - 2020-01-07 19:00:21 --> Router Class Initialized
INFO - 2020-01-07 19:00:21 --> Model "M_event" initialized
INFO - 2020-01-07 19:00:21 --> Model "M_tiket" initialized
INFO - 2020-01-07 19:00:21 --> Output Class Initialized
INFO - 2020-01-07 19:00:21 --> Security Class Initialized
INFO - 2020-01-07 19:00:21 --> Helper loaded: form_helper
INFO - 2020-01-07 19:00:21 --> Form Validation Class Initialized
DEBUG - 2020-01-07 19:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:21 --> Input Class Initialized
INFO - 2020-01-07 19:00:21 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-07 19:00:21 --> Language Class Initialized
ERROR - 2020-01-07 19:00:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\event\event_detail.php 58
ERROR - 2020-01-07 19:00:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\event\event_detail.php 59
ERROR - 2020-01-07 19:00:21 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-07 19:00:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\event\event_detail.php 60
INFO - 2020-01-07 19:00:21 --> Config Class Initialized
INFO - 2020-01-07 19:00:21 --> Hooks Class Initialized
INFO - 2020-01-07 19:00:21 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/event/event_detail.php
INFO - 2020-01-07 19:00:21 --> Final output sent to browser
DEBUG - 2020-01-07 19:00:21 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:21 --> Utf8 Class Initialized
DEBUG - 2020-01-07 19:00:21 --> Total execution time: 0.8124
INFO - 2020-01-07 19:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-07 19:00:21 --> URI Class Initialized
INFO - 2020-01-07 19:00:21 --> Controller Class Initialized
INFO - 2020-01-07 19:00:21 --> Router Class Initialized
INFO - 2020-01-07 19:00:21 --> Output Class Initialized
INFO - 2020-01-07 19:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-07 19:00:21 --> Pagination Class Initialized
INFO - 2020-01-07 19:00:21 --> Security Class Initialized
INFO - 2020-01-07 19:00:21 --> Model "M_event" initialized
DEBUG - 2020-01-07 19:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:21 --> Input Class Initialized
INFO - 2020-01-07 19:00:21 --> Model "M_tiket" initialized
INFO - 2020-01-07 19:00:21 --> Language Class Initialized
INFO - 2020-01-07 19:00:21 --> Helper loaded: form_helper
INFO - 2020-01-07 19:00:21 --> Form Validation Class Initialized
ERROR - 2020-01-07 19:00:21 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 19:00:22 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-07 19:00:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\event\event_detail.php 58
ERROR - 2020-01-07 19:00:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\event\event_detail.php 59
INFO - 2020-01-07 19:00:22 --> Config Class Initialized
INFO - 2020-01-07 19:00:22 --> Hooks Class Initialized
ERROR - 2020-01-07 19:00:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\event\event_detail.php 60
INFO - 2020-01-07 19:00:22 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/event/event_detail.php
DEBUG - 2020-01-07 19:00:22 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:22 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:22 --> Final output sent to browser
DEBUG - 2020-01-07 19:00:22 --> Total execution time: 1.2068
INFO - 2020-01-07 19:00:22 --> URI Class Initialized
INFO - 2020-01-07 19:00:22 --> Router Class Initialized
INFO - 2020-01-07 19:00:22 --> Output Class Initialized
INFO - 2020-01-07 19:00:22 --> Security Class Initialized
DEBUG - 2020-01-07 19:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:22 --> Input Class Initialized
INFO - 2020-01-07 19:00:22 --> Language Class Initialized
ERROR - 2020-01-07 19:00:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-07 19:00:22 --> Config Class Initialized
INFO - 2020-01-07 19:00:22 --> Hooks Class Initialized
DEBUG - 2020-01-07 19:00:22 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:22 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:22 --> URI Class Initialized
INFO - 2020-01-07 19:00:22 --> Router Class Initialized
INFO - 2020-01-07 19:00:22 --> Output Class Initialized
INFO - 2020-01-07 19:00:22 --> Security Class Initialized
DEBUG - 2020-01-07 19:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:22 --> Input Class Initialized
INFO - 2020-01-07 19:00:22 --> Language Class Initialized
ERROR - 2020-01-07 19:00:22 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-07 19:00:22 --> Config Class Initialized
INFO - 2020-01-07 19:00:22 --> Hooks Class Initialized
DEBUG - 2020-01-07 19:00:22 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:22 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:22 --> URI Class Initialized
INFO - 2020-01-07 19:00:22 --> Router Class Initialized
INFO - 2020-01-07 19:00:22 --> Output Class Initialized
INFO - 2020-01-07 19:00:22 --> Security Class Initialized
DEBUG - 2020-01-07 19:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:22 --> Input Class Initialized
INFO - 2020-01-07 19:00:23 --> Language Class Initialized
ERROR - 2020-01-07 19:00:23 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-07 19:00:23 --> Config Class Initialized
INFO - 2020-01-07 19:00:23 --> Hooks Class Initialized
DEBUG - 2020-01-07 19:00:23 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:23 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:23 --> URI Class Initialized
INFO - 2020-01-07 19:00:23 --> Router Class Initialized
INFO - 2020-01-07 19:00:23 --> Output Class Initialized
INFO - 2020-01-07 19:00:23 --> Security Class Initialized
DEBUG - 2020-01-07 19:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:23 --> Input Class Initialized
INFO - 2020-01-07 19:00:23 --> Language Class Initialized
ERROR - 2020-01-07 19:00:23 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-07 19:00:23 --> Config Class Initialized
INFO - 2020-01-07 19:00:23 --> Hooks Class Initialized
DEBUG - 2020-01-07 19:00:23 --> UTF-8 Support Enabled
INFO - 2020-01-07 19:00:23 --> Utf8 Class Initialized
INFO - 2020-01-07 19:00:23 --> URI Class Initialized
INFO - 2020-01-07 19:00:23 --> Router Class Initialized
INFO - 2020-01-07 19:00:23 --> Output Class Initialized
INFO - 2020-01-07 19:00:23 --> Security Class Initialized
DEBUG - 2020-01-07 19:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-07 19:00:23 --> Input Class Initialized
INFO - 2020-01-07 19:00:23 --> Language Class Initialized
ERROR - 2020-01-07 19:00:23 --> 404 Page Not Found: Bower_components/jquery-i18next
