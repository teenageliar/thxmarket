<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-09 00:58:52 --> Upload Class Initialized
INFO - 2020-03-09 00:58:52 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2020-03-09 00:58:52 --> You did not select a file to upload.
INFO - 2020-03-09 01:07:49 --> Final output sent to browser
DEBUG - 2020-03-09 01:07:49 --> Total execution time: 0.1543
INFO - 2020-03-09 01:09:02 --> Upload Class Initialized
INFO - 2020-03-09 01:09:02 --> Language file loaded: language/english/upload_lang.php
INFO - 2020-03-09 01:09:02 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2020-03-09 01:15:32 --> Upload Class Initialized
INFO - 2020-03-09 01:15:32 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-03-09 01:15:32 --> The upload path does not appear to be valid.
INFO - 2020-03-09 01:19:31 --> Upload Class Initialized
INFO - 2020-03-09 01:19:31 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-03-09 01:19:31 --> The upload path does not appear to be valid.
INFO - 2020-03-09 01:21:24 --> Upload Class Initialized
INFO - 2020-03-09 01:21:24 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-03-09 01:21:24 --> The upload path does not appear to be valid.
INFO - 2020-03-09 01:23:12 --> Upload Class Initialized
INFO - 2020-03-09 01:23:12 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-03-09 01:23:12 --> The upload path does not appear to be valid.
INFO - 2020-03-09 01:24:37 --> Upload Class Initialized
INFO - 2020-03-09 01:24:37 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-03-09 01:24:37 --> The upload path does not appear to be valid.
INFO - 2020-03-09 01:28:40 --> Upload Class Initialized
INFO - 2020-03-09 01:31:01 --> Upload Class Initialized
INFO - 2020-03-09 01:32:01 --> Final output sent to browser
DEBUG - 2020-03-09 01:32:01 --> Total execution time: 0.1712
INFO - 2020-03-09 01:32:37 --> Upload Class Initialized
INFO - 2020-03-09 01:34:20 --> Upload Class Initialized
