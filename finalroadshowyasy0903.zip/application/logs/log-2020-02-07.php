<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-07 10:32:41 --> Config Class Initialized
INFO - 2020-02-07 10:32:41 --> Hooks Class Initialized
DEBUG - 2020-02-07 10:32:42 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:42 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:42 --> URI Class Initialized
INFO - 2020-02-07 10:32:42 --> Router Class Initialized
INFO - 2020-02-07 10:32:42 --> Output Class Initialized
INFO - 2020-02-07 10:32:43 --> Security Class Initialized
DEBUG - 2020-02-07 10:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:43 --> Input Class Initialized
INFO - 2020-02-07 10:32:43 --> Language Class Initialized
INFO - 2020-02-07 10:32:43 --> Loader Class Initialized
INFO - 2020-02-07 10:32:43 --> Helper loaded: url_helper
INFO - 2020-02-07 10:32:44 --> Database Driver Class Initialized
DEBUG - 2020-02-07 10:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 10:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 10:32:44 --> Controller Class Initialized
INFO - 2020-02-07 10:32:44 --> Model "M_tiket" initialized
INFO - 2020-02-07 10:32:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 10:32:44 --> Model "M_pesan" initialized
INFO - 2020-02-07 10:32:45 --> Helper loaded: form_helper
INFO - 2020-02-07 10:32:45 --> Form Validation Class Initialized
INFO - 2020-02-07 10:32:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 10:32:45 --> Final output sent to browser
DEBUG - 2020-02-07 10:32:45 --> Total execution time: 4.2437
INFO - 2020-02-07 10:32:46 --> Config Class Initialized
INFO - 2020-02-07 10:32:46 --> Config Class Initialized
INFO - 2020-02-07 10:32:46 --> Config Class Initialized
INFO - 2020-02-07 10:32:46 --> Hooks Class Initialized
INFO - 2020-02-07 10:32:46 --> Hooks Class Initialized
INFO - 2020-02-07 10:32:46 --> Hooks Class Initialized
DEBUG - 2020-02-07 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 10:32:46 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:46 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:46 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:46 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:46 --> URI Class Initialized
INFO - 2020-02-07 10:32:46 --> URI Class Initialized
INFO - 2020-02-07 10:32:46 --> URI Class Initialized
INFO - 2020-02-07 10:32:46 --> Router Class Initialized
INFO - 2020-02-07 10:32:46 --> Router Class Initialized
INFO - 2020-02-07 10:32:46 --> Router Class Initialized
INFO - 2020-02-07 10:32:46 --> Output Class Initialized
INFO - 2020-02-07 10:32:46 --> Output Class Initialized
INFO - 2020-02-07 10:32:46 --> Output Class Initialized
INFO - 2020-02-07 10:32:46 --> Config Class Initialized
INFO - 2020-02-07 10:32:46 --> Config Class Initialized
INFO - 2020-02-07 10:32:46 --> Config Class Initialized
INFO - 2020-02-07 10:32:46 --> Hooks Class Initialized
INFO - 2020-02-07 10:32:46 --> Hooks Class Initialized
INFO - 2020-02-07 10:32:46 --> Security Class Initialized
INFO - 2020-02-07 10:32:46 --> Security Class Initialized
INFO - 2020-02-07 10:32:46 --> Hooks Class Initialized
INFO - 2020-02-07 10:32:46 --> Security Class Initialized
DEBUG - 2020-02-07 10:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 10:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 10:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 10:32:46 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:46 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:46 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:46 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:46 --> Input Class Initialized
INFO - 2020-02-07 10:32:46 --> Input Class Initialized
INFO - 2020-02-07 10:32:46 --> Input Class Initialized
INFO - 2020-02-07 10:32:46 --> Language Class Initialized
INFO - 2020-02-07 10:32:46 --> Language Class Initialized
INFO - 2020-02-07 10:32:46 --> Language Class Initialized
INFO - 2020-02-07 10:32:46 --> URI Class Initialized
INFO - 2020-02-07 10:32:46 --> URI Class Initialized
INFO - 2020-02-07 10:32:46 --> URI Class Initialized
INFO - 2020-02-07 10:32:46 --> Router Class Initialized
INFO - 2020-02-07 10:32:46 --> Router Class Initialized
INFO - 2020-02-07 10:32:46 --> Loader Class Initialized
INFO - 2020-02-07 10:32:46 --> Router Class Initialized
INFO - 2020-02-07 10:32:46 --> Helper loaded: url_helper
INFO - 2020-02-07 10:32:46 --> Output Class Initialized
INFO - 2020-02-07 10:32:46 --> Output Class Initialized
INFO - 2020-02-07 10:32:46 --> Output Class Initialized
INFO - 2020-02-07 10:32:46 --> Security Class Initialized
INFO - 2020-02-07 10:32:46 --> Security Class Initialized
INFO - 2020-02-07 10:32:46 --> Security Class Initialized
INFO - 2020-02-07 10:32:46 --> Database Driver Class Initialized
DEBUG - 2020-02-07 10:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 10:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 10:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 10:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 10:32:46 --> Input Class Initialized
INFO - 2020-02-07 10:32:46 --> Input Class Initialized
INFO - 2020-02-07 10:32:46 --> Input Class Initialized
INFO - 2020-02-07 10:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 10:32:46 --> Controller Class Initialized
INFO - 2020-02-07 10:32:46 --> Language Class Initialized
INFO - 2020-02-07 10:32:46 --> Language Class Initialized
INFO - 2020-02-07 10:32:46 --> Language Class Initialized
ERROR - 2020-02-07 10:32:46 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-07 10:32:46 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-07 10:32:46 --> Model "M_tiket" initialized
ERROR - 2020-02-07 10:32:46 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-07 10:32:46 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 10:32:46 --> Loader Class Initialized
INFO - 2020-02-07 10:32:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 10:32:46 --> Helper loaded: url_helper
INFO - 2020-02-07 10:32:46 --> Model "M_pesan" initialized
INFO - 2020-02-07 10:32:46 --> Database Driver Class Initialized
INFO - 2020-02-07 10:32:46 --> Helper loaded: form_helper
DEBUG - 2020-02-07 10:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 10:32:46 --> Form Validation Class Initialized
ERROR - 2020-02-07 10:32:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 10:32:46 --> Config Class Initialized
INFO - 2020-02-07 10:32:46 --> Config Class Initialized
INFO - 2020-02-07 10:32:46 --> Config Class Initialized
INFO - 2020-02-07 10:32:46 --> Config Class Initialized
INFO - 2020-02-07 10:32:46 --> Hooks Class Initialized
INFO - 2020-02-07 10:32:46 --> Hooks Class Initialized
INFO - 2020-02-07 10:32:46 --> Hooks Class Initialized
INFO - 2020-02-07 10:32:46 --> Hooks Class Initialized
DEBUG - 2020-02-07 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 10:32:46 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:46 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:46 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:46 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:46 --> Utf8 Class Initialized
ERROR - 2020-02-07 10:32:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 10:32:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 10:32:46 --> URI Class Initialized
INFO - 2020-02-07 10:32:46 --> URI Class Initialized
INFO - 2020-02-07 10:32:46 --> URI Class Initialized
INFO - 2020-02-07 10:32:46 --> Final output sent to browser
INFO - 2020-02-07 10:32:46 --> Router Class Initialized
DEBUG - 2020-02-07 10:32:46 --> Total execution time: 0.9368
INFO - 2020-02-07 10:32:46 --> URI Class Initialized
INFO - 2020-02-07 10:32:46 --> Output Class Initialized
INFO - 2020-02-07 10:32:46 --> Router Class Initialized
INFO - 2020-02-07 10:32:46 --> Router Class Initialized
INFO - 2020-02-07 10:32:47 --> Router Class Initialized
INFO - 2020-02-07 10:32:47 --> Output Class Initialized
INFO - 2020-02-07 10:32:47 --> Output Class Initialized
INFO - 2020-02-07 10:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 10:32:47 --> Security Class Initialized
INFO - 2020-02-07 10:32:47 --> Config Class Initialized
INFO - 2020-02-07 10:32:47 --> Controller Class Initialized
INFO - 2020-02-07 10:32:47 --> Security Class Initialized
INFO - 2020-02-07 10:32:47 --> Output Class Initialized
INFO - 2020-02-07 10:32:47 --> Security Class Initialized
DEBUG - 2020-02-07 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:47 --> Hooks Class Initialized
INFO - 2020-02-07 10:32:47 --> Input Class Initialized
DEBUG - 2020-02-07 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:47 --> Security Class Initialized
DEBUG - 2020-02-07 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:47 --> Model "M_tiket" initialized
INFO - 2020-02-07 10:32:47 --> Input Class Initialized
INFO - 2020-02-07 10:32:47 --> Input Class Initialized
INFO - 2020-02-07 10:32:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 10:32:47 --> Language Class Initialized
DEBUG - 2020-02-07 10:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 10:32:47 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:47 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:47 --> Language Class Initialized
INFO - 2020-02-07 10:32:47 --> Language Class Initialized
INFO - 2020-02-07 10:32:47 --> Input Class Initialized
ERROR - 2020-02-07 10:32:47 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 10:32:47 --> Model "M_pesan" initialized
INFO - 2020-02-07 10:32:47 --> Language Class Initialized
ERROR - 2020-02-07 10:32:47 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-07 10:32:47 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 10:32:47 --> URI Class Initialized
INFO - 2020-02-07 10:32:47 --> Helper loaded: form_helper
INFO - 2020-02-07 10:32:47 --> Form Validation Class Initialized
INFO - 2020-02-07 10:32:47 --> Config Class Initialized
INFO - 2020-02-07 10:32:47 --> Router Class Initialized
ERROR - 2020-02-07 10:32:47 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 10:32:47 --> Hooks Class Initialized
INFO - 2020-02-07 10:32:47 --> Output Class Initialized
ERROR - 2020-02-07 10:32:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 10:32:47 --> Security Class Initialized
INFO - 2020-02-07 10:32:47 --> Config Class Initialized
ERROR - 2020-02-07 10:32:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 10:32:47 --> Config Class Initialized
DEBUG - 2020-02-07 10:32:47 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:47 --> Hooks Class Initialized
INFO - 2020-02-07 10:32:47 --> Hooks Class Initialized
INFO - 2020-02-07 10:32:47 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
DEBUG - 2020-02-07 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:47 --> Input Class Initialized
INFO - 2020-02-07 10:32:47 --> URI Class Initialized
INFO - 2020-02-07 10:32:47 --> Final output sent to browser
DEBUG - 2020-02-07 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 10:32:47 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:47 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:47 --> Utf8 Class Initialized
DEBUG - 2020-02-07 10:32:47 --> Total execution time: 0.8539
INFO - 2020-02-07 10:32:47 --> Language Class Initialized
INFO - 2020-02-07 10:32:47 --> Router Class Initialized
INFO - 2020-02-07 10:32:47 --> URI Class Initialized
INFO - 2020-02-07 10:32:47 --> URI Class Initialized
ERROR - 2020-02-07 10:32:47 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 10:32:47 --> Output Class Initialized
INFO - 2020-02-07 10:32:47 --> Security Class Initialized
INFO - 2020-02-07 10:32:47 --> Router Class Initialized
INFO - 2020-02-07 10:32:47 --> Router Class Initialized
DEBUG - 2020-02-07 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:47 --> Output Class Initialized
INFO - 2020-02-07 10:32:47 --> Output Class Initialized
INFO - 2020-02-07 10:32:47 --> Input Class Initialized
INFO - 2020-02-07 10:32:47 --> Security Class Initialized
INFO - 2020-02-07 10:32:47 --> Security Class Initialized
INFO - 2020-02-07 10:32:47 --> Language Class Initialized
DEBUG - 2020-02-07 10:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:47 --> Input Class Initialized
INFO - 2020-02-07 10:32:47 --> Input Class Initialized
ERROR - 2020-02-07 10:32:47 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 10:32:47 --> Language Class Initialized
INFO - 2020-02-07 10:32:47 --> Language Class Initialized
ERROR - 2020-02-07 10:32:47 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-07 10:32:47 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 10:32:47 --> Config Class Initialized
INFO - 2020-02-07 10:32:47 --> Hooks Class Initialized
DEBUG - 2020-02-07 10:32:47 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:47 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:47 --> URI Class Initialized
INFO - 2020-02-07 10:32:47 --> Router Class Initialized
INFO - 2020-02-07 10:32:47 --> Output Class Initialized
INFO - 2020-02-07 10:32:47 --> Security Class Initialized
DEBUG - 2020-02-07 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:47 --> Input Class Initialized
INFO - 2020-02-07 10:32:47 --> Language Class Initialized
ERROR - 2020-02-07 10:32:47 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 10:32:47 --> Config Class Initialized
INFO - 2020-02-07 10:32:47 --> Hooks Class Initialized
DEBUG - 2020-02-07 10:32:47 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:47 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:47 --> URI Class Initialized
INFO - 2020-02-07 10:32:47 --> Router Class Initialized
INFO - 2020-02-07 10:32:47 --> Output Class Initialized
INFO - 2020-02-07 10:32:47 --> Security Class Initialized
DEBUG - 2020-02-07 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:47 --> Input Class Initialized
INFO - 2020-02-07 10:32:47 --> Language Class Initialized
ERROR - 2020-02-07 10:32:47 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 10:32:47 --> Config Class Initialized
INFO - 2020-02-07 10:32:47 --> Hooks Class Initialized
DEBUG - 2020-02-07 10:32:47 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:47 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:47 --> URI Class Initialized
INFO - 2020-02-07 10:32:47 --> Router Class Initialized
INFO - 2020-02-07 10:32:47 --> Output Class Initialized
INFO - 2020-02-07 10:32:48 --> Security Class Initialized
DEBUG - 2020-02-07 10:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:48 --> Input Class Initialized
INFO - 2020-02-07 10:32:48 --> Language Class Initialized
ERROR - 2020-02-07 10:32:48 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 10:32:48 --> Config Class Initialized
INFO - 2020-02-07 10:32:48 --> Hooks Class Initialized
DEBUG - 2020-02-07 10:32:48 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:48 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:48 --> URI Class Initialized
INFO - 2020-02-07 10:32:48 --> Router Class Initialized
INFO - 2020-02-07 10:32:48 --> Output Class Initialized
INFO - 2020-02-07 10:32:48 --> Security Class Initialized
DEBUG - 2020-02-07 10:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:48 --> Input Class Initialized
INFO - 2020-02-07 10:32:48 --> Language Class Initialized
ERROR - 2020-02-07 10:32:48 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 10:32:48 --> Config Class Initialized
INFO - 2020-02-07 10:32:48 --> Hooks Class Initialized
DEBUG - 2020-02-07 10:32:48 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:48 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:48 --> URI Class Initialized
INFO - 2020-02-07 10:32:48 --> Router Class Initialized
INFO - 2020-02-07 10:32:48 --> Output Class Initialized
INFO - 2020-02-07 10:32:48 --> Security Class Initialized
DEBUG - 2020-02-07 10:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:48 --> Input Class Initialized
INFO - 2020-02-07 10:32:48 --> Language Class Initialized
ERROR - 2020-02-07 10:32:48 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 10:32:48 --> Config Class Initialized
INFO - 2020-02-07 10:32:48 --> Hooks Class Initialized
DEBUG - 2020-02-07 10:32:48 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:48 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:48 --> URI Class Initialized
INFO - 2020-02-07 10:32:48 --> Router Class Initialized
INFO - 2020-02-07 10:32:48 --> Output Class Initialized
INFO - 2020-02-07 10:32:48 --> Security Class Initialized
DEBUG - 2020-02-07 10:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:48 --> Input Class Initialized
INFO - 2020-02-07 10:32:48 --> Language Class Initialized
ERROR - 2020-02-07 10:32:48 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 10:32:48 --> Config Class Initialized
INFO - 2020-02-07 10:32:48 --> Hooks Class Initialized
DEBUG - 2020-02-07 10:32:48 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:48 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:48 --> URI Class Initialized
INFO - 2020-02-07 10:32:48 --> Router Class Initialized
INFO - 2020-02-07 10:32:48 --> Output Class Initialized
INFO - 2020-02-07 10:32:48 --> Security Class Initialized
DEBUG - 2020-02-07 10:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:48 --> Input Class Initialized
INFO - 2020-02-07 10:32:49 --> Language Class Initialized
ERROR - 2020-02-07 10:32:49 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 10:32:49 --> Config Class Initialized
INFO - 2020-02-07 10:32:49 --> Hooks Class Initialized
DEBUG - 2020-02-07 10:32:49 --> UTF-8 Support Enabled
INFO - 2020-02-07 10:32:49 --> Utf8 Class Initialized
INFO - 2020-02-07 10:32:49 --> URI Class Initialized
INFO - 2020-02-07 10:32:49 --> Router Class Initialized
INFO - 2020-02-07 10:32:49 --> Output Class Initialized
INFO - 2020-02-07 10:32:49 --> Security Class Initialized
DEBUG - 2020-02-07 10:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 10:32:49 --> Input Class Initialized
INFO - 2020-02-07 10:32:49 --> Language Class Initialized
ERROR - 2020-02-07 10:32:49 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 11:04:34 --> Config Class Initialized
INFO - 2020-02-07 11:04:34 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:04:34 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:34 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:34 --> URI Class Initialized
INFO - 2020-02-07 11:04:34 --> Router Class Initialized
INFO - 2020-02-07 11:04:34 --> Output Class Initialized
INFO - 2020-02-07 11:04:34 --> Security Class Initialized
DEBUG - 2020-02-07 11:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:34 --> Input Class Initialized
INFO - 2020-02-07 11:04:34 --> Language Class Initialized
INFO - 2020-02-07 11:04:34 --> Loader Class Initialized
INFO - 2020-02-07 11:04:34 --> Helper loaded: url_helper
INFO - 2020-02-07 11:04:34 --> Database Driver Class Initialized
DEBUG - 2020-02-07 11:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:04:34 --> Controller Class Initialized
INFO - 2020-02-07 11:04:34 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:04:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:04:34 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:04:34 --> Helper loaded: form_helper
INFO - 2020-02-07 11:04:34 --> Form Validation Class Initialized
INFO - 2020-02-07 11:04:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:04:34 --> Final output sent to browser
DEBUG - 2020-02-07 11:04:34 --> Total execution time: 0.5788
INFO - 2020-02-07 11:04:34 --> Config Class Initialized
INFO - 2020-02-07 11:04:34 --> Config Class Initialized
INFO - 2020-02-07 11:04:34 --> Config Class Initialized
INFO - 2020-02-07 11:04:34 --> Config Class Initialized
INFO - 2020-02-07 11:04:34 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:34 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:34 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:34 --> Config Class Initialized
INFO - 2020-02-07 11:04:34 --> Config Class Initialized
INFO - 2020-02-07 11:04:34 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:34 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:34 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:04:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:04:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:04:34 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:34 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:34 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:04:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:04:34 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:34 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:04:34 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:34 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:34 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:34 --> URI Class Initialized
INFO - 2020-02-07 11:04:34 --> URI Class Initialized
INFO - 2020-02-07 11:04:34 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:34 --> URI Class Initialized
INFO - 2020-02-07 11:04:34 --> URI Class Initialized
INFO - 2020-02-07 11:04:34 --> URI Class Initialized
INFO - 2020-02-07 11:04:34 --> Router Class Initialized
INFO - 2020-02-07 11:04:34 --> Router Class Initialized
INFO - 2020-02-07 11:04:34 --> URI Class Initialized
INFO - 2020-02-07 11:04:34 --> Router Class Initialized
INFO - 2020-02-07 11:04:34 --> Router Class Initialized
INFO - 2020-02-07 11:04:34 --> Router Class Initialized
INFO - 2020-02-07 11:04:34 --> Output Class Initialized
INFO - 2020-02-07 11:04:34 --> Router Class Initialized
INFO - 2020-02-07 11:04:34 --> Output Class Initialized
INFO - 2020-02-07 11:04:34 --> Output Class Initialized
INFO - 2020-02-07 11:04:34 --> Security Class Initialized
INFO - 2020-02-07 11:04:34 --> Output Class Initialized
INFO - 2020-02-07 11:04:34 --> Security Class Initialized
INFO - 2020-02-07 11:04:34 --> Output Class Initialized
INFO - 2020-02-07 11:04:34 --> Output Class Initialized
INFO - 2020-02-07 11:04:34 --> Security Class Initialized
DEBUG - 2020-02-07 11:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:34 --> Security Class Initialized
INFO - 2020-02-07 11:04:34 --> Security Class Initialized
INFO - 2020-02-07 11:04:34 --> Security Class Initialized
INFO - 2020-02-07 11:04:34 --> Input Class Initialized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
DEBUG - 2020-02-07 11:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
ERROR - 2020-02-07 11:04:35 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-07 11:04:35 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-07 11:04:35 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-07 11:04:35 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-07 11:04:35 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 11:04:35 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 11:04:35 --> Config Class Initialized
INFO - 2020-02-07 11:04:35 --> Config Class Initialized
INFO - 2020-02-07 11:04:35 --> Config Class Initialized
INFO - 2020-02-07 11:04:35 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:35 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:35 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:35 --> Config Class Initialized
DEBUG - 2020-02-07 11:04:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:04:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:04:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:35 --> Config Class Initialized
INFO - 2020-02-07 11:04:35 --> Config Class Initialized
INFO - 2020-02-07 11:04:35 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:35 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:35 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:35 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:35 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:35 --> URI Class Initialized
INFO - 2020-02-07 11:04:35 --> URI Class Initialized
INFO - 2020-02-07 11:04:35 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:35 --> URI Class Initialized
DEBUG - 2020-02-07 11:04:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:35 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:35 --> Router Class Initialized
INFO - 2020-02-07 11:04:35 --> Router Class Initialized
DEBUG - 2020-02-07 11:04:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:35 --> Router Class Initialized
DEBUG - 2020-02-07 11:04:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:35 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:35 --> URI Class Initialized
INFO - 2020-02-07 11:04:35 --> Output Class Initialized
INFO - 2020-02-07 11:04:35 --> Output Class Initialized
INFO - 2020-02-07 11:04:35 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:35 --> Output Class Initialized
INFO - 2020-02-07 11:04:35 --> URI Class Initialized
INFO - 2020-02-07 11:04:35 --> Security Class Initialized
INFO - 2020-02-07 11:04:35 --> Router Class Initialized
INFO - 2020-02-07 11:04:35 --> Security Class Initialized
INFO - 2020-02-07 11:04:35 --> Security Class Initialized
INFO - 2020-02-07 11:04:35 --> URI Class Initialized
DEBUG - 2020-02-07 11:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:35 --> Router Class Initialized
INFO - 2020-02-07 11:04:35 --> Output Class Initialized
DEBUG - 2020-02-07 11:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:35 --> Router Class Initialized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
INFO - 2020-02-07 11:04:35 --> Security Class Initialized
INFO - 2020-02-07 11:04:35 --> Output Class Initialized
INFO - 2020-02-07 11:04:35 --> Output Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
INFO - 2020-02-07 11:04:35 --> Security Class Initialized
INFO - 2020-02-07 11:04:35 --> Security Class Initialized
DEBUG - 2020-02-07 11:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-07 11:04:35 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-07 11:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
ERROR - 2020-02-07 11:04:35 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:04:35 --> Loader Class Initialized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
INFO - 2020-02-07 11:04:35 --> Helper loaded: url_helper
INFO - 2020-02-07 11:04:35 --> Config Class Initialized
INFO - 2020-02-07 11:04:35 --> Config Class Initialized
INFO - 2020-02-07 11:04:35 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:35 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
INFO - 2020-02-07 11:04:35 --> Loader Class Initialized
INFO - 2020-02-07 11:04:35 --> Database Driver Class Initialized
ERROR - 2020-02-07 11:04:35 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-07 11:04:35 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-07 11:04:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:04:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:35 --> Helper loaded: url_helper
DEBUG - 2020-02-07 11:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:04:35 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:35 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:04:35 --> Database Driver Class Initialized
INFO - 2020-02-07 11:04:35 --> Controller Class Initialized
INFO - 2020-02-07 11:04:35 --> URI Class Initialized
INFO - 2020-02-07 11:04:35 --> URI Class Initialized
DEBUG - 2020-02-07 11:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:04:35 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:04:35 --> Router Class Initialized
INFO - 2020-02-07 11:04:35 --> Router Class Initialized
INFO - 2020-02-07 11:04:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:04:35 --> Output Class Initialized
INFO - 2020-02-07 11:04:35 --> Output Class Initialized
INFO - 2020-02-07 11:04:35 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:04:35 --> Security Class Initialized
INFO - 2020-02-07 11:04:35 --> Security Class Initialized
DEBUG - 2020-02-07 11:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:35 --> Helper loaded: form_helper
INFO - 2020-02-07 11:04:35 --> Form Validation Class Initialized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
ERROR - 2020-02-07 11:04:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 11:04:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 11:04:35 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-07 11:04:35 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 11:04:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:04:35 --> Config Class Initialized
INFO - 2020-02-07 11:04:35 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:35 --> Final output sent to browser
DEBUG - 2020-02-07 11:04:35 --> Total execution time: 0.6567
DEBUG - 2020-02-07 11:04:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:35 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:04:35 --> Controller Class Initialized
INFO - 2020-02-07 11:04:35 --> URI Class Initialized
INFO - 2020-02-07 11:04:35 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:04:35 --> Router Class Initialized
INFO - 2020-02-07 11:04:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:04:35 --> Output Class Initialized
INFO - 2020-02-07 11:04:35 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:04:35 --> Security Class Initialized
DEBUG - 2020-02-07 11:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:35 --> Helper loaded: form_helper
INFO - 2020-02-07 11:04:35 --> Form Validation Class Initialized
INFO - 2020-02-07 11:04:35 --> Input Class Initialized
INFO - 2020-02-07 11:04:35 --> Language Class Initialized
ERROR - 2020-02-07 11:04:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 11:04:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 11:04:35 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 11:04:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:04:36 --> Config Class Initialized
INFO - 2020-02-07 11:04:36 --> Hooks Class Initialized
INFO - 2020-02-07 11:04:36 --> Final output sent to browser
DEBUG - 2020-02-07 11:04:36 --> Total execution time: 0.8721
DEBUG - 2020-02-07 11:04:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:36 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:36 --> URI Class Initialized
INFO - 2020-02-07 11:04:36 --> Router Class Initialized
INFO - 2020-02-07 11:04:36 --> Output Class Initialized
INFO - 2020-02-07 11:04:36 --> Security Class Initialized
DEBUG - 2020-02-07 11:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:36 --> Input Class Initialized
INFO - 2020-02-07 11:04:36 --> Language Class Initialized
ERROR - 2020-02-07 11:04:36 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 11:04:36 --> Config Class Initialized
INFO - 2020-02-07 11:04:36 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:04:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:36 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:36 --> URI Class Initialized
INFO - 2020-02-07 11:04:36 --> Router Class Initialized
INFO - 2020-02-07 11:04:36 --> Output Class Initialized
INFO - 2020-02-07 11:04:36 --> Security Class Initialized
DEBUG - 2020-02-07 11:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:36 --> Input Class Initialized
INFO - 2020-02-07 11:04:36 --> Language Class Initialized
ERROR - 2020-02-07 11:04:36 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 11:04:36 --> Config Class Initialized
INFO - 2020-02-07 11:04:36 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:04:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:36 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:36 --> URI Class Initialized
INFO - 2020-02-07 11:04:36 --> Router Class Initialized
INFO - 2020-02-07 11:04:36 --> Output Class Initialized
INFO - 2020-02-07 11:04:36 --> Security Class Initialized
DEBUG - 2020-02-07 11:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:36 --> Input Class Initialized
INFO - 2020-02-07 11:04:36 --> Language Class Initialized
ERROR - 2020-02-07 11:04:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:04:36 --> Config Class Initialized
INFO - 2020-02-07 11:04:36 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:04:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:36 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:36 --> URI Class Initialized
INFO - 2020-02-07 11:04:36 --> Router Class Initialized
INFO - 2020-02-07 11:04:36 --> Output Class Initialized
INFO - 2020-02-07 11:04:36 --> Security Class Initialized
DEBUG - 2020-02-07 11:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:36 --> Input Class Initialized
INFO - 2020-02-07 11:04:36 --> Language Class Initialized
ERROR - 2020-02-07 11:04:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:04:37 --> Config Class Initialized
INFO - 2020-02-07 11:04:37 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:04:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:37 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:37 --> URI Class Initialized
INFO - 2020-02-07 11:04:37 --> Router Class Initialized
INFO - 2020-02-07 11:04:37 --> Output Class Initialized
INFO - 2020-02-07 11:04:37 --> Security Class Initialized
DEBUG - 2020-02-07 11:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:37 --> Input Class Initialized
INFO - 2020-02-07 11:04:37 --> Language Class Initialized
ERROR - 2020-02-07 11:04:37 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 11:04:37 --> Config Class Initialized
INFO - 2020-02-07 11:04:37 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:04:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:37 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:37 --> URI Class Initialized
INFO - 2020-02-07 11:04:37 --> Router Class Initialized
INFO - 2020-02-07 11:04:37 --> Output Class Initialized
INFO - 2020-02-07 11:04:37 --> Security Class Initialized
DEBUG - 2020-02-07 11:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:37 --> Input Class Initialized
INFO - 2020-02-07 11:04:37 --> Language Class Initialized
ERROR - 2020-02-07 11:04:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 11:04:37 --> Config Class Initialized
INFO - 2020-02-07 11:04:37 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:04:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:37 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:37 --> URI Class Initialized
INFO - 2020-02-07 11:04:37 --> Router Class Initialized
INFO - 2020-02-07 11:04:37 --> Output Class Initialized
INFO - 2020-02-07 11:04:37 --> Security Class Initialized
DEBUG - 2020-02-07 11:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:37 --> Input Class Initialized
INFO - 2020-02-07 11:04:37 --> Language Class Initialized
ERROR - 2020-02-07 11:04:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 11:04:37 --> Config Class Initialized
INFO - 2020-02-07 11:04:37 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:04:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:04:37 --> Utf8 Class Initialized
INFO - 2020-02-07 11:04:37 --> URI Class Initialized
INFO - 2020-02-07 11:04:37 --> Router Class Initialized
INFO - 2020-02-07 11:04:37 --> Output Class Initialized
INFO - 2020-02-07 11:04:37 --> Security Class Initialized
DEBUG - 2020-02-07 11:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:04:38 --> Input Class Initialized
INFO - 2020-02-07 11:04:38 --> Language Class Initialized
ERROR - 2020-02-07 11:04:38 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 11:09:22 --> Config Class Initialized
INFO - 2020-02-07 11:09:22 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:09:22 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:09:22 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:22 --> URI Class Initialized
INFO - 2020-02-07 11:09:22 --> Router Class Initialized
INFO - 2020-02-07 11:09:22 --> Output Class Initialized
INFO - 2020-02-07 11:09:23 --> Security Class Initialized
DEBUG - 2020-02-07 11:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:23 --> Input Class Initialized
INFO - 2020-02-07 11:09:23 --> Language Class Initialized
INFO - 2020-02-07 11:09:23 --> Loader Class Initialized
INFO - 2020-02-07 11:09:23 --> Helper loaded: url_helper
INFO - 2020-02-07 11:09:23 --> Database Driver Class Initialized
DEBUG - 2020-02-07 11:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:09:23 --> Controller Class Initialized
INFO - 2020-02-07 11:09:23 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:09:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:09:23 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:09:23 --> Helper loaded: form_helper
INFO - 2020-02-07 11:09:23 --> Form Validation Class Initialized
INFO - 2020-02-07 11:09:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:09:23 --> Final output sent to browser
DEBUG - 2020-02-07 11:09:23 --> Total execution time: 0.5995
INFO - 2020-02-07 11:09:23 --> Config Class Initialized
INFO - 2020-02-07 11:09:23 --> Config Class Initialized
INFO - 2020-02-07 11:09:23 --> Config Class Initialized
INFO - 2020-02-07 11:09:23 --> Hooks Class Initialized
INFO - 2020-02-07 11:09:23 --> Hooks Class Initialized
INFO - 2020-02-07 11:09:23 --> Hooks Class Initialized
INFO - 2020-02-07 11:09:23 --> Config Class Initialized
INFO - 2020-02-07 11:09:23 --> Config Class Initialized
INFO - 2020-02-07 11:09:23 --> Hooks Class Initialized
INFO - 2020-02-07 11:09:23 --> Hooks Class Initialized
INFO - 2020-02-07 11:09:23 --> Config Class Initialized
DEBUG - 2020-02-07 11:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:09:23 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:09:23 --> Hooks Class Initialized
INFO - 2020-02-07 11:09:23 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:23 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:09:23 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:09:23 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:23 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:23 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:23 --> URI Class Initialized
INFO - 2020-02-07 11:09:23 --> URI Class Initialized
INFO - 2020-02-07 11:09:23 --> URI Class Initialized
DEBUG - 2020-02-07 11:09:23 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:09:23 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:23 --> URI Class Initialized
INFO - 2020-02-07 11:09:23 --> Router Class Initialized
INFO - 2020-02-07 11:09:23 --> Router Class Initialized
INFO - 2020-02-07 11:09:23 --> Router Class Initialized
INFO - 2020-02-07 11:09:23 --> URI Class Initialized
INFO - 2020-02-07 11:09:23 --> URI Class Initialized
INFO - 2020-02-07 11:09:23 --> Router Class Initialized
INFO - 2020-02-07 11:09:23 --> Output Class Initialized
INFO - 2020-02-07 11:09:23 --> Output Class Initialized
INFO - 2020-02-07 11:09:23 --> Output Class Initialized
INFO - 2020-02-07 11:09:23 --> Router Class Initialized
INFO - 2020-02-07 11:09:23 --> Security Class Initialized
INFO - 2020-02-07 11:09:23 --> Security Class Initialized
INFO - 2020-02-07 11:09:23 --> Output Class Initialized
INFO - 2020-02-07 11:09:23 --> Output Class Initialized
INFO - 2020-02-07 11:09:23 --> Router Class Initialized
INFO - 2020-02-07 11:09:23 --> Security Class Initialized
DEBUG - 2020-02-07 11:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:23 --> Security Class Initialized
INFO - 2020-02-07 11:09:23 --> Output Class Initialized
DEBUG - 2020-02-07 11:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:23 --> Security Class Initialized
INFO - 2020-02-07 11:09:23 --> Input Class Initialized
INFO - 2020-02-07 11:09:23 --> Input Class Initialized
DEBUG - 2020-02-07 11:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:23 --> Security Class Initialized
DEBUG - 2020-02-07 11:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:23 --> Input Class Initialized
INFO - 2020-02-07 11:09:23 --> Input Class Initialized
INFO - 2020-02-07 11:09:23 --> Input Class Initialized
INFO - 2020-02-07 11:09:23 --> Language Class Initialized
INFO - 2020-02-07 11:09:23 --> Language Class Initialized
DEBUG - 2020-02-07 11:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:23 --> Language Class Initialized
INFO - 2020-02-07 11:09:23 --> Input Class Initialized
INFO - 2020-02-07 11:09:23 --> Language Class Initialized
ERROR - 2020-02-07 11:09:23 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 11:09:23 --> Language Class Initialized
ERROR - 2020-02-07 11:09:23 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-07 11:09:23 --> Loader Class Initialized
INFO - 2020-02-07 11:09:23 --> Language Class Initialized
INFO - 2020-02-07 11:09:23 --> Helper loaded: url_helper
ERROR - 2020-02-07 11:09:23 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-07 11:09:23 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 11:09:23 --> Config Class Initialized
INFO - 2020-02-07 11:09:23 --> Config Class Initialized
INFO - 2020-02-07 11:09:23 --> Hooks Class Initialized
INFO - 2020-02-07 11:09:23 --> Hooks Class Initialized
ERROR - 2020-02-07 11:09:23 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 11:09:23 --> Config Class Initialized
INFO - 2020-02-07 11:09:23 --> Database Driver Class Initialized
INFO - 2020-02-07 11:09:23 --> Config Class Initialized
INFO - 2020-02-07 11:09:23 --> Hooks Class Initialized
INFO - 2020-02-07 11:09:23 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:09:23 --> Config Class Initialized
INFO - 2020-02-07 11:09:23 --> Hooks Class Initialized
INFO - 2020-02-07 11:09:23 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:23 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-07 11:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:09:23 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:09:23 --> Controller Class Initialized
INFO - 2020-02-07 11:09:23 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:23 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:23 --> URI Class Initialized
INFO - 2020-02-07 11:09:23 --> URI Class Initialized
DEBUG - 2020-02-07 11:09:23 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:09:23 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:23 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:09:23 --> Router Class Initialized
INFO - 2020-02-07 11:09:23 --> URI Class Initialized
INFO - 2020-02-07 11:09:23 --> Router Class Initialized
INFO - 2020-02-07 11:09:23 --> URI Class Initialized
INFO - 2020-02-07 11:09:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:09:24 --> URI Class Initialized
INFO - 2020-02-07 11:09:24 --> Router Class Initialized
INFO - 2020-02-07 11:09:24 --> Router Class Initialized
INFO - 2020-02-07 11:09:24 --> Output Class Initialized
INFO - 2020-02-07 11:09:24 --> Output Class Initialized
INFO - 2020-02-07 11:09:24 --> Security Class Initialized
INFO - 2020-02-07 11:09:24 --> Router Class Initialized
INFO - 2020-02-07 11:09:24 --> Output Class Initialized
INFO - 2020-02-07 11:09:24 --> Security Class Initialized
INFO - 2020-02-07 11:09:24 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:09:24 --> Output Class Initialized
DEBUG - 2020-02-07 11:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:24 --> Security Class Initialized
DEBUG - 2020-02-07 11:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:24 --> Output Class Initialized
INFO - 2020-02-07 11:09:24 --> Security Class Initialized
INFO - 2020-02-07 11:09:24 --> Helper loaded: form_helper
DEBUG - 2020-02-07 11:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:24 --> Security Class Initialized
INFO - 2020-02-07 11:09:24 --> Input Class Initialized
INFO - 2020-02-07 11:09:24 --> Form Validation Class Initialized
INFO - 2020-02-07 11:09:24 --> Input Class Initialized
INFO - 2020-02-07 11:09:24 --> Input Class Initialized
DEBUG - 2020-02-07 11:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:24 --> Language Class Initialized
DEBUG - 2020-02-07 11:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:24 --> Input Class Initialized
INFO - 2020-02-07 11:09:24 --> Language Class Initialized
INFO - 2020-02-07 11:09:24 --> Language Class Initialized
INFO - 2020-02-07 11:09:24 --> Input Class Initialized
INFO - 2020-02-07 11:09:24 --> Loader Class Initialized
ERROR - 2020-02-07 11:09:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 11:09:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 11:09:24 --> Language Class Initialized
ERROR - 2020-02-07 11:09:24 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 11:09:24 --> Language Class Initialized
ERROR - 2020-02-07 11:09:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:09:24 --> Helper loaded: url_helper
INFO - 2020-02-07 11:09:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 11:09:24 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-07 11:09:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:09:24 --> Database Driver Class Initialized
INFO - 2020-02-07 11:09:24 --> Config Class Initialized
INFO - 2020-02-07 11:09:24 --> Config Class Initialized
INFO - 2020-02-07 11:09:24 --> Hooks Class Initialized
INFO - 2020-02-07 11:09:24 --> Hooks Class Initialized
INFO - 2020-02-07 11:09:24 --> Final output sent to browser
DEBUG - 2020-02-07 11:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-07 11:09:24 --> Total execution time: 0.7108
INFO - 2020-02-07 11:09:24 --> Config Class Initialized
DEBUG - 2020-02-07 11:09:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:09:24 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:09:24 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:24 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:24 --> Hooks Class Initialized
INFO - 2020-02-07 11:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:09:24 --> Controller Class Initialized
INFO - 2020-02-07 11:09:24 --> URI Class Initialized
INFO - 2020-02-07 11:09:24 --> URI Class Initialized
DEBUG - 2020-02-07 11:09:24 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:09:24 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:24 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:09:24 --> Router Class Initialized
INFO - 2020-02-07 11:09:24 --> Router Class Initialized
INFO - 2020-02-07 11:09:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:09:24 --> URI Class Initialized
INFO - 2020-02-07 11:09:24 --> Output Class Initialized
INFO - 2020-02-07 11:09:24 --> Output Class Initialized
INFO - 2020-02-07 11:09:24 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:09:24 --> Security Class Initialized
INFO - 2020-02-07 11:09:24 --> Router Class Initialized
INFO - 2020-02-07 11:09:24 --> Security Class Initialized
DEBUG - 2020-02-07 11:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:24 --> Output Class Initialized
INFO - 2020-02-07 11:09:24 --> Helper loaded: form_helper
INFO - 2020-02-07 11:09:24 --> Input Class Initialized
INFO - 2020-02-07 11:09:24 --> Input Class Initialized
INFO - 2020-02-07 11:09:24 --> Form Validation Class Initialized
INFO - 2020-02-07 11:09:24 --> Security Class Initialized
INFO - 2020-02-07 11:09:24 --> Language Class Initialized
INFO - 2020-02-07 11:09:24 --> Language Class Initialized
DEBUG - 2020-02-07 11:09:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-07 11:09:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 11:09:24 --> Input Class Initialized
ERROR - 2020-02-07 11:09:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 11:09:24 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-07 11:09:24 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 11:09:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:09:24 --> Language Class Initialized
INFO - 2020-02-07 11:09:24 --> Final output sent to browser
ERROR - 2020-02-07 11:09:24 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-07 11:09:24 --> Total execution time: 0.6425
INFO - 2020-02-07 11:09:24 --> Config Class Initialized
INFO - 2020-02-07 11:09:24 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:09:24 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:09:24 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:24 --> URI Class Initialized
INFO - 2020-02-07 11:09:24 --> Router Class Initialized
INFO - 2020-02-07 11:09:24 --> Output Class Initialized
INFO - 2020-02-07 11:09:24 --> Security Class Initialized
DEBUG - 2020-02-07 11:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:24 --> Input Class Initialized
INFO - 2020-02-07 11:09:24 --> Language Class Initialized
ERROR - 2020-02-07 11:09:24 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 11:09:24 --> Config Class Initialized
INFO - 2020-02-07 11:09:24 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:09:24 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:09:24 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:24 --> URI Class Initialized
INFO - 2020-02-07 11:09:24 --> Router Class Initialized
INFO - 2020-02-07 11:09:24 --> Output Class Initialized
INFO - 2020-02-07 11:09:24 --> Security Class Initialized
DEBUG - 2020-02-07 11:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:25 --> Input Class Initialized
INFO - 2020-02-07 11:09:25 --> Language Class Initialized
ERROR - 2020-02-07 11:09:25 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 11:09:25 --> Config Class Initialized
INFO - 2020-02-07 11:09:25 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:09:25 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:09:25 --> Utf8 Class Initialized
INFO - 2020-02-07 11:09:25 --> URI Class Initialized
INFO - 2020-02-07 11:09:25 --> Router Class Initialized
INFO - 2020-02-07 11:09:25 --> Output Class Initialized
INFO - 2020-02-07 11:09:25 --> Security Class Initialized
DEBUG - 2020-02-07 11:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:09:25 --> Input Class Initialized
INFO - 2020-02-07 11:09:25 --> Language Class Initialized
ERROR - 2020-02-07 11:09:25 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 11:14:41 --> Config Class Initialized
INFO - 2020-02-07 11:14:41 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:14:41 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:41 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:41 --> URI Class Initialized
INFO - 2020-02-07 11:14:41 --> Router Class Initialized
INFO - 2020-02-07 11:14:41 --> Output Class Initialized
INFO - 2020-02-07 11:14:41 --> Security Class Initialized
DEBUG - 2020-02-07 11:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:41 --> Input Class Initialized
INFO - 2020-02-07 11:14:41 --> Language Class Initialized
INFO - 2020-02-07 11:14:41 --> Loader Class Initialized
INFO - 2020-02-07 11:14:41 --> Helper loaded: url_helper
INFO - 2020-02-07 11:14:41 --> Database Driver Class Initialized
DEBUG - 2020-02-07 11:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:14:42 --> Controller Class Initialized
INFO - 2020-02-07 11:14:42 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:14:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:14:42 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:14:42 --> Helper loaded: form_helper
INFO - 2020-02-07 11:14:42 --> Form Validation Class Initialized
INFO - 2020-02-07 11:14:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:14:42 --> Final output sent to browser
DEBUG - 2020-02-07 11:14:42 --> Total execution time: 0.6143
INFO - 2020-02-07 11:14:42 --> Config Class Initialized
INFO - 2020-02-07 11:14:42 --> Config Class Initialized
INFO - 2020-02-07 11:14:42 --> Config Class Initialized
INFO - 2020-02-07 11:14:42 --> Hooks Class Initialized
INFO - 2020-02-07 11:14:42 --> Hooks Class Initialized
INFO - 2020-02-07 11:14:42 --> Hooks Class Initialized
INFO - 2020-02-07 11:14:42 --> Config Class Initialized
INFO - 2020-02-07 11:14:42 --> Config Class Initialized
INFO - 2020-02-07 11:14:42 --> Config Class Initialized
INFO - 2020-02-07 11:14:42 --> Hooks Class Initialized
INFO - 2020-02-07 11:14:42 --> Hooks Class Initialized
INFO - 2020-02-07 11:14:42 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:14:42 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:42 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:42 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:42 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:14:42 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:42 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:42 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:42 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:42 --> URI Class Initialized
INFO - 2020-02-07 11:14:42 --> URI Class Initialized
INFO - 2020-02-07 11:14:42 --> URI Class Initialized
INFO - 2020-02-07 11:14:42 --> URI Class Initialized
INFO - 2020-02-07 11:14:42 --> URI Class Initialized
INFO - 2020-02-07 11:14:42 --> URI Class Initialized
INFO - 2020-02-07 11:14:42 --> Router Class Initialized
INFO - 2020-02-07 11:14:42 --> Router Class Initialized
INFO - 2020-02-07 11:14:42 --> Router Class Initialized
INFO - 2020-02-07 11:14:42 --> Router Class Initialized
INFO - 2020-02-07 11:14:42 --> Router Class Initialized
INFO - 2020-02-07 11:14:42 --> Output Class Initialized
INFO - 2020-02-07 11:14:42 --> Router Class Initialized
INFO - 2020-02-07 11:14:42 --> Output Class Initialized
INFO - 2020-02-07 11:14:42 --> Output Class Initialized
INFO - 2020-02-07 11:14:42 --> Security Class Initialized
INFO - 2020-02-07 11:14:42 --> Output Class Initialized
INFO - 2020-02-07 11:14:42 --> Security Class Initialized
INFO - 2020-02-07 11:14:42 --> Output Class Initialized
INFO - 2020-02-07 11:14:42 --> Output Class Initialized
INFO - 2020-02-07 11:14:42 --> Security Class Initialized
DEBUG - 2020-02-07 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:42 --> Security Class Initialized
DEBUG - 2020-02-07 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:42 --> Security Class Initialized
INFO - 2020-02-07 11:14:42 --> Security Class Initialized
DEBUG - 2020-02-07 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:42 --> Input Class Initialized
INFO - 2020-02-07 11:14:42 --> Input Class Initialized
INFO - 2020-02-07 11:14:42 --> Input Class Initialized
DEBUG - 2020-02-07 11:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:42 --> Input Class Initialized
INFO - 2020-02-07 11:14:42 --> Input Class Initialized
INFO - 2020-02-07 11:14:42 --> Input Class Initialized
INFO - 2020-02-07 11:14:42 --> Language Class Initialized
INFO - 2020-02-07 11:14:42 --> Language Class Initialized
INFO - 2020-02-07 11:14:42 --> Language Class Initialized
INFO - 2020-02-07 11:14:42 --> Language Class Initialized
ERROR - 2020-02-07 11:14:42 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 11:14:42 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 11:14:42 --> Language Class Initialized
INFO - 2020-02-07 11:14:42 --> Language Class Initialized
INFO - 2020-02-07 11:14:42 --> Loader Class Initialized
ERROR - 2020-02-07 11:14:42 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-07 11:14:42 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-07 11:14:42 --> Helper loaded: url_helper
ERROR - 2020-02-07 11:14:42 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 11:14:42 --> Config Class Initialized
INFO - 2020-02-07 11:14:42 --> Config Class Initialized
INFO - 2020-02-07 11:14:42 --> Hooks Class Initialized
INFO - 2020-02-07 11:14:42 --> Hooks Class Initialized
INFO - 2020-02-07 11:14:42 --> Config Class Initialized
INFO - 2020-02-07 11:14:42 --> Config Class Initialized
INFO - 2020-02-07 11:14:42 --> Config Class Initialized
INFO - 2020-02-07 11:14:42 --> Database Driver Class Initialized
INFO - 2020-02-07 11:14:42 --> Hooks Class Initialized
INFO - 2020-02-07 11:14:42 --> Hooks Class Initialized
INFO - 2020-02-07 11:14:42 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:14:42 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:14:42 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:14:42 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:42 --> Controller Class Initialized
INFO - 2020-02-07 11:14:42 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:42 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:42 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:42 --> URI Class Initialized
INFO - 2020-02-07 11:14:42 --> URI Class Initialized
INFO - 2020-02-07 11:14:42 --> URI Class Initialized
INFO - 2020-02-07 11:14:42 --> URI Class Initialized
INFO - 2020-02-07 11:14:42 --> Router Class Initialized
INFO - 2020-02-07 11:14:42 --> Router Class Initialized
INFO - 2020-02-07 11:14:42 --> URI Class Initialized
INFO - 2020-02-07 11:14:42 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:14:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:14:42 --> Router Class Initialized
INFO - 2020-02-07 11:14:42 --> Output Class Initialized
INFO - 2020-02-07 11:14:42 --> Output Class Initialized
INFO - 2020-02-07 11:14:42 --> Router Class Initialized
INFO - 2020-02-07 11:14:42 --> Router Class Initialized
INFO - 2020-02-07 11:14:42 --> Security Class Initialized
INFO - 2020-02-07 11:14:42 --> Security Class Initialized
INFO - 2020-02-07 11:14:42 --> Output Class Initialized
INFO - 2020-02-07 11:14:42 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:14:42 --> Output Class Initialized
INFO - 2020-02-07 11:14:42 --> Output Class Initialized
INFO - 2020-02-07 11:14:42 --> Security Class Initialized
INFO - 2020-02-07 11:14:42 --> Security Class Initialized
INFO - 2020-02-07 11:14:42 --> Security Class Initialized
INFO - 2020-02-07 11:14:42 --> Helper loaded: form_helper
DEBUG - 2020-02-07 11:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:42 --> Input Class Initialized
INFO - 2020-02-07 11:14:42 --> Input Class Initialized
INFO - 2020-02-07 11:14:42 --> Form Validation Class Initialized
DEBUG - 2020-02-07 11:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:42 --> Input Class Initialized
INFO - 2020-02-07 11:14:42 --> Input Class Initialized
INFO - 2020-02-07 11:14:42 --> Input Class Initialized
INFO - 2020-02-07 11:14:42 --> Language Class Initialized
INFO - 2020-02-07 11:14:42 --> Language Class Initialized
ERROR - 2020-02-07 11:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 11:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 11:14:42 --> Language Class Initialized
INFO - 2020-02-07 11:14:42 --> Language Class Initialized
INFO - 2020-02-07 11:14:42 --> Language Class Initialized
ERROR - 2020-02-07 11:14:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-07 11:14:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:14:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 11:14:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-07 11:14:42 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-07 11:14:42 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 11:14:43 --> Config Class Initialized
INFO - 2020-02-07 11:14:43 --> Config Class Initialized
INFO - 2020-02-07 11:14:43 --> Hooks Class Initialized
INFO - 2020-02-07 11:14:43 --> Hooks Class Initialized
INFO - 2020-02-07 11:14:43 --> Final output sent to browser
INFO - 2020-02-07 11:14:43 --> Config Class Initialized
INFO - 2020-02-07 11:14:43 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:14:43 --> Total execution time: 0.6923
DEBUG - 2020-02-07 11:14:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:14:43 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:43 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:43 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:14:43 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:43 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:43 --> URI Class Initialized
INFO - 2020-02-07 11:14:43 --> URI Class Initialized
INFO - 2020-02-07 11:14:43 --> URI Class Initialized
INFO - 2020-02-07 11:14:43 --> Router Class Initialized
INFO - 2020-02-07 11:14:43 --> Router Class Initialized
INFO - 2020-02-07 11:14:43 --> Router Class Initialized
INFO - 2020-02-07 11:14:43 --> Output Class Initialized
INFO - 2020-02-07 11:14:43 --> Output Class Initialized
INFO - 2020-02-07 11:14:43 --> Security Class Initialized
INFO - 2020-02-07 11:14:43 --> Security Class Initialized
INFO - 2020-02-07 11:14:43 --> Output Class Initialized
INFO - 2020-02-07 11:14:43 --> Security Class Initialized
DEBUG - 2020-02-07 11:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:43 --> Input Class Initialized
INFO - 2020-02-07 11:14:43 --> Input Class Initialized
DEBUG - 2020-02-07 11:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:43 --> Input Class Initialized
INFO - 2020-02-07 11:14:43 --> Language Class Initialized
INFO - 2020-02-07 11:14:43 --> Language Class Initialized
INFO - 2020-02-07 11:14:43 --> Language Class Initialized
ERROR - 2020-02-07 11:14:43 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 11:14:43 --> Loader Class Initialized
ERROR - 2020-02-07 11:14:43 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 11:14:43 --> Helper loaded: url_helper
INFO - 2020-02-07 11:14:43 --> Database Driver Class Initialized
INFO - 2020-02-07 11:14:43 --> Config Class Initialized
INFO - 2020-02-07 11:14:43 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:14:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-07 11:14:43 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:43 --> Controller Class Initialized
INFO - 2020-02-07 11:14:43 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:43 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:14:43 --> URI Class Initialized
INFO - 2020-02-07 11:14:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:14:43 --> Router Class Initialized
INFO - 2020-02-07 11:14:43 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:14:43 --> Output Class Initialized
INFO - 2020-02-07 11:14:43 --> Security Class Initialized
INFO - 2020-02-07 11:14:43 --> Helper loaded: form_helper
INFO - 2020-02-07 11:14:43 --> Form Validation Class Initialized
DEBUG - 2020-02-07 11:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:43 --> Input Class Initialized
ERROR - 2020-02-07 11:14:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 11:14:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 11:14:43 --> Language Class Initialized
INFO - 2020-02-07 11:14:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 11:14:43 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 11:14:43 --> Final output sent to browser
INFO - 2020-02-07 11:14:43 --> Config Class Initialized
INFO - 2020-02-07 11:14:43 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:14:43 --> Total execution time: 0.5714
DEBUG - 2020-02-07 11:14:43 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:43 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:43 --> URI Class Initialized
INFO - 2020-02-07 11:14:43 --> Router Class Initialized
INFO - 2020-02-07 11:14:43 --> Output Class Initialized
INFO - 2020-02-07 11:14:43 --> Security Class Initialized
DEBUG - 2020-02-07 11:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:43 --> Input Class Initialized
INFO - 2020-02-07 11:14:43 --> Language Class Initialized
ERROR - 2020-02-07 11:14:43 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 11:14:43 --> Config Class Initialized
INFO - 2020-02-07 11:14:43 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:14:43 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:43 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:43 --> URI Class Initialized
INFO - 2020-02-07 11:14:44 --> Router Class Initialized
INFO - 2020-02-07 11:14:44 --> Output Class Initialized
INFO - 2020-02-07 11:14:44 --> Security Class Initialized
DEBUG - 2020-02-07 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:44 --> Input Class Initialized
INFO - 2020-02-07 11:14:44 --> Language Class Initialized
ERROR - 2020-02-07 11:14:44 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 11:14:44 --> Config Class Initialized
INFO - 2020-02-07 11:14:44 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:14:44 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:44 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:44 --> URI Class Initialized
INFO - 2020-02-07 11:14:44 --> Router Class Initialized
INFO - 2020-02-07 11:14:44 --> Output Class Initialized
INFO - 2020-02-07 11:14:44 --> Security Class Initialized
DEBUG - 2020-02-07 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:44 --> Input Class Initialized
INFO - 2020-02-07 11:14:44 --> Language Class Initialized
ERROR - 2020-02-07 11:14:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:14:44 --> Config Class Initialized
INFO - 2020-02-07 11:14:44 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:14:44 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:44 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:44 --> URI Class Initialized
INFO - 2020-02-07 11:14:44 --> Router Class Initialized
INFO - 2020-02-07 11:14:44 --> Output Class Initialized
INFO - 2020-02-07 11:14:44 --> Security Class Initialized
DEBUG - 2020-02-07 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:44 --> Input Class Initialized
INFO - 2020-02-07 11:14:44 --> Language Class Initialized
ERROR - 2020-02-07 11:14:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:14:44 --> Config Class Initialized
INFO - 2020-02-07 11:14:44 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:14:44 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:44 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:44 --> URI Class Initialized
INFO - 2020-02-07 11:14:44 --> Router Class Initialized
INFO - 2020-02-07 11:14:44 --> Output Class Initialized
INFO - 2020-02-07 11:14:44 --> Security Class Initialized
DEBUG - 2020-02-07 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:45 --> Input Class Initialized
INFO - 2020-02-07 11:14:45 --> Language Class Initialized
ERROR - 2020-02-07 11:14:45 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 11:14:45 --> Config Class Initialized
INFO - 2020-02-07 11:14:45 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:14:45 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:45 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:45 --> URI Class Initialized
INFO - 2020-02-07 11:14:45 --> Router Class Initialized
INFO - 2020-02-07 11:14:45 --> Output Class Initialized
INFO - 2020-02-07 11:14:45 --> Security Class Initialized
DEBUG - 2020-02-07 11:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:45 --> Input Class Initialized
INFO - 2020-02-07 11:14:45 --> Language Class Initialized
ERROR - 2020-02-07 11:14:45 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 11:14:45 --> Config Class Initialized
INFO - 2020-02-07 11:14:45 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:14:45 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:45 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:45 --> URI Class Initialized
INFO - 2020-02-07 11:14:45 --> Router Class Initialized
INFO - 2020-02-07 11:14:45 --> Output Class Initialized
INFO - 2020-02-07 11:14:45 --> Security Class Initialized
DEBUG - 2020-02-07 11:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:45 --> Input Class Initialized
INFO - 2020-02-07 11:14:45 --> Language Class Initialized
ERROR - 2020-02-07 11:14:45 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 11:14:45 --> Config Class Initialized
INFO - 2020-02-07 11:14:45 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:14:45 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:14:45 --> Utf8 Class Initialized
INFO - 2020-02-07 11:14:45 --> URI Class Initialized
INFO - 2020-02-07 11:14:45 --> Router Class Initialized
INFO - 2020-02-07 11:14:45 --> Output Class Initialized
INFO - 2020-02-07 11:14:45 --> Security Class Initialized
DEBUG - 2020-02-07 11:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:14:45 --> Input Class Initialized
INFO - 2020-02-07 11:14:45 --> Language Class Initialized
ERROR - 2020-02-07 11:14:45 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 11:19:20 --> Config Class Initialized
INFO - 2020-02-07 11:19:20 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:19:20 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:21 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:21 --> URI Class Initialized
INFO - 2020-02-07 11:19:21 --> Router Class Initialized
INFO - 2020-02-07 11:19:21 --> Output Class Initialized
INFO - 2020-02-07 11:19:21 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:21 --> Input Class Initialized
INFO - 2020-02-07 11:19:21 --> Language Class Initialized
INFO - 2020-02-07 11:19:21 --> Loader Class Initialized
INFO - 2020-02-07 11:19:21 --> Helper loaded: url_helper
INFO - 2020-02-07 11:19:21 --> Database Driver Class Initialized
DEBUG - 2020-02-07 11:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:19:21 --> Controller Class Initialized
INFO - 2020-02-07 11:19:21 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:19:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:19:21 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:19:21 --> Helper loaded: form_helper
INFO - 2020-02-07 11:19:21 --> Form Validation Class Initialized
INFO - 2020-02-07 11:19:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:19:21 --> Final output sent to browser
DEBUG - 2020-02-07 11:19:21 --> Total execution time: 0.6130
INFO - 2020-02-07 11:19:21 --> Config Class Initialized
INFO - 2020-02-07 11:19:21 --> Config Class Initialized
INFO - 2020-02-07 11:19:21 --> Config Class Initialized
INFO - 2020-02-07 11:19:21 --> Config Class Initialized
INFO - 2020-02-07 11:19:21 --> Config Class Initialized
INFO - 2020-02-07 11:19:21 --> Hooks Class Initialized
INFO - 2020-02-07 11:19:21 --> Hooks Class Initialized
INFO - 2020-02-07 11:19:21 --> Hooks Class Initialized
INFO - 2020-02-07 11:19:21 --> Hooks Class Initialized
INFO - 2020-02-07 11:19:21 --> Hooks Class Initialized
INFO - 2020-02-07 11:19:21 --> Config Class Initialized
INFO - 2020-02-07 11:19:21 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:19:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:19:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:19:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:19:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:19:21 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:21 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:21 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:21 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:19:21 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:21 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:21 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:21 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:21 --> URI Class Initialized
INFO - 2020-02-07 11:19:21 --> URI Class Initialized
INFO - 2020-02-07 11:19:21 --> URI Class Initialized
INFO - 2020-02-07 11:19:21 --> URI Class Initialized
INFO - 2020-02-07 11:19:21 --> URI Class Initialized
INFO - 2020-02-07 11:19:21 --> URI Class Initialized
INFO - 2020-02-07 11:19:21 --> Router Class Initialized
INFO - 2020-02-07 11:19:21 --> Router Class Initialized
INFO - 2020-02-07 11:19:21 --> Router Class Initialized
INFO - 2020-02-07 11:19:21 --> Router Class Initialized
INFO - 2020-02-07 11:19:21 --> Router Class Initialized
INFO - 2020-02-07 11:19:21 --> Output Class Initialized
INFO - 2020-02-07 11:19:21 --> Output Class Initialized
INFO - 2020-02-07 11:19:21 --> Output Class Initialized
INFO - 2020-02-07 11:19:21 --> Output Class Initialized
INFO - 2020-02-07 11:19:21 --> Output Class Initialized
INFO - 2020-02-07 11:19:21 --> Router Class Initialized
INFO - 2020-02-07 11:19:21 --> Security Class Initialized
INFO - 2020-02-07 11:19:21 --> Security Class Initialized
INFO - 2020-02-07 11:19:21 --> Security Class Initialized
INFO - 2020-02-07 11:19:21 --> Output Class Initialized
INFO - 2020-02-07 11:19:21 --> Security Class Initialized
INFO - 2020-02-07 11:19:21 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:21 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:21 --> Input Class Initialized
INFO - 2020-02-07 11:19:21 --> Input Class Initialized
INFO - 2020-02-07 11:19:21 --> Input Class Initialized
INFO - 2020-02-07 11:19:21 --> Input Class Initialized
INFO - 2020-02-07 11:19:21 --> Input Class Initialized
DEBUG - 2020-02-07 11:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:21 --> Input Class Initialized
INFO - 2020-02-07 11:19:21 --> Language Class Initialized
INFO - 2020-02-07 11:19:21 --> Language Class Initialized
INFO - 2020-02-07 11:19:21 --> Language Class Initialized
INFO - 2020-02-07 11:19:21 --> Language Class Initialized
INFO - 2020-02-07 11:19:21 --> Language Class Initialized
ERROR - 2020-02-07 11:19:21 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-07 11:19:21 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 11:19:21 --> Loader Class Initialized
INFO - 2020-02-07 11:19:21 --> Loader Class Initialized
INFO - 2020-02-07 11:19:22 --> Language Class Initialized
ERROR - 2020-02-07 11:19:22 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-07 11:19:22 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 11:19:22 --> Helper loaded: url_helper
INFO - 2020-02-07 11:19:22 --> Helper loaded: url_helper
INFO - 2020-02-07 11:19:22 --> Config Class Initialized
INFO - 2020-02-07 11:19:22 --> Config Class Initialized
INFO - 2020-02-07 11:19:22 --> Config Class Initialized
INFO - 2020-02-07 11:19:22 --> Hooks Class Initialized
INFO - 2020-02-07 11:19:22 --> Hooks Class Initialized
INFO - 2020-02-07 11:19:22 --> Hooks Class Initialized
INFO - 2020-02-07 11:19:22 --> Database Driver Class Initialized
INFO - 2020-02-07 11:19:22 --> Config Class Initialized
INFO - 2020-02-07 11:19:22 --> Database Driver Class Initialized
INFO - 2020-02-07 11:19:22 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:19:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:19:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:19:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-07 11:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:19:22 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:22 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:22 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-07 11:19:22 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:22 --> Controller Class Initialized
INFO - 2020-02-07 11:19:22 --> URI Class Initialized
INFO - 2020-02-07 11:19:22 --> URI Class Initialized
INFO - 2020-02-07 11:19:22 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:22 --> URI Class Initialized
INFO - 2020-02-07 11:19:22 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:19:22 --> Router Class Initialized
INFO - 2020-02-07 11:19:22 --> Router Class Initialized
INFO - 2020-02-07 11:19:22 --> URI Class Initialized
INFO - 2020-02-07 11:19:22 --> Router Class Initialized
INFO - 2020-02-07 11:19:22 --> Router Class Initialized
INFO - 2020-02-07 11:19:22 --> Output Class Initialized
INFO - 2020-02-07 11:19:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:19:22 --> Output Class Initialized
INFO - 2020-02-07 11:19:22 --> Output Class Initialized
INFO - 2020-02-07 11:19:22 --> Security Class Initialized
INFO - 2020-02-07 11:19:22 --> Security Class Initialized
INFO - 2020-02-07 11:19:22 --> Output Class Initialized
INFO - 2020-02-07 11:19:22 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:19:22 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:22 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:22 --> Helper loaded: form_helper
INFO - 2020-02-07 11:19:22 --> Input Class Initialized
INFO - 2020-02-07 11:19:22 --> Form Validation Class Initialized
INFO - 2020-02-07 11:19:22 --> Input Class Initialized
INFO - 2020-02-07 11:19:22 --> Input Class Initialized
DEBUG - 2020-02-07 11:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:22 --> Input Class Initialized
INFO - 2020-02-07 11:19:22 --> Language Class Initialized
INFO - 2020-02-07 11:19:22 --> Language Class Initialized
INFO - 2020-02-07 11:19:22 --> Language Class Initialized
ERROR - 2020-02-07 11:19:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 11:19:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 11:19:22 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-07 11:19:22 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 11:19:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:19:22 --> Language Class Initialized
ERROR - 2020-02-07 11:19:22 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 11:19:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:19:22 --> Config Class Initialized
INFO - 2020-02-07 11:19:22 --> Config Class Initialized
INFO - 2020-02-07 11:19:22 --> Config Class Initialized
INFO - 2020-02-07 11:19:22 --> Hooks Class Initialized
INFO - 2020-02-07 11:19:22 --> Final output sent to browser
INFO - 2020-02-07 11:19:22 --> Hooks Class Initialized
INFO - 2020-02-07 11:19:22 --> Hooks Class Initialized
INFO - 2020-02-07 11:19:22 --> Config Class Initialized
INFO - 2020-02-07 11:19:22 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:19:22 --> Total execution time: 0.8031
DEBUG - 2020-02-07 11:19:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:19:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:19:22 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:22 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:19:22 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:22 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:19:22 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:22 --> Controller Class Initialized
INFO - 2020-02-07 11:19:22 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:22 --> URI Class Initialized
INFO - 2020-02-07 11:19:22 --> URI Class Initialized
INFO - 2020-02-07 11:19:22 --> URI Class Initialized
INFO - 2020-02-07 11:19:22 --> Router Class Initialized
INFO - 2020-02-07 11:19:22 --> Router Class Initialized
INFO - 2020-02-07 11:19:22 --> URI Class Initialized
INFO - 2020-02-07 11:19:22 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:19:22 --> Router Class Initialized
INFO - 2020-02-07 11:19:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:19:22 --> Output Class Initialized
INFO - 2020-02-07 11:19:22 --> Output Class Initialized
INFO - 2020-02-07 11:19:22 --> Router Class Initialized
INFO - 2020-02-07 11:19:22 --> Output Class Initialized
INFO - 2020-02-07 11:19:22 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:19:22 --> Security Class Initialized
INFO - 2020-02-07 11:19:22 --> Security Class Initialized
INFO - 2020-02-07 11:19:22 --> Output Class Initialized
INFO - 2020-02-07 11:19:22 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:22 --> Security Class Initialized
INFO - 2020-02-07 11:19:22 --> Helper loaded: form_helper
INFO - 2020-02-07 11:19:22 --> Input Class Initialized
INFO - 2020-02-07 11:19:22 --> Input Class Initialized
INFO - 2020-02-07 11:19:22 --> Form Validation Class Initialized
INFO - 2020-02-07 11:19:22 --> Input Class Initialized
DEBUG - 2020-02-07 11:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:22 --> Input Class Initialized
INFO - 2020-02-07 11:19:22 --> Language Class Initialized
INFO - 2020-02-07 11:19:22 --> Language Class Initialized
INFO - 2020-02-07 11:19:22 --> Language Class Initialized
ERROR - 2020-02-07 11:19:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 11:19:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 11:19:22 --> Language Class Initialized
ERROR - 2020-02-07 11:19:22 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-07 11:19:22 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-07 11:19:22 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 11:19:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 11:19:22 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 11:19:22 --> Final output sent to browser
INFO - 2020-02-07 11:19:22 --> Config Class Initialized
DEBUG - 2020-02-07 11:19:22 --> Total execution time: 1.1464
INFO - 2020-02-07 11:19:22 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:19:22 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:22 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:22 --> URI Class Initialized
INFO - 2020-02-07 11:19:22 --> Router Class Initialized
INFO - 2020-02-07 11:19:22 --> Output Class Initialized
INFO - 2020-02-07 11:19:22 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:23 --> Input Class Initialized
INFO - 2020-02-07 11:19:23 --> Language Class Initialized
ERROR - 2020-02-07 11:19:23 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 11:19:23 --> Config Class Initialized
INFO - 2020-02-07 11:19:23 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:19:23 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:23 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:23 --> URI Class Initialized
INFO - 2020-02-07 11:19:23 --> Router Class Initialized
INFO - 2020-02-07 11:19:23 --> Output Class Initialized
INFO - 2020-02-07 11:19:23 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:23 --> Input Class Initialized
INFO - 2020-02-07 11:19:23 --> Language Class Initialized
ERROR - 2020-02-07 11:19:23 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 11:19:23 --> Config Class Initialized
INFO - 2020-02-07 11:19:23 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:19:23 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:23 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:23 --> URI Class Initialized
INFO - 2020-02-07 11:19:23 --> Router Class Initialized
INFO - 2020-02-07 11:19:23 --> Output Class Initialized
INFO - 2020-02-07 11:19:23 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:23 --> Input Class Initialized
INFO - 2020-02-07 11:19:23 --> Language Class Initialized
ERROR - 2020-02-07 11:19:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:19:23 --> Config Class Initialized
INFO - 2020-02-07 11:19:23 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:19:23 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:23 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:23 --> URI Class Initialized
INFO - 2020-02-07 11:19:23 --> Router Class Initialized
INFO - 2020-02-07 11:19:23 --> Output Class Initialized
INFO - 2020-02-07 11:19:23 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:23 --> Input Class Initialized
INFO - 2020-02-07 11:19:23 --> Language Class Initialized
ERROR - 2020-02-07 11:19:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:19:24 --> Config Class Initialized
INFO - 2020-02-07 11:19:24 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:19:24 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:24 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:24 --> URI Class Initialized
INFO - 2020-02-07 11:19:24 --> Router Class Initialized
INFO - 2020-02-07 11:19:24 --> Output Class Initialized
INFO - 2020-02-07 11:19:24 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:24 --> Input Class Initialized
INFO - 2020-02-07 11:19:24 --> Language Class Initialized
ERROR - 2020-02-07 11:19:24 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 11:19:24 --> Config Class Initialized
INFO - 2020-02-07 11:19:24 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:19:24 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:24 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:24 --> URI Class Initialized
INFO - 2020-02-07 11:19:24 --> Router Class Initialized
INFO - 2020-02-07 11:19:24 --> Output Class Initialized
INFO - 2020-02-07 11:19:24 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:24 --> Input Class Initialized
INFO - 2020-02-07 11:19:24 --> Language Class Initialized
ERROR - 2020-02-07 11:19:24 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 11:19:24 --> Config Class Initialized
INFO - 2020-02-07 11:19:24 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:19:24 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:24 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:24 --> URI Class Initialized
INFO - 2020-02-07 11:19:24 --> Router Class Initialized
INFO - 2020-02-07 11:19:24 --> Output Class Initialized
INFO - 2020-02-07 11:19:24 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:24 --> Input Class Initialized
INFO - 2020-02-07 11:19:24 --> Language Class Initialized
ERROR - 2020-02-07 11:19:24 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 11:19:24 --> Config Class Initialized
INFO - 2020-02-07 11:19:24 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:19:25 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:19:25 --> Utf8 Class Initialized
INFO - 2020-02-07 11:19:25 --> URI Class Initialized
INFO - 2020-02-07 11:19:25 --> Router Class Initialized
INFO - 2020-02-07 11:19:25 --> Output Class Initialized
INFO - 2020-02-07 11:19:25 --> Security Class Initialized
DEBUG - 2020-02-07 11:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:19:25 --> Input Class Initialized
INFO - 2020-02-07 11:19:25 --> Language Class Initialized
ERROR - 2020-02-07 11:19:25 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 11:24:51 --> Config Class Initialized
INFO - 2020-02-07 11:24:51 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:51 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:51 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:51 --> URI Class Initialized
INFO - 2020-02-07 11:24:51 --> Router Class Initialized
INFO - 2020-02-07 11:24:51 --> Output Class Initialized
INFO - 2020-02-07 11:24:51 --> Security Class Initialized
DEBUG - 2020-02-07 11:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:51 --> Input Class Initialized
INFO - 2020-02-07 11:24:51 --> Language Class Initialized
INFO - 2020-02-07 11:24:51 --> Loader Class Initialized
INFO - 2020-02-07 11:24:51 --> Helper loaded: url_helper
INFO - 2020-02-07 11:24:51 --> Database Driver Class Initialized
DEBUG - 2020-02-07 11:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:24:51 --> Controller Class Initialized
INFO - 2020-02-07 11:24:51 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:24:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:24:51 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:24:51 --> Helper loaded: form_helper
INFO - 2020-02-07 11:24:51 --> Form Validation Class Initialized
INFO - 2020-02-07 11:24:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:24:51 --> Final output sent to browser
DEBUG - 2020-02-07 11:24:51 --> Total execution time: 0.6630
INFO - 2020-02-07 11:24:51 --> Config Class Initialized
INFO - 2020-02-07 11:24:51 --> Config Class Initialized
INFO - 2020-02-07 11:24:51 --> Config Class Initialized
INFO - 2020-02-07 11:24:51 --> Hooks Class Initialized
INFO - 2020-02-07 11:24:51 --> Hooks Class Initialized
INFO - 2020-02-07 11:24:51 --> Config Class Initialized
INFO - 2020-02-07 11:24:52 --> Hooks Class Initialized
INFO - 2020-02-07 11:24:52 --> Config Class Initialized
INFO - 2020-02-07 11:24:52 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:52 --> Config Class Initialized
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:52 --> Hooks Class Initialized
INFO - 2020-02-07 11:24:52 --> Hooks Class Initialized
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
INFO - 2020-02-07 11:24:52 --> Security Class Initialized
INFO - 2020-02-07 11:24:52 --> Security Class Initialized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
DEBUG - 2020-02-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:52 --> Security Class Initialized
INFO - 2020-02-07 11:24:52 --> Security Class Initialized
INFO - 2020-02-07 11:24:52 --> Security Class Initialized
DEBUG - 2020-02-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
INFO - 2020-02-07 11:24:52 --> Input Class Initialized
INFO - 2020-02-07 11:24:52 --> Input Class Initialized
DEBUG - 2020-02-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:52 --> Security Class Initialized
DEBUG - 2020-02-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:52 --> Input Class Initialized
INFO - 2020-02-07 11:24:52 --> Input Class Initialized
INFO - 2020-02-07 11:24:52 --> Language Class Initialized
INFO - 2020-02-07 11:24:52 --> Language Class Initialized
INFO - 2020-02-07 11:24:52 --> Input Class Initialized
DEBUG - 2020-02-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:52 --> Input Class Initialized
INFO - 2020-02-07 11:24:52 --> Language Class Initialized
INFO - 2020-02-07 11:24:52 --> Language Class Initialized
INFO - 2020-02-07 11:24:52 --> Language Class Initialized
INFO - 2020-02-07 11:24:52 --> Loader Class Initialized
ERROR - 2020-02-07 11:24:52 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-07 11:24:52 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-07 11:24:52 --> Helper loaded: url_helper
INFO - 2020-02-07 11:24:52 --> Language Class Initialized
INFO - 2020-02-07 11:24:52 --> Loader Class Initialized
ERROR - 2020-02-07 11:24:52 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 11:24:52 --> Config Class Initialized
INFO - 2020-02-07 11:24:52 --> Hooks Class Initialized
ERROR - 2020-02-07 11:24:52 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 11:24:52 --> Helper loaded: url_helper
INFO - 2020-02-07 11:24:52 --> Database Driver Class Initialized
INFO - 2020-02-07 11:24:52 --> Config Class Initialized
INFO - 2020-02-07 11:24:52 --> Config Class Initialized
INFO - 2020-02-07 11:24:52 --> Hooks Class Initialized
INFO - 2020-02-07 11:24:52 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:24:52 --> Database Driver Class Initialized
INFO - 2020-02-07 11:24:52 --> Config Class Initialized
INFO - 2020-02-07 11:24:52 --> Hooks Class Initialized
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:52 --> Controller Class Initialized
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:52 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
INFO - 2020-02-07 11:24:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:24:52 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> Security Class Initialized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
DEBUG - 2020-02-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:52 --> Security Class Initialized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
INFO - 2020-02-07 11:24:52 --> Security Class Initialized
INFO - 2020-02-07 11:24:52 --> Helper loaded: form_helper
INFO - 2020-02-07 11:24:52 --> Form Validation Class Initialized
INFO - 2020-02-07 11:24:52 --> Input Class Initialized
DEBUG - 2020-02-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:52 --> Security Class Initialized
INFO - 2020-02-07 11:24:52 --> Input Class Initialized
INFO - 2020-02-07 11:24:52 --> Input Class Initialized
INFO - 2020-02-07 11:24:52 --> Language Class Initialized
DEBUG - 2020-02-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-07 11:24:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 11:24:52 --> Input Class Initialized
INFO - 2020-02-07 11:24:52 --> Language Class Initialized
ERROR - 2020-02-07 11:24:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 11:24:52 --> Language Class Initialized
ERROR - 2020-02-07 11:24:52 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 11:24:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 11:24:52 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 11:24:52 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:24:52 --> Language Class Initialized
INFO - 2020-02-07 11:24:52 --> Config Class Initialized
INFO - 2020-02-07 11:24:52 --> Hooks Class Initialized
INFO - 2020-02-07 11:24:52 --> Final output sent to browser
ERROR - 2020-02-07 11:24:52 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 11:24:52 --> Config Class Initialized
INFO - 2020-02-07 11:24:52 --> Config Class Initialized
INFO - 2020-02-07 11:24:52 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:52 --> Total execution time: 0.7332
INFO - 2020-02-07 11:24:52 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:52 --> Config Class Initialized
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:52 --> Hooks Class Initialized
INFO - 2020-02-07 11:24:52 --> Controller Class Initialized
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
INFO - 2020-02-07 11:24:52 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
DEBUG - 2020-02-07 11:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:24:52 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
INFO - 2020-02-07 11:24:52 --> URI Class Initialized
INFO - 2020-02-07 11:24:52 --> Security Class Initialized
INFO - 2020-02-07 11:24:52 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
DEBUG - 2020-02-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:52 --> Router Class Initialized
INFO - 2020-02-07 11:24:52 --> Security Class Initialized
INFO - 2020-02-07 11:24:52 --> Helper loaded: form_helper
INFO - 2020-02-07 11:24:52 --> Security Class Initialized
INFO - 2020-02-07 11:24:52 --> Input Class Initialized
DEBUG - 2020-02-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:52 --> Form Validation Class Initialized
INFO - 2020-02-07 11:24:52 --> Output Class Initialized
INFO - 2020-02-07 11:24:53 --> Input Class Initialized
INFO - 2020-02-07 11:24:53 --> Input Class Initialized
INFO - 2020-02-07 11:24:53 --> Language Class Initialized
INFO - 2020-02-07 11:24:53 --> Security Class Initialized
ERROR - 2020-02-07 11:24:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 11:24:53 --> Language Class Initialized
ERROR - 2020-02-07 11:24:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 11:24:53 --> Language Class Initialized
DEBUG - 2020-02-07 11:24:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-07 11:24:53 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 11:24:53 --> Input Class Initialized
INFO - 2020-02-07 11:24:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 11:24:53 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-07 11:24:53 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 11:24:53 --> Final output sent to browser
INFO - 2020-02-07 11:24:53 --> Language Class Initialized
DEBUG - 2020-02-07 11:24:53 --> Total execution time: 1.2301
ERROR - 2020-02-07 11:24:53 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 11:24:53 --> Config Class Initialized
INFO - 2020-02-07 11:24:53 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:53 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:53 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:53 --> URI Class Initialized
INFO - 2020-02-07 11:24:53 --> Router Class Initialized
INFO - 2020-02-07 11:24:53 --> Output Class Initialized
INFO - 2020-02-07 11:24:53 --> Security Class Initialized
DEBUG - 2020-02-07 11:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:53 --> Input Class Initialized
INFO - 2020-02-07 11:24:53 --> Language Class Initialized
ERROR - 2020-02-07 11:24:53 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 11:24:53 --> Config Class Initialized
INFO - 2020-02-07 11:24:53 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:53 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:53 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:53 --> URI Class Initialized
INFO - 2020-02-07 11:24:53 --> Router Class Initialized
INFO - 2020-02-07 11:24:53 --> Output Class Initialized
INFO - 2020-02-07 11:24:53 --> Security Class Initialized
DEBUG - 2020-02-07 11:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:54 --> Input Class Initialized
INFO - 2020-02-07 11:24:54 --> Language Class Initialized
ERROR - 2020-02-07 11:24:54 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 11:24:54 --> Config Class Initialized
INFO - 2020-02-07 11:24:54 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:54 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:54 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:54 --> URI Class Initialized
INFO - 2020-02-07 11:24:54 --> Router Class Initialized
INFO - 2020-02-07 11:24:54 --> Output Class Initialized
INFO - 2020-02-07 11:24:54 --> Security Class Initialized
DEBUG - 2020-02-07 11:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:54 --> Input Class Initialized
INFO - 2020-02-07 11:24:54 --> Language Class Initialized
ERROR - 2020-02-07 11:24:54 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 11:24:54 --> Config Class Initialized
INFO - 2020-02-07 11:24:54 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:54 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:54 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:55 --> URI Class Initialized
INFO - 2020-02-07 11:24:55 --> Router Class Initialized
INFO - 2020-02-07 11:24:55 --> Output Class Initialized
INFO - 2020-02-07 11:24:55 --> Security Class Initialized
DEBUG - 2020-02-07 11:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:55 --> Input Class Initialized
INFO - 2020-02-07 11:24:55 --> Language Class Initialized
ERROR - 2020-02-07 11:24:55 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:24:55 --> Config Class Initialized
INFO - 2020-02-07 11:24:55 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:55 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:55 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:55 --> URI Class Initialized
INFO - 2020-02-07 11:24:55 --> Router Class Initialized
INFO - 2020-02-07 11:24:55 --> Output Class Initialized
INFO - 2020-02-07 11:24:55 --> Security Class Initialized
DEBUG - 2020-02-07 11:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:55 --> Input Class Initialized
INFO - 2020-02-07 11:24:55 --> Language Class Initialized
ERROR - 2020-02-07 11:24:55 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:24:55 --> Config Class Initialized
INFO - 2020-02-07 11:24:56 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:56 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:56 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:56 --> URI Class Initialized
INFO - 2020-02-07 11:24:56 --> Router Class Initialized
INFO - 2020-02-07 11:24:56 --> Output Class Initialized
INFO - 2020-02-07 11:24:56 --> Security Class Initialized
DEBUG - 2020-02-07 11:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:56 --> Input Class Initialized
INFO - 2020-02-07 11:24:56 --> Language Class Initialized
ERROR - 2020-02-07 11:24:56 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 11:24:56 --> Config Class Initialized
INFO - 2020-02-07 11:24:56 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:56 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:56 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:56 --> URI Class Initialized
INFO - 2020-02-07 11:24:56 --> Router Class Initialized
INFO - 2020-02-07 11:24:56 --> Output Class Initialized
INFO - 2020-02-07 11:24:56 --> Security Class Initialized
DEBUG - 2020-02-07 11:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:56 --> Input Class Initialized
INFO - 2020-02-07 11:24:56 --> Language Class Initialized
ERROR - 2020-02-07 11:24:56 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 11:24:56 --> Config Class Initialized
INFO - 2020-02-07 11:24:56 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:56 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:56 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:56 --> URI Class Initialized
INFO - 2020-02-07 11:24:56 --> Router Class Initialized
INFO - 2020-02-07 11:24:56 --> Output Class Initialized
INFO - 2020-02-07 11:24:56 --> Security Class Initialized
DEBUG - 2020-02-07 11:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:56 --> Input Class Initialized
INFO - 2020-02-07 11:24:56 --> Language Class Initialized
ERROR - 2020-02-07 11:24:56 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 11:24:56 --> Config Class Initialized
INFO - 2020-02-07 11:24:56 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:24:56 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:24:56 --> Utf8 Class Initialized
INFO - 2020-02-07 11:24:56 --> URI Class Initialized
INFO - 2020-02-07 11:24:57 --> Router Class Initialized
INFO - 2020-02-07 11:24:57 --> Output Class Initialized
INFO - 2020-02-07 11:24:57 --> Security Class Initialized
DEBUG - 2020-02-07 11:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:24:57 --> Input Class Initialized
INFO - 2020-02-07 11:24:57 --> Language Class Initialized
ERROR - 2020-02-07 11:24:57 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 11:28:09 --> Config Class Initialized
INFO - 2020-02-07 11:28:09 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:28:09 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:09 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:09 --> URI Class Initialized
INFO - 2020-02-07 11:28:09 --> Router Class Initialized
INFO - 2020-02-07 11:28:09 --> Output Class Initialized
INFO - 2020-02-07 11:28:09 --> Security Class Initialized
DEBUG - 2020-02-07 11:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:09 --> Input Class Initialized
INFO - 2020-02-07 11:28:10 --> Language Class Initialized
INFO - 2020-02-07 11:28:10 --> Loader Class Initialized
INFO - 2020-02-07 11:28:10 --> Helper loaded: url_helper
INFO - 2020-02-07 11:28:10 --> Database Driver Class Initialized
DEBUG - 2020-02-07 11:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:28:10 --> Controller Class Initialized
INFO - 2020-02-07 11:28:10 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:28:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:28:10 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:28:10 --> Helper loaded: form_helper
INFO - 2020-02-07 11:28:10 --> Form Validation Class Initialized
INFO - 2020-02-07 11:28:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:28:10 --> Final output sent to browser
DEBUG - 2020-02-07 11:28:10 --> Total execution time: 0.9273
INFO - 2020-02-07 11:28:10 --> Config Class Initialized
INFO - 2020-02-07 11:28:10 --> Config Class Initialized
INFO - 2020-02-07 11:28:10 --> Config Class Initialized
INFO - 2020-02-07 11:28:10 --> Hooks Class Initialized
INFO - 2020-02-07 11:28:10 --> Hooks Class Initialized
INFO - 2020-02-07 11:28:10 --> Hooks Class Initialized
INFO - 2020-02-07 11:28:10 --> Config Class Initialized
INFO - 2020-02-07 11:28:10 --> Config Class Initialized
INFO - 2020-02-07 11:28:10 --> Config Class Initialized
INFO - 2020-02-07 11:28:10 --> Hooks Class Initialized
INFO - 2020-02-07 11:28:10 --> Hooks Class Initialized
INFO - 2020-02-07 11:28:10 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:28:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:28:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:28:10 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:10 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:28:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:28:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:28:10 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:10 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:10 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:10 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:10 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:10 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:10 --> URI Class Initialized
INFO - 2020-02-07 11:28:10 --> URI Class Initialized
INFO - 2020-02-07 11:28:10 --> URI Class Initialized
INFO - 2020-02-07 11:28:10 --> URI Class Initialized
INFO - 2020-02-07 11:28:10 --> URI Class Initialized
INFO - 2020-02-07 11:28:10 --> Router Class Initialized
INFO - 2020-02-07 11:28:10 --> Router Class Initialized
INFO - 2020-02-07 11:28:10 --> URI Class Initialized
INFO - 2020-02-07 11:28:10 --> Router Class Initialized
INFO - 2020-02-07 11:28:10 --> Router Class Initialized
INFO - 2020-02-07 11:28:10 --> Output Class Initialized
INFO - 2020-02-07 11:28:10 --> Router Class Initialized
INFO - 2020-02-07 11:28:10 --> Output Class Initialized
INFO - 2020-02-07 11:28:10 --> Output Class Initialized
INFO - 2020-02-07 11:28:10 --> Router Class Initialized
INFO - 2020-02-07 11:28:10 --> Security Class Initialized
INFO - 2020-02-07 11:28:10 --> Output Class Initialized
INFO - 2020-02-07 11:28:10 --> Output Class Initialized
INFO - 2020-02-07 11:28:10 --> Security Class Initialized
INFO - 2020-02-07 11:28:10 --> Security Class Initialized
INFO - 2020-02-07 11:28:10 --> Output Class Initialized
DEBUG - 2020-02-07 11:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:10 --> Security Class Initialized
DEBUG - 2020-02-07 11:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:10 --> Security Class Initialized
DEBUG - 2020-02-07 11:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:10 --> Security Class Initialized
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
DEBUG - 2020-02-07 11:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
ERROR - 2020-02-07 11:28:11 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
ERROR - 2020-02-07 11:28:11 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-07 11:28:11 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-07 11:28:11 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-07 11:28:11 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 11:28:11 --> Config Class Initialized
INFO - 2020-02-07 11:28:11 --> Config Class Initialized
INFO - 2020-02-07 11:28:11 --> Config Class Initialized
INFO - 2020-02-07 11:28:11 --> Loader Class Initialized
INFO - 2020-02-07 11:28:11 --> Hooks Class Initialized
INFO - 2020-02-07 11:28:11 --> Hooks Class Initialized
INFO - 2020-02-07 11:28:11 --> Hooks Class Initialized
INFO - 2020-02-07 11:28:11 --> Helper loaded: url_helper
INFO - 2020-02-07 11:28:11 --> Config Class Initialized
INFO - 2020-02-07 11:28:11 --> Config Class Initialized
INFO - 2020-02-07 11:28:11 --> Hooks Class Initialized
INFO - 2020-02-07 11:28:11 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:28:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:28:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:28:11 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:11 --> Database Driver Class Initialized
INFO - 2020-02-07 11:28:11 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:11 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:11 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:28:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:28:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:28:11 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:11 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:28:11 --> URI Class Initialized
INFO - 2020-02-07 11:28:11 --> URI Class Initialized
INFO - 2020-02-07 11:28:11 --> URI Class Initialized
INFO - 2020-02-07 11:28:11 --> URI Class Initialized
INFO - 2020-02-07 11:28:11 --> Controller Class Initialized
INFO - 2020-02-07 11:28:11 --> URI Class Initialized
INFO - 2020-02-07 11:28:11 --> Router Class Initialized
INFO - 2020-02-07 11:28:11 --> Router Class Initialized
INFO - 2020-02-07 11:28:11 --> Router Class Initialized
INFO - 2020-02-07 11:28:11 --> Router Class Initialized
INFO - 2020-02-07 11:28:11 --> Output Class Initialized
INFO - 2020-02-07 11:28:11 --> Output Class Initialized
INFO - 2020-02-07 11:28:11 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:28:11 --> Output Class Initialized
INFO - 2020-02-07 11:28:11 --> Router Class Initialized
INFO - 2020-02-07 11:28:11 --> Security Class Initialized
INFO - 2020-02-07 11:28:11 --> Security Class Initialized
INFO - 2020-02-07 11:28:11 --> Security Class Initialized
INFO - 2020-02-07 11:28:11 --> Output Class Initialized
INFO - 2020-02-07 11:28:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:28:11 --> Output Class Initialized
DEBUG - 2020-02-07 11:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:11 --> Security Class Initialized
INFO - 2020-02-07 11:28:11 --> Security Class Initialized
DEBUG - 2020-02-07 11:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:11 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
DEBUG - 2020-02-07 11:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:11 --> Helper loaded: form_helper
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
INFO - 2020-02-07 11:28:11 --> Form Validation Class Initialized
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
ERROR - 2020-02-07 11:28:11 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 11:28:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:28:11 --> Loader Class Initialized
ERROR - 2020-02-07 11:28:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 11:28:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 11:28:11 --> Helper loaded: url_helper
ERROR - 2020-02-07 11:28:11 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-07 11:28:11 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 11:28:11 --> Config Class Initialized
INFO - 2020-02-07 11:28:11 --> Config Class Initialized
INFO - 2020-02-07 11:28:11 --> Hooks Class Initialized
INFO - 2020-02-07 11:28:11 --> Hooks Class Initialized
INFO - 2020-02-07 11:28:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:28:11 --> Database Driver Class Initialized
INFO - 2020-02-07 11:28:11 --> Config Class Initialized
INFO - 2020-02-07 11:28:11 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:28:11 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:11 --> Final output sent to browser
DEBUG - 2020-02-07 11:28:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:28:11 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:11 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:28:11 --> Total execution time: 0.9228
DEBUG - 2020-02-07 11:28:11 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:28:11 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:11 --> URI Class Initialized
INFO - 2020-02-07 11:28:11 --> URI Class Initialized
INFO - 2020-02-07 11:28:11 --> Controller Class Initialized
INFO - 2020-02-07 11:28:11 --> URI Class Initialized
INFO - 2020-02-07 11:28:11 --> Router Class Initialized
INFO - 2020-02-07 11:28:11 --> Router Class Initialized
INFO - 2020-02-07 11:28:11 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:28:11 --> Router Class Initialized
INFO - 2020-02-07 11:28:11 --> Output Class Initialized
INFO - 2020-02-07 11:28:11 --> Output Class Initialized
INFO - 2020-02-07 11:28:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:28:11 --> Security Class Initialized
INFO - 2020-02-07 11:28:11 --> Output Class Initialized
INFO - 2020-02-07 11:28:11 --> Security Class Initialized
INFO - 2020-02-07 11:28:11 --> Model "M_pesan" initialized
DEBUG - 2020-02-07 11:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:11 --> Security Class Initialized
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
DEBUG - 2020-02-07 11:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:11 --> Helper loaded: form_helper
INFO - 2020-02-07 11:28:11 --> Form Validation Class Initialized
INFO - 2020-02-07 11:28:11 --> Input Class Initialized
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
INFO - 2020-02-07 11:28:11 --> Language Class Initialized
ERROR - 2020-02-07 11:28:11 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-07 11:28:11 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-07 11:28:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 11:28:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 11:28:11 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 11:28:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:28:11 --> Config Class Initialized
INFO - 2020-02-07 11:28:11 --> Hooks Class Initialized
INFO - 2020-02-07 11:28:11 --> Final output sent to browser
DEBUG - 2020-02-07 11:28:11 --> Total execution time: 0.7231
DEBUG - 2020-02-07 11:28:11 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:12 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:12 --> URI Class Initialized
INFO - 2020-02-07 11:28:12 --> Router Class Initialized
INFO - 2020-02-07 11:28:12 --> Output Class Initialized
INFO - 2020-02-07 11:28:12 --> Security Class Initialized
DEBUG - 2020-02-07 11:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:12 --> Input Class Initialized
INFO - 2020-02-07 11:28:12 --> Language Class Initialized
ERROR - 2020-02-07 11:28:12 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 11:28:12 --> Config Class Initialized
INFO - 2020-02-07 11:28:12 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:28:12 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:12 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:12 --> URI Class Initialized
INFO - 2020-02-07 11:28:12 --> Router Class Initialized
INFO - 2020-02-07 11:28:12 --> Output Class Initialized
INFO - 2020-02-07 11:28:12 --> Security Class Initialized
DEBUG - 2020-02-07 11:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:12 --> Input Class Initialized
INFO - 2020-02-07 11:28:12 --> Language Class Initialized
ERROR - 2020-02-07 11:28:12 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 11:28:12 --> Config Class Initialized
INFO - 2020-02-07 11:28:12 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:28:12 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:12 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:12 --> URI Class Initialized
INFO - 2020-02-07 11:28:12 --> Router Class Initialized
INFO - 2020-02-07 11:28:12 --> Output Class Initialized
INFO - 2020-02-07 11:28:12 --> Security Class Initialized
DEBUG - 2020-02-07 11:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:12 --> Input Class Initialized
INFO - 2020-02-07 11:28:12 --> Language Class Initialized
ERROR - 2020-02-07 11:28:12 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 11:28:12 --> Config Class Initialized
INFO - 2020-02-07 11:28:12 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:28:12 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:12 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:12 --> URI Class Initialized
INFO - 2020-02-07 11:28:13 --> Router Class Initialized
INFO - 2020-02-07 11:28:13 --> Output Class Initialized
INFO - 2020-02-07 11:28:13 --> Security Class Initialized
DEBUG - 2020-02-07 11:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:13 --> Input Class Initialized
INFO - 2020-02-07 11:28:13 --> Language Class Initialized
ERROR - 2020-02-07 11:28:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:28:13 --> Config Class Initialized
INFO - 2020-02-07 11:28:13 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:28:13 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:13 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:13 --> URI Class Initialized
INFO - 2020-02-07 11:28:13 --> Router Class Initialized
INFO - 2020-02-07 11:28:13 --> Output Class Initialized
INFO - 2020-02-07 11:28:13 --> Security Class Initialized
DEBUG - 2020-02-07 11:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:13 --> Input Class Initialized
INFO - 2020-02-07 11:28:13 --> Language Class Initialized
ERROR - 2020-02-07 11:28:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:28:13 --> Config Class Initialized
INFO - 2020-02-07 11:28:13 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:28:13 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:13 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:13 --> URI Class Initialized
INFO - 2020-02-07 11:28:13 --> Router Class Initialized
INFO - 2020-02-07 11:28:13 --> Output Class Initialized
INFO - 2020-02-07 11:28:13 --> Security Class Initialized
DEBUG - 2020-02-07 11:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:13 --> Input Class Initialized
INFO - 2020-02-07 11:28:13 --> Language Class Initialized
ERROR - 2020-02-07 11:28:13 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 11:28:13 --> Config Class Initialized
INFO - 2020-02-07 11:28:13 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:28:13 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:13 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:13 --> URI Class Initialized
INFO - 2020-02-07 11:28:13 --> Router Class Initialized
INFO - 2020-02-07 11:28:14 --> Output Class Initialized
INFO - 2020-02-07 11:28:14 --> Security Class Initialized
DEBUG - 2020-02-07 11:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:14 --> Input Class Initialized
INFO - 2020-02-07 11:28:14 --> Language Class Initialized
ERROR - 2020-02-07 11:28:14 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 11:28:14 --> Config Class Initialized
INFO - 2020-02-07 11:28:14 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:28:14 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:14 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:14 --> URI Class Initialized
INFO - 2020-02-07 11:28:14 --> Router Class Initialized
INFO - 2020-02-07 11:28:14 --> Output Class Initialized
INFO - 2020-02-07 11:28:14 --> Security Class Initialized
DEBUG - 2020-02-07 11:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:14 --> Input Class Initialized
INFO - 2020-02-07 11:28:14 --> Language Class Initialized
ERROR - 2020-02-07 11:28:14 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 11:28:14 --> Config Class Initialized
INFO - 2020-02-07 11:28:14 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:28:14 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:28:14 --> Utf8 Class Initialized
INFO - 2020-02-07 11:28:14 --> URI Class Initialized
INFO - 2020-02-07 11:28:14 --> Router Class Initialized
INFO - 2020-02-07 11:28:14 --> Output Class Initialized
INFO - 2020-02-07 11:28:14 --> Security Class Initialized
DEBUG - 2020-02-07 11:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:28:14 --> Input Class Initialized
INFO - 2020-02-07 11:28:14 --> Language Class Initialized
ERROR - 2020-02-07 11:28:14 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 11:30:01 --> Config Class Initialized
INFO - 2020-02-07 11:30:01 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:30:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:01 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:01 --> URI Class Initialized
INFO - 2020-02-07 11:30:01 --> Router Class Initialized
INFO - 2020-02-07 11:30:01 --> Output Class Initialized
INFO - 2020-02-07 11:30:01 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:01 --> Input Class Initialized
INFO - 2020-02-07 11:30:01 --> Language Class Initialized
INFO - 2020-02-07 11:30:01 --> Loader Class Initialized
INFO - 2020-02-07 11:30:01 --> Helper loaded: url_helper
INFO - 2020-02-07 11:30:01 --> Database Driver Class Initialized
DEBUG - 2020-02-07 11:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:30:01 --> Controller Class Initialized
INFO - 2020-02-07 11:30:01 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:30:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:30:01 --> Model "M_pesan" initialized
INFO - 2020-02-07 11:30:01 --> Helper loaded: form_helper
INFO - 2020-02-07 11:30:01 --> Form Validation Class Initialized
INFO - 2020-02-07 11:30:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:30:01 --> Final output sent to browser
DEBUG - 2020-02-07 11:30:01 --> Total execution time: 0.8057
INFO - 2020-02-07 11:30:01 --> Config Class Initialized
INFO - 2020-02-07 11:30:01 --> Config Class Initialized
INFO - 2020-02-07 11:30:01 --> Config Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
INFO - 2020-02-07 11:30:02 --> Config Class Initialized
INFO - 2020-02-07 11:30:02 --> Config Class Initialized
INFO - 2020-02-07 11:30:02 --> Config Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
INFO - 2020-02-07 11:30:02 --> Language Class Initialized
INFO - 2020-02-07 11:30:02 --> Language Class Initialized
INFO - 2020-02-07 11:30:02 --> Language Class Initialized
INFO - 2020-02-07 11:30:02 --> Language Class Initialized
ERROR - 2020-02-07 11:30:02 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-07 11:30:02 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-07 11:30:02 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-07 11:30:02 --> Language Class Initialized
INFO - 2020-02-07 11:30:02 --> Language Class Initialized
ERROR - 2020-02-07 11:30:02 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 11:30:02 --> Loader Class Initialized
INFO - 2020-02-07 11:30:02 --> Loader Class Initialized
INFO - 2020-02-07 11:30:02 --> Config Class Initialized
INFO - 2020-02-07 11:30:02 --> Config Class Initialized
INFO - 2020-02-07 11:30:02 --> Config Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
INFO - 2020-02-07 11:30:02 --> Helper loaded: url_helper
INFO - 2020-02-07 11:30:02 --> Helper loaded: url_helper
INFO - 2020-02-07 11:30:02 --> Config Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:02 --> Database Driver Class Initialized
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:02 --> Database Driver Class Initialized
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-07 11:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> Controller Class Initialized
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Model "M_pesan" initialized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:02 --> Helper loaded: form_helper
INFO - 2020-02-07 11:30:02 --> Form Validation Class Initialized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
INFO - 2020-02-07 11:30:02 --> Language Class Initialized
INFO - 2020-02-07 11:30:02 --> Language Class Initialized
INFO - 2020-02-07 11:30:02 --> Language Class Initialized
ERROR - 2020-02-07 11:30:02 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 11:30:02 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 11:30:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 11:30:02 --> Language Class Initialized
ERROR - 2020-02-07 11:30:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 11:30:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 11:30:02 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 11:30:02 --> Config Class Initialized
INFO - 2020-02-07 11:30:02 --> Config Class Initialized
INFO - 2020-02-07 11:30:02 --> Config Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
INFO - 2020-02-07 11:30:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:30:02 --> Config Class Initialized
INFO - 2020-02-07 11:30:02 --> Hooks Class Initialized
INFO - 2020-02-07 11:30:02 --> Final output sent to browser
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
DEBUG - 2020-02-07 11:30:02 --> Total execution time: 0.7627
DEBUG - 2020-02-07 11:30:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:02 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> Controller Class Initialized
INFO - 2020-02-07 11:30:02 --> URI Class Initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> Model "M_tiket" initialized
INFO - 2020-02-07 11:30:02 --> Router Class Initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
INFO - 2020-02-07 11:30:02 --> Output Class Initialized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
INFO - 2020-02-07 11:30:02 --> Model "M_pesan" initialized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:02 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
DEBUG - 2020-02-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:02 --> Helper loaded: form_helper
INFO - 2020-02-07 11:30:02 --> Form Validation Class Initialized
INFO - 2020-02-07 11:30:02 --> Language Class Initialized
INFO - 2020-02-07 11:30:02 --> Language Class Initialized
INFO - 2020-02-07 11:30:02 --> Input Class Initialized
INFO - 2020-02-07 11:30:02 --> Language Class Initialized
INFO - 2020-02-07 11:30:03 --> Language Class Initialized
ERROR - 2020-02-07 11:30:03 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-07 11:30:03 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-07 11:30:03 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-07 11:30:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 11:30:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 11:30:03 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 11:30:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 11:30:03 --> Config Class Initialized
INFO - 2020-02-07 11:30:03 --> Hooks Class Initialized
INFO - 2020-02-07 11:30:03 --> Final output sent to browser
DEBUG - 2020-02-07 11:30:03 --> Total execution time: 1.0847
DEBUG - 2020-02-07 11:30:03 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:03 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:03 --> URI Class Initialized
INFO - 2020-02-07 11:30:03 --> Router Class Initialized
INFO - 2020-02-07 11:30:03 --> Output Class Initialized
INFO - 2020-02-07 11:30:03 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:03 --> Input Class Initialized
INFO - 2020-02-07 11:30:03 --> Language Class Initialized
ERROR - 2020-02-07 11:30:03 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 11:30:03 --> Config Class Initialized
INFO - 2020-02-07 11:30:03 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:30:03 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:03 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:03 --> URI Class Initialized
INFO - 2020-02-07 11:30:03 --> Router Class Initialized
INFO - 2020-02-07 11:30:03 --> Output Class Initialized
INFO - 2020-02-07 11:30:03 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:03 --> Input Class Initialized
INFO - 2020-02-07 11:30:03 --> Language Class Initialized
ERROR - 2020-02-07 11:30:03 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 11:30:03 --> Config Class Initialized
INFO - 2020-02-07 11:30:03 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:30:03 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:03 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:03 --> URI Class Initialized
INFO - 2020-02-07 11:30:03 --> Router Class Initialized
INFO - 2020-02-07 11:30:03 --> Output Class Initialized
INFO - 2020-02-07 11:30:03 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:03 --> Input Class Initialized
INFO - 2020-02-07 11:30:03 --> Language Class Initialized
ERROR - 2020-02-07 11:30:03 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 11:30:04 --> Config Class Initialized
INFO - 2020-02-07 11:30:04 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:30:04 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:04 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:04 --> URI Class Initialized
INFO - 2020-02-07 11:30:04 --> Router Class Initialized
INFO - 2020-02-07 11:30:04 --> Output Class Initialized
INFO - 2020-02-07 11:30:04 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:04 --> Input Class Initialized
INFO - 2020-02-07 11:30:04 --> Language Class Initialized
ERROR - 2020-02-07 11:30:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:30:04 --> Config Class Initialized
INFO - 2020-02-07 11:30:04 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:30:04 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:04 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:04 --> URI Class Initialized
INFO - 2020-02-07 11:30:04 --> Router Class Initialized
INFO - 2020-02-07 11:30:04 --> Output Class Initialized
INFO - 2020-02-07 11:30:04 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:04 --> Input Class Initialized
INFO - 2020-02-07 11:30:04 --> Language Class Initialized
ERROR - 2020-02-07 11:30:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 11:30:04 --> Config Class Initialized
INFO - 2020-02-07 11:30:04 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:30:04 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:04 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:04 --> URI Class Initialized
INFO - 2020-02-07 11:30:04 --> Router Class Initialized
INFO - 2020-02-07 11:30:04 --> Output Class Initialized
INFO - 2020-02-07 11:30:04 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:04 --> Input Class Initialized
INFO - 2020-02-07 11:30:04 --> Language Class Initialized
ERROR - 2020-02-07 11:30:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 11:30:05 --> Config Class Initialized
INFO - 2020-02-07 11:30:05 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:30:05 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:05 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:05 --> URI Class Initialized
INFO - 2020-02-07 11:30:05 --> Router Class Initialized
INFO - 2020-02-07 11:30:05 --> Output Class Initialized
INFO - 2020-02-07 11:30:05 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:05 --> Input Class Initialized
INFO - 2020-02-07 11:30:05 --> Language Class Initialized
ERROR - 2020-02-07 11:30:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 11:30:05 --> Config Class Initialized
INFO - 2020-02-07 11:30:05 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:30:05 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:05 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:05 --> URI Class Initialized
INFO - 2020-02-07 11:30:05 --> Router Class Initialized
INFO - 2020-02-07 11:30:05 --> Output Class Initialized
INFO - 2020-02-07 11:30:05 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:05 --> Input Class Initialized
INFO - 2020-02-07 11:30:05 --> Language Class Initialized
ERROR - 2020-02-07 11:30:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 11:30:05 --> Config Class Initialized
INFO - 2020-02-07 11:30:05 --> Hooks Class Initialized
DEBUG - 2020-02-07 11:30:05 --> UTF-8 Support Enabled
INFO - 2020-02-07 11:30:05 --> Utf8 Class Initialized
INFO - 2020-02-07 11:30:05 --> URI Class Initialized
INFO - 2020-02-07 11:30:05 --> Router Class Initialized
INFO - 2020-02-07 11:30:05 --> Output Class Initialized
INFO - 2020-02-07 11:30:05 --> Security Class Initialized
DEBUG - 2020-02-07 11:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 11:30:05 --> Input Class Initialized
INFO - 2020-02-07 11:30:05 --> Language Class Initialized
ERROR - 2020-02-07 11:30:05 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 12:02:00 --> Config Class Initialized
INFO - 2020-02-07 12:02:00 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:00 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:01 --> URI Class Initialized
INFO - 2020-02-07 12:02:01 --> Router Class Initialized
INFO - 2020-02-07 12:02:01 --> Output Class Initialized
INFO - 2020-02-07 12:02:01 --> Security Class Initialized
DEBUG - 2020-02-07 12:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:01 --> Input Class Initialized
INFO - 2020-02-07 12:02:01 --> Language Class Initialized
INFO - 2020-02-07 12:02:01 --> Loader Class Initialized
INFO - 2020-02-07 12:02:01 --> Helper loaded: url_helper
INFO - 2020-02-07 12:02:01 --> Database Driver Class Initialized
DEBUG - 2020-02-07 12:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 12:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 12:02:01 --> Controller Class Initialized
INFO - 2020-02-07 12:02:01 --> Model "M_tiket" initialized
INFO - 2020-02-07 12:02:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 12:02:01 --> Model "M_pesan" initialized
INFO - 2020-02-07 12:02:01 --> Helper loaded: form_helper
INFO - 2020-02-07 12:02:01 --> Form Validation Class Initialized
INFO - 2020-02-07 12:02:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 12:02:01 --> Final output sent to browser
INFO - 2020-02-07 12:02:01 --> Config Class Initialized
INFO - 2020-02-07 12:02:01 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:01 --> Total execution time: 0.6453
INFO - 2020-02-07 12:02:01 --> Config Class Initialized
INFO - 2020-02-07 12:02:01 --> Config Class Initialized
INFO - 2020-02-07 12:02:01 --> Config Class Initialized
INFO - 2020-02-07 12:02:01 --> Config Class Initialized
INFO - 2020-02-07 12:02:01 --> Hooks Class Initialized
INFO - 2020-02-07 12:02:01 --> Hooks Class Initialized
INFO - 2020-02-07 12:02:01 --> Hooks Class Initialized
INFO - 2020-02-07 12:02:01 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:01 --> Config Class Initialized
INFO - 2020-02-07 12:02:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:01 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:02:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:01 --> URI Class Initialized
DEBUG - 2020-02-07 12:02:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:01 --> URI Class Initialized
INFO - 2020-02-07 12:02:01 --> URI Class Initialized
INFO - 2020-02-07 12:02:01 --> URI Class Initialized
INFO - 2020-02-07 12:02:01 --> URI Class Initialized
INFO - 2020-02-07 12:02:01 --> Router Class Initialized
INFO - 2020-02-07 12:02:01 --> URI Class Initialized
INFO - 2020-02-07 12:02:01 --> Router Class Initialized
INFO - 2020-02-07 12:02:01 --> Router Class Initialized
INFO - 2020-02-07 12:02:01 --> Router Class Initialized
INFO - 2020-02-07 12:02:01 --> Router Class Initialized
INFO - 2020-02-07 12:02:01 --> Output Class Initialized
INFO - 2020-02-07 12:02:01 --> Router Class Initialized
INFO - 2020-02-07 12:02:01 --> Output Class Initialized
INFO - 2020-02-07 12:02:01 --> Output Class Initialized
INFO - 2020-02-07 12:02:01 --> Output Class Initialized
INFO - 2020-02-07 12:02:01 --> Security Class Initialized
INFO - 2020-02-07 12:02:01 --> Output Class Initialized
INFO - 2020-02-07 12:02:01 --> Security Class Initialized
INFO - 2020-02-07 12:02:01 --> Security Class Initialized
INFO - 2020-02-07 12:02:01 --> Output Class Initialized
INFO - 2020-02-07 12:02:01 --> Security Class Initialized
INFO - 2020-02-07 12:02:01 --> Security Class Initialized
DEBUG - 2020-02-07 12:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 12:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 12:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 12:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:01 --> Security Class Initialized
DEBUG - 2020-02-07 12:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:01 --> Input Class Initialized
INFO - 2020-02-07 12:02:01 --> Input Class Initialized
INFO - 2020-02-07 12:02:01 --> Input Class Initialized
INFO - 2020-02-07 12:02:01 --> Input Class Initialized
INFO - 2020-02-07 12:02:01 --> Input Class Initialized
INFO - 2020-02-07 12:02:01 --> Language Class Initialized
DEBUG - 2020-02-07 12:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:01 --> Input Class Initialized
INFO - 2020-02-07 12:02:01 --> Language Class Initialized
INFO - 2020-02-07 12:02:01 --> Language Class Initialized
INFO - 2020-02-07 12:02:01 --> Language Class Initialized
INFO - 2020-02-07 12:02:01 --> Language Class Initialized
INFO - 2020-02-07 12:02:01 --> Loader Class Initialized
INFO - 2020-02-07 12:02:02 --> Language Class Initialized
ERROR - 2020-02-07 12:02:02 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-07 12:02:02 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-07 12:02:02 --> Helper loaded: url_helper
ERROR - 2020-02-07 12:02:02 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 12:02:02 --> Loader Class Initialized
ERROR - 2020-02-07 12:02:02 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 12:02:02 --> Helper loaded: url_helper
INFO - 2020-02-07 12:02:02 --> Database Driver Class Initialized
INFO - 2020-02-07 12:02:02 --> Config Class Initialized
INFO - 2020-02-07 12:02:02 --> Config Class Initialized
INFO - 2020-02-07 12:02:02 --> Hooks Class Initialized
INFO - 2020-02-07 12:02:02 --> Hooks Class Initialized
INFO - 2020-02-07 12:02:02 --> Config Class Initialized
DEBUG - 2020-02-07 12:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 12:02:02 --> Database Driver Class Initialized
INFO - 2020-02-07 12:02:02 --> Config Class Initialized
INFO - 2020-02-07 12:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 12:02:02 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:02:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 12:02:02 --> Hooks Class Initialized
INFO - 2020-02-07 12:02:02 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:02 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:02 --> Controller Class Initialized
INFO - 2020-02-07 12:02:02 --> URI Class Initialized
DEBUG - 2020-02-07 12:02:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:02:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:02 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:02 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:02 --> Model "M_tiket" initialized
INFO - 2020-02-07 12:02:02 --> URI Class Initialized
INFO - 2020-02-07 12:02:02 --> Router Class Initialized
INFO - 2020-02-07 12:02:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 12:02:02 --> URI Class Initialized
INFO - 2020-02-07 12:02:02 --> Router Class Initialized
INFO - 2020-02-07 12:02:02 --> Output Class Initialized
INFO - 2020-02-07 12:02:02 --> URI Class Initialized
INFO - 2020-02-07 12:02:02 --> Model "M_pesan" initialized
INFO - 2020-02-07 12:02:02 --> Router Class Initialized
INFO - 2020-02-07 12:02:02 --> Router Class Initialized
INFO - 2020-02-07 12:02:02 --> Output Class Initialized
INFO - 2020-02-07 12:02:02 --> Security Class Initialized
INFO - 2020-02-07 12:02:02 --> Security Class Initialized
INFO - 2020-02-07 12:02:02 --> Output Class Initialized
INFO - 2020-02-07 12:02:02 --> Output Class Initialized
DEBUG - 2020-02-07 12:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:02 --> Helper loaded: form_helper
INFO - 2020-02-07 12:02:02 --> Form Validation Class Initialized
INFO - 2020-02-07 12:02:02 --> Input Class Initialized
DEBUG - 2020-02-07 12:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:02 --> Security Class Initialized
INFO - 2020-02-07 12:02:02 --> Security Class Initialized
INFO - 2020-02-07 12:02:02 --> Input Class Initialized
INFO - 2020-02-07 12:02:02 --> Language Class Initialized
DEBUG - 2020-02-07 12:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 12:02:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-07 12:02:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 12:02:02 --> Input Class Initialized
ERROR - 2020-02-07 12:02:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 12:02:02 --> Language Class Initialized
INFO - 2020-02-07 12:02:02 --> Input Class Initialized
ERROR - 2020-02-07 12:02:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 12:02:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 12:02:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 12:02:02 --> Language Class Initialized
INFO - 2020-02-07 12:02:02 --> Language Class Initialized
INFO - 2020-02-07 12:02:02 --> Config Class Initialized
INFO - 2020-02-07 12:02:02 --> Hooks Class Initialized
ERROR - 2020-02-07 12:02:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 12:02:02 --> Final output sent to browser
ERROR - 2020-02-07 12:02:02 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 12:02:02 --> Config Class Initialized
INFO - 2020-02-07 12:02:02 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:02 --> Total execution time: 0.7553
DEBUG - 2020-02-07 12:02:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:02 --> Config Class Initialized
INFO - 2020-02-07 12:02:02 --> Hooks Class Initialized
INFO - 2020-02-07 12:02:02 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-07 12:02:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:02 --> Config Class Initialized
INFO - 2020-02-07 12:02:02 --> Hooks Class Initialized
INFO - 2020-02-07 12:02:02 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:02 --> Controller Class Initialized
INFO - 2020-02-07 12:02:02 --> URI Class Initialized
DEBUG - 2020-02-07 12:02:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:02 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:02 --> Model "M_tiket" initialized
INFO - 2020-02-07 12:02:02 --> URI Class Initialized
DEBUG - 2020-02-07 12:02:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:02 --> Router Class Initialized
INFO - 2020-02-07 12:02:02 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 12:02:02 --> URI Class Initialized
INFO - 2020-02-07 12:02:02 --> Router Class Initialized
INFO - 2020-02-07 12:02:02 --> Output Class Initialized
INFO - 2020-02-07 12:02:02 --> URI Class Initialized
INFO - 2020-02-07 12:02:02 --> Model "M_pesan" initialized
INFO - 2020-02-07 12:02:02 --> Router Class Initialized
INFO - 2020-02-07 12:02:02 --> Output Class Initialized
INFO - 2020-02-07 12:02:02 --> Security Class Initialized
INFO - 2020-02-07 12:02:02 --> Router Class Initialized
DEBUG - 2020-02-07 12:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:02 --> Security Class Initialized
INFO - 2020-02-07 12:02:02 --> Helper loaded: form_helper
INFO - 2020-02-07 12:02:02 --> Output Class Initialized
INFO - 2020-02-07 12:02:02 --> Input Class Initialized
INFO - 2020-02-07 12:02:02 --> Form Validation Class Initialized
INFO - 2020-02-07 12:02:02 --> Security Class Initialized
DEBUG - 2020-02-07 12:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:02 --> Output Class Initialized
INFO - 2020-02-07 12:02:02 --> Input Class Initialized
DEBUG - 2020-02-07 12:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:02 --> Language Class Initialized
INFO - 2020-02-07 12:02:02 --> Security Class Initialized
ERROR - 2020-02-07 12:02:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 12:02:02 --> Input Class Initialized
ERROR - 2020-02-07 12:02:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 12:02:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 12:02:02 --> Language Class Initialized
DEBUG - 2020-02-07 12:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:02 --> Input Class Initialized
INFO - 2020-02-07 12:02:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 12:02:02 --> Language Class Initialized
ERROR - 2020-02-07 12:02:02 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 12:02:02 --> Final output sent to browser
ERROR - 2020-02-07 12:02:02 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 12:02:02 --> Language Class Initialized
DEBUG - 2020-02-07 12:02:02 --> Total execution time: 1.0726
ERROR - 2020-02-07 12:02:02 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 12:02:02 --> Config Class Initialized
INFO - 2020-02-07 12:02:02 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:02 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:02 --> URI Class Initialized
INFO - 2020-02-07 12:02:02 --> Router Class Initialized
INFO - 2020-02-07 12:02:03 --> Output Class Initialized
INFO - 2020-02-07 12:02:03 --> Security Class Initialized
DEBUG - 2020-02-07 12:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:03 --> Input Class Initialized
INFO - 2020-02-07 12:02:03 --> Language Class Initialized
ERROR - 2020-02-07 12:02:03 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 12:02:03 --> Config Class Initialized
INFO - 2020-02-07 12:02:03 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:03 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:03 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:03 --> URI Class Initialized
INFO - 2020-02-07 12:02:03 --> Router Class Initialized
INFO - 2020-02-07 12:02:03 --> Output Class Initialized
INFO - 2020-02-07 12:02:03 --> Security Class Initialized
DEBUG - 2020-02-07 12:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:03 --> Input Class Initialized
INFO - 2020-02-07 12:02:03 --> Language Class Initialized
ERROR - 2020-02-07 12:02:03 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 12:02:03 --> Config Class Initialized
INFO - 2020-02-07 12:02:03 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:03 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:03 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:03 --> URI Class Initialized
INFO - 2020-02-07 12:02:03 --> Router Class Initialized
INFO - 2020-02-07 12:02:03 --> Output Class Initialized
INFO - 2020-02-07 12:02:03 --> Security Class Initialized
DEBUG - 2020-02-07 12:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:03 --> Input Class Initialized
INFO - 2020-02-07 12:02:03 --> Language Class Initialized
ERROR - 2020-02-07 12:02:03 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 12:02:03 --> Config Class Initialized
INFO - 2020-02-07 12:02:03 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:03 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:03 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:03 --> URI Class Initialized
INFO - 2020-02-07 12:02:03 --> Router Class Initialized
INFO - 2020-02-07 12:02:03 --> Output Class Initialized
INFO - 2020-02-07 12:02:03 --> Security Class Initialized
DEBUG - 2020-02-07 12:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:04 --> Input Class Initialized
INFO - 2020-02-07 12:02:04 --> Language Class Initialized
ERROR - 2020-02-07 12:02:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 12:02:04 --> Config Class Initialized
INFO - 2020-02-07 12:02:04 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:04 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:04 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:04 --> URI Class Initialized
INFO - 2020-02-07 12:02:04 --> Router Class Initialized
INFO - 2020-02-07 12:02:04 --> Output Class Initialized
INFO - 2020-02-07 12:02:04 --> Security Class Initialized
DEBUG - 2020-02-07 12:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:04 --> Input Class Initialized
INFO - 2020-02-07 12:02:04 --> Language Class Initialized
ERROR - 2020-02-07 12:02:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 12:02:04 --> Config Class Initialized
INFO - 2020-02-07 12:02:04 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:04 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:04 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:04 --> URI Class Initialized
INFO - 2020-02-07 12:02:04 --> Router Class Initialized
INFO - 2020-02-07 12:02:04 --> Output Class Initialized
INFO - 2020-02-07 12:02:04 --> Security Class Initialized
DEBUG - 2020-02-07 12:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:04 --> Input Class Initialized
INFO - 2020-02-07 12:02:04 --> Language Class Initialized
ERROR - 2020-02-07 12:02:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 12:02:04 --> Config Class Initialized
INFO - 2020-02-07 12:02:04 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:04 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:04 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:04 --> URI Class Initialized
INFO - 2020-02-07 12:02:04 --> Router Class Initialized
INFO - 2020-02-07 12:02:04 --> Output Class Initialized
INFO - 2020-02-07 12:02:04 --> Security Class Initialized
DEBUG - 2020-02-07 12:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:04 --> Input Class Initialized
INFO - 2020-02-07 12:02:04 --> Language Class Initialized
ERROR - 2020-02-07 12:02:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 12:02:05 --> Config Class Initialized
INFO - 2020-02-07 12:02:05 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:05 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:05 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:05 --> URI Class Initialized
INFO - 2020-02-07 12:02:05 --> Router Class Initialized
INFO - 2020-02-07 12:02:05 --> Output Class Initialized
INFO - 2020-02-07 12:02:05 --> Security Class Initialized
DEBUG - 2020-02-07 12:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:05 --> Input Class Initialized
INFO - 2020-02-07 12:02:05 --> Language Class Initialized
ERROR - 2020-02-07 12:02:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 12:02:05 --> Config Class Initialized
INFO - 2020-02-07 12:02:05 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:02:05 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:02:05 --> Utf8 Class Initialized
INFO - 2020-02-07 12:02:05 --> URI Class Initialized
INFO - 2020-02-07 12:02:05 --> Router Class Initialized
INFO - 2020-02-07 12:02:05 --> Output Class Initialized
INFO - 2020-02-07 12:02:05 --> Security Class Initialized
DEBUG - 2020-02-07 12:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:02:05 --> Input Class Initialized
INFO - 2020-02-07 12:02:05 --> Language Class Initialized
ERROR - 2020-02-07 12:02:05 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 12:35:00 --> Config Class Initialized
INFO - 2020-02-07 12:35:00 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:00 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:00 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:00 --> URI Class Initialized
INFO - 2020-02-07 12:35:00 --> Router Class Initialized
INFO - 2020-02-07 12:35:00 --> Output Class Initialized
INFO - 2020-02-07 12:35:00 --> Security Class Initialized
DEBUG - 2020-02-07 12:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:00 --> Input Class Initialized
INFO - 2020-02-07 12:35:00 --> Language Class Initialized
INFO - 2020-02-07 12:35:00 --> Loader Class Initialized
INFO - 2020-02-07 12:35:00 --> Helper loaded: url_helper
INFO - 2020-02-07 12:35:00 --> Database Driver Class Initialized
DEBUG - 2020-02-07 12:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 12:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 12:35:00 --> Controller Class Initialized
INFO - 2020-02-07 12:35:00 --> Model "M_tiket" initialized
INFO - 2020-02-07 12:35:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 12:35:00 --> Model "M_pesan" initialized
INFO - 2020-02-07 12:35:00 --> Helper loaded: form_helper
INFO - 2020-02-07 12:35:00 --> Form Validation Class Initialized
INFO - 2020-02-07 12:35:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 12:35:00 --> Final output sent to browser
DEBUG - 2020-02-07 12:35:00 --> Total execution time: 0.6981
INFO - 2020-02-07 12:35:00 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
INFO - 2020-02-07 12:35:01 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
DEBUG - 2020-02-07 12:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 12:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 12:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 12:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
INFO - 2020-02-07 12:35:01 --> Input Class Initialized
INFO - 2020-02-07 12:35:01 --> Input Class Initialized
INFO - 2020-02-07 12:35:01 --> Input Class Initialized
INFO - 2020-02-07 12:35:01 --> Input Class Initialized
DEBUG - 2020-02-07 12:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 12:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:01 --> Input Class Initialized
INFO - 2020-02-07 12:35:01 --> Language Class Initialized
INFO - 2020-02-07 12:35:01 --> Language Class Initialized
INFO - 2020-02-07 12:35:01 --> Input Class Initialized
INFO - 2020-02-07 12:35:01 --> Language Class Initialized
INFO - 2020-02-07 12:35:01 --> Language Class Initialized
INFO - 2020-02-07 12:35:01 --> Language Class Initialized
INFO - 2020-02-07 12:35:01 --> Language Class Initialized
ERROR - 2020-02-07 12:35:01 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-07 12:35:01 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-07 12:35:01 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-07 12:35:01 --> Loader Class Initialized
INFO - 2020-02-07 12:35:01 --> Helper loaded: url_helper
ERROR - 2020-02-07 12:35:01 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 12:35:01 --> Loader Class Initialized
INFO - 2020-02-07 12:35:01 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
INFO - 2020-02-07 12:35:01 --> Helper loaded: url_helper
INFO - 2020-02-07 12:35:01 --> Database Driver Class Initialized
INFO - 2020-02-07 12:35:01 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 12:35:01 --> Database Driver Class Initialized
INFO - 2020-02-07 12:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 12:35:01 --> Controller Class Initialized
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> Model "M_tiket" initialized
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
INFO - 2020-02-07 12:35:01 --> Model "M_pesan" initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
DEBUG - 2020-02-07 12:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
DEBUG - 2020-02-07 12:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 12:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:01 --> Helper loaded: form_helper
INFO - 2020-02-07 12:35:01 --> Input Class Initialized
INFO - 2020-02-07 12:35:01 --> Form Validation Class Initialized
INFO - 2020-02-07 12:35:01 --> Input Class Initialized
INFO - 2020-02-07 12:35:01 --> Input Class Initialized
DEBUG - 2020-02-07 12:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:01 --> Input Class Initialized
INFO - 2020-02-07 12:35:01 --> Language Class Initialized
INFO - 2020-02-07 12:35:01 --> Language Class Initialized
INFO - 2020-02-07 12:35:01 --> Language Class Initialized
ERROR - 2020-02-07 12:35:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 12:35:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 12:35:01 --> Language Class Initialized
ERROR - 2020-02-07 12:35:01 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 12:35:01 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 12:35:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 12:35:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 12:35:01 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 12:35:01 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
INFO - 2020-02-07 12:35:01 --> Final output sent to browser
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
INFO - 2020-02-07 12:35:01 --> Config Class Initialized
INFO - 2020-02-07 12:35:01 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:01 --> Total execution time: 0.7984
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-07 12:35:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:01 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> Controller Class Initialized
INFO - 2020-02-07 12:35:01 --> Model "M_tiket" initialized
INFO - 2020-02-07 12:35:01 --> URI Class Initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 12:35:01 --> Router Class Initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
INFO - 2020-02-07 12:35:01 --> Model "M_pesan" initialized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
INFO - 2020-02-07 12:35:01 --> Output Class Initialized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
INFO - 2020-02-07 12:35:01 --> Security Class Initialized
DEBUG - 2020-02-07 12:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 12:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 12:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:01 --> Helper loaded: form_helper
INFO - 2020-02-07 12:35:02 --> Input Class Initialized
INFO - 2020-02-07 12:35:02 --> Input Class Initialized
INFO - 2020-02-07 12:35:02 --> Form Validation Class Initialized
INFO - 2020-02-07 12:35:02 --> Input Class Initialized
DEBUG - 2020-02-07 12:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:02 --> Input Class Initialized
INFO - 2020-02-07 12:35:02 --> Language Class Initialized
INFO - 2020-02-07 12:35:02 --> Language Class Initialized
INFO - 2020-02-07 12:35:02 --> Language Class Initialized
ERROR - 2020-02-07 12:35:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 12:35:02 --> Language Class Initialized
ERROR - 2020-02-07 12:35:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 12:35:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-07 12:35:02 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-07 12:35:02 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 12:35:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 12:35:02 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 12:35:02 --> Final output sent to browser
INFO - 2020-02-07 12:35:02 --> Config Class Initialized
INFO - 2020-02-07 12:35:02 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:02 --> Total execution time: 1.1102
DEBUG - 2020-02-07 12:35:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:02 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:02 --> URI Class Initialized
INFO - 2020-02-07 12:35:02 --> Router Class Initialized
INFO - 2020-02-07 12:35:02 --> Output Class Initialized
INFO - 2020-02-07 12:35:02 --> Security Class Initialized
DEBUG - 2020-02-07 12:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:02 --> Input Class Initialized
INFO - 2020-02-07 12:35:02 --> Language Class Initialized
ERROR - 2020-02-07 12:35:02 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 12:35:02 --> Config Class Initialized
INFO - 2020-02-07 12:35:02 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:02 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:02 --> URI Class Initialized
INFO - 2020-02-07 12:35:02 --> Router Class Initialized
INFO - 2020-02-07 12:35:02 --> Output Class Initialized
INFO - 2020-02-07 12:35:02 --> Security Class Initialized
DEBUG - 2020-02-07 12:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:02 --> Input Class Initialized
INFO - 2020-02-07 12:35:02 --> Language Class Initialized
ERROR - 2020-02-07 12:35:02 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 12:35:02 --> Config Class Initialized
INFO - 2020-02-07 12:35:02 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:02 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:02 --> URI Class Initialized
INFO - 2020-02-07 12:35:02 --> Router Class Initialized
INFO - 2020-02-07 12:35:02 --> Output Class Initialized
INFO - 2020-02-07 12:35:02 --> Security Class Initialized
DEBUG - 2020-02-07 12:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:03 --> Input Class Initialized
INFO - 2020-02-07 12:35:03 --> Language Class Initialized
ERROR - 2020-02-07 12:35:03 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 12:35:03 --> Config Class Initialized
INFO - 2020-02-07 12:35:03 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:03 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:03 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:03 --> URI Class Initialized
INFO - 2020-02-07 12:35:03 --> Router Class Initialized
INFO - 2020-02-07 12:35:03 --> Output Class Initialized
INFO - 2020-02-07 12:35:03 --> Security Class Initialized
DEBUG - 2020-02-07 12:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:03 --> Input Class Initialized
INFO - 2020-02-07 12:35:03 --> Language Class Initialized
ERROR - 2020-02-07 12:35:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 12:35:03 --> Config Class Initialized
INFO - 2020-02-07 12:35:03 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:03 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:03 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:03 --> URI Class Initialized
INFO - 2020-02-07 12:35:03 --> Router Class Initialized
INFO - 2020-02-07 12:35:03 --> Output Class Initialized
INFO - 2020-02-07 12:35:03 --> Security Class Initialized
DEBUG - 2020-02-07 12:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:03 --> Input Class Initialized
INFO - 2020-02-07 12:35:03 --> Language Class Initialized
ERROR - 2020-02-07 12:35:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 12:35:04 --> Config Class Initialized
INFO - 2020-02-07 12:35:04 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:04 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:04 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:04 --> URI Class Initialized
INFO - 2020-02-07 12:35:04 --> Router Class Initialized
INFO - 2020-02-07 12:35:04 --> Output Class Initialized
INFO - 2020-02-07 12:35:04 --> Security Class Initialized
DEBUG - 2020-02-07 12:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:04 --> Input Class Initialized
INFO - 2020-02-07 12:35:04 --> Language Class Initialized
ERROR - 2020-02-07 12:35:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 12:35:04 --> Config Class Initialized
INFO - 2020-02-07 12:35:04 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:04 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:04 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:04 --> URI Class Initialized
INFO - 2020-02-07 12:35:04 --> Router Class Initialized
INFO - 2020-02-07 12:35:04 --> Output Class Initialized
INFO - 2020-02-07 12:35:04 --> Security Class Initialized
DEBUG - 2020-02-07 12:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:04 --> Input Class Initialized
INFO - 2020-02-07 12:35:04 --> Language Class Initialized
ERROR - 2020-02-07 12:35:04 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 12:35:05 --> Config Class Initialized
INFO - 2020-02-07 12:35:05 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:05 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:05 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:05 --> URI Class Initialized
INFO - 2020-02-07 12:35:05 --> Router Class Initialized
INFO - 2020-02-07 12:35:05 --> Output Class Initialized
INFO - 2020-02-07 12:35:05 --> Security Class Initialized
DEBUG - 2020-02-07 12:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:05 --> Input Class Initialized
INFO - 2020-02-07 12:35:05 --> Language Class Initialized
ERROR - 2020-02-07 12:35:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 12:35:05 --> Config Class Initialized
INFO - 2020-02-07 12:35:05 --> Hooks Class Initialized
DEBUG - 2020-02-07 12:35:05 --> UTF-8 Support Enabled
INFO - 2020-02-07 12:35:05 --> Utf8 Class Initialized
INFO - 2020-02-07 12:35:05 --> URI Class Initialized
INFO - 2020-02-07 12:35:05 --> Router Class Initialized
INFO - 2020-02-07 12:35:05 --> Output Class Initialized
INFO - 2020-02-07 12:35:05 --> Security Class Initialized
DEBUG - 2020-02-07 12:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 12:35:05 --> Input Class Initialized
INFO - 2020-02-07 12:35:05 --> Language Class Initialized
ERROR - 2020-02-07 12:35:05 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 13:10:35 --> Config Class Initialized
INFO - 2020-02-07 13:10:35 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:10:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:35 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:35 --> URI Class Initialized
INFO - 2020-02-07 13:10:35 --> Router Class Initialized
INFO - 2020-02-07 13:10:35 --> Output Class Initialized
INFO - 2020-02-07 13:10:35 --> Security Class Initialized
DEBUG - 2020-02-07 13:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:35 --> Input Class Initialized
INFO - 2020-02-07 13:10:36 --> Language Class Initialized
INFO - 2020-02-07 13:10:36 --> Loader Class Initialized
INFO - 2020-02-07 13:10:36 --> Helper loaded: url_helper
INFO - 2020-02-07 13:10:36 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:10:36 --> Controller Class Initialized
INFO - 2020-02-07 13:10:36 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:10:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:10:36 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:10:36 --> Helper loaded: form_helper
INFO - 2020-02-07 13:10:36 --> Form Validation Class Initialized
INFO - 2020-02-07 13:10:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 13:10:36 --> Final output sent to browser
DEBUG - 2020-02-07 13:10:36 --> Total execution time: 1.0685
INFO - 2020-02-07 13:10:36 --> Config Class Initialized
INFO - 2020-02-07 13:10:36 --> Config Class Initialized
INFO - 2020-02-07 13:10:36 --> Config Class Initialized
INFO - 2020-02-07 13:10:36 --> Config Class Initialized
INFO - 2020-02-07 13:10:36 --> Config Class Initialized
INFO - 2020-02-07 13:10:36 --> Hooks Class Initialized
INFO - 2020-02-07 13:10:36 --> Hooks Class Initialized
INFO - 2020-02-07 13:10:36 --> Hooks Class Initialized
INFO - 2020-02-07 13:10:36 --> Hooks Class Initialized
INFO - 2020-02-07 13:10:36 --> Hooks Class Initialized
INFO - 2020-02-07 13:10:36 --> Config Class Initialized
DEBUG - 2020-02-07 13:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:10:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:36 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:10:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:36 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:36 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:36 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:36 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:36 --> Utf8 Class Initialized
DEBUG - 2020-02-07 13:10:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:36 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:36 --> URI Class Initialized
INFO - 2020-02-07 13:10:36 --> URI Class Initialized
INFO - 2020-02-07 13:10:36 --> URI Class Initialized
INFO - 2020-02-07 13:10:36 --> URI Class Initialized
INFO - 2020-02-07 13:10:36 --> URI Class Initialized
INFO - 2020-02-07 13:10:36 --> URI Class Initialized
INFO - 2020-02-07 13:10:36 --> Router Class Initialized
INFO - 2020-02-07 13:10:36 --> Router Class Initialized
INFO - 2020-02-07 13:10:36 --> Router Class Initialized
INFO - 2020-02-07 13:10:36 --> Router Class Initialized
INFO - 2020-02-07 13:10:36 --> Router Class Initialized
INFO - 2020-02-07 13:10:36 --> Output Class Initialized
INFO - 2020-02-07 13:10:36 --> Output Class Initialized
INFO - 2020-02-07 13:10:36 --> Output Class Initialized
INFO - 2020-02-07 13:10:36 --> Router Class Initialized
INFO - 2020-02-07 13:10:36 --> Output Class Initialized
INFO - 2020-02-07 13:10:36 --> Output Class Initialized
INFO - 2020-02-07 13:10:36 --> Security Class Initialized
INFO - 2020-02-07 13:10:36 --> Security Class Initialized
INFO - 2020-02-07 13:10:36 --> Security Class Initialized
INFO - 2020-02-07 13:10:36 --> Security Class Initialized
INFO - 2020-02-07 13:10:36 --> Security Class Initialized
INFO - 2020-02-07 13:10:36 --> Output Class Initialized
DEBUG - 2020-02-07 13:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 13:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:36 --> Security Class Initialized
DEBUG - 2020-02-07 13:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 13:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 13:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:36 --> Input Class Initialized
INFO - 2020-02-07 13:10:36 --> Input Class Initialized
INFO - 2020-02-07 13:10:36 --> Input Class Initialized
INFO - 2020-02-07 13:10:36 --> Input Class Initialized
INFO - 2020-02-07 13:10:36 --> Input Class Initialized
DEBUG - 2020-02-07 13:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:37 --> Input Class Initialized
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
ERROR - 2020-02-07 13:10:37 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-07 13:10:37 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-07 13:10:37 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 13:10:37 --> Loader Class Initialized
INFO - 2020-02-07 13:10:37 --> Loader Class Initialized
INFO - 2020-02-07 13:10:37 --> Helper loaded: url_helper
INFO - 2020-02-07 13:10:37 --> Helper loaded: url_helper
ERROR - 2020-02-07 13:10:37 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 13:10:37 --> Config Class Initialized
INFO - 2020-02-07 13:10:37 --> Config Class Initialized
INFO - 2020-02-07 13:10:37 --> Hooks Class Initialized
INFO - 2020-02-07 13:10:37 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:10:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:37 --> Config Class Initialized
INFO - 2020-02-07 13:10:37 --> Database Driver Class Initialized
INFO - 2020-02-07 13:10:37 --> Hooks Class Initialized
INFO - 2020-02-07 13:10:37 --> Utf8 Class Initialized
DEBUG - 2020-02-07 13:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:10:37 --> Database Driver Class Initialized
INFO - 2020-02-07 13:10:37 --> Config Class Initialized
INFO - 2020-02-07 13:10:37 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:37 --> Hooks Class Initialized
INFO - 2020-02-07 13:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:10:37 --> URI Class Initialized
DEBUG - 2020-02-07 13:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:10:37 --> Controller Class Initialized
INFO - 2020-02-07 13:10:37 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:37 --> URI Class Initialized
INFO - 2020-02-07 13:10:37 --> Router Class Initialized
DEBUG - 2020-02-07 13:10:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:37 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:37 --> URI Class Initialized
INFO - 2020-02-07 13:10:37 --> Router Class Initialized
INFO - 2020-02-07 13:10:37 --> Output Class Initialized
INFO - 2020-02-07 13:10:37 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:10:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:10:37 --> URI Class Initialized
INFO - 2020-02-07 13:10:37 --> Router Class Initialized
INFO - 2020-02-07 13:10:37 --> Security Class Initialized
INFO - 2020-02-07 13:10:37 --> Output Class Initialized
INFO - 2020-02-07 13:10:37 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:10:37 --> Router Class Initialized
INFO - 2020-02-07 13:10:37 --> Security Class Initialized
INFO - 2020-02-07 13:10:37 --> Output Class Initialized
DEBUG - 2020-02-07 13:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:37 --> Input Class Initialized
INFO - 2020-02-07 13:10:37 --> Security Class Initialized
DEBUG - 2020-02-07 13:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:37 --> Output Class Initialized
INFO - 2020-02-07 13:10:37 --> Helper loaded: form_helper
INFO - 2020-02-07 13:10:37 --> Form Validation Class Initialized
INFO - 2020-02-07 13:10:37 --> Input Class Initialized
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
INFO - 2020-02-07 13:10:37 --> Security Class Initialized
DEBUG - 2020-02-07 13:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:37 --> Input Class Initialized
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
DEBUG - 2020-02-07 13:10:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-07 13:10:37 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 13:10:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 13:10:37 --> Input Class Initialized
ERROR - 2020-02-07 13:10:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
ERROR - 2020-02-07 13:10:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 13:10:37 --> Config Class Initialized
INFO - 2020-02-07 13:10:37 --> Hooks Class Initialized
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
INFO - 2020-02-07 13:10:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 13:10:37 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 13:10:37 --> Config Class Initialized
INFO - 2020-02-07 13:10:37 --> Hooks Class Initialized
INFO - 2020-02-07 13:10:37 --> Final output sent to browser
ERROR - 2020-02-07 13:10:37 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-07 13:10:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:37 --> Config Class Initialized
INFO - 2020-02-07 13:10:37 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:37 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:10:37 --> Total execution time: 0.7320
DEBUG - 2020-02-07 13:10:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:37 --> Config Class Initialized
INFO - 2020-02-07 13:10:37 --> Hooks Class Initialized
INFO - 2020-02-07 13:10:37 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:10:37 --> URI Class Initialized
DEBUG - 2020-02-07 13:10:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:37 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:37 --> Controller Class Initialized
INFO - 2020-02-07 13:10:37 --> URI Class Initialized
INFO - 2020-02-07 13:10:37 --> Router Class Initialized
DEBUG - 2020-02-07 13:10:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:37 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:37 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:10:37 --> URI Class Initialized
INFO - 2020-02-07 13:10:37 --> Router Class Initialized
INFO - 2020-02-07 13:10:37 --> Output Class Initialized
INFO - 2020-02-07 13:10:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:10:37 --> URI Class Initialized
INFO - 2020-02-07 13:10:37 --> Router Class Initialized
INFO - 2020-02-07 13:10:37 --> Security Class Initialized
INFO - 2020-02-07 13:10:37 --> Output Class Initialized
INFO - 2020-02-07 13:10:37 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:10:37 --> Router Class Initialized
INFO - 2020-02-07 13:10:37 --> Security Class Initialized
INFO - 2020-02-07 13:10:37 --> Output Class Initialized
DEBUG - 2020-02-07 13:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:37 --> Input Class Initialized
INFO - 2020-02-07 13:10:37 --> Security Class Initialized
INFO - 2020-02-07 13:10:37 --> Output Class Initialized
DEBUG - 2020-02-07 13:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:37 --> Helper loaded: form_helper
INFO - 2020-02-07 13:10:37 --> Form Validation Class Initialized
INFO - 2020-02-07 13:10:37 --> Input Class Initialized
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
DEBUG - 2020-02-07 13:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:37 --> Security Class Initialized
INFO - 2020-02-07 13:10:37 --> Input Class Initialized
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
ERROR - 2020-02-07 13:10:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-07 13:10:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-07 13:10:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 13:10:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 13:10:37 --> Input Class Initialized
ERROR - 2020-02-07 13:10:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
INFO - 2020-02-07 13:10:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 13:10:37 --> Language Class Initialized
ERROR - 2020-02-07 13:10:37 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 13:10:37 --> Final output sent to browser
ERROR - 2020-02-07 13:10:37 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-07 13:10:37 --> Total execution time: 1.0702
INFO - 2020-02-07 13:10:37 --> Config Class Initialized
INFO - 2020-02-07 13:10:37 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:10:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:37 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:37 --> URI Class Initialized
INFO - 2020-02-07 13:10:37 --> Router Class Initialized
INFO - 2020-02-07 13:10:37 --> Output Class Initialized
INFO - 2020-02-07 13:10:37 --> Security Class Initialized
DEBUG - 2020-02-07 13:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:38 --> Input Class Initialized
INFO - 2020-02-07 13:10:38 --> Language Class Initialized
ERROR - 2020-02-07 13:10:38 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 13:10:38 --> Config Class Initialized
INFO - 2020-02-07 13:10:38 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:10:38 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:38 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:38 --> URI Class Initialized
INFO - 2020-02-07 13:10:38 --> Router Class Initialized
INFO - 2020-02-07 13:10:38 --> Output Class Initialized
INFO - 2020-02-07 13:10:38 --> Security Class Initialized
DEBUG - 2020-02-07 13:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:38 --> Input Class Initialized
INFO - 2020-02-07 13:10:38 --> Language Class Initialized
ERROR - 2020-02-07 13:10:38 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 13:10:38 --> Config Class Initialized
INFO - 2020-02-07 13:10:38 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:10:38 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:38 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:38 --> URI Class Initialized
INFO - 2020-02-07 13:10:38 --> Router Class Initialized
INFO - 2020-02-07 13:10:38 --> Output Class Initialized
INFO - 2020-02-07 13:10:38 --> Security Class Initialized
DEBUG - 2020-02-07 13:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:38 --> Input Class Initialized
INFO - 2020-02-07 13:10:38 --> Language Class Initialized
ERROR - 2020-02-07 13:10:38 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 13:10:38 --> Config Class Initialized
INFO - 2020-02-07 13:10:38 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:10:38 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:38 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:38 --> URI Class Initialized
INFO - 2020-02-07 13:10:38 --> Router Class Initialized
INFO - 2020-02-07 13:10:38 --> Output Class Initialized
INFO - 2020-02-07 13:10:38 --> Security Class Initialized
DEBUG - 2020-02-07 13:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:38 --> Input Class Initialized
INFO - 2020-02-07 13:10:38 --> Language Class Initialized
ERROR - 2020-02-07 13:10:39 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 13:10:39 --> Config Class Initialized
INFO - 2020-02-07 13:10:39 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:10:39 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:39 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:39 --> URI Class Initialized
INFO - 2020-02-07 13:10:39 --> Router Class Initialized
INFO - 2020-02-07 13:10:39 --> Output Class Initialized
INFO - 2020-02-07 13:10:39 --> Security Class Initialized
DEBUG - 2020-02-07 13:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:39 --> Input Class Initialized
INFO - 2020-02-07 13:10:39 --> Language Class Initialized
ERROR - 2020-02-07 13:10:39 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 13:10:39 --> Config Class Initialized
INFO - 2020-02-07 13:10:39 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:10:39 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:39 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:39 --> URI Class Initialized
INFO - 2020-02-07 13:10:39 --> Router Class Initialized
INFO - 2020-02-07 13:10:39 --> Output Class Initialized
INFO - 2020-02-07 13:10:39 --> Security Class Initialized
DEBUG - 2020-02-07 13:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:39 --> Input Class Initialized
INFO - 2020-02-07 13:10:39 --> Language Class Initialized
ERROR - 2020-02-07 13:10:39 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 13:10:39 --> Config Class Initialized
INFO - 2020-02-07 13:10:39 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:10:39 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:39 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:39 --> URI Class Initialized
INFO - 2020-02-07 13:10:39 --> Router Class Initialized
INFO - 2020-02-07 13:10:39 --> Output Class Initialized
INFO - 2020-02-07 13:10:39 --> Security Class Initialized
DEBUG - 2020-02-07 13:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:39 --> Input Class Initialized
INFO - 2020-02-07 13:10:39 --> Language Class Initialized
ERROR - 2020-02-07 13:10:39 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 13:10:40 --> Config Class Initialized
INFO - 2020-02-07 13:10:40 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:10:40 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:40 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:40 --> URI Class Initialized
INFO - 2020-02-07 13:10:40 --> Router Class Initialized
INFO - 2020-02-07 13:10:40 --> Output Class Initialized
INFO - 2020-02-07 13:10:40 --> Security Class Initialized
DEBUG - 2020-02-07 13:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:40 --> Input Class Initialized
INFO - 2020-02-07 13:10:40 --> Language Class Initialized
ERROR - 2020-02-07 13:10:40 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 13:10:40 --> Config Class Initialized
INFO - 2020-02-07 13:10:40 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:10:40 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:10:40 --> Utf8 Class Initialized
INFO - 2020-02-07 13:10:40 --> URI Class Initialized
INFO - 2020-02-07 13:10:40 --> Router Class Initialized
INFO - 2020-02-07 13:10:40 --> Output Class Initialized
INFO - 2020-02-07 13:10:40 --> Security Class Initialized
DEBUG - 2020-02-07 13:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:10:40 --> Input Class Initialized
INFO - 2020-02-07 13:10:40 --> Language Class Initialized
ERROR - 2020-02-07 13:10:40 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 13:11:24 --> Config Class Initialized
INFO - 2020-02-07 13:11:24 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:11:24 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:11:24 --> Utf8 Class Initialized
INFO - 2020-02-07 13:11:24 --> URI Class Initialized
INFO - 2020-02-07 13:11:24 --> Router Class Initialized
INFO - 2020-02-07 13:11:24 --> Output Class Initialized
INFO - 2020-02-07 13:11:24 --> Security Class Initialized
DEBUG - 2020-02-07 13:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:11:25 --> Input Class Initialized
INFO - 2020-02-07 13:11:25 --> Language Class Initialized
INFO - 2020-02-07 13:11:25 --> Loader Class Initialized
INFO - 2020-02-07 13:11:25 --> Helper loaded: url_helper
INFO - 2020-02-07 13:11:25 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:11:25 --> Controller Class Initialized
INFO - 2020-02-07 13:11:25 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:11:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:11:25 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:11:25 --> Helper loaded: form_helper
INFO - 2020-02-07 13:11:25 --> Form Validation Class Initialized
ERROR - 2020-02-07 13:11:25 --> Severity: Notice --> Undefined variable: show C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 13:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 13:11:25 --> Severity: Notice --> Undefined variable: show C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 13:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 13:11:25 --> Severity: Notice --> Undefined variable: tiket C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 81
ERROR - 2020-02-07 13:11:26 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 81
INFO - 2020-02-07 13:15:51 --> Config Class Initialized
INFO - 2020-02-07 13:15:51 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:15:51 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:15:51 --> Utf8 Class Initialized
INFO - 2020-02-07 13:15:51 --> URI Class Initialized
INFO - 2020-02-07 13:15:51 --> Router Class Initialized
INFO - 2020-02-07 13:15:51 --> Output Class Initialized
INFO - 2020-02-07 13:15:51 --> Security Class Initialized
DEBUG - 2020-02-07 13:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:15:51 --> Input Class Initialized
INFO - 2020-02-07 13:15:51 --> Language Class Initialized
INFO - 2020-02-07 13:15:51 --> Loader Class Initialized
INFO - 2020-02-07 13:15:51 --> Helper loaded: url_helper
INFO - 2020-02-07 13:15:51 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:15:51 --> Controller Class Initialized
INFO - 2020-02-07 13:15:51 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:15:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:15:51 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:15:52 --> Helper loaded: form_helper
INFO - 2020-02-07 13:15:52 --> Form Validation Class Initialized
INFO - 2020-02-07 13:15:52 --> Final output sent to browser
DEBUG - 2020-02-07 13:15:52 --> Total execution time: 1.1636
INFO - 2020-02-07 13:16:10 --> Config Class Initialized
INFO - 2020-02-07 13:16:10 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:16:10 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:16:10 --> Utf8 Class Initialized
INFO - 2020-02-07 13:16:10 --> URI Class Initialized
INFO - 2020-02-07 13:16:10 --> Router Class Initialized
INFO - 2020-02-07 13:16:10 --> Output Class Initialized
INFO - 2020-02-07 13:16:10 --> Security Class Initialized
DEBUG - 2020-02-07 13:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:16:10 --> Input Class Initialized
INFO - 2020-02-07 13:16:10 --> Language Class Initialized
INFO - 2020-02-07 13:16:10 --> Loader Class Initialized
INFO - 2020-02-07 13:16:10 --> Helper loaded: url_helper
INFO - 2020-02-07 13:16:10 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:16:11 --> Controller Class Initialized
INFO - 2020-02-07 13:16:11 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:16:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:16:11 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:16:11 --> Helper loaded: form_helper
INFO - 2020-02-07 13:16:11 --> Form Validation Class Initialized
INFO - 2020-02-07 13:16:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 13:16:11 --> Final output sent to browser
INFO - 2020-02-07 13:16:11 --> Config Class Initialized
INFO - 2020-02-07 13:16:11 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:16:11 --> Total execution time: 1.0874
INFO - 2020-02-07 13:16:11 --> Config Class Initialized
INFO - 2020-02-07 13:16:11 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:16:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:16:11 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:16:11 --> Utf8 Class Initialized
INFO - 2020-02-07 13:16:11 --> Utf8 Class Initialized
INFO - 2020-02-07 13:16:11 --> URI Class Initialized
INFO - 2020-02-07 13:16:11 --> URI Class Initialized
INFO - 2020-02-07 13:16:11 --> Router Class Initialized
INFO - 2020-02-07 13:16:11 --> Router Class Initialized
INFO - 2020-02-07 13:16:11 --> Output Class Initialized
INFO - 2020-02-07 13:16:11 --> Output Class Initialized
INFO - 2020-02-07 13:16:11 --> Security Class Initialized
INFO - 2020-02-07 13:16:11 --> Security Class Initialized
DEBUG - 2020-02-07 13:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 13:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:16:11 --> Input Class Initialized
INFO - 2020-02-07 13:16:11 --> Input Class Initialized
INFO - 2020-02-07 13:16:11 --> Language Class Initialized
INFO - 2020-02-07 13:16:11 --> Language Class Initialized
INFO - 2020-02-07 13:16:11 --> Loader Class Initialized
INFO - 2020-02-07 13:16:11 --> Loader Class Initialized
INFO - 2020-02-07 13:16:11 --> Helper loaded: url_helper
INFO - 2020-02-07 13:16:11 --> Helper loaded: url_helper
INFO - 2020-02-07 13:16:11 --> Database Driver Class Initialized
INFO - 2020-02-07 13:16:11 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-07 13:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:16:12 --> Controller Class Initialized
INFO - 2020-02-07 13:16:12 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:16:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:16:12 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:16:12 --> Helper loaded: form_helper
INFO - 2020-02-07 13:16:12 --> Form Validation Class Initialized
ERROR - 2020-02-07 13:16:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 13:16:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 13:16:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 13:16:12 --> Final output sent to browser
DEBUG - 2020-02-07 13:16:12 --> Total execution time: 0.8538
INFO - 2020-02-07 13:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:16:12 --> Controller Class Initialized
INFO - 2020-02-07 13:16:12 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:16:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:16:12 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:16:12 --> Helper loaded: form_helper
INFO - 2020-02-07 13:16:12 --> Form Validation Class Initialized
ERROR - 2020-02-07 13:16:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 13:16:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 13:16:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 13:16:12 --> Final output sent to browser
DEBUG - 2020-02-07 13:16:12 --> Total execution time: 1.2207
INFO - 2020-02-07 13:16:22 --> Config Class Initialized
INFO - 2020-02-07 13:16:22 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:16:22 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:16:22 --> Utf8 Class Initialized
INFO - 2020-02-07 13:16:22 --> URI Class Initialized
INFO - 2020-02-07 13:16:22 --> Router Class Initialized
INFO - 2020-02-07 13:16:22 --> Output Class Initialized
INFO - 2020-02-07 13:16:22 --> Security Class Initialized
DEBUG - 2020-02-07 13:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:16:22 --> Input Class Initialized
INFO - 2020-02-07 13:16:22 --> Language Class Initialized
INFO - 2020-02-07 13:16:22 --> Loader Class Initialized
INFO - 2020-02-07 13:16:23 --> Helper loaded: url_helper
INFO - 2020-02-07 13:16:23 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:16:23 --> Controller Class Initialized
INFO - 2020-02-07 13:16:23 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:16:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:16:23 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:16:23 --> Helper loaded: form_helper
INFO - 2020-02-07 13:16:23 --> Form Validation Class Initialized
INFO - 2020-02-07 13:16:23 --> Final output sent to browser
DEBUG - 2020-02-07 13:16:23 --> Total execution time: 0.9410
INFO - 2020-02-07 13:17:25 --> Config Class Initialized
INFO - 2020-02-07 13:17:25 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:25 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:25 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:25 --> URI Class Initialized
INFO - 2020-02-07 13:17:25 --> Router Class Initialized
INFO - 2020-02-07 13:17:25 --> Output Class Initialized
INFO - 2020-02-07 13:17:25 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:25 --> Input Class Initialized
INFO - 2020-02-07 13:17:25 --> Language Class Initialized
INFO - 2020-02-07 13:17:25 --> Loader Class Initialized
INFO - 2020-02-07 13:17:25 --> Helper loaded: url_helper
INFO - 2020-02-07 13:17:25 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:17:25 --> Controller Class Initialized
INFO - 2020-02-07 13:17:25 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:17:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:17:25 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:17:25 --> Helper loaded: form_helper
INFO - 2020-02-07 13:17:25 --> Form Validation Class Initialized
INFO - 2020-02-07 13:17:25 --> Final output sent to browser
DEBUG - 2020-02-07 13:17:25 --> Total execution time: 0.7469
INFO - 2020-02-07 13:17:28 --> Config Class Initialized
INFO - 2020-02-07 13:17:28 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:28 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:28 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:28 --> URI Class Initialized
INFO - 2020-02-07 13:17:28 --> Router Class Initialized
INFO - 2020-02-07 13:17:28 --> Output Class Initialized
INFO - 2020-02-07 13:17:28 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:28 --> Input Class Initialized
INFO - 2020-02-07 13:17:28 --> Language Class Initialized
INFO - 2020-02-07 13:17:28 --> Loader Class Initialized
INFO - 2020-02-07 13:17:28 --> Helper loaded: url_helper
INFO - 2020-02-07 13:17:28 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:17:28 --> Controller Class Initialized
INFO - 2020-02-07 13:17:28 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:17:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:17:28 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:17:28 --> Helper loaded: form_helper
INFO - 2020-02-07 13:17:28 --> Form Validation Class Initialized
INFO - 2020-02-07 13:17:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 13:17:29 --> Final output sent to browser
DEBUG - 2020-02-07 13:17:29 --> Total execution time: 0.6653
INFO - 2020-02-07 13:17:29 --> Config Class Initialized
INFO - 2020-02-07 13:17:29 --> Config Class Initialized
INFO - 2020-02-07 13:17:29 --> Hooks Class Initialized
INFO - 2020-02-07 13:17:29 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:17:29 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:29 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:29 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:29 --> URI Class Initialized
INFO - 2020-02-07 13:17:29 --> URI Class Initialized
INFO - 2020-02-07 13:17:29 --> Router Class Initialized
INFO - 2020-02-07 13:17:29 --> Router Class Initialized
INFO - 2020-02-07 13:17:29 --> Output Class Initialized
INFO - 2020-02-07 13:17:29 --> Output Class Initialized
INFO - 2020-02-07 13:17:29 --> Security Class Initialized
INFO - 2020-02-07 13:17:29 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 13:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:29 --> Input Class Initialized
INFO - 2020-02-07 13:17:29 --> Input Class Initialized
INFO - 2020-02-07 13:17:29 --> Language Class Initialized
INFO - 2020-02-07 13:17:29 --> Language Class Initialized
INFO - 2020-02-07 13:17:29 --> Loader Class Initialized
INFO - 2020-02-07 13:17:29 --> Loader Class Initialized
INFO - 2020-02-07 13:17:29 --> Helper loaded: url_helper
INFO - 2020-02-07 13:17:29 --> Helper loaded: url_helper
INFO - 2020-02-07 13:17:29 --> Database Driver Class Initialized
INFO - 2020-02-07 13:17:29 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-07 13:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:17:29 --> Controller Class Initialized
INFO - 2020-02-07 13:17:29 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:17:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:17:29 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:17:30 --> Helper loaded: form_helper
INFO - 2020-02-07 13:17:30 --> Form Validation Class Initialized
ERROR - 2020-02-07 13:17:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 13:17:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 13:17:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 13:17:30 --> Final output sent to browser
DEBUG - 2020-02-07 13:17:30 --> Total execution time: 1.0754
INFO - 2020-02-07 13:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:17:30 --> Controller Class Initialized
INFO - 2020-02-07 13:17:30 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:17:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:17:30 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:17:30 --> Helper loaded: form_helper
INFO - 2020-02-07 13:17:30 --> Form Validation Class Initialized
ERROR - 2020-02-07 13:17:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 13:17:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 13:17:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 13:17:30 --> Final output sent to browser
DEBUG - 2020-02-07 13:17:30 --> Total execution time: 1.3935
INFO - 2020-02-07 13:17:33 --> Config Class Initialized
INFO - 2020-02-07 13:17:33 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:33 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:33 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:33 --> URI Class Initialized
INFO - 2020-02-07 13:17:33 --> Router Class Initialized
INFO - 2020-02-07 13:17:33 --> Output Class Initialized
INFO - 2020-02-07 13:17:33 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:33 --> Input Class Initialized
INFO - 2020-02-07 13:17:33 --> Language Class Initialized
INFO - 2020-02-07 13:17:33 --> Loader Class Initialized
INFO - 2020-02-07 13:17:33 --> Helper loaded: url_helper
INFO - 2020-02-07 13:17:33 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:17:33 --> Controller Class Initialized
INFO - 2020-02-07 13:17:33 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:17:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:17:33 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:17:33 --> Helper loaded: form_helper
INFO - 2020-02-07 13:17:33 --> Form Validation Class Initialized
INFO - 2020-02-07 13:17:33 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 13:17:33 --> Final output sent to browser
DEBUG - 2020-02-07 13:17:33 --> Total execution time: 0.6164
INFO - 2020-02-07 13:17:33 --> Config Class Initialized
INFO - 2020-02-07 13:17:33 --> Config Class Initialized
INFO - 2020-02-07 13:17:33 --> Config Class Initialized
INFO - 2020-02-07 13:17:33 --> Config Class Initialized
INFO - 2020-02-07 13:17:33 --> Config Class Initialized
INFO - 2020-02-07 13:17:33 --> Hooks Class Initialized
INFO - 2020-02-07 13:17:33 --> Hooks Class Initialized
INFO - 2020-02-07 13:17:33 --> Hooks Class Initialized
INFO - 2020-02-07 13:17:33 --> Hooks Class Initialized
INFO - 2020-02-07 13:17:33 --> Hooks Class Initialized
INFO - 2020-02-07 13:17:33 --> Config Class Initialized
INFO - 2020-02-07 13:17:33 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:17:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:17:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:17:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:17:33 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:33 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:33 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:33 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:33 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:33 --> Utf8 Class Initialized
DEBUG - 2020-02-07 13:17:33 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:34 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
INFO - 2020-02-07 13:17:34 --> Language Class Initialized
INFO - 2020-02-07 13:17:34 --> Language Class Initialized
INFO - 2020-02-07 13:17:34 --> Language Class Initialized
INFO - 2020-02-07 13:17:34 --> Language Class Initialized
INFO - 2020-02-07 13:17:34 --> Language Class Initialized
INFO - 2020-02-07 13:17:34 --> Language Class Initialized
ERROR - 2020-02-07 13:17:34 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-07 13:17:34 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 13:17:34 --> Loader Class Initialized
INFO - 2020-02-07 13:17:34 --> Loader Class Initialized
ERROR - 2020-02-07 13:17:34 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 13:17:34 --> Helper loaded: url_helper
INFO - 2020-02-07 13:17:34 --> Helper loaded: url_helper
ERROR - 2020-02-07 13:17:34 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 13:17:34 --> Config Class Initialized
INFO - 2020-02-07 13:17:34 --> Config Class Initialized
INFO - 2020-02-07 13:17:34 --> Config Class Initialized
INFO - 2020-02-07 13:17:34 --> Hooks Class Initialized
INFO - 2020-02-07 13:17:34 --> Hooks Class Initialized
INFO - 2020-02-07 13:17:34 --> Hooks Class Initialized
INFO - 2020-02-07 13:17:34 --> Database Driver Class Initialized
INFO - 2020-02-07 13:17:34 --> Database Driver Class Initialized
INFO - 2020-02-07 13:17:34 --> Config Class Initialized
INFO - 2020-02-07 13:17:34 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:17:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:17:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-07 13:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:17:34 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:17:34 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:34 --> Utf8 Class Initialized
DEBUG - 2020-02-07 13:17:34 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:34 --> Controller Class Initialized
INFO - 2020-02-07 13:17:34 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
INFO - 2020-02-07 13:17:34 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
INFO - 2020-02-07 13:17:34 --> Model "M_pesan" initialized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:34 --> Helper loaded: form_helper
INFO - 2020-02-07 13:17:34 --> Form Validation Class Initialized
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
INFO - 2020-02-07 13:17:34 --> Language Class Initialized
INFO - 2020-02-07 13:17:34 --> Language Class Initialized
INFO - 2020-02-07 13:17:34 --> Language Class Initialized
ERROR - 2020-02-07 13:17:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 13:17:34 --> Language Class Initialized
ERROR - 2020-02-07 13:17:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 13:17:34 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 13:17:34 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 13:17:34 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 13:17:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 13:17:34 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 13:17:34 --> Config Class Initialized
INFO - 2020-02-07 13:17:34 --> Config Class Initialized
INFO - 2020-02-07 13:17:34 --> Config Class Initialized
INFO - 2020-02-07 13:17:34 --> Hooks Class Initialized
INFO - 2020-02-07 13:17:34 --> Hooks Class Initialized
INFO - 2020-02-07 13:17:34 --> Final output sent to browser
INFO - 2020-02-07 13:17:34 --> Hooks Class Initialized
INFO - 2020-02-07 13:17:34 --> Config Class Initialized
DEBUG - 2020-02-07 13:17:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:17:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:17:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:17:34 --> Total execution time: 0.8472
INFO - 2020-02-07 13:17:34 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:34 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:34 --> Hooks Class Initialized
INFO - 2020-02-07 13:17:34 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:17:34 --> Controller Class Initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
DEBUG - 2020-02-07 13:17:34 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:34 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:34 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
INFO - 2020-02-07 13:17:34 --> URI Class Initialized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
INFO - 2020-02-07 13:17:34 --> Router Class Initialized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
INFO - 2020-02-07 13:17:34 --> Model "M_pesan" initialized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:34 --> Output Class Initialized
INFO - 2020-02-07 13:17:34 --> Helper loaded: form_helper
INFO - 2020-02-07 13:17:34 --> Form Validation Class Initialized
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
INFO - 2020-02-07 13:17:34 --> Security Class Initialized
INFO - 2020-02-07 13:17:34 --> Language Class Initialized
INFO - 2020-02-07 13:17:34 --> Language Class Initialized
INFO - 2020-02-07 13:17:34 --> Language Class Initialized
DEBUG - 2020-02-07 13:17:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-07 13:17:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 13:17:34 --> Input Class Initialized
ERROR - 2020-02-07 13:17:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 13:17:34 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-07 13:17:34 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-07 13:17:34 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 13:17:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 13:17:35 --> Language Class Initialized
INFO - 2020-02-07 13:17:35 --> Final output sent to browser
ERROR - 2020-02-07 13:17:35 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-07 13:17:35 --> Total execution time: 1.1786
INFO - 2020-02-07 13:17:35 --> Config Class Initialized
INFO - 2020-02-07 13:17:35 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:35 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:35 --> URI Class Initialized
INFO - 2020-02-07 13:17:35 --> Router Class Initialized
INFO - 2020-02-07 13:17:35 --> Output Class Initialized
INFO - 2020-02-07 13:17:35 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:35 --> Input Class Initialized
INFO - 2020-02-07 13:17:35 --> Language Class Initialized
ERROR - 2020-02-07 13:17:35 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 13:17:35 --> Config Class Initialized
INFO - 2020-02-07 13:17:35 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:35 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:35 --> URI Class Initialized
INFO - 2020-02-07 13:17:35 --> Router Class Initialized
INFO - 2020-02-07 13:17:35 --> Output Class Initialized
INFO - 2020-02-07 13:17:35 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:35 --> Input Class Initialized
INFO - 2020-02-07 13:17:35 --> Language Class Initialized
ERROR - 2020-02-07 13:17:35 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 13:17:35 --> Config Class Initialized
INFO - 2020-02-07 13:17:35 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:35 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:35 --> URI Class Initialized
INFO - 2020-02-07 13:17:35 --> Router Class Initialized
INFO - 2020-02-07 13:17:35 --> Output Class Initialized
INFO - 2020-02-07 13:17:36 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:36 --> Input Class Initialized
INFO - 2020-02-07 13:17:36 --> Language Class Initialized
ERROR - 2020-02-07 13:17:36 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 13:17:36 --> Config Class Initialized
INFO - 2020-02-07 13:17:36 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:36 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:36 --> URI Class Initialized
INFO - 2020-02-07 13:17:36 --> Router Class Initialized
INFO - 2020-02-07 13:17:36 --> Output Class Initialized
INFO - 2020-02-07 13:17:36 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:36 --> Input Class Initialized
INFO - 2020-02-07 13:17:36 --> Language Class Initialized
ERROR - 2020-02-07 13:17:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 13:17:36 --> Config Class Initialized
INFO - 2020-02-07 13:17:36 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:36 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:36 --> URI Class Initialized
INFO - 2020-02-07 13:17:36 --> Router Class Initialized
INFO - 2020-02-07 13:17:36 --> Output Class Initialized
INFO - 2020-02-07 13:17:36 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:36 --> Input Class Initialized
INFO - 2020-02-07 13:17:36 --> Language Class Initialized
ERROR - 2020-02-07 13:17:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 13:17:36 --> Config Class Initialized
INFO - 2020-02-07 13:17:36 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:36 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:36 --> URI Class Initialized
INFO - 2020-02-07 13:17:37 --> Router Class Initialized
INFO - 2020-02-07 13:17:37 --> Output Class Initialized
INFO - 2020-02-07 13:17:37 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:37 --> Input Class Initialized
INFO - 2020-02-07 13:17:37 --> Language Class Initialized
ERROR - 2020-02-07 13:17:37 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 13:17:37 --> Config Class Initialized
INFO - 2020-02-07 13:17:37 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:37 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:37 --> URI Class Initialized
INFO - 2020-02-07 13:17:37 --> Router Class Initialized
INFO - 2020-02-07 13:17:37 --> Output Class Initialized
INFO - 2020-02-07 13:17:37 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:37 --> Input Class Initialized
INFO - 2020-02-07 13:17:37 --> Language Class Initialized
ERROR - 2020-02-07 13:17:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 13:17:37 --> Config Class Initialized
INFO - 2020-02-07 13:17:37 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:37 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:37 --> URI Class Initialized
INFO - 2020-02-07 13:17:37 --> Router Class Initialized
INFO - 2020-02-07 13:17:37 --> Output Class Initialized
INFO - 2020-02-07 13:17:37 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:37 --> Input Class Initialized
INFO - 2020-02-07 13:17:37 --> Language Class Initialized
ERROR - 2020-02-07 13:17:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 13:17:37 --> Config Class Initialized
INFO - 2020-02-07 13:17:37 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:37 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:38 --> URI Class Initialized
INFO - 2020-02-07 13:17:38 --> Router Class Initialized
INFO - 2020-02-07 13:17:38 --> Output Class Initialized
INFO - 2020-02-07 13:17:38 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:38 --> Input Class Initialized
INFO - 2020-02-07 13:17:38 --> Language Class Initialized
ERROR - 2020-02-07 13:17:38 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 13:17:57 --> Config Class Initialized
INFO - 2020-02-07 13:17:57 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:17:57 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:17:57 --> Utf8 Class Initialized
INFO - 2020-02-07 13:17:57 --> URI Class Initialized
INFO - 2020-02-07 13:17:57 --> Router Class Initialized
INFO - 2020-02-07 13:17:57 --> Output Class Initialized
INFO - 2020-02-07 13:17:57 --> Security Class Initialized
DEBUG - 2020-02-07 13:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:17:57 --> Input Class Initialized
INFO - 2020-02-07 13:17:58 --> Language Class Initialized
INFO - 2020-02-07 13:17:58 --> Loader Class Initialized
INFO - 2020-02-07 13:17:58 --> Helper loaded: url_helper
INFO - 2020-02-07 13:17:58 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:17:58 --> Controller Class Initialized
INFO - 2020-02-07 13:17:58 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:17:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:17:58 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:17:58 --> Helper loaded: form_helper
INFO - 2020-02-07 13:17:58 --> Form Validation Class Initialized
INFO - 2020-02-07 13:17:58 --> Final output sent to browser
DEBUG - 2020-02-07 13:17:58 --> Total execution time: 0.7467
INFO - 2020-02-07 13:18:42 --> Config Class Initialized
INFO - 2020-02-07 13:18:42 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:18:42 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:18:42 --> Utf8 Class Initialized
INFO - 2020-02-07 13:18:42 --> URI Class Initialized
INFO - 2020-02-07 13:18:42 --> Router Class Initialized
INFO - 2020-02-07 13:18:42 --> Output Class Initialized
INFO - 2020-02-07 13:18:42 --> Security Class Initialized
DEBUG - 2020-02-07 13:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:18:42 --> Input Class Initialized
INFO - 2020-02-07 13:18:42 --> Language Class Initialized
INFO - 2020-02-07 13:18:42 --> Loader Class Initialized
INFO - 2020-02-07 13:18:42 --> Helper loaded: url_helper
INFO - 2020-02-07 13:18:42 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:18:42 --> Controller Class Initialized
INFO - 2020-02-07 13:18:42 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:18:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:18:42 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:18:42 --> Helper loaded: form_helper
INFO - 2020-02-07 13:18:42 --> Form Validation Class Initialized
INFO - 2020-02-07 13:18:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 13:18:43 --> Final output sent to browser
DEBUG - 2020-02-07 13:18:43 --> Total execution time: 0.7060
INFO - 2020-02-07 13:18:43 --> Config Class Initialized
INFO - 2020-02-07 13:18:43 --> Config Class Initialized
INFO - 2020-02-07 13:18:43 --> Hooks Class Initialized
INFO - 2020-02-07 13:18:43 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:18:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 13:18:43 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:18:43 --> Utf8 Class Initialized
INFO - 2020-02-07 13:18:43 --> Utf8 Class Initialized
INFO - 2020-02-07 13:18:43 --> URI Class Initialized
INFO - 2020-02-07 13:18:43 --> URI Class Initialized
INFO - 2020-02-07 13:18:43 --> Router Class Initialized
INFO - 2020-02-07 13:18:43 --> Router Class Initialized
INFO - 2020-02-07 13:18:43 --> Output Class Initialized
INFO - 2020-02-07 13:18:43 --> Output Class Initialized
INFO - 2020-02-07 13:18:43 --> Security Class Initialized
INFO - 2020-02-07 13:18:43 --> Security Class Initialized
DEBUG - 2020-02-07 13:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 13:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:18:43 --> Input Class Initialized
INFO - 2020-02-07 13:18:43 --> Input Class Initialized
INFO - 2020-02-07 13:18:43 --> Language Class Initialized
INFO - 2020-02-07 13:18:43 --> Language Class Initialized
INFO - 2020-02-07 13:18:43 --> Loader Class Initialized
INFO - 2020-02-07 13:18:43 --> Loader Class Initialized
INFO - 2020-02-07 13:18:43 --> Helper loaded: url_helper
INFO - 2020-02-07 13:18:43 --> Helper loaded: url_helper
INFO - 2020-02-07 13:18:43 --> Database Driver Class Initialized
INFO - 2020-02-07 13:18:43 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-07 13:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:18:43 --> Controller Class Initialized
INFO - 2020-02-07 13:18:43 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:18:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:18:43 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:18:43 --> Helper loaded: form_helper
INFO - 2020-02-07 13:18:43 --> Form Validation Class Initialized
ERROR - 2020-02-07 13:18:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 13:18:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 13:18:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 13:18:43 --> Final output sent to browser
DEBUG - 2020-02-07 13:18:43 --> Total execution time: 0.8456
INFO - 2020-02-07 13:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:18:44 --> Controller Class Initialized
INFO - 2020-02-07 13:18:44 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:18:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:18:44 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:18:44 --> Helper loaded: form_helper
INFO - 2020-02-07 13:18:44 --> Form Validation Class Initialized
ERROR - 2020-02-07 13:18:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 13:18:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 13:18:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 13:18:44 --> Final output sent to browser
DEBUG - 2020-02-07 13:18:44 --> Total execution time: 1.1404
INFO - 2020-02-07 13:19:27 --> Config Class Initialized
INFO - 2020-02-07 13:19:27 --> Hooks Class Initialized
DEBUG - 2020-02-07 13:19:27 --> UTF-8 Support Enabled
INFO - 2020-02-07 13:19:27 --> Utf8 Class Initialized
INFO - 2020-02-07 13:19:27 --> URI Class Initialized
INFO - 2020-02-07 13:19:27 --> Router Class Initialized
INFO - 2020-02-07 13:19:27 --> Output Class Initialized
INFO - 2020-02-07 13:19:27 --> Security Class Initialized
DEBUG - 2020-02-07 13:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 13:19:28 --> Input Class Initialized
INFO - 2020-02-07 13:19:28 --> Language Class Initialized
INFO - 2020-02-07 13:19:28 --> Loader Class Initialized
INFO - 2020-02-07 13:19:28 --> Helper loaded: url_helper
INFO - 2020-02-07 13:19:28 --> Database Driver Class Initialized
DEBUG - 2020-02-07 13:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 13:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 13:19:28 --> Controller Class Initialized
INFO - 2020-02-07 13:19:28 --> Model "M_tiket" initialized
INFO - 2020-02-07 13:19:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 13:19:28 --> Model "M_pesan" initialized
INFO - 2020-02-07 13:19:28 --> Helper loaded: form_helper
INFO - 2020-02-07 13:19:28 --> Form Validation Class Initialized
INFO - 2020-02-07 13:19:29 --> Final output sent to browser
DEBUG - 2020-02-07 13:19:29 --> Total execution time: 1.3168
INFO - 2020-02-07 16:12:56 --> Config Class Initialized
INFO - 2020-02-07 16:12:56 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:12:56 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:12:56 --> Utf8 Class Initialized
INFO - 2020-02-07 16:12:57 --> URI Class Initialized
INFO - 2020-02-07 16:12:57 --> Router Class Initialized
INFO - 2020-02-07 16:12:57 --> Output Class Initialized
INFO - 2020-02-07 16:12:57 --> Security Class Initialized
DEBUG - 2020-02-07 16:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:12:57 --> Input Class Initialized
INFO - 2020-02-07 16:12:57 --> Language Class Initialized
INFO - 2020-02-07 16:12:57 --> Loader Class Initialized
INFO - 2020-02-07 16:12:57 --> Helper loaded: url_helper
INFO - 2020-02-07 16:12:57 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:12:57 --> Controller Class Initialized
INFO - 2020-02-07 16:12:57 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:12:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:12:57 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:12:57 --> Helper loaded: form_helper
INFO - 2020-02-07 16:12:57 --> Form Validation Class Initialized
INFO - 2020-02-07 16:12:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:12:57 --> Final output sent to browser
DEBUG - 2020-02-07 16:12:57 --> Total execution time: 0.5101
INFO - 2020-02-07 16:12:57 --> Config Class Initialized
INFO - 2020-02-07 16:12:57 --> Config Class Initialized
INFO - 2020-02-07 16:12:57 --> Hooks Class Initialized
INFO - 2020-02-07 16:12:57 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:12:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:12:57 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:12:57 --> Utf8 Class Initialized
INFO - 2020-02-07 16:12:57 --> Utf8 Class Initialized
INFO - 2020-02-07 16:12:57 --> URI Class Initialized
INFO - 2020-02-07 16:12:57 --> URI Class Initialized
INFO - 2020-02-07 16:12:57 --> Router Class Initialized
INFO - 2020-02-07 16:12:57 --> Router Class Initialized
INFO - 2020-02-07 16:12:57 --> Output Class Initialized
INFO - 2020-02-07 16:12:57 --> Output Class Initialized
INFO - 2020-02-07 16:12:57 --> Security Class Initialized
INFO - 2020-02-07 16:12:57 --> Security Class Initialized
DEBUG - 2020-02-07 16:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:12:57 --> Input Class Initialized
INFO - 2020-02-07 16:12:57 --> Input Class Initialized
INFO - 2020-02-07 16:12:57 --> Language Class Initialized
INFO - 2020-02-07 16:12:57 --> Language Class Initialized
INFO - 2020-02-07 16:12:57 --> Loader Class Initialized
INFO - 2020-02-07 16:12:57 --> Loader Class Initialized
INFO - 2020-02-07 16:12:57 --> Helper loaded: url_helper
INFO - 2020-02-07 16:12:57 --> Helper loaded: url_helper
INFO - 2020-02-07 16:12:57 --> Database Driver Class Initialized
INFO - 2020-02-07 16:12:57 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-07 16:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:12:58 --> Controller Class Initialized
INFO - 2020-02-07 16:12:58 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:12:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:12:58 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:12:58 --> Helper loaded: form_helper
INFO - 2020-02-07 16:12:58 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:12:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 16:12:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 16:12:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:12:58 --> Final output sent to browser
DEBUG - 2020-02-07 16:12:58 --> Total execution time: 0.6722
INFO - 2020-02-07 16:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:12:58 --> Controller Class Initialized
INFO - 2020-02-07 16:12:58 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:12:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:12:58 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:12:58 --> Helper loaded: form_helper
INFO - 2020-02-07 16:12:58 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:12:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 16:12:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 16:12:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:12:58 --> Final output sent to browser
DEBUG - 2020-02-07 16:12:58 --> Total execution time: 0.8981
INFO - 2020-02-07 16:13:00 --> Config Class Initialized
INFO - 2020-02-07 16:13:00 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:13:00 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:00 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:00 --> URI Class Initialized
INFO - 2020-02-07 16:13:00 --> Router Class Initialized
INFO - 2020-02-07 16:13:00 --> Output Class Initialized
INFO - 2020-02-07 16:13:00 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:00 --> Input Class Initialized
INFO - 2020-02-07 16:13:00 --> Language Class Initialized
INFO - 2020-02-07 16:13:00 --> Loader Class Initialized
INFO - 2020-02-07 16:13:00 --> Helper loaded: url_helper
INFO - 2020-02-07 16:13:00 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:13:00 --> Controller Class Initialized
INFO - 2020-02-07 16:13:00 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:13:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:13:00 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:13:00 --> Helper loaded: form_helper
INFO - 2020-02-07 16:13:00 --> Form Validation Class Initialized
INFO - 2020-02-07 16:13:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:13:01 --> Final output sent to browser
DEBUG - 2020-02-07 16:13:01 --> Total execution time: 0.5212
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
ERROR - 2020-02-07 16:13:01 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-07 16:13:01 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-07 16:13:01 --> Loader Class Initialized
INFO - 2020-02-07 16:13:01 --> Loader Class Initialized
ERROR - 2020-02-07 16:13:01 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 16:13:01 --> Helper loaded: url_helper
INFO - 2020-02-07 16:13:01 --> Helper loaded: url_helper
ERROR - 2020-02-07 16:13:01 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
INFO - 2020-02-07 16:13:01 --> Database Driver Class Initialized
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
INFO - 2020-02-07 16:13:01 --> Database Driver Class Initialized
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-07 16:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:01 --> Controller Class Initialized
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
INFO - 2020-02-07 16:13:01 --> Helper loaded: form_helper
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
INFO - 2020-02-07 16:13:01 --> Form Validation Class Initialized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
ERROR - 2020-02-07 16:13:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
ERROR - 2020-02-07 16:13:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
ERROR - 2020-02-07 16:13:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-07 16:13:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:13:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 16:13:01 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-07 16:13:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
INFO - 2020-02-07 16:13:01 --> Final output sent to browser
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
INFO - 2020-02-07 16:13:01 --> Config Class Initialized
DEBUG - 2020-02-07 16:13:01 --> Total execution time: 0.6388
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
INFO - 2020-02-07 16:13:01 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:13:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:01 --> Controller Class Initialized
INFO - 2020-02-07 16:13:01 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> URI Class Initialized
INFO - 2020-02-07 16:13:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> Router Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Output Class Initialized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:01 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:01 --> Helper loaded: form_helper
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
INFO - 2020-02-07 16:13:01 --> Form Validation Class Initialized
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
INFO - 2020-02-07 16:13:01 --> Input Class Initialized
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
ERROR - 2020-02-07 16:13:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
ERROR - 2020-02-07 16:13:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 16:13:01 --> Language Class Initialized
ERROR - 2020-02-07 16:13:01 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-07 16:13:01 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 16:13:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 16:13:01 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-07 16:13:01 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 16:13:01 --> Final output sent to browser
INFO - 2020-02-07 16:13:02 --> Config Class Initialized
DEBUG - 2020-02-07 16:13:02 --> Total execution time: 0.9035
INFO - 2020-02-07 16:13:02 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:13:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:02 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:02 --> URI Class Initialized
INFO - 2020-02-07 16:13:02 --> Router Class Initialized
INFO - 2020-02-07 16:13:02 --> Output Class Initialized
INFO - 2020-02-07 16:13:02 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:02 --> Input Class Initialized
INFO - 2020-02-07 16:13:02 --> Language Class Initialized
ERROR - 2020-02-07 16:13:02 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 16:13:02 --> Config Class Initialized
INFO - 2020-02-07 16:13:02 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:13:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:02 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:02 --> URI Class Initialized
INFO - 2020-02-07 16:13:02 --> Router Class Initialized
INFO - 2020-02-07 16:13:02 --> Output Class Initialized
INFO - 2020-02-07 16:13:02 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:02 --> Input Class Initialized
INFO - 2020-02-07 16:13:02 --> Language Class Initialized
ERROR - 2020-02-07 16:13:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 16:13:02 --> Config Class Initialized
INFO - 2020-02-07 16:13:02 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:13:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:02 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:02 --> URI Class Initialized
INFO - 2020-02-07 16:13:02 --> Router Class Initialized
INFO - 2020-02-07 16:13:02 --> Output Class Initialized
INFO - 2020-02-07 16:13:02 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:02 --> Input Class Initialized
INFO - 2020-02-07 16:13:02 --> Language Class Initialized
ERROR - 2020-02-07 16:13:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:13:02 --> Config Class Initialized
INFO - 2020-02-07 16:13:02 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:13:02 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:02 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:02 --> URI Class Initialized
INFO - 2020-02-07 16:13:02 --> Router Class Initialized
INFO - 2020-02-07 16:13:02 --> Output Class Initialized
INFO - 2020-02-07 16:13:02 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:02 --> Input Class Initialized
INFO - 2020-02-07 16:13:02 --> Language Class Initialized
ERROR - 2020-02-07 16:13:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:13:03 --> Config Class Initialized
INFO - 2020-02-07 16:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:03 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:03 --> URI Class Initialized
INFO - 2020-02-07 16:13:03 --> Router Class Initialized
INFO - 2020-02-07 16:13:03 --> Output Class Initialized
INFO - 2020-02-07 16:13:03 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:03 --> Input Class Initialized
INFO - 2020-02-07 16:13:03 --> Language Class Initialized
ERROR - 2020-02-07 16:13:03 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 16:13:03 --> Config Class Initialized
INFO - 2020-02-07 16:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:03 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:03 --> URI Class Initialized
INFO - 2020-02-07 16:13:03 --> Router Class Initialized
INFO - 2020-02-07 16:13:03 --> Output Class Initialized
INFO - 2020-02-07 16:13:03 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:03 --> Input Class Initialized
INFO - 2020-02-07 16:13:03 --> Language Class Initialized
ERROR - 2020-02-07 16:13:03 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 16:13:03 --> Config Class Initialized
INFO - 2020-02-07 16:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:03 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:03 --> URI Class Initialized
INFO - 2020-02-07 16:13:03 --> Router Class Initialized
INFO - 2020-02-07 16:13:03 --> Output Class Initialized
INFO - 2020-02-07 16:13:03 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:03 --> Input Class Initialized
INFO - 2020-02-07 16:13:03 --> Language Class Initialized
ERROR - 2020-02-07 16:13:03 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 16:13:03 --> Config Class Initialized
INFO - 2020-02-07 16:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:03 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:03 --> URI Class Initialized
INFO - 2020-02-07 16:13:03 --> Router Class Initialized
INFO - 2020-02-07 16:13:04 --> Output Class Initialized
INFO - 2020-02-07 16:13:04 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:04 --> Input Class Initialized
INFO - 2020-02-07 16:13:04 --> Language Class Initialized
ERROR - 2020-02-07 16:13:04 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 16:13:31 --> Config Class Initialized
INFO - 2020-02-07 16:13:31 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:13:31 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:13:31 --> Utf8 Class Initialized
INFO - 2020-02-07 16:13:31 --> URI Class Initialized
INFO - 2020-02-07 16:13:31 --> Router Class Initialized
INFO - 2020-02-07 16:13:31 --> Output Class Initialized
INFO - 2020-02-07 16:13:31 --> Security Class Initialized
DEBUG - 2020-02-07 16:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:13:31 --> Input Class Initialized
INFO - 2020-02-07 16:13:31 --> Language Class Initialized
INFO - 2020-02-07 16:13:31 --> Loader Class Initialized
INFO - 2020-02-07 16:13:31 --> Helper loaded: url_helper
INFO - 2020-02-07 16:13:31 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:13:31 --> Controller Class Initialized
INFO - 2020-02-07 16:13:31 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:13:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:13:31 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:13:32 --> Helper loaded: form_helper
INFO - 2020-02-07 16:13:32 --> Form Validation Class Initialized
INFO - 2020-02-07 16:13:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:13:32 --> Final output sent to browser
DEBUG - 2020-02-07 16:13:32 --> Total execution time: 0.6610
INFO - 2020-02-07 16:15:30 --> Config Class Initialized
INFO - 2020-02-07 16:15:30 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:15:30 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:15:30 --> Utf8 Class Initialized
INFO - 2020-02-07 16:15:30 --> URI Class Initialized
INFO - 2020-02-07 16:15:30 --> Router Class Initialized
INFO - 2020-02-07 16:15:30 --> Output Class Initialized
INFO - 2020-02-07 16:15:30 --> Security Class Initialized
DEBUG - 2020-02-07 16:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:15:30 --> Input Class Initialized
INFO - 2020-02-07 16:15:30 --> Language Class Initialized
INFO - 2020-02-07 16:15:30 --> Loader Class Initialized
INFO - 2020-02-07 16:15:30 --> Helper loaded: url_helper
INFO - 2020-02-07 16:15:30 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:15:30 --> Controller Class Initialized
INFO - 2020-02-07 16:15:30 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:15:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:15:30 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:15:30 --> Helper loaded: form_helper
INFO - 2020-02-07 16:15:30 --> Form Validation Class Initialized
INFO - 2020-02-07 16:15:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:15:31 --> Final output sent to browser
DEBUG - 2020-02-07 16:15:31 --> Total execution time: 0.5363
INFO - 2020-02-07 16:15:31 --> Config Class Initialized
INFO - 2020-02-07 16:15:31 --> Config Class Initialized
INFO - 2020-02-07 16:15:31 --> Config Class Initialized
INFO - 2020-02-07 16:15:31 --> Hooks Class Initialized
INFO - 2020-02-07 16:15:31 --> Hooks Class Initialized
INFO - 2020-02-07 16:15:31 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:15:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:15:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:15:31 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:15:31 --> Utf8 Class Initialized
INFO - 2020-02-07 16:15:31 --> Utf8 Class Initialized
INFO - 2020-02-07 16:15:31 --> Utf8 Class Initialized
INFO - 2020-02-07 16:15:31 --> URI Class Initialized
INFO - 2020-02-07 16:15:31 --> URI Class Initialized
INFO - 2020-02-07 16:15:31 --> URI Class Initialized
INFO - 2020-02-07 16:15:31 --> Router Class Initialized
INFO - 2020-02-07 16:15:31 --> Router Class Initialized
INFO - 2020-02-07 16:15:31 --> Router Class Initialized
INFO - 2020-02-07 16:15:31 --> Output Class Initialized
INFO - 2020-02-07 16:15:31 --> Output Class Initialized
INFO - 2020-02-07 16:15:31 --> Output Class Initialized
INFO - 2020-02-07 16:15:31 --> Security Class Initialized
INFO - 2020-02-07 16:15:31 --> Security Class Initialized
INFO - 2020-02-07 16:15:31 --> Security Class Initialized
DEBUG - 2020-02-07 16:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:15:31 --> Input Class Initialized
INFO - 2020-02-07 16:15:31 --> Input Class Initialized
INFO - 2020-02-07 16:15:31 --> Input Class Initialized
INFO - 2020-02-07 16:15:31 --> Language Class Initialized
INFO - 2020-02-07 16:15:31 --> Language Class Initialized
INFO - 2020-02-07 16:15:31 --> Language Class Initialized
ERROR - 2020-02-07 16:15:31 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-07 16:15:31 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-07 16:15:31 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 16:15:35 --> Config Class Initialized
INFO - 2020-02-07 16:15:35 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:15:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:15:35 --> Utf8 Class Initialized
INFO - 2020-02-07 16:15:35 --> URI Class Initialized
INFO - 2020-02-07 16:15:35 --> Router Class Initialized
INFO - 2020-02-07 16:15:35 --> Output Class Initialized
INFO - 2020-02-07 16:15:35 --> Security Class Initialized
DEBUG - 2020-02-07 16:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:15:35 --> Input Class Initialized
INFO - 2020-02-07 16:15:35 --> Language Class Initialized
INFO - 2020-02-07 16:15:35 --> Loader Class Initialized
INFO - 2020-02-07 16:15:35 --> Helper loaded: url_helper
INFO - 2020-02-07 16:15:35 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:15:35 --> Controller Class Initialized
INFO - 2020-02-07 16:15:35 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:15:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:15:35 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:15:35 --> Helper loaded: form_helper
INFO - 2020-02-07 16:15:35 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:15:35 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
ERROR - 2020-02-07 16:15:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-07 16:15:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:15:35 --> Final output sent to browser
DEBUG - 2020-02-07 16:15:35 --> Total execution time: 0.7013
INFO - 2020-02-07 16:18:52 --> Config Class Initialized
INFO - 2020-02-07 16:18:52 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:18:53 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:53 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:53 --> URI Class Initialized
INFO - 2020-02-07 16:18:53 --> Router Class Initialized
INFO - 2020-02-07 16:18:53 --> Output Class Initialized
INFO - 2020-02-07 16:18:53 --> Security Class Initialized
DEBUG - 2020-02-07 16:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:53 --> Input Class Initialized
INFO - 2020-02-07 16:18:53 --> Language Class Initialized
INFO - 2020-02-07 16:18:53 --> Loader Class Initialized
INFO - 2020-02-07 16:18:53 --> Helper loaded: url_helper
INFO - 2020-02-07 16:18:53 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:18:53 --> Controller Class Initialized
INFO - 2020-02-07 16:18:53 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:18:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:18:53 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:18:53 --> Helper loaded: form_helper
INFO - 2020-02-07 16:18:53 --> Form Validation Class Initialized
INFO - 2020-02-07 16:18:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:18:53 --> Final output sent to browser
DEBUG - 2020-02-07 16:18:53 --> Total execution time: 0.6551
INFO - 2020-02-07 16:18:53 --> Config Class Initialized
INFO - 2020-02-07 16:18:53 --> Config Class Initialized
INFO - 2020-02-07 16:18:53 --> Hooks Class Initialized
INFO - 2020-02-07 16:18:53 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:18:53 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:53 --> Utf8 Class Initialized
DEBUG - 2020-02-07 16:18:53 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:53 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:53 --> URI Class Initialized
INFO - 2020-02-07 16:18:53 --> URI Class Initialized
INFO - 2020-02-07 16:18:53 --> Router Class Initialized
INFO - 2020-02-07 16:18:53 --> Router Class Initialized
INFO - 2020-02-07 16:18:53 --> Output Class Initialized
INFO - 2020-02-07 16:18:54 --> Output Class Initialized
INFO - 2020-02-07 16:18:54 --> Security Class Initialized
DEBUG - 2020-02-07 16:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:54 --> Security Class Initialized
INFO - 2020-02-07 16:18:54 --> Input Class Initialized
DEBUG - 2020-02-07 16:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:54 --> Input Class Initialized
INFO - 2020-02-07 16:18:54 --> Language Class Initialized
INFO - 2020-02-07 16:18:54 --> Language Class Initialized
INFO - 2020-02-07 16:18:54 --> Loader Class Initialized
INFO - 2020-02-07 16:18:54 --> Helper loaded: url_helper
INFO - 2020-02-07 16:18:54 --> Loader Class Initialized
INFO - 2020-02-07 16:18:54 --> Helper loaded: url_helper
INFO - 2020-02-07 16:18:54 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:18:54 --> Database Driver Class Initialized
INFO - 2020-02-07 16:18:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-07 16:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:18:54 --> Controller Class Initialized
INFO - 2020-02-07 16:18:54 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:18:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:18:54 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:18:54 --> Helper loaded: form_helper
INFO - 2020-02-07 16:18:54 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:18:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 16:18:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 16:18:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:18:54 --> Final output sent to browser
DEBUG - 2020-02-07 16:18:54 --> Total execution time: 0.8415
INFO - 2020-02-07 16:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:18:54 --> Controller Class Initialized
INFO - 2020-02-07 16:18:54 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:18:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:18:54 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:18:54 --> Helper loaded: form_helper
INFO - 2020-02-07 16:18:54 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:18:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 16:18:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 16:18:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:18:54 --> Final output sent to browser
DEBUG - 2020-02-07 16:18:54 --> Total execution time: 1.1105
INFO - 2020-02-07 16:18:56 --> Config Class Initialized
INFO - 2020-02-07 16:18:56 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:18:56 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:56 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:56 --> URI Class Initialized
INFO - 2020-02-07 16:18:57 --> Router Class Initialized
INFO - 2020-02-07 16:18:57 --> Output Class Initialized
INFO - 2020-02-07 16:18:57 --> Security Class Initialized
DEBUG - 2020-02-07 16:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:57 --> Input Class Initialized
INFO - 2020-02-07 16:18:57 --> Language Class Initialized
INFO - 2020-02-07 16:18:57 --> Loader Class Initialized
INFO - 2020-02-07 16:18:57 --> Helper loaded: url_helper
INFO - 2020-02-07 16:18:57 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:18:57 --> Controller Class Initialized
INFO - 2020-02-07 16:18:57 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:18:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:18:57 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:18:57 --> Helper loaded: form_helper
INFO - 2020-02-07 16:18:57 --> Form Validation Class Initialized
INFO - 2020-02-07 16:18:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:18:57 --> Final output sent to browser
INFO - 2020-02-07 16:18:57 --> Config Class Initialized
INFO - 2020-02-07 16:18:57 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:18:57 --> Total execution time: 0.5574
INFO - 2020-02-07 16:18:57 --> Config Class Initialized
INFO - 2020-02-07 16:18:57 --> Config Class Initialized
INFO - 2020-02-07 16:18:57 --> Config Class Initialized
INFO - 2020-02-07 16:18:57 --> Config Class Initialized
INFO - 2020-02-07 16:18:57 --> Hooks Class Initialized
INFO - 2020-02-07 16:18:57 --> Hooks Class Initialized
INFO - 2020-02-07 16:18:57 --> Hooks Class Initialized
INFO - 2020-02-07 16:18:57 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:18:57 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:57 --> Config Class Initialized
INFO - 2020-02-07 16:18:57 --> Utf8 Class Initialized
DEBUG - 2020-02-07 16:18:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:18:57 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:57 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:18:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:18:57 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:57 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:57 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:57 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:57 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:57 --> URI Class Initialized
DEBUG - 2020-02-07 16:18:57 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:57 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:57 --> URI Class Initialized
INFO - 2020-02-07 16:18:57 --> URI Class Initialized
INFO - 2020-02-07 16:18:57 --> Router Class Initialized
INFO - 2020-02-07 16:18:57 --> URI Class Initialized
INFO - 2020-02-07 16:18:57 --> URI Class Initialized
INFO - 2020-02-07 16:18:57 --> URI Class Initialized
INFO - 2020-02-07 16:18:57 --> Router Class Initialized
INFO - 2020-02-07 16:18:57 --> Output Class Initialized
INFO - 2020-02-07 16:18:57 --> Router Class Initialized
INFO - 2020-02-07 16:18:57 --> Router Class Initialized
INFO - 2020-02-07 16:18:57 --> Router Class Initialized
INFO - 2020-02-07 16:18:57 --> Output Class Initialized
INFO - 2020-02-07 16:18:57 --> Output Class Initialized
INFO - 2020-02-07 16:18:57 --> Output Class Initialized
INFO - 2020-02-07 16:18:57 --> Output Class Initialized
INFO - 2020-02-07 16:18:57 --> Security Class Initialized
INFO - 2020-02-07 16:18:57 --> Router Class Initialized
DEBUG - 2020-02-07 16:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:57 --> Security Class Initialized
INFO - 2020-02-07 16:18:57 --> Security Class Initialized
INFO - 2020-02-07 16:18:57 --> Security Class Initialized
INFO - 2020-02-07 16:18:57 --> Security Class Initialized
INFO - 2020-02-07 16:18:57 --> Output Class Initialized
INFO - 2020-02-07 16:18:57 --> Input Class Initialized
INFO - 2020-02-07 16:18:57 --> Security Class Initialized
DEBUG - 2020-02-07 16:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:57 --> Input Class Initialized
INFO - 2020-02-07 16:18:57 --> Input Class Initialized
INFO - 2020-02-07 16:18:57 --> Input Class Initialized
INFO - 2020-02-07 16:18:57 --> Input Class Initialized
INFO - 2020-02-07 16:18:57 --> Language Class Initialized
DEBUG - 2020-02-07 16:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:57 --> Input Class Initialized
INFO - 2020-02-07 16:18:57 --> Language Class Initialized
INFO - 2020-02-07 16:18:57 --> Language Class Initialized
INFO - 2020-02-07 16:18:57 --> Language Class Initialized
INFO - 2020-02-07 16:18:57 --> Language Class Initialized
INFO - 2020-02-07 16:18:57 --> Loader Class Initialized
INFO - 2020-02-07 16:18:57 --> Language Class Initialized
ERROR - 2020-02-07 16:18:57 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 16:18:57 --> Helper loaded: url_helper
ERROR - 2020-02-07 16:18:57 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 16:18:57 --> Loader Class Initialized
ERROR - 2020-02-07 16:18:57 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-07 16:18:57 --> Helper loaded: url_helper
ERROR - 2020-02-07 16:18:57 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 16:18:57 --> Database Driver Class Initialized
INFO - 2020-02-07 16:18:57 --> Config Class Initialized
INFO - 2020-02-07 16:18:57 --> Config Class Initialized
INFO - 2020-02-07 16:18:57 --> Config Class Initialized
INFO - 2020-02-07 16:18:57 --> Hooks Class Initialized
INFO - 2020-02-07 16:18:57 --> Hooks Class Initialized
INFO - 2020-02-07 16:18:57 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:18:57 --> Database Driver Class Initialized
INFO - 2020-02-07 16:18:57 --> Config Class Initialized
INFO - 2020-02-07 16:18:57 --> Hooks Class Initialized
INFO - 2020-02-07 16:18:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-07 16:18:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:18:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:18:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:18:57 --> Controller Class Initialized
INFO - 2020-02-07 16:18:57 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:57 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:57 --> Utf8 Class Initialized
DEBUG - 2020-02-07 16:18:57 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:57 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:57 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:18:57 --> URI Class Initialized
INFO - 2020-02-07 16:18:57 --> URI Class Initialized
INFO - 2020-02-07 16:18:57 --> URI Class Initialized
INFO - 2020-02-07 16:18:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:18:58 --> URI Class Initialized
INFO - 2020-02-07 16:18:58 --> Router Class Initialized
INFO - 2020-02-07 16:18:58 --> Router Class Initialized
INFO - 2020-02-07 16:18:58 --> Router Class Initialized
INFO - 2020-02-07 16:18:58 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:18:58 --> Output Class Initialized
INFO - 2020-02-07 16:18:58 --> Output Class Initialized
INFO - 2020-02-07 16:18:58 --> Router Class Initialized
INFO - 2020-02-07 16:18:58 --> Output Class Initialized
INFO - 2020-02-07 16:18:58 --> Security Class Initialized
INFO - 2020-02-07 16:18:58 --> Security Class Initialized
INFO - 2020-02-07 16:18:58 --> Output Class Initialized
INFO - 2020-02-07 16:18:58 --> Security Class Initialized
INFO - 2020-02-07 16:18:58 --> Helper loaded: form_helper
INFO - 2020-02-07 16:18:58 --> Form Validation Class Initialized
INFO - 2020-02-07 16:18:58 --> Security Class Initialized
DEBUG - 2020-02-07 16:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:58 --> Input Class Initialized
INFO - 2020-02-07 16:18:58 --> Input Class Initialized
INFO - 2020-02-07 16:18:58 --> Input Class Initialized
DEBUG - 2020-02-07 16:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-07 16:18:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 16:18:58 --> Language Class Initialized
INFO - 2020-02-07 16:18:58 --> Language Class Initialized
INFO - 2020-02-07 16:18:58 --> Input Class Initialized
INFO - 2020-02-07 16:18:58 --> Language Class Initialized
ERROR - 2020-02-07 16:18:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 16:18:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:18:58 --> Language Class Initialized
ERROR - 2020-02-07 16:18:58 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 16:18:58 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 16:18:58 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-07 16:18:58 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 16:18:58 --> Final output sent to browser
INFO - 2020-02-07 16:18:58 --> Config Class Initialized
INFO - 2020-02-07 16:18:58 --> Config Class Initialized
INFO - 2020-02-07 16:18:58 --> Config Class Initialized
INFO - 2020-02-07 16:18:58 --> Hooks Class Initialized
INFO - 2020-02-07 16:18:58 --> Hooks Class Initialized
INFO - 2020-02-07 16:18:58 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:18:58 --> Total execution time: 0.7226
INFO - 2020-02-07 16:18:58 --> Config Class Initialized
INFO - 2020-02-07 16:18:58 --> Hooks Class Initialized
INFO - 2020-02-07 16:18:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-07 16:18:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:18:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:18:58 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:58 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:58 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:58 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:58 --> Controller Class Initialized
DEBUG - 2020-02-07 16:18:58 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:58 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:58 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:18:58 --> URI Class Initialized
INFO - 2020-02-07 16:18:58 --> URI Class Initialized
INFO - 2020-02-07 16:18:58 --> URI Class Initialized
INFO - 2020-02-07 16:18:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:18:58 --> URI Class Initialized
INFO - 2020-02-07 16:18:58 --> Router Class Initialized
INFO - 2020-02-07 16:18:58 --> Router Class Initialized
INFO - 2020-02-07 16:18:58 --> Router Class Initialized
INFO - 2020-02-07 16:18:58 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:18:58 --> Router Class Initialized
INFO - 2020-02-07 16:18:58 --> Output Class Initialized
INFO - 2020-02-07 16:18:58 --> Output Class Initialized
INFO - 2020-02-07 16:18:58 --> Output Class Initialized
INFO - 2020-02-07 16:18:58 --> Security Class Initialized
INFO - 2020-02-07 16:18:58 --> Output Class Initialized
INFO - 2020-02-07 16:18:58 --> Security Class Initialized
INFO - 2020-02-07 16:18:58 --> Security Class Initialized
INFO - 2020-02-07 16:18:58 --> Helper loaded: form_helper
INFO - 2020-02-07 16:18:58 --> Form Validation Class Initialized
DEBUG - 2020-02-07 16:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:58 --> Security Class Initialized
DEBUG - 2020-02-07 16:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:58 --> Input Class Initialized
INFO - 2020-02-07 16:18:58 --> Input Class Initialized
INFO - 2020-02-07 16:18:58 --> Input Class Initialized
DEBUG - 2020-02-07 16:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-07 16:18:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 16:18:58 --> Input Class Initialized
ERROR - 2020-02-07 16:18:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 16:18:58 --> Language Class Initialized
INFO - 2020-02-07 16:18:58 --> Language Class Initialized
INFO - 2020-02-07 16:18:58 --> Language Class Initialized
INFO - 2020-02-07 16:18:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 16:18:58 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-07 16:18:58 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 16:18:58 --> Language Class Initialized
ERROR - 2020-02-07 16:18:58 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 16:18:58 --> Final output sent to browser
ERROR - 2020-02-07 16:18:58 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-07 16:18:58 --> Total execution time: 1.0571
INFO - 2020-02-07 16:18:58 --> Config Class Initialized
INFO - 2020-02-07 16:18:58 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:18:58 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:58 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:58 --> URI Class Initialized
INFO - 2020-02-07 16:18:58 --> Router Class Initialized
INFO - 2020-02-07 16:18:58 --> Output Class Initialized
INFO - 2020-02-07 16:18:58 --> Security Class Initialized
DEBUG - 2020-02-07 16:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:58 --> Input Class Initialized
INFO - 2020-02-07 16:18:58 --> Language Class Initialized
ERROR - 2020-02-07 16:18:58 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 16:18:58 --> Config Class Initialized
INFO - 2020-02-07 16:18:58 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:18:58 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:58 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:59 --> URI Class Initialized
INFO - 2020-02-07 16:18:59 --> Router Class Initialized
INFO - 2020-02-07 16:18:59 --> Output Class Initialized
INFO - 2020-02-07 16:18:59 --> Security Class Initialized
DEBUG - 2020-02-07 16:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:59 --> Input Class Initialized
INFO - 2020-02-07 16:18:59 --> Language Class Initialized
ERROR - 2020-02-07 16:18:59 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 16:18:59 --> Config Class Initialized
INFO - 2020-02-07 16:18:59 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:18:59 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:59 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:59 --> URI Class Initialized
INFO - 2020-02-07 16:18:59 --> Router Class Initialized
INFO - 2020-02-07 16:18:59 --> Output Class Initialized
INFO - 2020-02-07 16:18:59 --> Security Class Initialized
DEBUG - 2020-02-07 16:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:59 --> Input Class Initialized
INFO - 2020-02-07 16:18:59 --> Language Class Initialized
ERROR - 2020-02-07 16:18:59 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 16:18:59 --> Config Class Initialized
INFO - 2020-02-07 16:18:59 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:18:59 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:59 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:59 --> URI Class Initialized
INFO - 2020-02-07 16:18:59 --> Router Class Initialized
INFO - 2020-02-07 16:18:59 --> Output Class Initialized
INFO - 2020-02-07 16:18:59 --> Security Class Initialized
DEBUG - 2020-02-07 16:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:18:59 --> Input Class Initialized
INFO - 2020-02-07 16:18:59 --> Language Class Initialized
ERROR - 2020-02-07 16:18:59 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:18:59 --> Config Class Initialized
INFO - 2020-02-07 16:18:59 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:18:59 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:18:59 --> Utf8 Class Initialized
INFO - 2020-02-07 16:18:59 --> URI Class Initialized
INFO - 2020-02-07 16:18:59 --> Router Class Initialized
INFO - 2020-02-07 16:18:59 --> Output Class Initialized
INFO - 2020-02-07 16:18:59 --> Security Class Initialized
DEBUG - 2020-02-07 16:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:19:00 --> Input Class Initialized
INFO - 2020-02-07 16:19:00 --> Language Class Initialized
ERROR - 2020-02-07 16:19:00 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:19:00 --> Config Class Initialized
INFO - 2020-02-07 16:19:00 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:19:00 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:19:00 --> Utf8 Class Initialized
INFO - 2020-02-07 16:19:00 --> URI Class Initialized
INFO - 2020-02-07 16:19:00 --> Router Class Initialized
INFO - 2020-02-07 16:19:00 --> Output Class Initialized
INFO - 2020-02-07 16:19:00 --> Security Class Initialized
DEBUG - 2020-02-07 16:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:19:00 --> Input Class Initialized
INFO - 2020-02-07 16:19:00 --> Language Class Initialized
ERROR - 2020-02-07 16:19:00 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 16:19:00 --> Config Class Initialized
INFO - 2020-02-07 16:19:00 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:19:00 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:19:00 --> Utf8 Class Initialized
INFO - 2020-02-07 16:19:00 --> URI Class Initialized
INFO - 2020-02-07 16:19:00 --> Router Class Initialized
INFO - 2020-02-07 16:19:00 --> Output Class Initialized
INFO - 2020-02-07 16:19:00 --> Security Class Initialized
DEBUG - 2020-02-07 16:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:19:00 --> Input Class Initialized
INFO - 2020-02-07 16:19:00 --> Language Class Initialized
ERROR - 2020-02-07 16:19:00 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 16:19:00 --> Config Class Initialized
INFO - 2020-02-07 16:19:00 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:19:00 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:19:00 --> Utf8 Class Initialized
INFO - 2020-02-07 16:19:00 --> URI Class Initialized
INFO - 2020-02-07 16:19:00 --> Router Class Initialized
INFO - 2020-02-07 16:19:00 --> Output Class Initialized
INFO - 2020-02-07 16:19:00 --> Security Class Initialized
DEBUG - 2020-02-07 16:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:19:00 --> Input Class Initialized
INFO - 2020-02-07 16:19:00 --> Language Class Initialized
ERROR - 2020-02-07 16:19:01 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 16:19:01 --> Config Class Initialized
INFO - 2020-02-07 16:19:01 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:19:01 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:19:01 --> Utf8 Class Initialized
INFO - 2020-02-07 16:19:01 --> URI Class Initialized
INFO - 2020-02-07 16:19:01 --> Router Class Initialized
INFO - 2020-02-07 16:19:01 --> Output Class Initialized
INFO - 2020-02-07 16:19:01 --> Security Class Initialized
DEBUG - 2020-02-07 16:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:19:01 --> Input Class Initialized
INFO - 2020-02-07 16:19:01 --> Language Class Initialized
ERROR - 2020-02-07 16:19:01 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 16:19:39 --> Config Class Initialized
INFO - 2020-02-07 16:19:39 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:19:39 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:19:39 --> Utf8 Class Initialized
INFO - 2020-02-07 16:19:39 --> URI Class Initialized
INFO - 2020-02-07 16:19:39 --> Router Class Initialized
INFO - 2020-02-07 16:19:39 --> Output Class Initialized
INFO - 2020-02-07 16:19:39 --> Security Class Initialized
DEBUG - 2020-02-07 16:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:19:39 --> Input Class Initialized
INFO - 2020-02-07 16:19:39 --> Language Class Initialized
INFO - 2020-02-07 16:19:39 --> Loader Class Initialized
INFO - 2020-02-07 16:19:39 --> Helper loaded: url_helper
INFO - 2020-02-07 16:19:39 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:19:39 --> Controller Class Initialized
INFO - 2020-02-07 16:19:39 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:19:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:19:40 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:19:40 --> Helper loaded: form_helper
INFO - 2020-02-07 16:19:40 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:19:40 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
ERROR - 2020-02-07 16:19:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-07 16:19:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:19:40 --> Final output sent to browser
DEBUG - 2020-02-07 16:19:40 --> Total execution time: 0.8264
INFO - 2020-02-07 16:20:58 --> Config Class Initialized
INFO - 2020-02-07 16:20:58 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:20:58 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:20:58 --> Utf8 Class Initialized
INFO - 2020-02-07 16:20:58 --> URI Class Initialized
INFO - 2020-02-07 16:20:58 --> Router Class Initialized
INFO - 2020-02-07 16:20:58 --> Output Class Initialized
INFO - 2020-02-07 16:20:58 --> Security Class Initialized
DEBUG - 2020-02-07 16:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:20:58 --> Input Class Initialized
INFO - 2020-02-07 16:20:58 --> Language Class Initialized
INFO - 2020-02-07 16:20:58 --> Loader Class Initialized
INFO - 2020-02-07 16:20:58 --> Helper loaded: url_helper
INFO - 2020-02-07 16:20:58 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:20:58 --> Controller Class Initialized
INFO - 2020-02-07 16:20:58 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:20:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:20:58 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:20:58 --> Helper loaded: form_helper
INFO - 2020-02-07 16:20:58 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:20:59 --> Severity: Notice --> Undefined index: bank C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-07 16:20:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-07 16:20:59 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:20:59 --> Final output sent to browser
DEBUG - 2020-02-07 16:20:59 --> Total execution time: 0.8040
INFO - 2020-02-07 16:22:22 --> Config Class Initialized
INFO - 2020-02-07 16:22:22 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:22 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:22 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:22 --> URI Class Initialized
INFO - 2020-02-07 16:22:22 --> Router Class Initialized
INFO - 2020-02-07 16:22:22 --> Output Class Initialized
INFO - 2020-02-07 16:22:22 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:22 --> Input Class Initialized
INFO - 2020-02-07 16:22:22 --> Language Class Initialized
INFO - 2020-02-07 16:22:22 --> Loader Class Initialized
INFO - 2020-02-07 16:22:22 --> Helper loaded: url_helper
INFO - 2020-02-07 16:22:22 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:22:22 --> Controller Class Initialized
INFO - 2020-02-07 16:22:22 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:22:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:22:22 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:22:22 --> Helper loaded: form_helper
INFO - 2020-02-07 16:22:22 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:22:22 --> Severity: Notice --> Undefined index: bank C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-07 16:22:22 --> Severity: Notice --> Undefined variable: toket C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
ERROR - 2020-02-07 16:22:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-07 16:22:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:22:22 --> Final output sent to browser
DEBUG - 2020-02-07 16:22:22 --> Total execution time: 0.7209
INFO - 2020-02-07 16:22:27 --> Config Class Initialized
INFO - 2020-02-07 16:22:27 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:27 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:27 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:27 --> URI Class Initialized
INFO - 2020-02-07 16:22:27 --> Router Class Initialized
INFO - 2020-02-07 16:22:27 --> Output Class Initialized
INFO - 2020-02-07 16:22:27 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:27 --> Input Class Initialized
INFO - 2020-02-07 16:22:28 --> Language Class Initialized
INFO - 2020-02-07 16:22:28 --> Loader Class Initialized
INFO - 2020-02-07 16:22:28 --> Helper loaded: url_helper
INFO - 2020-02-07 16:22:28 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:22:28 --> Controller Class Initialized
INFO - 2020-02-07 16:22:28 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:22:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:22:28 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:22:28 --> Helper loaded: form_helper
INFO - 2020-02-07 16:22:28 --> Form Validation Class Initialized
INFO - 2020-02-07 16:22:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:22:28 --> Final output sent to browser
DEBUG - 2020-02-07 16:22:28 --> Total execution time: 0.6116
INFO - 2020-02-07 16:22:28 --> Config Class Initialized
INFO - 2020-02-07 16:22:28 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:28 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:28 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:28 --> URI Class Initialized
INFO - 2020-02-07 16:22:28 --> Router Class Initialized
INFO - 2020-02-07 16:22:28 --> Output Class Initialized
INFO - 2020-02-07 16:22:28 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:28 --> Input Class Initialized
INFO - 2020-02-07 16:22:28 --> Language Class Initialized
ERROR - 2020-02-07 16:22:28 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-07 16:22:41 --> Config Class Initialized
INFO - 2020-02-07 16:22:41 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:41 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:41 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:41 --> URI Class Initialized
INFO - 2020-02-07 16:22:41 --> Router Class Initialized
INFO - 2020-02-07 16:22:41 --> Output Class Initialized
INFO - 2020-02-07 16:22:41 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:41 --> Input Class Initialized
INFO - 2020-02-07 16:22:41 --> Language Class Initialized
INFO - 2020-02-07 16:22:41 --> Loader Class Initialized
INFO - 2020-02-07 16:22:41 --> Helper loaded: url_helper
INFO - 2020-02-07 16:22:41 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:22:41 --> Controller Class Initialized
INFO - 2020-02-07 16:22:41 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:22:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:22:41 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:22:41 --> Helper loaded: form_helper
INFO - 2020-02-07 16:22:41 --> Form Validation Class Initialized
INFO - 2020-02-07 16:22:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:22:41 --> Final output sent to browser
INFO - 2020-02-07 16:22:41 --> Config Class Initialized
INFO - 2020-02-07 16:22:41 --> Config Class Initialized
INFO - 2020-02-07 16:22:41 --> Config Class Initialized
INFO - 2020-02-07 16:22:41 --> Config Class Initialized
INFO - 2020-02-07 16:22:41 --> Hooks Class Initialized
INFO - 2020-02-07 16:22:41 --> Hooks Class Initialized
INFO - 2020-02-07 16:22:41 --> Hooks Class Initialized
INFO - 2020-02-07 16:22:41 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:41 --> Total execution time: 0.5756
INFO - 2020-02-07 16:22:41 --> Config Class Initialized
INFO - 2020-02-07 16:22:41 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:22:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:22:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:22:41 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:41 --> Config Class Initialized
INFO - 2020-02-07 16:22:41 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:41 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:41 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:41 --> Utf8 Class Initialized
DEBUG - 2020-02-07 16:22:41 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:41 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:41 --> Hooks Class Initialized
INFO - 2020-02-07 16:22:41 --> URI Class Initialized
INFO - 2020-02-07 16:22:41 --> URI Class Initialized
INFO - 2020-02-07 16:22:41 --> URI Class Initialized
INFO - 2020-02-07 16:22:41 --> URI Class Initialized
INFO - 2020-02-07 16:22:41 --> Router Class Initialized
INFO - 2020-02-07 16:22:41 --> URI Class Initialized
INFO - 2020-02-07 16:22:41 --> Router Class Initialized
INFO - 2020-02-07 16:22:41 --> Router Class Initialized
DEBUG - 2020-02-07 16:22:41 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:41 --> Router Class Initialized
INFO - 2020-02-07 16:22:41 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:41 --> Output Class Initialized
INFO - 2020-02-07 16:22:41 --> Output Class Initialized
INFO - 2020-02-07 16:22:41 --> Output Class Initialized
INFO - 2020-02-07 16:22:41 --> Output Class Initialized
INFO - 2020-02-07 16:22:41 --> Router Class Initialized
INFO - 2020-02-07 16:22:41 --> URI Class Initialized
INFO - 2020-02-07 16:22:41 --> Security Class Initialized
INFO - 2020-02-07 16:22:41 --> Security Class Initialized
INFO - 2020-02-07 16:22:41 --> Security Class Initialized
INFO - 2020-02-07 16:22:41 --> Security Class Initialized
INFO - 2020-02-07 16:22:41 --> Output Class Initialized
DEBUG - 2020-02-07 16:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:41 --> Router Class Initialized
DEBUG - 2020-02-07 16:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:41 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
DEBUG - 2020-02-07 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:42 --> Output Class Initialized
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
INFO - 2020-02-07 16:22:42 --> Security Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
ERROR - 2020-02-07 16:22:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-07 16:22:42 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-07 16:22:42 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-07 16:22:42 --> 404 Page Not Found: Bower_components/jquery
DEBUG - 2020-02-07 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
ERROR - 2020-02-07 16:22:42 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 16:22:42 --> Config Class Initialized
INFO - 2020-02-07 16:22:42 --> Config Class Initialized
INFO - 2020-02-07 16:22:42 --> Config Class Initialized
INFO - 2020-02-07 16:22:42 --> Config Class Initialized
INFO - 2020-02-07 16:22:42 --> Hooks Class Initialized
INFO - 2020-02-07 16:22:42 --> Hooks Class Initialized
INFO - 2020-02-07 16:22:42 --> Hooks Class Initialized
INFO - 2020-02-07 16:22:42 --> Hooks Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
INFO - 2020-02-07 16:22:42 --> Config Class Initialized
INFO - 2020-02-07 16:22:42 --> Hooks Class Initialized
ERROR - 2020-02-07 16:22:42 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-07 16:22:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:22:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:22:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:22:42 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:42 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:42 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:42 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:42 --> Utf8 Class Initialized
DEBUG - 2020-02-07 16:22:42 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:42 --> Config Class Initialized
INFO - 2020-02-07 16:22:42 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:42 --> Hooks Class Initialized
INFO - 2020-02-07 16:22:42 --> URI Class Initialized
INFO - 2020-02-07 16:22:42 --> URI Class Initialized
INFO - 2020-02-07 16:22:42 --> URI Class Initialized
INFO - 2020-02-07 16:22:42 --> URI Class Initialized
INFO - 2020-02-07 16:22:42 --> Router Class Initialized
INFO - 2020-02-07 16:22:42 --> Router Class Initialized
INFO - 2020-02-07 16:22:42 --> Router Class Initialized
DEBUG - 2020-02-07 16:22:42 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:42 --> URI Class Initialized
INFO - 2020-02-07 16:22:42 --> Router Class Initialized
INFO - 2020-02-07 16:22:42 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:42 --> Output Class Initialized
INFO - 2020-02-07 16:22:42 --> Output Class Initialized
INFO - 2020-02-07 16:22:42 --> Output Class Initialized
INFO - 2020-02-07 16:22:42 --> Output Class Initialized
INFO - 2020-02-07 16:22:42 --> Router Class Initialized
INFO - 2020-02-07 16:22:42 --> URI Class Initialized
INFO - 2020-02-07 16:22:42 --> Security Class Initialized
INFO - 2020-02-07 16:22:42 --> Security Class Initialized
INFO - 2020-02-07 16:22:42 --> Security Class Initialized
INFO - 2020-02-07 16:22:42 --> Security Class Initialized
INFO - 2020-02-07 16:22:42 --> Output Class Initialized
DEBUG - 2020-02-07 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:42 --> Router Class Initialized
DEBUG - 2020-02-07 16:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:42 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
DEBUG - 2020-02-07 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:42 --> Output Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
INFO - 2020-02-07 16:22:42 --> Security Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
ERROR - 2020-02-07 16:22:42 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-07 16:22:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:22:42 --> Loader Class Initialized
DEBUG - 2020-02-07 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:42 --> Loader Class Initialized
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
ERROR - 2020-02-07 16:22:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 16:22:42 --> Helper loaded: url_helper
INFO - 2020-02-07 16:22:42 --> Helper loaded: url_helper
INFO - 2020-02-07 16:22:42 --> Config Class Initialized
INFO - 2020-02-07 16:22:42 --> Config Class Initialized
INFO - 2020-02-07 16:22:42 --> Hooks Class Initialized
INFO - 2020-02-07 16:22:42 --> Hooks Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
INFO - 2020-02-07 16:22:42 --> Database Driver Class Initialized
INFO - 2020-02-07 16:22:42 --> Database Driver Class Initialized
ERROR - 2020-02-07 16:22:42 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-07 16:22:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:22:42 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-07 16:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:22:42 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:42 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:22:42 --> Controller Class Initialized
INFO - 2020-02-07 16:22:42 --> URI Class Initialized
INFO - 2020-02-07 16:22:42 --> URI Class Initialized
INFO - 2020-02-07 16:22:42 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:22:42 --> Router Class Initialized
INFO - 2020-02-07 16:22:42 --> Router Class Initialized
INFO - 2020-02-07 16:22:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:22:42 --> Output Class Initialized
INFO - 2020-02-07 16:22:42 --> Output Class Initialized
INFO - 2020-02-07 16:22:42 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:22:42 --> Security Class Initialized
INFO - 2020-02-07 16:22:42 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:42 --> Helper loaded: form_helper
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
INFO - 2020-02-07 16:22:42 --> Form Validation Class Initialized
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
INFO - 2020-02-07 16:22:42 --> Language Class Initialized
ERROR - 2020-02-07 16:22:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 16:22:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 16:22:42 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-07 16:22:42 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 16:22:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:22:42 --> Config Class Initialized
INFO - 2020-02-07 16:22:42 --> Hooks Class Initialized
INFO - 2020-02-07 16:22:42 --> Final output sent to browser
DEBUG - 2020-02-07 16:22:42 --> Total execution time: 0.6879
DEBUG - 2020-02-07 16:22:42 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:42 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:22:42 --> Controller Class Initialized
INFO - 2020-02-07 16:22:42 --> URI Class Initialized
INFO - 2020-02-07 16:22:42 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:22:42 --> Router Class Initialized
INFO - 2020-02-07 16:22:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:22:42 --> Output Class Initialized
INFO - 2020-02-07 16:22:42 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:22:42 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:42 --> Helper loaded: form_helper
INFO - 2020-02-07 16:22:42 --> Input Class Initialized
INFO - 2020-02-07 16:22:42 --> Form Validation Class Initialized
INFO - 2020-02-07 16:22:43 --> Language Class Initialized
ERROR - 2020-02-07 16:22:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 16:22:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 16:22:43 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 16:22:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:22:43 --> Config Class Initialized
INFO - 2020-02-07 16:22:43 --> Hooks Class Initialized
INFO - 2020-02-07 16:22:43 --> Final output sent to browser
DEBUG - 2020-02-07 16:22:43 --> Total execution time: 0.9722
DEBUG - 2020-02-07 16:22:43 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:43 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:43 --> URI Class Initialized
INFO - 2020-02-07 16:22:43 --> Router Class Initialized
INFO - 2020-02-07 16:22:43 --> Output Class Initialized
INFO - 2020-02-07 16:22:43 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:43 --> Input Class Initialized
INFO - 2020-02-07 16:22:43 --> Language Class Initialized
ERROR - 2020-02-07 16:22:43 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 16:22:43 --> Config Class Initialized
INFO - 2020-02-07 16:22:43 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:43 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:43 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:43 --> URI Class Initialized
INFO - 2020-02-07 16:22:43 --> Router Class Initialized
INFO - 2020-02-07 16:22:43 --> Output Class Initialized
INFO - 2020-02-07 16:22:43 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:43 --> Input Class Initialized
INFO - 2020-02-07 16:22:43 --> Language Class Initialized
ERROR - 2020-02-07 16:22:43 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 16:22:43 --> Config Class Initialized
INFO - 2020-02-07 16:22:43 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:43 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:43 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:43 --> URI Class Initialized
INFO - 2020-02-07 16:22:43 --> Router Class Initialized
INFO - 2020-02-07 16:22:43 --> Output Class Initialized
INFO - 2020-02-07 16:22:43 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:43 --> Input Class Initialized
INFO - 2020-02-07 16:22:43 --> Language Class Initialized
ERROR - 2020-02-07 16:22:43 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:22:43 --> Config Class Initialized
INFO - 2020-02-07 16:22:44 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:44 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:44 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:44 --> URI Class Initialized
INFO - 2020-02-07 16:22:44 --> Router Class Initialized
INFO - 2020-02-07 16:22:44 --> Output Class Initialized
INFO - 2020-02-07 16:22:44 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:44 --> Input Class Initialized
INFO - 2020-02-07 16:22:44 --> Language Class Initialized
ERROR - 2020-02-07 16:22:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:22:44 --> Config Class Initialized
INFO - 2020-02-07 16:22:44 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:44 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:44 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:44 --> URI Class Initialized
INFO - 2020-02-07 16:22:44 --> Router Class Initialized
INFO - 2020-02-07 16:22:44 --> Output Class Initialized
INFO - 2020-02-07 16:22:44 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:44 --> Input Class Initialized
INFO - 2020-02-07 16:22:44 --> Language Class Initialized
ERROR - 2020-02-07 16:22:44 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 16:22:44 --> Config Class Initialized
INFO - 2020-02-07 16:22:44 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:44 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:44 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:44 --> URI Class Initialized
INFO - 2020-02-07 16:22:44 --> Router Class Initialized
INFO - 2020-02-07 16:22:44 --> Output Class Initialized
INFO - 2020-02-07 16:22:44 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:44 --> Input Class Initialized
INFO - 2020-02-07 16:22:44 --> Language Class Initialized
ERROR - 2020-02-07 16:22:44 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 16:22:44 --> Config Class Initialized
INFO - 2020-02-07 16:22:44 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:44 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:44 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:44 --> URI Class Initialized
INFO - 2020-02-07 16:22:45 --> Router Class Initialized
INFO - 2020-02-07 16:22:45 --> Output Class Initialized
INFO - 2020-02-07 16:22:45 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:45 --> Input Class Initialized
INFO - 2020-02-07 16:22:45 --> Language Class Initialized
ERROR - 2020-02-07 16:22:45 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 16:22:45 --> Config Class Initialized
INFO - 2020-02-07 16:22:45 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:45 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:45 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:45 --> URI Class Initialized
INFO - 2020-02-07 16:22:45 --> Router Class Initialized
INFO - 2020-02-07 16:22:45 --> Output Class Initialized
INFO - 2020-02-07 16:22:45 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:45 --> Input Class Initialized
INFO - 2020-02-07 16:22:45 --> Language Class Initialized
ERROR - 2020-02-07 16:22:45 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 16:22:59 --> Config Class Initialized
INFO - 2020-02-07 16:22:59 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:22:59 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:22:59 --> Utf8 Class Initialized
INFO - 2020-02-07 16:22:59 --> URI Class Initialized
INFO - 2020-02-07 16:22:59 --> Router Class Initialized
INFO - 2020-02-07 16:22:59 --> Output Class Initialized
INFO - 2020-02-07 16:22:59 --> Security Class Initialized
DEBUG - 2020-02-07 16:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:22:59 --> Input Class Initialized
INFO - 2020-02-07 16:22:59 --> Language Class Initialized
INFO - 2020-02-07 16:22:59 --> Loader Class Initialized
INFO - 2020-02-07 16:22:59 --> Helper loaded: url_helper
INFO - 2020-02-07 16:22:59 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:22:59 --> Controller Class Initialized
INFO - 2020-02-07 16:22:59 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:22:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:22:59 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:22:59 --> Helper loaded: form_helper
INFO - 2020-02-07 16:22:59 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:23:00 --> Severity: Notice --> Undefined index: bank C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-07 16:23:00 --> Severity: Notice --> Undefined variable: bank C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-07 16:23:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:23:00 --> Final output sent to browser
DEBUG - 2020-02-07 16:23:00 --> Total execution time: 0.8242
INFO - 2020-02-07 16:25:11 --> Config Class Initialized
INFO - 2020-02-07 16:25:11 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:25:11 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:25:11 --> Utf8 Class Initialized
INFO - 2020-02-07 16:25:11 --> URI Class Initialized
INFO - 2020-02-07 16:25:11 --> Router Class Initialized
INFO - 2020-02-07 16:25:11 --> Output Class Initialized
INFO - 2020-02-07 16:25:11 --> Security Class Initialized
DEBUG - 2020-02-07 16:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:25:11 --> Input Class Initialized
INFO - 2020-02-07 16:25:11 --> Language Class Initialized
INFO - 2020-02-07 16:25:11 --> Loader Class Initialized
INFO - 2020-02-07 16:25:11 --> Helper loaded: url_helper
INFO - 2020-02-07 16:25:11 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:25:11 --> Controller Class Initialized
INFO - 2020-02-07 16:25:11 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:25:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:25:11 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:25:11 --> Helper loaded: form_helper
INFO - 2020-02-07 16:25:11 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-07 16:25:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:25:12 --> Final output sent to browser
DEBUG - 2020-02-07 16:25:12 --> Total execution time: 0.7878
INFO - 2020-02-07 16:26:53 --> Config Class Initialized
INFO - 2020-02-07 16:26:53 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:26:53 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:26:53 --> Utf8 Class Initialized
INFO - 2020-02-07 16:26:53 --> URI Class Initialized
INFO - 2020-02-07 16:26:53 --> Router Class Initialized
INFO - 2020-02-07 16:26:53 --> Output Class Initialized
INFO - 2020-02-07 16:26:53 --> Security Class Initialized
DEBUG - 2020-02-07 16:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:26:53 --> Input Class Initialized
INFO - 2020-02-07 16:26:53 --> Language Class Initialized
INFO - 2020-02-07 16:26:53 --> Loader Class Initialized
INFO - 2020-02-07 16:26:53 --> Helper loaded: url_helper
INFO - 2020-02-07 16:26:53 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:26:53 --> Controller Class Initialized
INFO - 2020-02-07 16:26:53 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:26:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:26:53 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:26:53 --> Helper loaded: form_helper
INFO - 2020-02-07 16:26:53 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-07 16:26:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:26:54 --> Final output sent to browser
DEBUG - 2020-02-07 16:26:54 --> Total execution time: 0.7419
INFO - 2020-02-07 16:26:57 --> Config Class Initialized
INFO - 2020-02-07 16:26:57 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:26:57 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:26:57 --> Utf8 Class Initialized
INFO - 2020-02-07 16:26:57 --> URI Class Initialized
INFO - 2020-02-07 16:26:57 --> Router Class Initialized
INFO - 2020-02-07 16:26:57 --> Output Class Initialized
INFO - 2020-02-07 16:26:57 --> Security Class Initialized
DEBUG - 2020-02-07 16:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:26:57 --> Input Class Initialized
INFO - 2020-02-07 16:26:57 --> Language Class Initialized
INFO - 2020-02-07 16:26:58 --> Loader Class Initialized
INFO - 2020-02-07 16:26:58 --> Helper loaded: url_helper
INFO - 2020-02-07 16:26:58 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:26:58 --> Controller Class Initialized
INFO - 2020-02-07 16:26:58 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:26:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:26:58 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:26:58 --> Helper loaded: form_helper
INFO - 2020-02-07 16:26:58 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:26:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-07 16:26:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:26:58 --> Final output sent to browser
DEBUG - 2020-02-07 16:26:58 --> Total execution time: 0.7999
INFO - 2020-02-07 16:27:18 --> Config Class Initialized
INFO - 2020-02-07 16:27:18 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:18 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:18 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:18 --> URI Class Initialized
INFO - 2020-02-07 16:27:18 --> Router Class Initialized
INFO - 2020-02-07 16:27:18 --> Output Class Initialized
INFO - 2020-02-07 16:27:18 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:18 --> Input Class Initialized
INFO - 2020-02-07 16:27:18 --> Language Class Initialized
INFO - 2020-02-07 16:27:18 --> Loader Class Initialized
INFO - 2020-02-07 16:27:18 --> Helper loaded: url_helper
INFO - 2020-02-07 16:27:18 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:27:18 --> Controller Class Initialized
INFO - 2020-02-07 16:27:18 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:27:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:27:18 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:27:18 --> Helper loaded: form_helper
INFO - 2020-02-07 16:27:18 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:27:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-07 16:27:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:27:19 --> Final output sent to browser
DEBUG - 2020-02-07 16:27:19 --> Total execution time: 0.8046
INFO - 2020-02-07 16:27:22 --> Config Class Initialized
INFO - 2020-02-07 16:27:22 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:22 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:22 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:22 --> URI Class Initialized
INFO - 2020-02-07 16:27:22 --> Router Class Initialized
INFO - 2020-02-07 16:27:22 --> Output Class Initialized
INFO - 2020-02-07 16:27:22 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:22 --> Input Class Initialized
INFO - 2020-02-07 16:27:22 --> Language Class Initialized
INFO - 2020-02-07 16:27:22 --> Loader Class Initialized
INFO - 2020-02-07 16:27:22 --> Helper loaded: url_helper
INFO - 2020-02-07 16:27:22 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:27:23 --> Controller Class Initialized
INFO - 2020-02-07 16:27:23 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:27:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:27:23 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:27:23 --> Helper loaded: form_helper
INFO - 2020-02-07 16:27:23 --> Form Validation Class Initialized
INFO - 2020-02-07 16:27:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:27:23 --> Final output sent to browser
DEBUG - 2020-02-07 16:27:23 --> Total execution time: 0.8329
INFO - 2020-02-07 16:27:23 --> Config Class Initialized
INFO - 2020-02-07 16:27:23 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:23 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:23 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:23 --> URI Class Initialized
INFO - 2020-02-07 16:27:23 --> Router Class Initialized
INFO - 2020-02-07 16:27:23 --> Output Class Initialized
INFO - 2020-02-07 16:27:23 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:23 --> Input Class Initialized
INFO - 2020-02-07 16:27:23 --> Language Class Initialized
ERROR - 2020-02-07 16:27:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:27:25 --> Config Class Initialized
INFO - 2020-02-07 16:27:25 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:25 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:25 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:25 --> URI Class Initialized
INFO - 2020-02-07 16:27:25 --> Router Class Initialized
INFO - 2020-02-07 16:27:25 --> Output Class Initialized
INFO - 2020-02-07 16:27:25 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:25 --> Input Class Initialized
INFO - 2020-02-07 16:27:25 --> Language Class Initialized
INFO - 2020-02-07 16:27:25 --> Loader Class Initialized
INFO - 2020-02-07 16:27:25 --> Helper loaded: url_helper
INFO - 2020-02-07 16:27:25 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:27:25 --> Controller Class Initialized
INFO - 2020-02-07 16:27:25 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:27:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:27:25 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:27:25 --> Helper loaded: form_helper
INFO - 2020-02-07 16:27:25 --> Form Validation Class Initialized
INFO - 2020-02-07 16:27:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:27:25 --> Final output sent to browser
INFO - 2020-02-07 16:27:25 --> Config Class Initialized
INFO - 2020-02-07 16:27:25 --> Config Class Initialized
INFO - 2020-02-07 16:27:25 --> Config Class Initialized
INFO - 2020-02-07 16:27:25 --> Hooks Class Initialized
INFO - 2020-02-07 16:27:25 --> Hooks Class Initialized
INFO - 2020-02-07 16:27:25 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:25 --> Total execution time: 0.6155
INFO - 2020-02-07 16:27:25 --> Config Class Initialized
INFO - 2020-02-07 16:27:25 --> Config Class Initialized
INFO - 2020-02-07 16:27:25 --> Hooks Class Initialized
INFO - 2020-02-07 16:27:25 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:27:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:27:25 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:25 --> Config Class Initialized
INFO - 2020-02-07 16:27:25 --> Hooks Class Initialized
INFO - 2020-02-07 16:27:25 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:25 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:25 --> Utf8 Class Initialized
DEBUG - 2020-02-07 16:27:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:27:26 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:26 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
INFO - 2020-02-07 16:27:26 --> Utf8 Class Initialized
DEBUG - 2020-02-07 16:27:26 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
INFO - 2020-02-07 16:27:26 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
ERROR - 2020-02-07 16:27:26 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-07 16:27:26 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-07 16:27:26 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
ERROR - 2020-02-07 16:27:26 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-07 16:27:26 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-07 16:27:26 --> Config Class Initialized
INFO - 2020-02-07 16:27:26 --> Config Class Initialized
INFO - 2020-02-07 16:27:26 --> Config Class Initialized
INFO - 2020-02-07 16:27:26 --> Hooks Class Initialized
INFO - 2020-02-07 16:27:26 --> Hooks Class Initialized
INFO - 2020-02-07 16:27:26 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:27:26 --> UTF-8 Support Enabled
ERROR - 2020-02-07 16:27:26 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-07 16:27:26 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:26 --> Config Class Initialized
INFO - 2020-02-07 16:27:26 --> Config Class Initialized
INFO - 2020-02-07 16:27:26 --> Hooks Class Initialized
INFO - 2020-02-07 16:27:26 --> Hooks Class Initialized
INFO - 2020-02-07 16:27:26 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:26 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:26 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:26 --> Config Class Initialized
INFO - 2020-02-07 16:27:26 --> Hooks Class Initialized
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
DEBUG - 2020-02-07 16:27:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:27:26 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:26 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:26 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
DEBUG - 2020-02-07 16:27:26 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
INFO - 2020-02-07 16:27:26 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
ERROR - 2020-02-07 16:27:26 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-07 16:27:26 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:26 --> Loader Class Initialized
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
INFO - 2020-02-07 16:27:26 --> Helper loaded: url_helper
INFO - 2020-02-07 16:27:26 --> Config Class Initialized
INFO - 2020-02-07 16:27:26 --> Config Class Initialized
INFO - 2020-02-07 16:27:26 --> Hooks Class Initialized
INFO - 2020-02-07 16:27:26 --> Hooks Class Initialized
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
ERROR - 2020-02-07 16:27:26 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 16:27:26 --> Loader Class Initialized
INFO - 2020-02-07 16:27:26 --> Database Driver Class Initialized
ERROR - 2020-02-07 16:27:26 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 16:27:26 --> Helper loaded: url_helper
DEBUG - 2020-02-07 16:27:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:27:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:27:26 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:26 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:27:26 --> Database Driver Class Initialized
INFO - 2020-02-07 16:27:26 --> Controller Class Initialized
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
INFO - 2020-02-07 16:27:26 --> URI Class Initialized
DEBUG - 2020-02-07 16:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:27:26 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
INFO - 2020-02-07 16:27:26 --> Router Class Initialized
INFO - 2020-02-07 16:27:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
INFO - 2020-02-07 16:27:26 --> Output Class Initialized
INFO - 2020-02-07 16:27:26 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
INFO - 2020-02-07 16:27:26 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:26 --> Helper loaded: form_helper
INFO - 2020-02-07 16:27:26 --> Form Validation Class Initialized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
INFO - 2020-02-07 16:27:26 --> Input Class Initialized
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
INFO - 2020-02-07 16:27:26 --> Language Class Initialized
ERROR - 2020-02-07 16:27:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 16:27:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 16:27:26 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-07 16:27:26 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 16:27:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:27:26 --> Config Class Initialized
INFO - 2020-02-07 16:27:26 --> Hooks Class Initialized
INFO - 2020-02-07 16:27:26 --> Final output sent to browser
DEBUG - 2020-02-07 16:27:26 --> Total execution time: 0.6928
DEBUG - 2020-02-07 16:27:26 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:27 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:27:27 --> Controller Class Initialized
INFO - 2020-02-07 16:27:27 --> URI Class Initialized
INFO - 2020-02-07 16:27:27 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:27:27 --> Router Class Initialized
INFO - 2020-02-07 16:27:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:27:27 --> Output Class Initialized
INFO - 2020-02-07 16:27:27 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:27:27 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:27 --> Helper loaded: form_helper
INFO - 2020-02-07 16:27:27 --> Form Validation Class Initialized
INFO - 2020-02-07 16:27:27 --> Input Class Initialized
INFO - 2020-02-07 16:27:27 --> Language Class Initialized
ERROR - 2020-02-07 16:27:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-07 16:27:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-02-07 16:27:27 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 16:27:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:27:27 --> Config Class Initialized
INFO - 2020-02-07 16:27:27 --> Hooks Class Initialized
INFO - 2020-02-07 16:27:27 --> Final output sent to browser
DEBUG - 2020-02-07 16:27:27 --> Total execution time: 1.0502
DEBUG - 2020-02-07 16:27:27 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:27 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:27 --> URI Class Initialized
INFO - 2020-02-07 16:27:27 --> Router Class Initialized
INFO - 2020-02-07 16:27:27 --> Output Class Initialized
INFO - 2020-02-07 16:27:27 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:27 --> Input Class Initialized
INFO - 2020-02-07 16:27:27 --> Language Class Initialized
ERROR - 2020-02-07 16:27:27 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 16:27:27 --> Config Class Initialized
INFO - 2020-02-07 16:27:27 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:27 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:27 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:27 --> URI Class Initialized
INFO - 2020-02-07 16:27:27 --> Router Class Initialized
INFO - 2020-02-07 16:27:27 --> Output Class Initialized
INFO - 2020-02-07 16:27:27 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:27 --> Input Class Initialized
INFO - 2020-02-07 16:27:27 --> Language Class Initialized
ERROR - 2020-02-07 16:27:27 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 16:27:27 --> Config Class Initialized
INFO - 2020-02-07 16:27:28 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:28 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:28 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:28 --> URI Class Initialized
INFO - 2020-02-07 16:27:28 --> Router Class Initialized
INFO - 2020-02-07 16:27:28 --> Output Class Initialized
INFO - 2020-02-07 16:27:28 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:28 --> Input Class Initialized
INFO - 2020-02-07 16:27:28 --> Language Class Initialized
ERROR - 2020-02-07 16:27:28 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:27:28 --> Config Class Initialized
INFO - 2020-02-07 16:27:28 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:28 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:28 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:28 --> URI Class Initialized
INFO - 2020-02-07 16:27:28 --> Router Class Initialized
INFO - 2020-02-07 16:27:28 --> Output Class Initialized
INFO - 2020-02-07 16:27:28 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:28 --> Input Class Initialized
INFO - 2020-02-07 16:27:28 --> Language Class Initialized
ERROR - 2020-02-07 16:27:28 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:27:28 --> Config Class Initialized
INFO - 2020-02-07 16:27:28 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:28 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:28 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:28 --> URI Class Initialized
INFO - 2020-02-07 16:27:28 --> Router Class Initialized
INFO - 2020-02-07 16:27:28 --> Output Class Initialized
INFO - 2020-02-07 16:27:28 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:28 --> Input Class Initialized
INFO - 2020-02-07 16:27:28 --> Language Class Initialized
ERROR - 2020-02-07 16:27:28 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 16:27:28 --> Config Class Initialized
INFO - 2020-02-07 16:27:28 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:29 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:29 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:29 --> URI Class Initialized
INFO - 2020-02-07 16:27:29 --> Router Class Initialized
INFO - 2020-02-07 16:27:29 --> Output Class Initialized
INFO - 2020-02-07 16:27:29 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:29 --> Input Class Initialized
INFO - 2020-02-07 16:27:29 --> Language Class Initialized
ERROR - 2020-02-07 16:27:29 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 16:27:29 --> Config Class Initialized
INFO - 2020-02-07 16:27:29 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:29 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:29 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:29 --> URI Class Initialized
INFO - 2020-02-07 16:27:29 --> Router Class Initialized
INFO - 2020-02-07 16:27:29 --> Output Class Initialized
INFO - 2020-02-07 16:27:29 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:29 --> Input Class Initialized
INFO - 2020-02-07 16:27:29 --> Language Class Initialized
ERROR - 2020-02-07 16:27:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 16:27:29 --> Config Class Initialized
INFO - 2020-02-07 16:27:29 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:29 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:29 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:29 --> URI Class Initialized
INFO - 2020-02-07 16:27:29 --> Router Class Initialized
INFO - 2020-02-07 16:27:29 --> Output Class Initialized
INFO - 2020-02-07 16:27:29 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:29 --> Input Class Initialized
INFO - 2020-02-07 16:27:29 --> Language Class Initialized
ERROR - 2020-02-07 16:27:29 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 16:27:47 --> Config Class Initialized
INFO - 2020-02-07 16:27:47 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:27:47 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:27:47 --> Utf8 Class Initialized
INFO - 2020-02-07 16:27:47 --> URI Class Initialized
INFO - 2020-02-07 16:27:47 --> Router Class Initialized
INFO - 2020-02-07 16:27:47 --> Output Class Initialized
INFO - 2020-02-07 16:27:47 --> Security Class Initialized
DEBUG - 2020-02-07 16:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:27:47 --> Input Class Initialized
INFO - 2020-02-07 16:27:47 --> Language Class Initialized
INFO - 2020-02-07 16:27:47 --> Loader Class Initialized
INFO - 2020-02-07 16:27:47 --> Helper loaded: url_helper
INFO - 2020-02-07 16:27:47 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:27:47 --> Controller Class Initialized
INFO - 2020-02-07 16:27:47 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:27:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:27:47 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:27:47 --> Helper loaded: form_helper
INFO - 2020-02-07 16:27:47 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:27:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-07 16:27:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:27:48 --> Final output sent to browser
DEBUG - 2020-02-07 16:27:48 --> Total execution time: 0.7402
INFO - 2020-02-07 16:29:27 --> Config Class Initialized
INFO - 2020-02-07 16:29:27 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:27 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:27 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:27 --> URI Class Initialized
INFO - 2020-02-07 16:29:27 --> Router Class Initialized
INFO - 2020-02-07 16:29:27 --> Output Class Initialized
INFO - 2020-02-07 16:29:27 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:27 --> Input Class Initialized
INFO - 2020-02-07 16:29:27 --> Language Class Initialized
INFO - 2020-02-07 16:29:27 --> Loader Class Initialized
INFO - 2020-02-07 16:29:27 --> Helper loaded: url_helper
INFO - 2020-02-07 16:29:27 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:29:27 --> Controller Class Initialized
INFO - 2020-02-07 16:29:27 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:29:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:29:28 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:29:28 --> Helper loaded: form_helper
INFO - 2020-02-07 16:29:28 --> Form Validation Class Initialized
INFO - 2020-02-07 16:29:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:29:28 --> Final output sent to browser
DEBUG - 2020-02-07 16:29:28 --> Total execution time: 0.6416
INFO - 2020-02-07 16:29:34 --> Config Class Initialized
INFO - 2020-02-07 16:29:34 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:34 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:34 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:35 --> URI Class Initialized
INFO - 2020-02-07 16:29:35 --> Router Class Initialized
INFO - 2020-02-07 16:29:35 --> Output Class Initialized
INFO - 2020-02-07 16:29:35 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:35 --> Input Class Initialized
INFO - 2020-02-07 16:29:35 --> Language Class Initialized
INFO - 2020-02-07 16:29:35 --> Loader Class Initialized
INFO - 2020-02-07 16:29:35 --> Helper loaded: url_helper
INFO - 2020-02-07 16:29:35 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:29:35 --> Controller Class Initialized
INFO - 2020-02-07 16:29:35 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:29:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:29:35 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:29:35 --> Helper loaded: form_helper
INFO - 2020-02-07 16:29:35 --> Form Validation Class Initialized
INFO - 2020-02-07 16:29:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:29:35 --> Final output sent to browser
INFO - 2020-02-07 16:29:35 --> Config Class Initialized
INFO - 2020-02-07 16:29:35 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:35 --> Total execution time: 0.6166
INFO - 2020-02-07 16:29:35 --> Config Class Initialized
INFO - 2020-02-07 16:29:35 --> Config Class Initialized
INFO - 2020-02-07 16:29:35 --> Config Class Initialized
INFO - 2020-02-07 16:29:35 --> Config Class Initialized
INFO - 2020-02-07 16:29:35 --> Hooks Class Initialized
INFO - 2020-02-07 16:29:35 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:35 --> Hooks Class Initialized
INFO - 2020-02-07 16:29:35 --> Hooks Class Initialized
INFO - 2020-02-07 16:29:35 --> Config Class Initialized
INFO - 2020-02-07 16:29:35 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:35 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:29:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:29:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:29:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:35 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:35 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:35 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:35 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:35 --> URI Class Initialized
DEBUG - 2020-02-07 16:29:35 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:35 --> URI Class Initialized
INFO - 2020-02-07 16:29:35 --> URI Class Initialized
INFO - 2020-02-07 16:29:35 --> URI Class Initialized
INFO - 2020-02-07 16:29:35 --> Router Class Initialized
INFO - 2020-02-07 16:29:35 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:35 --> URI Class Initialized
INFO - 2020-02-07 16:29:35 --> URI Class Initialized
INFO - 2020-02-07 16:29:35 --> Output Class Initialized
INFO - 2020-02-07 16:29:35 --> Router Class Initialized
INFO - 2020-02-07 16:29:35 --> Router Class Initialized
INFO - 2020-02-07 16:29:35 --> Router Class Initialized
INFO - 2020-02-07 16:29:35 --> Router Class Initialized
INFO - 2020-02-07 16:29:35 --> Router Class Initialized
INFO - 2020-02-07 16:29:35 --> Security Class Initialized
INFO - 2020-02-07 16:29:35 --> Output Class Initialized
INFO - 2020-02-07 16:29:35 --> Output Class Initialized
INFO - 2020-02-07 16:29:35 --> Output Class Initialized
INFO - 2020-02-07 16:29:35 --> Output Class Initialized
DEBUG - 2020-02-07 16:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:35 --> Security Class Initialized
INFO - 2020-02-07 16:29:35 --> Output Class Initialized
INFO - 2020-02-07 16:29:35 --> Security Class Initialized
INFO - 2020-02-07 16:29:35 --> Security Class Initialized
INFO - 2020-02-07 16:29:35 --> Security Class Initialized
INFO - 2020-02-07 16:29:35 --> Input Class Initialized
DEBUG - 2020-02-07 16:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:35 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:35 --> Input Class Initialized
INFO - 2020-02-07 16:29:35 --> Input Class Initialized
INFO - 2020-02-07 16:29:35 --> Input Class Initialized
INFO - 2020-02-07 16:29:35 --> Input Class Initialized
INFO - 2020-02-07 16:29:35 --> Language Class Initialized
DEBUG - 2020-02-07 16:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:35 --> Language Class Initialized
INFO - 2020-02-07 16:29:35 --> Language Class Initialized
INFO - 2020-02-07 16:29:35 --> Language Class Initialized
INFO - 2020-02-07 16:29:35 --> Language Class Initialized
INFO - 2020-02-07 16:29:35 --> Input Class Initialized
INFO - 2020-02-07 16:29:35 --> Loader Class Initialized
ERROR - 2020-02-07 16:29:35 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-07 16:29:35 --> Helper loaded: url_helper
ERROR - 2020-02-07 16:29:35 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-07 16:29:35 --> Language Class Initialized
ERROR - 2020-02-07 16:29:35 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-07 16:29:35 --> Loader Class Initialized
ERROR - 2020-02-07 16:29:35 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 16:29:35 --> Helper loaded: url_helper
INFO - 2020-02-07 16:29:35 --> Database Driver Class Initialized
INFO - 2020-02-07 16:29:35 --> Config Class Initialized
INFO - 2020-02-07 16:29:35 --> Config Class Initialized
INFO - 2020-02-07 16:29:35 --> Config Class Initialized
INFO - 2020-02-07 16:29:35 --> Hooks Class Initialized
INFO - 2020-02-07 16:29:35 --> Hooks Class Initialized
INFO - 2020-02-07 16:29:35 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:29:36 --> Database Driver Class Initialized
INFO - 2020-02-07 16:29:36 --> Config Class Initialized
INFO - 2020-02-07 16:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:29:36 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:29:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-07 16:29:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:36 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:36 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:36 --> Controller Class Initialized
INFO - 2020-02-07 16:29:36 --> Utf8 Class Initialized
DEBUG - 2020-02-07 16:29:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:36 --> URI Class Initialized
INFO - 2020-02-07 16:29:36 --> URI Class Initialized
INFO - 2020-02-07 16:29:36 --> URI Class Initialized
INFO - 2020-02-07 16:29:36 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:29:36 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:36 --> URI Class Initialized
INFO - 2020-02-07 16:29:36 --> Router Class Initialized
INFO - 2020-02-07 16:29:36 --> Router Class Initialized
INFO - 2020-02-07 16:29:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:29:36 --> Router Class Initialized
INFO - 2020-02-07 16:29:36 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:29:36 --> Router Class Initialized
INFO - 2020-02-07 16:29:36 --> Output Class Initialized
INFO - 2020-02-07 16:29:36 --> Output Class Initialized
INFO - 2020-02-07 16:29:36 --> Output Class Initialized
INFO - 2020-02-07 16:29:36 --> Security Class Initialized
INFO - 2020-02-07 16:29:36 --> Security Class Initialized
INFO - 2020-02-07 16:29:36 --> Output Class Initialized
INFO - 2020-02-07 16:29:36 --> Helper loaded: form_helper
INFO - 2020-02-07 16:29:36 --> Security Class Initialized
INFO - 2020-02-07 16:29:36 --> Form Validation Class Initialized
INFO - 2020-02-07 16:29:36 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:36 --> Input Class Initialized
INFO - 2020-02-07 16:29:36 --> Input Class Initialized
INFO - 2020-02-07 16:29:36 --> Input Class Initialized
DEBUG - 2020-02-07 16:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-07 16:29:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 16:29:36 --> Input Class Initialized
INFO - 2020-02-07 16:29:36 --> Language Class Initialized
ERROR - 2020-02-07 16:29:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 16:29:36 --> Language Class Initialized
INFO - 2020-02-07 16:29:36 --> Language Class Initialized
INFO - 2020-02-07 16:29:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 16:29:36 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-07 16:29:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:29:36 --> Language Class Initialized
ERROR - 2020-02-07 16:29:36 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 16:29:36 --> Final output sent to browser
ERROR - 2020-02-07 16:29:36 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 16:29:36 --> Config Class Initialized
INFO - 2020-02-07 16:29:36 --> Config Class Initialized
INFO - 2020-02-07 16:29:36 --> Config Class Initialized
INFO - 2020-02-07 16:29:36 --> Hooks Class Initialized
INFO - 2020-02-07 16:29:36 --> Hooks Class Initialized
INFO - 2020-02-07 16:29:36 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:36 --> Total execution time: 0.7454
INFO - 2020-02-07 16:29:36 --> Config Class Initialized
INFO - 2020-02-07 16:29:36 --> Hooks Class Initialized
INFO - 2020-02-07 16:29:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-07 16:29:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:29:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 16:29:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:36 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:36 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:36 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:36 --> Controller Class Initialized
DEBUG - 2020-02-07 16:29:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:36 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:36 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:29:36 --> URI Class Initialized
INFO - 2020-02-07 16:29:36 --> URI Class Initialized
INFO - 2020-02-07 16:29:36 --> URI Class Initialized
INFO - 2020-02-07 16:29:36 --> URI Class Initialized
INFO - 2020-02-07 16:29:36 --> Router Class Initialized
INFO - 2020-02-07 16:29:36 --> Router Class Initialized
INFO - 2020-02-07 16:29:36 --> Router Class Initialized
INFO - 2020-02-07 16:29:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:29:36 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:29:36 --> Router Class Initialized
INFO - 2020-02-07 16:29:36 --> Output Class Initialized
INFO - 2020-02-07 16:29:36 --> Output Class Initialized
INFO - 2020-02-07 16:29:36 --> Output Class Initialized
INFO - 2020-02-07 16:29:36 --> Security Class Initialized
INFO - 2020-02-07 16:29:36 --> Security Class Initialized
INFO - 2020-02-07 16:29:36 --> Security Class Initialized
INFO - 2020-02-07 16:29:36 --> Output Class Initialized
INFO - 2020-02-07 16:29:36 --> Helper loaded: form_helper
INFO - 2020-02-07 16:29:36 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:36 --> Form Validation Class Initialized
DEBUG - 2020-02-07 16:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-07 16:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:36 --> Input Class Initialized
INFO - 2020-02-07 16:29:36 --> Input Class Initialized
INFO - 2020-02-07 16:29:36 --> Input Class Initialized
DEBUG - 2020-02-07 16:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-07 16:29:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-07 16:29:36 --> Input Class Initialized
INFO - 2020-02-07 16:29:36 --> Language Class Initialized
INFO - 2020-02-07 16:29:36 --> Language Class Initialized
INFO - 2020-02-07 16:29:36 --> Language Class Initialized
ERROR - 2020-02-07 16:29:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-07 16:29:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-07 16:29:36 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-07 16:29:36 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-07 16:29:36 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 16:29:36 --> Language Class Initialized
INFO - 2020-02-07 16:29:36 --> Final output sent to browser
ERROR - 2020-02-07 16:29:36 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-07 16:29:36 --> Total execution time: 1.0596
INFO - 2020-02-07 16:29:36 --> Config Class Initialized
INFO - 2020-02-07 16:29:36 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:36 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:36 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:36 --> URI Class Initialized
INFO - 2020-02-07 16:29:36 --> Router Class Initialized
INFO - 2020-02-07 16:29:36 --> Output Class Initialized
INFO - 2020-02-07 16:29:36 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:36 --> Input Class Initialized
INFO - 2020-02-07 16:29:36 --> Language Class Initialized
ERROR - 2020-02-07 16:29:36 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-07 16:29:36 --> Config Class Initialized
INFO - 2020-02-07 16:29:37 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:37 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:37 --> URI Class Initialized
INFO - 2020-02-07 16:29:37 --> Router Class Initialized
INFO - 2020-02-07 16:29:37 --> Output Class Initialized
INFO - 2020-02-07 16:29:37 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:37 --> Input Class Initialized
INFO - 2020-02-07 16:29:37 --> Language Class Initialized
ERROR - 2020-02-07 16:29:37 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-07 16:29:37 --> Config Class Initialized
INFO - 2020-02-07 16:29:37 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:37 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:37 --> URI Class Initialized
INFO - 2020-02-07 16:29:37 --> Router Class Initialized
INFO - 2020-02-07 16:29:37 --> Output Class Initialized
INFO - 2020-02-07 16:29:37 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:37 --> Input Class Initialized
INFO - 2020-02-07 16:29:37 --> Language Class Initialized
ERROR - 2020-02-07 16:29:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:29:37 --> Config Class Initialized
INFO - 2020-02-07 16:29:37 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:37 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:37 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:37 --> URI Class Initialized
INFO - 2020-02-07 16:29:37 --> Router Class Initialized
INFO - 2020-02-07 16:29:37 --> Output Class Initialized
INFO - 2020-02-07 16:29:37 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:37 --> Input Class Initialized
INFO - 2020-02-07 16:29:37 --> Language Class Initialized
ERROR - 2020-02-07 16:29:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:29:37 --> Config Class Initialized
INFO - 2020-02-07 16:29:38 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:38 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:38 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:38 --> URI Class Initialized
INFO - 2020-02-07 16:29:38 --> Router Class Initialized
INFO - 2020-02-07 16:29:38 --> Output Class Initialized
INFO - 2020-02-07 16:29:38 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:38 --> Input Class Initialized
INFO - 2020-02-07 16:29:38 --> Language Class Initialized
ERROR - 2020-02-07 16:29:38 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-07 16:29:38 --> Config Class Initialized
INFO - 2020-02-07 16:29:38 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:38 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:38 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:38 --> URI Class Initialized
INFO - 2020-02-07 16:29:38 --> Router Class Initialized
INFO - 2020-02-07 16:29:38 --> Output Class Initialized
INFO - 2020-02-07 16:29:38 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:38 --> Input Class Initialized
INFO - 2020-02-07 16:29:38 --> Language Class Initialized
ERROR - 2020-02-07 16:29:38 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-07 16:29:38 --> Config Class Initialized
INFO - 2020-02-07 16:29:38 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:38 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:38 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:38 --> URI Class Initialized
INFO - 2020-02-07 16:29:38 --> Router Class Initialized
INFO - 2020-02-07 16:29:38 --> Output Class Initialized
INFO - 2020-02-07 16:29:38 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:38 --> Input Class Initialized
INFO - 2020-02-07 16:29:38 --> Language Class Initialized
ERROR - 2020-02-07 16:29:38 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-07 16:29:38 --> Config Class Initialized
INFO - 2020-02-07 16:29:39 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:39 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:39 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:39 --> URI Class Initialized
INFO - 2020-02-07 16:29:39 --> Router Class Initialized
INFO - 2020-02-07 16:29:39 --> Output Class Initialized
INFO - 2020-02-07 16:29:39 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:39 --> Input Class Initialized
INFO - 2020-02-07 16:29:39 --> Language Class Initialized
ERROR - 2020-02-07 16:29:39 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-07 16:29:57 --> Config Class Initialized
INFO - 2020-02-07 16:29:57 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:29:57 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:29:57 --> Utf8 Class Initialized
INFO - 2020-02-07 16:29:57 --> URI Class Initialized
INFO - 2020-02-07 16:29:57 --> Router Class Initialized
INFO - 2020-02-07 16:29:57 --> Output Class Initialized
INFO - 2020-02-07 16:29:57 --> Security Class Initialized
DEBUG - 2020-02-07 16:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:29:57 --> Input Class Initialized
INFO - 2020-02-07 16:29:58 --> Language Class Initialized
INFO - 2020-02-07 16:29:58 --> Loader Class Initialized
INFO - 2020-02-07 16:29:58 --> Helper loaded: url_helper
INFO - 2020-02-07 16:29:58 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:29:58 --> Controller Class Initialized
INFO - 2020-02-07 16:29:58 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:29:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:29:58 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:29:58 --> Helper loaded: form_helper
INFO - 2020-02-07 16:29:58 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:29:58 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
ERROR - 2020-02-07 16:29:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-07 16:29:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:29:58 --> Final output sent to browser
DEBUG - 2020-02-07 16:29:58 --> Total execution time: 0.8000
INFO - 2020-02-07 16:30:47 --> Config Class Initialized
INFO - 2020-02-07 16:30:48 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:30:48 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:30:48 --> Utf8 Class Initialized
INFO - 2020-02-07 16:30:48 --> URI Class Initialized
INFO - 2020-02-07 16:30:48 --> Router Class Initialized
INFO - 2020-02-07 16:30:48 --> Output Class Initialized
INFO - 2020-02-07 16:30:48 --> Security Class Initialized
DEBUG - 2020-02-07 16:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:30:48 --> Input Class Initialized
INFO - 2020-02-07 16:30:48 --> Language Class Initialized
INFO - 2020-02-07 16:30:48 --> Loader Class Initialized
INFO - 2020-02-07 16:30:48 --> Helper loaded: url_helper
INFO - 2020-02-07 16:30:48 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:30:48 --> Controller Class Initialized
INFO - 2020-02-07 16:30:48 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:30:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:30:48 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:30:48 --> Helper loaded: form_helper
INFO - 2020-02-07 16:30:48 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-07 16:30:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:30:48 --> Final output sent to browser
DEBUG - 2020-02-07 16:30:48 --> Total execution time: 0.9868
INFO - 2020-02-07 16:35:41 --> Config Class Initialized
INFO - 2020-02-07 16:35:41 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:35:41 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:35:41 --> Utf8 Class Initialized
INFO - 2020-02-07 16:35:41 --> URI Class Initialized
INFO - 2020-02-07 16:35:41 --> Router Class Initialized
INFO - 2020-02-07 16:35:42 --> Output Class Initialized
INFO - 2020-02-07 16:35:42 --> Security Class Initialized
DEBUG - 2020-02-07 16:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:35:42 --> Input Class Initialized
INFO - 2020-02-07 16:35:42 --> Language Class Initialized
INFO - 2020-02-07 16:35:42 --> Loader Class Initialized
INFO - 2020-02-07 16:35:42 --> Helper loaded: url_helper
INFO - 2020-02-07 16:35:42 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:35:42 --> Controller Class Initialized
INFO - 2020-02-07 16:35:42 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:35:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:35:42 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:35:42 --> Helper loaded: form_helper
INFO - 2020-02-07 16:35:42 --> Form Validation Class Initialized
ERROR - 2020-02-07 16:35:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 1
INFO - 2020-02-07 16:35:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-07 16:35:42 --> Final output sent to browser
DEBUG - 2020-02-07 16:35:42 --> Total execution time: 0.8418
INFO - 2020-02-07 16:36:38 --> Config Class Initialized
INFO - 2020-02-07 16:36:38 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:36:38 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:36:38 --> Utf8 Class Initialized
INFO - 2020-02-07 16:36:38 --> URI Class Initialized
INFO - 2020-02-07 16:36:38 --> Router Class Initialized
INFO - 2020-02-07 16:36:38 --> Output Class Initialized
INFO - 2020-02-07 16:36:38 --> Security Class Initialized
DEBUG - 2020-02-07 16:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:36:38 --> Input Class Initialized
INFO - 2020-02-07 16:36:38 --> Language Class Initialized
INFO - 2020-02-07 16:36:38 --> Loader Class Initialized
INFO - 2020-02-07 16:36:38 --> Helper loaded: url_helper
INFO - 2020-02-07 16:36:38 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:36:38 --> Controller Class Initialized
INFO - 2020-02-07 16:36:38 --> Model "M_tiket" initialized
INFO - 2020-02-07 16:36:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 16:36:38 --> Model "M_pesan" initialized
INFO - 2020-02-07 16:36:38 --> Helper loaded: form_helper
INFO - 2020-02-07 16:36:38 --> Form Validation Class Initialized
INFO - 2020-02-07 16:36:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 16:36:38 --> Final output sent to browser
INFO - 2020-02-07 16:36:38 --> Config Class Initialized
INFO - 2020-02-07 16:36:38 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:36:38 --> Total execution time: 0.6756
INFO - 2020-02-07 16:36:38 --> Config Class Initialized
INFO - 2020-02-07 16:36:39 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:36:39 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:36:39 --> Utf8 Class Initialized
DEBUG - 2020-02-07 16:36:39 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:36:39 --> Utf8 Class Initialized
INFO - 2020-02-07 16:36:39 --> URI Class Initialized
INFO - 2020-02-07 16:36:39 --> URI Class Initialized
INFO - 2020-02-07 16:36:39 --> Router Class Initialized
INFO - 2020-02-07 16:36:39 --> Router Class Initialized
INFO - 2020-02-07 16:36:39 --> Output Class Initialized
INFO - 2020-02-07 16:36:39 --> Security Class Initialized
INFO - 2020-02-07 16:36:39 --> Output Class Initialized
DEBUG - 2020-02-07 16:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:36:39 --> Security Class Initialized
INFO - 2020-02-07 16:36:39 --> Input Class Initialized
DEBUG - 2020-02-07 16:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:36:39 --> Input Class Initialized
INFO - 2020-02-07 16:36:39 --> Language Class Initialized
INFO - 2020-02-07 16:36:39 --> Language Class Initialized
ERROR - 2020-02-07 16:36:39 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-07 16:36:39 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-07 16:44:44 --> Config Class Initialized
INFO - 2020-02-07 16:44:44 --> Hooks Class Initialized
DEBUG - 2020-02-07 16:44:44 --> UTF-8 Support Enabled
INFO - 2020-02-07 16:44:44 --> Utf8 Class Initialized
INFO - 2020-02-07 16:44:44 --> URI Class Initialized
INFO - 2020-02-07 16:44:44 --> Router Class Initialized
INFO - 2020-02-07 16:44:44 --> Output Class Initialized
INFO - 2020-02-07 16:44:44 --> Security Class Initialized
DEBUG - 2020-02-07 16:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 16:44:44 --> Input Class Initialized
INFO - 2020-02-07 16:44:44 --> Language Class Initialized
INFO - 2020-02-07 16:44:44 --> Loader Class Initialized
INFO - 2020-02-07 16:44:44 --> Helper loaded: url_helper
INFO - 2020-02-07 16:44:44 --> Database Driver Class Initialized
DEBUG - 2020-02-07 16:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 16:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 16:44:44 --> Controller Class Initialized
ERROR - 2020-02-07 16:44:44 --> Severity: Notice --> Undefined property: Admin::$template C:\xampp\htdocs\roadshow\application\controllers\Admin.php 9
ERROR - 2020-02-07 16:44:44 --> Severity: error --> Exception: Call to a member function load() on null C:\xampp\htdocs\roadshow\application\controllers\Admin.php 9
INFO - 2020-02-07 17:03:10 --> Config Class Initialized
INFO - 2020-02-07 17:03:10 --> Hooks Class Initialized
DEBUG - 2020-02-07 17:03:10 --> UTF-8 Support Enabled
INFO - 2020-02-07 17:03:10 --> Utf8 Class Initialized
INFO - 2020-02-07 17:03:11 --> URI Class Initialized
INFO - 2020-02-07 17:03:11 --> Router Class Initialized
INFO - 2020-02-07 17:03:11 --> Output Class Initialized
INFO - 2020-02-07 17:03:11 --> Security Class Initialized
DEBUG - 2020-02-07 17:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-07 17:03:11 --> Input Class Initialized
INFO - 2020-02-07 17:03:11 --> Language Class Initialized
INFO - 2020-02-07 17:03:11 --> Loader Class Initialized
INFO - 2020-02-07 17:03:11 --> Helper loaded: url_helper
INFO - 2020-02-07 17:03:11 --> Database Driver Class Initialized
DEBUG - 2020-02-07 17:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-07 17:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-07 17:03:12 --> Controller Class Initialized
INFO - 2020-02-07 17:03:12 --> Model "M_tiket" initialized
INFO - 2020-02-07 17:03:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-07 17:03:12 --> Model "M_pesan" initialized
INFO - 2020-02-07 17:03:12 --> Helper loaded: form_helper
INFO - 2020-02-07 17:03:12 --> Form Validation Class Initialized
INFO - 2020-02-07 17:03:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-07 17:03:12 --> Final output sent to browser
DEBUG - 2020-02-07 17:03:13 --> Total execution time: 2.3340
