<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-10 07:03:40 --> Config Class Initialized
INFO - 2020-01-10 07:03:40 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:03:41 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:03:41 --> Utf8 Class Initialized
INFO - 2020-01-10 07:03:41 --> URI Class Initialized
DEBUG - 2020-01-10 07:03:41 --> No URI present. Default controller set.
INFO - 2020-01-10 07:03:41 --> Router Class Initialized
INFO - 2020-01-10 07:03:41 --> Output Class Initialized
INFO - 2020-01-10 07:03:41 --> Security Class Initialized
DEBUG - 2020-01-10 07:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:03:41 --> Input Class Initialized
INFO - 2020-01-10 07:03:41 --> Language Class Initialized
INFO - 2020-01-10 07:03:41 --> Loader Class Initialized
INFO - 2020-01-10 07:03:41 --> Helper loaded: url_helper
INFO - 2020-01-10 07:03:41 --> Database Driver Class Initialized
DEBUG - 2020-01-10 07:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 07:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 07:03:42 --> Controller Class Initialized
INFO - 2020-01-10 07:03:42 --> Model "M_login" initialized
INFO - 2020-01-10 07:03:42 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2020-01-10 07:03:42 --> Final output sent to browser
DEBUG - 2020-01-10 07:03:42 --> Total execution time: 1.6753
INFO - 2020-01-10 07:03:44 --> Config Class Initialized
INFO - 2020-01-10 07:03:44 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:03:44 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:03:44 --> Utf8 Class Initialized
INFO - 2020-01-10 07:03:44 --> URI Class Initialized
DEBUG - 2020-01-10 07:03:44 --> No URI present. Default controller set.
INFO - 2020-01-10 07:03:44 --> Router Class Initialized
INFO - 2020-01-10 07:03:44 --> Output Class Initialized
INFO - 2020-01-10 07:03:44 --> Security Class Initialized
DEBUG - 2020-01-10 07:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:03:44 --> Input Class Initialized
INFO - 2020-01-10 07:03:44 --> Language Class Initialized
INFO - 2020-01-10 07:03:44 --> Loader Class Initialized
INFO - 2020-01-10 07:03:44 --> Helper loaded: url_helper
INFO - 2020-01-10 07:03:44 --> Database Driver Class Initialized
DEBUG - 2020-01-10 07:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 07:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 07:03:44 --> Controller Class Initialized
INFO - 2020-01-10 07:03:44 --> Model "M_login" initialized
INFO - 2020-01-10 07:03:44 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2020-01-10 07:03:44 --> Final output sent to browser
DEBUG - 2020-01-10 07:03:44 --> Total execution time: 0.3374
INFO - 2020-01-10 07:03:56 --> Config Class Initialized
INFO - 2020-01-10 07:03:56 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:03:56 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:03:56 --> Utf8 Class Initialized
INFO - 2020-01-10 07:03:56 --> URI Class Initialized
INFO - 2020-01-10 07:03:56 --> Router Class Initialized
INFO - 2020-01-10 07:03:56 --> Output Class Initialized
INFO - 2020-01-10 07:03:56 --> Security Class Initialized
DEBUG - 2020-01-10 07:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:03:56 --> Input Class Initialized
INFO - 2020-01-10 07:03:56 --> Language Class Initialized
INFO - 2020-01-10 07:03:56 --> Loader Class Initialized
INFO - 2020-01-10 07:03:56 --> Helper loaded: url_helper
INFO - 2020-01-10 07:03:56 --> Database Driver Class Initialized
DEBUG - 2020-01-10 07:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 07:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 07:03:56 --> Controller Class Initialized
INFO - 2020-01-10 07:03:56 --> Model "M_login" initialized
INFO - 2020-01-10 07:03:56 --> Config Class Initialized
INFO - 2020-01-10 07:03:56 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:03:56 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:03:56 --> Utf8 Class Initialized
INFO - 2020-01-10 07:03:56 --> URI Class Initialized
INFO - 2020-01-10 07:03:56 --> Router Class Initialized
INFO - 2020-01-10 07:03:56 --> Output Class Initialized
INFO - 2020-01-10 07:03:56 --> Security Class Initialized
DEBUG - 2020-01-10 07:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:03:56 --> Input Class Initialized
INFO - 2020-01-10 07:03:56 --> Language Class Initialized
INFO - 2020-01-10 07:03:56 --> Loader Class Initialized
INFO - 2020-01-10 07:03:56 --> Helper loaded: url_helper
INFO - 2020-01-10 07:03:56 --> Database Driver Class Initialized
DEBUG - 2020-01-10 07:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 07:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 07:03:56 --> Controller Class Initialized
INFO - 2020-01-10 07:03:57 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 07:03:57 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2020-01-10 07:03:57 --> Final output sent to browser
DEBUG - 2020-01-10 07:03:57 --> Total execution time: 0.5314
INFO - 2020-01-10 07:03:57 --> Config Class Initialized
INFO - 2020-01-10 07:03:57 --> Config Class Initialized
INFO - 2020-01-10 07:03:57 --> Hooks Class Initialized
INFO - 2020-01-10 07:03:57 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:03:57 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:03:57 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:03:57 --> Utf8 Class Initialized
INFO - 2020-01-10 07:03:57 --> Utf8 Class Initialized
INFO - 2020-01-10 07:03:57 --> URI Class Initialized
INFO - 2020-01-10 07:03:57 --> URI Class Initialized
INFO - 2020-01-10 07:03:57 --> Router Class Initialized
INFO - 2020-01-10 07:03:57 --> Router Class Initialized
INFO - 2020-01-10 07:03:57 --> Output Class Initialized
INFO - 2020-01-10 07:03:57 --> Output Class Initialized
INFO - 2020-01-10 07:03:57 --> Security Class Initialized
INFO - 2020-01-10 07:03:57 --> Security Class Initialized
DEBUG - 2020-01-10 07:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:03:57 --> Input Class Initialized
INFO - 2020-01-10 07:03:57 --> Input Class Initialized
INFO - 2020-01-10 07:03:57 --> Language Class Initialized
INFO - 2020-01-10 07:03:57 --> Language Class Initialized
ERROR - 2020-01-10 07:03:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-10 07:03:57 --> 404 Page Not Found: Assets/js
INFO - 2020-01-10 07:04:00 --> Config Class Initialized
INFO - 2020-01-10 07:04:00 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:00 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:00 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:00 --> URI Class Initialized
INFO - 2020-01-10 07:04:00 --> Router Class Initialized
INFO - 2020-01-10 07:04:00 --> Output Class Initialized
INFO - 2020-01-10 07:04:00 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:00 --> Input Class Initialized
INFO - 2020-01-10 07:04:00 --> Language Class Initialized
INFO - 2020-01-10 07:04:00 --> Loader Class Initialized
INFO - 2020-01-10 07:04:00 --> Helper loaded: url_helper
INFO - 2020-01-10 07:04:00 --> Database Driver Class Initialized
DEBUG - 2020-01-10 07:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 07:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 07:04:00 --> Controller Class Initialized
INFO - 2020-01-10 07:04:00 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 07:04:00 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2020-01-10 07:04:00 --> Final output sent to browser
DEBUG - 2020-01-10 07:04:00 --> Total execution time: 0.3959
INFO - 2020-01-10 07:04:00 --> Config Class Initialized
INFO - 2020-01-10 07:04:00 --> Config Class Initialized
INFO - 2020-01-10 07:04:00 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:00 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:00 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:00 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:00 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:00 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:00 --> URI Class Initialized
INFO - 2020-01-10 07:04:00 --> URI Class Initialized
INFO - 2020-01-10 07:04:00 --> Router Class Initialized
INFO - 2020-01-10 07:04:00 --> Router Class Initialized
INFO - 2020-01-10 07:04:00 --> Output Class Initialized
INFO - 2020-01-10 07:04:00 --> Output Class Initialized
INFO - 2020-01-10 07:04:00 --> Security Class Initialized
INFO - 2020-01-10 07:04:00 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:00 --> Input Class Initialized
INFO - 2020-01-10 07:04:00 --> Input Class Initialized
INFO - 2020-01-10 07:04:00 --> Language Class Initialized
INFO - 2020-01-10 07:04:00 --> Language Class Initialized
ERROR - 2020-01-10 07:04:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-10 07:04:00 --> 404 Page Not Found: Assets/js
INFO - 2020-01-10 07:04:01 --> Config Class Initialized
INFO - 2020-01-10 07:04:01 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:01 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:01 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:01 --> URI Class Initialized
INFO - 2020-01-10 07:04:01 --> Router Class Initialized
INFO - 2020-01-10 07:04:01 --> Output Class Initialized
INFO - 2020-01-10 07:04:01 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:01 --> Input Class Initialized
INFO - 2020-01-10 07:04:01 --> Language Class Initialized
ERROR - 2020-01-10 07:04:01 --> 404 Page Not Found: Assets/js
INFO - 2020-01-10 07:04:05 --> Config Class Initialized
INFO - 2020-01-10 07:04:05 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:05 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:05 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:05 --> URI Class Initialized
INFO - 2020-01-10 07:04:05 --> Router Class Initialized
INFO - 2020-01-10 07:04:05 --> Output Class Initialized
INFO - 2020-01-10 07:04:05 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:05 --> Input Class Initialized
INFO - 2020-01-10 07:04:05 --> Language Class Initialized
INFO - 2020-01-10 07:04:05 --> Loader Class Initialized
INFO - 2020-01-10 07:04:05 --> Helper loaded: url_helper
INFO - 2020-01-10 07:04:05 --> Database Driver Class Initialized
DEBUG - 2020-01-10 07:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 07:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 07:04:05 --> Controller Class Initialized
INFO - 2020-01-10 07:04:05 --> Model "M_login" initialized
INFO - 2020-01-10 07:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-10 07:04:05 --> Pagination Class Initialized
INFO - 2020-01-10 07:04:05 --> Model "M_show" initialized
INFO - 2020-01-10 07:04:05 --> Helper loaded: form_helper
INFO - 2020-01-10 07:04:05 --> Form Validation Class Initialized
INFO - 2020-01-10 07:04:06 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 07:04:06 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-10 07:04:06 --> Final output sent to browser
DEBUG - 2020-01-10 07:04:06 --> Total execution time: 1.1262
INFO - 2020-01-10 07:04:06 --> Config Class Initialized
INFO - 2020-01-10 07:04:06 --> Config Class Initialized
INFO - 2020-01-10 07:04:06 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:06 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:06 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:06 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:06 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:06 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:06 --> URI Class Initialized
INFO - 2020-01-10 07:04:06 --> URI Class Initialized
INFO - 2020-01-10 07:04:06 --> Router Class Initialized
INFO - 2020-01-10 07:04:06 --> Router Class Initialized
INFO - 2020-01-10 07:04:06 --> Output Class Initialized
INFO - 2020-01-10 07:04:06 --> Output Class Initialized
INFO - 2020-01-10 07:04:06 --> Security Class Initialized
INFO - 2020-01-10 07:04:06 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:06 --> Input Class Initialized
INFO - 2020-01-10 07:04:06 --> Input Class Initialized
INFO - 2020-01-10 07:04:06 --> Language Class Initialized
INFO - 2020-01-10 07:04:06 --> Language Class Initialized
ERROR - 2020-01-10 07:04:06 --> 404 Page Not Found: Show/assets
ERROR - 2020-01-10 07:04:06 --> 404 Page Not Found: Show/assets
INFO - 2020-01-10 07:04:06 --> Config Class Initialized
INFO - 2020-01-10 07:04:06 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:06 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:06 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:06 --> URI Class Initialized
INFO - 2020-01-10 07:04:06 --> Router Class Initialized
INFO - 2020-01-10 07:04:06 --> Output Class Initialized
INFO - 2020-01-10 07:04:06 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:06 --> Input Class Initialized
INFO - 2020-01-10 07:04:06 --> Language Class Initialized
ERROR - 2020-01-10 07:04:06 --> 404 Page Not Found: Show/assets
INFO - 2020-01-10 07:04:14 --> Config Class Initialized
INFO - 2020-01-10 07:04:14 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:14 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:14 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:14 --> URI Class Initialized
INFO - 2020-01-10 07:04:14 --> Router Class Initialized
INFO - 2020-01-10 07:04:14 --> Output Class Initialized
INFO - 2020-01-10 07:04:14 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:14 --> Input Class Initialized
INFO - 2020-01-10 07:04:14 --> Language Class Initialized
INFO - 2020-01-10 07:04:14 --> Loader Class Initialized
INFO - 2020-01-10 07:04:14 --> Helper loaded: url_helper
INFO - 2020-01-10 07:04:14 --> Database Driver Class Initialized
DEBUG - 2020-01-10 07:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 07:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 07:04:14 --> Controller Class Initialized
INFO - 2020-01-10 07:04:14 --> Model "M_login" initialized
INFO - 2020-01-10 07:04:14 --> Model "M_tiket" initialized
INFO - 2020-01-10 07:04:14 --> Helper loaded: form_helper
INFO - 2020-01-10 07:04:14 --> Form Validation Class Initialized
INFO - 2020-01-10 07:04:15 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 07:04:15 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-10 07:04:15 --> Final output sent to browser
DEBUG - 2020-01-10 07:04:15 --> Total execution time: 0.8822
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
DEBUG - 2020-01-10 07:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
INFO - 2020-01-10 07:04:15 --> Input Class Initialized
INFO - 2020-01-10 07:04:15 --> Input Class Initialized
DEBUG - 2020-01-10 07:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:15 --> Input Class Initialized
INFO - 2020-01-10 07:04:15 --> Input Class Initialized
INFO - 2020-01-10 07:04:15 --> Input Class Initialized
INFO - 2020-01-10 07:04:15 --> Input Class Initialized
INFO - 2020-01-10 07:04:15 --> Language Class Initialized
INFO - 2020-01-10 07:04:15 --> Language Class Initialized
INFO - 2020-01-10 07:04:15 --> Language Class Initialized
INFO - 2020-01-10 07:04:15 --> Language Class Initialized
INFO - 2020-01-10 07:04:15 --> Language Class Initialized
ERROR - 2020-01-10 07:04:15 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-01-10 07:04:15 --> Language Class Initialized
ERROR - 2020-01-10 07:04:15 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-01-10 07:04:15 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-10 07:04:15 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-10 07:04:15 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-10 07:04:15 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:15 --> Input Class Initialized
INFO - 2020-01-10 07:04:15 --> Input Class Initialized
INFO - 2020-01-10 07:04:15 --> Input Class Initialized
INFO - 2020-01-10 07:04:15 --> Input Class Initialized
INFO - 2020-01-10 07:04:15 --> Input Class Initialized
INFO - 2020-01-10 07:04:15 --> Input Class Initialized
INFO - 2020-01-10 07:04:15 --> Language Class Initialized
INFO - 2020-01-10 07:04:15 --> Language Class Initialized
INFO - 2020-01-10 07:04:15 --> Language Class Initialized
INFO - 2020-01-10 07:04:15 --> Language Class Initialized
INFO - 2020-01-10 07:04:15 --> Language Class Initialized
INFO - 2020-01-10 07:04:15 --> Language Class Initialized
ERROR - 2020-01-10 07:04:15 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-01-10 07:04:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-01-10 07:04:15 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-01-10 07:04:15 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-01-10 07:04:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-01-10 07:04:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Config Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:15 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:15 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> URI Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Router Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Output Class Initialized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
INFO - 2020-01-10 07:04:15 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:16 --> Input Class Initialized
INFO - 2020-01-10 07:04:16 --> Input Class Initialized
INFO - 2020-01-10 07:04:16 --> Input Class Initialized
INFO - 2020-01-10 07:04:16 --> Language Class Initialized
INFO - 2020-01-10 07:04:16 --> Language Class Initialized
INFO - 2020-01-10 07:04:16 --> Language Class Initialized
ERROR - 2020-01-10 07:04:16 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-01-10 07:04:16 --> Loader Class Initialized
INFO - 2020-01-10 07:04:16 --> Loader Class Initialized
INFO - 2020-01-10 07:04:16 --> Helper loaded: url_helper
INFO - 2020-01-10 07:04:16 --> Helper loaded: url_helper
INFO - 2020-01-10 07:04:16 --> Config Class Initialized
INFO - 2020-01-10 07:04:16 --> Database Driver Class Initialized
INFO - 2020-01-10 07:04:16 --> Database Driver Class Initialized
INFO - 2020-01-10 07:04:16 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-01-10 07:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 07:04:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-01-10 07:04:16 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:16 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:16 --> Controller Class Initialized
INFO - 2020-01-10 07:04:16 --> Model "M_login" initialized
INFO - 2020-01-10 07:04:16 --> URI Class Initialized
INFO - 2020-01-10 07:04:16 --> Model "M_tiket" initialized
INFO - 2020-01-10 07:04:16 --> Router Class Initialized
INFO - 2020-01-10 07:04:16 --> Output Class Initialized
INFO - 2020-01-10 07:04:16 --> Helper loaded: form_helper
INFO - 2020-01-10 07:04:16 --> Form Validation Class Initialized
INFO - 2020-01-10 07:04:16 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:16 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 07:04:16 --> Input Class Initialized
ERROR - 2020-01-10 07:04:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-10 07:04:16 --> Language Class Initialized
ERROR - 2020-01-10 07:04:16 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-10 07:04:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-01-10 07:04:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-10 07:04:16 --> Config Class Initialized
INFO - 2020-01-10 07:04:16 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:16 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-10 07:04:16 --> Final output sent to browser
DEBUG - 2020-01-10 07:04:16 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:16 --> Utf8 Class Initialized
DEBUG - 2020-01-10 07:04:16 --> Total execution time: 0.5320
INFO - 2020-01-10 07:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 07:04:16 --> URI Class Initialized
INFO - 2020-01-10 07:04:16 --> Controller Class Initialized
INFO - 2020-01-10 07:04:16 --> Router Class Initialized
INFO - 2020-01-10 07:04:16 --> Model "M_login" initialized
INFO - 2020-01-10 07:04:16 --> Output Class Initialized
INFO - 2020-01-10 07:04:16 --> Model "M_tiket" initialized
INFO - 2020-01-10 07:04:16 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:16 --> Helper loaded: form_helper
INFO - 2020-01-10 07:04:16 --> Form Validation Class Initialized
INFO - 2020-01-10 07:04:16 --> Input Class Initialized
INFO - 2020-01-10 07:04:16 --> Language Class Initialized
INFO - 2020-01-10 07:04:16 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-10 07:04:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-01-10 07:04:16 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-10 07:04:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-01-10 07:04:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-10 07:04:16 --> Config Class Initialized
INFO - 2020-01-10 07:04:16 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:16 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-10 07:04:16 --> Final output sent to browser
DEBUG - 2020-01-10 07:04:16 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:16 --> Utf8 Class Initialized
DEBUG - 2020-01-10 07:04:16 --> Total execution time: 0.7467
INFO - 2020-01-10 07:04:16 --> URI Class Initialized
INFO - 2020-01-10 07:04:16 --> Router Class Initialized
INFO - 2020-01-10 07:04:16 --> Output Class Initialized
INFO - 2020-01-10 07:04:16 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:16 --> Input Class Initialized
INFO - 2020-01-10 07:04:16 --> Language Class Initialized
ERROR - 2020-01-10 07:04:16 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-10 07:04:16 --> Config Class Initialized
INFO - 2020-01-10 07:04:16 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:16 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:16 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:16 --> URI Class Initialized
INFO - 2020-01-10 07:04:16 --> Router Class Initialized
INFO - 2020-01-10 07:04:16 --> Output Class Initialized
INFO - 2020-01-10 07:04:16 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:16 --> Input Class Initialized
INFO - 2020-01-10 07:04:16 --> Language Class Initialized
ERROR - 2020-01-10 07:04:16 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-10 07:04:17 --> Config Class Initialized
INFO - 2020-01-10 07:04:17 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:17 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:17 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:17 --> URI Class Initialized
INFO - 2020-01-10 07:04:17 --> Router Class Initialized
INFO - 2020-01-10 07:04:17 --> Output Class Initialized
INFO - 2020-01-10 07:04:17 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:17 --> Input Class Initialized
INFO - 2020-01-10 07:04:17 --> Language Class Initialized
ERROR - 2020-01-10 07:04:17 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-10 07:04:17 --> Config Class Initialized
INFO - 2020-01-10 07:04:17 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:17 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:17 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:17 --> URI Class Initialized
INFO - 2020-01-10 07:04:17 --> Router Class Initialized
INFO - 2020-01-10 07:04:17 --> Output Class Initialized
INFO - 2020-01-10 07:04:17 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:17 --> Input Class Initialized
INFO - 2020-01-10 07:04:17 --> Language Class Initialized
ERROR - 2020-01-10 07:04:17 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-10 07:04:17 --> Config Class Initialized
INFO - 2020-01-10 07:04:17 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:17 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:17 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:17 --> URI Class Initialized
INFO - 2020-01-10 07:04:17 --> Router Class Initialized
INFO - 2020-01-10 07:04:17 --> Output Class Initialized
INFO - 2020-01-10 07:04:17 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:17 --> Input Class Initialized
INFO - 2020-01-10 07:04:17 --> Language Class Initialized
ERROR - 2020-01-10 07:04:17 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-10 07:04:17 --> Config Class Initialized
INFO - 2020-01-10 07:04:17 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:17 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:17 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:17 --> URI Class Initialized
INFO - 2020-01-10 07:04:17 --> Router Class Initialized
INFO - 2020-01-10 07:04:17 --> Output Class Initialized
INFO - 2020-01-10 07:04:17 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:17 --> Input Class Initialized
INFO - 2020-01-10 07:04:17 --> Language Class Initialized
ERROR - 2020-01-10 07:04:17 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-10 07:04:20 --> Config Class Initialized
INFO - 2020-01-10 07:04:20 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:20 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:20 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:20 --> URI Class Initialized
INFO - 2020-01-10 07:04:20 --> Router Class Initialized
INFO - 2020-01-10 07:04:20 --> Output Class Initialized
INFO - 2020-01-10 07:04:20 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:20 --> Input Class Initialized
INFO - 2020-01-10 07:04:20 --> Language Class Initialized
INFO - 2020-01-10 07:04:20 --> Loader Class Initialized
INFO - 2020-01-10 07:04:20 --> Helper loaded: url_helper
INFO - 2020-01-10 07:04:20 --> Database Driver Class Initialized
DEBUG - 2020-01-10 07:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 07:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 07:04:20 --> Controller Class Initialized
INFO - 2020-01-10 07:04:20 --> Model "M_login" initialized
INFO - 2020-01-10 07:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-10 07:04:20 --> Pagination Class Initialized
INFO - 2020-01-10 07:04:20 --> Model "M_show" initialized
INFO - 2020-01-10 07:04:20 --> Helper loaded: form_helper
INFO - 2020-01-10 07:04:20 --> Form Validation Class Initialized
INFO - 2020-01-10 07:04:20 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 07:04:20 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-10 07:04:20 --> Final output sent to browser
DEBUG - 2020-01-10 07:04:20 --> Total execution time: 0.5442
INFO - 2020-01-10 07:04:20 --> Config Class Initialized
INFO - 2020-01-10 07:04:20 --> Config Class Initialized
INFO - 2020-01-10 07:04:20 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:20 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:20 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:20 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:20 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:20 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:20 --> URI Class Initialized
INFO - 2020-01-10 07:04:20 --> URI Class Initialized
INFO - 2020-01-10 07:04:20 --> Router Class Initialized
INFO - 2020-01-10 07:04:20 --> Router Class Initialized
INFO - 2020-01-10 07:04:20 --> Output Class Initialized
INFO - 2020-01-10 07:04:20 --> Output Class Initialized
INFO - 2020-01-10 07:04:20 --> Security Class Initialized
INFO - 2020-01-10 07:04:20 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:20 --> Input Class Initialized
INFO - 2020-01-10 07:04:20 --> Input Class Initialized
INFO - 2020-01-10 07:04:20 --> Language Class Initialized
INFO - 2020-01-10 07:04:20 --> Language Class Initialized
ERROR - 2020-01-10 07:04:20 --> 404 Page Not Found: Show/assets
ERROR - 2020-01-10 07:04:20 --> 404 Page Not Found: Show/assets
INFO - 2020-01-10 07:04:30 --> Config Class Initialized
INFO - 2020-01-10 07:04:31 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:31 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:31 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:31 --> URI Class Initialized
INFO - 2020-01-10 07:04:31 --> Router Class Initialized
INFO - 2020-01-10 07:04:31 --> Output Class Initialized
INFO - 2020-01-10 07:04:31 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:31 --> Input Class Initialized
INFO - 2020-01-10 07:04:31 --> Language Class Initialized
INFO - 2020-01-10 07:04:31 --> Loader Class Initialized
INFO - 2020-01-10 07:04:31 --> Helper loaded: url_helper
INFO - 2020-01-10 07:04:31 --> Database Driver Class Initialized
DEBUG - 2020-01-10 07:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 07:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 07:04:31 --> Controller Class Initialized
INFO - 2020-01-10 07:04:31 --> Model "M_login" initialized
INFO - 2020-01-10 07:04:31 --> Model "M_tiket" initialized
INFO - 2020-01-10 07:04:31 --> Helper loaded: form_helper
INFO - 2020-01-10 07:04:31 --> Form Validation Class Initialized
INFO - 2020-01-10 07:04:31 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 07:04:31 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-10 07:04:31 --> Final output sent to browser
DEBUG - 2020-01-10 07:04:31 --> Total execution time: 0.5972
INFO - 2020-01-10 07:04:31 --> Config Class Initialized
INFO - 2020-01-10 07:04:31 --> Config Class Initialized
INFO - 2020-01-10 07:04:31 --> Config Class Initialized
INFO - 2020-01-10 07:04:31 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:31 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:31 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:31 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:31 --> Config Class Initialized
INFO - 2020-01-10 07:04:31 --> Config Class Initialized
INFO - 2020-01-10 07:04:31 --> Config Class Initialized
INFO - 2020-01-10 07:04:31 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:31 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:31 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:31 --> Utf8 Class Initialized
DEBUG - 2020-01-10 07:04:31 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:31 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:31 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:31 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:31 --> URI Class Initialized
DEBUG - 2020-01-10 07:04:31 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:31 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:31 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:31 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:31 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:31 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:31 --> URI Class Initialized
INFO - 2020-01-10 07:04:31 --> URI Class Initialized
INFO - 2020-01-10 07:04:31 --> Router Class Initialized
INFO - 2020-01-10 07:04:31 --> URI Class Initialized
INFO - 2020-01-10 07:04:31 --> URI Class Initialized
INFO - 2020-01-10 07:04:31 --> Output Class Initialized
INFO - 2020-01-10 07:04:31 --> Router Class Initialized
INFO - 2020-01-10 07:04:31 --> Router Class Initialized
INFO - 2020-01-10 07:04:31 --> URI Class Initialized
INFO - 2020-01-10 07:04:31 --> Router Class Initialized
INFO - 2020-01-10 07:04:31 --> Router Class Initialized
INFO - 2020-01-10 07:04:31 --> Router Class Initialized
INFO - 2020-01-10 07:04:31 --> Output Class Initialized
INFO - 2020-01-10 07:04:31 --> Security Class Initialized
INFO - 2020-01-10 07:04:31 --> Output Class Initialized
INFO - 2020-01-10 07:04:31 --> Security Class Initialized
INFO - 2020-01-10 07:04:31 --> Security Class Initialized
INFO - 2020-01-10 07:04:31 --> Output Class Initialized
INFO - 2020-01-10 07:04:31 --> Output Class Initialized
INFO - 2020-01-10 07:04:31 --> Output Class Initialized
DEBUG - 2020-01-10 07:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:31 --> Input Class Initialized
DEBUG - 2020-01-10 07:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:31 --> Security Class Initialized
INFO - 2020-01-10 07:04:31 --> Security Class Initialized
INFO - 2020-01-10 07:04:31 --> Security Class Initialized
INFO - 2020-01-10 07:04:31 --> Input Class Initialized
INFO - 2020-01-10 07:04:31 --> Input Class Initialized
INFO - 2020-01-10 07:04:31 --> Language Class Initialized
DEBUG - 2020-01-10 07:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:31 --> Input Class Initialized
INFO - 2020-01-10 07:04:31 --> Input Class Initialized
INFO - 2020-01-10 07:04:31 --> Input Class Initialized
INFO - 2020-01-10 07:04:31 --> Language Class Initialized
INFO - 2020-01-10 07:04:31 --> Language Class Initialized
ERROR - 2020-01-10 07:04:31 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-01-10 07:04:31 --> Language Class Initialized
INFO - 2020-01-10 07:04:31 --> Language Class Initialized
ERROR - 2020-01-10 07:04:31 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-10 07:04:31 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-01-10 07:04:31 --> Language Class Initialized
INFO - 2020-01-10 07:04:31 --> Config Class Initialized
ERROR - 2020-01-10 07:04:31 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-10 07:04:31 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-10 07:04:31 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-01-10 07:04:31 --> Config Class Initialized
INFO - 2020-01-10 07:04:31 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:31 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:31 --> Config Class Initialized
INFO - 2020-01-10 07:04:31 --> Config Class Initialized
INFO - 2020-01-10 07:04:31 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:31 --> Config Class Initialized
INFO - 2020-01-10 07:04:31 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:31 --> Config Class Initialized
DEBUG - 2020-01-10 07:04:31 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:31 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:32 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:32 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:32 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:32 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:32 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:32 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:32 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:32 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:32 --> URI Class Initialized
DEBUG - 2020-01-10 07:04:32 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:32 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:32 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:32 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:32 --> URI Class Initialized
INFO - 2020-01-10 07:04:32 --> URI Class Initialized
INFO - 2020-01-10 07:04:32 --> Router Class Initialized
INFO - 2020-01-10 07:04:32 --> URI Class Initialized
INFO - 2020-01-10 07:04:32 --> Router Class Initialized
INFO - 2020-01-10 07:04:32 --> URI Class Initialized
INFO - 2020-01-10 07:04:32 --> Router Class Initialized
INFO - 2020-01-10 07:04:32 --> Output Class Initialized
INFO - 2020-01-10 07:04:32 --> Router Class Initialized
INFO - 2020-01-10 07:04:32 --> URI Class Initialized
INFO - 2020-01-10 07:04:32 --> Router Class Initialized
INFO - 2020-01-10 07:04:32 --> Output Class Initialized
INFO - 2020-01-10 07:04:32 --> Output Class Initialized
INFO - 2020-01-10 07:04:32 --> Output Class Initialized
INFO - 2020-01-10 07:04:32 --> Security Class Initialized
INFO - 2020-01-10 07:04:32 --> Router Class Initialized
DEBUG - 2020-01-10 07:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:32 --> Security Class Initialized
INFO - 2020-01-10 07:04:32 --> Security Class Initialized
INFO - 2020-01-10 07:04:32 --> Security Class Initialized
INFO - 2020-01-10 07:04:32 --> Output Class Initialized
INFO - 2020-01-10 07:04:32 --> Output Class Initialized
INFO - 2020-01-10 07:04:32 --> Input Class Initialized
DEBUG - 2020-01-10 07:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:32 --> Security Class Initialized
INFO - 2020-01-10 07:04:32 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:32 --> Input Class Initialized
INFO - 2020-01-10 07:04:32 --> Input Class Initialized
INFO - 2020-01-10 07:04:32 --> Input Class Initialized
INFO - 2020-01-10 07:04:32 --> Language Class Initialized
DEBUG - 2020-01-10 07:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 07:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:32 --> Input Class Initialized
INFO - 2020-01-10 07:04:32 --> Input Class Initialized
INFO - 2020-01-10 07:04:32 --> Language Class Initialized
INFO - 2020-01-10 07:04:32 --> Language Class Initialized
ERROR - 2020-01-10 07:04:32 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-10 07:04:32 --> Language Class Initialized
INFO - 2020-01-10 07:04:32 --> Language Class Initialized
INFO - 2020-01-10 07:04:32 --> Language Class Initialized
ERROR - 2020-01-10 07:04:32 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-01-10 07:04:32 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-10 07:04:32 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-10 07:04:32 --> Config Class Initialized
ERROR - 2020-01-10 07:04:32 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-10 07:04:32 --> Loader Class Initialized
INFO - 2020-01-10 07:04:32 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:32 --> Config Class Initialized
INFO - 2020-01-10 07:04:32 --> Helper loaded: url_helper
INFO - 2020-01-10 07:04:32 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:32 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:32 --> Database Driver Class Initialized
INFO - 2020-01-10 07:04:32 --> Utf8 Class Initialized
DEBUG - 2020-01-10 07:04:32 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 07:04:32 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 07:04:32 --> URI Class Initialized
INFO - 2020-01-10 07:04:32 --> Controller Class Initialized
INFO - 2020-01-10 07:04:32 --> URI Class Initialized
INFO - 2020-01-10 07:04:32 --> Router Class Initialized
INFO - 2020-01-10 07:04:32 --> Model "M_login" initialized
INFO - 2020-01-10 07:04:32 --> Router Class Initialized
INFO - 2020-01-10 07:04:32 --> Output Class Initialized
INFO - 2020-01-10 07:04:32 --> Model "M_tiket" initialized
INFO - 2020-01-10 07:04:32 --> Security Class Initialized
INFO - 2020-01-10 07:04:32 --> Output Class Initialized
DEBUG - 2020-01-10 07:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:32 --> Security Class Initialized
INFO - 2020-01-10 07:04:32 --> Helper loaded: form_helper
INFO - 2020-01-10 07:04:32 --> Form Validation Class Initialized
INFO - 2020-01-10 07:04:32 --> Input Class Initialized
DEBUG - 2020-01-10 07:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:32 --> Input Class Initialized
INFO - 2020-01-10 07:04:32 --> Language Class Initialized
INFO - 2020-01-10 07:04:32 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 07:04:32 --> Language Class Initialized
ERROR - 2020-01-10 07:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-01-10 07:04:32 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-10 07:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2020-01-10 07:04:32 --> Loader Class Initialized
INFO - 2020-01-10 07:04:32 --> Config Class Initialized
ERROR - 2020-01-10 07:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-10 07:04:32 --> Helper loaded: url_helper
INFO - 2020-01-10 07:04:32 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:32 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-10 07:04:32 --> Database Driver Class Initialized
INFO - 2020-01-10 07:04:32 --> Final output sent to browser
DEBUG - 2020-01-10 07:04:32 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 07:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-01-10 07:04:32 --> Total execution time: 0.5209
INFO - 2020-01-10 07:04:32 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 07:04:32 --> URI Class Initialized
INFO - 2020-01-10 07:04:32 --> Controller Class Initialized
INFO - 2020-01-10 07:04:32 --> Router Class Initialized
INFO - 2020-01-10 07:04:32 --> Model "M_login" initialized
INFO - 2020-01-10 07:04:32 --> Output Class Initialized
INFO - 2020-01-10 07:04:32 --> Model "M_tiket" initialized
INFO - 2020-01-10 07:04:32 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:32 --> Helper loaded: form_helper
INFO - 2020-01-10 07:04:32 --> Input Class Initialized
INFO - 2020-01-10 07:04:32 --> Form Validation Class Initialized
INFO - 2020-01-10 07:04:32 --> Language Class Initialized
INFO - 2020-01-10 07:04:32 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-10 07:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2020-01-10 07:04:32 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-10 07:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-01-10 07:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-10 07:04:32 --> Config Class Initialized
INFO - 2020-01-10 07:04:32 --> Hooks Class Initialized
INFO - 2020-01-10 07:04:32 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-10 07:04:32 --> Final output sent to browser
DEBUG - 2020-01-10 07:04:32 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:32 --> Utf8 Class Initialized
DEBUG - 2020-01-10 07:04:32 --> Total execution time: 0.5053
INFO - 2020-01-10 07:04:32 --> URI Class Initialized
INFO - 2020-01-10 07:04:32 --> Router Class Initialized
INFO - 2020-01-10 07:04:32 --> Output Class Initialized
INFO - 2020-01-10 07:04:32 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:32 --> Input Class Initialized
INFO - 2020-01-10 07:04:32 --> Language Class Initialized
ERROR - 2020-01-10 07:04:32 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-10 07:04:32 --> Config Class Initialized
INFO - 2020-01-10 07:04:32 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:32 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:32 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:33 --> URI Class Initialized
INFO - 2020-01-10 07:04:33 --> Router Class Initialized
INFO - 2020-01-10 07:04:33 --> Output Class Initialized
INFO - 2020-01-10 07:04:33 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:33 --> Input Class Initialized
INFO - 2020-01-10 07:04:33 --> Language Class Initialized
ERROR - 2020-01-10 07:04:33 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-10 07:04:33 --> Config Class Initialized
INFO - 2020-01-10 07:04:33 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:33 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:33 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:33 --> URI Class Initialized
INFO - 2020-01-10 07:04:33 --> Router Class Initialized
INFO - 2020-01-10 07:04:33 --> Output Class Initialized
INFO - 2020-01-10 07:04:33 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:33 --> Input Class Initialized
INFO - 2020-01-10 07:04:33 --> Language Class Initialized
ERROR - 2020-01-10 07:04:33 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-10 07:04:33 --> Config Class Initialized
INFO - 2020-01-10 07:04:33 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:33 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:33 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:33 --> URI Class Initialized
INFO - 2020-01-10 07:04:33 --> Router Class Initialized
INFO - 2020-01-10 07:04:33 --> Output Class Initialized
INFO - 2020-01-10 07:04:33 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:33 --> Input Class Initialized
INFO - 2020-01-10 07:04:33 --> Language Class Initialized
ERROR - 2020-01-10 07:04:33 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-10 07:04:33 --> Config Class Initialized
INFO - 2020-01-10 07:04:33 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:33 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:33 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:33 --> URI Class Initialized
INFO - 2020-01-10 07:04:33 --> Router Class Initialized
INFO - 2020-01-10 07:04:33 --> Output Class Initialized
INFO - 2020-01-10 07:04:33 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:33 --> Input Class Initialized
INFO - 2020-01-10 07:04:33 --> Language Class Initialized
ERROR - 2020-01-10 07:04:33 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-10 07:04:33 --> Config Class Initialized
INFO - 2020-01-10 07:04:33 --> Hooks Class Initialized
DEBUG - 2020-01-10 07:04:33 --> UTF-8 Support Enabled
INFO - 2020-01-10 07:04:33 --> Utf8 Class Initialized
INFO - 2020-01-10 07:04:33 --> URI Class Initialized
INFO - 2020-01-10 07:04:33 --> Router Class Initialized
INFO - 2020-01-10 07:04:33 --> Output Class Initialized
INFO - 2020-01-10 07:04:33 --> Security Class Initialized
DEBUG - 2020-01-10 07:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 07:04:34 --> Input Class Initialized
INFO - 2020-01-10 07:04:34 --> Language Class Initialized
ERROR - 2020-01-10 07:04:34 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-10 08:17:39 --> Config Class Initialized
INFO - 2020-01-10 08:17:39 --> Hooks Class Initialized
DEBUG - 2020-01-10 08:17:39 --> UTF-8 Support Enabled
INFO - 2020-01-10 08:17:39 --> Utf8 Class Initialized
INFO - 2020-01-10 08:17:39 --> URI Class Initialized
DEBUG - 2020-01-10 08:17:39 --> No URI present. Default controller set.
INFO - 2020-01-10 08:17:39 --> Router Class Initialized
INFO - 2020-01-10 08:17:40 --> Output Class Initialized
INFO - 2020-01-10 08:17:40 --> Security Class Initialized
DEBUG - 2020-01-10 08:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 08:17:40 --> Input Class Initialized
INFO - 2020-01-10 08:17:40 --> Language Class Initialized
INFO - 2020-01-10 08:17:40 --> Loader Class Initialized
INFO - 2020-01-10 08:17:40 --> Helper loaded: url_helper
INFO - 2020-01-10 08:17:40 --> Database Driver Class Initialized
DEBUG - 2020-01-10 08:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 08:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 08:17:40 --> Controller Class Initialized
INFO - 2020-01-10 08:17:40 --> Model "M_login" initialized
INFO - 2020-01-10 08:17:40 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2020-01-10 08:17:40 --> Final output sent to browser
DEBUG - 2020-01-10 08:17:40 --> Total execution time: 0.8859
INFO - 2020-01-10 08:17:44 --> Config Class Initialized
INFO - 2020-01-10 08:17:44 --> Hooks Class Initialized
DEBUG - 2020-01-10 08:17:44 --> UTF-8 Support Enabled
INFO - 2020-01-10 08:17:44 --> Utf8 Class Initialized
INFO - 2020-01-10 08:17:44 --> URI Class Initialized
INFO - 2020-01-10 08:17:44 --> Router Class Initialized
INFO - 2020-01-10 08:17:44 --> Output Class Initialized
INFO - 2020-01-10 08:17:44 --> Security Class Initialized
DEBUG - 2020-01-10 08:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 08:17:44 --> Input Class Initialized
INFO - 2020-01-10 08:17:44 --> Language Class Initialized
INFO - 2020-01-10 08:17:44 --> Loader Class Initialized
INFO - 2020-01-10 08:17:44 --> Helper loaded: url_helper
INFO - 2020-01-10 08:17:44 --> Database Driver Class Initialized
DEBUG - 2020-01-10 08:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 08:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 08:17:44 --> Controller Class Initialized
INFO - 2020-01-10 08:17:44 --> Model "M_login" initialized
INFO - 2020-01-10 08:17:45 --> Config Class Initialized
INFO - 2020-01-10 08:17:45 --> Hooks Class Initialized
DEBUG - 2020-01-10 08:17:45 --> UTF-8 Support Enabled
INFO - 2020-01-10 08:17:45 --> Utf8 Class Initialized
INFO - 2020-01-10 08:17:45 --> URI Class Initialized
INFO - 2020-01-10 08:17:45 --> Router Class Initialized
INFO - 2020-01-10 08:17:45 --> Output Class Initialized
INFO - 2020-01-10 08:17:45 --> Security Class Initialized
DEBUG - 2020-01-10 08:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 08:17:45 --> Input Class Initialized
INFO - 2020-01-10 08:17:45 --> Language Class Initialized
INFO - 2020-01-10 08:17:45 --> Loader Class Initialized
INFO - 2020-01-10 08:17:45 --> Helper loaded: url_helper
INFO - 2020-01-10 08:17:45 --> Database Driver Class Initialized
DEBUG - 2020-01-10 08:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 08:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 08:17:45 --> Controller Class Initialized
INFO - 2020-01-10 08:17:45 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 08:17:45 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2020-01-10 08:17:45 --> Final output sent to browser
DEBUG - 2020-01-10 08:17:45 --> Total execution time: 0.4058
INFO - 2020-01-10 08:17:45 --> Config Class Initialized
INFO - 2020-01-10 08:17:45 --> Config Class Initialized
INFO - 2020-01-10 08:17:45 --> Hooks Class Initialized
INFO - 2020-01-10 08:17:45 --> Hooks Class Initialized
DEBUG - 2020-01-10 08:17:45 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 08:17:45 --> UTF-8 Support Enabled
INFO - 2020-01-10 08:17:45 --> Utf8 Class Initialized
INFO - 2020-01-10 08:17:45 --> Utf8 Class Initialized
INFO - 2020-01-10 08:17:45 --> URI Class Initialized
INFO - 2020-01-10 08:17:45 --> URI Class Initialized
INFO - 2020-01-10 08:17:45 --> Router Class Initialized
INFO - 2020-01-10 08:17:45 --> Router Class Initialized
INFO - 2020-01-10 08:17:45 --> Output Class Initialized
INFO - 2020-01-10 08:17:45 --> Output Class Initialized
INFO - 2020-01-10 08:17:45 --> Security Class Initialized
INFO - 2020-01-10 08:17:45 --> Security Class Initialized
DEBUG - 2020-01-10 08:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 08:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 08:17:45 --> Input Class Initialized
INFO - 2020-01-10 08:17:45 --> Input Class Initialized
INFO - 2020-01-10 08:17:45 --> Language Class Initialized
INFO - 2020-01-10 08:17:45 --> Language Class Initialized
ERROR - 2020-01-10 08:17:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-10 08:17:46 --> 404 Page Not Found: Assets/js
INFO - 2020-01-10 08:17:46 --> Config Class Initialized
INFO - 2020-01-10 08:17:46 --> Hooks Class Initialized
DEBUG - 2020-01-10 08:17:46 --> UTF-8 Support Enabled
INFO - 2020-01-10 08:17:46 --> Utf8 Class Initialized
INFO - 2020-01-10 08:17:46 --> URI Class Initialized
INFO - 2020-01-10 08:17:46 --> Router Class Initialized
INFO - 2020-01-10 08:17:46 --> Output Class Initialized
INFO - 2020-01-10 08:17:46 --> Security Class Initialized
DEBUG - 2020-01-10 08:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 08:17:46 --> Input Class Initialized
INFO - 2020-01-10 08:17:46 --> Language Class Initialized
ERROR - 2020-01-10 08:17:46 --> 404 Page Not Found: Assets/js
INFO - 2020-01-10 08:17:48 --> Config Class Initialized
INFO - 2020-01-10 08:17:48 --> Hooks Class Initialized
DEBUG - 2020-01-10 08:17:48 --> UTF-8 Support Enabled
INFO - 2020-01-10 08:17:48 --> Utf8 Class Initialized
INFO - 2020-01-10 08:17:48 --> URI Class Initialized
INFO - 2020-01-10 08:17:48 --> Router Class Initialized
INFO - 2020-01-10 08:17:48 --> Output Class Initialized
INFO - 2020-01-10 08:17:48 --> Security Class Initialized
DEBUG - 2020-01-10 08:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 08:17:48 --> Input Class Initialized
INFO - 2020-01-10 08:17:48 --> Language Class Initialized
INFO - 2020-01-10 08:17:48 --> Loader Class Initialized
INFO - 2020-01-10 08:17:48 --> Helper loaded: url_helper
INFO - 2020-01-10 08:17:48 --> Database Driver Class Initialized
DEBUG - 2020-01-10 08:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 08:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 08:17:48 --> Controller Class Initialized
INFO - 2020-01-10 08:17:48 --> Model "M_login" initialized
INFO - 2020-01-10 08:17:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-10 08:17:48 --> Pagination Class Initialized
INFO - 2020-01-10 08:17:48 --> Model "M_show" initialized
INFO - 2020-01-10 08:17:48 --> Helper loaded: form_helper
INFO - 2020-01-10 08:17:48 --> Form Validation Class Initialized
INFO - 2020-01-10 08:17:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 08:17:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-10 08:17:48 --> Final output sent to browser
DEBUG - 2020-01-10 08:17:48 --> Total execution time: 0.6783
INFO - 2020-01-10 08:17:48 --> Config Class Initialized
INFO - 2020-01-10 08:17:48 --> Config Class Initialized
INFO - 2020-01-10 08:17:48 --> Hooks Class Initialized
INFO - 2020-01-10 08:17:48 --> Hooks Class Initialized
DEBUG - 2020-01-10 08:17:48 --> UTF-8 Support Enabled
DEBUG - 2020-01-10 08:17:48 --> UTF-8 Support Enabled
INFO - 2020-01-10 08:17:48 --> Utf8 Class Initialized
INFO - 2020-01-10 08:17:48 --> Utf8 Class Initialized
INFO - 2020-01-10 08:17:48 --> URI Class Initialized
INFO - 2020-01-10 08:17:48 --> URI Class Initialized
INFO - 2020-01-10 08:17:49 --> Router Class Initialized
INFO - 2020-01-10 08:17:49 --> Router Class Initialized
INFO - 2020-01-10 08:17:49 --> Output Class Initialized
INFO - 2020-01-10 08:17:49 --> Output Class Initialized
INFO - 2020-01-10 08:17:49 --> Security Class Initialized
INFO - 2020-01-10 08:17:49 --> Security Class Initialized
DEBUG - 2020-01-10 08:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-10 08:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 08:17:49 --> Input Class Initialized
INFO - 2020-01-10 08:17:49 --> Input Class Initialized
INFO - 2020-01-10 08:17:49 --> Language Class Initialized
INFO - 2020-01-10 08:17:49 --> Language Class Initialized
ERROR - 2020-01-10 08:17:49 --> 404 Page Not Found: Show/assets
ERROR - 2020-01-10 08:17:49 --> 404 Page Not Found: Show/assets
INFO - 2020-01-10 08:17:54 --> Config Class Initialized
INFO - 2020-01-10 08:17:54 --> Hooks Class Initialized
DEBUG - 2020-01-10 08:17:54 --> UTF-8 Support Enabled
INFO - 2020-01-10 08:17:54 --> Utf8 Class Initialized
INFO - 2020-01-10 08:17:54 --> URI Class Initialized
INFO - 2020-01-10 08:17:55 --> Router Class Initialized
INFO - 2020-01-10 08:17:55 --> Output Class Initialized
INFO - 2020-01-10 08:17:55 --> Security Class Initialized
DEBUG - 2020-01-10 08:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 08:17:55 --> Input Class Initialized
INFO - 2020-01-10 08:17:55 --> Language Class Initialized
INFO - 2020-01-10 08:17:55 --> Loader Class Initialized
INFO - 2020-01-10 08:17:55 --> Helper loaded: url_helper
INFO - 2020-01-10 08:17:55 --> Database Driver Class Initialized
DEBUG - 2020-01-10 08:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 08:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 08:17:55 --> Controller Class Initialized
INFO - 2020-01-10 08:17:55 --> Model "M_login" initialized
INFO - 2020-01-10 08:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-10 08:17:55 --> Pagination Class Initialized
INFO - 2020-01-10 08:17:55 --> Model "M_show" initialized
INFO - 2020-01-10 08:17:55 --> Helper loaded: form_helper
INFO - 2020-01-10 08:17:55 --> Form Validation Class Initialized
INFO - 2020-01-10 08:17:55 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 08:17:55 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-10 08:17:55 --> Final output sent to browser
DEBUG - 2020-01-10 08:17:55 --> Total execution time: 0.4869
INFO - 2020-01-10 08:45:09 --> Config Class Initialized
INFO - 2020-01-10 08:45:09 --> Hooks Class Initialized
DEBUG - 2020-01-10 08:45:09 --> UTF-8 Support Enabled
INFO - 2020-01-10 08:45:09 --> Utf8 Class Initialized
INFO - 2020-01-10 08:45:10 --> URI Class Initialized
INFO - 2020-01-10 08:45:10 --> Router Class Initialized
INFO - 2020-01-10 08:45:10 --> Output Class Initialized
INFO - 2020-01-10 08:45:10 --> Security Class Initialized
DEBUG - 2020-01-10 08:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 08:45:10 --> Input Class Initialized
INFO - 2020-01-10 08:45:10 --> Language Class Initialized
INFO - 2020-01-10 08:45:10 --> Loader Class Initialized
INFO - 2020-01-10 08:45:10 --> Helper loaded: url_helper
INFO - 2020-01-10 08:45:10 --> Database Driver Class Initialized
DEBUG - 2020-01-10 08:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 08:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 08:45:11 --> Controller Class Initialized
INFO - 2020-01-10 08:45:11 --> Model "M_login" initialized
INFO - 2020-01-10 08:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-10 08:45:11 --> Pagination Class Initialized
INFO - 2020-01-10 08:45:11 --> Model "M_show" initialized
INFO - 2020-01-10 08:45:11 --> Helper loaded: form_helper
INFO - 2020-01-10 08:45:11 --> Form Validation Class Initialized
INFO - 2020-01-10 08:45:12 --> Config Class Initialized
INFO - 2020-01-10 08:45:12 --> Hooks Class Initialized
DEBUG - 2020-01-10 08:45:12 --> UTF-8 Support Enabled
INFO - 2020-01-10 08:45:12 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 08:45:12 --> Utf8 Class Initialized
INFO - 2020-01-10 08:45:12 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-10 08:45:12 --> Final output sent to browser
INFO - 2020-01-10 08:45:12 --> URI Class Initialized
DEBUG - 2020-01-10 08:45:12 --> Total execution time: 2.6043
INFO - 2020-01-10 08:45:12 --> Router Class Initialized
INFO - 2020-01-10 08:45:12 --> Output Class Initialized
INFO - 2020-01-10 08:45:12 --> Security Class Initialized
DEBUG - 2020-01-10 08:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 08:45:12 --> Input Class Initialized
INFO - 2020-01-10 08:45:12 --> Language Class Initialized
INFO - 2020-01-10 08:45:12 --> Loader Class Initialized
INFO - 2020-01-10 08:45:12 --> Helper loaded: url_helper
INFO - 2020-01-10 08:45:12 --> Database Driver Class Initialized
DEBUG - 2020-01-10 08:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 08:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 08:45:12 --> Controller Class Initialized
INFO - 2020-01-10 08:45:12 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 08:45:12 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2020-01-10 08:45:12 --> Final output sent to browser
DEBUG - 2020-01-10 08:45:12 --> Total execution time: 0.5015
INFO - 2020-01-10 08:45:13 --> Config Class Initialized
INFO - 2020-01-10 08:45:13 --> Hooks Class Initialized
DEBUG - 2020-01-10 08:45:13 --> UTF-8 Support Enabled
INFO - 2020-01-10 08:45:13 --> Utf8 Class Initialized
INFO - 2020-01-10 08:45:13 --> URI Class Initialized
INFO - 2020-01-10 08:45:13 --> Router Class Initialized
INFO - 2020-01-10 08:45:13 --> Output Class Initialized
INFO - 2020-01-10 08:45:13 --> Security Class Initialized
DEBUG - 2020-01-10 08:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 08:45:13 --> Input Class Initialized
INFO - 2020-01-10 08:45:13 --> Language Class Initialized
ERROR - 2020-01-10 08:45:13 --> 404 Page Not Found: Assets/js
INFO - 2020-01-10 09:13:48 --> Config Class Initialized
INFO - 2020-01-10 09:13:48 --> Hooks Class Initialized
DEBUG - 2020-01-10 09:13:48 --> UTF-8 Support Enabled
INFO - 2020-01-10 09:13:48 --> Utf8 Class Initialized
INFO - 2020-01-10 09:13:48 --> URI Class Initialized
INFO - 2020-01-10 09:13:48 --> Router Class Initialized
INFO - 2020-01-10 09:13:49 --> Output Class Initialized
INFO - 2020-01-10 09:13:49 --> Security Class Initialized
DEBUG - 2020-01-10 09:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-10 09:13:49 --> Input Class Initialized
INFO - 2020-01-10 09:13:49 --> Language Class Initialized
INFO - 2020-01-10 09:13:49 --> Loader Class Initialized
INFO - 2020-01-10 09:13:49 --> Helper loaded: url_helper
INFO - 2020-01-10 09:13:49 --> Database Driver Class Initialized
DEBUG - 2020-01-10 09:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-10 09:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-10 09:13:49 --> Controller Class Initialized
INFO - 2020-01-10 09:13:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-10 09:13:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2020-01-10 09:13:50 --> Final output sent to browser
DEBUG - 2020-01-10 09:13:50 --> Total execution time: 1.8346
