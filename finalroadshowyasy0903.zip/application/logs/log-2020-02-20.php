<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-20 08:39:19 --> Config Class Initialized
INFO - 2020-02-20 08:39:19 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:19 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:19 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:19 --> URI Class Initialized
DEBUG - 2020-02-20 08:39:20 --> No URI present. Default controller set.
INFO - 2020-02-20 08:39:20 --> Router Class Initialized
INFO - 2020-02-20 08:39:20 --> Output Class Initialized
INFO - 2020-02-20 08:39:20 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:20 --> Input Class Initialized
INFO - 2020-02-20 08:39:21 --> Language Class Initialized
INFO - 2020-02-20 08:39:21 --> Loader Class Initialized
INFO - 2020-02-20 08:39:21 --> Helper loaded: url_helper
INFO - 2020-02-20 08:39:21 --> Helper loaded: string_helper
INFO - 2020-02-20 08:39:21 --> Database Driver Class Initialized
DEBUG - 2020-02-20 08:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-20 08:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-20 08:39:22 --> Controller Class Initialized
INFO - 2020-02-20 08:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 08:39:22 --> Pagination Class Initialized
INFO - 2020-02-20 08:39:22 --> Model "M_show" initialized
INFO - 2020-02-20 08:39:23 --> Helper loaded: form_helper
INFO - 2020-02-20 08:39:23 --> Form Validation Class Initialized
INFO - 2020-02-20 08:39:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-20 08:39:23 --> Config Class Initialized
INFO - 2020-02-20 08:39:23 --> Final output sent to browser
INFO - 2020-02-20 08:39:23 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 08:39:24 --> Total execution time: 4.6767
INFO - 2020-02-20 08:39:24 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:24 --> URI Class Initialized
DEBUG - 2020-02-20 08:39:24 --> No URI present. Default controller set.
INFO - 2020-02-20 08:39:24 --> Router Class Initialized
INFO - 2020-02-20 08:39:24 --> Output Class Initialized
INFO - 2020-02-20 08:39:24 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:24 --> Input Class Initialized
INFO - 2020-02-20 08:39:24 --> Language Class Initialized
INFO - 2020-02-20 08:39:24 --> Loader Class Initialized
INFO - 2020-02-20 08:39:24 --> Helper loaded: url_helper
INFO - 2020-02-20 08:39:24 --> Helper loaded: string_helper
INFO - 2020-02-20 08:39:24 --> Database Driver Class Initialized
DEBUG - 2020-02-20 08:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-20 08:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-20 08:39:24 --> Controller Class Initialized
INFO - 2020-02-20 08:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 08:39:24 --> Pagination Class Initialized
INFO - 2020-02-20 08:39:24 --> Model "M_show" initialized
INFO - 2020-02-20 08:39:24 --> Helper loaded: form_helper
INFO - 2020-02-20 08:39:24 --> Form Validation Class Initialized
INFO - 2020-02-20 08:39:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-20 08:39:24 --> Final output sent to browser
DEBUG - 2020-02-20 08:39:24 --> Total execution time: 0.6046
INFO - 2020-02-20 08:39:31 --> Config Class Initialized
INFO - 2020-02-20 08:39:31 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:31 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:31 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:31 --> URI Class Initialized
INFO - 2020-02-20 08:39:32 --> Router Class Initialized
INFO - 2020-02-20 08:39:32 --> Output Class Initialized
INFO - 2020-02-20 08:39:32 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:32 --> Input Class Initialized
INFO - 2020-02-20 08:39:32 --> Language Class Initialized
INFO - 2020-02-20 08:39:32 --> Loader Class Initialized
INFO - 2020-02-20 08:39:32 --> Helper loaded: url_helper
INFO - 2020-02-20 08:39:32 --> Helper loaded: string_helper
INFO - 2020-02-20 08:39:32 --> Database Driver Class Initialized
DEBUG - 2020-02-20 08:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-20 08:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-20 08:39:32 --> Controller Class Initialized
INFO - 2020-02-20 08:39:32 --> Model "M_tiket" initialized
INFO - 2020-02-20 08:39:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-20 08:39:33 --> Model "M_pesan" initialized
INFO - 2020-02-20 08:39:33 --> Helper loaded: form_helper
INFO - 2020-02-20 08:39:33 --> Form Validation Class Initialized
INFO - 2020-02-20 08:39:33 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-20 08:39:33 --> Final output sent to browser
DEBUG - 2020-02-20 08:39:33 --> Total execution time: 2.0157
INFO - 2020-02-20 08:39:33 --> Config Class Initialized
INFO - 2020-02-20 08:39:33 --> Config Class Initialized
INFO - 2020-02-20 08:39:33 --> Config Class Initialized
INFO - 2020-02-20 08:39:33 --> Hooks Class Initialized
INFO - 2020-02-20 08:39:33 --> Hooks Class Initialized
INFO - 2020-02-20 08:39:33 --> Config Class Initialized
INFO - 2020-02-20 08:39:33 --> Hooks Class Initialized
INFO - 2020-02-20 08:39:33 --> Config Class Initialized
INFO - 2020-02-20 08:39:33 --> Config Class Initialized
INFO - 2020-02-20 08:39:33 --> Hooks Class Initialized
INFO - 2020-02-20 08:39:33 --> Hooks Class Initialized
INFO - 2020-02-20 08:39:33 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 08:39:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 08:39:33 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
DEBUG - 2020-02-20 08:39:34 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
DEBUG - 2020-02-20 08:39:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 08:39:34 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
INFO - 2020-02-20 08:39:34 --> Loader Class Initialized
INFO - 2020-02-20 08:39:34 --> Helper loaded: url_helper
ERROR - 2020-02-20 08:39:34 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-20 08:39:34 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-20 08:39:34 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-20 08:39:34 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-20 08:39:34 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-20 08:39:34 --> Helper loaded: string_helper
INFO - 2020-02-20 08:39:34 --> Database Driver Class Initialized
INFO - 2020-02-20 08:39:34 --> Config Class Initialized
INFO - 2020-02-20 08:39:34 --> Hooks Class Initialized
INFO - 2020-02-20 08:39:34 --> Config Class Initialized
INFO - 2020-02-20 08:39:34 --> Config Class Initialized
INFO - 2020-02-20 08:39:34 --> Config Class Initialized
DEBUG - 2020-02-20 08:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-20 08:39:34 --> Config Class Initialized
INFO - 2020-02-20 08:39:34 --> Hooks Class Initialized
INFO - 2020-02-20 08:39:34 --> Hooks Class Initialized
INFO - 2020-02-20 08:39:34 --> Hooks Class Initialized
INFO - 2020-02-20 08:39:34 --> Hooks Class Initialized
INFO - 2020-02-20 08:39:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-20 08:39:34 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:34 --> Controller Class Initialized
DEBUG - 2020-02-20 08:39:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 08:39:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 08:39:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 08:39:34 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:34 --> Model "M_tiket" initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> Model "M_pesan" initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
INFO - 2020-02-20 08:39:34 --> Helper loaded: form_helper
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
INFO - 2020-02-20 08:39:34 --> Form Validation Class Initialized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-20 08:39:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
INFO - 2020-02-20 08:39:34 --> Loader Class Initialized
INFO - 2020-02-20 08:39:34 --> Helper loaded: url_helper
ERROR - 2020-02-20 08:39:34 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-20 08:39:34 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-20 08:39:34 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-20 08:39:34 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-20 08:39:34 --> Helper loaded: string_helper
ERROR - 2020-02-20 08:39:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-20 08:39:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-20 08:39:34 --> Config Class Initialized
INFO - 2020-02-20 08:39:34 --> Database Driver Class Initialized
INFO - 2020-02-20 08:39:34 --> Config Class Initialized
INFO - 2020-02-20 08:39:34 --> Hooks Class Initialized
INFO - 2020-02-20 08:39:34 --> Config Class Initialized
INFO - 2020-02-20 08:39:34 --> Final output sent to browser
INFO - 2020-02-20 08:39:34 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-20 08:39:34 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:34 --> Total execution time: 0.7687
DEBUG - 2020-02-20 08:39:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 08:39:34 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-20 08:39:34 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:34 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:34 --> Controller Class Initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> Model "M_tiket" initialized
INFO - 2020-02-20 08:39:34 --> URI Class Initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-20 08:39:34 --> Router Class Initialized
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
INFO - 2020-02-20 08:39:34 --> Model "M_pesan" initialized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
INFO - 2020-02-20 08:39:34 --> Output Class Initialized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:34 --> Security Class Initialized
INFO - 2020-02-20 08:39:34 --> Helper loaded: form_helper
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
INFO - 2020-02-20 08:39:34 --> Form Validation Class Initialized
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
DEBUG - 2020-02-20 08:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:34 --> Input Class Initialized
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
ERROR - 2020-02-20 08:39:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-20 08:39:34 --> Language Class Initialized
ERROR - 2020-02-20 08:39:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-20 08:39:34 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-20 08:39:34 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-20 08:39:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-20 08:39:34 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-20 08:39:34 --> Final output sent to browser
DEBUG - 2020-02-20 08:39:34 --> Total execution time: 0.5588
INFO - 2020-02-20 08:39:34 --> Config Class Initialized
INFO - 2020-02-20 08:39:35 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:35 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:35 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:35 --> URI Class Initialized
INFO - 2020-02-20 08:39:35 --> Router Class Initialized
INFO - 2020-02-20 08:39:35 --> Output Class Initialized
INFO - 2020-02-20 08:39:35 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:35 --> Input Class Initialized
INFO - 2020-02-20 08:39:35 --> Language Class Initialized
ERROR - 2020-02-20 08:39:35 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-20 08:39:35 --> Config Class Initialized
INFO - 2020-02-20 08:39:35 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:35 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:35 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:35 --> URI Class Initialized
INFO - 2020-02-20 08:39:35 --> Router Class Initialized
INFO - 2020-02-20 08:39:35 --> Output Class Initialized
INFO - 2020-02-20 08:39:35 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:35 --> Input Class Initialized
INFO - 2020-02-20 08:39:35 --> Language Class Initialized
ERROR - 2020-02-20 08:39:35 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-20 08:39:35 --> Config Class Initialized
INFO - 2020-02-20 08:39:35 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:35 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:35 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:35 --> URI Class Initialized
INFO - 2020-02-20 08:39:35 --> Router Class Initialized
INFO - 2020-02-20 08:39:35 --> Output Class Initialized
INFO - 2020-02-20 08:39:35 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:35 --> Input Class Initialized
INFO - 2020-02-20 08:39:35 --> Language Class Initialized
ERROR - 2020-02-20 08:39:35 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-20 08:39:35 --> Config Class Initialized
INFO - 2020-02-20 08:39:35 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:35 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:35 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:35 --> URI Class Initialized
INFO - 2020-02-20 08:39:35 --> Router Class Initialized
INFO - 2020-02-20 08:39:35 --> Output Class Initialized
INFO - 2020-02-20 08:39:35 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:35 --> Input Class Initialized
INFO - 2020-02-20 08:39:35 --> Language Class Initialized
ERROR - 2020-02-20 08:39:35 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-20 08:39:35 --> Config Class Initialized
INFO - 2020-02-20 08:39:35 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:35 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:35 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:35 --> URI Class Initialized
INFO - 2020-02-20 08:39:36 --> Router Class Initialized
INFO - 2020-02-20 08:39:36 --> Output Class Initialized
INFO - 2020-02-20 08:39:36 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:36 --> Input Class Initialized
INFO - 2020-02-20 08:39:36 --> Language Class Initialized
ERROR - 2020-02-20 08:39:36 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-20 08:39:36 --> Config Class Initialized
INFO - 2020-02-20 08:39:36 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:36 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:36 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:36 --> URI Class Initialized
INFO - 2020-02-20 08:39:36 --> Router Class Initialized
INFO - 2020-02-20 08:39:36 --> Output Class Initialized
INFO - 2020-02-20 08:39:36 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:36 --> Input Class Initialized
INFO - 2020-02-20 08:39:36 --> Language Class Initialized
ERROR - 2020-02-20 08:39:36 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-20 08:39:36 --> Config Class Initialized
INFO - 2020-02-20 08:39:36 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:36 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:36 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:36 --> URI Class Initialized
INFO - 2020-02-20 08:39:36 --> Router Class Initialized
INFO - 2020-02-20 08:39:36 --> Output Class Initialized
INFO - 2020-02-20 08:39:36 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:36 --> Input Class Initialized
INFO - 2020-02-20 08:39:36 --> Language Class Initialized
ERROR - 2020-02-20 08:39:36 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-20 08:39:36 --> Config Class Initialized
INFO - 2020-02-20 08:39:36 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:39:36 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:39:36 --> Utf8 Class Initialized
INFO - 2020-02-20 08:39:36 --> URI Class Initialized
INFO - 2020-02-20 08:39:36 --> Router Class Initialized
INFO - 2020-02-20 08:39:36 --> Output Class Initialized
INFO - 2020-02-20 08:39:36 --> Security Class Initialized
DEBUG - 2020-02-20 08:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:39:36 --> Input Class Initialized
INFO - 2020-02-20 08:39:36 --> Language Class Initialized
ERROR - 2020-02-20 08:39:36 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-20 08:40:08 --> Config Class Initialized
INFO - 2020-02-20 08:40:08 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:40:08 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:40:08 --> Utf8 Class Initialized
INFO - 2020-02-20 08:40:08 --> URI Class Initialized
INFO - 2020-02-20 08:40:08 --> Router Class Initialized
INFO - 2020-02-20 08:40:08 --> Output Class Initialized
INFO - 2020-02-20 08:40:08 --> Security Class Initialized
DEBUG - 2020-02-20 08:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:40:08 --> Input Class Initialized
INFO - 2020-02-20 08:40:08 --> Language Class Initialized
INFO - 2020-02-20 08:40:08 --> Loader Class Initialized
INFO - 2020-02-20 08:40:08 --> Helper loaded: url_helper
INFO - 2020-02-20 08:40:08 --> Helper loaded: string_helper
INFO - 2020-02-20 08:40:08 --> Database Driver Class Initialized
DEBUG - 2020-02-20 08:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-20 08:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-20 08:40:08 --> Controller Class Initialized
INFO - 2020-02-20 08:40:08 --> Model "M_tiket" initialized
INFO - 2020-02-20 08:40:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-20 08:40:08 --> Model "M_pesan" initialized
INFO - 2020-02-20 08:40:08 --> Helper loaded: form_helper
INFO - 2020-02-20 08:40:09 --> Form Validation Class Initialized
INFO - 2020-02-20 08:40:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-20 08:40:09 --> Final output sent to browser
DEBUG - 2020-02-20 08:40:09 --> Total execution time: 1.0398
INFO - 2020-02-20 08:40:25 --> Config Class Initialized
INFO - 2020-02-20 08:40:25 --> Hooks Class Initialized
DEBUG - 2020-02-20 08:40:25 --> UTF-8 Support Enabled
INFO - 2020-02-20 08:40:25 --> Utf8 Class Initialized
INFO - 2020-02-20 08:40:25 --> URI Class Initialized
INFO - 2020-02-20 08:40:25 --> Router Class Initialized
INFO - 2020-02-20 08:40:26 --> Output Class Initialized
INFO - 2020-02-20 08:40:26 --> Security Class Initialized
DEBUG - 2020-02-20 08:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 08:40:26 --> Input Class Initialized
INFO - 2020-02-20 08:40:26 --> Language Class Initialized
INFO - 2020-02-20 08:40:26 --> Loader Class Initialized
INFO - 2020-02-20 08:40:26 --> Helper loaded: url_helper
INFO - 2020-02-20 08:40:26 --> Helper loaded: string_helper
INFO - 2020-02-20 08:40:26 --> Database Driver Class Initialized
DEBUG - 2020-02-20 08:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-20 08:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-20 08:40:26 --> Controller Class Initialized
INFO - 2020-02-20 08:40:26 --> Model "M_tiket" initialized
INFO - 2020-02-20 08:40:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-20 08:40:26 --> Model "M_pesan" initialized
INFO - 2020-02-20 08:40:26 --> Helper loaded: form_helper
INFO - 2020-02-20 08:40:26 --> Form Validation Class Initialized
ERROR - 2020-02-20 08:40:26 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-20 11:12:55 --> Config Class Initialized
INFO - 2020-02-20 11:12:55 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:12:55 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:12:55 --> Utf8 Class Initialized
INFO - 2020-02-20 11:12:55 --> URI Class Initialized
DEBUG - 2020-02-20 11:12:55 --> No URI present. Default controller set.
INFO - 2020-02-20 11:12:55 --> Router Class Initialized
INFO - 2020-02-20 11:12:55 --> Output Class Initialized
INFO - 2020-02-20 11:12:55 --> Security Class Initialized
DEBUG - 2020-02-20 11:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:12:55 --> Input Class Initialized
INFO - 2020-02-20 11:12:56 --> Language Class Initialized
INFO - 2020-02-20 11:12:56 --> Loader Class Initialized
INFO - 2020-02-20 11:12:56 --> Helper loaded: url_helper
INFO - 2020-02-20 11:12:56 --> Helper loaded: string_helper
INFO - 2020-02-20 11:12:56 --> Database Driver Class Initialized
DEBUG - 2020-02-20 11:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-20 11:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-20 11:12:56 --> Controller Class Initialized
INFO - 2020-02-20 11:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:12:56 --> Pagination Class Initialized
INFO - 2020-02-20 11:12:56 --> Model "M_show" initialized
INFO - 2020-02-20 11:12:56 --> Helper loaded: form_helper
INFO - 2020-02-20 11:12:56 --> Form Validation Class Initialized
INFO - 2020-02-20 11:12:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-20 11:12:56 --> Final output sent to browser
DEBUG - 2020-02-20 11:12:56 --> Total execution time: 1.4828
INFO - 2020-02-20 11:12:59 --> Config Class Initialized
INFO - 2020-02-20 11:12:59 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:12:59 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:12:59 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:00 --> URI Class Initialized
DEBUG - 2020-02-20 11:13:00 --> No URI present. Default controller set.
INFO - 2020-02-20 11:13:00 --> Router Class Initialized
INFO - 2020-02-20 11:13:00 --> Output Class Initialized
INFO - 2020-02-20 11:13:00 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:00 --> Input Class Initialized
INFO - 2020-02-20 11:13:00 --> Language Class Initialized
INFO - 2020-02-20 11:13:00 --> Loader Class Initialized
INFO - 2020-02-20 11:13:00 --> Helper loaded: url_helper
INFO - 2020-02-20 11:13:00 --> Helper loaded: string_helper
INFO - 2020-02-20 11:13:00 --> Database Driver Class Initialized
DEBUG - 2020-02-20 11:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-20 11:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-20 11:13:00 --> Controller Class Initialized
INFO - 2020-02-20 11:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:13:00 --> Pagination Class Initialized
INFO - 2020-02-20 11:13:00 --> Model "M_show" initialized
INFO - 2020-02-20 11:13:00 --> Helper loaded: form_helper
INFO - 2020-02-20 11:13:00 --> Form Validation Class Initialized
INFO - 2020-02-20 11:13:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-20 11:13:00 --> Final output sent to browser
DEBUG - 2020-02-20 11:13:00 --> Total execution time: 0.4434
INFO - 2020-02-20 11:13:04 --> Config Class Initialized
INFO - 2020-02-20 11:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:04 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:04 --> URI Class Initialized
INFO - 2020-02-20 11:13:04 --> Router Class Initialized
INFO - 2020-02-20 11:13:04 --> Output Class Initialized
INFO - 2020-02-20 11:13:04 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:04 --> Input Class Initialized
INFO - 2020-02-20 11:13:04 --> Language Class Initialized
INFO - 2020-02-20 11:13:04 --> Loader Class Initialized
INFO - 2020-02-20 11:13:05 --> Helper loaded: url_helper
INFO - 2020-02-20 11:13:05 --> Helper loaded: string_helper
INFO - 2020-02-20 11:13:05 --> Database Driver Class Initialized
DEBUG - 2020-02-20 11:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-20 11:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-20 11:13:05 --> Controller Class Initialized
INFO - 2020-02-20 11:13:05 --> Model "M_tiket" initialized
INFO - 2020-02-20 11:13:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-20 11:13:05 --> Model "M_pesan" initialized
INFO - 2020-02-20 11:13:05 --> Helper loaded: form_helper
INFO - 2020-02-20 11:13:05 --> Form Validation Class Initialized
INFO - 2020-02-20 11:13:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-20 11:13:05 --> Final output sent to browser
DEBUG - 2020-02-20 11:13:05 --> Total execution time: 0.6070
INFO - 2020-02-20 11:13:05 --> Config Class Initialized
INFO - 2020-02-20 11:13:05 --> Config Class Initialized
INFO - 2020-02-20 11:13:05 --> Config Class Initialized
INFO - 2020-02-20 11:13:05 --> Config Class Initialized
INFO - 2020-02-20 11:13:05 --> Config Class Initialized
INFO - 2020-02-20 11:13:05 --> Hooks Class Initialized
INFO - 2020-02-20 11:13:05 --> Hooks Class Initialized
INFO - 2020-02-20 11:13:05 --> Hooks Class Initialized
INFO - 2020-02-20 11:13:05 --> Hooks Class Initialized
INFO - 2020-02-20 11:13:05 --> Hooks Class Initialized
INFO - 2020-02-20 11:13:05 --> Config Class Initialized
INFO - 2020-02-20 11:13:05 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:05 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:05 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:05 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:05 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:05 --> Utf8 Class Initialized
DEBUG - 2020-02-20 11:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:05 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:05 --> URI Class Initialized
INFO - 2020-02-20 11:13:05 --> URI Class Initialized
INFO - 2020-02-20 11:13:05 --> URI Class Initialized
INFO - 2020-02-20 11:13:05 --> URI Class Initialized
INFO - 2020-02-20 11:13:05 --> URI Class Initialized
INFO - 2020-02-20 11:13:05 --> URI Class Initialized
INFO - 2020-02-20 11:13:05 --> Router Class Initialized
INFO - 2020-02-20 11:13:05 --> Router Class Initialized
INFO - 2020-02-20 11:13:05 --> Router Class Initialized
INFO - 2020-02-20 11:13:05 --> Router Class Initialized
INFO - 2020-02-20 11:13:05 --> Router Class Initialized
INFO - 2020-02-20 11:13:05 --> Router Class Initialized
INFO - 2020-02-20 11:13:05 --> Output Class Initialized
INFO - 2020-02-20 11:13:05 --> Output Class Initialized
INFO - 2020-02-20 11:13:05 --> Output Class Initialized
INFO - 2020-02-20 11:13:05 --> Output Class Initialized
INFO - 2020-02-20 11:13:05 --> Output Class Initialized
INFO - 2020-02-20 11:13:05 --> Security Class Initialized
INFO - 2020-02-20 11:13:05 --> Security Class Initialized
INFO - 2020-02-20 11:13:05 --> Security Class Initialized
INFO - 2020-02-20 11:13:05 --> Output Class Initialized
INFO - 2020-02-20 11:13:05 --> Security Class Initialized
INFO - 2020-02-20 11:13:05 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 11:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 11:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:05 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 11:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:05 --> Input Class Initialized
INFO - 2020-02-20 11:13:05 --> Input Class Initialized
INFO - 2020-02-20 11:13:05 --> Input Class Initialized
INFO - 2020-02-20 11:13:05 --> Input Class Initialized
INFO - 2020-02-20 11:13:05 --> Input Class Initialized
DEBUG - 2020-02-20 11:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:05 --> Input Class Initialized
INFO - 2020-02-20 11:13:05 --> Language Class Initialized
INFO - 2020-02-20 11:13:05 --> Language Class Initialized
INFO - 2020-02-20 11:13:05 --> Language Class Initialized
INFO - 2020-02-20 11:13:05 --> Language Class Initialized
INFO - 2020-02-20 11:13:05 --> Language Class Initialized
INFO - 2020-02-20 11:13:05 --> Language Class Initialized
INFO - 2020-02-20 11:13:05 --> Loader Class Initialized
INFO - 2020-02-20 11:13:05 --> Helper loaded: url_helper
ERROR - 2020-02-20 11:13:05 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-20 11:13:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-20 11:13:05 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-20 11:13:05 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-20 11:13:05 --> Loader Class Initialized
INFO - 2020-02-20 11:13:05 --> Helper loaded: string_helper
INFO - 2020-02-20 11:13:05 --> Helper loaded: url_helper
INFO - 2020-02-20 11:13:05 --> Helper loaded: string_helper
INFO - 2020-02-20 11:13:05 --> Database Driver Class Initialized
INFO - 2020-02-20 11:13:05 --> Config Class Initialized
INFO - 2020-02-20 11:13:05 --> Config Class Initialized
INFO - 2020-02-20 11:13:05 --> Config Class Initialized
INFO - 2020-02-20 11:13:05 --> Hooks Class Initialized
INFO - 2020-02-20 11:13:05 --> Hooks Class Initialized
INFO - 2020-02-20 11:13:05 --> Hooks Class Initialized
INFO - 2020-02-20 11:13:05 --> Config Class Initialized
DEBUG - 2020-02-20 11:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-20 11:13:05 --> Database Driver Class Initialized
INFO - 2020-02-20 11:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-20 11:13:05 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-20 11:13:05 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:05 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:05 --> Controller Class Initialized
INFO - 2020-02-20 11:13:05 --> Utf8 Class Initialized
DEBUG - 2020-02-20 11:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:05 --> Model "M_tiket" initialized
INFO - 2020-02-20 11:13:05 --> URI Class Initialized
INFO - 2020-02-20 11:13:05 --> URI Class Initialized
INFO - 2020-02-20 11:13:05 --> URI Class Initialized
INFO - 2020-02-20 11:13:05 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-20 11:13:05 --> Router Class Initialized
INFO - 2020-02-20 11:13:05 --> Router Class Initialized
INFO - 2020-02-20 11:13:05 --> Router Class Initialized
INFO - 2020-02-20 11:13:05 --> URI Class Initialized
INFO - 2020-02-20 11:13:05 --> Model "M_pesan" initialized
INFO - 2020-02-20 11:13:05 --> Router Class Initialized
INFO - 2020-02-20 11:13:05 --> Output Class Initialized
INFO - 2020-02-20 11:13:05 --> Output Class Initialized
INFO - 2020-02-20 11:13:05 --> Output Class Initialized
INFO - 2020-02-20 11:13:05 --> Security Class Initialized
INFO - 2020-02-20 11:13:05 --> Security Class Initialized
INFO - 2020-02-20 11:13:05 --> Security Class Initialized
INFO - 2020-02-20 11:13:05 --> Output Class Initialized
INFO - 2020-02-20 11:13:05 --> Helper loaded: form_helper
INFO - 2020-02-20 11:13:05 --> Form Validation Class Initialized
DEBUG - 2020-02-20 11:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 11:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:05 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:05 --> Input Class Initialized
INFO - 2020-02-20 11:13:05 --> Input Class Initialized
INFO - 2020-02-20 11:13:05 --> Input Class Initialized
DEBUG - 2020-02-20 11:13:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-20 11:13:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-20 11:13:05 --> Input Class Initialized
INFO - 2020-02-20 11:13:05 --> Language Class Initialized
INFO - 2020-02-20 11:13:05 --> Language Class Initialized
INFO - 2020-02-20 11:13:05 --> Language Class Initialized
ERROR - 2020-02-20 11:13:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-20 11:13:06 --> Language Class Initialized
ERROR - 2020-02-20 11:13:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-20 11:13:06 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-20 11:13:06 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-20 11:13:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-20 11:13:06 --> Final output sent to browser
ERROR - 2020-02-20 11:13:06 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-20 11:13:06 --> Total execution time: 0.5321
INFO - 2020-02-20 11:13:06 --> Config Class Initialized
INFO - 2020-02-20 11:13:06 --> Config Class Initialized
INFO - 2020-02-20 11:13:06 --> Config Class Initialized
INFO - 2020-02-20 11:13:06 --> Hooks Class Initialized
INFO - 2020-02-20 11:13:06 --> Hooks Class Initialized
INFO - 2020-02-20 11:13:06 --> Hooks Class Initialized
INFO - 2020-02-20 11:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-20 11:13:06 --> Config Class Initialized
INFO - 2020-02-20 11:13:06 --> Controller Class Initialized
INFO - 2020-02-20 11:13:06 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:13:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:13:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:06 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:06 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:06 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:06 --> Model "M_tiket" initialized
DEBUG - 2020-02-20 11:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-20 11:13:06 --> URI Class Initialized
INFO - 2020-02-20 11:13:06 --> URI Class Initialized
INFO - 2020-02-20 11:13:06 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:06 --> URI Class Initialized
INFO - 2020-02-20 11:13:06 --> Model "M_pesan" initialized
INFO - 2020-02-20 11:13:06 --> URI Class Initialized
INFO - 2020-02-20 11:13:06 --> Router Class Initialized
INFO - 2020-02-20 11:13:06 --> Router Class Initialized
INFO - 2020-02-20 11:13:06 --> Router Class Initialized
INFO - 2020-02-20 11:13:06 --> Router Class Initialized
INFO - 2020-02-20 11:13:06 --> Output Class Initialized
INFO - 2020-02-20 11:13:06 --> Output Class Initialized
INFO - 2020-02-20 11:13:06 --> Helper loaded: form_helper
INFO - 2020-02-20 11:13:06 --> Output Class Initialized
INFO - 2020-02-20 11:13:06 --> Form Validation Class Initialized
INFO - 2020-02-20 11:13:06 --> Security Class Initialized
INFO - 2020-02-20 11:13:06 --> Security Class Initialized
INFO - 2020-02-20 11:13:06 --> Security Class Initialized
INFO - 2020-02-20 11:13:06 --> Output Class Initialized
DEBUG - 2020-02-20 11:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 11:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 11:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:06 --> Security Class Initialized
ERROR - 2020-02-20 11:13:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-20 11:13:06 --> Input Class Initialized
INFO - 2020-02-20 11:13:06 --> Input Class Initialized
INFO - 2020-02-20 11:13:06 --> Input Class Initialized
ERROR - 2020-02-20 11:13:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
DEBUG - 2020-02-20 11:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:06 --> Input Class Initialized
INFO - 2020-02-20 11:13:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-20 11:13:06 --> Language Class Initialized
INFO - 2020-02-20 11:13:06 --> Language Class Initialized
INFO - 2020-02-20 11:13:06 --> Language Class Initialized
INFO - 2020-02-20 11:13:06 --> Final output sent to browser
INFO - 2020-02-20 11:13:06 --> Language Class Initialized
ERROR - 2020-02-20 11:13:06 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-20 11:13:06 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-20 11:13:06 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-20 11:13:06 --> Total execution time: 0.7055
ERROR - 2020-02-20 11:13:06 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-20 11:13:06 --> Config Class Initialized
INFO - 2020-02-20 11:13:06 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:06 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:06 --> URI Class Initialized
INFO - 2020-02-20 11:13:06 --> Router Class Initialized
INFO - 2020-02-20 11:13:06 --> Output Class Initialized
INFO - 2020-02-20 11:13:06 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:06 --> Input Class Initialized
INFO - 2020-02-20 11:13:06 --> Language Class Initialized
ERROR - 2020-02-20 11:13:06 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-20 11:13:06 --> Config Class Initialized
INFO - 2020-02-20 11:13:06 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:06 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:06 --> URI Class Initialized
INFO - 2020-02-20 11:13:06 --> Router Class Initialized
INFO - 2020-02-20 11:13:06 --> Output Class Initialized
INFO - 2020-02-20 11:13:06 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:06 --> Input Class Initialized
INFO - 2020-02-20 11:13:06 --> Language Class Initialized
ERROR - 2020-02-20 11:13:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-20 11:13:06 --> Config Class Initialized
INFO - 2020-02-20 11:13:06 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:06 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:06 --> URI Class Initialized
INFO - 2020-02-20 11:13:06 --> Router Class Initialized
INFO - 2020-02-20 11:13:06 --> Output Class Initialized
INFO - 2020-02-20 11:13:06 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:06 --> Input Class Initialized
INFO - 2020-02-20 11:13:06 --> Language Class Initialized
ERROR - 2020-02-20 11:13:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-20 11:13:06 --> Config Class Initialized
INFO - 2020-02-20 11:13:06 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:06 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:06 --> URI Class Initialized
INFO - 2020-02-20 11:13:06 --> Router Class Initialized
INFO - 2020-02-20 11:13:07 --> Output Class Initialized
INFO - 2020-02-20 11:13:07 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:07 --> Input Class Initialized
INFO - 2020-02-20 11:13:07 --> Language Class Initialized
ERROR - 2020-02-20 11:13:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-20 11:13:07 --> Config Class Initialized
INFO - 2020-02-20 11:13:07 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:13:07 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:07 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:07 --> URI Class Initialized
INFO - 2020-02-20 11:13:07 --> Router Class Initialized
INFO - 2020-02-20 11:13:07 --> Output Class Initialized
INFO - 2020-02-20 11:13:07 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:07 --> Input Class Initialized
INFO - 2020-02-20 11:13:07 --> Language Class Initialized
ERROR - 2020-02-20 11:13:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-20 11:13:07 --> Config Class Initialized
INFO - 2020-02-20 11:13:07 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:13:07 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:07 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:07 --> URI Class Initialized
INFO - 2020-02-20 11:13:07 --> Router Class Initialized
INFO - 2020-02-20 11:13:07 --> Output Class Initialized
INFO - 2020-02-20 11:13:07 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:07 --> Input Class Initialized
INFO - 2020-02-20 11:13:07 --> Language Class Initialized
ERROR - 2020-02-20 11:13:07 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-20 11:13:07 --> Config Class Initialized
INFO - 2020-02-20 11:13:07 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:13:07 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:07 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:07 --> URI Class Initialized
INFO - 2020-02-20 11:13:07 --> Router Class Initialized
INFO - 2020-02-20 11:13:07 --> Output Class Initialized
INFO - 2020-02-20 11:13:07 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:07 --> Input Class Initialized
INFO - 2020-02-20 11:13:07 --> Language Class Initialized
ERROR - 2020-02-20 11:13:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-20 11:13:07 --> Config Class Initialized
INFO - 2020-02-20 11:13:07 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:13:07 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:07 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:07 --> URI Class Initialized
INFO - 2020-02-20 11:13:07 --> Router Class Initialized
INFO - 2020-02-20 11:13:07 --> Output Class Initialized
INFO - 2020-02-20 11:13:07 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:07 --> Input Class Initialized
INFO - 2020-02-20 11:13:07 --> Language Class Initialized
ERROR - 2020-02-20 11:13:07 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-20 11:13:07 --> Config Class Initialized
INFO - 2020-02-20 11:13:07 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:13:07 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:13:07 --> Utf8 Class Initialized
INFO - 2020-02-20 11:13:07 --> URI Class Initialized
INFO - 2020-02-20 11:13:07 --> Router Class Initialized
INFO - 2020-02-20 11:13:07 --> Output Class Initialized
INFO - 2020-02-20 11:13:07 --> Security Class Initialized
DEBUG - 2020-02-20 11:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:13:07 --> Input Class Initialized
INFO - 2020-02-20 11:13:08 --> Language Class Initialized
ERROR - 2020-02-20 11:13:08 --> 404 Page Not Found: Bower_components/jquery-i18next
