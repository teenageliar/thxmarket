<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-15 05:59:35 --> Config Class Initialized
INFO - 2020-02-15 05:59:35 --> Hooks Class Initialized
DEBUG - 2020-02-15 05:59:37 --> UTF-8 Support Enabled
INFO - 2020-02-15 05:59:37 --> Utf8 Class Initialized
INFO - 2020-02-15 05:59:37 --> URI Class Initialized
INFO - 2020-02-15 05:59:37 --> Router Class Initialized
INFO - 2020-02-15 05:59:38 --> Output Class Initialized
INFO - 2020-02-15 05:59:38 --> Security Class Initialized
DEBUG - 2020-02-15 05:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 05:59:38 --> Input Class Initialized
INFO - 2020-02-15 05:59:39 --> Language Class Initialized
INFO - 2020-02-15 05:59:39 --> Loader Class Initialized
INFO - 2020-02-15 05:59:39 --> Helper loaded: url_helper
INFO - 2020-02-15 05:59:39 --> Helper loaded: string_helper
INFO - 2020-02-15 05:59:40 --> Database Driver Class Initialized
DEBUG - 2020-02-15 05:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 05:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 05:59:40 --> Controller Class Initialized
INFO - 2020-02-15 05:59:40 --> Model "M_tiket" initialized
INFO - 2020-02-15 05:59:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 05:59:40 --> Model "M_pesan" initialized
INFO - 2020-02-15 05:59:40 --> Helper loaded: form_helper
INFO - 2020-02-15 05:59:40 --> Form Validation Class Initialized
INFO - 2020-02-15 05:59:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 05:59:41 --> Final output sent to browser
DEBUG - 2020-02-15 05:59:41 --> Total execution time: 6.8839
INFO - 2020-02-15 05:59:43 --> Config Class Initialized
INFO - 2020-02-15 05:59:43 --> Config Class Initialized
INFO - 2020-02-15 05:59:43 --> Hooks Class Initialized
INFO - 2020-02-15 05:59:43 --> Hooks Class Initialized
DEBUG - 2020-02-15 05:59:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 05:59:43 --> UTF-8 Support Enabled
INFO - 2020-02-15 05:59:43 --> Utf8 Class Initialized
INFO - 2020-02-15 05:59:43 --> Utf8 Class Initialized
INFO - 2020-02-15 05:59:43 --> URI Class Initialized
INFO - 2020-02-15 05:59:43 --> URI Class Initialized
INFO - 2020-02-15 05:59:43 --> Router Class Initialized
INFO - 2020-02-15 05:59:43 --> Router Class Initialized
INFO - 2020-02-15 05:59:43 --> Output Class Initialized
INFO - 2020-02-15 05:59:43 --> Output Class Initialized
INFO - 2020-02-15 05:59:43 --> Security Class Initialized
INFO - 2020-02-15 05:59:43 --> Security Class Initialized
DEBUG - 2020-02-15 05:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 05:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 05:59:43 --> Input Class Initialized
INFO - 2020-02-15 05:59:43 --> Input Class Initialized
INFO - 2020-02-15 05:59:43 --> Language Class Initialized
INFO - 2020-02-15 05:59:43 --> Language Class Initialized
INFO - 2020-02-15 05:59:43 --> Loader Class Initialized
INFO - 2020-02-15 05:59:43 --> Loader Class Initialized
INFO - 2020-02-15 05:59:43 --> Helper loaded: url_helper
INFO - 2020-02-15 05:59:43 --> Helper loaded: url_helper
INFO - 2020-02-15 05:59:43 --> Helper loaded: string_helper
INFO - 2020-02-15 05:59:43 --> Helper loaded: string_helper
INFO - 2020-02-15 05:59:44 --> Database Driver Class Initialized
INFO - 2020-02-15 05:59:44 --> Database Driver Class Initialized
DEBUG - 2020-02-15 05:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 05:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 05:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 05:59:44 --> Controller Class Initialized
INFO - 2020-02-15 05:59:44 --> Model "M_tiket" initialized
INFO - 2020-02-15 05:59:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 05:59:44 --> Model "M_pesan" initialized
INFO - 2020-02-15 05:59:44 --> Helper loaded: form_helper
INFO - 2020-02-15 05:59:44 --> Form Validation Class Initialized
ERROR - 2020-02-15 05:59:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 05:59:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 05:59:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 05:59:45 --> Final output sent to browser
DEBUG - 2020-02-15 05:59:45 --> Total execution time: 1.9867
INFO - 2020-02-15 05:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 05:59:45 --> Controller Class Initialized
INFO - 2020-02-15 05:59:45 --> Model "M_tiket" initialized
INFO - 2020-02-15 05:59:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 05:59:45 --> Model "M_pesan" initialized
INFO - 2020-02-15 05:59:45 --> Helper loaded: form_helper
INFO - 2020-02-15 05:59:45 --> Form Validation Class Initialized
ERROR - 2020-02-15 05:59:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 05:59:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 05:59:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 05:59:45 --> Final output sent to browser
DEBUG - 2020-02-15 05:59:45 --> Total execution time: 2.6055
INFO - 2020-02-15 11:03:37 --> Config Class Initialized
INFO - 2020-02-15 11:03:37 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:38 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:38 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:38 --> URI Class Initialized
INFO - 2020-02-15 11:03:38 --> Router Class Initialized
INFO - 2020-02-15 11:03:38 --> Output Class Initialized
INFO - 2020-02-15 11:03:38 --> Security Class Initialized
DEBUG - 2020-02-15 11:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:39 --> Input Class Initialized
INFO - 2020-02-15 11:03:39 --> Language Class Initialized
INFO - 2020-02-15 11:03:39 --> Loader Class Initialized
INFO - 2020-02-15 11:03:39 --> Helper loaded: url_helper
INFO - 2020-02-15 11:03:39 --> Helper loaded: string_helper
INFO - 2020-02-15 11:03:39 --> Database Driver Class Initialized
DEBUG - 2020-02-15 11:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 11:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 11:03:39 --> Controller Class Initialized
INFO - 2020-02-15 11:03:39 --> Model "M_tiket" initialized
INFO - 2020-02-15 11:03:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:03:39 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:03:39 --> Helper loaded: form_helper
INFO - 2020-02-15 11:03:39 --> Form Validation Class Initialized
INFO - 2020-02-15 11:03:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 11:03:40 --> Final output sent to browser
DEBUG - 2020-02-15 11:03:40 --> Total execution time: 2.6335
INFO - 2020-02-15 11:03:40 --> Config Class Initialized
INFO - 2020-02-15 11:03:40 --> Config Class Initialized
INFO - 2020-02-15 11:03:40 --> Hooks Class Initialized
INFO - 2020-02-15 11:03:40 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:03:40 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:40 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:40 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:40 --> URI Class Initialized
INFO - 2020-02-15 11:03:40 --> Router Class Initialized
INFO - 2020-02-15 11:03:40 --> Output Class Initialized
INFO - 2020-02-15 11:03:40 --> Security Class Initialized
INFO - 2020-02-15 11:03:40 --> URI Class Initialized
DEBUG - 2020-02-15 11:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:40 --> Router Class Initialized
INFO - 2020-02-15 11:03:40 --> Input Class Initialized
INFO - 2020-02-15 11:03:40 --> Output Class Initialized
INFO - 2020-02-15 11:03:40 --> Language Class Initialized
INFO - 2020-02-15 11:03:40 --> Security Class Initialized
INFO - 2020-02-15 11:03:40 --> Config Class Initialized
INFO - 2020-02-15 11:03:40 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:40 --> Loader Class Initialized
INFO - 2020-02-15 11:03:40 --> Input Class Initialized
INFO - 2020-02-15 11:03:40 --> Helper loaded: url_helper
INFO - 2020-02-15 11:03:40 --> Language Class Initialized
INFO - 2020-02-15 11:03:40 --> Helper loaded: string_helper
DEBUG - 2020-02-15 11:03:40 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:40 --> Config Class Initialized
INFO - 2020-02-15 11:03:40 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:40 --> Loader Class Initialized
INFO - 2020-02-15 11:03:40 --> Hooks Class Initialized
INFO - 2020-02-15 11:03:40 --> Database Driver Class Initialized
INFO - 2020-02-15 11:03:40 --> URI Class Initialized
INFO - 2020-02-15 11:03:40 --> Helper loaded: url_helper
DEBUG - 2020-02-15 11:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 11:03:40 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:40 --> Config Class Initialized
INFO - 2020-02-15 11:03:40 --> Hooks Class Initialized
INFO - 2020-02-15 11:03:40 --> Router Class Initialized
INFO - 2020-02-15 11:03:40 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 11:03:40 --> Helper loaded: string_helper
INFO - 2020-02-15 11:03:40 --> URI Class Initialized
INFO - 2020-02-15 11:03:40 --> Controller Class Initialized
INFO - 2020-02-15 11:03:40 --> Output Class Initialized
DEBUG - 2020-02-15 11:03:40 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:40 --> Config Class Initialized
INFO - 2020-02-15 11:03:40 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:40 --> Hooks Class Initialized
INFO - 2020-02-15 11:03:40 --> Security Class Initialized
INFO - 2020-02-15 11:03:40 --> Router Class Initialized
INFO - 2020-02-15 11:03:40 --> Model "M_tiket" initialized
INFO - 2020-02-15 11:03:40 --> Database Driver Class Initialized
INFO - 2020-02-15 11:03:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:03:40 --> URI Class Initialized
DEBUG - 2020-02-15 11:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:40 --> Output Class Initialized
DEBUG - 2020-02-15 11:03:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 11:03:40 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:40 --> Input Class Initialized
INFO - 2020-02-15 11:03:40 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:03:40 --> Router Class Initialized
INFO - 2020-02-15 11:03:40 --> Security Class Initialized
INFO - 2020-02-15 11:03:40 --> Language Class Initialized
DEBUG - 2020-02-15 11:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:40 --> URI Class Initialized
INFO - 2020-02-15 11:03:40 --> Helper loaded: form_helper
INFO - 2020-02-15 11:03:40 --> Input Class Initialized
INFO - 2020-02-15 11:03:40 --> Form Validation Class Initialized
INFO - 2020-02-15 11:03:40 --> Router Class Initialized
INFO - 2020-02-15 11:03:40 --> Output Class Initialized
ERROR - 2020-02-15 11:03:40 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-15 11:03:40 --> Language Class Initialized
INFO - 2020-02-15 11:03:40 --> Security Class Initialized
ERROR - 2020-02-15 11:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 11:03:40 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-15 11:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:40 --> Output Class Initialized
INFO - 2020-02-15 11:03:40 --> Input Class Initialized
INFO - 2020-02-15 11:03:40 --> Security Class Initialized
INFO - 2020-02-15 11:03:40 --> Language Class Initialized
DEBUG - 2020-02-15 11:03:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-15 11:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 11:03:40 --> Input Class Initialized
INFO - 2020-02-15 11:03:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-15 11:03:40 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 11:03:40 --> Final output sent to browser
INFO - 2020-02-15 11:03:40 --> Language Class Initialized
DEBUG - 2020-02-15 11:03:40 --> Total execution time: 0.5283
ERROR - 2020-02-15 11:03:40 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 11:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 11:03:40 --> Config Class Initialized
INFO - 2020-02-15 11:03:40 --> Config Class Initialized
INFO - 2020-02-15 11:03:40 --> Config Class Initialized
INFO - 2020-02-15 11:03:40 --> Hooks Class Initialized
INFO - 2020-02-15 11:03:40 --> Hooks Class Initialized
INFO - 2020-02-15 11:03:40 --> Controller Class Initialized
INFO - 2020-02-15 11:03:40 --> Hooks Class Initialized
INFO - 2020-02-15 11:03:40 --> Config Class Initialized
INFO - 2020-02-15 11:03:40 --> Config Class Initialized
INFO - 2020-02-15 11:03:40 --> Hooks Class Initialized
INFO - 2020-02-15 11:03:40 --> Hooks Class Initialized
INFO - 2020-02-15 11:03:40 --> Model "M_tiket" initialized
DEBUG - 2020-02-15 11:03:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:03:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:03:40 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:40 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:40 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:03:40 --> Utf8 Class Initialized
DEBUG - 2020-02-15 11:03:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:03:40 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:40 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:40 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:40 --> URI Class Initialized
INFO - 2020-02-15 11:03:40 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:03:40 --> URI Class Initialized
INFO - 2020-02-15 11:03:40 --> URI Class Initialized
INFO - 2020-02-15 11:03:40 --> URI Class Initialized
INFO - 2020-02-15 11:03:40 --> URI Class Initialized
INFO - 2020-02-15 11:03:40 --> Router Class Initialized
INFO - 2020-02-15 11:03:40 --> Router Class Initialized
INFO - 2020-02-15 11:03:40 --> Router Class Initialized
INFO - 2020-02-15 11:03:40 --> Helper loaded: form_helper
INFO - 2020-02-15 11:03:40 --> Form Validation Class Initialized
INFO - 2020-02-15 11:03:41 --> Output Class Initialized
INFO - 2020-02-15 11:03:41 --> Router Class Initialized
INFO - 2020-02-15 11:03:41 --> Output Class Initialized
INFO - 2020-02-15 11:03:41 --> Output Class Initialized
INFO - 2020-02-15 11:03:41 --> Router Class Initialized
INFO - 2020-02-15 11:03:41 --> Security Class Initialized
INFO - 2020-02-15 11:03:41 --> Output Class Initialized
INFO - 2020-02-15 11:03:41 --> Security Class Initialized
INFO - 2020-02-15 11:03:41 --> Security Class Initialized
INFO - 2020-02-15 11:03:41 --> Output Class Initialized
ERROR - 2020-02-15 11:03:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
DEBUG - 2020-02-15 11:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 11:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:41 --> Security Class Initialized
DEBUG - 2020-02-15 11:03:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-15 11:03:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 11:03:41 --> Security Class Initialized
INFO - 2020-02-15 11:03:41 --> Input Class Initialized
INFO - 2020-02-15 11:03:41 --> Input Class Initialized
INFO - 2020-02-15 11:03:41 --> Input Class Initialized
INFO - 2020-02-15 11:03:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-15 11:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 11:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:41 --> Input Class Initialized
INFO - 2020-02-15 11:03:41 --> Final output sent to browser
INFO - 2020-02-15 11:03:41 --> Input Class Initialized
INFO - 2020-02-15 11:03:41 --> Language Class Initialized
INFO - 2020-02-15 11:03:41 --> Language Class Initialized
INFO - 2020-02-15 11:03:41 --> Language Class Initialized
DEBUG - 2020-02-15 11:03:41 --> Total execution time: 0.7722
INFO - 2020-02-15 11:03:41 --> Language Class Initialized
ERROR - 2020-02-15 11:03:41 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 11:03:41 --> Language Class Initialized
ERROR - 2020-02-15 11:03:41 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-15 11:03:41 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-15 11:03:41 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-15 11:03:41 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 11:03:41 --> Config Class Initialized
INFO - 2020-02-15 11:03:41 --> Config Class Initialized
INFO - 2020-02-15 11:03:41 --> Hooks Class Initialized
INFO - 2020-02-15 11:03:41 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:41 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:41 --> Utf8 Class Initialized
DEBUG - 2020-02-15 11:03:41 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:41 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:41 --> URI Class Initialized
INFO - 2020-02-15 11:03:41 --> Router Class Initialized
INFO - 2020-02-15 11:03:41 --> URI Class Initialized
INFO - 2020-02-15 11:03:41 --> Router Class Initialized
INFO - 2020-02-15 11:03:41 --> Output Class Initialized
INFO - 2020-02-15 11:03:41 --> Output Class Initialized
INFO - 2020-02-15 11:03:41 --> Security Class Initialized
DEBUG - 2020-02-15 11:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:41 --> Security Class Initialized
INFO - 2020-02-15 11:03:41 --> Input Class Initialized
DEBUG - 2020-02-15 11:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:41 --> Input Class Initialized
INFO - 2020-02-15 11:03:41 --> Language Class Initialized
INFO - 2020-02-15 11:03:41 --> Language Class Initialized
ERROR - 2020-02-15 11:03:41 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-15 11:03:41 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 11:03:41 --> Config Class Initialized
INFO - 2020-02-15 11:03:41 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:41 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:41 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:41 --> URI Class Initialized
INFO - 2020-02-15 11:03:41 --> Router Class Initialized
INFO - 2020-02-15 11:03:41 --> Output Class Initialized
INFO - 2020-02-15 11:03:41 --> Security Class Initialized
DEBUG - 2020-02-15 11:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:41 --> Input Class Initialized
INFO - 2020-02-15 11:03:41 --> Language Class Initialized
ERROR - 2020-02-15 11:03:41 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-15 11:03:41 --> Config Class Initialized
INFO - 2020-02-15 11:03:41 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:41 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:41 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:41 --> URI Class Initialized
INFO - 2020-02-15 11:03:41 --> Router Class Initialized
INFO - 2020-02-15 11:03:41 --> Output Class Initialized
INFO - 2020-02-15 11:03:41 --> Security Class Initialized
DEBUG - 2020-02-15 11:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:41 --> Input Class Initialized
INFO - 2020-02-15 11:03:41 --> Language Class Initialized
ERROR - 2020-02-15 11:03:41 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 11:03:41 --> Config Class Initialized
INFO - 2020-02-15 11:03:41 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:41 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:41 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:41 --> URI Class Initialized
INFO - 2020-02-15 11:03:41 --> Router Class Initialized
INFO - 2020-02-15 11:03:41 --> Output Class Initialized
INFO - 2020-02-15 11:03:41 --> Security Class Initialized
DEBUG - 2020-02-15 11:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:41 --> Input Class Initialized
INFO - 2020-02-15 11:03:41 --> Language Class Initialized
ERROR - 2020-02-15 11:03:41 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 11:03:41 --> Config Class Initialized
INFO - 2020-02-15 11:03:41 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:41 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:41 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:42 --> URI Class Initialized
INFO - 2020-02-15 11:03:42 --> Router Class Initialized
INFO - 2020-02-15 11:03:42 --> Output Class Initialized
INFO - 2020-02-15 11:03:42 --> Security Class Initialized
DEBUG - 2020-02-15 11:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:42 --> Input Class Initialized
INFO - 2020-02-15 11:03:42 --> Language Class Initialized
ERROR - 2020-02-15 11:03:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 11:03:42 --> Config Class Initialized
INFO - 2020-02-15 11:03:42 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:42 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:42 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:42 --> URI Class Initialized
INFO - 2020-02-15 11:03:42 --> Router Class Initialized
INFO - 2020-02-15 11:03:42 --> Output Class Initialized
INFO - 2020-02-15 11:03:42 --> Security Class Initialized
DEBUG - 2020-02-15 11:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:42 --> Input Class Initialized
INFO - 2020-02-15 11:03:42 --> Language Class Initialized
ERROR - 2020-02-15 11:03:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 11:03:42 --> Config Class Initialized
INFO - 2020-02-15 11:03:42 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:42 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:42 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:42 --> URI Class Initialized
INFO - 2020-02-15 11:03:42 --> Router Class Initialized
INFO - 2020-02-15 11:03:42 --> Output Class Initialized
INFO - 2020-02-15 11:03:42 --> Security Class Initialized
DEBUG - 2020-02-15 11:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:42 --> Input Class Initialized
INFO - 2020-02-15 11:03:42 --> Language Class Initialized
ERROR - 2020-02-15 11:03:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 11:03:42 --> Config Class Initialized
INFO - 2020-02-15 11:03:42 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:42 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:42 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:42 --> URI Class Initialized
INFO - 2020-02-15 11:03:42 --> Router Class Initialized
INFO - 2020-02-15 11:03:42 --> Output Class Initialized
INFO - 2020-02-15 11:03:42 --> Security Class Initialized
DEBUG - 2020-02-15 11:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:42 --> Input Class Initialized
INFO - 2020-02-15 11:03:42 --> Language Class Initialized
ERROR - 2020-02-15 11:03:42 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 11:03:42 --> Config Class Initialized
INFO - 2020-02-15 11:03:42 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:42 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:42 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:42 --> URI Class Initialized
INFO - 2020-02-15 11:03:42 --> Router Class Initialized
INFO - 2020-02-15 11:03:42 --> Output Class Initialized
INFO - 2020-02-15 11:03:42 --> Security Class Initialized
DEBUG - 2020-02-15 11:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:42 --> Input Class Initialized
INFO - 2020-02-15 11:03:42 --> Language Class Initialized
ERROR - 2020-02-15 11:03:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 11:03:42 --> Config Class Initialized
INFO - 2020-02-15 11:03:42 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:42 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:42 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:42 --> URI Class Initialized
INFO - 2020-02-15 11:03:42 --> Router Class Initialized
INFO - 2020-02-15 11:03:43 --> Output Class Initialized
INFO - 2020-02-15 11:03:43 --> Security Class Initialized
DEBUG - 2020-02-15 11:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:43 --> Input Class Initialized
INFO - 2020-02-15 11:03:43 --> Language Class Initialized
ERROR - 2020-02-15 11:03:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 11:03:43 --> Config Class Initialized
INFO - 2020-02-15 11:03:43 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:03:43 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:03:43 --> Utf8 Class Initialized
INFO - 2020-02-15 11:03:43 --> URI Class Initialized
INFO - 2020-02-15 11:03:43 --> Router Class Initialized
INFO - 2020-02-15 11:03:43 --> Output Class Initialized
INFO - 2020-02-15 11:03:43 --> Security Class Initialized
DEBUG - 2020-02-15 11:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:03:43 --> Input Class Initialized
INFO - 2020-02-15 11:03:43 --> Language Class Initialized
ERROR - 2020-02-15 11:03:43 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 11:04:19 --> Config Class Initialized
INFO - 2020-02-15 11:04:19 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:04:19 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:04:19 --> Utf8 Class Initialized
INFO - 2020-02-15 11:04:19 --> URI Class Initialized
INFO - 2020-02-15 11:04:19 --> Router Class Initialized
INFO - 2020-02-15 11:04:19 --> Output Class Initialized
INFO - 2020-02-15 11:04:19 --> Security Class Initialized
DEBUG - 2020-02-15 11:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:04:19 --> Input Class Initialized
INFO - 2020-02-15 11:04:19 --> Language Class Initialized
INFO - 2020-02-15 11:04:19 --> Loader Class Initialized
INFO - 2020-02-15 11:04:19 --> Helper loaded: url_helper
INFO - 2020-02-15 11:04:19 --> Helper loaded: string_helper
INFO - 2020-02-15 11:04:19 --> Database Driver Class Initialized
DEBUG - 2020-02-15 11:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 11:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 11:04:20 --> Controller Class Initialized
INFO - 2020-02-15 11:04:20 --> Model "M_tiket" initialized
INFO - 2020-02-15 11:04:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:04:20 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:04:20 --> Helper loaded: form_helper
INFO - 2020-02-15 11:04:20 --> Form Validation Class Initialized
INFO - 2020-02-15 11:04:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-15 11:05:36 --> Config Class Initialized
INFO - 2020-02-15 11:05:36 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:05:36 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:05:36 --> Utf8 Class Initialized
INFO - 2020-02-15 11:05:36 --> URI Class Initialized
INFO - 2020-02-15 11:05:36 --> Router Class Initialized
INFO - 2020-02-15 11:05:36 --> Output Class Initialized
INFO - 2020-02-15 11:05:36 --> Security Class Initialized
DEBUG - 2020-02-15 11:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:05:36 --> Input Class Initialized
INFO - 2020-02-15 11:05:36 --> Language Class Initialized
INFO - 2020-02-15 11:05:36 --> Loader Class Initialized
INFO - 2020-02-15 11:05:36 --> Helper loaded: url_helper
INFO - 2020-02-15 11:05:36 --> Helper loaded: string_helper
INFO - 2020-02-15 11:05:36 --> Database Driver Class Initialized
DEBUG - 2020-02-15 11:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 11:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 11:05:36 --> Controller Class Initialized
INFO - 2020-02-15 11:05:36 --> Model "M_tiket" initialized
INFO - 2020-02-15 11:05:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:05:36 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:05:37 --> Helper loaded: form_helper
INFO - 2020-02-15 11:05:37 --> Form Validation Class Initialized
INFO - 2020-02-15 11:05:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 11:05:37 --> Final output sent to browser
DEBUG - 2020-02-15 11:05:37 --> Total execution time: 0.6574
INFO - 2020-02-15 11:06:17 --> Config Class Initialized
INFO - 2020-02-15 11:06:17 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:17 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:17 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:17 --> URI Class Initialized
INFO - 2020-02-15 11:06:17 --> Router Class Initialized
INFO - 2020-02-15 11:06:17 --> Output Class Initialized
INFO - 2020-02-15 11:06:18 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:18 --> Input Class Initialized
INFO - 2020-02-15 11:06:18 --> Language Class Initialized
INFO - 2020-02-15 11:06:18 --> Loader Class Initialized
INFO - 2020-02-15 11:06:18 --> Helper loaded: url_helper
INFO - 2020-02-15 11:06:18 --> Helper loaded: string_helper
INFO - 2020-02-15 11:06:18 --> Database Driver Class Initialized
DEBUG - 2020-02-15 11:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 11:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 11:06:18 --> Controller Class Initialized
INFO - 2020-02-15 11:06:18 --> Model "M_tiket" initialized
INFO - 2020-02-15 11:06:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:06:18 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:06:18 --> Helper loaded: form_helper
INFO - 2020-02-15 11:06:18 --> Form Validation Class Initialized
ERROR - 2020-02-15 11:06:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 60
ERROR - 2020-02-15 11:06:18 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `id_pengunjung`) VALUES ('33', '200000', '1', '2', NULL)
INFO - 2020-02-15 11:06:18 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-15 11:06:34 --> Config Class Initialized
INFO - 2020-02-15 11:06:34 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:34 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:34 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:34 --> URI Class Initialized
INFO - 2020-02-15 11:06:34 --> Router Class Initialized
INFO - 2020-02-15 11:06:34 --> Output Class Initialized
INFO - 2020-02-15 11:06:34 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:34 --> Input Class Initialized
INFO - 2020-02-15 11:06:34 --> Language Class Initialized
INFO - 2020-02-15 11:06:34 --> Loader Class Initialized
INFO - 2020-02-15 11:06:34 --> Helper loaded: url_helper
INFO - 2020-02-15 11:06:34 --> Helper loaded: string_helper
INFO - 2020-02-15 11:06:34 --> Database Driver Class Initialized
DEBUG - 2020-02-15 11:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 11:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 11:06:34 --> Controller Class Initialized
INFO - 2020-02-15 11:06:34 --> Model "M_tiket" initialized
INFO - 2020-02-15 11:06:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:06:34 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:06:34 --> Helper loaded: form_helper
INFO - 2020-02-15 11:06:34 --> Form Validation Class Initialized
INFO - 2020-02-15 11:06:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 11:06:34 --> Final output sent to browser
DEBUG - 2020-02-15 11:06:34 --> Total execution time: 0.5098
INFO - 2020-02-15 11:06:34 --> Config Class Initialized
INFO - 2020-02-15 11:06:34 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:34 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:34 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:34 --> URI Class Initialized
INFO - 2020-02-15 11:06:34 --> Router Class Initialized
INFO - 2020-02-15 11:06:34 --> Output Class Initialized
INFO - 2020-02-15 11:06:34 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:34 --> Input Class Initialized
INFO - 2020-02-15 11:06:34 --> Language Class Initialized
INFO - 2020-02-15 11:06:34 --> Loader Class Initialized
INFO - 2020-02-15 11:06:34 --> Helper loaded: url_helper
INFO - 2020-02-15 11:06:34 --> Helper loaded: string_helper
INFO - 2020-02-15 11:06:34 --> Database Driver Class Initialized
DEBUG - 2020-02-15 11:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 11:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 11:06:35 --> Config Class Initialized
INFO - 2020-02-15 11:06:35 --> Controller Class Initialized
INFO - 2020-02-15 11:06:35 --> Hooks Class Initialized
INFO - 2020-02-15 11:06:35 --> Model "M_tiket" initialized
DEBUG - 2020-02-15 11:06:35 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:35 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:06:35 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:06:35 --> URI Class Initialized
INFO - 2020-02-15 11:06:35 --> Router Class Initialized
INFO - 2020-02-15 11:06:35 --> Helper loaded: form_helper
INFO - 2020-02-15 11:06:35 --> Form Validation Class Initialized
INFO - 2020-02-15 11:06:35 --> Output Class Initialized
INFO - 2020-02-15 11:06:35 --> Security Class Initialized
ERROR - 2020-02-15 11:06:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 11:06:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
DEBUG - 2020-02-15 11:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:35 --> Input Class Initialized
INFO - 2020-02-15 11:06:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 11:06:35 --> Final output sent to browser
INFO - 2020-02-15 11:06:35 --> Language Class Initialized
DEBUG - 2020-02-15 11:06:35 --> Total execution time: 0.6673
INFO - 2020-02-15 11:06:35 --> Loader Class Initialized
INFO - 2020-02-15 11:06:35 --> Helper loaded: url_helper
INFO - 2020-02-15 11:06:35 --> Helper loaded: string_helper
INFO - 2020-02-15 11:06:35 --> Database Driver Class Initialized
DEBUG - 2020-02-15 11:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 11:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 11:06:35 --> Controller Class Initialized
INFO - 2020-02-15 11:06:35 --> Model "M_tiket" initialized
INFO - 2020-02-15 11:06:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:06:35 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:06:35 --> Helper loaded: form_helper
INFO - 2020-02-15 11:06:35 --> Form Validation Class Initialized
ERROR - 2020-02-15 11:06:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 11:06:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 11:06:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 11:06:35 --> Final output sent to browser
DEBUG - 2020-02-15 11:06:35 --> Total execution time: 0.6262
INFO - 2020-02-15 11:06:37 --> Config Class Initialized
INFO - 2020-02-15 11:06:37 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:37 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:37 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:37 --> URI Class Initialized
INFO - 2020-02-15 11:06:37 --> Router Class Initialized
INFO - 2020-02-15 11:06:37 --> Output Class Initialized
INFO - 2020-02-15 11:06:37 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:37 --> Input Class Initialized
INFO - 2020-02-15 11:06:37 --> Language Class Initialized
INFO - 2020-02-15 11:06:37 --> Loader Class Initialized
INFO - 2020-02-15 11:06:37 --> Helper loaded: url_helper
INFO - 2020-02-15 11:06:37 --> Helper loaded: string_helper
INFO - 2020-02-15 11:06:37 --> Database Driver Class Initialized
DEBUG - 2020-02-15 11:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 11:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 11:06:37 --> Controller Class Initialized
INFO - 2020-02-15 11:06:37 --> Model "M_tiket" initialized
INFO - 2020-02-15 11:06:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:06:37 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:06:37 --> Helper loaded: form_helper
INFO - 2020-02-15 11:06:38 --> Form Validation Class Initialized
INFO - 2020-02-15 11:06:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 11:06:38 --> Final output sent to browser
DEBUG - 2020-02-15 11:06:38 --> Total execution time: 0.7001
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:38 --> Input Class Initialized
INFO - 2020-02-15 11:06:38 --> Input Class Initialized
INFO - 2020-02-15 11:06:38 --> Input Class Initialized
INFO - 2020-02-15 11:06:38 --> Input Class Initialized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:38 --> Input Class Initialized
INFO - 2020-02-15 11:06:38 --> Input Class Initialized
INFO - 2020-02-15 11:06:38 --> Language Class Initialized
INFO - 2020-02-15 11:06:38 --> Language Class Initialized
INFO - 2020-02-15 11:06:38 --> Language Class Initialized
INFO - 2020-02-15 11:06:38 --> Language Class Initialized
INFO - 2020-02-15 11:06:38 --> Language Class Initialized
INFO - 2020-02-15 11:06:38 --> Language Class Initialized
ERROR - 2020-02-15 11:06:38 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-15 11:06:38 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-15 11:06:38 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-15 11:06:38 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-15 11:06:38 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-15 11:06:38 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:38 --> Input Class Initialized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:38 --> Input Class Initialized
INFO - 2020-02-15 11:06:38 --> Input Class Initialized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:38 --> Input Class Initialized
INFO - 2020-02-15 11:06:38 --> Input Class Initialized
INFO - 2020-02-15 11:06:38 --> Input Class Initialized
INFO - 2020-02-15 11:06:38 --> Language Class Initialized
INFO - 2020-02-15 11:06:38 --> Language Class Initialized
INFO - 2020-02-15 11:06:38 --> Language Class Initialized
INFO - 2020-02-15 11:06:38 --> Language Class Initialized
INFO - 2020-02-15 11:06:38 --> Language Class Initialized
INFO - 2020-02-15 11:06:38 --> Language Class Initialized
INFO - 2020-02-15 11:06:38 --> Loader Class Initialized
ERROR - 2020-02-15 11:06:38 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 11:06:38 --> Loader Class Initialized
ERROR - 2020-02-15 11:06:38 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-15 11:06:38 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-15 11:06:38 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 11:06:38 --> Helper loaded: url_helper
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Helper loaded: url_helper
INFO - 2020-02-15 11:06:38 --> Helper loaded: string_helper
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
INFO - 2020-02-15 11:06:38 --> Config Class Initialized
INFO - 2020-02-15 11:06:38 --> Helper loaded: string_helper
INFO - 2020-02-15 11:06:38 --> Database Driver Class Initialized
INFO - 2020-02-15 11:06:38 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 11:06:38 --> Database Driver Class Initialized
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-15 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 11:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 11:06:38 --> Controller Class Initialized
INFO - 2020-02-15 11:06:38 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> Model "M_tiket" initialized
INFO - 2020-02-15 11:06:38 --> URI Class Initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:06:38 --> Router Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
INFO - 2020-02-15 11:06:38 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
INFO - 2020-02-15 11:06:38 --> Output Class Initialized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:38 --> Security Class Initialized
INFO - 2020-02-15 11:06:38 --> Helper loaded: form_helper
INFO - 2020-02-15 11:06:38 --> Form Validation Class Initialized
INFO - 2020-02-15 11:06:38 --> Input Class Initialized
DEBUG - 2020-02-15 11:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:39 --> Input Class Initialized
INFO - 2020-02-15 11:06:39 --> Language Class Initialized
ERROR - 2020-02-15 11:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-15 11:06:39 --> Language Class Initialized
ERROR - 2020-02-15 11:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-15 11:06:39 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 11:06:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-15 11:06:39 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-15 11:06:39 --> Final output sent to browser
INFO - 2020-02-15 11:06:39 --> Config Class Initialized
INFO - 2020-02-15 11:06:39 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:39 --> Total execution time: 0.6156
INFO - 2020-02-15 11:06:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-15 11:06:39 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:39 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:39 --> Controller Class Initialized
INFO - 2020-02-15 11:06:39 --> Model "M_tiket" initialized
INFO - 2020-02-15 11:06:39 --> URI Class Initialized
INFO - 2020-02-15 11:06:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:06:39 --> Router Class Initialized
INFO - 2020-02-15 11:06:39 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:06:39 --> Output Class Initialized
INFO - 2020-02-15 11:06:39 --> Security Class Initialized
INFO - 2020-02-15 11:06:39 --> Helper loaded: form_helper
INFO - 2020-02-15 11:06:39 --> Form Validation Class Initialized
DEBUG - 2020-02-15 11:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:39 --> Input Class Initialized
ERROR - 2020-02-15 11:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-15 11:06:39 --> Language Class Initialized
ERROR - 2020-02-15 11:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 11:06:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-15 11:06:39 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 11:06:39 --> Final output sent to browser
INFO - 2020-02-15 11:06:39 --> Config Class Initialized
DEBUG - 2020-02-15 11:06:39 --> Total execution time: 0.8887
INFO - 2020-02-15 11:06:39 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:39 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:39 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:39 --> URI Class Initialized
INFO - 2020-02-15 11:06:39 --> Router Class Initialized
INFO - 2020-02-15 11:06:39 --> Output Class Initialized
INFO - 2020-02-15 11:06:39 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:39 --> Input Class Initialized
INFO - 2020-02-15 11:06:39 --> Language Class Initialized
ERROR - 2020-02-15 11:06:39 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 11:06:39 --> Config Class Initialized
INFO - 2020-02-15 11:06:39 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:39 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:39 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:39 --> URI Class Initialized
INFO - 2020-02-15 11:06:39 --> Router Class Initialized
INFO - 2020-02-15 11:06:39 --> Output Class Initialized
INFO - 2020-02-15 11:06:39 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:39 --> Input Class Initialized
INFO - 2020-02-15 11:06:39 --> Language Class Initialized
ERROR - 2020-02-15 11:06:39 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 11:06:39 --> Config Class Initialized
INFO - 2020-02-15 11:06:39 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:39 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:39 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:39 --> URI Class Initialized
INFO - 2020-02-15 11:06:40 --> Router Class Initialized
INFO - 2020-02-15 11:06:40 --> Output Class Initialized
INFO - 2020-02-15 11:06:40 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:40 --> Input Class Initialized
INFO - 2020-02-15 11:06:40 --> Language Class Initialized
ERROR - 2020-02-15 11:06:40 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 11:06:40 --> Config Class Initialized
INFO - 2020-02-15 11:06:40 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:40 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:40 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:40 --> URI Class Initialized
INFO - 2020-02-15 11:06:40 --> Router Class Initialized
INFO - 2020-02-15 11:06:40 --> Output Class Initialized
INFO - 2020-02-15 11:06:40 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:40 --> Input Class Initialized
INFO - 2020-02-15 11:06:40 --> Language Class Initialized
ERROR - 2020-02-15 11:06:40 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 11:06:40 --> Config Class Initialized
INFO - 2020-02-15 11:06:40 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:40 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:40 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:40 --> URI Class Initialized
INFO - 2020-02-15 11:06:40 --> Router Class Initialized
INFO - 2020-02-15 11:06:40 --> Output Class Initialized
INFO - 2020-02-15 11:06:40 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:40 --> Input Class Initialized
INFO - 2020-02-15 11:06:40 --> Language Class Initialized
ERROR - 2020-02-15 11:06:40 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 11:06:40 --> Config Class Initialized
INFO - 2020-02-15 11:06:40 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:40 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:40 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:40 --> URI Class Initialized
INFO - 2020-02-15 11:06:40 --> Router Class Initialized
INFO - 2020-02-15 11:06:40 --> Output Class Initialized
INFO - 2020-02-15 11:06:40 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:40 --> Input Class Initialized
INFO - 2020-02-15 11:06:40 --> Language Class Initialized
ERROR - 2020-02-15 11:06:41 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 11:06:41 --> Config Class Initialized
INFO - 2020-02-15 11:06:41 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:41 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:41 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:41 --> URI Class Initialized
INFO - 2020-02-15 11:06:41 --> Router Class Initialized
INFO - 2020-02-15 11:06:41 --> Output Class Initialized
INFO - 2020-02-15 11:06:41 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:41 --> Input Class Initialized
INFO - 2020-02-15 11:06:41 --> Language Class Initialized
ERROR - 2020-02-15 11:06:41 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 11:06:41 --> Config Class Initialized
INFO - 2020-02-15 11:06:41 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:41 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:41 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:41 --> URI Class Initialized
INFO - 2020-02-15 11:06:41 --> Router Class Initialized
INFO - 2020-02-15 11:06:41 --> Output Class Initialized
INFO - 2020-02-15 11:06:41 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:41 --> Input Class Initialized
INFO - 2020-02-15 11:06:41 --> Language Class Initialized
ERROR - 2020-02-15 11:06:41 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 11:06:57 --> Config Class Initialized
INFO - 2020-02-15 11:06:57 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:06:57 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:06:57 --> Utf8 Class Initialized
INFO - 2020-02-15 11:06:57 --> URI Class Initialized
INFO - 2020-02-15 11:06:57 --> Router Class Initialized
INFO - 2020-02-15 11:06:57 --> Output Class Initialized
INFO - 2020-02-15 11:06:57 --> Security Class Initialized
DEBUG - 2020-02-15 11:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:06:57 --> Input Class Initialized
INFO - 2020-02-15 11:06:57 --> Language Class Initialized
INFO - 2020-02-15 11:06:57 --> Loader Class Initialized
INFO - 2020-02-15 11:06:57 --> Helper loaded: url_helper
INFO - 2020-02-15 11:06:57 --> Helper loaded: string_helper
INFO - 2020-02-15 11:06:57 --> Database Driver Class Initialized
DEBUG - 2020-02-15 11:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 11:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 11:06:58 --> Controller Class Initialized
INFO - 2020-02-15 11:06:58 --> Model "M_tiket" initialized
INFO - 2020-02-15 11:06:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:06:58 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:06:58 --> Helper loaded: form_helper
INFO - 2020-02-15 11:06:58 --> Form Validation Class Initialized
INFO - 2020-02-15 11:06:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-15 11:06:58 --> Final output sent to browser
DEBUG - 2020-02-15 11:06:58 --> Total execution time: 0.7846
INFO - 2020-02-15 11:07:36 --> Config Class Initialized
INFO - 2020-02-15 11:07:36 --> Hooks Class Initialized
DEBUG - 2020-02-15 11:07:36 --> UTF-8 Support Enabled
INFO - 2020-02-15 11:07:36 --> Utf8 Class Initialized
INFO - 2020-02-15 11:07:36 --> URI Class Initialized
INFO - 2020-02-15 11:07:36 --> Router Class Initialized
INFO - 2020-02-15 11:07:36 --> Output Class Initialized
INFO - 2020-02-15 11:07:36 --> Security Class Initialized
DEBUG - 2020-02-15 11:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 11:07:36 --> Input Class Initialized
INFO - 2020-02-15 11:07:36 --> Language Class Initialized
INFO - 2020-02-15 11:07:37 --> Loader Class Initialized
INFO - 2020-02-15 11:07:37 --> Helper loaded: url_helper
INFO - 2020-02-15 11:07:37 --> Helper loaded: string_helper
INFO - 2020-02-15 11:07:37 --> Database Driver Class Initialized
DEBUG - 2020-02-15 11:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 11:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 11:07:37 --> Controller Class Initialized
INFO - 2020-02-15 11:07:37 --> Model "M_tiket" initialized
INFO - 2020-02-15 11:07:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 11:07:37 --> Model "M_pesan" initialized
INFO - 2020-02-15 11:07:37 --> Helper loaded: form_helper
INFO - 2020-02-15 11:07:37 --> Form Validation Class Initialized
INFO - 2020-02-15 11:07:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-15 11:07:37 --> Final output sent to browser
DEBUG - 2020-02-15 11:07:37 --> Total execution time: 1.2726
INFO - 2020-02-15 13:26:03 --> Config Class Initialized
INFO - 2020-02-15 13:26:03 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:26:05 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:26:05 --> Utf8 Class Initialized
INFO - 2020-02-15 13:26:05 --> URI Class Initialized
INFO - 2020-02-15 13:26:05 --> Router Class Initialized
INFO - 2020-02-15 13:26:06 --> Output Class Initialized
INFO - 2020-02-15 13:26:06 --> Security Class Initialized
DEBUG - 2020-02-15 13:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:26:06 --> Input Class Initialized
INFO - 2020-02-15 13:26:06 --> Language Class Initialized
INFO - 2020-02-15 13:26:06 --> Loader Class Initialized
INFO - 2020-02-15 13:26:07 --> Helper loaded: url_helper
INFO - 2020-02-15 13:26:07 --> Helper loaded: string_helper
INFO - 2020-02-15 13:26:07 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:26:07 --> Controller Class Initialized
INFO - 2020-02-15 13:26:08 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:26:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:26:08 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:26:08 --> Helper loaded: form_helper
INFO - 2020-02-15 13:26:08 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:26:08 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 30
ERROR - 2020-02-15 13:26:08 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-15 13:26:08 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
INFO - 2020-02-15 13:26:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-15 13:26:09 --> Final output sent to browser
DEBUG - 2020-02-15 13:26:09 --> Total execution time: 5.9974
INFO - 2020-02-15 13:30:42 --> Config Class Initialized
INFO - 2020-02-15 13:30:42 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:30:42 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:30:42 --> Utf8 Class Initialized
INFO - 2020-02-15 13:30:42 --> URI Class Initialized
INFO - 2020-02-15 13:30:42 --> Router Class Initialized
INFO - 2020-02-15 13:30:42 --> Output Class Initialized
INFO - 2020-02-15 13:30:42 --> Security Class Initialized
DEBUG - 2020-02-15 13:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:30:42 --> Input Class Initialized
INFO - 2020-02-15 13:30:42 --> Language Class Initialized
INFO - 2020-02-15 13:30:42 --> Loader Class Initialized
INFO - 2020-02-15 13:30:42 --> Helper loaded: url_helper
INFO - 2020-02-15 13:30:42 --> Helper loaded: string_helper
INFO - 2020-02-15 13:30:42 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:30:42 --> Controller Class Initialized
INFO - 2020-02-15 13:30:42 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:30:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:30:42 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:30:42 --> Helper loaded: form_helper
INFO - 2020-02-15 13:30:42 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:30:42 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-15 13:30:42 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-15 13:30:42 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-15 13:30:42 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 42
INFO - 2020-02-15 13:30:42 --> Final output sent to browser
DEBUG - 2020-02-15 13:30:43 --> Total execution time: 0.5552
INFO - 2020-02-15 13:31:12 --> Config Class Initialized
INFO - 2020-02-15 13:31:12 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:31:12 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:31:12 --> Utf8 Class Initialized
INFO - 2020-02-15 13:31:12 --> URI Class Initialized
INFO - 2020-02-15 13:31:12 --> Router Class Initialized
INFO - 2020-02-15 13:31:12 --> Output Class Initialized
INFO - 2020-02-15 13:31:12 --> Security Class Initialized
DEBUG - 2020-02-15 13:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:31:12 --> Input Class Initialized
INFO - 2020-02-15 13:31:12 --> Language Class Initialized
INFO - 2020-02-15 13:31:12 --> Loader Class Initialized
INFO - 2020-02-15 13:31:12 --> Helper loaded: url_helper
INFO - 2020-02-15 13:31:12 --> Helper loaded: string_helper
INFO - 2020-02-15 13:31:12 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:31:12 --> Controller Class Initialized
INFO - 2020-02-15 13:31:12 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:31:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:31:12 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:31:12 --> Helper loaded: form_helper
INFO - 2020-02-15 13:31:12 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:31:12 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-15 13:31:12 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-15 13:31:12 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-15 13:31:12 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 42
INFO - 2020-02-15 13:31:12 --> Final output sent to browser
DEBUG - 2020-02-15 13:31:12 --> Total execution time: 0.7556
INFO - 2020-02-15 13:31:54 --> Config Class Initialized
INFO - 2020-02-15 13:31:54 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:31:54 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:31:54 --> Utf8 Class Initialized
INFO - 2020-02-15 13:31:54 --> URI Class Initialized
INFO - 2020-02-15 13:31:54 --> Router Class Initialized
INFO - 2020-02-15 13:31:54 --> Output Class Initialized
INFO - 2020-02-15 13:31:54 --> Security Class Initialized
DEBUG - 2020-02-15 13:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:31:54 --> Input Class Initialized
INFO - 2020-02-15 13:31:54 --> Language Class Initialized
INFO - 2020-02-15 13:31:54 --> Loader Class Initialized
INFO - 2020-02-15 13:31:54 --> Helper loaded: url_helper
INFO - 2020-02-15 13:31:54 --> Helper loaded: string_helper
INFO - 2020-02-15 13:31:54 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:31:54 --> Controller Class Initialized
INFO - 2020-02-15 13:31:54 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:31:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:31:54 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:31:54 --> Helper loaded: form_helper
INFO - 2020-02-15 13:31:54 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:31:55 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-15 13:31:55 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-15 13:31:55 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-15 13:31:55 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 42
INFO - 2020-02-15 13:31:55 --> Final output sent to browser
DEBUG - 2020-02-15 13:31:55 --> Total execution time: 0.6400
INFO - 2020-02-15 13:32:03 --> Config Class Initialized
INFO - 2020-02-15 13:32:03 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:32:03 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:03 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:03 --> URI Class Initialized
INFO - 2020-02-15 13:32:03 --> Router Class Initialized
INFO - 2020-02-15 13:32:03 --> Output Class Initialized
INFO - 2020-02-15 13:32:03 --> Security Class Initialized
DEBUG - 2020-02-15 13:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:03 --> Input Class Initialized
INFO - 2020-02-15 13:32:04 --> Language Class Initialized
INFO - 2020-02-15 13:32:04 --> Loader Class Initialized
INFO - 2020-02-15 13:32:04 --> Helper loaded: url_helper
INFO - 2020-02-15 13:32:04 --> Helper loaded: string_helper
INFO - 2020-02-15 13:32:04 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:32:04 --> Controller Class Initialized
INFO - 2020-02-15 13:32:04 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:32:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:32:04 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:32:04 --> Helper loaded: form_helper
INFO - 2020-02-15 13:32:04 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:32:04 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-15 13:32:04 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-15 13:32:04 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-15 13:32:04 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 42
INFO - 2020-02-15 13:32:04 --> Final output sent to browser
DEBUG - 2020-02-15 13:32:04 --> Total execution time: 0.5795
INFO - 2020-02-15 13:32:33 --> Config Class Initialized
INFO - 2020-02-15 13:32:33 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:32:33 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:33 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:33 --> URI Class Initialized
INFO - 2020-02-15 13:32:33 --> Router Class Initialized
INFO - 2020-02-15 13:32:33 --> Output Class Initialized
INFO - 2020-02-15 13:32:33 --> Security Class Initialized
DEBUG - 2020-02-15 13:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:33 --> Input Class Initialized
INFO - 2020-02-15 13:32:33 --> Language Class Initialized
INFO - 2020-02-15 13:32:33 --> Loader Class Initialized
INFO - 2020-02-15 13:32:33 --> Helper loaded: url_helper
INFO - 2020-02-15 13:32:33 --> Helper loaded: string_helper
INFO - 2020-02-15 13:32:33 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:32:33 --> Controller Class Initialized
INFO - 2020-02-15 13:32:33 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:32:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:32:33 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:32:33 --> Helper loaded: form_helper
INFO - 2020-02-15 13:32:33 --> Form Validation Class Initialized
INFO - 2020-02-15 13:32:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:32:34 --> Final output sent to browser
DEBUG - 2020-02-15 13:32:34 --> Total execution time: 1.4059
INFO - 2020-02-15 13:32:35 --> Config Class Initialized
INFO - 2020-02-15 13:32:35 --> Config Class Initialized
INFO - 2020-02-15 13:32:35 --> Config Class Initialized
INFO - 2020-02-15 13:32:35 --> Hooks Class Initialized
INFO - 2020-02-15 13:32:35 --> Hooks Class Initialized
INFO - 2020-02-15 13:32:35 --> Hooks Class Initialized
INFO - 2020-02-15 13:32:35 --> Config Class Initialized
INFO - 2020-02-15 13:32:35 --> Hooks Class Initialized
INFO - 2020-02-15 13:32:35 --> Config Class Initialized
INFO - 2020-02-15 13:32:35 --> Config Class Initialized
DEBUG - 2020-02-15 13:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:32:35 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:35 --> Hooks Class Initialized
INFO - 2020-02-15 13:32:35 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:35 --> Hooks Class Initialized
INFO - 2020-02-15 13:32:35 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:35 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:32:35 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:35 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:35 --> URI Class Initialized
INFO - 2020-02-15 13:32:35 --> URI Class Initialized
INFO - 2020-02-15 13:32:35 --> Router Class Initialized
INFO - 2020-02-15 13:32:35 --> URI Class Initialized
INFO - 2020-02-15 13:32:35 --> URI Class Initialized
INFO - 2020-02-15 13:32:35 --> Router Class Initialized
DEBUG - 2020-02-15 13:32:35 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:35 --> Router Class Initialized
DEBUG - 2020-02-15 13:32:35 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:35 --> Output Class Initialized
INFO - 2020-02-15 13:32:35 --> Router Class Initialized
INFO - 2020-02-15 13:32:35 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:35 --> Output Class Initialized
INFO - 2020-02-15 13:32:35 --> Security Class Initialized
INFO - 2020-02-15 13:32:35 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:35 --> Output Class Initialized
INFO - 2020-02-15 13:32:35 --> Output Class Initialized
INFO - 2020-02-15 13:32:35 --> URI Class Initialized
INFO - 2020-02-15 13:32:35 --> Security Class Initialized
INFO - 2020-02-15 13:32:35 --> Security Class Initialized
INFO - 2020-02-15 13:32:35 --> Security Class Initialized
DEBUG - 2020-02-15 13:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:35 --> Router Class Initialized
DEBUG - 2020-02-15 13:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:35 --> Input Class Initialized
INFO - 2020-02-15 13:32:35 --> Input Class Initialized
INFO - 2020-02-15 13:32:35 --> Input Class Initialized
INFO - 2020-02-15 13:32:35 --> Input Class Initialized
INFO - 2020-02-15 13:32:35 --> Language Class Initialized
INFO - 2020-02-15 13:32:35 --> Output Class Initialized
INFO - 2020-02-15 13:32:35 --> Language Class Initialized
INFO - 2020-02-15 13:32:35 --> Language Class Initialized
ERROR - 2020-02-15 13:32:35 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 13:32:35 --> Language Class Initialized
INFO - 2020-02-15 13:32:35 --> Security Class Initialized
ERROR - 2020-02-15 13:32:35 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-15 13:32:35 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-15 13:32:35 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-15 13:32:35 --> URI Class Initialized
DEBUG - 2020-02-15 13:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:35 --> Input Class Initialized
INFO - 2020-02-15 13:32:35 --> Router Class Initialized
INFO - 2020-02-15 13:32:36 --> Config Class Initialized
INFO - 2020-02-15 13:32:36 --> Config Class Initialized
INFO - 2020-02-15 13:32:36 --> Language Class Initialized
INFO - 2020-02-15 13:32:36 --> Config Class Initialized
INFO - 2020-02-15 13:32:36 --> Output Class Initialized
INFO - 2020-02-15 13:32:36 --> Config Class Initialized
INFO - 2020-02-15 13:32:36 --> Hooks Class Initialized
ERROR - 2020-02-15 13:32:36 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 13:32:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:32:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:32:36 --> Security Class Initialized
INFO - 2020-02-15 13:32:36 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:32:36 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:36 --> Input Class Initialized
INFO - 2020-02-15 13:32:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:36 --> Config Class Initialized
INFO - 2020-02-15 13:32:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:32:36 --> Language Class Initialized
INFO - 2020-02-15 13:32:36 --> URI Class Initialized
INFO - 2020-02-15 13:32:36 --> URI Class Initialized
INFO - 2020-02-15 13:32:36 --> URI Class Initialized
INFO - 2020-02-15 13:32:36 --> URI Class Initialized
INFO - 2020-02-15 13:32:36 --> Router Class Initialized
INFO - 2020-02-15 13:32:36 --> Router Class Initialized
INFO - 2020-02-15 13:32:36 --> Router Class Initialized
INFO - 2020-02-15 13:32:36 --> Router Class Initialized
DEBUG - 2020-02-15 13:32:36 --> UTF-8 Support Enabled
ERROR - 2020-02-15 13:32:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:32:36 --> Output Class Initialized
INFO - 2020-02-15 13:32:36 --> Output Class Initialized
INFO - 2020-02-15 13:32:36 --> Output Class Initialized
INFO - 2020-02-15 13:32:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:36 --> Output Class Initialized
INFO - 2020-02-15 13:32:36 --> Security Class Initialized
INFO - 2020-02-15 13:32:36 --> Security Class Initialized
INFO - 2020-02-15 13:32:36 --> Security Class Initialized
INFO - 2020-02-15 13:32:36 --> Security Class Initialized
INFO - 2020-02-15 13:32:36 --> URI Class Initialized
DEBUG - 2020-02-15 13:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:36 --> Router Class Initialized
DEBUG - 2020-02-15 13:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:36 --> Input Class Initialized
INFO - 2020-02-15 13:32:36 --> Input Class Initialized
INFO - 2020-02-15 13:32:36 --> Input Class Initialized
INFO - 2020-02-15 13:32:36 --> Input Class Initialized
INFO - 2020-02-15 13:32:36 --> Output Class Initialized
INFO - 2020-02-15 13:32:36 --> Language Class Initialized
INFO - 2020-02-15 13:32:36 --> Language Class Initialized
INFO - 2020-02-15 13:32:36 --> Language Class Initialized
INFO - 2020-02-15 13:32:36 --> Security Class Initialized
INFO - 2020-02-15 13:32:36 --> Language Class Initialized
ERROR - 2020-02-15 13:32:36 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-15 13:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-15 13:32:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:32:36 --> Loader Class Initialized
INFO - 2020-02-15 13:32:36 --> Loader Class Initialized
INFO - 2020-02-15 13:32:36 --> Config Class Initialized
INFO - 2020-02-15 13:32:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:32:36 --> Input Class Initialized
INFO - 2020-02-15 13:32:36 --> Helper loaded: url_helper
INFO - 2020-02-15 13:32:36 --> Helper loaded: url_helper
INFO - 2020-02-15 13:32:36 --> Helper loaded: string_helper
INFO - 2020-02-15 13:32:36 --> Language Class Initialized
INFO - 2020-02-15 13:32:36 --> Helper loaded: string_helper
DEBUG - 2020-02-15 13:32:36 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:36 --> Utf8 Class Initialized
ERROR - 2020-02-15 13:32:36 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 13:32:36 --> Database Driver Class Initialized
INFO - 2020-02-15 13:32:36 --> Database Driver Class Initialized
INFO - 2020-02-15 13:32:36 --> URI Class Initialized
DEBUG - 2020-02-15 13:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 13:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:32:36 --> Router Class Initialized
INFO - 2020-02-15 13:32:36 --> Controller Class Initialized
INFO - 2020-02-15 13:32:36 --> Output Class Initialized
INFO - 2020-02-15 13:32:36 --> Config Class Initialized
INFO - 2020-02-15 13:32:36 --> Config Class Initialized
INFO - 2020-02-15 13:32:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:32:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:32:36 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:32:36 --> Security Class Initialized
INFO - 2020-02-15 13:32:36 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-15 13:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:32:36 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:36 --> Input Class Initialized
INFO - 2020-02-15 13:32:36 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:32:36 --> URI Class Initialized
INFO - 2020-02-15 13:32:36 --> URI Class Initialized
INFO - 2020-02-15 13:32:36 --> Helper loaded: form_helper
INFO - 2020-02-15 13:32:36 --> Language Class Initialized
INFO - 2020-02-15 13:32:36 --> Form Validation Class Initialized
INFO - 2020-02-15 13:32:36 --> Router Class Initialized
ERROR - 2020-02-15 13:32:36 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 13:32:36 --> Router Class Initialized
INFO - 2020-02-15 13:32:36 --> Output Class Initialized
INFO - 2020-02-15 13:32:36 --> Output Class Initialized
ERROR - 2020-02-15 13:32:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:32:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:32:36 --> Security Class Initialized
INFO - 2020-02-15 13:32:36 --> Security Class Initialized
INFO - 2020-02-15 13:32:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-15 13:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:36 --> Input Class Initialized
INFO - 2020-02-15 13:32:36 --> Input Class Initialized
INFO - 2020-02-15 13:32:36 --> Final output sent to browser
DEBUG - 2020-02-15 13:32:36 --> Total execution time: 0.6786
INFO - 2020-02-15 13:32:36 --> Language Class Initialized
INFO - 2020-02-15 13:32:36 --> Language Class Initialized
INFO - 2020-02-15 13:32:36 --> Session: Class initialized using 'files' driver.
ERROR - 2020-02-15 13:32:36 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-15 13:32:36 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-15 13:32:36 --> Controller Class Initialized
INFO - 2020-02-15 13:32:36 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:32:36 --> Config Class Initialized
INFO - 2020-02-15 13:32:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:32:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:32:36 --> Model "M_pesan" initialized
DEBUG - 2020-02-15 13:32:36 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:36 --> Helper loaded: form_helper
INFO - 2020-02-15 13:32:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:36 --> Form Validation Class Initialized
INFO - 2020-02-15 13:32:36 --> URI Class Initialized
ERROR - 2020-02-15 13:32:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:32:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:32:37 --> Router Class Initialized
INFO - 2020-02-15 13:32:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:32:37 --> Output Class Initialized
INFO - 2020-02-15 13:32:37 --> Final output sent to browser
INFO - 2020-02-15 13:32:37 --> Security Class Initialized
DEBUG - 2020-02-15 13:32:37 --> Total execution time: 1.0791
DEBUG - 2020-02-15 13:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:37 --> Input Class Initialized
INFO - 2020-02-15 13:32:37 --> Language Class Initialized
ERROR - 2020-02-15 13:32:37 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 13:32:37 --> Config Class Initialized
INFO - 2020-02-15 13:32:37 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:32:37 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:37 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:37 --> URI Class Initialized
INFO - 2020-02-15 13:32:37 --> Router Class Initialized
INFO - 2020-02-15 13:32:38 --> Output Class Initialized
INFO - 2020-02-15 13:32:38 --> Security Class Initialized
DEBUG - 2020-02-15 13:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:38 --> Input Class Initialized
INFO - 2020-02-15 13:32:38 --> Language Class Initialized
ERROR - 2020-02-15 13:32:38 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 13:32:38 --> Config Class Initialized
INFO - 2020-02-15 13:32:38 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:32:38 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:38 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:38 --> URI Class Initialized
INFO - 2020-02-15 13:32:38 --> Router Class Initialized
INFO - 2020-02-15 13:32:38 --> Output Class Initialized
INFO - 2020-02-15 13:32:38 --> Security Class Initialized
DEBUG - 2020-02-15 13:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:38 --> Input Class Initialized
INFO - 2020-02-15 13:32:38 --> Language Class Initialized
ERROR - 2020-02-15 13:32:38 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 13:32:38 --> Config Class Initialized
INFO - 2020-02-15 13:32:38 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:32:38 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:38 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:38 --> URI Class Initialized
INFO - 2020-02-15 13:32:39 --> Router Class Initialized
INFO - 2020-02-15 13:32:39 --> Output Class Initialized
INFO - 2020-02-15 13:32:39 --> Security Class Initialized
DEBUG - 2020-02-15 13:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:39 --> Input Class Initialized
INFO - 2020-02-15 13:32:39 --> Language Class Initialized
ERROR - 2020-02-15 13:32:39 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:32:39 --> Config Class Initialized
INFO - 2020-02-15 13:32:39 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:32:39 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:39 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:39 --> URI Class Initialized
INFO - 2020-02-15 13:32:39 --> Router Class Initialized
INFO - 2020-02-15 13:32:39 --> Output Class Initialized
INFO - 2020-02-15 13:32:39 --> Security Class Initialized
DEBUG - 2020-02-15 13:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:39 --> Input Class Initialized
INFO - 2020-02-15 13:32:39 --> Language Class Initialized
ERROR - 2020-02-15 13:32:39 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:32:39 --> Config Class Initialized
INFO - 2020-02-15 13:32:39 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:32:39 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:39 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:39 --> URI Class Initialized
INFO - 2020-02-15 13:32:39 --> Router Class Initialized
INFO - 2020-02-15 13:32:39 --> Output Class Initialized
INFO - 2020-02-15 13:32:39 --> Security Class Initialized
DEBUG - 2020-02-15 13:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:40 --> Input Class Initialized
INFO - 2020-02-15 13:32:40 --> Language Class Initialized
ERROR - 2020-02-15 13:32:40 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 13:32:40 --> Config Class Initialized
INFO - 2020-02-15 13:32:40 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:32:40 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:40 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:40 --> URI Class Initialized
INFO - 2020-02-15 13:32:40 --> Router Class Initialized
INFO - 2020-02-15 13:32:40 --> Output Class Initialized
INFO - 2020-02-15 13:32:40 --> Security Class Initialized
DEBUG - 2020-02-15 13:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:40 --> Input Class Initialized
INFO - 2020-02-15 13:32:40 --> Language Class Initialized
ERROR - 2020-02-15 13:32:40 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 13:32:40 --> Config Class Initialized
INFO - 2020-02-15 13:32:40 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:32:40 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:40 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:40 --> URI Class Initialized
INFO - 2020-02-15 13:32:40 --> Router Class Initialized
INFO - 2020-02-15 13:32:40 --> Output Class Initialized
INFO - 2020-02-15 13:32:40 --> Security Class Initialized
DEBUG - 2020-02-15 13:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:40 --> Input Class Initialized
INFO - 2020-02-15 13:32:40 --> Language Class Initialized
ERROR - 2020-02-15 13:32:40 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 13:32:41 --> Config Class Initialized
INFO - 2020-02-15 13:32:41 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:32:41 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:32:41 --> Utf8 Class Initialized
INFO - 2020-02-15 13:32:41 --> URI Class Initialized
INFO - 2020-02-15 13:32:41 --> Router Class Initialized
INFO - 2020-02-15 13:32:41 --> Output Class Initialized
INFO - 2020-02-15 13:32:41 --> Security Class Initialized
DEBUG - 2020-02-15 13:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:32:41 --> Input Class Initialized
INFO - 2020-02-15 13:32:41 --> Language Class Initialized
ERROR - 2020-02-15 13:32:41 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 13:33:01 --> Config Class Initialized
INFO - 2020-02-15 13:33:01 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:33:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:33:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:33:01 --> URI Class Initialized
INFO - 2020-02-15 13:33:01 --> Router Class Initialized
INFO - 2020-02-15 13:33:01 --> Output Class Initialized
INFO - 2020-02-15 13:33:01 --> Security Class Initialized
DEBUG - 2020-02-15 13:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:33:01 --> Input Class Initialized
INFO - 2020-02-15 13:33:01 --> Language Class Initialized
INFO - 2020-02-15 13:33:01 --> Loader Class Initialized
INFO - 2020-02-15 13:33:01 --> Helper loaded: url_helper
INFO - 2020-02-15 13:33:01 --> Helper loaded: string_helper
INFO - 2020-02-15 13:33:01 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:33:01 --> Controller Class Initialized
INFO - 2020-02-15 13:33:01 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:33:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:33:01 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:33:01 --> Helper loaded: form_helper
INFO - 2020-02-15 13:33:01 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:33:02 --> Query error: Unknown column 'tanggal_pemesanan' in 'field list' - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pemesanan`, `tanggal_exp`, `tanggal_approve`, `id_pengunjung`) VALUES ('34', '120000', '1', '1', NULL, NULL, NULL, '190')
INFO - 2020-02-15 13:33:02 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-15 13:33:23 --> Config Class Initialized
INFO - 2020-02-15 13:33:23 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:33:23 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:33:23 --> Utf8 Class Initialized
INFO - 2020-02-15 13:33:23 --> URI Class Initialized
INFO - 2020-02-15 13:33:23 --> Router Class Initialized
INFO - 2020-02-15 13:33:23 --> Output Class Initialized
INFO - 2020-02-15 13:33:23 --> Security Class Initialized
DEBUG - 2020-02-15 13:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:33:23 --> Input Class Initialized
INFO - 2020-02-15 13:33:23 --> Language Class Initialized
INFO - 2020-02-15 13:33:23 --> Loader Class Initialized
INFO - 2020-02-15 13:33:23 --> Helper loaded: url_helper
INFO - 2020-02-15 13:33:23 --> Helper loaded: string_helper
INFO - 2020-02-15 13:33:24 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:33:24 --> Controller Class Initialized
INFO - 2020-02-15 13:33:24 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:33:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:33:24 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:33:24 --> Helper loaded: form_helper
INFO - 2020-02-15 13:33:24 --> Form Validation Class Initialized
INFO - 2020-02-15 13:33:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:33:24 --> Final output sent to browser
DEBUG - 2020-02-15 13:33:24 --> Total execution time: 0.8264
INFO - 2020-02-15 13:33:24 --> Config Class Initialized
INFO - 2020-02-15 13:33:24 --> Config Class Initialized
INFO - 2020-02-15 13:33:24 --> Hooks Class Initialized
INFO - 2020-02-15 13:33:24 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:33:24 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:33:24 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:33:24 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:33:24 --> Utf8 Class Initialized
INFO - 2020-02-15 13:33:24 --> URI Class Initialized
INFO - 2020-02-15 13:33:24 --> URI Class Initialized
INFO - 2020-02-15 13:33:24 --> Router Class Initialized
INFO - 2020-02-15 13:33:24 --> Router Class Initialized
INFO - 2020-02-15 13:33:24 --> Output Class Initialized
INFO - 2020-02-15 13:33:24 --> Security Class Initialized
INFO - 2020-02-15 13:33:24 --> Output Class Initialized
DEBUG - 2020-02-15 13:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:33:24 --> Security Class Initialized
INFO - 2020-02-15 13:33:24 --> Input Class Initialized
DEBUG - 2020-02-15 13:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:33:24 --> Input Class Initialized
INFO - 2020-02-15 13:33:24 --> Language Class Initialized
INFO - 2020-02-15 13:33:24 --> Language Class Initialized
INFO - 2020-02-15 13:33:24 --> Loader Class Initialized
INFO - 2020-02-15 13:33:24 --> Helper loaded: url_helper
INFO - 2020-02-15 13:33:24 --> Loader Class Initialized
INFO - 2020-02-15 13:33:24 --> Helper loaded: string_helper
INFO - 2020-02-15 13:33:24 --> Helper loaded: url_helper
INFO - 2020-02-15 13:33:24 --> Helper loaded: string_helper
INFO - 2020-02-15 13:33:24 --> Database Driver Class Initialized
INFO - 2020-02-15 13:33:24 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:33:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-15 13:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:33:24 --> Controller Class Initialized
INFO - 2020-02-15 13:33:24 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:33:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:33:25 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:33:25 --> Helper loaded: form_helper
INFO - 2020-02-15 13:33:25 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:33:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:33:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:33:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:33:25 --> Final output sent to browser
DEBUG - 2020-02-15 13:33:25 --> Total execution time: 0.7649
INFO - 2020-02-15 13:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:33:25 --> Controller Class Initialized
INFO - 2020-02-15 13:33:25 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:33:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:33:25 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:33:25 --> Helper loaded: form_helper
INFO - 2020-02-15 13:33:25 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:33:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:33:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:33:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:33:25 --> Final output sent to browser
DEBUG - 2020-02-15 13:33:25 --> Total execution time: 1.0458
INFO - 2020-02-15 13:33:27 --> Config Class Initialized
INFO - 2020-02-15 13:33:27 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:33:27 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:33:27 --> Utf8 Class Initialized
INFO - 2020-02-15 13:33:27 --> URI Class Initialized
INFO - 2020-02-15 13:33:27 --> Router Class Initialized
INFO - 2020-02-15 13:33:27 --> Output Class Initialized
INFO - 2020-02-15 13:33:27 --> Security Class Initialized
DEBUG - 2020-02-15 13:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:33:28 --> Input Class Initialized
INFO - 2020-02-15 13:33:28 --> Language Class Initialized
INFO - 2020-02-15 13:33:28 --> Loader Class Initialized
INFO - 2020-02-15 13:33:28 --> Helper loaded: url_helper
INFO - 2020-02-15 13:33:28 --> Helper loaded: string_helper
INFO - 2020-02-15 13:33:28 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:33:28 --> Controller Class Initialized
INFO - 2020-02-15 13:33:28 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:33:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:33:28 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:33:28 --> Helper loaded: form_helper
INFO - 2020-02-15 13:33:28 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:33:28 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-15 13:33:28 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-15 13:33:28 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-15 13:33:28 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 42
INFO - 2020-02-15 13:33:28 --> Final output sent to browser
DEBUG - 2020-02-15 13:33:28 --> Total execution time: 0.8486
INFO - 2020-02-15 13:34:56 --> Config Class Initialized
INFO - 2020-02-15 13:34:56 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:34:57 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:34:57 --> Utf8 Class Initialized
INFO - 2020-02-15 13:34:57 --> URI Class Initialized
INFO - 2020-02-15 13:34:57 --> Router Class Initialized
INFO - 2020-02-15 13:34:57 --> Output Class Initialized
INFO - 2020-02-15 13:34:57 --> Security Class Initialized
DEBUG - 2020-02-15 13:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:34:57 --> Input Class Initialized
INFO - 2020-02-15 13:34:57 --> Language Class Initialized
INFO - 2020-02-15 13:34:57 --> Loader Class Initialized
INFO - 2020-02-15 13:34:57 --> Helper loaded: url_helper
INFO - 2020-02-15 13:34:57 --> Helper loaded: string_helper
INFO - 2020-02-15 13:34:57 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:34:57 --> Controller Class Initialized
INFO - 2020-02-15 13:34:57 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:34:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:34:57 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:34:57 --> Helper loaded: form_helper
INFO - 2020-02-15 13:34:57 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:34:57 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-15 13:34:57 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-15 13:34:57 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-15 13:34:57 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 42
INFO - 2020-02-15 13:34:57 --> Final output sent to browser
DEBUG - 2020-02-15 13:34:57 --> Total execution time: 0.9328
INFO - 2020-02-15 13:35:04 --> Config Class Initialized
INFO - 2020-02-15 13:35:04 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:35:04 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:35:04 --> Utf8 Class Initialized
INFO - 2020-02-15 13:35:04 --> URI Class Initialized
INFO - 2020-02-15 13:35:04 --> Router Class Initialized
INFO - 2020-02-15 13:35:05 --> Output Class Initialized
INFO - 2020-02-15 13:35:05 --> Security Class Initialized
DEBUG - 2020-02-15 13:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:35:05 --> Input Class Initialized
INFO - 2020-02-15 13:35:05 --> Language Class Initialized
INFO - 2020-02-15 13:35:05 --> Loader Class Initialized
INFO - 2020-02-15 13:35:05 --> Helper loaded: url_helper
INFO - 2020-02-15 13:35:05 --> Helper loaded: string_helper
INFO - 2020-02-15 13:35:05 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:35:05 --> Controller Class Initialized
INFO - 2020-02-15 13:35:05 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:35:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:35:05 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:35:05 --> Helper loaded: form_helper
INFO - 2020-02-15 13:35:05 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:35:05 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-15 13:35:05 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-15 13:35:05 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-15 13:35:05 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 42
INFO - 2020-02-15 13:35:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-15 13:35:05 --> Final output sent to browser
DEBUG - 2020-02-15 13:35:05 --> Total execution time: 1.1973
INFO - 2020-02-15 13:35:19 --> Config Class Initialized
INFO - 2020-02-15 13:35:19 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:35:19 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:35:19 --> Utf8 Class Initialized
INFO - 2020-02-15 13:35:19 --> URI Class Initialized
INFO - 2020-02-15 13:35:19 --> Router Class Initialized
INFO - 2020-02-15 13:35:19 --> Output Class Initialized
INFO - 2020-02-15 13:35:19 --> Security Class Initialized
DEBUG - 2020-02-15 13:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:35:19 --> Input Class Initialized
INFO - 2020-02-15 13:35:19 --> Language Class Initialized
INFO - 2020-02-15 13:35:19 --> Loader Class Initialized
INFO - 2020-02-15 13:35:19 --> Helper loaded: url_helper
INFO - 2020-02-15 13:35:19 --> Helper loaded: string_helper
INFO - 2020-02-15 13:35:19 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:35:19 --> Controller Class Initialized
INFO - 2020-02-15 13:35:19 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:35:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:35:19 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:35:19 --> Helper loaded: form_helper
INFO - 2020-02-15 13:35:19 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:35:19 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-15 13:35:19 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-15 13:35:19 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-15 13:35:19 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 42
INFO - 2020-02-15 13:35:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-15 13:35:19 --> Final output sent to browser
DEBUG - 2020-02-15 13:35:19 --> Total execution time: 0.7573
INFO - 2020-02-15 13:35:27 --> Config Class Initialized
INFO - 2020-02-15 13:35:27 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:35:27 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:35:27 --> Utf8 Class Initialized
INFO - 2020-02-15 13:35:27 --> URI Class Initialized
INFO - 2020-02-15 13:35:27 --> Router Class Initialized
INFO - 2020-02-15 13:35:27 --> Output Class Initialized
INFO - 2020-02-15 13:35:27 --> Security Class Initialized
DEBUG - 2020-02-15 13:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:35:27 --> Input Class Initialized
INFO - 2020-02-15 13:35:27 --> Language Class Initialized
INFO - 2020-02-15 13:35:27 --> Loader Class Initialized
INFO - 2020-02-15 13:35:27 --> Helper loaded: url_helper
INFO - 2020-02-15 13:35:27 --> Helper loaded: string_helper
INFO - 2020-02-15 13:35:27 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:35:27 --> Controller Class Initialized
INFO - 2020-02-15 13:35:27 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:35:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:35:27 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:35:27 --> Helper loaded: form_helper
INFO - 2020-02-15 13:35:27 --> Form Validation Class Initialized
INFO - 2020-02-15 13:35:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:35:28 --> Final output sent to browser
DEBUG - 2020-02-15 13:35:28 --> Total execution time: 0.7247
INFO - 2020-02-15 13:35:28 --> Config Class Initialized
INFO - 2020-02-15 13:35:28 --> Hooks Class Initialized
INFO - 2020-02-15 13:35:28 --> Config Class Initialized
DEBUG - 2020-02-15 13:35:28 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:35:28 --> Hooks Class Initialized
INFO - 2020-02-15 13:35:28 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:35:28 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:35:28 --> URI Class Initialized
INFO - 2020-02-15 13:35:28 --> Utf8 Class Initialized
INFO - 2020-02-15 13:35:28 --> Router Class Initialized
INFO - 2020-02-15 13:35:28 --> URI Class Initialized
INFO - 2020-02-15 13:35:28 --> Router Class Initialized
INFO - 2020-02-15 13:35:28 --> Output Class Initialized
INFO - 2020-02-15 13:35:28 --> Output Class Initialized
INFO - 2020-02-15 13:35:28 --> Security Class Initialized
INFO - 2020-02-15 13:35:28 --> Security Class Initialized
DEBUG - 2020-02-15 13:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:35:28 --> Input Class Initialized
DEBUG - 2020-02-15 13:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:35:28 --> Input Class Initialized
INFO - 2020-02-15 13:35:28 --> Language Class Initialized
INFO - 2020-02-15 13:35:28 --> Language Class Initialized
INFO - 2020-02-15 13:35:28 --> Loader Class Initialized
INFO - 2020-02-15 13:35:28 --> Helper loaded: url_helper
INFO - 2020-02-15 13:35:28 --> Loader Class Initialized
INFO - 2020-02-15 13:35:28 --> Helper loaded: string_helper
INFO - 2020-02-15 13:35:28 --> Helper loaded: url_helper
INFO - 2020-02-15 13:35:28 --> Helper loaded: string_helper
INFO - 2020-02-15 13:35:28 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:35:28 --> Database Driver Class Initialized
INFO - 2020-02-15 13:35:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-15 13:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:35:28 --> Controller Class Initialized
INFO - 2020-02-15 13:35:28 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:35:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:35:28 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:35:28 --> Helper loaded: form_helper
INFO - 2020-02-15 13:35:28 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:35:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:35:29 --> Final output sent to browser
DEBUG - 2020-02-15 13:35:29 --> Total execution time: 0.8962
INFO - 2020-02-15 13:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:35:29 --> Controller Class Initialized
INFO - 2020-02-15 13:35:29 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:35:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:35:29 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:35:29 --> Helper loaded: form_helper
INFO - 2020-02-15 13:35:29 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:35:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:35:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:35:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:35:29 --> Final output sent to browser
DEBUG - 2020-02-15 13:35:29 --> Total execution time: 1.1008
INFO - 2020-02-15 13:35:48 --> Config Class Initialized
INFO - 2020-02-15 13:35:48 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:35:48 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:35:48 --> Utf8 Class Initialized
INFO - 2020-02-15 13:35:48 --> URI Class Initialized
DEBUG - 2020-02-15 13:35:48 --> No URI present. Default controller set.
INFO - 2020-02-15 13:35:48 --> Router Class Initialized
INFO - 2020-02-15 13:35:48 --> Output Class Initialized
INFO - 2020-02-15 13:35:48 --> Security Class Initialized
DEBUG - 2020-02-15 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:35:48 --> Input Class Initialized
INFO - 2020-02-15 13:35:48 --> Language Class Initialized
INFO - 2020-02-15 13:35:48 --> Loader Class Initialized
INFO - 2020-02-15 13:35:48 --> Helper loaded: url_helper
INFO - 2020-02-15 13:35:48 --> Helper loaded: string_helper
INFO - 2020-02-15 13:35:49 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:35:49 --> Controller Class Initialized
INFO - 2020-02-15 13:35:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-15 13:35:49 --> Pagination Class Initialized
INFO - 2020-02-15 13:35:49 --> Model "M_show" initialized
INFO - 2020-02-15 13:35:49 --> Helper loaded: form_helper
INFO - 2020-02-15 13:35:49 --> Form Validation Class Initialized
INFO - 2020-02-15 13:35:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-15 13:35:50 --> Final output sent to browser
DEBUG - 2020-02-15 13:35:50 --> Total execution time: 2.3293
INFO - 2020-02-15 13:36:21 --> Config Class Initialized
INFO - 2020-02-15 13:36:21 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:36:21 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:36:21 --> Utf8 Class Initialized
INFO - 2020-02-15 13:36:21 --> URI Class Initialized
INFO - 2020-02-15 13:36:21 --> Router Class Initialized
INFO - 2020-02-15 13:36:21 --> Output Class Initialized
INFO - 2020-02-15 13:36:21 --> Security Class Initialized
DEBUG - 2020-02-15 13:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:36:22 --> Input Class Initialized
INFO - 2020-02-15 13:36:22 --> Language Class Initialized
INFO - 2020-02-15 13:36:22 --> Loader Class Initialized
INFO - 2020-02-15 13:36:22 --> Helper loaded: url_helper
INFO - 2020-02-15 13:36:22 --> Helper loaded: string_helper
INFO - 2020-02-15 13:36:22 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:36:22 --> Config Class Initialized
INFO - 2020-02-15 13:36:22 --> Hooks Class Initialized
INFO - 2020-02-15 13:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:36:22 --> Controller Class Initialized
DEBUG - 2020-02-15 13:36:22 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:36:22 --> Utf8 Class Initialized
INFO - 2020-02-15 13:36:22 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:36:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:36:22 --> URI Class Initialized
INFO - 2020-02-15 13:36:22 --> Model "M_pesan" initialized
DEBUG - 2020-02-15 13:36:22 --> No URI present. Default controller set.
INFO - 2020-02-15 13:36:22 --> Router Class Initialized
INFO - 2020-02-15 13:36:22 --> Helper loaded: form_helper
INFO - 2020-02-15 13:36:22 --> Form Validation Class Initialized
INFO - 2020-02-15 13:36:22 --> Output Class Initialized
INFO - 2020-02-15 13:36:22 --> Security Class Initialized
INFO - 2020-02-15 13:36:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:36:22 --> Final output sent to browser
DEBUG - 2020-02-15 13:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:36:22 --> Total execution time: 0.6610
INFO - 2020-02-15 13:36:22 --> Input Class Initialized
INFO - 2020-02-15 13:36:22 --> Language Class Initialized
INFO - 2020-02-15 13:36:22 --> Loader Class Initialized
INFO - 2020-02-15 13:36:22 --> Helper loaded: url_helper
INFO - 2020-02-15 13:36:22 --> Helper loaded: string_helper
INFO - 2020-02-15 13:36:22 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:36:22 --> Controller Class Initialized
INFO - 2020-02-15 13:36:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-15 13:36:22 --> Pagination Class Initialized
INFO - 2020-02-15 13:36:22 --> Model "M_show" initialized
INFO - 2020-02-15 13:36:22 --> Helper loaded: form_helper
INFO - 2020-02-15 13:36:22 --> Form Validation Class Initialized
INFO - 2020-02-15 13:36:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-15 13:36:22 --> Final output sent to browser
DEBUG - 2020-02-15 13:36:22 --> Total execution time: 0.5924
INFO - 2020-02-15 13:36:25 --> Config Class Initialized
INFO - 2020-02-15 13:36:25 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:36:25 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:36:25 --> Utf8 Class Initialized
INFO - 2020-02-15 13:36:25 --> URI Class Initialized
INFO - 2020-02-15 13:36:25 --> Router Class Initialized
INFO - 2020-02-15 13:36:26 --> Output Class Initialized
INFO - 2020-02-15 13:36:26 --> Security Class Initialized
DEBUG - 2020-02-15 13:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:36:26 --> Input Class Initialized
INFO - 2020-02-15 13:36:26 --> Language Class Initialized
INFO - 2020-02-15 13:36:26 --> Loader Class Initialized
INFO - 2020-02-15 13:36:26 --> Helper loaded: url_helper
INFO - 2020-02-15 13:36:26 --> Helper loaded: string_helper
INFO - 2020-02-15 13:36:26 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:36:26 --> Controller Class Initialized
INFO - 2020-02-15 13:36:26 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:36:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:36:26 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:36:26 --> Helper loaded: form_helper
INFO - 2020-02-15 13:36:26 --> Form Validation Class Initialized
INFO - 2020-02-15 13:36:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:36:26 --> Final output sent to browser
DEBUG - 2020-02-15 13:36:26 --> Total execution time: 1.0417
INFO - 2020-02-15 13:36:26 --> Config Class Initialized
INFO - 2020-02-15 13:36:26 --> Config Class Initialized
INFO - 2020-02-15 13:36:26 --> Hooks Class Initialized
INFO - 2020-02-15 13:36:26 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:36:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:36:26 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:36:26 --> Utf8 Class Initialized
INFO - 2020-02-15 13:36:26 --> Utf8 Class Initialized
INFO - 2020-02-15 13:36:26 --> URI Class Initialized
INFO - 2020-02-15 13:36:26 --> URI Class Initialized
INFO - 2020-02-15 13:36:26 --> Router Class Initialized
INFO - 2020-02-15 13:36:26 --> Router Class Initialized
INFO - 2020-02-15 13:36:26 --> Output Class Initialized
INFO - 2020-02-15 13:36:26 --> Output Class Initialized
INFO - 2020-02-15 13:36:26 --> Security Class Initialized
INFO - 2020-02-15 13:36:26 --> Security Class Initialized
DEBUG - 2020-02-15 13:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:36:27 --> Input Class Initialized
INFO - 2020-02-15 13:36:27 --> Input Class Initialized
INFO - 2020-02-15 13:36:27 --> Language Class Initialized
INFO - 2020-02-15 13:36:27 --> Language Class Initialized
INFO - 2020-02-15 13:36:27 --> Loader Class Initialized
INFO - 2020-02-15 13:36:27 --> Loader Class Initialized
INFO - 2020-02-15 13:36:27 --> Helper loaded: url_helper
INFO - 2020-02-15 13:36:27 --> Helper loaded: url_helper
INFO - 2020-02-15 13:36:27 --> Helper loaded: string_helper
INFO - 2020-02-15 13:36:27 --> Helper loaded: string_helper
INFO - 2020-02-15 13:36:27 --> Database Driver Class Initialized
INFO - 2020-02-15 13:36:27 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 13:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:36:27 --> Controller Class Initialized
INFO - 2020-02-15 13:36:27 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:36:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:36:27 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:36:27 --> Helper loaded: form_helper
INFO - 2020-02-15 13:36:27 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:36:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:36:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:36:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:36:27 --> Final output sent to browser
DEBUG - 2020-02-15 13:36:27 --> Total execution time: 0.7375
INFO - 2020-02-15 13:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:36:27 --> Controller Class Initialized
INFO - 2020-02-15 13:36:27 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:36:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:36:27 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:36:27 --> Helper loaded: form_helper
INFO - 2020-02-15 13:36:27 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:36:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:36:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:36:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:36:27 --> Final output sent to browser
DEBUG - 2020-02-15 13:36:27 --> Total execution time: 1.0241
INFO - 2020-02-15 13:36:28 --> Config Class Initialized
INFO - 2020-02-15 13:36:28 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:36:28 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:36:28 --> Utf8 Class Initialized
INFO - 2020-02-15 13:36:28 --> URI Class Initialized
DEBUG - 2020-02-15 13:36:28 --> No URI present. Default controller set.
INFO - 2020-02-15 13:36:28 --> Router Class Initialized
INFO - 2020-02-15 13:36:28 --> Output Class Initialized
INFO - 2020-02-15 13:36:28 --> Security Class Initialized
DEBUG - 2020-02-15 13:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:36:28 --> Input Class Initialized
INFO - 2020-02-15 13:36:28 --> Language Class Initialized
INFO - 2020-02-15 13:36:29 --> Loader Class Initialized
INFO - 2020-02-15 13:36:29 --> Helper loaded: url_helper
INFO - 2020-02-15 13:36:29 --> Helper loaded: string_helper
INFO - 2020-02-15 13:36:29 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:36:29 --> Controller Class Initialized
INFO - 2020-02-15 13:36:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-15 13:36:29 --> Pagination Class Initialized
INFO - 2020-02-15 13:36:29 --> Model "M_show" initialized
INFO - 2020-02-15 13:36:29 --> Helper loaded: form_helper
INFO - 2020-02-15 13:36:29 --> Form Validation Class Initialized
INFO - 2020-02-15 13:36:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-15 13:36:29 --> Final output sent to browser
DEBUG - 2020-02-15 13:36:29 --> Total execution time: 1.1054
INFO - 2020-02-15 13:36:52 --> Config Class Initialized
INFO - 2020-02-15 13:36:52 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:36:52 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:36:52 --> Utf8 Class Initialized
INFO - 2020-02-15 13:36:53 --> URI Class Initialized
INFO - 2020-02-15 13:36:53 --> Router Class Initialized
INFO - 2020-02-15 13:36:53 --> Output Class Initialized
INFO - 2020-02-15 13:36:53 --> Security Class Initialized
DEBUG - 2020-02-15 13:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:36:53 --> Input Class Initialized
INFO - 2020-02-15 13:36:53 --> Language Class Initialized
ERROR - 2020-02-15 13:36:53 --> 404 Page Not Found: Upload_bukti/index
INFO - 2020-02-15 13:37:03 --> Config Class Initialized
INFO - 2020-02-15 13:37:04 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:37:04 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:37:04 --> Utf8 Class Initialized
INFO - 2020-02-15 13:37:04 --> URI Class Initialized
INFO - 2020-02-15 13:37:04 --> Router Class Initialized
INFO - 2020-02-15 13:37:04 --> Output Class Initialized
INFO - 2020-02-15 13:37:04 --> Security Class Initialized
DEBUG - 2020-02-15 13:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:37:04 --> Input Class Initialized
INFO - 2020-02-15 13:37:04 --> Language Class Initialized
INFO - 2020-02-15 13:37:04 --> Loader Class Initialized
INFO - 2020-02-15 13:37:04 --> Helper loaded: url_helper
INFO - 2020-02-15 13:37:04 --> Helper loaded: string_helper
INFO - 2020-02-15 13:37:04 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:37:04 --> Controller Class Initialized
INFO - 2020-02-15 13:37:04 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:37:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:37:04 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:37:04 --> Helper loaded: form_helper
INFO - 2020-02-15 13:37:04 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:37:04 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-15 13:37:19 --> Config Class Initialized
INFO - 2020-02-15 13:37:19 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:37:19 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:37:19 --> Utf8 Class Initialized
INFO - 2020-02-15 13:37:19 --> URI Class Initialized
INFO - 2020-02-15 13:37:19 --> Router Class Initialized
INFO - 2020-02-15 13:37:19 --> Output Class Initialized
INFO - 2020-02-15 13:37:19 --> Security Class Initialized
DEBUG - 2020-02-15 13:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:37:19 --> Input Class Initialized
INFO - 2020-02-15 13:37:19 --> Language Class Initialized
INFO - 2020-02-15 13:37:19 --> Loader Class Initialized
INFO - 2020-02-15 13:37:19 --> Helper loaded: url_helper
INFO - 2020-02-15 13:37:19 --> Helper loaded: string_helper
INFO - 2020-02-15 13:37:19 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:37:19 --> Controller Class Initialized
INFO - 2020-02-15 13:37:19 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:37:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:37:19 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:37:19 --> Helper loaded: form_helper
INFO - 2020-02-15 13:37:19 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:37:20 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-15 13:37:20 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-15 13:37:20 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-15 13:37:20 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 42
INFO - 2020-02-15 13:37:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-15 13:37:20 --> Final output sent to browser
DEBUG - 2020-02-15 13:37:20 --> Total execution time: 0.6455
INFO - 2020-02-15 13:37:37 --> Config Class Initialized
INFO - 2020-02-15 13:37:37 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:37:37 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:37:37 --> Utf8 Class Initialized
INFO - 2020-02-15 13:37:37 --> URI Class Initialized
INFO - 2020-02-15 13:37:37 --> Router Class Initialized
INFO - 2020-02-15 13:37:37 --> Output Class Initialized
INFO - 2020-02-15 13:37:37 --> Security Class Initialized
DEBUG - 2020-02-15 13:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:37:37 --> Input Class Initialized
INFO - 2020-02-15 13:37:37 --> Language Class Initialized
INFO - 2020-02-15 13:37:37 --> Loader Class Initialized
INFO - 2020-02-15 13:37:37 --> Helper loaded: url_helper
INFO - 2020-02-15 13:37:37 --> Helper loaded: string_helper
INFO - 2020-02-15 13:37:37 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:37:37 --> Controller Class Initialized
INFO - 2020-02-15 13:37:37 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:37:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:37:37 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:37:37 --> Helper loaded: form_helper
INFO - 2020-02-15 13:37:37 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:37:37 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-15 13:37:37 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-15 13:37:37 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-15 13:37:37 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 42
INFO - 2020-02-15 13:37:38 --> Config Class Initialized
INFO - 2020-02-15 13:37:38 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:37:38 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:37:38 --> Utf8 Class Initialized
INFO - 2020-02-15 13:37:38 --> URI Class Initialized
INFO - 2020-02-15 13:37:38 --> Router Class Initialized
INFO - 2020-02-15 13:37:38 --> Output Class Initialized
INFO - 2020-02-15 13:37:38 --> Security Class Initialized
DEBUG - 2020-02-15 13:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:37:38 --> Input Class Initialized
INFO - 2020-02-15 13:37:38 --> Language Class Initialized
INFO - 2020-02-15 13:37:38 --> Loader Class Initialized
INFO - 2020-02-15 13:37:38 --> Helper loaded: url_helper
INFO - 2020-02-15 13:37:38 --> Helper loaded: string_helper
INFO - 2020-02-15 13:37:38 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:37:38 --> Controller Class Initialized
INFO - 2020-02-15 13:37:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-15 13:37:38 --> Pagination Class Initialized
INFO - 2020-02-15 13:37:38 --> Model "M_show" initialized
INFO - 2020-02-15 13:37:38 --> Helper loaded: form_helper
INFO - 2020-02-15 13:37:38 --> Form Validation Class Initialized
INFO - 2020-02-15 13:37:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-15 13:37:38 --> Final output sent to browser
DEBUG - 2020-02-15 13:37:38 --> Total execution time: 0.5681
INFO - 2020-02-15 13:37:38 --> Config Class Initialized
INFO - 2020-02-15 13:37:38 --> Config Class Initialized
INFO - 2020-02-15 13:37:38 --> Hooks Class Initialized
INFO - 2020-02-15 13:37:38 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:37:38 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:37:38 --> Utf8 Class Initialized
INFO - 2020-02-15 13:37:38 --> Utf8 Class Initialized
INFO - 2020-02-15 13:37:39 --> URI Class Initialized
INFO - 2020-02-15 13:37:39 --> URI Class Initialized
INFO - 2020-02-15 13:37:39 --> Router Class Initialized
INFO - 2020-02-15 13:37:39 --> Router Class Initialized
INFO - 2020-02-15 13:37:39 --> Output Class Initialized
INFO - 2020-02-15 13:37:39 --> Output Class Initialized
INFO - 2020-02-15 13:37:39 --> Security Class Initialized
INFO - 2020-02-15 13:37:39 --> Security Class Initialized
DEBUG - 2020-02-15 13:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:37:39 --> Input Class Initialized
INFO - 2020-02-15 13:37:39 --> Input Class Initialized
INFO - 2020-02-15 13:37:39 --> Language Class Initialized
INFO - 2020-02-15 13:37:39 --> Language Class Initialized
ERROR - 2020-02-15 13:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-15 13:37:39 --> 404 Page Not Found: Assets/js
INFO - 2020-02-15 13:37:39 --> Config Class Initialized
INFO - 2020-02-15 13:37:39 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:37:39 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:37:39 --> Utf8 Class Initialized
INFO - 2020-02-15 13:37:39 --> URI Class Initialized
INFO - 2020-02-15 13:37:39 --> Router Class Initialized
INFO - 2020-02-15 13:37:39 --> Output Class Initialized
INFO - 2020-02-15 13:37:39 --> Security Class Initialized
DEBUG - 2020-02-15 13:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:37:39 --> Input Class Initialized
INFO - 2020-02-15 13:37:39 --> Language Class Initialized
ERROR - 2020-02-15 13:37:39 --> 404 Page Not Found: Assets/js
INFO - 2020-02-15 13:37:52 --> Config Class Initialized
INFO - 2020-02-15 13:37:53 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:37:53 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:37:53 --> Utf8 Class Initialized
INFO - 2020-02-15 13:37:53 --> URI Class Initialized
INFO - 2020-02-15 13:37:53 --> Router Class Initialized
INFO - 2020-02-15 13:37:53 --> Output Class Initialized
INFO - 2020-02-15 13:37:53 --> Security Class Initialized
DEBUG - 2020-02-15 13:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:37:53 --> Input Class Initialized
INFO - 2020-02-15 13:37:53 --> Language Class Initialized
INFO - 2020-02-15 13:37:53 --> Loader Class Initialized
INFO - 2020-02-15 13:37:53 --> Helper loaded: url_helper
INFO - 2020-02-15 13:37:53 --> Helper loaded: string_helper
INFO - 2020-02-15 13:37:53 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:37:53 --> Controller Class Initialized
INFO - 2020-02-15 13:37:53 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:37:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:37:53 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:37:54 --> Helper loaded: form_helper
INFO - 2020-02-15 13:37:54 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:37:54 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-15 13:37:57 --> Config Class Initialized
INFO - 2020-02-15 13:37:57 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:37:57 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:37:57 --> Utf8 Class Initialized
INFO - 2020-02-15 13:37:57 --> URI Class Initialized
INFO - 2020-02-15 13:37:57 --> Router Class Initialized
INFO - 2020-02-15 13:37:57 --> Output Class Initialized
INFO - 2020-02-15 13:37:57 --> Security Class Initialized
DEBUG - 2020-02-15 13:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:37:57 --> Input Class Initialized
INFO - 2020-02-15 13:37:57 --> Language Class Initialized
INFO - 2020-02-15 13:37:57 --> Loader Class Initialized
INFO - 2020-02-15 13:37:57 --> Helper loaded: url_helper
INFO - 2020-02-15 13:37:58 --> Helper loaded: string_helper
INFO - 2020-02-15 13:37:58 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:37:58 --> Controller Class Initialized
INFO - 2020-02-15 13:37:58 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:37:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:37:58 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:37:58 --> Helper loaded: form_helper
INFO - 2020-02-15 13:37:58 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:37:58 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-15 13:37:58 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-15 13:37:58 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-15 13:37:58 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 42
INFO - 2020-02-15 13:37:58 --> Config Class Initialized
INFO - 2020-02-15 13:37:58 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:37:58 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:37:58 --> Utf8 Class Initialized
INFO - 2020-02-15 13:37:58 --> URI Class Initialized
INFO - 2020-02-15 13:37:58 --> Router Class Initialized
INFO - 2020-02-15 13:37:58 --> Output Class Initialized
INFO - 2020-02-15 13:37:58 --> Security Class Initialized
DEBUG - 2020-02-15 13:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:37:58 --> Input Class Initialized
INFO - 2020-02-15 13:37:58 --> Language Class Initialized
INFO - 2020-02-15 13:37:58 --> Loader Class Initialized
INFO - 2020-02-15 13:37:58 --> Helper loaded: url_helper
INFO - 2020-02-15 13:37:58 --> Helper loaded: string_helper
INFO - 2020-02-15 13:37:58 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:37:58 --> Controller Class Initialized
INFO - 2020-02-15 13:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-15 13:37:58 --> Pagination Class Initialized
INFO - 2020-02-15 13:37:58 --> Model "M_show" initialized
INFO - 2020-02-15 13:37:58 --> Helper loaded: form_helper
INFO - 2020-02-15 13:37:58 --> Form Validation Class Initialized
INFO - 2020-02-15 13:37:58 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-15 13:37:58 --> Final output sent to browser
DEBUG - 2020-02-15 13:37:59 --> Total execution time: 0.5806
INFO - 2020-02-15 13:37:59 --> Config Class Initialized
INFO - 2020-02-15 13:37:59 --> Config Class Initialized
INFO - 2020-02-15 13:37:59 --> Hooks Class Initialized
INFO - 2020-02-15 13:37:59 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:37:59 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:37:59 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:37:59 --> Utf8 Class Initialized
INFO - 2020-02-15 13:37:59 --> Utf8 Class Initialized
INFO - 2020-02-15 13:37:59 --> URI Class Initialized
INFO - 2020-02-15 13:37:59 --> URI Class Initialized
INFO - 2020-02-15 13:37:59 --> Router Class Initialized
INFO - 2020-02-15 13:37:59 --> Router Class Initialized
INFO - 2020-02-15 13:37:59 --> Output Class Initialized
INFO - 2020-02-15 13:37:59 --> Output Class Initialized
INFO - 2020-02-15 13:37:59 --> Security Class Initialized
INFO - 2020-02-15 13:37:59 --> Security Class Initialized
DEBUG - 2020-02-15 13:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:37:59 --> Input Class Initialized
INFO - 2020-02-15 13:37:59 --> Input Class Initialized
INFO - 2020-02-15 13:37:59 --> Language Class Initialized
INFO - 2020-02-15 13:37:59 --> Language Class Initialized
ERROR - 2020-02-15 13:37:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-15 13:37:59 --> 404 Page Not Found: Assets/js
INFO - 2020-02-15 13:37:59 --> Config Class Initialized
INFO - 2020-02-15 13:37:59 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:37:59 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:37:59 --> Utf8 Class Initialized
INFO - 2020-02-15 13:37:59 --> URI Class Initialized
INFO - 2020-02-15 13:37:59 --> Router Class Initialized
INFO - 2020-02-15 13:37:59 --> Output Class Initialized
INFO - 2020-02-15 13:38:00 --> Security Class Initialized
DEBUG - 2020-02-15 13:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:38:00 --> Input Class Initialized
INFO - 2020-02-15 13:38:00 --> Language Class Initialized
ERROR - 2020-02-15 13:38:00 --> 404 Page Not Found: Assets/js
INFO - 2020-02-15 13:38:12 --> Config Class Initialized
INFO - 2020-02-15 13:38:12 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:38:12 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:38:12 --> Utf8 Class Initialized
INFO - 2020-02-15 13:38:12 --> URI Class Initialized
INFO - 2020-02-15 13:38:12 --> Router Class Initialized
INFO - 2020-02-15 13:38:12 --> Output Class Initialized
INFO - 2020-02-15 13:38:12 --> Security Class Initialized
DEBUG - 2020-02-15 13:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:38:13 --> Input Class Initialized
INFO - 2020-02-15 13:38:13 --> Language Class Initialized
INFO - 2020-02-15 13:38:13 --> Loader Class Initialized
INFO - 2020-02-15 13:38:13 --> Helper loaded: url_helper
INFO - 2020-02-15 13:38:13 --> Helper loaded: string_helper
INFO - 2020-02-15 13:38:13 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:38:13 --> Controller Class Initialized
INFO - 2020-02-15 13:38:13 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:38:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:38:13 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:38:13 --> Helper loaded: form_helper
INFO - 2020-02-15 13:38:13 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:38:13 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-15 13:38:17 --> Config Class Initialized
INFO - 2020-02-15 13:38:17 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:38:17 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:38:17 --> Utf8 Class Initialized
INFO - 2020-02-15 13:38:17 --> URI Class Initialized
INFO - 2020-02-15 13:38:17 --> Router Class Initialized
INFO - 2020-02-15 13:38:17 --> Output Class Initialized
INFO - 2020-02-15 13:38:17 --> Security Class Initialized
DEBUG - 2020-02-15 13:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:38:17 --> Input Class Initialized
INFO - 2020-02-15 13:38:17 --> Language Class Initialized
INFO - 2020-02-15 13:38:17 --> Loader Class Initialized
INFO - 2020-02-15 13:38:17 --> Helper loaded: url_helper
INFO - 2020-02-15 13:38:17 --> Helper loaded: string_helper
INFO - 2020-02-15 13:38:17 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:38:17 --> Controller Class Initialized
INFO - 2020-02-15 13:38:17 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:38:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:38:17 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:38:17 --> Helper loaded: form_helper
INFO - 2020-02-15 13:38:17 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:38:17 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-15 13:38:17 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
ERROR - 2020-02-15 13:38:17 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 33
ERROR - 2020-02-15 13:38:17 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 42
INFO - 2020-02-15 13:38:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-15 13:38:17 --> Final output sent to browser
DEBUG - 2020-02-15 13:38:17 --> Total execution time: 0.7080
INFO - 2020-02-15 13:42:56 --> Config Class Initialized
INFO - 2020-02-15 13:42:56 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:42:56 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:42:56 --> Utf8 Class Initialized
INFO - 2020-02-15 13:42:56 --> URI Class Initialized
DEBUG - 2020-02-15 13:42:56 --> No URI present. Default controller set.
INFO - 2020-02-15 13:42:56 --> Router Class Initialized
INFO - 2020-02-15 13:42:56 --> Output Class Initialized
INFO - 2020-02-15 13:42:56 --> Security Class Initialized
DEBUG - 2020-02-15 13:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:42:56 --> Input Class Initialized
INFO - 2020-02-15 13:42:56 --> Language Class Initialized
INFO - 2020-02-15 13:42:56 --> Loader Class Initialized
INFO - 2020-02-15 13:42:56 --> Helper loaded: url_helper
INFO - 2020-02-15 13:42:56 --> Helper loaded: string_helper
INFO - 2020-02-15 13:42:56 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:42:57 --> Controller Class Initialized
INFO - 2020-02-15 13:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-15 13:42:57 --> Pagination Class Initialized
INFO - 2020-02-15 13:42:57 --> Model "M_show" initialized
INFO - 2020-02-15 13:42:57 --> Helper loaded: form_helper
INFO - 2020-02-15 13:42:57 --> Form Validation Class Initialized
INFO - 2020-02-15 13:42:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-15 13:42:57 --> Final output sent to browser
DEBUG - 2020-02-15 13:42:57 --> Total execution time: 0.6630
INFO - 2020-02-15 13:42:59 --> Config Class Initialized
INFO - 2020-02-15 13:42:59 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:42:59 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:42:59 --> Utf8 Class Initialized
INFO - 2020-02-15 13:42:59 --> URI Class Initialized
INFO - 2020-02-15 13:43:00 --> Router Class Initialized
INFO - 2020-02-15 13:43:00 --> Output Class Initialized
INFO - 2020-02-15 13:43:00 --> Security Class Initialized
DEBUG - 2020-02-15 13:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:00 --> Input Class Initialized
INFO - 2020-02-15 13:43:00 --> Language Class Initialized
INFO - 2020-02-15 13:43:00 --> Loader Class Initialized
INFO - 2020-02-15 13:43:00 --> Helper loaded: url_helper
INFO - 2020-02-15 13:43:00 --> Helper loaded: string_helper
INFO - 2020-02-15 13:43:00 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:43:00 --> Controller Class Initialized
INFO - 2020-02-15 13:43:00 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:43:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:43:00 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:43:00 --> Helper loaded: form_helper
INFO - 2020-02-15 13:43:00 --> Form Validation Class Initialized
INFO - 2020-02-15 13:43:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:43:00 --> Final output sent to browser
DEBUG - 2020-02-15 13:43:00 --> Total execution time: 0.9598
INFO - 2020-02-15 13:43:00 --> Config Class Initialized
INFO - 2020-02-15 13:43:00 --> Config Class Initialized
INFO - 2020-02-15 13:43:00 --> Hooks Class Initialized
INFO - 2020-02-15 13:43:00 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:43:00 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:00 --> Config Class Initialized
INFO - 2020-02-15 13:43:00 --> Config Class Initialized
INFO - 2020-02-15 13:43:00 --> Config Class Initialized
INFO - 2020-02-15 13:43:00 --> Config Class Initialized
INFO - 2020-02-15 13:43:00 --> Hooks Class Initialized
INFO - 2020-02-15 13:43:00 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:00 --> Hooks Class Initialized
INFO - 2020-02-15 13:43:00 --> Hooks Class Initialized
INFO - 2020-02-15 13:43:00 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:43:00 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:00 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:00 --> URI Class Initialized
DEBUG - 2020-02-15 13:43:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:43:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:43:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:43:00 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:00 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:00 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:00 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:00 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:00 --> URI Class Initialized
INFO - 2020-02-15 13:43:00 --> Router Class Initialized
INFO - 2020-02-15 13:43:00 --> URI Class Initialized
INFO - 2020-02-15 13:43:00 --> Output Class Initialized
INFO - 2020-02-15 13:43:00 --> URI Class Initialized
INFO - 2020-02-15 13:43:00 --> URI Class Initialized
INFO - 2020-02-15 13:43:00 --> URI Class Initialized
INFO - 2020-02-15 13:43:00 --> Router Class Initialized
INFO - 2020-02-15 13:43:00 --> Router Class Initialized
INFO - 2020-02-15 13:43:00 --> Router Class Initialized
INFO - 2020-02-15 13:43:00 --> Output Class Initialized
INFO - 2020-02-15 13:43:00 --> Router Class Initialized
INFO - 2020-02-15 13:43:00 --> Router Class Initialized
INFO - 2020-02-15 13:43:00 --> Security Class Initialized
DEBUG - 2020-02-15 13:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:00 --> Security Class Initialized
INFO - 2020-02-15 13:43:00 --> Output Class Initialized
INFO - 2020-02-15 13:43:00 --> Output Class Initialized
INFO - 2020-02-15 13:43:00 --> Output Class Initialized
INFO - 2020-02-15 13:43:00 --> Output Class Initialized
INFO - 2020-02-15 13:43:00 --> Input Class Initialized
DEBUG - 2020-02-15 13:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:00 --> Security Class Initialized
INFO - 2020-02-15 13:43:00 --> Security Class Initialized
INFO - 2020-02-15 13:43:00 --> Security Class Initialized
INFO - 2020-02-15 13:43:00 --> Security Class Initialized
INFO - 2020-02-15 13:43:00 --> Input Class Initialized
INFO - 2020-02-15 13:43:00 --> Language Class Initialized
DEBUG - 2020-02-15 13:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:01 --> Input Class Initialized
INFO - 2020-02-15 13:43:01 --> Input Class Initialized
INFO - 2020-02-15 13:43:01 --> Input Class Initialized
INFO - 2020-02-15 13:43:01 --> Input Class Initialized
INFO - 2020-02-15 13:43:01 --> Language Class Initialized
ERROR - 2020-02-15 13:43:01 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-15 13:43:01 --> Language Class Initialized
INFO - 2020-02-15 13:43:01 --> Language Class Initialized
INFO - 2020-02-15 13:43:01 --> Language Class Initialized
INFO - 2020-02-15 13:43:01 --> Language Class Initialized
INFO - 2020-02-15 13:43:01 --> Loader Class Initialized
INFO - 2020-02-15 13:43:01 --> Config Class Initialized
INFO - 2020-02-15 13:43:01 --> Hooks Class Initialized
ERROR - 2020-02-15 13:43:01 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-15 13:43:01 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-15 13:43:01 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 13:43:01 --> Helper loaded: url_helper
INFO - 2020-02-15 13:43:01 --> Loader Class Initialized
INFO - 2020-02-15 13:43:01 --> Helper loaded: string_helper
DEBUG - 2020-02-15 13:43:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:01 --> Helper loaded: url_helper
INFO - 2020-02-15 13:43:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:01 --> Config Class Initialized
INFO - 2020-02-15 13:43:01 --> Helper loaded: string_helper
INFO - 2020-02-15 13:43:01 --> Config Class Initialized
INFO - 2020-02-15 13:43:01 --> Config Class Initialized
INFO - 2020-02-15 13:43:01 --> Database Driver Class Initialized
INFO - 2020-02-15 13:43:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:43:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:43:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:43:01 --> URI Class Initialized
DEBUG - 2020-02-15 13:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:43:01 --> Database Driver Class Initialized
INFO - 2020-02-15 13:43:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-15 13:43:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:43:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:01 --> Router Class Initialized
DEBUG - 2020-02-15 13:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 13:43:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:01 --> Controller Class Initialized
INFO - 2020-02-15 13:43:01 --> Output Class Initialized
INFO - 2020-02-15 13:43:01 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:43:01 --> URI Class Initialized
INFO - 2020-02-15 13:43:01 --> Security Class Initialized
INFO - 2020-02-15 13:43:01 --> URI Class Initialized
INFO - 2020-02-15 13:43:01 --> URI Class Initialized
DEBUG - 2020-02-15 13:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:01 --> Router Class Initialized
INFO - 2020-02-15 13:43:01 --> Router Class Initialized
INFO - 2020-02-15 13:43:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:43:01 --> Router Class Initialized
INFO - 2020-02-15 13:43:01 --> Input Class Initialized
INFO - 2020-02-15 13:43:01 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:43:01 --> Output Class Initialized
INFO - 2020-02-15 13:43:01 --> Output Class Initialized
INFO - 2020-02-15 13:43:01 --> Output Class Initialized
INFO - 2020-02-15 13:43:01 --> Language Class Initialized
INFO - 2020-02-15 13:43:01 --> Security Class Initialized
INFO - 2020-02-15 13:43:01 --> Security Class Initialized
INFO - 2020-02-15 13:43:01 --> Security Class Initialized
INFO - 2020-02-15 13:43:01 --> Helper loaded: form_helper
INFO - 2020-02-15 13:43:01 --> Form Validation Class Initialized
DEBUG - 2020-02-15 13:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:43:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-15 13:43:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 13:43:01 --> Input Class Initialized
INFO - 2020-02-15 13:43:01 --> Input Class Initialized
INFO - 2020-02-15 13:43:01 --> Input Class Initialized
ERROR - 2020-02-15 13:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-15 13:43:01 --> Config Class Initialized
INFO - 2020-02-15 13:43:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:43:01 --> Language Class Initialized
INFO - 2020-02-15 13:43:01 --> Language Class Initialized
ERROR - 2020-02-15 13:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:43:01 --> Language Class Initialized
ERROR - 2020-02-15 13:43:01 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-15 13:43:01 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-15 13:43:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:43:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-15 13:43:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:01 --> Final output sent to browser
INFO - 2020-02-15 13:43:01 --> Config Class Initialized
INFO - 2020-02-15 13:43:01 --> Config Class Initialized
INFO - 2020-02-15 13:43:01 --> Config Class Initialized
INFO - 2020-02-15 13:43:01 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:43:01 --> Total execution time: 0.7719
INFO - 2020-02-15 13:43:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:43:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:43:01 --> URI Class Initialized
INFO - 2020-02-15 13:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:43:01 --> Router Class Initialized
DEBUG - 2020-02-15 13:43:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:43:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:43:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:01 --> Controller Class Initialized
INFO - 2020-02-15 13:43:01 --> Output Class Initialized
INFO - 2020-02-15 13:43:01 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:43:01 --> URI Class Initialized
INFO - 2020-02-15 13:43:01 --> URI Class Initialized
INFO - 2020-02-15 13:43:01 --> URI Class Initialized
INFO - 2020-02-15 13:43:01 --> Security Class Initialized
INFO - 2020-02-15 13:43:01 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-15 13:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:01 --> Router Class Initialized
INFO - 2020-02-15 13:43:01 --> Router Class Initialized
INFO - 2020-02-15 13:43:01 --> Router Class Initialized
INFO - 2020-02-15 13:43:01 --> Input Class Initialized
INFO - 2020-02-15 13:43:01 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:43:01 --> Output Class Initialized
INFO - 2020-02-15 13:43:01 --> Output Class Initialized
INFO - 2020-02-15 13:43:01 --> Output Class Initialized
INFO - 2020-02-15 13:43:01 --> Security Class Initialized
INFO - 2020-02-15 13:43:01 --> Security Class Initialized
INFO - 2020-02-15 13:43:01 --> Security Class Initialized
INFO - 2020-02-15 13:43:01 --> Language Class Initialized
INFO - 2020-02-15 13:43:01 --> Helper loaded: form_helper
INFO - 2020-02-15 13:43:01 --> Form Validation Class Initialized
DEBUG - 2020-02-15 13:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:43:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-15 13:43:01 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-15 13:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:01 --> Input Class Initialized
INFO - 2020-02-15 13:43:01 --> Input Class Initialized
INFO - 2020-02-15 13:43:01 --> Input Class Initialized
ERROR - 2020-02-15 13:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-15 13:43:01 --> Language Class Initialized
ERROR - 2020-02-15 13:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:43:01 --> Language Class Initialized
INFO - 2020-02-15 13:43:01 --> Language Class Initialized
INFO - 2020-02-15 13:43:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-15 13:43:01 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-15 13:43:01 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-15 13:43:01 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 13:43:01 --> Final output sent to browser
INFO - 2020-02-15 13:43:01 --> Config Class Initialized
INFO - 2020-02-15 13:43:01 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:43:01 --> Total execution time: 1.0911
DEBUG - 2020-02-15 13:43:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:01 --> URI Class Initialized
INFO - 2020-02-15 13:43:01 --> Router Class Initialized
INFO - 2020-02-15 13:43:01 --> Output Class Initialized
INFO - 2020-02-15 13:43:01 --> Security Class Initialized
DEBUG - 2020-02-15 13:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:02 --> Input Class Initialized
INFO - 2020-02-15 13:43:02 --> Language Class Initialized
ERROR - 2020-02-15 13:43:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 13:43:02 --> Config Class Initialized
INFO - 2020-02-15 13:43:02 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:43:02 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:02 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:02 --> URI Class Initialized
INFO - 2020-02-15 13:43:02 --> Router Class Initialized
INFO - 2020-02-15 13:43:02 --> Output Class Initialized
INFO - 2020-02-15 13:43:02 --> Security Class Initialized
DEBUG - 2020-02-15 13:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:02 --> Input Class Initialized
INFO - 2020-02-15 13:43:02 --> Language Class Initialized
ERROR - 2020-02-15 13:43:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:43:02 --> Config Class Initialized
INFO - 2020-02-15 13:43:02 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:43:02 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:02 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:02 --> URI Class Initialized
INFO - 2020-02-15 13:43:02 --> Router Class Initialized
INFO - 2020-02-15 13:43:02 --> Output Class Initialized
INFO - 2020-02-15 13:43:02 --> Security Class Initialized
DEBUG - 2020-02-15 13:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:02 --> Input Class Initialized
INFO - 2020-02-15 13:43:02 --> Language Class Initialized
ERROR - 2020-02-15 13:43:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:43:02 --> Config Class Initialized
INFO - 2020-02-15 13:43:02 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:43:02 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:03 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:03 --> URI Class Initialized
INFO - 2020-02-15 13:43:03 --> Router Class Initialized
INFO - 2020-02-15 13:43:03 --> Output Class Initialized
INFO - 2020-02-15 13:43:03 --> Security Class Initialized
DEBUG - 2020-02-15 13:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:03 --> Input Class Initialized
INFO - 2020-02-15 13:43:03 --> Language Class Initialized
ERROR - 2020-02-15 13:43:03 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 13:43:03 --> Config Class Initialized
INFO - 2020-02-15 13:43:03 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:43:03 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:03 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:03 --> URI Class Initialized
INFO - 2020-02-15 13:43:03 --> Router Class Initialized
INFO - 2020-02-15 13:43:03 --> Output Class Initialized
INFO - 2020-02-15 13:43:03 --> Security Class Initialized
DEBUG - 2020-02-15 13:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:03 --> Input Class Initialized
INFO - 2020-02-15 13:43:03 --> Language Class Initialized
ERROR - 2020-02-15 13:43:03 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 13:43:03 --> Config Class Initialized
INFO - 2020-02-15 13:43:03 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:43:03 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:03 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:03 --> URI Class Initialized
INFO - 2020-02-15 13:43:03 --> Router Class Initialized
INFO - 2020-02-15 13:43:03 --> Output Class Initialized
INFO - 2020-02-15 13:43:03 --> Security Class Initialized
DEBUG - 2020-02-15 13:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:03 --> Input Class Initialized
INFO - 2020-02-15 13:43:03 --> Language Class Initialized
ERROR - 2020-02-15 13:43:03 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 13:43:03 --> Config Class Initialized
INFO - 2020-02-15 13:43:03 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:43:03 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:03 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:03 --> URI Class Initialized
INFO - 2020-02-15 13:43:03 --> Router Class Initialized
INFO - 2020-02-15 13:43:03 --> Output Class Initialized
INFO - 2020-02-15 13:43:04 --> Security Class Initialized
DEBUG - 2020-02-15 13:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:04 --> Input Class Initialized
INFO - 2020-02-15 13:43:04 --> Language Class Initialized
ERROR - 2020-02-15 13:43:04 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 13:43:29 --> Config Class Initialized
INFO - 2020-02-15 13:43:29 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:43:29 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:43:29 --> Utf8 Class Initialized
INFO - 2020-02-15 13:43:29 --> URI Class Initialized
INFO - 2020-02-15 13:43:29 --> Router Class Initialized
INFO - 2020-02-15 13:43:30 --> Output Class Initialized
INFO - 2020-02-15 13:43:30 --> Security Class Initialized
DEBUG - 2020-02-15 13:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:43:30 --> Input Class Initialized
INFO - 2020-02-15 13:43:30 --> Language Class Initialized
INFO - 2020-02-15 13:43:30 --> Loader Class Initialized
INFO - 2020-02-15 13:43:30 --> Helper loaded: url_helper
INFO - 2020-02-15 13:43:30 --> Helper loaded: string_helper
INFO - 2020-02-15 13:43:30 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:43:30 --> Controller Class Initialized
INFO - 2020-02-15 13:43:30 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:43:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:43:30 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:43:30 --> Helper loaded: form_helper
INFO - 2020-02-15 13:43:30 --> Form Validation Class Initialized
INFO - 2020-02-15 13:43:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:43:30 --> Final output sent to browser
DEBUG - 2020-02-15 13:43:30 --> Total execution time: 0.9237
INFO - 2020-02-15 13:47:10 --> Config Class Initialized
INFO - 2020-02-15 13:47:10 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:47:10 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:10 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:10 --> URI Class Initialized
DEBUG - 2020-02-15 13:47:10 --> No URI present. Default controller set.
INFO - 2020-02-15 13:47:10 --> Router Class Initialized
INFO - 2020-02-15 13:47:10 --> Output Class Initialized
INFO - 2020-02-15 13:47:10 --> Security Class Initialized
DEBUG - 2020-02-15 13:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:10 --> Input Class Initialized
INFO - 2020-02-15 13:47:10 --> Language Class Initialized
INFO - 2020-02-15 13:47:10 --> Loader Class Initialized
INFO - 2020-02-15 13:47:10 --> Helper loaded: url_helper
INFO - 2020-02-15 13:47:10 --> Helper loaded: string_helper
INFO - 2020-02-15 13:47:10 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:47:10 --> Controller Class Initialized
INFO - 2020-02-15 13:47:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-15 13:47:10 --> Pagination Class Initialized
INFO - 2020-02-15 13:47:10 --> Model "M_show" initialized
INFO - 2020-02-15 13:47:10 --> Helper loaded: form_helper
INFO - 2020-02-15 13:47:10 --> Form Validation Class Initialized
INFO - 2020-02-15 13:47:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-15 13:47:10 --> Final output sent to browser
DEBUG - 2020-02-15 13:47:10 --> Total execution time: 0.7316
INFO - 2020-02-15 13:47:13 --> Config Class Initialized
INFO - 2020-02-15 13:47:13 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:13 --> URI Class Initialized
INFO - 2020-02-15 13:47:13 --> Router Class Initialized
INFO - 2020-02-15 13:47:13 --> Output Class Initialized
INFO - 2020-02-15 13:47:13 --> Security Class Initialized
DEBUG - 2020-02-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:13 --> Input Class Initialized
INFO - 2020-02-15 13:47:13 --> Language Class Initialized
INFO - 2020-02-15 13:47:13 --> Loader Class Initialized
INFO - 2020-02-15 13:47:13 --> Helper loaded: url_helper
INFO - 2020-02-15 13:47:13 --> Helper loaded: string_helper
INFO - 2020-02-15 13:47:13 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:47:13 --> Controller Class Initialized
INFO - 2020-02-15 13:47:13 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:47:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:47:13 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:47:14 --> Helper loaded: form_helper
INFO - 2020-02-15 13:47:14 --> Form Validation Class Initialized
INFO - 2020-02-15 13:47:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:47:14 --> Final output sent to browser
DEBUG - 2020-02-15 13:47:14 --> Total execution time: 0.9382
INFO - 2020-02-15 13:47:14 --> Config Class Initialized
INFO - 2020-02-15 13:47:14 --> Config Class Initialized
INFO - 2020-02-15 13:47:14 --> Config Class Initialized
INFO - 2020-02-15 13:47:14 --> Config Class Initialized
INFO - 2020-02-15 13:47:14 --> Config Class Initialized
INFO - 2020-02-15 13:47:14 --> Hooks Class Initialized
INFO - 2020-02-15 13:47:14 --> Hooks Class Initialized
INFO - 2020-02-15 13:47:14 --> Hooks Class Initialized
INFO - 2020-02-15 13:47:14 --> Hooks Class Initialized
INFO - 2020-02-15 13:47:14 --> Hooks Class Initialized
INFO - 2020-02-15 13:47:14 --> Config Class Initialized
INFO - 2020-02-15 13:47:14 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:47:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:47:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:47:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:47:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:14 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:14 --> URI Class Initialized
INFO - 2020-02-15 13:47:14 --> URI Class Initialized
INFO - 2020-02-15 13:47:14 --> URI Class Initialized
INFO - 2020-02-15 13:47:14 --> URI Class Initialized
INFO - 2020-02-15 13:47:14 --> URI Class Initialized
INFO - 2020-02-15 13:47:14 --> URI Class Initialized
INFO - 2020-02-15 13:47:14 --> Router Class Initialized
INFO - 2020-02-15 13:47:14 --> Router Class Initialized
INFO - 2020-02-15 13:47:14 --> Router Class Initialized
INFO - 2020-02-15 13:47:14 --> Router Class Initialized
INFO - 2020-02-15 13:47:14 --> Router Class Initialized
INFO - 2020-02-15 13:47:14 --> Output Class Initialized
INFO - 2020-02-15 13:47:14 --> Output Class Initialized
INFO - 2020-02-15 13:47:14 --> Output Class Initialized
INFO - 2020-02-15 13:47:14 --> Output Class Initialized
INFO - 2020-02-15 13:47:14 --> Router Class Initialized
INFO - 2020-02-15 13:47:14 --> Output Class Initialized
INFO - 2020-02-15 13:47:14 --> Security Class Initialized
INFO - 2020-02-15 13:47:14 --> Security Class Initialized
INFO - 2020-02-15 13:47:14 --> Security Class Initialized
INFO - 2020-02-15 13:47:14 --> Security Class Initialized
INFO - 2020-02-15 13:47:14 --> Security Class Initialized
INFO - 2020-02-15 13:47:14 --> Output Class Initialized
DEBUG - 2020-02-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:14 --> Security Class Initialized
DEBUG - 2020-02-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:14 --> Input Class Initialized
INFO - 2020-02-15 13:47:14 --> Input Class Initialized
INFO - 2020-02-15 13:47:14 --> Input Class Initialized
INFO - 2020-02-15 13:47:14 --> Input Class Initialized
INFO - 2020-02-15 13:47:14 --> Input Class Initialized
DEBUG - 2020-02-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:14 --> Language Class Initialized
INFO - 2020-02-15 13:47:14 --> Language Class Initialized
INFO - 2020-02-15 13:47:14 --> Language Class Initialized
INFO - 2020-02-15 13:47:14 --> Input Class Initialized
INFO - 2020-02-15 13:47:14 --> Language Class Initialized
INFO - 2020-02-15 13:47:14 --> Language Class Initialized
INFO - 2020-02-15 13:47:14 --> Language Class Initialized
ERROR - 2020-02-15 13:47:14 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-15 13:47:14 --> Loader Class Initialized
INFO - 2020-02-15 13:47:14 --> Loader Class Initialized
ERROR - 2020-02-15 13:47:14 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-15 13:47:14 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 13:47:14 --> Helper loaded: url_helper
ERROR - 2020-02-15 13:47:14 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 13:47:14 --> Helper loaded: url_helper
INFO - 2020-02-15 13:47:14 --> Config Class Initialized
INFO - 2020-02-15 13:47:14 --> Config Class Initialized
INFO - 2020-02-15 13:47:14 --> Config Class Initialized
INFO - 2020-02-15 13:47:14 --> Hooks Class Initialized
INFO - 2020-02-15 13:47:14 --> Helper loaded: string_helper
INFO - 2020-02-15 13:47:14 --> Hooks Class Initialized
INFO - 2020-02-15 13:47:14 --> Helper loaded: string_helper
DEBUG - 2020-02-15 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:14 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:14 --> Database Driver Class Initialized
INFO - 2020-02-15 13:47:14 --> Database Driver Class Initialized
INFO - 2020-02-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:14 --> Config Class Initialized
INFO - 2020-02-15 13:47:14 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:47:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 13:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:14 --> Hooks Class Initialized
INFO - 2020-02-15 13:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:47:14 --> URI Class Initialized
INFO - 2020-02-15 13:47:14 --> URI Class Initialized
INFO - 2020-02-15 13:47:14 --> Controller Class Initialized
INFO - 2020-02-15 13:47:14 --> URI Class Initialized
INFO - 2020-02-15 13:47:14 --> Router Class Initialized
INFO - 2020-02-15 13:47:14 --> Router Class Initialized
DEBUG - 2020-02-15 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:14 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:47:14 --> Router Class Initialized
INFO - 2020-02-15 13:47:14 --> Output Class Initialized
INFO - 2020-02-15 13:47:14 --> Output Class Initialized
INFO - 2020-02-15 13:47:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:47:14 --> Security Class Initialized
INFO - 2020-02-15 13:47:14 --> URI Class Initialized
INFO - 2020-02-15 13:47:14 --> Security Class Initialized
INFO - 2020-02-15 13:47:14 --> Output Class Initialized
INFO - 2020-02-15 13:47:14 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:47:14 --> Security Class Initialized
DEBUG - 2020-02-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:14 --> Router Class Initialized
INFO - 2020-02-15 13:47:14 --> Input Class Initialized
INFO - 2020-02-15 13:47:14 --> Input Class Initialized
DEBUG - 2020-02-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:14 --> Output Class Initialized
INFO - 2020-02-15 13:47:14 --> Helper loaded: form_helper
INFO - 2020-02-15 13:47:14 --> Form Validation Class Initialized
INFO - 2020-02-15 13:47:14 --> Input Class Initialized
INFO - 2020-02-15 13:47:14 --> Language Class Initialized
INFO - 2020-02-15 13:47:14 --> Language Class Initialized
INFO - 2020-02-15 13:47:14 --> Security Class Initialized
ERROR - 2020-02-15 13:47:15 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-15 13:47:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-15 13:47:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:47:15 --> Language Class Initialized
ERROR - 2020-02-15 13:47:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-15 13:47:15 --> Input Class Initialized
ERROR - 2020-02-15 13:47:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-15 13:47:15 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 13:47:15 --> Language Class Initialized
INFO - 2020-02-15 13:47:15 --> Config Class Initialized
INFO - 2020-02-15 13:47:15 --> Config Class Initialized
INFO - 2020-02-15 13:47:15 --> Hooks Class Initialized
INFO - 2020-02-15 13:47:15 --> Hooks Class Initialized
INFO - 2020-02-15 13:47:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-15 13:47:15 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 13:47:15 --> Final output sent to browser
INFO - 2020-02-15 13:47:15 --> Config Class Initialized
DEBUG - 2020-02-15 13:47:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:47:15 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:15 --> Config Class Initialized
INFO - 2020-02-15 13:47:15 --> Hooks Class Initialized
INFO - 2020-02-15 13:47:15 --> Hooks Class Initialized
INFO - 2020-02-15 13:47:15 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:47:15 --> Total execution time: 0.8941
INFO - 2020-02-15 13:47:15 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:15 --> URI Class Initialized
INFO - 2020-02-15 13:47:15 --> URI Class Initialized
INFO - 2020-02-15 13:47:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-15 13:47:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:47:15 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:15 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:15 --> Controller Class Initialized
INFO - 2020-02-15 13:47:15 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:15 --> Router Class Initialized
INFO - 2020-02-15 13:47:15 --> Router Class Initialized
INFO - 2020-02-15 13:47:15 --> URI Class Initialized
INFO - 2020-02-15 13:47:15 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:47:15 --> URI Class Initialized
INFO - 2020-02-15 13:47:15 --> Output Class Initialized
INFO - 2020-02-15 13:47:15 --> Output Class Initialized
INFO - 2020-02-15 13:47:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:47:15 --> Router Class Initialized
INFO - 2020-02-15 13:47:15 --> Security Class Initialized
INFO - 2020-02-15 13:47:15 --> Security Class Initialized
INFO - 2020-02-15 13:47:15 --> Router Class Initialized
INFO - 2020-02-15 13:47:15 --> Model "M_pesan" initialized
DEBUG - 2020-02-15 13:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:15 --> Output Class Initialized
INFO - 2020-02-15 13:47:15 --> Output Class Initialized
DEBUG - 2020-02-15 13:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:15 --> Input Class Initialized
INFO - 2020-02-15 13:47:15 --> Security Class Initialized
INFO - 2020-02-15 13:47:15 --> Helper loaded: form_helper
INFO - 2020-02-15 13:47:15 --> Input Class Initialized
INFO - 2020-02-15 13:47:15 --> Security Class Initialized
INFO - 2020-02-15 13:47:15 --> Language Class Initialized
INFO - 2020-02-15 13:47:15 --> Language Class Initialized
DEBUG - 2020-02-15 13:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:15 --> Form Validation Class Initialized
DEBUG - 2020-02-15 13:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:15 --> Input Class Initialized
INFO - 2020-02-15 13:47:15 --> Input Class Initialized
ERROR - 2020-02-15 13:47:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-15 13:47:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-15 13:47:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:47:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:47:15 --> Language Class Initialized
INFO - 2020-02-15 13:47:15 --> Language Class Initialized
INFO - 2020-02-15 13:47:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-15 13:47:15 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-15 13:47:15 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 13:47:15 --> Final output sent to browser
INFO - 2020-02-15 13:47:15 --> Config Class Initialized
INFO - 2020-02-15 13:47:15 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:47:15 --> Total execution time: 1.2891
DEBUG - 2020-02-15 13:47:15 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:15 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:15 --> URI Class Initialized
INFO - 2020-02-15 13:47:15 --> Router Class Initialized
INFO - 2020-02-15 13:47:15 --> Output Class Initialized
INFO - 2020-02-15 13:47:15 --> Security Class Initialized
DEBUG - 2020-02-15 13:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:15 --> Input Class Initialized
INFO - 2020-02-15 13:47:15 --> Language Class Initialized
ERROR - 2020-02-15 13:47:15 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 13:47:15 --> Config Class Initialized
INFO - 2020-02-15 13:47:15 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:47:15 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:15 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:15 --> URI Class Initialized
INFO - 2020-02-15 13:47:15 --> Router Class Initialized
INFO - 2020-02-15 13:47:15 --> Output Class Initialized
INFO - 2020-02-15 13:47:16 --> Security Class Initialized
DEBUG - 2020-02-15 13:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:16 --> Input Class Initialized
INFO - 2020-02-15 13:47:16 --> Language Class Initialized
ERROR - 2020-02-15 13:47:16 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 13:47:16 --> Config Class Initialized
INFO - 2020-02-15 13:47:16 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:47:16 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:16 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:16 --> URI Class Initialized
INFO - 2020-02-15 13:47:16 --> Router Class Initialized
INFO - 2020-02-15 13:47:16 --> Output Class Initialized
INFO - 2020-02-15 13:47:16 --> Security Class Initialized
DEBUG - 2020-02-15 13:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:16 --> Input Class Initialized
INFO - 2020-02-15 13:47:16 --> Language Class Initialized
ERROR - 2020-02-15 13:47:16 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:47:16 --> Config Class Initialized
INFO - 2020-02-15 13:47:16 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:47:16 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:16 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:16 --> URI Class Initialized
INFO - 2020-02-15 13:47:16 --> Router Class Initialized
INFO - 2020-02-15 13:47:16 --> Output Class Initialized
INFO - 2020-02-15 13:47:16 --> Security Class Initialized
DEBUG - 2020-02-15 13:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:16 --> Input Class Initialized
INFO - 2020-02-15 13:47:16 --> Language Class Initialized
ERROR - 2020-02-15 13:47:16 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:47:16 --> Config Class Initialized
INFO - 2020-02-15 13:47:16 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:47:16 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:16 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:16 --> URI Class Initialized
INFO - 2020-02-15 13:47:16 --> Router Class Initialized
INFO - 2020-02-15 13:47:16 --> Output Class Initialized
INFO - 2020-02-15 13:47:17 --> Security Class Initialized
DEBUG - 2020-02-15 13:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:17 --> Input Class Initialized
INFO - 2020-02-15 13:47:17 --> Language Class Initialized
ERROR - 2020-02-15 13:47:17 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 13:47:17 --> Config Class Initialized
INFO - 2020-02-15 13:47:17 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:47:17 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:17 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:17 --> URI Class Initialized
INFO - 2020-02-15 13:47:17 --> Router Class Initialized
INFO - 2020-02-15 13:47:17 --> Output Class Initialized
INFO - 2020-02-15 13:47:17 --> Security Class Initialized
DEBUG - 2020-02-15 13:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:17 --> Input Class Initialized
INFO - 2020-02-15 13:47:17 --> Language Class Initialized
ERROR - 2020-02-15 13:47:17 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 13:47:17 --> Config Class Initialized
INFO - 2020-02-15 13:47:17 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:47:17 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:17 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:17 --> URI Class Initialized
INFO - 2020-02-15 13:47:17 --> Router Class Initialized
INFO - 2020-02-15 13:47:17 --> Output Class Initialized
INFO - 2020-02-15 13:47:17 --> Security Class Initialized
DEBUG - 2020-02-15 13:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:17 --> Input Class Initialized
INFO - 2020-02-15 13:47:17 --> Language Class Initialized
ERROR - 2020-02-15 13:47:17 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 13:47:17 --> Config Class Initialized
INFO - 2020-02-15 13:47:17 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:47:17 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:17 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:17 --> URI Class Initialized
INFO - 2020-02-15 13:47:17 --> Router Class Initialized
INFO - 2020-02-15 13:47:17 --> Output Class Initialized
INFO - 2020-02-15 13:47:17 --> Security Class Initialized
DEBUG - 2020-02-15 13:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:18 --> Input Class Initialized
INFO - 2020-02-15 13:47:18 --> Language Class Initialized
ERROR - 2020-02-15 13:47:18 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 13:47:32 --> Config Class Initialized
INFO - 2020-02-15 13:47:32 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:47:32 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:47:33 --> Utf8 Class Initialized
INFO - 2020-02-15 13:47:33 --> URI Class Initialized
INFO - 2020-02-15 13:47:33 --> Router Class Initialized
INFO - 2020-02-15 13:47:33 --> Output Class Initialized
INFO - 2020-02-15 13:47:33 --> Security Class Initialized
DEBUG - 2020-02-15 13:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:47:33 --> Input Class Initialized
INFO - 2020-02-15 13:47:33 --> Language Class Initialized
INFO - 2020-02-15 13:47:33 --> Loader Class Initialized
INFO - 2020-02-15 13:47:33 --> Helper loaded: url_helper
INFO - 2020-02-15 13:47:33 --> Helper loaded: string_helper
INFO - 2020-02-15 13:47:33 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:47:33 --> Controller Class Initialized
INFO - 2020-02-15 13:47:33 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:47:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:47:33 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:47:33 --> Helper loaded: form_helper
INFO - 2020-02-15 13:47:33 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:47:34 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\roadshow\application\models\M_pesan.php 74
ERROR - 2020-02-15 13:47:34 --> Query error: Unknown column 'tanggal_pemesanan' in 'field list' - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pemesanan`, `tanggal_exp`, `tanggal_approve`, `id_pengunjung`) VALUES ('34', '', '1', '0', NULL, '2020-02-16 01:47', NULL, '191')
INFO - 2020-02-15 13:47:34 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-15 13:48:41 --> Config Class Initialized
INFO - 2020-02-15 13:48:41 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:48:41 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:48:41 --> Utf8 Class Initialized
INFO - 2020-02-15 13:48:41 --> URI Class Initialized
INFO - 2020-02-15 13:48:41 --> Router Class Initialized
INFO - 2020-02-15 13:48:41 --> Output Class Initialized
INFO - 2020-02-15 13:48:41 --> Security Class Initialized
DEBUG - 2020-02-15 13:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:48:41 --> Input Class Initialized
INFO - 2020-02-15 13:48:41 --> Language Class Initialized
INFO - 2020-02-15 13:48:41 --> Loader Class Initialized
INFO - 2020-02-15 13:48:41 --> Helper loaded: url_helper
INFO - 2020-02-15 13:48:41 --> Helper loaded: string_helper
INFO - 2020-02-15 13:48:41 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:48:41 --> Controller Class Initialized
INFO - 2020-02-15 13:48:41 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:48:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:48:41 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:48:41 --> Helper loaded: form_helper
INFO - 2020-02-15 13:48:41 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:48:41 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 70
ERROR - 2020-02-15 13:48:41 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 71
ERROR - 2020-02-15 13:48:41 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 72
ERROR - 2020-02-15 13:48:41 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 73
ERROR - 2020-02-15 13:48:42 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 81
ERROR - 2020-02-15 13:48:42 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 82
ERROR - 2020-02-15 13:48:42 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 83
ERROR - 2020-02-15 13:48:42 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 84
ERROR - 2020-02-15 13:48:42 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pengunjung` (`nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2020-02-15 13:48:42 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-15 13:48:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow\system\core\Common.php 570
INFO - 2020-02-15 13:48:53 --> Config Class Initialized
INFO - 2020-02-15 13:48:54 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:48:54 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:48:54 --> Utf8 Class Initialized
INFO - 2020-02-15 13:48:54 --> URI Class Initialized
INFO - 2020-02-15 13:48:54 --> Router Class Initialized
INFO - 2020-02-15 13:48:54 --> Output Class Initialized
INFO - 2020-02-15 13:48:54 --> Security Class Initialized
DEBUG - 2020-02-15 13:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:48:54 --> Input Class Initialized
INFO - 2020-02-15 13:48:54 --> Language Class Initialized
INFO - 2020-02-15 13:48:54 --> Loader Class Initialized
INFO - 2020-02-15 13:48:54 --> Helper loaded: url_helper
INFO - 2020-02-15 13:48:54 --> Helper loaded: string_helper
INFO - 2020-02-15 13:48:54 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:48:54 --> Controller Class Initialized
INFO - 2020-02-15 13:48:54 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:48:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:48:54 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:48:54 --> Helper loaded: form_helper
INFO - 2020-02-15 13:48:54 --> Form Validation Class Initialized
INFO - 2020-02-15 13:48:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:48:54 --> Final output sent to browser
DEBUG - 2020-02-15 13:48:54 --> Total execution time: 0.8786
INFO - 2020-02-15 13:48:54 --> Config Class Initialized
INFO - 2020-02-15 13:48:54 --> Config Class Initialized
INFO - 2020-02-15 13:48:55 --> Hooks Class Initialized
INFO - 2020-02-15 13:48:55 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:48:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:48:55 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:48:55 --> Utf8 Class Initialized
INFO - 2020-02-15 13:48:55 --> Utf8 Class Initialized
INFO - 2020-02-15 13:48:55 --> URI Class Initialized
INFO - 2020-02-15 13:48:55 --> URI Class Initialized
INFO - 2020-02-15 13:48:55 --> Router Class Initialized
INFO - 2020-02-15 13:48:55 --> Router Class Initialized
INFO - 2020-02-15 13:48:55 --> Output Class Initialized
INFO - 2020-02-15 13:48:55 --> Output Class Initialized
INFO - 2020-02-15 13:48:55 --> Security Class Initialized
INFO - 2020-02-15 13:48:55 --> Security Class Initialized
DEBUG - 2020-02-15 13:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:48:55 --> Input Class Initialized
INFO - 2020-02-15 13:48:55 --> Input Class Initialized
INFO - 2020-02-15 13:48:55 --> Language Class Initialized
INFO - 2020-02-15 13:48:55 --> Language Class Initialized
INFO - 2020-02-15 13:48:55 --> Loader Class Initialized
INFO - 2020-02-15 13:48:55 --> Loader Class Initialized
INFO - 2020-02-15 13:48:55 --> Helper loaded: url_helper
INFO - 2020-02-15 13:48:55 --> Helper loaded: url_helper
INFO - 2020-02-15 13:48:55 --> Helper loaded: string_helper
INFO - 2020-02-15 13:48:55 --> Helper loaded: string_helper
INFO - 2020-02-15 13:48:55 --> Database Driver Class Initialized
INFO - 2020-02-15 13:48:55 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 13:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:48:55 --> Controller Class Initialized
INFO - 2020-02-15 13:48:55 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:48:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:48:55 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:48:55 --> Helper loaded: form_helper
INFO - 2020-02-15 13:48:55 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:48:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:48:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:48:55 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:48:55 --> Final output sent to browser
DEBUG - 2020-02-15 13:48:55 --> Total execution time: 0.8148
INFO - 2020-02-15 13:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:48:55 --> Controller Class Initialized
INFO - 2020-02-15 13:48:55 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:48:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:48:55 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:48:55 --> Helper loaded: form_helper
INFO - 2020-02-15 13:48:55 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:48:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:48:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:48:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:48:56 --> Final output sent to browser
DEBUG - 2020-02-15 13:48:56 --> Total execution time: 1.1379
INFO - 2020-02-15 13:48:59 --> Config Class Initialized
INFO - 2020-02-15 13:48:59 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:48:59 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:48:59 --> Utf8 Class Initialized
INFO - 2020-02-15 13:48:59 --> URI Class Initialized
INFO - 2020-02-15 13:48:59 --> Router Class Initialized
INFO - 2020-02-15 13:48:59 --> Output Class Initialized
INFO - 2020-02-15 13:48:59 --> Security Class Initialized
DEBUG - 2020-02-15 13:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:48:59 --> Input Class Initialized
INFO - 2020-02-15 13:48:59 --> Language Class Initialized
INFO - 2020-02-15 13:48:59 --> Loader Class Initialized
INFO - 2020-02-15 13:48:59 --> Helper loaded: url_helper
INFO - 2020-02-15 13:48:59 --> Helper loaded: string_helper
INFO - 2020-02-15 13:48:59 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:48:59 --> Controller Class Initialized
INFO - 2020-02-15 13:48:59 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:48:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:48:59 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:48:59 --> Helper loaded: form_helper
INFO - 2020-02-15 13:48:59 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:48:59 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\roadshow\application\models\M_pesan.php 74
ERROR - 2020-02-15 13:48:59 --> Query error: Column 'tanggal_approve' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `id_pengunjung`) VALUES ('34', '', '1', '0', NULL, '2020-02-16 01:48', NULL, '191')
INFO - 2020-02-15 13:48:59 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-15 13:49:58 --> Config Class Initialized
INFO - 2020-02-15 13:49:58 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:49:58 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:49:58 --> Utf8 Class Initialized
INFO - 2020-02-15 13:49:58 --> URI Class Initialized
INFO - 2020-02-15 13:49:58 --> Router Class Initialized
INFO - 2020-02-15 13:49:58 --> Output Class Initialized
INFO - 2020-02-15 13:49:58 --> Security Class Initialized
DEBUG - 2020-02-15 13:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:49:58 --> Input Class Initialized
INFO - 2020-02-15 13:49:58 --> Language Class Initialized
INFO - 2020-02-15 13:49:58 --> Loader Class Initialized
INFO - 2020-02-15 13:49:58 --> Helper loaded: url_helper
INFO - 2020-02-15 13:49:58 --> Helper loaded: string_helper
INFO - 2020-02-15 13:49:58 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:49:58 --> Controller Class Initialized
INFO - 2020-02-15 13:49:58 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:49:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:49:58 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:49:59 --> Helper loaded: form_helper
INFO - 2020-02-15 13:49:59 --> Form Validation Class Initialized
INFO - 2020-02-15 13:49:59 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:49:59 --> Final output sent to browser
DEBUG - 2020-02-15 13:49:59 --> Total execution time: 0.8319
INFO - 2020-02-15 13:49:59 --> Config Class Initialized
INFO - 2020-02-15 13:49:59 --> Hooks Class Initialized
INFO - 2020-02-15 13:49:59 --> Config Class Initialized
INFO - 2020-02-15 13:49:59 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:49:59 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:49:59 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:49:59 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:49:59 --> Utf8 Class Initialized
INFO - 2020-02-15 13:49:59 --> URI Class Initialized
INFO - 2020-02-15 13:49:59 --> URI Class Initialized
INFO - 2020-02-15 13:49:59 --> Router Class Initialized
INFO - 2020-02-15 13:49:59 --> Output Class Initialized
INFO - 2020-02-15 13:49:59 --> Router Class Initialized
INFO - 2020-02-15 13:49:59 --> Output Class Initialized
INFO - 2020-02-15 13:49:59 --> Security Class Initialized
DEBUG - 2020-02-15 13:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:49:59 --> Security Class Initialized
INFO - 2020-02-15 13:49:59 --> Input Class Initialized
DEBUG - 2020-02-15 13:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:49:59 --> Input Class Initialized
INFO - 2020-02-15 13:49:59 --> Language Class Initialized
INFO - 2020-02-15 13:49:59 --> Language Class Initialized
INFO - 2020-02-15 13:49:59 --> Loader Class Initialized
INFO - 2020-02-15 13:49:59 --> Helper loaded: url_helper
INFO - 2020-02-15 13:49:59 --> Loader Class Initialized
INFO - 2020-02-15 13:49:59 --> Helper loaded: string_helper
INFO - 2020-02-15 13:49:59 --> Helper loaded: url_helper
INFO - 2020-02-15 13:49:59 --> Helper loaded: string_helper
INFO - 2020-02-15 13:49:59 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:49:59 --> Database Driver Class Initialized
INFO - 2020-02-15 13:49:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-15 13:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:49:59 --> Controller Class Initialized
INFO - 2020-02-15 13:49:59 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:49:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:49:59 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:49:59 --> Helper loaded: form_helper
INFO - 2020-02-15 13:49:59 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:49:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:50:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:50:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:50:00 --> Final output sent to browser
DEBUG - 2020-02-15 13:50:00 --> Total execution time: 0.8160
INFO - 2020-02-15 13:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:50:00 --> Controller Class Initialized
INFO - 2020-02-15 13:50:00 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:50:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:50:00 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:50:00 --> Helper loaded: form_helper
INFO - 2020-02-15 13:50:00 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:50:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:50:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:50:00 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:50:00 --> Final output sent to browser
DEBUG - 2020-02-15 13:50:00 --> Total execution time: 1.1130
INFO - 2020-02-15 13:50:00 --> Config Class Initialized
INFO - 2020-02-15 13:50:00 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:50:00 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:00 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:00 --> URI Class Initialized
INFO - 2020-02-15 13:50:00 --> Router Class Initialized
INFO - 2020-02-15 13:50:00 --> Output Class Initialized
INFO - 2020-02-15 13:50:00 --> Security Class Initialized
DEBUG - 2020-02-15 13:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:00 --> Input Class Initialized
INFO - 2020-02-15 13:50:00 --> Language Class Initialized
INFO - 2020-02-15 13:50:01 --> Loader Class Initialized
INFO - 2020-02-15 13:50:01 --> Helper loaded: url_helper
INFO - 2020-02-15 13:50:01 --> Helper loaded: string_helper
INFO - 2020-02-15 13:50:01 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:50:01 --> Controller Class Initialized
INFO - 2020-02-15 13:50:01 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:50:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:50:01 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:50:01 --> Helper loaded: form_helper
INFO - 2020-02-15 13:50:01 --> Form Validation Class Initialized
INFO - 2020-02-15 13:50:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:50:01 --> Final output sent to browser
INFO - 2020-02-15 13:50:01 --> Config Class Initialized
INFO - 2020-02-15 13:50:01 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:50:01 --> Total execution time: 0.6533
INFO - 2020-02-15 13:50:01 --> Config Class Initialized
INFO - 2020-02-15 13:50:01 --> Config Class Initialized
INFO - 2020-02-15 13:50:01 --> Config Class Initialized
INFO - 2020-02-15 13:50:01 --> Config Class Initialized
INFO - 2020-02-15 13:50:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:50:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:50:01 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:50:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:50:01 --> Config Class Initialized
INFO - 2020-02-15 13:50:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:50:01 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:50:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:01 --> URI Class Initialized
DEBUG - 2020-02-15 13:50:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:01 --> URI Class Initialized
INFO - 2020-02-15 13:50:01 --> URI Class Initialized
INFO - 2020-02-15 13:50:01 --> URI Class Initialized
INFO - 2020-02-15 13:50:01 --> Router Class Initialized
INFO - 2020-02-15 13:50:01 --> URI Class Initialized
INFO - 2020-02-15 13:50:01 --> URI Class Initialized
INFO - 2020-02-15 13:50:01 --> Router Class Initialized
INFO - 2020-02-15 13:50:01 --> Router Class Initialized
INFO - 2020-02-15 13:50:01 --> Output Class Initialized
INFO - 2020-02-15 13:50:01 --> Router Class Initialized
INFO - 2020-02-15 13:50:01 --> Router Class Initialized
INFO - 2020-02-15 13:50:01 --> Output Class Initialized
INFO - 2020-02-15 13:50:01 --> Security Class Initialized
INFO - 2020-02-15 13:50:01 --> Output Class Initialized
INFO - 2020-02-15 13:50:01 --> Output Class Initialized
INFO - 2020-02-15 13:50:01 --> Output Class Initialized
INFO - 2020-02-15 13:50:01 --> Router Class Initialized
DEBUG - 2020-02-15 13:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:01 --> Security Class Initialized
INFO - 2020-02-15 13:50:01 --> Security Class Initialized
INFO - 2020-02-15 13:50:01 --> Security Class Initialized
INFO - 2020-02-15 13:50:01 --> Security Class Initialized
INFO - 2020-02-15 13:50:01 --> Output Class Initialized
INFO - 2020-02-15 13:50:01 --> Input Class Initialized
DEBUG - 2020-02-15 13:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:01 --> Security Class Initialized
DEBUG - 2020-02-15 13:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:01 --> Input Class Initialized
INFO - 2020-02-15 13:50:01 --> Input Class Initialized
INFO - 2020-02-15 13:50:01 --> Input Class Initialized
INFO - 2020-02-15 13:50:01 --> Input Class Initialized
INFO - 2020-02-15 13:50:01 --> Language Class Initialized
DEBUG - 2020-02-15 13:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:01 --> Input Class Initialized
INFO - 2020-02-15 13:50:01 --> Language Class Initialized
INFO - 2020-02-15 13:50:01 --> Language Class Initialized
INFO - 2020-02-15 13:50:01 --> Language Class Initialized
INFO - 2020-02-15 13:50:01 --> Language Class Initialized
ERROR - 2020-02-15 13:50:01 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-15 13:50:01 --> Language Class Initialized
ERROR - 2020-02-15 13:50:01 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-15 13:50:01 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-15 13:50:01 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-15 13:50:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 13:50:01 --> Config Class Initialized
INFO - 2020-02-15 13:50:01 --> Hooks Class Initialized
ERROR - 2020-02-15 13:50:01 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:50:01 --> Config Class Initialized
INFO - 2020-02-15 13:50:01 --> Config Class Initialized
INFO - 2020-02-15 13:50:01 --> Config Class Initialized
INFO - 2020-02-15 13:50:01 --> Config Class Initialized
INFO - 2020-02-15 13:50:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:50:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:50:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:50:01 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:50:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:01 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:50:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:01 --> Config Class Initialized
DEBUG - 2020-02-15 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:50:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:01 --> Hooks Class Initialized
INFO - 2020-02-15 13:50:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:01 --> URI Class Initialized
INFO - 2020-02-15 13:50:01 --> URI Class Initialized
INFO - 2020-02-15 13:50:01 --> URI Class Initialized
INFO - 2020-02-15 13:50:01 --> URI Class Initialized
INFO - 2020-02-15 13:50:01 --> URI Class Initialized
INFO - 2020-02-15 13:50:01 --> Router Class Initialized
DEBUG - 2020-02-15 13:50:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:01 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:01 --> Router Class Initialized
INFO - 2020-02-15 13:50:01 --> Router Class Initialized
INFO - 2020-02-15 13:50:01 --> Router Class Initialized
INFO - 2020-02-15 13:50:01 --> Router Class Initialized
INFO - 2020-02-15 13:50:01 --> Output Class Initialized
INFO - 2020-02-15 13:50:02 --> URI Class Initialized
INFO - 2020-02-15 13:50:02 --> Output Class Initialized
INFO - 2020-02-15 13:50:02 --> Output Class Initialized
INFO - 2020-02-15 13:50:02 --> Output Class Initialized
INFO - 2020-02-15 13:50:02 --> Output Class Initialized
INFO - 2020-02-15 13:50:02 --> Security Class Initialized
INFO - 2020-02-15 13:50:02 --> Security Class Initialized
INFO - 2020-02-15 13:50:02 --> Security Class Initialized
INFO - 2020-02-15 13:50:02 --> Router Class Initialized
INFO - 2020-02-15 13:50:02 --> Security Class Initialized
INFO - 2020-02-15 13:50:02 --> Security Class Initialized
DEBUG - 2020-02-15 13:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:02 --> Input Class Initialized
DEBUG - 2020-02-15 13:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:02 --> Output Class Initialized
DEBUG - 2020-02-15 13:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:02 --> Input Class Initialized
INFO - 2020-02-15 13:50:02 --> Input Class Initialized
INFO - 2020-02-15 13:50:02 --> Input Class Initialized
INFO - 2020-02-15 13:50:02 --> Language Class Initialized
INFO - 2020-02-15 13:50:02 --> Input Class Initialized
INFO - 2020-02-15 13:50:02 --> Security Class Initialized
INFO - 2020-02-15 13:50:02 --> Language Class Initialized
INFO - 2020-02-15 13:50:02 --> Language Class Initialized
ERROR - 2020-02-15 13:50:02 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-15 13:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:02 --> Language Class Initialized
INFO - 2020-02-15 13:50:02 --> Language Class Initialized
ERROR - 2020-02-15 13:50:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 13:50:02 --> Input Class Initialized
ERROR - 2020-02-15 13:50:02 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 13:50:02 --> Loader Class Initialized
ERROR - 2020-02-15 13:50:02 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 13:50:02 --> Config Class Initialized
INFO - 2020-02-15 13:50:02 --> Hooks Class Initialized
INFO - 2020-02-15 13:50:02 --> Language Class Initialized
INFO - 2020-02-15 13:50:02 --> Helper loaded: url_helper
INFO - 2020-02-15 13:50:02 --> Config Class Initialized
INFO - 2020-02-15 13:50:02 --> Hooks Class Initialized
INFO - 2020-02-15 13:50:02 --> Helper loaded: string_helper
INFO - 2020-02-15 13:50:02 --> Loader Class Initialized
DEBUG - 2020-02-15 13:50:02 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:02 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:02 --> Helper loaded: url_helper
DEBUG - 2020-02-15 13:50:02 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:02 --> Database Driver Class Initialized
INFO - 2020-02-15 13:50:02 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:02 --> Helper loaded: string_helper
INFO - 2020-02-15 13:50:02 --> URI Class Initialized
DEBUG - 2020-02-15 13:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:50:02 --> URI Class Initialized
INFO - 2020-02-15 13:50:02 --> Router Class Initialized
INFO - 2020-02-15 13:50:02 --> Database Driver Class Initialized
INFO - 2020-02-15 13:50:02 --> Controller Class Initialized
INFO - 2020-02-15 13:50:02 --> Router Class Initialized
INFO - 2020-02-15 13:50:02 --> Output Class Initialized
DEBUG - 2020-02-15 13:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:50:02 --> Security Class Initialized
INFO - 2020-02-15 13:50:02 --> Output Class Initialized
INFO - 2020-02-15 13:50:02 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:50:02 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-15 13:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:02 --> Security Class Initialized
INFO - 2020-02-15 13:50:02 --> Input Class Initialized
INFO - 2020-02-15 13:50:02 --> Model "M_pesan" initialized
DEBUG - 2020-02-15 13:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:02 --> Input Class Initialized
INFO - 2020-02-15 13:50:02 --> Language Class Initialized
INFO - 2020-02-15 13:50:02 --> Helper loaded: form_helper
INFO - 2020-02-15 13:50:02 --> Form Validation Class Initialized
INFO - 2020-02-15 13:50:02 --> Language Class Initialized
ERROR - 2020-02-15 13:50:02 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-15 13:50:02 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-15 13:50:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:50:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:50:02 --> Config Class Initialized
INFO - 2020-02-15 13:50:02 --> Hooks Class Initialized
INFO - 2020-02-15 13:50:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:50:02 --> Final output sent to browser
DEBUG - 2020-02-15 13:50:02 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:02 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:50:02 --> Total execution time: 0.7441
INFO - 2020-02-15 13:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:50:02 --> URI Class Initialized
INFO - 2020-02-15 13:50:02 --> Controller Class Initialized
INFO - 2020-02-15 13:50:02 --> Router Class Initialized
INFO - 2020-02-15 13:50:02 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:50:02 --> Output Class Initialized
INFO - 2020-02-15 13:50:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:50:02 --> Security Class Initialized
INFO - 2020-02-15 13:50:02 --> Model "M_pesan" initialized
DEBUG - 2020-02-15 13:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:02 --> Input Class Initialized
INFO - 2020-02-15 13:50:02 --> Helper loaded: form_helper
INFO - 2020-02-15 13:50:02 --> Form Validation Class Initialized
INFO - 2020-02-15 13:50:02 --> Language Class Initialized
ERROR - 2020-02-15 13:50:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-15 13:50:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:50:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:50:02 --> Config Class Initialized
INFO - 2020-02-15 13:50:02 --> Hooks Class Initialized
INFO - 2020-02-15 13:50:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:50:02 --> Final output sent to browser
DEBUG - 2020-02-15 13:50:02 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:02 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:50:02 --> Total execution time: 1.0259
INFO - 2020-02-15 13:50:02 --> URI Class Initialized
INFO - 2020-02-15 13:50:03 --> Router Class Initialized
INFO - 2020-02-15 13:50:03 --> Output Class Initialized
INFO - 2020-02-15 13:50:03 --> Security Class Initialized
DEBUG - 2020-02-15 13:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:03 --> Input Class Initialized
INFO - 2020-02-15 13:50:03 --> Language Class Initialized
ERROR - 2020-02-15 13:50:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:50:03 --> Config Class Initialized
INFO - 2020-02-15 13:50:03 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:50:03 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:03 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:03 --> URI Class Initialized
INFO - 2020-02-15 13:50:03 --> Router Class Initialized
INFO - 2020-02-15 13:50:03 --> Output Class Initialized
INFO - 2020-02-15 13:50:03 --> Security Class Initialized
DEBUG - 2020-02-15 13:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:03 --> Input Class Initialized
INFO - 2020-02-15 13:50:03 --> Language Class Initialized
ERROR - 2020-02-15 13:50:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:50:03 --> Config Class Initialized
INFO - 2020-02-15 13:50:03 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:50:03 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:03 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:03 --> URI Class Initialized
INFO - 2020-02-15 13:50:03 --> Router Class Initialized
INFO - 2020-02-15 13:50:03 --> Output Class Initialized
INFO - 2020-02-15 13:50:03 --> Security Class Initialized
DEBUG - 2020-02-15 13:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:03 --> Input Class Initialized
INFO - 2020-02-15 13:50:03 --> Language Class Initialized
ERROR - 2020-02-15 13:50:03 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 13:50:03 --> Config Class Initialized
INFO - 2020-02-15 13:50:03 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:50:04 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:04 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:04 --> URI Class Initialized
INFO - 2020-02-15 13:50:04 --> Router Class Initialized
INFO - 2020-02-15 13:50:04 --> Output Class Initialized
INFO - 2020-02-15 13:50:04 --> Security Class Initialized
DEBUG - 2020-02-15 13:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:04 --> Input Class Initialized
INFO - 2020-02-15 13:50:04 --> Language Class Initialized
ERROR - 2020-02-15 13:50:04 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 13:50:04 --> Config Class Initialized
INFO - 2020-02-15 13:50:04 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:50:04 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:04 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:04 --> URI Class Initialized
INFO - 2020-02-15 13:50:04 --> Router Class Initialized
INFO - 2020-02-15 13:50:04 --> Output Class Initialized
INFO - 2020-02-15 13:50:04 --> Security Class Initialized
DEBUG - 2020-02-15 13:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:04 --> Input Class Initialized
INFO - 2020-02-15 13:50:04 --> Language Class Initialized
ERROR - 2020-02-15 13:50:04 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 13:50:04 --> Config Class Initialized
INFO - 2020-02-15 13:50:04 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:50:04 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:04 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:04 --> URI Class Initialized
INFO - 2020-02-15 13:50:04 --> Router Class Initialized
INFO - 2020-02-15 13:50:04 --> Output Class Initialized
INFO - 2020-02-15 13:50:04 --> Security Class Initialized
DEBUG - 2020-02-15 13:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:04 --> Input Class Initialized
INFO - 2020-02-15 13:50:04 --> Language Class Initialized
ERROR - 2020-02-15 13:50:04 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 13:50:19 --> Config Class Initialized
INFO - 2020-02-15 13:50:19 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:50:19 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:50:19 --> Utf8 Class Initialized
INFO - 2020-02-15 13:50:19 --> URI Class Initialized
INFO - 2020-02-15 13:50:19 --> Router Class Initialized
INFO - 2020-02-15 13:50:19 --> Output Class Initialized
INFO - 2020-02-15 13:50:19 --> Security Class Initialized
DEBUG - 2020-02-15 13:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:50:19 --> Input Class Initialized
INFO - 2020-02-15 13:50:19 --> Language Class Initialized
INFO - 2020-02-15 13:50:19 --> Loader Class Initialized
INFO - 2020-02-15 13:50:19 --> Helper loaded: url_helper
INFO - 2020-02-15 13:50:19 --> Helper loaded: string_helper
INFO - 2020-02-15 13:50:19 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:50:19 --> Controller Class Initialized
INFO - 2020-02-15 13:50:19 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:50:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:50:19 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:50:19 --> Helper loaded: form_helper
INFO - 2020-02-15 13:50:19 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:50:20 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\roadshow\application\models\M_pesan.php 74
ERROR - 2020-02-15 13:50:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '11121'' at line 3 - Invalid query: SELECT *
FROM `pemesanan`
WHERE  = '11121'
INFO - 2020-02-15 13:50:20 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-15 13:52:29 --> Config Class Initialized
INFO - 2020-02-15 13:52:29 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:52:29 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:52:29 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:29 --> URI Class Initialized
INFO - 2020-02-15 13:52:29 --> Router Class Initialized
INFO - 2020-02-15 13:52:29 --> Output Class Initialized
INFO - 2020-02-15 13:52:29 --> Security Class Initialized
DEBUG - 2020-02-15 13:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:52:29 --> Input Class Initialized
INFO - 2020-02-15 13:52:29 --> Language Class Initialized
INFO - 2020-02-15 13:52:30 --> Loader Class Initialized
INFO - 2020-02-15 13:52:30 --> Helper loaded: url_helper
INFO - 2020-02-15 13:52:30 --> Helper loaded: string_helper
INFO - 2020-02-15 13:52:30 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:52:30 --> Controller Class Initialized
INFO - 2020-02-15 13:52:30 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:52:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:52:30 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:52:30 --> Helper loaded: form_helper
INFO - 2020-02-15 13:52:30 --> Config Class Initialized
INFO - 2020-02-15 13:52:30 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:30 --> Form Validation Class Initialized
DEBUG - 2020-02-15 13:52:30 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:52:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:52:30 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:30 --> Final output sent to browser
DEBUG - 2020-02-15 13:52:30 --> Total execution time: 0.9568
INFO - 2020-02-15 13:52:30 --> URI Class Initialized
DEBUG - 2020-02-15 13:52:30 --> No URI present. Default controller set.
INFO - 2020-02-15 13:52:30 --> Router Class Initialized
INFO - 2020-02-15 13:52:30 --> Output Class Initialized
INFO - 2020-02-15 13:52:30 --> Security Class Initialized
DEBUG - 2020-02-15 13:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:52:30 --> Input Class Initialized
INFO - 2020-02-15 13:52:30 --> Language Class Initialized
INFO - 2020-02-15 13:52:30 --> Loader Class Initialized
INFO - 2020-02-15 13:52:30 --> Helper loaded: url_helper
INFO - 2020-02-15 13:52:30 --> Helper loaded: string_helper
INFO - 2020-02-15 13:52:30 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:52:30 --> Controller Class Initialized
INFO - 2020-02-15 13:52:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-15 13:52:30 --> Pagination Class Initialized
INFO - 2020-02-15 13:52:30 --> Model "M_show" initialized
INFO - 2020-02-15 13:52:30 --> Helper loaded: form_helper
INFO - 2020-02-15 13:52:30 --> Form Validation Class Initialized
INFO - 2020-02-15 13:52:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-15 13:52:31 --> Final output sent to browser
DEBUG - 2020-02-15 13:52:31 --> Total execution time: 0.6977
INFO - 2020-02-15 13:52:33 --> Config Class Initialized
INFO - 2020-02-15 13:52:33 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:52:33 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:52:33 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:33 --> URI Class Initialized
INFO - 2020-02-15 13:52:33 --> Router Class Initialized
INFO - 2020-02-15 13:52:33 --> Output Class Initialized
INFO - 2020-02-15 13:52:33 --> Security Class Initialized
DEBUG - 2020-02-15 13:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:52:33 --> Input Class Initialized
INFO - 2020-02-15 13:52:33 --> Language Class Initialized
INFO - 2020-02-15 13:52:33 --> Loader Class Initialized
INFO - 2020-02-15 13:52:33 --> Helper loaded: url_helper
INFO - 2020-02-15 13:52:33 --> Helper loaded: string_helper
INFO - 2020-02-15 13:52:33 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:52:33 --> Controller Class Initialized
INFO - 2020-02-15 13:52:33 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:52:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:52:33 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:52:33 --> Helper loaded: form_helper
INFO - 2020-02-15 13:52:33 --> Form Validation Class Initialized
INFO - 2020-02-15 13:52:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:52:34 --> Final output sent to browser
DEBUG - 2020-02-15 13:52:34 --> Total execution time: 0.6967
INFO - 2020-02-15 13:52:34 --> Config Class Initialized
INFO - 2020-02-15 13:52:34 --> Config Class Initialized
INFO - 2020-02-15 13:52:34 --> Config Class Initialized
INFO - 2020-02-15 13:52:34 --> Config Class Initialized
INFO - 2020-02-15 13:52:34 --> Config Class Initialized
INFO - 2020-02-15 13:52:34 --> Config Class Initialized
INFO - 2020-02-15 13:52:34 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:34 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:34 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:34 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:34 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:34 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:52:34 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:52:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:34 --> URI Class Initialized
INFO - 2020-02-15 13:52:34 --> URI Class Initialized
INFO - 2020-02-15 13:52:34 --> URI Class Initialized
INFO - 2020-02-15 13:52:34 --> URI Class Initialized
INFO - 2020-02-15 13:52:34 --> URI Class Initialized
INFO - 2020-02-15 13:52:34 --> URI Class Initialized
INFO - 2020-02-15 13:52:34 --> Router Class Initialized
INFO - 2020-02-15 13:52:34 --> Router Class Initialized
INFO - 2020-02-15 13:52:34 --> Router Class Initialized
INFO - 2020-02-15 13:52:34 --> Router Class Initialized
INFO - 2020-02-15 13:52:34 --> Router Class Initialized
INFO - 2020-02-15 13:52:34 --> Router Class Initialized
INFO - 2020-02-15 13:52:34 --> Output Class Initialized
INFO - 2020-02-15 13:52:34 --> Output Class Initialized
INFO - 2020-02-15 13:52:34 --> Output Class Initialized
INFO - 2020-02-15 13:52:34 --> Output Class Initialized
INFO - 2020-02-15 13:52:34 --> Output Class Initialized
INFO - 2020-02-15 13:52:34 --> Output Class Initialized
INFO - 2020-02-15 13:52:34 --> Security Class Initialized
INFO - 2020-02-15 13:52:34 --> Security Class Initialized
INFO - 2020-02-15 13:52:34 --> Security Class Initialized
INFO - 2020-02-15 13:52:34 --> Security Class Initialized
INFO - 2020-02-15 13:52:34 --> Security Class Initialized
INFO - 2020-02-15 13:52:34 --> Security Class Initialized
DEBUG - 2020-02-15 13:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:52:34 --> Input Class Initialized
INFO - 2020-02-15 13:52:34 --> Input Class Initialized
INFO - 2020-02-15 13:52:34 --> Input Class Initialized
INFO - 2020-02-15 13:52:34 --> Input Class Initialized
INFO - 2020-02-15 13:52:34 --> Input Class Initialized
INFO - 2020-02-15 13:52:34 --> Input Class Initialized
INFO - 2020-02-15 13:52:34 --> Language Class Initialized
INFO - 2020-02-15 13:52:34 --> Language Class Initialized
INFO - 2020-02-15 13:52:34 --> Language Class Initialized
INFO - 2020-02-15 13:52:34 --> Language Class Initialized
INFO - 2020-02-15 13:52:34 --> Language Class Initialized
INFO - 2020-02-15 13:52:34 --> Language Class Initialized
ERROR - 2020-02-15 13:52:34 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-15 13:52:34 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-15 13:52:34 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-15 13:52:34 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-15 13:52:34 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-15 13:52:34 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 13:52:34 --> Config Class Initialized
INFO - 2020-02-15 13:52:34 --> Config Class Initialized
INFO - 2020-02-15 13:52:34 --> Config Class Initialized
INFO - 2020-02-15 13:52:34 --> Config Class Initialized
INFO - 2020-02-15 13:52:34 --> Config Class Initialized
INFO - 2020-02-15 13:52:34 --> Config Class Initialized
INFO - 2020-02-15 13:52:34 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:34 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:34 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:34 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:34 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:34 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:52:34 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:52:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:34 --> URI Class Initialized
INFO - 2020-02-15 13:52:34 --> URI Class Initialized
INFO - 2020-02-15 13:52:34 --> URI Class Initialized
INFO - 2020-02-15 13:52:34 --> URI Class Initialized
INFO - 2020-02-15 13:52:34 --> URI Class Initialized
INFO - 2020-02-15 13:52:34 --> URI Class Initialized
INFO - 2020-02-15 13:52:34 --> Router Class Initialized
INFO - 2020-02-15 13:52:34 --> Router Class Initialized
INFO - 2020-02-15 13:52:34 --> Router Class Initialized
INFO - 2020-02-15 13:52:34 --> Router Class Initialized
INFO - 2020-02-15 13:52:34 --> Router Class Initialized
INFO - 2020-02-15 13:52:34 --> Router Class Initialized
INFO - 2020-02-15 13:52:34 --> Output Class Initialized
INFO - 2020-02-15 13:52:34 --> Output Class Initialized
INFO - 2020-02-15 13:52:34 --> Output Class Initialized
INFO - 2020-02-15 13:52:34 --> Output Class Initialized
INFO - 2020-02-15 13:52:34 --> Output Class Initialized
INFO - 2020-02-15 13:52:34 --> Output Class Initialized
INFO - 2020-02-15 13:52:34 --> Security Class Initialized
INFO - 2020-02-15 13:52:34 --> Security Class Initialized
INFO - 2020-02-15 13:52:34 --> Security Class Initialized
INFO - 2020-02-15 13:52:34 --> Security Class Initialized
INFO - 2020-02-15 13:52:34 --> Security Class Initialized
INFO - 2020-02-15 13:52:34 --> Security Class Initialized
DEBUG - 2020-02-15 13:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:52:34 --> Input Class Initialized
INFO - 2020-02-15 13:52:34 --> Input Class Initialized
INFO - 2020-02-15 13:52:34 --> Input Class Initialized
INFO - 2020-02-15 13:52:34 --> Input Class Initialized
INFO - 2020-02-15 13:52:34 --> Input Class Initialized
INFO - 2020-02-15 13:52:34 --> Input Class Initialized
INFO - 2020-02-15 13:52:34 --> Language Class Initialized
INFO - 2020-02-15 13:52:34 --> Language Class Initialized
INFO - 2020-02-15 13:52:34 --> Language Class Initialized
INFO - 2020-02-15 13:52:34 --> Language Class Initialized
INFO - 2020-02-15 13:52:34 --> Language Class Initialized
INFO - 2020-02-15 13:52:34 --> Language Class Initialized
ERROR - 2020-02-15 13:52:35 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-15 13:52:35 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-15 13:52:35 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-15 13:52:35 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 13:52:35 --> Loader Class Initialized
INFO - 2020-02-15 13:52:35 --> Loader Class Initialized
INFO - 2020-02-15 13:52:35 --> Helper loaded: url_helper
INFO - 2020-02-15 13:52:35 --> Helper loaded: url_helper
INFO - 2020-02-15 13:52:35 --> Config Class Initialized
INFO - 2020-02-15 13:52:35 --> Config Class Initialized
INFO - 2020-02-15 13:52:35 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:35 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:35 --> Helper loaded: string_helper
INFO - 2020-02-15 13:52:35 --> Helper loaded: string_helper
DEBUG - 2020-02-15 13:52:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:52:35 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:52:35 --> Database Driver Class Initialized
INFO - 2020-02-15 13:52:35 --> Database Driver Class Initialized
INFO - 2020-02-15 13:52:35 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:35 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 13:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:52:35 --> URI Class Initialized
INFO - 2020-02-15 13:52:35 --> URI Class Initialized
INFO - 2020-02-15 13:52:35 --> Controller Class Initialized
INFO - 2020-02-15 13:52:35 --> Router Class Initialized
INFO - 2020-02-15 13:52:35 --> Router Class Initialized
INFO - 2020-02-15 13:52:35 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:52:35 --> Output Class Initialized
INFO - 2020-02-15 13:52:35 --> Output Class Initialized
INFO - 2020-02-15 13:52:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:52:35 --> Security Class Initialized
INFO - 2020-02-15 13:52:35 --> Security Class Initialized
INFO - 2020-02-15 13:52:35 --> Model "M_pesan" initialized
DEBUG - 2020-02-15 13:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:52:35 --> Input Class Initialized
INFO - 2020-02-15 13:52:35 --> Input Class Initialized
INFO - 2020-02-15 13:52:35 --> Helper loaded: form_helper
INFO - 2020-02-15 13:52:35 --> Form Validation Class Initialized
INFO - 2020-02-15 13:52:35 --> Language Class Initialized
INFO - 2020-02-15 13:52:35 --> Language Class Initialized
ERROR - 2020-02-15 13:52:35 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-15 13:52:35 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-15 13:52:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:52:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:52:35 --> Config Class Initialized
INFO - 2020-02-15 13:52:35 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:52:35 --> Final output sent to browser
DEBUG - 2020-02-15 13:52:35 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:52:35 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:52:35 --> Total execution time: 0.8635
INFO - 2020-02-15 13:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:52:35 --> URI Class Initialized
INFO - 2020-02-15 13:52:35 --> Controller Class Initialized
INFO - 2020-02-15 13:52:35 --> Router Class Initialized
INFO - 2020-02-15 13:52:35 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:52:35 --> Output Class Initialized
INFO - 2020-02-15 13:52:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:52:35 --> Security Class Initialized
INFO - 2020-02-15 13:52:35 --> Model "M_pesan" initialized
DEBUG - 2020-02-15 13:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:52:35 --> Input Class Initialized
INFO - 2020-02-15 13:52:35 --> Helper loaded: form_helper
INFO - 2020-02-15 13:52:35 --> Form Validation Class Initialized
INFO - 2020-02-15 13:52:35 --> Language Class Initialized
ERROR - 2020-02-15 13:52:35 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-15 13:52:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:52:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:52:35 --> Config Class Initialized
INFO - 2020-02-15 13:52:35 --> Hooks Class Initialized
INFO - 2020-02-15 13:52:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:52:35 --> Final output sent to browser
DEBUG - 2020-02-15 13:52:35 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:52:35 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:52:35 --> Total execution time: 1.2018
INFO - 2020-02-15 13:52:35 --> URI Class Initialized
INFO - 2020-02-15 13:52:35 --> Router Class Initialized
INFO - 2020-02-15 13:52:35 --> Output Class Initialized
INFO - 2020-02-15 13:52:36 --> Security Class Initialized
DEBUG - 2020-02-15 13:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:52:36 --> Input Class Initialized
INFO - 2020-02-15 13:52:36 --> Language Class Initialized
ERROR - 2020-02-15 13:52:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:52:36 --> Config Class Initialized
INFO - 2020-02-15 13:52:36 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:52:36 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:52:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:36 --> URI Class Initialized
INFO - 2020-02-15 13:52:36 --> Router Class Initialized
INFO - 2020-02-15 13:52:36 --> Output Class Initialized
INFO - 2020-02-15 13:52:36 --> Security Class Initialized
DEBUG - 2020-02-15 13:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:52:36 --> Input Class Initialized
INFO - 2020-02-15 13:52:36 --> Language Class Initialized
ERROR - 2020-02-15 13:52:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:52:36 --> Config Class Initialized
INFO - 2020-02-15 13:52:36 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:52:36 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:52:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:36 --> URI Class Initialized
INFO - 2020-02-15 13:52:36 --> Router Class Initialized
INFO - 2020-02-15 13:52:36 --> Output Class Initialized
INFO - 2020-02-15 13:52:36 --> Security Class Initialized
DEBUG - 2020-02-15 13:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:52:36 --> Input Class Initialized
INFO - 2020-02-15 13:52:36 --> Language Class Initialized
ERROR - 2020-02-15 13:52:36 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 13:52:36 --> Config Class Initialized
INFO - 2020-02-15 13:52:36 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:52:37 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:52:37 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:37 --> URI Class Initialized
INFO - 2020-02-15 13:52:37 --> Router Class Initialized
INFO - 2020-02-15 13:52:37 --> Output Class Initialized
INFO - 2020-02-15 13:52:37 --> Security Class Initialized
DEBUG - 2020-02-15 13:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:52:37 --> Input Class Initialized
INFO - 2020-02-15 13:52:37 --> Language Class Initialized
ERROR - 2020-02-15 13:52:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 13:52:37 --> Config Class Initialized
INFO - 2020-02-15 13:52:37 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:52:37 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:52:37 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:37 --> URI Class Initialized
INFO - 2020-02-15 13:52:37 --> Router Class Initialized
INFO - 2020-02-15 13:52:37 --> Output Class Initialized
INFO - 2020-02-15 13:52:37 --> Security Class Initialized
DEBUG - 2020-02-15 13:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:52:37 --> Input Class Initialized
INFO - 2020-02-15 13:52:37 --> Language Class Initialized
ERROR - 2020-02-15 13:52:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 13:52:37 --> Config Class Initialized
INFO - 2020-02-15 13:52:37 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:52:37 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:52:37 --> Utf8 Class Initialized
INFO - 2020-02-15 13:52:37 --> URI Class Initialized
INFO - 2020-02-15 13:52:37 --> Router Class Initialized
INFO - 2020-02-15 13:52:37 --> Output Class Initialized
INFO - 2020-02-15 13:52:37 --> Security Class Initialized
DEBUG - 2020-02-15 13:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:52:38 --> Input Class Initialized
INFO - 2020-02-15 13:52:38 --> Language Class Initialized
ERROR - 2020-02-15 13:52:38 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 13:53:17 --> Config Class Initialized
INFO - 2020-02-15 13:53:17 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:53:17 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:53:17 --> Utf8 Class Initialized
INFO - 2020-02-15 13:53:17 --> URI Class Initialized
INFO - 2020-02-15 13:53:17 --> Router Class Initialized
INFO - 2020-02-15 13:53:17 --> Output Class Initialized
INFO - 2020-02-15 13:53:17 --> Security Class Initialized
DEBUG - 2020-02-15 13:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:53:17 --> Input Class Initialized
INFO - 2020-02-15 13:53:17 --> Language Class Initialized
INFO - 2020-02-15 13:53:17 --> Loader Class Initialized
INFO - 2020-02-15 13:53:17 --> Helper loaded: url_helper
INFO - 2020-02-15 13:53:17 --> Helper loaded: string_helper
INFO - 2020-02-15 13:53:17 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:53:17 --> Controller Class Initialized
INFO - 2020-02-15 13:53:17 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:53:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:53:18 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:53:18 --> Helper loaded: form_helper
INFO - 2020-02-15 13:53:18 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:53:18 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\roadshow\application\models\M_pesan.php 74
ERROR - 2020-02-15 13:53:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '34567'' at line 3 - Invalid query: SELECT *
FROM `pemesanan`
WHERE  = '34567'
INFO - 2020-02-15 13:53:18 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-15 13:54:21 --> Config Class Initialized
INFO - 2020-02-15 13:54:21 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:54:21 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:54:21 --> Utf8 Class Initialized
INFO - 2020-02-15 13:54:21 --> URI Class Initialized
INFO - 2020-02-15 13:54:21 --> Router Class Initialized
INFO - 2020-02-15 13:54:21 --> Output Class Initialized
INFO - 2020-02-15 13:54:21 --> Security Class Initialized
DEBUG - 2020-02-15 13:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:54:21 --> Input Class Initialized
INFO - 2020-02-15 13:54:21 --> Language Class Initialized
INFO - 2020-02-15 13:54:21 --> Loader Class Initialized
INFO - 2020-02-15 13:54:21 --> Helper loaded: url_helper
INFO - 2020-02-15 13:54:21 --> Helper loaded: string_helper
INFO - 2020-02-15 13:54:21 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:54:21 --> Controller Class Initialized
INFO - 2020-02-15 13:54:22 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:54:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:54:22 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:54:22 --> Helper loaded: form_helper
INFO - 2020-02-15 13:54:22 --> Form Validation Class Initialized
INFO - 2020-02-15 13:54:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:54:22 --> Final output sent to browser
INFO - 2020-02-15 13:54:22 --> Config Class Initialized
DEBUG - 2020-02-15 13:54:22 --> Total execution time: 0.9830
INFO - 2020-02-15 13:54:22 --> Hooks Class Initialized
INFO - 2020-02-15 13:54:22 --> Config Class Initialized
INFO - 2020-02-15 13:54:22 --> Config Class Initialized
INFO - 2020-02-15 13:54:22 --> Hooks Class Initialized
INFO - 2020-02-15 13:54:22 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:54:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:54:22 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:54:22 --> Utf8 Class Initialized
INFO - 2020-02-15 13:54:22 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:54:22 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:54:22 --> Utf8 Class Initialized
INFO - 2020-02-15 13:54:22 --> URI Class Initialized
INFO - 2020-02-15 13:54:22 --> URI Class Initialized
INFO - 2020-02-15 13:54:22 --> URI Class Initialized
INFO - 2020-02-15 13:54:22 --> Router Class Initialized
INFO - 2020-02-15 13:54:22 --> Router Class Initialized
INFO - 2020-02-15 13:54:22 --> Router Class Initialized
INFO - 2020-02-15 13:54:22 --> Output Class Initialized
INFO - 2020-02-15 13:54:22 --> Output Class Initialized
INFO - 2020-02-15 13:54:22 --> Output Class Initialized
INFO - 2020-02-15 13:54:22 --> Security Class Initialized
INFO - 2020-02-15 13:54:22 --> Security Class Initialized
DEBUG - 2020-02-15 13:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:54:22 --> Security Class Initialized
INFO - 2020-02-15 13:54:22 --> Input Class Initialized
INFO - 2020-02-15 13:54:22 --> Input Class Initialized
DEBUG - 2020-02-15 13:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:54:22 --> Input Class Initialized
INFO - 2020-02-15 13:54:22 --> Language Class Initialized
INFO - 2020-02-15 13:54:22 --> Language Class Initialized
INFO - 2020-02-15 13:54:22 --> Language Class Initialized
ERROR - 2020-02-15 13:54:22 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 13:54:22 --> Loader Class Initialized
INFO - 2020-02-15 13:54:22 --> Helper loaded: url_helper
INFO - 2020-02-15 13:54:22 --> Loader Class Initialized
INFO - 2020-02-15 13:54:22 --> Helper loaded: string_helper
INFO - 2020-02-15 13:54:22 --> Helper loaded: url_helper
INFO - 2020-02-15 13:54:22 --> Helper loaded: string_helper
INFO - 2020-02-15 13:54:22 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:54:22 --> Database Driver Class Initialized
INFO - 2020-02-15 13:54:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-15 13:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:54:22 --> Controller Class Initialized
INFO - 2020-02-15 13:54:22 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:54:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:54:23 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:54:23 --> Helper loaded: form_helper
INFO - 2020-02-15 13:54:23 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:54:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:54:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:54:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:54:23 --> Final output sent to browser
DEBUG - 2020-02-15 13:54:23 --> Total execution time: 0.8090
INFO - 2020-02-15 13:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:54:23 --> Controller Class Initialized
INFO - 2020-02-15 13:54:23 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:54:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:54:23 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:54:23 --> Helper loaded: form_helper
INFO - 2020-02-15 13:54:23 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:54:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:54:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:54:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:54:23 --> Final output sent to browser
DEBUG - 2020-02-15 13:54:23 --> Total execution time: 1.1590
INFO - 2020-02-15 13:54:31 --> Config Class Initialized
INFO - 2020-02-15 13:54:31 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:54:31 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:54:31 --> Utf8 Class Initialized
INFO - 2020-02-15 13:54:31 --> URI Class Initialized
INFO - 2020-02-15 13:54:31 --> Router Class Initialized
INFO - 2020-02-15 13:54:31 --> Output Class Initialized
INFO - 2020-02-15 13:54:31 --> Security Class Initialized
DEBUG - 2020-02-15 13:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:54:31 --> Input Class Initialized
INFO - 2020-02-15 13:54:31 --> Language Class Initialized
INFO - 2020-02-15 13:54:31 --> Loader Class Initialized
INFO - 2020-02-15 13:54:31 --> Helper loaded: url_helper
INFO - 2020-02-15 13:54:31 --> Helper loaded: string_helper
INFO - 2020-02-15 13:54:31 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:54:32 --> Controller Class Initialized
INFO - 2020-02-15 13:54:32 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:54:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:54:32 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:54:32 --> Helper loaded: form_helper
INFO - 2020-02-15 13:54:32 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:54:32 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\roadshow\application\models\M_pesan.php 74
ERROR - 2020-02-15 13:54:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '345671'' at line 3 - Invalid query: SELECT *
FROM `pemesanan`
WHERE  = '345671'
INFO - 2020-02-15 13:54:32 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-15 13:55:26 --> Config Class Initialized
INFO - 2020-02-15 13:55:26 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:26 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:26 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:26 --> URI Class Initialized
INFO - 2020-02-15 13:55:26 --> Router Class Initialized
INFO - 2020-02-15 13:55:26 --> Output Class Initialized
INFO - 2020-02-15 13:55:26 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:26 --> Input Class Initialized
INFO - 2020-02-15 13:55:26 --> Language Class Initialized
INFO - 2020-02-15 13:55:26 --> Loader Class Initialized
INFO - 2020-02-15 13:55:26 --> Helper loaded: url_helper
INFO - 2020-02-15 13:55:26 --> Helper loaded: string_helper
INFO - 2020-02-15 13:55:26 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:55:26 --> Controller Class Initialized
INFO - 2020-02-15 13:55:26 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:55:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:55:26 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:55:26 --> Helper loaded: form_helper
INFO - 2020-02-15 13:55:26 --> Form Validation Class Initialized
INFO - 2020-02-15 13:55:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:55:27 --> Final output sent to browser
INFO - 2020-02-15 13:55:27 --> Config Class Initialized
INFO - 2020-02-15 13:55:27 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:27 --> Total execution time: 0.9761
INFO - 2020-02-15 13:55:27 --> Config Class Initialized
INFO - 2020-02-15 13:55:27 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:27 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:27 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:55:27 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:27 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:27 --> URI Class Initialized
INFO - 2020-02-15 13:55:27 --> URI Class Initialized
INFO - 2020-02-15 13:55:27 --> Router Class Initialized
INFO - 2020-02-15 13:55:27 --> Router Class Initialized
INFO - 2020-02-15 13:55:27 --> Output Class Initialized
INFO - 2020-02-15 13:55:27 --> Security Class Initialized
INFO - 2020-02-15 13:55:27 --> Output Class Initialized
DEBUG - 2020-02-15 13:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:27 --> Security Class Initialized
INFO - 2020-02-15 13:55:27 --> Input Class Initialized
DEBUG - 2020-02-15 13:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:27 --> Input Class Initialized
INFO - 2020-02-15 13:55:27 --> Language Class Initialized
INFO - 2020-02-15 13:55:27 --> Language Class Initialized
INFO - 2020-02-15 13:55:27 --> Loader Class Initialized
INFO - 2020-02-15 13:55:27 --> Helper loaded: url_helper
INFO - 2020-02-15 13:55:27 --> Loader Class Initialized
INFO - 2020-02-15 13:55:27 --> Helper loaded: string_helper
INFO - 2020-02-15 13:55:27 --> Helper loaded: url_helper
INFO - 2020-02-15 13:55:27 --> Helper loaded: string_helper
INFO - 2020-02-15 13:55:27 --> Database Driver Class Initialized
INFO - 2020-02-15 13:55:27 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:55:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-15 13:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:55:27 --> Controller Class Initialized
INFO - 2020-02-15 13:55:27 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:55:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:55:27 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:55:27 --> Helper loaded: form_helper
INFO - 2020-02-15 13:55:27 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:55:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:55:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:55:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:55:28 --> Final output sent to browser
DEBUG - 2020-02-15 13:55:28 --> Total execution time: 1.0146
INFO - 2020-02-15 13:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:55:28 --> Controller Class Initialized
INFO - 2020-02-15 13:55:28 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:55:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:55:28 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:55:28 --> Helper loaded: form_helper
INFO - 2020-02-15 13:55:28 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:55:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:55:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:55:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:55:28 --> Final output sent to browser
DEBUG - 2020-02-15 13:55:28 --> Total execution time: 1.3972
INFO - 2020-02-15 13:55:28 --> Config Class Initialized
INFO - 2020-02-15 13:55:28 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:28 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:28 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:28 --> URI Class Initialized
INFO - 2020-02-15 13:55:28 --> Router Class Initialized
INFO - 2020-02-15 13:55:28 --> Output Class Initialized
INFO - 2020-02-15 13:55:28 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:28 --> Input Class Initialized
INFO - 2020-02-15 13:55:28 --> Language Class Initialized
INFO - 2020-02-15 13:55:28 --> Loader Class Initialized
INFO - 2020-02-15 13:55:28 --> Helper loaded: url_helper
INFO - 2020-02-15 13:55:28 --> Helper loaded: string_helper
INFO - 2020-02-15 13:55:29 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:55:29 --> Controller Class Initialized
INFO - 2020-02-15 13:55:29 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:55:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:55:29 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:55:29 --> Helper loaded: form_helper
INFO - 2020-02-15 13:55:29 --> Form Validation Class Initialized
INFO - 2020-02-15 13:55:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:55:29 --> Final output sent to browser
DEBUG - 2020-02-15 13:55:29 --> Total execution time: 0.7184
INFO - 2020-02-15 13:55:29 --> Config Class Initialized
INFO - 2020-02-15 13:55:29 --> Config Class Initialized
INFO - 2020-02-15 13:55:29 --> Hooks Class Initialized
INFO - 2020-02-15 13:55:29 --> Hooks Class Initialized
INFO - 2020-02-15 13:55:29 --> Config Class Initialized
INFO - 2020-02-15 13:55:29 --> Config Class Initialized
INFO - 2020-02-15 13:55:29 --> Hooks Class Initialized
INFO - 2020-02-15 13:55:29 --> Config Class Initialized
INFO - 2020-02-15 13:55:29 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:55:29 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:29 --> Config Class Initialized
INFO - 2020-02-15 13:55:29 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:29 --> Hooks Class Initialized
INFO - 2020-02-15 13:55:29 --> Hooks Class Initialized
INFO - 2020-02-15 13:55:29 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:55:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:55:29 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:29 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:29 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:29 --> URI Class Initialized
INFO - 2020-02-15 13:55:29 --> URI Class Initialized
DEBUG - 2020-02-15 13:55:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:55:29 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:29 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:29 --> URI Class Initialized
INFO - 2020-02-15 13:55:29 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:29 --> URI Class Initialized
INFO - 2020-02-15 13:55:29 --> Router Class Initialized
INFO - 2020-02-15 13:55:29 --> Router Class Initialized
INFO - 2020-02-15 13:55:29 --> Router Class Initialized
INFO - 2020-02-15 13:55:29 --> Output Class Initialized
INFO - 2020-02-15 13:55:29 --> Router Class Initialized
INFO - 2020-02-15 13:55:29 --> URI Class Initialized
INFO - 2020-02-15 13:55:29 --> Output Class Initialized
INFO - 2020-02-15 13:55:29 --> URI Class Initialized
INFO - 2020-02-15 13:55:29 --> Router Class Initialized
INFO - 2020-02-15 13:55:29 --> Router Class Initialized
INFO - 2020-02-15 13:55:29 --> Security Class Initialized
INFO - 2020-02-15 13:55:29 --> Output Class Initialized
INFO - 2020-02-15 13:55:29 --> Output Class Initialized
INFO - 2020-02-15 13:55:29 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:29 --> Output Class Initialized
INFO - 2020-02-15 13:55:29 --> Security Class Initialized
INFO - 2020-02-15 13:55:29 --> Output Class Initialized
INFO - 2020-02-15 13:55:29 --> Security Class Initialized
INFO - 2020-02-15 13:55:29 --> Input Class Initialized
DEBUG - 2020-02-15 13:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:29 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:29 --> Input Class Initialized
INFO - 2020-02-15 13:55:29 --> Security Class Initialized
INFO - 2020-02-15 13:55:29 --> Input Class Initialized
INFO - 2020-02-15 13:55:29 --> Input Class Initialized
INFO - 2020-02-15 13:55:29 --> Language Class Initialized
INFO - 2020-02-15 13:55:29 --> Language Class Initialized
DEBUG - 2020-02-15 13:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:29 --> Input Class Initialized
INFO - 2020-02-15 13:55:29 --> Language Class Initialized
INFO - 2020-02-15 13:55:29 --> Language Class Initialized
INFO - 2020-02-15 13:55:29 --> Input Class Initialized
ERROR - 2020-02-15 13:55:29 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-15 13:55:29 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-15 13:55:29 --> Language Class Initialized
INFO - 2020-02-15 13:55:29 --> Language Class Initialized
ERROR - 2020-02-15 13:55:29 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-15 13:55:29 --> Loader Class Initialized
INFO - 2020-02-15 13:55:29 --> Config Class Initialized
INFO - 2020-02-15 13:55:29 --> Config Class Initialized
INFO - 2020-02-15 13:55:29 --> Hooks Class Initialized
INFO - 2020-02-15 13:55:29 --> Hooks Class Initialized
ERROR - 2020-02-15 13:55:29 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 13:55:29 --> Helper loaded: url_helper
INFO - 2020-02-15 13:55:29 --> Loader Class Initialized
INFO - 2020-02-15 13:55:29 --> Config Class Initialized
INFO - 2020-02-15 13:55:29 --> Helper loaded: url_helper
INFO - 2020-02-15 13:55:29 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:55:29 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:29 --> Helper loaded: string_helper
INFO - 2020-02-15 13:55:30 --> Config Class Initialized
INFO - 2020-02-15 13:55:30 --> Hooks Class Initialized
INFO - 2020-02-15 13:55:30 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:30 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:30 --> Helper loaded: string_helper
DEBUG - 2020-02-15 13:55:30 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:30 --> Database Driver Class Initialized
INFO - 2020-02-15 13:55:30 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:55:30 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:30 --> URI Class Initialized
INFO - 2020-02-15 13:55:30 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:55:30 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:55:30 --> URI Class Initialized
INFO - 2020-02-15 13:55:30 --> Router Class Initialized
INFO - 2020-02-15 13:55:30 --> URI Class Initialized
DEBUG - 2020-02-15 13:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:55:30 --> Controller Class Initialized
INFO - 2020-02-15 13:55:30 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:55:30 --> Output Class Initialized
INFO - 2020-02-15 13:55:30 --> URI Class Initialized
INFO - 2020-02-15 13:55:30 --> Router Class Initialized
INFO - 2020-02-15 13:55:30 --> Router Class Initialized
INFO - 2020-02-15 13:55:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:55:30 --> Router Class Initialized
INFO - 2020-02-15 13:55:30 --> Output Class Initialized
INFO - 2020-02-15 13:55:30 --> Output Class Initialized
INFO - 2020-02-15 13:55:30 --> Security Class Initialized
INFO - 2020-02-15 13:55:30 --> Model "M_pesan" initialized
DEBUG - 2020-02-15 13:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:30 --> Security Class Initialized
INFO - 2020-02-15 13:55:30 --> Security Class Initialized
INFO - 2020-02-15 13:55:30 --> Output Class Initialized
INFO - 2020-02-15 13:55:30 --> Input Class Initialized
DEBUG - 2020-02-15 13:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:30 --> Security Class Initialized
INFO - 2020-02-15 13:55:30 --> Helper loaded: form_helper
INFO - 2020-02-15 13:55:30 --> Form Validation Class Initialized
INFO - 2020-02-15 13:55:30 --> Input Class Initialized
INFO - 2020-02-15 13:55:30 --> Input Class Initialized
INFO - 2020-02-15 13:55:30 --> Language Class Initialized
DEBUG - 2020-02-15 13:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:30 --> Input Class Initialized
INFO - 2020-02-15 13:55:30 --> Language Class Initialized
INFO - 2020-02-15 13:55:30 --> Language Class Initialized
ERROR - 2020-02-15 13:55:30 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-15 13:55:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:55:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:55:30 --> Language Class Initialized
ERROR - 2020-02-15 13:55:30 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-15 13:55:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:55:30 --> Config Class Initialized
INFO - 2020-02-15 13:55:30 --> Hooks Class Initialized
INFO - 2020-02-15 13:55:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-15 13:55:30 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 13:55:30 --> Config Class Initialized
INFO - 2020-02-15 13:55:30 --> Config Class Initialized
INFO - 2020-02-15 13:55:30 --> Hooks Class Initialized
INFO - 2020-02-15 13:55:30 --> Hooks Class Initialized
INFO - 2020-02-15 13:55:30 --> Final output sent to browser
DEBUG - 2020-02-15 13:55:30 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:30 --> Config Class Initialized
INFO - 2020-02-15 13:55:30 --> Hooks Class Initialized
INFO - 2020-02-15 13:55:30 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:55:30 --> Total execution time: 1.0609
DEBUG - 2020-02-15 13:55:30 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:55:30 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:30 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:30 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:55:30 --> URI Class Initialized
DEBUG - 2020-02-15 13:55:30 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:30 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:30 --> Controller Class Initialized
INFO - 2020-02-15 13:55:30 --> URI Class Initialized
INFO - 2020-02-15 13:55:30 --> Router Class Initialized
INFO - 2020-02-15 13:55:30 --> URI Class Initialized
INFO - 2020-02-15 13:55:30 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:55:30 --> URI Class Initialized
INFO - 2020-02-15 13:55:30 --> Router Class Initialized
INFO - 2020-02-15 13:55:30 --> Output Class Initialized
INFO - 2020-02-15 13:55:30 --> Router Class Initialized
INFO - 2020-02-15 13:55:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:55:30 --> Router Class Initialized
INFO - 2020-02-15 13:55:30 --> Output Class Initialized
INFO - 2020-02-15 13:55:30 --> Output Class Initialized
INFO - 2020-02-15 13:55:30 --> Security Class Initialized
INFO - 2020-02-15 13:55:30 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:55:30 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:30 --> Security Class Initialized
INFO - 2020-02-15 13:55:30 --> Output Class Initialized
INFO - 2020-02-15 13:55:30 --> Input Class Initialized
INFO - 2020-02-15 13:55:30 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:30 --> Helper loaded: form_helper
INFO - 2020-02-15 13:55:30 --> Form Validation Class Initialized
DEBUG - 2020-02-15 13:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:30 --> Language Class Initialized
INFO - 2020-02-15 13:55:30 --> Input Class Initialized
INFO - 2020-02-15 13:55:30 --> Input Class Initialized
INFO - 2020-02-15 13:55:30 --> Input Class Initialized
INFO - 2020-02-15 13:55:30 --> Language Class Initialized
INFO - 2020-02-15 13:55:30 --> Language Class Initialized
ERROR - 2020-02-15 13:55:30 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-15 13:55:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:55:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-15 13:55:30 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-15 13:55:30 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 13:55:30 --> Language Class Initialized
INFO - 2020-02-15 13:55:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-15 13:55:30 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-15 13:55:30 --> Final output sent to browser
INFO - 2020-02-15 13:55:30 --> Config Class Initialized
DEBUG - 2020-02-15 13:55:30 --> Total execution time: 1.4559
INFO - 2020-02-15 13:55:30 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:30 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:30 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:31 --> URI Class Initialized
INFO - 2020-02-15 13:55:31 --> Router Class Initialized
INFO - 2020-02-15 13:55:31 --> Output Class Initialized
INFO - 2020-02-15 13:55:31 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:31 --> Input Class Initialized
INFO - 2020-02-15 13:55:31 --> Language Class Initialized
ERROR - 2020-02-15 13:55:31 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 13:55:31 --> Config Class Initialized
INFO - 2020-02-15 13:55:31 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:31 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:31 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:31 --> URI Class Initialized
INFO - 2020-02-15 13:55:31 --> Router Class Initialized
INFO - 2020-02-15 13:55:31 --> Output Class Initialized
INFO - 2020-02-15 13:55:31 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:31 --> Input Class Initialized
INFO - 2020-02-15 13:55:31 --> Language Class Initialized
ERROR - 2020-02-15 13:55:31 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 13:55:31 --> Config Class Initialized
INFO - 2020-02-15 13:55:31 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:31 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:31 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:31 --> URI Class Initialized
INFO - 2020-02-15 13:55:31 --> Router Class Initialized
INFO - 2020-02-15 13:55:31 --> Output Class Initialized
INFO - 2020-02-15 13:55:31 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:31 --> Input Class Initialized
INFO - 2020-02-15 13:55:31 --> Language Class Initialized
ERROR - 2020-02-15 13:55:32 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 13:55:32 --> Config Class Initialized
INFO - 2020-02-15 13:55:32 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:32 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:32 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:32 --> URI Class Initialized
INFO - 2020-02-15 13:55:32 --> Router Class Initialized
INFO - 2020-02-15 13:55:32 --> Output Class Initialized
INFO - 2020-02-15 13:55:32 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:32 --> Input Class Initialized
INFO - 2020-02-15 13:55:32 --> Language Class Initialized
ERROR - 2020-02-15 13:55:32 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:55:32 --> Config Class Initialized
INFO - 2020-02-15 13:55:32 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:32 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:32 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:32 --> URI Class Initialized
INFO - 2020-02-15 13:55:32 --> Router Class Initialized
INFO - 2020-02-15 13:55:32 --> Output Class Initialized
INFO - 2020-02-15 13:55:32 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:32 --> Input Class Initialized
INFO - 2020-02-15 13:55:33 --> Language Class Initialized
ERROR - 2020-02-15 13:55:33 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:55:33 --> Config Class Initialized
INFO - 2020-02-15 13:55:33 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:33 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:33 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:33 --> URI Class Initialized
INFO - 2020-02-15 13:55:33 --> Router Class Initialized
INFO - 2020-02-15 13:55:33 --> Output Class Initialized
INFO - 2020-02-15 13:55:33 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:33 --> Input Class Initialized
INFO - 2020-02-15 13:55:33 --> Language Class Initialized
ERROR - 2020-02-15 13:55:33 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 13:55:33 --> Config Class Initialized
INFO - 2020-02-15 13:55:33 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:33 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:33 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:33 --> URI Class Initialized
INFO - 2020-02-15 13:55:33 --> Router Class Initialized
INFO - 2020-02-15 13:55:33 --> Output Class Initialized
INFO - 2020-02-15 13:55:33 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:33 --> Input Class Initialized
INFO - 2020-02-15 13:55:33 --> Language Class Initialized
ERROR - 2020-02-15 13:55:33 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 13:55:34 --> Config Class Initialized
INFO - 2020-02-15 13:55:34 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:34 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:34 --> URI Class Initialized
INFO - 2020-02-15 13:55:34 --> Router Class Initialized
INFO - 2020-02-15 13:55:34 --> Output Class Initialized
INFO - 2020-02-15 13:55:34 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:34 --> Input Class Initialized
INFO - 2020-02-15 13:55:34 --> Language Class Initialized
ERROR - 2020-02-15 13:55:34 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 13:55:34 --> Config Class Initialized
INFO - 2020-02-15 13:55:34 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:34 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:34 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:34 --> URI Class Initialized
INFO - 2020-02-15 13:55:35 --> Router Class Initialized
INFO - 2020-02-15 13:55:35 --> Output Class Initialized
INFO - 2020-02-15 13:55:35 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:35 --> Input Class Initialized
INFO - 2020-02-15 13:55:35 --> Language Class Initialized
ERROR - 2020-02-15 13:55:35 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 13:55:44 --> Config Class Initialized
INFO - 2020-02-15 13:55:44 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:55:44 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:55:44 --> Utf8 Class Initialized
INFO - 2020-02-15 13:55:44 --> URI Class Initialized
INFO - 2020-02-15 13:55:44 --> Router Class Initialized
INFO - 2020-02-15 13:55:44 --> Output Class Initialized
INFO - 2020-02-15 13:55:44 --> Security Class Initialized
DEBUG - 2020-02-15 13:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:55:44 --> Input Class Initialized
INFO - 2020-02-15 13:55:44 --> Language Class Initialized
INFO - 2020-02-15 13:55:44 --> Loader Class Initialized
INFO - 2020-02-15 13:55:44 --> Helper loaded: url_helper
INFO - 2020-02-15 13:55:44 --> Helper loaded: string_helper
INFO - 2020-02-15 13:55:44 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:55:45 --> Controller Class Initialized
INFO - 2020-02-15 13:55:45 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:55:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:55:45 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:55:45 --> Helper loaded: form_helper
INFO - 2020-02-15 13:55:45 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:55:45 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\roadshow\application\models\M_pesan.php 74
ERROR - 2020-02-15 13:55:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '12121'' at line 3 - Invalid query: SELECT *
FROM `pemesanan`
WHERE  = '12121'
INFO - 2020-02-15 13:55:46 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-15 13:56:31 --> Config Class Initialized
INFO - 2020-02-15 13:56:31 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:56:31 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:31 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:31 --> URI Class Initialized
DEBUG - 2020-02-15 13:56:31 --> No URI present. Default controller set.
INFO - 2020-02-15 13:56:31 --> Router Class Initialized
INFO - 2020-02-15 13:56:31 --> Output Class Initialized
INFO - 2020-02-15 13:56:31 --> Security Class Initialized
DEBUG - 2020-02-15 13:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:31 --> Input Class Initialized
INFO - 2020-02-15 13:56:31 --> Language Class Initialized
INFO - 2020-02-15 13:56:31 --> Loader Class Initialized
INFO - 2020-02-15 13:56:31 --> Helper loaded: url_helper
INFO - 2020-02-15 13:56:31 --> Helper loaded: string_helper
INFO - 2020-02-15 13:56:31 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:56:31 --> Controller Class Initialized
INFO - 2020-02-15 13:56:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-15 13:56:31 --> Pagination Class Initialized
INFO - 2020-02-15 13:56:31 --> Model "M_show" initialized
INFO - 2020-02-15 13:56:31 --> Helper loaded: form_helper
INFO - 2020-02-15 13:56:32 --> Form Validation Class Initialized
INFO - 2020-02-15 13:56:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-15 13:56:32 --> Final output sent to browser
DEBUG - 2020-02-15 13:56:32 --> Total execution time: 0.7237
INFO - 2020-02-15 13:56:35 --> Config Class Initialized
INFO - 2020-02-15 13:56:35 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:56:35 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:35 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:35 --> URI Class Initialized
INFO - 2020-02-15 13:56:35 --> Router Class Initialized
INFO - 2020-02-15 13:56:35 --> Output Class Initialized
INFO - 2020-02-15 13:56:35 --> Security Class Initialized
DEBUG - 2020-02-15 13:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:35 --> Input Class Initialized
INFO - 2020-02-15 13:56:35 --> Language Class Initialized
INFO - 2020-02-15 13:56:35 --> Loader Class Initialized
INFO - 2020-02-15 13:56:35 --> Helper loaded: url_helper
INFO - 2020-02-15 13:56:35 --> Helper loaded: string_helper
INFO - 2020-02-15 13:56:35 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:56:35 --> Controller Class Initialized
INFO - 2020-02-15 13:56:35 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:56:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:56:35 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:56:35 --> Helper loaded: form_helper
INFO - 2020-02-15 13:56:35 --> Form Validation Class Initialized
INFO - 2020-02-15 13:56:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:56:36 --> Final output sent to browser
DEBUG - 2020-02-15 13:56:36 --> Total execution time: 1.0115
INFO - 2020-02-15 13:56:36 --> Config Class Initialized
INFO - 2020-02-15 13:56:36 --> Config Class Initialized
INFO - 2020-02-15 13:56:36 --> Config Class Initialized
INFO - 2020-02-15 13:56:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:56:36 --> Config Class Initialized
INFO - 2020-02-15 13:56:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:56:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:56:36 --> Config Class Initialized
INFO - 2020-02-15 13:56:36 --> Config Class Initialized
INFO - 2020-02-15 13:56:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:56:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:56:36 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:56:36 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:36 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:56:36 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:36 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:56:36 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:36 --> URI Class Initialized
INFO - 2020-02-15 13:56:36 --> URI Class Initialized
INFO - 2020-02-15 13:56:36 --> URI Class Initialized
INFO - 2020-02-15 13:56:36 --> URI Class Initialized
INFO - 2020-02-15 13:56:36 --> Router Class Initialized
INFO - 2020-02-15 13:56:36 --> URI Class Initialized
INFO - 2020-02-15 13:56:36 --> URI Class Initialized
INFO - 2020-02-15 13:56:36 --> Router Class Initialized
INFO - 2020-02-15 13:56:36 --> Router Class Initialized
INFO - 2020-02-15 13:56:36 --> Router Class Initialized
INFO - 2020-02-15 13:56:36 --> Router Class Initialized
INFO - 2020-02-15 13:56:36 --> Router Class Initialized
INFO - 2020-02-15 13:56:36 --> Output Class Initialized
INFO - 2020-02-15 13:56:36 --> Output Class Initialized
INFO - 2020-02-15 13:56:36 --> Output Class Initialized
INFO - 2020-02-15 13:56:36 --> Security Class Initialized
INFO - 2020-02-15 13:56:36 --> Security Class Initialized
INFO - 2020-02-15 13:56:36 --> Output Class Initialized
INFO - 2020-02-15 13:56:36 --> Output Class Initialized
INFO - 2020-02-15 13:56:36 --> Security Class Initialized
INFO - 2020-02-15 13:56:36 --> Output Class Initialized
INFO - 2020-02-15 13:56:36 --> Security Class Initialized
DEBUG - 2020-02-15 13:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:36 --> Security Class Initialized
DEBUG - 2020-02-15 13:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:36 --> Security Class Initialized
INFO - 2020-02-15 13:56:36 --> Input Class Initialized
INFO - 2020-02-15 13:56:36 --> Input Class Initialized
INFO - 2020-02-15 13:56:36 --> Input Class Initialized
DEBUG - 2020-02-15 13:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:36 --> Input Class Initialized
INFO - 2020-02-15 13:56:36 --> Input Class Initialized
INFO - 2020-02-15 13:56:36 --> Input Class Initialized
INFO - 2020-02-15 13:56:36 --> Language Class Initialized
INFO - 2020-02-15 13:56:36 --> Language Class Initialized
INFO - 2020-02-15 13:56:36 --> Language Class Initialized
INFO - 2020-02-15 13:56:36 --> Language Class Initialized
ERROR - 2020-02-15 13:56:36 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-15 13:56:36 --> Loader Class Initialized
INFO - 2020-02-15 13:56:36 --> Language Class Initialized
INFO - 2020-02-15 13:56:36 --> Language Class Initialized
INFO - 2020-02-15 13:56:36 --> Loader Class Initialized
ERROR - 2020-02-15 13:56:36 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-15 13:56:36 --> Helper loaded: url_helper
ERROR - 2020-02-15 13:56:36 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 13:56:36 --> Helper loaded: url_helper
ERROR - 2020-02-15 13:56:36 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 13:56:36 --> Config Class Initialized
INFO - 2020-02-15 13:56:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:56:36 --> Helper loaded: string_helper
INFO - 2020-02-15 13:56:36 --> Helper loaded: string_helper
INFO - 2020-02-15 13:56:36 --> Config Class Initialized
INFO - 2020-02-15 13:56:36 --> Config Class Initialized
INFO - 2020-02-15 13:56:36 --> Config Class Initialized
INFO - 2020-02-15 13:56:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:56:36 --> Hooks Class Initialized
INFO - 2020-02-15 13:56:36 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:56:36 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:36 --> Database Driver Class Initialized
INFO - 2020-02-15 13:56:36 --> Database Driver Class Initialized
INFO - 2020-02-15 13:56:36 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 13:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:56:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:56:36 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:36 --> URI Class Initialized
INFO - 2020-02-15 13:56:36 --> Controller Class Initialized
INFO - 2020-02-15 13:56:36 --> URI Class Initialized
INFO - 2020-02-15 13:56:36 --> Router Class Initialized
INFO - 2020-02-15 13:56:36 --> URI Class Initialized
INFO - 2020-02-15 13:56:36 --> URI Class Initialized
INFO - 2020-02-15 13:56:36 --> Router Class Initialized
INFO - 2020-02-15 13:56:36 --> Router Class Initialized
INFO - 2020-02-15 13:56:36 --> Output Class Initialized
INFO - 2020-02-15 13:56:36 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:56:36 --> Router Class Initialized
INFO - 2020-02-15 13:56:36 --> Output Class Initialized
INFO - 2020-02-15 13:56:36 --> Output Class Initialized
INFO - 2020-02-15 13:56:36 --> Output Class Initialized
INFO - 2020-02-15 13:56:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:56:36 --> Security Class Initialized
INFO - 2020-02-15 13:56:36 --> Model "M_pesan" initialized
DEBUG - 2020-02-15 13:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:36 --> Security Class Initialized
INFO - 2020-02-15 13:56:36 --> Security Class Initialized
INFO - 2020-02-15 13:56:36 --> Security Class Initialized
INFO - 2020-02-15 13:56:36 --> Input Class Initialized
DEBUG - 2020-02-15 13:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:36 --> Helper loaded: form_helper
INFO - 2020-02-15 13:56:36 --> Input Class Initialized
INFO - 2020-02-15 13:56:36 --> Form Validation Class Initialized
INFO - 2020-02-15 13:56:36 --> Input Class Initialized
INFO - 2020-02-15 13:56:36 --> Input Class Initialized
INFO - 2020-02-15 13:56:36 --> Language Class Initialized
INFO - 2020-02-15 13:56:36 --> Language Class Initialized
INFO - 2020-02-15 13:56:36 --> Language Class Initialized
INFO - 2020-02-15 13:56:36 --> Language Class Initialized
ERROR - 2020-02-15 13:56:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:56:36 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-15 13:56:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-15 13:56:36 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-15 13:56:36 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-15 13:56:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:56:37 --> Config Class Initialized
INFO - 2020-02-15 13:56:37 --> Hooks Class Initialized
INFO - 2020-02-15 13:56:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:56:37 --> Config Class Initialized
INFO - 2020-02-15 13:56:37 --> Config Class Initialized
INFO - 2020-02-15 13:56:37 --> Config Class Initialized
INFO - 2020-02-15 13:56:37 --> Hooks Class Initialized
INFO - 2020-02-15 13:56:37 --> Hooks Class Initialized
INFO - 2020-02-15 13:56:37 --> Hooks Class Initialized
INFO - 2020-02-15 13:56:37 --> Final output sent to browser
DEBUG - 2020-02-15 13:56:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:56:37 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:37 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:37 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:56:37 --> Total execution time: 0.9335
DEBUG - 2020-02-15 13:56:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:56:37 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:37 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:56:37 --> URI Class Initialized
INFO - 2020-02-15 13:56:37 --> URI Class Initialized
INFO - 2020-02-15 13:56:37 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:37 --> Controller Class Initialized
INFO - 2020-02-15 13:56:37 --> URI Class Initialized
INFO - 2020-02-15 13:56:37 --> Router Class Initialized
INFO - 2020-02-15 13:56:37 --> Router Class Initialized
INFO - 2020-02-15 13:56:37 --> URI Class Initialized
INFO - 2020-02-15 13:56:37 --> Router Class Initialized
INFO - 2020-02-15 13:56:37 --> Router Class Initialized
INFO - 2020-02-15 13:56:37 --> Output Class Initialized
INFO - 2020-02-15 13:56:37 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:56:37 --> Output Class Initialized
INFO - 2020-02-15 13:56:37 --> Security Class Initialized
INFO - 2020-02-15 13:56:37 --> Output Class Initialized
INFO - 2020-02-15 13:56:37 --> Security Class Initialized
INFO - 2020-02-15 13:56:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:56:37 --> Output Class Initialized
INFO - 2020-02-15 13:56:37 --> Security Class Initialized
DEBUG - 2020-02-15 13:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:37 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:56:37 --> Security Class Initialized
INFO - 2020-02-15 13:56:37 --> Input Class Initialized
INFO - 2020-02-15 13:56:37 --> Input Class Initialized
DEBUG - 2020-02-15 13:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:37 --> Helper loaded: form_helper
INFO - 2020-02-15 13:56:37 --> Form Validation Class Initialized
INFO - 2020-02-15 13:56:37 --> Input Class Initialized
INFO - 2020-02-15 13:56:37 --> Input Class Initialized
INFO - 2020-02-15 13:56:37 --> Language Class Initialized
INFO - 2020-02-15 13:56:37 --> Language Class Initialized
INFO - 2020-02-15 13:56:37 --> Language Class Initialized
INFO - 2020-02-15 13:56:37 --> Language Class Initialized
ERROR - 2020-02-15 13:56:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-15 13:56:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-15 13:56:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:56:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-15 13:56:37 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-15 13:56:37 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 13:56:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:56:37 --> Final output sent to browser
INFO - 2020-02-15 13:56:37 --> Config Class Initialized
INFO - 2020-02-15 13:56:37 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:56:37 --> Total execution time: 1.3874
DEBUG - 2020-02-15 13:56:37 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:37 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:37 --> URI Class Initialized
INFO - 2020-02-15 13:56:37 --> Router Class Initialized
INFO - 2020-02-15 13:56:37 --> Output Class Initialized
INFO - 2020-02-15 13:56:37 --> Security Class Initialized
DEBUG - 2020-02-15 13:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:37 --> Input Class Initialized
INFO - 2020-02-15 13:56:37 --> Language Class Initialized
ERROR - 2020-02-15 13:56:37 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 13:56:37 --> Config Class Initialized
INFO - 2020-02-15 13:56:37 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:56:38 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:38 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:38 --> URI Class Initialized
INFO - 2020-02-15 13:56:38 --> Router Class Initialized
INFO - 2020-02-15 13:56:38 --> Output Class Initialized
INFO - 2020-02-15 13:56:38 --> Security Class Initialized
DEBUG - 2020-02-15 13:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:38 --> Input Class Initialized
INFO - 2020-02-15 13:56:38 --> Language Class Initialized
ERROR - 2020-02-15 13:56:38 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:56:38 --> Config Class Initialized
INFO - 2020-02-15 13:56:38 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:56:38 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:38 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:38 --> URI Class Initialized
INFO - 2020-02-15 13:56:38 --> Router Class Initialized
INFO - 2020-02-15 13:56:38 --> Output Class Initialized
INFO - 2020-02-15 13:56:38 --> Security Class Initialized
DEBUG - 2020-02-15 13:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:38 --> Input Class Initialized
INFO - 2020-02-15 13:56:38 --> Language Class Initialized
ERROR - 2020-02-15 13:56:38 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:56:38 --> Config Class Initialized
INFO - 2020-02-15 13:56:38 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:56:38 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:38 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:38 --> URI Class Initialized
INFO - 2020-02-15 13:56:38 --> Router Class Initialized
INFO - 2020-02-15 13:56:38 --> Output Class Initialized
INFO - 2020-02-15 13:56:38 --> Security Class Initialized
DEBUG - 2020-02-15 13:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:38 --> Input Class Initialized
INFO - 2020-02-15 13:56:38 --> Language Class Initialized
ERROR - 2020-02-15 13:56:39 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 13:56:39 --> Config Class Initialized
INFO - 2020-02-15 13:56:39 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:56:39 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:39 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:39 --> URI Class Initialized
INFO - 2020-02-15 13:56:39 --> Router Class Initialized
INFO - 2020-02-15 13:56:39 --> Output Class Initialized
INFO - 2020-02-15 13:56:39 --> Security Class Initialized
DEBUG - 2020-02-15 13:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:39 --> Input Class Initialized
INFO - 2020-02-15 13:56:39 --> Language Class Initialized
ERROR - 2020-02-15 13:56:39 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 13:56:39 --> Config Class Initialized
INFO - 2020-02-15 13:56:39 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:56:39 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:39 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:39 --> URI Class Initialized
INFO - 2020-02-15 13:56:39 --> Router Class Initialized
INFO - 2020-02-15 13:56:39 --> Output Class Initialized
INFO - 2020-02-15 13:56:39 --> Security Class Initialized
DEBUG - 2020-02-15 13:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:39 --> Input Class Initialized
INFO - 2020-02-15 13:56:39 --> Language Class Initialized
ERROR - 2020-02-15 13:56:39 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 13:56:39 --> Config Class Initialized
INFO - 2020-02-15 13:56:39 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:56:39 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:39 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:39 --> URI Class Initialized
INFO - 2020-02-15 13:56:39 --> Router Class Initialized
INFO - 2020-02-15 13:56:39 --> Output Class Initialized
INFO - 2020-02-15 13:56:40 --> Security Class Initialized
DEBUG - 2020-02-15 13:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:40 --> Input Class Initialized
INFO - 2020-02-15 13:56:40 --> Language Class Initialized
ERROR - 2020-02-15 13:56:40 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 13:56:52 --> Config Class Initialized
INFO - 2020-02-15 13:56:52 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:56:52 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:56:52 --> Utf8 Class Initialized
INFO - 2020-02-15 13:56:52 --> URI Class Initialized
INFO - 2020-02-15 13:56:52 --> Router Class Initialized
INFO - 2020-02-15 13:56:52 --> Output Class Initialized
INFO - 2020-02-15 13:56:52 --> Security Class Initialized
DEBUG - 2020-02-15 13:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:56:52 --> Input Class Initialized
INFO - 2020-02-15 13:56:52 --> Language Class Initialized
INFO - 2020-02-15 13:56:52 --> Loader Class Initialized
INFO - 2020-02-15 13:56:52 --> Helper loaded: url_helper
INFO - 2020-02-15 13:56:52 --> Helper loaded: string_helper
INFO - 2020-02-15 13:56:52 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:56:53 --> Controller Class Initialized
INFO - 2020-02-15 13:56:53 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:56:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:56:53 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:56:53 --> Helper loaded: form_helper
INFO - 2020-02-15 13:56:53 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:56:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '12121'' at line 3 - Invalid query: SELECT *
FROM `pemesanan`
WHERE  = '12121'
INFO - 2020-02-15 13:56:53 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-15 13:57:46 --> Config Class Initialized
INFO - 2020-02-15 13:57:46 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:57:46 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:57:46 --> Utf8 Class Initialized
INFO - 2020-02-15 13:57:46 --> URI Class Initialized
INFO - 2020-02-15 13:57:46 --> Router Class Initialized
INFO - 2020-02-15 13:57:46 --> Output Class Initialized
INFO - 2020-02-15 13:57:46 --> Security Class Initialized
DEBUG - 2020-02-15 13:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:57:46 --> Input Class Initialized
INFO - 2020-02-15 13:57:46 --> Language Class Initialized
INFO - 2020-02-15 13:57:46 --> Loader Class Initialized
INFO - 2020-02-15 13:57:46 --> Helper loaded: url_helper
INFO - 2020-02-15 13:57:46 --> Helper loaded: string_helper
INFO - 2020-02-15 13:57:46 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:57:46 --> Controller Class Initialized
INFO - 2020-02-15 13:57:46 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:57:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:57:46 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:57:46 --> Helper loaded: form_helper
INFO - 2020-02-15 13:57:46 --> Form Validation Class Initialized
INFO - 2020-02-15 13:57:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:57:46 --> Final output sent to browser
DEBUG - 2020-02-15 13:57:47 --> Total execution time: 0.9685
INFO - 2020-02-15 13:57:47 --> Config Class Initialized
INFO - 2020-02-15 13:57:47 --> Config Class Initialized
INFO - 2020-02-15 13:57:47 --> Hooks Class Initialized
INFO - 2020-02-15 13:57:47 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:57:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:57:47 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:57:47 --> Utf8 Class Initialized
INFO - 2020-02-15 13:57:47 --> Utf8 Class Initialized
INFO - 2020-02-15 13:57:47 --> URI Class Initialized
INFO - 2020-02-15 13:57:47 --> URI Class Initialized
INFO - 2020-02-15 13:57:47 --> Router Class Initialized
INFO - 2020-02-15 13:57:47 --> Router Class Initialized
INFO - 2020-02-15 13:57:47 --> Output Class Initialized
INFO - 2020-02-15 13:57:47 --> Output Class Initialized
INFO - 2020-02-15 13:57:47 --> Security Class Initialized
INFO - 2020-02-15 13:57:47 --> Security Class Initialized
DEBUG - 2020-02-15 13:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:57:47 --> Input Class Initialized
INFO - 2020-02-15 13:57:47 --> Input Class Initialized
INFO - 2020-02-15 13:57:47 --> Language Class Initialized
INFO - 2020-02-15 13:57:47 --> Language Class Initialized
INFO - 2020-02-15 13:57:47 --> Loader Class Initialized
INFO - 2020-02-15 13:57:47 --> Loader Class Initialized
INFO - 2020-02-15 13:57:47 --> Helper loaded: url_helper
INFO - 2020-02-15 13:57:47 --> Helper loaded: url_helper
INFO - 2020-02-15 13:57:47 --> Helper loaded: string_helper
INFO - 2020-02-15 13:57:47 --> Helper loaded: string_helper
INFO - 2020-02-15 13:57:47 --> Database Driver Class Initialized
INFO - 2020-02-15 13:57:47 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 13:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:57:47 --> Controller Class Initialized
INFO - 2020-02-15 13:57:47 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:57:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:57:47 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:57:47 --> Helper loaded: form_helper
INFO - 2020-02-15 13:57:47 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:57:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:57:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:57:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:57:48 --> Final output sent to browser
DEBUG - 2020-02-15 13:57:48 --> Total execution time: 0.9208
INFO - 2020-02-15 13:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:57:48 --> Controller Class Initialized
INFO - 2020-02-15 13:57:48 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:57:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:57:48 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:57:48 --> Helper loaded: form_helper
INFO - 2020-02-15 13:57:48 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:57:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:57:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:57:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:57:48 --> Final output sent to browser
DEBUG - 2020-02-15 13:57:48 --> Total execution time: 1.3149
INFO - 2020-02-15 13:57:55 --> Config Class Initialized
INFO - 2020-02-15 13:57:55 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:57:56 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:57:56 --> Utf8 Class Initialized
INFO - 2020-02-15 13:57:56 --> URI Class Initialized
INFO - 2020-02-15 13:57:56 --> Router Class Initialized
INFO - 2020-02-15 13:57:56 --> Output Class Initialized
INFO - 2020-02-15 13:57:56 --> Security Class Initialized
DEBUG - 2020-02-15 13:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:57:56 --> Input Class Initialized
INFO - 2020-02-15 13:57:56 --> Language Class Initialized
INFO - 2020-02-15 13:57:56 --> Loader Class Initialized
INFO - 2020-02-15 13:57:56 --> Helper loaded: url_helper
INFO - 2020-02-15 13:57:56 --> Helper loaded: string_helper
INFO - 2020-02-15 13:57:56 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:57:56 --> Controller Class Initialized
INFO - 2020-02-15 13:57:56 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:57:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:57:56 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:57:56 --> Helper loaded: form_helper
INFO - 2020-02-15 13:57:56 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:57:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 81
ERROR - 2020-02-15 13:57:56 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `id_pengunjung`) VALUES ('34', '240000', '1', '2', '20-02-15 01:57:56', '2020-02-16 01:57:56', NULL, NULL)
INFO - 2020-02-15 13:57:56 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-15 13:58:03 --> Config Class Initialized
INFO - 2020-02-15 13:58:03 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:03 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:03 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:03 --> URI Class Initialized
INFO - 2020-02-15 13:58:03 --> Router Class Initialized
INFO - 2020-02-15 13:58:03 --> Output Class Initialized
INFO - 2020-02-15 13:58:03 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:03 --> Input Class Initialized
INFO - 2020-02-15 13:58:03 --> Language Class Initialized
INFO - 2020-02-15 13:58:04 --> Loader Class Initialized
INFO - 2020-02-15 13:58:04 --> Helper loaded: url_helper
INFO - 2020-02-15 13:58:04 --> Helper loaded: string_helper
INFO - 2020-02-15 13:58:04 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:58:04 --> Controller Class Initialized
INFO - 2020-02-15 13:58:04 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:58:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:58:04 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:58:04 --> Helper loaded: form_helper
INFO - 2020-02-15 13:58:04 --> Form Validation Class Initialized
INFO - 2020-02-15 13:58:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:58:04 --> Final output sent to browser
DEBUG - 2020-02-15 13:58:04 --> Total execution time: 0.9645
INFO - 2020-02-15 13:58:04 --> Config Class Initialized
INFO - 2020-02-15 13:58:04 --> Config Class Initialized
INFO - 2020-02-15 13:58:04 --> Hooks Class Initialized
INFO - 2020-02-15 13:58:04 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:58:04 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:04 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:04 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:04 --> URI Class Initialized
INFO - 2020-02-15 13:58:04 --> URI Class Initialized
INFO - 2020-02-15 13:58:04 --> Router Class Initialized
INFO - 2020-02-15 13:58:04 --> Router Class Initialized
INFO - 2020-02-15 13:58:04 --> Output Class Initialized
INFO - 2020-02-15 13:58:04 --> Output Class Initialized
INFO - 2020-02-15 13:58:04 --> Security Class Initialized
INFO - 2020-02-15 13:58:04 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:04 --> Input Class Initialized
INFO - 2020-02-15 13:58:04 --> Input Class Initialized
INFO - 2020-02-15 13:58:04 --> Language Class Initialized
INFO - 2020-02-15 13:58:04 --> Language Class Initialized
INFO - 2020-02-15 13:58:04 --> Loader Class Initialized
INFO - 2020-02-15 13:58:04 --> Loader Class Initialized
INFO - 2020-02-15 13:58:05 --> Helper loaded: url_helper
INFO - 2020-02-15 13:58:05 --> Helper loaded: url_helper
INFO - 2020-02-15 13:58:05 --> Helper loaded: string_helper
INFO - 2020-02-15 13:58:05 --> Helper loaded: string_helper
INFO - 2020-02-15 13:58:05 --> Database Driver Class Initialized
INFO - 2020-02-15 13:58:05 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 13:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:58:05 --> Controller Class Initialized
INFO - 2020-02-15 13:58:05 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:58:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:58:05 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:58:05 --> Helper loaded: form_helper
INFO - 2020-02-15 13:58:05 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:58:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:58:05 --> Final output sent to browser
DEBUG - 2020-02-15 13:58:05 --> Total execution time: 1.3887
INFO - 2020-02-15 13:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:58:06 --> Controller Class Initialized
INFO - 2020-02-15 13:58:06 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:58:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:58:06 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:58:06 --> Helper loaded: form_helper
INFO - 2020-02-15 13:58:06 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:58:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:58:06 --> Final output sent to browser
DEBUG - 2020-02-15 13:58:06 --> Total execution time: 1.8972
INFO - 2020-02-15 13:58:14 --> Config Class Initialized
INFO - 2020-02-15 13:58:14 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:14 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:14 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:14 --> URI Class Initialized
INFO - 2020-02-15 13:58:14 --> Router Class Initialized
INFO - 2020-02-15 13:58:14 --> Output Class Initialized
INFO - 2020-02-15 13:58:14 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:14 --> Input Class Initialized
INFO - 2020-02-15 13:58:14 --> Language Class Initialized
INFO - 2020-02-15 13:58:14 --> Loader Class Initialized
INFO - 2020-02-15 13:58:14 --> Helper loaded: url_helper
INFO - 2020-02-15 13:58:14 --> Helper loaded: string_helper
INFO - 2020-02-15 13:58:14 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:58:14 --> Controller Class Initialized
INFO - 2020-02-15 13:58:14 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:58:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:58:14 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:58:14 --> Helper loaded: form_helper
INFO - 2020-02-15 13:58:14 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:58:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 81
ERROR - 2020-02-15 13:58:15 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `id_pengunjung`) VALUES ('34', '240000', '1', '2', '20-02-15 01:58:15', '2020-02-16 01:58:15', NULL, NULL)
INFO - 2020-02-15 13:58:15 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-15 13:58:20 --> Config Class Initialized
INFO - 2020-02-15 13:58:20 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:20 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:20 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:20 --> URI Class Initialized
INFO - 2020-02-15 13:58:20 --> Router Class Initialized
INFO - 2020-02-15 13:58:20 --> Output Class Initialized
INFO - 2020-02-15 13:58:20 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:20 --> Input Class Initialized
INFO - 2020-02-15 13:58:20 --> Language Class Initialized
INFO - 2020-02-15 13:58:20 --> Loader Class Initialized
INFO - 2020-02-15 13:58:20 --> Helper loaded: url_helper
INFO - 2020-02-15 13:58:20 --> Helper loaded: string_helper
INFO - 2020-02-15 13:58:20 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:58:20 --> Controller Class Initialized
INFO - 2020-02-15 13:58:20 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:58:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:58:20 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:58:20 --> Helper loaded: form_helper
INFO - 2020-02-15 13:58:20 --> Form Validation Class Initialized
INFO - 2020-02-15 13:58:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:58:20 --> Final output sent to browser
DEBUG - 2020-02-15 13:58:21 --> Total execution time: 0.9498
INFO - 2020-02-15 13:58:21 --> Config Class Initialized
INFO - 2020-02-15 13:58:21 --> Config Class Initialized
INFO - 2020-02-15 13:58:21 --> Hooks Class Initialized
INFO - 2020-02-15 13:58:21 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:58:21 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:21 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:21 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:21 --> URI Class Initialized
INFO - 2020-02-15 13:58:21 --> URI Class Initialized
INFO - 2020-02-15 13:58:21 --> Router Class Initialized
INFO - 2020-02-15 13:58:21 --> Router Class Initialized
INFO - 2020-02-15 13:58:21 --> Output Class Initialized
INFO - 2020-02-15 13:58:21 --> Output Class Initialized
INFO - 2020-02-15 13:58:21 --> Security Class Initialized
INFO - 2020-02-15 13:58:21 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:21 --> Input Class Initialized
INFO - 2020-02-15 13:58:21 --> Input Class Initialized
INFO - 2020-02-15 13:58:21 --> Language Class Initialized
INFO - 2020-02-15 13:58:21 --> Language Class Initialized
INFO - 2020-02-15 13:58:21 --> Loader Class Initialized
INFO - 2020-02-15 13:58:21 --> Loader Class Initialized
INFO - 2020-02-15 13:58:21 --> Helper loaded: url_helper
INFO - 2020-02-15 13:58:21 --> Helper loaded: url_helper
INFO - 2020-02-15 13:58:21 --> Helper loaded: string_helper
INFO - 2020-02-15 13:58:21 --> Helper loaded: string_helper
INFO - 2020-02-15 13:58:21 --> Database Driver Class Initialized
INFO - 2020-02-15 13:58:21 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 13:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:58:21 --> Controller Class Initialized
INFO - 2020-02-15 13:58:21 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:58:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:58:21 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:58:21 --> Helper loaded: form_helper
INFO - 2020-02-15 13:58:21 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:58:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:58:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:58:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:58:22 --> Final output sent to browser
DEBUG - 2020-02-15 13:58:22 --> Total execution time: 0.9679
INFO - 2020-02-15 13:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:58:22 --> Controller Class Initialized
INFO - 2020-02-15 13:58:22 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:58:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:58:22 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:58:22 --> Helper loaded: form_helper
INFO - 2020-02-15 13:58:22 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:58:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:58:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:58:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:58:22 --> Final output sent to browser
DEBUG - 2020-02-15 13:58:22 --> Total execution time: 1.3412
INFO - 2020-02-15 13:58:22 --> Config Class Initialized
INFO - 2020-02-15 13:58:23 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:23 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:23 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:23 --> URI Class Initialized
INFO - 2020-02-15 13:58:23 --> Router Class Initialized
INFO - 2020-02-15 13:58:23 --> Output Class Initialized
INFO - 2020-02-15 13:58:23 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:23 --> Input Class Initialized
INFO - 2020-02-15 13:58:23 --> Language Class Initialized
INFO - 2020-02-15 13:58:23 --> Loader Class Initialized
INFO - 2020-02-15 13:58:23 --> Helper loaded: url_helper
INFO - 2020-02-15 13:58:23 --> Helper loaded: string_helper
INFO - 2020-02-15 13:58:23 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:58:23 --> Controller Class Initialized
INFO - 2020-02-15 13:58:23 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:58:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:58:23 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:58:23 --> Helper loaded: form_helper
INFO - 2020-02-15 13:58:23 --> Form Validation Class Initialized
INFO - 2020-02-15 13:58:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:58:23 --> Final output sent to browser
INFO - 2020-02-15 13:58:24 --> Config Class Initialized
INFO - 2020-02-15 13:58:24 --> Config Class Initialized
INFO - 2020-02-15 13:58:24 --> Config Class Initialized
INFO - 2020-02-15 13:58:24 --> Config Class Initialized
INFO - 2020-02-15 13:58:24 --> Hooks Class Initialized
INFO - 2020-02-15 13:58:24 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:24 --> Total execution time: 0.8717
INFO - 2020-02-15 13:58:24 --> Hooks Class Initialized
INFO - 2020-02-15 13:58:24 --> Hooks Class Initialized
INFO - 2020-02-15 13:58:24 --> Config Class Initialized
INFO - 2020-02-15 13:58:24 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:58:24 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:24 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:24 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:24 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:24 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:58:24 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:24 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:24 --> URI Class Initialized
INFO - 2020-02-15 13:58:24 --> URI Class Initialized
INFO - 2020-02-15 13:58:24 --> URI Class Initialized
INFO - 2020-02-15 13:58:24 --> URI Class Initialized
INFO - 2020-02-15 13:58:24 --> Router Class Initialized
INFO - 2020-02-15 13:58:24 --> Router Class Initialized
INFO - 2020-02-15 13:58:24 --> URI Class Initialized
INFO - 2020-02-15 13:58:24 --> Router Class Initialized
INFO - 2020-02-15 13:58:24 --> Router Class Initialized
INFO - 2020-02-15 13:58:24 --> Router Class Initialized
INFO - 2020-02-15 13:58:24 --> Output Class Initialized
INFO - 2020-02-15 13:58:24 --> Output Class Initialized
INFO - 2020-02-15 13:58:24 --> Output Class Initialized
INFO - 2020-02-15 13:58:24 --> Output Class Initialized
INFO - 2020-02-15 13:58:24 --> Security Class Initialized
INFO - 2020-02-15 13:58:24 --> Security Class Initialized
INFO - 2020-02-15 13:58:24 --> Security Class Initialized
INFO - 2020-02-15 13:58:24 --> Output Class Initialized
INFO - 2020-02-15 13:58:24 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:24 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:24 --> Input Class Initialized
INFO - 2020-02-15 13:58:24 --> Input Class Initialized
INFO - 2020-02-15 13:58:24 --> Input Class Initialized
INFO - 2020-02-15 13:58:24 --> Input Class Initialized
DEBUG - 2020-02-15 13:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:24 --> Input Class Initialized
INFO - 2020-02-15 13:58:24 --> Language Class Initialized
INFO - 2020-02-15 13:58:24 --> Language Class Initialized
INFO - 2020-02-15 13:58:24 --> Language Class Initialized
INFO - 2020-02-15 13:58:24 --> Language Class Initialized
INFO - 2020-02-15 13:58:24 --> Language Class Initialized
ERROR - 2020-02-15 13:58:24 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-15 13:58:24 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-15 13:58:24 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-15 13:58:24 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-15 13:58:24 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 13:58:24 --> Config Class Initialized
INFO - 2020-02-15 13:58:24 --> Config Class Initialized
INFO - 2020-02-15 13:58:24 --> Config Class Initialized
INFO - 2020-02-15 13:58:24 --> Config Class Initialized
INFO - 2020-02-15 13:58:24 --> Hooks Class Initialized
INFO - 2020-02-15 13:58:24 --> Hooks Class Initialized
INFO - 2020-02-15 13:58:24 --> Hooks Class Initialized
INFO - 2020-02-15 13:58:24 --> Hooks Class Initialized
INFO - 2020-02-15 13:58:24 --> Config Class Initialized
INFO - 2020-02-15 13:58:24 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:58:24 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:24 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:24 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:24 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:24 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:58:24 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:24 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:24 --> URI Class Initialized
INFO - 2020-02-15 13:58:24 --> URI Class Initialized
INFO - 2020-02-15 13:58:24 --> URI Class Initialized
INFO - 2020-02-15 13:58:24 --> URI Class Initialized
INFO - 2020-02-15 13:58:24 --> Router Class Initialized
INFO - 2020-02-15 13:58:24 --> Router Class Initialized
INFO - 2020-02-15 13:58:24 --> Router Class Initialized
INFO - 2020-02-15 13:58:24 --> URI Class Initialized
INFO - 2020-02-15 13:58:24 --> Router Class Initialized
INFO - 2020-02-15 13:58:25 --> Output Class Initialized
INFO - 2020-02-15 13:58:25 --> Output Class Initialized
INFO - 2020-02-15 13:58:25 --> Output Class Initialized
INFO - 2020-02-15 13:58:25 --> Router Class Initialized
INFO - 2020-02-15 13:58:25 --> Output Class Initialized
INFO - 2020-02-15 13:58:25 --> Security Class Initialized
INFO - 2020-02-15 13:58:25 --> Security Class Initialized
INFO - 2020-02-15 13:58:25 --> Security Class Initialized
INFO - 2020-02-15 13:58:25 --> Security Class Initialized
INFO - 2020-02-15 13:58:25 --> Output Class Initialized
DEBUG - 2020-02-15 13:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:25 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 13:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:25 --> Input Class Initialized
INFO - 2020-02-15 13:58:25 --> Input Class Initialized
INFO - 2020-02-15 13:58:25 --> Input Class Initialized
INFO - 2020-02-15 13:58:25 --> Input Class Initialized
DEBUG - 2020-02-15 13:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:25 --> Input Class Initialized
INFO - 2020-02-15 13:58:25 --> Language Class Initialized
INFO - 2020-02-15 13:58:25 --> Language Class Initialized
INFO - 2020-02-15 13:58:25 --> Language Class Initialized
INFO - 2020-02-15 13:58:25 --> Language Class Initialized
ERROR - 2020-02-15 13:58:25 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:58:25 --> Loader Class Initialized
INFO - 2020-02-15 13:58:25 --> Loader Class Initialized
ERROR - 2020-02-15 13:58:25 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:58:25 --> Language Class Initialized
ERROR - 2020-02-15 13:58:25 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 13:58:25 --> Helper loaded: url_helper
INFO - 2020-02-15 13:58:25 --> Helper loaded: url_helper
INFO - 2020-02-15 13:58:25 --> Config Class Initialized
INFO - 2020-02-15 13:58:25 --> Config Class Initialized
INFO - 2020-02-15 13:58:25 --> Hooks Class Initialized
INFO - 2020-02-15 13:58:25 --> Hooks Class Initialized
INFO - 2020-02-15 13:58:25 --> Helper loaded: string_helper
INFO - 2020-02-15 13:58:25 --> Helper loaded: string_helper
INFO - 2020-02-15 13:58:25 --> Config Class Initialized
INFO - 2020-02-15 13:58:25 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:58:25 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:25 --> Database Driver Class Initialized
INFO - 2020-02-15 13:58:25 --> Database Driver Class Initialized
INFO - 2020-02-15 13:58:25 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:25 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:58:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:58:25 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:58:25 --> URI Class Initialized
INFO - 2020-02-15 13:58:25 --> URI Class Initialized
DEBUG - 2020-02-15 13:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:58:25 --> Controller Class Initialized
INFO - 2020-02-15 13:58:25 --> URI Class Initialized
INFO - 2020-02-15 13:58:25 --> Router Class Initialized
INFO - 2020-02-15 13:58:25 --> Router Class Initialized
INFO - 2020-02-15 13:58:25 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:58:25 --> Router Class Initialized
INFO - 2020-02-15 13:58:25 --> Output Class Initialized
INFO - 2020-02-15 13:58:25 --> Output Class Initialized
INFO - 2020-02-15 13:58:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:58:25 --> Security Class Initialized
INFO - 2020-02-15 13:58:25 --> Security Class Initialized
INFO - 2020-02-15 13:58:25 --> Output Class Initialized
INFO - 2020-02-15 13:58:25 --> Model "M_pesan" initialized
DEBUG - 2020-02-15 13:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:25 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:25 --> Input Class Initialized
INFO - 2020-02-15 13:58:25 --> Input Class Initialized
DEBUG - 2020-02-15 13:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:25 --> Helper loaded: form_helper
INFO - 2020-02-15 13:58:25 --> Form Validation Class Initialized
INFO - 2020-02-15 13:58:25 --> Input Class Initialized
INFO - 2020-02-15 13:58:25 --> Language Class Initialized
INFO - 2020-02-15 13:58:25 --> Language Class Initialized
INFO - 2020-02-15 13:58:25 --> Language Class Initialized
ERROR - 2020-02-15 13:58:25 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-15 13:58:25 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-15 13:58:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:58:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-15 13:58:25 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 13:58:25 --> Config Class Initialized
INFO - 2020-02-15 13:58:25 --> Hooks Class Initialized
INFO - 2020-02-15 13:58:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:58:25 --> Final output sent to browser
DEBUG - 2020-02-15 13:58:25 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:25 --> Utf8 Class Initialized
DEBUG - 2020-02-15 13:58:25 --> Total execution time: 1.0917
INFO - 2020-02-15 13:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:58:25 --> URI Class Initialized
INFO - 2020-02-15 13:58:26 --> Controller Class Initialized
INFO - 2020-02-15 13:58:26 --> Router Class Initialized
INFO - 2020-02-15 13:58:26 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:58:26 --> Output Class Initialized
INFO - 2020-02-15 13:58:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:58:26 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:26 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:58:26 --> Input Class Initialized
INFO - 2020-02-15 13:58:26 --> Helper loaded: form_helper
INFO - 2020-02-15 13:58:26 --> Form Validation Class Initialized
INFO - 2020-02-15 13:58:26 --> Language Class Initialized
ERROR - 2020-02-15 13:58:26 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-15 13:58:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 13:58:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 13:58:26 --> Config Class Initialized
INFO - 2020-02-15 13:58:26 --> Hooks Class Initialized
INFO - 2020-02-15 13:58:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 13:58:26 --> Final output sent to browser
DEBUG - 2020-02-15 13:58:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 13:58:26 --> Total execution time: 1.7111
INFO - 2020-02-15 13:58:26 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:26 --> URI Class Initialized
INFO - 2020-02-15 13:58:26 --> Router Class Initialized
INFO - 2020-02-15 13:58:26 --> Output Class Initialized
INFO - 2020-02-15 13:58:26 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:26 --> Input Class Initialized
INFO - 2020-02-15 13:58:26 --> Language Class Initialized
ERROR - 2020-02-15 13:58:26 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 13:58:26 --> Config Class Initialized
INFO - 2020-02-15 13:58:26 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:26 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:26 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:27 --> URI Class Initialized
INFO - 2020-02-15 13:58:27 --> Router Class Initialized
INFO - 2020-02-15 13:58:27 --> Output Class Initialized
INFO - 2020-02-15 13:58:27 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:27 --> Input Class Initialized
INFO - 2020-02-15 13:58:27 --> Language Class Initialized
ERROR - 2020-02-15 13:58:27 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 13:58:27 --> Config Class Initialized
INFO - 2020-02-15 13:58:27 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:27 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:27 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:27 --> URI Class Initialized
INFO - 2020-02-15 13:58:27 --> Router Class Initialized
INFO - 2020-02-15 13:58:27 --> Output Class Initialized
INFO - 2020-02-15 13:58:27 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:27 --> Input Class Initialized
INFO - 2020-02-15 13:58:27 --> Language Class Initialized
ERROR - 2020-02-15 13:58:27 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 13:58:27 --> Config Class Initialized
INFO - 2020-02-15 13:58:27 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:27 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:27 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:27 --> URI Class Initialized
INFO - 2020-02-15 13:58:27 --> Router Class Initialized
INFO - 2020-02-15 13:58:27 --> Output Class Initialized
INFO - 2020-02-15 13:58:27 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:27 --> Input Class Initialized
INFO - 2020-02-15 13:58:28 --> Language Class Initialized
ERROR - 2020-02-15 13:58:28 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:58:28 --> Config Class Initialized
INFO - 2020-02-15 13:58:28 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:28 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:28 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:28 --> URI Class Initialized
INFO - 2020-02-15 13:58:28 --> Router Class Initialized
INFO - 2020-02-15 13:58:28 --> Output Class Initialized
INFO - 2020-02-15 13:58:28 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:28 --> Input Class Initialized
INFO - 2020-02-15 13:58:28 --> Language Class Initialized
ERROR - 2020-02-15 13:58:28 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 13:58:28 --> Config Class Initialized
INFO - 2020-02-15 13:58:28 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:28 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:28 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:28 --> URI Class Initialized
INFO - 2020-02-15 13:58:28 --> Router Class Initialized
INFO - 2020-02-15 13:58:28 --> Output Class Initialized
INFO - 2020-02-15 13:58:28 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:28 --> Input Class Initialized
INFO - 2020-02-15 13:58:28 --> Language Class Initialized
ERROR - 2020-02-15 13:58:28 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 13:58:28 --> Config Class Initialized
INFO - 2020-02-15 13:58:28 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:28 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:29 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:29 --> URI Class Initialized
INFO - 2020-02-15 13:58:29 --> Router Class Initialized
INFO - 2020-02-15 13:58:29 --> Output Class Initialized
INFO - 2020-02-15 13:58:29 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:29 --> Input Class Initialized
INFO - 2020-02-15 13:58:29 --> Language Class Initialized
ERROR - 2020-02-15 13:58:29 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 13:58:29 --> Config Class Initialized
INFO - 2020-02-15 13:58:29 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:29 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:29 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:29 --> URI Class Initialized
INFO - 2020-02-15 13:58:29 --> Router Class Initialized
INFO - 2020-02-15 13:58:29 --> Output Class Initialized
INFO - 2020-02-15 13:58:29 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:29 --> Input Class Initialized
INFO - 2020-02-15 13:58:29 --> Language Class Initialized
ERROR - 2020-02-15 13:58:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 13:58:29 --> Config Class Initialized
INFO - 2020-02-15 13:58:29 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:29 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:29 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:29 --> URI Class Initialized
INFO - 2020-02-15 13:58:29 --> Router Class Initialized
INFO - 2020-02-15 13:58:29 --> Output Class Initialized
INFO - 2020-02-15 13:58:29 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:30 --> Input Class Initialized
INFO - 2020-02-15 13:58:30 --> Language Class Initialized
ERROR - 2020-02-15 13:58:30 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 13:58:59 --> Config Class Initialized
INFO - 2020-02-15 13:58:59 --> Hooks Class Initialized
DEBUG - 2020-02-15 13:58:59 --> UTF-8 Support Enabled
INFO - 2020-02-15 13:58:59 --> Utf8 Class Initialized
INFO - 2020-02-15 13:58:59 --> URI Class Initialized
INFO - 2020-02-15 13:58:59 --> Router Class Initialized
INFO - 2020-02-15 13:58:59 --> Output Class Initialized
INFO - 2020-02-15 13:58:59 --> Security Class Initialized
DEBUG - 2020-02-15 13:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 13:58:59 --> Input Class Initialized
INFO - 2020-02-15 13:58:59 --> Language Class Initialized
INFO - 2020-02-15 13:58:59 --> Loader Class Initialized
INFO - 2020-02-15 13:58:59 --> Helper loaded: url_helper
INFO - 2020-02-15 13:58:59 --> Helper loaded: string_helper
INFO - 2020-02-15 13:58:59 --> Database Driver Class Initialized
DEBUG - 2020-02-15 13:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 13:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 13:58:59 --> Controller Class Initialized
INFO - 2020-02-15 13:58:59 --> Model "M_tiket" initialized
INFO - 2020-02-15 13:58:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 13:58:59 --> Model "M_pesan" initialized
INFO - 2020-02-15 13:58:59 --> Helper loaded: form_helper
INFO - 2020-02-15 13:58:59 --> Form Validation Class Initialized
ERROR - 2020-02-15 13:59:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '212121'' at line 3 - Invalid query: SELECT *
FROM `pemesanan`
WHERE  = '212121'
INFO - 2020-02-15 13:59:00 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-15 14:01:24 --> Config Class Initialized
INFO - 2020-02-15 14:01:24 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:24 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:24 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:24 --> URI Class Initialized
INFO - 2020-02-15 14:01:25 --> Router Class Initialized
INFO - 2020-02-15 14:01:25 --> Output Class Initialized
INFO - 2020-02-15 14:01:25 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:25 --> Input Class Initialized
INFO - 2020-02-15 14:01:25 --> Language Class Initialized
INFO - 2020-02-15 14:01:25 --> Loader Class Initialized
INFO - 2020-02-15 14:01:25 --> Helper loaded: url_helper
INFO - 2020-02-15 14:01:25 --> Helper loaded: string_helper
INFO - 2020-02-15 14:01:25 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:01:25 --> Controller Class Initialized
INFO - 2020-02-15 14:01:25 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:01:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:01:25 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:01:25 --> Helper loaded: form_helper
INFO - 2020-02-15 14:01:25 --> Form Validation Class Initialized
INFO - 2020-02-15 14:01:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:01:25 --> Final output sent to browser
INFO - 2020-02-15 14:01:25 --> Config Class Initialized
INFO - 2020-02-15 14:01:25 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:25 --> Total execution time: 0.8574
INFO - 2020-02-15 14:01:25 --> Config Class Initialized
INFO - 2020-02-15 14:01:25 --> Config Class Initialized
INFO - 2020-02-15 14:01:25 --> Hooks Class Initialized
INFO - 2020-02-15 14:01:25 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:25 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:25 --> Utf8 Class Initialized
DEBUG - 2020-02-15 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:01:25 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:26 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:26 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:26 --> URI Class Initialized
INFO - 2020-02-15 14:01:26 --> URI Class Initialized
INFO - 2020-02-15 14:01:26 --> URI Class Initialized
INFO - 2020-02-15 14:01:26 --> Router Class Initialized
INFO - 2020-02-15 14:01:26 --> Router Class Initialized
INFO - 2020-02-15 14:01:26 --> Router Class Initialized
INFO - 2020-02-15 14:01:26 --> Output Class Initialized
INFO - 2020-02-15 14:01:26 --> Security Class Initialized
INFO - 2020-02-15 14:01:26 --> Output Class Initialized
INFO - 2020-02-15 14:01:26 --> Output Class Initialized
INFO - 2020-02-15 14:01:26 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:26 --> Security Class Initialized
INFO - 2020-02-15 14:01:26 --> Input Class Initialized
DEBUG - 2020-02-15 14:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 14:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:26 --> Input Class Initialized
INFO - 2020-02-15 14:01:26 --> Input Class Initialized
INFO - 2020-02-15 14:01:26 --> Language Class Initialized
INFO - 2020-02-15 14:01:26 --> Language Class Initialized
INFO - 2020-02-15 14:01:26 --> Language Class Initialized
ERROR - 2020-02-15 14:01:26 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-15 14:01:26 --> Loader Class Initialized
INFO - 2020-02-15 14:01:26 --> Loader Class Initialized
INFO - 2020-02-15 14:01:26 --> Helper loaded: url_helper
INFO - 2020-02-15 14:01:26 --> Helper loaded: url_helper
INFO - 2020-02-15 14:01:26 --> Helper loaded: string_helper
INFO - 2020-02-15 14:01:26 --> Helper loaded: string_helper
INFO - 2020-02-15 14:01:26 --> Database Driver Class Initialized
INFO - 2020-02-15 14:01:26 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 14:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:01:26 --> Controller Class Initialized
INFO - 2020-02-15 14:01:26 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:01:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:01:26 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:01:26 --> Helper loaded: form_helper
INFO - 2020-02-15 14:01:26 --> Form Validation Class Initialized
ERROR - 2020-02-15 14:01:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 14:01:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 14:01:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:01:26 --> Final output sent to browser
DEBUG - 2020-02-15 14:01:26 --> Total execution time: 0.9589
INFO - 2020-02-15 14:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:01:26 --> Controller Class Initialized
INFO - 2020-02-15 14:01:26 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:01:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:01:26 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:01:27 --> Helper loaded: form_helper
INFO - 2020-02-15 14:01:27 --> Form Validation Class Initialized
INFO - 2020-02-15 14:01:27 --> Config Class Initialized
INFO - 2020-02-15 14:01:27 --> Hooks Class Initialized
ERROR - 2020-02-15 14:01:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 14:01:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
DEBUG - 2020-02-15 14:01:27 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:27 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:01:27 --> Final output sent to browser
INFO - 2020-02-15 14:01:27 --> URI Class Initialized
DEBUG - 2020-02-15 14:01:27 --> Total execution time: 1.3159
INFO - 2020-02-15 14:01:27 --> Router Class Initialized
INFO - 2020-02-15 14:01:27 --> Output Class Initialized
INFO - 2020-02-15 14:01:27 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:27 --> Input Class Initialized
INFO - 2020-02-15 14:01:27 --> Language Class Initialized
INFO - 2020-02-15 14:01:27 --> Loader Class Initialized
INFO - 2020-02-15 14:01:27 --> Helper loaded: url_helper
INFO - 2020-02-15 14:01:27 --> Helper loaded: string_helper
INFO - 2020-02-15 14:01:27 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:01:27 --> Controller Class Initialized
INFO - 2020-02-15 14:01:27 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:01:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:01:27 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:01:27 --> Helper loaded: form_helper
INFO - 2020-02-15 14:01:27 --> Form Validation Class Initialized
INFO - 2020-02-15 14:01:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:01:27 --> Final output sent to browser
INFO - 2020-02-15 14:01:27 --> Config Class Initialized
INFO - 2020-02-15 14:01:27 --> Config Class Initialized
INFO - 2020-02-15 14:01:27 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:27 --> Total execution time: 0.7728
INFO - 2020-02-15 14:01:27 --> Hooks Class Initialized
INFO - 2020-02-15 14:01:27 --> Config Class Initialized
INFO - 2020-02-15 14:01:27 --> Config Class Initialized
INFO - 2020-02-15 14:01:27 --> Config Class Initialized
INFO - 2020-02-15 14:01:27 --> Hooks Class Initialized
INFO - 2020-02-15 14:01:27 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:27 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:27 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:27 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:27 --> Config Class Initialized
INFO - 2020-02-15 14:01:27 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:27 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:27 --> Hooks Class Initialized
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> Router Class Initialized
INFO - 2020-02-15 14:01:28 --> Router Class Initialized
DEBUG - 2020-02-15 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:01:28 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:28 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:28 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:28 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:28 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:28 --> Output Class Initialized
INFO - 2020-02-15 14:01:28 --> Output Class Initialized
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> Security Class Initialized
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:28 --> Router Class Initialized
DEBUG - 2020-02-15 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:28 --> Router Class Initialized
INFO - 2020-02-15 14:01:28 --> Router Class Initialized
INFO - 2020-02-15 14:01:28 --> Router Class Initialized
INFO - 2020-02-15 14:01:28 --> Input Class Initialized
INFO - 2020-02-15 14:01:28 --> Input Class Initialized
INFO - 2020-02-15 14:01:28 --> Output Class Initialized
INFO - 2020-02-15 14:01:28 --> Output Class Initialized
INFO - 2020-02-15 14:01:28 --> Output Class Initialized
INFO - 2020-02-15 14:01:28 --> Output Class Initialized
INFO - 2020-02-15 14:01:28 --> Language Class Initialized
INFO - 2020-02-15 14:01:28 --> Language Class Initialized
INFO - 2020-02-15 14:01:28 --> Security Class Initialized
INFO - 2020-02-15 14:01:28 --> Security Class Initialized
INFO - 2020-02-15 14:01:28 --> Security Class Initialized
INFO - 2020-02-15 14:01:28 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 14:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-15 14:01:28 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-15 14:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-15 14:01:28 --> 404 Page Not Found: Bower_components/tether
DEBUG - 2020-02-15 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:28 --> Input Class Initialized
INFO - 2020-02-15 14:01:28 --> Input Class Initialized
INFO - 2020-02-15 14:01:28 --> Input Class Initialized
INFO - 2020-02-15 14:01:28 --> Input Class Initialized
INFO - 2020-02-15 14:01:28 --> Config Class Initialized
INFO - 2020-02-15 14:01:28 --> Config Class Initialized
INFO - 2020-02-15 14:01:28 --> Hooks Class Initialized
INFO - 2020-02-15 14:01:28 --> Hooks Class Initialized
INFO - 2020-02-15 14:01:28 --> Language Class Initialized
INFO - 2020-02-15 14:01:28 --> Language Class Initialized
INFO - 2020-02-15 14:01:28 --> Language Class Initialized
INFO - 2020-02-15 14:01:28 --> Language Class Initialized
ERROR - 2020-02-15 14:01:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 14:01:28 --> Loader Class Initialized
ERROR - 2020-02-15 14:01:28 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-15 14:01:28 --> 404 Page Not Found: Bower_components/jquery
DEBUG - 2020-02-15 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:01:28 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:28 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:28 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:28 --> Helper loaded: url_helper
INFO - 2020-02-15 14:01:28 --> Config Class Initialized
INFO - 2020-02-15 14:01:28 --> Config Class Initialized
INFO - 2020-02-15 14:01:28 --> Config Class Initialized
INFO - 2020-02-15 14:01:28 --> Hooks Class Initialized
INFO - 2020-02-15 14:01:28 --> Hooks Class Initialized
INFO - 2020-02-15 14:01:28 --> Hooks Class Initialized
INFO - 2020-02-15 14:01:28 --> Helper loaded: string_helper
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> Router Class Initialized
INFO - 2020-02-15 14:01:28 --> Router Class Initialized
DEBUG - 2020-02-15 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:01:28 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:28 --> Database Driver Class Initialized
INFO - 2020-02-15 14:01:28 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:28 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:28 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:28 --> Output Class Initialized
INFO - 2020-02-15 14:01:28 --> Output Class Initialized
DEBUG - 2020-02-15 14:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> Security Class Initialized
INFO - 2020-02-15 14:01:28 --> Security Class Initialized
INFO - 2020-02-15 14:01:28 --> Controller Class Initialized
DEBUG - 2020-02-15 14:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:28 --> Router Class Initialized
INFO - 2020-02-15 14:01:28 --> Router Class Initialized
INFO - 2020-02-15 14:01:28 --> Router Class Initialized
INFO - 2020-02-15 14:01:28 --> Input Class Initialized
INFO - 2020-02-15 14:01:28 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:01:28 --> Input Class Initialized
INFO - 2020-02-15 14:01:28 --> Output Class Initialized
INFO - 2020-02-15 14:01:28 --> Output Class Initialized
INFO - 2020-02-15 14:01:28 --> Output Class Initialized
INFO - 2020-02-15 14:01:28 --> Language Class Initialized
INFO - 2020-02-15 14:01:28 --> Language Class Initialized
INFO - 2020-02-15 14:01:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:01:28 --> Security Class Initialized
INFO - 2020-02-15 14:01:28 --> Security Class Initialized
INFO - 2020-02-15 14:01:28 --> Security Class Initialized
ERROR - 2020-02-15 14:01:28 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-15 14:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:28 --> Model "M_pesan" initialized
DEBUG - 2020-02-15 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:28 --> Loader Class Initialized
INFO - 2020-02-15 14:01:28 --> Input Class Initialized
INFO - 2020-02-15 14:01:28 --> Input Class Initialized
INFO - 2020-02-15 14:01:28 --> Helper loaded: url_helper
INFO - 2020-02-15 14:01:28 --> Input Class Initialized
INFO - 2020-02-15 14:01:28 --> Helper loaded: form_helper
INFO - 2020-02-15 14:01:28 --> Config Class Initialized
INFO - 2020-02-15 14:01:28 --> Hooks Class Initialized
INFO - 2020-02-15 14:01:28 --> Form Validation Class Initialized
INFO - 2020-02-15 14:01:28 --> Language Class Initialized
INFO - 2020-02-15 14:01:28 --> Language Class Initialized
INFO - 2020-02-15 14:01:28 --> Language Class Initialized
INFO - 2020-02-15 14:01:28 --> Helper loaded: string_helper
ERROR - 2020-02-15 14:01:28 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-15 14:01:28 --> UTF-8 Support Enabled
ERROR - 2020-02-15 14:01:28 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-15 14:01:28 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 14:01:28 --> Database Driver Class Initialized
ERROR - 2020-02-15 14:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-15 14:01:28 --> Utf8 Class Initialized
ERROR - 2020-02-15 14:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
DEBUG - 2020-02-15 14:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:01:28 --> Config Class Initialized
INFO - 2020-02-15 14:01:28 --> Config Class Initialized
INFO - 2020-02-15 14:01:28 --> Hooks Class Initialized
INFO - 2020-02-15 14:01:28 --> Hooks Class Initialized
INFO - 2020-02-15 14:01:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> Final output sent to browser
INFO - 2020-02-15 14:01:28 --> Router Class Initialized
DEBUG - 2020-02-15 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:01:28 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:28 --> Utf8 Class Initialized
DEBUG - 2020-02-15 14:01:28 --> Total execution time: 0.9496
INFO - 2020-02-15 14:01:28 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:28 --> Output Class Initialized
INFO - 2020-02-15 14:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> URI Class Initialized
INFO - 2020-02-15 14:01:28 --> Security Class Initialized
INFO - 2020-02-15 14:01:29 --> Controller Class Initialized
INFO - 2020-02-15 14:01:29 --> Router Class Initialized
DEBUG - 2020-02-15 14:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:29 --> Router Class Initialized
INFO - 2020-02-15 14:01:29 --> Input Class Initialized
INFO - 2020-02-15 14:01:29 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:01:29 --> Output Class Initialized
INFO - 2020-02-15 14:01:29 --> Output Class Initialized
INFO - 2020-02-15 14:01:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:01:29 --> Language Class Initialized
INFO - 2020-02-15 14:01:29 --> Security Class Initialized
INFO - 2020-02-15 14:01:29 --> Security Class Initialized
INFO - 2020-02-15 14:01:29 --> Model "M_pesan" initialized
DEBUG - 2020-02-15 14:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 14:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-15 14:01:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 14:01:29 --> Input Class Initialized
INFO - 2020-02-15 14:01:29 --> Input Class Initialized
INFO - 2020-02-15 14:01:29 --> Helper loaded: form_helper
INFO - 2020-02-15 14:01:29 --> Form Validation Class Initialized
INFO - 2020-02-15 14:01:29 --> Language Class Initialized
INFO - 2020-02-15 14:01:29 --> Language Class Initialized
ERROR - 2020-02-15 14:01:29 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-15 14:01:29 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-15 14:01:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 14:01:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 14:01:29 --> Config Class Initialized
INFO - 2020-02-15 14:01:29 --> Hooks Class Initialized
INFO - 2020-02-15 14:01:29 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:01:29 --> Final output sent to browser
DEBUG - 2020-02-15 14:01:29 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:29 --> Utf8 Class Initialized
DEBUG - 2020-02-15 14:01:29 --> Total execution time: 1.0748
INFO - 2020-02-15 14:01:29 --> URI Class Initialized
INFO - 2020-02-15 14:01:29 --> Router Class Initialized
INFO - 2020-02-15 14:01:29 --> Output Class Initialized
INFO - 2020-02-15 14:01:29 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:29 --> Input Class Initialized
INFO - 2020-02-15 14:01:29 --> Language Class Initialized
ERROR - 2020-02-15 14:01:29 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 14:01:29 --> Config Class Initialized
INFO - 2020-02-15 14:01:29 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:29 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:29 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:29 --> URI Class Initialized
INFO - 2020-02-15 14:01:29 --> Router Class Initialized
INFO - 2020-02-15 14:01:29 --> Output Class Initialized
INFO - 2020-02-15 14:01:29 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:29 --> Input Class Initialized
INFO - 2020-02-15 14:01:30 --> Language Class Initialized
ERROR - 2020-02-15 14:01:30 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 14:01:30 --> Config Class Initialized
INFO - 2020-02-15 14:01:30 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:30 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:30 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:30 --> URI Class Initialized
INFO - 2020-02-15 14:01:30 --> Router Class Initialized
INFO - 2020-02-15 14:01:30 --> Output Class Initialized
INFO - 2020-02-15 14:01:30 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:30 --> Input Class Initialized
INFO - 2020-02-15 14:01:30 --> Language Class Initialized
ERROR - 2020-02-15 14:01:30 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 14:01:30 --> Config Class Initialized
INFO - 2020-02-15 14:01:30 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:30 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:30 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:30 --> URI Class Initialized
INFO - 2020-02-15 14:01:30 --> Router Class Initialized
INFO - 2020-02-15 14:01:30 --> Output Class Initialized
INFO - 2020-02-15 14:01:30 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:30 --> Input Class Initialized
INFO - 2020-02-15 14:01:30 --> Language Class Initialized
ERROR - 2020-02-15 14:01:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 14:01:30 --> Config Class Initialized
INFO - 2020-02-15 14:01:30 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:31 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:31 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:31 --> URI Class Initialized
INFO - 2020-02-15 14:01:31 --> Router Class Initialized
INFO - 2020-02-15 14:01:31 --> Output Class Initialized
INFO - 2020-02-15 14:01:31 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:31 --> Input Class Initialized
INFO - 2020-02-15 14:01:31 --> Language Class Initialized
ERROR - 2020-02-15 14:01:31 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 14:01:31 --> Config Class Initialized
INFO - 2020-02-15 14:01:31 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:31 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:31 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:31 --> URI Class Initialized
INFO - 2020-02-15 14:01:31 --> Router Class Initialized
INFO - 2020-02-15 14:01:31 --> Output Class Initialized
INFO - 2020-02-15 14:01:31 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:31 --> Input Class Initialized
INFO - 2020-02-15 14:01:31 --> Language Class Initialized
ERROR - 2020-02-15 14:01:31 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 14:01:31 --> Config Class Initialized
INFO - 2020-02-15 14:01:31 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:31 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:31 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:31 --> URI Class Initialized
INFO - 2020-02-15 14:01:31 --> Router Class Initialized
INFO - 2020-02-15 14:01:31 --> Output Class Initialized
INFO - 2020-02-15 14:01:31 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:32 --> Input Class Initialized
INFO - 2020-02-15 14:01:32 --> Language Class Initialized
ERROR - 2020-02-15 14:01:32 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 14:01:32 --> Config Class Initialized
INFO - 2020-02-15 14:01:32 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:32 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:32 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:32 --> URI Class Initialized
INFO - 2020-02-15 14:01:32 --> Router Class Initialized
INFO - 2020-02-15 14:01:32 --> Output Class Initialized
INFO - 2020-02-15 14:01:32 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:32 --> Input Class Initialized
INFO - 2020-02-15 14:01:32 --> Language Class Initialized
ERROR - 2020-02-15 14:01:32 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 14:01:32 --> Config Class Initialized
INFO - 2020-02-15 14:01:32 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:32 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:32 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:32 --> URI Class Initialized
INFO - 2020-02-15 14:01:32 --> Router Class Initialized
INFO - 2020-02-15 14:01:32 --> Output Class Initialized
INFO - 2020-02-15 14:01:32 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:32 --> Input Class Initialized
INFO - 2020-02-15 14:01:32 --> Language Class Initialized
ERROR - 2020-02-15 14:01:32 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-15 14:01:59 --> Config Class Initialized
INFO - 2020-02-15 14:01:59 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:01:59 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:01:59 --> Utf8 Class Initialized
INFO - 2020-02-15 14:01:59 --> URI Class Initialized
INFO - 2020-02-15 14:01:59 --> Router Class Initialized
INFO - 2020-02-15 14:01:59 --> Output Class Initialized
INFO - 2020-02-15 14:01:59 --> Security Class Initialized
DEBUG - 2020-02-15 14:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:01:59 --> Input Class Initialized
INFO - 2020-02-15 14:01:59 --> Language Class Initialized
INFO - 2020-02-15 14:01:59 --> Loader Class Initialized
INFO - 2020-02-15 14:01:59 --> Helper loaded: url_helper
INFO - 2020-02-15 14:01:59 --> Helper loaded: string_helper
INFO - 2020-02-15 14:01:59 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:01:59 --> Controller Class Initialized
INFO - 2020-02-15 14:01:59 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:01:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:01:59 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:01:59 --> Helper loaded: form_helper
INFO - 2020-02-15 14:02:00 --> Form Validation Class Initialized
ERROR - 2020-02-15 14:02:00 --> Severity: Notice --> Undefined variable: pemesanan C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
ERROR - 2020-02-15 14:02:00 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-15 14:02:45 --> Config Class Initialized
INFO - 2020-02-15 14:02:45 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:02:45 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:02:45 --> Utf8 Class Initialized
INFO - 2020-02-15 14:02:45 --> URI Class Initialized
INFO - 2020-02-15 14:02:45 --> Router Class Initialized
INFO - 2020-02-15 14:02:45 --> Output Class Initialized
INFO - 2020-02-15 14:02:45 --> Security Class Initialized
DEBUG - 2020-02-15 14:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:02:45 --> Input Class Initialized
INFO - 2020-02-15 14:02:45 --> Language Class Initialized
INFO - 2020-02-15 14:02:45 --> Loader Class Initialized
INFO - 2020-02-15 14:02:45 --> Helper loaded: url_helper
INFO - 2020-02-15 14:02:45 --> Helper loaded: string_helper
INFO - 2020-02-15 14:02:45 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:02:45 --> Controller Class Initialized
INFO - 2020-02-15 14:02:45 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:02:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:02:45 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:02:46 --> Helper loaded: form_helper
INFO - 2020-02-15 14:02:46 --> Form Validation Class Initialized
INFO - 2020-02-15 14:02:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:02:46 --> Final output sent to browser
DEBUG - 2020-02-15 14:02:46 --> Total execution time: 0.9741
INFO - 2020-02-15 14:02:46 --> Config Class Initialized
INFO - 2020-02-15 14:02:46 --> Config Class Initialized
INFO - 2020-02-15 14:02:46 --> Hooks Class Initialized
INFO - 2020-02-15 14:02:46 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:02:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:02:46 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:02:46 --> Utf8 Class Initialized
INFO - 2020-02-15 14:02:46 --> Utf8 Class Initialized
INFO - 2020-02-15 14:02:46 --> URI Class Initialized
INFO - 2020-02-15 14:02:46 --> URI Class Initialized
INFO - 2020-02-15 14:02:46 --> Router Class Initialized
INFO - 2020-02-15 14:02:46 --> Router Class Initialized
INFO - 2020-02-15 14:02:46 --> Output Class Initialized
INFO - 2020-02-15 14:02:46 --> Output Class Initialized
INFO - 2020-02-15 14:02:46 --> Security Class Initialized
INFO - 2020-02-15 14:02:46 --> Security Class Initialized
DEBUG - 2020-02-15 14:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 14:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:02:46 --> Input Class Initialized
INFO - 2020-02-15 14:02:46 --> Input Class Initialized
INFO - 2020-02-15 14:02:46 --> Language Class Initialized
INFO - 2020-02-15 14:02:46 --> Language Class Initialized
INFO - 2020-02-15 14:02:46 --> Loader Class Initialized
INFO - 2020-02-15 14:02:46 --> Loader Class Initialized
INFO - 2020-02-15 14:02:46 --> Helper loaded: url_helper
INFO - 2020-02-15 14:02:46 --> Helper loaded: url_helper
INFO - 2020-02-15 14:02:46 --> Helper loaded: string_helper
INFO - 2020-02-15 14:02:46 --> Helper loaded: string_helper
INFO - 2020-02-15 14:02:46 --> Database Driver Class Initialized
INFO - 2020-02-15 14:02:46 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 14:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:02:46 --> Controller Class Initialized
INFO - 2020-02-15 14:02:46 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:02:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:02:46 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:02:46 --> Helper loaded: form_helper
INFO - 2020-02-15 14:02:47 --> Form Validation Class Initialized
ERROR - 2020-02-15 14:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 14:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 14:02:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:02:47 --> Final output sent to browser
DEBUG - 2020-02-15 14:02:47 --> Total execution time: 0.9329
INFO - 2020-02-15 14:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:02:47 --> Controller Class Initialized
INFO - 2020-02-15 14:02:47 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:02:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:02:47 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:02:47 --> Helper loaded: form_helper
INFO - 2020-02-15 14:02:47 --> Form Validation Class Initialized
ERROR - 2020-02-15 14:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 14:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 14:02:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:02:47 --> Final output sent to browser
DEBUG - 2020-02-15 14:02:47 --> Total execution time: 1.2739
INFO - 2020-02-15 14:03:16 --> Config Class Initialized
INFO - 2020-02-15 14:03:16 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:03:16 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:03:16 --> Utf8 Class Initialized
INFO - 2020-02-15 14:03:16 --> URI Class Initialized
INFO - 2020-02-15 14:03:16 --> Router Class Initialized
INFO - 2020-02-15 14:03:16 --> Output Class Initialized
INFO - 2020-02-15 14:03:16 --> Security Class Initialized
DEBUG - 2020-02-15 14:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:03:16 --> Input Class Initialized
INFO - 2020-02-15 14:03:16 --> Language Class Initialized
INFO - 2020-02-15 14:03:16 --> Loader Class Initialized
INFO - 2020-02-15 14:03:16 --> Helper loaded: url_helper
INFO - 2020-02-15 14:03:17 --> Helper loaded: string_helper
INFO - 2020-02-15 14:03:17 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:03:17 --> Controller Class Initialized
INFO - 2020-02-15 14:03:17 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:03:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:03:17 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:03:17 --> Helper loaded: form_helper
INFO - 2020-02-15 14:03:17 --> Form Validation Class Initialized
INFO - 2020-02-15 14:03:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-15 14:03:17 --> Final output sent to browser
DEBUG - 2020-02-15 14:03:17 --> Total execution time: 1.1326
INFO - 2020-02-15 14:06:58 --> Config Class Initialized
INFO - 2020-02-15 14:06:58 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:06:58 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:06:59 --> Utf8 Class Initialized
INFO - 2020-02-15 14:06:59 --> URI Class Initialized
INFO - 2020-02-15 14:06:59 --> Router Class Initialized
INFO - 2020-02-15 14:06:59 --> Output Class Initialized
INFO - 2020-02-15 14:06:59 --> Security Class Initialized
DEBUG - 2020-02-15 14:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:06:59 --> Input Class Initialized
INFO - 2020-02-15 14:06:59 --> Language Class Initialized
ERROR - 2020-02-15 14:06:59 --> 404 Page Not Found: Konfimirmasi/111
INFO - 2020-02-15 14:07:08 --> Config Class Initialized
INFO - 2020-02-15 14:07:08 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:07:09 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:07:09 --> Utf8 Class Initialized
INFO - 2020-02-15 14:07:09 --> URI Class Initialized
INFO - 2020-02-15 14:07:09 --> Router Class Initialized
INFO - 2020-02-15 14:07:09 --> Output Class Initialized
INFO - 2020-02-15 14:07:09 --> Security Class Initialized
DEBUG - 2020-02-15 14:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:07:09 --> Input Class Initialized
INFO - 2020-02-15 14:07:09 --> Language Class Initialized
INFO - 2020-02-15 14:07:09 --> Loader Class Initialized
INFO - 2020-02-15 14:07:09 --> Helper loaded: url_helper
INFO - 2020-02-15 14:07:09 --> Helper loaded: string_helper
INFO - 2020-02-15 14:07:09 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:07:09 --> Controller Class Initialized
INFO - 2020-02-15 14:07:09 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:07:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:07:09 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:07:09 --> Helper loaded: form_helper
INFO - 2020-02-15 14:07:09 --> Form Validation Class Initialized
INFO - 2020-02-15 14:07:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:07:09 --> Final output sent to browser
INFO - 2020-02-15 14:07:10 --> Config Class Initialized
INFO - 2020-02-15 14:07:10 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:07:10 --> Total execution time: 1.0977
INFO - 2020-02-15 14:07:10 --> Config Class Initialized
INFO - 2020-02-15 14:07:10 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:07:10 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:07:10 --> Utf8 Class Initialized
DEBUG - 2020-02-15 14:07:10 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:07:10 --> Utf8 Class Initialized
INFO - 2020-02-15 14:07:10 --> URI Class Initialized
INFO - 2020-02-15 14:07:10 --> URI Class Initialized
INFO - 2020-02-15 14:07:10 --> Router Class Initialized
INFO - 2020-02-15 14:07:10 --> Router Class Initialized
INFO - 2020-02-15 14:07:10 --> Output Class Initialized
INFO - 2020-02-15 14:07:10 --> Security Class Initialized
INFO - 2020-02-15 14:07:10 --> Output Class Initialized
INFO - 2020-02-15 14:07:10 --> Security Class Initialized
DEBUG - 2020-02-15 14:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:07:10 --> Input Class Initialized
DEBUG - 2020-02-15 14:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:07:10 --> Input Class Initialized
INFO - 2020-02-15 14:07:10 --> Language Class Initialized
INFO - 2020-02-15 14:07:10 --> Language Class Initialized
INFO - 2020-02-15 14:07:10 --> Loader Class Initialized
INFO - 2020-02-15 14:07:10 --> Helper loaded: url_helper
INFO - 2020-02-15 14:07:10 --> Loader Class Initialized
INFO - 2020-02-15 14:07:10 --> Helper loaded: string_helper
INFO - 2020-02-15 14:07:10 --> Helper loaded: url_helper
INFO - 2020-02-15 14:07:10 --> Helper loaded: string_helper
INFO - 2020-02-15 14:07:10 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:07:10 --> Database Driver Class Initialized
INFO - 2020-02-15 14:07:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-15 14:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:07:10 --> Controller Class Initialized
INFO - 2020-02-15 14:07:10 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:07:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:07:10 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:07:10 --> Helper loaded: form_helper
INFO - 2020-02-15 14:07:10 --> Form Validation Class Initialized
ERROR - 2020-02-15 14:07:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 14:07:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 14:07:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:07:10 --> Final output sent to browser
DEBUG - 2020-02-15 14:07:11 --> Total execution time: 0.9169
INFO - 2020-02-15 14:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:07:11 --> Controller Class Initialized
INFO - 2020-02-15 14:07:11 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:07:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:07:11 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:07:11 --> Helper loaded: form_helper
INFO - 2020-02-15 14:07:11 --> Form Validation Class Initialized
ERROR - 2020-02-15 14:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 14:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 14:07:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:07:11 --> Final output sent to browser
DEBUG - 2020-02-15 14:07:11 --> Total execution time: 1.2798
INFO - 2020-02-15 14:07:27 --> Config Class Initialized
INFO - 2020-02-15 14:07:27 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:07:27 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:07:27 --> Utf8 Class Initialized
INFO - 2020-02-15 14:07:27 --> URI Class Initialized
INFO - 2020-02-15 14:07:27 --> Router Class Initialized
INFO - 2020-02-15 14:07:27 --> Output Class Initialized
INFO - 2020-02-15 14:07:27 --> Security Class Initialized
DEBUG - 2020-02-15 14:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:07:27 --> Input Class Initialized
INFO - 2020-02-15 14:07:27 --> Language Class Initialized
INFO - 2020-02-15 14:07:27 --> Loader Class Initialized
INFO - 2020-02-15 14:07:27 --> Helper loaded: url_helper
INFO - 2020-02-15 14:07:27 --> Helper loaded: string_helper
INFO - 2020-02-15 14:07:27 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:07:27 --> Controller Class Initialized
INFO - 2020-02-15 14:07:28 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:07:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:07:28 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:07:28 --> Helper loaded: form_helper
INFO - 2020-02-15 14:07:28 --> Form Validation Class Initialized
INFO - 2020-02-15 14:07:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-15 14:07:28 --> Final output sent to browser
DEBUG - 2020-02-15 14:07:28 --> Total execution time: 1.0011
INFO - 2020-02-15 14:07:47 --> Config Class Initialized
INFO - 2020-02-15 14:07:47 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:07:47 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:07:47 --> Utf8 Class Initialized
INFO - 2020-02-15 14:07:47 --> URI Class Initialized
INFO - 2020-02-15 14:07:48 --> Router Class Initialized
INFO - 2020-02-15 14:07:48 --> Output Class Initialized
INFO - 2020-02-15 14:07:48 --> Security Class Initialized
DEBUG - 2020-02-15 14:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:07:48 --> Input Class Initialized
INFO - 2020-02-15 14:07:48 --> Language Class Initialized
INFO - 2020-02-15 14:07:48 --> Loader Class Initialized
INFO - 2020-02-15 14:07:48 --> Helper loaded: url_helper
INFO - 2020-02-15 14:07:48 --> Helper loaded: string_helper
INFO - 2020-02-15 14:07:48 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:07:48 --> Controller Class Initialized
INFO - 2020-02-15 14:07:48 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:07:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:07:48 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:07:48 --> Helper loaded: form_helper
INFO - 2020-02-15 14:07:48 --> Form Validation Class Initialized
INFO - 2020-02-15 14:07:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:07:48 --> Final output sent to browser
DEBUG - 2020-02-15 14:07:48 --> Total execution time: 1.0767
INFO - 2020-02-15 14:07:48 --> Config Class Initialized
INFO - 2020-02-15 14:07:48 --> Config Class Initialized
INFO - 2020-02-15 14:07:48 --> Hooks Class Initialized
INFO - 2020-02-15 14:07:48 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:07:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:07:48 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:07:48 --> Utf8 Class Initialized
INFO - 2020-02-15 14:07:48 --> Utf8 Class Initialized
INFO - 2020-02-15 14:07:49 --> URI Class Initialized
INFO - 2020-02-15 14:07:49 --> URI Class Initialized
INFO - 2020-02-15 14:07:49 --> Router Class Initialized
INFO - 2020-02-15 14:07:49 --> Router Class Initialized
INFO - 2020-02-15 14:07:49 --> Output Class Initialized
INFO - 2020-02-15 14:07:49 --> Output Class Initialized
INFO - 2020-02-15 14:07:49 --> Security Class Initialized
INFO - 2020-02-15 14:07:49 --> Security Class Initialized
DEBUG - 2020-02-15 14:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 14:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:07:49 --> Input Class Initialized
INFO - 2020-02-15 14:07:49 --> Input Class Initialized
INFO - 2020-02-15 14:07:49 --> Language Class Initialized
INFO - 2020-02-15 14:07:49 --> Language Class Initialized
INFO - 2020-02-15 14:07:49 --> Loader Class Initialized
INFO - 2020-02-15 14:07:49 --> Loader Class Initialized
INFO - 2020-02-15 14:07:49 --> Helper loaded: url_helper
INFO - 2020-02-15 14:07:49 --> Helper loaded: url_helper
INFO - 2020-02-15 14:07:49 --> Helper loaded: string_helper
INFO - 2020-02-15 14:07:49 --> Helper loaded: string_helper
INFO - 2020-02-15 14:07:49 --> Database Driver Class Initialized
INFO - 2020-02-15 14:07:49 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-15 14:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:07:49 --> Controller Class Initialized
INFO - 2020-02-15 14:07:49 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:07:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:07:49 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:07:49 --> Helper loaded: form_helper
INFO - 2020-02-15 14:07:49 --> Form Validation Class Initialized
ERROR - 2020-02-15 14:07:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 14:07:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 14:07:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:07:49 --> Final output sent to browser
DEBUG - 2020-02-15 14:07:49 --> Total execution time: 0.9390
INFO - 2020-02-15 14:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:07:49 --> Controller Class Initialized
INFO - 2020-02-15 14:07:49 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:07:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:07:49 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:07:49 --> Helper loaded: form_helper
INFO - 2020-02-15 14:07:50 --> Form Validation Class Initialized
ERROR - 2020-02-15 14:07:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 14:07:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 14:07:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:07:50 --> Final output sent to browser
DEBUG - 2020-02-15 14:07:50 --> Total execution time: 1.3220
INFO - 2020-02-15 14:07:52 --> Config Class Initialized
INFO - 2020-02-15 14:07:52 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:07:52 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:07:52 --> Utf8 Class Initialized
INFO - 2020-02-15 14:07:52 --> URI Class Initialized
DEBUG - 2020-02-15 14:07:52 --> No URI present. Default controller set.
INFO - 2020-02-15 14:07:52 --> Router Class Initialized
INFO - 2020-02-15 14:07:52 --> Output Class Initialized
INFO - 2020-02-15 14:07:52 --> Security Class Initialized
DEBUG - 2020-02-15 14:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:07:52 --> Input Class Initialized
INFO - 2020-02-15 14:07:52 --> Language Class Initialized
INFO - 2020-02-15 14:07:52 --> Loader Class Initialized
INFO - 2020-02-15 14:07:52 --> Helper loaded: url_helper
INFO - 2020-02-15 14:07:52 --> Helper loaded: string_helper
INFO - 2020-02-15 14:07:52 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:07:52 --> Controller Class Initialized
INFO - 2020-02-15 14:07:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-15 14:07:52 --> Pagination Class Initialized
INFO - 2020-02-15 14:07:52 --> Model "M_show" initialized
INFO - 2020-02-15 14:07:52 --> Helper loaded: form_helper
INFO - 2020-02-15 14:07:52 --> Form Validation Class Initialized
INFO - 2020-02-15 14:07:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-15 14:07:53 --> Final output sent to browser
DEBUG - 2020-02-15 14:07:53 --> Total execution time: 0.9657
INFO - 2020-02-15 14:12:01 --> Config Class Initialized
INFO - 2020-02-15 14:12:01 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:01 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:01 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:02 --> URI Class Initialized
INFO - 2020-02-15 14:12:02 --> Router Class Initialized
INFO - 2020-02-15 14:12:02 --> Output Class Initialized
INFO - 2020-02-15 14:12:02 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:02 --> Input Class Initialized
INFO - 2020-02-15 14:12:02 --> Language Class Initialized
INFO - 2020-02-15 14:12:02 --> Loader Class Initialized
INFO - 2020-02-15 14:12:02 --> Helper loaded: url_helper
INFO - 2020-02-15 14:12:02 --> Helper loaded: string_helper
INFO - 2020-02-15 14:12:02 --> Database Driver Class Initialized
DEBUG - 2020-02-15 14:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:12:02 --> Controller Class Initialized
INFO - 2020-02-15 14:12:02 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:12:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:12:02 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:12:02 --> Helper loaded: form_helper
INFO - 2020-02-15 14:12:02 --> Form Validation Class Initialized
INFO - 2020-02-15 14:12:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:12:02 --> Final output sent to browser
INFO - 2020-02-15 14:12:02 --> Config Class Initialized
INFO - 2020-02-15 14:12:02 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:02 --> Total execution time: 0.9541
INFO - 2020-02-15 14:12:02 --> Config Class Initialized
INFO - 2020-02-15 14:12:02 --> Config Class Initialized
INFO - 2020-02-15 14:12:02 --> Config Class Initialized
INFO - 2020-02-15 14:12:02 --> Hooks Class Initialized
INFO - 2020-02-15 14:12:02 --> Hooks Class Initialized
INFO - 2020-02-15 14:12:02 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:02 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:02 --> Config Class Initialized
INFO - 2020-02-15 14:12:02 --> Config Class Initialized
INFO - 2020-02-15 14:12:02 --> Hooks Class Initialized
INFO - 2020-02-15 14:12:02 --> Utf8 Class Initialized
DEBUG - 2020-02-15 14:12:03 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:03 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:12:03 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:03 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:03 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:03 --> Utf8 Class Initialized
DEBUG - 2020-02-15 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:12:03 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:03 --> URI Class Initialized
INFO - 2020-02-15 14:12:03 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:03 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:03 --> URI Class Initialized
INFO - 2020-02-15 14:12:03 --> Router Class Initialized
INFO - 2020-02-15 14:12:03 --> URI Class Initialized
INFO - 2020-02-15 14:12:03 --> URI Class Initialized
INFO - 2020-02-15 14:12:03 --> URI Class Initialized
INFO - 2020-02-15 14:12:03 --> Router Class Initialized
INFO - 2020-02-15 14:12:03 --> Output Class Initialized
INFO - 2020-02-15 14:12:03 --> Router Class Initialized
INFO - 2020-02-15 14:12:03 --> Router Class Initialized
INFO - 2020-02-15 14:12:03 --> URI Class Initialized
INFO - 2020-02-15 14:12:03 --> Router Class Initialized
INFO - 2020-02-15 14:12:03 --> Router Class Initialized
INFO - 2020-02-15 14:12:03 --> Output Class Initialized
INFO - 2020-02-15 14:12:03 --> Output Class Initialized
INFO - 2020-02-15 14:12:03 --> Output Class Initialized
INFO - 2020-02-15 14:12:03 --> Security Class Initialized
INFO - 2020-02-15 14:12:03 --> Output Class Initialized
INFO - 2020-02-15 14:12:03 --> Output Class Initialized
INFO - 2020-02-15 14:12:03 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:03 --> Security Class Initialized
INFO - 2020-02-15 14:12:03 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:03 --> Security Class Initialized
INFO - 2020-02-15 14:12:03 --> Input Class Initialized
INFO - 2020-02-15 14:12:03 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 14:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:03 --> Input Class Initialized
INFO - 2020-02-15 14:12:03 --> Input Class Initialized
INFO - 2020-02-15 14:12:03 --> Language Class Initialized
INFO - 2020-02-15 14:12:03 --> Input Class Initialized
DEBUG - 2020-02-15 14:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 14:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:03 --> Input Class Initialized
INFO - 2020-02-15 14:12:03 --> Language Class Initialized
INFO - 2020-02-15 14:12:03 --> Input Class Initialized
INFO - 2020-02-15 14:12:03 --> Language Class Initialized
INFO - 2020-02-15 14:12:03 --> Language Class Initialized
INFO - 2020-02-15 14:12:03 --> Loader Class Initialized
INFO - 2020-02-15 14:12:03 --> Language Class Initialized
ERROR - 2020-02-15 14:12:03 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-15 14:12:03 --> Language Class Initialized
INFO - 2020-02-15 14:12:03 --> Loader Class Initialized
ERROR - 2020-02-15 14:12:03 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-15 14:12:03 --> Helper loaded: url_helper
INFO - 2020-02-15 14:12:03 --> Helper loaded: string_helper
ERROR - 2020-02-15 14:12:03 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 14:12:03 --> Helper loaded: url_helper
ERROR - 2020-02-15 14:12:03 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 14:12:03 --> Config Class Initialized
INFO - 2020-02-15 14:12:03 --> Config Class Initialized
INFO - 2020-02-15 14:12:03 --> Hooks Class Initialized
INFO - 2020-02-15 14:12:03 --> Hooks Class Initialized
INFO - 2020-02-15 14:12:03 --> Helper loaded: string_helper
INFO - 2020-02-15 14:12:03 --> Database Driver Class Initialized
INFO - 2020-02-15 14:12:03 --> Config Class Initialized
INFO - 2020-02-15 14:12:03 --> Config Class Initialized
INFO - 2020-02-15 14:12:03 --> Hooks Class Initialized
INFO - 2020-02-15 14:12:03 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:12:03 --> Database Driver Class Initialized
INFO - 2020-02-15 14:12:03 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-15 14:12:03 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:03 --> Utf8 Class Initialized
DEBUG - 2020-02-15 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-15 14:12:03 --> Controller Class Initialized
INFO - 2020-02-15 14:12:03 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:03 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:03 --> URI Class Initialized
INFO - 2020-02-15 14:12:03 --> URI Class Initialized
INFO - 2020-02-15 14:12:03 --> URI Class Initialized
INFO - 2020-02-15 14:12:03 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:12:03 --> Router Class Initialized
INFO - 2020-02-15 14:12:03 --> Router Class Initialized
INFO - 2020-02-15 14:12:03 --> URI Class Initialized
INFO - 2020-02-15 14:12:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:12:03 --> Output Class Initialized
INFO - 2020-02-15 14:12:03 --> Output Class Initialized
INFO - 2020-02-15 14:12:03 --> Router Class Initialized
INFO - 2020-02-15 14:12:03 --> Router Class Initialized
INFO - 2020-02-15 14:12:03 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:12:03 --> Security Class Initialized
INFO - 2020-02-15 14:12:03 --> Security Class Initialized
INFO - 2020-02-15 14:12:03 --> Output Class Initialized
INFO - 2020-02-15 14:12:03 --> Output Class Initialized
DEBUG - 2020-02-15 14:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:03 --> Security Class Initialized
INFO - 2020-02-15 14:12:03 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:03 --> Helper loaded: form_helper
INFO - 2020-02-15 14:12:03 --> Input Class Initialized
INFO - 2020-02-15 14:12:03 --> Form Validation Class Initialized
INFO - 2020-02-15 14:12:03 --> Input Class Initialized
DEBUG - 2020-02-15 14:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 14:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:03 --> Input Class Initialized
INFO - 2020-02-15 14:12:03 --> Input Class Initialized
INFO - 2020-02-15 14:12:03 --> Language Class Initialized
INFO - 2020-02-15 14:12:03 --> Language Class Initialized
ERROR - 2020-02-15 14:12:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-15 14:12:03 --> Language Class Initialized
ERROR - 2020-02-15 14:12:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 14:12:03 --> Language Class Initialized
ERROR - 2020-02-15 14:12:03 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-15 14:12:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 14:12:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-15 14:12:03 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-15 14:12:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 14:12:03 --> Config Class Initialized
INFO - 2020-02-15 14:12:03 --> Config Class Initialized
INFO - 2020-02-15 14:12:03 --> Hooks Class Initialized
INFO - 2020-02-15 14:12:03 --> Hooks Class Initialized
INFO - 2020-02-15 14:12:03 --> Final output sent to browser
INFO - 2020-02-15 14:12:03 --> Config Class Initialized
INFO - 2020-02-15 14:12:03 --> Config Class Initialized
INFO - 2020-02-15 14:12:03 --> Hooks Class Initialized
INFO - 2020-02-15 14:12:03 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:03 --> Total execution time: 0.9971
DEBUG - 2020-02-15 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:12:03 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:03 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-15 14:12:03 --> Utf8 Class Initialized
DEBUG - 2020-02-15 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-15 14:12:03 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:04 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:04 --> Controller Class Initialized
INFO - 2020-02-15 14:12:04 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:04 --> URI Class Initialized
INFO - 2020-02-15 14:12:04 --> URI Class Initialized
INFO - 2020-02-15 14:12:04 --> Model "M_tiket" initialized
INFO - 2020-02-15 14:12:04 --> URI Class Initialized
INFO - 2020-02-15 14:12:04 --> Router Class Initialized
INFO - 2020-02-15 14:12:04 --> Router Class Initialized
INFO - 2020-02-15 14:12:04 --> URI Class Initialized
INFO - 2020-02-15 14:12:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-15 14:12:04 --> Router Class Initialized
INFO - 2020-02-15 14:12:04 --> Router Class Initialized
INFO - 2020-02-15 14:12:04 --> Output Class Initialized
INFO - 2020-02-15 14:12:04 --> Output Class Initialized
INFO - 2020-02-15 14:12:04 --> Model "M_pesan" initialized
INFO - 2020-02-15 14:12:04 --> Security Class Initialized
INFO - 2020-02-15 14:12:04 --> Security Class Initialized
INFO - 2020-02-15 14:12:04 --> Output Class Initialized
INFO - 2020-02-15 14:12:04 --> Output Class Initialized
DEBUG - 2020-02-15 14:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:04 --> Security Class Initialized
INFO - 2020-02-15 14:12:04 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:04 --> Helper loaded: form_helper
INFO - 2020-02-15 14:12:04 --> Form Validation Class Initialized
INFO - 2020-02-15 14:12:04 --> Input Class Initialized
INFO - 2020-02-15 14:12:04 --> Input Class Initialized
DEBUG - 2020-02-15 14:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-15 14:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:04 --> Input Class Initialized
INFO - 2020-02-15 14:12:04 --> Input Class Initialized
INFO - 2020-02-15 14:12:04 --> Language Class Initialized
INFO - 2020-02-15 14:12:04 --> Language Class Initialized
ERROR - 2020-02-15 14:12:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-15 14:12:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-15 14:12:04 --> Language Class Initialized
ERROR - 2020-02-15 14:12:04 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-15 14:12:04 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 14:12:04 --> Language Class Initialized
ERROR - 2020-02-15 14:12:04 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-15 14:12:04 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-15 14:12:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-15 14:12:04 --> Final output sent to browser
INFO - 2020-02-15 14:12:04 --> Config Class Initialized
INFO - 2020-02-15 14:12:04 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:04 --> Total execution time: 1.4140
DEBUG - 2020-02-15 14:12:04 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:04 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:04 --> URI Class Initialized
INFO - 2020-02-15 14:12:04 --> Router Class Initialized
INFO - 2020-02-15 14:12:04 --> Output Class Initialized
INFO - 2020-02-15 14:12:04 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:04 --> Input Class Initialized
INFO - 2020-02-15 14:12:04 --> Language Class Initialized
ERROR - 2020-02-15 14:12:04 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-15 14:12:04 --> Config Class Initialized
INFO - 2020-02-15 14:12:04 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:04 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:04 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:04 --> URI Class Initialized
INFO - 2020-02-15 14:12:04 --> Router Class Initialized
INFO - 2020-02-15 14:12:04 --> Output Class Initialized
INFO - 2020-02-15 14:12:05 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:05 --> Input Class Initialized
INFO - 2020-02-15 14:12:05 --> Language Class Initialized
ERROR - 2020-02-15 14:12:05 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-15 14:12:05 --> Config Class Initialized
INFO - 2020-02-15 14:12:05 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:05 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:05 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:05 --> URI Class Initialized
INFO - 2020-02-15 14:12:05 --> Router Class Initialized
INFO - 2020-02-15 14:12:05 --> Output Class Initialized
INFO - 2020-02-15 14:12:05 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:05 --> Input Class Initialized
INFO - 2020-02-15 14:12:05 --> Language Class Initialized
ERROR - 2020-02-15 14:12:05 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-15 14:12:05 --> Config Class Initialized
INFO - 2020-02-15 14:12:05 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:05 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:05 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:05 --> URI Class Initialized
INFO - 2020-02-15 14:12:05 --> Router Class Initialized
INFO - 2020-02-15 14:12:05 --> Output Class Initialized
INFO - 2020-02-15 14:12:05 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:05 --> Input Class Initialized
INFO - 2020-02-15 14:12:05 --> Language Class Initialized
ERROR - 2020-02-15 14:12:05 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 14:12:06 --> Config Class Initialized
INFO - 2020-02-15 14:12:06 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:06 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:06 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:06 --> URI Class Initialized
INFO - 2020-02-15 14:12:06 --> Router Class Initialized
INFO - 2020-02-15 14:12:06 --> Output Class Initialized
INFO - 2020-02-15 14:12:06 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:06 --> Input Class Initialized
INFO - 2020-02-15 14:12:06 --> Language Class Initialized
ERROR - 2020-02-15 14:12:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-15 14:12:06 --> Config Class Initialized
INFO - 2020-02-15 14:12:06 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:06 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:06 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:06 --> URI Class Initialized
INFO - 2020-02-15 14:12:06 --> Router Class Initialized
INFO - 2020-02-15 14:12:06 --> Output Class Initialized
INFO - 2020-02-15 14:12:06 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:06 --> Input Class Initialized
INFO - 2020-02-15 14:12:06 --> Language Class Initialized
ERROR - 2020-02-15 14:12:06 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-15 14:12:06 --> Config Class Initialized
INFO - 2020-02-15 14:12:06 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:06 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:06 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:06 --> URI Class Initialized
INFO - 2020-02-15 14:12:07 --> Router Class Initialized
INFO - 2020-02-15 14:12:07 --> Output Class Initialized
INFO - 2020-02-15 14:12:07 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:07 --> Input Class Initialized
INFO - 2020-02-15 14:12:07 --> Language Class Initialized
ERROR - 2020-02-15 14:12:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-15 14:12:07 --> Config Class Initialized
INFO - 2020-02-15 14:12:07 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:07 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:07 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:07 --> URI Class Initialized
INFO - 2020-02-15 14:12:07 --> Router Class Initialized
INFO - 2020-02-15 14:12:07 --> Output Class Initialized
INFO - 2020-02-15 14:12:07 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:07 --> Input Class Initialized
INFO - 2020-02-15 14:12:07 --> Language Class Initialized
ERROR - 2020-02-15 14:12:07 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-15 14:12:07 --> Config Class Initialized
INFO - 2020-02-15 14:12:07 --> Hooks Class Initialized
DEBUG - 2020-02-15 14:12:07 --> UTF-8 Support Enabled
INFO - 2020-02-15 14:12:07 --> Utf8 Class Initialized
INFO - 2020-02-15 14:12:07 --> URI Class Initialized
INFO - 2020-02-15 14:12:07 --> Router Class Initialized
INFO - 2020-02-15 14:12:07 --> Output Class Initialized
INFO - 2020-02-15 14:12:07 --> Security Class Initialized
DEBUG - 2020-02-15 14:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-15 14:12:07 --> Input Class Initialized
INFO - 2020-02-15 14:12:07 --> Language Class Initialized
ERROR - 2020-02-15 14:12:08 --> 404 Page Not Found: Bower_components/jquery-i18next
