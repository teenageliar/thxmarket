<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-26 00:47:43 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `id_pengunjung`) VALUES ('33', '100000', '1', '1', '20-02-26 12:47:43', '2020-02-27 12:47:43', NULL, 'PM144', NULL, NULL)
INFO - 2020-02-26 00:47:43 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-26 00:48:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 00:48:07 --> Final output sent to browser
DEBUG - 2020-02-26 00:48:07 --> Total execution time: 0.5883
ERROR - 2020-02-26 00:48:26 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `id_pengunjung`) VALUES ('34', '', '1', '1', '20-02-26 12:48:26', '2020-02-27 12:48:26', NULL, 'PM145', NULL, NULL)
INFO - 2020-02-26 00:48:26 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-26 00:48:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 00:48:51 --> Final output sent to browser
DEBUG - 2020-02-26 00:48:51 --> Total execution time: 0.5783
INFO - 2020-02-26 01:23:40 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 01:23:40 --> Final output sent to browser
DEBUG - 2020-02-26 01:23:40 --> Total execution time: 1.3961
INFO - 2020-02-26 01:24:38 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 01:24:38 --> Final output sent to browser
DEBUG - 2020-02-26 01:24:38 --> Total execution time: 1.0708
INFO - 2020-02-26 08:27:44 --> Config Class Initialized
INFO - 2020-02-26 08:27:45 --> Hooks Class Initialized
DEBUG - 2020-02-26 08:27:45 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:27:45 --> Utf8 Class Initialized
INFO - 2020-02-26 08:27:45 --> URI Class Initialized
INFO - 2020-02-26 08:27:45 --> Router Class Initialized
INFO - 2020-02-26 08:27:45 --> Output Class Initialized
INFO - 2020-02-26 08:27:45 --> Security Class Initialized
DEBUG - 2020-02-26 08:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:27:45 --> Input Class Initialized
INFO - 2020-02-26 08:27:45 --> Language Class Initialized
INFO - 2020-02-26 08:27:45 --> Loader Class Initialized
INFO - 2020-02-26 08:27:45 --> Helper loaded: url_helper
INFO - 2020-02-26 08:27:45 --> Helper loaded: string_helper
INFO - 2020-02-26 08:27:46 --> Database Driver Class Initialized
DEBUG - 2020-02-26 08:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 08:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 08:27:46 --> Controller Class Initialized
INFO - 2020-02-26 08:27:46 --> Model "M_tiket" initialized
INFO - 2020-02-26 08:27:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 08:27:46 --> Model "M_pesan" initialized
INFO - 2020-02-26 08:27:46 --> Helper loaded: form_helper
INFO - 2020-02-26 08:27:46 --> Form Validation Class Initialized
ERROR - 2020-02-26 08:27:46 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow-2\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 28
INFO - 2020-02-26 08:27:54 --> Config Class Initialized
INFO - 2020-02-26 08:27:54 --> Hooks Class Initialized
DEBUG - 2020-02-26 08:27:54 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:27:54 --> Utf8 Class Initialized
INFO - 2020-02-26 08:27:54 --> URI Class Initialized
INFO - 2020-02-26 08:27:54 --> Router Class Initialized
INFO - 2020-02-26 08:27:54 --> Output Class Initialized
INFO - 2020-02-26 08:27:54 --> Security Class Initialized
DEBUG - 2020-02-26 08:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:27:54 --> Input Class Initialized
INFO - 2020-02-26 08:27:54 --> Language Class Initialized
INFO - 2020-02-26 08:27:54 --> Loader Class Initialized
INFO - 2020-02-26 08:27:54 --> Helper loaded: url_helper
INFO - 2020-02-26 08:27:54 --> Helper loaded: string_helper
INFO - 2020-02-26 08:27:54 --> Database Driver Class Initialized
DEBUG - 2020-02-26 08:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 08:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 08:27:54 --> Controller Class Initialized
INFO - 2020-02-26 08:27:54 --> Model "M_tiket" initialized
INFO - 2020-02-26 08:27:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 08:27:54 --> Model "M_pesan" initialized
INFO - 2020-02-26 08:27:54 --> Helper loaded: form_helper
INFO - 2020-02-26 08:27:54 --> Form Validation Class Initialized
INFO - 2020-02-26 08:27:55 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 08:27:55 --> Final output sent to browser
DEBUG - 2020-02-26 08:27:55 --> Total execution time: 0.7507
INFO - 2020-02-26 08:27:55 --> Config Class Initialized
INFO - 2020-02-26 08:27:55 --> Hooks Class Initialized
DEBUG - 2020-02-26 08:27:55 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:27:55 --> Utf8 Class Initialized
INFO - 2020-02-26 08:27:55 --> URI Class Initialized
INFO - 2020-02-26 08:27:55 --> Router Class Initialized
INFO - 2020-02-26 08:27:55 --> Output Class Initialized
INFO - 2020-02-26 08:27:55 --> Security Class Initialized
DEBUG - 2020-02-26 08:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:27:55 --> Input Class Initialized
INFO - 2020-02-26 08:27:55 --> Language Class Initialized
ERROR - 2020-02-26 08:27:55 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-26 08:27:56 --> Config Class Initialized
INFO - 2020-02-26 08:27:56 --> Config Class Initialized
INFO - 2020-02-26 08:27:56 --> Hooks Class Initialized
INFO - 2020-02-26 08:27:56 --> Hooks Class Initialized
DEBUG - 2020-02-26 08:27:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 08:27:56 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:27:56 --> Utf8 Class Initialized
INFO - 2020-02-26 08:27:56 --> Utf8 Class Initialized
INFO - 2020-02-26 08:27:56 --> URI Class Initialized
INFO - 2020-02-26 08:27:56 --> URI Class Initialized
INFO - 2020-02-26 08:27:56 --> Router Class Initialized
INFO - 2020-02-26 08:27:56 --> Router Class Initialized
INFO - 2020-02-26 08:27:56 --> Output Class Initialized
INFO - 2020-02-26 08:27:56 --> Output Class Initialized
INFO - 2020-02-26 08:27:56 --> Security Class Initialized
INFO - 2020-02-26 08:27:56 --> Security Class Initialized
DEBUG - 2020-02-26 08:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 08:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:27:56 --> Input Class Initialized
INFO - 2020-02-26 08:27:56 --> Input Class Initialized
INFO - 2020-02-26 08:27:56 --> Language Class Initialized
INFO - 2020-02-26 08:27:56 --> Language Class Initialized
INFO - 2020-02-26 08:27:56 --> Loader Class Initialized
INFO - 2020-02-26 08:27:56 --> Loader Class Initialized
INFO - 2020-02-26 08:27:56 --> Helper loaded: url_helper
INFO - 2020-02-26 08:27:56 --> Helper loaded: url_helper
INFO - 2020-02-26 08:27:56 --> Helper loaded: string_helper
INFO - 2020-02-26 08:27:56 --> Helper loaded: string_helper
INFO - 2020-02-26 08:27:56 --> Database Driver Class Initialized
INFO - 2020-02-26 08:27:56 --> Database Driver Class Initialized
DEBUG - 2020-02-26 08:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 08:27:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-26 08:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 08:27:56 --> Controller Class Initialized
INFO - 2020-02-26 08:27:56 --> Model "M_tiket" initialized
INFO - 2020-02-26 08:27:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 08:27:56 --> Model "M_pesan" initialized
INFO - 2020-02-26 08:27:56 --> Helper loaded: form_helper
INFO - 2020-02-26 08:27:56 --> Form Validation Class Initialized
ERROR - 2020-02-26 08:27:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 08:27:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 08:27:56 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 08:27:56 --> Final output sent to browser
DEBUG - 2020-02-26 08:27:56 --> Total execution time: 0.8048
INFO - 2020-02-26 08:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 08:27:56 --> Controller Class Initialized
INFO - 2020-02-26 08:27:56 --> Model "M_tiket" initialized
INFO - 2020-02-26 08:27:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 08:27:57 --> Model "M_pesan" initialized
INFO - 2020-02-26 08:27:57 --> Helper loaded: form_helper
INFO - 2020-02-26 08:27:57 --> Form Validation Class Initialized
ERROR - 2020-02-26 08:27:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 08:27:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 08:27:57 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 08:27:57 --> Final output sent to browser
DEBUG - 2020-02-26 08:27:57 --> Total execution time: 1.1622
INFO - 2020-02-26 08:27:58 --> Config Class Initialized
INFO - 2020-02-26 08:27:58 --> Hooks Class Initialized
DEBUG - 2020-02-26 08:27:58 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:27:58 --> Utf8 Class Initialized
INFO - 2020-02-26 08:27:58 --> URI Class Initialized
DEBUG - 2020-02-26 08:27:58 --> No URI present. Default controller set.
INFO - 2020-02-26 08:27:58 --> Router Class Initialized
INFO - 2020-02-26 08:27:58 --> Output Class Initialized
INFO - 2020-02-26 08:27:59 --> Security Class Initialized
DEBUG - 2020-02-26 08:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:27:59 --> Input Class Initialized
INFO - 2020-02-26 08:27:59 --> Language Class Initialized
INFO - 2020-02-26 08:27:59 --> Loader Class Initialized
INFO - 2020-02-26 08:27:59 --> Helper loaded: url_helper
INFO - 2020-02-26 08:27:59 --> Helper loaded: string_helper
INFO - 2020-02-26 08:27:59 --> Database Driver Class Initialized
DEBUG - 2020-02-26 08:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 08:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 08:27:59 --> Controller Class Initialized
INFO - 2020-02-26 08:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 08:27:59 --> Pagination Class Initialized
INFO - 2020-02-26 08:28:00 --> Model "M_show" initialized
INFO - 2020-02-26 08:28:00 --> Helper loaded: form_helper
INFO - 2020-02-26 08:28:00 --> Form Validation Class Initialized
INFO - 2020-02-26 08:28:00 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 08:28:00 --> Final output sent to browser
DEBUG - 2020-02-26 08:28:00 --> Total execution time: 1.8897
INFO - 2020-02-26 08:28:06 --> Config Class Initialized
INFO - 2020-02-26 08:28:06 --> Hooks Class Initialized
DEBUG - 2020-02-26 08:28:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:28:07 --> Utf8 Class Initialized
INFO - 2020-02-26 08:28:07 --> URI Class Initialized
INFO - 2020-02-26 08:28:07 --> Router Class Initialized
INFO - 2020-02-26 08:28:07 --> Output Class Initialized
INFO - 2020-02-26 08:28:07 --> Security Class Initialized
DEBUG - 2020-02-26 08:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:28:07 --> Input Class Initialized
INFO - 2020-02-26 08:28:07 --> Language Class Initialized
ERROR - 2020-02-26 08:28:07 --> 404 Page Not Found: Tiket/bayar_nanti
INFO - 2020-02-26 08:28:15 --> Config Class Initialized
INFO - 2020-02-26 08:28:15 --> Hooks Class Initialized
DEBUG - 2020-02-26 08:28:15 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:28:15 --> Utf8 Class Initialized
INFO - 2020-02-26 08:28:15 --> URI Class Initialized
DEBUG - 2020-02-26 08:28:15 --> No URI present. Default controller set.
INFO - 2020-02-26 08:28:15 --> Router Class Initialized
INFO - 2020-02-26 08:28:15 --> Output Class Initialized
INFO - 2020-02-26 08:28:16 --> Security Class Initialized
DEBUG - 2020-02-26 08:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:28:16 --> Input Class Initialized
INFO - 2020-02-26 08:28:16 --> Language Class Initialized
INFO - 2020-02-26 08:28:16 --> Loader Class Initialized
INFO - 2020-02-26 08:28:16 --> Helper loaded: url_helper
INFO - 2020-02-26 08:28:16 --> Helper loaded: string_helper
INFO - 2020-02-26 08:28:16 --> Database Driver Class Initialized
DEBUG - 2020-02-26 08:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 08:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 08:28:16 --> Controller Class Initialized
INFO - 2020-02-26 08:28:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 08:28:16 --> Pagination Class Initialized
INFO - 2020-02-26 08:28:16 --> Model "M_show" initialized
INFO - 2020-02-26 08:28:16 --> Helper loaded: form_helper
INFO - 2020-02-26 08:28:16 --> Form Validation Class Initialized
INFO - 2020-02-26 08:28:16 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 08:28:16 --> Final output sent to browser
DEBUG - 2020-02-26 08:28:16 --> Total execution time: 1.3254
INFO - 2020-02-26 08:33:04 --> Config Class Initialized
INFO - 2020-02-26 08:33:04 --> Hooks Class Initialized
DEBUG - 2020-02-26 08:33:04 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:33:04 --> Utf8 Class Initialized
INFO - 2020-02-26 08:33:04 --> URI Class Initialized
INFO - 2020-02-26 08:33:04 --> Router Class Initialized
INFO - 2020-02-26 08:33:04 --> Output Class Initialized
INFO - 2020-02-26 08:33:04 --> Security Class Initialized
DEBUG - 2020-02-26 08:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:33:04 --> Input Class Initialized
INFO - 2020-02-26 08:33:04 --> Language Class Initialized
INFO - 2020-02-26 08:33:04 --> Loader Class Initialized
INFO - 2020-02-26 08:33:05 --> Helper loaded: url_helper
INFO - 2020-02-26 08:33:05 --> Helper loaded: string_helper
INFO - 2020-02-26 08:33:05 --> Database Driver Class Initialized
DEBUG - 2020-02-26 08:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 08:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 08:33:05 --> Controller Class Initialized
INFO - 2020-02-26 08:33:05 --> Model "M_tiket" initialized
INFO - 2020-02-26 08:33:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 08:33:05 --> Model "M_pesan" initialized
INFO - 2020-02-26 08:33:05 --> Helper loaded: form_helper
INFO - 2020-02-26 08:33:05 --> Form Validation Class Initialized
INFO - 2020-02-26 08:33:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 08:33:05 --> Final output sent to browser
DEBUG - 2020-02-26 08:33:05 --> Total execution time: 1.0794
INFO - 2020-02-26 08:33:05 --> Config Class Initialized
INFO - 2020-02-26 08:33:05 --> Config Class Initialized
INFO - 2020-02-26 08:33:05 --> Config Class Initialized
INFO - 2020-02-26 08:33:05 --> Hooks Class Initialized
INFO - 2020-02-26 08:33:05 --> Hooks Class Initialized
INFO - 2020-02-26 08:33:05 --> Hooks Class Initialized
INFO - 2020-02-26 08:33:05 --> Config Class Initialized
INFO - 2020-02-26 08:33:05 --> Config Class Initialized
INFO - 2020-02-26 08:33:05 --> Config Class Initialized
INFO - 2020-02-26 08:33:05 --> Hooks Class Initialized
INFO - 2020-02-26 08:33:05 --> Hooks Class Initialized
DEBUG - 2020-02-26 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 08:33:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:33:05 --> Hooks Class Initialized
INFO - 2020-02-26 08:33:05 --> Utf8 Class Initialized
INFO - 2020-02-26 08:33:05 --> Utf8 Class Initialized
INFO - 2020-02-26 08:33:05 --> Utf8 Class Initialized
DEBUG - 2020-02-26 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 08:33:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:33:05 --> Utf8 Class Initialized
INFO - 2020-02-26 08:33:05 --> Utf8 Class Initialized
INFO - 2020-02-26 08:33:05 --> Utf8 Class Initialized
INFO - 2020-02-26 08:33:06 --> URI Class Initialized
INFO - 2020-02-26 08:33:06 --> URI Class Initialized
INFO - 2020-02-26 08:33:06 --> URI Class Initialized
INFO - 2020-02-26 08:33:06 --> URI Class Initialized
INFO - 2020-02-26 08:33:06 --> Router Class Initialized
INFO - 2020-02-26 08:33:06 --> URI Class Initialized
INFO - 2020-02-26 08:33:06 --> URI Class Initialized
INFO - 2020-02-26 08:33:06 --> Router Class Initialized
INFO - 2020-02-26 08:33:06 --> Router Class Initialized
INFO - 2020-02-26 08:33:06 --> Router Class Initialized
INFO - 2020-02-26 08:33:06 --> Router Class Initialized
INFO - 2020-02-26 08:33:06 --> Output Class Initialized
INFO - 2020-02-26 08:33:06 --> Router Class Initialized
INFO - 2020-02-26 08:33:06 --> Output Class Initialized
INFO - 2020-02-26 08:33:06 --> Output Class Initialized
INFO - 2020-02-26 08:33:06 --> Security Class Initialized
INFO - 2020-02-26 08:33:06 --> Security Class Initialized
INFO - 2020-02-26 08:33:06 --> Security Class Initialized
INFO - 2020-02-26 08:33:06 --> Output Class Initialized
INFO - 2020-02-26 08:33:06 --> Output Class Initialized
INFO - 2020-02-26 08:33:06 --> Output Class Initialized
DEBUG - 2020-02-26 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:33:06 --> Security Class Initialized
INFO - 2020-02-26 08:33:06 --> Security Class Initialized
INFO - 2020-02-26 08:33:06 --> Security Class Initialized
DEBUG - 2020-02-26 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:33:06 --> Input Class Initialized
INFO - 2020-02-26 08:33:06 --> Input Class Initialized
INFO - 2020-02-26 08:33:06 --> Input Class Initialized
DEBUG - 2020-02-26 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:33:06 --> Input Class Initialized
INFO - 2020-02-26 08:33:06 --> Input Class Initialized
INFO - 2020-02-26 08:33:06 --> Input Class Initialized
INFO - 2020-02-26 08:33:06 --> Language Class Initialized
INFO - 2020-02-26 08:33:06 --> Language Class Initialized
INFO - 2020-02-26 08:33:06 --> Language Class Initialized
INFO - 2020-02-26 08:33:06 --> Language Class Initialized
INFO - 2020-02-26 08:33:06 --> Language Class Initialized
ERROR - 2020-02-26 08:33:06 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-26 08:33:06 --> Language Class Initialized
INFO - 2020-02-26 08:33:06 --> Loader Class Initialized
INFO - 2020-02-26 08:33:06 --> Loader Class Initialized
ERROR - 2020-02-26 08:33:06 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 08:33:06 --> Helper loaded: url_helper
ERROR - 2020-02-26 08:33:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 08:33:06 --> Helper loaded: url_helper
ERROR - 2020-02-26 08:33:06 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 08:33:06 --> Config Class Initialized
INFO - 2020-02-26 08:33:06 --> Hooks Class Initialized
INFO - 2020-02-26 08:33:06 --> Helper loaded: string_helper
INFO - 2020-02-26 08:33:06 --> Helper loaded: string_helper
INFO - 2020-02-26 08:33:06 --> Config Class Initialized
INFO - 2020-02-26 08:33:06 --> Config Class Initialized
INFO - 2020-02-26 08:33:06 --> Config Class Initialized
INFO - 2020-02-26 08:33:06 --> Hooks Class Initialized
INFO - 2020-02-26 08:33:06 --> Hooks Class Initialized
DEBUG - 2020-02-26 08:33:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:33:06 --> Database Driver Class Initialized
INFO - 2020-02-26 08:33:06 --> Database Driver Class Initialized
INFO - 2020-02-26 08:33:06 --> Hooks Class Initialized
INFO - 2020-02-26 08:33:06 --> Utf8 Class Initialized
DEBUG - 2020-02-26 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-26 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 08:33:06 --> Utf8 Class Initialized
INFO - 2020-02-26 08:33:06 --> Utf8 Class Initialized
INFO - 2020-02-26 08:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 08:33:06 --> URI Class Initialized
DEBUG - 2020-02-26 08:33:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:33:06 --> Utf8 Class Initialized
INFO - 2020-02-26 08:33:06 --> Controller Class Initialized
INFO - 2020-02-26 08:33:06 --> URI Class Initialized
INFO - 2020-02-26 08:33:06 --> URI Class Initialized
INFO - 2020-02-26 08:33:06 --> Router Class Initialized
INFO - 2020-02-26 08:33:06 --> Model "M_tiket" initialized
INFO - 2020-02-26 08:33:06 --> Router Class Initialized
INFO - 2020-02-26 08:33:06 --> URI Class Initialized
INFO - 2020-02-26 08:33:06 --> Router Class Initialized
INFO - 2020-02-26 08:33:06 --> Output Class Initialized
INFO - 2020-02-26 08:33:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 08:33:06 --> Security Class Initialized
INFO - 2020-02-26 08:33:06 --> Output Class Initialized
INFO - 2020-02-26 08:33:06 --> Output Class Initialized
INFO - 2020-02-26 08:33:06 --> Router Class Initialized
INFO - 2020-02-26 08:33:06 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:33:06 --> Security Class Initialized
INFO - 2020-02-26 08:33:06 --> Security Class Initialized
INFO - 2020-02-26 08:33:06 --> Output Class Initialized
INFO - 2020-02-26 08:33:06 --> Input Class Initialized
DEBUG - 2020-02-26 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:33:06 --> Security Class Initialized
INFO - 2020-02-26 08:33:06 --> Helper loaded: form_helper
INFO - 2020-02-26 08:33:06 --> Form Validation Class Initialized
INFO - 2020-02-26 08:33:06 --> Input Class Initialized
INFO - 2020-02-26 08:33:06 --> Language Class Initialized
INFO - 2020-02-26 08:33:06 --> Input Class Initialized
DEBUG - 2020-02-26 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:33:06 --> Input Class Initialized
INFO - 2020-02-26 08:33:06 --> Language Class Initialized
INFO - 2020-02-26 08:33:06 --> Language Class Initialized
ERROR - 2020-02-26 08:33:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 08:33:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 08:33:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 08:33:06 --> Language Class Initialized
ERROR - 2020-02-26 08:33:06 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 08:33:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 08:33:06 --> Config Class Initialized
INFO - 2020-02-26 08:33:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-26 08:33:06 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 08:33:06 --> Config Class Initialized
INFO - 2020-02-26 08:33:06 --> Config Class Initialized
INFO - 2020-02-26 08:33:06 --> Hooks Class Initialized
INFO - 2020-02-26 08:33:06 --> Hooks Class Initialized
INFO - 2020-02-26 08:33:06 --> Final output sent to browser
INFO - 2020-02-26 08:33:06 --> Hooks Class Initialized
DEBUG - 2020-02-26 08:33:06 --> Total execution time: 0.6813
DEBUG - 2020-02-26 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 08:33:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:33:06 --> Utf8 Class Initialized
INFO - 2020-02-26 08:33:06 --> Utf8 Class Initialized
INFO - 2020-02-26 08:33:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-26 08:33:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:33:06 --> Utf8 Class Initialized
INFO - 2020-02-26 08:33:06 --> Controller Class Initialized
INFO - 2020-02-26 08:33:06 --> URI Class Initialized
INFO - 2020-02-26 08:33:06 --> URI Class Initialized
INFO - 2020-02-26 08:33:06 --> Model "M_tiket" initialized
INFO - 2020-02-26 08:33:06 --> URI Class Initialized
INFO - 2020-02-26 08:33:06 --> Router Class Initialized
INFO - 2020-02-26 08:33:06 --> Router Class Initialized
INFO - 2020-02-26 08:33:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 08:33:06 --> Router Class Initialized
INFO - 2020-02-26 08:33:06 --> Output Class Initialized
INFO - 2020-02-26 08:33:06 --> Output Class Initialized
INFO - 2020-02-26 08:33:06 --> Model "M_pesan" initialized
INFO - 2020-02-26 08:33:06 --> Security Class Initialized
INFO - 2020-02-26 08:33:06 --> Output Class Initialized
INFO - 2020-02-26 08:33:06 --> Security Class Initialized
DEBUG - 2020-02-26 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:33:06 --> Security Class Initialized
INFO - 2020-02-26 08:33:06 --> Helper loaded: form_helper
INFO - 2020-02-26 08:33:06 --> Form Validation Class Initialized
INFO - 2020-02-26 08:33:06 --> Input Class Initialized
INFO - 2020-02-26 08:33:06 --> Input Class Initialized
DEBUG - 2020-02-26 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:33:06 --> Input Class Initialized
INFO - 2020-02-26 08:33:06 --> Language Class Initialized
INFO - 2020-02-26 08:33:06 --> Language Class Initialized
ERROR - 2020-02-26 08:33:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 08:33:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 08:33:06 --> Language Class Initialized
ERROR - 2020-02-26 08:33:06 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-26 08:33:06 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 08:33:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-26 08:33:06 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 08:33:06 --> Final output sent to browser
DEBUG - 2020-02-26 08:33:06 --> Total execution time: 0.9271
INFO - 2020-02-26 08:33:44 --> Config Class Initialized
INFO - 2020-02-26 08:33:44 --> Hooks Class Initialized
DEBUG - 2020-02-26 08:33:44 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:33:44 --> Utf8 Class Initialized
INFO - 2020-02-26 08:33:44 --> URI Class Initialized
INFO - 2020-02-26 08:33:44 --> Router Class Initialized
INFO - 2020-02-26 08:33:44 --> Output Class Initialized
INFO - 2020-02-26 08:33:44 --> Security Class Initialized
DEBUG - 2020-02-26 08:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:33:45 --> Input Class Initialized
INFO - 2020-02-26 08:33:45 --> Language Class Initialized
INFO - 2020-02-26 08:33:45 --> Loader Class Initialized
INFO - 2020-02-26 08:33:45 --> Helper loaded: url_helper
INFO - 2020-02-26 08:33:45 --> Helper loaded: string_helper
INFO - 2020-02-26 08:33:45 --> Database Driver Class Initialized
DEBUG - 2020-02-26 08:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 08:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 08:33:45 --> Controller Class Initialized
INFO - 2020-02-26 08:33:45 --> Model "M_tiket" initialized
INFO - 2020-02-26 08:33:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 08:33:45 --> Model "M_pesan" initialized
INFO - 2020-02-26 08:33:46 --> Helper loaded: form_helper
INFO - 2020-02-26 08:33:46 --> Form Validation Class Initialized
INFO - 2020-02-26 14:33:46 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 14:33:46 --> Final output sent to browser
DEBUG - 2020-02-26 14:33:46 --> Total execution time: 1.9319
INFO - 2020-02-26 08:59:56 --> Config Class Initialized
INFO - 2020-02-26 08:59:56 --> Hooks Class Initialized
DEBUG - 2020-02-26 08:59:56 --> UTF-8 Support Enabled
INFO - 2020-02-26 08:59:56 --> Utf8 Class Initialized
INFO - 2020-02-26 08:59:56 --> URI Class Initialized
INFO - 2020-02-26 08:59:56 --> Router Class Initialized
INFO - 2020-02-26 08:59:56 --> Output Class Initialized
INFO - 2020-02-26 08:59:56 --> Security Class Initialized
DEBUG - 2020-02-26 08:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 08:59:56 --> Input Class Initialized
INFO - 2020-02-26 08:59:56 --> Language Class Initialized
INFO - 2020-02-26 08:59:56 --> Loader Class Initialized
INFO - 2020-02-26 08:59:57 --> Helper loaded: url_helper
INFO - 2020-02-26 08:59:57 --> Helper loaded: string_helper
INFO - 2020-02-26 08:59:57 --> Database Driver Class Initialized
DEBUG - 2020-02-26 08:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 08:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 08:59:57 --> Controller Class Initialized
INFO - 2020-02-26 08:59:57 --> Model "M_tiket" initialized
INFO - 2020-02-26 08:59:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 08:59:57 --> Model "M_pesan" initialized
INFO - 2020-02-26 08:59:57 --> Helper loaded: form_helper
INFO - 2020-02-26 08:59:57 --> Form Validation Class Initialized
ERROR - 2020-02-26 08:59:57 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 69
ERROR - 2020-02-26 08:59:57 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 70
ERROR - 2020-02-26 08:59:57 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 71
ERROR - 2020-02-26 08:59:57 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 72
ERROR - 2020-02-26 08:59:57 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 81
ERROR - 2020-02-26 08:59:57 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 82
ERROR - 2020-02-26 08:59:57 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 83
ERROR - 2020-02-26 08:59:57 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 84
ERROR - 2020-02-26 08:59:57 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pengunjung` (`nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2020-02-26 08:59:57 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-26 08:59:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow-2\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow-2\system\core\Common.php 570
INFO - 2020-02-26 09:00:08 --> Config Class Initialized
INFO - 2020-02-26 09:00:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:00:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:00:08 --> Utf8 Class Initialized
INFO - 2020-02-26 09:00:08 --> URI Class Initialized
INFO - 2020-02-26 09:00:08 --> Router Class Initialized
INFO - 2020-02-26 09:00:08 --> Output Class Initialized
INFO - 2020-02-26 09:00:08 --> Security Class Initialized
DEBUG - 2020-02-26 09:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:00:08 --> Input Class Initialized
INFO - 2020-02-26 09:00:08 --> Language Class Initialized
INFO - 2020-02-26 09:00:08 --> Loader Class Initialized
INFO - 2020-02-26 09:00:09 --> Helper loaded: url_helper
INFO - 2020-02-26 09:00:09 --> Helper loaded: string_helper
INFO - 2020-02-26 09:00:09 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:00:09 --> Controller Class Initialized
INFO - 2020-02-26 09:00:09 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:00:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:00:09 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:00:09 --> Helper loaded: form_helper
INFO - 2020-02-26 09:00:09 --> Form Validation Class Initialized
INFO - 2020-02-26 09:00:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:00:09 --> Final output sent to browser
DEBUG - 2020-02-26 09:00:09 --> Total execution time: 1.3689
INFO - 2020-02-26 09:00:09 --> Config Class Initialized
INFO - 2020-02-26 09:00:09 --> Config Class Initialized
INFO - 2020-02-26 09:00:09 --> Config Class Initialized
INFO - 2020-02-26 09:00:09 --> Hooks Class Initialized
INFO - 2020-02-26 09:00:09 --> Hooks Class Initialized
INFO - 2020-02-26 09:00:09 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:00:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:00:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:00:09 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:00:09 --> Utf8 Class Initialized
INFO - 2020-02-26 09:00:09 --> Utf8 Class Initialized
INFO - 2020-02-26 09:00:09 --> Utf8 Class Initialized
INFO - 2020-02-26 09:00:09 --> URI Class Initialized
INFO - 2020-02-26 09:00:09 --> URI Class Initialized
INFO - 2020-02-26 09:00:09 --> URI Class Initialized
INFO - 2020-02-26 09:00:09 --> Router Class Initialized
INFO - 2020-02-26 09:00:09 --> Router Class Initialized
INFO - 2020-02-26 09:00:09 --> Router Class Initialized
INFO - 2020-02-26 09:00:09 --> Output Class Initialized
INFO - 2020-02-26 09:00:09 --> Output Class Initialized
INFO - 2020-02-26 09:00:09 --> Output Class Initialized
INFO - 2020-02-26 09:00:09 --> Security Class Initialized
INFO - 2020-02-26 09:00:09 --> Security Class Initialized
INFO - 2020-02-26 09:00:09 --> Security Class Initialized
DEBUG - 2020-02-26 09:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:00:09 --> Input Class Initialized
INFO - 2020-02-26 09:00:09 --> Input Class Initialized
INFO - 2020-02-26 09:00:09 --> Input Class Initialized
INFO - 2020-02-26 09:00:09 --> Language Class Initialized
INFO - 2020-02-26 09:00:09 --> Language Class Initialized
INFO - 2020-02-26 09:00:09 --> Language Class Initialized
ERROR - 2020-02-26 09:00:09 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-26 09:00:09 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 09:00:09 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 09:00:22 --> Config Class Initialized
INFO - 2020-02-26 09:00:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:00:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:00:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:00:22 --> URI Class Initialized
INFO - 2020-02-26 09:00:22 --> Router Class Initialized
INFO - 2020-02-26 09:00:22 --> Output Class Initialized
INFO - 2020-02-26 09:00:22 --> Security Class Initialized
DEBUG - 2020-02-26 09:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:00:22 --> Input Class Initialized
INFO - 2020-02-26 09:00:22 --> Language Class Initialized
INFO - 2020-02-26 09:00:22 --> Loader Class Initialized
INFO - 2020-02-26 09:00:22 --> Helper loaded: url_helper
INFO - 2020-02-26 09:00:22 --> Helper loaded: string_helper
INFO - 2020-02-26 09:00:22 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:00:22 --> Controller Class Initialized
INFO - 2020-02-26 09:00:22 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:00:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:00:22 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:00:22 --> Helper loaded: form_helper
INFO - 2020-02-26 09:00:22 --> Form Validation Class Initialized
INFO - 2020-02-26 15:00:23 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 15:00:23 --> Final output sent to browser
DEBUG - 2020-02-26 15:00:23 --> Total execution time: 1.0333
INFO - 2020-02-26 09:00:27 --> Config Class Initialized
INFO - 2020-02-26 09:00:27 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:00:27 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:00:27 --> Utf8 Class Initialized
INFO - 2020-02-26 09:00:27 --> URI Class Initialized
INFO - 2020-02-26 09:00:27 --> Router Class Initialized
INFO - 2020-02-26 09:00:27 --> Output Class Initialized
INFO - 2020-02-26 09:00:27 --> Security Class Initialized
DEBUG - 2020-02-26 09:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:00:27 --> Input Class Initialized
INFO - 2020-02-26 09:00:27 --> Language Class Initialized
INFO - 2020-02-26 09:00:28 --> Loader Class Initialized
INFO - 2020-02-26 09:00:28 --> Helper loaded: url_helper
INFO - 2020-02-26 09:00:28 --> Helper loaded: string_helper
INFO - 2020-02-26 09:00:28 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:00:28 --> Controller Class Initialized
INFO - 2020-02-26 09:00:28 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:00:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:00:28 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:00:28 --> Helper loaded: form_helper
INFO - 2020-02-26 09:00:28 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:00:28 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 33
ERROR - 2020-02-26 09:00:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IS NULL' at line 3 - Invalid query: SELECT *
FROM `pemesanan`
WHERE  IS NULL
INFO - 2020-02-26 09:00:28 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-26 09:00:55 --> Config Class Initialized
INFO - 2020-02-26 09:00:55 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:00:55 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:00:55 --> Utf8 Class Initialized
INFO - 2020-02-26 09:00:55 --> URI Class Initialized
INFO - 2020-02-26 09:00:55 --> Router Class Initialized
INFO - 2020-02-26 09:00:55 --> Output Class Initialized
INFO - 2020-02-26 09:00:55 --> Security Class Initialized
DEBUG - 2020-02-26 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:00:55 --> Input Class Initialized
INFO - 2020-02-26 09:00:55 --> Language Class Initialized
INFO - 2020-02-26 09:00:55 --> Loader Class Initialized
INFO - 2020-02-26 09:00:55 --> Helper loaded: url_helper
INFO - 2020-02-26 09:00:55 --> Helper loaded: string_helper
INFO - 2020-02-26 09:00:55 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:00:55 --> Controller Class Initialized
INFO - 2020-02-26 09:00:55 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:00:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:00:55 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:00:55 --> Helper loaded: form_helper
INFO - 2020-02-26 09:00:55 --> Form Validation Class Initialized
INFO - 2020-02-26 09:00:55 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:00:55 --> Final output sent to browser
DEBUG - 2020-02-26 09:00:55 --> Total execution time: 0.6615
INFO - 2020-02-26 09:00:56 --> Config Class Initialized
INFO - 2020-02-26 09:00:56 --> Config Class Initialized
INFO - 2020-02-26 09:00:56 --> Hooks Class Initialized
INFO - 2020-02-26 09:00:56 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:00:56 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:00:56 --> Utf8 Class Initialized
DEBUG - 2020-02-26 09:00:56 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:00:56 --> Utf8 Class Initialized
INFO - 2020-02-26 09:00:56 --> URI Class Initialized
INFO - 2020-02-26 09:00:56 --> URI Class Initialized
INFO - 2020-02-26 09:00:56 --> Router Class Initialized
INFO - 2020-02-26 09:00:56 --> Router Class Initialized
INFO - 2020-02-26 09:00:56 --> Output Class Initialized
INFO - 2020-02-26 09:00:56 --> Security Class Initialized
INFO - 2020-02-26 09:00:56 --> Output Class Initialized
DEBUG - 2020-02-26 09:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:00:56 --> Security Class Initialized
INFO - 2020-02-26 09:00:56 --> Input Class Initialized
DEBUG - 2020-02-26 09:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:00:56 --> Input Class Initialized
INFO - 2020-02-26 09:00:56 --> Language Class Initialized
INFO - 2020-02-26 09:00:56 --> Language Class Initialized
INFO - 2020-02-26 09:00:56 --> Loader Class Initialized
INFO - 2020-02-26 09:00:56 --> Helper loaded: url_helper
INFO - 2020-02-26 09:00:56 --> Loader Class Initialized
INFO - 2020-02-26 09:00:56 --> Helper loaded: string_helper
INFO - 2020-02-26 09:00:56 --> Helper loaded: url_helper
INFO - 2020-02-26 09:00:56 --> Helper loaded: string_helper
INFO - 2020-02-26 09:00:56 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:00:56 --> Database Driver Class Initialized
INFO - 2020-02-26 09:00:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-26 09:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:00:56 --> Controller Class Initialized
INFO - 2020-02-26 09:00:56 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:00:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:00:56 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:00:56 --> Helper loaded: form_helper
INFO - 2020-02-26 09:00:56 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:00:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 09:00:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 09:00:56 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:00:56 --> Final output sent to browser
DEBUG - 2020-02-26 09:00:56 --> Total execution time: 0.7349
INFO - 2020-02-26 09:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:00:56 --> Controller Class Initialized
INFO - 2020-02-26 09:00:56 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:00:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:00:56 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:00:56 --> Helper loaded: form_helper
INFO - 2020-02-26 09:00:57 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:00:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 09:00:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 09:00:57 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:00:57 --> Final output sent to browser
DEBUG - 2020-02-26 09:00:57 --> Total execution time: 1.0233
INFO - 2020-02-26 09:01:00 --> Config Class Initialized
INFO - 2020-02-26 09:01:00 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:01:00 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:01:00 --> Utf8 Class Initialized
INFO - 2020-02-26 09:01:00 --> URI Class Initialized
INFO - 2020-02-26 09:01:00 --> Router Class Initialized
INFO - 2020-02-26 09:01:00 --> Output Class Initialized
INFO - 2020-02-26 09:01:00 --> Security Class Initialized
DEBUG - 2020-02-26 09:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:01:00 --> Input Class Initialized
INFO - 2020-02-26 09:01:00 --> Language Class Initialized
INFO - 2020-02-26 09:01:00 --> Loader Class Initialized
INFO - 2020-02-26 09:01:00 --> Helper loaded: url_helper
INFO - 2020-02-26 09:01:00 --> Helper loaded: string_helper
INFO - 2020-02-26 09:01:00 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:01:00 --> Controller Class Initialized
INFO - 2020-02-26 09:01:00 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:01:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:01:00 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:01:00 --> Helper loaded: form_helper
INFO - 2020-02-26 09:01:00 --> Form Validation Class Initialized
INFO - 2020-02-26 15:01:00 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 15:01:00 --> Final output sent to browser
DEBUG - 2020-02-26 15:01:00 --> Total execution time: 0.8113
INFO - 2020-02-26 09:01:02 --> Config Class Initialized
INFO - 2020-02-26 09:01:02 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:01:03 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:01:03 --> Utf8 Class Initialized
INFO - 2020-02-26 09:01:03 --> URI Class Initialized
INFO - 2020-02-26 09:01:03 --> Router Class Initialized
INFO - 2020-02-26 09:01:03 --> Output Class Initialized
INFO - 2020-02-26 09:01:03 --> Security Class Initialized
DEBUG - 2020-02-26 09:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:01:03 --> Input Class Initialized
INFO - 2020-02-26 09:01:03 --> Language Class Initialized
INFO - 2020-02-26 09:01:03 --> Loader Class Initialized
INFO - 2020-02-26 09:01:03 --> Helper loaded: url_helper
INFO - 2020-02-26 09:01:03 --> Helper loaded: string_helper
INFO - 2020-02-26 09:01:03 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:01:03 --> Controller Class Initialized
INFO - 2020-02-26 09:01:03 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:01:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:01:03 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:01:03 --> Helper loaded: form_helper
INFO - 2020-02-26 09:01:03 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:01:03 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 41
INFO - 2020-02-26 09:01:03 --> Config Class Initialized
INFO - 2020-02-26 09:01:03 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:01:03 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:01:03 --> Utf8 Class Initialized
INFO - 2020-02-26 09:01:03 --> URI Class Initialized
INFO - 2020-02-26 09:01:03 --> Router Class Initialized
INFO - 2020-02-26 09:01:03 --> Output Class Initialized
INFO - 2020-02-26 09:01:03 --> Security Class Initialized
DEBUG - 2020-02-26 09:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:01:04 --> Input Class Initialized
INFO - 2020-02-26 09:01:04 --> Language Class Initialized
INFO - 2020-02-26 09:01:04 --> Loader Class Initialized
INFO - 2020-02-26 09:01:04 --> Helper loaded: url_helper
INFO - 2020-02-26 09:01:04 --> Helper loaded: string_helper
INFO - 2020-02-26 09:01:04 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:01:04 --> Controller Class Initialized
INFO - 2020-02-26 09:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 09:01:04 --> Pagination Class Initialized
INFO - 2020-02-26 09:01:04 --> Model "M_show" initialized
INFO - 2020-02-26 09:01:04 --> Helper loaded: form_helper
INFO - 2020-02-26 09:01:04 --> Form Validation Class Initialized
INFO - 2020-02-26 09:01:04 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 09:01:04 --> Final output sent to browser
DEBUG - 2020-02-26 09:01:04 --> Total execution time: 0.7050
INFO - 2020-02-26 09:01:04 --> Config Class Initialized
INFO - 2020-02-26 09:01:04 --> Config Class Initialized
INFO - 2020-02-26 09:01:04 --> Hooks Class Initialized
INFO - 2020-02-26 09:01:04 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:01:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:01:04 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:01:04 --> Utf8 Class Initialized
INFO - 2020-02-26 09:01:04 --> Utf8 Class Initialized
INFO - 2020-02-26 09:01:04 --> URI Class Initialized
INFO - 2020-02-26 09:01:04 --> URI Class Initialized
INFO - 2020-02-26 09:01:04 --> Router Class Initialized
INFO - 2020-02-26 09:01:04 --> Router Class Initialized
INFO - 2020-02-26 09:01:04 --> Output Class Initialized
INFO - 2020-02-26 09:01:04 --> Output Class Initialized
INFO - 2020-02-26 09:01:04 --> Security Class Initialized
INFO - 2020-02-26 09:01:04 --> Security Class Initialized
DEBUG - 2020-02-26 09:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:01:04 --> Input Class Initialized
INFO - 2020-02-26 09:01:04 --> Input Class Initialized
INFO - 2020-02-26 09:01:04 --> Language Class Initialized
INFO - 2020-02-26 09:01:04 --> Language Class Initialized
ERROR - 2020-02-26 09:01:04 --> 404 Page Not Found: Show/assets
ERROR - 2020-02-26 09:01:04 --> 404 Page Not Found: Show/assets
INFO - 2020-02-26 09:01:04 --> Config Class Initialized
INFO - 2020-02-26 09:01:04 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:01:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:01:05 --> Utf8 Class Initialized
INFO - 2020-02-26 09:01:05 --> URI Class Initialized
INFO - 2020-02-26 09:01:05 --> Router Class Initialized
INFO - 2020-02-26 09:01:05 --> Output Class Initialized
INFO - 2020-02-26 09:01:05 --> Security Class Initialized
DEBUG - 2020-02-26 09:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:01:05 --> Input Class Initialized
INFO - 2020-02-26 09:01:05 --> Language Class Initialized
ERROR - 2020-02-26 09:01:05 --> 404 Page Not Found: Show/assets
INFO - 2020-02-26 09:03:28 --> Config Class Initialized
INFO - 2020-02-26 09:03:28 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:03:28 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:28 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:28 --> URI Class Initialized
INFO - 2020-02-26 09:03:28 --> Router Class Initialized
INFO - 2020-02-26 09:03:28 --> Output Class Initialized
INFO - 2020-02-26 09:03:28 --> Security Class Initialized
DEBUG - 2020-02-26 09:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:28 --> Input Class Initialized
INFO - 2020-02-26 09:03:28 --> Language Class Initialized
INFO - 2020-02-26 09:03:28 --> Loader Class Initialized
INFO - 2020-02-26 09:03:28 --> Helper loaded: url_helper
INFO - 2020-02-26 09:03:28 --> Helper loaded: string_helper
INFO - 2020-02-26 09:03:28 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:03:28 --> Controller Class Initialized
INFO - 2020-02-26 09:03:28 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:03:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:03:28 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:03:28 --> Helper loaded: form_helper
INFO - 2020-02-26 09:03:28 --> Form Validation Class Initialized
INFO - 2020-02-26 09:03:28 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:03:28 --> Final output sent to browser
DEBUG - 2020-02-26 09:03:28 --> Total execution time: 0.5968
INFO - 2020-02-26 09:03:28 --> Config Class Initialized
INFO - 2020-02-26 09:03:28 --> Config Class Initialized
INFO - 2020-02-26 09:03:28 --> Config Class Initialized
INFO - 2020-02-26 09:03:28 --> Config Class Initialized
INFO - 2020-02-26 09:03:28 --> Config Class Initialized
INFO - 2020-02-26 09:03:28 --> Config Class Initialized
INFO - 2020-02-26 09:03:28 --> Hooks Class Initialized
INFO - 2020-02-26 09:03:28 --> Hooks Class Initialized
INFO - 2020-02-26 09:03:28 --> Hooks Class Initialized
INFO - 2020-02-26 09:03:28 --> Hooks Class Initialized
INFO - 2020-02-26 09:03:28 --> Hooks Class Initialized
INFO - 2020-02-26 09:03:28 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:03:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:03:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:03:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:03:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:03:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:03:28 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:28 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:28 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:28 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:28 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:28 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:28 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:28 --> URI Class Initialized
INFO - 2020-02-26 09:03:28 --> URI Class Initialized
INFO - 2020-02-26 09:03:28 --> URI Class Initialized
INFO - 2020-02-26 09:03:28 --> URI Class Initialized
INFO - 2020-02-26 09:03:28 --> URI Class Initialized
INFO - 2020-02-26 09:03:28 --> URI Class Initialized
INFO - 2020-02-26 09:03:28 --> Router Class Initialized
INFO - 2020-02-26 09:03:28 --> Router Class Initialized
INFO - 2020-02-26 09:03:28 --> Router Class Initialized
INFO - 2020-02-26 09:03:28 --> Router Class Initialized
INFO - 2020-02-26 09:03:28 --> Router Class Initialized
INFO - 2020-02-26 09:03:28 --> Router Class Initialized
INFO - 2020-02-26 09:03:28 --> Output Class Initialized
INFO - 2020-02-26 09:03:28 --> Output Class Initialized
INFO - 2020-02-26 09:03:28 --> Output Class Initialized
INFO - 2020-02-26 09:03:28 --> Output Class Initialized
INFO - 2020-02-26 09:03:28 --> Output Class Initialized
INFO - 2020-02-26 09:03:28 --> Output Class Initialized
INFO - 2020-02-26 09:03:28 --> Security Class Initialized
INFO - 2020-02-26 09:03:28 --> Security Class Initialized
INFO - 2020-02-26 09:03:28 --> Security Class Initialized
INFO - 2020-02-26 09:03:28 --> Security Class Initialized
INFO - 2020-02-26 09:03:28 --> Security Class Initialized
INFO - 2020-02-26 09:03:28 --> Security Class Initialized
DEBUG - 2020-02-26 09:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:28 --> Input Class Initialized
INFO - 2020-02-26 09:03:28 --> Input Class Initialized
INFO - 2020-02-26 09:03:28 --> Input Class Initialized
INFO - 2020-02-26 09:03:28 --> Input Class Initialized
INFO - 2020-02-26 09:03:28 --> Input Class Initialized
INFO - 2020-02-26 09:03:28 --> Input Class Initialized
INFO - 2020-02-26 09:03:28 --> Language Class Initialized
INFO - 2020-02-26 09:03:28 --> Language Class Initialized
INFO - 2020-02-26 09:03:28 --> Language Class Initialized
INFO - 2020-02-26 09:03:28 --> Language Class Initialized
INFO - 2020-02-26 09:03:28 --> Language Class Initialized
INFO - 2020-02-26 09:03:28 --> Language Class Initialized
ERROR - 2020-02-26 09:03:28 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 09:03:28 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 09:03:28 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 09:03:28 --> Loader Class Initialized
ERROR - 2020-02-26 09:03:28 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 09:03:28 --> Loader Class Initialized
INFO - 2020-02-26 09:03:28 --> Helper loaded: url_helper
INFO - 2020-02-26 09:03:29 --> Helper loaded: url_helper
INFO - 2020-02-26 09:03:29 --> Config Class Initialized
INFO - 2020-02-26 09:03:29 --> Config Class Initialized
INFO - 2020-02-26 09:03:29 --> Config Class Initialized
INFO - 2020-02-26 09:03:29 --> Config Class Initialized
INFO - 2020-02-26 09:03:29 --> Hooks Class Initialized
INFO - 2020-02-26 09:03:29 --> Hooks Class Initialized
INFO - 2020-02-26 09:03:29 --> Hooks Class Initialized
INFO - 2020-02-26 09:03:29 --> Hooks Class Initialized
INFO - 2020-02-26 09:03:29 --> Helper loaded: string_helper
INFO - 2020-02-26 09:03:29 --> Helper loaded: string_helper
DEBUG - 2020-02-26 09:03:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:03:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:03:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:03:29 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:29 --> Database Driver Class Initialized
INFO - 2020-02-26 09:03:29 --> Database Driver Class Initialized
INFO - 2020-02-26 09:03:29 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:29 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:29 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:29 --> Utf8 Class Initialized
DEBUG - 2020-02-26 09:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-26 09:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:03:29 --> URI Class Initialized
INFO - 2020-02-26 09:03:29 --> URI Class Initialized
INFO - 2020-02-26 09:03:29 --> URI Class Initialized
INFO - 2020-02-26 09:03:29 --> URI Class Initialized
INFO - 2020-02-26 09:03:29 --> Controller Class Initialized
INFO - 2020-02-26 09:03:29 --> Router Class Initialized
INFO - 2020-02-26 09:03:29 --> Router Class Initialized
INFO - 2020-02-26 09:03:29 --> Router Class Initialized
INFO - 2020-02-26 09:03:29 --> Router Class Initialized
INFO - 2020-02-26 09:03:29 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:03:29 --> Output Class Initialized
INFO - 2020-02-26 09:03:29 --> Output Class Initialized
INFO - 2020-02-26 09:03:29 --> Output Class Initialized
INFO - 2020-02-26 09:03:29 --> Output Class Initialized
INFO - 2020-02-26 09:03:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:03:29 --> Security Class Initialized
INFO - 2020-02-26 09:03:29 --> Security Class Initialized
INFO - 2020-02-26 09:03:29 --> Security Class Initialized
INFO - 2020-02-26 09:03:29 --> Security Class Initialized
INFO - 2020-02-26 09:03:29 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 09:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:29 --> Input Class Initialized
INFO - 2020-02-26 09:03:29 --> Input Class Initialized
INFO - 2020-02-26 09:03:29 --> Input Class Initialized
INFO - 2020-02-26 09:03:29 --> Input Class Initialized
INFO - 2020-02-26 09:03:29 --> Helper loaded: form_helper
INFO - 2020-02-26 09:03:29 --> Form Validation Class Initialized
INFO - 2020-02-26 09:03:29 --> Language Class Initialized
INFO - 2020-02-26 09:03:29 --> Language Class Initialized
INFO - 2020-02-26 09:03:29 --> Language Class Initialized
INFO - 2020-02-26 09:03:29 --> Language Class Initialized
ERROR - 2020-02-26 09:03:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 09:03:29 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 09:03:29 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 09:03:29 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-26 09:03:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 09:03:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 09:03:29 --> Config Class Initialized
INFO - 2020-02-26 09:03:29 --> Config Class Initialized
INFO - 2020-02-26 09:03:29 --> Hooks Class Initialized
INFO - 2020-02-26 09:03:29 --> Hooks Class Initialized
INFO - 2020-02-26 09:03:29 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:03:29 --> Config Class Initialized
INFO - 2020-02-26 09:03:29 --> Hooks Class Initialized
INFO - 2020-02-26 09:03:29 --> Final output sent to browser
DEBUG - 2020-02-26 09:03:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:03:29 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:29 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:29 --> Utf8 Class Initialized
DEBUG - 2020-02-26 09:03:29 --> Total execution time: 0.7033
DEBUG - 2020-02-26 09:03:29 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:29 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:29 --> URI Class Initialized
INFO - 2020-02-26 09:03:29 --> URI Class Initialized
INFO - 2020-02-26 09:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:03:29 --> Config Class Initialized
INFO - 2020-02-26 09:03:29 --> Hooks Class Initialized
INFO - 2020-02-26 09:03:29 --> Controller Class Initialized
INFO - 2020-02-26 09:03:29 --> Router Class Initialized
INFO - 2020-02-26 09:03:29 --> Router Class Initialized
INFO - 2020-02-26 09:03:29 --> URI Class Initialized
INFO - 2020-02-26 09:03:29 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:03:29 --> Output Class Initialized
INFO - 2020-02-26 09:03:29 --> Output Class Initialized
INFO - 2020-02-26 09:03:29 --> Router Class Initialized
DEBUG - 2020-02-26 09:03:29 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:29 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:03:29 --> Security Class Initialized
INFO - 2020-02-26 09:03:29 --> Output Class Initialized
INFO - 2020-02-26 09:03:29 --> Security Class Initialized
INFO - 2020-02-26 09:03:29 --> URI Class Initialized
DEBUG - 2020-02-26 09:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:29 --> Security Class Initialized
INFO - 2020-02-26 09:03:29 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 09:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:29 --> Input Class Initialized
INFO - 2020-02-26 09:03:29 --> Input Class Initialized
INFO - 2020-02-26 09:03:29 --> Router Class Initialized
DEBUG - 2020-02-26 09:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:29 --> Helper loaded: form_helper
INFO - 2020-02-26 09:03:29 --> Form Validation Class Initialized
INFO - 2020-02-26 09:03:29 --> Language Class Initialized
INFO - 2020-02-26 09:03:29 --> Language Class Initialized
INFO - 2020-02-26 09:03:29 --> Input Class Initialized
INFO - 2020-02-26 09:03:29 --> Output Class Initialized
INFO - 2020-02-26 09:03:29 --> Language Class Initialized
ERROR - 2020-02-26 09:03:29 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-26 09:03:29 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 09:03:29 --> Security Class Initialized
ERROR - 2020-02-26 09:03:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 09:03:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 09:03:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-26 09:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:29 --> Input Class Initialized
INFO - 2020-02-26 09:03:29 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:03:29 --> Final output sent to browser
INFO - 2020-02-26 09:03:29 --> Language Class Initialized
DEBUG - 2020-02-26 09:03:29 --> Total execution time: 0.9474
ERROR - 2020-02-26 09:03:29 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 09:03:29 --> Config Class Initialized
INFO - 2020-02-26 09:03:29 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:03:29 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:29 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:29 --> URI Class Initialized
INFO - 2020-02-26 09:03:29 --> Router Class Initialized
INFO - 2020-02-26 09:03:29 --> Output Class Initialized
INFO - 2020-02-26 09:03:29 --> Security Class Initialized
DEBUG - 2020-02-26 09:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:29 --> Input Class Initialized
INFO - 2020-02-26 09:03:29 --> Language Class Initialized
ERROR - 2020-02-26 09:03:29 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 09:03:30 --> Config Class Initialized
INFO - 2020-02-26 09:03:30 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:03:30 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:30 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:30 --> URI Class Initialized
INFO - 2020-02-26 09:03:30 --> Router Class Initialized
INFO - 2020-02-26 09:03:30 --> Output Class Initialized
INFO - 2020-02-26 09:03:30 --> Security Class Initialized
DEBUG - 2020-02-26 09:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:30 --> Input Class Initialized
INFO - 2020-02-26 09:03:30 --> Language Class Initialized
ERROR - 2020-02-26 09:03:30 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 09:03:30 --> Config Class Initialized
INFO - 2020-02-26 09:03:30 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:03:30 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:30 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:30 --> URI Class Initialized
INFO - 2020-02-26 09:03:30 --> Router Class Initialized
INFO - 2020-02-26 09:03:30 --> Output Class Initialized
INFO - 2020-02-26 09:03:30 --> Security Class Initialized
DEBUG - 2020-02-26 09:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:30 --> Input Class Initialized
INFO - 2020-02-26 09:03:30 --> Language Class Initialized
ERROR - 2020-02-26 09:03:31 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 09:03:31 --> Config Class Initialized
INFO - 2020-02-26 09:03:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:03:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:31 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:31 --> URI Class Initialized
INFO - 2020-02-26 09:03:31 --> Router Class Initialized
INFO - 2020-02-26 09:03:31 --> Output Class Initialized
INFO - 2020-02-26 09:03:31 --> Security Class Initialized
DEBUG - 2020-02-26 09:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:31 --> Input Class Initialized
INFO - 2020-02-26 09:03:31 --> Language Class Initialized
ERROR - 2020-02-26 09:03:31 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 09:03:31 --> Config Class Initialized
INFO - 2020-02-26 09:03:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:03:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:31 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:31 --> URI Class Initialized
INFO - 2020-02-26 09:03:31 --> Router Class Initialized
INFO - 2020-02-26 09:03:31 --> Output Class Initialized
INFO - 2020-02-26 09:03:31 --> Security Class Initialized
DEBUG - 2020-02-26 09:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:31 --> Input Class Initialized
INFO - 2020-02-26 09:03:31 --> Language Class Initialized
ERROR - 2020-02-26 09:03:31 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 09:03:31 --> Config Class Initialized
INFO - 2020-02-26 09:03:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:03:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:31 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:31 --> URI Class Initialized
INFO - 2020-02-26 09:03:31 --> Router Class Initialized
INFO - 2020-02-26 09:03:31 --> Output Class Initialized
INFO - 2020-02-26 09:03:31 --> Security Class Initialized
DEBUG - 2020-02-26 09:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:31 --> Input Class Initialized
INFO - 2020-02-26 09:03:31 --> Language Class Initialized
ERROR - 2020-02-26 09:03:31 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 09:03:31 --> Config Class Initialized
INFO - 2020-02-26 09:03:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:03:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:31 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:32 --> URI Class Initialized
INFO - 2020-02-26 09:03:32 --> Router Class Initialized
INFO - 2020-02-26 09:03:32 --> Output Class Initialized
INFO - 2020-02-26 09:03:32 --> Security Class Initialized
DEBUG - 2020-02-26 09:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:32 --> Input Class Initialized
INFO - 2020-02-26 09:03:32 --> Language Class Initialized
ERROR - 2020-02-26 09:03:32 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 09:03:32 --> Config Class Initialized
INFO - 2020-02-26 09:03:32 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:03:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:03:32 --> Utf8 Class Initialized
INFO - 2020-02-26 09:03:32 --> URI Class Initialized
INFO - 2020-02-26 09:03:32 --> Router Class Initialized
INFO - 2020-02-26 09:03:32 --> Output Class Initialized
INFO - 2020-02-26 09:03:32 --> Security Class Initialized
DEBUG - 2020-02-26 09:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:03:32 --> Input Class Initialized
INFO - 2020-02-26 09:03:32 --> Language Class Initialized
ERROR - 2020-02-26 09:03:32 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 09:24:00 --> Config Class Initialized
INFO - 2020-02-26 09:24:01 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:01 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:01 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:01 --> URI Class Initialized
INFO - 2020-02-26 09:24:01 --> Router Class Initialized
INFO - 2020-02-26 09:24:01 --> Output Class Initialized
INFO - 2020-02-26 09:24:01 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:01 --> Input Class Initialized
INFO - 2020-02-26 09:24:01 --> Language Class Initialized
INFO - 2020-02-26 09:24:01 --> Loader Class Initialized
INFO - 2020-02-26 09:24:01 --> Helper loaded: url_helper
INFO - 2020-02-26 09:24:01 --> Helper loaded: string_helper
INFO - 2020-02-26 09:24:01 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:24:01 --> Controller Class Initialized
INFO - 2020-02-26 09:24:01 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:24:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:24:01 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:24:01 --> Helper loaded: form_helper
INFO - 2020-02-26 09:24:01 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:24:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 79
ERROR - 2020-02-26 15:24:02 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `id_pengunjung`) VALUES ('33', '100000', '1', '1', '20-02-26 03:24:02', '2020-02-27 03:24:02', NULL, 'PM151', NULL, NULL)
INFO - 2020-02-26 15:24:02 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-26 09:24:14 --> Config Class Initialized
INFO - 2020-02-26 09:24:14 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:14 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:14 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:14 --> URI Class Initialized
INFO - 2020-02-26 09:24:14 --> Router Class Initialized
INFO - 2020-02-26 09:24:14 --> Output Class Initialized
INFO - 2020-02-26 09:24:14 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:14 --> Input Class Initialized
INFO - 2020-02-26 09:24:14 --> Language Class Initialized
INFO - 2020-02-26 09:24:14 --> Loader Class Initialized
INFO - 2020-02-26 09:24:14 --> Helper loaded: url_helper
INFO - 2020-02-26 09:24:14 --> Helper loaded: string_helper
INFO - 2020-02-26 09:24:14 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:24:14 --> Controller Class Initialized
INFO - 2020-02-26 09:24:15 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:24:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:24:15 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:24:15 --> Helper loaded: form_helper
INFO - 2020-02-26 09:24:15 --> Form Validation Class Initialized
INFO - 2020-02-26 09:24:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:24:15 --> Final output sent to browser
DEBUG - 2020-02-26 09:24:15 --> Total execution time: 1.0610
INFO - 2020-02-26 09:24:15 --> Config Class Initialized
INFO - 2020-02-26 09:24:15 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:15 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:15 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:15 --> URI Class Initialized
INFO - 2020-02-26 09:24:15 --> Router Class Initialized
INFO - 2020-02-26 09:24:15 --> Output Class Initialized
INFO - 2020-02-26 09:24:15 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:15 --> Input Class Initialized
INFO - 2020-02-26 09:24:15 --> Language Class Initialized
ERROR - 2020-02-26 09:24:15 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 09:24:19 --> Config Class Initialized
INFO - 2020-02-26 09:24:19 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:19 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:19 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:19 --> URI Class Initialized
INFO - 2020-02-26 09:24:19 --> Router Class Initialized
INFO - 2020-02-26 09:24:19 --> Output Class Initialized
INFO - 2020-02-26 09:24:19 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:19 --> Input Class Initialized
INFO - 2020-02-26 09:24:19 --> Language Class Initialized
INFO - 2020-02-26 09:24:20 --> Loader Class Initialized
INFO - 2020-02-26 09:24:20 --> Helper loaded: url_helper
INFO - 2020-02-26 09:24:20 --> Helper loaded: string_helper
INFO - 2020-02-26 09:24:20 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:24:20 --> Controller Class Initialized
INFO - 2020-02-26 09:24:20 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:24:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:24:20 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:24:20 --> Helper loaded: form_helper
INFO - 2020-02-26 09:24:20 --> Form Validation Class Initialized
INFO - 2020-02-26 09:24:20 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:24:20 --> Final output sent to browser
DEBUG - 2020-02-26 09:24:20 --> Total execution time: 1.5423
INFO - 2020-02-26 09:24:20 --> Config Class Initialized
INFO - 2020-02-26 09:24:20 --> Config Class Initialized
INFO - 2020-02-26 09:24:20 --> Config Class Initialized
INFO - 2020-02-26 09:24:20 --> Hooks Class Initialized
INFO - 2020-02-26 09:24:20 --> Config Class Initialized
INFO - 2020-02-26 09:24:20 --> Config Class Initialized
INFO - 2020-02-26 09:24:20 --> Hooks Class Initialized
INFO - 2020-02-26 09:24:20 --> Hooks Class Initialized
INFO - 2020-02-26 09:24:20 --> Config Class Initialized
INFO - 2020-02-26 09:24:20 --> Hooks Class Initialized
INFO - 2020-02-26 09:24:20 --> Hooks Class Initialized
INFO - 2020-02-26 09:24:20 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:24:20 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:20 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:20 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:20 --> Utf8 Class Initialized
DEBUG - 2020-02-26 09:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:24:20 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:20 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:20 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:20 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:20 --> URI Class Initialized
INFO - 2020-02-26 09:24:20 --> URI Class Initialized
INFO - 2020-02-26 09:24:20 --> URI Class Initialized
INFO - 2020-02-26 09:24:20 --> URI Class Initialized
INFO - 2020-02-26 09:24:20 --> Router Class Initialized
INFO - 2020-02-26 09:24:20 --> Router Class Initialized
INFO - 2020-02-26 09:24:20 --> URI Class Initialized
INFO - 2020-02-26 09:24:20 --> Router Class Initialized
INFO - 2020-02-26 09:24:20 --> URI Class Initialized
INFO - 2020-02-26 09:24:21 --> Router Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Router Class Initialized
INFO - 2020-02-26 09:24:21 --> Router Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
ERROR - 2020-02-26 09:24:21 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-26 09:24:21 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
ERROR - 2020-02-26 09:24:21 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 09:24:21 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 09:24:21 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 09:24:21 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 09:24:21 --> Config Class Initialized
INFO - 2020-02-26 09:24:21 --> Config Class Initialized
INFO - 2020-02-26 09:24:21 --> Config Class Initialized
INFO - 2020-02-26 09:24:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:24:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:24:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:24:21 --> Config Class Initialized
INFO - 2020-02-26 09:24:21 --> Config Class Initialized
INFO - 2020-02-26 09:24:21 --> Config Class Initialized
INFO - 2020-02-26 09:24:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:24:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:24:21 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:24:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:21 --> Utf8 Class Initialized
DEBUG - 2020-02-26 09:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:24:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:21 --> URI Class Initialized
INFO - 2020-02-26 09:24:21 --> URI Class Initialized
INFO - 2020-02-26 09:24:21 --> URI Class Initialized
INFO - 2020-02-26 09:24:21 --> Router Class Initialized
INFO - 2020-02-26 09:24:21 --> URI Class Initialized
INFO - 2020-02-26 09:24:21 --> URI Class Initialized
INFO - 2020-02-26 09:24:21 --> URI Class Initialized
INFO - 2020-02-26 09:24:21 --> Router Class Initialized
INFO - 2020-02-26 09:24:21 --> Router Class Initialized
INFO - 2020-02-26 09:24:21 --> Router Class Initialized
INFO - 2020-02-26 09:24:21 --> Router Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Router Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
ERROR - 2020-02-26 09:24:21 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 09:24:21 --> Loader Class Initialized
INFO - 2020-02-26 09:24:21 --> Loader Class Initialized
ERROR - 2020-02-26 09:24:21 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 09:24:21 --> Helper loaded: url_helper
INFO - 2020-02-26 09:24:21 --> Helper loaded: url_helper
ERROR - 2020-02-26 09:24:21 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 09:24:21 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 09:24:21 --> Config Class Initialized
INFO - 2020-02-26 09:24:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:24:21 --> Helper loaded: string_helper
INFO - 2020-02-26 09:24:21 --> Helper loaded: string_helper
INFO - 2020-02-26 09:24:21 --> Config Class Initialized
DEBUG - 2020-02-26 09:24:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:21 --> Database Driver Class Initialized
INFO - 2020-02-26 09:24:21 --> Database Driver Class Initialized
INFO - 2020-02-26 09:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:21 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-26 09:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:24:21 --> URI Class Initialized
DEBUG - 2020-02-26 09:24:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:21 --> Controller Class Initialized
INFO - 2020-02-26 09:24:21 --> Router Class Initialized
INFO - 2020-02-26 09:24:21 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:24:21 --> URI Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:24:21 --> Router Class Initialized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
INFO - 2020-02-26 09:24:21 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
INFO - 2020-02-26 09:24:21 --> Helper loaded: form_helper
INFO - 2020-02-26 09:24:21 --> Form Validation Class Initialized
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
ERROR - 2020-02-26 09:24:21 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 09:24:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 09:24:21 --> Language Class Initialized
ERROR - 2020-02-26 09:24:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 09:24:21 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-26 09:24:21 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 09:24:21 --> Final output sent to browser
DEBUG - 2020-02-26 09:24:21 --> Total execution time: 0.6026
INFO - 2020-02-26 09:24:21 --> Config Class Initialized
INFO - 2020-02-26 09:24:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:24:21 --> Controller Class Initialized
DEBUG - 2020-02-26 09:24:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:21 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:24:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:24:21 --> URI Class Initialized
INFO - 2020-02-26 09:24:21 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:24:21 --> Router Class Initialized
INFO - 2020-02-26 09:24:21 --> Output Class Initialized
INFO - 2020-02-26 09:24:21 --> Helper loaded: form_helper
INFO - 2020-02-26 09:24:21 --> Form Validation Class Initialized
INFO - 2020-02-26 09:24:21 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-26 09:24:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 09:24:21 --> Input Class Initialized
ERROR - 2020-02-26 09:24:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 09:24:22 --> Language Class Initialized
INFO - 2020-02-26 09:24:22 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:24:22 --> Final output sent to browser
ERROR - 2020-02-26 09:24:22 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-26 09:24:22 --> Total execution time: 0.8557
INFO - 2020-02-26 09:24:22 --> Config Class Initialized
INFO - 2020-02-26 09:24:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:22 --> URI Class Initialized
INFO - 2020-02-26 09:24:22 --> Router Class Initialized
INFO - 2020-02-26 09:24:22 --> Output Class Initialized
INFO - 2020-02-26 09:24:22 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:22 --> Input Class Initialized
INFO - 2020-02-26 09:24:22 --> Language Class Initialized
ERROR - 2020-02-26 09:24:22 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 09:24:22 --> Config Class Initialized
INFO - 2020-02-26 09:24:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:22 --> URI Class Initialized
INFO - 2020-02-26 09:24:22 --> Router Class Initialized
INFO - 2020-02-26 09:24:22 --> Output Class Initialized
INFO - 2020-02-26 09:24:22 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:22 --> Input Class Initialized
INFO - 2020-02-26 09:24:22 --> Language Class Initialized
ERROR - 2020-02-26 09:24:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 09:24:22 --> Config Class Initialized
INFO - 2020-02-26 09:24:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:22 --> URI Class Initialized
INFO - 2020-02-26 09:24:22 --> Router Class Initialized
INFO - 2020-02-26 09:24:22 --> Output Class Initialized
INFO - 2020-02-26 09:24:22 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:22 --> Input Class Initialized
INFO - 2020-02-26 09:24:22 --> Language Class Initialized
ERROR - 2020-02-26 09:24:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 09:24:22 --> Config Class Initialized
INFO - 2020-02-26 09:24:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:22 --> URI Class Initialized
INFO - 2020-02-26 09:24:22 --> Router Class Initialized
INFO - 2020-02-26 09:24:22 --> Output Class Initialized
INFO - 2020-02-26 09:24:22 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:23 --> Input Class Initialized
INFO - 2020-02-26 09:24:23 --> Language Class Initialized
ERROR - 2020-02-26 09:24:23 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 09:24:23 --> Config Class Initialized
INFO - 2020-02-26 09:24:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:23 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:23 --> URI Class Initialized
INFO - 2020-02-26 09:24:23 --> Router Class Initialized
INFO - 2020-02-26 09:24:23 --> Output Class Initialized
INFO - 2020-02-26 09:24:23 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:23 --> Input Class Initialized
INFO - 2020-02-26 09:24:23 --> Language Class Initialized
ERROR - 2020-02-26 09:24:23 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 09:24:23 --> Config Class Initialized
INFO - 2020-02-26 09:24:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:23 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:23 --> URI Class Initialized
INFO - 2020-02-26 09:24:23 --> Router Class Initialized
INFO - 2020-02-26 09:24:23 --> Output Class Initialized
INFO - 2020-02-26 09:24:23 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:23 --> Input Class Initialized
INFO - 2020-02-26 09:24:23 --> Language Class Initialized
ERROR - 2020-02-26 09:24:23 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 09:24:23 --> Config Class Initialized
INFO - 2020-02-26 09:24:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:24:23 --> Utf8 Class Initialized
INFO - 2020-02-26 09:24:23 --> URI Class Initialized
INFO - 2020-02-26 09:24:23 --> Router Class Initialized
INFO - 2020-02-26 09:24:23 --> Output Class Initialized
INFO - 2020-02-26 09:24:23 --> Security Class Initialized
DEBUG - 2020-02-26 09:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:24:23 --> Input Class Initialized
INFO - 2020-02-26 09:24:23 --> Language Class Initialized
ERROR - 2020-02-26 09:24:23 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 09:25:00 --> Config Class Initialized
INFO - 2020-02-26 09:25:00 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:25:00 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:25:00 --> Utf8 Class Initialized
INFO - 2020-02-26 09:25:00 --> URI Class Initialized
INFO - 2020-02-26 09:25:00 --> Router Class Initialized
INFO - 2020-02-26 09:25:00 --> Output Class Initialized
INFO - 2020-02-26 09:25:00 --> Security Class Initialized
DEBUG - 2020-02-26 09:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:25:00 --> Input Class Initialized
INFO - 2020-02-26 09:25:00 --> Language Class Initialized
INFO - 2020-02-26 09:25:00 --> Loader Class Initialized
INFO - 2020-02-26 09:25:01 --> Helper loaded: url_helper
INFO - 2020-02-26 09:25:01 --> Helper loaded: string_helper
INFO - 2020-02-26 09:25:01 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:25:01 --> Controller Class Initialized
INFO - 2020-02-26 09:25:01 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:25:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:25:01 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:25:01 --> Helper loaded: form_helper
INFO - 2020-02-26 09:25:01 --> Form Validation Class Initialized
INFO - 2020-02-26 15:25:01 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 15:25:01 --> Final output sent to browser
DEBUG - 2020-02-26 15:25:01 --> Total execution time: 0.8823
INFO - 2020-02-26 09:29:19 --> Config Class Initialized
INFO - 2020-02-26 09:29:19 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:29:19 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:29:19 --> Utf8 Class Initialized
INFO - 2020-02-26 09:29:19 --> URI Class Initialized
INFO - 2020-02-26 09:29:19 --> Router Class Initialized
INFO - 2020-02-26 09:29:19 --> Output Class Initialized
INFO - 2020-02-26 09:29:19 --> Security Class Initialized
DEBUG - 2020-02-26 09:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:29:20 --> Input Class Initialized
INFO - 2020-02-26 09:29:20 --> Language Class Initialized
INFO - 2020-02-26 09:29:20 --> Loader Class Initialized
INFO - 2020-02-26 09:29:20 --> Helper loaded: url_helper
INFO - 2020-02-26 09:29:20 --> Helper loaded: string_helper
INFO - 2020-02-26 09:29:20 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:29:20 --> Controller Class Initialized
INFO - 2020-02-26 09:29:20 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:29:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:29:20 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:29:20 --> Helper loaded: form_helper
INFO - 2020-02-26 09:29:20 --> Form Validation Class Initialized
ERROR - 2020-02-26 15:29:20 --> Severity: Notice --> Undefined variable: kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 62
INFO - 2020-02-26 15:29:20 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 15:29:20 --> Final output sent to browser
DEBUG - 2020-02-26 15:29:20 --> Total execution time: 1.0471
INFO - 2020-02-26 09:29:51 --> Config Class Initialized
INFO - 2020-02-26 09:29:51 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:29:51 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:29:51 --> Utf8 Class Initialized
INFO - 2020-02-26 09:29:51 --> URI Class Initialized
INFO - 2020-02-26 09:29:51 --> Router Class Initialized
INFO - 2020-02-26 09:29:51 --> Output Class Initialized
INFO - 2020-02-26 09:29:51 --> Security Class Initialized
DEBUG - 2020-02-26 09:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:29:51 --> Input Class Initialized
INFO - 2020-02-26 09:29:51 --> Language Class Initialized
INFO - 2020-02-26 09:29:51 --> Loader Class Initialized
INFO - 2020-02-26 09:29:51 --> Helper loaded: url_helper
INFO - 2020-02-26 09:29:51 --> Helper loaded: string_helper
INFO - 2020-02-26 09:29:51 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:29:51 --> Controller Class Initialized
INFO - 2020-02-26 09:29:51 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:29:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:29:51 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:29:51 --> Helper loaded: form_helper
INFO - 2020-02-26 09:29:51 --> Form Validation Class Initialized
ERROR - 2020-02-26 15:29:51 --> Severity: Notice --> Undefined variable: kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 62
INFO - 2020-02-26 15:29:51 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 15:29:52 --> Final output sent to browser
DEBUG - 2020-02-26 15:29:52 --> Total execution time: 0.8705
INFO - 2020-02-26 09:29:54 --> Config Class Initialized
INFO - 2020-02-26 09:29:54 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:29:54 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:29:54 --> Utf8 Class Initialized
INFO - 2020-02-26 09:29:54 --> URI Class Initialized
INFO - 2020-02-26 09:29:54 --> Router Class Initialized
INFO - 2020-02-26 09:29:54 --> Output Class Initialized
INFO - 2020-02-26 09:29:54 --> Security Class Initialized
DEBUG - 2020-02-26 09:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:29:54 --> Input Class Initialized
INFO - 2020-02-26 09:29:54 --> Language Class Initialized
INFO - 2020-02-26 09:29:54 --> Loader Class Initialized
INFO - 2020-02-26 09:29:54 --> Helper loaded: url_helper
INFO - 2020-02-26 09:29:54 --> Helper loaded: string_helper
INFO - 2020-02-26 09:29:54 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:29:54 --> Controller Class Initialized
INFO - 2020-02-26 09:29:54 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:29:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:29:55 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:29:55 --> Helper loaded: form_helper
INFO - 2020-02-26 09:29:55 --> Form Validation Class Initialized
ERROR - 2020-02-26 15:29:55 --> Severity: Notice --> Undefined variable: kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 62
INFO - 2020-02-26 15:29:55 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 15:29:55 --> Final output sent to browser
DEBUG - 2020-02-26 15:29:55 --> Total execution time: 0.8306
INFO - 2020-02-26 09:30:22 --> Config Class Initialized
INFO - 2020-02-26 09:30:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:30:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:30:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:30:22 --> URI Class Initialized
INFO - 2020-02-26 09:30:22 --> Router Class Initialized
INFO - 2020-02-26 09:30:22 --> Output Class Initialized
INFO - 2020-02-26 09:30:22 --> Security Class Initialized
DEBUG - 2020-02-26 09:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:30:22 --> Input Class Initialized
INFO - 2020-02-26 09:30:22 --> Language Class Initialized
INFO - 2020-02-26 09:30:22 --> Loader Class Initialized
INFO - 2020-02-26 09:30:22 --> Helper loaded: url_helper
INFO - 2020-02-26 09:30:22 --> Helper loaded: string_helper
INFO - 2020-02-26 09:30:22 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:30:22 --> Controller Class Initialized
INFO - 2020-02-26 09:30:22 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:30:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:30:23 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:30:23 --> Helper loaded: form_helper
INFO - 2020-02-26 09:30:23 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:30:23 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow-2\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 55
INFO - 2020-02-26 09:32:33 --> Config Class Initialized
INFO - 2020-02-26 09:32:33 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:32:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:32:33 --> Utf8 Class Initialized
INFO - 2020-02-26 09:32:33 --> URI Class Initialized
INFO - 2020-02-26 09:32:33 --> Router Class Initialized
INFO - 2020-02-26 09:32:33 --> Output Class Initialized
INFO - 2020-02-26 09:32:33 --> Security Class Initialized
DEBUG - 2020-02-26 09:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:32:33 --> Input Class Initialized
INFO - 2020-02-26 09:32:33 --> Language Class Initialized
INFO - 2020-02-26 09:32:33 --> Loader Class Initialized
INFO - 2020-02-26 09:32:33 --> Helper loaded: url_helper
INFO - 2020-02-26 09:32:33 --> Helper loaded: string_helper
INFO - 2020-02-26 09:32:33 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:32:33 --> Controller Class Initialized
INFO - 2020-02-26 09:32:33 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:32:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:32:33 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:32:33 --> Helper loaded: form_helper
INFO - 2020-02-26 09:32:33 --> Form Validation Class Initialized
ERROR - 2020-02-26 15:32:34 --> Severity: Notice --> Undefined variable: kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 62
INFO - 2020-02-26 15:32:34 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 15:32:34 --> Final output sent to browser
DEBUG - 2020-02-26 15:32:34 --> Total execution time: 0.8696
INFO - 2020-02-26 09:33:52 --> Config Class Initialized
INFO - 2020-02-26 09:33:52 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:33:52 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:33:52 --> Utf8 Class Initialized
INFO - 2020-02-26 09:33:52 --> URI Class Initialized
INFO - 2020-02-26 09:33:52 --> Router Class Initialized
INFO - 2020-02-26 09:33:52 --> Output Class Initialized
INFO - 2020-02-26 09:33:52 --> Security Class Initialized
DEBUG - 2020-02-26 09:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:33:52 --> Input Class Initialized
INFO - 2020-02-26 09:33:52 --> Language Class Initialized
INFO - 2020-02-26 09:33:52 --> Loader Class Initialized
INFO - 2020-02-26 09:33:52 --> Helper loaded: url_helper
INFO - 2020-02-26 09:33:52 --> Helper loaded: string_helper
INFO - 2020-02-26 09:33:52 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:33:52 --> Controller Class Initialized
INFO - 2020-02-26 09:33:52 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:33:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:33:52 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:33:52 --> Helper loaded: form_helper
INFO - 2020-02-26 09:33:53 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:33:53 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 70
ERROR - 2020-02-26 09:33:53 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 71
ERROR - 2020-02-26 09:33:53 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 72
ERROR - 2020-02-26 09:33:53 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 73
ERROR - 2020-02-26 09:33:53 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 81
ERROR - 2020-02-26 09:33:53 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 82
ERROR - 2020-02-26 09:33:53 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 83
ERROR - 2020-02-26 09:33:53 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 84
ERROR - 2020-02-26 09:33:53 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pengunjung` (`nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2020-02-26 09:33:53 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-26 09:33:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow-2\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow-2\system\core\Common.php 570
INFO - 2020-02-26 09:34:09 --> Config Class Initialized
INFO - 2020-02-26 09:34:09 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:09 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:09 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:10 --> URI Class Initialized
INFO - 2020-02-26 09:34:10 --> Router Class Initialized
INFO - 2020-02-26 09:34:10 --> Output Class Initialized
INFO - 2020-02-26 09:34:10 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:10 --> Input Class Initialized
INFO - 2020-02-26 09:34:10 --> Language Class Initialized
INFO - 2020-02-26 09:34:10 --> Loader Class Initialized
INFO - 2020-02-26 09:34:10 --> Helper loaded: url_helper
INFO - 2020-02-26 09:34:10 --> Helper loaded: string_helper
INFO - 2020-02-26 09:34:10 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:34:10 --> Controller Class Initialized
INFO - 2020-02-26 09:34:10 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:34:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:34:10 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:34:10 --> Helper loaded: form_helper
INFO - 2020-02-26 09:34:10 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:34:10 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 70
ERROR - 2020-02-26 09:34:10 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 71
ERROR - 2020-02-26 09:34:10 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 72
ERROR - 2020-02-26 09:34:10 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 73
ERROR - 2020-02-26 09:34:10 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 81
ERROR - 2020-02-26 09:34:10 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 82
ERROR - 2020-02-26 09:34:10 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 83
ERROR - 2020-02-26 09:34:10 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow-2\application\models\M_pengunjung.php 84
ERROR - 2020-02-26 09:34:10 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pengunjung` (`nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2020-02-26 09:34:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-26 09:34:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow-2\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow-2\system\core\Common.php 570
INFO - 2020-02-26 09:34:15 --> Config Class Initialized
INFO - 2020-02-26 09:34:15 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:15 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:15 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:15 --> URI Class Initialized
INFO - 2020-02-26 09:34:15 --> Router Class Initialized
INFO - 2020-02-26 09:34:15 --> Output Class Initialized
INFO - 2020-02-26 09:34:15 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:15 --> Input Class Initialized
INFO - 2020-02-26 09:34:15 --> Language Class Initialized
INFO - 2020-02-26 09:34:15 --> Loader Class Initialized
INFO - 2020-02-26 09:34:15 --> Helper loaded: url_helper
INFO - 2020-02-26 09:34:15 --> Helper loaded: string_helper
INFO - 2020-02-26 09:34:15 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:34:15 --> Controller Class Initialized
INFO - 2020-02-26 09:34:15 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:34:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:34:15 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:34:15 --> Helper loaded: form_helper
INFO - 2020-02-26 09:34:15 --> Form Validation Class Initialized
INFO - 2020-02-26 09:34:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:34:16 --> Final output sent to browser
DEBUG - 2020-02-26 09:34:16 --> Total execution time: 0.7458
INFO - 2020-02-26 09:34:16 --> Config Class Initialized
INFO - 2020-02-26 09:34:16 --> Hooks Class Initialized
INFO - 2020-02-26 09:34:16 --> Config Class Initialized
INFO - 2020-02-26 09:34:16 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:16 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:16 --> Utf8 Class Initialized
DEBUG - 2020-02-26 09:34:16 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:16 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:16 --> URI Class Initialized
INFO - 2020-02-26 09:34:16 --> URI Class Initialized
INFO - 2020-02-26 09:34:16 --> Router Class Initialized
INFO - 2020-02-26 09:34:16 --> Router Class Initialized
INFO - 2020-02-26 09:34:16 --> Output Class Initialized
INFO - 2020-02-26 09:34:16 --> Security Class Initialized
INFO - 2020-02-26 09:34:16 --> Output Class Initialized
INFO - 2020-02-26 09:34:16 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:16 --> Input Class Initialized
DEBUG - 2020-02-26 09:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:16 --> Input Class Initialized
INFO - 2020-02-26 09:34:16 --> Language Class Initialized
INFO - 2020-02-26 09:34:16 --> Language Class Initialized
ERROR - 2020-02-26 09:34:16 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 09:34:16 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 09:34:19 --> Config Class Initialized
INFO - 2020-02-26 09:34:20 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:20 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:20 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:20 --> URI Class Initialized
INFO - 2020-02-26 09:34:20 --> Router Class Initialized
INFO - 2020-02-26 09:34:20 --> Output Class Initialized
INFO - 2020-02-26 09:34:20 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:20 --> Input Class Initialized
INFO - 2020-02-26 09:34:20 --> Language Class Initialized
INFO - 2020-02-26 09:34:20 --> Loader Class Initialized
INFO - 2020-02-26 09:34:20 --> Helper loaded: url_helper
INFO - 2020-02-26 09:34:20 --> Helper loaded: string_helper
INFO - 2020-02-26 09:34:20 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:34:20 --> Controller Class Initialized
INFO - 2020-02-26 09:34:20 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:34:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:34:20 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:34:20 --> Helper loaded: form_helper
INFO - 2020-02-26 09:34:20 --> Form Validation Class Initialized
INFO - 2020-02-26 09:34:20 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:34:20 --> Final output sent to browser
DEBUG - 2020-02-26 09:34:20 --> Total execution time: 0.8815
INFO - 2020-02-26 09:34:20 --> Config Class Initialized
INFO - 2020-02-26 09:34:20 --> Config Class Initialized
INFO - 2020-02-26 09:34:20 --> Config Class Initialized
INFO - 2020-02-26 09:34:20 --> Config Class Initialized
INFO - 2020-02-26 09:34:20 --> Hooks Class Initialized
INFO - 2020-02-26 09:34:20 --> Hooks Class Initialized
INFO - 2020-02-26 09:34:20 --> Hooks Class Initialized
INFO - 2020-02-26 09:34:20 --> Config Class Initialized
INFO - 2020-02-26 09:34:20 --> Hooks Class Initialized
INFO - 2020-02-26 09:34:20 --> Config Class Initialized
INFO - 2020-02-26 09:34:20 --> Hooks Class Initialized
INFO - 2020-02-26 09:34:20 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:34:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
DEBUG - 2020-02-26 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:34:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
ERROR - 2020-02-26 09:34:21 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 09:34:21 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 09:34:21 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 09:34:21 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-26 09:34:21 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-26 09:34:21 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 09:34:21 --> Config Class Initialized
INFO - 2020-02-26 09:34:21 --> Config Class Initialized
INFO - 2020-02-26 09:34:21 --> Config Class Initialized
INFO - 2020-02-26 09:34:21 --> Config Class Initialized
INFO - 2020-02-26 09:34:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:34:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:34:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:34:21 --> Config Class Initialized
INFO - 2020-02-26 09:34:21 --> Config Class Initialized
INFO - 2020-02-26 09:34:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:34:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:34:21 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:34:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
DEBUG - 2020-02-26 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:34:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
ERROR - 2020-02-26 09:34:21 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
INFO - 2020-02-26 09:34:21 --> Loader Class Initialized
INFO - 2020-02-26 09:34:21 --> Loader Class Initialized
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
ERROR - 2020-02-26 09:34:21 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 09:34:21 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 09:34:21 --> Helper loaded: url_helper
INFO - 2020-02-26 09:34:21 --> Helper loaded: url_helper
ERROR - 2020-02-26 09:34:21 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 09:34:21 --> Config Class Initialized
INFO - 2020-02-26 09:34:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:34:21 --> Helper loaded: string_helper
INFO - 2020-02-26 09:34:21 --> Helper loaded: string_helper
INFO - 2020-02-26 09:34:21 --> Config Class Initialized
INFO - 2020-02-26 09:34:21 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:21 --> Database Driver Class Initialized
INFO - 2020-02-26 09:34:21 --> Database Driver Class Initialized
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
DEBUG - 2020-02-26 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-26 09:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:34:21 --> Controller Class Initialized
INFO - 2020-02-26 09:34:21 --> Controller Class Initialized
INFO - 2020-02-26 09:34:21 --> URI Class Initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:34:21 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:34:21 --> Router Class Initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:34:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:34:21 --> Output Class Initialized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
INFO - 2020-02-26 09:34:21 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:34:21 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:34:21 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
DEBUG - 2020-02-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:21 --> Helper loaded: form_helper
INFO - 2020-02-26 09:34:21 --> Helper loaded: form_helper
INFO - 2020-02-26 09:34:21 --> Form Validation Class Initialized
INFO - 2020-02-26 09:34:21 --> Form Validation Class Initialized
INFO - 2020-02-26 09:34:21 --> Input Class Initialized
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
INFO - 2020-02-26 09:34:21 --> Language Class Initialized
ERROR - 2020-02-26 09:34:21 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 09:34:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 09:34:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 09:34:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 09:34:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 09:34:21 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 09:34:21 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:34:21 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:34:21 --> Config Class Initialized
INFO - 2020-02-26 09:34:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:34:21 --> Final output sent to browser
INFO - 2020-02-26 09:34:21 --> Final output sent to browser
DEBUG - 2020-02-26 09:34:21 --> Total execution time: 0.6777
DEBUG - 2020-02-26 09:34:21 --> Total execution time: 0.6837
DEBUG - 2020-02-26 09:34:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:22 --> URI Class Initialized
INFO - 2020-02-26 09:34:22 --> Router Class Initialized
INFO - 2020-02-26 09:34:22 --> Output Class Initialized
INFO - 2020-02-26 09:34:22 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:22 --> Input Class Initialized
INFO - 2020-02-26 09:34:22 --> Language Class Initialized
ERROR - 2020-02-26 09:34:22 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 09:34:22 --> Config Class Initialized
INFO - 2020-02-26 09:34:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:22 --> URI Class Initialized
INFO - 2020-02-26 09:34:22 --> Router Class Initialized
INFO - 2020-02-26 09:34:22 --> Output Class Initialized
INFO - 2020-02-26 09:34:22 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:22 --> Input Class Initialized
INFO - 2020-02-26 09:34:22 --> Language Class Initialized
ERROR - 2020-02-26 09:34:22 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 09:34:22 --> Config Class Initialized
INFO - 2020-02-26 09:34:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:22 --> URI Class Initialized
INFO - 2020-02-26 09:34:22 --> Router Class Initialized
INFO - 2020-02-26 09:34:22 --> Output Class Initialized
INFO - 2020-02-26 09:34:22 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:22 --> Input Class Initialized
INFO - 2020-02-26 09:34:22 --> Language Class Initialized
ERROR - 2020-02-26 09:34:22 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 09:34:22 --> Config Class Initialized
INFO - 2020-02-26 09:34:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:22 --> URI Class Initialized
INFO - 2020-02-26 09:34:22 --> Router Class Initialized
INFO - 2020-02-26 09:34:22 --> Output Class Initialized
INFO - 2020-02-26 09:34:22 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:23 --> Input Class Initialized
INFO - 2020-02-26 09:34:23 --> Language Class Initialized
ERROR - 2020-02-26 09:34:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 09:34:23 --> Config Class Initialized
INFO - 2020-02-26 09:34:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:23 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:23 --> URI Class Initialized
INFO - 2020-02-26 09:34:23 --> Router Class Initialized
INFO - 2020-02-26 09:34:23 --> Output Class Initialized
INFO - 2020-02-26 09:34:23 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:23 --> Input Class Initialized
INFO - 2020-02-26 09:34:23 --> Language Class Initialized
ERROR - 2020-02-26 09:34:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 09:34:23 --> Config Class Initialized
INFO - 2020-02-26 09:34:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:23 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:23 --> URI Class Initialized
INFO - 2020-02-26 09:34:23 --> Router Class Initialized
INFO - 2020-02-26 09:34:23 --> Output Class Initialized
INFO - 2020-02-26 09:34:23 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:23 --> Input Class Initialized
INFO - 2020-02-26 09:34:23 --> Language Class Initialized
ERROR - 2020-02-26 09:34:23 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 09:34:23 --> Config Class Initialized
INFO - 2020-02-26 09:34:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:23 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:23 --> URI Class Initialized
INFO - 2020-02-26 09:34:23 --> Router Class Initialized
INFO - 2020-02-26 09:34:23 --> Output Class Initialized
INFO - 2020-02-26 09:34:23 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:23 --> Input Class Initialized
INFO - 2020-02-26 09:34:23 --> Language Class Initialized
ERROR - 2020-02-26 09:34:23 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 09:34:24 --> Config Class Initialized
INFO - 2020-02-26 09:34:24 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:24 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:24 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:24 --> URI Class Initialized
INFO - 2020-02-26 09:34:24 --> Router Class Initialized
INFO - 2020-02-26 09:34:24 --> Output Class Initialized
INFO - 2020-02-26 09:34:24 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:24 --> Input Class Initialized
INFO - 2020-02-26 09:34:24 --> Language Class Initialized
ERROR - 2020-02-26 09:34:24 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 09:34:24 --> Config Class Initialized
INFO - 2020-02-26 09:34:24 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:34:24 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:34:24 --> Utf8 Class Initialized
INFO - 2020-02-26 09:34:24 --> URI Class Initialized
INFO - 2020-02-26 09:34:24 --> Router Class Initialized
INFO - 2020-02-26 09:34:24 --> Output Class Initialized
INFO - 2020-02-26 09:34:24 --> Security Class Initialized
DEBUG - 2020-02-26 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:34:24 --> Input Class Initialized
INFO - 2020-02-26 09:34:24 --> Language Class Initialized
ERROR - 2020-02-26 09:34:24 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 09:41:34 --> Config Class Initialized
INFO - 2020-02-26 09:41:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:41:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:41:34 --> Utf8 Class Initialized
INFO - 2020-02-26 09:41:34 --> URI Class Initialized
INFO - 2020-02-26 09:41:34 --> Router Class Initialized
INFO - 2020-02-26 09:41:34 --> Output Class Initialized
INFO - 2020-02-26 09:41:34 --> Security Class Initialized
DEBUG - 2020-02-26 09:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:41:34 --> Input Class Initialized
INFO - 2020-02-26 09:41:34 --> Language Class Initialized
INFO - 2020-02-26 09:41:34 --> Loader Class Initialized
INFO - 2020-02-26 09:41:34 --> Helper loaded: url_helper
INFO - 2020-02-26 09:41:34 --> Helper loaded: string_helper
INFO - 2020-02-26 09:41:34 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:41:34 --> Controller Class Initialized
INFO - 2020-02-26 09:41:34 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:41:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:41:34 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:41:34 --> Helper loaded: form_helper
INFO - 2020-02-26 09:41:34 --> Form Validation Class Initialized
ERROR - 2020-02-26 15:41:34 --> Severity: Notice --> Undefined variable: kode C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 62
INFO - 2020-02-26 15:41:35 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 15:41:35 --> Final output sent to browser
DEBUG - 2020-02-26 15:41:35 --> Total execution time: 0.9698
INFO - 2020-02-26 09:42:51 --> Config Class Initialized
INFO - 2020-02-26 09:42:51 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:42:51 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:42:51 --> Utf8 Class Initialized
INFO - 2020-02-26 09:42:51 --> URI Class Initialized
INFO - 2020-02-26 09:42:51 --> Router Class Initialized
INFO - 2020-02-26 09:42:51 --> Output Class Initialized
INFO - 2020-02-26 09:42:51 --> Security Class Initialized
DEBUG - 2020-02-26 09:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:42:51 --> Input Class Initialized
INFO - 2020-02-26 09:42:51 --> Language Class Initialized
INFO - 2020-02-26 09:42:51 --> Loader Class Initialized
INFO - 2020-02-26 09:42:51 --> Helper loaded: url_helper
INFO - 2020-02-26 09:42:51 --> Helper loaded: string_helper
INFO - 2020-02-26 09:42:51 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:42:51 --> Controller Class Initialized
INFO - 2020-02-26 09:42:51 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:42:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:42:51 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:42:51 --> Helper loaded: form_helper
INFO - 2020-02-26 09:42:51 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:42:51 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow-2\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 55
INFO - 2020-02-26 09:44:58 --> Config Class Initialized
INFO - 2020-02-26 09:44:58 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:44:58 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:44:58 --> Utf8 Class Initialized
INFO - 2020-02-26 09:44:58 --> URI Class Initialized
INFO - 2020-02-26 09:44:58 --> Router Class Initialized
INFO - 2020-02-26 09:44:58 --> Output Class Initialized
INFO - 2020-02-26 09:44:58 --> Security Class Initialized
DEBUG - 2020-02-26 09:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:44:58 --> Input Class Initialized
INFO - 2020-02-26 09:44:58 --> Language Class Initialized
INFO - 2020-02-26 09:44:58 --> Loader Class Initialized
INFO - 2020-02-26 09:44:58 --> Helper loaded: url_helper
INFO - 2020-02-26 09:44:59 --> Helper loaded: string_helper
INFO - 2020-02-26 09:44:59 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:44:59 --> Controller Class Initialized
INFO - 2020-02-26 09:44:59 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:44:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:44:59 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:44:59 --> Helper loaded: form_helper
INFO - 2020-02-26 09:44:59 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:44:59 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow-2\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 55
INFO - 2020-02-26 09:45:36 --> Config Class Initialized
INFO - 2020-02-26 09:45:36 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:45:36 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:45:36 --> Utf8 Class Initialized
INFO - 2020-02-26 09:45:36 --> URI Class Initialized
INFO - 2020-02-26 09:45:36 --> Router Class Initialized
INFO - 2020-02-26 09:45:36 --> Output Class Initialized
INFO - 2020-02-26 09:45:36 --> Security Class Initialized
DEBUG - 2020-02-26 09:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:45:36 --> Input Class Initialized
INFO - 2020-02-26 09:45:36 --> Language Class Initialized
INFO - 2020-02-26 09:45:36 --> Loader Class Initialized
INFO - 2020-02-26 09:45:37 --> Helper loaded: url_helper
INFO - 2020-02-26 09:45:37 --> Helper loaded: string_helper
INFO - 2020-02-26 09:45:37 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:45:37 --> Controller Class Initialized
INFO - 2020-02-26 09:45:37 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:45:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:45:37 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:45:37 --> Helper loaded: form_helper
INFO - 2020-02-26 09:45:37 --> Form Validation Class Initialized
INFO - 2020-02-26 09:45:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:45:37 --> Final output sent to browser
DEBUG - 2020-02-26 09:45:37 --> Total execution time: 0.9333
INFO - 2020-02-26 09:45:42 --> Config Class Initialized
INFO - 2020-02-26 09:45:42 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:45:42 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:45:43 --> Utf8 Class Initialized
INFO - 2020-02-26 09:45:43 --> URI Class Initialized
INFO - 2020-02-26 09:45:43 --> Router Class Initialized
INFO - 2020-02-26 09:45:43 --> Output Class Initialized
INFO - 2020-02-26 09:45:43 --> Security Class Initialized
DEBUG - 2020-02-26 09:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:45:43 --> Input Class Initialized
INFO - 2020-02-26 09:45:43 --> Language Class Initialized
INFO - 2020-02-26 09:45:43 --> Loader Class Initialized
INFO - 2020-02-26 09:45:43 --> Helper loaded: url_helper
INFO - 2020-02-26 09:45:43 --> Helper loaded: string_helper
INFO - 2020-02-26 09:45:43 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:45:43 --> Controller Class Initialized
INFO - 2020-02-26 09:45:43 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:45:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:45:44 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:45:44 --> Helper loaded: form_helper
INFO - 2020-02-26 09:45:44 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:45:44 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow-2\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 55
INFO - 2020-02-26 09:48:08 --> Config Class Initialized
INFO - 2020-02-26 09:48:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:08 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:08 --> URI Class Initialized
INFO - 2020-02-26 09:48:08 --> Router Class Initialized
INFO - 2020-02-26 09:48:08 --> Output Class Initialized
INFO - 2020-02-26 09:48:08 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:08 --> Input Class Initialized
INFO - 2020-02-26 09:48:08 --> Language Class Initialized
INFO - 2020-02-26 09:48:08 --> Loader Class Initialized
INFO - 2020-02-26 09:48:08 --> Helper loaded: url_helper
INFO - 2020-02-26 09:48:08 --> Helper loaded: string_helper
INFO - 2020-02-26 09:48:08 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:48:08 --> Controller Class Initialized
INFO - 2020-02-26 09:48:08 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:48:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:48:08 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:48:08 --> Helper loaded: form_helper
INFO - 2020-02-26 09:48:08 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:48:08 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow-2\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 55
INFO - 2020-02-26 09:48:13 --> Config Class Initialized
INFO - 2020-02-26 09:48:13 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:13 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:13 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:13 --> URI Class Initialized
INFO - 2020-02-26 09:48:13 --> Router Class Initialized
INFO - 2020-02-26 09:48:13 --> Output Class Initialized
INFO - 2020-02-26 09:48:13 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:13 --> Input Class Initialized
INFO - 2020-02-26 09:48:13 --> Language Class Initialized
INFO - 2020-02-26 09:48:14 --> Loader Class Initialized
INFO - 2020-02-26 09:48:14 --> Helper loaded: url_helper
INFO - 2020-02-26 09:48:14 --> Helper loaded: string_helper
INFO - 2020-02-26 09:48:14 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:48:14 --> Controller Class Initialized
INFO - 2020-02-26 09:48:14 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:48:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:48:14 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:48:14 --> Helper loaded: form_helper
INFO - 2020-02-26 09:48:14 --> Form Validation Class Initialized
INFO - 2020-02-26 09:48:14 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:48:14 --> Final output sent to browser
DEBUG - 2020-02-26 09:48:14 --> Total execution time: 0.7914
INFO - 2020-02-26 09:48:14 --> Config Class Initialized
INFO - 2020-02-26 09:48:14 --> Hooks Class Initialized
INFO - 2020-02-26 09:48:14 --> Config Class Initialized
INFO - 2020-02-26 09:48:14 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:14 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:14 --> Utf8 Class Initialized
DEBUG - 2020-02-26 09:48:14 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:14 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:14 --> URI Class Initialized
INFO - 2020-02-26 09:48:14 --> URI Class Initialized
INFO - 2020-02-26 09:48:14 --> Router Class Initialized
INFO - 2020-02-26 09:48:14 --> Router Class Initialized
INFO - 2020-02-26 09:48:14 --> Output Class Initialized
INFO - 2020-02-26 09:48:14 --> Security Class Initialized
INFO - 2020-02-26 09:48:14 --> Output Class Initialized
INFO - 2020-02-26 09:48:14 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:14 --> Input Class Initialized
DEBUG - 2020-02-26 09:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:14 --> Input Class Initialized
INFO - 2020-02-26 09:48:14 --> Language Class Initialized
INFO - 2020-02-26 09:48:14 --> Language Class Initialized
INFO - 2020-02-26 09:48:14 --> Loader Class Initialized
INFO - 2020-02-26 09:48:14 --> Helper loaded: url_helper
INFO - 2020-02-26 09:48:14 --> Loader Class Initialized
INFO - 2020-02-26 09:48:14 --> Helper loaded: string_helper
INFO - 2020-02-26 09:48:14 --> Helper loaded: url_helper
INFO - 2020-02-26 09:48:14 --> Helper loaded: string_helper
INFO - 2020-02-26 09:48:14 --> Database Driver Class Initialized
INFO - 2020-02-26 09:48:14 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:48:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-26 09:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:48:14 --> Controller Class Initialized
INFO - 2020-02-26 09:48:14 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:48:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:48:14 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:48:15 --> Helper loaded: form_helper
INFO - 2020-02-26 09:48:15 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:48:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 09:48:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 09:48:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:48:15 --> Final output sent to browser
DEBUG - 2020-02-26 09:48:15 --> Total execution time: 0.7009
INFO - 2020-02-26 09:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:48:15 --> Controller Class Initialized
INFO - 2020-02-26 09:48:15 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:48:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:48:15 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:48:15 --> Helper loaded: form_helper
INFO - 2020-02-26 09:48:15 --> Form Validation Class Initialized
ERROR - 2020-02-26 09:48:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 09:48:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 09:48:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:48:15 --> Final output sent to browser
DEBUG - 2020-02-26 09:48:15 --> Total execution time: 0.9215
INFO - 2020-02-26 09:48:20 --> Config Class Initialized
INFO - 2020-02-26 09:48:20 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:20 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:20 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:20 --> URI Class Initialized
INFO - 2020-02-26 09:48:20 --> Router Class Initialized
INFO - 2020-02-26 09:48:20 --> Output Class Initialized
INFO - 2020-02-26 09:48:20 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:20 --> Input Class Initialized
INFO - 2020-02-26 09:48:20 --> Language Class Initialized
INFO - 2020-02-26 09:48:20 --> Loader Class Initialized
INFO - 2020-02-26 09:48:20 --> Helper loaded: url_helper
INFO - 2020-02-26 09:48:20 --> Helper loaded: string_helper
INFO - 2020-02-26 09:48:20 --> Database Driver Class Initialized
DEBUG - 2020-02-26 09:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:48:21 --> Controller Class Initialized
INFO - 2020-02-26 09:48:21 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:48:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:48:21 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:48:21 --> Helper loaded: form_helper
INFO - 2020-02-26 09:48:21 --> Form Validation Class Initialized
INFO - 2020-02-26 09:48:21 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:48:21 --> Final output sent to browser
DEBUG - 2020-02-26 09:48:21 --> Total execution time: 0.7786
INFO - 2020-02-26 09:48:21 --> Config Class Initialized
INFO - 2020-02-26 09:48:21 --> Config Class Initialized
INFO - 2020-02-26 09:48:21 --> Config Class Initialized
INFO - 2020-02-26 09:48:21 --> Config Class Initialized
INFO - 2020-02-26 09:48:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:48:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:48:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:48:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:48:21 --> Config Class Initialized
INFO - 2020-02-26 09:48:21 --> Config Class Initialized
INFO - 2020-02-26 09:48:21 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:48:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:21 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:48:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:21 --> Utf8 Class Initialized
DEBUG - 2020-02-26 09:48:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:21 --> URI Class Initialized
INFO - 2020-02-26 09:48:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:21 --> URI Class Initialized
INFO - 2020-02-26 09:48:21 --> Router Class Initialized
INFO - 2020-02-26 09:48:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:21 --> Utf8 Class Initialized
DEBUG - 2020-02-26 09:48:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:21 --> URI Class Initialized
INFO - 2020-02-26 09:48:21 --> Router Class Initialized
INFO - 2020-02-26 09:48:21 --> URI Class Initialized
INFO - 2020-02-26 09:48:21 --> URI Class Initialized
INFO - 2020-02-26 09:48:21 --> Output Class Initialized
INFO - 2020-02-26 09:48:21 --> URI Class Initialized
INFO - 2020-02-26 09:48:21 --> Security Class Initialized
INFO - 2020-02-26 09:48:21 --> Router Class Initialized
INFO - 2020-02-26 09:48:21 --> Router Class Initialized
INFO - 2020-02-26 09:48:21 --> Router Class Initialized
INFO - 2020-02-26 09:48:21 --> Output Class Initialized
DEBUG - 2020-02-26 09:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:21 --> Router Class Initialized
INFO - 2020-02-26 09:48:21 --> Output Class Initialized
INFO - 2020-02-26 09:48:21 --> Output Class Initialized
INFO - 2020-02-26 09:48:21 --> Security Class Initialized
INFO - 2020-02-26 09:48:21 --> Output Class Initialized
INFO - 2020-02-26 09:48:21 --> Input Class Initialized
DEBUG - 2020-02-26 09:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:21 --> Security Class Initialized
INFO - 2020-02-26 09:48:21 --> Security Class Initialized
INFO - 2020-02-26 09:48:21 --> Output Class Initialized
INFO - 2020-02-26 09:48:21 --> Security Class Initialized
INFO - 2020-02-26 09:48:21 --> Input Class Initialized
INFO - 2020-02-26 09:48:21 --> Language Class Initialized
DEBUG - 2020-02-26 09:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 09:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:21 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:21 --> Input Class Initialized
INFO - 2020-02-26 09:48:21 --> Input Class Initialized
INFO - 2020-02-26 09:48:21 --> Input Class Initialized
ERROR - 2020-02-26 09:48:21 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-26 09:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:21 --> Language Class Initialized
INFO - 2020-02-26 09:48:21 --> Input Class Initialized
INFO - 2020-02-26 09:48:21 --> Language Class Initialized
ERROR - 2020-02-26 09:48:21 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 09:48:21 --> Language Class Initialized
INFO - 2020-02-26 09:48:21 --> Language Class Initialized
INFO - 2020-02-26 09:48:21 --> Config Class Initialized
INFO - 2020-02-26 09:48:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:48:21 --> Language Class Initialized
ERROR - 2020-02-26 09:48:21 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-26 09:48:21 --> Loader Class Initialized
INFO - 2020-02-26 09:48:21 --> Loader Class Initialized
INFO - 2020-02-26 09:48:21 --> Config Class Initialized
INFO - 2020-02-26 09:48:21 --> Hooks Class Initialized
ERROR - 2020-02-26 09:48:21 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 09:48:21 --> Helper loaded: url_helper
DEBUG - 2020-02-26 09:48:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:21 --> Helper loaded: url_helper
INFO - 2020-02-26 09:48:21 --> Config Class Initialized
INFO - 2020-02-26 09:48:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:48:21 --> Helper loaded: string_helper
INFO - 2020-02-26 09:48:21 --> Helper loaded: string_helper
DEBUG - 2020-02-26 09:48:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:21 --> Config Class Initialized
INFO - 2020-02-26 09:48:21 --> Hooks Class Initialized
INFO - 2020-02-26 09:48:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:21 --> URI Class Initialized
DEBUG - 2020-02-26 09:48:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:21 --> Database Driver Class Initialized
INFO - 2020-02-26 09:48:21 --> Database Driver Class Initialized
INFO - 2020-02-26 09:48:21 --> Router Class Initialized
INFO - 2020-02-26 09:48:21 --> Utf8 Class Initialized
DEBUG - 2020-02-26 09:48:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:21 --> URI Class Initialized
DEBUG - 2020-02-26 09:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-26 09:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 09:48:21 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:48:21 --> Output Class Initialized
INFO - 2020-02-26 09:48:21 --> URI Class Initialized
INFO - 2020-02-26 09:48:21 --> Router Class Initialized
INFO - 2020-02-26 09:48:21 --> Controller Class Initialized
INFO - 2020-02-26 09:48:21 --> URI Class Initialized
INFO - 2020-02-26 09:48:21 --> Output Class Initialized
INFO - 2020-02-26 09:48:21 --> Security Class Initialized
INFO - 2020-02-26 09:48:21 --> Router Class Initialized
INFO - 2020-02-26 09:48:21 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:48:21 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:21 --> Router Class Initialized
INFO - 2020-02-26 09:48:21 --> Output Class Initialized
INFO - 2020-02-26 09:48:22 --> Input Class Initialized
INFO - 2020-02-26 09:48:22 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-26 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:22 --> Security Class Initialized
INFO - 2020-02-26 09:48:22 --> Output Class Initialized
INFO - 2020-02-26 09:48:22 --> Input Class Initialized
DEBUG - 2020-02-26 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:22 --> Security Class Initialized
INFO - 2020-02-26 09:48:22 --> Language Class Initialized
INFO - 2020-02-26 09:48:22 --> Model "M_pesan" initialized
INFO - 2020-02-26 09:48:22 --> Input Class Initialized
INFO - 2020-02-26 09:48:22 --> Language Class Initialized
DEBUG - 2020-02-26 09:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-26 09:48:22 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 09:48:22 --> Helper loaded: form_helper
INFO - 2020-02-26 09:48:22 --> Form Validation Class Initialized
INFO - 2020-02-26 09:48:22 --> Input Class Initialized
INFO - 2020-02-26 09:48:22 --> Language Class Initialized
ERROR - 2020-02-26 09:48:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 09:48:22 --> Config Class Initialized
INFO - 2020-02-26 09:48:22 --> Hooks Class Initialized
INFO - 2020-02-26 09:48:22 --> Language Class Initialized
ERROR - 2020-02-26 09:48:22 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 09:48:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 09:48:22 --> Config Class Initialized
INFO - 2020-02-26 09:48:22 --> Hooks Class Initialized
ERROR - 2020-02-26 09:48:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 09:48:22 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-26 09:48:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:22 --> Config Class Initialized
INFO - 2020-02-26 09:48:22 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:48:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:22 --> Config Class Initialized
INFO - 2020-02-26 09:48:22 --> Hooks Class Initialized
INFO - 2020-02-26 09:48:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:22 --> Final output sent to browser
INFO - 2020-02-26 09:48:22 --> URI Class Initialized
DEBUG - 2020-02-26 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 09:48:22 --> Total execution time: 0.9317
INFO - 2020-02-26 09:48:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:22 --> URI Class Initialized
INFO - 2020-02-26 09:48:22 --> Router Class Initialized
DEBUG - 2020-02-26 09:48:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 09:48:22 --> URI Class Initialized
INFO - 2020-02-26 09:48:22 --> Router Class Initialized
INFO - 2020-02-26 09:48:22 --> Output Class Initialized
INFO - 2020-02-26 09:48:22 --> URI Class Initialized
INFO - 2020-02-26 09:48:22 --> Controller Class Initialized
INFO - 2020-02-26 09:48:22 --> Router Class Initialized
INFO - 2020-02-26 09:48:22 --> Output Class Initialized
INFO - 2020-02-26 09:48:22 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:22 --> Security Class Initialized
INFO - 2020-02-26 09:48:22 --> Router Class Initialized
INFO - 2020-02-26 09:48:22 --> Output Class Initialized
INFO - 2020-02-26 09:48:22 --> Model "M_tiket" initialized
INFO - 2020-02-26 09:48:22 --> Input Class Initialized
DEBUG - 2020-02-26 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:22 --> Security Class Initialized
INFO - 2020-02-26 09:48:22 --> Output Class Initialized
INFO - 2020-02-26 09:48:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 09:48:22 --> Input Class Initialized
INFO - 2020-02-26 09:48:22 --> Language Class Initialized
INFO - 2020-02-26 09:48:22 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:22 --> Security Class Initialized
INFO - 2020-02-26 09:48:22 --> Input Class Initialized
ERROR - 2020-02-26 09:48:22 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-26 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:22 --> Language Class Initialized
INFO - 2020-02-26 09:48:22 --> Helper loaded: form_helper
INFO - 2020-02-26 09:48:22 --> Form Validation Class Initialized
INFO - 2020-02-26 09:48:22 --> Input Class Initialized
INFO - 2020-02-26 09:48:22 --> Language Class Initialized
ERROR - 2020-02-26 09:48:22 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 09:48:22 --> Language Class Initialized
ERROR - 2020-02-26 09:48:22 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 09:48:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 09:48:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 09:48:22 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 09:48:22 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 09:48:22 --> Config Class Initialized
INFO - 2020-02-26 09:48:22 --> Hooks Class Initialized
INFO - 2020-02-26 09:48:22 --> Final output sent to browser
DEBUG - 2020-02-26 09:48:22 --> Total execution time: 1.2486
DEBUG - 2020-02-26 09:48:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:22 --> URI Class Initialized
INFO - 2020-02-26 09:48:22 --> Router Class Initialized
INFO - 2020-02-26 09:48:22 --> Output Class Initialized
INFO - 2020-02-26 09:48:22 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:22 --> Input Class Initialized
INFO - 2020-02-26 09:48:22 --> Language Class Initialized
ERROR - 2020-02-26 09:48:22 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 09:48:22 --> Config Class Initialized
INFO - 2020-02-26 09:48:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:22 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:22 --> URI Class Initialized
INFO - 2020-02-26 09:48:23 --> Router Class Initialized
INFO - 2020-02-26 09:48:23 --> Output Class Initialized
INFO - 2020-02-26 09:48:23 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:23 --> Input Class Initialized
INFO - 2020-02-26 09:48:23 --> Language Class Initialized
ERROR - 2020-02-26 09:48:23 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 09:48:23 --> Config Class Initialized
INFO - 2020-02-26 09:48:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:23 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:23 --> URI Class Initialized
INFO - 2020-02-26 09:48:23 --> Router Class Initialized
INFO - 2020-02-26 09:48:23 --> Output Class Initialized
INFO - 2020-02-26 09:48:23 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:23 --> Input Class Initialized
INFO - 2020-02-26 09:48:23 --> Language Class Initialized
ERROR - 2020-02-26 09:48:23 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 09:48:23 --> Config Class Initialized
INFO - 2020-02-26 09:48:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:23 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:23 --> URI Class Initialized
INFO - 2020-02-26 09:48:23 --> Router Class Initialized
INFO - 2020-02-26 09:48:23 --> Output Class Initialized
INFO - 2020-02-26 09:48:23 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:23 --> Input Class Initialized
INFO - 2020-02-26 09:48:23 --> Language Class Initialized
ERROR - 2020-02-26 09:48:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 09:48:23 --> Config Class Initialized
INFO - 2020-02-26 09:48:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:23 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:23 --> URI Class Initialized
INFO - 2020-02-26 09:48:23 --> Router Class Initialized
INFO - 2020-02-26 09:48:23 --> Output Class Initialized
INFO - 2020-02-26 09:48:23 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:24 --> Input Class Initialized
INFO - 2020-02-26 09:48:24 --> Language Class Initialized
ERROR - 2020-02-26 09:48:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 09:48:24 --> Config Class Initialized
INFO - 2020-02-26 09:48:24 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:24 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:24 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:24 --> URI Class Initialized
INFO - 2020-02-26 09:48:24 --> Router Class Initialized
INFO - 2020-02-26 09:48:24 --> Output Class Initialized
INFO - 2020-02-26 09:48:24 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:24 --> Input Class Initialized
INFO - 2020-02-26 09:48:24 --> Language Class Initialized
ERROR - 2020-02-26 09:48:24 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 09:48:24 --> Config Class Initialized
INFO - 2020-02-26 09:48:24 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:24 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:24 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:24 --> URI Class Initialized
INFO - 2020-02-26 09:48:24 --> Router Class Initialized
INFO - 2020-02-26 09:48:24 --> Output Class Initialized
INFO - 2020-02-26 09:48:24 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:24 --> Input Class Initialized
INFO - 2020-02-26 09:48:24 --> Language Class Initialized
ERROR - 2020-02-26 09:48:24 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 09:48:24 --> Config Class Initialized
INFO - 2020-02-26 09:48:24 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:24 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:24 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:24 --> URI Class Initialized
INFO - 2020-02-26 09:48:24 --> Router Class Initialized
INFO - 2020-02-26 09:48:24 --> Output Class Initialized
INFO - 2020-02-26 09:48:24 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:24 --> Input Class Initialized
INFO - 2020-02-26 09:48:24 --> Language Class Initialized
ERROR - 2020-02-26 09:48:24 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 09:48:25 --> Config Class Initialized
INFO - 2020-02-26 09:48:25 --> Hooks Class Initialized
DEBUG - 2020-02-26 09:48:25 --> UTF-8 Support Enabled
INFO - 2020-02-26 09:48:25 --> Utf8 Class Initialized
INFO - 2020-02-26 09:48:25 --> URI Class Initialized
INFO - 2020-02-26 09:48:25 --> Router Class Initialized
INFO - 2020-02-26 09:48:25 --> Output Class Initialized
INFO - 2020-02-26 09:48:25 --> Security Class Initialized
DEBUG - 2020-02-26 09:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 09:48:25 --> Input Class Initialized
INFO - 2020-02-26 09:48:25 --> Language Class Initialized
ERROR - 2020-02-26 09:48:25 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 10:22:05 --> Config Class Initialized
INFO - 2020-02-26 10:22:05 --> Hooks Class Initialized
DEBUG - 2020-02-26 10:22:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 10:22:05 --> Utf8 Class Initialized
INFO - 2020-02-26 10:22:05 --> URI Class Initialized
INFO - 2020-02-26 10:22:05 --> Router Class Initialized
INFO - 2020-02-26 10:22:05 --> Output Class Initialized
INFO - 2020-02-26 10:22:05 --> Security Class Initialized
DEBUG - 2020-02-26 10:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 10:22:06 --> Input Class Initialized
INFO - 2020-02-26 10:22:06 --> Language Class Initialized
INFO - 2020-02-26 10:22:06 --> Loader Class Initialized
INFO - 2020-02-26 10:22:06 --> Helper loaded: url_helper
INFO - 2020-02-26 10:22:06 --> Helper loaded: string_helper
INFO - 2020-02-26 10:22:06 --> Database Driver Class Initialized
DEBUG - 2020-02-26 10:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 10:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 10:22:06 --> Controller Class Initialized
INFO - 2020-02-26 10:22:06 --> Model "M_tiket" initialized
INFO - 2020-02-26 10:22:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 10:22:06 --> Model "M_pesan" initialized
INFO - 2020-02-26 10:22:06 --> Helper loaded: form_helper
INFO - 2020-02-26 10:22:06 --> Form Validation Class Initialized
INFO - 2020-02-26 16:22:07 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 16:22:07 --> Final output sent to browser
DEBUG - 2020-02-26 16:22:07 --> Total execution time: 2.1167
INFO - 2020-02-26 10:32:52 --> Config Class Initialized
INFO - 2020-02-26 10:32:52 --> Hooks Class Initialized
DEBUG - 2020-02-26 10:32:52 --> UTF-8 Support Enabled
INFO - 2020-02-26 10:32:52 --> Utf8 Class Initialized
INFO - 2020-02-26 10:32:52 --> URI Class Initialized
INFO - 2020-02-26 10:32:52 --> Router Class Initialized
INFO - 2020-02-26 10:32:52 --> Output Class Initialized
INFO - 2020-02-26 10:32:52 --> Security Class Initialized
DEBUG - 2020-02-26 10:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 10:32:52 --> Input Class Initialized
INFO - 2020-02-26 10:32:52 --> Language Class Initialized
INFO - 2020-02-26 10:32:52 --> Loader Class Initialized
INFO - 2020-02-26 10:32:52 --> Helper loaded: url_helper
INFO - 2020-02-26 10:32:52 --> Helper loaded: string_helper
INFO - 2020-02-26 10:32:52 --> Database Driver Class Initialized
DEBUG - 2020-02-26 10:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 10:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 10:32:52 --> Controller Class Initialized
INFO - 2020-02-26 10:32:52 --> Model "M_tiket" initialized
INFO - 2020-02-26 10:32:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 10:32:52 --> Model "M_pesan" initialized
INFO - 2020-02-26 10:32:52 --> Helper loaded: form_helper
INFO - 2020-02-26 10:32:52 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:32:53 --> Severity: Notice --> Undefined variable: kodepemesanan C:\xampp\htdocs\roadshow-2\application\views\Pemesanan\konfirm_bayar.php 3
INFO - 2020-02-26 16:32:53 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 16:32:53 --> Final output sent to browser
DEBUG - 2020-02-26 16:32:53 --> Total execution time: 1.0679
INFO - 2020-02-26 10:33:14 --> Config Class Initialized
INFO - 2020-02-26 10:33:14 --> Hooks Class Initialized
DEBUG - 2020-02-26 10:33:14 --> UTF-8 Support Enabled
INFO - 2020-02-26 10:33:14 --> Utf8 Class Initialized
INFO - 2020-02-26 10:33:14 --> URI Class Initialized
INFO - 2020-02-26 10:33:14 --> Router Class Initialized
INFO - 2020-02-26 10:33:14 --> Output Class Initialized
INFO - 2020-02-26 10:33:14 --> Security Class Initialized
DEBUG - 2020-02-26 10:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 10:33:14 --> Input Class Initialized
INFO - 2020-02-26 10:33:14 --> Language Class Initialized
INFO - 2020-02-26 10:33:14 --> Loader Class Initialized
INFO - 2020-02-26 10:33:14 --> Helper loaded: url_helper
INFO - 2020-02-26 10:33:14 --> Helper loaded: string_helper
INFO - 2020-02-26 10:33:14 --> Database Driver Class Initialized
DEBUG - 2020-02-26 10:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 10:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 10:33:15 --> Controller Class Initialized
INFO - 2020-02-26 10:33:15 --> Model "M_tiket" initialized
INFO - 2020-02-26 10:33:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 10:33:15 --> Model "M_pesan" initialized
INFO - 2020-02-26 10:33:15 --> Helper loaded: form_helper
INFO - 2020-02-26 10:33:15 --> Form Validation Class Initialized
INFO - 2020-02-26 16:33:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 16:33:15 --> Final output sent to browser
DEBUG - 2020-02-26 16:33:15 --> Total execution time: 0.5799
INFO - 2020-02-26 10:47:15 --> Config Class Initialized
INFO - 2020-02-26 10:47:16 --> Hooks Class Initialized
DEBUG - 2020-02-26 10:47:16 --> UTF-8 Support Enabled
INFO - 2020-02-26 10:47:16 --> Utf8 Class Initialized
INFO - 2020-02-26 10:47:16 --> URI Class Initialized
INFO - 2020-02-26 10:47:16 --> Router Class Initialized
INFO - 2020-02-26 10:47:16 --> Output Class Initialized
INFO - 2020-02-26 10:47:16 --> Security Class Initialized
DEBUG - 2020-02-26 10:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 10:47:16 --> Input Class Initialized
INFO - 2020-02-26 10:47:16 --> Language Class Initialized
INFO - 2020-02-26 10:47:16 --> Loader Class Initialized
INFO - 2020-02-26 10:47:16 --> Helper loaded: url_helper
INFO - 2020-02-26 10:47:16 --> Helper loaded: string_helper
INFO - 2020-02-26 10:47:17 --> Database Driver Class Initialized
DEBUG - 2020-02-26 10:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 10:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 10:47:17 --> Controller Class Initialized
INFO - 2020-02-26 10:47:17 --> Model "M_tiket" initialized
INFO - 2020-02-26 10:47:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 10:47:17 --> Model "M_pesan" initialized
INFO - 2020-02-26 10:47:17 --> Helper loaded: form_helper
INFO - 2020-02-26 10:47:17 --> Form Validation Class Initialized
INFO - 2020-02-26 16:47:17 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 16:47:17 --> Final output sent to browser
DEBUG - 2020-02-26 16:47:17 --> Total execution time: 1.8514
INFO - 2020-02-26 11:05:08 --> Config Class Initialized
INFO - 2020-02-26 11:05:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:05:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:08 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:08 --> URI Class Initialized
INFO - 2020-02-26 11:05:09 --> Router Class Initialized
INFO - 2020-02-26 11:05:09 --> Output Class Initialized
INFO - 2020-02-26 11:05:09 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:09 --> Input Class Initialized
INFO - 2020-02-26 11:05:09 --> Language Class Initialized
INFO - 2020-02-26 11:05:09 --> Loader Class Initialized
INFO - 2020-02-26 11:05:09 --> Helper loaded: url_helper
INFO - 2020-02-26 11:05:09 --> Helper loaded: string_helper
INFO - 2020-02-26 11:05:09 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:05:09 --> Controller Class Initialized
INFO - 2020-02-26 11:05:09 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:05:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:05:09 --> Model "M_pesan" initialized
INFO - 2020-02-26 11:05:09 --> Helper loaded: form_helper
INFO - 2020-02-26 11:05:09 --> Form Validation Class Initialized
ERROR - 2020-02-26 11:05:09 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 42
INFO - 2020-02-26 11:05:09 --> Config Class Initialized
INFO - 2020-02-26 11:05:09 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:05:10 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:10 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:10 --> URI Class Initialized
INFO - 2020-02-26 11:05:10 --> Router Class Initialized
INFO - 2020-02-26 11:05:10 --> Output Class Initialized
INFO - 2020-02-26 11:05:10 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:10 --> Input Class Initialized
INFO - 2020-02-26 11:05:10 --> Language Class Initialized
INFO - 2020-02-26 11:05:10 --> Loader Class Initialized
INFO - 2020-02-26 11:05:10 --> Helper loaded: url_helper
INFO - 2020-02-26 11:05:10 --> Helper loaded: string_helper
INFO - 2020-02-26 11:05:10 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:05:10 --> Controller Class Initialized
INFO - 2020-02-26 11:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 11:05:10 --> Pagination Class Initialized
INFO - 2020-02-26 11:05:10 --> Model "M_show" initialized
INFO - 2020-02-26 11:05:10 --> Helper loaded: form_helper
INFO - 2020-02-26 11:05:10 --> Form Validation Class Initialized
INFO - 2020-02-26 11:05:10 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 11:05:10 --> Final output sent to browser
DEBUG - 2020-02-26 11:05:10 --> Total execution time: 0.6473
INFO - 2020-02-26 11:05:10 --> Config Class Initialized
INFO - 2020-02-26 11:05:10 --> Config Class Initialized
INFO - 2020-02-26 11:05:10 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:10 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:05:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:05:10 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:10 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:10 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:10 --> URI Class Initialized
INFO - 2020-02-26 11:05:10 --> URI Class Initialized
INFO - 2020-02-26 11:05:10 --> Router Class Initialized
INFO - 2020-02-26 11:05:10 --> Router Class Initialized
INFO - 2020-02-26 11:05:10 --> Output Class Initialized
INFO - 2020-02-26 11:05:10 --> Output Class Initialized
INFO - 2020-02-26 11:05:11 --> Security Class Initialized
INFO - 2020-02-26 11:05:11 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:11 --> Input Class Initialized
INFO - 2020-02-26 11:05:11 --> Input Class Initialized
INFO - 2020-02-26 11:05:11 --> Language Class Initialized
INFO - 2020-02-26 11:05:11 --> Language Class Initialized
ERROR - 2020-02-26 11:05:11 --> 404 Page Not Found: Show/assets
ERROR - 2020-02-26 11:05:11 --> 404 Page Not Found: Show/assets
INFO - 2020-02-26 11:05:31 --> Config Class Initialized
INFO - 2020-02-26 11:05:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:05:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:31 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:31 --> URI Class Initialized
INFO - 2020-02-26 11:05:31 --> Router Class Initialized
INFO - 2020-02-26 11:05:31 --> Output Class Initialized
INFO - 2020-02-26 11:05:31 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:31 --> Input Class Initialized
INFO - 2020-02-26 11:05:31 --> Language Class Initialized
INFO - 2020-02-26 11:05:31 --> Loader Class Initialized
INFO - 2020-02-26 11:05:31 --> Helper loaded: url_helper
INFO - 2020-02-26 11:05:31 --> Helper loaded: string_helper
INFO - 2020-02-26 11:05:31 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:05:31 --> Controller Class Initialized
INFO - 2020-02-26 11:05:31 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:05:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:05:31 --> Model "M_pesan" initialized
INFO - 2020-02-26 11:05:31 --> Helper loaded: form_helper
INFO - 2020-02-26 11:05:31 --> Form Validation Class Initialized
INFO - 2020-02-26 11:05:31 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 11:05:31 --> Final output sent to browser
DEBUG - 2020-02-26 11:05:31 --> Total execution time: 0.6020
INFO - 2020-02-26 11:05:31 --> Config Class Initialized
INFO - 2020-02-26 11:05:31 --> Config Class Initialized
INFO - 2020-02-26 11:05:31 --> Config Class Initialized
INFO - 2020-02-26 11:05:31 --> Config Class Initialized
INFO - 2020-02-26 11:05:31 --> Config Class Initialized
INFO - 2020-02-26 11:05:31 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:31 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:31 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:31 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:31 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:31 --> Config Class Initialized
INFO - 2020-02-26 11:05:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:05:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:05:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:05:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:05:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:05:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:31 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:31 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:31 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:31 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:31 --> Utf8 Class Initialized
DEBUG - 2020-02-26 11:05:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:31 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:31 --> URI Class Initialized
INFO - 2020-02-26 11:05:31 --> URI Class Initialized
INFO - 2020-02-26 11:05:31 --> URI Class Initialized
INFO - 2020-02-26 11:05:31 --> URI Class Initialized
INFO - 2020-02-26 11:05:31 --> URI Class Initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> URI Class Initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
ERROR - 2020-02-26 11:05:32 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-26 11:05:32 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-26 11:05:32 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 11:05:32 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 11:05:32 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 11:05:32 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 11:05:32 --> Config Class Initialized
INFO - 2020-02-26 11:05:32 --> Config Class Initialized
INFO - 2020-02-26 11:05:32 --> Config Class Initialized
INFO - 2020-02-26 11:05:32 --> Config Class Initialized
INFO - 2020-02-26 11:05:32 --> Config Class Initialized
INFO - 2020-02-26 11:05:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:32 --> Config Class Initialized
INFO - 2020-02-26 11:05:32 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:05:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:32 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:32 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:32 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:32 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:32 --> Utf8 Class Initialized
DEBUG - 2020-02-26 11:05:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:32 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:32 --> URI Class Initialized
INFO - 2020-02-26 11:05:32 --> URI Class Initialized
INFO - 2020-02-26 11:05:32 --> URI Class Initialized
INFO - 2020-02-26 11:05:32 --> URI Class Initialized
INFO - 2020-02-26 11:05:32 --> URI Class Initialized
INFO - 2020-02-26 11:05:32 --> URI Class Initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
ERROR - 2020-02-26 11:05:32 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-26 11:05:32 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 11:05:32 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 11:05:32 --> Loader Class Initialized
INFO - 2020-02-26 11:05:32 --> Loader Class Initialized
ERROR - 2020-02-26 11:05:32 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 11:05:32 --> Helper loaded: url_helper
INFO - 2020-02-26 11:05:32 --> Helper loaded: url_helper
INFO - 2020-02-26 11:05:32 --> Helper loaded: string_helper
INFO - 2020-02-26 11:05:32 --> Helper loaded: string_helper
INFO - 2020-02-26 11:05:32 --> Config Class Initialized
INFO - 2020-02-26 11:05:32 --> Config Class Initialized
INFO - 2020-02-26 11:05:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:32 --> Database Driver Class Initialized
INFO - 2020-02-26 11:05:32 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-26 11:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:05:32 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:32 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:05:32 --> Controller Class Initialized
INFO - 2020-02-26 11:05:32 --> URI Class Initialized
INFO - 2020-02-26 11:05:32 --> URI Class Initialized
INFO - 2020-02-26 11:05:32 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Model "M_pesan" initialized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:32 --> Helper loaded: form_helper
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
INFO - 2020-02-26 11:05:32 --> Form Validation Class Initialized
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
ERROR - 2020-02-26 11:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 11:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 11:05:32 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 11:05:32 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 11:05:32 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 11:05:32 --> Config Class Initialized
INFO - 2020-02-26 11:05:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:32 --> Final output sent to browser
DEBUG - 2020-02-26 11:05:32 --> Total execution time: 0.5399
DEBUG - 2020-02-26 11:05:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:32 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:05:32 --> Controller Class Initialized
INFO - 2020-02-26 11:05:32 --> URI Class Initialized
INFO - 2020-02-26 11:05:32 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:05:32 --> Router Class Initialized
INFO - 2020-02-26 11:05:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:05:32 --> Output Class Initialized
INFO - 2020-02-26 11:05:32 --> Model "M_pesan" initialized
INFO - 2020-02-26 11:05:32 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:32 --> Helper loaded: form_helper
INFO - 2020-02-26 11:05:32 --> Input Class Initialized
INFO - 2020-02-26 11:05:32 --> Form Validation Class Initialized
INFO - 2020-02-26 11:05:32 --> Language Class Initialized
ERROR - 2020-02-26 11:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 11:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 11:05:32 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 11:05:32 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 11:05:32 --> Config Class Initialized
INFO - 2020-02-26 11:05:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:05:32 --> Final output sent to browser
DEBUG - 2020-02-26 11:05:32 --> Total execution time: 0.7559
DEBUG - 2020-02-26 11:05:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:33 --> URI Class Initialized
INFO - 2020-02-26 11:05:33 --> Router Class Initialized
INFO - 2020-02-26 11:05:33 --> Output Class Initialized
INFO - 2020-02-26 11:05:33 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:33 --> Input Class Initialized
INFO - 2020-02-26 11:05:33 --> Language Class Initialized
ERROR - 2020-02-26 11:05:33 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 11:05:33 --> Config Class Initialized
INFO - 2020-02-26 11:05:33 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:05:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:33 --> URI Class Initialized
INFO - 2020-02-26 11:05:33 --> Router Class Initialized
INFO - 2020-02-26 11:05:33 --> Output Class Initialized
INFO - 2020-02-26 11:05:33 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:33 --> Input Class Initialized
INFO - 2020-02-26 11:05:33 --> Language Class Initialized
ERROR - 2020-02-26 11:05:33 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 11:05:33 --> Config Class Initialized
INFO - 2020-02-26 11:05:33 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:05:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:33 --> URI Class Initialized
INFO - 2020-02-26 11:05:33 --> Router Class Initialized
INFO - 2020-02-26 11:05:33 --> Output Class Initialized
INFO - 2020-02-26 11:05:33 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:33 --> Input Class Initialized
INFO - 2020-02-26 11:05:33 --> Language Class Initialized
ERROR - 2020-02-26 11:05:33 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 11:05:33 --> Config Class Initialized
INFO - 2020-02-26 11:05:33 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:05:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:33 --> URI Class Initialized
INFO - 2020-02-26 11:05:33 --> Router Class Initialized
INFO - 2020-02-26 11:05:33 --> Output Class Initialized
INFO - 2020-02-26 11:05:33 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:33 --> Input Class Initialized
INFO - 2020-02-26 11:05:33 --> Language Class Initialized
ERROR - 2020-02-26 11:05:33 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 11:05:34 --> Config Class Initialized
INFO - 2020-02-26 11:05:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:05:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:34 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:34 --> URI Class Initialized
INFO - 2020-02-26 11:05:34 --> Router Class Initialized
INFO - 2020-02-26 11:05:34 --> Output Class Initialized
INFO - 2020-02-26 11:05:34 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:34 --> Input Class Initialized
INFO - 2020-02-26 11:05:34 --> Language Class Initialized
ERROR - 2020-02-26 11:05:34 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 11:05:34 --> Config Class Initialized
INFO - 2020-02-26 11:05:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:05:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:34 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:34 --> URI Class Initialized
INFO - 2020-02-26 11:05:34 --> Router Class Initialized
INFO - 2020-02-26 11:05:34 --> Output Class Initialized
INFO - 2020-02-26 11:05:34 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:34 --> Input Class Initialized
INFO - 2020-02-26 11:05:34 --> Language Class Initialized
ERROR - 2020-02-26 11:05:34 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 11:05:34 --> Config Class Initialized
INFO - 2020-02-26 11:05:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:05:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:34 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:34 --> URI Class Initialized
INFO - 2020-02-26 11:05:34 --> Router Class Initialized
INFO - 2020-02-26 11:05:34 --> Output Class Initialized
INFO - 2020-02-26 11:05:34 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:34 --> Input Class Initialized
INFO - 2020-02-26 11:05:34 --> Language Class Initialized
ERROR - 2020-02-26 11:05:34 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 11:05:34 --> Config Class Initialized
INFO - 2020-02-26 11:05:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:05:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:05:34 --> Utf8 Class Initialized
INFO - 2020-02-26 11:05:34 --> URI Class Initialized
INFO - 2020-02-26 11:05:34 --> Router Class Initialized
INFO - 2020-02-26 11:05:34 --> Output Class Initialized
INFO - 2020-02-26 11:05:34 --> Security Class Initialized
DEBUG - 2020-02-26 11:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:05:34 --> Input Class Initialized
INFO - 2020-02-26 11:05:34 --> Language Class Initialized
ERROR - 2020-02-26 11:05:34 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 11:06:07 --> Config Class Initialized
INFO - 2020-02-26 11:06:07 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:06:07 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:06:07 --> Utf8 Class Initialized
INFO - 2020-02-26 11:06:07 --> URI Class Initialized
INFO - 2020-02-26 11:06:07 --> Router Class Initialized
INFO - 2020-02-26 11:06:07 --> Output Class Initialized
INFO - 2020-02-26 11:06:07 --> Security Class Initialized
DEBUG - 2020-02-26 11:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:06:08 --> Input Class Initialized
INFO - 2020-02-26 11:06:08 --> Language Class Initialized
INFO - 2020-02-26 11:06:08 --> Loader Class Initialized
INFO - 2020-02-26 11:06:08 --> Helper loaded: url_helper
INFO - 2020-02-26 11:06:08 --> Helper loaded: string_helper
INFO - 2020-02-26 11:06:08 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:06:08 --> Controller Class Initialized
INFO - 2020-02-26 11:06:08 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:06:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:06:08 --> Model "M_pesan" initialized
INFO - 2020-02-26 11:06:08 --> Helper loaded: form_helper
INFO - 2020-02-26 11:06:08 --> Form Validation Class Initialized
INFO - 2020-02-26 17:06:08 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 17:06:08 --> Final output sent to browser
DEBUG - 2020-02-26 17:06:08 --> Total execution time: 0.7680
INFO - 2020-02-26 11:07:00 --> Config Class Initialized
INFO - 2020-02-26 11:07:00 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:07:00 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:07:00 --> Utf8 Class Initialized
INFO - 2020-02-26 11:07:00 --> URI Class Initialized
INFO - 2020-02-26 11:07:00 --> Router Class Initialized
INFO - 2020-02-26 11:07:00 --> Output Class Initialized
INFO - 2020-02-26 11:07:00 --> Security Class Initialized
DEBUG - 2020-02-26 11:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:07:00 --> Input Class Initialized
INFO - 2020-02-26 11:07:00 --> Language Class Initialized
INFO - 2020-02-26 11:07:00 --> Loader Class Initialized
INFO - 2020-02-26 11:07:00 --> Helper loaded: url_helper
INFO - 2020-02-26 11:07:00 --> Helper loaded: string_helper
INFO - 2020-02-26 11:07:00 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:07:00 --> Controller Class Initialized
INFO - 2020-02-26 11:07:00 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:07:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:07:00 --> Model "M_pesan" initialized
INFO - 2020-02-26 11:07:00 --> Helper loaded: form_helper
INFO - 2020-02-26 11:07:00 --> Form Validation Class Initialized
ERROR - 2020-02-26 11:07:00 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 42
INFO - 2020-02-26 11:07:00 --> Config Class Initialized
INFO - 2020-02-26 11:07:01 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:07:01 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:07:01 --> Utf8 Class Initialized
INFO - 2020-02-26 11:07:01 --> URI Class Initialized
INFO - 2020-02-26 11:07:01 --> Router Class Initialized
INFO - 2020-02-26 11:07:01 --> Output Class Initialized
INFO - 2020-02-26 11:07:01 --> Security Class Initialized
DEBUG - 2020-02-26 11:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:07:01 --> Input Class Initialized
INFO - 2020-02-26 11:07:01 --> Language Class Initialized
INFO - 2020-02-26 11:07:01 --> Loader Class Initialized
INFO - 2020-02-26 11:07:01 --> Helper loaded: url_helper
INFO - 2020-02-26 11:07:01 --> Helper loaded: string_helper
INFO - 2020-02-26 11:07:01 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:07:01 --> Controller Class Initialized
INFO - 2020-02-26 11:07:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 11:07:01 --> Pagination Class Initialized
INFO - 2020-02-26 11:07:01 --> Model "M_show" initialized
INFO - 2020-02-26 11:07:01 --> Helper loaded: form_helper
INFO - 2020-02-26 11:07:01 --> Form Validation Class Initialized
INFO - 2020-02-26 11:07:01 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 11:07:01 --> Final output sent to browser
DEBUG - 2020-02-26 11:07:01 --> Total execution time: 0.4499
INFO - 2020-02-26 11:07:01 --> Config Class Initialized
INFO - 2020-02-26 11:07:01 --> Config Class Initialized
INFO - 2020-02-26 11:07:01 --> Hooks Class Initialized
INFO - 2020-02-26 11:07:01 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:07:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:07:01 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:07:01 --> Utf8 Class Initialized
INFO - 2020-02-26 11:07:01 --> Utf8 Class Initialized
INFO - 2020-02-26 11:07:01 --> URI Class Initialized
INFO - 2020-02-26 11:07:01 --> URI Class Initialized
INFO - 2020-02-26 11:07:01 --> Router Class Initialized
INFO - 2020-02-26 11:07:01 --> Router Class Initialized
INFO - 2020-02-26 11:07:01 --> Output Class Initialized
INFO - 2020-02-26 11:07:01 --> Output Class Initialized
INFO - 2020-02-26 11:07:01 --> Security Class Initialized
INFO - 2020-02-26 11:07:01 --> Security Class Initialized
DEBUG - 2020-02-26 11:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:07:01 --> Input Class Initialized
INFO - 2020-02-26 11:07:01 --> Input Class Initialized
INFO - 2020-02-26 11:07:01 --> Language Class Initialized
INFO - 2020-02-26 11:07:01 --> Language Class Initialized
ERROR - 2020-02-26 11:07:01 --> 404 Page Not Found: Show/assets
ERROR - 2020-02-26 11:07:01 --> 404 Page Not Found: Show/assets
INFO - 2020-02-26 11:12:07 --> Config Class Initialized
INFO - 2020-02-26 11:12:07 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:12:07 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:12:07 --> Utf8 Class Initialized
INFO - 2020-02-26 11:12:07 --> URI Class Initialized
DEBUG - 2020-02-26 11:12:07 --> No URI present. Default controller set.
INFO - 2020-02-26 11:12:07 --> Router Class Initialized
INFO - 2020-02-26 11:12:07 --> Output Class Initialized
INFO - 2020-02-26 11:12:07 --> Security Class Initialized
DEBUG - 2020-02-26 11:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:12:07 --> Input Class Initialized
INFO - 2020-02-26 11:12:07 --> Language Class Initialized
INFO - 2020-02-26 11:12:07 --> Loader Class Initialized
INFO - 2020-02-26 11:12:08 --> Helper loaded: url_helper
INFO - 2020-02-26 11:12:08 --> Helper loaded: string_helper
INFO - 2020-02-26 11:12:08 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:12:08 --> Controller Class Initialized
INFO - 2020-02-26 11:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 11:12:08 --> Pagination Class Initialized
INFO - 2020-02-26 11:12:08 --> Model "M_show" initialized
INFO - 2020-02-26 11:12:08 --> Helper loaded: form_helper
INFO - 2020-02-26 11:12:08 --> Form Validation Class Initialized
INFO - 2020-02-26 11:12:08 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 11:12:08 --> Final output sent to browser
INFO - 2020-02-26 11:12:08 --> Config Class Initialized
DEBUG - 2020-02-26 11:12:08 --> Total execution time: 0.5487
INFO - 2020-02-26 11:12:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:12:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:12:08 --> Utf8 Class Initialized
INFO - 2020-02-26 11:12:08 --> URI Class Initialized
DEBUG - 2020-02-26 11:12:08 --> No URI present. Default controller set.
INFO - 2020-02-26 11:12:08 --> Router Class Initialized
INFO - 2020-02-26 11:12:08 --> Output Class Initialized
INFO - 2020-02-26 11:12:08 --> Security Class Initialized
DEBUG - 2020-02-26 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:12:08 --> Input Class Initialized
INFO - 2020-02-26 11:12:08 --> Language Class Initialized
INFO - 2020-02-26 11:12:08 --> Loader Class Initialized
INFO - 2020-02-26 11:12:08 --> Helper loaded: url_helper
INFO - 2020-02-26 11:12:08 --> Helper loaded: string_helper
INFO - 2020-02-26 11:12:08 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:12:08 --> Controller Class Initialized
INFO - 2020-02-26 11:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 11:12:08 --> Pagination Class Initialized
INFO - 2020-02-26 11:12:08 --> Model "M_show" initialized
INFO - 2020-02-26 11:12:08 --> Helper loaded: form_helper
INFO - 2020-02-26 11:12:08 --> Form Validation Class Initialized
INFO - 2020-02-26 11:12:08 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 11:12:08 --> Final output sent to browser
DEBUG - 2020-02-26 11:12:08 --> Total execution time: 0.6085
INFO - 2020-02-26 11:14:35 --> Config Class Initialized
INFO - 2020-02-26 11:14:35 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:14:35 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:14:35 --> Utf8 Class Initialized
INFO - 2020-02-26 11:14:35 --> URI Class Initialized
INFO - 2020-02-26 11:14:35 --> Router Class Initialized
INFO - 2020-02-26 11:14:35 --> Output Class Initialized
INFO - 2020-02-26 11:14:35 --> Security Class Initialized
DEBUG - 2020-02-26 11:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:14:35 --> Input Class Initialized
INFO - 2020-02-26 11:14:35 --> Language Class Initialized
ERROR - 2020-02-26 11:14:35 --> 404 Page Not Found: Pemesanan/form_bukti
INFO - 2020-02-26 11:15:31 --> Config Class Initialized
INFO - 2020-02-26 11:15:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:15:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:15:31 --> Utf8 Class Initialized
INFO - 2020-02-26 11:15:31 --> URI Class Initialized
INFO - 2020-02-26 11:15:31 --> Router Class Initialized
INFO - 2020-02-26 11:15:31 --> Output Class Initialized
INFO - 2020-02-26 11:15:31 --> Security Class Initialized
DEBUG - 2020-02-26 11:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:15:31 --> Input Class Initialized
INFO - 2020-02-26 11:15:31 --> Language Class Initialized
INFO - 2020-02-26 11:15:31 --> Loader Class Initialized
INFO - 2020-02-26 11:15:31 --> Helper loaded: url_helper
INFO - 2020-02-26 11:15:31 --> Helper loaded: string_helper
INFO - 2020-02-26 11:15:31 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:15:31 --> Controller Class Initialized
INFO - 2020-02-26 11:15:31 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:15:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:15:31 --> Model "M_pesan" initialized
INFO - 2020-02-26 11:15:31 --> Helper loaded: form_helper
INFO - 2020-02-26 11:15:31 --> Form Validation Class Initialized
ERROR - 2020-02-26 11:15:31 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 30
ERROR - 2020-02-26 11:15:31 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 31
ERROR - 2020-02-26 11:15:31 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 32
ERROR - 2020-02-26 11:15:31 --> Severity: Notice --> Undefined index: kodebayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 33
ERROR - 2020-02-26 11:15:31 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 42
INFO - 2020-02-26 11:15:31 --> Config Class Initialized
INFO - 2020-02-26 11:15:32 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:15:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:15:32 --> Utf8 Class Initialized
INFO - 2020-02-26 11:15:32 --> URI Class Initialized
INFO - 2020-02-26 11:15:32 --> Router Class Initialized
INFO - 2020-02-26 11:15:32 --> Output Class Initialized
INFO - 2020-02-26 11:15:32 --> Security Class Initialized
DEBUG - 2020-02-26 11:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:15:32 --> Input Class Initialized
INFO - 2020-02-26 11:15:32 --> Language Class Initialized
INFO - 2020-02-26 11:15:32 --> Loader Class Initialized
INFO - 2020-02-26 11:15:32 --> Helper loaded: url_helper
INFO - 2020-02-26 11:15:32 --> Helper loaded: string_helper
INFO - 2020-02-26 11:15:32 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:15:32 --> Controller Class Initialized
INFO - 2020-02-26 11:15:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 11:15:32 --> Pagination Class Initialized
INFO - 2020-02-26 11:15:32 --> Model "M_show" initialized
INFO - 2020-02-26 11:15:32 --> Helper loaded: form_helper
INFO - 2020-02-26 11:15:32 --> Form Validation Class Initialized
INFO - 2020-02-26 11:15:32 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 11:15:32 --> Final output sent to browser
DEBUG - 2020-02-26 11:15:32 --> Total execution time: 0.4593
INFO - 2020-02-26 11:15:32 --> Config Class Initialized
INFO - 2020-02-26 11:15:32 --> Config Class Initialized
INFO - 2020-02-26 11:15:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:15:32 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:15:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:15:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:15:32 --> Utf8 Class Initialized
INFO - 2020-02-26 11:15:32 --> Utf8 Class Initialized
INFO - 2020-02-26 11:15:32 --> URI Class Initialized
INFO - 2020-02-26 11:15:32 --> URI Class Initialized
INFO - 2020-02-26 11:15:32 --> Router Class Initialized
INFO - 2020-02-26 11:15:32 --> Router Class Initialized
INFO - 2020-02-26 11:15:32 --> Output Class Initialized
INFO - 2020-02-26 11:15:32 --> Output Class Initialized
INFO - 2020-02-26 11:15:32 --> Security Class Initialized
INFO - 2020-02-26 11:15:32 --> Security Class Initialized
DEBUG - 2020-02-26 11:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:15:32 --> Input Class Initialized
INFO - 2020-02-26 11:15:32 --> Input Class Initialized
INFO - 2020-02-26 11:15:32 --> Language Class Initialized
INFO - 2020-02-26 11:15:32 --> Language Class Initialized
ERROR - 2020-02-26 11:15:32 --> 404 Page Not Found: Show/assets
ERROR - 2020-02-26 11:15:33 --> 404 Page Not Found: Show/assets
INFO - 2020-02-26 11:15:33 --> Config Class Initialized
INFO - 2020-02-26 11:15:33 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:15:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:15:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:15:33 --> URI Class Initialized
INFO - 2020-02-26 11:15:33 --> Router Class Initialized
INFO - 2020-02-26 11:15:33 --> Output Class Initialized
INFO - 2020-02-26 11:15:33 --> Security Class Initialized
DEBUG - 2020-02-26 11:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:15:33 --> Input Class Initialized
INFO - 2020-02-26 11:15:33 --> Language Class Initialized
ERROR - 2020-02-26 11:15:33 --> 404 Page Not Found: Show/assets
INFO - 2020-02-26 11:15:33 --> Config Class Initialized
INFO - 2020-02-26 11:15:33 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:15:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:15:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:15:33 --> URI Class Initialized
INFO - 2020-02-26 11:15:33 --> Router Class Initialized
INFO - 2020-02-26 11:15:33 --> Output Class Initialized
INFO - 2020-02-26 11:15:33 --> Security Class Initialized
DEBUG - 2020-02-26 11:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:15:33 --> Input Class Initialized
INFO - 2020-02-26 11:15:33 --> Language Class Initialized
ERROR - 2020-02-26 11:15:33 --> 404 Page Not Found: Show/assets
INFO - 2020-02-26 11:34:32 --> Config Class Initialized
INFO - 2020-02-26 11:34:32 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:34:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:32 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:32 --> URI Class Initialized
INFO - 2020-02-26 11:34:32 --> Router Class Initialized
INFO - 2020-02-26 11:34:32 --> Output Class Initialized
INFO - 2020-02-26 11:34:32 --> Security Class Initialized
DEBUG - 2020-02-26 11:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:32 --> Input Class Initialized
INFO - 2020-02-26 11:34:32 --> Language Class Initialized
INFO - 2020-02-26 11:34:32 --> Loader Class Initialized
INFO - 2020-02-26 11:34:32 --> Helper loaded: url_helper
INFO - 2020-02-26 11:34:32 --> Helper loaded: string_helper
INFO - 2020-02-26 11:34:32 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:34:32 --> Controller Class Initialized
INFO - 2020-02-26 11:34:32 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:34:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:34:32 --> Model "M_pesan" initialized
INFO - 2020-02-26 11:34:32 --> Helper loaded: form_helper
INFO - 2020-02-26 11:34:32 --> Form Validation Class Initialized
INFO - 2020-02-26 11:34:32 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 11:34:32 --> Final output sent to browser
DEBUG - 2020-02-26 11:34:32 --> Total execution time: 0.5573
INFO - 2020-02-26 11:34:32 --> Config Class Initialized
INFO - 2020-02-26 11:34:32 --> Config Class Initialized
INFO - 2020-02-26 11:34:32 --> Config Class Initialized
INFO - 2020-02-26 11:34:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:32 --> Config Class Initialized
INFO - 2020-02-26 11:34:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:32 --> Config Class Initialized
INFO - 2020-02-26 11:34:32 --> Config Class Initialized
INFO - 2020-02-26 11:34:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:32 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:32 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:34:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:34:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:34:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
DEBUG - 2020-02-26 11:34:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:34:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:34:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
ERROR - 2020-02-26 11:34:33 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
ERROR - 2020-02-26 11:34:33 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-26 11:34:33 --> Loader Class Initialized
ERROR - 2020-02-26 11:34:33 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 11:34:33 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 11:34:33 --> Helper loaded: url_helper
INFO - 2020-02-26 11:34:33 --> Loader Class Initialized
INFO - 2020-02-26 11:34:33 --> Config Class Initialized
INFO - 2020-02-26 11:34:33 --> Config Class Initialized
INFO - 2020-02-26 11:34:33 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:33 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:33 --> Helper loaded: string_helper
INFO - 2020-02-26 11:34:33 --> Helper loaded: url_helper
INFO - 2020-02-26 11:34:33 --> Config Class Initialized
INFO - 2020-02-26 11:34:33 --> Config Class Initialized
INFO - 2020-02-26 11:34:33 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:33 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:33 --> Helper loaded: string_helper
DEBUG - 2020-02-26 11:34:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:34:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:33 --> Database Driver Class Initialized
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
DEBUG - 2020-02-26 11:34:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:34:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:34:33 --> Database Driver Class Initialized
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
DEBUG - 2020-02-26 11:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:34:33 --> Controller Class Initialized
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:33 --> Helper loaded: form_helper
INFO - 2020-02-26 11:34:33 --> Form Validation Class Initialized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
ERROR - 2020-02-26 11:34:33 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 11:34:33 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 11:34:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 11:34:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 11:34:33 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 11:34:33 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 11:34:33 --> Config Class Initialized
INFO - 2020-02-26 11:34:33 --> Config Class Initialized
INFO - 2020-02-26 11:34:33 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:33 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:33 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 11:34:33 --> Config Class Initialized
INFO - 2020-02-26 11:34:33 --> Config Class Initialized
INFO - 2020-02-26 11:34:33 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:33 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:33 --> Final output sent to browser
DEBUG - 2020-02-26 11:34:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:34:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
DEBUG - 2020-02-26 11:34:33 --> Total execution time: 0.6272
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
DEBUG - 2020-02-26 11:34:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:34:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> Controller Class Initialized
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
INFO - 2020-02-26 11:34:33 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:33 --> Helper loaded: form_helper
INFO - 2020-02-26 11:34:33 --> Form Validation Class Initialized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
ERROR - 2020-02-26 11:34:33 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-26 11:34:33 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 11:34:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 11:34:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 11:34:33 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 11:34:33 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 11:34:33 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 11:34:33 --> Config Class Initialized
INFO - 2020-02-26 11:34:33 --> Hooks Class Initialized
INFO - 2020-02-26 11:34:33 --> Final output sent to browser
DEBUG - 2020-02-26 11:34:33 --> Total execution time: 0.8802
DEBUG - 2020-02-26 11:34:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:33 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:33 --> URI Class Initialized
INFO - 2020-02-26 11:34:33 --> Router Class Initialized
INFO - 2020-02-26 11:34:33 --> Output Class Initialized
INFO - 2020-02-26 11:34:33 --> Security Class Initialized
DEBUG - 2020-02-26 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:33 --> Input Class Initialized
INFO - 2020-02-26 11:34:33 --> Language Class Initialized
ERROR - 2020-02-26 11:34:34 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 11:34:34 --> Config Class Initialized
INFO - 2020-02-26 11:34:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:34:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:34 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:34 --> URI Class Initialized
INFO - 2020-02-26 11:34:34 --> Router Class Initialized
INFO - 2020-02-26 11:34:34 --> Output Class Initialized
INFO - 2020-02-26 11:34:34 --> Security Class Initialized
DEBUG - 2020-02-26 11:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:34 --> Input Class Initialized
INFO - 2020-02-26 11:34:34 --> Language Class Initialized
ERROR - 2020-02-26 11:34:34 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 11:34:34 --> Config Class Initialized
INFO - 2020-02-26 11:34:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:34:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:34 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:34 --> URI Class Initialized
INFO - 2020-02-26 11:34:34 --> Router Class Initialized
INFO - 2020-02-26 11:34:34 --> Output Class Initialized
INFO - 2020-02-26 11:34:34 --> Security Class Initialized
DEBUG - 2020-02-26 11:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:34 --> Input Class Initialized
INFO - 2020-02-26 11:34:34 --> Language Class Initialized
ERROR - 2020-02-26 11:34:34 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 11:34:34 --> Config Class Initialized
INFO - 2020-02-26 11:34:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:34:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:34 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:34 --> URI Class Initialized
INFO - 2020-02-26 11:34:34 --> Router Class Initialized
INFO - 2020-02-26 11:34:34 --> Output Class Initialized
INFO - 2020-02-26 11:34:34 --> Security Class Initialized
DEBUG - 2020-02-26 11:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:34 --> Input Class Initialized
INFO - 2020-02-26 11:34:34 --> Language Class Initialized
ERROR - 2020-02-26 11:34:34 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 11:34:34 --> Config Class Initialized
INFO - 2020-02-26 11:34:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:34:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:34 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:34 --> URI Class Initialized
INFO - 2020-02-26 11:34:34 --> Router Class Initialized
INFO - 2020-02-26 11:34:34 --> Output Class Initialized
INFO - 2020-02-26 11:34:34 --> Security Class Initialized
DEBUG - 2020-02-26 11:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:35 --> Input Class Initialized
INFO - 2020-02-26 11:34:35 --> Language Class Initialized
ERROR - 2020-02-26 11:34:35 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 11:34:35 --> Config Class Initialized
INFO - 2020-02-26 11:34:35 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:34:35 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:35 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:35 --> URI Class Initialized
INFO - 2020-02-26 11:34:35 --> Router Class Initialized
INFO - 2020-02-26 11:34:35 --> Output Class Initialized
INFO - 2020-02-26 11:34:35 --> Security Class Initialized
DEBUG - 2020-02-26 11:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:35 --> Input Class Initialized
INFO - 2020-02-26 11:34:35 --> Language Class Initialized
ERROR - 2020-02-26 11:34:35 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 11:34:35 --> Config Class Initialized
INFO - 2020-02-26 11:34:35 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:34:35 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:35 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:35 --> URI Class Initialized
INFO - 2020-02-26 11:34:35 --> Router Class Initialized
INFO - 2020-02-26 11:34:35 --> Output Class Initialized
INFO - 2020-02-26 11:34:35 --> Security Class Initialized
DEBUG - 2020-02-26 11:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:35 --> Input Class Initialized
INFO - 2020-02-26 11:34:35 --> Language Class Initialized
ERROR - 2020-02-26 11:34:35 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 11:34:35 --> Config Class Initialized
INFO - 2020-02-26 11:34:35 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:34:35 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:34:35 --> Utf8 Class Initialized
INFO - 2020-02-26 11:34:35 --> URI Class Initialized
INFO - 2020-02-26 11:34:35 --> Router Class Initialized
INFO - 2020-02-26 11:34:35 --> Output Class Initialized
INFO - 2020-02-26 11:34:35 --> Security Class Initialized
DEBUG - 2020-02-26 11:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:34:35 --> Input Class Initialized
INFO - 2020-02-26 11:34:35 --> Language Class Initialized
ERROR - 2020-02-26 11:34:35 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 11:35:02 --> Config Class Initialized
INFO - 2020-02-26 11:35:02 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:35:02 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:35:02 --> Utf8 Class Initialized
INFO - 2020-02-26 11:35:03 --> URI Class Initialized
INFO - 2020-02-26 11:35:03 --> Router Class Initialized
INFO - 2020-02-26 11:35:03 --> Output Class Initialized
INFO - 2020-02-26 11:35:03 --> Security Class Initialized
DEBUG - 2020-02-26 11:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:35:03 --> Input Class Initialized
INFO - 2020-02-26 11:35:03 --> Language Class Initialized
INFO - 2020-02-26 11:35:03 --> Loader Class Initialized
INFO - 2020-02-26 11:35:03 --> Helper loaded: url_helper
INFO - 2020-02-26 11:35:03 --> Helper loaded: string_helper
INFO - 2020-02-26 11:35:03 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:35:03 --> Controller Class Initialized
INFO - 2020-02-26 11:35:03 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:35:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:35:03 --> Model "M_pesan" initialized
INFO - 2020-02-26 11:35:03 --> Helper loaded: form_helper
INFO - 2020-02-26 11:35:03 --> Form Validation Class Initialized
INFO - 2020-02-26 17:35:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 17:35:03 --> Final output sent to browser
DEBUG - 2020-02-26 17:35:03 --> Total execution time: 0.6685
INFO - 2020-02-26 11:35:09 --> Config Class Initialized
INFO - 2020-02-26 11:35:09 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:35:09 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:35:09 --> Utf8 Class Initialized
INFO - 2020-02-26 11:35:09 --> URI Class Initialized
INFO - 2020-02-26 11:35:09 --> Router Class Initialized
INFO - 2020-02-26 11:35:09 --> Output Class Initialized
INFO - 2020-02-26 11:35:09 --> Security Class Initialized
DEBUG - 2020-02-26 11:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:35:09 --> Input Class Initialized
INFO - 2020-02-26 11:35:09 --> Language Class Initialized
INFO - 2020-02-26 11:35:09 --> Loader Class Initialized
INFO - 2020-02-26 11:35:09 --> Helper loaded: url_helper
INFO - 2020-02-26 11:35:09 --> Helper loaded: string_helper
INFO - 2020-02-26 11:35:09 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:35:09 --> Controller Class Initialized
INFO - 2020-02-26 11:35:09 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:35:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:35:09 --> Model "M_pesan" initialized
INFO - 2020-02-26 11:35:09 --> Helper loaded: form_helper
INFO - 2020-02-26 11:35:09 --> Form Validation Class Initialized
ERROR - 2020-02-26 11:35:09 --> Severity: Warning --> strtotime() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 39
ERROR - 2020-02-26 11:35:09 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 41
ERROR - 2020-02-26 11:35:09 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 44
INFO - 2020-02-26 11:35:09 --> Config Class Initialized
INFO - 2020-02-26 11:35:09 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:35:09 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:35:09 --> Utf8 Class Initialized
INFO - 2020-02-26 11:35:09 --> URI Class Initialized
INFO - 2020-02-26 11:35:09 --> Router Class Initialized
INFO - 2020-02-26 11:35:09 --> Output Class Initialized
INFO - 2020-02-26 11:35:09 --> Security Class Initialized
DEBUG - 2020-02-26 11:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:35:09 --> Input Class Initialized
INFO - 2020-02-26 11:35:09 --> Language Class Initialized
INFO - 2020-02-26 11:35:09 --> Loader Class Initialized
INFO - 2020-02-26 11:35:09 --> Helper loaded: url_helper
INFO - 2020-02-26 11:35:09 --> Helper loaded: string_helper
INFO - 2020-02-26 11:35:09 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:35:09 --> Controller Class Initialized
INFO - 2020-02-26 11:35:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 11:35:09 --> Pagination Class Initialized
INFO - 2020-02-26 11:35:09 --> Model "M_show" initialized
INFO - 2020-02-26 11:35:10 --> Helper loaded: form_helper
INFO - 2020-02-26 11:35:10 --> Form Validation Class Initialized
INFO - 2020-02-26 11:35:10 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 11:35:10 --> Final output sent to browser
DEBUG - 2020-02-26 11:35:10 --> Total execution time: 0.4910
INFO - 2020-02-26 11:35:10 --> Config Class Initialized
INFO - 2020-02-26 11:35:10 --> Config Class Initialized
INFO - 2020-02-26 11:35:10 --> Hooks Class Initialized
INFO - 2020-02-26 11:35:10 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:35:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:35:10 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:35:10 --> Utf8 Class Initialized
INFO - 2020-02-26 11:35:10 --> Utf8 Class Initialized
INFO - 2020-02-26 11:35:10 --> URI Class Initialized
INFO - 2020-02-26 11:35:10 --> URI Class Initialized
INFO - 2020-02-26 11:35:10 --> Router Class Initialized
INFO - 2020-02-26 11:35:10 --> Router Class Initialized
INFO - 2020-02-26 11:35:10 --> Output Class Initialized
INFO - 2020-02-26 11:35:10 --> Output Class Initialized
INFO - 2020-02-26 11:35:10 --> Security Class Initialized
INFO - 2020-02-26 11:35:10 --> Security Class Initialized
DEBUG - 2020-02-26 11:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:35:10 --> Input Class Initialized
INFO - 2020-02-26 11:35:10 --> Input Class Initialized
INFO - 2020-02-26 11:35:10 --> Language Class Initialized
INFO - 2020-02-26 11:35:10 --> Language Class Initialized
ERROR - 2020-02-26 11:35:10 --> 404 Page Not Found: Show/assets
ERROR - 2020-02-26 11:35:10 --> 404 Page Not Found: Show/assets
INFO - 2020-02-26 11:36:34 --> Config Class Initialized
INFO - 2020-02-26 11:36:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:36:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:34 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:34 --> URI Class Initialized
INFO - 2020-02-26 11:36:34 --> Router Class Initialized
INFO - 2020-02-26 11:36:34 --> Output Class Initialized
INFO - 2020-02-26 11:36:34 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:34 --> Input Class Initialized
INFO - 2020-02-26 11:36:34 --> Language Class Initialized
INFO - 2020-02-26 11:36:34 --> Loader Class Initialized
INFO - 2020-02-26 11:36:34 --> Helper loaded: url_helper
INFO - 2020-02-26 11:36:34 --> Helper loaded: string_helper
INFO - 2020-02-26 11:36:34 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:36:34 --> Controller Class Initialized
INFO - 2020-02-26 11:36:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 11:36:34 --> Pagination Class Initialized
INFO - 2020-02-26 11:36:34 --> Model "M_show" initialized
INFO - 2020-02-26 11:36:34 --> Helper loaded: form_helper
INFO - 2020-02-26 11:36:34 --> Form Validation Class Initialized
INFO - 2020-02-26 11:36:34 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 11:36:34 --> Final output sent to browser
DEBUG - 2020-02-26 11:36:34 --> Total execution time: 0.6170
INFO - 2020-02-26 11:36:34 --> Config Class Initialized
INFO - 2020-02-26 11:36:34 --> Config Class Initialized
INFO - 2020-02-26 11:36:34 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:36:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:34 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:34 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:35 --> URI Class Initialized
INFO - 2020-02-26 11:36:35 --> URI Class Initialized
INFO - 2020-02-26 11:36:35 --> Router Class Initialized
INFO - 2020-02-26 11:36:35 --> Router Class Initialized
INFO - 2020-02-26 11:36:35 --> Output Class Initialized
INFO - 2020-02-26 11:36:35 --> Output Class Initialized
INFO - 2020-02-26 11:36:35 --> Security Class Initialized
INFO - 2020-02-26 11:36:35 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:35 --> Input Class Initialized
INFO - 2020-02-26 11:36:35 --> Input Class Initialized
INFO - 2020-02-26 11:36:35 --> Language Class Initialized
INFO - 2020-02-26 11:36:35 --> Language Class Initialized
ERROR - 2020-02-26 11:36:35 --> 404 Page Not Found: Show/assets
ERROR - 2020-02-26 11:36:35 --> 404 Page Not Found: Show/assets
INFO - 2020-02-26 11:36:36 --> Config Class Initialized
INFO - 2020-02-26 11:36:36 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:36:36 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:36 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:36 --> URI Class Initialized
INFO - 2020-02-26 11:36:36 --> Router Class Initialized
INFO - 2020-02-26 11:36:36 --> Output Class Initialized
INFO - 2020-02-26 11:36:36 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:36 --> Input Class Initialized
INFO - 2020-02-26 11:36:36 --> Language Class Initialized
INFO - 2020-02-26 11:36:36 --> Loader Class Initialized
INFO - 2020-02-26 11:36:36 --> Helper loaded: url_helper
INFO - 2020-02-26 11:36:36 --> Helper loaded: string_helper
INFO - 2020-02-26 11:36:36 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:36:36 --> Controller Class Initialized
INFO - 2020-02-26 11:36:36 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:36:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:36:36 --> Model "M_pesan" initialized
INFO - 2020-02-26 11:36:36 --> Helper loaded: form_helper
INFO - 2020-02-26 11:36:36 --> Form Validation Class Initialized
INFO - 2020-02-26 11:36:36 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 11:36:36 --> Final output sent to browser
DEBUG - 2020-02-26 11:36:36 --> Total execution time: 0.5003
INFO - 2020-02-26 11:36:36 --> Config Class Initialized
INFO - 2020-02-26 11:36:36 --> Config Class Initialized
INFO - 2020-02-26 11:36:36 --> Config Class Initialized
INFO - 2020-02-26 11:36:36 --> Config Class Initialized
INFO - 2020-02-26 11:36:36 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:36 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:36 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:36 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:36 --> Config Class Initialized
INFO - 2020-02-26 11:36:36 --> Config Class Initialized
INFO - 2020-02-26 11:36:36 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:36 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:36:36 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:36 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:36 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:36 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:36 --> Utf8 Class Initialized
DEBUG - 2020-02-26 11:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:36:36 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:36 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:36 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:36 --> URI Class Initialized
INFO - 2020-02-26 11:36:36 --> URI Class Initialized
INFO - 2020-02-26 11:36:36 --> URI Class Initialized
INFO - 2020-02-26 11:36:36 --> URI Class Initialized
INFO - 2020-02-26 11:36:36 --> URI Class Initialized
INFO - 2020-02-26 11:36:36 --> URI Class Initialized
INFO - 2020-02-26 11:36:36 --> Router Class Initialized
INFO - 2020-02-26 11:36:36 --> Router Class Initialized
INFO - 2020-02-26 11:36:36 --> Router Class Initialized
INFO - 2020-02-26 11:36:36 --> Router Class Initialized
INFO - 2020-02-26 11:36:36 --> Router Class Initialized
INFO - 2020-02-26 11:36:36 --> Output Class Initialized
INFO - 2020-02-26 11:36:36 --> Output Class Initialized
INFO - 2020-02-26 11:36:36 --> Output Class Initialized
INFO - 2020-02-26 11:36:36 --> Output Class Initialized
INFO - 2020-02-26 11:36:36 --> Router Class Initialized
INFO - 2020-02-26 11:36:36 --> Security Class Initialized
INFO - 2020-02-26 11:36:36 --> Security Class Initialized
INFO - 2020-02-26 11:36:36 --> Output Class Initialized
INFO - 2020-02-26 11:36:36 --> Output Class Initialized
INFO - 2020-02-26 11:36:36 --> Security Class Initialized
INFO - 2020-02-26 11:36:36 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:36 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:36 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:36 --> Input Class Initialized
INFO - 2020-02-26 11:36:36 --> Input Class Initialized
INFO - 2020-02-26 11:36:36 --> Input Class Initialized
INFO - 2020-02-26 11:36:36 --> Input Class Initialized
DEBUG - 2020-02-26 11:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:36 --> Input Class Initialized
INFO - 2020-02-26 11:36:36 --> Input Class Initialized
INFO - 2020-02-26 11:36:36 --> Language Class Initialized
INFO - 2020-02-26 11:36:36 --> Language Class Initialized
INFO - 2020-02-26 11:36:36 --> Language Class Initialized
INFO - 2020-02-26 11:36:36 --> Language Class Initialized
ERROR - 2020-02-26 11:36:36 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 11:36:36 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-26 11:36:36 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 11:36:36 --> Language Class Initialized
INFO - 2020-02-26 11:36:37 --> Language Class Initialized
INFO - 2020-02-26 11:36:37 --> Loader Class Initialized
ERROR - 2020-02-26 11:36:37 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 11:36:37 --> Helper loaded: url_helper
INFO - 2020-02-26 11:36:37 --> Loader Class Initialized
INFO - 2020-02-26 11:36:37 --> Config Class Initialized
INFO - 2020-02-26 11:36:37 --> Config Class Initialized
INFO - 2020-02-26 11:36:37 --> Config Class Initialized
INFO - 2020-02-26 11:36:37 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:37 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:37 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:37 --> Helper loaded: url_helper
INFO - 2020-02-26 11:36:37 --> Helper loaded: string_helper
INFO - 2020-02-26 11:36:37 --> Config Class Initialized
INFO - 2020-02-26 11:36:37 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:37 --> Helper loaded: string_helper
DEBUG - 2020-02-26 11:36:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:36:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:36:37 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:37 --> Database Driver Class Initialized
INFO - 2020-02-26 11:36:37 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:37 --> Utf8 Class Initialized
DEBUG - 2020-02-26 11:36:37 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:37 --> Utf8 Class Initialized
DEBUG - 2020-02-26 11:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:36:37 --> Database Driver Class Initialized
INFO - 2020-02-26 11:36:37 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:36:37 --> URI Class Initialized
INFO - 2020-02-26 11:36:37 --> URI Class Initialized
INFO - 2020-02-26 11:36:37 --> URI Class Initialized
DEBUG - 2020-02-26 11:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:36:37 --> Controller Class Initialized
INFO - 2020-02-26 11:36:37 --> URI Class Initialized
INFO - 2020-02-26 11:36:37 --> Router Class Initialized
INFO - 2020-02-26 11:36:37 --> Router Class Initialized
INFO - 2020-02-26 11:36:37 --> Router Class Initialized
INFO - 2020-02-26 11:36:37 --> Router Class Initialized
INFO - 2020-02-26 11:36:37 --> Output Class Initialized
INFO - 2020-02-26 11:36:37 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:36:37 --> Output Class Initialized
INFO - 2020-02-26 11:36:37 --> Output Class Initialized
INFO - 2020-02-26 11:36:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:36:37 --> Security Class Initialized
INFO - 2020-02-26 11:36:37 --> Security Class Initialized
INFO - 2020-02-26 11:36:37 --> Output Class Initialized
INFO - 2020-02-26 11:36:37 --> Security Class Initialized
INFO - 2020-02-26 11:36:37 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 11:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:37 --> Security Class Initialized
INFO - 2020-02-26 11:36:37 --> Input Class Initialized
INFO - 2020-02-26 11:36:37 --> Input Class Initialized
INFO - 2020-02-26 11:36:37 --> Input Class Initialized
DEBUG - 2020-02-26 11:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:37 --> Helper loaded: form_helper
INFO - 2020-02-26 11:36:37 --> Form Validation Class Initialized
INFO - 2020-02-26 11:36:37 --> Input Class Initialized
INFO - 2020-02-26 11:36:37 --> Language Class Initialized
INFO - 2020-02-26 11:36:37 --> Language Class Initialized
INFO - 2020-02-26 11:36:37 --> Language Class Initialized
INFO - 2020-02-26 11:36:37 --> Language Class Initialized
ERROR - 2020-02-26 11:36:37 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 11:36:37 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 11:36:37 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 11:36:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 11:36:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 11:36:37 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 11:36:37 --> Config Class Initialized
INFO - 2020-02-26 11:36:37 --> Config Class Initialized
INFO - 2020-02-26 11:36:37 --> Config Class Initialized
INFO - 2020-02-26 11:36:37 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:37 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:37 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 11:36:37 --> Config Class Initialized
INFO - 2020-02-26 11:36:37 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:37 --> Final output sent to browser
DEBUG - 2020-02-26 11:36:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:36:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:36:37 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:37 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:37 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:37 --> Utf8 Class Initialized
DEBUG - 2020-02-26 11:36:37 --> Total execution time: 0.6672
DEBUG - 2020-02-26 11:36:37 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:37 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:36:37 --> URI Class Initialized
INFO - 2020-02-26 11:36:37 --> URI Class Initialized
INFO - 2020-02-26 11:36:37 --> URI Class Initialized
INFO - 2020-02-26 11:36:37 --> Controller Class Initialized
INFO - 2020-02-26 11:36:37 --> URI Class Initialized
INFO - 2020-02-26 11:36:37 --> Router Class Initialized
INFO - 2020-02-26 11:36:37 --> Router Class Initialized
INFO - 2020-02-26 11:36:37 --> Router Class Initialized
INFO - 2020-02-26 11:36:37 --> Router Class Initialized
INFO - 2020-02-26 11:36:37 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:36:37 --> Output Class Initialized
INFO - 2020-02-26 11:36:37 --> Output Class Initialized
INFO - 2020-02-26 11:36:37 --> Output Class Initialized
INFO - 2020-02-26 11:36:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:36:37 --> Security Class Initialized
INFO - 2020-02-26 11:36:37 --> Security Class Initialized
INFO - 2020-02-26 11:36:37 --> Output Class Initialized
INFO - 2020-02-26 11:36:37 --> Security Class Initialized
INFO - 2020-02-26 11:36:37 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 11:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:37 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:37 --> Input Class Initialized
INFO - 2020-02-26 11:36:37 --> Input Class Initialized
INFO - 2020-02-26 11:36:37 --> Input Class Initialized
DEBUG - 2020-02-26 11:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:37 --> Helper loaded: form_helper
INFO - 2020-02-26 11:36:37 --> Form Validation Class Initialized
INFO - 2020-02-26 11:36:37 --> Language Class Initialized
INFO - 2020-02-26 11:36:37 --> Language Class Initialized
INFO - 2020-02-26 11:36:37 --> Language Class Initialized
INFO - 2020-02-26 11:36:37 --> Input Class Initialized
INFO - 2020-02-26 11:36:37 --> Language Class Initialized
ERROR - 2020-02-26 11:36:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-26 11:36:37 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 11:36:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 11:36:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 11:36:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 11:36:37 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 11:36:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 11:36:37 --> Config Class Initialized
INFO - 2020-02-26 11:36:37 --> Hooks Class Initialized
INFO - 2020-02-26 11:36:37 --> Final output sent to browser
DEBUG - 2020-02-26 11:36:37 --> Total execution time: 0.9091
DEBUG - 2020-02-26 11:36:37 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:37 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:37 --> URI Class Initialized
INFO - 2020-02-26 11:36:37 --> Router Class Initialized
INFO - 2020-02-26 11:36:37 --> Output Class Initialized
INFO - 2020-02-26 11:36:37 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:37 --> Input Class Initialized
INFO - 2020-02-26 11:36:37 --> Language Class Initialized
ERROR - 2020-02-26 11:36:37 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 11:36:37 --> Config Class Initialized
INFO - 2020-02-26 11:36:37 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:36:37 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:37 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:37 --> URI Class Initialized
INFO - 2020-02-26 11:36:38 --> Router Class Initialized
INFO - 2020-02-26 11:36:38 --> Output Class Initialized
INFO - 2020-02-26 11:36:38 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:38 --> Input Class Initialized
INFO - 2020-02-26 11:36:38 --> Language Class Initialized
ERROR - 2020-02-26 11:36:38 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 11:36:38 --> Config Class Initialized
INFO - 2020-02-26 11:36:38 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:36:38 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:38 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:38 --> URI Class Initialized
INFO - 2020-02-26 11:36:38 --> Router Class Initialized
INFO - 2020-02-26 11:36:38 --> Output Class Initialized
INFO - 2020-02-26 11:36:38 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:38 --> Input Class Initialized
INFO - 2020-02-26 11:36:38 --> Language Class Initialized
ERROR - 2020-02-26 11:36:38 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 11:36:38 --> Config Class Initialized
INFO - 2020-02-26 11:36:38 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:36:38 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:38 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:38 --> URI Class Initialized
INFO - 2020-02-26 11:36:38 --> Router Class Initialized
INFO - 2020-02-26 11:36:38 --> Output Class Initialized
INFO - 2020-02-26 11:36:38 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:38 --> Input Class Initialized
INFO - 2020-02-26 11:36:38 --> Language Class Initialized
ERROR - 2020-02-26 11:36:38 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 11:36:38 --> Config Class Initialized
INFO - 2020-02-26 11:36:38 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:36:38 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:38 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:38 --> URI Class Initialized
INFO - 2020-02-26 11:36:38 --> Router Class Initialized
INFO - 2020-02-26 11:36:38 --> Output Class Initialized
INFO - 2020-02-26 11:36:38 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:38 --> Input Class Initialized
INFO - 2020-02-26 11:36:38 --> Language Class Initialized
ERROR - 2020-02-26 11:36:38 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 11:36:39 --> Config Class Initialized
INFO - 2020-02-26 11:36:39 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:36:39 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:39 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:39 --> URI Class Initialized
INFO - 2020-02-26 11:36:39 --> Router Class Initialized
INFO - 2020-02-26 11:36:39 --> Output Class Initialized
INFO - 2020-02-26 11:36:39 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:39 --> Input Class Initialized
INFO - 2020-02-26 11:36:39 --> Language Class Initialized
ERROR - 2020-02-26 11:36:39 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 11:36:39 --> Config Class Initialized
INFO - 2020-02-26 11:36:39 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:36:39 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:39 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:39 --> URI Class Initialized
INFO - 2020-02-26 11:36:39 --> Router Class Initialized
INFO - 2020-02-26 11:36:39 --> Output Class Initialized
INFO - 2020-02-26 11:36:39 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:39 --> Input Class Initialized
INFO - 2020-02-26 11:36:39 --> Language Class Initialized
ERROR - 2020-02-26 11:36:39 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 11:36:39 --> Config Class Initialized
INFO - 2020-02-26 11:36:39 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:36:39 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:39 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:39 --> URI Class Initialized
INFO - 2020-02-26 11:36:39 --> Router Class Initialized
INFO - 2020-02-26 11:36:39 --> Output Class Initialized
INFO - 2020-02-26 11:36:39 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:39 --> Input Class Initialized
INFO - 2020-02-26 11:36:39 --> Language Class Initialized
ERROR - 2020-02-26 11:36:39 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 11:36:39 --> Config Class Initialized
INFO - 2020-02-26 11:36:39 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:36:39 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:36:39 --> Utf8 Class Initialized
INFO - 2020-02-26 11:36:39 --> URI Class Initialized
INFO - 2020-02-26 11:36:39 --> Router Class Initialized
INFO - 2020-02-26 11:36:39 --> Output Class Initialized
INFO - 2020-02-26 11:36:39 --> Security Class Initialized
DEBUG - 2020-02-26 11:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:36:39 --> Input Class Initialized
INFO - 2020-02-26 11:36:40 --> Language Class Initialized
ERROR - 2020-02-26 11:36:40 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 11:37:08 --> Config Class Initialized
INFO - 2020-02-26 11:37:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:37:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:37:08 --> Utf8 Class Initialized
INFO - 2020-02-26 11:37:09 --> URI Class Initialized
INFO - 2020-02-26 11:37:09 --> Router Class Initialized
INFO - 2020-02-26 11:37:09 --> Output Class Initialized
INFO - 2020-02-26 11:37:09 --> Security Class Initialized
DEBUG - 2020-02-26 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:37:09 --> Input Class Initialized
INFO - 2020-02-26 11:37:09 --> Language Class Initialized
INFO - 2020-02-26 11:37:09 --> Loader Class Initialized
INFO - 2020-02-26 11:37:09 --> Helper loaded: url_helper
INFO - 2020-02-26 11:37:09 --> Helper loaded: string_helper
INFO - 2020-02-26 11:37:09 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:37:09 --> Controller Class Initialized
INFO - 2020-02-26 11:37:09 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:37:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:37:09 --> Model "M_pesan" initialized
INFO - 2020-02-26 11:37:09 --> Helper loaded: form_helper
INFO - 2020-02-26 11:37:09 --> Form Validation Class Initialized
INFO - 2020-02-26 17:37:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 17:37:09 --> Final output sent to browser
DEBUG - 2020-02-26 17:37:09 --> Total execution time: 0.6374
INFO - 2020-02-26 11:37:12 --> Config Class Initialized
INFO - 2020-02-26 11:37:12 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:37:12 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:37:12 --> Utf8 Class Initialized
INFO - 2020-02-26 11:37:12 --> URI Class Initialized
INFO - 2020-02-26 11:37:12 --> Router Class Initialized
INFO - 2020-02-26 11:37:12 --> Output Class Initialized
INFO - 2020-02-26 11:37:12 --> Security Class Initialized
DEBUG - 2020-02-26 11:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:37:13 --> Input Class Initialized
INFO - 2020-02-26 11:37:13 --> Language Class Initialized
INFO - 2020-02-26 11:37:13 --> Loader Class Initialized
INFO - 2020-02-26 11:37:13 --> Helper loaded: url_helper
INFO - 2020-02-26 11:37:13 --> Helper loaded: string_helper
INFO - 2020-02-26 11:37:13 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:37:13 --> Controller Class Initialized
INFO - 2020-02-26 11:37:13 --> Model "M_tiket" initialized
INFO - 2020-02-26 11:37:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 11:37:13 --> Model "M_pesan" initialized
INFO - 2020-02-26 11:37:13 --> Helper loaded: form_helper
INFO - 2020-02-26 11:37:13 --> Form Validation Class Initialized
ERROR - 2020-02-26 11:37:13 --> Severity: Warning --> strtotime() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 39
ERROR - 2020-02-26 11:37:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 41
ERROR - 2020-02-26 11:37:13 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 44
ERROR - 2020-02-26 11:37:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 50
ERROR - 2020-02-26 11:37:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 52
INFO - 2020-02-26 11:37:13 --> Config Class Initialized
INFO - 2020-02-26 11:37:13 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:37:13 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:37:13 --> Utf8 Class Initialized
INFO - 2020-02-26 11:37:13 --> URI Class Initialized
INFO - 2020-02-26 11:37:13 --> Router Class Initialized
INFO - 2020-02-26 11:37:13 --> Output Class Initialized
INFO - 2020-02-26 11:37:13 --> Security Class Initialized
DEBUG - 2020-02-26 11:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:37:13 --> Input Class Initialized
INFO - 2020-02-26 11:37:13 --> Language Class Initialized
INFO - 2020-02-26 11:37:13 --> Loader Class Initialized
INFO - 2020-02-26 11:37:13 --> Helper loaded: url_helper
INFO - 2020-02-26 11:37:13 --> Helper loaded: string_helper
INFO - 2020-02-26 11:37:13 --> Database Driver Class Initialized
DEBUG - 2020-02-26 11:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 11:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 11:37:13 --> Controller Class Initialized
INFO - 2020-02-26 11:37:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 11:37:13 --> Pagination Class Initialized
INFO - 2020-02-26 11:37:13 --> Model "M_show" initialized
INFO - 2020-02-26 11:37:13 --> Helper loaded: form_helper
INFO - 2020-02-26 11:37:13 --> Form Validation Class Initialized
INFO - 2020-02-26 11:37:13 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 11:37:13 --> Final output sent to browser
DEBUG - 2020-02-26 11:37:14 --> Total execution time: 0.5186
INFO - 2020-02-26 11:37:14 --> Config Class Initialized
INFO - 2020-02-26 11:37:14 --> Config Class Initialized
INFO - 2020-02-26 11:37:14 --> Hooks Class Initialized
INFO - 2020-02-26 11:37:14 --> Hooks Class Initialized
DEBUG - 2020-02-26 11:37:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 11:37:14 --> UTF-8 Support Enabled
INFO - 2020-02-26 11:37:14 --> Utf8 Class Initialized
INFO - 2020-02-26 11:37:14 --> Utf8 Class Initialized
INFO - 2020-02-26 11:37:14 --> URI Class Initialized
INFO - 2020-02-26 11:37:14 --> URI Class Initialized
INFO - 2020-02-26 11:37:14 --> Router Class Initialized
INFO - 2020-02-26 11:37:14 --> Router Class Initialized
INFO - 2020-02-26 11:37:14 --> Output Class Initialized
INFO - 2020-02-26 11:37:14 --> Output Class Initialized
INFO - 2020-02-26 11:37:14 --> Security Class Initialized
INFO - 2020-02-26 11:37:14 --> Security Class Initialized
DEBUG - 2020-02-26 11:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 11:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 11:37:14 --> Input Class Initialized
INFO - 2020-02-26 11:37:14 --> Input Class Initialized
INFO - 2020-02-26 11:37:14 --> Language Class Initialized
INFO - 2020-02-26 11:37:14 --> Language Class Initialized
ERROR - 2020-02-26 11:37:14 --> 404 Page Not Found: Show/assets
ERROR - 2020-02-26 11:37:14 --> 404 Page Not Found: Show/assets
INFO - 2020-02-26 14:09:08 --> Config Class Initialized
INFO - 2020-02-26 14:09:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:09:09 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:09:09 --> Utf8 Class Initialized
INFO - 2020-02-26 14:09:09 --> URI Class Initialized
INFO - 2020-02-26 14:09:09 --> Router Class Initialized
INFO - 2020-02-26 14:09:09 --> Output Class Initialized
INFO - 2020-02-26 14:09:09 --> Security Class Initialized
DEBUG - 2020-02-26 14:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:09:10 --> Input Class Initialized
INFO - 2020-02-26 14:09:10 --> Language Class Initialized
INFO - 2020-02-26 14:09:10 --> Loader Class Initialized
INFO - 2020-02-26 14:09:10 --> Helper loaded: url_helper
INFO - 2020-02-26 14:09:10 --> Helper loaded: string_helper
INFO - 2020-02-26 14:09:10 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:09:11 --> Controller Class Initialized
INFO - 2020-02-26 14:09:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 14:09:11 --> Pagination Class Initialized
INFO - 2020-02-26 14:09:11 --> Model "M_show" initialized
INFO - 2020-02-26 14:09:12 --> Helper loaded: form_helper
INFO - 2020-02-26 14:09:12 --> Form Validation Class Initialized
INFO - 2020-02-26 14:09:12 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 14:09:12 --> Final output sent to browser
DEBUG - 2020-02-26 14:09:12 --> Total execution time: 4.7786
INFO - 2020-02-26 14:09:13 --> Config Class Initialized
INFO - 2020-02-26 14:09:13 --> Config Class Initialized
INFO - 2020-02-26 14:09:13 --> Hooks Class Initialized
INFO - 2020-02-26 14:09:13 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:09:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:09:13 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:09:13 --> Utf8 Class Initialized
INFO - 2020-02-26 14:09:13 --> Utf8 Class Initialized
INFO - 2020-02-26 14:09:13 --> URI Class Initialized
INFO - 2020-02-26 14:09:13 --> URI Class Initialized
INFO - 2020-02-26 14:09:13 --> Router Class Initialized
INFO - 2020-02-26 14:09:13 --> Router Class Initialized
INFO - 2020-02-26 14:09:13 --> Output Class Initialized
INFO - 2020-02-26 14:09:13 --> Output Class Initialized
INFO - 2020-02-26 14:09:13 --> Security Class Initialized
INFO - 2020-02-26 14:09:13 --> Security Class Initialized
DEBUG - 2020-02-26 14:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 14:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:09:13 --> Input Class Initialized
INFO - 2020-02-26 14:09:13 --> Input Class Initialized
INFO - 2020-02-26 14:09:13 --> Language Class Initialized
INFO - 2020-02-26 14:09:13 --> Language Class Initialized
ERROR - 2020-02-26 14:09:13 --> 404 Page Not Found: Show/assets
ERROR - 2020-02-26 14:09:13 --> 404 Page Not Found: Show/assets
INFO - 2020-02-26 14:15:12 --> Config Class Initialized
INFO - 2020-02-26 14:15:12 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:12 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:12 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:12 --> URI Class Initialized
INFO - 2020-02-26 14:15:12 --> Router Class Initialized
INFO - 2020-02-26 14:15:12 --> Output Class Initialized
INFO - 2020-02-26 14:15:12 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:12 --> Input Class Initialized
INFO - 2020-02-26 14:15:12 --> Language Class Initialized
INFO - 2020-02-26 14:15:12 --> Loader Class Initialized
INFO - 2020-02-26 14:15:13 --> Helper loaded: url_helper
INFO - 2020-02-26 14:15:13 --> Helper loaded: string_helper
INFO - 2020-02-26 14:15:13 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:15:13 --> Controller Class Initialized
INFO - 2020-02-26 14:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 14:15:13 --> Pagination Class Initialized
INFO - 2020-02-26 14:15:13 --> Model "M_show" initialized
INFO - 2020-02-26 14:15:13 --> Helper loaded: form_helper
INFO - 2020-02-26 14:15:13 --> Form Validation Class Initialized
INFO - 2020-02-26 14:15:13 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 14:15:13 --> Final output sent to browser
DEBUG - 2020-02-26 14:15:13 --> Total execution time: 1.3313
INFO - 2020-02-26 14:15:13 --> Config Class Initialized
INFO - 2020-02-26 14:15:13 --> Config Class Initialized
INFO - 2020-02-26 14:15:13 --> Hooks Class Initialized
INFO - 2020-02-26 14:15:13 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:15:13 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:13 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:13 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:14 --> URI Class Initialized
INFO - 2020-02-26 14:15:14 --> URI Class Initialized
INFO - 2020-02-26 14:15:14 --> Router Class Initialized
INFO - 2020-02-26 14:15:14 --> Router Class Initialized
INFO - 2020-02-26 14:15:14 --> Output Class Initialized
INFO - 2020-02-26 14:15:14 --> Output Class Initialized
INFO - 2020-02-26 14:15:14 --> Security Class Initialized
INFO - 2020-02-26 14:15:14 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 14:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:14 --> Input Class Initialized
INFO - 2020-02-26 14:15:14 --> Input Class Initialized
INFO - 2020-02-26 14:15:14 --> Language Class Initialized
INFO - 2020-02-26 14:15:14 --> Language Class Initialized
ERROR - 2020-02-26 14:15:14 --> 404 Page Not Found: Show/assets
ERROR - 2020-02-26 14:15:14 --> 404 Page Not Found: Show/assets
INFO - 2020-02-26 14:15:16 --> Config Class Initialized
INFO - 2020-02-26 14:15:16 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:16 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:16 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:17 --> URI Class Initialized
INFO - 2020-02-26 14:15:17 --> Router Class Initialized
INFO - 2020-02-26 14:15:17 --> Output Class Initialized
INFO - 2020-02-26 14:15:17 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:17 --> Input Class Initialized
INFO - 2020-02-26 14:15:17 --> Language Class Initialized
INFO - 2020-02-26 14:15:17 --> Loader Class Initialized
INFO - 2020-02-26 14:15:17 --> Helper loaded: url_helper
INFO - 2020-02-26 14:15:17 --> Helper loaded: string_helper
INFO - 2020-02-26 14:15:17 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:15:17 --> Controller Class Initialized
INFO - 2020-02-26 14:15:17 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:15:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:15:17 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:15:17 --> Helper loaded: form_helper
INFO - 2020-02-26 14:15:17 --> Form Validation Class Initialized
INFO - 2020-02-26 14:15:17 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 14:15:17 --> Final output sent to browser
DEBUG - 2020-02-26 14:15:18 --> Total execution time: 1.1149
INFO - 2020-02-26 14:15:18 --> Config Class Initialized
INFO - 2020-02-26 14:15:18 --> Config Class Initialized
INFO - 2020-02-26 14:15:18 --> Config Class Initialized
INFO - 2020-02-26 14:15:18 --> Config Class Initialized
INFO - 2020-02-26 14:15:18 --> Config Class Initialized
INFO - 2020-02-26 14:15:18 --> Config Class Initialized
INFO - 2020-02-26 14:15:18 --> Hooks Class Initialized
INFO - 2020-02-26 14:15:18 --> Hooks Class Initialized
INFO - 2020-02-26 14:15:18 --> Hooks Class Initialized
INFO - 2020-02-26 14:15:18 --> Hooks Class Initialized
INFO - 2020-02-26 14:15:18 --> Hooks Class Initialized
INFO - 2020-02-26 14:15:18 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:15:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:15:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:15:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:15:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:15:18 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:18 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:18 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:18 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:18 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:18 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:18 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:18 --> URI Class Initialized
INFO - 2020-02-26 14:15:18 --> URI Class Initialized
INFO - 2020-02-26 14:15:18 --> URI Class Initialized
INFO - 2020-02-26 14:15:18 --> URI Class Initialized
INFO - 2020-02-26 14:15:18 --> URI Class Initialized
INFO - 2020-02-26 14:15:18 --> URI Class Initialized
INFO - 2020-02-26 14:15:18 --> Router Class Initialized
INFO - 2020-02-26 14:15:18 --> Router Class Initialized
INFO - 2020-02-26 14:15:18 --> Router Class Initialized
INFO - 2020-02-26 14:15:18 --> Router Class Initialized
INFO - 2020-02-26 14:15:18 --> Router Class Initialized
INFO - 2020-02-26 14:15:18 --> Router Class Initialized
INFO - 2020-02-26 14:15:18 --> Output Class Initialized
INFO - 2020-02-26 14:15:18 --> Output Class Initialized
INFO - 2020-02-26 14:15:18 --> Output Class Initialized
INFO - 2020-02-26 14:15:18 --> Output Class Initialized
INFO - 2020-02-26 14:15:18 --> Output Class Initialized
INFO - 2020-02-26 14:15:18 --> Output Class Initialized
INFO - 2020-02-26 14:15:18 --> Security Class Initialized
INFO - 2020-02-26 14:15:18 --> Security Class Initialized
INFO - 2020-02-26 14:15:18 --> Security Class Initialized
INFO - 2020-02-26 14:15:18 --> Security Class Initialized
INFO - 2020-02-26 14:15:18 --> Security Class Initialized
INFO - 2020-02-26 14:15:18 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 14:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 14:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 14:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 14:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 14:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:18 --> Input Class Initialized
INFO - 2020-02-26 14:15:18 --> Input Class Initialized
INFO - 2020-02-26 14:15:18 --> Input Class Initialized
INFO - 2020-02-26 14:15:18 --> Input Class Initialized
INFO - 2020-02-26 14:15:18 --> Input Class Initialized
INFO - 2020-02-26 14:15:18 --> Input Class Initialized
INFO - 2020-02-26 14:15:18 --> Language Class Initialized
INFO - 2020-02-26 14:15:18 --> Language Class Initialized
INFO - 2020-02-26 14:15:18 --> Language Class Initialized
INFO - 2020-02-26 14:15:18 --> Language Class Initialized
INFO - 2020-02-26 14:15:18 --> Language Class Initialized
INFO - 2020-02-26 14:15:18 --> Language Class Initialized
ERROR - 2020-02-26 14:15:18 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-26 14:15:18 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 14:15:18 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-26 14:15:18 --> Loader Class Initialized
INFO - 2020-02-26 14:15:18 --> Loader Class Initialized
ERROR - 2020-02-26 14:15:18 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 14:15:18 --> Helper loaded: url_helper
INFO - 2020-02-26 14:15:18 --> Helper loaded: url_helper
INFO - 2020-02-26 14:15:18 --> Config Class Initialized
INFO - 2020-02-26 14:15:18 --> Config Class Initialized
INFO - 2020-02-26 14:15:18 --> Config Class Initialized
INFO - 2020-02-26 14:15:18 --> Hooks Class Initialized
INFO - 2020-02-26 14:15:18 --> Hooks Class Initialized
INFO - 2020-02-26 14:15:18 --> Hooks Class Initialized
INFO - 2020-02-26 14:15:18 --> Helper loaded: string_helper
INFO - 2020-02-26 14:15:18 --> Helper loaded: string_helper
DEBUG - 2020-02-26 14:15:18 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:18 --> Database Driver Class Initialized
INFO - 2020-02-26 14:15:18 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:15:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:15:18 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:18 --> Config Class Initialized
INFO - 2020-02-26 14:15:18 --> Hooks Class Initialized
INFO - 2020-02-26 14:15:18 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:18 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:18 --> Utf8 Class Initialized
DEBUG - 2020-02-26 14:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-26 14:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:15:18 --> URI Class Initialized
INFO - 2020-02-26 14:15:18 --> URI Class Initialized
INFO - 2020-02-26 14:15:18 --> URI Class Initialized
DEBUG - 2020-02-26 14:15:18 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:18 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:18 --> Controller Class Initialized
INFO - 2020-02-26 14:15:18 --> Router Class Initialized
INFO - 2020-02-26 14:15:18 --> Router Class Initialized
INFO - 2020-02-26 14:15:18 --> Router Class Initialized
INFO - 2020-02-26 14:15:18 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:15:18 --> Output Class Initialized
INFO - 2020-02-26 14:15:18 --> Output Class Initialized
INFO - 2020-02-26 14:15:18 --> Output Class Initialized
INFO - 2020-02-26 14:15:18 --> URI Class Initialized
INFO - 2020-02-26 14:15:18 --> Security Class Initialized
INFO - 2020-02-26 14:15:18 --> Security Class Initialized
INFO - 2020-02-26 14:15:18 --> Router Class Initialized
INFO - 2020-02-26 14:15:18 --> Security Class Initialized
INFO - 2020-02-26 14:15:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:15:18 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 14:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 14:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 14:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:18 --> Output Class Initialized
INFO - 2020-02-26 14:15:18 --> Input Class Initialized
INFO - 2020-02-26 14:15:18 --> Input Class Initialized
INFO - 2020-02-26 14:15:18 --> Input Class Initialized
INFO - 2020-02-26 14:15:18 --> Security Class Initialized
INFO - 2020-02-26 14:15:18 --> Helper loaded: form_helper
INFO - 2020-02-26 14:15:18 --> Form Validation Class Initialized
INFO - 2020-02-26 14:15:18 --> Language Class Initialized
INFO - 2020-02-26 14:15:18 --> Language Class Initialized
INFO - 2020-02-26 14:15:18 --> Language Class Initialized
DEBUG - 2020-02-26 14:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:18 --> Input Class Initialized
ERROR - 2020-02-26 14:15:18 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-26 14:15:18 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 14:15:18 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 14:15:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 14:15:18 --> Language Class Initialized
INFO - 2020-02-26 14:15:18 --> Config Class Initialized
INFO - 2020-02-26 14:15:18 --> Config Class Initialized
INFO - 2020-02-26 14:15:18 --> Config Class Initialized
INFO - 2020-02-26 14:15:18 --> Hooks Class Initialized
INFO - 2020-02-26 14:15:18 --> Hooks Class Initialized
INFO - 2020-02-26 14:15:18 --> Hooks Class Initialized
ERROR - 2020-02-26 14:15:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-26 14:15:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 14:15:19 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-26 14:15:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:15:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:15:19 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:19 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:19 --> Final output sent to browser
INFO - 2020-02-26 14:15:19 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:19 --> Utf8 Class Initialized
DEBUG - 2020-02-26 14:15:19 --> Total execution time: 0.9776
INFO - 2020-02-26 14:15:19 --> URI Class Initialized
INFO - 2020-02-26 14:15:19 --> URI Class Initialized
INFO - 2020-02-26 14:15:19 --> URI Class Initialized
INFO - 2020-02-26 14:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:15:19 --> Router Class Initialized
INFO - 2020-02-26 14:15:19 --> Router Class Initialized
INFO - 2020-02-26 14:15:19 --> Router Class Initialized
INFO - 2020-02-26 14:15:19 --> Controller Class Initialized
INFO - 2020-02-26 14:15:19 --> Output Class Initialized
INFO - 2020-02-26 14:15:19 --> Output Class Initialized
INFO - 2020-02-26 14:15:19 --> Output Class Initialized
INFO - 2020-02-26 14:15:19 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:15:19 --> Security Class Initialized
INFO - 2020-02-26 14:15:19 --> Security Class Initialized
INFO - 2020-02-26 14:15:19 --> Security Class Initialized
INFO - 2020-02-26 14:15:19 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-26 14:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 14:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 14:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:19 --> Input Class Initialized
INFO - 2020-02-26 14:15:19 --> Input Class Initialized
INFO - 2020-02-26 14:15:19 --> Input Class Initialized
INFO - 2020-02-26 14:15:19 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:15:19 --> Language Class Initialized
INFO - 2020-02-26 14:15:19 --> Language Class Initialized
INFO - 2020-02-26 14:15:19 --> Language Class Initialized
INFO - 2020-02-26 14:15:19 --> Helper loaded: form_helper
INFO - 2020-02-26 14:15:19 --> Form Validation Class Initialized
ERROR - 2020-02-26 14:15:19 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 14:15:19 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 14:15:19 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 14:15:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 14:15:19 --> Config Class Initialized
INFO - 2020-02-26 14:15:19 --> Hooks Class Initialized
ERROR - 2020-02-26 14:15:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 14:15:19 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-26 14:15:19 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:19 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:19 --> Final output sent to browser
DEBUG - 2020-02-26 14:15:19 --> Total execution time: 1.3669
INFO - 2020-02-26 14:15:19 --> URI Class Initialized
INFO - 2020-02-26 14:15:19 --> Router Class Initialized
INFO - 2020-02-26 14:15:19 --> Output Class Initialized
INFO - 2020-02-26 14:15:19 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:19 --> Input Class Initialized
INFO - 2020-02-26 14:15:19 --> Language Class Initialized
ERROR - 2020-02-26 14:15:19 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 14:15:19 --> Config Class Initialized
INFO - 2020-02-26 14:15:19 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:19 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:19 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:19 --> URI Class Initialized
INFO - 2020-02-26 14:15:19 --> Router Class Initialized
INFO - 2020-02-26 14:15:19 --> Output Class Initialized
INFO - 2020-02-26 14:15:19 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:20 --> Input Class Initialized
INFO - 2020-02-26 14:15:20 --> Language Class Initialized
ERROR - 2020-02-26 14:15:20 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 14:15:20 --> Config Class Initialized
INFO - 2020-02-26 14:15:20 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:20 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:20 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:20 --> URI Class Initialized
INFO - 2020-02-26 14:15:20 --> Router Class Initialized
INFO - 2020-02-26 14:15:20 --> Output Class Initialized
INFO - 2020-02-26 14:15:20 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:20 --> Input Class Initialized
INFO - 2020-02-26 14:15:20 --> Language Class Initialized
ERROR - 2020-02-26 14:15:20 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 14:15:20 --> Config Class Initialized
INFO - 2020-02-26 14:15:20 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:20 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:20 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:20 --> URI Class Initialized
INFO - 2020-02-26 14:15:20 --> Router Class Initialized
INFO - 2020-02-26 14:15:20 --> Output Class Initialized
INFO - 2020-02-26 14:15:20 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:20 --> Input Class Initialized
INFO - 2020-02-26 14:15:20 --> Language Class Initialized
ERROR - 2020-02-26 14:15:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 14:15:20 --> Config Class Initialized
INFO - 2020-02-26 14:15:20 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:20 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:20 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:20 --> URI Class Initialized
INFO - 2020-02-26 14:15:21 --> Router Class Initialized
INFO - 2020-02-26 14:15:21 --> Output Class Initialized
INFO - 2020-02-26 14:15:21 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:21 --> Input Class Initialized
INFO - 2020-02-26 14:15:21 --> Language Class Initialized
ERROR - 2020-02-26 14:15:21 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 14:15:21 --> Config Class Initialized
INFO - 2020-02-26 14:15:21 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:21 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:21 --> URI Class Initialized
INFO - 2020-02-26 14:15:21 --> Router Class Initialized
INFO - 2020-02-26 14:15:21 --> Output Class Initialized
INFO - 2020-02-26 14:15:21 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:21 --> Input Class Initialized
INFO - 2020-02-26 14:15:21 --> Language Class Initialized
ERROR - 2020-02-26 14:15:21 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 14:15:21 --> Config Class Initialized
INFO - 2020-02-26 14:15:21 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:21 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:21 --> URI Class Initialized
INFO - 2020-02-26 14:15:21 --> Router Class Initialized
INFO - 2020-02-26 14:15:21 --> Output Class Initialized
INFO - 2020-02-26 14:15:21 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:21 --> Input Class Initialized
INFO - 2020-02-26 14:15:21 --> Language Class Initialized
ERROR - 2020-02-26 14:15:21 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 14:15:21 --> Config Class Initialized
INFO - 2020-02-26 14:15:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:22 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:22 --> URI Class Initialized
INFO - 2020-02-26 14:15:22 --> Router Class Initialized
INFO - 2020-02-26 14:15:22 --> Output Class Initialized
INFO - 2020-02-26 14:15:22 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:22 --> Input Class Initialized
INFO - 2020-02-26 14:15:22 --> Language Class Initialized
ERROR - 2020-02-26 14:15:22 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 14:15:22 --> Config Class Initialized
INFO - 2020-02-26 14:15:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:22 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:22 --> URI Class Initialized
INFO - 2020-02-26 14:15:22 --> Router Class Initialized
INFO - 2020-02-26 14:15:22 --> Output Class Initialized
INFO - 2020-02-26 14:15:22 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:22 --> Input Class Initialized
INFO - 2020-02-26 14:15:22 --> Language Class Initialized
ERROR - 2020-02-26 14:15:22 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 14:15:50 --> Config Class Initialized
INFO - 2020-02-26 14:15:50 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:50 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:50 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:50 --> URI Class Initialized
INFO - 2020-02-26 14:15:50 --> Router Class Initialized
INFO - 2020-02-26 14:15:50 --> Output Class Initialized
INFO - 2020-02-26 14:15:50 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:51 --> Input Class Initialized
INFO - 2020-02-26 14:15:51 --> Language Class Initialized
INFO - 2020-02-26 14:15:51 --> Loader Class Initialized
INFO - 2020-02-26 14:15:51 --> Helper loaded: url_helper
INFO - 2020-02-26 14:15:51 --> Helper loaded: string_helper
INFO - 2020-02-26 14:15:51 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:15:51 --> Controller Class Initialized
INFO - 2020-02-26 14:15:51 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:15:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:15:51 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:15:51 --> Helper loaded: form_helper
INFO - 2020-02-26 14:15:51 --> Form Validation Class Initialized
INFO - 2020-02-26 20:15:51 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 20:15:51 --> Final output sent to browser
DEBUG - 2020-02-26 20:15:51 --> Total execution time: 1.1169
INFO - 2020-02-26 14:15:56 --> Config Class Initialized
INFO - 2020-02-26 14:15:56 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:56 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:56 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:56 --> URI Class Initialized
INFO - 2020-02-26 14:15:56 --> Router Class Initialized
INFO - 2020-02-26 14:15:56 --> Output Class Initialized
INFO - 2020-02-26 14:15:56 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:56 --> Input Class Initialized
INFO - 2020-02-26 14:15:56 --> Language Class Initialized
INFO - 2020-02-26 14:15:57 --> Loader Class Initialized
INFO - 2020-02-26 14:15:57 --> Helper loaded: url_helper
INFO - 2020-02-26 14:15:57 --> Helper loaded: string_helper
INFO - 2020-02-26 14:15:57 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:15:57 --> Controller Class Initialized
INFO - 2020-02-26 14:15:57 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:15:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:15:57 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:15:57 --> Helper loaded: form_helper
INFO - 2020-02-26 14:15:57 --> Form Validation Class Initialized
ERROR - 2020-02-26 14:15:57 --> Severity: Warning --> strtotime() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 39
ERROR - 2020-02-26 14:15:57 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 41
ERROR - 2020-02-26 14:15:57 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 44
INFO - 2020-02-26 14:15:57 --> Config Class Initialized
INFO - 2020-02-26 14:15:57 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:57 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:58 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:58 --> URI Class Initialized
INFO - 2020-02-26 14:15:58 --> Router Class Initialized
INFO - 2020-02-26 14:15:58 --> Output Class Initialized
INFO - 2020-02-26 14:15:58 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:58 --> Input Class Initialized
INFO - 2020-02-26 14:15:58 --> Language Class Initialized
INFO - 2020-02-26 14:15:58 --> Loader Class Initialized
INFO - 2020-02-26 14:15:58 --> Helper loaded: url_helper
INFO - 2020-02-26 14:15:58 --> Helper loaded: string_helper
INFO - 2020-02-26 14:15:58 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:15:58 --> Controller Class Initialized
INFO - 2020-02-26 14:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 14:15:58 --> Pagination Class Initialized
INFO - 2020-02-26 14:15:58 --> Model "M_show" initialized
INFO - 2020-02-26 14:15:58 --> Helper loaded: form_helper
INFO - 2020-02-26 14:15:58 --> Form Validation Class Initialized
INFO - 2020-02-26 14:15:58 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 14:15:58 --> Final output sent to browser
DEBUG - 2020-02-26 14:15:58 --> Total execution time: 0.7224
INFO - 2020-02-26 14:15:58 --> Config Class Initialized
INFO - 2020-02-26 14:15:58 --> Config Class Initialized
INFO - 2020-02-26 14:15:58 --> Hooks Class Initialized
INFO - 2020-02-26 14:15:58 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:15:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:15:58 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:15:59 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:59 --> Utf8 Class Initialized
INFO - 2020-02-26 14:15:59 --> URI Class Initialized
INFO - 2020-02-26 14:15:59 --> URI Class Initialized
INFO - 2020-02-26 14:15:59 --> Router Class Initialized
INFO - 2020-02-26 14:15:59 --> Router Class Initialized
INFO - 2020-02-26 14:15:59 --> Output Class Initialized
INFO - 2020-02-26 14:15:59 --> Output Class Initialized
INFO - 2020-02-26 14:15:59 --> Security Class Initialized
INFO - 2020-02-26 14:15:59 --> Security Class Initialized
DEBUG - 2020-02-26 14:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 14:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:15:59 --> Input Class Initialized
INFO - 2020-02-26 14:15:59 --> Input Class Initialized
INFO - 2020-02-26 14:15:59 --> Language Class Initialized
INFO - 2020-02-26 14:15:59 --> Language Class Initialized
ERROR - 2020-02-26 14:15:59 --> 404 Page Not Found: Show/assets
ERROR - 2020-02-26 14:15:59 --> 404 Page Not Found: Show/assets
INFO - 2020-02-26 14:20:36 --> Config Class Initialized
INFO - 2020-02-26 14:20:36 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:20:37 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:37 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:37 --> URI Class Initialized
INFO - 2020-02-26 14:20:37 --> Router Class Initialized
INFO - 2020-02-26 14:20:37 --> Output Class Initialized
INFO - 2020-02-26 14:20:37 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:37 --> Input Class Initialized
INFO - 2020-02-26 14:20:37 --> Language Class Initialized
INFO - 2020-02-26 14:20:37 --> Loader Class Initialized
INFO - 2020-02-26 14:20:37 --> Helper loaded: url_helper
INFO - 2020-02-26 14:20:37 --> Helper loaded: string_helper
INFO - 2020-02-26 14:20:37 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:20:37 --> Controller Class Initialized
INFO - 2020-02-26 14:20:37 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:20:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:20:37 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:20:37 --> Helper loaded: form_helper
INFO - 2020-02-26 14:20:37 --> Form Validation Class Initialized
INFO - 2020-02-26 14:20:38 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 14:20:38 --> Final output sent to browser
DEBUG - 2020-02-26 14:20:38 --> Total execution time: 1.1915
INFO - 2020-02-26 14:20:38 --> Config Class Initialized
INFO - 2020-02-26 14:20:38 --> Config Class Initialized
INFO - 2020-02-26 14:20:38 --> Config Class Initialized
INFO - 2020-02-26 14:20:38 --> Hooks Class Initialized
INFO - 2020-02-26 14:20:38 --> Hooks Class Initialized
INFO - 2020-02-26 14:20:38 --> Config Class Initialized
INFO - 2020-02-26 14:20:38 --> Hooks Class Initialized
INFO - 2020-02-26 14:20:38 --> Config Class Initialized
INFO - 2020-02-26 14:20:38 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:20:38 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:38 --> Config Class Initialized
INFO - 2020-02-26 14:20:38 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:20:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:20:38 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:38 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:38 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:38 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:38 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:20:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:20:38 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:38 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:38 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:38 --> URI Class Initialized
INFO - 2020-02-26 14:20:38 --> URI Class Initialized
INFO - 2020-02-26 14:20:38 --> URI Class Initialized
DEBUG - 2020-02-26 14:20:38 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:38 --> URI Class Initialized
INFO - 2020-02-26 14:20:38 --> URI Class Initialized
INFO - 2020-02-26 14:20:38 --> Router Class Initialized
INFO - 2020-02-26 14:20:38 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:38 --> Router Class Initialized
INFO - 2020-02-26 14:20:38 --> Router Class Initialized
INFO - 2020-02-26 14:20:38 --> Router Class Initialized
INFO - 2020-02-26 14:20:38 --> Output Class Initialized
INFO - 2020-02-26 14:20:38 --> Router Class Initialized
INFO - 2020-02-26 14:20:38 --> URI Class Initialized
INFO - 2020-02-26 14:20:38 --> Output Class Initialized
INFO - 2020-02-26 14:20:38 --> Output Class Initialized
INFO - 2020-02-26 14:20:38 --> Security Class Initialized
INFO - 2020-02-26 14:20:38 --> Security Class Initialized
INFO - 2020-02-26 14:20:38 --> Output Class Initialized
INFO - 2020-02-26 14:20:38 --> Output Class Initialized
INFO - 2020-02-26 14:20:38 --> Security Class Initialized
INFO - 2020-02-26 14:20:38 --> Router Class Initialized
DEBUG - 2020-02-26 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:38 --> Input Class Initialized
DEBUG - 2020-02-26 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:38 --> Security Class Initialized
INFO - 2020-02-26 14:20:38 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:38 --> Output Class Initialized
INFO - 2020-02-26 14:20:38 --> Input Class Initialized
INFO - 2020-02-26 14:20:38 --> Language Class Initialized
INFO - 2020-02-26 14:20:38 --> Input Class Initialized
DEBUG - 2020-02-26 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:38 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:38 --> Input Class Initialized
INFO - 2020-02-26 14:20:38 --> Language Class Initialized
ERROR - 2020-02-26 14:20:38 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 14:20:38 --> Input Class Initialized
DEBUG - 2020-02-26 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:38 --> Language Class Initialized
INFO - 2020-02-26 14:20:38 --> Language Class Initialized
INFO - 2020-02-26 14:20:38 --> Input Class Initialized
INFO - 2020-02-26 14:20:38 --> Language Class Initialized
INFO - 2020-02-26 14:20:38 --> Loader Class Initialized
INFO - 2020-02-26 14:20:38 --> Config Class Initialized
INFO - 2020-02-26 14:20:38 --> Loader Class Initialized
INFO - 2020-02-26 14:20:38 --> Hooks Class Initialized
ERROR - 2020-02-26 14:20:38 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 14:20:38 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-26 14:20:38 --> Language Class Initialized
INFO - 2020-02-26 14:20:38 --> Helper loaded: url_helper
INFO - 2020-02-26 14:20:38 --> Helper loaded: string_helper
INFO - 2020-02-26 14:20:38 --> Helper loaded: url_helper
DEBUG - 2020-02-26 14:20:38 --> UTF-8 Support Enabled
ERROR - 2020-02-26 14:20:38 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 14:20:38 --> Config Class Initialized
INFO - 2020-02-26 14:20:38 --> Config Class Initialized
INFO - 2020-02-26 14:20:38 --> Hooks Class Initialized
INFO - 2020-02-26 14:20:38 --> Hooks Class Initialized
INFO - 2020-02-26 14:20:38 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:38 --> Helper loaded: string_helper
INFO - 2020-02-26 14:20:38 --> Database Driver Class Initialized
INFO - 2020-02-26 14:20:38 --> Config Class Initialized
INFO - 2020-02-26 14:20:38 --> Hooks Class Initialized
INFO - 2020-02-26 14:20:38 --> URI Class Initialized
DEBUG - 2020-02-26 14:20:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:20:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:20:38 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:38 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:38 --> Router Class Initialized
INFO - 2020-02-26 14:20:38 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:20:38 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:38 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:38 --> Controller Class Initialized
INFO - 2020-02-26 14:20:38 --> URI Class Initialized
INFO - 2020-02-26 14:20:38 --> URI Class Initialized
INFO - 2020-02-26 14:20:38 --> Output Class Initialized
DEBUG - 2020-02-26 14:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:20:38 --> URI Class Initialized
INFO - 2020-02-26 14:20:38 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:20:38 --> Router Class Initialized
INFO - 2020-02-26 14:20:38 --> Router Class Initialized
INFO - 2020-02-26 14:20:38 --> Security Class Initialized
INFO - 2020-02-26 14:20:38 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-26 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:38 --> Output Class Initialized
INFO - 2020-02-26 14:20:38 --> Router Class Initialized
INFO - 2020-02-26 14:20:38 --> Output Class Initialized
INFO - 2020-02-26 14:20:38 --> Input Class Initialized
INFO - 2020-02-26 14:20:38 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:20:38 --> Output Class Initialized
INFO - 2020-02-26 14:20:38 --> Security Class Initialized
INFO - 2020-02-26 14:20:38 --> Security Class Initialized
INFO - 2020-02-26 14:20:38 --> Language Class Initialized
DEBUG - 2020-02-26 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:38 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:38 --> Helper loaded: form_helper
INFO - 2020-02-26 14:20:39 --> Form Validation Class Initialized
INFO - 2020-02-26 14:20:39 --> Input Class Initialized
INFO - 2020-02-26 14:20:39 --> Input Class Initialized
DEBUG - 2020-02-26 14:20:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-26 14:20:39 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 14:20:39 --> Input Class Initialized
INFO - 2020-02-26 14:20:39 --> Language Class Initialized
INFO - 2020-02-26 14:20:39 --> Language Class Initialized
ERROR - 2020-02-26 14:20:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 14:20:39 --> Config Class Initialized
INFO - 2020-02-26 14:20:39 --> Hooks Class Initialized
INFO - 2020-02-26 14:20:39 --> Language Class Initialized
ERROR - 2020-02-26 14:20:39 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 14:20:39 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 14:20:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 14:20:39 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 14:20:39 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-26 14:20:39 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:39 --> Config Class Initialized
INFO - 2020-02-26 14:20:39 --> Config Class Initialized
INFO - 2020-02-26 14:20:39 --> Hooks Class Initialized
INFO - 2020-02-26 14:20:39 --> Hooks Class Initialized
INFO - 2020-02-26 14:20:39 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:39 --> Final output sent to browser
INFO - 2020-02-26 14:20:39 --> Config Class Initialized
DEBUG - 2020-02-26 14:20:39 --> Total execution time: 1.0137
INFO - 2020-02-26 14:20:39 --> Hooks Class Initialized
INFO - 2020-02-26 14:20:39 --> URI Class Initialized
DEBUG - 2020-02-26 14:20:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 14:20:39 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:39 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:39 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-26 14:20:39 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:39 --> Router Class Initialized
INFO - 2020-02-26 14:20:39 --> Controller Class Initialized
INFO - 2020-02-26 14:20:39 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:39 --> URI Class Initialized
INFO - 2020-02-26 14:20:39 --> Output Class Initialized
INFO - 2020-02-26 14:20:39 --> URI Class Initialized
INFO - 2020-02-26 14:20:39 --> URI Class Initialized
INFO - 2020-02-26 14:20:39 --> Router Class Initialized
INFO - 2020-02-26 14:20:39 --> Security Class Initialized
INFO - 2020-02-26 14:20:39 --> Router Class Initialized
INFO - 2020-02-26 14:20:39 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:20:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:20:39 --> Router Class Initialized
INFO - 2020-02-26 14:20:39 --> Output Class Initialized
INFO - 2020-02-26 14:20:39 --> Output Class Initialized
DEBUG - 2020-02-26 14:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:39 --> Input Class Initialized
INFO - 2020-02-26 14:20:39 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:20:39 --> Output Class Initialized
INFO - 2020-02-26 14:20:39 --> Security Class Initialized
INFO - 2020-02-26 14:20:39 --> Security Class Initialized
INFO - 2020-02-26 14:20:39 --> Language Class Initialized
DEBUG - 2020-02-26 14:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:39 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:39 --> Helper loaded: form_helper
INFO - 2020-02-26 14:20:39 --> Form Validation Class Initialized
INFO - 2020-02-26 14:20:39 --> Input Class Initialized
INFO - 2020-02-26 14:20:39 --> Input Class Initialized
ERROR - 2020-02-26 14:20:39 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-26 14:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:39 --> Input Class Initialized
INFO - 2020-02-26 14:20:39 --> Language Class Initialized
INFO - 2020-02-26 14:20:39 --> Language Class Initialized
ERROR - 2020-02-26 14:20:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 14:20:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 14:20:39 --> Language Class Initialized
ERROR - 2020-02-26 14:20:39 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 14:20:39 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 14:20:39 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-26 14:20:39 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 14:20:39 --> Final output sent to browser
INFO - 2020-02-26 14:20:39 --> Config Class Initialized
INFO - 2020-02-26 14:20:39 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:20:39 --> Total execution time: 1.4435
DEBUG - 2020-02-26 14:20:39 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:39 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:39 --> URI Class Initialized
INFO - 2020-02-26 14:20:39 --> Router Class Initialized
INFO - 2020-02-26 14:20:39 --> Output Class Initialized
INFO - 2020-02-26 14:20:39 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:39 --> Input Class Initialized
INFO - 2020-02-26 14:20:40 --> Language Class Initialized
ERROR - 2020-02-26 14:20:40 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 14:20:40 --> Config Class Initialized
INFO - 2020-02-26 14:20:40 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:20:40 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:40 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:40 --> URI Class Initialized
INFO - 2020-02-26 14:20:40 --> Router Class Initialized
INFO - 2020-02-26 14:20:40 --> Output Class Initialized
INFO - 2020-02-26 14:20:40 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:40 --> Input Class Initialized
INFO - 2020-02-26 14:20:40 --> Language Class Initialized
ERROR - 2020-02-26 14:20:40 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 14:20:40 --> Config Class Initialized
INFO - 2020-02-26 14:20:40 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:20:40 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:40 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:40 --> URI Class Initialized
INFO - 2020-02-26 14:20:40 --> Router Class Initialized
INFO - 2020-02-26 14:20:40 --> Output Class Initialized
INFO - 2020-02-26 14:20:40 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:40 --> Input Class Initialized
INFO - 2020-02-26 14:20:40 --> Language Class Initialized
ERROR - 2020-02-26 14:20:40 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 14:20:41 --> Config Class Initialized
INFO - 2020-02-26 14:20:41 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:20:41 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:41 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:41 --> URI Class Initialized
INFO - 2020-02-26 14:20:41 --> Router Class Initialized
INFO - 2020-02-26 14:20:41 --> Output Class Initialized
INFO - 2020-02-26 14:20:41 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:41 --> Input Class Initialized
INFO - 2020-02-26 14:20:41 --> Language Class Initialized
ERROR - 2020-02-26 14:20:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 14:20:41 --> Config Class Initialized
INFO - 2020-02-26 14:20:41 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:20:41 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:41 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:41 --> URI Class Initialized
INFO - 2020-02-26 14:20:41 --> Router Class Initialized
INFO - 2020-02-26 14:20:41 --> Output Class Initialized
INFO - 2020-02-26 14:20:41 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:41 --> Input Class Initialized
INFO - 2020-02-26 14:20:41 --> Language Class Initialized
ERROR - 2020-02-26 14:20:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 14:20:41 --> Config Class Initialized
INFO - 2020-02-26 14:20:41 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:20:41 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:41 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:41 --> URI Class Initialized
INFO - 2020-02-26 14:20:42 --> Router Class Initialized
INFO - 2020-02-26 14:20:42 --> Output Class Initialized
INFO - 2020-02-26 14:20:42 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:42 --> Input Class Initialized
INFO - 2020-02-26 14:20:42 --> Language Class Initialized
ERROR - 2020-02-26 14:20:42 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 14:20:42 --> Config Class Initialized
INFO - 2020-02-26 14:20:42 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:20:42 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:42 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:42 --> URI Class Initialized
INFO - 2020-02-26 14:20:42 --> Router Class Initialized
INFO - 2020-02-26 14:20:42 --> Output Class Initialized
INFO - 2020-02-26 14:20:42 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:42 --> Input Class Initialized
INFO - 2020-02-26 14:20:42 --> Language Class Initialized
ERROR - 2020-02-26 14:20:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 14:20:42 --> Config Class Initialized
INFO - 2020-02-26 14:20:42 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:20:42 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:42 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:42 --> URI Class Initialized
INFO - 2020-02-26 14:20:42 --> Router Class Initialized
INFO - 2020-02-26 14:20:42 --> Output Class Initialized
INFO - 2020-02-26 14:20:42 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:42 --> Input Class Initialized
INFO - 2020-02-26 14:20:42 --> Language Class Initialized
ERROR - 2020-02-26 14:20:42 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 14:20:43 --> Config Class Initialized
INFO - 2020-02-26 14:20:43 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:20:43 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:20:43 --> Utf8 Class Initialized
INFO - 2020-02-26 14:20:43 --> URI Class Initialized
INFO - 2020-02-26 14:20:43 --> Router Class Initialized
INFO - 2020-02-26 14:20:43 --> Output Class Initialized
INFO - 2020-02-26 14:20:43 --> Security Class Initialized
DEBUG - 2020-02-26 14:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:20:43 --> Input Class Initialized
INFO - 2020-02-26 14:20:43 --> Language Class Initialized
ERROR - 2020-02-26 14:20:43 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 14:31:36 --> Config Class Initialized
INFO - 2020-02-26 14:31:37 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:31:37 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:31:37 --> Utf8 Class Initialized
INFO - 2020-02-26 14:31:37 --> URI Class Initialized
INFO - 2020-02-26 14:31:37 --> Router Class Initialized
INFO - 2020-02-26 14:31:37 --> Output Class Initialized
INFO - 2020-02-26 14:31:37 --> Security Class Initialized
DEBUG - 2020-02-26 14:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:31:38 --> Input Class Initialized
INFO - 2020-02-26 14:31:38 --> Language Class Initialized
INFO - 2020-02-26 14:31:38 --> Loader Class Initialized
INFO - 2020-02-26 14:31:38 --> Helper loaded: url_helper
INFO - 2020-02-26 14:31:38 --> Helper loaded: string_helper
INFO - 2020-02-26 14:31:38 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:31:38 --> Controller Class Initialized
INFO - 2020-02-26 14:31:39 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:31:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:31:39 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:31:39 --> Helper loaded: form_helper
INFO - 2020-02-26 14:31:39 --> Form Validation Class Initialized
INFO - 2020-02-26 20:31:39 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 20:31:39 --> Final output sent to browser
DEBUG - 2020-02-26 20:31:39 --> Total execution time: 2.9563
INFO - 2020-02-26 14:31:42 --> Config Class Initialized
INFO - 2020-02-26 14:31:42 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:31:42 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:31:42 --> Utf8 Class Initialized
INFO - 2020-02-26 14:31:42 --> URI Class Initialized
INFO - 2020-02-26 14:31:42 --> Router Class Initialized
INFO - 2020-02-26 14:31:43 --> Output Class Initialized
INFO - 2020-02-26 14:31:43 --> Security Class Initialized
DEBUG - 2020-02-26 14:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:31:43 --> Input Class Initialized
INFO - 2020-02-26 14:31:43 --> Language Class Initialized
INFO - 2020-02-26 14:31:43 --> Loader Class Initialized
INFO - 2020-02-26 14:31:43 --> Helper loaded: url_helper
INFO - 2020-02-26 14:31:43 --> Helper loaded: string_helper
INFO - 2020-02-26 14:31:43 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:31:43 --> Controller Class Initialized
INFO - 2020-02-26 14:31:43 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:31:43 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:31:43 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:31:44 --> Helper loaded: form_helper
INFO - 2020-02-26 14:31:44 --> Form Validation Class Initialized
ERROR - 2020-02-26 14:31:44 --> Severity: Warning --> strtotime() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 39
ERROR - 2020-02-26 14:31:44 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 41
ERROR - 2020-02-26 14:31:44 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 44
INFO - 2020-02-26 14:31:44 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 14:31:44 --> Final output sent to browser
DEBUG - 2020-02-26 14:31:44 --> Total execution time: 2.2687
INFO - 2020-02-26 14:33:58 --> Config Class Initialized
INFO - 2020-02-26 14:33:58 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:33:58 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:33:58 --> Utf8 Class Initialized
INFO - 2020-02-26 14:33:59 --> URI Class Initialized
INFO - 2020-02-26 14:33:59 --> Router Class Initialized
INFO - 2020-02-26 14:33:59 --> Output Class Initialized
INFO - 2020-02-26 14:33:59 --> Security Class Initialized
DEBUG - 2020-02-26 14:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:33:59 --> Input Class Initialized
INFO - 2020-02-26 14:33:59 --> Language Class Initialized
INFO - 2020-02-26 14:33:59 --> Loader Class Initialized
INFO - 2020-02-26 14:33:59 --> Helper loaded: url_helper
INFO - 2020-02-26 14:33:59 --> Helper loaded: string_helper
INFO - 2020-02-26 14:33:59 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:33:59 --> Controller Class Initialized
INFO - 2020-02-26 14:33:59 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:33:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:33:59 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:33:59 --> Helper loaded: form_helper
INFO - 2020-02-26 14:33:59 --> Form Validation Class Initialized
ERROR - 2020-02-26 14:33:59 --> Severity: Warning --> strtotime() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 40
ERROR - 2020-02-26 14:33:59 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 42
INFO - 2020-02-26 14:33:59 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 14:33:59 --> Final output sent to browser
DEBUG - 2020-02-26 14:33:59 --> Total execution time: 1.2277
INFO - 2020-02-26 14:35:31 --> Config Class Initialized
INFO - 2020-02-26 14:35:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:35:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:35:32 --> Utf8 Class Initialized
INFO - 2020-02-26 14:35:32 --> URI Class Initialized
INFO - 2020-02-26 14:35:32 --> Router Class Initialized
INFO - 2020-02-26 14:35:32 --> Output Class Initialized
INFO - 2020-02-26 14:35:32 --> Security Class Initialized
DEBUG - 2020-02-26 14:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:35:32 --> Input Class Initialized
INFO - 2020-02-26 14:35:32 --> Language Class Initialized
INFO - 2020-02-26 14:35:32 --> Loader Class Initialized
INFO - 2020-02-26 14:35:32 --> Helper loaded: url_helper
INFO - 2020-02-26 14:35:33 --> Helper loaded: string_helper
INFO - 2020-02-26 14:35:33 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:35:33 --> Controller Class Initialized
INFO - 2020-02-26 14:35:33 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:35:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:35:33 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:35:34 --> Helper loaded: form_helper
INFO - 2020-02-26 14:35:34 --> Form Validation Class Initialized
ERROR - 2020-02-26 14:35:34 --> Severity: Warning --> strtotime() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 35
INFO - 2020-02-26 14:35:34 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 14:35:34 --> Final output sent to browser
DEBUG - 2020-02-26 14:35:34 --> Total execution time: 2.5573
INFO - 2020-02-26 14:35:58 --> Config Class Initialized
INFO - 2020-02-26 14:35:58 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:35:58 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:35:58 --> Utf8 Class Initialized
INFO - 2020-02-26 14:35:58 --> URI Class Initialized
INFO - 2020-02-26 14:35:58 --> Router Class Initialized
INFO - 2020-02-26 14:35:58 --> Output Class Initialized
INFO - 2020-02-26 14:35:58 --> Security Class Initialized
DEBUG - 2020-02-26 14:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:35:59 --> Input Class Initialized
INFO - 2020-02-26 14:35:59 --> Language Class Initialized
INFO - 2020-02-26 14:35:59 --> Loader Class Initialized
INFO - 2020-02-26 14:35:59 --> Helper loaded: url_helper
INFO - 2020-02-26 14:35:59 --> Helper loaded: string_helper
INFO - 2020-02-26 14:35:59 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:35:59 --> Controller Class Initialized
INFO - 2020-02-26 14:35:59 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:35:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:35:59 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:35:59 --> Helper loaded: form_helper
INFO - 2020-02-26 14:35:59 --> Form Validation Class Initialized
ERROR - 2020-02-26 14:35:59 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 35
INFO - 2020-02-26 14:35:59 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 14:35:59 --> Final output sent to browser
DEBUG - 2020-02-26 14:35:59 --> Total execution time: 0.8044
INFO - 2020-02-26 14:42:27 --> Config Class Initialized
INFO - 2020-02-26 14:42:27 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:42:27 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:42:27 --> Utf8 Class Initialized
INFO - 2020-02-26 14:42:27 --> URI Class Initialized
INFO - 2020-02-26 14:42:27 --> Router Class Initialized
INFO - 2020-02-26 14:42:27 --> Output Class Initialized
INFO - 2020-02-26 14:42:27 --> Security Class Initialized
DEBUG - 2020-02-26 14:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:42:27 --> Input Class Initialized
INFO - 2020-02-26 14:42:27 --> Language Class Initialized
INFO - 2020-02-26 14:42:27 --> Loader Class Initialized
INFO - 2020-02-26 14:42:27 --> Helper loaded: url_helper
INFO - 2020-02-26 14:42:27 --> Helper loaded: string_helper
INFO - 2020-02-26 14:42:27 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:42:27 --> Controller Class Initialized
INFO - 2020-02-26 14:42:27 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:42:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:42:27 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:42:27 --> Helper loaded: form_helper
INFO - 2020-02-26 14:42:28 --> Form Validation Class Initialized
ERROR - 2020-02-26 14:42:28 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 35
INFO - 2020-02-26 14:42:28 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 14:42:28 --> Final output sent to browser
DEBUG - 2020-02-26 14:42:28 --> Total execution time: 0.8417
INFO - 2020-02-26 14:43:16 --> Config Class Initialized
INFO - 2020-02-26 14:43:16 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:43:16 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:43:16 --> Utf8 Class Initialized
INFO - 2020-02-26 14:43:16 --> URI Class Initialized
INFO - 2020-02-26 14:43:16 --> Router Class Initialized
INFO - 2020-02-26 14:43:16 --> Output Class Initialized
INFO - 2020-02-26 14:43:16 --> Security Class Initialized
DEBUG - 2020-02-26 14:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:43:17 --> Input Class Initialized
INFO - 2020-02-26 14:43:17 --> Language Class Initialized
INFO - 2020-02-26 14:43:17 --> Loader Class Initialized
INFO - 2020-02-26 14:43:17 --> Helper loaded: url_helper
INFO - 2020-02-26 14:43:17 --> Helper loaded: string_helper
INFO - 2020-02-26 14:43:17 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:43:17 --> Controller Class Initialized
INFO - 2020-02-26 14:43:17 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:43:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:43:17 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:43:17 --> Helper loaded: form_helper
INFO - 2020-02-26 14:43:17 --> Form Validation Class Initialized
ERROR - 2020-02-26 14:43:17 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 14:43:17 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 14:43:17 --> Final output sent to browser
DEBUG - 2020-02-26 14:43:17 --> Total execution time: 0.8196
INFO - 2020-02-26 14:44:07 --> Config Class Initialized
INFO - 2020-02-26 14:44:07 --> Hooks Class Initialized
DEBUG - 2020-02-26 14:44:07 --> UTF-8 Support Enabled
INFO - 2020-02-26 14:44:07 --> Utf8 Class Initialized
INFO - 2020-02-26 14:44:07 --> URI Class Initialized
INFO - 2020-02-26 14:44:07 --> Router Class Initialized
INFO - 2020-02-26 14:44:07 --> Output Class Initialized
INFO - 2020-02-26 14:44:07 --> Security Class Initialized
DEBUG - 2020-02-26 14:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 14:44:07 --> Input Class Initialized
INFO - 2020-02-26 14:44:07 --> Language Class Initialized
INFO - 2020-02-26 14:44:07 --> Loader Class Initialized
INFO - 2020-02-26 14:44:07 --> Helper loaded: url_helper
INFO - 2020-02-26 14:44:07 --> Helper loaded: string_helper
INFO - 2020-02-26 14:44:07 --> Database Driver Class Initialized
DEBUG - 2020-02-26 14:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 14:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 14:44:07 --> Controller Class Initialized
INFO - 2020-02-26 14:44:07 --> Model "M_tiket" initialized
INFO - 2020-02-26 14:44:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 14:44:07 --> Model "M_pesan" initialized
INFO - 2020-02-26 14:44:07 --> Helper loaded: form_helper
INFO - 2020-02-26 14:44:07 --> Form Validation Class Initialized
ERROR - 2020-02-26 14:44:07 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 14:44:08 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 14:44:08 --> Final output sent to browser
DEBUG - 2020-02-26 14:44:08 --> Total execution time: 0.8250
INFO - 2020-02-26 16:20:02 --> Config Class Initialized
INFO - 2020-02-26 16:20:02 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:20:02 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:20:02 --> Utf8 Class Initialized
INFO - 2020-02-26 16:20:02 --> URI Class Initialized
INFO - 2020-02-26 16:20:02 --> Router Class Initialized
INFO - 2020-02-26 16:20:02 --> Output Class Initialized
INFO - 2020-02-26 16:20:02 --> Security Class Initialized
DEBUG - 2020-02-26 16:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:20:02 --> Input Class Initialized
INFO - 2020-02-26 16:20:02 --> Language Class Initialized
INFO - 2020-02-26 16:20:02 --> Loader Class Initialized
INFO - 2020-02-26 16:20:02 --> Helper loaded: url_helper
INFO - 2020-02-26 16:20:02 --> Helper loaded: string_helper
INFO - 2020-02-26 16:20:03 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:20:03 --> Controller Class Initialized
INFO - 2020-02-26 16:20:03 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:20:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:20:03 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:20:03 --> Helper loaded: form_helper
INFO - 2020-02-26 16:20:03 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:20:03 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 16:20:04 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:20:04 --> Final output sent to browser
DEBUG - 2020-02-26 16:20:04 --> Total execution time: 2.1544
INFO - 2020-02-26 16:21:35 --> Config Class Initialized
INFO - 2020-02-26 16:21:35 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:21:35 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:21:35 --> Utf8 Class Initialized
INFO - 2020-02-26 16:21:35 --> URI Class Initialized
INFO - 2020-02-26 16:21:35 --> Router Class Initialized
INFO - 2020-02-26 16:21:35 --> Output Class Initialized
INFO - 2020-02-26 16:21:35 --> Security Class Initialized
DEBUG - 2020-02-26 16:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:21:35 --> Input Class Initialized
INFO - 2020-02-26 16:21:35 --> Language Class Initialized
INFO - 2020-02-26 16:21:35 --> Loader Class Initialized
INFO - 2020-02-26 16:21:35 --> Helper loaded: url_helper
INFO - 2020-02-26 16:21:35 --> Helper loaded: string_helper
INFO - 2020-02-26 16:21:35 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:21:35 --> Controller Class Initialized
INFO - 2020-02-26 16:21:35 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:21:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:21:35 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:21:35 --> Helper loaded: form_helper
INFO - 2020-02-26 16:21:35 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:21:35 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 16:21:35 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:21:35 --> Final output sent to browser
DEBUG - 2020-02-26 16:21:35 --> Total execution time: 0.8084
INFO - 2020-02-26 16:21:40 --> Config Class Initialized
INFO - 2020-02-26 16:21:40 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:21:40 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:21:40 --> Utf8 Class Initialized
INFO - 2020-02-26 16:21:40 --> URI Class Initialized
INFO - 2020-02-26 16:21:40 --> Router Class Initialized
INFO - 2020-02-26 16:21:40 --> Output Class Initialized
INFO - 2020-02-26 16:21:40 --> Security Class Initialized
DEBUG - 2020-02-26 16:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:21:40 --> Input Class Initialized
INFO - 2020-02-26 16:21:40 --> Language Class Initialized
INFO - 2020-02-26 16:21:40 --> Loader Class Initialized
INFO - 2020-02-26 16:21:40 --> Helper loaded: url_helper
INFO - 2020-02-26 16:21:40 --> Helper loaded: string_helper
INFO - 2020-02-26 16:21:40 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:21:40 --> Controller Class Initialized
INFO - 2020-02-26 16:21:40 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:21:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:21:40 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:21:41 --> Helper loaded: form_helper
INFO - 2020-02-26 16:21:41 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:21:41 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 16:21:41 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:21:41 --> Final output sent to browser
DEBUG - 2020-02-26 16:21:41 --> Total execution time: 0.6140
INFO - 2020-02-26 16:22:22 --> Config Class Initialized
INFO - 2020-02-26 16:22:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:22:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:23 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:23 --> URI Class Initialized
DEBUG - 2020-02-26 16:22:23 --> No URI present. Default controller set.
INFO - 2020-02-26 16:22:23 --> Router Class Initialized
INFO - 2020-02-26 16:22:23 --> Output Class Initialized
INFO - 2020-02-26 16:22:23 --> Security Class Initialized
DEBUG - 2020-02-26 16:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:23 --> Input Class Initialized
INFO - 2020-02-26 16:22:23 --> Language Class Initialized
INFO - 2020-02-26 16:22:23 --> Loader Class Initialized
INFO - 2020-02-26 16:22:23 --> Helper loaded: url_helper
INFO - 2020-02-26 16:22:23 --> Helper loaded: string_helper
INFO - 2020-02-26 16:22:23 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:22:23 --> Controller Class Initialized
INFO - 2020-02-26 16:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 16:22:23 --> Pagination Class Initialized
INFO - 2020-02-26 16:22:23 --> Model "M_show" initialized
INFO - 2020-02-26 16:22:23 --> Helper loaded: form_helper
INFO - 2020-02-26 16:22:23 --> Form Validation Class Initialized
INFO - 2020-02-26 16:22:23 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 16:22:23 --> Final output sent to browser
INFO - 2020-02-26 16:22:23 --> Config Class Initialized
INFO - 2020-02-26 16:22:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:22:23 --> Total execution time: 0.8654
DEBUG - 2020-02-26 16:22:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:23 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:23 --> URI Class Initialized
DEBUG - 2020-02-26 16:22:24 --> No URI present. Default controller set.
INFO - 2020-02-26 16:22:24 --> Router Class Initialized
INFO - 2020-02-26 16:22:24 --> Output Class Initialized
INFO - 2020-02-26 16:22:24 --> Security Class Initialized
DEBUG - 2020-02-26 16:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:24 --> Input Class Initialized
INFO - 2020-02-26 16:22:24 --> Language Class Initialized
INFO - 2020-02-26 16:22:24 --> Loader Class Initialized
INFO - 2020-02-26 16:22:24 --> Helper loaded: url_helper
INFO - 2020-02-26 16:22:24 --> Helper loaded: string_helper
INFO - 2020-02-26 16:22:24 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:22:24 --> Controller Class Initialized
INFO - 2020-02-26 16:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 16:22:24 --> Pagination Class Initialized
INFO - 2020-02-26 16:22:24 --> Model "M_show" initialized
INFO - 2020-02-26 16:22:24 --> Helper loaded: form_helper
INFO - 2020-02-26 16:22:24 --> Form Validation Class Initialized
INFO - 2020-02-26 16:22:24 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 16:22:24 --> Final output sent to browser
DEBUG - 2020-02-26 16:22:24 --> Total execution time: 0.7613
INFO - 2020-02-26 16:22:29 --> Config Class Initialized
INFO - 2020-02-26 16:22:29 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:22:29 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:29 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:29 --> URI Class Initialized
INFO - 2020-02-26 16:22:29 --> Router Class Initialized
INFO - 2020-02-26 16:22:29 --> Output Class Initialized
INFO - 2020-02-26 16:22:29 --> Security Class Initialized
DEBUG - 2020-02-26 16:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:30 --> Input Class Initialized
INFO - 2020-02-26 16:22:30 --> Language Class Initialized
INFO - 2020-02-26 16:22:30 --> Loader Class Initialized
INFO - 2020-02-26 16:22:30 --> Helper loaded: url_helper
INFO - 2020-02-26 16:22:30 --> Helper loaded: string_helper
INFO - 2020-02-26 16:22:30 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:22:30 --> Controller Class Initialized
INFO - 2020-02-26 16:22:30 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:22:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:22:30 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:22:30 --> Helper loaded: form_helper
INFO - 2020-02-26 16:22:30 --> Form Validation Class Initialized
INFO - 2020-02-26 16:22:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:22:30 --> Final output sent to browser
DEBUG - 2020-02-26 16:22:30 --> Total execution time: 0.7524
INFO - 2020-02-26 16:22:30 --> Config Class Initialized
INFO - 2020-02-26 16:22:30 --> Config Class Initialized
INFO - 2020-02-26 16:22:30 --> Hooks Class Initialized
INFO - 2020-02-26 16:22:30 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:22:30 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:22:30 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:30 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:30 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:30 --> URI Class Initialized
INFO - 2020-02-26 16:22:30 --> URI Class Initialized
INFO - 2020-02-26 16:22:30 --> Config Class Initialized
INFO - 2020-02-26 16:22:30 --> Config Class Initialized
INFO - 2020-02-26 16:22:30 --> Hooks Class Initialized
INFO - 2020-02-26 16:22:30 --> Hooks Class Initialized
INFO - 2020-02-26 16:22:30 --> Router Class Initialized
INFO - 2020-02-26 16:22:30 --> Router Class Initialized
INFO - 2020-02-26 16:22:30 --> Config Class Initialized
INFO - 2020-02-26 16:22:30 --> Config Class Initialized
INFO - 2020-02-26 16:22:30 --> Hooks Class Initialized
INFO - 2020-02-26 16:22:30 --> Hooks Class Initialized
INFO - 2020-02-26 16:22:30 --> Output Class Initialized
INFO - 2020-02-26 16:22:30 --> Output Class Initialized
DEBUG - 2020-02-26 16:22:30 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:22:30 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:30 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:30 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:30 --> Security Class Initialized
INFO - 2020-02-26 16:22:30 --> Security Class Initialized
DEBUG - 2020-02-26 16:22:30 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:22:30 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:30 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:30 --> Utf8 Class Initialized
DEBUG - 2020-02-26 16:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:30 --> URI Class Initialized
DEBUG - 2020-02-26 16:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:30 --> URI Class Initialized
INFO - 2020-02-26 16:22:30 --> Input Class Initialized
INFO - 2020-02-26 16:22:30 --> Router Class Initialized
INFO - 2020-02-26 16:22:30 --> Router Class Initialized
INFO - 2020-02-26 16:22:30 --> Input Class Initialized
INFO - 2020-02-26 16:22:30 --> URI Class Initialized
INFO - 2020-02-26 16:22:30 --> URI Class Initialized
INFO - 2020-02-26 16:22:30 --> Language Class Initialized
INFO - 2020-02-26 16:22:30 --> Router Class Initialized
INFO - 2020-02-26 16:22:30 --> Output Class Initialized
INFO - 2020-02-26 16:22:30 --> Language Class Initialized
INFO - 2020-02-26 16:22:30 --> Router Class Initialized
INFO - 2020-02-26 16:22:30 --> Output Class Initialized
INFO - 2020-02-26 16:22:30 --> Security Class Initialized
INFO - 2020-02-26 16:22:30 --> Security Class Initialized
INFO - 2020-02-26 16:22:30 --> Loader Class Initialized
ERROR - 2020-02-26 16:22:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 16:22:30 --> Output Class Initialized
INFO - 2020-02-26 16:22:30 --> Output Class Initialized
INFO - 2020-02-26 16:22:30 --> Helper loaded: url_helper
INFO - 2020-02-26 16:22:30 --> Security Class Initialized
DEBUG - 2020-02-26 16:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:31 --> Input Class Initialized
INFO - 2020-02-26 16:22:31 --> Input Class Initialized
INFO - 2020-02-26 16:22:31 --> Helper loaded: string_helper
INFO - 2020-02-26 16:22:31 --> Security Class Initialized
DEBUG - 2020-02-26 16:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:31 --> Input Class Initialized
INFO - 2020-02-26 16:22:31 --> Language Class Initialized
INFO - 2020-02-26 16:22:31 --> Language Class Initialized
DEBUG - 2020-02-26 16:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:31 --> Config Class Initialized
INFO - 2020-02-26 16:22:31 --> Database Driver Class Initialized
INFO - 2020-02-26 16:22:31 --> Hooks Class Initialized
INFO - 2020-02-26 16:22:31 --> Input Class Initialized
INFO - 2020-02-26 16:22:31 --> Language Class Initialized
ERROR - 2020-02-26 16:22:31 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 16:22:31 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-26 16:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:22:31 --> Language Class Initialized
ERROR - 2020-02-26 16:22:31 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2020-02-26 16:22:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:31 --> Config Class Initialized
INFO - 2020-02-26 16:22:31 --> Config Class Initialized
INFO - 2020-02-26 16:22:31 --> Hooks Class Initialized
INFO - 2020-02-26 16:22:31 --> Hooks Class Initialized
INFO - 2020-02-26 16:22:31 --> Controller Class Initialized
INFO - 2020-02-26 16:22:31 --> Utf8 Class Initialized
ERROR - 2020-02-26 16:22:31 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 16:22:31 --> Config Class Initialized
INFO - 2020-02-26 16:22:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:22:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:31 --> URI Class Initialized
DEBUG - 2020-02-26 16:22:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:31 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:22:31 --> Config Class Initialized
INFO - 2020-02-26 16:22:31 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:31 --> Hooks Class Initialized
INFO - 2020-02-26 16:22:31 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:22:31 --> Router Class Initialized
DEBUG - 2020-02-26 16:22:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:31 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:31 --> URI Class Initialized
INFO - 2020-02-26 16:22:31 --> URI Class Initialized
INFO - 2020-02-26 16:22:31 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:22:31 --> Output Class Initialized
DEBUG - 2020-02-26 16:22:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:31 --> Router Class Initialized
INFO - 2020-02-26 16:22:31 --> Router Class Initialized
INFO - 2020-02-26 16:22:31 --> Security Class Initialized
INFO - 2020-02-26 16:22:31 --> Helper loaded: form_helper
INFO - 2020-02-26 16:22:31 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:31 --> URI Class Initialized
INFO - 2020-02-26 16:22:31 --> Form Validation Class Initialized
INFO - 2020-02-26 16:22:31 --> URI Class Initialized
DEBUG - 2020-02-26 16:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:31 --> Router Class Initialized
INFO - 2020-02-26 16:22:31 --> Output Class Initialized
INFO - 2020-02-26 16:22:31 --> Output Class Initialized
INFO - 2020-02-26 16:22:31 --> Input Class Initialized
INFO - 2020-02-26 16:22:31 --> Output Class Initialized
INFO - 2020-02-26 16:22:31 --> Security Class Initialized
INFO - 2020-02-26 16:22:31 --> Security Class Initialized
INFO - 2020-02-26 16:22:31 --> Router Class Initialized
ERROR - 2020-02-26 16:22:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 16:22:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 16:22:31 --> Language Class Initialized
DEBUG - 2020-02-26 16:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:31 --> Security Class Initialized
DEBUG - 2020-02-26 16:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:31 --> Output Class Initialized
INFO - 2020-02-26 16:22:31 --> Input Class Initialized
INFO - 2020-02-26 16:22:31 --> Input Class Initialized
INFO - 2020-02-26 16:22:31 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-26 16:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:31 --> Security Class Initialized
ERROR - 2020-02-26 16:22:31 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 16:22:31 --> Final output sent to browser
INFO - 2020-02-26 16:22:31 --> Input Class Initialized
DEBUG - 2020-02-26 16:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:31 --> Language Class Initialized
INFO - 2020-02-26 16:22:31 --> Language Class Initialized
INFO - 2020-02-26 16:22:31 --> Input Class Initialized
DEBUG - 2020-02-26 16:22:31 --> Total execution time: 0.7904
INFO - 2020-02-26 16:22:31 --> Language Class Initialized
ERROR - 2020-02-26 16:22:31 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 16:22:31 --> Config Class Initialized
INFO - 2020-02-26 16:22:31 --> Loader Class Initialized
INFO - 2020-02-26 16:22:31 --> Hooks Class Initialized
INFO - 2020-02-26 16:22:31 --> Helper loaded: url_helper
ERROR - 2020-02-26 16:22:31 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 16:22:31 --> Language Class Initialized
INFO - 2020-02-26 16:22:31 --> Config Class Initialized
INFO - 2020-02-26 16:22:31 --> Hooks Class Initialized
INFO - 2020-02-26 16:22:31 --> Helper loaded: string_helper
ERROR - 2020-02-26 16:22:31 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-26 16:22:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:31 --> Utf8 Class Initialized
DEBUG - 2020-02-26 16:22:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:31 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:31 --> URI Class Initialized
INFO - 2020-02-26 16:22:31 --> Database Driver Class Initialized
INFO - 2020-02-26 16:22:31 --> Config Class Initialized
INFO - 2020-02-26 16:22:31 --> Hooks Class Initialized
INFO - 2020-02-26 16:22:31 --> URI Class Initialized
INFO - 2020-02-26 16:22:31 --> Router Class Initialized
DEBUG - 2020-02-26 16:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:22:31 --> Output Class Initialized
INFO - 2020-02-26 16:22:31 --> Router Class Initialized
DEBUG - 2020-02-26 16:22:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:31 --> Controller Class Initialized
INFO - 2020-02-26 16:22:31 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:31 --> Security Class Initialized
INFO - 2020-02-26 16:22:31 --> Output Class Initialized
INFO - 2020-02-26 16:22:31 --> URI Class Initialized
INFO - 2020-02-26 16:22:31 --> Model "M_tiket" initialized
DEBUG - 2020-02-26 16:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:31 --> Security Class Initialized
INFO - 2020-02-26 16:22:31 --> Input Class Initialized
DEBUG - 2020-02-26 16:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:31 --> Router Class Initialized
INFO - 2020-02-26 16:22:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:22:31 --> Input Class Initialized
INFO - 2020-02-26 16:22:31 --> Language Class Initialized
INFO - 2020-02-26 16:22:31 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:22:31 --> Output Class Initialized
INFO - 2020-02-26 16:22:31 --> Language Class Initialized
ERROR - 2020-02-26 16:22:31 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 16:22:31 --> Security Class Initialized
INFO - 2020-02-26 16:22:31 --> Helper loaded: form_helper
INFO - 2020-02-26 16:22:31 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:22:31 --> 404 Page Not Found: Bower_components/jquery-i18next
DEBUG - 2020-02-26 16:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:31 --> Input Class Initialized
ERROR - 2020-02-26 16:22:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 16:22:31 --> Language Class Initialized
ERROR - 2020-02-26 16:22:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 16:22:31 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 16:22:31 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:22:31 --> Final output sent to browser
DEBUG - 2020-02-26 16:22:31 --> Total execution time: 0.7661
INFO - 2020-02-26 16:22:31 --> Config Class Initialized
INFO - 2020-02-26 16:22:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:22:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:31 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:31 --> URI Class Initialized
INFO - 2020-02-26 16:22:32 --> Router Class Initialized
INFO - 2020-02-26 16:22:32 --> Output Class Initialized
INFO - 2020-02-26 16:22:32 --> Security Class Initialized
DEBUG - 2020-02-26 16:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:32 --> Input Class Initialized
INFO - 2020-02-26 16:22:32 --> Language Class Initialized
ERROR - 2020-02-26 16:22:32 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 16:22:32 --> Config Class Initialized
INFO - 2020-02-26 16:22:32 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:22:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:32 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:32 --> URI Class Initialized
INFO - 2020-02-26 16:22:32 --> Router Class Initialized
INFO - 2020-02-26 16:22:32 --> Output Class Initialized
INFO - 2020-02-26 16:22:32 --> Security Class Initialized
DEBUG - 2020-02-26 16:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:32 --> Input Class Initialized
INFO - 2020-02-26 16:22:32 --> Language Class Initialized
ERROR - 2020-02-26 16:22:32 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 16:22:32 --> Config Class Initialized
INFO - 2020-02-26 16:22:32 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:22:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:32 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:32 --> URI Class Initialized
INFO - 2020-02-26 16:22:32 --> Router Class Initialized
INFO - 2020-02-26 16:22:32 --> Output Class Initialized
INFO - 2020-02-26 16:22:32 --> Security Class Initialized
DEBUG - 2020-02-26 16:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:32 --> Input Class Initialized
INFO - 2020-02-26 16:22:32 --> Language Class Initialized
ERROR - 2020-02-26 16:22:32 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 16:22:32 --> Config Class Initialized
INFO - 2020-02-26 16:22:32 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:22:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:32 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:32 --> URI Class Initialized
INFO - 2020-02-26 16:22:32 --> Router Class Initialized
INFO - 2020-02-26 16:22:33 --> Output Class Initialized
INFO - 2020-02-26 16:22:33 --> Security Class Initialized
DEBUG - 2020-02-26 16:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:33 --> Input Class Initialized
INFO - 2020-02-26 16:22:33 --> Language Class Initialized
ERROR - 2020-02-26 16:22:33 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 16:22:33 --> Config Class Initialized
INFO - 2020-02-26 16:22:33 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:22:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:33 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:33 --> URI Class Initialized
INFO - 2020-02-26 16:22:33 --> Router Class Initialized
INFO - 2020-02-26 16:22:33 --> Output Class Initialized
INFO - 2020-02-26 16:22:33 --> Security Class Initialized
DEBUG - 2020-02-26 16:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:33 --> Input Class Initialized
INFO - 2020-02-26 16:22:33 --> Language Class Initialized
ERROR - 2020-02-26 16:22:33 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 16:22:56 --> Config Class Initialized
INFO - 2020-02-26 16:22:56 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:22:56 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:22:56 --> Utf8 Class Initialized
INFO - 2020-02-26 16:22:56 --> URI Class Initialized
INFO - 2020-02-26 16:22:56 --> Router Class Initialized
INFO - 2020-02-26 16:22:56 --> Output Class Initialized
INFO - 2020-02-26 16:22:56 --> Security Class Initialized
DEBUG - 2020-02-26 16:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:22:56 --> Input Class Initialized
INFO - 2020-02-26 16:22:56 --> Language Class Initialized
INFO - 2020-02-26 16:22:56 --> Loader Class Initialized
INFO - 2020-02-26 16:22:56 --> Helper loaded: url_helper
INFO - 2020-02-26 16:22:56 --> Helper loaded: string_helper
INFO - 2020-02-26 16:22:56 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:22:56 --> Controller Class Initialized
INFO - 2020-02-26 16:22:56 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:22:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:22:57 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:22:57 --> Helper loaded: form_helper
INFO - 2020-02-26 16:22:57 --> Form Validation Class Initialized
INFO - 2020-02-26 22:22:57 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 22:22:57 --> Final output sent to browser
DEBUG - 2020-02-26 22:22:57 --> Total execution time: 1.0953
INFO - 2020-02-26 16:23:02 --> Config Class Initialized
INFO - 2020-02-26 16:23:02 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:23:02 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:23:02 --> Utf8 Class Initialized
INFO - 2020-02-26 16:23:02 --> URI Class Initialized
INFO - 2020-02-26 16:23:02 --> Router Class Initialized
INFO - 2020-02-26 16:23:02 --> Output Class Initialized
INFO - 2020-02-26 16:23:02 --> Security Class Initialized
DEBUG - 2020-02-26 16:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:23:02 --> Input Class Initialized
INFO - 2020-02-26 16:23:02 --> Language Class Initialized
INFO - 2020-02-26 16:23:02 --> Loader Class Initialized
INFO - 2020-02-26 16:23:02 --> Helper loaded: url_helper
INFO - 2020-02-26 16:23:02 --> Helper loaded: string_helper
INFO - 2020-02-26 16:23:02 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:23:02 --> Controller Class Initialized
INFO - 2020-02-26 16:23:02 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:23:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:23:02 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:23:02 --> Helper loaded: form_helper
INFO - 2020-02-26 16:23:02 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:23:02 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 16:23:02 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:23:02 --> Final output sent to browser
DEBUG - 2020-02-26 16:23:02 --> Total execution time: 0.6103
INFO - 2020-02-26 16:24:08 --> Config Class Initialized
INFO - 2020-02-26 16:24:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:24:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:08 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:08 --> URI Class Initialized
INFO - 2020-02-26 16:24:08 --> Router Class Initialized
INFO - 2020-02-26 16:24:09 --> Output Class Initialized
INFO - 2020-02-26 16:24:09 --> Security Class Initialized
DEBUG - 2020-02-26 16:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:09 --> Input Class Initialized
INFO - 2020-02-26 16:24:09 --> Language Class Initialized
INFO - 2020-02-26 16:24:09 --> Loader Class Initialized
INFO - 2020-02-26 16:24:09 --> Helper loaded: url_helper
INFO - 2020-02-26 16:24:09 --> Helper loaded: string_helper
INFO - 2020-02-26 16:24:09 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:24:09 --> Controller Class Initialized
INFO - 2020-02-26 16:24:09 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:24:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:24:09 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:24:09 --> Helper loaded: form_helper
INFO - 2020-02-26 16:24:09 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:24:09 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 30
ERROR - 2020-02-26 16:24:09 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 31
ERROR - 2020-02-26 16:24:09 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 32
ERROR - 2020-02-26 16:24:09 --> Severity: Notice --> Undefined index: kodebayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 33
ERROR - 2020-02-26 16:24:09 --> Severity: Notice --> Undefined index: kodebayar C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 68
ERROR - 2020-02-26 16:24:09 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 16:24:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:24:09 --> Final output sent to browser
DEBUG - 2020-02-26 16:24:09 --> Total execution time: 0.7749
INFO - 2020-02-26 16:24:17 --> Config Class Initialized
INFO - 2020-02-26 16:24:17 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:24:17 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:17 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:17 --> URI Class Initialized
INFO - 2020-02-26 16:24:17 --> Router Class Initialized
INFO - 2020-02-26 16:24:17 --> Output Class Initialized
INFO - 2020-02-26 16:24:17 --> Security Class Initialized
DEBUG - 2020-02-26 16:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:17 --> Input Class Initialized
INFO - 2020-02-26 16:24:17 --> Language Class Initialized
INFO - 2020-02-26 16:24:17 --> Loader Class Initialized
INFO - 2020-02-26 16:24:17 --> Helper loaded: url_helper
INFO - 2020-02-26 16:24:17 --> Helper loaded: string_helper
INFO - 2020-02-26 16:24:17 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:24:17 --> Controller Class Initialized
INFO - 2020-02-26 16:24:17 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:24:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:24:17 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:24:17 --> Helper loaded: form_helper
INFO - 2020-02-26 16:24:17 --> Form Validation Class Initialized
INFO - 2020-02-26 16:24:17 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:24:17 --> Final output sent to browser
DEBUG - 2020-02-26 16:24:17 --> Total execution time: 0.7127
INFO - 2020-02-26 16:24:18 --> Config Class Initialized
INFO - 2020-02-26 16:24:18 --> Config Class Initialized
INFO - 2020-02-26 16:24:18 --> Config Class Initialized
INFO - 2020-02-26 16:24:18 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:18 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:18 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:24:18 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:18 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:18 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:18 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:18 --> URI Class Initialized
INFO - 2020-02-26 16:24:18 --> URI Class Initialized
INFO - 2020-02-26 16:24:18 --> URI Class Initialized
INFO - 2020-02-26 16:24:18 --> Router Class Initialized
INFO - 2020-02-26 16:24:18 --> Router Class Initialized
INFO - 2020-02-26 16:24:18 --> Router Class Initialized
INFO - 2020-02-26 16:24:18 --> Output Class Initialized
INFO - 2020-02-26 16:24:18 --> Output Class Initialized
INFO - 2020-02-26 16:24:18 --> Output Class Initialized
INFO - 2020-02-26 16:24:18 --> Security Class Initialized
INFO - 2020-02-26 16:24:18 --> Security Class Initialized
INFO - 2020-02-26 16:24:18 --> Security Class Initialized
DEBUG - 2020-02-26 16:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:18 --> Input Class Initialized
INFO - 2020-02-26 16:24:18 --> Input Class Initialized
INFO - 2020-02-26 16:24:18 --> Input Class Initialized
INFO - 2020-02-26 16:24:18 --> Language Class Initialized
INFO - 2020-02-26 16:24:18 --> Language Class Initialized
INFO - 2020-02-26 16:24:18 --> Language Class Initialized
ERROR - 2020-02-26 16:24:18 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 16:24:18 --> Loader Class Initialized
INFO - 2020-02-26 16:24:18 --> Loader Class Initialized
INFO - 2020-02-26 16:24:18 --> Helper loaded: url_helper
INFO - 2020-02-26 16:24:18 --> Helper loaded: url_helper
INFO - 2020-02-26 16:24:18 --> Helper loaded: string_helper
INFO - 2020-02-26 16:24:18 --> Helper loaded: string_helper
INFO - 2020-02-26 16:24:18 --> Database Driver Class Initialized
INFO - 2020-02-26 16:24:18 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-26 16:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:24:18 --> Controller Class Initialized
INFO - 2020-02-26 16:24:18 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:24:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:24:18 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:24:18 --> Helper loaded: form_helper
INFO - 2020-02-26 16:24:18 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:24:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 16:24:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 16:24:18 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:24:19 --> Final output sent to browser
DEBUG - 2020-02-26 16:24:19 --> Total execution time: 0.8641
INFO - 2020-02-26 16:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:24:19 --> Controller Class Initialized
INFO - 2020-02-26 16:24:19 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:24:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:24:19 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:24:19 --> Helper loaded: form_helper
INFO - 2020-02-26 16:24:19 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:24:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 16:24:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 16:24:19 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:24:19 --> Final output sent to browser
DEBUG - 2020-02-26 16:24:19 --> Total execution time: 1.1644
INFO - 2020-02-26 16:24:21 --> Config Class Initialized
INFO - 2020-02-26 16:24:21 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:24:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:21 --> URI Class Initialized
INFO - 2020-02-26 16:24:21 --> Router Class Initialized
INFO - 2020-02-26 16:24:21 --> Output Class Initialized
INFO - 2020-02-26 16:24:21 --> Security Class Initialized
DEBUG - 2020-02-26 16:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:21 --> Input Class Initialized
INFO - 2020-02-26 16:24:21 --> Language Class Initialized
INFO - 2020-02-26 16:24:21 --> Loader Class Initialized
INFO - 2020-02-26 16:24:21 --> Helper loaded: url_helper
INFO - 2020-02-26 16:24:21 --> Helper loaded: string_helper
INFO - 2020-02-26 16:24:21 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:24:21 --> Controller Class Initialized
INFO - 2020-02-26 16:24:21 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:24:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:24:21 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:24:21 --> Helper loaded: form_helper
INFO - 2020-02-26 16:24:21 --> Form Validation Class Initialized
INFO - 2020-02-26 16:24:21 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:24:21 --> Final output sent to browser
INFO - 2020-02-26 16:24:21 --> Config Class Initialized
INFO - 2020-02-26 16:24:21 --> Config Class Initialized
INFO - 2020-02-26 16:24:21 --> Config Class Initialized
INFO - 2020-02-26 16:24:21 --> Config Class Initialized
INFO - 2020-02-26 16:24:21 --> Config Class Initialized
INFO - 2020-02-26 16:24:21 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:21 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:21 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:21 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:24:21 --> Total execution time: 0.6249
INFO - 2020-02-26 16:24:21 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:24:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:21 --> Config Class Initialized
DEBUG - 2020-02-26 16:24:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:21 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:21 --> URI Class Initialized
INFO - 2020-02-26 16:24:21 --> URI Class Initialized
INFO - 2020-02-26 16:24:21 --> URI Class Initialized
INFO - 2020-02-26 16:24:21 --> URI Class Initialized
DEBUG - 2020-02-26 16:24:21 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:21 --> URI Class Initialized
INFO - 2020-02-26 16:24:21 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:21 --> Router Class Initialized
INFO - 2020-02-26 16:24:21 --> Router Class Initialized
INFO - 2020-02-26 16:24:21 --> Router Class Initialized
INFO - 2020-02-26 16:24:21 --> Router Class Initialized
INFO - 2020-02-26 16:24:21 --> Router Class Initialized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:22 --> URI Class Initialized
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
INFO - 2020-02-26 16:24:22 --> Router Class Initialized
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
ERROR - 2020-02-26 16:24:22 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 16:24:22 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-26 16:24:22 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 16:24:22 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-26 16:24:22 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
INFO - 2020-02-26 16:24:22 --> Config Class Initialized
INFO - 2020-02-26 16:24:22 --> Config Class Initialized
INFO - 2020-02-26 16:24:22 --> Config Class Initialized
INFO - 2020-02-26 16:24:22 --> Config Class Initialized
INFO - 2020-02-26 16:24:22 --> Config Class Initialized
INFO - 2020-02-26 16:24:22 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:22 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:22 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:22 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:22 --> Hooks Class Initialized
ERROR - 2020-02-26 16:24:22 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-26 16:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:24:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:22 --> Config Class Initialized
INFO - 2020-02-26 16:24:22 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:22 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:22 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:22 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:22 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:22 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:22 --> URI Class Initialized
INFO - 2020-02-26 16:24:22 --> URI Class Initialized
INFO - 2020-02-26 16:24:22 --> URI Class Initialized
DEBUG - 2020-02-26 16:24:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:22 --> URI Class Initialized
INFO - 2020-02-26 16:24:22 --> URI Class Initialized
INFO - 2020-02-26 16:24:22 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:22 --> Router Class Initialized
INFO - 2020-02-26 16:24:22 --> Router Class Initialized
INFO - 2020-02-26 16:24:22 --> Router Class Initialized
INFO - 2020-02-26 16:24:22 --> Router Class Initialized
INFO - 2020-02-26 16:24:22 --> Router Class Initialized
INFO - 2020-02-26 16:24:22 --> URI Class Initialized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
INFO - 2020-02-26 16:24:22 --> Router Class Initialized
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
ERROR - 2020-02-26 16:24:22 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 16:24:22 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 16:24:22 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-26 16:24:22 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 16:24:22 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
INFO - 2020-02-26 16:24:22 --> Config Class Initialized
INFO - 2020-02-26 16:24:22 --> Config Class Initialized
INFO - 2020-02-26 16:24:22 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:22 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:22 --> Loader Class Initialized
INFO - 2020-02-26 16:24:22 --> Helper loaded: url_helper
DEBUG - 2020-02-26 16:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:24:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:22 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:22 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:22 --> Helper loaded: string_helper
INFO - 2020-02-26 16:24:22 --> URI Class Initialized
INFO - 2020-02-26 16:24:22 --> URI Class Initialized
INFO - 2020-02-26 16:24:22 --> Database Driver Class Initialized
INFO - 2020-02-26 16:24:22 --> Router Class Initialized
INFO - 2020-02-26 16:24:22 --> Router Class Initialized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
DEBUG - 2020-02-26 16:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
INFO - 2020-02-26 16:24:22 --> Security Class Initialized
INFO - 2020-02-26 16:24:22 --> Controller Class Initialized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
INFO - 2020-02-26 16:24:22 --> Input Class Initialized
INFO - 2020-02-26 16:24:22 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
INFO - 2020-02-26 16:24:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:24:22 --> Language Class Initialized
INFO - 2020-02-26 16:24:22 --> Model "M_pesan" initialized
ERROR - 2020-02-26 16:24:22 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 16:24:22 --> Loader Class Initialized
INFO - 2020-02-26 16:24:22 --> Helper loaded: url_helper
INFO - 2020-02-26 16:24:22 --> Helper loaded: form_helper
INFO - 2020-02-26 16:24:22 --> Config Class Initialized
INFO - 2020-02-26 16:24:22 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:22 --> Form Validation Class Initialized
INFO - 2020-02-26 16:24:22 --> Helper loaded: string_helper
DEBUG - 2020-02-26 16:24:22 --> UTF-8 Support Enabled
ERROR - 2020-02-26 16:24:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 16:24:22 --> Database Driver Class Initialized
INFO - 2020-02-26 16:24:22 --> Utf8 Class Initialized
ERROR - 2020-02-26 16:24:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
DEBUG - 2020-02-26 16:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:24:22 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:24:22 --> URI Class Initialized
INFO - 2020-02-26 16:24:22 --> Final output sent to browser
INFO - 2020-02-26 16:24:22 --> Router Class Initialized
DEBUG - 2020-02-26 16:24:22 --> Total execution time: 0.7175
INFO - 2020-02-26 16:24:22 --> Output Class Initialized
INFO - 2020-02-26 16:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:24:23 --> Security Class Initialized
INFO - 2020-02-26 16:24:23 --> Controller Class Initialized
DEBUG - 2020-02-26 16:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:23 --> Input Class Initialized
INFO - 2020-02-26 16:24:23 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:24:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:24:23 --> Language Class Initialized
INFO - 2020-02-26 16:24:23 --> Model "M_pesan" initialized
ERROR - 2020-02-26 16:24:23 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 16:24:23 --> Helper loaded: form_helper
INFO - 2020-02-26 16:24:23 --> Config Class Initialized
INFO - 2020-02-26 16:24:23 --> Hooks Class Initialized
INFO - 2020-02-26 16:24:23 --> Form Validation Class Initialized
DEBUG - 2020-02-26 16:24:23 --> UTF-8 Support Enabled
ERROR - 2020-02-26 16:24:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 16:24:23 --> Utf8 Class Initialized
ERROR - 2020-02-26 16:24:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 16:24:23 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:24:23 --> URI Class Initialized
INFO - 2020-02-26 16:24:23 --> Final output sent to browser
INFO - 2020-02-26 16:24:23 --> Router Class Initialized
DEBUG - 2020-02-26 16:24:23 --> Total execution time: 0.7568
INFO - 2020-02-26 16:24:23 --> Output Class Initialized
INFO - 2020-02-26 16:24:23 --> Security Class Initialized
DEBUG - 2020-02-26 16:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:23 --> Input Class Initialized
INFO - 2020-02-26 16:24:23 --> Language Class Initialized
ERROR - 2020-02-26 16:24:23 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 16:24:23 --> Config Class Initialized
INFO - 2020-02-26 16:24:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:23 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:23 --> URI Class Initialized
INFO - 2020-02-26 16:24:23 --> Router Class Initialized
INFO - 2020-02-26 16:24:23 --> Output Class Initialized
INFO - 2020-02-26 16:24:23 --> Security Class Initialized
DEBUG - 2020-02-26 16:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:23 --> Input Class Initialized
INFO - 2020-02-26 16:24:23 --> Language Class Initialized
ERROR - 2020-02-26 16:24:23 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 16:24:23 --> Config Class Initialized
INFO - 2020-02-26 16:24:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:23 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:23 --> URI Class Initialized
INFO - 2020-02-26 16:24:23 --> Router Class Initialized
INFO - 2020-02-26 16:24:23 --> Output Class Initialized
INFO - 2020-02-26 16:24:24 --> Security Class Initialized
DEBUG - 2020-02-26 16:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:24 --> Input Class Initialized
INFO - 2020-02-26 16:24:24 --> Language Class Initialized
ERROR - 2020-02-26 16:24:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 16:24:24 --> Config Class Initialized
INFO - 2020-02-26 16:24:24 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:24:24 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:24 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:24 --> URI Class Initialized
INFO - 2020-02-26 16:24:24 --> Router Class Initialized
INFO - 2020-02-26 16:24:24 --> Output Class Initialized
INFO - 2020-02-26 16:24:24 --> Security Class Initialized
DEBUG - 2020-02-26 16:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:24 --> Input Class Initialized
INFO - 2020-02-26 16:24:24 --> Language Class Initialized
ERROR - 2020-02-26 16:24:24 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 16:24:24 --> Config Class Initialized
INFO - 2020-02-26 16:24:24 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:24:24 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:24 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:24 --> URI Class Initialized
INFO - 2020-02-26 16:24:24 --> Router Class Initialized
INFO - 2020-02-26 16:24:24 --> Output Class Initialized
INFO - 2020-02-26 16:24:24 --> Security Class Initialized
DEBUG - 2020-02-26 16:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:24 --> Input Class Initialized
INFO - 2020-02-26 16:24:24 --> Language Class Initialized
ERROR - 2020-02-26 16:24:24 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 16:24:24 --> Config Class Initialized
INFO - 2020-02-26 16:24:24 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:24:24 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:24 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:24 --> URI Class Initialized
INFO - 2020-02-26 16:24:24 --> Router Class Initialized
INFO - 2020-02-26 16:24:24 --> Output Class Initialized
INFO - 2020-02-26 16:24:25 --> Security Class Initialized
DEBUG - 2020-02-26 16:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:25 --> Input Class Initialized
INFO - 2020-02-26 16:24:25 --> Language Class Initialized
ERROR - 2020-02-26 16:24:25 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 16:24:25 --> Config Class Initialized
INFO - 2020-02-26 16:24:25 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:24:25 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:24:25 --> Utf8 Class Initialized
INFO - 2020-02-26 16:24:25 --> URI Class Initialized
INFO - 2020-02-26 16:24:25 --> Router Class Initialized
INFO - 2020-02-26 16:24:25 --> Output Class Initialized
INFO - 2020-02-26 16:24:25 --> Security Class Initialized
DEBUG - 2020-02-26 16:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:24:25 --> Input Class Initialized
INFO - 2020-02-26 16:24:25 --> Language Class Initialized
ERROR - 2020-02-26 16:24:25 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 16:25:14 --> Config Class Initialized
INFO - 2020-02-26 16:25:14 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:25:14 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:25:14 --> Utf8 Class Initialized
INFO - 2020-02-26 16:25:14 --> URI Class Initialized
INFO - 2020-02-26 16:25:14 --> Router Class Initialized
INFO - 2020-02-26 16:25:14 --> Output Class Initialized
INFO - 2020-02-26 16:25:14 --> Security Class Initialized
DEBUG - 2020-02-26 16:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:25:14 --> Input Class Initialized
INFO - 2020-02-26 16:25:14 --> Language Class Initialized
INFO - 2020-02-26 16:25:14 --> Loader Class Initialized
INFO - 2020-02-26 16:25:14 --> Helper loaded: url_helper
INFO - 2020-02-26 16:25:14 --> Helper loaded: string_helper
INFO - 2020-02-26 16:25:14 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:25:14 --> Controller Class Initialized
INFO - 2020-02-26 16:25:14 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:25:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:25:15 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:25:15 --> Helper loaded: form_helper
INFO - 2020-02-26 16:25:15 --> Form Validation Class Initialized
INFO - 2020-02-26 22:25:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 22:25:15 --> Final output sent to browser
DEBUG - 2020-02-26 22:25:15 --> Total execution time: 0.8980
INFO - 2020-02-26 16:25:26 --> Config Class Initialized
INFO - 2020-02-26 16:25:26 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:25:26 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:25:26 --> Utf8 Class Initialized
INFO - 2020-02-26 16:25:27 --> URI Class Initialized
INFO - 2020-02-26 16:25:27 --> Router Class Initialized
INFO - 2020-02-26 16:25:27 --> Output Class Initialized
INFO - 2020-02-26 16:25:27 --> Security Class Initialized
DEBUG - 2020-02-26 16:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:25:27 --> Input Class Initialized
INFO - 2020-02-26 16:25:27 --> Language Class Initialized
INFO - 2020-02-26 16:25:27 --> Loader Class Initialized
INFO - 2020-02-26 16:25:27 --> Helper loaded: url_helper
INFO - 2020-02-26 16:25:27 --> Helper loaded: string_helper
INFO - 2020-02-26 16:25:27 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:25:27 --> Controller Class Initialized
INFO - 2020-02-26 16:25:27 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:25:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:25:27 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:25:27 --> Helper loaded: form_helper
INFO - 2020-02-26 16:25:27 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:25:27 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 16:25:27 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:25:27 --> Final output sent to browser
DEBUG - 2020-02-26 16:25:27 --> Total execution time: 0.6745
INFO - 2020-02-26 16:30:02 --> Config Class Initialized
INFO - 2020-02-26 16:30:02 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:02 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:02 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:02 --> URI Class Initialized
INFO - 2020-02-26 16:30:02 --> Router Class Initialized
INFO - 2020-02-26 16:30:02 --> Output Class Initialized
INFO - 2020-02-26 16:30:02 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:02 --> Input Class Initialized
INFO - 2020-02-26 16:30:02 --> Language Class Initialized
INFO - 2020-02-26 16:30:02 --> Loader Class Initialized
INFO - 2020-02-26 16:30:02 --> Helper loaded: url_helper
INFO - 2020-02-26 16:30:02 --> Helper loaded: string_helper
INFO - 2020-02-26 16:30:02 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:30:02 --> Controller Class Initialized
INFO - 2020-02-26 16:30:02 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:30:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:30:02 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:30:02 --> Helper loaded: form_helper
INFO - 2020-02-26 16:30:02 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:30:02 --> Severity: Notice --> Undefined index: kode_bayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 33
ERROR - 2020-02-26 16:30:02 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 16:30:02 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:30:02 --> Final output sent to browser
DEBUG - 2020-02-26 16:30:02 --> Total execution time: 0.8992
INFO - 2020-02-26 16:30:14 --> Config Class Initialized
INFO - 2020-02-26 16:30:14 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:14 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:15 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:15 --> URI Class Initialized
INFO - 2020-02-26 16:30:15 --> Router Class Initialized
INFO - 2020-02-26 16:30:15 --> Output Class Initialized
INFO - 2020-02-26 16:30:15 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:15 --> Input Class Initialized
INFO - 2020-02-26 16:30:15 --> Language Class Initialized
INFO - 2020-02-26 16:30:15 --> Loader Class Initialized
INFO - 2020-02-26 16:30:15 --> Helper loaded: url_helper
INFO - 2020-02-26 16:30:15 --> Helper loaded: string_helper
INFO - 2020-02-26 16:30:15 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:30:15 --> Controller Class Initialized
INFO - 2020-02-26 16:30:15 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:30:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:30:15 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:30:15 --> Helper loaded: form_helper
INFO - 2020-02-26 16:30:15 --> Form Validation Class Initialized
INFO - 2020-02-26 16:30:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:30:15 --> Final output sent to browser
DEBUG - 2020-02-26 16:30:15 --> Total execution time: 0.8440
INFO - 2020-02-26 16:30:15 --> Config Class Initialized
INFO - 2020-02-26 16:30:15 --> Config Class Initialized
INFO - 2020-02-26 16:30:15 --> Config Class Initialized
INFO - 2020-02-26 16:30:15 --> Hooks Class Initialized
INFO - 2020-02-26 16:30:15 --> Hooks Class Initialized
INFO - 2020-02-26 16:30:15 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:30:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:30:15 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:15 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:15 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:15 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:16 --> URI Class Initialized
INFO - 2020-02-26 16:30:16 --> URI Class Initialized
INFO - 2020-02-26 16:30:16 --> URI Class Initialized
INFO - 2020-02-26 16:30:16 --> Router Class Initialized
INFO - 2020-02-26 16:30:16 --> Router Class Initialized
INFO - 2020-02-26 16:30:16 --> Router Class Initialized
INFO - 2020-02-26 16:30:16 --> Output Class Initialized
INFO - 2020-02-26 16:30:16 --> Output Class Initialized
INFO - 2020-02-26 16:30:16 --> Output Class Initialized
INFO - 2020-02-26 16:30:16 --> Security Class Initialized
INFO - 2020-02-26 16:30:16 --> Security Class Initialized
INFO - 2020-02-26 16:30:16 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:16 --> Input Class Initialized
DEBUG - 2020-02-26 16:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:16 --> Input Class Initialized
INFO - 2020-02-26 16:30:16 --> Input Class Initialized
INFO - 2020-02-26 16:30:16 --> Language Class Initialized
INFO - 2020-02-26 16:30:16 --> Language Class Initialized
INFO - 2020-02-26 16:30:16 --> Language Class Initialized
INFO - 2020-02-26 16:30:16 --> Loader Class Initialized
ERROR - 2020-02-26 16:30:16 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 16:30:16 --> Helper loaded: url_helper
INFO - 2020-02-26 16:30:16 --> Loader Class Initialized
INFO - 2020-02-26 16:30:16 --> Helper loaded: string_helper
INFO - 2020-02-26 16:30:16 --> Helper loaded: url_helper
INFO - 2020-02-26 16:30:16 --> Helper loaded: string_helper
INFO - 2020-02-26 16:30:16 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:30:16 --> Database Driver Class Initialized
INFO - 2020-02-26 16:30:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-26 16:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:30:16 --> Controller Class Initialized
INFO - 2020-02-26 16:30:16 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:30:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:30:16 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:30:16 --> Helper loaded: form_helper
INFO - 2020-02-26 16:30:16 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:30:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 16:30:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 16:30:16 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:30:16 --> Final output sent to browser
DEBUG - 2020-02-26 16:30:16 --> Total execution time: 1.0442
INFO - 2020-02-26 16:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:30:17 --> Controller Class Initialized
INFO - 2020-02-26 16:30:17 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:30:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:30:17 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:30:17 --> Helper loaded: form_helper
INFO - 2020-02-26 16:30:17 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:30:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 16:30:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 16:30:17 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:30:17 --> Final output sent to browser
DEBUG - 2020-02-26 16:30:17 --> Total execution time: 1.4677
INFO - 2020-02-26 16:30:26 --> Config Class Initialized
INFO - 2020-02-26 16:30:26 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:26 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:26 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:26 --> URI Class Initialized
INFO - 2020-02-26 16:30:26 --> Router Class Initialized
INFO - 2020-02-26 16:30:26 --> Output Class Initialized
INFO - 2020-02-26 16:30:26 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:26 --> Input Class Initialized
INFO - 2020-02-26 16:30:26 --> Language Class Initialized
INFO - 2020-02-26 16:30:26 --> Loader Class Initialized
INFO - 2020-02-26 16:30:26 --> Helper loaded: url_helper
INFO - 2020-02-26 16:30:26 --> Helper loaded: string_helper
INFO - 2020-02-26 16:30:26 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:30:26 --> Controller Class Initialized
INFO - 2020-02-26 16:30:26 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:30:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:30:27 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:30:27 --> Helper loaded: form_helper
INFO - 2020-02-26 16:30:27 --> Form Validation Class Initialized
INFO - 2020-02-26 16:30:27 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:30:27 --> Final output sent to browser
INFO - 2020-02-26 16:30:27 --> Config Class Initialized
INFO - 2020-02-26 16:30:27 --> Config Class Initialized
INFO - 2020-02-26 16:30:27 --> Config Class Initialized
INFO - 2020-02-26 16:30:27 --> Config Class Initialized
INFO - 2020-02-26 16:30:27 --> Hooks Class Initialized
INFO - 2020-02-26 16:30:27 --> Hooks Class Initialized
INFO - 2020-02-26 16:30:27 --> Hooks Class Initialized
INFO - 2020-02-26 16:30:27 --> Config Class Initialized
INFO - 2020-02-26 16:30:27 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:27 --> Total execution time: 0.8561
DEBUG - 2020-02-26 16:30:27 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:27 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:27 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:27 --> Config Class Initialized
DEBUG - 2020-02-26 16:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:30:27 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:27 --> Hooks Class Initialized
INFO - 2020-02-26 16:30:27 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:27 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:27 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:27 --> Utf8 Class Initialized
DEBUG - 2020-02-26 16:30:27 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:27 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:27 --> URI Class Initialized
INFO - 2020-02-26 16:30:27 --> URI Class Initialized
DEBUG - 2020-02-26 16:30:27 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:27 --> URI Class Initialized
INFO - 2020-02-26 16:30:27 --> URI Class Initialized
INFO - 2020-02-26 16:30:27 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:27 --> Router Class Initialized
INFO - 2020-02-26 16:30:27 --> Router Class Initialized
INFO - 2020-02-26 16:30:27 --> URI Class Initialized
INFO - 2020-02-26 16:30:27 --> Router Class Initialized
INFO - 2020-02-26 16:30:27 --> Router Class Initialized
INFO - 2020-02-26 16:30:27 --> URI Class Initialized
INFO - 2020-02-26 16:30:27 --> Router Class Initialized
INFO - 2020-02-26 16:30:27 --> Output Class Initialized
INFO - 2020-02-26 16:30:27 --> Output Class Initialized
INFO - 2020-02-26 16:30:27 --> Output Class Initialized
INFO - 2020-02-26 16:30:27 --> Output Class Initialized
INFO - 2020-02-26 16:30:27 --> Router Class Initialized
INFO - 2020-02-26 16:30:27 --> Security Class Initialized
INFO - 2020-02-26 16:30:27 --> Security Class Initialized
INFO - 2020-02-26 16:30:27 --> Security Class Initialized
INFO - 2020-02-26 16:30:27 --> Output Class Initialized
INFO - 2020-02-26 16:30:27 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:27 --> Output Class Initialized
DEBUG - 2020-02-26 16:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:27 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:27 --> Input Class Initialized
INFO - 2020-02-26 16:30:27 --> Input Class Initialized
INFO - 2020-02-26 16:30:27 --> Input Class Initialized
INFO - 2020-02-26 16:30:27 --> Security Class Initialized
INFO - 2020-02-26 16:30:27 --> Input Class Initialized
DEBUG - 2020-02-26 16:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:28 --> Language Class Initialized
INFO - 2020-02-26 16:30:28 --> Language Class Initialized
DEBUG - 2020-02-26 16:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:28 --> Language Class Initialized
INFO - 2020-02-26 16:30:28 --> Language Class Initialized
INFO - 2020-02-26 16:30:28 --> Input Class Initialized
INFO - 2020-02-26 16:30:28 --> Language Class Initialized
INFO - 2020-02-26 16:30:28 --> Input Class Initialized
ERROR - 2020-02-26 16:30:28 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-26 16:30:28 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 16:30:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 16:30:28 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 16:30:28 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 16:30:28 --> Config Class Initialized
INFO - 2020-02-26 16:30:28 --> Config Class Initialized
INFO - 2020-02-26 16:30:28 --> Hooks Class Initialized
INFO - 2020-02-26 16:30:28 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:28 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:28 --> Language Class Initialized
INFO - 2020-02-26 16:30:28 --> Config Class Initialized
INFO - 2020-02-26 16:30:28 --> Config Class Initialized
INFO - 2020-02-26 16:30:28 --> Config Class Initialized
INFO - 2020-02-26 16:30:28 --> Hooks Class Initialized
INFO - 2020-02-26 16:30:28 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:28 --> Hooks Class Initialized
INFO - 2020-02-26 16:30:28 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:28 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:28 --> Loader Class Initialized
INFO - 2020-02-26 16:30:28 --> URI Class Initialized
INFO - 2020-02-26 16:30:28 --> Helper loaded: url_helper
INFO - 2020-02-26 16:30:28 --> Utf8 Class Initialized
DEBUG - 2020-02-26 16:30:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:30:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:30:28 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:28 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:28 --> Helper loaded: string_helper
INFO - 2020-02-26 16:30:28 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:28 --> Router Class Initialized
INFO - 2020-02-26 16:30:28 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:28 --> URI Class Initialized
INFO - 2020-02-26 16:30:28 --> URI Class Initialized
INFO - 2020-02-26 16:30:28 --> Router Class Initialized
INFO - 2020-02-26 16:30:28 --> URI Class Initialized
INFO - 2020-02-26 16:30:28 --> Output Class Initialized
INFO - 2020-02-26 16:30:28 --> URI Class Initialized
INFO - 2020-02-26 16:30:28 --> Database Driver Class Initialized
INFO - 2020-02-26 16:30:28 --> Router Class Initialized
INFO - 2020-02-26 16:30:28 --> Security Class Initialized
INFO - 2020-02-26 16:30:28 --> Router Class Initialized
INFO - 2020-02-26 16:30:28 --> Router Class Initialized
INFO - 2020-02-26 16:30:28 --> Output Class Initialized
DEBUG - 2020-02-26 16:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:30:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-26 16:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:28 --> Output Class Initialized
INFO - 2020-02-26 16:30:28 --> Security Class Initialized
INFO - 2020-02-26 16:30:28 --> Output Class Initialized
INFO - 2020-02-26 16:30:28 --> Output Class Initialized
INFO - 2020-02-26 16:30:28 --> Input Class Initialized
INFO - 2020-02-26 16:30:28 --> Security Class Initialized
INFO - 2020-02-26 16:30:28 --> Security Class Initialized
INFO - 2020-02-26 16:30:28 --> Controller Class Initialized
INFO - 2020-02-26 16:30:28 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:28 --> Language Class Initialized
INFO - 2020-02-26 16:30:28 --> Input Class Initialized
INFO - 2020-02-26 16:30:28 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:30:28 --> Input Class Initialized
INFO - 2020-02-26 16:30:28 --> Input Class Initialized
INFO - 2020-02-26 16:30:28 --> Language Class Initialized
INFO - 2020-02-26 16:30:28 --> Input Class Initialized
INFO - 2020-02-26 16:30:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:30:28 --> Loader Class Initialized
INFO - 2020-02-26 16:30:28 --> Language Class Initialized
INFO - 2020-02-26 16:30:28 --> Language Class Initialized
INFO - 2020-02-26 16:30:28 --> Helper loaded: url_helper
INFO - 2020-02-26 16:30:28 --> Model "M_pesan" initialized
ERROR - 2020-02-26 16:30:28 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 16:30:28 --> Language Class Initialized
INFO - 2020-02-26 16:30:28 --> Helper loaded: string_helper
ERROR - 2020-02-26 16:30:28 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 16:30:28 --> Helper loaded: form_helper
ERROR - 2020-02-26 16:30:28 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-26 16:30:28 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 16:30:28 --> Config Class Initialized
INFO - 2020-02-26 16:30:28 --> Hooks Class Initialized
INFO - 2020-02-26 16:30:28 --> Form Validation Class Initialized
INFO - 2020-02-26 16:30:29 --> Database Driver Class Initialized
INFO - 2020-02-26 16:30:29 --> Config Class Initialized
INFO - 2020-02-26 16:30:29 --> Config Class Initialized
INFO - 2020-02-26 16:30:29 --> Hooks Class Initialized
INFO - 2020-02-26 16:30:29 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:29 --> UTF-8 Support Enabled
ERROR - 2020-02-26 16:30:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
DEBUG - 2020-02-26 16:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-02-26 16:30:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 16:30:29 --> Utf8 Class Initialized
DEBUG - 2020-02-26 16:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:30:29 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:29 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:29 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:30:29 --> URI Class Initialized
INFO - 2020-02-26 16:30:29 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:29 --> Final output sent to browser
INFO - 2020-02-26 16:30:29 --> Router Class Initialized
INFO - 2020-02-26 16:30:29 --> URI Class Initialized
INFO - 2020-02-26 16:30:29 --> URI Class Initialized
DEBUG - 2020-02-26 16:30:29 --> Total execution time: 1.6951
INFO - 2020-02-26 16:30:29 --> Router Class Initialized
INFO - 2020-02-26 16:30:29 --> Router Class Initialized
INFO - 2020-02-26 16:30:29 --> Output Class Initialized
INFO - 2020-02-26 16:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:30:29 --> Output Class Initialized
INFO - 2020-02-26 16:30:29 --> Security Class Initialized
INFO - 2020-02-26 16:30:29 --> Output Class Initialized
INFO - 2020-02-26 16:30:29 --> Controller Class Initialized
INFO - 2020-02-26 16:30:29 --> Security Class Initialized
INFO - 2020-02-26 16:30:29 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:29 --> Input Class Initialized
INFO - 2020-02-26 16:30:29 --> Model "M_tiket" initialized
DEBUG - 2020-02-26 16:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:29 --> Input Class Initialized
INFO - 2020-02-26 16:30:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:30:29 --> Language Class Initialized
INFO - 2020-02-26 16:30:29 --> Input Class Initialized
INFO - 2020-02-26 16:30:29 --> Model "M_pesan" initialized
ERROR - 2020-02-26 16:30:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 16:30:29 --> Language Class Initialized
INFO - 2020-02-26 16:30:29 --> Language Class Initialized
ERROR - 2020-02-26 16:30:29 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 16:30:29 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 16:30:29 --> Helper loaded: form_helper
INFO - 2020-02-26 16:30:29 --> Form Validation Class Initialized
INFO - 2020-02-26 16:30:29 --> Config Class Initialized
INFO - 2020-02-26 16:30:29 --> Hooks Class Initialized
ERROR - 2020-02-26 16:30:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 16:30:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
DEBUG - 2020-02-26 16:30:29 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:29 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:29 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:30:29 --> Final output sent to browser
INFO - 2020-02-26 16:30:29 --> URI Class Initialized
DEBUG - 2020-02-26 16:30:29 --> Total execution time: 1.5840
INFO - 2020-02-26 16:30:29 --> Router Class Initialized
INFO - 2020-02-26 16:30:29 --> Output Class Initialized
INFO - 2020-02-26 16:30:29 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:30 --> Input Class Initialized
INFO - 2020-02-26 16:30:30 --> Language Class Initialized
ERROR - 2020-02-26 16:30:30 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 16:30:30 --> Config Class Initialized
INFO - 2020-02-26 16:30:30 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:30 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:30 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:30 --> URI Class Initialized
INFO - 2020-02-26 16:30:30 --> Router Class Initialized
INFO - 2020-02-26 16:30:30 --> Output Class Initialized
INFO - 2020-02-26 16:30:30 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:30 --> Input Class Initialized
INFO - 2020-02-26 16:30:30 --> Language Class Initialized
ERROR - 2020-02-26 16:30:30 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 16:30:30 --> Config Class Initialized
INFO - 2020-02-26 16:30:30 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:30 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:30 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:30 --> URI Class Initialized
INFO - 2020-02-26 16:30:30 --> Router Class Initialized
INFO - 2020-02-26 16:30:30 --> Output Class Initialized
INFO - 2020-02-26 16:30:30 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:30 --> Input Class Initialized
INFO - 2020-02-26 16:30:30 --> Language Class Initialized
ERROR - 2020-02-26 16:30:30 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 16:30:30 --> Config Class Initialized
INFO - 2020-02-26 16:30:30 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:30 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:30 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:30 --> URI Class Initialized
INFO - 2020-02-26 16:30:30 --> Router Class Initialized
INFO - 2020-02-26 16:30:30 --> Output Class Initialized
INFO - 2020-02-26 16:30:30 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:30 --> Input Class Initialized
INFO - 2020-02-26 16:30:30 --> Language Class Initialized
ERROR - 2020-02-26 16:30:31 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 16:30:31 --> Config Class Initialized
INFO - 2020-02-26 16:30:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:31 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:31 --> URI Class Initialized
INFO - 2020-02-26 16:30:31 --> Router Class Initialized
INFO - 2020-02-26 16:30:31 --> Output Class Initialized
INFO - 2020-02-26 16:30:31 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:31 --> Input Class Initialized
INFO - 2020-02-26 16:30:31 --> Language Class Initialized
ERROR - 2020-02-26 16:30:31 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 16:30:31 --> Config Class Initialized
INFO - 2020-02-26 16:30:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:31 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:31 --> URI Class Initialized
INFO - 2020-02-26 16:30:31 --> Router Class Initialized
INFO - 2020-02-26 16:30:31 --> Output Class Initialized
INFO - 2020-02-26 16:30:31 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:31 --> Input Class Initialized
INFO - 2020-02-26 16:30:31 --> Language Class Initialized
ERROR - 2020-02-26 16:30:31 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 16:30:31 --> Config Class Initialized
INFO - 2020-02-26 16:30:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:31 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:31 --> URI Class Initialized
INFO - 2020-02-26 16:30:31 --> Router Class Initialized
INFO - 2020-02-26 16:30:31 --> Output Class Initialized
INFO - 2020-02-26 16:30:31 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:31 --> Input Class Initialized
INFO - 2020-02-26 16:30:31 --> Language Class Initialized
ERROR - 2020-02-26 16:30:32 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 16:30:32 --> Config Class Initialized
INFO - 2020-02-26 16:30:32 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:32 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:32 --> URI Class Initialized
INFO - 2020-02-26 16:30:32 --> Router Class Initialized
INFO - 2020-02-26 16:30:32 --> Output Class Initialized
INFO - 2020-02-26 16:30:32 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:32 --> Input Class Initialized
INFO - 2020-02-26 16:30:32 --> Language Class Initialized
ERROR - 2020-02-26 16:30:32 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 16:30:32 --> Config Class Initialized
INFO - 2020-02-26 16:30:32 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:30:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:30:32 --> Utf8 Class Initialized
INFO - 2020-02-26 16:30:32 --> URI Class Initialized
INFO - 2020-02-26 16:30:32 --> Router Class Initialized
INFO - 2020-02-26 16:30:32 --> Output Class Initialized
INFO - 2020-02-26 16:30:32 --> Security Class Initialized
DEBUG - 2020-02-26 16:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:30:32 --> Input Class Initialized
INFO - 2020-02-26 16:30:32 --> Language Class Initialized
ERROR - 2020-02-26 16:30:32 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 16:31:32 --> Config Class Initialized
INFO - 2020-02-26 16:31:32 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:31:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:31:32 --> Utf8 Class Initialized
INFO - 2020-02-26 16:31:32 --> URI Class Initialized
INFO - 2020-02-26 16:31:32 --> Router Class Initialized
INFO - 2020-02-26 16:31:32 --> Output Class Initialized
INFO - 2020-02-26 16:31:32 --> Security Class Initialized
DEBUG - 2020-02-26 16:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:31:32 --> Input Class Initialized
INFO - 2020-02-26 16:31:32 --> Language Class Initialized
INFO - 2020-02-26 16:31:32 --> Loader Class Initialized
INFO - 2020-02-26 16:31:32 --> Helper loaded: url_helper
INFO - 2020-02-26 16:31:32 --> Helper loaded: string_helper
INFO - 2020-02-26 16:31:32 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:31:32 --> Controller Class Initialized
INFO - 2020-02-26 16:31:32 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:31:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:31:32 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:31:32 --> Helper loaded: form_helper
INFO - 2020-02-26 16:31:32 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 94
ERROR - 2020-02-26 22:31:33 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `id_pengunjung`) VALUES ('33', '100000', '1', '1', '20-02-26 10:31:33', '2020-02-27 10:31:33', NULL, 'PM168', NULL, NULL)
INFO - 2020-02-26 22:31:33 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-26 16:31:53 --> Config Class Initialized
INFO - 2020-02-26 16:31:53 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:31:53 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:31:53 --> Utf8 Class Initialized
INFO - 2020-02-26 16:31:53 --> URI Class Initialized
INFO - 2020-02-26 16:31:53 --> Router Class Initialized
INFO - 2020-02-26 16:31:53 --> Output Class Initialized
INFO - 2020-02-26 16:31:53 --> Security Class Initialized
DEBUG - 2020-02-26 16:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:31:53 --> Input Class Initialized
INFO - 2020-02-26 16:31:53 --> Language Class Initialized
INFO - 2020-02-26 16:31:53 --> Loader Class Initialized
INFO - 2020-02-26 16:31:53 --> Helper loaded: url_helper
INFO - 2020-02-26 16:31:53 --> Helper loaded: string_helper
INFO - 2020-02-26 16:31:53 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:31:53 --> Controller Class Initialized
INFO - 2020-02-26 16:31:53 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:31:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:31:53 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:31:53 --> Helper loaded: form_helper
INFO - 2020-02-26 16:31:53 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:31:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 94
ERROR - 2020-02-26 22:31:54 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `id_pengunjung`) VALUES ('33', '100000', '1', '1', '20-02-26 10:31:54', '2020-02-27 10:31:54', NULL, 'PM168', NULL, NULL)
INFO - 2020-02-26 22:31:54 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-26 16:32:00 --> Config Class Initialized
INFO - 2020-02-26 16:32:00 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:00 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:00 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:00 --> URI Class Initialized
DEBUG - 2020-02-26 16:32:00 --> No URI present. Default controller set.
INFO - 2020-02-26 16:32:00 --> Router Class Initialized
INFO - 2020-02-26 16:32:00 --> Output Class Initialized
INFO - 2020-02-26 16:32:00 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:00 --> Input Class Initialized
INFO - 2020-02-26 16:32:00 --> Language Class Initialized
INFO - 2020-02-26 16:32:00 --> Loader Class Initialized
INFO - 2020-02-26 16:32:01 --> Helper loaded: url_helper
INFO - 2020-02-26 16:32:01 --> Helper loaded: string_helper
INFO - 2020-02-26 16:32:01 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:32:01 --> Controller Class Initialized
INFO - 2020-02-26 16:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 16:32:01 --> Pagination Class Initialized
INFO - 2020-02-26 16:32:01 --> Model "M_show" initialized
INFO - 2020-02-26 16:32:01 --> Helper loaded: form_helper
INFO - 2020-02-26 16:32:01 --> Form Validation Class Initialized
INFO - 2020-02-26 16:32:01 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 16:32:01 --> Final output sent to browser
INFO - 2020-02-26 16:32:01 --> Config Class Initialized
INFO - 2020-02-26 16:32:01 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:01 --> Total execution time: 0.7870
DEBUG - 2020-02-26 16:32:01 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:01 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:01 --> URI Class Initialized
DEBUG - 2020-02-26 16:32:01 --> No URI present. Default controller set.
INFO - 2020-02-26 16:32:01 --> Router Class Initialized
INFO - 2020-02-26 16:32:01 --> Output Class Initialized
INFO - 2020-02-26 16:32:01 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:01 --> Input Class Initialized
INFO - 2020-02-26 16:32:01 --> Language Class Initialized
INFO - 2020-02-26 16:32:01 --> Loader Class Initialized
INFO - 2020-02-26 16:32:01 --> Helper loaded: url_helper
INFO - 2020-02-26 16:32:01 --> Helper loaded: string_helper
INFO - 2020-02-26 16:32:01 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:32:01 --> Controller Class Initialized
INFO - 2020-02-26 16:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 16:32:01 --> Pagination Class Initialized
INFO - 2020-02-26 16:32:02 --> Model "M_show" initialized
INFO - 2020-02-26 16:32:02 --> Helper loaded: form_helper
INFO - 2020-02-26 16:32:02 --> Form Validation Class Initialized
INFO - 2020-02-26 16:32:02 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 16:32:02 --> Final output sent to browser
DEBUG - 2020-02-26 16:32:02 --> Total execution time: 0.7700
INFO - 2020-02-26 16:32:04 --> Config Class Initialized
INFO - 2020-02-26 16:32:04 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:04 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:04 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:04 --> URI Class Initialized
INFO - 2020-02-26 16:32:04 --> Router Class Initialized
INFO - 2020-02-26 16:32:04 --> Output Class Initialized
INFO - 2020-02-26 16:32:04 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:04 --> Input Class Initialized
INFO - 2020-02-26 16:32:05 --> Language Class Initialized
INFO - 2020-02-26 16:32:05 --> Loader Class Initialized
INFO - 2020-02-26 16:32:05 --> Helper loaded: url_helper
INFO - 2020-02-26 16:32:05 --> Helper loaded: string_helper
INFO - 2020-02-26 16:32:05 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:32:05 --> Controller Class Initialized
INFO - 2020-02-26 16:32:05 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:32:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:32:05 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:32:05 --> Helper loaded: form_helper
INFO - 2020-02-26 16:32:05 --> Form Validation Class Initialized
INFO - 2020-02-26 16:32:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 16:32:05 --> Final output sent to browser
INFO - 2020-02-26 16:32:05 --> Config Class Initialized
INFO - 2020-02-26 16:32:05 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:05 --> Total execution time: 0.7345
INFO - 2020-02-26 16:32:05 --> Config Class Initialized
INFO - 2020-02-26 16:32:05 --> Config Class Initialized
INFO - 2020-02-26 16:32:05 --> Config Class Initialized
INFO - 2020-02-26 16:32:05 --> Config Class Initialized
INFO - 2020-02-26 16:32:05 --> Hooks Class Initialized
INFO - 2020-02-26 16:32:05 --> Hooks Class Initialized
INFO - 2020-02-26 16:32:05 --> Hooks Class Initialized
INFO - 2020-02-26 16:32:05 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:05 --> Config Class Initialized
INFO - 2020-02-26 16:32:05 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:05 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:32:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:32:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:32:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:05 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:05 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:05 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:05 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:05 --> URI Class Initialized
DEBUG - 2020-02-26 16:32:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:05 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:05 --> URI Class Initialized
INFO - 2020-02-26 16:32:05 --> URI Class Initialized
INFO - 2020-02-26 16:32:05 --> URI Class Initialized
INFO - 2020-02-26 16:32:05 --> URI Class Initialized
INFO - 2020-02-26 16:32:05 --> Router Class Initialized
INFO - 2020-02-26 16:32:05 --> Router Class Initialized
INFO - 2020-02-26 16:32:05 --> Router Class Initialized
INFO - 2020-02-26 16:32:05 --> Router Class Initialized
INFO - 2020-02-26 16:32:05 --> Output Class Initialized
INFO - 2020-02-26 16:32:05 --> URI Class Initialized
INFO - 2020-02-26 16:32:05 --> Router Class Initialized
INFO - 2020-02-26 16:32:05 --> Router Class Initialized
INFO - 2020-02-26 16:32:05 --> Output Class Initialized
INFO - 2020-02-26 16:32:05 --> Output Class Initialized
INFO - 2020-02-26 16:32:05 --> Output Class Initialized
INFO - 2020-02-26 16:32:05 --> Security Class Initialized
INFO - 2020-02-26 16:32:05 --> Output Class Initialized
DEBUG - 2020-02-26 16:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:05 --> Security Class Initialized
INFO - 2020-02-26 16:32:05 --> Security Class Initialized
INFO - 2020-02-26 16:32:05 --> Output Class Initialized
INFO - 2020-02-26 16:32:05 --> Security Class Initialized
INFO - 2020-02-26 16:32:05 --> Security Class Initialized
INFO - 2020-02-26 16:32:05 --> Input Class Initialized
DEBUG - 2020-02-26 16:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:05 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:05 --> Input Class Initialized
INFO - 2020-02-26 16:32:05 --> Input Class Initialized
INFO - 2020-02-26 16:32:05 --> Input Class Initialized
INFO - 2020-02-26 16:32:05 --> Input Class Initialized
INFO - 2020-02-26 16:32:05 --> Language Class Initialized
DEBUG - 2020-02-26 16:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:05 --> Input Class Initialized
INFO - 2020-02-26 16:32:05 --> Language Class Initialized
ERROR - 2020-02-26 16:32:05 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-26 16:32:05 --> Language Class Initialized
INFO - 2020-02-26 16:32:05 --> Language Class Initialized
INFO - 2020-02-26 16:32:05 --> Language Class Initialized
INFO - 2020-02-26 16:32:05 --> Language Class Initialized
ERROR - 2020-02-26 16:32:05 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-26 16:32:05 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 16:32:05 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-26 16:32:05 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 16:32:05 --> Config Class Initialized
INFO - 2020-02-26 16:32:05 --> Hooks Class Initialized
INFO - 2020-02-26 16:32:05 --> Loader Class Initialized
INFO - 2020-02-26 16:32:05 --> Config Class Initialized
INFO - 2020-02-26 16:32:05 --> Config Class Initialized
INFO - 2020-02-26 16:32:05 --> Config Class Initialized
INFO - 2020-02-26 16:32:05 --> Config Class Initialized
INFO - 2020-02-26 16:32:05 --> Hooks Class Initialized
INFO - 2020-02-26 16:32:05 --> Hooks Class Initialized
INFO - 2020-02-26 16:32:05 --> Hooks Class Initialized
INFO - 2020-02-26 16:32:05 --> Hooks Class Initialized
INFO - 2020-02-26 16:32:05 --> Helper loaded: url_helper
DEBUG - 2020-02-26 16:32:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:06 --> Utf8 Class Initialized
DEBUG - 2020-02-26 16:32:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:06 --> Helper loaded: string_helper
DEBUG - 2020-02-26 16:32:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:32:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:32:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:06 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:06 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:06 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:06 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:06 --> URI Class Initialized
INFO - 2020-02-26 16:32:06 --> Database Driver Class Initialized
INFO - 2020-02-26 16:32:06 --> URI Class Initialized
INFO - 2020-02-26 16:32:06 --> URI Class Initialized
INFO - 2020-02-26 16:32:06 --> URI Class Initialized
INFO - 2020-02-26 16:32:06 --> URI Class Initialized
INFO - 2020-02-26 16:32:06 --> Router Class Initialized
DEBUG - 2020-02-26 16:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:32:06 --> Router Class Initialized
INFO - 2020-02-26 16:32:06 --> Router Class Initialized
INFO - 2020-02-26 16:32:06 --> Router Class Initialized
INFO - 2020-02-26 16:32:06 --> Router Class Initialized
INFO - 2020-02-26 16:32:06 --> Output Class Initialized
INFO - 2020-02-26 16:32:06 --> Controller Class Initialized
INFO - 2020-02-26 16:32:06 --> Security Class Initialized
INFO - 2020-02-26 16:32:06 --> Output Class Initialized
INFO - 2020-02-26 16:32:06 --> Output Class Initialized
INFO - 2020-02-26 16:32:06 --> Output Class Initialized
INFO - 2020-02-26 16:32:06 --> Output Class Initialized
DEBUG - 2020-02-26 16:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:06 --> Security Class Initialized
INFO - 2020-02-26 16:32:06 --> Security Class Initialized
INFO - 2020-02-26 16:32:06 --> Security Class Initialized
INFO - 2020-02-26 16:32:06 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:32:06 --> Security Class Initialized
INFO - 2020-02-26 16:32:06 --> Input Class Initialized
DEBUG - 2020-02-26 16:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:06 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-26 16:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:06 --> Input Class Initialized
INFO - 2020-02-26 16:32:06 --> Input Class Initialized
INFO - 2020-02-26 16:32:06 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:32:06 --> Input Class Initialized
INFO - 2020-02-26 16:32:06 --> Language Class Initialized
INFO - 2020-02-26 16:32:06 --> Input Class Initialized
INFO - 2020-02-26 16:32:06 --> Language Class Initialized
INFO - 2020-02-26 16:32:06 --> Language Class Initialized
INFO - 2020-02-26 16:32:06 --> Language Class Initialized
INFO - 2020-02-26 16:32:06 --> Helper loaded: form_helper
INFO - 2020-02-26 16:32:06 --> Loader Class Initialized
INFO - 2020-02-26 16:32:06 --> Language Class Initialized
INFO - 2020-02-26 16:32:06 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:32:06 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 16:32:06 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 16:32:06 --> Helper loaded: url_helper
ERROR - 2020-02-26 16:32:06 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-26 16:32:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 16:32:06 --> Helper loaded: string_helper
INFO - 2020-02-26 16:32:06 --> Config Class Initialized
ERROR - 2020-02-26 16:32:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 16:32:06 --> Config Class Initialized
INFO - 2020-02-26 16:32:06 --> Config Class Initialized
INFO - 2020-02-26 16:32:06 --> Hooks Class Initialized
INFO - 2020-02-26 16:32:06 --> Hooks Class Initialized
INFO - 2020-02-26 16:32:06 --> Hooks Class Initialized
ERROR - 2020-02-26 16:32:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 16:32:06 --> Database Driver Class Initialized
INFO - 2020-02-26 16:32:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-26 16:32:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:32:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 16:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-26 16:32:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:06 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:06 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:06 --> Final output sent to browser
INFO - 2020-02-26 16:32:06 --> Utf8 Class Initialized
DEBUG - 2020-02-26 16:32:06 --> Total execution time: 0.8984
INFO - 2020-02-26 16:32:06 --> URI Class Initialized
INFO - 2020-02-26 16:32:06 --> URI Class Initialized
INFO - 2020-02-26 16:32:06 --> URI Class Initialized
INFO - 2020-02-26 16:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:32:06 --> Router Class Initialized
INFO - 2020-02-26 16:32:06 --> Router Class Initialized
INFO - 2020-02-26 16:32:06 --> Router Class Initialized
INFO - 2020-02-26 16:32:06 --> Controller Class Initialized
INFO - 2020-02-26 16:32:06 --> Output Class Initialized
INFO - 2020-02-26 16:32:06 --> Output Class Initialized
INFO - 2020-02-26 16:32:06 --> Output Class Initialized
INFO - 2020-02-26 16:32:06 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:32:06 --> Security Class Initialized
INFO - 2020-02-26 16:32:06 --> Security Class Initialized
INFO - 2020-02-26 16:32:06 --> Security Class Initialized
INFO - 2020-02-26 16:32:06 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-26 16:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 16:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:06 --> Input Class Initialized
INFO - 2020-02-26 16:32:06 --> Input Class Initialized
INFO - 2020-02-26 16:32:06 --> Input Class Initialized
INFO - 2020-02-26 16:32:06 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:32:06 --> Language Class Initialized
INFO - 2020-02-26 16:32:06 --> Language Class Initialized
INFO - 2020-02-26 16:32:06 --> Language Class Initialized
INFO - 2020-02-26 16:32:06 --> Helper loaded: form_helper
INFO - 2020-02-26 16:32:06 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:32:06 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 16:32:06 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 16:32:06 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-26 16:32:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 16:32:06 --> Config Class Initialized
INFO - 2020-02-26 16:32:06 --> Hooks Class Initialized
ERROR - 2020-02-26 16:32:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 16:32:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-26 16:32:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:06 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:06 --> Final output sent to browser
DEBUG - 2020-02-26 16:32:06 --> Total execution time: 0.9264
INFO - 2020-02-26 16:32:06 --> URI Class Initialized
INFO - 2020-02-26 16:32:06 --> Router Class Initialized
INFO - 2020-02-26 16:32:06 --> Output Class Initialized
INFO - 2020-02-26 16:32:06 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:07 --> Input Class Initialized
INFO - 2020-02-26 16:32:07 --> Language Class Initialized
ERROR - 2020-02-26 16:32:07 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 16:32:07 --> Config Class Initialized
INFO - 2020-02-26 16:32:07 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:07 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:07 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:07 --> URI Class Initialized
INFO - 2020-02-26 16:32:07 --> Router Class Initialized
INFO - 2020-02-26 16:32:07 --> Output Class Initialized
INFO - 2020-02-26 16:32:07 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:07 --> Input Class Initialized
INFO - 2020-02-26 16:32:07 --> Language Class Initialized
ERROR - 2020-02-26 16:32:07 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 16:32:07 --> Config Class Initialized
INFO - 2020-02-26 16:32:07 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:07 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:07 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:07 --> URI Class Initialized
INFO - 2020-02-26 16:32:07 --> Router Class Initialized
INFO - 2020-02-26 16:32:07 --> Output Class Initialized
INFO - 2020-02-26 16:32:07 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:07 --> Input Class Initialized
INFO - 2020-02-26 16:32:07 --> Language Class Initialized
ERROR - 2020-02-26 16:32:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 16:32:07 --> Config Class Initialized
INFO - 2020-02-26 16:32:07 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:07 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:07 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:07 --> URI Class Initialized
INFO - 2020-02-26 16:32:07 --> Router Class Initialized
INFO - 2020-02-26 16:32:07 --> Output Class Initialized
INFO - 2020-02-26 16:32:07 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:08 --> Input Class Initialized
INFO - 2020-02-26 16:32:08 --> Language Class Initialized
ERROR - 2020-02-26 16:32:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 16:32:08 --> Config Class Initialized
INFO - 2020-02-26 16:32:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:08 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:08 --> URI Class Initialized
INFO - 2020-02-26 16:32:08 --> Router Class Initialized
INFO - 2020-02-26 16:32:08 --> Output Class Initialized
INFO - 2020-02-26 16:32:08 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:08 --> Input Class Initialized
INFO - 2020-02-26 16:32:08 --> Language Class Initialized
ERROR - 2020-02-26 16:32:08 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 16:32:08 --> Config Class Initialized
INFO - 2020-02-26 16:32:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:08 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:08 --> URI Class Initialized
INFO - 2020-02-26 16:32:08 --> Router Class Initialized
INFO - 2020-02-26 16:32:08 --> Output Class Initialized
INFO - 2020-02-26 16:32:08 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:08 --> Input Class Initialized
INFO - 2020-02-26 16:32:08 --> Language Class Initialized
ERROR - 2020-02-26 16:32:08 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 16:32:08 --> Config Class Initialized
INFO - 2020-02-26 16:32:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:08 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:08 --> URI Class Initialized
INFO - 2020-02-26 16:32:08 --> Router Class Initialized
INFO - 2020-02-26 16:32:08 --> Output Class Initialized
INFO - 2020-02-26 16:32:08 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:09 --> Input Class Initialized
INFO - 2020-02-26 16:32:09 --> Language Class Initialized
ERROR - 2020-02-26 16:32:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 16:32:09 --> Config Class Initialized
INFO - 2020-02-26 16:32:09 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:09 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:09 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:09 --> URI Class Initialized
INFO - 2020-02-26 16:32:09 --> Router Class Initialized
INFO - 2020-02-26 16:32:09 --> Output Class Initialized
INFO - 2020-02-26 16:32:09 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:09 --> Input Class Initialized
INFO - 2020-02-26 16:32:09 --> Language Class Initialized
ERROR - 2020-02-26 16:32:09 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 16:32:22 --> Config Class Initialized
INFO - 2020-02-26 16:32:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:22 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:22 --> URI Class Initialized
INFO - 2020-02-26 16:32:22 --> Router Class Initialized
INFO - 2020-02-26 16:32:22 --> Output Class Initialized
INFO - 2020-02-26 16:32:22 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:22 --> Input Class Initialized
INFO - 2020-02-26 16:32:22 --> Language Class Initialized
INFO - 2020-02-26 16:32:22 --> Loader Class Initialized
INFO - 2020-02-26 16:32:22 --> Helper loaded: url_helper
INFO - 2020-02-26 16:32:22 --> Helper loaded: string_helper
INFO - 2020-02-26 16:32:23 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:32:23 --> Controller Class Initialized
INFO - 2020-02-26 16:32:23 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:32:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:32:23 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:32:23 --> Helper loaded: form_helper
INFO - 2020-02-26 16:32:23 --> Form Validation Class Initialized
INFO - 2020-02-26 22:32:23 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 22:32:23 --> Final output sent to browser
DEBUG - 2020-02-26 22:32:23 --> Total execution time: 0.8143
INFO - 2020-02-26 16:32:40 --> Config Class Initialized
INFO - 2020-02-26 16:32:40 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:32:40 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:32:40 --> Utf8 Class Initialized
INFO - 2020-02-26 16:32:41 --> URI Class Initialized
INFO - 2020-02-26 16:32:41 --> Router Class Initialized
INFO - 2020-02-26 16:32:41 --> Output Class Initialized
INFO - 2020-02-26 16:32:41 --> Security Class Initialized
DEBUG - 2020-02-26 16:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:32:41 --> Input Class Initialized
INFO - 2020-02-26 16:32:41 --> Language Class Initialized
INFO - 2020-02-26 16:32:41 --> Loader Class Initialized
INFO - 2020-02-26 16:32:41 --> Helper loaded: url_helper
INFO - 2020-02-26 16:32:41 --> Helper loaded: string_helper
INFO - 2020-02-26 16:32:41 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:32:41 --> Controller Class Initialized
INFO - 2020-02-26 16:32:41 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:32:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:32:41 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:32:41 --> Helper loaded: form_helper
INFO - 2020-02-26 16:32:41 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:32:41 --> Severity: Notice --> Undefined index: kodebayar C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 68
ERROR - 2020-02-26 16:32:41 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 16:32:41 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:32:41 --> Final output sent to browser
DEBUG - 2020-02-26 16:32:41 --> Total execution time: 0.7701
INFO - 2020-02-26 16:33:20 --> Config Class Initialized
INFO - 2020-02-26 16:33:20 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:33:20 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:33:20 --> Utf8 Class Initialized
INFO - 2020-02-26 16:33:20 --> URI Class Initialized
INFO - 2020-02-26 16:33:20 --> Router Class Initialized
INFO - 2020-02-26 16:33:20 --> Output Class Initialized
INFO - 2020-02-26 16:33:21 --> Security Class Initialized
DEBUG - 2020-02-26 16:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:33:21 --> Input Class Initialized
INFO - 2020-02-26 16:33:21 --> Language Class Initialized
INFO - 2020-02-26 16:33:21 --> Loader Class Initialized
INFO - 2020-02-26 16:33:21 --> Helper loaded: url_helper
INFO - 2020-02-26 16:33:21 --> Helper loaded: string_helper
INFO - 2020-02-26 16:33:21 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:33:21 --> Controller Class Initialized
INFO - 2020-02-26 16:33:21 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:33:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:33:21 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:33:21 --> Helper loaded: form_helper
INFO - 2020-02-26 16:33:21 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:33:21 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 16:33:21 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:33:21 --> Final output sent to browser
DEBUG - 2020-02-26 16:33:21 --> Total execution time: 0.7196
INFO - 2020-02-26 16:34:33 --> Config Class Initialized
INFO - 2020-02-26 16:34:33 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:34:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:34:33 --> Utf8 Class Initialized
INFO - 2020-02-26 16:34:33 --> URI Class Initialized
INFO - 2020-02-26 16:34:33 --> Router Class Initialized
INFO - 2020-02-26 16:34:33 --> Output Class Initialized
INFO - 2020-02-26 16:34:33 --> Security Class Initialized
DEBUG - 2020-02-26 16:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:34:33 --> Input Class Initialized
INFO - 2020-02-26 16:34:33 --> Language Class Initialized
INFO - 2020-02-26 16:34:33 --> Loader Class Initialized
INFO - 2020-02-26 16:34:33 --> Helper loaded: url_helper
INFO - 2020-02-26 16:34:33 --> Helper loaded: string_helper
INFO - 2020-02-26 16:34:33 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:34:34 --> Controller Class Initialized
INFO - 2020-02-26 16:34:34 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:34:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:34:34 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:34:34 --> Helper loaded: form_helper
INFO - 2020-02-26 16:34:34 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:34:34 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
ERROR - 2020-02-26 16:34:34 --> Severity: Notice --> Undefined variable: kode C:\xampp\htdocs\roadshow-2\application\views\Pemesanan\form_bukti.php 10
INFO - 2020-02-26 16:34:34 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:34:34 --> Final output sent to browser
DEBUG - 2020-02-26 16:34:34 --> Total execution time: 0.7284
INFO - 2020-02-26 16:37:05 --> Config Class Initialized
INFO - 2020-02-26 16:37:05 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:37:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:37:05 --> Utf8 Class Initialized
INFO - 2020-02-26 16:37:05 --> URI Class Initialized
INFO - 2020-02-26 16:37:05 --> Router Class Initialized
INFO - 2020-02-26 16:37:05 --> Output Class Initialized
INFO - 2020-02-26 16:37:05 --> Security Class Initialized
DEBUG - 2020-02-26 16:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:37:05 --> Input Class Initialized
INFO - 2020-02-26 16:37:05 --> Language Class Initialized
INFO - 2020-02-26 16:37:05 --> Loader Class Initialized
INFO - 2020-02-26 16:37:05 --> Helper loaded: url_helper
INFO - 2020-02-26 16:37:05 --> Helper loaded: string_helper
INFO - 2020-02-26 16:37:05 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:37:05 --> Controller Class Initialized
INFO - 2020-02-26 16:37:05 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:37:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:37:06 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:37:06 --> Helper loaded: form_helper
INFO - 2020-02-26 16:37:06 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:37:06 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
ERROR - 2020-02-26 16:37:06 --> Severity: Notice --> Undefined variable: kodebangsat C:\xampp\htdocs\roadshow-2\application\views\Pemesanan\form_bukti.php 10
INFO - 2020-02-26 16:37:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:37:06 --> Final output sent to browser
DEBUG - 2020-02-26 16:37:06 --> Total execution time: 0.8057
INFO - 2020-02-26 16:38:30 --> Config Class Initialized
INFO - 2020-02-26 16:38:30 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:38:30 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:38:30 --> Utf8 Class Initialized
INFO - 2020-02-26 16:38:30 --> URI Class Initialized
INFO - 2020-02-26 16:38:31 --> Router Class Initialized
INFO - 2020-02-26 16:38:31 --> Output Class Initialized
INFO - 2020-02-26 16:38:31 --> Security Class Initialized
DEBUG - 2020-02-26 16:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:38:31 --> Input Class Initialized
INFO - 2020-02-26 16:38:31 --> Language Class Initialized
INFO - 2020-02-26 16:38:31 --> Loader Class Initialized
INFO - 2020-02-26 16:38:31 --> Helper loaded: url_helper
INFO - 2020-02-26 16:38:31 --> Helper loaded: string_helper
INFO - 2020-02-26 16:38:31 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:38:31 --> Controller Class Initialized
INFO - 2020-02-26 16:38:31 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:38:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:38:31 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:38:31 --> Helper loaded: form_helper
INFO - 2020-02-26 16:38:31 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:38:31 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 16:38:31 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:38:31 --> Final output sent to browser
DEBUG - 2020-02-26 16:38:31 --> Total execution time: 0.6863
INFO - 2020-02-26 16:39:03 --> Config Class Initialized
INFO - 2020-02-26 16:39:03 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:39:03 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:39:03 --> Utf8 Class Initialized
INFO - 2020-02-26 16:39:03 --> URI Class Initialized
INFO - 2020-02-26 16:39:03 --> Router Class Initialized
INFO - 2020-02-26 16:39:03 --> Output Class Initialized
INFO - 2020-02-26 16:39:03 --> Security Class Initialized
DEBUG - 2020-02-26 16:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:39:03 --> Input Class Initialized
INFO - 2020-02-26 16:39:03 --> Language Class Initialized
INFO - 2020-02-26 16:39:03 --> Loader Class Initialized
INFO - 2020-02-26 16:39:03 --> Helper loaded: url_helper
INFO - 2020-02-26 16:39:03 --> Helper loaded: string_helper
INFO - 2020-02-26 16:39:03 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:39:03 --> Controller Class Initialized
INFO - 2020-02-26 16:39:03 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:39:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:39:03 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:39:03 --> Helper loaded: form_helper
INFO - 2020-02-26 16:39:03 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:39:03 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 16:39:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:39:03 --> Final output sent to browser
DEBUG - 2020-02-26 16:39:03 --> Total execution time: 0.6890
INFO - 2020-02-26 16:39:22 --> Config Class Initialized
INFO - 2020-02-26 16:39:22 --> Hooks Class Initialized
DEBUG - 2020-02-26 16:39:22 --> UTF-8 Support Enabled
INFO - 2020-02-26 16:39:22 --> Utf8 Class Initialized
INFO - 2020-02-26 16:39:22 --> URI Class Initialized
INFO - 2020-02-26 16:39:22 --> Router Class Initialized
INFO - 2020-02-26 16:39:22 --> Output Class Initialized
INFO - 2020-02-26 16:39:22 --> Security Class Initialized
DEBUG - 2020-02-26 16:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 16:39:22 --> Input Class Initialized
INFO - 2020-02-26 16:39:22 --> Language Class Initialized
INFO - 2020-02-26 16:39:22 --> Loader Class Initialized
INFO - 2020-02-26 16:39:22 --> Helper loaded: url_helper
INFO - 2020-02-26 16:39:22 --> Helper loaded: string_helper
INFO - 2020-02-26 16:39:22 --> Database Driver Class Initialized
DEBUG - 2020-02-26 16:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 16:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 16:39:23 --> Controller Class Initialized
INFO - 2020-02-26 16:39:23 --> Model "M_tiket" initialized
INFO - 2020-02-26 16:39:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 16:39:23 --> Model "M_pesan" initialized
INFO - 2020-02-26 16:39:23 --> Helper loaded: form_helper
INFO - 2020-02-26 16:39:23 --> Form Validation Class Initialized
ERROR - 2020-02-26 16:39:23 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 16:39:23 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 16:39:23 --> Final output sent to browser
DEBUG - 2020-02-26 16:39:23 --> Total execution time: 0.6861
INFO - 2020-02-26 17:22:51 --> Config Class Initialized
INFO - 2020-02-26 17:22:51 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:22:51 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:22:51 --> Utf8 Class Initialized
INFO - 2020-02-26 17:22:51 --> URI Class Initialized
INFO - 2020-02-26 17:22:52 --> Router Class Initialized
INFO - 2020-02-26 17:22:52 --> Output Class Initialized
INFO - 2020-02-26 17:22:52 --> Security Class Initialized
DEBUG - 2020-02-26 17:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:22:52 --> Input Class Initialized
INFO - 2020-02-26 17:22:52 --> Language Class Initialized
INFO - 2020-02-26 17:22:52 --> Loader Class Initialized
INFO - 2020-02-26 17:22:52 --> Helper loaded: url_helper
INFO - 2020-02-26 17:22:52 --> Helper loaded: string_helper
INFO - 2020-02-26 17:22:52 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:22:52 --> Controller Class Initialized
INFO - 2020-02-26 17:22:53 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:22:53 --> Model "M_pengunjung" initialized
ERROR - 2020-02-26 17:22:53 --> Severity: Compile Error --> Cannot redeclare M_pesan::$kode_unik C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 18
INFO - 2020-02-26 17:23:27 --> Config Class Initialized
INFO - 2020-02-26 17:23:27 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:23:27 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:27 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:27 --> URI Class Initialized
INFO - 2020-02-26 17:23:27 --> Router Class Initialized
INFO - 2020-02-26 17:23:27 --> Output Class Initialized
INFO - 2020-02-26 17:23:27 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:27 --> Input Class Initialized
INFO - 2020-02-26 17:23:27 --> Language Class Initialized
INFO - 2020-02-26 17:23:27 --> Loader Class Initialized
INFO - 2020-02-26 17:23:27 --> Helper loaded: url_helper
INFO - 2020-02-26 17:23:27 --> Helper loaded: string_helper
INFO - 2020-02-26 17:23:27 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:23:28 --> Controller Class Initialized
INFO - 2020-02-26 17:23:28 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:23:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:23:28 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:23:28 --> Helper loaded: form_helper
INFO - 2020-02-26 17:23:28 --> Form Validation Class Initialized
ERROR - 2020-02-26 17:23:28 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 30
ERROR - 2020-02-26 17:23:28 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 31
ERROR - 2020-02-26 17:23:28 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 32
ERROR - 2020-02-26 17:23:28 --> Severity: Notice --> Undefined index: kode_bayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 33
ERROR - 2020-02-26 17:23:28 --> Severity: Notice --> Undefined index: kode_bayar C:\xampp\htdocs\roadshow-2\application\models\M_pesan.php 70
ERROR - 2020-02-26 17:23:28 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 17:23:28 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 17:23:28 --> Final output sent to browser
DEBUG - 2020-02-26 17:23:28 --> Total execution time: 0.9973
INFO - 2020-02-26 17:23:37 --> Config Class Initialized
INFO - 2020-02-26 17:23:37 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:23:37 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:37 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:37 --> URI Class Initialized
DEBUG - 2020-02-26 17:23:37 --> No URI present. Default controller set.
INFO - 2020-02-26 17:23:37 --> Router Class Initialized
INFO - 2020-02-26 17:23:37 --> Output Class Initialized
INFO - 2020-02-26 17:23:37 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:37 --> Input Class Initialized
INFO - 2020-02-26 17:23:37 --> Language Class Initialized
INFO - 2020-02-26 17:23:37 --> Loader Class Initialized
INFO - 2020-02-26 17:23:37 --> Helper loaded: url_helper
INFO - 2020-02-26 17:23:37 --> Helper loaded: string_helper
INFO - 2020-02-26 17:23:37 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:23:37 --> Controller Class Initialized
INFO - 2020-02-26 17:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 17:23:38 --> Pagination Class Initialized
INFO - 2020-02-26 17:23:38 --> Model "M_show" initialized
INFO - 2020-02-26 17:23:38 --> Helper loaded: form_helper
INFO - 2020-02-26 17:23:38 --> Form Validation Class Initialized
INFO - 2020-02-26 17:23:38 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 17:23:38 --> Final output sent to browser
INFO - 2020-02-26 17:23:38 --> Config Class Initialized
INFO - 2020-02-26 17:23:38 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:23:38 --> Total execution time: 1.0545
DEBUG - 2020-02-26 17:23:38 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:38 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:38 --> URI Class Initialized
DEBUG - 2020-02-26 17:23:38 --> No URI present. Default controller set.
INFO - 2020-02-26 17:23:38 --> Router Class Initialized
INFO - 2020-02-26 17:23:38 --> Output Class Initialized
INFO - 2020-02-26 17:23:38 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:38 --> Input Class Initialized
INFO - 2020-02-26 17:23:38 --> Language Class Initialized
INFO - 2020-02-26 17:23:38 --> Loader Class Initialized
INFO - 2020-02-26 17:23:38 --> Helper loaded: url_helper
INFO - 2020-02-26 17:23:38 --> Helper loaded: string_helper
INFO - 2020-02-26 17:23:38 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:23:39 --> Controller Class Initialized
INFO - 2020-02-26 17:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 17:23:39 --> Pagination Class Initialized
INFO - 2020-02-26 17:23:39 --> Model "M_show" initialized
INFO - 2020-02-26 17:23:39 --> Helper loaded: form_helper
INFO - 2020-02-26 17:23:39 --> Form Validation Class Initialized
INFO - 2020-02-26 17:23:39 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 17:23:39 --> Final output sent to browser
DEBUG - 2020-02-26 17:23:39 --> Total execution time: 0.8406
INFO - 2020-02-26 17:23:54 --> Config Class Initialized
INFO - 2020-02-26 17:23:54 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:23:54 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:54 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:54 --> URI Class Initialized
INFO - 2020-02-26 17:23:54 --> Router Class Initialized
INFO - 2020-02-26 17:23:54 --> Output Class Initialized
INFO - 2020-02-26 17:23:54 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:54 --> Input Class Initialized
INFO - 2020-02-26 17:23:54 --> Language Class Initialized
INFO - 2020-02-26 17:23:54 --> Loader Class Initialized
INFO - 2020-02-26 17:23:54 --> Helper loaded: url_helper
INFO - 2020-02-26 17:23:54 --> Helper loaded: string_helper
INFO - 2020-02-26 17:23:54 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:23:54 --> Controller Class Initialized
INFO - 2020-02-26 17:23:55 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:23:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:23:55 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:23:55 --> Helper loaded: form_helper
INFO - 2020-02-26 17:23:55 --> Form Validation Class Initialized
INFO - 2020-02-26 17:23:55 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 17:23:55 --> Final output sent to browser
DEBUG - 2020-02-26 17:23:55 --> Total execution time: 0.8604
INFO - 2020-02-26 17:23:55 --> Config Class Initialized
INFO - 2020-02-26 17:23:55 --> Config Class Initialized
INFO - 2020-02-26 17:23:55 --> Config Class Initialized
INFO - 2020-02-26 17:23:55 --> Config Class Initialized
INFO - 2020-02-26 17:23:55 --> Config Class Initialized
INFO - 2020-02-26 17:23:55 --> Hooks Class Initialized
INFO - 2020-02-26 17:23:55 --> Hooks Class Initialized
INFO - 2020-02-26 17:23:55 --> Hooks Class Initialized
INFO - 2020-02-26 17:23:55 --> Hooks Class Initialized
INFO - 2020-02-26 17:23:55 --> Hooks Class Initialized
INFO - 2020-02-26 17:23:55 --> Config Class Initialized
INFO - 2020-02-26 17:23:55 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:23:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:23:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:23:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:23:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:23:55 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:55 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:55 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:55 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:55 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:23:55 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:55 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:55 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:55 --> URI Class Initialized
INFO - 2020-02-26 17:23:55 --> URI Class Initialized
INFO - 2020-02-26 17:23:55 --> URI Class Initialized
INFO - 2020-02-26 17:23:55 --> URI Class Initialized
INFO - 2020-02-26 17:23:55 --> URI Class Initialized
INFO - 2020-02-26 17:23:55 --> URI Class Initialized
INFO - 2020-02-26 17:23:55 --> Router Class Initialized
INFO - 2020-02-26 17:23:55 --> Router Class Initialized
INFO - 2020-02-26 17:23:55 --> Router Class Initialized
INFO - 2020-02-26 17:23:55 --> Router Class Initialized
INFO - 2020-02-26 17:23:55 --> Router Class Initialized
INFO - 2020-02-26 17:23:55 --> Output Class Initialized
INFO - 2020-02-26 17:23:55 --> Output Class Initialized
INFO - 2020-02-26 17:23:55 --> Output Class Initialized
INFO - 2020-02-26 17:23:55 --> Output Class Initialized
INFO - 2020-02-26 17:23:55 --> Router Class Initialized
INFO - 2020-02-26 17:23:55 --> Output Class Initialized
INFO - 2020-02-26 17:23:55 --> Security Class Initialized
INFO - 2020-02-26 17:23:55 --> Output Class Initialized
INFO - 2020-02-26 17:23:55 --> Security Class Initialized
INFO - 2020-02-26 17:23:55 --> Security Class Initialized
INFO - 2020-02-26 17:23:55 --> Security Class Initialized
INFO - 2020-02-26 17:23:55 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:55 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:55 --> Input Class Initialized
INFO - 2020-02-26 17:23:55 --> Input Class Initialized
INFO - 2020-02-26 17:23:55 --> Input Class Initialized
INFO - 2020-02-26 17:23:55 --> Input Class Initialized
INFO - 2020-02-26 17:23:55 --> Input Class Initialized
DEBUG - 2020-02-26 17:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:55 --> Input Class Initialized
INFO - 2020-02-26 17:23:55 --> Language Class Initialized
INFO - 2020-02-26 17:23:55 --> Language Class Initialized
INFO - 2020-02-26 17:23:55 --> Language Class Initialized
INFO - 2020-02-26 17:23:55 --> Language Class Initialized
INFO - 2020-02-26 17:23:55 --> Language Class Initialized
INFO - 2020-02-26 17:23:55 --> Language Class Initialized
ERROR - 2020-02-26 17:23:55 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 17:23:55 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-26 17:23:55 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-26 17:23:55 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 17:23:55 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 17:23:55 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 17:23:55 --> Config Class Initialized
INFO - 2020-02-26 17:23:55 --> Config Class Initialized
INFO - 2020-02-26 17:23:55 --> Config Class Initialized
INFO - 2020-02-26 17:23:55 --> Config Class Initialized
INFO - 2020-02-26 17:23:55 --> Config Class Initialized
INFO - 2020-02-26 17:23:55 --> Config Class Initialized
INFO - 2020-02-26 17:23:56 --> Hooks Class Initialized
INFO - 2020-02-26 17:23:56 --> Hooks Class Initialized
INFO - 2020-02-26 17:23:56 --> Hooks Class Initialized
INFO - 2020-02-26 17:23:56 --> Hooks Class Initialized
INFO - 2020-02-26 17:23:56 --> Hooks Class Initialized
INFO - 2020-02-26 17:23:56 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:23:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:23:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:23:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:23:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:23:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:23:56 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:56 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:56 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:56 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:56 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:56 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:56 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:56 --> URI Class Initialized
INFO - 2020-02-26 17:23:56 --> URI Class Initialized
INFO - 2020-02-26 17:23:56 --> URI Class Initialized
INFO - 2020-02-26 17:23:56 --> URI Class Initialized
INFO - 2020-02-26 17:23:56 --> URI Class Initialized
INFO - 2020-02-26 17:23:56 --> URI Class Initialized
INFO - 2020-02-26 17:23:56 --> Router Class Initialized
INFO - 2020-02-26 17:23:56 --> Router Class Initialized
INFO - 2020-02-26 17:23:56 --> Router Class Initialized
INFO - 2020-02-26 17:23:56 --> Router Class Initialized
INFO - 2020-02-26 17:23:56 --> Router Class Initialized
INFO - 2020-02-26 17:23:56 --> Router Class Initialized
INFO - 2020-02-26 17:23:56 --> Output Class Initialized
INFO - 2020-02-26 17:23:56 --> Output Class Initialized
INFO - 2020-02-26 17:23:56 --> Output Class Initialized
INFO - 2020-02-26 17:23:56 --> Output Class Initialized
INFO - 2020-02-26 17:23:56 --> Output Class Initialized
INFO - 2020-02-26 17:23:56 --> Output Class Initialized
INFO - 2020-02-26 17:23:56 --> Security Class Initialized
INFO - 2020-02-26 17:23:56 --> Security Class Initialized
INFO - 2020-02-26 17:23:56 --> Security Class Initialized
INFO - 2020-02-26 17:23:56 --> Security Class Initialized
INFO - 2020-02-26 17:23:56 --> Security Class Initialized
INFO - 2020-02-26 17:23:56 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:56 --> Input Class Initialized
INFO - 2020-02-26 17:23:56 --> Input Class Initialized
INFO - 2020-02-26 17:23:56 --> Input Class Initialized
INFO - 2020-02-26 17:23:56 --> Input Class Initialized
INFO - 2020-02-26 17:23:56 --> Input Class Initialized
INFO - 2020-02-26 17:23:56 --> Input Class Initialized
INFO - 2020-02-26 17:23:56 --> Language Class Initialized
INFO - 2020-02-26 17:23:56 --> Language Class Initialized
INFO - 2020-02-26 17:23:56 --> Language Class Initialized
INFO - 2020-02-26 17:23:56 --> Language Class Initialized
INFO - 2020-02-26 17:23:56 --> Language Class Initialized
INFO - 2020-02-26 17:23:56 --> Language Class Initialized
ERROR - 2020-02-26 17:23:56 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 17:23:56 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 17:23:56 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 17:23:56 --> Loader Class Initialized
INFO - 2020-02-26 17:23:56 --> Loader Class Initialized
ERROR - 2020-02-26 17:23:56 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 17:23:56 --> Helper loaded: url_helper
INFO - 2020-02-26 17:23:56 --> Helper loaded: url_helper
INFO - 2020-02-26 17:23:56 --> Config Class Initialized
INFO - 2020-02-26 17:23:56 --> Config Class Initialized
INFO - 2020-02-26 17:23:56 --> Hooks Class Initialized
INFO - 2020-02-26 17:23:56 --> Hooks Class Initialized
INFO - 2020-02-26 17:23:56 --> Helper loaded: string_helper
INFO - 2020-02-26 17:23:56 --> Helper loaded: string_helper
DEBUG - 2020-02-26 17:23:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:23:56 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:56 --> Database Driver Class Initialized
INFO - 2020-02-26 17:23:56 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:56 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:23:56 --> Database Driver Class Initialized
INFO - 2020-02-26 17:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:23:56 --> URI Class Initialized
INFO - 2020-02-26 17:23:56 --> URI Class Initialized
DEBUG - 2020-02-26 17:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:23:56 --> Controller Class Initialized
INFO - 2020-02-26 17:23:56 --> Router Class Initialized
INFO - 2020-02-26 17:23:56 --> Router Class Initialized
INFO - 2020-02-26 17:23:56 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:23:56 --> Output Class Initialized
INFO - 2020-02-26 17:23:56 --> Output Class Initialized
INFO - 2020-02-26 17:23:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:23:56 --> Security Class Initialized
INFO - 2020-02-26 17:23:56 --> Security Class Initialized
INFO - 2020-02-26 17:23:56 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 17:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:56 --> Input Class Initialized
INFO - 2020-02-26 17:23:56 --> Input Class Initialized
INFO - 2020-02-26 17:23:56 --> Helper loaded: form_helper
INFO - 2020-02-26 17:23:56 --> Form Validation Class Initialized
INFO - 2020-02-26 17:23:56 --> Language Class Initialized
INFO - 2020-02-26 17:23:56 --> Language Class Initialized
ERROR - 2020-02-26 17:23:56 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 17:23:56 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 17:23:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 17:23:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 17:23:56 --> Config Class Initialized
INFO - 2020-02-26 17:23:56 --> Hooks Class Initialized
INFO - 2020-02-26 17:23:56 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 17:23:56 --> Final output sent to browser
DEBUG - 2020-02-26 17:23:56 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:56 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:23:56 --> Total execution time: 0.8330
INFO - 2020-02-26 17:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:23:56 --> URI Class Initialized
INFO - 2020-02-26 17:23:56 --> Controller Class Initialized
INFO - 2020-02-26 17:23:56 --> Router Class Initialized
INFO - 2020-02-26 17:23:56 --> Output Class Initialized
INFO - 2020-02-26 17:23:56 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:23:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:23:56 --> Security Class Initialized
INFO - 2020-02-26 17:23:56 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 17:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:56 --> Input Class Initialized
INFO - 2020-02-26 17:23:57 --> Language Class Initialized
INFO - 2020-02-26 17:23:57 --> Helper loaded: form_helper
INFO - 2020-02-26 17:23:57 --> Form Validation Class Initialized
ERROR - 2020-02-26 17:23:57 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-26 17:23:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 17:23:57 --> Config Class Initialized
INFO - 2020-02-26 17:23:57 --> Hooks Class Initialized
ERROR - 2020-02-26 17:23:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 17:23:57 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-26 17:23:57 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:57 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:57 --> Final output sent to browser
DEBUG - 2020-02-26 17:23:57 --> Total execution time: 1.2274
INFO - 2020-02-26 17:23:57 --> URI Class Initialized
INFO - 2020-02-26 17:23:57 --> Router Class Initialized
INFO - 2020-02-26 17:23:57 --> Output Class Initialized
INFO - 2020-02-26 17:23:57 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:57 --> Input Class Initialized
INFO - 2020-02-26 17:23:57 --> Language Class Initialized
ERROR - 2020-02-26 17:23:57 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 17:23:57 --> Config Class Initialized
INFO - 2020-02-26 17:23:57 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:23:57 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:57 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:57 --> URI Class Initialized
INFO - 2020-02-26 17:23:57 --> Router Class Initialized
INFO - 2020-02-26 17:23:57 --> Output Class Initialized
INFO - 2020-02-26 17:23:57 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:57 --> Input Class Initialized
INFO - 2020-02-26 17:23:57 --> Language Class Initialized
ERROR - 2020-02-26 17:23:57 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 17:23:57 --> Config Class Initialized
INFO - 2020-02-26 17:23:57 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:23:57 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:57 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:57 --> URI Class Initialized
INFO - 2020-02-26 17:23:57 --> Router Class Initialized
INFO - 2020-02-26 17:23:57 --> Output Class Initialized
INFO - 2020-02-26 17:23:58 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:58 --> Input Class Initialized
INFO - 2020-02-26 17:23:58 --> Language Class Initialized
ERROR - 2020-02-26 17:23:58 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 17:23:58 --> Config Class Initialized
INFO - 2020-02-26 17:23:58 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:23:58 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:58 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:58 --> URI Class Initialized
INFO - 2020-02-26 17:23:58 --> Router Class Initialized
INFO - 2020-02-26 17:23:58 --> Output Class Initialized
INFO - 2020-02-26 17:23:58 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:58 --> Input Class Initialized
INFO - 2020-02-26 17:23:58 --> Language Class Initialized
ERROR - 2020-02-26 17:23:58 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 17:23:58 --> Config Class Initialized
INFO - 2020-02-26 17:23:58 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:23:58 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:58 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:58 --> URI Class Initialized
INFO - 2020-02-26 17:23:58 --> Router Class Initialized
INFO - 2020-02-26 17:23:58 --> Output Class Initialized
INFO - 2020-02-26 17:23:58 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:58 --> Input Class Initialized
INFO - 2020-02-26 17:23:58 --> Language Class Initialized
ERROR - 2020-02-26 17:23:58 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 17:23:58 --> Config Class Initialized
INFO - 2020-02-26 17:23:58 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:23:58 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:58 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:59 --> URI Class Initialized
INFO - 2020-02-26 17:23:59 --> Router Class Initialized
INFO - 2020-02-26 17:23:59 --> Output Class Initialized
INFO - 2020-02-26 17:23:59 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:59 --> Input Class Initialized
INFO - 2020-02-26 17:23:59 --> Language Class Initialized
ERROR - 2020-02-26 17:23:59 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 17:23:59 --> Config Class Initialized
INFO - 2020-02-26 17:23:59 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:23:59 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:59 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:59 --> URI Class Initialized
INFO - 2020-02-26 17:23:59 --> Router Class Initialized
INFO - 2020-02-26 17:23:59 --> Output Class Initialized
INFO - 2020-02-26 17:23:59 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:59 --> Input Class Initialized
INFO - 2020-02-26 17:23:59 --> Language Class Initialized
ERROR - 2020-02-26 17:23:59 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 17:23:59 --> Config Class Initialized
INFO - 2020-02-26 17:23:59 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:23:59 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:23:59 --> Utf8 Class Initialized
INFO - 2020-02-26 17:23:59 --> URI Class Initialized
INFO - 2020-02-26 17:23:59 --> Router Class Initialized
INFO - 2020-02-26 17:23:59 --> Output Class Initialized
INFO - 2020-02-26 17:23:59 --> Security Class Initialized
DEBUG - 2020-02-26 17:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:23:59 --> Input Class Initialized
INFO - 2020-02-26 17:24:00 --> Language Class Initialized
ERROR - 2020-02-26 17:24:00 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 17:24:31 --> Config Class Initialized
INFO - 2020-02-26 17:24:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:24:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:24:31 --> Utf8 Class Initialized
INFO - 2020-02-26 17:24:31 --> URI Class Initialized
INFO - 2020-02-26 17:24:31 --> Router Class Initialized
INFO - 2020-02-26 17:24:31 --> Output Class Initialized
INFO - 2020-02-26 17:24:31 --> Security Class Initialized
DEBUG - 2020-02-26 17:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:24:31 --> Input Class Initialized
INFO - 2020-02-26 17:24:31 --> Language Class Initialized
INFO - 2020-02-26 17:24:31 --> Loader Class Initialized
INFO - 2020-02-26 17:24:31 --> Helper loaded: url_helper
INFO - 2020-02-26 17:24:31 --> Helper loaded: string_helper
INFO - 2020-02-26 17:24:31 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:24:31 --> Controller Class Initialized
INFO - 2020-02-26 17:24:31 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:24:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:24:31 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:24:31 --> Helper loaded: form_helper
INFO - 2020-02-26 17:24:32 --> Form Validation Class Initialized
ERROR - 2020-02-26 17:24:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 99
ERROR - 2020-02-26 23:24:32 --> Query error: Unknown column 'total_bayar' in 'field list' - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `total_bayar`, `bukti_bayar`, `id_pengunjung`) VALUES ('33', '200000', '1', '2', '20-02-26 11:24:32', '2020-02-27 11:24:32', NULL, 'PM169', NULL, NULL, 'default.jpg', NULL)
INFO - 2020-02-26 23:24:32 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-26 17:25:18 --> Config Class Initialized
INFO - 2020-02-26 17:25:18 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:18 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:18 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:18 --> URI Class Initialized
INFO - 2020-02-26 17:25:18 --> Router Class Initialized
INFO - 2020-02-26 17:25:18 --> Output Class Initialized
INFO - 2020-02-26 17:25:18 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:18 --> Input Class Initialized
INFO - 2020-02-26 17:25:18 --> Language Class Initialized
INFO - 2020-02-26 17:25:18 --> Loader Class Initialized
INFO - 2020-02-26 17:25:18 --> Helper loaded: url_helper
INFO - 2020-02-26 17:25:18 --> Helper loaded: string_helper
INFO - 2020-02-26 17:25:18 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:25:18 --> Controller Class Initialized
INFO - 2020-02-26 17:25:19 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:25:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:25:19 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:25:19 --> Helper loaded: form_helper
INFO - 2020-02-26 17:25:19 --> Form Validation Class Initialized
INFO - 2020-02-26 17:25:19 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 17:25:19 --> Final output sent to browser
DEBUG - 2020-02-26 17:25:19 --> Total execution time: 0.7117
INFO - 2020-02-26 17:25:19 --> Config Class Initialized
INFO - 2020-02-26 17:25:19 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:19 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:19 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:19 --> URI Class Initialized
INFO - 2020-02-26 17:25:19 --> Router Class Initialized
INFO - 2020-02-26 17:25:19 --> Output Class Initialized
INFO - 2020-02-26 17:25:19 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:19 --> Input Class Initialized
INFO - 2020-02-26 17:25:19 --> Language Class Initialized
ERROR - 2020-02-26 17:25:19 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 17:25:26 --> Config Class Initialized
INFO - 2020-02-26 17:25:26 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:26 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:26 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:26 --> URI Class Initialized
INFO - 2020-02-26 17:25:27 --> Router Class Initialized
INFO - 2020-02-26 17:25:27 --> Output Class Initialized
INFO - 2020-02-26 17:25:27 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:27 --> Input Class Initialized
INFO - 2020-02-26 17:25:27 --> Language Class Initialized
INFO - 2020-02-26 17:25:27 --> Loader Class Initialized
INFO - 2020-02-26 17:25:27 --> Helper loaded: url_helper
INFO - 2020-02-26 17:25:27 --> Helper loaded: string_helper
INFO - 2020-02-26 17:25:27 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:25:27 --> Controller Class Initialized
INFO - 2020-02-26 17:25:27 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:25:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:25:27 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:25:27 --> Helper loaded: form_helper
INFO - 2020-02-26 17:25:27 --> Form Validation Class Initialized
INFO - 2020-02-26 17:25:27 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 17:25:27 --> Final output sent to browser
DEBUG - 2020-02-26 17:25:27 --> Total execution time: 0.7347
INFO - 2020-02-26 17:25:27 --> Config Class Initialized
INFO - 2020-02-26 17:25:27 --> Config Class Initialized
INFO - 2020-02-26 17:25:27 --> Config Class Initialized
INFO - 2020-02-26 17:25:27 --> Config Class Initialized
INFO - 2020-02-26 17:25:27 --> Config Class Initialized
INFO - 2020-02-26 17:25:27 --> Hooks Class Initialized
INFO - 2020-02-26 17:25:27 --> Hooks Class Initialized
INFO - 2020-02-26 17:25:27 --> Hooks Class Initialized
INFO - 2020-02-26 17:25:27 --> Hooks Class Initialized
INFO - 2020-02-26 17:25:27 --> Hooks Class Initialized
INFO - 2020-02-26 17:25:27 --> Config Class Initialized
INFO - 2020-02-26 17:25:27 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:25:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:25:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:25:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:25:27 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:27 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:27 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:27 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:27 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:27 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:25:27 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:27 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:27 --> URI Class Initialized
INFO - 2020-02-26 17:25:27 --> URI Class Initialized
INFO - 2020-02-26 17:25:27 --> URI Class Initialized
INFO - 2020-02-26 17:25:27 --> URI Class Initialized
INFO - 2020-02-26 17:25:27 --> URI Class Initialized
INFO - 2020-02-26 17:25:27 --> URI Class Initialized
INFO - 2020-02-26 17:25:27 --> Router Class Initialized
INFO - 2020-02-26 17:25:27 --> Router Class Initialized
INFO - 2020-02-26 17:25:27 --> Router Class Initialized
INFO - 2020-02-26 17:25:27 --> Router Class Initialized
INFO - 2020-02-26 17:25:27 --> Router Class Initialized
INFO - 2020-02-26 17:25:27 --> Output Class Initialized
INFO - 2020-02-26 17:25:27 --> Output Class Initialized
INFO - 2020-02-26 17:25:27 --> Output Class Initialized
INFO - 2020-02-26 17:25:27 --> Output Class Initialized
INFO - 2020-02-26 17:25:27 --> Output Class Initialized
INFO - 2020-02-26 17:25:27 --> Router Class Initialized
INFO - 2020-02-26 17:25:27 --> Security Class Initialized
INFO - 2020-02-26 17:25:27 --> Security Class Initialized
INFO - 2020-02-26 17:25:27 --> Security Class Initialized
INFO - 2020-02-26 17:25:27 --> Security Class Initialized
INFO - 2020-02-26 17:25:27 --> Security Class Initialized
INFO - 2020-02-26 17:25:27 --> Output Class Initialized
INFO - 2020-02-26 17:25:27 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
DEBUG - 2020-02-26 17:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
ERROR - 2020-02-26 17:25:28 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
ERROR - 2020-02-26 17:25:28 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 17:25:28 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 17:25:28 --> Loader Class Initialized
INFO - 2020-02-26 17:25:28 --> Loader Class Initialized
INFO - 2020-02-26 17:25:28 --> Helper loaded: url_helper
INFO - 2020-02-26 17:25:28 --> Helper loaded: url_helper
ERROR - 2020-02-26 17:25:28 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 17:25:28 --> Config Class Initialized
INFO - 2020-02-26 17:25:28 --> Config Class Initialized
INFO - 2020-02-26 17:25:28 --> Config Class Initialized
INFO - 2020-02-26 17:25:28 --> Hooks Class Initialized
INFO - 2020-02-26 17:25:28 --> Hooks Class Initialized
INFO - 2020-02-26 17:25:28 --> Hooks Class Initialized
INFO - 2020-02-26 17:25:28 --> Helper loaded: string_helper
INFO - 2020-02-26 17:25:28 --> Helper loaded: string_helper
INFO - 2020-02-26 17:25:28 --> Config Class Initialized
INFO - 2020-02-26 17:25:28 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:25:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:25:28 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:28 --> Database Driver Class Initialized
INFO - 2020-02-26 17:25:28 --> Database Driver Class Initialized
INFO - 2020-02-26 17:25:28 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:28 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:25:28 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:28 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:25:28 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:28 --> URI Class Initialized
INFO - 2020-02-26 17:25:28 --> URI Class Initialized
INFO - 2020-02-26 17:25:28 --> URI Class Initialized
DEBUG - 2020-02-26 17:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:25:28 --> Router Class Initialized
INFO - 2020-02-26 17:25:28 --> Router Class Initialized
INFO - 2020-02-26 17:25:28 --> Controller Class Initialized
INFO - 2020-02-26 17:25:28 --> URI Class Initialized
INFO - 2020-02-26 17:25:28 --> Router Class Initialized
INFO - 2020-02-26 17:25:28 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:25:28 --> Router Class Initialized
INFO - 2020-02-26 17:25:28 --> Output Class Initialized
INFO - 2020-02-26 17:25:28 --> Output Class Initialized
INFO - 2020-02-26 17:25:28 --> Output Class Initialized
INFO - 2020-02-26 17:25:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:25:28 --> Security Class Initialized
INFO - 2020-02-26 17:25:28 --> Security Class Initialized
INFO - 2020-02-26 17:25:28 --> Security Class Initialized
INFO - 2020-02-26 17:25:28 --> Output Class Initialized
INFO - 2020-02-26 17:25:28 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 17:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:28 --> Security Class Initialized
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
DEBUG - 2020-02-26 17:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:28 --> Helper loaded: form_helper
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
INFO - 2020-02-26 17:25:28 --> Form Validation Class Initialized
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
ERROR - 2020-02-26 17:25:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 17:25:28 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 17:25:28 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 17:25:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 17:25:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 17:25:28 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 17:25:28 --> Config Class Initialized
INFO - 2020-02-26 17:25:28 --> Config Class Initialized
INFO - 2020-02-26 17:25:28 --> Config Class Initialized
INFO - 2020-02-26 17:25:28 --> Hooks Class Initialized
INFO - 2020-02-26 17:25:28 --> Hooks Class Initialized
INFO - 2020-02-26 17:25:28 --> Hooks Class Initialized
INFO - 2020-02-26 17:25:28 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-26 17:25:28 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:28 --> Config Class Initialized
INFO - 2020-02-26 17:25:28 --> Hooks Class Initialized
INFO - 2020-02-26 17:25:28 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:28 --> Final output sent to browser
DEBUG - 2020-02-26 17:25:28 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:28 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:25:28 --> Total execution time: 0.9235
INFO - 2020-02-26 17:25:28 --> URI Class Initialized
DEBUG - 2020-02-26 17:25:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:25:28 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:28 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:28 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:25:28 --> URI Class Initialized
INFO - 2020-02-26 17:25:28 --> Router Class Initialized
INFO - 2020-02-26 17:25:28 --> Controller Class Initialized
INFO - 2020-02-26 17:25:28 --> URI Class Initialized
INFO - 2020-02-26 17:25:28 --> URI Class Initialized
INFO - 2020-02-26 17:25:28 --> Router Class Initialized
INFO - 2020-02-26 17:25:28 --> Output Class Initialized
INFO - 2020-02-26 17:25:28 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:25:28 --> Router Class Initialized
INFO - 2020-02-26 17:25:28 --> Router Class Initialized
INFO - 2020-02-26 17:25:28 --> Output Class Initialized
INFO - 2020-02-26 17:25:28 --> Security Class Initialized
INFO - 2020-02-26 17:25:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:25:28 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:28 --> Output Class Initialized
INFO - 2020-02-26 17:25:28 --> Output Class Initialized
INFO - 2020-02-26 17:25:28 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 17:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:28 --> Security Class Initialized
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
INFO - 2020-02-26 17:25:28 --> Security Class Initialized
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
DEBUG - 2020-02-26 17:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
DEBUG - 2020-02-26 17:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:28 --> Helper loaded: form_helper
INFO - 2020-02-26 17:25:28 --> Form Validation Class Initialized
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
INFO - 2020-02-26 17:25:28 --> Input Class Initialized
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
ERROR - 2020-02-26 17:25:28 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
INFO - 2020-02-26 17:25:28 --> Language Class Initialized
ERROR - 2020-02-26 17:25:28 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 17:25:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 17:25:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 17:25:28 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-26 17:25:28 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 17:25:28 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 17:25:28 --> Config Class Initialized
INFO - 2020-02-26 17:25:28 --> Hooks Class Initialized
INFO - 2020-02-26 17:25:28 --> Final output sent to browser
DEBUG - 2020-02-26 17:25:29 --> Total execution time: 1.2998
DEBUG - 2020-02-26 17:25:29 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:29 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:29 --> URI Class Initialized
INFO - 2020-02-26 17:25:29 --> Router Class Initialized
INFO - 2020-02-26 17:25:29 --> Output Class Initialized
INFO - 2020-02-26 17:25:29 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:29 --> Input Class Initialized
INFO - 2020-02-26 17:25:29 --> Language Class Initialized
ERROR - 2020-02-26 17:25:29 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 17:25:29 --> Config Class Initialized
INFO - 2020-02-26 17:25:29 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:29 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:29 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:29 --> URI Class Initialized
INFO - 2020-02-26 17:25:29 --> Router Class Initialized
INFO - 2020-02-26 17:25:29 --> Output Class Initialized
INFO - 2020-02-26 17:25:29 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:29 --> Input Class Initialized
INFO - 2020-02-26 17:25:29 --> Language Class Initialized
ERROR - 2020-02-26 17:25:29 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 17:25:29 --> Config Class Initialized
INFO - 2020-02-26 17:25:29 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:29 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:29 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:29 --> URI Class Initialized
INFO - 2020-02-26 17:25:29 --> Router Class Initialized
INFO - 2020-02-26 17:25:29 --> Output Class Initialized
INFO - 2020-02-26 17:25:29 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:29 --> Input Class Initialized
INFO - 2020-02-26 17:25:29 --> Language Class Initialized
ERROR - 2020-02-26 17:25:30 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 17:25:30 --> Config Class Initialized
INFO - 2020-02-26 17:25:30 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:30 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:30 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:30 --> URI Class Initialized
INFO - 2020-02-26 17:25:30 --> Router Class Initialized
INFO - 2020-02-26 17:25:30 --> Output Class Initialized
INFO - 2020-02-26 17:25:30 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:30 --> Input Class Initialized
INFO - 2020-02-26 17:25:30 --> Language Class Initialized
ERROR - 2020-02-26 17:25:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 17:25:30 --> Config Class Initialized
INFO - 2020-02-26 17:25:30 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:30 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:30 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:30 --> URI Class Initialized
INFO - 2020-02-26 17:25:30 --> Router Class Initialized
INFO - 2020-02-26 17:25:30 --> Output Class Initialized
INFO - 2020-02-26 17:25:30 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:30 --> Input Class Initialized
INFO - 2020-02-26 17:25:30 --> Language Class Initialized
ERROR - 2020-02-26 17:25:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 17:25:30 --> Config Class Initialized
INFO - 2020-02-26 17:25:30 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:30 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:30 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:30 --> URI Class Initialized
INFO - 2020-02-26 17:25:30 --> Router Class Initialized
INFO - 2020-02-26 17:25:30 --> Output Class Initialized
INFO - 2020-02-26 17:25:30 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:31 --> Input Class Initialized
INFO - 2020-02-26 17:25:31 --> Language Class Initialized
ERROR - 2020-02-26 17:25:31 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 17:25:31 --> Config Class Initialized
INFO - 2020-02-26 17:25:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:31 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:31 --> URI Class Initialized
INFO - 2020-02-26 17:25:31 --> Router Class Initialized
INFO - 2020-02-26 17:25:31 --> Output Class Initialized
INFO - 2020-02-26 17:25:31 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:31 --> Input Class Initialized
INFO - 2020-02-26 17:25:31 --> Language Class Initialized
ERROR - 2020-02-26 17:25:31 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 17:25:31 --> Config Class Initialized
INFO - 2020-02-26 17:25:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:31 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:31 --> URI Class Initialized
INFO - 2020-02-26 17:25:31 --> Router Class Initialized
INFO - 2020-02-26 17:25:31 --> Output Class Initialized
INFO - 2020-02-26 17:25:31 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:31 --> Input Class Initialized
INFO - 2020-02-26 17:25:31 --> Language Class Initialized
ERROR - 2020-02-26 17:25:31 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 17:25:31 --> Config Class Initialized
INFO - 2020-02-26 17:25:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:31 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:31 --> URI Class Initialized
INFO - 2020-02-26 17:25:32 --> Router Class Initialized
INFO - 2020-02-26 17:25:32 --> Output Class Initialized
INFO - 2020-02-26 17:25:32 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:32 --> Input Class Initialized
INFO - 2020-02-26 17:25:32 --> Language Class Initialized
ERROR - 2020-02-26 17:25:32 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 17:25:52 --> Config Class Initialized
INFO - 2020-02-26 17:25:52 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:25:52 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:25:52 --> Utf8 Class Initialized
INFO - 2020-02-26 17:25:52 --> URI Class Initialized
INFO - 2020-02-26 17:25:52 --> Router Class Initialized
INFO - 2020-02-26 17:25:52 --> Output Class Initialized
INFO - 2020-02-26 17:25:52 --> Security Class Initialized
DEBUG - 2020-02-26 17:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:25:52 --> Input Class Initialized
INFO - 2020-02-26 17:25:52 --> Language Class Initialized
INFO - 2020-02-26 17:25:52 --> Loader Class Initialized
INFO - 2020-02-26 17:25:52 --> Helper loaded: url_helper
INFO - 2020-02-26 17:25:52 --> Helper loaded: string_helper
INFO - 2020-02-26 17:25:52 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:25:52 --> Controller Class Initialized
INFO - 2020-02-26 17:25:53 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:25:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:25:53 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:25:53 --> Helper loaded: form_helper
INFO - 2020-02-26 17:25:53 --> Form Validation Class Initialized
ERROR - 2020-02-26 23:25:53 --> Query error: Unknown column 'total_bayar' in 'field list' - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `total_bayar`, `bukti_bayar`, `id_pengunjung`) VALUES ('33', '200000', '1', '2', '20-02-26 11:25:53', '2020-02-27 11:25:53', NULL, 'PM169', NULL, NULL, 'default.jpg', '183')
INFO - 2020-02-26 23:25:53 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-26 17:26:51 --> Config Class Initialized
INFO - 2020-02-26 17:26:52 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:26:52 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:26:52 --> Utf8 Class Initialized
INFO - 2020-02-26 17:26:52 --> URI Class Initialized
INFO - 2020-02-26 17:26:52 --> Router Class Initialized
INFO - 2020-02-26 17:26:52 --> Output Class Initialized
INFO - 2020-02-26 17:26:52 --> Security Class Initialized
DEBUG - 2020-02-26 17:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:26:52 --> Input Class Initialized
INFO - 2020-02-26 17:26:52 --> Language Class Initialized
INFO - 2020-02-26 17:26:52 --> Loader Class Initialized
INFO - 2020-02-26 17:26:52 --> Helper loaded: url_helper
INFO - 2020-02-26 17:26:52 --> Helper loaded: string_helper
INFO - 2020-02-26 17:26:52 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:26:52 --> Controller Class Initialized
INFO - 2020-02-26 17:26:52 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:26:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:26:52 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:26:52 --> Helper loaded: form_helper
INFO - 2020-02-26 17:26:52 --> Form Validation Class Initialized
INFO - 2020-02-26 23:26:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 23:26:52 --> Final output sent to browser
DEBUG - 2020-02-26 23:26:52 --> Total execution time: 0.8441
INFO - 2020-02-26 17:27:02 --> Config Class Initialized
INFO - 2020-02-26 17:27:02 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:27:02 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:27:02 --> Utf8 Class Initialized
INFO - 2020-02-26 17:27:02 --> URI Class Initialized
INFO - 2020-02-26 17:27:02 --> Router Class Initialized
INFO - 2020-02-26 17:27:02 --> Output Class Initialized
INFO - 2020-02-26 17:27:02 --> Security Class Initialized
DEBUG - 2020-02-26 17:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:27:02 --> Input Class Initialized
INFO - 2020-02-26 17:27:02 --> Language Class Initialized
INFO - 2020-02-26 17:27:02 --> Loader Class Initialized
INFO - 2020-02-26 17:27:02 --> Helper loaded: url_helper
INFO - 2020-02-26 17:27:02 --> Helper loaded: string_helper
INFO - 2020-02-26 17:27:02 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:27:03 --> Controller Class Initialized
INFO - 2020-02-26 17:27:03 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:27:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:27:03 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:27:03 --> Helper loaded: form_helper
INFO - 2020-02-26 17:27:03 --> Form Validation Class Initialized
ERROR - 2020-02-26 17:27:03 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 17:27:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 17:27:03 --> Final output sent to browser
DEBUG - 2020-02-26 17:27:03 --> Total execution time: 0.7279
INFO - 2020-02-26 17:27:49 --> Config Class Initialized
INFO - 2020-02-26 17:27:49 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:27:49 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:27:49 --> Utf8 Class Initialized
INFO - 2020-02-26 17:27:50 --> URI Class Initialized
INFO - 2020-02-26 17:27:50 --> Router Class Initialized
INFO - 2020-02-26 17:27:50 --> Output Class Initialized
INFO - 2020-02-26 17:27:50 --> Security Class Initialized
DEBUG - 2020-02-26 17:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:27:50 --> Input Class Initialized
INFO - 2020-02-26 17:27:50 --> Language Class Initialized
INFO - 2020-02-26 17:27:50 --> Loader Class Initialized
INFO - 2020-02-26 17:27:50 --> Helper loaded: url_helper
INFO - 2020-02-26 17:27:50 --> Helper loaded: string_helper
INFO - 2020-02-26 17:27:50 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:27:50 --> Controller Class Initialized
INFO - 2020-02-26 17:27:50 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:27:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:27:50 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:27:50 --> Helper loaded: form_helper
INFO - 2020-02-26 17:27:51 --> Form Validation Class Initialized
INFO - 2020-02-26 17:27:51 --> Config Class Initialized
INFO - 2020-02-26 17:27:51 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:27:51 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:27:51 --> Utf8 Class Initialized
INFO - 2020-02-26 17:27:51 --> URI Class Initialized
INFO - 2020-02-26 17:27:51 --> Router Class Initialized
INFO - 2020-02-26 17:27:51 --> Output Class Initialized
INFO - 2020-02-26 17:27:51 --> Security Class Initialized
DEBUG - 2020-02-26 17:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:27:51 --> Input Class Initialized
INFO - 2020-02-26 17:27:51 --> Language Class Initialized
ERROR - 2020-02-26 17:27:51 --> 404 Page Not Found: Show/show_list
INFO - 2020-02-26 17:30:01 --> Config Class Initialized
INFO - 2020-02-26 17:30:01 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:30:01 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:30:01 --> Utf8 Class Initialized
INFO - 2020-02-26 17:30:01 --> URI Class Initialized
DEBUG - 2020-02-26 17:30:01 --> No URI present. Default controller set.
INFO - 2020-02-26 17:30:01 --> Router Class Initialized
INFO - 2020-02-26 17:30:01 --> Output Class Initialized
INFO - 2020-02-26 17:30:01 --> Security Class Initialized
DEBUG - 2020-02-26 17:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:30:01 --> Input Class Initialized
INFO - 2020-02-26 17:30:01 --> Language Class Initialized
INFO - 2020-02-26 17:30:01 --> Loader Class Initialized
INFO - 2020-02-26 17:30:01 --> Helper loaded: url_helper
INFO - 2020-02-26 17:30:02 --> Helper loaded: string_helper
INFO - 2020-02-26 17:30:02 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:30:02 --> Controller Class Initialized
INFO - 2020-02-26 17:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 17:30:02 --> Pagination Class Initialized
INFO - 2020-02-26 17:30:02 --> Model "M_show" initialized
INFO - 2020-02-26 17:30:02 --> Helper loaded: form_helper
INFO - 2020-02-26 17:30:02 --> Form Validation Class Initialized
INFO - 2020-02-26 17:30:02 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 17:30:02 --> Final output sent to browser
INFO - 2020-02-26 17:30:02 --> Config Class Initialized
INFO - 2020-02-26 17:30:02 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:30:02 --> Total execution time: 1.3012
DEBUG - 2020-02-26 17:30:02 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:30:02 --> Utf8 Class Initialized
INFO - 2020-02-26 17:30:02 --> URI Class Initialized
DEBUG - 2020-02-26 17:30:02 --> No URI present. Default controller set.
INFO - 2020-02-26 17:30:02 --> Router Class Initialized
INFO - 2020-02-26 17:30:02 --> Output Class Initialized
INFO - 2020-02-26 17:30:02 --> Security Class Initialized
DEBUG - 2020-02-26 17:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:30:02 --> Input Class Initialized
INFO - 2020-02-26 17:30:02 --> Language Class Initialized
INFO - 2020-02-26 17:30:03 --> Loader Class Initialized
INFO - 2020-02-26 17:30:03 --> Helper loaded: url_helper
INFO - 2020-02-26 17:30:03 --> Helper loaded: string_helper
INFO - 2020-02-26 17:30:03 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:30:03 --> Controller Class Initialized
INFO - 2020-02-26 17:30:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 17:30:03 --> Pagination Class Initialized
INFO - 2020-02-26 17:30:03 --> Model "M_show" initialized
INFO - 2020-02-26 17:30:03 --> Helper loaded: form_helper
INFO - 2020-02-26 17:30:03 --> Form Validation Class Initialized
INFO - 2020-02-26 17:30:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 17:30:03 --> Final output sent to browser
DEBUG - 2020-02-26 17:30:03 --> Total execution time: 1.0703
INFO - 2020-02-26 17:30:56 --> Config Class Initialized
INFO - 2020-02-26 17:30:56 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:30:56 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:30:56 --> Utf8 Class Initialized
INFO - 2020-02-26 17:30:56 --> URI Class Initialized
DEBUG - 2020-02-26 17:30:56 --> No URI present. Default controller set.
INFO - 2020-02-26 17:30:56 --> Router Class Initialized
INFO - 2020-02-26 17:30:56 --> Output Class Initialized
INFO - 2020-02-26 17:30:56 --> Security Class Initialized
DEBUG - 2020-02-26 17:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:30:56 --> Input Class Initialized
INFO - 2020-02-26 17:30:56 --> Language Class Initialized
INFO - 2020-02-26 17:30:57 --> Loader Class Initialized
INFO - 2020-02-26 17:30:57 --> Helper loaded: url_helper
INFO - 2020-02-26 17:30:57 --> Helper loaded: string_helper
INFO - 2020-02-26 17:30:57 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:30:57 --> Controller Class Initialized
INFO - 2020-02-26 17:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 17:30:57 --> Pagination Class Initialized
INFO - 2020-02-26 17:30:57 --> Model "M_show" initialized
INFO - 2020-02-26 17:30:57 --> Helper loaded: form_helper
INFO - 2020-02-26 17:30:57 --> Form Validation Class Initialized
INFO - 2020-02-26 17:30:57 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 17:30:57 --> Final output sent to browser
DEBUG - 2020-02-26 17:30:57 --> Total execution time: 0.8218
INFO - 2020-02-26 17:31:02 --> Config Class Initialized
INFO - 2020-02-26 17:31:02 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:02 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:02 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:03 --> URI Class Initialized
INFO - 2020-02-26 17:31:03 --> Router Class Initialized
INFO - 2020-02-26 17:31:03 --> Output Class Initialized
INFO - 2020-02-26 17:31:03 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:03 --> Input Class Initialized
INFO - 2020-02-26 17:31:03 --> Language Class Initialized
INFO - 2020-02-26 17:31:03 --> Loader Class Initialized
INFO - 2020-02-26 17:31:03 --> Helper loaded: url_helper
INFO - 2020-02-26 17:31:03 --> Helper loaded: string_helper
INFO - 2020-02-26 17:31:03 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:31:03 --> Controller Class Initialized
INFO - 2020-02-26 17:31:03 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:31:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:31:03 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:31:03 --> Helper loaded: form_helper
INFO - 2020-02-26 17:31:03 --> Form Validation Class Initialized
INFO - 2020-02-26 17:31:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 17:31:03 --> Final output sent to browser
INFO - 2020-02-26 17:31:03 --> Config Class Initialized
INFO - 2020-02-26 17:31:03 --> Config Class Initialized
INFO - 2020-02-26 17:31:03 --> Config Class Initialized
INFO - 2020-02-26 17:31:03 --> Config Class Initialized
INFO - 2020-02-26 17:31:03 --> Hooks Class Initialized
INFO - 2020-02-26 17:31:03 --> Hooks Class Initialized
INFO - 2020-02-26 17:31:03 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:03 --> Total execution time: 0.8079
INFO - 2020-02-26 17:31:03 --> Hooks Class Initialized
INFO - 2020-02-26 17:31:03 --> Config Class Initialized
INFO - 2020-02-26 17:31:03 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:31:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:31:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:31:03 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:03 --> Config Class Initialized
INFO - 2020-02-26 17:31:03 --> Hooks Class Initialized
INFO - 2020-02-26 17:31:03 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:31:03 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:03 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:03 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:03 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:03 --> URI Class Initialized
INFO - 2020-02-26 17:31:03 --> URI Class Initialized
INFO - 2020-02-26 17:31:03 --> URI Class Initialized
INFO - 2020-02-26 17:31:03 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:03 --> URI Class Initialized
DEBUG - 2020-02-26 17:31:03 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:03 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:03 --> Router Class Initialized
INFO - 2020-02-26 17:31:03 --> Router Class Initialized
INFO - 2020-02-26 17:31:03 --> Router Class Initialized
INFO - 2020-02-26 17:31:03 --> URI Class Initialized
INFO - 2020-02-26 17:31:03 --> Router Class Initialized
INFO - 2020-02-26 17:31:04 --> URI Class Initialized
INFO - 2020-02-26 17:31:04 --> Output Class Initialized
INFO - 2020-02-26 17:31:04 --> Output Class Initialized
INFO - 2020-02-26 17:31:04 --> Output Class Initialized
INFO - 2020-02-26 17:31:04 --> Router Class Initialized
INFO - 2020-02-26 17:31:04 --> Output Class Initialized
INFO - 2020-02-26 17:31:04 --> Security Class Initialized
INFO - 2020-02-26 17:31:04 --> Router Class Initialized
INFO - 2020-02-26 17:31:04 --> Output Class Initialized
INFO - 2020-02-26 17:31:04 --> Security Class Initialized
INFO - 2020-02-26 17:31:04 --> Security Class Initialized
INFO - 2020-02-26 17:31:04 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:04 --> Security Class Initialized
INFO - 2020-02-26 17:31:04 --> Output Class Initialized
DEBUG - 2020-02-26 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:04 --> Input Class Initialized
INFO - 2020-02-26 17:31:04 --> Input Class Initialized
INFO - 2020-02-26 17:31:04 --> Input Class Initialized
INFO - 2020-02-26 17:31:04 --> Input Class Initialized
INFO - 2020-02-26 17:31:04 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:04 --> Input Class Initialized
INFO - 2020-02-26 17:31:04 --> Language Class Initialized
DEBUG - 2020-02-26 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:04 --> Language Class Initialized
INFO - 2020-02-26 17:31:04 --> Language Class Initialized
INFO - 2020-02-26 17:31:04 --> Language Class Initialized
INFO - 2020-02-26 17:31:04 --> Input Class Initialized
ERROR - 2020-02-26 17:31:04 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 17:31:04 --> Language Class Initialized
INFO - 2020-02-26 17:31:04 --> Loader Class Initialized
ERROR - 2020-02-26 17:31:04 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 17:31:04 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 17:31:04 --> Language Class Initialized
ERROR - 2020-02-26 17:31:04 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 17:31:04 --> Helper loaded: url_helper
INFO - 2020-02-26 17:31:04 --> Config Class Initialized
INFO - 2020-02-26 17:31:04 --> Config Class Initialized
INFO - 2020-02-26 17:31:04 --> Config Class Initialized
INFO - 2020-02-26 17:31:04 --> Hooks Class Initialized
INFO - 2020-02-26 17:31:04 --> Hooks Class Initialized
INFO - 2020-02-26 17:31:04 --> Hooks Class Initialized
INFO - 2020-02-26 17:31:04 --> Helper loaded: string_helper
ERROR - 2020-02-26 17:31:04 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 17:31:04 --> Config Class Initialized
INFO - 2020-02-26 17:31:04 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:31:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:31:04 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:04 --> Database Driver Class Initialized
INFO - 2020-02-26 17:31:04 --> Config Class Initialized
INFO - 2020-02-26 17:31:04 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:04 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:04 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:04 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:31:04 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:04 --> URI Class Initialized
INFO - 2020-02-26 17:31:04 --> URI Class Initialized
INFO - 2020-02-26 17:31:04 --> URI Class Initialized
INFO - 2020-02-26 17:31:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-26 17:31:04 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:04 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:04 --> Controller Class Initialized
INFO - 2020-02-26 17:31:04 --> URI Class Initialized
INFO - 2020-02-26 17:31:04 --> Router Class Initialized
INFO - 2020-02-26 17:31:04 --> Router Class Initialized
INFO - 2020-02-26 17:31:04 --> Router Class Initialized
INFO - 2020-02-26 17:31:04 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:31:04 --> Output Class Initialized
INFO - 2020-02-26 17:31:04 --> Output Class Initialized
INFO - 2020-02-26 17:31:04 --> Router Class Initialized
INFO - 2020-02-26 17:31:04 --> Output Class Initialized
INFO - 2020-02-26 17:31:04 --> URI Class Initialized
INFO - 2020-02-26 17:31:04 --> Security Class Initialized
INFO - 2020-02-26 17:31:04 --> Router Class Initialized
INFO - 2020-02-26 17:31:04 --> Security Class Initialized
INFO - 2020-02-26 17:31:04 --> Security Class Initialized
INFO - 2020-02-26 17:31:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:31:04 --> Output Class Initialized
DEBUG - 2020-02-26 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:04 --> Input Class Initialized
INFO - 2020-02-26 17:31:04 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:31:04 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:04 --> Output Class Initialized
DEBUG - 2020-02-26 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:04 --> Input Class Initialized
INFO - 2020-02-26 17:31:04 --> Security Class Initialized
INFO - 2020-02-26 17:31:04 --> Language Class Initialized
DEBUG - 2020-02-26 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:04 --> Input Class Initialized
INFO - 2020-02-26 17:31:04 --> Helper loaded: form_helper
INFO - 2020-02-26 17:31:04 --> Form Validation Class Initialized
INFO - 2020-02-26 17:31:04 --> Input Class Initialized
INFO - 2020-02-26 17:31:04 --> Language Class Initialized
DEBUG - 2020-02-26 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:04 --> Language Class Initialized
ERROR - 2020-02-26 17:31:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 17:31:04 --> Input Class Initialized
INFO - 2020-02-26 17:31:04 --> Language Class Initialized
INFO - 2020-02-26 17:31:04 --> Loader Class Initialized
ERROR - 2020-02-26 17:31:04 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 17:31:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 17:31:04 --> Config Class Initialized
INFO - 2020-02-26 17:31:04 --> Hooks Class Initialized
ERROR - 2020-02-26 17:31:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 17:31:04 --> Helper loaded: url_helper
INFO - 2020-02-26 17:31:04 --> Language Class Initialized
ERROR - 2020-02-26 17:31:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 17:31:04 --> Config Class Initialized
INFO - 2020-02-26 17:31:04 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-26 17:31:04 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 17:31:04 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:04 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:04 --> Helper loaded: string_helper
INFO - 2020-02-26 17:31:05 --> Config Class Initialized
INFO - 2020-02-26 17:31:05 --> Hooks Class Initialized
INFO - 2020-02-26 17:31:05 --> Final output sent to browser
INFO - 2020-02-26 17:31:05 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:31:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:05 --> Database Driver Class Initialized
INFO - 2020-02-26 17:31:05 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:31:05 --> Total execution time: 1.2714
INFO - 2020-02-26 17:31:05 --> URI Class Initialized
DEBUG - 2020-02-26 17:31:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:31:05 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:05 --> URI Class Initialized
INFO - 2020-02-26 17:31:05 --> Router Class Initialized
INFO - 2020-02-26 17:31:05 --> Controller Class Initialized
INFO - 2020-02-26 17:31:05 --> Router Class Initialized
INFO - 2020-02-26 17:31:05 --> URI Class Initialized
INFO - 2020-02-26 17:31:05 --> Output Class Initialized
INFO - 2020-02-26 17:31:05 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:31:05 --> Security Class Initialized
INFO - 2020-02-26 17:31:05 --> Output Class Initialized
INFO - 2020-02-26 17:31:05 --> Router Class Initialized
INFO - 2020-02-26 17:31:05 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-26 17:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:05 --> Security Class Initialized
INFO - 2020-02-26 17:31:05 --> Output Class Initialized
INFO - 2020-02-26 17:31:05 --> Input Class Initialized
INFO - 2020-02-26 17:31:05 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:31:05 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:05 --> Input Class Initialized
INFO - 2020-02-26 17:31:05 --> Language Class Initialized
DEBUG - 2020-02-26 17:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:05 --> Helper loaded: form_helper
INFO - 2020-02-26 17:31:05 --> Input Class Initialized
INFO - 2020-02-26 17:31:05 --> Form Validation Class Initialized
INFO - 2020-02-26 17:31:05 --> Language Class Initialized
ERROR - 2020-02-26 17:31:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 17:31:05 --> Language Class Initialized
ERROR - 2020-02-26 17:31:05 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 17:31:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 17:31:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 17:31:05 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 17:31:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 17:31:05 --> Config Class Initialized
INFO - 2020-02-26 17:31:05 --> Hooks Class Initialized
INFO - 2020-02-26 17:31:05 --> Final output sent to browser
DEBUG - 2020-02-26 17:31:05 --> Total execution time: 1.2421
DEBUG - 2020-02-26 17:31:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:05 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:05 --> URI Class Initialized
INFO - 2020-02-26 17:31:05 --> Router Class Initialized
INFO - 2020-02-26 17:31:05 --> Output Class Initialized
INFO - 2020-02-26 17:31:05 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:05 --> Input Class Initialized
INFO - 2020-02-26 17:31:05 --> Language Class Initialized
ERROR - 2020-02-26 17:31:05 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 17:31:05 --> Config Class Initialized
INFO - 2020-02-26 17:31:05 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:05 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:05 --> URI Class Initialized
INFO - 2020-02-26 17:31:06 --> Router Class Initialized
INFO - 2020-02-26 17:31:06 --> Output Class Initialized
INFO - 2020-02-26 17:31:06 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:06 --> Input Class Initialized
INFO - 2020-02-26 17:31:06 --> Language Class Initialized
ERROR - 2020-02-26 17:31:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 17:31:06 --> Config Class Initialized
INFO - 2020-02-26 17:31:06 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:06 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:06 --> URI Class Initialized
INFO - 2020-02-26 17:31:06 --> Router Class Initialized
INFO - 2020-02-26 17:31:06 --> Output Class Initialized
INFO - 2020-02-26 17:31:06 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:06 --> Input Class Initialized
INFO - 2020-02-26 17:31:06 --> Language Class Initialized
ERROR - 2020-02-26 17:31:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 17:31:06 --> Config Class Initialized
INFO - 2020-02-26 17:31:06 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:06 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:06 --> URI Class Initialized
INFO - 2020-02-26 17:31:06 --> Router Class Initialized
INFO - 2020-02-26 17:31:06 --> Output Class Initialized
INFO - 2020-02-26 17:31:06 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:07 --> Input Class Initialized
INFO - 2020-02-26 17:31:07 --> Language Class Initialized
ERROR - 2020-02-26 17:31:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 17:31:07 --> Config Class Initialized
INFO - 2020-02-26 17:31:07 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:07 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:07 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:07 --> URI Class Initialized
INFO - 2020-02-26 17:31:07 --> Router Class Initialized
INFO - 2020-02-26 17:31:07 --> Output Class Initialized
INFO - 2020-02-26 17:31:07 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:07 --> Input Class Initialized
INFO - 2020-02-26 17:31:07 --> Language Class Initialized
ERROR - 2020-02-26 17:31:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 17:31:07 --> Config Class Initialized
INFO - 2020-02-26 17:31:07 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:07 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:07 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:07 --> URI Class Initialized
INFO - 2020-02-26 17:31:07 --> Router Class Initialized
INFO - 2020-02-26 17:31:07 --> Output Class Initialized
INFO - 2020-02-26 17:31:07 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:07 --> Input Class Initialized
INFO - 2020-02-26 17:31:07 --> Language Class Initialized
ERROR - 2020-02-26 17:31:08 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 17:31:08 --> Config Class Initialized
INFO - 2020-02-26 17:31:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:08 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:08 --> URI Class Initialized
INFO - 2020-02-26 17:31:08 --> Router Class Initialized
INFO - 2020-02-26 17:31:08 --> Output Class Initialized
INFO - 2020-02-26 17:31:08 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:08 --> Input Class Initialized
INFO - 2020-02-26 17:31:08 --> Language Class Initialized
ERROR - 2020-02-26 17:31:08 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 17:31:08 --> Config Class Initialized
INFO - 2020-02-26 17:31:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:08 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:08 --> URI Class Initialized
INFO - 2020-02-26 17:31:08 --> Router Class Initialized
INFO - 2020-02-26 17:31:08 --> Output Class Initialized
INFO - 2020-02-26 17:31:08 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:08 --> Input Class Initialized
INFO - 2020-02-26 17:31:08 --> Language Class Initialized
ERROR - 2020-02-26 17:31:08 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 17:31:08 --> Config Class Initialized
INFO - 2020-02-26 17:31:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:09 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:09 --> URI Class Initialized
INFO - 2020-02-26 17:31:09 --> Router Class Initialized
INFO - 2020-02-26 17:31:09 --> Output Class Initialized
INFO - 2020-02-26 17:31:09 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:09 --> Input Class Initialized
INFO - 2020-02-26 17:31:09 --> Language Class Initialized
ERROR - 2020-02-26 17:31:09 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 17:31:36 --> Config Class Initialized
INFO - 2020-02-26 17:31:36 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:36 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:36 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:36 --> URI Class Initialized
INFO - 2020-02-26 17:31:36 --> Router Class Initialized
INFO - 2020-02-26 17:31:37 --> Output Class Initialized
INFO - 2020-02-26 17:31:37 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:37 --> Input Class Initialized
INFO - 2020-02-26 17:31:37 --> Language Class Initialized
INFO - 2020-02-26 17:31:37 --> Loader Class Initialized
INFO - 2020-02-26 17:31:37 --> Helper loaded: url_helper
INFO - 2020-02-26 17:31:37 --> Helper loaded: string_helper
INFO - 2020-02-26 17:31:37 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:31:37 --> Controller Class Initialized
INFO - 2020-02-26 17:31:37 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:31:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:31:37 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:31:37 --> Helper loaded: form_helper
INFO - 2020-02-26 17:31:37 --> Form Validation Class Initialized
INFO - 2020-02-26 23:31:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 23:31:37 --> Final output sent to browser
DEBUG - 2020-02-26 23:31:37 --> Total execution time: 1.0164
INFO - 2020-02-26 17:31:41 --> Config Class Initialized
INFO - 2020-02-26 17:31:41 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:31:41 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:31:41 --> Utf8 Class Initialized
INFO - 2020-02-26 17:31:41 --> URI Class Initialized
INFO - 2020-02-26 17:31:42 --> Router Class Initialized
INFO - 2020-02-26 17:31:42 --> Output Class Initialized
INFO - 2020-02-26 17:31:42 --> Security Class Initialized
DEBUG - 2020-02-26 17:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:31:42 --> Input Class Initialized
INFO - 2020-02-26 17:31:42 --> Language Class Initialized
INFO - 2020-02-26 17:31:42 --> Loader Class Initialized
INFO - 2020-02-26 17:31:42 --> Helper loaded: url_helper
INFO - 2020-02-26 17:31:42 --> Helper loaded: string_helper
INFO - 2020-02-26 17:31:42 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:31:42 --> Controller Class Initialized
INFO - 2020-02-26 17:31:42 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:31:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:31:42 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:31:42 --> Helper loaded: form_helper
INFO - 2020-02-26 17:31:42 --> Form Validation Class Initialized
ERROR - 2020-02-26 17:31:42 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 17:31:42 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 17:31:42 --> Final output sent to browser
DEBUG - 2020-02-26 17:31:42 --> Total execution time: 0.9094
INFO - 2020-02-26 17:32:00 --> Config Class Initialized
INFO - 2020-02-26 17:32:00 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:32:00 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:32:00 --> Utf8 Class Initialized
INFO - 2020-02-26 17:32:00 --> URI Class Initialized
INFO - 2020-02-26 17:32:00 --> Router Class Initialized
INFO - 2020-02-26 17:32:00 --> Output Class Initialized
INFO - 2020-02-26 17:32:00 --> Security Class Initialized
DEBUG - 2020-02-26 17:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:32:00 --> Input Class Initialized
INFO - 2020-02-26 17:32:00 --> Language Class Initialized
INFO - 2020-02-26 17:32:00 --> Loader Class Initialized
INFO - 2020-02-26 17:32:00 --> Helper loaded: url_helper
INFO - 2020-02-26 17:32:00 --> Helper loaded: string_helper
INFO - 2020-02-26 17:32:00 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:32:00 --> Controller Class Initialized
INFO - 2020-02-26 17:32:00 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:32:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:32:00 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:32:00 --> Helper loaded: form_helper
INFO - 2020-02-26 17:32:01 --> Form Validation Class Initialized
INFO - 2020-02-26 17:32:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-26 17:32:01 --> Config Class Initialized
INFO - 2020-02-26 17:32:01 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:32:01 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:32:01 --> Utf8 Class Initialized
INFO - 2020-02-26 17:32:01 --> URI Class Initialized
INFO - 2020-02-26 17:32:01 --> Router Class Initialized
INFO - 2020-02-26 17:32:01 --> Output Class Initialized
INFO - 2020-02-26 17:32:01 --> Security Class Initialized
DEBUG - 2020-02-26 17:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:32:01 --> Input Class Initialized
INFO - 2020-02-26 17:32:01 --> Language Class Initialized
ERROR - 2020-02-26 17:32:01 --> 404 Page Not Found: Indexphp/show
INFO - 2020-02-26 17:41:01 --> Config Class Initialized
INFO - 2020-02-26 17:41:01 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:41:01 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:02 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:02 --> URI Class Initialized
DEBUG - 2020-02-26 17:41:02 --> No URI present. Default controller set.
INFO - 2020-02-26 17:41:02 --> Router Class Initialized
INFO - 2020-02-26 17:41:02 --> Output Class Initialized
INFO - 2020-02-26 17:41:02 --> Security Class Initialized
DEBUG - 2020-02-26 17:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:02 --> Input Class Initialized
INFO - 2020-02-26 17:41:02 --> Language Class Initialized
INFO - 2020-02-26 17:41:02 --> Loader Class Initialized
INFO - 2020-02-26 17:41:02 --> Helper loaded: url_helper
INFO - 2020-02-26 17:41:02 --> Helper loaded: string_helper
INFO - 2020-02-26 17:41:02 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:41:02 --> Controller Class Initialized
INFO - 2020-02-26 17:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 17:41:02 --> Pagination Class Initialized
INFO - 2020-02-26 17:41:02 --> Model "M_show" initialized
INFO - 2020-02-26 17:41:02 --> Helper loaded: form_helper
INFO - 2020-02-26 17:41:02 --> Form Validation Class Initialized
INFO - 2020-02-26 17:41:02 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 17:41:02 --> Final output sent to browser
INFO - 2020-02-26 17:41:02 --> Config Class Initialized
INFO - 2020-02-26 17:41:02 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:41:02 --> Total execution time: 1.0405
DEBUG - 2020-02-26 17:41:02 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:02 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:03 --> URI Class Initialized
DEBUG - 2020-02-26 17:41:03 --> No URI present. Default controller set.
INFO - 2020-02-26 17:41:03 --> Router Class Initialized
INFO - 2020-02-26 17:41:03 --> Output Class Initialized
INFO - 2020-02-26 17:41:03 --> Security Class Initialized
DEBUG - 2020-02-26 17:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:03 --> Input Class Initialized
INFO - 2020-02-26 17:41:03 --> Language Class Initialized
INFO - 2020-02-26 17:41:03 --> Loader Class Initialized
INFO - 2020-02-26 17:41:03 --> Helper loaded: url_helper
INFO - 2020-02-26 17:41:03 --> Helper loaded: string_helper
INFO - 2020-02-26 17:41:03 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:41:03 --> Controller Class Initialized
INFO - 2020-02-26 17:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 17:41:03 --> Pagination Class Initialized
INFO - 2020-02-26 17:41:03 --> Model "M_show" initialized
INFO - 2020-02-26 17:41:03 --> Helper loaded: form_helper
INFO - 2020-02-26 17:41:03 --> Form Validation Class Initialized
INFO - 2020-02-26 17:41:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 17:41:03 --> Final output sent to browser
DEBUG - 2020-02-26 17:41:03 --> Total execution time: 0.9673
INFO - 2020-02-26 17:41:07 --> Config Class Initialized
INFO - 2020-02-26 17:41:07 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:41:07 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:07 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:07 --> URI Class Initialized
INFO - 2020-02-26 17:41:07 --> Router Class Initialized
INFO - 2020-02-26 17:41:07 --> Output Class Initialized
INFO - 2020-02-26 17:41:07 --> Security Class Initialized
DEBUG - 2020-02-26 17:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:07 --> Input Class Initialized
INFO - 2020-02-26 17:41:07 --> Language Class Initialized
INFO - 2020-02-26 17:41:07 --> Loader Class Initialized
INFO - 2020-02-26 17:41:07 --> Helper loaded: url_helper
INFO - 2020-02-26 17:41:07 --> Helper loaded: string_helper
INFO - 2020-02-26 17:41:07 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:41:07 --> Controller Class Initialized
INFO - 2020-02-26 17:41:07 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:41:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:41:07 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:41:07 --> Helper loaded: form_helper
INFO - 2020-02-26 17:41:07 --> Form Validation Class Initialized
INFO - 2020-02-26 17:41:07 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 17:41:07 --> Final output sent to browser
INFO - 2020-02-26 17:41:07 --> Config Class Initialized
INFO - 2020-02-26 17:41:07 --> Config Class Initialized
INFO - 2020-02-26 17:41:07 --> Config Class Initialized
INFO - 2020-02-26 17:41:07 --> Config Class Initialized
INFO - 2020-02-26 17:41:07 --> Config Class Initialized
INFO - 2020-02-26 17:41:07 --> Hooks Class Initialized
INFO - 2020-02-26 17:41:07 --> Hooks Class Initialized
INFO - 2020-02-26 17:41:07 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:41:07 --> Total execution time: 0.8448
INFO - 2020-02-26 17:41:07 --> Hooks Class Initialized
INFO - 2020-02-26 17:41:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:41:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:41:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:41:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:41:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:08 --> Config Class Initialized
DEBUG - 2020-02-26 17:41:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:08 --> Hooks Class Initialized
INFO - 2020-02-26 17:41:08 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:08 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:08 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:08 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:08 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:08 --> URI Class Initialized
INFO - 2020-02-26 17:41:08 --> URI Class Initialized
INFO - 2020-02-26 17:41:08 --> URI Class Initialized
INFO - 2020-02-26 17:41:08 --> URI Class Initialized
INFO - 2020-02-26 17:41:08 --> URI Class Initialized
DEBUG - 2020-02-26 17:41:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:08 --> Router Class Initialized
INFO - 2020-02-26 17:41:08 --> Router Class Initialized
INFO - 2020-02-26 17:41:08 --> Router Class Initialized
INFO - 2020-02-26 17:41:08 --> Router Class Initialized
INFO - 2020-02-26 17:41:08 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:08 --> Router Class Initialized
INFO - 2020-02-26 17:41:08 --> URI Class Initialized
INFO - 2020-02-26 17:41:08 --> Output Class Initialized
INFO - 2020-02-26 17:41:08 --> Output Class Initialized
INFO - 2020-02-26 17:41:08 --> Output Class Initialized
INFO - 2020-02-26 17:41:08 --> Output Class Initialized
INFO - 2020-02-26 17:41:08 --> Output Class Initialized
INFO - 2020-02-26 17:41:08 --> Security Class Initialized
INFO - 2020-02-26 17:41:08 --> Security Class Initialized
INFO - 2020-02-26 17:41:08 --> Security Class Initialized
INFO - 2020-02-26 17:41:08 --> Security Class Initialized
INFO - 2020-02-26 17:41:08 --> Security Class Initialized
INFO - 2020-02-26 17:41:08 --> Router Class Initialized
DEBUG - 2020-02-26 17:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:08 --> Output Class Initialized
DEBUG - 2020-02-26 17:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:08 --> Input Class Initialized
INFO - 2020-02-26 17:41:08 --> Input Class Initialized
INFO - 2020-02-26 17:41:08 --> Input Class Initialized
INFO - 2020-02-26 17:41:08 --> Input Class Initialized
INFO - 2020-02-26 17:41:08 --> Input Class Initialized
INFO - 2020-02-26 17:41:08 --> Security Class Initialized
INFO - 2020-02-26 17:41:08 --> Language Class Initialized
INFO - 2020-02-26 17:41:08 --> Language Class Initialized
DEBUG - 2020-02-26 17:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:08 --> Language Class Initialized
INFO - 2020-02-26 17:41:08 --> Language Class Initialized
INFO - 2020-02-26 17:41:08 --> Language Class Initialized
ERROR - 2020-02-26 17:41:08 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 17:41:08 --> Input Class Initialized
ERROR - 2020-02-26 17:41:08 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-26 17:41:08 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-26 17:41:08 --> Loader Class Initialized
ERROR - 2020-02-26 17:41:08 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 17:41:08 --> Language Class Initialized
INFO - 2020-02-26 17:41:08 --> Helper loaded: url_helper
INFO - 2020-02-26 17:41:08 --> Config Class Initialized
INFO - 2020-02-26 17:41:08 --> Config Class Initialized
INFO - 2020-02-26 17:41:08 --> Config Class Initialized
INFO - 2020-02-26 17:41:08 --> Config Class Initialized
INFO - 2020-02-26 17:41:08 --> Hooks Class Initialized
INFO - 2020-02-26 17:41:08 --> Hooks Class Initialized
INFO - 2020-02-26 17:41:08 --> Hooks Class Initialized
INFO - 2020-02-26 17:41:08 --> Hooks Class Initialized
INFO - 2020-02-26 17:41:08 --> Helper loaded: string_helper
INFO - 2020-02-26 17:41:08 --> Loader Class Initialized
DEBUG - 2020-02-26 17:41:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:08 --> Helper loaded: url_helper
DEBUG - 2020-02-26 17:41:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:41:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:08 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:41:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:08 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:08 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:08 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:08 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:08 --> Helper loaded: string_helper
DEBUG - 2020-02-26 17:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:41:08 --> URI Class Initialized
INFO - 2020-02-26 17:41:08 --> URI Class Initialized
INFO - 2020-02-26 17:41:08 --> URI Class Initialized
INFO - 2020-02-26 17:41:08 --> URI Class Initialized
INFO - 2020-02-26 17:41:08 --> Database Driver Class Initialized
INFO - 2020-02-26 17:41:08 --> Controller Class Initialized
INFO - 2020-02-26 17:41:08 --> Router Class Initialized
INFO - 2020-02-26 17:41:08 --> Router Class Initialized
INFO - 2020-02-26 17:41:08 --> Router Class Initialized
INFO - 2020-02-26 17:41:08 --> Router Class Initialized
DEBUG - 2020-02-26 17:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:41:08 --> Output Class Initialized
INFO - 2020-02-26 17:41:08 --> Output Class Initialized
INFO - 2020-02-26 17:41:08 --> Output Class Initialized
INFO - 2020-02-26 17:41:08 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:41:08 --> Output Class Initialized
INFO - 2020-02-26 17:41:08 --> Security Class Initialized
INFO - 2020-02-26 17:41:08 --> Security Class Initialized
INFO - 2020-02-26 17:41:08 --> Security Class Initialized
INFO - 2020-02-26 17:41:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:41:08 --> Security Class Initialized
INFO - 2020-02-26 17:41:08 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 17:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:08 --> Input Class Initialized
INFO - 2020-02-26 17:41:08 --> Input Class Initialized
INFO - 2020-02-26 17:41:08 --> Input Class Initialized
INFO - 2020-02-26 17:41:08 --> Input Class Initialized
INFO - 2020-02-26 17:41:08 --> Helper loaded: form_helper
INFO - 2020-02-26 17:41:08 --> Language Class Initialized
INFO - 2020-02-26 17:41:08 --> Language Class Initialized
INFO - 2020-02-26 17:41:08 --> Language Class Initialized
INFO - 2020-02-26 17:41:08 --> Language Class Initialized
INFO - 2020-02-26 17:41:08 --> Form Validation Class Initialized
ERROR - 2020-02-26 17:41:08 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-26 17:41:08 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 17:41:08 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 17:41:08 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 17:41:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 17:41:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 17:41:08 --> Config Class Initialized
INFO - 2020-02-26 17:41:08 --> Config Class Initialized
INFO - 2020-02-26 17:41:08 --> Config Class Initialized
INFO - 2020-02-26 17:41:08 --> Config Class Initialized
INFO - 2020-02-26 17:41:09 --> Hooks Class Initialized
INFO - 2020-02-26 17:41:09 --> Hooks Class Initialized
INFO - 2020-02-26 17:41:09 --> Hooks Class Initialized
INFO - 2020-02-26 17:41:09 --> Hooks Class Initialized
INFO - 2020-02-26 17:41:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 17:41:09 --> Final output sent to browser
DEBUG - 2020-02-26 17:41:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:41:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:41:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:41:09 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:09 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:09 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:41:09 --> Total execution time: 1.0829
INFO - 2020-02-26 17:41:09 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:09 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:09 --> URI Class Initialized
INFO - 2020-02-26 17:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:41:09 --> URI Class Initialized
INFO - 2020-02-26 17:41:09 --> URI Class Initialized
INFO - 2020-02-26 17:41:09 --> URI Class Initialized
INFO - 2020-02-26 17:41:09 --> Controller Class Initialized
INFO - 2020-02-26 17:41:09 --> Router Class Initialized
INFO - 2020-02-26 17:41:09 --> Router Class Initialized
INFO - 2020-02-26 17:41:09 --> Router Class Initialized
INFO - 2020-02-26 17:41:09 --> Router Class Initialized
INFO - 2020-02-26 17:41:09 --> Output Class Initialized
INFO - 2020-02-26 17:41:09 --> Output Class Initialized
INFO - 2020-02-26 17:41:09 --> Output Class Initialized
INFO - 2020-02-26 17:41:09 --> Output Class Initialized
INFO - 2020-02-26 17:41:09 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:41:09 --> Security Class Initialized
INFO - 2020-02-26 17:41:09 --> Security Class Initialized
INFO - 2020-02-26 17:41:09 --> Security Class Initialized
INFO - 2020-02-26 17:41:09 --> Security Class Initialized
INFO - 2020-02-26 17:41:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:41:09 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 17:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:09 --> Input Class Initialized
INFO - 2020-02-26 17:41:09 --> Input Class Initialized
INFO - 2020-02-26 17:41:09 --> Input Class Initialized
INFO - 2020-02-26 17:41:09 --> Input Class Initialized
INFO - 2020-02-26 17:41:09 --> Helper loaded: form_helper
INFO - 2020-02-26 17:41:09 --> Form Validation Class Initialized
INFO - 2020-02-26 17:41:09 --> Language Class Initialized
INFO - 2020-02-26 17:41:09 --> Language Class Initialized
INFO - 2020-02-26 17:41:09 --> Language Class Initialized
INFO - 2020-02-26 17:41:09 --> Language Class Initialized
ERROR - 2020-02-26 17:41:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 17:41:09 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-26 17:41:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-26 17:41:09 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 17:41:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 17:41:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 17:41:09 --> Config Class Initialized
INFO - 2020-02-26 17:41:09 --> Hooks Class Initialized
INFO - 2020-02-26 17:41:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 17:41:09 --> Final output sent to browser
DEBUG - 2020-02-26 17:41:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:41:09 --> Total execution time: 1.4128
INFO - 2020-02-26 17:41:09 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:09 --> URI Class Initialized
INFO - 2020-02-26 17:41:09 --> Router Class Initialized
INFO - 2020-02-26 17:41:09 --> Output Class Initialized
INFO - 2020-02-26 17:41:09 --> Security Class Initialized
DEBUG - 2020-02-26 17:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:09 --> Input Class Initialized
INFO - 2020-02-26 17:41:09 --> Language Class Initialized
ERROR - 2020-02-26 17:41:09 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 17:41:09 --> Config Class Initialized
INFO - 2020-02-26 17:41:09 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:41:09 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:09 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:09 --> URI Class Initialized
INFO - 2020-02-26 17:41:10 --> Router Class Initialized
INFO - 2020-02-26 17:41:10 --> Output Class Initialized
INFO - 2020-02-26 17:41:10 --> Security Class Initialized
DEBUG - 2020-02-26 17:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:10 --> Input Class Initialized
INFO - 2020-02-26 17:41:10 --> Language Class Initialized
ERROR - 2020-02-26 17:41:10 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 17:41:10 --> Config Class Initialized
INFO - 2020-02-26 17:41:10 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:41:10 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:10 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:10 --> URI Class Initialized
INFO - 2020-02-26 17:41:10 --> Router Class Initialized
INFO - 2020-02-26 17:41:10 --> Output Class Initialized
INFO - 2020-02-26 17:41:10 --> Security Class Initialized
DEBUG - 2020-02-26 17:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:10 --> Input Class Initialized
INFO - 2020-02-26 17:41:10 --> Language Class Initialized
ERROR - 2020-02-26 17:41:10 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 17:41:10 --> Config Class Initialized
INFO - 2020-02-26 17:41:10 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:41:10 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:10 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:10 --> URI Class Initialized
INFO - 2020-02-26 17:41:10 --> Router Class Initialized
INFO - 2020-02-26 17:41:10 --> Output Class Initialized
INFO - 2020-02-26 17:41:10 --> Security Class Initialized
DEBUG - 2020-02-26 17:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:10 --> Input Class Initialized
INFO - 2020-02-26 17:41:11 --> Language Class Initialized
ERROR - 2020-02-26 17:41:11 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 17:41:11 --> Config Class Initialized
INFO - 2020-02-26 17:41:11 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:41:11 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:11 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:11 --> URI Class Initialized
INFO - 2020-02-26 17:41:11 --> Router Class Initialized
INFO - 2020-02-26 17:41:11 --> Output Class Initialized
INFO - 2020-02-26 17:41:11 --> Security Class Initialized
DEBUG - 2020-02-26 17:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:11 --> Input Class Initialized
INFO - 2020-02-26 17:41:11 --> Language Class Initialized
ERROR - 2020-02-26 17:41:11 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 17:41:11 --> Config Class Initialized
INFO - 2020-02-26 17:41:11 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:41:11 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:11 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:11 --> URI Class Initialized
INFO - 2020-02-26 17:41:11 --> Router Class Initialized
INFO - 2020-02-26 17:41:11 --> Output Class Initialized
INFO - 2020-02-26 17:41:11 --> Security Class Initialized
DEBUG - 2020-02-26 17:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:11 --> Input Class Initialized
INFO - 2020-02-26 17:41:11 --> Language Class Initialized
ERROR - 2020-02-26 17:41:12 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 17:41:12 --> Config Class Initialized
INFO - 2020-02-26 17:41:12 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:41:12 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:12 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:12 --> URI Class Initialized
INFO - 2020-02-26 17:41:12 --> Router Class Initialized
INFO - 2020-02-26 17:41:12 --> Output Class Initialized
INFO - 2020-02-26 17:41:12 --> Security Class Initialized
DEBUG - 2020-02-26 17:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:12 --> Input Class Initialized
INFO - 2020-02-26 17:41:12 --> Language Class Initialized
ERROR - 2020-02-26 17:41:12 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 17:41:34 --> Config Class Initialized
INFO - 2020-02-26 17:41:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:41:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:34 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:34 --> URI Class Initialized
INFO - 2020-02-26 17:41:34 --> Router Class Initialized
INFO - 2020-02-26 17:41:34 --> Output Class Initialized
INFO - 2020-02-26 17:41:34 --> Security Class Initialized
DEBUG - 2020-02-26 17:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:34 --> Input Class Initialized
INFO - 2020-02-26 17:41:35 --> Language Class Initialized
INFO - 2020-02-26 17:41:35 --> Loader Class Initialized
INFO - 2020-02-26 17:41:35 --> Helper loaded: url_helper
INFO - 2020-02-26 17:41:35 --> Helper loaded: string_helper
INFO - 2020-02-26 17:41:35 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:41:35 --> Controller Class Initialized
INFO - 2020-02-26 17:41:35 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:41:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:41:35 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:41:35 --> Helper loaded: form_helper
INFO - 2020-02-26 17:41:35 --> Form Validation Class Initialized
INFO - 2020-02-26 23:41:35 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 23:41:35 --> Final output sent to browser
DEBUG - 2020-02-26 23:41:35 --> Total execution time: 1.1657
INFO - 2020-02-26 17:41:43 --> Config Class Initialized
INFO - 2020-02-26 17:41:43 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:41:43 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:41:43 --> Utf8 Class Initialized
INFO - 2020-02-26 17:41:43 --> URI Class Initialized
INFO - 2020-02-26 17:41:43 --> Router Class Initialized
INFO - 2020-02-26 17:41:43 --> Output Class Initialized
INFO - 2020-02-26 17:41:43 --> Security Class Initialized
DEBUG - 2020-02-26 17:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:41:43 --> Input Class Initialized
INFO - 2020-02-26 17:41:43 --> Language Class Initialized
INFO - 2020-02-26 17:41:43 --> Loader Class Initialized
INFO - 2020-02-26 17:41:43 --> Helper loaded: url_helper
INFO - 2020-02-26 17:41:44 --> Helper loaded: string_helper
INFO - 2020-02-26 17:41:44 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:41:44 --> Controller Class Initialized
INFO - 2020-02-26 17:41:44 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:41:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:41:44 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:41:44 --> Helper loaded: form_helper
INFO - 2020-02-26 17:41:44 --> Form Validation Class Initialized
ERROR - 2020-02-26 17:41:44 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 17:41:44 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 17:41:44 --> Final output sent to browser
DEBUG - 2020-02-26 17:41:44 --> Total execution time: 0.8997
INFO - 2020-02-26 17:42:23 --> Config Class Initialized
INFO - 2020-02-26 17:42:23 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:42:23 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:42:23 --> Utf8 Class Initialized
INFO - 2020-02-26 17:42:23 --> URI Class Initialized
INFO - 2020-02-26 17:42:23 --> Router Class Initialized
INFO - 2020-02-26 17:42:23 --> Output Class Initialized
INFO - 2020-02-26 17:42:23 --> Security Class Initialized
DEBUG - 2020-02-26 17:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:42:23 --> Input Class Initialized
INFO - 2020-02-26 17:42:23 --> Language Class Initialized
INFO - 2020-02-26 17:42:23 --> Loader Class Initialized
INFO - 2020-02-26 17:42:23 --> Helper loaded: url_helper
INFO - 2020-02-26 17:42:23 --> Helper loaded: string_helper
INFO - 2020-02-26 17:42:23 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:42:23 --> Controller Class Initialized
INFO - 2020-02-26 17:42:23 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:42:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:42:23 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:42:23 --> Helper loaded: form_helper
INFO - 2020-02-26 17:42:23 --> Form Validation Class Initialized
INFO - 2020-02-26 17:42:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-26 17:42:24 --> Config Class Initialized
INFO - 2020-02-26 17:42:24 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:42:24 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:42:24 --> Utf8 Class Initialized
INFO - 2020-02-26 17:42:24 --> URI Class Initialized
INFO - 2020-02-26 17:42:24 --> Router Class Initialized
INFO - 2020-02-26 17:42:24 --> Output Class Initialized
INFO - 2020-02-26 17:42:24 --> Security Class Initialized
DEBUG - 2020-02-26 17:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:42:24 --> Input Class Initialized
INFO - 2020-02-26 17:42:24 --> Language Class Initialized
INFO - 2020-02-26 17:42:24 --> Loader Class Initialized
INFO - 2020-02-26 17:42:24 --> Helper loaded: url_helper
INFO - 2020-02-26 17:42:24 --> Helper loaded: string_helper
INFO - 2020-02-26 17:42:24 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:42:24 --> Controller Class Initialized
INFO - 2020-02-26 17:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 17:42:24 --> Pagination Class Initialized
INFO - 2020-02-26 17:42:24 --> Model "M_show" initialized
INFO - 2020-02-26 17:42:24 --> Helper loaded: form_helper
INFO - 2020-02-26 17:42:24 --> Form Validation Class Initialized
INFO - 2020-02-26 17:42:24 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 17:42:24 --> Final output sent to browser
DEBUG - 2020-02-26 17:42:24 --> Total execution time: 0.7441
INFO - 2020-02-26 17:42:24 --> Config Class Initialized
INFO - 2020-02-26 17:42:25 --> Config Class Initialized
INFO - 2020-02-26 17:42:25 --> Hooks Class Initialized
INFO - 2020-02-26 17:42:25 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:42:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:42:25 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:42:25 --> Utf8 Class Initialized
INFO - 2020-02-26 17:42:25 --> Utf8 Class Initialized
INFO - 2020-02-26 17:42:25 --> URI Class Initialized
INFO - 2020-02-26 17:42:25 --> URI Class Initialized
INFO - 2020-02-26 17:42:25 --> Router Class Initialized
INFO - 2020-02-26 17:42:25 --> Router Class Initialized
INFO - 2020-02-26 17:42:25 --> Output Class Initialized
INFO - 2020-02-26 17:42:25 --> Output Class Initialized
INFO - 2020-02-26 17:42:25 --> Security Class Initialized
INFO - 2020-02-26 17:42:25 --> Security Class Initialized
DEBUG - 2020-02-26 17:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:42:25 --> Input Class Initialized
INFO - 2020-02-26 17:42:25 --> Input Class Initialized
INFO - 2020-02-26 17:42:25 --> Language Class Initialized
INFO - 2020-02-26 17:42:25 --> Language Class Initialized
ERROR - 2020-02-26 17:42:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-26 17:42:25 --> 404 Page Not Found: Assets/js
INFO - 2020-02-26 17:42:25 --> Config Class Initialized
INFO - 2020-02-26 17:42:25 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:42:25 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:42:25 --> Utf8 Class Initialized
INFO - 2020-02-26 17:42:25 --> URI Class Initialized
INFO - 2020-02-26 17:42:25 --> Router Class Initialized
INFO - 2020-02-26 17:42:25 --> Output Class Initialized
INFO - 2020-02-26 17:42:25 --> Security Class Initialized
DEBUG - 2020-02-26 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:42:25 --> Input Class Initialized
INFO - 2020-02-26 17:42:25 --> Language Class Initialized
ERROR - 2020-02-26 17:42:25 --> 404 Page Not Found: Assets/js
INFO - 2020-02-26 17:50:44 --> Config Class Initialized
INFO - 2020-02-26 17:50:45 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:50:45 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:45 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:45 --> URI Class Initialized
INFO - 2020-02-26 17:50:45 --> Router Class Initialized
INFO - 2020-02-26 17:50:45 --> Output Class Initialized
INFO - 2020-02-26 17:50:45 --> Security Class Initialized
DEBUG - 2020-02-26 17:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:45 --> Input Class Initialized
INFO - 2020-02-26 17:50:45 --> Language Class Initialized
INFO - 2020-02-26 17:50:45 --> Loader Class Initialized
INFO - 2020-02-26 17:50:45 --> Helper loaded: url_helper
INFO - 2020-02-26 17:50:45 --> Helper loaded: string_helper
INFO - 2020-02-26 17:50:45 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:50:45 --> Controller Class Initialized
INFO - 2020-02-26 17:50:45 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:50:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:50:45 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:50:45 --> Helper loaded: form_helper
INFO - 2020-02-26 17:50:45 --> Form Validation Class Initialized
INFO - 2020-02-26 17:50:45 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 17:50:45 --> Final output sent to browser
DEBUG - 2020-02-26 17:50:45 --> Total execution time: 1.0084
INFO - 2020-02-26 17:50:46 --> Config Class Initialized
INFO - 2020-02-26 17:50:46 --> Config Class Initialized
INFO - 2020-02-26 17:50:46 --> Config Class Initialized
INFO - 2020-02-26 17:50:46 --> Config Class Initialized
INFO - 2020-02-26 17:50:46 --> Config Class Initialized
INFO - 2020-02-26 17:50:46 --> Config Class Initialized
INFO - 2020-02-26 17:50:46 --> Hooks Class Initialized
INFO - 2020-02-26 17:50:46 --> Hooks Class Initialized
INFO - 2020-02-26 17:50:46 --> Hooks Class Initialized
INFO - 2020-02-26 17:50:46 --> Hooks Class Initialized
INFO - 2020-02-26 17:50:46 --> Hooks Class Initialized
INFO - 2020-02-26 17:50:46 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:50:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:50:46 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:46 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:46 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:50:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:50:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:50:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:50:46 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:46 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:46 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:46 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:46 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:46 --> URI Class Initialized
INFO - 2020-02-26 17:50:46 --> URI Class Initialized
INFO - 2020-02-26 17:50:46 --> URI Class Initialized
INFO - 2020-02-26 17:50:46 --> Router Class Initialized
INFO - 2020-02-26 17:50:46 --> URI Class Initialized
INFO - 2020-02-26 17:50:46 --> Router Class Initialized
INFO - 2020-02-26 17:50:46 --> URI Class Initialized
INFO - 2020-02-26 17:50:46 --> URI Class Initialized
INFO - 2020-02-26 17:50:46 --> Output Class Initialized
INFO - 2020-02-26 17:50:46 --> Router Class Initialized
INFO - 2020-02-26 17:50:46 --> Router Class Initialized
INFO - 2020-02-26 17:50:46 --> Router Class Initialized
INFO - 2020-02-26 17:50:46 --> Router Class Initialized
INFO - 2020-02-26 17:50:46 --> Output Class Initialized
INFO - 2020-02-26 17:50:46 --> Output Class Initialized
INFO - 2020-02-26 17:50:46 --> Output Class Initialized
INFO - 2020-02-26 17:50:46 --> Output Class Initialized
INFO - 2020-02-26 17:50:46 --> Security Class Initialized
INFO - 2020-02-26 17:50:46 --> Security Class Initialized
INFO - 2020-02-26 17:50:46 --> Output Class Initialized
DEBUG - 2020-02-26 17:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:46 --> Security Class Initialized
INFO - 2020-02-26 17:50:46 --> Security Class Initialized
INFO - 2020-02-26 17:50:46 --> Security Class Initialized
INFO - 2020-02-26 17:50:46 --> Security Class Initialized
INFO - 2020-02-26 17:50:46 --> Input Class Initialized
INFO - 2020-02-26 17:50:46 --> Input Class Initialized
DEBUG - 2020-02-26 17:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:46 --> Input Class Initialized
INFO - 2020-02-26 17:50:46 --> Input Class Initialized
INFO - 2020-02-26 17:50:46 --> Input Class Initialized
INFO - 2020-02-26 17:50:46 --> Input Class Initialized
INFO - 2020-02-26 17:50:46 --> Language Class Initialized
INFO - 2020-02-26 17:50:46 --> Language Class Initialized
INFO - 2020-02-26 17:50:46 --> Language Class Initialized
INFO - 2020-02-26 17:50:46 --> Language Class Initialized
INFO - 2020-02-26 17:50:46 --> Language Class Initialized
ERROR - 2020-02-26 17:50:46 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 17:50:46 --> Language Class Initialized
INFO - 2020-02-26 17:50:46 --> Loader Class Initialized
INFO - 2020-02-26 17:50:46 --> Helper loaded: url_helper
ERROR - 2020-02-26 17:50:46 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 17:50:46 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 17:50:46 --> Loader Class Initialized
ERROR - 2020-02-26 17:50:46 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-26 17:50:46 --> Config Class Initialized
INFO - 2020-02-26 17:50:46 --> Hooks Class Initialized
INFO - 2020-02-26 17:50:46 --> Helper loaded: string_helper
INFO - 2020-02-26 17:50:46 --> Helper loaded: url_helper
INFO - 2020-02-26 17:50:46 --> Config Class Initialized
INFO - 2020-02-26 17:50:46 --> Config Class Initialized
INFO - 2020-02-26 17:50:46 --> Config Class Initialized
INFO - 2020-02-26 17:50:46 --> Hooks Class Initialized
INFO - 2020-02-26 17:50:46 --> Hooks Class Initialized
INFO - 2020-02-26 17:50:46 --> Hooks Class Initialized
INFO - 2020-02-26 17:50:46 --> Helper loaded: string_helper
DEBUG - 2020-02-26 17:50:46 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:46 --> Database Driver Class Initialized
INFO - 2020-02-26 17:50:46 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:50:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:50:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:50:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:50:46 --> Database Driver Class Initialized
INFO - 2020-02-26 17:50:46 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:46 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:46 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:50:46 --> URI Class Initialized
DEBUG - 2020-02-26 17:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:50:46 --> Controller Class Initialized
INFO - 2020-02-26 17:50:46 --> URI Class Initialized
INFO - 2020-02-26 17:50:46 --> Router Class Initialized
INFO - 2020-02-26 17:50:46 --> URI Class Initialized
INFO - 2020-02-26 17:50:46 --> URI Class Initialized
INFO - 2020-02-26 17:50:46 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:50:46 --> Router Class Initialized
INFO - 2020-02-26 17:50:46 --> Output Class Initialized
INFO - 2020-02-26 17:50:46 --> Router Class Initialized
INFO - 2020-02-26 17:50:46 --> Router Class Initialized
INFO - 2020-02-26 17:50:46 --> Security Class Initialized
INFO - 2020-02-26 17:50:46 --> Output Class Initialized
INFO - 2020-02-26 17:50:46 --> Output Class Initialized
INFO - 2020-02-26 17:50:46 --> Output Class Initialized
INFO - 2020-02-26 17:50:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:50:47 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:47 --> Security Class Initialized
INFO - 2020-02-26 17:50:47 --> Security Class Initialized
INFO - 2020-02-26 17:50:47 --> Security Class Initialized
DEBUG - 2020-02-26 17:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:47 --> Input Class Initialized
DEBUG - 2020-02-26 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:47 --> Helper loaded: form_helper
INFO - 2020-02-26 17:50:47 --> Input Class Initialized
INFO - 2020-02-26 17:50:47 --> Form Validation Class Initialized
INFO - 2020-02-26 17:50:47 --> Input Class Initialized
INFO - 2020-02-26 17:50:47 --> Input Class Initialized
INFO - 2020-02-26 17:50:47 --> Language Class Initialized
INFO - 2020-02-26 17:50:47 --> Language Class Initialized
INFO - 2020-02-26 17:50:47 --> Language Class Initialized
INFO - 2020-02-26 17:50:47 --> Language Class Initialized
ERROR - 2020-02-26 17:50:47 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 17:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 17:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 17:50:47 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-26 17:50:47 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 17:50:47 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 17:50:47 --> Config Class Initialized
INFO - 2020-02-26 17:50:47 --> Hooks Class Initialized
INFO - 2020-02-26 17:50:47 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 17:50:47 --> Config Class Initialized
INFO - 2020-02-26 17:50:47 --> Config Class Initialized
INFO - 2020-02-26 17:50:47 --> Hooks Class Initialized
INFO - 2020-02-26 17:50:47 --> Final output sent to browser
INFO - 2020-02-26 17:50:47 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:50:47 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:47 --> Config Class Initialized
INFO - 2020-02-26 17:50:47 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:50:47 --> Total execution time: 1.2502
INFO - 2020-02-26 17:50:47 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:50:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 17:50:47 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:47 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:50:47 --> URI Class Initialized
INFO - 2020-02-26 17:50:47 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:50:47 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:47 --> Controller Class Initialized
INFO - 2020-02-26 17:50:47 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:47 --> URI Class Initialized
INFO - 2020-02-26 17:50:47 --> URI Class Initialized
INFO - 2020-02-26 17:50:47 --> Router Class Initialized
INFO - 2020-02-26 17:50:47 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:50:47 --> Router Class Initialized
INFO - 2020-02-26 17:50:47 --> Router Class Initialized
INFO - 2020-02-26 17:50:47 --> Output Class Initialized
INFO - 2020-02-26 17:50:47 --> URI Class Initialized
INFO - 2020-02-26 17:50:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:50:47 --> Router Class Initialized
INFO - 2020-02-26 17:50:47 --> Output Class Initialized
INFO - 2020-02-26 17:50:47 --> Security Class Initialized
INFO - 2020-02-26 17:50:47 --> Output Class Initialized
INFO - 2020-02-26 17:50:47 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:47 --> Security Class Initialized
INFO - 2020-02-26 17:50:47 --> Output Class Initialized
INFO - 2020-02-26 17:50:47 --> Security Class Initialized
INFO - 2020-02-26 17:50:47 --> Input Class Initialized
DEBUG - 2020-02-26 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:47 --> Security Class Initialized
DEBUG - 2020-02-26 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:47 --> Helper loaded: form_helper
INFO - 2020-02-26 17:50:47 --> Form Validation Class Initialized
INFO - 2020-02-26 17:50:47 --> Input Class Initialized
INFO - 2020-02-26 17:50:47 --> Input Class Initialized
INFO - 2020-02-26 17:50:47 --> Language Class Initialized
DEBUG - 2020-02-26 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:47 --> Input Class Initialized
INFO - 2020-02-26 17:50:47 --> Language Class Initialized
INFO - 2020-02-26 17:50:47 --> Language Class Initialized
ERROR - 2020-02-26 17:50:47 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-26 17:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 17:50:47 --> Language Class Initialized
ERROR - 2020-02-26 17:50:47 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 17:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 17:50:47 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 17:50:47 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-26 17:50:47 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 17:50:47 --> Final output sent to browser
INFO - 2020-02-26 17:50:47 --> Config Class Initialized
INFO - 2020-02-26 17:50:47 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:50:47 --> Total execution time: 1.6537
DEBUG - 2020-02-26 17:50:47 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:47 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:47 --> URI Class Initialized
INFO - 2020-02-26 17:50:47 --> Router Class Initialized
INFO - 2020-02-26 17:50:47 --> Output Class Initialized
INFO - 2020-02-26 17:50:47 --> Security Class Initialized
DEBUG - 2020-02-26 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:47 --> Input Class Initialized
INFO - 2020-02-26 17:50:48 --> Language Class Initialized
ERROR - 2020-02-26 17:50:48 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 17:50:48 --> Config Class Initialized
INFO - 2020-02-26 17:50:48 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:50:48 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:48 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:48 --> URI Class Initialized
INFO - 2020-02-26 17:50:48 --> Router Class Initialized
INFO - 2020-02-26 17:50:48 --> Output Class Initialized
INFO - 2020-02-26 17:50:48 --> Security Class Initialized
DEBUG - 2020-02-26 17:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:48 --> Input Class Initialized
INFO - 2020-02-26 17:50:48 --> Language Class Initialized
ERROR - 2020-02-26 17:50:48 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 17:50:48 --> Config Class Initialized
INFO - 2020-02-26 17:50:48 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:50:48 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:48 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:48 --> URI Class Initialized
INFO - 2020-02-26 17:50:48 --> Router Class Initialized
INFO - 2020-02-26 17:50:48 --> Output Class Initialized
INFO - 2020-02-26 17:50:48 --> Security Class Initialized
DEBUG - 2020-02-26 17:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:48 --> Input Class Initialized
INFO - 2020-02-26 17:50:48 --> Language Class Initialized
ERROR - 2020-02-26 17:50:48 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 17:50:49 --> Config Class Initialized
INFO - 2020-02-26 17:50:49 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:50:49 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:49 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:49 --> URI Class Initialized
INFO - 2020-02-26 17:50:49 --> Router Class Initialized
INFO - 2020-02-26 17:50:49 --> Output Class Initialized
INFO - 2020-02-26 17:50:49 --> Security Class Initialized
DEBUG - 2020-02-26 17:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:49 --> Input Class Initialized
INFO - 2020-02-26 17:50:49 --> Language Class Initialized
ERROR - 2020-02-26 17:50:49 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 17:50:49 --> Config Class Initialized
INFO - 2020-02-26 17:50:49 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:50:49 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:49 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:49 --> URI Class Initialized
INFO - 2020-02-26 17:50:49 --> Router Class Initialized
INFO - 2020-02-26 17:50:49 --> Output Class Initialized
INFO - 2020-02-26 17:50:49 --> Security Class Initialized
DEBUG - 2020-02-26 17:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:49 --> Input Class Initialized
INFO - 2020-02-26 17:50:49 --> Language Class Initialized
ERROR - 2020-02-26 17:50:49 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 17:50:49 --> Config Class Initialized
INFO - 2020-02-26 17:50:49 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:50:50 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:50 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:50 --> URI Class Initialized
INFO - 2020-02-26 17:50:50 --> Router Class Initialized
INFO - 2020-02-26 17:50:50 --> Output Class Initialized
INFO - 2020-02-26 17:50:50 --> Security Class Initialized
DEBUG - 2020-02-26 17:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:50 --> Input Class Initialized
INFO - 2020-02-26 17:50:50 --> Language Class Initialized
ERROR - 2020-02-26 17:50:50 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 17:50:50 --> Config Class Initialized
INFO - 2020-02-26 17:50:50 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:50:50 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:50:50 --> Utf8 Class Initialized
INFO - 2020-02-26 17:50:50 --> URI Class Initialized
INFO - 2020-02-26 17:50:50 --> Router Class Initialized
INFO - 2020-02-26 17:50:50 --> Output Class Initialized
INFO - 2020-02-26 17:50:50 --> Security Class Initialized
DEBUG - 2020-02-26 17:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:50:50 --> Input Class Initialized
INFO - 2020-02-26 17:50:50 --> Language Class Initialized
ERROR - 2020-02-26 17:50:50 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 17:51:08 --> Config Class Initialized
INFO - 2020-02-26 17:51:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:51:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:51:08 --> Utf8 Class Initialized
INFO - 2020-02-26 17:51:08 --> URI Class Initialized
INFO - 2020-02-26 17:51:08 --> Router Class Initialized
INFO - 2020-02-26 17:51:08 --> Output Class Initialized
INFO - 2020-02-26 17:51:08 --> Security Class Initialized
DEBUG - 2020-02-26 17:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:51:08 --> Input Class Initialized
INFO - 2020-02-26 17:51:08 --> Language Class Initialized
INFO - 2020-02-26 17:51:08 --> Loader Class Initialized
INFO - 2020-02-26 17:51:08 --> Helper loaded: url_helper
INFO - 2020-02-26 17:51:08 --> Helper loaded: string_helper
INFO - 2020-02-26 17:51:09 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:51:09 --> Controller Class Initialized
INFO - 2020-02-26 17:51:09 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:51:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:51:09 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:51:09 --> Helper loaded: form_helper
INFO - 2020-02-26 17:51:09 --> Form Validation Class Initialized
INFO - 2020-02-26 23:51:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-26 23:51:09 --> Final output sent to browser
DEBUG - 2020-02-26 23:51:09 --> Total execution time: 1.0011
INFO - 2020-02-26 17:51:15 --> Config Class Initialized
INFO - 2020-02-26 17:51:15 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:51:15 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:51:15 --> Utf8 Class Initialized
INFO - 2020-02-26 17:51:15 --> URI Class Initialized
INFO - 2020-02-26 17:51:15 --> Router Class Initialized
INFO - 2020-02-26 17:51:15 --> Output Class Initialized
INFO - 2020-02-26 17:51:15 --> Security Class Initialized
DEBUG - 2020-02-26 17:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:51:15 --> Input Class Initialized
INFO - 2020-02-26 17:51:15 --> Language Class Initialized
INFO - 2020-02-26 17:51:15 --> Loader Class Initialized
INFO - 2020-02-26 17:51:15 --> Helper loaded: url_helper
INFO - 2020-02-26 17:51:15 --> Helper loaded: string_helper
INFO - 2020-02-26 17:51:15 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:51:15 --> Controller Class Initialized
INFO - 2020-02-26 17:51:15 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:51:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:51:15 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:51:15 --> Helper loaded: form_helper
INFO - 2020-02-26 17:51:15 --> Form Validation Class Initialized
ERROR - 2020-02-26 17:51:15 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 17:51:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 17:51:15 --> Final output sent to browser
DEBUG - 2020-02-26 17:51:15 --> Total execution time: 0.8254
INFO - 2020-02-26 17:51:42 --> Config Class Initialized
INFO - 2020-02-26 17:51:42 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:51:42 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:51:42 --> Utf8 Class Initialized
INFO - 2020-02-26 17:51:42 --> URI Class Initialized
INFO - 2020-02-26 17:51:42 --> Router Class Initialized
INFO - 2020-02-26 17:51:42 --> Output Class Initialized
INFO - 2020-02-26 17:51:42 --> Security Class Initialized
DEBUG - 2020-02-26 17:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:51:42 --> Input Class Initialized
INFO - 2020-02-26 17:51:42 --> Language Class Initialized
INFO - 2020-02-26 17:51:42 --> Loader Class Initialized
INFO - 2020-02-26 17:51:42 --> Helper loaded: url_helper
INFO - 2020-02-26 17:51:42 --> Helper loaded: string_helper
INFO - 2020-02-26 17:51:42 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:51:42 --> Controller Class Initialized
INFO - 2020-02-26 17:51:42 --> Model "M_tiket" initialized
INFO - 2020-02-26 17:51:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 17:51:42 --> Model "M_pesan" initialized
INFO - 2020-02-26 17:51:42 --> Helper loaded: form_helper
INFO - 2020-02-26 17:51:42 --> Form Validation Class Initialized
INFO - 2020-02-26 17:51:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-26 17:51:42 --> Config Class Initialized
INFO - 2020-02-26 17:51:42 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:51:42 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:51:42 --> Utf8 Class Initialized
INFO - 2020-02-26 17:51:42 --> URI Class Initialized
INFO - 2020-02-26 17:51:42 --> Router Class Initialized
INFO - 2020-02-26 17:51:43 --> Output Class Initialized
INFO - 2020-02-26 17:51:43 --> Security Class Initialized
DEBUG - 2020-02-26 17:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:51:43 --> Input Class Initialized
INFO - 2020-02-26 17:51:43 --> Language Class Initialized
INFO - 2020-02-26 17:51:43 --> Loader Class Initialized
INFO - 2020-02-26 17:51:43 --> Helper loaded: url_helper
INFO - 2020-02-26 17:51:43 --> Helper loaded: string_helper
INFO - 2020-02-26 17:51:43 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:51:43 --> Controller Class Initialized
INFO - 2020-02-26 17:51:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 17:51:43 --> Pagination Class Initialized
INFO - 2020-02-26 17:51:43 --> Model "M_show" initialized
INFO - 2020-02-26 17:51:43 --> Helper loaded: form_helper
INFO - 2020-02-26 17:51:43 --> Form Validation Class Initialized
INFO - 2020-02-26 17:51:43 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 17:51:43 --> Final output sent to browser
DEBUG - 2020-02-26 17:51:43 --> Total execution time: 0.7587
INFO - 2020-02-26 17:51:43 --> Config Class Initialized
INFO - 2020-02-26 17:51:43 --> Config Class Initialized
INFO - 2020-02-26 17:51:43 --> Hooks Class Initialized
INFO - 2020-02-26 17:51:43 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:51:43 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:51:43 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:51:43 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:51:43 --> Utf8 Class Initialized
INFO - 2020-02-26 17:51:43 --> URI Class Initialized
INFO - 2020-02-26 17:51:44 --> Router Class Initialized
INFO - 2020-02-26 17:51:44 --> URI Class Initialized
INFO - 2020-02-26 17:51:44 --> Router Class Initialized
INFO - 2020-02-26 17:51:44 --> Output Class Initialized
INFO - 2020-02-26 17:51:44 --> Security Class Initialized
INFO - 2020-02-26 17:51:44 --> Output Class Initialized
DEBUG - 2020-02-26 17:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:51:44 --> Security Class Initialized
INFO - 2020-02-26 17:51:44 --> Input Class Initialized
DEBUG - 2020-02-26 17:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:51:44 --> Input Class Initialized
INFO - 2020-02-26 17:51:44 --> Language Class Initialized
INFO - 2020-02-26 17:51:44 --> Language Class Initialized
ERROR - 2020-02-26 17:51:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-26 17:51:44 --> 404 Page Not Found: Assets/js
INFO - 2020-02-26 17:56:43 --> Config Class Initialized
INFO - 2020-02-26 17:56:43 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:56:43 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:56:43 --> Utf8 Class Initialized
INFO - 2020-02-26 17:56:43 --> URI Class Initialized
INFO - 2020-02-26 17:56:44 --> Router Class Initialized
INFO - 2020-02-26 17:56:44 --> Output Class Initialized
INFO - 2020-02-26 17:56:44 --> Security Class Initialized
DEBUG - 2020-02-26 17:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:56:44 --> Input Class Initialized
INFO - 2020-02-26 17:56:44 --> Language Class Initialized
INFO - 2020-02-26 17:56:44 --> Loader Class Initialized
INFO - 2020-02-26 17:56:44 --> Helper loaded: url_helper
INFO - 2020-02-26 17:56:44 --> Helper loaded: string_helper
INFO - 2020-02-26 17:56:44 --> Database Driver Class Initialized
DEBUG - 2020-02-26 17:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 17:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 17:56:44 --> Controller Class Initialized
INFO - 2020-02-26 17:56:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 17:56:44 --> Pagination Class Initialized
INFO - 2020-02-26 17:56:44 --> Model "M_show" initialized
INFO - 2020-02-26 17:56:44 --> Helper loaded: form_helper
INFO - 2020-02-26 17:56:44 --> Form Validation Class Initialized
INFO - 2020-02-26 17:56:44 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 17:56:44 --> Final output sent to browser
DEBUG - 2020-02-26 17:56:44 --> Total execution time: 1.4404
INFO - 2020-02-26 17:56:44 --> Config Class Initialized
INFO - 2020-02-26 17:56:44 --> Hooks Class Initialized
INFO - 2020-02-26 17:56:44 --> Config Class Initialized
INFO - 2020-02-26 17:56:45 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:56:45 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:56:45 --> Utf8 Class Initialized
DEBUG - 2020-02-26 17:56:45 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:56:45 --> Utf8 Class Initialized
INFO - 2020-02-26 17:56:45 --> URI Class Initialized
INFO - 2020-02-26 17:56:45 --> URI Class Initialized
INFO - 2020-02-26 17:56:45 --> Router Class Initialized
INFO - 2020-02-26 17:56:45 --> Router Class Initialized
INFO - 2020-02-26 17:56:45 --> Output Class Initialized
INFO - 2020-02-26 17:56:45 --> Output Class Initialized
INFO - 2020-02-26 17:56:45 --> Security Class Initialized
DEBUG - 2020-02-26 17:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:56:45 --> Security Class Initialized
INFO - 2020-02-26 17:56:45 --> Input Class Initialized
DEBUG - 2020-02-26 17:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:56:45 --> Input Class Initialized
INFO - 2020-02-26 17:56:45 --> Language Class Initialized
INFO - 2020-02-26 17:56:45 --> Language Class Initialized
ERROR - 2020-02-26 17:56:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-26 17:56:45 --> 404 Page Not Found: Assets/js
INFO - 2020-02-26 17:56:45 --> Config Class Initialized
INFO - 2020-02-26 17:56:45 --> Hooks Class Initialized
DEBUG - 2020-02-26 17:56:45 --> UTF-8 Support Enabled
INFO - 2020-02-26 17:56:45 --> Utf8 Class Initialized
INFO - 2020-02-26 17:56:45 --> URI Class Initialized
INFO - 2020-02-26 17:56:45 --> Router Class Initialized
INFO - 2020-02-26 17:56:45 --> Output Class Initialized
INFO - 2020-02-26 17:56:45 --> Security Class Initialized
DEBUG - 2020-02-26 17:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 17:56:46 --> Input Class Initialized
INFO - 2020-02-26 17:56:46 --> Language Class Initialized
ERROR - 2020-02-26 17:56:46 --> 404 Page Not Found: Assets/js
INFO - 2020-02-26 18:04:28 --> Config Class Initialized
INFO - 2020-02-26 18:04:28 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:04:28 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:28 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:28 --> URI Class Initialized
INFO - 2020-02-26 18:04:29 --> Router Class Initialized
INFO - 2020-02-26 18:04:29 --> Output Class Initialized
INFO - 2020-02-26 18:04:29 --> Security Class Initialized
DEBUG - 2020-02-26 18:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:29 --> Input Class Initialized
INFO - 2020-02-26 18:04:29 --> Language Class Initialized
INFO - 2020-02-26 18:04:29 --> Loader Class Initialized
INFO - 2020-02-26 18:04:29 --> Helper loaded: url_helper
INFO - 2020-02-26 18:04:29 --> Helper loaded: string_helper
INFO - 2020-02-26 18:04:29 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:04:30 --> Controller Class Initialized
INFO - 2020-02-26 18:04:30 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:04:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:04:30 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:04:30 --> Helper loaded: form_helper
INFO - 2020-02-26 18:04:30 --> Form Validation Class Initialized
INFO - 2020-02-26 18:04:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:04:31 --> Final output sent to browser
DEBUG - 2020-02-26 18:04:31 --> Total execution time: 2.8070
INFO - 2020-02-26 18:04:31 --> Config Class Initialized
INFO - 2020-02-26 18:04:31 --> Config Class Initialized
INFO - 2020-02-26 18:04:31 --> Config Class Initialized
INFO - 2020-02-26 18:04:31 --> Config Class Initialized
INFO - 2020-02-26 18:04:31 --> Config Class Initialized
INFO - 2020-02-26 18:04:31 --> Hooks Class Initialized
INFO - 2020-02-26 18:04:31 --> Hooks Class Initialized
INFO - 2020-02-26 18:04:31 --> Hooks Class Initialized
INFO - 2020-02-26 18:04:31 --> Hooks Class Initialized
INFO - 2020-02-26 18:04:31 --> Hooks Class Initialized
INFO - 2020-02-26 18:04:31 --> Config Class Initialized
DEBUG - 2020-02-26 18:04:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:04:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:04:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:04:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:04:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:31 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:31 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:31 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:31 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:31 --> Utf8 Class Initialized
DEBUG - 2020-02-26 18:04:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:31 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:31 --> URI Class Initialized
INFO - 2020-02-26 18:04:31 --> URI Class Initialized
INFO - 2020-02-26 18:04:31 --> URI Class Initialized
INFO - 2020-02-26 18:04:31 --> URI Class Initialized
INFO - 2020-02-26 18:04:31 --> URI Class Initialized
INFO - 2020-02-26 18:04:31 --> Router Class Initialized
INFO - 2020-02-26 18:04:31 --> Router Class Initialized
INFO - 2020-02-26 18:04:31 --> Router Class Initialized
INFO - 2020-02-26 18:04:31 --> URI Class Initialized
INFO - 2020-02-26 18:04:31 --> Router Class Initialized
INFO - 2020-02-26 18:04:31 --> Router Class Initialized
INFO - 2020-02-26 18:04:31 --> Router Class Initialized
INFO - 2020-02-26 18:04:31 --> Output Class Initialized
INFO - 2020-02-26 18:04:31 --> Output Class Initialized
INFO - 2020-02-26 18:04:31 --> Output Class Initialized
INFO - 2020-02-26 18:04:31 --> Output Class Initialized
INFO - 2020-02-26 18:04:31 --> Output Class Initialized
INFO - 2020-02-26 18:04:31 --> Security Class Initialized
INFO - 2020-02-26 18:04:31 --> Security Class Initialized
INFO - 2020-02-26 18:04:31 --> Security Class Initialized
INFO - 2020-02-26 18:04:31 --> Security Class Initialized
INFO - 2020-02-26 18:04:31 --> Security Class Initialized
INFO - 2020-02-26 18:04:31 --> Output Class Initialized
DEBUG - 2020-02-26 18:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:31 --> Security Class Initialized
DEBUG - 2020-02-26 18:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:31 --> Input Class Initialized
INFO - 2020-02-26 18:04:31 --> Input Class Initialized
INFO - 2020-02-26 18:04:31 --> Input Class Initialized
INFO - 2020-02-26 18:04:31 --> Input Class Initialized
INFO - 2020-02-26 18:04:31 --> Input Class Initialized
DEBUG - 2020-02-26 18:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:31 --> Input Class Initialized
INFO - 2020-02-26 18:04:31 --> Language Class Initialized
INFO - 2020-02-26 18:04:31 --> Language Class Initialized
INFO - 2020-02-26 18:04:31 --> Language Class Initialized
INFO - 2020-02-26 18:04:31 --> Language Class Initialized
INFO - 2020-02-26 18:04:31 --> Language Class Initialized
INFO - 2020-02-26 18:04:31 --> Language Class Initialized
INFO - 2020-02-26 18:04:31 --> Loader Class Initialized
INFO - 2020-02-26 18:04:31 --> Loader Class Initialized
ERROR - 2020-02-26 18:04:31 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-26 18:04:31 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 18:04:31 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 18:04:31 --> Helper loaded: url_helper
ERROR - 2020-02-26 18:04:31 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 18:04:31 --> Helper loaded: url_helper
INFO - 2020-02-26 18:04:31 --> Config Class Initialized
INFO - 2020-02-26 18:04:31 --> Config Class Initialized
INFO - 2020-02-26 18:04:31 --> Config Class Initialized
INFO - 2020-02-26 18:04:31 --> Hooks Class Initialized
INFO - 2020-02-26 18:04:31 --> Hooks Class Initialized
INFO - 2020-02-26 18:04:31 --> Helper loaded: string_helper
INFO - 2020-02-26 18:04:31 --> Hooks Class Initialized
INFO - 2020-02-26 18:04:31 --> Helper loaded: string_helper
INFO - 2020-02-26 18:04:31 --> Config Class Initialized
INFO - 2020-02-26 18:04:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:04:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:04:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:04:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:31 --> Database Driver Class Initialized
INFO - 2020-02-26 18:04:31 --> Database Driver Class Initialized
INFO - 2020-02-26 18:04:31 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:31 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:31 --> Utf8 Class Initialized
DEBUG - 2020-02-26 18:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-26 18:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-26 18:04:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:31 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:04:31 --> URI Class Initialized
INFO - 2020-02-26 18:04:31 --> URI Class Initialized
INFO - 2020-02-26 18:04:31 --> URI Class Initialized
INFO - 2020-02-26 18:04:31 --> Controller Class Initialized
INFO - 2020-02-26 18:04:31 --> URI Class Initialized
INFO - 2020-02-26 18:04:31 --> Router Class Initialized
INFO - 2020-02-26 18:04:31 --> Router Class Initialized
INFO - 2020-02-26 18:04:31 --> Router Class Initialized
INFO - 2020-02-26 18:04:32 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:04:32 --> Router Class Initialized
INFO - 2020-02-26 18:04:32 --> Output Class Initialized
INFO - 2020-02-26 18:04:32 --> Output Class Initialized
INFO - 2020-02-26 18:04:32 --> Output Class Initialized
INFO - 2020-02-26 18:04:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:04:32 --> Security Class Initialized
INFO - 2020-02-26 18:04:32 --> Security Class Initialized
INFO - 2020-02-26 18:04:32 --> Output Class Initialized
INFO - 2020-02-26 18:04:32 --> Security Class Initialized
INFO - 2020-02-26 18:04:32 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 18:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:32 --> Security Class Initialized
INFO - 2020-02-26 18:04:32 --> Input Class Initialized
INFO - 2020-02-26 18:04:32 --> Input Class Initialized
INFO - 2020-02-26 18:04:32 --> Input Class Initialized
DEBUG - 2020-02-26 18:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:32 --> Helper loaded: form_helper
INFO - 2020-02-26 18:04:32 --> Form Validation Class Initialized
INFO - 2020-02-26 18:04:32 --> Input Class Initialized
INFO - 2020-02-26 18:04:32 --> Language Class Initialized
INFO - 2020-02-26 18:04:32 --> Language Class Initialized
INFO - 2020-02-26 18:04:32 --> Language Class Initialized
INFO - 2020-02-26 18:04:32 --> Language Class Initialized
ERROR - 2020-02-26 18:04:32 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 18:04:32 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 18:04:32 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 18:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 18:04:32 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-26 18:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 18:04:32 --> Config Class Initialized
INFO - 2020-02-26 18:04:32 --> Config Class Initialized
INFO - 2020-02-26 18:04:32 --> Config Class Initialized
INFO - 2020-02-26 18:04:32 --> Hooks Class Initialized
INFO - 2020-02-26 18:04:32 --> Hooks Class Initialized
INFO - 2020-02-26 18:04:32 --> Hooks Class Initialized
INFO - 2020-02-26 18:04:32 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:04:32 --> Config Class Initialized
INFO - 2020-02-26 18:04:32 --> Hooks Class Initialized
INFO - 2020-02-26 18:04:32 --> Final output sent to browser
DEBUG - 2020-02-26 18:04:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:04:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:04:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:32 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:32 --> Utf8 Class Initialized
DEBUG - 2020-02-26 18:04:32 --> Total execution time: 1.1702
INFO - 2020-02-26 18:04:32 --> Utf8 Class Initialized
DEBUG - 2020-02-26 18:04:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:32 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:04:32 --> URI Class Initialized
INFO - 2020-02-26 18:04:32 --> URI Class Initialized
INFO - 2020-02-26 18:04:32 --> URI Class Initialized
INFO - 2020-02-26 18:04:32 --> Controller Class Initialized
INFO - 2020-02-26 18:04:32 --> URI Class Initialized
INFO - 2020-02-26 18:04:32 --> Router Class Initialized
INFO - 2020-02-26 18:04:32 --> Router Class Initialized
INFO - 2020-02-26 18:04:32 --> Router Class Initialized
INFO - 2020-02-26 18:04:32 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:04:32 --> Router Class Initialized
INFO - 2020-02-26 18:04:32 --> Output Class Initialized
INFO - 2020-02-26 18:04:32 --> Output Class Initialized
INFO - 2020-02-26 18:04:32 --> Output Class Initialized
INFO - 2020-02-26 18:04:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:04:32 --> Security Class Initialized
INFO - 2020-02-26 18:04:32 --> Security Class Initialized
INFO - 2020-02-26 18:04:32 --> Security Class Initialized
INFO - 2020-02-26 18:04:32 --> Output Class Initialized
INFO - 2020-02-26 18:04:32 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 18:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:32 --> Security Class Initialized
DEBUG - 2020-02-26 18:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:32 --> Input Class Initialized
INFO - 2020-02-26 18:04:32 --> Input Class Initialized
INFO - 2020-02-26 18:04:32 --> Input Class Initialized
DEBUG - 2020-02-26 18:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:32 --> Helper loaded: form_helper
INFO - 2020-02-26 18:04:32 --> Input Class Initialized
INFO - 2020-02-26 18:04:32 --> Form Validation Class Initialized
INFO - 2020-02-26 18:04:32 --> Language Class Initialized
INFO - 2020-02-26 18:04:32 --> Language Class Initialized
INFO - 2020-02-26 18:04:32 --> Language Class Initialized
INFO - 2020-02-26 18:04:32 --> Language Class Initialized
ERROR - 2020-02-26 18:04:32 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-26 18:04:32 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 18:04:32 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 18:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 18:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 18:04:32 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 18:04:32 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:04:32 --> Config Class Initialized
INFO - 2020-02-26 18:04:32 --> Hooks Class Initialized
INFO - 2020-02-26 18:04:32 --> Final output sent to browser
DEBUG - 2020-02-26 18:04:32 --> Total execution time: 1.6144
DEBUG - 2020-02-26 18:04:32 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:32 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:32 --> URI Class Initialized
INFO - 2020-02-26 18:04:32 --> Router Class Initialized
INFO - 2020-02-26 18:04:32 --> Output Class Initialized
INFO - 2020-02-26 18:04:32 --> Security Class Initialized
DEBUG - 2020-02-26 18:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:33 --> Input Class Initialized
INFO - 2020-02-26 18:04:33 --> Language Class Initialized
ERROR - 2020-02-26 18:04:33 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 18:04:33 --> Config Class Initialized
INFO - 2020-02-26 18:04:33 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:04:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:33 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:33 --> URI Class Initialized
INFO - 2020-02-26 18:04:33 --> Router Class Initialized
INFO - 2020-02-26 18:04:33 --> Output Class Initialized
INFO - 2020-02-26 18:04:33 --> Security Class Initialized
DEBUG - 2020-02-26 18:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:33 --> Input Class Initialized
INFO - 2020-02-26 18:04:33 --> Language Class Initialized
ERROR - 2020-02-26 18:04:33 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 18:04:33 --> Config Class Initialized
INFO - 2020-02-26 18:04:33 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:04:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:33 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:33 --> URI Class Initialized
INFO - 2020-02-26 18:04:33 --> Router Class Initialized
INFO - 2020-02-26 18:04:33 --> Output Class Initialized
INFO - 2020-02-26 18:04:33 --> Security Class Initialized
DEBUG - 2020-02-26 18:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:33 --> Input Class Initialized
INFO - 2020-02-26 18:04:33 --> Language Class Initialized
ERROR - 2020-02-26 18:04:33 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 18:04:34 --> Config Class Initialized
INFO - 2020-02-26 18:04:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:04:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:34 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:34 --> URI Class Initialized
INFO - 2020-02-26 18:04:34 --> Router Class Initialized
INFO - 2020-02-26 18:04:34 --> Output Class Initialized
INFO - 2020-02-26 18:04:34 --> Security Class Initialized
DEBUG - 2020-02-26 18:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:34 --> Input Class Initialized
INFO - 2020-02-26 18:04:34 --> Language Class Initialized
ERROR - 2020-02-26 18:04:34 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 18:04:34 --> Config Class Initialized
INFO - 2020-02-26 18:04:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:04:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:34 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:34 --> URI Class Initialized
INFO - 2020-02-26 18:04:34 --> Router Class Initialized
INFO - 2020-02-26 18:04:34 --> Output Class Initialized
INFO - 2020-02-26 18:04:34 --> Security Class Initialized
DEBUG - 2020-02-26 18:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:34 --> Input Class Initialized
INFO - 2020-02-26 18:04:34 --> Language Class Initialized
ERROR - 2020-02-26 18:04:34 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 18:04:34 --> Config Class Initialized
INFO - 2020-02-26 18:04:34 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:04:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:34 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:35 --> URI Class Initialized
INFO - 2020-02-26 18:04:35 --> Router Class Initialized
INFO - 2020-02-26 18:04:35 --> Output Class Initialized
INFO - 2020-02-26 18:04:35 --> Security Class Initialized
DEBUG - 2020-02-26 18:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:35 --> Input Class Initialized
INFO - 2020-02-26 18:04:35 --> Language Class Initialized
ERROR - 2020-02-26 18:04:35 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 18:04:35 --> Config Class Initialized
INFO - 2020-02-26 18:04:35 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:04:35 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:35 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:35 --> URI Class Initialized
INFO - 2020-02-26 18:04:35 --> Router Class Initialized
INFO - 2020-02-26 18:04:35 --> Output Class Initialized
INFO - 2020-02-26 18:04:35 --> Security Class Initialized
DEBUG - 2020-02-26 18:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:35 --> Input Class Initialized
INFO - 2020-02-26 18:04:35 --> Language Class Initialized
ERROR - 2020-02-26 18:04:35 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 18:04:35 --> Config Class Initialized
INFO - 2020-02-26 18:04:35 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:04:35 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:04:35 --> Utf8 Class Initialized
INFO - 2020-02-26 18:04:35 --> URI Class Initialized
INFO - 2020-02-26 18:04:35 --> Router Class Initialized
INFO - 2020-02-26 18:04:35 --> Output Class Initialized
INFO - 2020-02-26 18:04:35 --> Security Class Initialized
DEBUG - 2020-02-26 18:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:04:36 --> Input Class Initialized
INFO - 2020-02-26 18:04:36 --> Language Class Initialized
ERROR - 2020-02-26 18:04:36 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 18:05:51 --> Config Class Initialized
INFO - 2020-02-26 18:05:51 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:05:51 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:05:51 --> Utf8 Class Initialized
INFO - 2020-02-26 18:05:51 --> URI Class Initialized
INFO - 2020-02-26 18:05:51 --> Router Class Initialized
INFO - 2020-02-26 18:05:51 --> Output Class Initialized
INFO - 2020-02-26 18:05:51 --> Security Class Initialized
DEBUG - 2020-02-26 18:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:05:51 --> Input Class Initialized
INFO - 2020-02-26 18:05:51 --> Language Class Initialized
INFO - 2020-02-26 18:05:51 --> Loader Class Initialized
INFO - 2020-02-26 18:05:51 --> Helper loaded: url_helper
INFO - 2020-02-26 18:05:52 --> Helper loaded: string_helper
INFO - 2020-02-26 18:05:52 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:05:52 --> Controller Class Initialized
INFO - 2020-02-26 18:05:52 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:05:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:05:52 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:05:52 --> Helper loaded: form_helper
INFO - 2020-02-26 18:05:52 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:05:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 100
INFO - 2020-02-26 18:06:45 --> Config Class Initialized
INFO - 2020-02-26 18:06:45 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:06:45 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:06:45 --> Utf8 Class Initialized
INFO - 2020-02-26 18:06:45 --> URI Class Initialized
INFO - 2020-02-26 18:06:45 --> Router Class Initialized
INFO - 2020-02-26 18:06:45 --> Output Class Initialized
INFO - 2020-02-26 18:06:45 --> Security Class Initialized
DEBUG - 2020-02-26 18:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:06:46 --> Input Class Initialized
INFO - 2020-02-26 18:06:46 --> Language Class Initialized
INFO - 2020-02-26 18:06:46 --> Loader Class Initialized
INFO - 2020-02-26 18:06:46 --> Helper loaded: url_helper
INFO - 2020-02-26 18:06:46 --> Helper loaded: string_helper
INFO - 2020-02-26 18:06:46 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:06:46 --> Controller Class Initialized
INFO - 2020-02-26 18:06:46 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:06:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:06:46 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:06:46 --> Helper loaded: form_helper
INFO - 2020-02-26 18:06:46 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:06:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 100
INFO - 2020-02-26 18:07:31 --> Config Class Initialized
INFO - 2020-02-26 18:07:31 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:31 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:31 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:31 --> URI Class Initialized
INFO - 2020-02-26 18:07:31 --> Router Class Initialized
INFO - 2020-02-26 18:07:31 --> Output Class Initialized
INFO - 2020-02-26 18:07:31 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:31 --> Input Class Initialized
INFO - 2020-02-26 18:07:31 --> Language Class Initialized
INFO - 2020-02-26 18:07:31 --> Loader Class Initialized
INFO - 2020-02-26 18:07:31 --> Helper loaded: url_helper
INFO - 2020-02-26 18:07:31 --> Helper loaded: string_helper
INFO - 2020-02-26 18:07:31 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:07:32 --> Controller Class Initialized
INFO - 2020-02-26 18:07:32 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:07:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:07:32 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:07:32 --> Helper loaded: form_helper
INFO - 2020-02-26 18:07:32 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 100
INFO - 2020-02-26 18:07:37 --> Config Class Initialized
INFO - 2020-02-26 18:07:37 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:37 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:37 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:37 --> URI Class Initialized
INFO - 2020-02-26 18:07:37 --> Router Class Initialized
INFO - 2020-02-26 18:07:37 --> Output Class Initialized
INFO - 2020-02-26 18:07:37 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:37 --> Input Class Initialized
INFO - 2020-02-26 18:07:37 --> Language Class Initialized
INFO - 2020-02-26 18:07:37 --> Loader Class Initialized
INFO - 2020-02-26 18:07:37 --> Helper loaded: url_helper
INFO - 2020-02-26 18:07:37 --> Helper loaded: string_helper
INFO - 2020-02-26 18:07:37 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:07:37 --> Controller Class Initialized
INFO - 2020-02-26 18:07:37 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:07:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:07:37 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:07:37 --> Helper loaded: form_helper
INFO - 2020-02-26 18:07:37 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 100
INFO - 2020-02-26 18:07:39 --> Config Class Initialized
INFO - 2020-02-26 18:07:39 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:39 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:39 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:39 --> URI Class Initialized
INFO - 2020-02-26 18:07:39 --> Router Class Initialized
INFO - 2020-02-26 18:07:39 --> Output Class Initialized
INFO - 2020-02-26 18:07:39 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:39 --> Input Class Initialized
INFO - 2020-02-26 18:07:39 --> Language Class Initialized
INFO - 2020-02-26 18:07:39 --> Loader Class Initialized
INFO - 2020-02-26 18:07:39 --> Helper loaded: url_helper
INFO - 2020-02-26 18:07:39 --> Helper loaded: string_helper
INFO - 2020-02-26 18:07:39 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:07:39 --> Controller Class Initialized
INFO - 2020-02-26 18:07:39 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:07:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:07:39 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:07:40 --> Helper loaded: form_helper
INFO - 2020-02-26 18:07:40 --> Form Validation Class Initialized
INFO - 2020-02-26 18:07:40 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:07:40 --> Final output sent to browser
DEBUG - 2020-02-26 18:07:40 --> Total execution time: 0.7650
INFO - 2020-02-26 18:07:43 --> Config Class Initialized
INFO - 2020-02-26 18:07:43 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:43 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:43 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:43 --> URI Class Initialized
INFO - 2020-02-26 18:07:43 --> Router Class Initialized
INFO - 2020-02-26 18:07:43 --> Output Class Initialized
INFO - 2020-02-26 18:07:43 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:43 --> Input Class Initialized
INFO - 2020-02-26 18:07:43 --> Language Class Initialized
INFO - 2020-02-26 18:07:43 --> Loader Class Initialized
INFO - 2020-02-26 18:07:43 --> Helper loaded: url_helper
INFO - 2020-02-26 18:07:44 --> Helper loaded: string_helper
INFO - 2020-02-26 18:07:44 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:07:44 --> Controller Class Initialized
INFO - 2020-02-26 18:07:44 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:07:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:07:44 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:07:44 --> Helper loaded: form_helper
INFO - 2020-02-26 18:07:44 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 100
INFO - 2020-02-26 18:07:47 --> Config Class Initialized
INFO - 2020-02-26 18:07:47 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:47 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:47 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:47 --> URI Class Initialized
INFO - 2020-02-26 18:07:47 --> Router Class Initialized
INFO - 2020-02-26 18:07:47 --> Output Class Initialized
INFO - 2020-02-26 18:07:47 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:47 --> Input Class Initialized
INFO - 2020-02-26 18:07:47 --> Language Class Initialized
INFO - 2020-02-26 18:07:47 --> Loader Class Initialized
INFO - 2020-02-26 18:07:47 --> Helper loaded: url_helper
INFO - 2020-02-26 18:07:47 --> Helper loaded: string_helper
INFO - 2020-02-26 18:07:47 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:07:47 --> Controller Class Initialized
INFO - 2020-02-26 18:07:47 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:07:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:07:47 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:07:47 --> Helper loaded: form_helper
INFO - 2020-02-26 18:07:47 --> Form Validation Class Initialized
INFO - 2020-02-26 18:07:47 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:07:47 --> Final output sent to browser
DEBUG - 2020-02-26 18:07:48 --> Total execution time: 0.7746
INFO - 2020-02-26 18:07:51 --> Config Class Initialized
INFO - 2020-02-26 18:07:51 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:51 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:51 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:51 --> URI Class Initialized
INFO - 2020-02-26 18:07:51 --> Router Class Initialized
INFO - 2020-02-26 18:07:51 --> Output Class Initialized
INFO - 2020-02-26 18:07:51 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:51 --> Input Class Initialized
INFO - 2020-02-26 18:07:51 --> Language Class Initialized
INFO - 2020-02-26 18:07:51 --> Loader Class Initialized
INFO - 2020-02-26 18:07:51 --> Helper loaded: url_helper
INFO - 2020-02-26 18:07:51 --> Helper loaded: string_helper
INFO - 2020-02-26 18:07:51 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:07:51 --> Controller Class Initialized
INFO - 2020-02-26 18:07:51 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:07:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:07:52 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:07:52 --> Helper loaded: form_helper
INFO - 2020-02-26 18:07:52 --> Form Validation Class Initialized
INFO - 2020-02-26 18:07:52 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:07:52 --> Final output sent to browser
INFO - 2020-02-26 18:07:52 --> Config Class Initialized
INFO - 2020-02-26 18:07:52 --> Config Class Initialized
INFO - 2020-02-26 18:07:52 --> Config Class Initialized
INFO - 2020-02-26 18:07:52 --> Hooks Class Initialized
INFO - 2020-02-26 18:07:52 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:52 --> Total execution time: 0.7893
INFO - 2020-02-26 18:07:52 --> Hooks Class Initialized
INFO - 2020-02-26 18:07:52 --> Config Class Initialized
INFO - 2020-02-26 18:07:52 --> Config Class Initialized
INFO - 2020-02-26 18:07:52 --> Hooks Class Initialized
INFO - 2020-02-26 18:07:52 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:07:52 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:52 --> Config Class Initialized
INFO - 2020-02-26 18:07:52 --> Hooks Class Initialized
INFO - 2020-02-26 18:07:52 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:52 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:52 --> Utf8 Class Initialized
DEBUG - 2020-02-26 18:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:07:52 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:52 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:52 --> URI Class Initialized
INFO - 2020-02-26 18:07:52 --> URI Class Initialized
INFO - 2020-02-26 18:07:52 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:52 --> URI Class Initialized
DEBUG - 2020-02-26 18:07:52 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:52 --> URI Class Initialized
INFO - 2020-02-26 18:07:52 --> Router Class Initialized
INFO - 2020-02-26 18:07:52 --> URI Class Initialized
INFO - 2020-02-26 18:07:52 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:52 --> Router Class Initialized
INFO - 2020-02-26 18:07:52 --> Router Class Initialized
INFO - 2020-02-26 18:07:52 --> URI Class Initialized
INFO - 2020-02-26 18:07:52 --> Router Class Initialized
INFO - 2020-02-26 18:07:52 --> Output Class Initialized
INFO - 2020-02-26 18:07:52 --> Router Class Initialized
INFO - 2020-02-26 18:07:52 --> Output Class Initialized
INFO - 2020-02-26 18:07:52 --> Output Class Initialized
INFO - 2020-02-26 18:07:52 --> Security Class Initialized
INFO - 2020-02-26 18:07:52 --> Output Class Initialized
INFO - 2020-02-26 18:07:52 --> Security Class Initialized
INFO - 2020-02-26 18:07:52 --> Output Class Initialized
INFO - 2020-02-26 18:07:52 --> Router Class Initialized
INFO - 2020-02-26 18:07:52 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:52 --> Security Class Initialized
INFO - 2020-02-26 18:07:52 --> Output Class Initialized
INFO - 2020-02-26 18:07:52 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:52 --> Input Class Initialized
INFO - 2020-02-26 18:07:52 --> Input Class Initialized
INFO - 2020-02-26 18:07:52 --> Input Class Initialized
DEBUG - 2020-02-26 18:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:52 --> Security Class Initialized
INFO - 2020-02-26 18:07:52 --> Input Class Initialized
INFO - 2020-02-26 18:07:52 --> Input Class Initialized
INFO - 2020-02-26 18:07:52 --> Language Class Initialized
DEBUG - 2020-02-26 18:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:52 --> Language Class Initialized
INFO - 2020-02-26 18:07:52 --> Language Class Initialized
INFO - 2020-02-26 18:07:52 --> Input Class Initialized
INFO - 2020-02-26 18:07:52 --> Language Class Initialized
ERROR - 2020-02-26 18:07:52 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-26 18:07:52 --> Language Class Initialized
INFO - 2020-02-26 18:07:52 --> Loader Class Initialized
INFO - 2020-02-26 18:07:52 --> Loader Class Initialized
INFO - 2020-02-26 18:07:52 --> Language Class Initialized
ERROR - 2020-02-26 18:07:52 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 18:07:52 --> Helper loaded: url_helper
ERROR - 2020-02-26 18:07:52 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-26 18:07:52 --> Helper loaded: url_helper
INFO - 2020-02-26 18:07:52 --> Config Class Initialized
INFO - 2020-02-26 18:07:52 --> Hooks Class Initialized
ERROR - 2020-02-26 18:07:52 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 18:07:52 --> Helper loaded: string_helper
INFO - 2020-02-26 18:07:52 --> Helper loaded: string_helper
DEBUG - 2020-02-26 18:07:52 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:52 --> Config Class Initialized
INFO - 2020-02-26 18:07:52 --> Config Class Initialized
INFO - 2020-02-26 18:07:52 --> Config Class Initialized
INFO - 2020-02-26 18:07:52 --> Hooks Class Initialized
INFO - 2020-02-26 18:07:52 --> Hooks Class Initialized
INFO - 2020-02-26 18:07:52 --> Hooks Class Initialized
INFO - 2020-02-26 18:07:52 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:52 --> Database Driver Class Initialized
INFO - 2020-02-26 18:07:52 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:07:52 --> URI Class Initialized
DEBUG - 2020-02-26 18:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:07:52 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:52 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:07:52 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:52 --> Router Class Initialized
INFO - 2020-02-26 18:07:52 --> Controller Class Initialized
INFO - 2020-02-26 18:07:52 --> URI Class Initialized
INFO - 2020-02-26 18:07:52 --> URI Class Initialized
INFO - 2020-02-26 18:07:52 --> Output Class Initialized
INFO - 2020-02-26 18:07:52 --> URI Class Initialized
INFO - 2020-02-26 18:07:52 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:07:52 --> Security Class Initialized
INFO - 2020-02-26 18:07:52 --> Router Class Initialized
INFO - 2020-02-26 18:07:52 --> Router Class Initialized
INFO - 2020-02-26 18:07:52 --> Router Class Initialized
INFO - 2020-02-26 18:07:52 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-26 18:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:52 --> Output Class Initialized
INFO - 2020-02-26 18:07:52 --> Output Class Initialized
INFO - 2020-02-26 18:07:52 --> Output Class Initialized
INFO - 2020-02-26 18:07:52 --> Input Class Initialized
INFO - 2020-02-26 18:07:52 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:07:52 --> Security Class Initialized
INFO - 2020-02-26 18:07:52 --> Security Class Initialized
INFO - 2020-02-26 18:07:52 --> Security Class Initialized
INFO - 2020-02-26 18:07:52 --> Language Class Initialized
DEBUG - 2020-02-26 18:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:53 --> Helper loaded: form_helper
INFO - 2020-02-26 18:07:53 --> Input Class Initialized
INFO - 2020-02-26 18:07:53 --> Form Validation Class Initialized
INFO - 2020-02-26 18:07:53 --> Input Class Initialized
INFO - 2020-02-26 18:07:53 --> Input Class Initialized
ERROR - 2020-02-26 18:07:53 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 18:07:53 --> Language Class Initialized
INFO - 2020-02-26 18:07:53 --> Language Class Initialized
INFO - 2020-02-26 18:07:53 --> Language Class Initialized
ERROR - 2020-02-26 18:07:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 18:07:53 --> Config Class Initialized
INFO - 2020-02-26 18:07:53 --> Hooks Class Initialized
ERROR - 2020-02-26 18:07:53 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-26 18:07:53 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 18:07:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 18:07:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 18:07:53 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-26 18:07:53 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:53 --> Config Class Initialized
INFO - 2020-02-26 18:07:53 --> Config Class Initialized
INFO - 2020-02-26 18:07:53 --> Config Class Initialized
INFO - 2020-02-26 18:07:53 --> Hooks Class Initialized
INFO - 2020-02-26 18:07:53 --> Hooks Class Initialized
INFO - 2020-02-26 18:07:53 --> Hooks Class Initialized
INFO - 2020-02-26 18:07:53 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:53 --> Final output sent to browser
DEBUG - 2020-02-26 18:07:53 --> Total execution time: 0.9774
INFO - 2020-02-26 18:07:53 --> URI Class Initialized
DEBUG - 2020-02-26 18:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:07:53 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:53 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:53 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:53 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:07:53 --> Router Class Initialized
INFO - 2020-02-26 18:07:53 --> URI Class Initialized
INFO - 2020-02-26 18:07:53 --> Controller Class Initialized
INFO - 2020-02-26 18:07:53 --> URI Class Initialized
INFO - 2020-02-26 18:07:53 --> URI Class Initialized
INFO - 2020-02-26 18:07:53 --> Output Class Initialized
INFO - 2020-02-26 18:07:53 --> Router Class Initialized
INFO - 2020-02-26 18:07:53 --> Security Class Initialized
INFO - 2020-02-26 18:07:53 --> Router Class Initialized
INFO - 2020-02-26 18:07:53 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:07:53 --> Router Class Initialized
INFO - 2020-02-26 18:07:53 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-26 18:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:53 --> Output Class Initialized
INFO - 2020-02-26 18:07:53 --> Output Class Initialized
INFO - 2020-02-26 18:07:53 --> Output Class Initialized
INFO - 2020-02-26 18:07:53 --> Input Class Initialized
INFO - 2020-02-26 18:07:53 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:07:53 --> Security Class Initialized
INFO - 2020-02-26 18:07:53 --> Security Class Initialized
INFO - 2020-02-26 18:07:53 --> Security Class Initialized
INFO - 2020-02-26 18:07:53 --> Language Class Initialized
DEBUG - 2020-02-26 18:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:53 --> Helper loaded: form_helper
INFO - 2020-02-26 18:07:53 --> Input Class Initialized
INFO - 2020-02-26 18:07:53 --> Input Class Initialized
INFO - 2020-02-26 18:07:53 --> Form Validation Class Initialized
INFO - 2020-02-26 18:07:53 --> Input Class Initialized
ERROR - 2020-02-26 18:07:53 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 18:07:53 --> Language Class Initialized
INFO - 2020-02-26 18:07:53 --> Language Class Initialized
INFO - 2020-02-26 18:07:53 --> Language Class Initialized
ERROR - 2020-02-26 18:07:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 18:07:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 18:07:53 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 18:07:53 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 18:07:53 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 18:07:53 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:07:53 --> Config Class Initialized
INFO - 2020-02-26 18:07:53 --> Hooks Class Initialized
INFO - 2020-02-26 18:07:53 --> Final output sent to browser
DEBUG - 2020-02-26 18:07:53 --> Total execution time: 1.3626
DEBUG - 2020-02-26 18:07:53 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:53 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:53 --> URI Class Initialized
INFO - 2020-02-26 18:07:53 --> Router Class Initialized
INFO - 2020-02-26 18:07:53 --> Output Class Initialized
INFO - 2020-02-26 18:07:53 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:53 --> Input Class Initialized
INFO - 2020-02-26 18:07:53 --> Language Class Initialized
ERROR - 2020-02-26 18:07:53 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 18:07:53 --> Config Class Initialized
INFO - 2020-02-26 18:07:53 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:54 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:54 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:54 --> URI Class Initialized
INFO - 2020-02-26 18:07:54 --> Router Class Initialized
INFO - 2020-02-26 18:07:54 --> Output Class Initialized
INFO - 2020-02-26 18:07:54 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:54 --> Input Class Initialized
INFO - 2020-02-26 18:07:54 --> Language Class Initialized
ERROR - 2020-02-26 18:07:54 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 18:07:54 --> Config Class Initialized
INFO - 2020-02-26 18:07:54 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:54 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:54 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:54 --> URI Class Initialized
INFO - 2020-02-26 18:07:54 --> Router Class Initialized
INFO - 2020-02-26 18:07:54 --> Output Class Initialized
INFO - 2020-02-26 18:07:54 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:54 --> Input Class Initialized
INFO - 2020-02-26 18:07:54 --> Language Class Initialized
ERROR - 2020-02-26 18:07:54 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 18:07:54 --> Config Class Initialized
INFO - 2020-02-26 18:07:54 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:54 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:54 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:54 --> URI Class Initialized
INFO - 2020-02-26 18:07:54 --> Router Class Initialized
INFO - 2020-02-26 18:07:54 --> Output Class Initialized
INFO - 2020-02-26 18:07:54 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:54 --> Input Class Initialized
INFO - 2020-02-26 18:07:55 --> Language Class Initialized
ERROR - 2020-02-26 18:07:55 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 18:07:55 --> Config Class Initialized
INFO - 2020-02-26 18:07:55 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:55 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:55 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:55 --> URI Class Initialized
INFO - 2020-02-26 18:07:55 --> Router Class Initialized
INFO - 2020-02-26 18:07:55 --> Output Class Initialized
INFO - 2020-02-26 18:07:55 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:55 --> Input Class Initialized
INFO - 2020-02-26 18:07:55 --> Language Class Initialized
ERROR - 2020-02-26 18:07:55 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 18:07:55 --> Config Class Initialized
INFO - 2020-02-26 18:07:55 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:55 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:55 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:55 --> URI Class Initialized
INFO - 2020-02-26 18:07:55 --> Router Class Initialized
INFO - 2020-02-26 18:07:55 --> Output Class Initialized
INFO - 2020-02-26 18:07:55 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:55 --> Input Class Initialized
INFO - 2020-02-26 18:07:55 --> Language Class Initialized
ERROR - 2020-02-26 18:07:55 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 18:07:55 --> Config Class Initialized
INFO - 2020-02-26 18:07:55 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:55 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:55 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:55 --> URI Class Initialized
INFO - 2020-02-26 18:07:56 --> Router Class Initialized
INFO - 2020-02-26 18:07:56 --> Output Class Initialized
INFO - 2020-02-26 18:07:56 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:56 --> Input Class Initialized
INFO - 2020-02-26 18:07:56 --> Language Class Initialized
ERROR - 2020-02-26 18:07:56 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 18:07:56 --> Config Class Initialized
INFO - 2020-02-26 18:07:56 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:07:56 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:07:56 --> Utf8 Class Initialized
INFO - 2020-02-26 18:07:56 --> URI Class Initialized
INFO - 2020-02-26 18:07:56 --> Router Class Initialized
INFO - 2020-02-26 18:07:56 --> Output Class Initialized
INFO - 2020-02-26 18:07:56 --> Security Class Initialized
DEBUG - 2020-02-26 18:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:07:56 --> Input Class Initialized
INFO - 2020-02-26 18:07:56 --> Language Class Initialized
ERROR - 2020-02-26 18:07:56 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 18:08:17 --> Config Class Initialized
INFO - 2020-02-26 18:08:17 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:08:17 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:08:17 --> Utf8 Class Initialized
INFO - 2020-02-26 18:08:17 --> URI Class Initialized
INFO - 2020-02-26 18:08:17 --> Router Class Initialized
INFO - 2020-02-26 18:08:18 --> Output Class Initialized
INFO - 2020-02-26 18:08:18 --> Security Class Initialized
DEBUG - 2020-02-26 18:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:08:18 --> Input Class Initialized
INFO - 2020-02-26 18:08:18 --> Language Class Initialized
INFO - 2020-02-26 18:08:18 --> Loader Class Initialized
INFO - 2020-02-26 18:08:18 --> Helper loaded: url_helper
INFO - 2020-02-26 18:08:18 --> Helper loaded: string_helper
INFO - 2020-02-26 18:08:18 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:08:18 --> Controller Class Initialized
INFO - 2020-02-26 18:08:18 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:08:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:08:18 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:08:18 --> Helper loaded: form_helper
INFO - 2020-02-26 18:08:18 --> Form Validation Class Initialized
INFO - 2020-02-26 18:08:24 --> Config Class Initialized
INFO - 2020-02-26 18:08:24 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:08:24 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:08:24 --> Utf8 Class Initialized
INFO - 2020-02-26 18:08:24 --> URI Class Initialized
INFO - 2020-02-26 18:08:24 --> Router Class Initialized
INFO - 2020-02-26 18:08:24 --> Output Class Initialized
INFO - 2020-02-26 18:08:24 --> Security Class Initialized
DEBUG - 2020-02-26 18:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:08:24 --> Input Class Initialized
INFO - 2020-02-26 18:08:24 --> Language Class Initialized
INFO - 2020-02-26 18:08:24 --> Loader Class Initialized
INFO - 2020-02-26 18:08:24 --> Helper loaded: url_helper
INFO - 2020-02-26 18:08:24 --> Helper loaded: string_helper
INFO - 2020-02-26 18:08:24 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:08:24 --> Controller Class Initialized
INFO - 2020-02-26 18:08:24 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:08:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:08:24 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:08:25 --> Helper loaded: form_helper
INFO - 2020-02-26 18:08:25 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:08:25 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 18:08:25 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 18:08:25 --> Final output sent to browser
DEBUG - 2020-02-26 18:08:25 --> Total execution time: 0.8593
INFO - 2020-02-26 18:08:43 --> Config Class Initialized
INFO - 2020-02-26 18:08:43 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:08:43 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:08:43 --> Utf8 Class Initialized
INFO - 2020-02-26 18:08:43 --> URI Class Initialized
INFO - 2020-02-26 18:08:43 --> Router Class Initialized
INFO - 2020-02-26 18:08:43 --> Output Class Initialized
INFO - 2020-02-26 18:08:43 --> Security Class Initialized
DEBUG - 2020-02-26 18:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:08:43 --> Input Class Initialized
INFO - 2020-02-26 18:08:43 --> Language Class Initialized
INFO - 2020-02-26 18:08:43 --> Loader Class Initialized
INFO - 2020-02-26 18:08:43 --> Helper loaded: url_helper
INFO - 2020-02-26 18:08:43 --> Helper loaded: string_helper
INFO - 2020-02-26 18:08:43 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:08:44 --> Controller Class Initialized
INFO - 2020-02-26 18:08:44 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:08:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:08:44 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:08:44 --> Helper loaded: form_helper
INFO - 2020-02-26 18:08:44 --> Form Validation Class Initialized
INFO - 2020-02-26 18:08:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-26 18:08:44 --> Config Class Initialized
INFO - 2020-02-26 18:08:44 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:08:44 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:08:44 --> Utf8 Class Initialized
INFO - 2020-02-26 18:08:44 --> URI Class Initialized
INFO - 2020-02-26 18:08:44 --> Router Class Initialized
INFO - 2020-02-26 18:08:44 --> Output Class Initialized
INFO - 2020-02-26 18:08:44 --> Security Class Initialized
DEBUG - 2020-02-26 18:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:08:44 --> Input Class Initialized
INFO - 2020-02-26 18:08:44 --> Language Class Initialized
INFO - 2020-02-26 18:08:44 --> Loader Class Initialized
INFO - 2020-02-26 18:08:44 --> Helper loaded: url_helper
INFO - 2020-02-26 18:08:44 --> Helper loaded: string_helper
INFO - 2020-02-26 18:08:44 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:08:44 --> Controller Class Initialized
INFO - 2020-02-26 18:08:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 18:08:44 --> Pagination Class Initialized
INFO - 2020-02-26 18:08:44 --> Model "M_show" initialized
INFO - 2020-02-26 18:08:44 --> Helper loaded: form_helper
INFO - 2020-02-26 18:08:45 --> Form Validation Class Initialized
INFO - 2020-02-26 18:08:45 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 18:08:45 --> Final output sent to browser
DEBUG - 2020-02-26 18:08:45 --> Total execution time: 0.9035
INFO - 2020-02-26 18:08:45 --> Config Class Initialized
INFO - 2020-02-26 18:08:45 --> Config Class Initialized
INFO - 2020-02-26 18:08:45 --> Hooks Class Initialized
INFO - 2020-02-26 18:08:45 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:08:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:08:45 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:08:45 --> Utf8 Class Initialized
INFO - 2020-02-26 18:08:45 --> Utf8 Class Initialized
INFO - 2020-02-26 18:08:45 --> URI Class Initialized
INFO - 2020-02-26 18:08:45 --> URI Class Initialized
INFO - 2020-02-26 18:08:45 --> Router Class Initialized
INFO - 2020-02-26 18:08:45 --> Router Class Initialized
INFO - 2020-02-26 18:08:45 --> Output Class Initialized
INFO - 2020-02-26 18:08:45 --> Output Class Initialized
INFO - 2020-02-26 18:08:45 --> Security Class Initialized
INFO - 2020-02-26 18:08:45 --> Security Class Initialized
DEBUG - 2020-02-26 18:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:08:45 --> Input Class Initialized
INFO - 2020-02-26 18:08:45 --> Input Class Initialized
INFO - 2020-02-26 18:08:45 --> Language Class Initialized
INFO - 2020-02-26 18:08:45 --> Language Class Initialized
ERROR - 2020-02-26 18:08:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-26 18:08:46 --> 404 Page Not Found: Assets/js
INFO - 2020-02-26 18:15:32 --> Config Class Initialized
INFO - 2020-02-26 18:15:33 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:15:33 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:15:33 --> Utf8 Class Initialized
INFO - 2020-02-26 18:15:33 --> URI Class Initialized
INFO - 2020-02-26 18:15:33 --> Router Class Initialized
INFO - 2020-02-26 18:15:33 --> Output Class Initialized
INFO - 2020-02-26 18:15:33 --> Security Class Initialized
DEBUG - 2020-02-26 18:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:15:33 --> Input Class Initialized
INFO - 2020-02-26 18:15:33 --> Language Class Initialized
INFO - 2020-02-26 18:15:33 --> Loader Class Initialized
INFO - 2020-02-26 18:15:33 --> Helper loaded: url_helper
INFO - 2020-02-26 18:15:33 --> Helper loaded: string_helper
INFO - 2020-02-26 18:15:33 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:15:33 --> Controller Class Initialized
INFO - 2020-02-26 18:15:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 18:15:33 --> Pagination Class Initialized
INFO - 2020-02-26 18:15:33 --> Model "M_show" initialized
INFO - 2020-02-26 18:15:33 --> Helper loaded: form_helper
INFO - 2020-02-26 18:15:33 --> Form Validation Class Initialized
INFO - 2020-02-26 18:15:33 --> Config Class Initialized
INFO - 2020-02-26 18:15:33 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:15:34 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:15:34 --> Utf8 Class Initialized
INFO - 2020-02-26 18:15:34 --> URI Class Initialized
INFO - 2020-02-26 18:15:34 --> Router Class Initialized
INFO - 2020-02-26 18:15:34 --> Output Class Initialized
INFO - 2020-02-26 18:15:34 --> Security Class Initialized
DEBUG - 2020-02-26 18:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:15:34 --> Input Class Initialized
INFO - 2020-02-26 18:15:34 --> Language Class Initialized
ERROR - 2020-02-26 18:15:34 --> 404 Page Not Found: Show/show_list
INFO - 2020-02-26 18:16:36 --> Config Class Initialized
INFO - 2020-02-26 18:16:36 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:16:36 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:16:36 --> Utf8 Class Initialized
INFO - 2020-02-26 18:16:36 --> URI Class Initialized
INFO - 2020-02-26 18:16:36 --> Router Class Initialized
INFO - 2020-02-26 18:16:36 --> Output Class Initialized
INFO - 2020-02-26 18:16:36 --> Security Class Initialized
DEBUG - 2020-02-26 18:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:16:36 --> Input Class Initialized
INFO - 2020-02-26 18:16:36 --> Language Class Initialized
INFO - 2020-02-26 18:16:36 --> Loader Class Initialized
INFO - 2020-02-26 18:16:36 --> Helper loaded: url_helper
INFO - 2020-02-26 18:16:36 --> Helper loaded: string_helper
INFO - 2020-02-26 18:16:36 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:16:36 --> Controller Class Initialized
INFO - 2020-02-26 18:16:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 18:16:37 --> Pagination Class Initialized
INFO - 2020-02-26 18:16:37 --> Model "M_show" initialized
INFO - 2020-02-26 18:16:37 --> Helper loaded: form_helper
INFO - 2020-02-26 18:16:37 --> Form Validation Class Initialized
INFO - 2020-02-26 18:17:46 --> Config Class Initialized
INFO - 2020-02-26 18:17:47 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:17:47 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:17:47 --> Utf8 Class Initialized
INFO - 2020-02-26 18:17:47 --> URI Class Initialized
INFO - 2020-02-26 18:17:47 --> Router Class Initialized
INFO - 2020-02-26 18:17:47 --> Output Class Initialized
INFO - 2020-02-26 18:17:47 --> Security Class Initialized
DEBUG - 2020-02-26 18:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:17:47 --> Input Class Initialized
INFO - 2020-02-26 18:17:47 --> Language Class Initialized
INFO - 2020-02-26 18:17:47 --> Loader Class Initialized
INFO - 2020-02-26 18:17:47 --> Helper loaded: url_helper
INFO - 2020-02-26 18:17:47 --> Helper loaded: string_helper
INFO - 2020-02-26 18:17:47 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:17:47 --> Controller Class Initialized
INFO - 2020-02-26 18:17:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 18:17:47 --> Pagination Class Initialized
INFO - 2020-02-26 18:17:47 --> Model "M_show" initialized
INFO - 2020-02-26 18:17:47 --> Helper loaded: form_helper
INFO - 2020-02-26 18:17:47 --> Form Validation Class Initialized
INFO - 2020-02-26 18:17:47 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\component/menu.php
INFO - 2020-02-26 18:17:47 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/tambah_show.php
INFO - 2020-02-26 18:17:47 --> Final output sent to browser
DEBUG - 2020-02-26 18:17:48 --> Total execution time: 1.1496
INFO - 2020-02-26 18:18:35 --> Config Class Initialized
INFO - 2020-02-26 18:18:35 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:18:35 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:18:35 --> Utf8 Class Initialized
INFO - 2020-02-26 18:18:35 --> URI Class Initialized
INFO - 2020-02-26 18:18:35 --> Router Class Initialized
INFO - 2020-02-26 18:18:35 --> Output Class Initialized
INFO - 2020-02-26 18:18:35 --> Security Class Initialized
DEBUG - 2020-02-26 18:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:18:35 --> Input Class Initialized
INFO - 2020-02-26 18:18:36 --> Language Class Initialized
INFO - 2020-02-26 18:18:36 --> Loader Class Initialized
INFO - 2020-02-26 18:18:36 --> Helper loaded: url_helper
INFO - 2020-02-26 18:18:36 --> Helper loaded: string_helper
INFO - 2020-02-26 18:18:36 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:18:36 --> Controller Class Initialized
INFO - 2020-02-26 18:18:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 18:18:36 --> Pagination Class Initialized
INFO - 2020-02-26 18:18:36 --> Model "M_show" initialized
INFO - 2020-02-26 18:18:36 --> Helper loaded: form_helper
INFO - 2020-02-26 18:18:36 --> Form Validation Class Initialized
INFO - 2020-02-26 18:18:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-26 18:18:36 --> Upload Class Initialized
INFO - 2020-02-26 18:18:36 --> Config Class Initialized
INFO - 2020-02-26 18:18:36 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:18:36 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:18:36 --> Utf8 Class Initialized
INFO - 2020-02-26 18:18:36 --> URI Class Initialized
INFO - 2020-02-26 18:18:36 --> Router Class Initialized
INFO - 2020-02-26 18:18:36 --> Output Class Initialized
INFO - 2020-02-26 18:18:36 --> Security Class Initialized
DEBUG - 2020-02-26 18:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:18:37 --> Input Class Initialized
INFO - 2020-02-26 18:18:37 --> Language Class Initialized
ERROR - 2020-02-26 18:18:37 --> 404 Page Not Found: Show/show_list
INFO - 2020-02-26 18:18:45 --> Config Class Initialized
INFO - 2020-02-26 18:18:45 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:18:46 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:18:46 --> Utf8 Class Initialized
INFO - 2020-02-26 18:18:46 --> URI Class Initialized
DEBUG - 2020-02-26 18:18:46 --> No URI present. Default controller set.
INFO - 2020-02-26 18:18:46 --> Router Class Initialized
INFO - 2020-02-26 18:18:46 --> Output Class Initialized
INFO - 2020-02-26 18:18:46 --> Security Class Initialized
DEBUG - 2020-02-26 18:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:18:46 --> Input Class Initialized
INFO - 2020-02-26 18:18:46 --> Language Class Initialized
INFO - 2020-02-26 18:18:46 --> Loader Class Initialized
INFO - 2020-02-26 18:18:46 --> Helper loaded: url_helper
INFO - 2020-02-26 18:18:46 --> Helper loaded: string_helper
INFO - 2020-02-26 18:18:46 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:18:46 --> Controller Class Initialized
INFO - 2020-02-26 18:18:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 18:18:46 --> Pagination Class Initialized
INFO - 2020-02-26 18:18:46 --> Model "M_show" initialized
INFO - 2020-02-26 18:18:46 --> Helper loaded: form_helper
INFO - 2020-02-26 18:18:46 --> Form Validation Class Initialized
INFO - 2020-02-26 18:18:46 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 18:18:46 --> Final output sent to browser
DEBUG - 2020-02-26 18:18:46 --> Total execution time: 0.8052
INFO - 2020-02-26 18:19:02 --> Config Class Initialized
INFO - 2020-02-26 18:19:02 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:19:02 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:19:02 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:02 --> URI Class Initialized
INFO - 2020-02-26 18:19:02 --> Router Class Initialized
INFO - 2020-02-26 18:19:02 --> Output Class Initialized
INFO - 2020-02-26 18:19:02 --> Security Class Initialized
DEBUG - 2020-02-26 18:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:19:03 --> Input Class Initialized
INFO - 2020-02-26 18:19:03 --> Language Class Initialized
INFO - 2020-02-26 18:19:03 --> Loader Class Initialized
INFO - 2020-02-26 18:19:03 --> Helper loaded: url_helper
INFO - 2020-02-26 18:19:03 --> Helper loaded: string_helper
INFO - 2020-02-26 18:19:03 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:19:03 --> Controller Class Initialized
INFO - 2020-02-26 18:19:03 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:19:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:19:03 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:19:03 --> Helper loaded: form_helper
INFO - 2020-02-26 18:19:03 --> Form Validation Class Initialized
INFO - 2020-02-26 18:19:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:19:03 --> Final output sent to browser
DEBUG - 2020-02-26 18:19:03 --> Total execution time: 0.9998
INFO - 2020-02-26 18:19:03 --> Config Class Initialized
INFO - 2020-02-26 18:19:03 --> Config Class Initialized
INFO - 2020-02-26 18:19:03 --> Config Class Initialized
INFO - 2020-02-26 18:19:03 --> Config Class Initialized
INFO - 2020-02-26 18:19:03 --> Config Class Initialized
INFO - 2020-02-26 18:19:03 --> Config Class Initialized
INFO - 2020-02-26 18:19:03 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:03 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:03 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:03 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:03 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:03 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:19:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:19:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:19:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:19:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:19:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:19:03 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:19:03 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:03 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:03 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:03 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:03 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:03 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:03 --> URI Class Initialized
INFO - 2020-02-26 18:19:03 --> URI Class Initialized
INFO - 2020-02-26 18:19:03 --> URI Class Initialized
INFO - 2020-02-26 18:19:03 --> URI Class Initialized
INFO - 2020-02-26 18:19:03 --> URI Class Initialized
INFO - 2020-02-26 18:19:03 --> URI Class Initialized
INFO - 2020-02-26 18:19:03 --> Router Class Initialized
INFO - 2020-02-26 18:19:03 --> Router Class Initialized
INFO - 2020-02-26 18:19:03 --> Router Class Initialized
INFO - 2020-02-26 18:19:03 --> Router Class Initialized
INFO - 2020-02-26 18:19:03 --> Router Class Initialized
INFO - 2020-02-26 18:19:03 --> Router Class Initialized
INFO - 2020-02-26 18:19:03 --> Output Class Initialized
INFO - 2020-02-26 18:19:03 --> Output Class Initialized
INFO - 2020-02-26 18:19:03 --> Output Class Initialized
INFO - 2020-02-26 18:19:03 --> Output Class Initialized
INFO - 2020-02-26 18:19:03 --> Output Class Initialized
INFO - 2020-02-26 18:19:03 --> Output Class Initialized
INFO - 2020-02-26 18:19:03 --> Security Class Initialized
INFO - 2020-02-26 18:19:03 --> Security Class Initialized
INFO - 2020-02-26 18:19:03 --> Security Class Initialized
INFO - 2020-02-26 18:19:03 --> Security Class Initialized
INFO - 2020-02-26 18:19:03 --> Security Class Initialized
INFO - 2020-02-26 18:19:03 --> Security Class Initialized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Language Class Initialized
INFO - 2020-02-26 18:19:04 --> Language Class Initialized
INFO - 2020-02-26 18:19:04 --> Language Class Initialized
INFO - 2020-02-26 18:19:04 --> Language Class Initialized
INFO - 2020-02-26 18:19:04 --> Language Class Initialized
INFO - 2020-02-26 18:19:04 --> Language Class Initialized
ERROR - 2020-02-26 18:19:04 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 18:19:04 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 18:19:04 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-26 18:19:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 18:19:04 --> Loader Class Initialized
INFO - 2020-02-26 18:19:04 --> Loader Class Initialized
INFO - 2020-02-26 18:19:04 --> Helper loaded: url_helper
INFO - 2020-02-26 18:19:04 --> Helper loaded: url_helper
INFO - 2020-02-26 18:19:04 --> Config Class Initialized
INFO - 2020-02-26 18:19:04 --> Config Class Initialized
INFO - 2020-02-26 18:19:04 --> Config Class Initialized
INFO - 2020-02-26 18:19:04 --> Config Class Initialized
INFO - 2020-02-26 18:19:04 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:04 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:04 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:04 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:04 --> Helper loaded: string_helper
INFO - 2020-02-26 18:19:04 --> Helper loaded: string_helper
DEBUG - 2020-02-26 18:19:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:19:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:19:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:19:04 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:19:04 --> Database Driver Class Initialized
INFO - 2020-02-26 18:19:04 --> Database Driver Class Initialized
INFO - 2020-02-26 18:19:04 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:04 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:04 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:04 --> Utf8 Class Initialized
DEBUG - 2020-02-26 18:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-26 18:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:19:04 --> URI Class Initialized
INFO - 2020-02-26 18:19:04 --> URI Class Initialized
INFO - 2020-02-26 18:19:04 --> URI Class Initialized
INFO - 2020-02-26 18:19:04 --> URI Class Initialized
INFO - 2020-02-26 18:19:04 --> Controller Class Initialized
INFO - 2020-02-26 18:19:04 --> Router Class Initialized
INFO - 2020-02-26 18:19:04 --> Router Class Initialized
INFO - 2020-02-26 18:19:04 --> Router Class Initialized
INFO - 2020-02-26 18:19:04 --> Router Class Initialized
INFO - 2020-02-26 18:19:04 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:19:04 --> Output Class Initialized
INFO - 2020-02-26 18:19:04 --> Output Class Initialized
INFO - 2020-02-26 18:19:04 --> Output Class Initialized
INFO - 2020-02-26 18:19:04 --> Output Class Initialized
INFO - 2020-02-26 18:19:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:19:04 --> Security Class Initialized
INFO - 2020-02-26 18:19:04 --> Security Class Initialized
INFO - 2020-02-26 18:19:04 --> Security Class Initialized
INFO - 2020-02-26 18:19:04 --> Security Class Initialized
INFO - 2020-02-26 18:19:04 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Helper loaded: form_helper
INFO - 2020-02-26 18:19:04 --> Form Validation Class Initialized
INFO - 2020-02-26 18:19:04 --> Language Class Initialized
INFO - 2020-02-26 18:19:04 --> Language Class Initialized
INFO - 2020-02-26 18:19:04 --> Language Class Initialized
INFO - 2020-02-26 18:19:04 --> Language Class Initialized
ERROR - 2020-02-26 18:19:04 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 18:19:04 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 18:19:04 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 18:19:04 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-26 18:19:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 18:19:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 18:19:04 --> Config Class Initialized
INFO - 2020-02-26 18:19:04 --> Config Class Initialized
INFO - 2020-02-26 18:19:04 --> Config Class Initialized
INFO - 2020-02-26 18:19:04 --> Config Class Initialized
INFO - 2020-02-26 18:19:04 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:04 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:04 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:04 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:04 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:19:04 --> Final output sent to browser
DEBUG - 2020-02-26 18:19:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:19:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:19:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:19:04 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:19:04 --> Utf8 Class Initialized
DEBUG - 2020-02-26 18:19:04 --> Total execution time: 1.0194
INFO - 2020-02-26 18:19:04 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:04 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:04 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:04 --> URI Class Initialized
INFO - 2020-02-26 18:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:19:04 --> URI Class Initialized
INFO - 2020-02-26 18:19:04 --> URI Class Initialized
INFO - 2020-02-26 18:19:04 --> URI Class Initialized
INFO - 2020-02-26 18:19:04 --> Controller Class Initialized
INFO - 2020-02-26 18:19:04 --> Router Class Initialized
INFO - 2020-02-26 18:19:04 --> Router Class Initialized
INFO - 2020-02-26 18:19:04 --> Router Class Initialized
INFO - 2020-02-26 18:19:04 --> Router Class Initialized
INFO - 2020-02-26 18:19:04 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:19:04 --> Output Class Initialized
INFO - 2020-02-26 18:19:04 --> Output Class Initialized
INFO - 2020-02-26 18:19:04 --> Output Class Initialized
INFO - 2020-02-26 18:19:04 --> Output Class Initialized
INFO - 2020-02-26 18:19:04 --> Security Class Initialized
INFO - 2020-02-26 18:19:04 --> Security Class Initialized
INFO - 2020-02-26 18:19:04 --> Security Class Initialized
INFO - 2020-02-26 18:19:04 --> Security Class Initialized
INFO - 2020-02-26 18:19:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:19:04 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Input Class Initialized
INFO - 2020-02-26 18:19:04 --> Helper loaded: form_helper
INFO - 2020-02-26 18:19:05 --> Form Validation Class Initialized
INFO - 2020-02-26 18:19:05 --> Language Class Initialized
INFO - 2020-02-26 18:19:05 --> Language Class Initialized
INFO - 2020-02-26 18:19:05 --> Language Class Initialized
INFO - 2020-02-26 18:19:05 --> Language Class Initialized
ERROR - 2020-02-26 18:19:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 18:19:05 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-26 18:19:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-26 18:19:05 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 18:19:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 18:19:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 18:19:05 --> Config Class Initialized
INFO - 2020-02-26 18:19:05 --> Hooks Class Initialized
INFO - 2020-02-26 18:19:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:19:05 --> Final output sent to browser
DEBUG - 2020-02-26 18:19:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:19:05 --> Total execution time: 1.4799
INFO - 2020-02-26 18:19:05 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:05 --> URI Class Initialized
INFO - 2020-02-26 18:19:05 --> Router Class Initialized
INFO - 2020-02-26 18:19:05 --> Output Class Initialized
INFO - 2020-02-26 18:19:05 --> Security Class Initialized
DEBUG - 2020-02-26 18:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:19:05 --> Input Class Initialized
INFO - 2020-02-26 18:19:05 --> Language Class Initialized
ERROR - 2020-02-26 18:19:05 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 18:19:05 --> Config Class Initialized
INFO - 2020-02-26 18:19:05 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:19:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:19:05 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:05 --> URI Class Initialized
INFO - 2020-02-26 18:19:05 --> Router Class Initialized
INFO - 2020-02-26 18:19:05 --> Output Class Initialized
INFO - 2020-02-26 18:19:05 --> Security Class Initialized
DEBUG - 2020-02-26 18:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:19:05 --> Input Class Initialized
INFO - 2020-02-26 18:19:05 --> Language Class Initialized
ERROR - 2020-02-26 18:19:05 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 18:19:05 --> Config Class Initialized
INFO - 2020-02-26 18:19:05 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:19:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:19:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:06 --> URI Class Initialized
INFO - 2020-02-26 18:19:06 --> Router Class Initialized
INFO - 2020-02-26 18:19:06 --> Output Class Initialized
INFO - 2020-02-26 18:19:06 --> Security Class Initialized
DEBUG - 2020-02-26 18:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:19:06 --> Input Class Initialized
INFO - 2020-02-26 18:19:06 --> Language Class Initialized
ERROR - 2020-02-26 18:19:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 18:19:06 --> Config Class Initialized
INFO - 2020-02-26 18:19:06 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:19:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:19:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:06 --> URI Class Initialized
INFO - 2020-02-26 18:19:06 --> Router Class Initialized
INFO - 2020-02-26 18:19:06 --> Output Class Initialized
INFO - 2020-02-26 18:19:06 --> Security Class Initialized
DEBUG - 2020-02-26 18:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:19:06 --> Input Class Initialized
INFO - 2020-02-26 18:19:06 --> Language Class Initialized
ERROR - 2020-02-26 18:19:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 18:19:06 --> Config Class Initialized
INFO - 2020-02-26 18:19:06 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:19:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:19:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:06 --> URI Class Initialized
INFO - 2020-02-26 18:19:06 --> Router Class Initialized
INFO - 2020-02-26 18:19:06 --> Output Class Initialized
INFO - 2020-02-26 18:19:07 --> Security Class Initialized
DEBUG - 2020-02-26 18:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:19:07 --> Input Class Initialized
INFO - 2020-02-26 18:19:07 --> Language Class Initialized
ERROR - 2020-02-26 18:19:07 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 18:19:07 --> Config Class Initialized
INFO - 2020-02-26 18:19:07 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:19:07 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:19:07 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:07 --> URI Class Initialized
INFO - 2020-02-26 18:19:07 --> Router Class Initialized
INFO - 2020-02-26 18:19:07 --> Output Class Initialized
INFO - 2020-02-26 18:19:07 --> Security Class Initialized
DEBUG - 2020-02-26 18:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:19:07 --> Input Class Initialized
INFO - 2020-02-26 18:19:07 --> Language Class Initialized
ERROR - 2020-02-26 18:19:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 18:19:07 --> Config Class Initialized
INFO - 2020-02-26 18:19:07 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:19:07 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:19:07 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:07 --> URI Class Initialized
INFO - 2020-02-26 18:19:07 --> Router Class Initialized
INFO - 2020-02-26 18:19:07 --> Output Class Initialized
INFO - 2020-02-26 18:19:07 --> Security Class Initialized
DEBUG - 2020-02-26 18:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:19:07 --> Input Class Initialized
INFO - 2020-02-26 18:19:07 --> Language Class Initialized
ERROR - 2020-02-26 18:19:07 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 18:19:08 --> Config Class Initialized
INFO - 2020-02-26 18:19:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:19:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:19:08 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:08 --> URI Class Initialized
INFO - 2020-02-26 18:19:08 --> Router Class Initialized
INFO - 2020-02-26 18:19:08 --> Output Class Initialized
INFO - 2020-02-26 18:19:08 --> Security Class Initialized
DEBUG - 2020-02-26 18:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:19:08 --> Input Class Initialized
INFO - 2020-02-26 18:19:08 --> Language Class Initialized
ERROR - 2020-02-26 18:19:08 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 18:19:09 --> Config Class Initialized
INFO - 2020-02-26 18:19:09 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:19:09 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:19:09 --> Utf8 Class Initialized
INFO - 2020-02-26 18:19:09 --> URI Class Initialized
DEBUG - 2020-02-26 18:19:09 --> No URI present. Default controller set.
INFO - 2020-02-26 18:19:09 --> Router Class Initialized
INFO - 2020-02-26 18:19:09 --> Output Class Initialized
INFO - 2020-02-26 18:19:09 --> Security Class Initialized
DEBUG - 2020-02-26 18:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:19:09 --> Input Class Initialized
INFO - 2020-02-26 18:19:09 --> Language Class Initialized
INFO - 2020-02-26 18:19:09 --> Loader Class Initialized
INFO - 2020-02-26 18:19:09 --> Helper loaded: url_helper
INFO - 2020-02-26 18:19:10 --> Helper loaded: string_helper
INFO - 2020-02-26 18:19:10 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:19:10 --> Controller Class Initialized
INFO - 2020-02-26 18:19:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 18:19:10 --> Pagination Class Initialized
INFO - 2020-02-26 18:19:10 --> Model "M_show" initialized
INFO - 2020-02-26 18:19:10 --> Helper loaded: form_helper
INFO - 2020-02-26 18:19:10 --> Form Validation Class Initialized
INFO - 2020-02-26 18:19:10 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 18:19:10 --> Final output sent to browser
DEBUG - 2020-02-26 18:19:10 --> Total execution time: 1.0747
INFO - 2020-02-26 18:38:37 --> Config Class Initialized
INFO - 2020-02-26 18:38:37 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:38:37 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:37 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:37 --> URI Class Initialized
INFO - 2020-02-26 18:38:37 --> Router Class Initialized
INFO - 2020-02-26 18:38:37 --> Output Class Initialized
INFO - 2020-02-26 18:38:37 --> Security Class Initialized
DEBUG - 2020-02-26 18:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:37 --> Input Class Initialized
INFO - 2020-02-26 18:38:37 --> Language Class Initialized
INFO - 2020-02-26 18:38:38 --> Loader Class Initialized
INFO - 2020-02-26 18:38:38 --> Helper loaded: url_helper
INFO - 2020-02-26 18:38:38 --> Helper loaded: string_helper
INFO - 2020-02-26 18:38:38 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:38:38 --> Controller Class Initialized
INFO - 2020-02-26 18:38:38 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:38:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:38:38 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:38:38 --> Helper loaded: form_helper
INFO - 2020-02-26 18:38:38 --> Form Validation Class Initialized
INFO - 2020-02-26 18:38:39 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:38:39 --> Final output sent to browser
DEBUG - 2020-02-26 18:38:39 --> Total execution time: 2.0202
INFO - 2020-02-26 18:38:39 --> Config Class Initialized
INFO - 2020-02-26 18:38:39 --> Config Class Initialized
INFO - 2020-02-26 18:38:39 --> Config Class Initialized
INFO - 2020-02-26 18:38:39 --> Config Class Initialized
INFO - 2020-02-26 18:38:39 --> Hooks Class Initialized
INFO - 2020-02-26 18:38:39 --> Hooks Class Initialized
INFO - 2020-02-26 18:38:39 --> Hooks Class Initialized
INFO - 2020-02-26 18:38:39 --> Hooks Class Initialized
INFO - 2020-02-26 18:38:39 --> Config Class Initialized
INFO - 2020-02-26 18:38:39 --> Config Class Initialized
INFO - 2020-02-26 18:38:39 --> Hooks Class Initialized
INFO - 2020-02-26 18:38:39 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:38:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:38:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:38:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:38:39 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:39 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:39 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:39 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:39 --> Utf8 Class Initialized
DEBUG - 2020-02-26 18:38:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:38:39 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:39 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:39 --> URI Class Initialized
INFO - 2020-02-26 18:38:39 --> URI Class Initialized
INFO - 2020-02-26 18:38:39 --> URI Class Initialized
INFO - 2020-02-26 18:38:39 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:39 --> URI Class Initialized
INFO - 2020-02-26 18:38:39 --> URI Class Initialized
INFO - 2020-02-26 18:38:39 --> URI Class Initialized
INFO - 2020-02-26 18:38:39 --> Router Class Initialized
INFO - 2020-02-26 18:38:39 --> Router Class Initialized
INFO - 2020-02-26 18:38:39 --> Router Class Initialized
INFO - 2020-02-26 18:38:39 --> Router Class Initialized
INFO - 2020-02-26 18:38:39 --> Router Class Initialized
INFO - 2020-02-26 18:38:39 --> Output Class Initialized
INFO - 2020-02-26 18:38:39 --> Output Class Initialized
INFO - 2020-02-26 18:38:39 --> Router Class Initialized
INFO - 2020-02-26 18:38:39 --> Output Class Initialized
INFO - 2020-02-26 18:38:39 --> Output Class Initialized
INFO - 2020-02-26 18:38:39 --> Security Class Initialized
INFO - 2020-02-26 18:38:39 --> Security Class Initialized
INFO - 2020-02-26 18:38:39 --> Output Class Initialized
INFO - 2020-02-26 18:38:39 --> Security Class Initialized
INFO - 2020-02-26 18:38:39 --> Security Class Initialized
INFO - 2020-02-26 18:38:39 --> Output Class Initialized
DEBUG - 2020-02-26 18:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:39 --> Security Class Initialized
DEBUG - 2020-02-26 18:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:39 --> Security Class Initialized
DEBUG - 2020-02-26 18:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:39 --> Input Class Initialized
INFO - 2020-02-26 18:38:39 --> Input Class Initialized
INFO - 2020-02-26 18:38:39 --> Input Class Initialized
DEBUG - 2020-02-26 18:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:39 --> Input Class Initialized
INFO - 2020-02-26 18:38:39 --> Input Class Initialized
INFO - 2020-02-26 18:38:39 --> Input Class Initialized
INFO - 2020-02-26 18:38:39 --> Language Class Initialized
INFO - 2020-02-26 18:38:39 --> Language Class Initialized
INFO - 2020-02-26 18:38:39 --> Language Class Initialized
INFO - 2020-02-26 18:38:39 --> Language Class Initialized
INFO - 2020-02-26 18:38:39 --> Language Class Initialized
INFO - 2020-02-26 18:38:39 --> Language Class Initialized
INFO - 2020-02-26 18:38:39 --> Loader Class Initialized
ERROR - 2020-02-26 18:38:39 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 18:38:39 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 18:38:39 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 18:38:39 --> Helper loaded: url_helper
INFO - 2020-02-26 18:38:39 --> Loader Class Initialized
ERROR - 2020-02-26 18:38:39 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 18:38:39 --> Helper loaded: string_helper
INFO - 2020-02-26 18:38:39 --> Helper loaded: url_helper
INFO - 2020-02-26 18:38:39 --> Config Class Initialized
INFO - 2020-02-26 18:38:39 --> Config Class Initialized
INFO - 2020-02-26 18:38:39 --> Config Class Initialized
INFO - 2020-02-26 18:38:39 --> Config Class Initialized
INFO - 2020-02-26 18:38:39 --> Hooks Class Initialized
INFO - 2020-02-26 18:38:39 --> Helper loaded: string_helper
INFO - 2020-02-26 18:38:39 --> Database Driver Class Initialized
INFO - 2020-02-26 18:38:39 --> Hooks Class Initialized
INFO - 2020-02-26 18:38:39 --> Hooks Class Initialized
INFO - 2020-02-26 18:38:39 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:38:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:38:39 --> Database Driver Class Initialized
INFO - 2020-02-26 18:38:39 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-26 18:38:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:38:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:38:39 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:38:39 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:39 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:39 --> Controller Class Initialized
INFO - 2020-02-26 18:38:39 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:39 --> URI Class Initialized
INFO - 2020-02-26 18:38:39 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:38:39 --> URI Class Initialized
INFO - 2020-02-26 18:38:39 --> URI Class Initialized
INFO - 2020-02-26 18:38:39 --> Router Class Initialized
INFO - 2020-02-26 18:38:39 --> URI Class Initialized
INFO - 2020-02-26 18:38:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:38:39 --> Router Class Initialized
INFO - 2020-02-26 18:38:39 --> Output Class Initialized
INFO - 2020-02-26 18:38:39 --> Router Class Initialized
INFO - 2020-02-26 18:38:39 --> Router Class Initialized
INFO - 2020-02-26 18:38:39 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:38:39 --> Security Class Initialized
INFO - 2020-02-26 18:38:39 --> Output Class Initialized
INFO - 2020-02-26 18:38:39 --> Output Class Initialized
INFO - 2020-02-26 18:38:39 --> Output Class Initialized
INFO - 2020-02-26 18:38:39 --> Security Class Initialized
INFO - 2020-02-26 18:38:39 --> Security Class Initialized
INFO - 2020-02-26 18:38:39 --> Helper loaded: form_helper
DEBUG - 2020-02-26 18:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:39 --> Security Class Initialized
INFO - 2020-02-26 18:38:39 --> Form Validation Class Initialized
INFO - 2020-02-26 18:38:39 --> Input Class Initialized
DEBUG - 2020-02-26 18:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:40 --> Input Class Initialized
INFO - 2020-02-26 18:38:40 --> Input Class Initialized
INFO - 2020-02-26 18:38:40 --> Input Class Initialized
INFO - 2020-02-26 18:38:40 --> Language Class Initialized
ERROR - 2020-02-26 18:38:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 18:38:40 --> Language Class Initialized
INFO - 2020-02-26 18:38:40 --> Language Class Initialized
INFO - 2020-02-26 18:38:40 --> Language Class Initialized
ERROR - 2020-02-26 18:38:40 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 18:38:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 18:38:40 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-26 18:38:40 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-26 18:38:40 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-26 18:38:40 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 18:38:40 --> Config Class Initialized
INFO - 2020-02-26 18:38:40 --> Hooks Class Initialized
INFO - 2020-02-26 18:38:40 --> Final output sent to browser
INFO - 2020-02-26 18:38:40 --> Config Class Initialized
INFO - 2020-02-26 18:38:40 --> Config Class Initialized
INFO - 2020-02-26 18:38:40 --> Config Class Initialized
INFO - 2020-02-26 18:38:40 --> Hooks Class Initialized
INFO - 2020-02-26 18:38:40 --> Hooks Class Initialized
INFO - 2020-02-26 18:38:40 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:38:40 --> Total execution time: 0.9797
DEBUG - 2020-02-26 18:38:40 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:40 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-26 18:38:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:38:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:38:40 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:40 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:40 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:40 --> Controller Class Initialized
INFO - 2020-02-26 18:38:40 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:40 --> URI Class Initialized
INFO - 2020-02-26 18:38:40 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:38:40 --> URI Class Initialized
INFO - 2020-02-26 18:38:40 --> URI Class Initialized
INFO - 2020-02-26 18:38:40 --> Router Class Initialized
INFO - 2020-02-26 18:38:40 --> URI Class Initialized
INFO - 2020-02-26 18:38:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:38:40 --> Router Class Initialized
INFO - 2020-02-26 18:38:40 --> Router Class Initialized
INFO - 2020-02-26 18:38:40 --> Router Class Initialized
INFO - 2020-02-26 18:38:40 --> Output Class Initialized
INFO - 2020-02-26 18:38:40 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:38:40 --> Output Class Initialized
INFO - 2020-02-26 18:38:40 --> Output Class Initialized
INFO - 2020-02-26 18:38:40 --> Output Class Initialized
INFO - 2020-02-26 18:38:40 --> Security Class Initialized
DEBUG - 2020-02-26 18:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:40 --> Security Class Initialized
INFO - 2020-02-26 18:38:40 --> Security Class Initialized
INFO - 2020-02-26 18:38:40 --> Helper loaded: form_helper
INFO - 2020-02-26 18:38:40 --> Security Class Initialized
INFO - 2020-02-26 18:38:40 --> Input Class Initialized
INFO - 2020-02-26 18:38:40 --> Form Validation Class Initialized
DEBUG - 2020-02-26 18:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:40 --> Input Class Initialized
INFO - 2020-02-26 18:38:40 --> Input Class Initialized
INFO - 2020-02-26 18:38:40 --> Input Class Initialized
INFO - 2020-02-26 18:38:40 --> Language Class Initialized
ERROR - 2020-02-26 18:38:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-26 18:38:40 --> Language Class Initialized
INFO - 2020-02-26 18:38:40 --> Language Class Initialized
ERROR - 2020-02-26 18:38:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 18:38:40 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 18:38:40 --> Language Class Initialized
INFO - 2020-02-26 18:38:40 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-26 18:38:40 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-26 18:38:40 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 18:38:40 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 18:38:40 --> Final output sent to browser
INFO - 2020-02-26 18:38:40 --> Config Class Initialized
INFO - 2020-02-26 18:38:40 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:38:40 --> Total execution time: 1.3928
DEBUG - 2020-02-26 18:38:40 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:40 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:40 --> URI Class Initialized
INFO - 2020-02-26 18:38:40 --> Router Class Initialized
INFO - 2020-02-26 18:38:40 --> Output Class Initialized
INFO - 2020-02-26 18:38:40 --> Security Class Initialized
DEBUG - 2020-02-26 18:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:40 --> Input Class Initialized
INFO - 2020-02-26 18:38:40 --> Language Class Initialized
ERROR - 2020-02-26 18:38:40 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 18:38:41 --> Config Class Initialized
INFO - 2020-02-26 18:38:41 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:38:41 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:41 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:41 --> URI Class Initialized
INFO - 2020-02-26 18:38:41 --> Router Class Initialized
INFO - 2020-02-26 18:38:41 --> Output Class Initialized
INFO - 2020-02-26 18:38:41 --> Security Class Initialized
DEBUG - 2020-02-26 18:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:41 --> Input Class Initialized
INFO - 2020-02-26 18:38:41 --> Language Class Initialized
ERROR - 2020-02-26 18:38:41 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 18:38:41 --> Config Class Initialized
INFO - 2020-02-26 18:38:41 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:38:41 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:41 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:41 --> URI Class Initialized
INFO - 2020-02-26 18:38:41 --> Router Class Initialized
INFO - 2020-02-26 18:38:41 --> Output Class Initialized
INFO - 2020-02-26 18:38:41 --> Security Class Initialized
DEBUG - 2020-02-26 18:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:41 --> Input Class Initialized
INFO - 2020-02-26 18:38:41 --> Language Class Initialized
ERROR - 2020-02-26 18:38:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 18:38:41 --> Config Class Initialized
INFO - 2020-02-26 18:38:41 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:38:41 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:41 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:42 --> URI Class Initialized
INFO - 2020-02-26 18:38:42 --> Router Class Initialized
INFO - 2020-02-26 18:38:42 --> Output Class Initialized
INFO - 2020-02-26 18:38:42 --> Security Class Initialized
DEBUG - 2020-02-26 18:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:42 --> Input Class Initialized
INFO - 2020-02-26 18:38:42 --> Language Class Initialized
ERROR - 2020-02-26 18:38:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 18:38:42 --> Config Class Initialized
INFO - 2020-02-26 18:38:42 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:38:42 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:42 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:42 --> URI Class Initialized
INFO - 2020-02-26 18:38:42 --> Router Class Initialized
INFO - 2020-02-26 18:38:42 --> Output Class Initialized
INFO - 2020-02-26 18:38:42 --> Security Class Initialized
DEBUG - 2020-02-26 18:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:42 --> Input Class Initialized
INFO - 2020-02-26 18:38:42 --> Language Class Initialized
ERROR - 2020-02-26 18:38:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 18:38:42 --> Config Class Initialized
INFO - 2020-02-26 18:38:42 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:38:42 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:42 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:42 --> URI Class Initialized
INFO - 2020-02-26 18:38:42 --> Router Class Initialized
INFO - 2020-02-26 18:38:42 --> Output Class Initialized
INFO - 2020-02-26 18:38:42 --> Security Class Initialized
DEBUG - 2020-02-26 18:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:42 --> Input Class Initialized
INFO - 2020-02-26 18:38:43 --> Language Class Initialized
ERROR - 2020-02-26 18:38:43 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 18:38:43 --> Config Class Initialized
INFO - 2020-02-26 18:38:43 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:38:43 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:43 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:43 --> URI Class Initialized
INFO - 2020-02-26 18:38:43 --> Router Class Initialized
INFO - 2020-02-26 18:38:43 --> Output Class Initialized
INFO - 2020-02-26 18:38:43 --> Security Class Initialized
DEBUG - 2020-02-26 18:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:43 --> Input Class Initialized
INFO - 2020-02-26 18:38:43 --> Language Class Initialized
ERROR - 2020-02-26 18:38:43 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 18:38:43 --> Config Class Initialized
INFO - 2020-02-26 18:38:43 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:38:43 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:43 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:43 --> URI Class Initialized
INFO - 2020-02-26 18:38:43 --> Router Class Initialized
INFO - 2020-02-26 18:38:43 --> Output Class Initialized
INFO - 2020-02-26 18:38:43 --> Security Class Initialized
DEBUG - 2020-02-26 18:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:43 --> Input Class Initialized
INFO - 2020-02-26 18:38:43 --> Language Class Initialized
ERROR - 2020-02-26 18:38:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 18:38:43 --> Config Class Initialized
INFO - 2020-02-26 18:38:44 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:38:44 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:38:44 --> Utf8 Class Initialized
INFO - 2020-02-26 18:38:44 --> URI Class Initialized
INFO - 2020-02-26 18:38:44 --> Router Class Initialized
INFO - 2020-02-26 18:38:44 --> Output Class Initialized
INFO - 2020-02-26 18:38:44 --> Security Class Initialized
DEBUG - 2020-02-26 18:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:38:44 --> Input Class Initialized
INFO - 2020-02-26 18:38:44 --> Language Class Initialized
ERROR - 2020-02-26 18:38:44 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 18:39:13 --> Config Class Initialized
INFO - 2020-02-26 18:39:13 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:39:13 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:39:13 --> Utf8 Class Initialized
INFO - 2020-02-26 18:39:13 --> URI Class Initialized
INFO - 2020-02-26 18:39:13 --> Router Class Initialized
INFO - 2020-02-26 18:39:13 --> Output Class Initialized
INFO - 2020-02-26 18:39:13 --> Security Class Initialized
DEBUG - 2020-02-26 18:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:39:14 --> Input Class Initialized
INFO - 2020-02-26 18:39:14 --> Language Class Initialized
INFO - 2020-02-26 18:39:14 --> Loader Class Initialized
INFO - 2020-02-26 18:39:14 --> Helper loaded: url_helper
INFO - 2020-02-26 18:39:14 --> Helper loaded: string_helper
INFO - 2020-02-26 18:39:14 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:39:14 --> Controller Class Initialized
INFO - 2020-02-26 18:39:14 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:39:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:39:14 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:39:14 --> Helper loaded: form_helper
INFO - 2020-02-26 18:39:14 --> Form Validation Class Initialized
INFO - 2020-02-26 18:39:18 --> Config Class Initialized
INFO - 2020-02-26 18:39:18 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:39:18 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:39:18 --> Utf8 Class Initialized
INFO - 2020-02-26 18:39:18 --> URI Class Initialized
INFO - 2020-02-26 18:39:18 --> Router Class Initialized
INFO - 2020-02-26 18:39:18 --> Output Class Initialized
INFO - 2020-02-26 18:39:18 --> Security Class Initialized
DEBUG - 2020-02-26 18:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:39:19 --> Input Class Initialized
INFO - 2020-02-26 18:39:19 --> Language Class Initialized
INFO - 2020-02-26 18:39:19 --> Loader Class Initialized
INFO - 2020-02-26 18:39:19 --> Helper loaded: url_helper
INFO - 2020-02-26 18:39:19 --> Helper loaded: string_helper
INFO - 2020-02-26 18:39:19 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:39:19 --> Controller Class Initialized
INFO - 2020-02-26 18:39:19 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:39:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:39:19 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:39:19 --> Helper loaded: form_helper
INFO - 2020-02-26 18:39:19 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:39:19 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 18:39:19 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 18:39:19 --> Final output sent to browser
DEBUG - 2020-02-26 18:39:19 --> Total execution time: 0.9035
INFO - 2020-02-26 18:39:35 --> Config Class Initialized
INFO - 2020-02-26 18:39:35 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:39:35 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:39:35 --> Utf8 Class Initialized
INFO - 2020-02-26 18:39:35 --> URI Class Initialized
INFO - 2020-02-26 18:39:35 --> Router Class Initialized
INFO - 2020-02-26 18:39:35 --> Output Class Initialized
INFO - 2020-02-26 18:39:35 --> Security Class Initialized
DEBUG - 2020-02-26 18:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:39:35 --> Input Class Initialized
INFO - 2020-02-26 18:39:35 --> Language Class Initialized
INFO - 2020-02-26 18:39:35 --> Loader Class Initialized
INFO - 2020-02-26 18:39:35 --> Helper loaded: url_helper
INFO - 2020-02-26 18:39:35 --> Helper loaded: string_helper
INFO - 2020-02-26 18:39:35 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:39:35 --> Controller Class Initialized
INFO - 2020-02-26 18:39:35 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:39:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:39:35 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:39:35 --> Helper loaded: form_helper
INFO - 2020-02-26 18:39:36 --> Form Validation Class Initialized
INFO - 2020-02-26 18:39:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-26 18:39:36 --> Config Class Initialized
INFO - 2020-02-26 18:39:36 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:39:36 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:39:36 --> Utf8 Class Initialized
INFO - 2020-02-26 18:39:36 --> URI Class Initialized
INFO - 2020-02-26 18:39:36 --> Router Class Initialized
INFO - 2020-02-26 18:39:36 --> Output Class Initialized
INFO - 2020-02-26 18:39:36 --> Security Class Initialized
DEBUG - 2020-02-26 18:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:39:36 --> Input Class Initialized
INFO - 2020-02-26 18:39:36 --> Language Class Initialized
INFO - 2020-02-26 18:39:36 --> Loader Class Initialized
INFO - 2020-02-26 18:39:36 --> Helper loaded: url_helper
INFO - 2020-02-26 18:39:36 --> Helper loaded: string_helper
INFO - 2020-02-26 18:39:36 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:39:36 --> Controller Class Initialized
INFO - 2020-02-26 18:39:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 18:39:36 --> Pagination Class Initialized
INFO - 2020-02-26 18:39:36 --> Model "M_show" initialized
INFO - 2020-02-26 18:39:36 --> Helper loaded: form_helper
INFO - 2020-02-26 18:39:36 --> Form Validation Class Initialized
INFO - 2020-02-26 18:39:37 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 18:39:37 --> Final output sent to browser
DEBUG - 2020-02-26 18:39:37 --> Total execution time: 0.9439
INFO - 2020-02-26 18:39:37 --> Config Class Initialized
INFO - 2020-02-26 18:39:37 --> Config Class Initialized
INFO - 2020-02-26 18:39:37 --> Hooks Class Initialized
INFO - 2020-02-26 18:39:37 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:39:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:39:37 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:39:37 --> Utf8 Class Initialized
INFO - 2020-02-26 18:39:37 --> Utf8 Class Initialized
INFO - 2020-02-26 18:39:37 --> URI Class Initialized
INFO - 2020-02-26 18:39:37 --> URI Class Initialized
INFO - 2020-02-26 18:39:37 --> Router Class Initialized
INFO - 2020-02-26 18:39:37 --> Router Class Initialized
INFO - 2020-02-26 18:39:37 --> Output Class Initialized
INFO - 2020-02-26 18:39:37 --> Output Class Initialized
INFO - 2020-02-26 18:39:37 --> Security Class Initialized
INFO - 2020-02-26 18:39:37 --> Security Class Initialized
DEBUG - 2020-02-26 18:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:39:37 --> Input Class Initialized
INFO - 2020-02-26 18:39:37 --> Input Class Initialized
INFO - 2020-02-26 18:39:37 --> Language Class Initialized
INFO - 2020-02-26 18:39:37 --> Language Class Initialized
ERROR - 2020-02-26 18:39:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-26 18:39:37 --> 404 Page Not Found: Assets/js
INFO - 2020-02-26 18:39:38 --> Config Class Initialized
INFO - 2020-02-26 18:39:38 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:39:38 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:39:38 --> Utf8 Class Initialized
INFO - 2020-02-26 18:39:38 --> URI Class Initialized
INFO - 2020-02-26 18:39:38 --> Router Class Initialized
INFO - 2020-02-26 18:39:38 --> Output Class Initialized
INFO - 2020-02-26 18:39:38 --> Security Class Initialized
DEBUG - 2020-02-26 18:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:39:38 --> Input Class Initialized
INFO - 2020-02-26 18:39:38 --> Language Class Initialized
ERROR - 2020-02-26 18:39:38 --> 404 Page Not Found: Assets/js
INFO - 2020-02-26 18:43:59 --> Config Class Initialized
INFO - 2020-02-26 18:43:59 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:43:59 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:43:59 --> Utf8 Class Initialized
INFO - 2020-02-26 18:43:59 --> URI Class Initialized
INFO - 2020-02-26 18:43:59 --> Router Class Initialized
INFO - 2020-02-26 18:43:59 --> Output Class Initialized
INFO - 2020-02-26 18:43:59 --> Security Class Initialized
DEBUG - 2020-02-26 18:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:43:59 --> Input Class Initialized
INFO - 2020-02-26 18:43:59 --> Language Class Initialized
INFO - 2020-02-26 18:43:59 --> Loader Class Initialized
INFO - 2020-02-26 18:43:59 --> Helper loaded: url_helper
INFO - 2020-02-26 18:43:59 --> Helper loaded: string_helper
INFO - 2020-02-26 18:43:59 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:43:59 --> Controller Class Initialized
INFO - 2020-02-26 18:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 18:43:59 --> Pagination Class Initialized
INFO - 2020-02-26 18:43:59 --> Model "M_show" initialized
INFO - 2020-02-26 18:43:59 --> Helper loaded: form_helper
INFO - 2020-02-26 18:43:59 --> Form Validation Class Initialized
INFO - 2020-02-26 18:43:59 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 18:44:00 --> Final output sent to browser
DEBUG - 2020-02-26 18:44:00 --> Total execution time: 0.9266
INFO - 2020-02-26 18:44:00 --> Config Class Initialized
INFO - 2020-02-26 18:44:00 --> Config Class Initialized
INFO - 2020-02-26 18:44:00 --> Hooks Class Initialized
INFO - 2020-02-26 18:44:00 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:44:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:44:00 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:00 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:00 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:00 --> URI Class Initialized
INFO - 2020-02-26 18:44:00 --> URI Class Initialized
INFO - 2020-02-26 18:44:00 --> Router Class Initialized
INFO - 2020-02-26 18:44:00 --> Router Class Initialized
INFO - 2020-02-26 18:44:00 --> Output Class Initialized
INFO - 2020-02-26 18:44:00 --> Output Class Initialized
INFO - 2020-02-26 18:44:00 --> Security Class Initialized
INFO - 2020-02-26 18:44:00 --> Security Class Initialized
DEBUG - 2020-02-26 18:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:00 --> Input Class Initialized
INFO - 2020-02-26 18:44:00 --> Input Class Initialized
INFO - 2020-02-26 18:44:00 --> Language Class Initialized
INFO - 2020-02-26 18:44:00 --> Language Class Initialized
ERROR - 2020-02-26 18:44:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-26 18:44:00 --> 404 Page Not Found: Assets/js
INFO - 2020-02-26 18:44:05 --> Config Class Initialized
INFO - 2020-02-26 18:44:05 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:44:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:05 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:05 --> URI Class Initialized
INFO - 2020-02-26 18:44:05 --> Router Class Initialized
INFO - 2020-02-26 18:44:05 --> Output Class Initialized
INFO - 2020-02-26 18:44:05 --> Security Class Initialized
DEBUG - 2020-02-26 18:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:05 --> Input Class Initialized
INFO - 2020-02-26 18:44:05 --> Language Class Initialized
INFO - 2020-02-26 18:44:05 --> Loader Class Initialized
INFO - 2020-02-26 18:44:05 --> Helper loaded: url_helper
INFO - 2020-02-26 18:44:05 --> Helper loaded: string_helper
INFO - 2020-02-26 18:44:05 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:44:05 --> Controller Class Initialized
INFO - 2020-02-26 18:44:05 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:44:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:44:05 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:44:05 --> Helper loaded: form_helper
INFO - 2020-02-26 18:44:06 --> Form Validation Class Initialized
INFO - 2020-02-26 18:44:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:44:06 --> Final output sent to browser
DEBUG - 2020-02-26 18:44:06 --> Total execution time: 0.8307
INFO - 2020-02-26 18:44:06 --> Config Class Initialized
INFO - 2020-02-26 18:44:06 --> Config Class Initialized
INFO - 2020-02-26 18:44:06 --> Config Class Initialized
INFO - 2020-02-26 18:44:06 --> Config Class Initialized
INFO - 2020-02-26 18:44:06 --> Config Class Initialized
INFO - 2020-02-26 18:44:06 --> Hooks Class Initialized
INFO - 2020-02-26 18:44:06 --> Hooks Class Initialized
INFO - 2020-02-26 18:44:06 --> Hooks Class Initialized
INFO - 2020-02-26 18:44:06 --> Hooks Class Initialized
INFO - 2020-02-26 18:44:06 --> Hooks Class Initialized
INFO - 2020-02-26 18:44:06 --> Config Class Initialized
INFO - 2020-02-26 18:44:06 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:44:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:06 --> Utf8 Class Initialized
DEBUG - 2020-02-26 18:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:44:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:06 --> URI Class Initialized
INFO - 2020-02-26 18:44:06 --> URI Class Initialized
INFO - 2020-02-26 18:44:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:06 --> URI Class Initialized
INFO - 2020-02-26 18:44:06 --> URI Class Initialized
INFO - 2020-02-26 18:44:06 --> Router Class Initialized
INFO - 2020-02-26 18:44:06 --> Router Class Initialized
INFO - 2020-02-26 18:44:06 --> URI Class Initialized
INFO - 2020-02-26 18:44:06 --> URI Class Initialized
INFO - 2020-02-26 18:44:06 --> Router Class Initialized
INFO - 2020-02-26 18:44:06 --> Router Class Initialized
INFO - 2020-02-26 18:44:06 --> Router Class Initialized
INFO - 2020-02-26 18:44:06 --> Router Class Initialized
INFO - 2020-02-26 18:44:06 --> Output Class Initialized
INFO - 2020-02-26 18:44:06 --> Output Class Initialized
INFO - 2020-02-26 18:44:06 --> Output Class Initialized
INFO - 2020-02-26 18:44:06 --> Security Class Initialized
INFO - 2020-02-26 18:44:06 --> Security Class Initialized
INFO - 2020-02-26 18:44:06 --> Security Class Initialized
INFO - 2020-02-26 18:44:06 --> Output Class Initialized
INFO - 2020-02-26 18:44:06 --> Output Class Initialized
INFO - 2020-02-26 18:44:06 --> Output Class Initialized
DEBUG - 2020-02-26 18:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:06 --> Security Class Initialized
INFO - 2020-02-26 18:44:06 --> Security Class Initialized
DEBUG - 2020-02-26 18:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:06 --> Security Class Initialized
INFO - 2020-02-26 18:44:06 --> Input Class Initialized
INFO - 2020-02-26 18:44:06 --> Input Class Initialized
INFO - 2020-02-26 18:44:06 --> Input Class Initialized
DEBUG - 2020-02-26 18:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:06 --> Input Class Initialized
INFO - 2020-02-26 18:44:06 --> Input Class Initialized
INFO - 2020-02-26 18:44:06 --> Input Class Initialized
INFO - 2020-02-26 18:44:06 --> Language Class Initialized
INFO - 2020-02-26 18:44:06 --> Language Class Initialized
INFO - 2020-02-26 18:44:06 --> Language Class Initialized
INFO - 2020-02-26 18:44:06 --> Language Class Initialized
INFO - 2020-02-26 18:44:06 --> Language Class Initialized
ERROR - 2020-02-26 18:44:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 18:44:06 --> Language Class Initialized
INFO - 2020-02-26 18:44:06 --> Loader Class Initialized
INFO - 2020-02-26 18:44:06 --> Loader Class Initialized
ERROR - 2020-02-26 18:44:06 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-26 18:44:06 --> Helper loaded: url_helper
INFO - 2020-02-26 18:44:06 --> Helper loaded: url_helper
ERROR - 2020-02-26 18:44:06 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-26 18:44:06 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-26 18:44:06 --> Config Class Initialized
INFO - 2020-02-26 18:44:06 --> Hooks Class Initialized
INFO - 2020-02-26 18:44:06 --> Helper loaded: string_helper
INFO - 2020-02-26 18:44:06 --> Helper loaded: string_helper
INFO - 2020-02-26 18:44:06 --> Config Class Initialized
INFO - 2020-02-26 18:44:06 --> Config Class Initialized
INFO - 2020-02-26 18:44:06 --> Config Class Initialized
INFO - 2020-02-26 18:44:06 --> Hooks Class Initialized
INFO - 2020-02-26 18:44:06 --> Hooks Class Initialized
INFO - 2020-02-26 18:44:06 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:44:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:06 --> Database Driver Class Initialized
INFO - 2020-02-26 18:44:06 --> Database Driver Class Initialized
INFO - 2020-02-26 18:44:06 --> Utf8 Class Initialized
DEBUG - 2020-02-26 18:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-26 18:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:44:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:06 --> URI Class Initialized
INFO - 2020-02-26 18:44:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:06 --> Controller Class Initialized
INFO - 2020-02-26 18:44:06 --> URI Class Initialized
INFO - 2020-02-26 18:44:06 --> URI Class Initialized
INFO - 2020-02-26 18:44:06 --> URI Class Initialized
INFO - 2020-02-26 18:44:06 --> Router Class Initialized
INFO - 2020-02-26 18:44:06 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:44:06 --> Router Class Initialized
INFO - 2020-02-26 18:44:06 --> Router Class Initialized
INFO - 2020-02-26 18:44:06 --> Router Class Initialized
INFO - 2020-02-26 18:44:06 --> Output Class Initialized
INFO - 2020-02-26 18:44:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:44:06 --> Security Class Initialized
INFO - 2020-02-26 18:44:06 --> Output Class Initialized
INFO - 2020-02-26 18:44:06 --> Output Class Initialized
INFO - 2020-02-26 18:44:06 --> Output Class Initialized
INFO - 2020-02-26 18:44:06 --> Model "M_pesan" initialized
DEBUG - 2020-02-26 18:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:06 --> Security Class Initialized
INFO - 2020-02-26 18:44:06 --> Security Class Initialized
INFO - 2020-02-26 18:44:06 --> Security Class Initialized
INFO - 2020-02-26 18:44:06 --> Input Class Initialized
DEBUG - 2020-02-26 18:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:06 --> Helper loaded: form_helper
INFO - 2020-02-26 18:44:06 --> Input Class Initialized
INFO - 2020-02-26 18:44:06 --> Input Class Initialized
INFO - 2020-02-26 18:44:06 --> Input Class Initialized
INFO - 2020-02-26 18:44:06 --> Form Validation Class Initialized
INFO - 2020-02-26 18:44:06 --> Language Class Initialized
INFO - 2020-02-26 18:44:07 --> Language Class Initialized
INFO - 2020-02-26 18:44:07 --> Language Class Initialized
INFO - 2020-02-26 18:44:07 --> Language Class Initialized
ERROR - 2020-02-26 18:44:07 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-26 18:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 18:44:07 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 18:44:07 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-26 18:44:07 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-26 18:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 18:44:07 --> Config Class Initialized
INFO - 2020-02-26 18:44:07 --> Hooks Class Initialized
INFO - 2020-02-26 18:44:07 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:44:07 --> Config Class Initialized
INFO - 2020-02-26 18:44:07 --> Config Class Initialized
INFO - 2020-02-26 18:44:07 --> Config Class Initialized
INFO - 2020-02-26 18:44:07 --> Hooks Class Initialized
INFO - 2020-02-26 18:44:07 --> Final output sent to browser
INFO - 2020-02-26 18:44:07 --> Hooks Class Initialized
INFO - 2020-02-26 18:44:07 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:44:07 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:07 --> Utf8 Class Initialized
DEBUG - 2020-02-26 18:44:07 --> Total execution time: 1.0009
DEBUG - 2020-02-26 18:44:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:44:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:44:07 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:07 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:07 --> URI Class Initialized
INFO - 2020-02-26 18:44:07 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:07 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:07 --> URI Class Initialized
INFO - 2020-02-26 18:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:44:07 --> Router Class Initialized
INFO - 2020-02-26 18:44:07 --> Controller Class Initialized
INFO - 2020-02-26 18:44:07 --> Output Class Initialized
INFO - 2020-02-26 18:44:07 --> URI Class Initialized
INFO - 2020-02-26 18:44:07 --> Router Class Initialized
INFO - 2020-02-26 18:44:07 --> URI Class Initialized
INFO - 2020-02-26 18:44:07 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:44:07 --> Router Class Initialized
INFO - 2020-02-26 18:44:07 --> Security Class Initialized
INFO - 2020-02-26 18:44:07 --> Output Class Initialized
INFO - 2020-02-26 18:44:07 --> Router Class Initialized
INFO - 2020-02-26 18:44:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:44:07 --> Output Class Initialized
INFO - 2020-02-26 18:44:07 --> Output Class Initialized
INFO - 2020-02-26 18:44:07 --> Security Class Initialized
DEBUG - 2020-02-26 18:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:07 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:44:07 --> Security Class Initialized
INFO - 2020-02-26 18:44:07 --> Input Class Initialized
INFO - 2020-02-26 18:44:07 --> Security Class Initialized
DEBUG - 2020-02-26 18:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:07 --> Input Class Initialized
INFO - 2020-02-26 18:44:07 --> Language Class Initialized
DEBUG - 2020-02-26 18:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:07 --> Helper loaded: form_helper
INFO - 2020-02-26 18:44:07 --> Input Class Initialized
INFO - 2020-02-26 18:44:07 --> Form Validation Class Initialized
INFO - 2020-02-26 18:44:07 --> Input Class Initialized
INFO - 2020-02-26 18:44:07 --> Language Class Initialized
ERROR - 2020-02-26 18:44:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 18:44:07 --> Language Class Initialized
INFO - 2020-02-26 18:44:07 --> Language Class Initialized
ERROR - 2020-02-26 18:44:07 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-26 18:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 18:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-26 18:44:07 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-26 18:44:07 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 18:44:07 --> Config Class Initialized
INFO - 2020-02-26 18:44:07 --> Hooks Class Initialized
INFO - 2020-02-26 18:44:07 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:44:07 --> Final output sent to browser
DEBUG - 2020-02-26 18:44:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:44:07 --> Total execution time: 1.5832
INFO - 2020-02-26 18:44:07 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:07 --> URI Class Initialized
INFO - 2020-02-26 18:44:07 --> Router Class Initialized
INFO - 2020-02-26 18:44:07 --> Output Class Initialized
INFO - 2020-02-26 18:44:07 --> Security Class Initialized
DEBUG - 2020-02-26 18:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:08 --> Input Class Initialized
INFO - 2020-02-26 18:44:08 --> Language Class Initialized
ERROR - 2020-02-26 18:44:08 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-26 18:44:08 --> Config Class Initialized
INFO - 2020-02-26 18:44:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:44:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:08 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:08 --> URI Class Initialized
INFO - 2020-02-26 18:44:08 --> Router Class Initialized
INFO - 2020-02-26 18:44:08 --> Output Class Initialized
INFO - 2020-02-26 18:44:08 --> Security Class Initialized
DEBUG - 2020-02-26 18:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:08 --> Input Class Initialized
INFO - 2020-02-26 18:44:08 --> Language Class Initialized
ERROR - 2020-02-26 18:44:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 18:44:08 --> Config Class Initialized
INFO - 2020-02-26 18:44:08 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:44:08 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:08 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:08 --> URI Class Initialized
INFO - 2020-02-26 18:44:08 --> Router Class Initialized
INFO - 2020-02-26 18:44:08 --> Output Class Initialized
INFO - 2020-02-26 18:44:08 --> Security Class Initialized
DEBUG - 2020-02-26 18:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:08 --> Input Class Initialized
INFO - 2020-02-26 18:44:08 --> Language Class Initialized
ERROR - 2020-02-26 18:44:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-26 18:44:09 --> Config Class Initialized
INFO - 2020-02-26 18:44:09 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:44:09 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:09 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:09 --> URI Class Initialized
INFO - 2020-02-26 18:44:09 --> Router Class Initialized
INFO - 2020-02-26 18:44:09 --> Output Class Initialized
INFO - 2020-02-26 18:44:09 --> Security Class Initialized
DEBUG - 2020-02-26 18:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:09 --> Input Class Initialized
INFO - 2020-02-26 18:44:09 --> Language Class Initialized
ERROR - 2020-02-26 18:44:09 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-26 18:44:09 --> Config Class Initialized
INFO - 2020-02-26 18:44:09 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:44:09 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:09 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:09 --> URI Class Initialized
INFO - 2020-02-26 18:44:09 --> Router Class Initialized
INFO - 2020-02-26 18:44:09 --> Output Class Initialized
INFO - 2020-02-26 18:44:09 --> Security Class Initialized
DEBUG - 2020-02-26 18:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:09 --> Input Class Initialized
INFO - 2020-02-26 18:44:09 --> Language Class Initialized
ERROR - 2020-02-26 18:44:09 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-26 18:44:09 --> Config Class Initialized
INFO - 2020-02-26 18:44:09 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:44:09 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:09 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:09 --> URI Class Initialized
INFO - 2020-02-26 18:44:10 --> Router Class Initialized
INFO - 2020-02-26 18:44:10 --> Output Class Initialized
INFO - 2020-02-26 18:44:10 --> Security Class Initialized
DEBUG - 2020-02-26 18:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:10 --> Input Class Initialized
INFO - 2020-02-26 18:44:10 --> Language Class Initialized
ERROR - 2020-02-26 18:44:10 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-26 18:44:10 --> Config Class Initialized
INFO - 2020-02-26 18:44:10 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:44:10 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:10 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:10 --> URI Class Initialized
INFO - 2020-02-26 18:44:10 --> Router Class Initialized
INFO - 2020-02-26 18:44:10 --> Output Class Initialized
INFO - 2020-02-26 18:44:10 --> Security Class Initialized
DEBUG - 2020-02-26 18:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:10 --> Input Class Initialized
INFO - 2020-02-26 18:44:10 --> Language Class Initialized
ERROR - 2020-02-26 18:44:10 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-26 18:44:27 --> Config Class Initialized
INFO - 2020-02-26 18:44:27 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:44:27 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:44:27 --> Utf8 Class Initialized
INFO - 2020-02-26 18:44:27 --> URI Class Initialized
INFO - 2020-02-26 18:44:27 --> Router Class Initialized
INFO - 2020-02-26 18:44:27 --> Output Class Initialized
INFO - 2020-02-26 18:44:27 --> Security Class Initialized
DEBUG - 2020-02-26 18:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:44:27 --> Input Class Initialized
INFO - 2020-02-26 18:44:27 --> Language Class Initialized
INFO - 2020-02-26 18:44:27 --> Loader Class Initialized
INFO - 2020-02-26 18:44:27 --> Helper loaded: url_helper
INFO - 2020-02-26 18:44:27 --> Helper loaded: string_helper
INFO - 2020-02-26 18:44:27 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:44:27 --> Controller Class Initialized
INFO - 2020-02-26 18:44:27 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:44:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:44:28 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:44:28 --> Helper loaded: form_helper
INFO - 2020-02-26 18:44:28 --> Form Validation Class Initialized
INFO - 2020-02-26 18:45:10 --> Config Class Initialized
INFO - 2020-02-26 18:45:11 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:45:11 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:45:11 --> Utf8 Class Initialized
INFO - 2020-02-26 18:45:11 --> URI Class Initialized
INFO - 2020-02-26 18:45:11 --> Router Class Initialized
INFO - 2020-02-26 18:45:11 --> Output Class Initialized
INFO - 2020-02-26 18:45:11 --> Security Class Initialized
DEBUG - 2020-02-26 18:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:45:11 --> Input Class Initialized
INFO - 2020-02-26 18:45:11 --> Language Class Initialized
INFO - 2020-02-26 18:45:11 --> Loader Class Initialized
INFO - 2020-02-26 18:45:11 --> Helper loaded: url_helper
INFO - 2020-02-26 18:45:11 --> Helper loaded: string_helper
INFO - 2020-02-26 18:45:11 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:45:11 --> Controller Class Initialized
INFO - 2020-02-26 18:45:11 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:45:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:45:11 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:45:11 --> Helper loaded: form_helper
INFO - 2020-02-26 18:45:11 --> Form Validation Class Initialized
INFO - 2020-02-26 18:45:15 --> Config Class Initialized
INFO - 2020-02-26 18:45:15 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:45:15 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:45:15 --> Utf8 Class Initialized
INFO - 2020-02-26 18:45:15 --> URI Class Initialized
INFO - 2020-02-26 18:45:15 --> Router Class Initialized
INFO - 2020-02-26 18:45:15 --> Output Class Initialized
INFO - 2020-02-26 18:45:15 --> Security Class Initialized
DEBUG - 2020-02-26 18:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:45:15 --> Input Class Initialized
INFO - 2020-02-26 18:45:15 --> Language Class Initialized
INFO - 2020-02-26 18:45:15 --> Loader Class Initialized
INFO - 2020-02-26 18:45:15 --> Helper loaded: url_helper
INFO - 2020-02-26 18:45:15 --> Helper loaded: string_helper
INFO - 2020-02-26 18:45:15 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:45:16 --> Controller Class Initialized
INFO - 2020-02-26 18:45:16 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:45:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:45:16 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:45:16 --> Helper loaded: form_helper
INFO - 2020-02-26 18:45:16 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:45:16 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 32
ERROR - 2020-02-26 18:45:16 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 18:45:16 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 18:45:16 --> Final output sent to browser
DEBUG - 2020-02-26 18:45:16 --> Total execution time: 0.8747
INFO - 2020-02-26 18:47:11 --> Config Class Initialized
INFO - 2020-02-26 18:47:11 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:47:11 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:47:11 --> Utf8 Class Initialized
INFO - 2020-02-26 18:47:11 --> URI Class Initialized
INFO - 2020-02-26 18:47:11 --> Router Class Initialized
INFO - 2020-02-26 18:47:11 --> Output Class Initialized
INFO - 2020-02-26 18:47:12 --> Security Class Initialized
DEBUG - 2020-02-26 18:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:47:12 --> Input Class Initialized
INFO - 2020-02-26 18:47:12 --> Language Class Initialized
INFO - 2020-02-26 18:47:12 --> Loader Class Initialized
INFO - 2020-02-26 18:47:12 --> Helper loaded: url_helper
INFO - 2020-02-26 18:47:12 --> Helper loaded: string_helper
INFO - 2020-02-26 18:47:12 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:47:12 --> Controller Class Initialized
INFO - 2020-02-26 18:47:12 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:47:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:47:12 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:47:12 --> Helper loaded: form_helper
INFO - 2020-02-26 18:47:12 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:47:12 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 32
ERROR - 2020-02-26 18:47:12 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 18:47:12 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 18:47:12 --> Final output sent to browser
DEBUG - 2020-02-26 18:47:12 --> Total execution time: 0.8938
INFO - 2020-02-26 18:47:30 --> Config Class Initialized
INFO - 2020-02-26 18:47:30 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:47:30 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:47:30 --> Utf8 Class Initialized
INFO - 2020-02-26 18:47:30 --> URI Class Initialized
INFO - 2020-02-26 18:47:30 --> Router Class Initialized
INFO - 2020-02-26 18:47:30 --> Output Class Initialized
INFO - 2020-02-26 18:47:30 --> Security Class Initialized
DEBUG - 2020-02-26 18:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:47:30 --> Input Class Initialized
INFO - 2020-02-26 18:47:30 --> Language Class Initialized
INFO - 2020-02-26 18:47:30 --> Loader Class Initialized
INFO - 2020-02-26 18:47:30 --> Helper loaded: url_helper
INFO - 2020-02-26 18:47:30 --> Helper loaded: string_helper
INFO - 2020-02-26 18:47:30 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:47:30 --> Controller Class Initialized
INFO - 2020-02-26 18:47:30 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:47:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:47:30 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:47:30 --> Helper loaded: form_helper
INFO - 2020-02-26 18:47:30 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:47:30 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 32
ERROR - 2020-02-26 18:47:30 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 18:47:30 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 18:47:30 --> Final output sent to browser
DEBUG - 2020-02-26 18:47:30 --> Total execution time: 0.8857
INFO - 2020-02-26 18:48:06 --> Config Class Initialized
INFO - 2020-02-26 18:48:06 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:48:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:48:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:48:07 --> URI Class Initialized
INFO - 2020-02-26 18:48:07 --> Router Class Initialized
INFO - 2020-02-26 18:48:07 --> Output Class Initialized
INFO - 2020-02-26 18:48:07 --> Security Class Initialized
DEBUG - 2020-02-26 18:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:48:07 --> Input Class Initialized
INFO - 2020-02-26 18:48:07 --> Language Class Initialized
INFO - 2020-02-26 18:48:07 --> Loader Class Initialized
INFO - 2020-02-26 18:48:07 --> Helper loaded: url_helper
INFO - 2020-02-26 18:48:07 --> Helper loaded: string_helper
INFO - 2020-02-26 18:48:07 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:48:07 --> Controller Class Initialized
INFO - 2020-02-26 18:48:07 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:48:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:48:07 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:48:07 --> Helper loaded: form_helper
INFO - 2020-02-26 18:48:07 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:48:07 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 32
ERROR - 2020-02-26 18:48:07 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 18:48:07 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 18:48:07 --> Final output sent to browser
DEBUG - 2020-02-26 18:48:07 --> Total execution time: 0.9124
INFO - 2020-02-26 18:48:14 --> Config Class Initialized
INFO - 2020-02-26 18:48:14 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:48:14 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:48:14 --> Utf8 Class Initialized
INFO - 2020-02-26 18:48:14 --> URI Class Initialized
INFO - 2020-02-26 18:48:14 --> Router Class Initialized
INFO - 2020-02-26 18:48:14 --> Output Class Initialized
INFO - 2020-02-26 18:48:15 --> Security Class Initialized
DEBUG - 2020-02-26 18:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:48:15 --> Input Class Initialized
INFO - 2020-02-26 18:48:15 --> Language Class Initialized
INFO - 2020-02-26 18:48:15 --> Loader Class Initialized
INFO - 2020-02-26 18:48:15 --> Helper loaded: url_helper
INFO - 2020-02-26 18:48:15 --> Helper loaded: string_helper
INFO - 2020-02-26 18:48:15 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:48:15 --> Controller Class Initialized
INFO - 2020-02-26 18:48:15 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:48:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:48:15 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:48:15 --> Helper loaded: form_helper
INFO - 2020-02-26 18:48:15 --> Form Validation Class Initialized
INFO - 2020-02-26 18:48:15 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:48:15 --> Final output sent to browser
DEBUG - 2020-02-26 18:48:15 --> Total execution time: 0.8754
INFO - 2020-02-26 18:48:15 --> Config Class Initialized
INFO - 2020-02-26 18:48:15 --> Config Class Initialized
INFO - 2020-02-26 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-26 18:48:15 --> Config Class Initialized
INFO - 2020-02-26 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-26 18:48:15 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:48:15 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-26 18:48:15 --> Utf8 Class Initialized
DEBUG - 2020-02-26 18:48:15 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-26 18:48:15 --> URI Class Initialized
INFO - 2020-02-26 18:48:15 --> URI Class Initialized
INFO - 2020-02-26 18:48:15 --> URI Class Initialized
INFO - 2020-02-26 18:48:15 --> Router Class Initialized
INFO - 2020-02-26 18:48:15 --> Router Class Initialized
INFO - 2020-02-26 18:48:15 --> Output Class Initialized
INFO - 2020-02-26 18:48:15 --> Router Class Initialized
INFO - 2020-02-26 18:48:15 --> Output Class Initialized
INFO - 2020-02-26 18:48:16 --> Security Class Initialized
INFO - 2020-02-26 18:48:16 --> Security Class Initialized
INFO - 2020-02-26 18:48:16 --> Output Class Initialized
DEBUG - 2020-02-26 18:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:48:16 --> Security Class Initialized
INFO - 2020-02-26 18:48:16 --> Input Class Initialized
INFO - 2020-02-26 18:48:16 --> Input Class Initialized
DEBUG - 2020-02-26 18:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:48:16 --> Input Class Initialized
INFO - 2020-02-26 18:48:16 --> Language Class Initialized
INFO - 2020-02-26 18:48:16 --> Language Class Initialized
INFO - 2020-02-26 18:48:16 --> Language Class Initialized
ERROR - 2020-02-26 18:48:16 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-26 18:48:16 --> Loader Class Initialized
INFO - 2020-02-26 18:48:16 --> Helper loaded: url_helper
INFO - 2020-02-26 18:48:16 --> Loader Class Initialized
INFO - 2020-02-26 18:48:16 --> Helper loaded: string_helper
INFO - 2020-02-26 18:48:16 --> Helper loaded: url_helper
INFO - 2020-02-26 18:48:16 --> Helper loaded: string_helper
INFO - 2020-02-26 18:48:16 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:48:16 --> Database Driver Class Initialized
INFO - 2020-02-26 18:48:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-26 18:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:48:16 --> Controller Class Initialized
INFO - 2020-02-26 18:48:16 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:48:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:48:16 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:48:16 --> Helper loaded: form_helper
INFO - 2020-02-26 18:48:16 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:48:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 18:48:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 18:48:16 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:48:16 --> Final output sent to browser
DEBUG - 2020-02-26 18:48:16 --> Total execution time: 1.0752
INFO - 2020-02-26 18:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:48:16 --> Controller Class Initialized
INFO - 2020-02-26 18:48:16 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:48:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:48:16 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:48:17 --> Helper loaded: form_helper
INFO - 2020-02-26 18:48:17 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:48:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-26 18:48:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-26 18:48:17 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-26 18:48:17 --> Final output sent to browser
DEBUG - 2020-02-26 18:48:17 --> Total execution time: 1.4373
INFO - 2020-02-26 18:48:19 --> Config Class Initialized
INFO - 2020-02-26 18:48:19 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:48:19 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:48:19 --> Utf8 Class Initialized
INFO - 2020-02-26 18:48:19 --> URI Class Initialized
INFO - 2020-02-26 18:48:19 --> Router Class Initialized
INFO - 2020-02-26 18:48:19 --> Output Class Initialized
INFO - 2020-02-26 18:48:19 --> Security Class Initialized
DEBUG - 2020-02-26 18:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:48:19 --> Input Class Initialized
INFO - 2020-02-26 18:48:19 --> Language Class Initialized
INFO - 2020-02-26 18:48:19 --> Loader Class Initialized
INFO - 2020-02-26 18:48:19 --> Helper loaded: url_helper
INFO - 2020-02-26 18:48:19 --> Helper loaded: string_helper
INFO - 2020-02-26 18:48:19 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:48:19 --> Controller Class Initialized
INFO - 2020-02-26 18:48:19 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:48:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:48:19 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:48:20 --> Helper loaded: form_helper
INFO - 2020-02-26 18:48:20 --> Form Validation Class Initialized
INFO - 2020-02-26 18:48:24 --> Config Class Initialized
INFO - 2020-02-26 18:48:24 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:48:24 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:48:24 --> Utf8 Class Initialized
INFO - 2020-02-26 18:48:24 --> URI Class Initialized
INFO - 2020-02-26 18:48:24 --> Router Class Initialized
INFO - 2020-02-26 18:48:24 --> Output Class Initialized
INFO - 2020-02-26 18:48:24 --> Security Class Initialized
DEBUG - 2020-02-26 18:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:48:24 --> Input Class Initialized
INFO - 2020-02-26 18:48:24 --> Language Class Initialized
INFO - 2020-02-26 18:48:24 --> Loader Class Initialized
INFO - 2020-02-26 18:48:25 --> Helper loaded: url_helper
INFO - 2020-02-26 18:48:25 --> Helper loaded: string_helper
INFO - 2020-02-26 18:48:25 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:48:25 --> Controller Class Initialized
INFO - 2020-02-26 18:48:25 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:48:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:48:25 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:48:25 --> Helper loaded: form_helper
INFO - 2020-02-26 18:48:25 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:48:25 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 18:48:25 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 18:48:25 --> Final output sent to browser
DEBUG - 2020-02-26 18:48:25 --> Total execution time: 0.8480
INFO - 2020-02-26 18:48:44 --> Config Class Initialized
INFO - 2020-02-26 18:48:44 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:48:44 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:48:44 --> Utf8 Class Initialized
INFO - 2020-02-26 18:48:44 --> URI Class Initialized
INFO - 2020-02-26 18:48:44 --> Router Class Initialized
INFO - 2020-02-26 18:48:44 --> Output Class Initialized
INFO - 2020-02-26 18:48:44 --> Security Class Initialized
DEBUG - 2020-02-26 18:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:48:44 --> Input Class Initialized
INFO - 2020-02-26 18:48:44 --> Language Class Initialized
INFO - 2020-02-26 18:48:44 --> Loader Class Initialized
INFO - 2020-02-26 18:48:44 --> Helper loaded: url_helper
INFO - 2020-02-26 18:48:44 --> Helper loaded: string_helper
INFO - 2020-02-26 18:48:44 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:48:44 --> Controller Class Initialized
INFO - 2020-02-26 18:48:45 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:48:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:48:45 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:48:45 --> Helper loaded: form_helper
INFO - 2020-02-26 18:48:45 --> Form Validation Class Initialized
ERROR - 2020-02-26 18:48:45 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 36
INFO - 2020-02-26 18:48:45 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\pemesanan/form_bukti.php
INFO - 2020-02-26 18:48:45 --> Final output sent to browser
DEBUG - 2020-02-26 18:48:45 --> Total execution time: 0.8584
INFO - 2020-02-26 18:49:04 --> Config Class Initialized
INFO - 2020-02-26 18:49:04 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:49:04 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:49:04 --> Utf8 Class Initialized
INFO - 2020-02-26 18:49:04 --> URI Class Initialized
INFO - 2020-02-26 18:49:04 --> Router Class Initialized
INFO - 2020-02-26 18:49:04 --> Output Class Initialized
INFO - 2020-02-26 18:49:04 --> Security Class Initialized
DEBUG - 2020-02-26 18:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:49:04 --> Input Class Initialized
INFO - 2020-02-26 18:49:04 --> Language Class Initialized
INFO - 2020-02-26 18:49:04 --> Loader Class Initialized
INFO - 2020-02-26 18:49:04 --> Helper loaded: url_helper
INFO - 2020-02-26 18:49:04 --> Helper loaded: string_helper
INFO - 2020-02-26 18:49:04 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:49:04 --> Controller Class Initialized
INFO - 2020-02-26 18:49:04 --> Model "M_tiket" initialized
INFO - 2020-02-26 18:49:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-26 18:49:05 --> Model "M_pesan" initialized
INFO - 2020-02-26 18:49:05 --> Helper loaded: form_helper
INFO - 2020-02-26 18:49:05 --> Form Validation Class Initialized
INFO - 2020-02-26 18:49:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-26 18:49:05 --> Config Class Initialized
INFO - 2020-02-26 18:49:05 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:49:05 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:49:05 --> Utf8 Class Initialized
INFO - 2020-02-26 18:49:05 --> URI Class Initialized
INFO - 2020-02-26 18:49:05 --> Router Class Initialized
INFO - 2020-02-26 18:49:05 --> Output Class Initialized
INFO - 2020-02-26 18:49:05 --> Security Class Initialized
DEBUG - 2020-02-26 18:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:49:05 --> Input Class Initialized
INFO - 2020-02-26 18:49:05 --> Language Class Initialized
INFO - 2020-02-26 18:49:05 --> Loader Class Initialized
INFO - 2020-02-26 18:49:05 --> Helper loaded: url_helper
INFO - 2020-02-26 18:49:05 --> Helper loaded: string_helper
INFO - 2020-02-26 18:49:05 --> Database Driver Class Initialized
DEBUG - 2020-02-26 18:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-26 18:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-26 18:49:05 --> Controller Class Initialized
INFO - 2020-02-26 18:49:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-26 18:49:05 --> Pagination Class Initialized
INFO - 2020-02-26 18:49:05 --> Model "M_show" initialized
INFO - 2020-02-26 18:49:05 --> Helper loaded: form_helper
INFO - 2020-02-26 18:49:05 --> Form Validation Class Initialized
INFO - 2020-02-26 18:49:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-26 18:49:05 --> Final output sent to browser
DEBUG - 2020-02-26 18:49:06 --> Total execution time: 0.8217
INFO - 2020-02-26 18:49:06 --> Config Class Initialized
INFO - 2020-02-26 18:49:06 --> Config Class Initialized
INFO - 2020-02-26 18:49:06 --> Hooks Class Initialized
INFO - 2020-02-26 18:49:06 --> Hooks Class Initialized
DEBUG - 2020-02-26 18:49:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-26 18:49:06 --> UTF-8 Support Enabled
INFO - 2020-02-26 18:49:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:49:06 --> Utf8 Class Initialized
INFO - 2020-02-26 18:49:06 --> URI Class Initialized
INFO - 2020-02-26 18:49:06 --> URI Class Initialized
INFO - 2020-02-26 18:49:06 --> Router Class Initialized
INFO - 2020-02-26 18:49:06 --> Router Class Initialized
INFO - 2020-02-26 18:49:06 --> Output Class Initialized
INFO - 2020-02-26 18:49:06 --> Output Class Initialized
INFO - 2020-02-26 18:49:06 --> Security Class Initialized
INFO - 2020-02-26 18:49:06 --> Security Class Initialized
DEBUG - 2020-02-26 18:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-26 18:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-26 18:49:06 --> Input Class Initialized
INFO - 2020-02-26 18:49:06 --> Input Class Initialized
INFO - 2020-02-26 18:49:06 --> Language Class Initialized
INFO - 2020-02-26 18:49:06 --> Language Class Initialized
ERROR - 2020-02-26 18:49:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-26 18:49:06 --> 404 Page Not Found: Assets/js
