<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-14 07:39:13 --> Config Class Initialized
INFO - 2020-02-14 07:39:13 --> Hooks Class Initialized
DEBUG - 2020-02-14 07:39:13 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:13 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:13 --> URI Class Initialized
INFO - 2020-02-14 07:39:13 --> Router Class Initialized
INFO - 2020-02-14 07:39:13 --> Output Class Initialized
INFO - 2020-02-14 07:39:13 --> Security Class Initialized
DEBUG - 2020-02-14 07:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:14 --> Input Class Initialized
INFO - 2020-02-14 07:39:14 --> Language Class Initialized
INFO - 2020-02-14 07:39:14 --> Loader Class Initialized
INFO - 2020-02-14 07:39:14 --> Helper loaded: url_helper
INFO - 2020-02-14 07:39:14 --> Helper loaded: string_helper
INFO - 2020-02-14 07:39:14 --> Database Driver Class Initialized
DEBUG - 2020-02-14 07:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 07:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 07:39:17 --> Controller Class Initialized
INFO - 2020-02-14 07:39:17 --> Model "M_tiket" initialized
INFO - 2020-02-14 07:39:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 07:39:17 --> Model "M_pesan" initialized
INFO - 2020-02-14 07:39:17 --> Helper loaded: form_helper
INFO - 2020-02-14 07:39:17 --> Form Validation Class Initialized
INFO - 2020-02-14 07:39:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 07:39:17 --> Final output sent to browser
DEBUG - 2020-02-14 07:39:17 --> Total execution time: 4.6584
INFO - 2020-02-14 07:39:17 --> Config Class Initialized
INFO - 2020-02-14 07:39:17 --> Hooks Class Initialized
DEBUG - 2020-02-14 07:39:17 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:17 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:17 --> URI Class Initialized
INFO - 2020-02-14 07:39:17 --> Config Class Initialized
INFO - 2020-02-14 07:39:17 --> Hooks Class Initialized
INFO - 2020-02-14 07:39:17 --> Router Class Initialized
INFO - 2020-02-14 07:39:17 --> Output Class Initialized
DEBUG - 2020-02-14 07:39:17 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:17 --> Config Class Initialized
INFO - 2020-02-14 07:39:17 --> Config Class Initialized
INFO - 2020-02-14 07:39:17 --> Config Class Initialized
INFO - 2020-02-14 07:39:17 --> Config Class Initialized
INFO - 2020-02-14 07:39:17 --> Hooks Class Initialized
INFO - 2020-02-14 07:39:17 --> Hooks Class Initialized
INFO - 2020-02-14 07:39:17 --> Hooks Class Initialized
INFO - 2020-02-14 07:39:17 --> Security Class Initialized
INFO - 2020-02-14 07:39:17 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:17 --> Hooks Class Initialized
DEBUG - 2020-02-14 07:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 07:39:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 07:39:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 07:39:17 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:17 --> URI Class Initialized
DEBUG - 2020-02-14 07:39:17 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:17 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:17 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:17 --> Input Class Initialized
INFO - 2020-02-14 07:39:17 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:17 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:17 --> Router Class Initialized
INFO - 2020-02-14 07:39:17 --> Language Class Initialized
INFO - 2020-02-14 07:39:17 --> URI Class Initialized
INFO - 2020-02-14 07:39:17 --> URI Class Initialized
INFO - 2020-02-14 07:39:17 --> URI Class Initialized
INFO - 2020-02-14 07:39:17 --> Output Class Initialized
INFO - 2020-02-14 07:39:17 --> URI Class Initialized
INFO - 2020-02-14 07:39:17 --> Security Class Initialized
INFO - 2020-02-14 07:39:17 --> Router Class Initialized
INFO - 2020-02-14 07:39:17 --> Router Class Initialized
INFO - 2020-02-14 07:39:17 --> Router Class Initialized
INFO - 2020-02-14 07:39:17 --> Router Class Initialized
DEBUG - 2020-02-14 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:17 --> Output Class Initialized
INFO - 2020-02-14 07:39:17 --> Output Class Initialized
INFO - 2020-02-14 07:39:17 --> Output Class Initialized
INFO - 2020-02-14 07:39:17 --> Output Class Initialized
ERROR - 2020-02-14 07:39:17 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-14 07:39:17 --> Input Class Initialized
INFO - 2020-02-14 07:39:17 --> Security Class Initialized
INFO - 2020-02-14 07:39:17 --> Security Class Initialized
INFO - 2020-02-14 07:39:17 --> Security Class Initialized
INFO - 2020-02-14 07:39:18 --> Security Class Initialized
DEBUG - 2020-02-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
INFO - 2020-02-14 07:39:18 --> Config Class Initialized
INFO - 2020-02-14 07:39:18 --> Hooks Class Initialized
INFO - 2020-02-14 07:39:18 --> Input Class Initialized
INFO - 2020-02-14 07:39:18 --> Input Class Initialized
INFO - 2020-02-14 07:39:18 --> Input Class Initialized
INFO - 2020-02-14 07:39:18 --> Input Class Initialized
ERROR - 2020-02-14 07:39:18 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
DEBUG - 2020-02-14 07:39:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:18 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:18 --> Config Class Initialized
ERROR - 2020-02-14 07:39:18 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-14 07:39:18 --> Loader Class Initialized
ERROR - 2020-02-14 07:39:18 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-14 07:39:18 --> Loader Class Initialized
INFO - 2020-02-14 07:39:18 --> Hooks Class Initialized
INFO - 2020-02-14 07:39:18 --> URI Class Initialized
INFO - 2020-02-14 07:39:18 --> Helper loaded: url_helper
INFO - 2020-02-14 07:39:18 --> Helper loaded: url_helper
INFO - 2020-02-14 07:39:18 --> Helper loaded: string_helper
INFO - 2020-02-14 07:39:18 --> Helper loaded: string_helper
INFO - 2020-02-14 07:39:18 --> Router Class Initialized
DEBUG - 2020-02-14 07:39:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:18 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:18 --> Output Class Initialized
INFO - 2020-02-14 07:39:18 --> Database Driver Class Initialized
INFO - 2020-02-14 07:39:18 --> Database Driver Class Initialized
INFO - 2020-02-14 07:39:18 --> URI Class Initialized
INFO - 2020-02-14 07:39:18 --> Security Class Initialized
DEBUG - 2020-02-14 07:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-14 07:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 07:39:18 --> Router Class Initialized
INFO - 2020-02-14 07:39:18 --> Input Class Initialized
INFO - 2020-02-14 07:39:18 --> Controller Class Initialized
INFO - 2020-02-14 07:39:18 --> Output Class Initialized
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
INFO - 2020-02-14 07:39:18 --> Model "M_tiket" initialized
INFO - 2020-02-14 07:39:18 --> Security Class Initialized
INFO - 2020-02-14 07:39:18 --> Model "M_pengunjung" initialized
ERROR - 2020-02-14 07:39:18 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2020-02-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:18 --> Model "M_pesan" initialized
INFO - 2020-02-14 07:39:18 --> Input Class Initialized
INFO - 2020-02-14 07:39:18 --> Config Class Initialized
INFO - 2020-02-14 07:39:18 --> Config Class Initialized
INFO - 2020-02-14 07:39:18 --> Hooks Class Initialized
INFO - 2020-02-14 07:39:18 --> Hooks Class Initialized
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
INFO - 2020-02-14 07:39:18 --> Helper loaded: form_helper
INFO - 2020-02-14 07:39:18 --> Form Validation Class Initialized
ERROR - 2020-02-14 07:39:18 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-14 07:39:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 07:39:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:18 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:18 --> Utf8 Class Initialized
ERROR - 2020-02-14 07:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-14 07:39:18 --> URI Class Initialized
INFO - 2020-02-14 07:39:18 --> URI Class Initialized
INFO - 2020-02-14 07:39:18 --> Config Class Initialized
INFO - 2020-02-14 07:39:18 --> Config Class Initialized
INFO - 2020-02-14 07:39:18 --> Hooks Class Initialized
INFO - 2020-02-14 07:39:18 --> Hooks Class Initialized
INFO - 2020-02-14 07:39:18 --> Router Class Initialized
INFO - 2020-02-14 07:39:18 --> Router Class Initialized
INFO - 2020-02-14 07:39:18 --> Output Class Initialized
INFO - 2020-02-14 07:39:18 --> Output Class Initialized
DEBUG - 2020-02-14 07:39:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 07:39:18 --> UTF-8 Support Enabled
ERROR - 2020-02-14 07:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-14 07:39:18 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:18 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 07:39:18 --> Security Class Initialized
INFO - 2020-02-14 07:39:18 --> Security Class Initialized
INFO - 2020-02-14 07:39:18 --> Final output sent to browser
DEBUG - 2020-02-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:18 --> URI Class Initialized
INFO - 2020-02-14 07:39:18 --> URI Class Initialized
INFO - 2020-02-14 07:39:18 --> Input Class Initialized
INFO - 2020-02-14 07:39:18 --> Input Class Initialized
DEBUG - 2020-02-14 07:39:18 --> Total execution time: 0.5171
INFO - 2020-02-14 07:39:18 --> Router Class Initialized
INFO - 2020-02-14 07:39:18 --> Router Class Initialized
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
INFO - 2020-02-14 07:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 07:39:18 --> Output Class Initialized
INFO - 2020-02-14 07:39:18 --> Output Class Initialized
INFO - 2020-02-14 07:39:18 --> Config Class Initialized
INFO - 2020-02-14 07:39:18 --> Hooks Class Initialized
ERROR - 2020-02-14 07:39:18 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-14 07:39:18 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-14 07:39:18 --> Security Class Initialized
INFO - 2020-02-14 07:39:18 --> Security Class Initialized
INFO - 2020-02-14 07:39:18 --> Controller Class Initialized
DEBUG - 2020-02-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 07:39:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:18 --> Model "M_tiket" initialized
INFO - 2020-02-14 07:39:18 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:18 --> Input Class Initialized
INFO - 2020-02-14 07:39:18 --> Input Class Initialized
INFO - 2020-02-14 07:39:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 07:39:18 --> Model "M_pesan" initialized
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
INFO - 2020-02-14 07:39:18 --> URI Class Initialized
INFO - 2020-02-14 07:39:18 --> Router Class Initialized
ERROR - 2020-02-14 07:39:18 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-14 07:39:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-14 07:39:18 --> Helper loaded: form_helper
INFO - 2020-02-14 07:39:18 --> Form Validation Class Initialized
INFO - 2020-02-14 07:39:18 --> Output Class Initialized
INFO - 2020-02-14 07:39:18 --> Security Class Initialized
ERROR - 2020-02-14 07:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-14 07:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
DEBUG - 2020-02-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:18 --> Input Class Initialized
INFO - 2020-02-14 07:39:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 07:39:18 --> Final output sent to browser
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
DEBUG - 2020-02-14 07:39:18 --> Total execution time: 0.7020
ERROR - 2020-02-14 07:39:18 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-14 07:39:18 --> Config Class Initialized
INFO - 2020-02-14 07:39:18 --> Hooks Class Initialized
DEBUG - 2020-02-14 07:39:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:18 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:18 --> URI Class Initialized
INFO - 2020-02-14 07:39:18 --> Router Class Initialized
INFO - 2020-02-14 07:39:18 --> Output Class Initialized
INFO - 2020-02-14 07:39:18 --> Security Class Initialized
DEBUG - 2020-02-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:18 --> Input Class Initialized
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
ERROR - 2020-02-14 07:39:18 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-14 07:39:18 --> Config Class Initialized
INFO - 2020-02-14 07:39:18 --> Hooks Class Initialized
DEBUG - 2020-02-14 07:39:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:18 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:18 --> URI Class Initialized
INFO - 2020-02-14 07:39:18 --> Router Class Initialized
INFO - 2020-02-14 07:39:18 --> Output Class Initialized
INFO - 2020-02-14 07:39:18 --> Security Class Initialized
DEBUG - 2020-02-14 07:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:18 --> Input Class Initialized
INFO - 2020-02-14 07:39:18 --> Language Class Initialized
ERROR - 2020-02-14 07:39:18 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-14 07:39:18 --> Config Class Initialized
INFO - 2020-02-14 07:39:18 --> Hooks Class Initialized
DEBUG - 2020-02-14 07:39:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:18 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:18 --> URI Class Initialized
INFO - 2020-02-14 07:39:18 --> Router Class Initialized
INFO - 2020-02-14 07:39:19 --> Output Class Initialized
INFO - 2020-02-14 07:39:19 --> Security Class Initialized
DEBUG - 2020-02-14 07:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:19 --> Input Class Initialized
INFO - 2020-02-14 07:39:19 --> Language Class Initialized
ERROR - 2020-02-14 07:39:19 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-14 07:39:19 --> Config Class Initialized
INFO - 2020-02-14 07:39:19 --> Hooks Class Initialized
DEBUG - 2020-02-14 07:39:19 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:19 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:19 --> URI Class Initialized
INFO - 2020-02-14 07:39:19 --> Router Class Initialized
INFO - 2020-02-14 07:39:19 --> Output Class Initialized
INFO - 2020-02-14 07:39:19 --> Security Class Initialized
DEBUG - 2020-02-14 07:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:19 --> Input Class Initialized
INFO - 2020-02-14 07:39:19 --> Language Class Initialized
ERROR - 2020-02-14 07:39:19 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-14 07:39:19 --> Config Class Initialized
INFO - 2020-02-14 07:39:19 --> Hooks Class Initialized
DEBUG - 2020-02-14 07:39:19 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:19 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:19 --> URI Class Initialized
INFO - 2020-02-14 07:39:19 --> Router Class Initialized
INFO - 2020-02-14 07:39:19 --> Output Class Initialized
INFO - 2020-02-14 07:39:19 --> Security Class Initialized
DEBUG - 2020-02-14 07:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:19 --> Input Class Initialized
INFO - 2020-02-14 07:39:19 --> Language Class Initialized
ERROR - 2020-02-14 07:39:19 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-14 07:39:19 --> Config Class Initialized
INFO - 2020-02-14 07:39:19 --> Hooks Class Initialized
DEBUG - 2020-02-14 07:39:19 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:19 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:19 --> URI Class Initialized
INFO - 2020-02-14 07:39:19 --> Router Class Initialized
INFO - 2020-02-14 07:39:19 --> Output Class Initialized
INFO - 2020-02-14 07:39:19 --> Security Class Initialized
DEBUG - 2020-02-14 07:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:19 --> Input Class Initialized
INFO - 2020-02-14 07:39:19 --> Language Class Initialized
ERROR - 2020-02-14 07:39:19 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-14 07:39:19 --> Config Class Initialized
INFO - 2020-02-14 07:39:19 --> Hooks Class Initialized
DEBUG - 2020-02-14 07:39:19 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:19 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:19 --> URI Class Initialized
INFO - 2020-02-14 07:39:19 --> Router Class Initialized
INFO - 2020-02-14 07:39:19 --> Output Class Initialized
INFO - 2020-02-14 07:39:19 --> Security Class Initialized
DEBUG - 2020-02-14 07:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:19 --> Input Class Initialized
INFO - 2020-02-14 07:39:19 --> Language Class Initialized
ERROR - 2020-02-14 07:39:19 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-14 07:39:19 --> Config Class Initialized
INFO - 2020-02-14 07:39:19 --> Hooks Class Initialized
DEBUG - 2020-02-14 07:39:19 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:19 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:19 --> URI Class Initialized
INFO - 2020-02-14 07:39:19 --> Router Class Initialized
INFO - 2020-02-14 07:39:19 --> Output Class Initialized
INFO - 2020-02-14 07:39:19 --> Security Class Initialized
DEBUG - 2020-02-14 07:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:19 --> Input Class Initialized
INFO - 2020-02-14 07:39:19 --> Language Class Initialized
ERROR - 2020-02-14 07:39:19 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-14 07:39:19 --> Config Class Initialized
INFO - 2020-02-14 07:39:19 --> Hooks Class Initialized
DEBUG - 2020-02-14 07:39:19 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:39:19 --> Utf8 Class Initialized
INFO - 2020-02-14 07:39:19 --> URI Class Initialized
INFO - 2020-02-14 07:39:19 --> Router Class Initialized
INFO - 2020-02-14 07:39:20 --> Output Class Initialized
INFO - 2020-02-14 07:39:20 --> Security Class Initialized
DEBUG - 2020-02-14 07:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:39:20 --> Input Class Initialized
INFO - 2020-02-14 07:39:20 --> Language Class Initialized
ERROR - 2020-02-14 07:39:20 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-14 07:59:08 --> Config Class Initialized
INFO - 2020-02-14 07:59:08 --> Hooks Class Initialized
DEBUG - 2020-02-14 07:59:08 --> UTF-8 Support Enabled
INFO - 2020-02-14 07:59:08 --> Utf8 Class Initialized
INFO - 2020-02-14 07:59:08 --> URI Class Initialized
INFO - 2020-02-14 07:59:08 --> Router Class Initialized
INFO - 2020-02-14 07:59:08 --> Output Class Initialized
INFO - 2020-02-14 07:59:08 --> Security Class Initialized
DEBUG - 2020-02-14 07:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 07:59:08 --> Input Class Initialized
INFO - 2020-02-14 07:59:08 --> Language Class Initialized
INFO - 2020-02-14 07:59:09 --> Loader Class Initialized
INFO - 2020-02-14 07:59:09 --> Helper loaded: url_helper
INFO - 2020-02-14 07:59:09 --> Helper loaded: string_helper
INFO - 2020-02-14 07:59:09 --> Database Driver Class Initialized
DEBUG - 2020-02-14 07:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 07:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 07:59:09 --> Controller Class Initialized
INFO - 2020-02-14 07:59:09 --> Model "M_tiket" initialized
INFO - 2020-02-14 07:59:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 07:59:09 --> Model "M_pesan" initialized
INFO - 2020-02-14 07:59:09 --> Helper loaded: form_helper
INFO - 2020-02-14 07:59:09 --> Form Validation Class Initialized
INFO - 2020-02-14 07:59:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-14 07:59:09 --> Final output sent to browser
DEBUG - 2020-02-14 07:59:09 --> Total execution time: 1.4729
INFO - 2020-02-14 08:00:02 --> Config Class Initialized
INFO - 2020-02-14 08:00:02 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:00:02 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:00:02 --> Utf8 Class Initialized
INFO - 2020-02-14 08:00:02 --> URI Class Initialized
INFO - 2020-02-14 08:00:02 --> Router Class Initialized
INFO - 2020-02-14 08:00:02 --> Output Class Initialized
INFO - 2020-02-14 08:00:02 --> Security Class Initialized
DEBUG - 2020-02-14 08:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:00:02 --> Input Class Initialized
INFO - 2020-02-14 08:00:02 --> Language Class Initialized
INFO - 2020-02-14 08:00:02 --> Loader Class Initialized
INFO - 2020-02-14 08:00:02 --> Helper loaded: url_helper
INFO - 2020-02-14 08:00:02 --> Helper loaded: string_helper
INFO - 2020-02-14 08:00:02 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:00:02 --> Controller Class Initialized
INFO - 2020-02-14 08:00:02 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:00:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:00:02 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:00:02 --> Helper loaded: form_helper
INFO - 2020-02-14 08:00:02 --> Form Validation Class Initialized
INFO - 2020-02-14 08:00:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-14 08:00:02 --> Final output sent to browser
DEBUG - 2020-02-14 08:00:02 --> Total execution time: 0.3480
INFO - 2020-02-14 08:00:08 --> Config Class Initialized
INFO - 2020-02-14 08:00:08 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:00:08 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:00:08 --> Utf8 Class Initialized
INFO - 2020-02-14 08:00:09 --> URI Class Initialized
INFO - 2020-02-14 08:00:09 --> Router Class Initialized
INFO - 2020-02-14 08:00:09 --> Output Class Initialized
INFO - 2020-02-14 08:00:09 --> Security Class Initialized
DEBUG - 2020-02-14 08:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:00:09 --> Input Class Initialized
INFO - 2020-02-14 08:00:09 --> Language Class Initialized
INFO - 2020-02-14 08:00:09 --> Loader Class Initialized
INFO - 2020-02-14 08:00:09 --> Helper loaded: url_helper
INFO - 2020-02-14 08:00:09 --> Helper loaded: string_helper
INFO - 2020-02-14 08:00:09 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:00:09 --> Controller Class Initialized
INFO - 2020-02-14 08:00:09 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:00:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:00:09 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:00:09 --> Helper loaded: form_helper
INFO - 2020-02-14 08:00:09 --> Form Validation Class Initialized
INFO - 2020-02-14 08:00:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:00:09 --> Final output sent to browser
DEBUG - 2020-02-14 08:00:09 --> Total execution time: 0.4016
INFO - 2020-02-14 08:00:09 --> Config Class Initialized
INFO - 2020-02-14 08:00:09 --> Config Class Initialized
INFO - 2020-02-14 08:00:09 --> Hooks Class Initialized
INFO - 2020-02-14 08:00:09 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:00:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:00:09 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:00:09 --> Utf8 Class Initialized
INFO - 2020-02-14 08:00:09 --> Utf8 Class Initialized
INFO - 2020-02-14 08:00:09 --> URI Class Initialized
INFO - 2020-02-14 08:00:09 --> URI Class Initialized
INFO - 2020-02-14 08:00:09 --> Router Class Initialized
INFO - 2020-02-14 08:00:09 --> Router Class Initialized
INFO - 2020-02-14 08:00:09 --> Output Class Initialized
INFO - 2020-02-14 08:00:09 --> Security Class Initialized
INFO - 2020-02-14 08:00:09 --> Output Class Initialized
DEBUG - 2020-02-14 08:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:00:09 --> Security Class Initialized
INFO - 2020-02-14 08:00:09 --> Input Class Initialized
DEBUG - 2020-02-14 08:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:00:09 --> Input Class Initialized
INFO - 2020-02-14 08:00:09 --> Language Class Initialized
INFO - 2020-02-14 08:00:09 --> Language Class Initialized
INFO - 2020-02-14 08:00:09 --> Loader Class Initialized
INFO - 2020-02-14 08:00:09 --> Helper loaded: url_helper
INFO - 2020-02-14 08:00:09 --> Loader Class Initialized
INFO - 2020-02-14 08:00:09 --> Helper loaded: string_helper
INFO - 2020-02-14 08:00:09 --> Helper loaded: url_helper
INFO - 2020-02-14 08:00:09 --> Helper loaded: string_helper
INFO - 2020-02-14 08:00:09 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:00:09 --> Database Driver Class Initialized
INFO - 2020-02-14 08:00:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-14 08:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:00:09 --> Controller Class Initialized
INFO - 2020-02-14 08:00:09 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:00:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:00:09 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:00:09 --> Helper loaded: form_helper
INFO - 2020-02-14 08:00:09 --> Form Validation Class Initialized
ERROR - 2020-02-14 08:00:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-14 08:00:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-14 08:00:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:00:10 --> Final output sent to browser
DEBUG - 2020-02-14 08:00:10 --> Total execution time: 0.6547
INFO - 2020-02-14 08:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:00:10 --> Controller Class Initialized
INFO - 2020-02-14 08:00:10 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:00:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:00:10 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:00:10 --> Helper loaded: form_helper
INFO - 2020-02-14 08:00:10 --> Form Validation Class Initialized
ERROR - 2020-02-14 08:00:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-14 08:00:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-14 08:00:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:00:10 --> Final output sent to browser
DEBUG - 2020-02-14 08:00:10 --> Total execution time: 0.8184
INFO - 2020-02-14 08:00:44 --> Config Class Initialized
INFO - 2020-02-14 08:00:44 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:00:44 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:00:44 --> Utf8 Class Initialized
INFO - 2020-02-14 08:00:44 --> URI Class Initialized
INFO - 2020-02-14 08:00:44 --> Router Class Initialized
INFO - 2020-02-14 08:00:44 --> Output Class Initialized
INFO - 2020-02-14 08:00:44 --> Security Class Initialized
DEBUG - 2020-02-14 08:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:00:45 --> Input Class Initialized
INFO - 2020-02-14 08:00:45 --> Language Class Initialized
INFO - 2020-02-14 08:00:45 --> Loader Class Initialized
INFO - 2020-02-14 08:00:45 --> Helper loaded: url_helper
INFO - 2020-02-14 08:00:45 --> Helper loaded: string_helper
INFO - 2020-02-14 08:00:45 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:00:45 --> Controller Class Initialized
INFO - 2020-02-14 08:00:45 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:00:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:00:45 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:00:45 --> Helper loaded: form_helper
INFO - 2020-02-14 08:00:45 --> Form Validation Class Initialized
INFO - 2020-02-14 08:00:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-14 08:00:45 --> Final output sent to browser
DEBUG - 2020-02-14 08:00:45 --> Total execution time: 0.5251
INFO - 2020-02-14 08:01:04 --> Config Class Initialized
INFO - 2020-02-14 08:01:04 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:01:04 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:01:04 --> Utf8 Class Initialized
INFO - 2020-02-14 08:01:04 --> URI Class Initialized
INFO - 2020-02-14 08:01:04 --> Router Class Initialized
INFO - 2020-02-14 08:01:04 --> Output Class Initialized
INFO - 2020-02-14 08:01:04 --> Security Class Initialized
DEBUG - 2020-02-14 08:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:01:04 --> Input Class Initialized
INFO - 2020-02-14 08:01:04 --> Language Class Initialized
INFO - 2020-02-14 08:01:04 --> Loader Class Initialized
INFO - 2020-02-14 08:01:04 --> Helper loaded: url_helper
INFO - 2020-02-14 08:01:04 --> Helper loaded: string_helper
INFO - 2020-02-14 08:01:04 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:01:04 --> Controller Class Initialized
INFO - 2020-02-14 08:01:04 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:01:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:01:04 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:01:04 --> Helper loaded: form_helper
INFO - 2020-02-14 08:01:04 --> Form Validation Class Initialized
INFO - 2020-02-14 08:01:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:01:04 --> Final output sent to browser
DEBUG - 2020-02-14 08:01:04 --> Total execution time: 0.3673
INFO - 2020-02-14 08:01:04 --> Config Class Initialized
INFO - 2020-02-14 08:01:04 --> Hooks Class Initialized
INFO - 2020-02-14 08:01:04 --> Config Class Initialized
INFO - 2020-02-14 08:01:04 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:01:04 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:01:04 --> Utf8 Class Initialized
DEBUG - 2020-02-14 08:01:04 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:01:04 --> Utf8 Class Initialized
INFO - 2020-02-14 08:01:04 --> URI Class Initialized
INFO - 2020-02-14 08:01:04 --> URI Class Initialized
INFO - 2020-02-14 08:01:04 --> Router Class Initialized
INFO - 2020-02-14 08:01:04 --> Router Class Initialized
INFO - 2020-02-14 08:01:04 --> Output Class Initialized
INFO - 2020-02-14 08:01:04 --> Security Class Initialized
INFO - 2020-02-14 08:01:04 --> Output Class Initialized
DEBUG - 2020-02-14 08:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:01:05 --> Security Class Initialized
INFO - 2020-02-14 08:01:05 --> Input Class Initialized
DEBUG - 2020-02-14 08:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:01:05 --> Input Class Initialized
INFO - 2020-02-14 08:01:05 --> Language Class Initialized
INFO - 2020-02-14 08:01:05 --> Language Class Initialized
INFO - 2020-02-14 08:01:05 --> Loader Class Initialized
INFO - 2020-02-14 08:01:05 --> Helper loaded: url_helper
INFO - 2020-02-14 08:01:05 --> Loader Class Initialized
INFO - 2020-02-14 08:01:05 --> Helper loaded: string_helper
INFO - 2020-02-14 08:01:05 --> Helper loaded: url_helper
INFO - 2020-02-14 08:01:05 --> Helper loaded: string_helper
INFO - 2020-02-14 08:01:05 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:01:05 --> Database Driver Class Initialized
INFO - 2020-02-14 08:01:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-14 08:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:01:05 --> Controller Class Initialized
INFO - 2020-02-14 08:01:05 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:01:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:01:05 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:01:05 --> Helper loaded: form_helper
INFO - 2020-02-14 08:01:05 --> Form Validation Class Initialized
ERROR - 2020-02-14 08:01:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-14 08:01:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-14 08:01:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:01:05 --> Final output sent to browser
DEBUG - 2020-02-14 08:01:05 --> Total execution time: 0.4997
INFO - 2020-02-14 08:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:01:05 --> Controller Class Initialized
INFO - 2020-02-14 08:01:05 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:01:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:01:05 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:01:05 --> Helper loaded: form_helper
INFO - 2020-02-14 08:01:05 --> Form Validation Class Initialized
ERROR - 2020-02-14 08:01:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-14 08:01:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-14 08:01:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:01:05 --> Final output sent to browser
DEBUG - 2020-02-14 08:01:05 --> Total execution time: 0.6318
INFO - 2020-02-14 08:02:10 --> Config Class Initialized
INFO - 2020-02-14 08:02:10 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:02:10 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:10 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:10 --> URI Class Initialized
DEBUG - 2020-02-14 08:02:10 --> No URI present. Default controller set.
INFO - 2020-02-14 08:02:10 --> Router Class Initialized
INFO - 2020-02-14 08:02:10 --> Output Class Initialized
INFO - 2020-02-14 08:02:10 --> Security Class Initialized
DEBUG - 2020-02-14 08:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:10 --> Input Class Initialized
INFO - 2020-02-14 08:02:10 --> Language Class Initialized
INFO - 2020-02-14 08:02:10 --> Loader Class Initialized
INFO - 2020-02-14 08:02:10 --> Helper loaded: url_helper
INFO - 2020-02-14 08:02:10 --> Helper loaded: string_helper
INFO - 2020-02-14 08:02:10 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:02:10 --> Controller Class Initialized
INFO - 2020-02-14 08:02:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-14 08:02:10 --> Pagination Class Initialized
INFO - 2020-02-14 08:02:10 --> Model "M_show" initialized
INFO - 2020-02-14 08:02:10 --> Helper loaded: form_helper
INFO - 2020-02-14 08:02:10 --> Form Validation Class Initialized
INFO - 2020-02-14 08:02:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-14 08:02:10 --> Final output sent to browser
DEBUG - 2020-02-14 08:02:10 --> Total execution time: 0.6793
INFO - 2020-02-14 08:02:13 --> Config Class Initialized
INFO - 2020-02-14 08:02:13 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:02:13 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:13 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:13 --> URI Class Initialized
DEBUG - 2020-02-14 08:02:13 --> No URI present. Default controller set.
INFO - 2020-02-14 08:02:13 --> Router Class Initialized
INFO - 2020-02-14 08:02:13 --> Output Class Initialized
INFO - 2020-02-14 08:02:13 --> Security Class Initialized
DEBUG - 2020-02-14 08:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:13 --> Input Class Initialized
INFO - 2020-02-14 08:02:13 --> Language Class Initialized
INFO - 2020-02-14 08:02:13 --> Loader Class Initialized
INFO - 2020-02-14 08:02:13 --> Helper loaded: url_helper
INFO - 2020-02-14 08:02:13 --> Helper loaded: string_helper
INFO - 2020-02-14 08:02:13 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:02:13 --> Controller Class Initialized
INFO - 2020-02-14 08:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-14 08:02:13 --> Pagination Class Initialized
INFO - 2020-02-14 08:02:13 --> Model "M_show" initialized
INFO - 2020-02-14 08:02:13 --> Helper loaded: form_helper
INFO - 2020-02-14 08:02:13 --> Form Validation Class Initialized
INFO - 2020-02-14 08:02:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-14 08:02:13 --> Final output sent to browser
DEBUG - 2020-02-14 08:02:13 --> Total execution time: 0.3981
INFO - 2020-02-14 08:02:17 --> Config Class Initialized
INFO - 2020-02-14 08:02:17 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:02:17 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:17 --> URI Class Initialized
INFO - 2020-02-14 08:02:17 --> Router Class Initialized
INFO - 2020-02-14 08:02:17 --> Output Class Initialized
INFO - 2020-02-14 08:02:17 --> Security Class Initialized
DEBUG - 2020-02-14 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:17 --> Input Class Initialized
INFO - 2020-02-14 08:02:17 --> Language Class Initialized
INFO - 2020-02-14 08:02:17 --> Loader Class Initialized
INFO - 2020-02-14 08:02:17 --> Helper loaded: url_helper
INFO - 2020-02-14 08:02:17 --> Helper loaded: string_helper
INFO - 2020-02-14 08:02:17 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:02:17 --> Controller Class Initialized
INFO - 2020-02-14 08:02:17 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:02:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:02:17 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:02:17 --> Helper loaded: form_helper
INFO - 2020-02-14 08:02:17 --> Form Validation Class Initialized
INFO - 2020-02-14 08:02:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:02:17 --> Final output sent to browser
DEBUG - 2020-02-14 08:02:17 --> Total execution time: 0.3804
INFO - 2020-02-14 08:02:17 --> Config Class Initialized
INFO - 2020-02-14 08:02:17 --> Config Class Initialized
INFO - 2020-02-14 08:02:17 --> Config Class Initialized
INFO - 2020-02-14 08:02:17 --> Config Class Initialized
INFO - 2020-02-14 08:02:17 --> Config Class Initialized
INFO - 2020-02-14 08:02:17 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:17 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:17 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:17 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:17 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:17 --> Config Class Initialized
DEBUG - 2020-02-14 08:02:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:02:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:02:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:02:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:02:17 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:17 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:17 --> URI Class Initialized
INFO - 2020-02-14 08:02:17 --> URI Class Initialized
INFO - 2020-02-14 08:02:17 --> URI Class Initialized
INFO - 2020-02-14 08:02:17 --> URI Class Initialized
INFO - 2020-02-14 08:02:17 --> URI Class Initialized
DEBUG - 2020-02-14 08:02:17 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:17 --> Router Class Initialized
INFO - 2020-02-14 08:02:17 --> Router Class Initialized
INFO - 2020-02-14 08:02:17 --> Router Class Initialized
INFO - 2020-02-14 08:02:17 --> Router Class Initialized
INFO - 2020-02-14 08:02:17 --> Router Class Initialized
INFO - 2020-02-14 08:02:17 --> URI Class Initialized
INFO - 2020-02-14 08:02:17 --> Output Class Initialized
INFO - 2020-02-14 08:02:17 --> Output Class Initialized
INFO - 2020-02-14 08:02:17 --> Output Class Initialized
INFO - 2020-02-14 08:02:17 --> Output Class Initialized
INFO - 2020-02-14 08:02:17 --> Output Class Initialized
INFO - 2020-02-14 08:02:17 --> Security Class Initialized
INFO - 2020-02-14 08:02:17 --> Security Class Initialized
INFO - 2020-02-14 08:02:17 --> Security Class Initialized
INFO - 2020-02-14 08:02:17 --> Security Class Initialized
INFO - 2020-02-14 08:02:17 --> Router Class Initialized
INFO - 2020-02-14 08:02:17 --> Security Class Initialized
DEBUG - 2020-02-14 08:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:17 --> Output Class Initialized
DEBUG - 2020-02-14 08:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:17 --> Input Class Initialized
INFO - 2020-02-14 08:02:17 --> Input Class Initialized
INFO - 2020-02-14 08:02:17 --> Input Class Initialized
INFO - 2020-02-14 08:02:17 --> Input Class Initialized
INFO - 2020-02-14 08:02:17 --> Input Class Initialized
INFO - 2020-02-14 08:02:17 --> Security Class Initialized
INFO - 2020-02-14 08:02:17 --> Language Class Initialized
INFO - 2020-02-14 08:02:17 --> Language Class Initialized
INFO - 2020-02-14 08:02:17 --> Language Class Initialized
INFO - 2020-02-14 08:02:17 --> Language Class Initialized
INFO - 2020-02-14 08:02:17 --> Language Class Initialized
DEBUG - 2020-02-14 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:17 --> Input Class Initialized
ERROR - 2020-02-14 08:02:17 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-14 08:02:17 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-14 08:02:17 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-14 08:02:17 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-14 08:02:17 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-14 08:02:17 --> Language Class Initialized
ERROR - 2020-02-14 08:02:17 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-14 08:02:17 --> Config Class Initialized
INFO - 2020-02-14 08:02:17 --> Config Class Initialized
INFO - 2020-02-14 08:02:17 --> Config Class Initialized
INFO - 2020-02-14 08:02:17 --> Config Class Initialized
INFO - 2020-02-14 08:02:17 --> Config Class Initialized
INFO - 2020-02-14 08:02:17 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:17 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:17 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:17 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:17 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:17 --> Config Class Initialized
DEBUG - 2020-02-14 08:02:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:02:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:02:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:02:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:02:17 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:17 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:17 --> URI Class Initialized
INFO - 2020-02-14 08:02:17 --> URI Class Initialized
INFO - 2020-02-14 08:02:17 --> URI Class Initialized
INFO - 2020-02-14 08:02:17 --> URI Class Initialized
INFO - 2020-02-14 08:02:17 --> URI Class Initialized
DEBUG - 2020-02-14 08:02:17 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:17 --> Router Class Initialized
INFO - 2020-02-14 08:02:17 --> Router Class Initialized
INFO - 2020-02-14 08:02:17 --> Router Class Initialized
INFO - 2020-02-14 08:02:17 --> Router Class Initialized
INFO - 2020-02-14 08:02:17 --> Router Class Initialized
INFO - 2020-02-14 08:02:17 --> URI Class Initialized
INFO - 2020-02-14 08:02:17 --> Output Class Initialized
INFO - 2020-02-14 08:02:17 --> Output Class Initialized
INFO - 2020-02-14 08:02:17 --> Output Class Initialized
INFO - 2020-02-14 08:02:17 --> Output Class Initialized
INFO - 2020-02-14 08:02:17 --> Output Class Initialized
INFO - 2020-02-14 08:02:17 --> Security Class Initialized
INFO - 2020-02-14 08:02:17 --> Security Class Initialized
INFO - 2020-02-14 08:02:17 --> Security Class Initialized
INFO - 2020-02-14 08:02:17 --> Security Class Initialized
INFO - 2020-02-14 08:02:17 --> Security Class Initialized
INFO - 2020-02-14 08:02:17 --> Router Class Initialized
DEBUG - 2020-02-14 08:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:17 --> Output Class Initialized
INFO - 2020-02-14 08:02:17 --> Input Class Initialized
INFO - 2020-02-14 08:02:17 --> Input Class Initialized
INFO - 2020-02-14 08:02:17 --> Input Class Initialized
INFO - 2020-02-14 08:02:17 --> Input Class Initialized
INFO - 2020-02-14 08:02:17 --> Input Class Initialized
INFO - 2020-02-14 08:02:17 --> Security Class Initialized
INFO - 2020-02-14 08:02:17 --> Language Class Initialized
INFO - 2020-02-14 08:02:17 --> Language Class Initialized
INFO - 2020-02-14 08:02:17 --> Language Class Initialized
INFO - 2020-02-14 08:02:17 --> Language Class Initialized
INFO - 2020-02-14 08:02:17 --> Language Class Initialized
DEBUG - 2020-02-14 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:17 --> Input Class Initialized
ERROR - 2020-02-14 08:02:18 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-14 08:02:18 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-14 08:02:18 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-14 08:02:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-14 08:02:18 --> Loader Class Initialized
INFO - 2020-02-14 08:02:18 --> Language Class Initialized
INFO - 2020-02-14 08:02:18 --> Helper loaded: url_helper
INFO - 2020-02-14 08:02:18 --> Config Class Initialized
INFO - 2020-02-14 08:02:18 --> Config Class Initialized
INFO - 2020-02-14 08:02:18 --> Helper loaded: string_helper
INFO - 2020-02-14 08:02:18 --> Loader Class Initialized
INFO - 2020-02-14 08:02:18 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:18 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:18 --> Helper loaded: url_helper
INFO - 2020-02-14 08:02:18 --> Database Driver Class Initialized
INFO - 2020-02-14 08:02:18 --> Helper loaded: string_helper
DEBUG - 2020-02-14 08:02:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:02:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:02:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:02:18 --> Database Driver Class Initialized
INFO - 2020-02-14 08:02:18 --> Controller Class Initialized
INFO - 2020-02-14 08:02:18 --> URI Class Initialized
INFO - 2020-02-14 08:02:18 --> URI Class Initialized
DEBUG - 2020-02-14 08:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:02:18 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:02:18 --> Router Class Initialized
INFO - 2020-02-14 08:02:18 --> Router Class Initialized
INFO - 2020-02-14 08:02:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:02:18 --> Output Class Initialized
INFO - 2020-02-14 08:02:18 --> Output Class Initialized
INFO - 2020-02-14 08:02:18 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:02:18 --> Security Class Initialized
INFO - 2020-02-14 08:02:18 --> Security Class Initialized
DEBUG - 2020-02-14 08:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:18 --> Helper loaded: form_helper
INFO - 2020-02-14 08:02:18 --> Input Class Initialized
INFO - 2020-02-14 08:02:18 --> Input Class Initialized
INFO - 2020-02-14 08:02:18 --> Form Validation Class Initialized
INFO - 2020-02-14 08:02:18 --> Language Class Initialized
INFO - 2020-02-14 08:02:18 --> Language Class Initialized
ERROR - 2020-02-14 08:02:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-14 08:02:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-14 08:02:18 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-14 08:02:18 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-14 08:02:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:02:18 --> Final output sent to browser
INFO - 2020-02-14 08:02:18 --> Config Class Initialized
DEBUG - 2020-02-14 08:02:18 --> Total execution time: 0.4419
INFO - 2020-02-14 08:02:18 --> Hooks Class Initialized
INFO - 2020-02-14 08:02:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-14 08:02:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:18 --> Controller Class Initialized
INFO - 2020-02-14 08:02:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:18 --> URI Class Initialized
INFO - 2020-02-14 08:02:18 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:02:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:02:18 --> Router Class Initialized
INFO - 2020-02-14 08:02:18 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:02:18 --> Output Class Initialized
INFO - 2020-02-14 08:02:18 --> Security Class Initialized
INFO - 2020-02-14 08:02:18 --> Helper loaded: form_helper
INFO - 2020-02-14 08:02:18 --> Form Validation Class Initialized
DEBUG - 2020-02-14 08:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:18 --> Input Class Initialized
ERROR - 2020-02-14 08:02:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-14 08:02:18 --> Language Class Initialized
ERROR - 2020-02-14 08:02:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-14 08:02:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-14 08:02:18 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-14 08:02:18 --> Final output sent to browser
DEBUG - 2020-02-14 08:02:18 --> Total execution time: 0.5735
INFO - 2020-02-14 08:02:18 --> Config Class Initialized
INFO - 2020-02-14 08:02:18 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:02:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:18 --> URI Class Initialized
INFO - 2020-02-14 08:02:18 --> Router Class Initialized
INFO - 2020-02-14 08:02:18 --> Output Class Initialized
INFO - 2020-02-14 08:02:18 --> Security Class Initialized
DEBUG - 2020-02-14 08:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:18 --> Input Class Initialized
INFO - 2020-02-14 08:02:18 --> Language Class Initialized
ERROR - 2020-02-14 08:02:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-14 08:02:18 --> Config Class Initialized
INFO - 2020-02-14 08:02:18 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:02:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:18 --> URI Class Initialized
INFO - 2020-02-14 08:02:18 --> Router Class Initialized
INFO - 2020-02-14 08:02:18 --> Output Class Initialized
INFO - 2020-02-14 08:02:18 --> Security Class Initialized
DEBUG - 2020-02-14 08:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:18 --> Input Class Initialized
INFO - 2020-02-14 08:02:18 --> Language Class Initialized
ERROR - 2020-02-14 08:02:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-14 08:02:18 --> Config Class Initialized
INFO - 2020-02-14 08:02:18 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:02:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:18 --> URI Class Initialized
INFO - 2020-02-14 08:02:18 --> Router Class Initialized
INFO - 2020-02-14 08:02:18 --> Output Class Initialized
INFO - 2020-02-14 08:02:18 --> Security Class Initialized
DEBUG - 2020-02-14 08:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:18 --> Input Class Initialized
INFO - 2020-02-14 08:02:18 --> Language Class Initialized
ERROR - 2020-02-14 08:02:19 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-14 08:02:19 --> Config Class Initialized
INFO - 2020-02-14 08:02:19 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:02:19 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:19 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:19 --> URI Class Initialized
INFO - 2020-02-14 08:02:19 --> Router Class Initialized
INFO - 2020-02-14 08:02:19 --> Output Class Initialized
INFO - 2020-02-14 08:02:19 --> Security Class Initialized
DEBUG - 2020-02-14 08:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:19 --> Input Class Initialized
INFO - 2020-02-14 08:02:19 --> Language Class Initialized
ERROR - 2020-02-14 08:02:19 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-14 08:02:19 --> Config Class Initialized
INFO - 2020-02-14 08:02:19 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:02:19 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:19 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:19 --> URI Class Initialized
INFO - 2020-02-14 08:02:19 --> Router Class Initialized
INFO - 2020-02-14 08:02:19 --> Output Class Initialized
INFO - 2020-02-14 08:02:19 --> Security Class Initialized
DEBUG - 2020-02-14 08:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:19 --> Input Class Initialized
INFO - 2020-02-14 08:02:19 --> Language Class Initialized
ERROR - 2020-02-14 08:02:19 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-14 08:02:19 --> Config Class Initialized
INFO - 2020-02-14 08:02:19 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:02:19 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:02:19 --> Utf8 Class Initialized
INFO - 2020-02-14 08:02:19 --> URI Class Initialized
INFO - 2020-02-14 08:02:19 --> Router Class Initialized
INFO - 2020-02-14 08:02:19 --> Output Class Initialized
INFO - 2020-02-14 08:02:19 --> Security Class Initialized
DEBUG - 2020-02-14 08:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:02:19 --> Input Class Initialized
INFO - 2020-02-14 08:02:19 --> Language Class Initialized
ERROR - 2020-02-14 08:02:19 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-14 08:03:03 --> Config Class Initialized
INFO - 2020-02-14 08:03:04 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:03:04 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:03:04 --> Utf8 Class Initialized
INFO - 2020-02-14 08:03:04 --> URI Class Initialized
INFO - 2020-02-14 08:03:04 --> Router Class Initialized
INFO - 2020-02-14 08:03:04 --> Output Class Initialized
INFO - 2020-02-14 08:03:04 --> Security Class Initialized
DEBUG - 2020-02-14 08:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:03:04 --> Input Class Initialized
INFO - 2020-02-14 08:03:04 --> Language Class Initialized
INFO - 2020-02-14 08:03:04 --> Loader Class Initialized
INFO - 2020-02-14 08:03:04 --> Helper loaded: url_helper
INFO - 2020-02-14 08:03:04 --> Helper loaded: string_helper
INFO - 2020-02-14 08:03:04 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:03:04 --> Controller Class Initialized
INFO - 2020-02-14 08:03:04 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:03:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:03:04 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:03:04 --> Helper loaded: form_helper
INFO - 2020-02-14 08:03:04 --> Form Validation Class Initialized
INFO - 2020-02-14 08:03:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-14 08:03:04 --> Final output sent to browser
DEBUG - 2020-02-14 08:03:04 --> Total execution time: 0.5104
INFO - 2020-02-14 08:05:11 --> Config Class Initialized
INFO - 2020-02-14 08:05:11 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:05:11 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:05:11 --> Utf8 Class Initialized
INFO - 2020-02-14 08:05:11 --> URI Class Initialized
INFO - 2020-02-14 08:05:11 --> Router Class Initialized
INFO - 2020-02-14 08:05:11 --> Output Class Initialized
INFO - 2020-02-14 08:05:11 --> Security Class Initialized
DEBUG - 2020-02-14 08:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:05:11 --> Input Class Initialized
INFO - 2020-02-14 08:05:11 --> Language Class Initialized
INFO - 2020-02-14 08:05:11 --> Loader Class Initialized
INFO - 2020-02-14 08:05:11 --> Helper loaded: url_helper
INFO - 2020-02-14 08:05:11 --> Helper loaded: string_helper
INFO - 2020-02-14 08:05:11 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:05:11 --> Controller Class Initialized
INFO - 2020-02-14 08:05:11 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:05:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:05:11 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:05:11 --> Helper loaded: form_helper
INFO - 2020-02-14 08:05:11 --> Form Validation Class Initialized
INFO - 2020-02-14 08:05:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-14 08:05:11 --> Final output sent to browser
DEBUG - 2020-02-14 08:05:11 --> Total execution time: 0.3703
INFO - 2020-02-14 08:05:49 --> Config Class Initialized
INFO - 2020-02-14 08:05:49 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:05:49 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:05:49 --> Utf8 Class Initialized
INFO - 2020-02-14 08:05:49 --> URI Class Initialized
INFO - 2020-02-14 08:05:49 --> Router Class Initialized
INFO - 2020-02-14 08:05:49 --> Output Class Initialized
INFO - 2020-02-14 08:05:49 --> Security Class Initialized
DEBUG - 2020-02-14 08:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:05:49 --> Input Class Initialized
INFO - 2020-02-14 08:05:49 --> Language Class Initialized
INFO - 2020-02-14 08:05:49 --> Loader Class Initialized
INFO - 2020-02-14 08:05:49 --> Helper loaded: url_helper
INFO - 2020-02-14 08:05:49 --> Helper loaded: string_helper
INFO - 2020-02-14 08:05:49 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:05:49 --> Controller Class Initialized
INFO - 2020-02-14 08:05:49 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:05:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:05:49 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:05:49 --> Helper loaded: form_helper
INFO - 2020-02-14 08:05:49 --> Form Validation Class Initialized
INFO - 2020-02-14 08:05:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:05:49 --> Final output sent to browser
DEBUG - 2020-02-14 08:05:49 --> Total execution time: 0.4751
INFO - 2020-02-14 08:05:49 --> Config Class Initialized
INFO - 2020-02-14 08:05:49 --> Config Class Initialized
INFO - 2020-02-14 08:05:49 --> Hooks Class Initialized
INFO - 2020-02-14 08:05:49 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:05:49 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:05:49 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:05:50 --> Utf8 Class Initialized
INFO - 2020-02-14 08:05:50 --> Utf8 Class Initialized
INFO - 2020-02-14 08:05:50 --> URI Class Initialized
INFO - 2020-02-14 08:05:50 --> URI Class Initialized
INFO - 2020-02-14 08:05:50 --> Router Class Initialized
INFO - 2020-02-14 08:05:50 --> Router Class Initialized
INFO - 2020-02-14 08:05:50 --> Output Class Initialized
INFO - 2020-02-14 08:05:50 --> Output Class Initialized
INFO - 2020-02-14 08:05:50 --> Security Class Initialized
INFO - 2020-02-14 08:05:50 --> Security Class Initialized
DEBUG - 2020-02-14 08:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:05:50 --> Input Class Initialized
INFO - 2020-02-14 08:05:50 --> Input Class Initialized
INFO - 2020-02-14 08:05:50 --> Language Class Initialized
INFO - 2020-02-14 08:05:50 --> Language Class Initialized
INFO - 2020-02-14 08:05:50 --> Loader Class Initialized
INFO - 2020-02-14 08:05:50 --> Loader Class Initialized
INFO - 2020-02-14 08:05:50 --> Helper loaded: url_helper
INFO - 2020-02-14 08:05:50 --> Helper loaded: url_helper
INFO - 2020-02-14 08:05:50 --> Helper loaded: string_helper
INFO - 2020-02-14 08:05:50 --> Helper loaded: string_helper
INFO - 2020-02-14 08:05:50 --> Database Driver Class Initialized
INFO - 2020-02-14 08:05:50 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-14 08:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:05:50 --> Controller Class Initialized
INFO - 2020-02-14 08:05:50 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:05:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:05:50 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:05:50 --> Helper loaded: form_helper
INFO - 2020-02-14 08:05:50 --> Form Validation Class Initialized
ERROR - 2020-02-14 08:05:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-14 08:05:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-14 08:05:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:05:50 --> Final output sent to browser
DEBUG - 2020-02-14 08:05:50 --> Total execution time: 0.6029
INFO - 2020-02-14 08:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:05:50 --> Controller Class Initialized
INFO - 2020-02-14 08:05:50 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:05:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:05:50 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:05:50 --> Helper loaded: form_helper
INFO - 2020-02-14 08:05:50 --> Form Validation Class Initialized
ERROR - 2020-02-14 08:05:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-14 08:05:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-14 08:05:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:05:50 --> Final output sent to browser
DEBUG - 2020-02-14 08:05:50 --> Total execution time: 0.7745
INFO - 2020-02-14 08:05:55 --> Config Class Initialized
INFO - 2020-02-14 08:05:55 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:05:55 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:05:55 --> Utf8 Class Initialized
INFO - 2020-02-14 08:05:55 --> URI Class Initialized
INFO - 2020-02-14 08:05:55 --> Router Class Initialized
INFO - 2020-02-14 08:05:55 --> Output Class Initialized
INFO - 2020-02-14 08:05:56 --> Security Class Initialized
DEBUG - 2020-02-14 08:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:05:56 --> Input Class Initialized
INFO - 2020-02-14 08:05:56 --> Language Class Initialized
INFO - 2020-02-14 08:05:56 --> Loader Class Initialized
INFO - 2020-02-14 08:05:56 --> Helper loaded: url_helper
INFO - 2020-02-14 08:05:56 --> Helper loaded: string_helper
INFO - 2020-02-14 08:05:56 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:05:56 --> Controller Class Initialized
INFO - 2020-02-14 08:05:56 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:05:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:05:56 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:05:56 --> Helper loaded: form_helper
INFO - 2020-02-14 08:05:56 --> Form Validation Class Initialized
INFO - 2020-02-14 08:05:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:05:56 --> Final output sent to browser
DEBUG - 2020-02-14 08:05:56 --> Total execution time: 0.3986
INFO - 2020-02-14 08:05:56 --> Config Class Initialized
INFO - 2020-02-14 08:05:56 --> Config Class Initialized
INFO - 2020-02-14 08:05:56 --> Hooks Class Initialized
INFO - 2020-02-14 08:05:56 --> Config Class Initialized
INFO - 2020-02-14 08:05:56 --> Hooks Class Initialized
INFO - 2020-02-14 08:05:56 --> Config Class Initialized
INFO - 2020-02-14 08:05:56 --> Config Class Initialized
INFO - 2020-02-14 08:05:56 --> Hooks Class Initialized
INFO - 2020-02-14 08:05:56 --> Hooks Class Initialized
INFO - 2020-02-14 08:05:56 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:05:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:05:56 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:05:56 --> Utf8 Class Initialized
DEBUG - 2020-02-14 08:05:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:05:56 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:05:56 --> Utf8 Class Initialized
DEBUG - 2020-02-14 08:05:56 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:05:56 --> Utf8 Class Initialized
INFO - 2020-02-14 08:05:56 --> Utf8 Class Initialized
INFO - 2020-02-14 08:05:56 --> Utf8 Class Initialized
INFO - 2020-02-14 08:05:56 --> URI Class Initialized
INFO - 2020-02-14 08:05:56 --> URI Class Initialized
INFO - 2020-02-14 08:05:56 --> URI Class Initialized
INFO - 2020-02-14 08:05:56 --> URI Class Initialized
INFO - 2020-02-14 08:05:56 --> URI Class Initialized
INFO - 2020-02-14 08:05:56 --> Router Class Initialized
INFO - 2020-02-14 08:05:56 --> Router Class Initialized
INFO - 2020-02-14 08:05:56 --> Output Class Initialized
INFO - 2020-02-14 08:05:56 --> Output Class Initialized
INFO - 2020-02-14 08:05:56 --> Router Class Initialized
INFO - 2020-02-14 08:05:56 --> Router Class Initialized
INFO - 2020-02-14 08:05:56 --> Router Class Initialized
INFO - 2020-02-14 08:05:56 --> Security Class Initialized
INFO - 2020-02-14 08:05:56 --> Security Class Initialized
INFO - 2020-02-14 08:05:56 --> Output Class Initialized
INFO - 2020-02-14 08:05:56 --> Output Class Initialized
INFO - 2020-02-14 08:05:56 --> Output Class Initialized
DEBUG - 2020-02-14 08:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:05:56 --> Security Class Initialized
DEBUG - 2020-02-14 08:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:05:56 --> Security Class Initialized
INFO - 2020-02-14 08:05:56 --> Security Class Initialized
INFO - 2020-02-14 08:05:56 --> Input Class Initialized
INFO - 2020-02-14 08:05:56 --> Input Class Initialized
DEBUG - 2020-02-14 08:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:05:56 --> Input Class Initialized
INFO - 2020-02-14 08:05:56 --> Input Class Initialized
INFO - 2020-02-14 08:05:56 --> Language Class Initialized
INFO - 2020-02-14 08:05:56 --> Language Class Initialized
INFO - 2020-02-14 08:05:56 --> Input Class Initialized
INFO - 2020-02-14 08:05:56 --> Language Class Initialized
INFO - 2020-02-14 08:05:56 --> Language Class Initialized
ERROR - 2020-02-14 08:05:56 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-14 08:05:56 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-14 08:05:56 --> Language Class Initialized
ERROR - 2020-02-14 08:05:56 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-14 08:05:56 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-14 08:05:56 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-14 08:05:56 --> Config Class Initialized
INFO - 2020-02-14 08:05:56 --> Config Class Initialized
INFO - 2020-02-14 08:05:56 --> Hooks Class Initialized
INFO - 2020-02-14 08:05:56 --> Config Class Initialized
INFO - 2020-02-14 08:05:56 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:00 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:06:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:00 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:00 --> Config Class Initialized
INFO - 2020-02-14 08:06:01 --> Config Class Initialized
INFO - 2020-02-14 08:06:01 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:01 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:01 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:01 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:06 --> Config Class Initialized
INFO - 2020-02-14 08:06:06 --> Config Class Initialized
INFO - 2020-02-14 08:06:06 --> Config Class Initialized
INFO - 2020-02-14 08:06:06 --> Config Class Initialized
INFO - 2020-02-14 08:06:06 --> Config Class Initialized
INFO - 2020-02-14 08:06:06 --> Config Class Initialized
INFO - 2020-02-14 08:06:06 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:06 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:06 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:06 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:06 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:06 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:06:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:06 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:06 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:06 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:06 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:06 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:06 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:06 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:06 --> URI Class Initialized
INFO - 2020-02-14 08:06:06 --> URI Class Initialized
INFO - 2020-02-14 08:06:06 --> URI Class Initialized
INFO - 2020-02-14 08:06:06 --> URI Class Initialized
INFO - 2020-02-14 08:06:06 --> URI Class Initialized
INFO - 2020-02-14 08:06:06 --> URI Class Initialized
INFO - 2020-02-14 08:06:06 --> Router Class Initialized
INFO - 2020-02-14 08:06:06 --> Router Class Initialized
INFO - 2020-02-14 08:06:06 --> Router Class Initialized
INFO - 2020-02-14 08:06:06 --> Router Class Initialized
INFO - 2020-02-14 08:06:06 --> Router Class Initialized
INFO - 2020-02-14 08:06:06 --> Router Class Initialized
INFO - 2020-02-14 08:06:06 --> Output Class Initialized
INFO - 2020-02-14 08:06:06 --> Output Class Initialized
INFO - 2020-02-14 08:06:06 --> Output Class Initialized
INFO - 2020-02-14 08:06:06 --> Output Class Initialized
INFO - 2020-02-14 08:06:06 --> Output Class Initialized
INFO - 2020-02-14 08:06:06 --> Output Class Initialized
INFO - 2020-02-14 08:06:06 --> Security Class Initialized
INFO - 2020-02-14 08:06:06 --> Security Class Initialized
INFO - 2020-02-14 08:06:06 --> Security Class Initialized
INFO - 2020-02-14 08:06:06 --> Security Class Initialized
INFO - 2020-02-14 08:06:06 --> Security Class Initialized
INFO - 2020-02-14 08:06:06 --> Security Class Initialized
DEBUG - 2020-02-14 08:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:06 --> Input Class Initialized
INFO - 2020-02-14 08:06:06 --> Input Class Initialized
INFO - 2020-02-14 08:06:06 --> Input Class Initialized
INFO - 2020-02-14 08:06:06 --> Input Class Initialized
INFO - 2020-02-14 08:06:06 --> Input Class Initialized
INFO - 2020-02-14 08:06:06 --> Input Class Initialized
INFO - 2020-02-14 08:06:06 --> Language Class Initialized
INFO - 2020-02-14 08:06:06 --> Language Class Initialized
INFO - 2020-02-14 08:06:06 --> Language Class Initialized
INFO - 2020-02-14 08:06:06 --> Language Class Initialized
INFO - 2020-02-14 08:06:06 --> Language Class Initialized
INFO - 2020-02-14 08:06:06 --> Language Class Initialized
ERROR - 2020-02-14 08:06:06 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-14 08:06:06 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-14 08:06:06 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-14 08:06:06 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-14 08:06:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-14 08:06:06 --> Loader Class Initialized
INFO - 2020-02-14 08:06:06 --> Helper loaded: url_helper
INFO - 2020-02-14 08:06:06 --> Config Class Initialized
INFO - 2020-02-14 08:06:06 --> Config Class Initialized
INFO - 2020-02-14 08:06:06 --> Config Class Initialized
INFO - 2020-02-14 08:06:06 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:06 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:06 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:06 --> Helper loaded: string_helper
DEBUG - 2020-02-14 08:06:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:06 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:06 --> Database Driver Class Initialized
INFO - 2020-02-14 08:06:06 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:06 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:06 --> Utf8 Class Initialized
DEBUG - 2020-02-14 08:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:06:06 --> URI Class Initialized
INFO - 2020-02-14 08:06:06 --> URI Class Initialized
INFO - 2020-02-14 08:06:06 --> URI Class Initialized
INFO - 2020-02-14 08:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:06:06 --> Controller Class Initialized
INFO - 2020-02-14 08:06:06 --> Router Class Initialized
INFO - 2020-02-14 08:06:06 --> Router Class Initialized
INFO - 2020-02-14 08:06:06 --> Router Class Initialized
INFO - 2020-02-14 08:06:06 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:06:06 --> Output Class Initialized
INFO - 2020-02-14 08:06:06 --> Output Class Initialized
INFO - 2020-02-14 08:06:06 --> Output Class Initialized
INFO - 2020-02-14 08:06:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:06:06 --> Security Class Initialized
INFO - 2020-02-14 08:06:06 --> Security Class Initialized
INFO - 2020-02-14 08:06:06 --> Security Class Initialized
INFO - 2020-02-14 08:06:06 --> Model "M_pesan" initialized
DEBUG - 2020-02-14 08:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:06 --> Input Class Initialized
INFO - 2020-02-14 08:06:06 --> Input Class Initialized
INFO - 2020-02-14 08:06:06 --> Input Class Initialized
INFO - 2020-02-14 08:06:06 --> Helper loaded: form_helper
INFO - 2020-02-14 08:06:06 --> Form Validation Class Initialized
INFO - 2020-02-14 08:06:06 --> Language Class Initialized
INFO - 2020-02-14 08:06:06 --> Language Class Initialized
INFO - 2020-02-14 08:06:06 --> Language Class Initialized
ERROR - 2020-02-14 08:06:06 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-14 08:06:06 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-14 08:06:06 --> Loader Class Initialized
ERROR - 2020-02-14 08:06:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-14 08:06:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-14 08:06:06 --> Helper loaded: url_helper
INFO - 2020-02-14 08:06:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:06:06 --> Helper loaded: string_helper
INFO - 2020-02-14 08:06:06 --> Final output sent to browser
INFO - 2020-02-14 08:06:06 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:06:06 --> Total execution time: 0.4619
DEBUG - 2020-02-14 08:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:06:06 --> Controller Class Initialized
INFO - 2020-02-14 08:06:06 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:06:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:06:06 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:06:06 --> Helper loaded: form_helper
INFO - 2020-02-14 08:06:06 --> Form Validation Class Initialized
ERROR - 2020-02-14 08:06:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-14 08:06:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-14 08:06:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:06:06 --> Final output sent to browser
DEBUG - 2020-02-14 08:06:06 --> Total execution time: 0.4117
INFO - 2020-02-14 08:06:17 --> Config Class Initialized
INFO - 2020-02-14 08:06:17 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:06:17 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:17 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:17 --> URI Class Initialized
INFO - 2020-02-14 08:06:17 --> Router Class Initialized
INFO - 2020-02-14 08:06:17 --> Output Class Initialized
INFO - 2020-02-14 08:06:17 --> Security Class Initialized
DEBUG - 2020-02-14 08:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:17 --> Input Class Initialized
INFO - 2020-02-14 08:06:17 --> Language Class Initialized
INFO - 2020-02-14 08:06:17 --> Loader Class Initialized
INFO - 2020-02-14 08:06:17 --> Helper loaded: url_helper
INFO - 2020-02-14 08:06:17 --> Helper loaded: string_helper
INFO - 2020-02-14 08:06:17 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:06:17 --> Controller Class Initialized
INFO - 2020-02-14 08:06:17 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:06:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:06:17 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:06:17 --> Helper loaded: form_helper
INFO - 2020-02-14 08:06:17 --> Form Validation Class Initialized
INFO - 2020-02-14 08:06:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:06:17 --> Final output sent to browser
DEBUG - 2020-02-14 08:06:17 --> Total execution time: 0.4450
INFO - 2020-02-14 08:06:17 --> Config Class Initialized
INFO - 2020-02-14 08:06:17 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:17 --> Config Class Initialized
INFO - 2020-02-14 08:06:17 --> Config Class Initialized
INFO - 2020-02-14 08:06:17 --> Config Class Initialized
INFO - 2020-02-14 08:06:17 --> Config Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:18 --> Config Class Initialized
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
ERROR - 2020-02-14 08:06:18 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
ERROR - 2020-02-14 08:06:18 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-14 08:06:18 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-14 08:06:18 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-14 08:06:18 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-14 08:06:18 --> Config Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
ERROR - 2020-02-14 08:06:18 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-14 08:06:18 --> Config Class Initialized
INFO - 2020-02-14 08:06:18 --> Config Class Initialized
INFO - 2020-02-14 08:06:18 --> Config Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:18 --> Config Class Initialized
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:18 --> Config Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
ERROR - 2020-02-14 08:06:18 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
INFO - 2020-02-14 08:06:18 --> Loader Class Initialized
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
INFO - 2020-02-14 08:06:18 --> Helper loaded: url_helper
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
ERROR - 2020-02-14 08:06:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-14 08:06:18 --> Loader Class Initialized
INFO - 2020-02-14 08:06:18 --> Config Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:18 --> Helper loaded: string_helper
INFO - 2020-02-14 08:06:18 --> Helper loaded: url_helper
ERROR - 2020-02-14 08:06:18 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-14 08:06:18 --> Helper loaded: string_helper
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
ERROR - 2020-02-14 08:06:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-14 08:06:18 --> Database Driver Class Initialized
INFO - 2020-02-14 08:06:18 --> Config Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
DEBUG - 2020-02-14 08:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:06:18 --> Database Driver Class Initialized
INFO - 2020-02-14 08:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-14 08:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:06:18 --> Controller Class Initialized
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> URI Class Initialized
INFO - 2020-02-14 08:06:18 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
INFO - 2020-02-14 08:06:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:06:18 --> Router Class Initialized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
INFO - 2020-02-14 08:06:18 --> Model "M_pesan" initialized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:18 --> Output Class Initialized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
INFO - 2020-02-14 08:06:18 --> Security Class Initialized
INFO - 2020-02-14 08:06:18 --> Helper loaded: form_helper
INFO - 2020-02-14 08:06:18 --> Form Validation Class Initialized
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
DEBUG - 2020-02-14 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:18 --> Input Class Initialized
ERROR - 2020-02-14 08:06:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-14 08:06:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-14 08:06:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-14 08:06:18 --> Language Class Initialized
INFO - 2020-02-14 08:06:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-14 08:06:18 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-14 08:06:18 --> Final output sent to browser
INFO - 2020-02-14 08:06:18 --> Config Class Initialized
INFO - 2020-02-14 08:06:18 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:06:18 --> Total execution time: 0.7080
INFO - 2020-02-14 08:06:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-14 08:06:18 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:18 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:18 --> Controller Class Initialized
INFO - 2020-02-14 08:06:19 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:06:19 --> URI Class Initialized
INFO - 2020-02-14 08:06:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:06:19 --> Router Class Initialized
INFO - 2020-02-14 08:06:19 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:06:19 --> Output Class Initialized
INFO - 2020-02-14 08:06:19 --> Security Class Initialized
INFO - 2020-02-14 08:06:19 --> Helper loaded: form_helper
INFO - 2020-02-14 08:06:19 --> Form Validation Class Initialized
DEBUG - 2020-02-14 08:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:19 --> Input Class Initialized
ERROR - 2020-02-14 08:06:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-14 08:06:19 --> Language Class Initialized
ERROR - 2020-02-14 08:06:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-14 08:06:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-14 08:06:19 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-14 08:06:19 --> Final output sent to browser
INFO - 2020-02-14 08:06:19 --> Config Class Initialized
INFO - 2020-02-14 08:06:19 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:06:19 --> Total execution time: 0.9744
DEBUG - 2020-02-14 08:06:19 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:19 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:19 --> URI Class Initialized
INFO - 2020-02-14 08:06:19 --> Router Class Initialized
INFO - 2020-02-14 08:06:19 --> Output Class Initialized
INFO - 2020-02-14 08:06:19 --> Security Class Initialized
DEBUG - 2020-02-14 08:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:19 --> Input Class Initialized
INFO - 2020-02-14 08:06:19 --> Language Class Initialized
ERROR - 2020-02-14 08:06:19 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-14 08:06:19 --> Config Class Initialized
INFO - 2020-02-14 08:06:19 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:06:19 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:19 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:19 --> URI Class Initialized
INFO - 2020-02-14 08:06:19 --> Router Class Initialized
INFO - 2020-02-14 08:06:19 --> Output Class Initialized
INFO - 2020-02-14 08:06:19 --> Security Class Initialized
DEBUG - 2020-02-14 08:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:19 --> Input Class Initialized
INFO - 2020-02-14 08:06:19 --> Language Class Initialized
ERROR - 2020-02-14 08:06:19 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-14 08:06:19 --> Config Class Initialized
INFO - 2020-02-14 08:06:19 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:06:19 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:19 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:19 --> URI Class Initialized
INFO - 2020-02-14 08:06:19 --> Router Class Initialized
INFO - 2020-02-14 08:06:19 --> Output Class Initialized
INFO - 2020-02-14 08:06:19 --> Security Class Initialized
DEBUG - 2020-02-14 08:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:19 --> Input Class Initialized
INFO - 2020-02-14 08:06:19 --> Language Class Initialized
ERROR - 2020-02-14 08:06:19 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-14 08:06:19 --> Config Class Initialized
INFO - 2020-02-14 08:06:19 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:06:20 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:20 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:20 --> URI Class Initialized
INFO - 2020-02-14 08:06:20 --> Router Class Initialized
INFO - 2020-02-14 08:06:20 --> Output Class Initialized
INFO - 2020-02-14 08:06:20 --> Security Class Initialized
DEBUG - 2020-02-14 08:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:20 --> Input Class Initialized
INFO - 2020-02-14 08:06:20 --> Language Class Initialized
ERROR - 2020-02-14 08:06:20 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-14 08:06:20 --> Config Class Initialized
INFO - 2020-02-14 08:06:20 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:06:20 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:20 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:20 --> URI Class Initialized
INFO - 2020-02-14 08:06:20 --> Router Class Initialized
INFO - 2020-02-14 08:06:20 --> Output Class Initialized
INFO - 2020-02-14 08:06:20 --> Security Class Initialized
DEBUG - 2020-02-14 08:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:20 --> Input Class Initialized
INFO - 2020-02-14 08:06:20 --> Language Class Initialized
ERROR - 2020-02-14 08:06:20 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-14 08:06:20 --> Config Class Initialized
INFO - 2020-02-14 08:06:20 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:06:20 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:20 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:20 --> URI Class Initialized
INFO - 2020-02-14 08:06:20 --> Router Class Initialized
INFO - 2020-02-14 08:06:20 --> Output Class Initialized
INFO - 2020-02-14 08:06:20 --> Security Class Initialized
DEBUG - 2020-02-14 08:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:20 --> Input Class Initialized
INFO - 2020-02-14 08:06:20 --> Language Class Initialized
ERROR - 2020-02-14 08:06:20 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-14 08:06:20 --> Config Class Initialized
INFO - 2020-02-14 08:06:20 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:06:20 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:06:20 --> Utf8 Class Initialized
INFO - 2020-02-14 08:06:20 --> URI Class Initialized
INFO - 2020-02-14 08:06:20 --> Router Class Initialized
INFO - 2020-02-14 08:06:20 --> Output Class Initialized
INFO - 2020-02-14 08:06:20 --> Security Class Initialized
DEBUG - 2020-02-14 08:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:06:20 --> Input Class Initialized
INFO - 2020-02-14 08:06:20 --> Language Class Initialized
ERROR - 2020-02-14 08:06:20 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-14 08:07:22 --> Config Class Initialized
INFO - 2020-02-14 08:07:22 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:07:22 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:07:22 --> Utf8 Class Initialized
INFO - 2020-02-14 08:07:22 --> URI Class Initialized
INFO - 2020-02-14 08:07:22 --> Router Class Initialized
INFO - 2020-02-14 08:07:22 --> Output Class Initialized
INFO - 2020-02-14 08:07:22 --> Security Class Initialized
DEBUG - 2020-02-14 08:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:07:22 --> Input Class Initialized
INFO - 2020-02-14 08:07:22 --> Language Class Initialized
INFO - 2020-02-14 08:07:22 --> Loader Class Initialized
INFO - 2020-02-14 08:07:22 --> Helper loaded: url_helper
INFO - 2020-02-14 08:07:22 --> Helper loaded: string_helper
INFO - 2020-02-14 08:07:22 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:07:22 --> Controller Class Initialized
INFO - 2020-02-14 08:07:22 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:07:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:07:22 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:07:22 --> Helper loaded: form_helper
INFO - 2020-02-14 08:07:22 --> Form Validation Class Initialized
INFO - 2020-02-14 08:07:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-14 08:07:22 --> Final output sent to browser
DEBUG - 2020-02-14 08:07:22 --> Total execution time: 0.4877
INFO - 2020-02-14 08:30:59 --> Config Class Initialized
INFO - 2020-02-14 08:30:59 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:30:59 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:30:59 --> Utf8 Class Initialized
INFO - 2020-02-14 08:30:59 --> URI Class Initialized
INFO - 2020-02-14 08:30:59 --> Router Class Initialized
INFO - 2020-02-14 08:30:59 --> Output Class Initialized
INFO - 2020-02-14 08:30:59 --> Security Class Initialized
DEBUG - 2020-02-14 08:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:30:59 --> Input Class Initialized
INFO - 2020-02-14 08:30:59 --> Language Class Initialized
INFO - 2020-02-14 08:30:59 --> Loader Class Initialized
INFO - 2020-02-14 08:30:59 --> Helper loaded: url_helper
INFO - 2020-02-14 08:30:59 --> Helper loaded: string_helper
INFO - 2020-02-14 08:30:59 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:30:59 --> Controller Class Initialized
INFO - 2020-02-14 08:30:59 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:30:59 --> Model "M_pengunjung" initialized
ERROR - 2020-02-14 08:30:59 --> Severity: error --> Exception: syntax error, unexpected '$query' (T_VARIABLE) C:\xampp\htdocs\roadshow\application\models\M_pesan.php 51
INFO - 2020-02-14 08:32:12 --> Config Class Initialized
INFO - 2020-02-14 08:32:12 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:32:12 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:32:12 --> Utf8 Class Initialized
INFO - 2020-02-14 08:32:12 --> URI Class Initialized
INFO - 2020-02-14 08:32:12 --> Router Class Initialized
INFO - 2020-02-14 08:32:12 --> Output Class Initialized
INFO - 2020-02-14 08:32:12 --> Security Class Initialized
DEBUG - 2020-02-14 08:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:32:12 --> Input Class Initialized
INFO - 2020-02-14 08:32:12 --> Language Class Initialized
INFO - 2020-02-14 08:32:12 --> Loader Class Initialized
INFO - 2020-02-14 08:32:12 --> Helper loaded: url_helper
INFO - 2020-02-14 08:32:12 --> Helper loaded: string_helper
INFO - 2020-02-14 08:32:12 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:32:12 --> Controller Class Initialized
INFO - 2020-02-14 08:32:12 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:32:12 --> Model "M_pengunjung" initialized
ERROR - 2020-02-14 08:32:12 --> Severity: error --> Exception: syntax error, unexpected '$query' (T_VARIABLE) C:\xampp\htdocs\roadshow\application\models\M_pesan.php 51
INFO - 2020-02-14 08:36:29 --> Config Class Initialized
INFO - 2020-02-14 08:36:29 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:36:29 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:36:29 --> Utf8 Class Initialized
INFO - 2020-02-14 08:36:29 --> URI Class Initialized
INFO - 2020-02-14 08:36:29 --> Router Class Initialized
INFO - 2020-02-14 08:36:29 --> Output Class Initialized
INFO - 2020-02-14 08:36:29 --> Security Class Initialized
DEBUG - 2020-02-14 08:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:36:29 --> Input Class Initialized
INFO - 2020-02-14 08:36:29 --> Language Class Initialized
INFO - 2020-02-14 08:36:29 --> Loader Class Initialized
INFO - 2020-02-14 08:36:29 --> Helper loaded: url_helper
INFO - 2020-02-14 08:36:29 --> Helper loaded: string_helper
INFO - 2020-02-14 08:36:29 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:36:29 --> Controller Class Initialized
INFO - 2020-02-14 08:36:29 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:36:29 --> Model "M_pengunjung" initialized
ERROR - 2020-02-14 08:36:29 --> Severity: error --> Exception: syntax error, unexpected '$query' (T_VARIABLE) C:\xampp\htdocs\roadshow\application\models\M_pesan.php 51
INFO - 2020-02-14 08:37:15 --> Config Class Initialized
INFO - 2020-02-14 08:37:15 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:37:15 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:37:15 --> Utf8 Class Initialized
INFO - 2020-02-14 08:37:15 --> URI Class Initialized
INFO - 2020-02-14 08:37:15 --> Router Class Initialized
INFO - 2020-02-14 08:37:15 --> Output Class Initialized
INFO - 2020-02-14 08:37:15 --> Security Class Initialized
DEBUG - 2020-02-14 08:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:37:15 --> Input Class Initialized
INFO - 2020-02-14 08:37:15 --> Language Class Initialized
INFO - 2020-02-14 08:37:15 --> Loader Class Initialized
INFO - 2020-02-14 08:37:15 --> Helper loaded: url_helper
INFO - 2020-02-14 08:37:15 --> Helper loaded: string_helper
INFO - 2020-02-14 08:37:15 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:37:15 --> Controller Class Initialized
INFO - 2020-02-14 08:37:15 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:37:15 --> Model "M_pengunjung" initialized
ERROR - 2020-02-14 08:37:15 --> Severity: error --> Exception: syntax error, unexpected '$query' (T_VARIABLE) C:\xampp\htdocs\roadshow\application\models\M_pesan.php 51
INFO - 2020-02-14 08:37:49 --> Config Class Initialized
INFO - 2020-02-14 08:37:49 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:37:49 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:37:49 --> Utf8 Class Initialized
INFO - 2020-02-14 08:37:49 --> URI Class Initialized
INFO - 2020-02-14 08:37:49 --> Router Class Initialized
INFO - 2020-02-14 08:37:49 --> Output Class Initialized
INFO - 2020-02-14 08:37:49 --> Security Class Initialized
DEBUG - 2020-02-14 08:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:37:49 --> Input Class Initialized
INFO - 2020-02-14 08:37:49 --> Language Class Initialized
INFO - 2020-02-14 08:37:49 --> Loader Class Initialized
INFO - 2020-02-14 08:37:49 --> Helper loaded: url_helper
INFO - 2020-02-14 08:37:49 --> Helper loaded: string_helper
INFO - 2020-02-14 08:37:49 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:37:49 --> Controller Class Initialized
INFO - 2020-02-14 08:37:49 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:37:49 --> Model "M_pengunjung" initialized
ERROR - 2020-02-14 08:37:49 --> Severity: error --> Exception: syntax error, unexpected '$query1' (T_VARIABLE) C:\xampp\htdocs\roadshow\application\models\M_pesan.php 51
INFO - 2020-02-14 08:44:45 --> Config Class Initialized
INFO - 2020-02-14 08:44:45 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:44:45 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:44:45 --> Utf8 Class Initialized
INFO - 2020-02-14 08:44:45 --> URI Class Initialized
INFO - 2020-02-14 08:44:45 --> Router Class Initialized
INFO - 2020-02-14 08:44:45 --> Output Class Initialized
INFO - 2020-02-14 08:44:45 --> Security Class Initialized
DEBUG - 2020-02-14 08:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:44:45 --> Input Class Initialized
INFO - 2020-02-14 08:44:45 --> Language Class Initialized
INFO - 2020-02-14 08:44:45 --> Loader Class Initialized
INFO - 2020-02-14 08:44:45 --> Helper loaded: url_helper
INFO - 2020-02-14 08:44:45 --> Helper loaded: string_helper
INFO - 2020-02-14 08:44:45 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:44:45 --> Controller Class Initialized
INFO - 2020-02-14 08:44:45 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:44:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:44:45 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:44:46 --> Helper loaded: form_helper
INFO - 2020-02-14 08:44:46 --> Form Validation Class Initialized
ERROR - 2020-02-14 08:44:46 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-14 08:45:22 --> Config Class Initialized
INFO - 2020-02-14 08:45:22 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:45:22 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:45:22 --> Utf8 Class Initialized
INFO - 2020-02-14 08:45:22 --> URI Class Initialized
INFO - 2020-02-14 08:45:22 --> Router Class Initialized
INFO - 2020-02-14 08:45:22 --> Output Class Initialized
INFO - 2020-02-14 08:45:22 --> Security Class Initialized
DEBUG - 2020-02-14 08:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:45:22 --> Input Class Initialized
INFO - 2020-02-14 08:45:22 --> Language Class Initialized
INFO - 2020-02-14 08:45:22 --> Loader Class Initialized
INFO - 2020-02-14 08:45:22 --> Helper loaded: url_helper
INFO - 2020-02-14 08:45:22 --> Helper loaded: string_helper
INFO - 2020-02-14 08:45:22 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:45:22 --> Controller Class Initialized
INFO - 2020-02-14 08:45:22 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:45:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:45:22 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:45:22 --> Helper loaded: form_helper
INFO - 2020-02-14 08:45:22 --> Form Validation Class Initialized
INFO - 2020-02-14 08:45:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-14 08:45:22 --> Final output sent to browser
DEBUG - 2020-02-14 08:45:22 --> Total execution time: 0.6051
INFO - 2020-02-14 08:53:22 --> Config Class Initialized
INFO - 2020-02-14 08:53:22 --> Hooks Class Initialized
DEBUG - 2020-02-14 08:53:22 --> UTF-8 Support Enabled
INFO - 2020-02-14 08:53:22 --> Utf8 Class Initialized
INFO - 2020-02-14 08:53:22 --> URI Class Initialized
INFO - 2020-02-14 08:53:22 --> Router Class Initialized
INFO - 2020-02-14 08:53:22 --> Output Class Initialized
INFO - 2020-02-14 08:53:22 --> Security Class Initialized
DEBUG - 2020-02-14 08:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-14 08:53:22 --> Input Class Initialized
INFO - 2020-02-14 08:53:22 --> Language Class Initialized
INFO - 2020-02-14 08:53:22 --> Loader Class Initialized
INFO - 2020-02-14 08:53:22 --> Helper loaded: url_helper
INFO - 2020-02-14 08:53:22 --> Helper loaded: string_helper
INFO - 2020-02-14 08:53:22 --> Database Driver Class Initialized
DEBUG - 2020-02-14 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-14 08:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-14 08:53:22 --> Controller Class Initialized
INFO - 2020-02-14 08:53:22 --> Model "M_tiket" initialized
INFO - 2020-02-14 08:53:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-14 08:53:22 --> Model "M_pesan" initialized
INFO - 2020-02-14 08:53:22 --> Helper loaded: form_helper
INFO - 2020-02-14 08:53:22 --> Form Validation Class Initialized
INFO - 2020-02-14 08:53:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-14 08:53:22 --> Final output sent to browser
DEBUG - 2020-02-14 08:53:22 --> Total execution time: 0.4666
