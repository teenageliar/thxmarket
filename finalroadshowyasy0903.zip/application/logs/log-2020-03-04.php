<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-04 00:00:24 --> Upload Class Initialized
INFO - 2020-03-04 00:02:08 --> Upload Class Initialized
INFO - 2020-03-04 00:49:59 --> Final output sent to browser
DEBUG - 2020-03-04 00:49:59 --> Total execution time: 0.1223
INFO - 2020-03-04 00:54:48 --> Upload Class Initialized
INFO - 2020-03-04 00:54:48 --> Language file loaded: language/english/upload_lang.php
INFO - 2020-03-04 00:54:48 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2020-03-04 01:00:44 --> Final output sent to browser
DEBUG - 2020-03-04 01:00:44 --> Total execution time: 0.5480
INFO - 2020-03-04 01:01:08 --> Upload Class Initialized
INFO - 2020-03-04 01:01:08 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2020-03-04 01:01:08 --> You did not select a file to upload.
INFO - 2020-03-04 01:45:35 --> Final output sent to browser
DEBUG - 2020-03-04 01:45:35 --> Total execution time: 0.1230
INFO - 2020-03-04 02:03:22 --> Final output sent to browser
DEBUG - 2020-03-04 02:03:22 --> Total execution time: 0.1573
INFO - 2020-03-04 02:30:21 --> Final output sent to browser
DEBUG - 2020-03-04 02:30:21 --> Total execution time: 0.1408
INFO - 2020-03-04 02:37:01 --> Upload Class Initialized
INFO - 2020-03-04 02:37:01 --> Language file loaded: language/english/upload_lang.php
INFO - 2020-03-04 02:37:01 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2020-03-04 05:52:18 --> Final output sent to browser
DEBUG - 2020-03-04 05:52:18 --> Total execution time: 0.1983
INFO - 2020-03-04 06:06:48 --> Final output sent to browser
DEBUG - 2020-03-04 06:06:48 --> Total execution time: 0.1526
INFO - 2020-03-04 00:01:49 --> Config Class Initialized
INFO - 2020-03-04 00:01:49 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:01:49 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:01:49 --> Utf8 Class Initialized
INFO - 2020-03-04 00:01:49 --> URI Class Initialized
DEBUG - 2020-03-04 00:01:49 --> No URI present. Default controller set.
INFO - 2020-03-04 00:01:49 --> Router Class Initialized
INFO - 2020-03-04 00:01:49 --> Output Class Initialized
INFO - 2020-03-04 00:01:49 --> Security Class Initialized
DEBUG - 2020-03-04 00:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:01:49 --> Input Class Initialized
INFO - 2020-03-04 00:01:49 --> Language Class Initialized
INFO - 2020-03-04 00:01:49 --> Loader Class Initialized
INFO - 2020-03-04 00:01:49 --> Helper loaded: url_helper
INFO - 2020-03-04 00:01:49 --> Helper loaded: string_helper
INFO - 2020-03-04 00:01:49 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:01:49 --> Controller Class Initialized
INFO - 2020-03-04 00:01:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:01:49 --> Pagination Class Initialized
INFO - 2020-03-04 00:01:49 --> Model "M_show" initialized
INFO - 2020-03-04 00:01:49 --> Helper loaded: form_helper
INFO - 2020-03-04 00:01:49 --> Form Validation Class Initialized
INFO - 2020-03-04 00:01:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:01:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 00:01:49 --> Final output sent to browser
DEBUG - 2020-03-04 00:01:49 --> Total execution time: 0.0358
INFO - 2020-03-04 00:02:09 --> Config Class Initialized
INFO - 2020-03-04 00:02:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:02:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:02:09 --> Utf8 Class Initialized
INFO - 2020-03-04 00:02:09 --> URI Class Initialized
DEBUG - 2020-03-04 00:02:09 --> No URI present. Default controller set.
INFO - 2020-03-04 00:02:09 --> Router Class Initialized
INFO - 2020-03-04 00:02:09 --> Output Class Initialized
INFO - 2020-03-04 00:02:09 --> Security Class Initialized
DEBUG - 2020-03-04 00:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:02:09 --> Input Class Initialized
INFO - 2020-03-04 00:02:09 --> Language Class Initialized
INFO - 2020-03-04 00:02:09 --> Loader Class Initialized
INFO - 2020-03-04 00:02:09 --> Helper loaded: url_helper
INFO - 2020-03-04 00:02:09 --> Helper loaded: string_helper
INFO - 2020-03-04 00:02:09 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:02:09 --> Controller Class Initialized
INFO - 2020-03-04 00:02:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:02:09 --> Pagination Class Initialized
INFO - 2020-03-04 00:02:09 --> Model "M_show" initialized
INFO - 2020-03-04 00:02:09 --> Helper loaded: form_helper
INFO - 2020-03-04 00:02:09 --> Form Validation Class Initialized
INFO - 2020-03-04 00:02:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:02:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 00:02:09 --> Final output sent to browser
DEBUG - 2020-03-04 00:02:09 --> Total execution time: 0.0057
INFO - 2020-03-04 00:02:20 --> Config Class Initialized
INFO - 2020-03-04 00:02:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:02:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:02:20 --> Utf8 Class Initialized
INFO - 2020-03-04 00:02:20 --> URI Class Initialized
INFO - 2020-03-04 00:02:20 --> Router Class Initialized
INFO - 2020-03-04 00:02:20 --> Output Class Initialized
INFO - 2020-03-04 00:02:20 --> Security Class Initialized
DEBUG - 2020-03-04 00:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:02:20 --> Input Class Initialized
INFO - 2020-03-04 00:02:20 --> Language Class Initialized
INFO - 2020-03-04 00:02:20 --> Loader Class Initialized
INFO - 2020-03-04 00:02:20 --> Helper loaded: url_helper
INFO - 2020-03-04 00:02:20 --> Helper loaded: string_helper
INFO - 2020-03-04 00:02:20 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:02:20 --> Controller Class Initialized
INFO - 2020-03-04 00:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:02:20 --> Pagination Class Initialized
INFO - 2020-03-04 00:02:20 --> Model "M_show" initialized
INFO - 2020-03-04 00:02:20 --> Helper loaded: form_helper
INFO - 2020-03-04 00:02:20 --> Form Validation Class Initialized
INFO - 2020-03-04 00:02:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:02:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-04 00:02:20 --> Final output sent to browser
DEBUG - 2020-03-04 00:02:20 --> Total execution time: 0.0060
INFO - 2020-03-04 00:02:34 --> Config Class Initialized
INFO - 2020-03-04 00:02:34 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:02:34 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:02:34 --> Utf8 Class Initialized
INFO - 2020-03-04 00:02:34 --> URI Class Initialized
INFO - 2020-03-04 00:02:34 --> Router Class Initialized
INFO - 2020-03-04 00:02:34 --> Output Class Initialized
INFO - 2020-03-04 00:02:34 --> Security Class Initialized
DEBUG - 2020-03-04 00:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:02:34 --> Input Class Initialized
INFO - 2020-03-04 00:02:34 --> Language Class Initialized
INFO - 2020-03-04 00:02:34 --> Loader Class Initialized
INFO - 2020-03-04 00:02:34 --> Helper loaded: url_helper
INFO - 2020-03-04 00:02:34 --> Helper loaded: string_helper
INFO - 2020-03-04 00:02:34 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:02:34 --> Controller Class Initialized
INFO - 2020-03-04 00:02:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:02:34 --> Pagination Class Initialized
INFO - 2020-03-04 00:02:34 --> Model "M_show" initialized
INFO - 2020-03-04 00:02:34 --> Helper loaded: form_helper
INFO - 2020-03-04 00:02:34 --> Form Validation Class Initialized
INFO - 2020-03-04 00:02:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:02:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 00:02:34 --> Final output sent to browser
DEBUG - 2020-03-04 00:02:34 --> Total execution time: 0.0056
INFO - 2020-03-04 00:02:40 --> Config Class Initialized
INFO - 2020-03-04 00:02:40 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:02:40 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:02:40 --> Utf8 Class Initialized
INFO - 2020-03-04 00:02:40 --> URI Class Initialized
INFO - 2020-03-04 00:02:40 --> Router Class Initialized
INFO - 2020-03-04 00:02:40 --> Output Class Initialized
INFO - 2020-03-04 00:02:40 --> Security Class Initialized
DEBUG - 2020-03-04 00:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:02:40 --> Input Class Initialized
INFO - 2020-03-04 00:02:40 --> Language Class Initialized
INFO - 2020-03-04 00:02:40 --> Loader Class Initialized
INFO - 2020-03-04 00:02:40 --> Helper loaded: url_helper
INFO - 2020-03-04 00:02:40 --> Helper loaded: string_helper
INFO - 2020-03-04 00:02:40 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:02:40 --> Controller Class Initialized
INFO - 2020-03-04 00:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:02:40 --> Pagination Class Initialized
INFO - 2020-03-04 00:02:40 --> Model "M_show" initialized
INFO - 2020-03-04 00:02:40 --> Helper loaded: form_helper
INFO - 2020-03-04 00:02:40 --> Form Validation Class Initialized
INFO - 2020-03-04 00:02:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:02:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 00:02:40 --> Final output sent to browser
DEBUG - 2020-03-04 00:02:40 --> Total execution time: 0.0087
INFO - 2020-03-04 00:02:46 --> Config Class Initialized
INFO - 2020-03-04 00:02:46 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:02:46 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:02:46 --> Utf8 Class Initialized
INFO - 2020-03-04 00:02:46 --> URI Class Initialized
INFO - 2020-03-04 00:02:46 --> Router Class Initialized
INFO - 2020-03-04 00:02:46 --> Output Class Initialized
INFO - 2020-03-04 00:02:46 --> Security Class Initialized
DEBUG - 2020-03-04 00:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:02:46 --> Input Class Initialized
INFO - 2020-03-04 00:02:46 --> Language Class Initialized
INFO - 2020-03-04 00:02:46 --> Loader Class Initialized
INFO - 2020-03-04 00:02:46 --> Helper loaded: url_helper
INFO - 2020-03-04 00:02:46 --> Helper loaded: string_helper
INFO - 2020-03-04 00:02:46 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:02:46 --> Controller Class Initialized
INFO - 2020-03-04 00:02:46 --> Model "M_tiket" initialized
INFO - 2020-03-04 00:02:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 00:02:46 --> Model "M_pesan" initialized
INFO - 2020-03-04 00:02:46 --> Helper loaded: form_helper
INFO - 2020-03-04 00:02:46 --> Form Validation Class Initialized
INFO - 2020-03-04 00:02:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 00:02:46 --> Final output sent to browser
DEBUG - 2020-03-04 00:02:46 --> Total execution time: 0.0104
INFO - 2020-03-04 00:02:52 --> Config Class Initialized
INFO - 2020-03-04 00:02:52 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:02:52 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:02:52 --> Utf8 Class Initialized
INFO - 2020-03-04 00:02:52 --> URI Class Initialized
DEBUG - 2020-03-04 00:02:52 --> No URI present. Default controller set.
INFO - 2020-03-04 00:02:52 --> Router Class Initialized
INFO - 2020-03-04 00:02:52 --> Output Class Initialized
INFO - 2020-03-04 00:02:52 --> Security Class Initialized
DEBUG - 2020-03-04 00:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:02:52 --> Input Class Initialized
INFO - 2020-03-04 00:02:52 --> Language Class Initialized
INFO - 2020-03-04 00:02:52 --> Loader Class Initialized
INFO - 2020-03-04 00:02:52 --> Helper loaded: url_helper
INFO - 2020-03-04 00:02:52 --> Helper loaded: string_helper
INFO - 2020-03-04 00:02:52 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:02:52 --> Controller Class Initialized
INFO - 2020-03-04 00:02:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:02:52 --> Pagination Class Initialized
INFO - 2020-03-04 00:02:52 --> Model "M_show" initialized
INFO - 2020-03-04 00:02:52 --> Helper loaded: form_helper
INFO - 2020-03-04 00:02:52 --> Form Validation Class Initialized
INFO - 2020-03-04 00:02:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:02:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 00:02:52 --> Final output sent to browser
DEBUG - 2020-03-04 00:02:52 --> Total execution time: 0.0142
INFO - 2020-03-04 00:03:04 --> Config Class Initialized
INFO - 2020-03-04 00:03:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:03:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:03:04 --> Utf8 Class Initialized
INFO - 2020-03-04 00:03:04 --> URI Class Initialized
INFO - 2020-03-04 00:03:04 --> Router Class Initialized
INFO - 2020-03-04 00:03:04 --> Output Class Initialized
INFO - 2020-03-04 00:03:04 --> Security Class Initialized
DEBUG - 2020-03-04 00:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:03:04 --> Input Class Initialized
INFO - 2020-03-04 00:03:04 --> Language Class Initialized
INFO - 2020-03-04 00:03:04 --> Loader Class Initialized
INFO - 2020-03-04 00:03:04 --> Helper loaded: url_helper
INFO - 2020-03-04 00:03:04 --> Helper loaded: string_helper
INFO - 2020-03-04 00:03:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:03:04 --> Controller Class Initialized
INFO - 2020-03-04 00:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:03:04 --> Pagination Class Initialized
INFO - 2020-03-04 00:03:04 --> Model "M_show" initialized
INFO - 2020-03-04 00:03:04 --> Helper loaded: form_helper
INFO - 2020-03-04 00:03:04 --> Form Validation Class Initialized
INFO - 2020-03-04 00:03:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:03:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 00:03:04 --> Final output sent to browser
DEBUG - 2020-03-04 00:03:04 --> Total execution time: 0.0056
INFO - 2020-03-04 00:03:05 --> Config Class Initialized
INFO - 2020-03-04 00:03:05 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:03:05 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:03:05 --> Utf8 Class Initialized
INFO - 2020-03-04 00:03:05 --> URI Class Initialized
INFO - 2020-03-04 00:03:05 --> Router Class Initialized
INFO - 2020-03-04 00:03:05 --> Output Class Initialized
INFO - 2020-03-04 00:03:05 --> Security Class Initialized
DEBUG - 2020-03-04 00:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:03:05 --> Input Class Initialized
INFO - 2020-03-04 00:03:05 --> Language Class Initialized
ERROR - 2020-03-04 00:03:05 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 00:03:10 --> Config Class Initialized
INFO - 2020-03-04 00:03:10 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:03:10 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:03:10 --> Utf8 Class Initialized
INFO - 2020-03-04 00:03:10 --> URI Class Initialized
INFO - 2020-03-04 00:03:10 --> Router Class Initialized
INFO - 2020-03-04 00:03:10 --> Output Class Initialized
INFO - 2020-03-04 00:03:10 --> Security Class Initialized
DEBUG - 2020-03-04 00:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:03:10 --> Input Class Initialized
INFO - 2020-03-04 00:03:10 --> Language Class Initialized
INFO - 2020-03-04 00:03:10 --> Loader Class Initialized
INFO - 2020-03-04 00:03:10 --> Helper loaded: url_helper
INFO - 2020-03-04 00:03:10 --> Helper loaded: string_helper
INFO - 2020-03-04 00:03:10 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:03:10 --> Controller Class Initialized
INFO - 2020-03-04 00:03:10 --> Model "M_tiket" initialized
INFO - 2020-03-04 00:03:10 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 00:03:10 --> Model "M_pesan" initialized
INFO - 2020-03-04 00:03:10 --> Helper loaded: form_helper
INFO - 2020-03-04 00:03:10 --> Form Validation Class Initialized
INFO - 2020-03-04 00:03:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 00:03:10 --> Final output sent to browser
DEBUG - 2020-03-04 00:03:10 --> Total execution time: 0.0075
INFO - 2020-03-04 00:03:45 --> Config Class Initialized
INFO - 2020-03-04 00:03:45 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:03:45 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:03:45 --> Utf8 Class Initialized
INFO - 2020-03-04 00:03:45 --> URI Class Initialized
INFO - 2020-03-04 00:03:45 --> Router Class Initialized
INFO - 2020-03-04 00:03:45 --> Output Class Initialized
INFO - 2020-03-04 00:03:45 --> Security Class Initialized
DEBUG - 2020-03-04 00:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:03:45 --> Input Class Initialized
INFO - 2020-03-04 00:03:45 --> Language Class Initialized
INFO - 2020-03-04 00:03:45 --> Loader Class Initialized
INFO - 2020-03-04 00:03:45 --> Helper loaded: url_helper
INFO - 2020-03-04 00:03:45 --> Helper loaded: string_helper
INFO - 2020-03-04 00:03:45 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:03:45 --> Controller Class Initialized
INFO - 2020-03-04 00:03:45 --> Model "M_tiket" initialized
INFO - 2020-03-04 00:03:45 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 00:03:45 --> Model "M_pesan" initialized
INFO - 2020-03-04 00:03:45 --> Helper loaded: form_helper
INFO - 2020-03-04 00:03:45 --> Form Validation Class Initialized
INFO - 2020-03-04 00:03:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 00:03:45 --> Final output sent to browser
DEBUG - 2020-03-04 00:03:45 --> Total execution time: 0.0076
INFO - 2020-03-04 00:04:20 --> Config Class Initialized
INFO - 2020-03-04 00:04:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:04:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:04:20 --> Utf8 Class Initialized
INFO - 2020-03-04 00:04:20 --> URI Class Initialized
INFO - 2020-03-04 00:04:20 --> Router Class Initialized
INFO - 2020-03-04 00:04:20 --> Output Class Initialized
INFO - 2020-03-04 00:04:20 --> Security Class Initialized
DEBUG - 2020-03-04 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:04:20 --> Input Class Initialized
INFO - 2020-03-04 00:04:20 --> Language Class Initialized
INFO - 2020-03-04 00:04:20 --> Loader Class Initialized
INFO - 2020-03-04 00:04:20 --> Helper loaded: url_helper
INFO - 2020-03-04 00:04:20 --> Helper loaded: string_helper
INFO - 2020-03-04 00:04:20 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:04:20 --> Controller Class Initialized
INFO - 2020-03-04 00:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:04:20 --> Pagination Class Initialized
INFO - 2020-03-04 00:04:20 --> Model "M_show" initialized
INFO - 2020-03-04 00:04:20 --> Helper loaded: form_helper
INFO - 2020-03-04 00:04:20 --> Form Validation Class Initialized
INFO - 2020-03-04 00:04:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:04:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 00:04:20 --> Final output sent to browser
DEBUG - 2020-03-04 00:04:20 --> Total execution time: 0.0067
INFO - 2020-03-04 00:04:23 --> Config Class Initialized
INFO - 2020-03-04 00:04:23 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:04:23 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:04:23 --> Utf8 Class Initialized
INFO - 2020-03-04 00:04:23 --> URI Class Initialized
INFO - 2020-03-04 00:04:23 --> Router Class Initialized
INFO - 2020-03-04 00:04:23 --> Output Class Initialized
INFO - 2020-03-04 00:04:23 --> Security Class Initialized
DEBUG - 2020-03-04 00:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:04:23 --> Input Class Initialized
INFO - 2020-03-04 00:04:23 --> Language Class Initialized
INFO - 2020-03-04 00:04:23 --> Loader Class Initialized
INFO - 2020-03-04 00:04:23 --> Helper loaded: url_helper
INFO - 2020-03-04 00:04:23 --> Helper loaded: string_helper
INFO - 2020-03-04 00:04:23 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:04:23 --> Controller Class Initialized
INFO - 2020-03-04 00:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:04:23 --> Pagination Class Initialized
INFO - 2020-03-04 00:04:23 --> Model "M_show" initialized
INFO - 2020-03-04 00:04:23 --> Helper loaded: form_helper
INFO - 2020-03-04 00:04:23 --> Form Validation Class Initialized
INFO - 2020-03-04 00:04:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:04:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 00:04:23 --> Final output sent to browser
DEBUG - 2020-03-04 00:04:23 --> Total execution time: 0.0060
INFO - 2020-03-04 00:04:26 --> Config Class Initialized
INFO - 2020-03-04 00:04:26 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:04:26 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:04:26 --> Utf8 Class Initialized
INFO - 2020-03-04 00:04:26 --> URI Class Initialized
INFO - 2020-03-04 00:04:26 --> Router Class Initialized
INFO - 2020-03-04 00:04:26 --> Output Class Initialized
INFO - 2020-03-04 00:04:26 --> Security Class Initialized
DEBUG - 2020-03-04 00:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:04:26 --> Input Class Initialized
INFO - 2020-03-04 00:04:26 --> Language Class Initialized
INFO - 2020-03-04 00:04:26 --> Loader Class Initialized
INFO - 2020-03-04 00:04:26 --> Helper loaded: url_helper
INFO - 2020-03-04 00:04:26 --> Helper loaded: string_helper
INFO - 2020-03-04 00:04:26 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:04:26 --> Controller Class Initialized
INFO - 2020-03-04 00:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:04:26 --> Pagination Class Initialized
INFO - 2020-03-04 00:04:26 --> Model "M_show" initialized
INFO - 2020-03-04 00:04:26 --> Helper loaded: form_helper
INFO - 2020-03-04 00:04:26 --> Form Validation Class Initialized
INFO - 2020-03-04 00:04:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:04:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-04 00:04:26 --> Final output sent to browser
DEBUG - 2020-03-04 00:04:26 --> Total execution time: 0.0053
INFO - 2020-03-04 00:04:31 --> Config Class Initialized
INFO - 2020-03-04 00:04:31 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:04:31 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:04:31 --> Utf8 Class Initialized
INFO - 2020-03-04 00:04:31 --> URI Class Initialized
DEBUG - 2020-03-04 00:04:31 --> No URI present. Default controller set.
INFO - 2020-03-04 00:04:31 --> Router Class Initialized
INFO - 2020-03-04 00:04:31 --> Output Class Initialized
INFO - 2020-03-04 00:04:31 --> Security Class Initialized
DEBUG - 2020-03-04 00:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:04:31 --> Input Class Initialized
INFO - 2020-03-04 00:04:31 --> Language Class Initialized
INFO - 2020-03-04 00:04:31 --> Loader Class Initialized
INFO - 2020-03-04 00:04:31 --> Helper loaded: url_helper
INFO - 2020-03-04 00:04:31 --> Helper loaded: string_helper
INFO - 2020-03-04 00:04:31 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:04:31 --> Controller Class Initialized
INFO - 2020-03-04 00:04:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:04:31 --> Pagination Class Initialized
INFO - 2020-03-04 00:04:31 --> Model "M_show" initialized
INFO - 2020-03-04 00:04:31 --> Helper loaded: form_helper
INFO - 2020-03-04 00:04:31 --> Form Validation Class Initialized
INFO - 2020-03-04 00:04:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:04:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 00:04:31 --> Final output sent to browser
DEBUG - 2020-03-04 00:04:31 --> Total execution time: 0.0052
INFO - 2020-03-04 00:04:36 --> Config Class Initialized
INFO - 2020-03-04 00:04:36 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:04:36 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:04:36 --> Utf8 Class Initialized
INFO - 2020-03-04 00:04:36 --> URI Class Initialized
DEBUG - 2020-03-04 00:04:36 --> No URI present. Default controller set.
INFO - 2020-03-04 00:04:36 --> Router Class Initialized
INFO - 2020-03-04 00:04:36 --> Output Class Initialized
INFO - 2020-03-04 00:04:36 --> Security Class Initialized
DEBUG - 2020-03-04 00:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:04:36 --> Input Class Initialized
INFO - 2020-03-04 00:04:36 --> Language Class Initialized
INFO - 2020-03-04 00:04:36 --> Loader Class Initialized
INFO - 2020-03-04 00:04:36 --> Helper loaded: url_helper
INFO - 2020-03-04 00:04:36 --> Helper loaded: string_helper
INFO - 2020-03-04 00:04:36 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:04:36 --> Controller Class Initialized
INFO - 2020-03-04 00:04:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:04:36 --> Pagination Class Initialized
INFO - 2020-03-04 00:04:36 --> Model "M_show" initialized
INFO - 2020-03-04 00:04:36 --> Helper loaded: form_helper
INFO - 2020-03-04 00:04:36 --> Form Validation Class Initialized
INFO - 2020-03-04 00:04:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:04:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 00:04:36 --> Final output sent to browser
DEBUG - 2020-03-04 00:04:36 --> Total execution time: 0.0054
INFO - 2020-03-04 00:05:07 --> Config Class Initialized
INFO - 2020-03-04 00:05:07 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:05:07 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:05:07 --> Utf8 Class Initialized
INFO - 2020-03-04 00:05:07 --> URI Class Initialized
INFO - 2020-03-04 00:05:07 --> Router Class Initialized
INFO - 2020-03-04 00:05:07 --> Output Class Initialized
INFO - 2020-03-04 00:05:07 --> Security Class Initialized
DEBUG - 2020-03-04 00:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:05:07 --> Input Class Initialized
INFO - 2020-03-04 00:05:07 --> Language Class Initialized
INFO - 2020-03-04 00:05:07 --> Loader Class Initialized
INFO - 2020-03-04 00:05:07 --> Helper loaded: url_helper
INFO - 2020-03-04 00:05:07 --> Helper loaded: string_helper
INFO - 2020-03-04 00:05:07 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:05:07 --> Controller Class Initialized
INFO - 2020-03-04 00:05:07 --> Model "M_tiket" initialized
INFO - 2020-03-04 00:05:07 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 00:05:07 --> Model "M_pesan" initialized
INFO - 2020-03-04 00:05:07 --> Helper loaded: form_helper
INFO - 2020-03-04 00:05:07 --> Form Validation Class Initialized
INFO - 2020-03-04 00:05:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 00:05:07 --> Final output sent to browser
DEBUG - 2020-03-04 00:05:07 --> Total execution time: 0.0068
INFO - 2020-03-04 00:30:56 --> Config Class Initialized
INFO - 2020-03-04 00:30:56 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:30:56 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:30:56 --> Utf8 Class Initialized
INFO - 2020-03-04 00:30:56 --> URI Class Initialized
DEBUG - 2020-03-04 00:30:56 --> No URI present. Default controller set.
INFO - 2020-03-04 00:30:56 --> Router Class Initialized
INFO - 2020-03-04 00:30:56 --> Output Class Initialized
INFO - 2020-03-04 00:30:56 --> Security Class Initialized
DEBUG - 2020-03-04 00:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:30:56 --> Input Class Initialized
INFO - 2020-03-04 00:30:56 --> Language Class Initialized
INFO - 2020-03-04 00:30:56 --> Loader Class Initialized
INFO - 2020-03-04 00:30:56 --> Helper loaded: url_helper
INFO - 2020-03-04 00:30:56 --> Helper loaded: string_helper
INFO - 2020-03-04 00:30:56 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:30:56 --> Controller Class Initialized
INFO - 2020-03-04 00:30:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:30:56 --> Pagination Class Initialized
INFO - 2020-03-04 00:30:56 --> Model "M_show" initialized
INFO - 2020-03-04 00:30:56 --> Helper loaded: form_helper
INFO - 2020-03-04 00:30:56 --> Form Validation Class Initialized
INFO - 2020-03-04 00:30:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:30:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 00:30:56 --> Final output sent to browser
DEBUG - 2020-03-04 00:30:56 --> Total execution time: 0.0393
INFO - 2020-03-04 00:31:11 --> Config Class Initialized
INFO - 2020-03-04 00:31:11 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:31:11 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:31:11 --> Utf8 Class Initialized
INFO - 2020-03-04 00:31:11 --> URI Class Initialized
INFO - 2020-03-04 00:31:11 --> Router Class Initialized
INFO - 2020-03-04 00:31:11 --> Output Class Initialized
INFO - 2020-03-04 00:31:11 --> Security Class Initialized
DEBUG - 2020-03-04 00:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:31:11 --> Input Class Initialized
INFO - 2020-03-04 00:31:11 --> Language Class Initialized
INFO - 2020-03-04 00:31:11 --> Loader Class Initialized
INFO - 2020-03-04 00:31:11 --> Helper loaded: url_helper
INFO - 2020-03-04 00:31:11 --> Helper loaded: string_helper
INFO - 2020-03-04 00:31:11 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:31:11 --> Controller Class Initialized
INFO - 2020-03-04 00:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:31:11 --> Pagination Class Initialized
INFO - 2020-03-04 00:31:11 --> Model "M_show" initialized
INFO - 2020-03-04 00:31:11 --> Helper loaded: form_helper
INFO - 2020-03-04 00:31:11 --> Form Validation Class Initialized
INFO - 2020-03-04 00:31:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:31:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 00:31:11 --> Final output sent to browser
DEBUG - 2020-03-04 00:31:11 --> Total execution time: 0.0095
INFO - 2020-03-04 00:33:08 --> Config Class Initialized
INFO - 2020-03-04 00:33:08 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:33:08 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:33:08 --> Utf8 Class Initialized
INFO - 2020-03-04 00:33:08 --> URI Class Initialized
INFO - 2020-03-04 00:33:08 --> Router Class Initialized
INFO - 2020-03-04 00:33:08 --> Output Class Initialized
INFO - 2020-03-04 00:33:08 --> Security Class Initialized
DEBUG - 2020-03-04 00:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:33:08 --> Input Class Initialized
INFO - 2020-03-04 00:33:08 --> Language Class Initialized
INFO - 2020-03-04 00:33:08 --> Loader Class Initialized
INFO - 2020-03-04 00:33:08 --> Helper loaded: url_helper
INFO - 2020-03-04 00:33:08 --> Helper loaded: string_helper
INFO - 2020-03-04 00:33:08 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:33:08 --> Controller Class Initialized
INFO - 2020-03-04 00:33:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:33:08 --> Pagination Class Initialized
INFO - 2020-03-04 00:33:08 --> Model "M_show" initialized
INFO - 2020-03-04 00:33:08 --> Helper loaded: form_helper
INFO - 2020-03-04 00:33:08 --> Form Validation Class Initialized
INFO - 2020-03-04 00:33:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:33:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-04 00:33:08 --> Final output sent to browser
DEBUG - 2020-03-04 00:33:08 --> Total execution time: 0.0295
INFO - 2020-03-04 00:34:33 --> Config Class Initialized
INFO - 2020-03-04 00:34:33 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:34:33 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:34:33 --> Utf8 Class Initialized
INFO - 2020-03-04 00:34:33 --> URI Class Initialized
INFO - 2020-03-04 00:34:33 --> Router Class Initialized
INFO - 2020-03-04 00:34:33 --> Output Class Initialized
INFO - 2020-03-04 00:34:33 --> Security Class Initialized
DEBUG - 2020-03-04 00:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:34:33 --> Input Class Initialized
INFO - 2020-03-04 00:34:33 --> Language Class Initialized
INFO - 2020-03-04 00:34:33 --> Loader Class Initialized
INFO - 2020-03-04 00:34:33 --> Helper loaded: url_helper
INFO - 2020-03-04 00:34:33 --> Helper loaded: string_helper
INFO - 2020-03-04 00:34:33 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:34:33 --> Controller Class Initialized
INFO - 2020-03-04 00:34:33 --> Model "M_tiket" initialized
INFO - 2020-03-04 00:34:33 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 00:34:33 --> Model "M_pesan" initialized
INFO - 2020-03-04 00:34:33 --> Helper loaded: form_helper
INFO - 2020-03-04 00:34:33 --> Form Validation Class Initialized
INFO - 2020-03-04 00:34:33 --> Config Class Initialized
INFO - 2020-03-04 00:34:33 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:34:33 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:34:33 --> Utf8 Class Initialized
INFO - 2020-03-04 00:34:33 --> URI Class Initialized
INFO - 2020-03-04 00:34:33 --> Router Class Initialized
INFO - 2020-03-04 00:34:33 --> Output Class Initialized
INFO - 2020-03-04 00:34:33 --> Security Class Initialized
DEBUG - 2020-03-04 00:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:34:33 --> Input Class Initialized
INFO - 2020-03-04 00:34:33 --> Language Class Initialized
INFO - 2020-03-04 00:34:33 --> Loader Class Initialized
INFO - 2020-03-04 00:34:33 --> Helper loaded: url_helper
INFO - 2020-03-04 00:34:33 --> Helper loaded: string_helper
INFO - 2020-03-04 00:34:33 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:34:33 --> Controller Class Initialized
INFO - 2020-03-04 00:34:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:34:33 --> Pagination Class Initialized
INFO - 2020-03-04 00:34:33 --> Model "M_show" initialized
INFO - 2020-03-04 00:34:33 --> Helper loaded: form_helper
INFO - 2020-03-04 00:34:33 --> Form Validation Class Initialized
INFO - 2020-03-04 00:34:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:34:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 00:34:33 --> Final output sent to browser
DEBUG - 2020-03-04 00:34:33 --> Total execution time: 0.0059
INFO - 2020-03-04 00:34:35 --> Config Class Initialized
INFO - 2020-03-04 00:34:35 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:34:35 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:34:35 --> Utf8 Class Initialized
INFO - 2020-03-04 00:34:35 --> URI Class Initialized
INFO - 2020-03-04 00:34:35 --> Router Class Initialized
INFO - 2020-03-04 00:34:35 --> Output Class Initialized
INFO - 2020-03-04 00:34:35 --> Security Class Initialized
DEBUG - 2020-03-04 00:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:34:35 --> Input Class Initialized
INFO - 2020-03-04 00:34:35 --> Language Class Initialized
ERROR - 2020-03-04 00:34:35 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 00:34:54 --> Config Class Initialized
INFO - 2020-03-04 00:34:54 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:34:54 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:34:54 --> Utf8 Class Initialized
INFO - 2020-03-04 00:34:54 --> URI Class Initialized
INFO - 2020-03-04 00:34:54 --> Router Class Initialized
INFO - 2020-03-04 00:34:54 --> Output Class Initialized
INFO - 2020-03-04 00:34:54 --> Security Class Initialized
DEBUG - 2020-03-04 00:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:34:54 --> Input Class Initialized
INFO - 2020-03-04 00:34:54 --> Language Class Initialized
INFO - 2020-03-04 00:34:54 --> Loader Class Initialized
INFO - 2020-03-04 00:34:54 --> Helper loaded: url_helper
INFO - 2020-03-04 00:34:54 --> Helper loaded: string_helper
INFO - 2020-03-04 00:34:54 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:34:54 --> Controller Class Initialized
INFO - 2020-03-04 00:34:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:34:54 --> Pagination Class Initialized
INFO - 2020-03-04 00:34:54 --> Model "M_show" initialized
INFO - 2020-03-04 00:34:54 --> Helper loaded: form_helper
INFO - 2020-03-04 00:34:54 --> Form Validation Class Initialized
INFO - 2020-03-04 00:34:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:34:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-04 00:34:54 --> Final output sent to browser
DEBUG - 2020-03-04 00:34:54 --> Total execution time: 0.0074
INFO - 2020-03-04 00:35:04 --> Config Class Initialized
INFO - 2020-03-04 00:35:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:35:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:35:04 --> Utf8 Class Initialized
INFO - 2020-03-04 00:35:04 --> URI Class Initialized
INFO - 2020-03-04 00:35:04 --> Router Class Initialized
INFO - 2020-03-04 00:35:04 --> Output Class Initialized
INFO - 2020-03-04 00:35:04 --> Security Class Initialized
DEBUG - 2020-03-04 00:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:35:04 --> Input Class Initialized
INFO - 2020-03-04 00:35:04 --> Language Class Initialized
INFO - 2020-03-04 00:35:04 --> Loader Class Initialized
INFO - 2020-03-04 00:35:04 --> Helper loaded: url_helper
INFO - 2020-03-04 00:35:04 --> Helper loaded: string_helper
INFO - 2020-03-04 00:35:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:35:04 --> Controller Class Initialized
INFO - 2020-03-04 00:35:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:35:04 --> Pagination Class Initialized
INFO - 2020-03-04 00:35:04 --> Model "M_show" initialized
INFO - 2020-03-04 00:35:04 --> Helper loaded: form_helper
INFO - 2020-03-04 00:35:04 --> Form Validation Class Initialized
INFO - 2020-03-04 00:35:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:35:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-04 00:35:04 --> Final output sent to browser
DEBUG - 2020-03-04 00:35:04 --> Total execution time: 0.0085
INFO - 2020-03-04 00:35:11 --> Config Class Initialized
INFO - 2020-03-04 00:35:11 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:35:11 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:35:11 --> Utf8 Class Initialized
INFO - 2020-03-04 00:35:11 --> URI Class Initialized
INFO - 2020-03-04 00:35:11 --> Router Class Initialized
INFO - 2020-03-04 00:35:11 --> Output Class Initialized
INFO - 2020-03-04 00:35:11 --> Security Class Initialized
DEBUG - 2020-03-04 00:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:35:11 --> Input Class Initialized
INFO - 2020-03-04 00:35:11 --> Language Class Initialized
INFO - 2020-03-04 00:35:11 --> Loader Class Initialized
INFO - 2020-03-04 00:35:11 --> Helper loaded: url_helper
INFO - 2020-03-04 00:35:11 --> Helper loaded: string_helper
INFO - 2020-03-04 00:35:11 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:35:11 --> Controller Class Initialized
INFO - 2020-03-04 00:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:35:11 --> Pagination Class Initialized
INFO - 2020-03-04 00:35:11 --> Model "M_show" initialized
INFO - 2020-03-04 00:35:11 --> Helper loaded: form_helper
INFO - 2020-03-04 00:35:11 --> Form Validation Class Initialized
INFO - 2020-03-04 00:35:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:35:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-04 00:35:11 --> Final output sent to browser
DEBUG - 2020-03-04 00:35:11 --> Total execution time: 0.0051
INFO - 2020-03-04 00:35:20 --> Config Class Initialized
INFO - 2020-03-04 00:35:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:35:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:35:20 --> Utf8 Class Initialized
INFO - 2020-03-04 00:35:20 --> URI Class Initialized
INFO - 2020-03-04 00:35:20 --> Router Class Initialized
INFO - 2020-03-04 00:35:20 --> Output Class Initialized
INFO - 2020-03-04 00:35:20 --> Security Class Initialized
DEBUG - 2020-03-04 00:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:35:20 --> Input Class Initialized
INFO - 2020-03-04 00:35:20 --> Language Class Initialized
INFO - 2020-03-04 00:35:20 --> Loader Class Initialized
INFO - 2020-03-04 00:35:20 --> Helper loaded: url_helper
INFO - 2020-03-04 00:35:20 --> Helper loaded: string_helper
INFO - 2020-03-04 00:35:20 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:35:20 --> Controller Class Initialized
INFO - 2020-03-04 00:35:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:35:20 --> Pagination Class Initialized
INFO - 2020-03-04 00:35:20 --> Model "M_show" initialized
INFO - 2020-03-04 00:35:20 --> Helper loaded: form_helper
INFO - 2020-03-04 00:35:20 --> Form Validation Class Initialized
INFO - 2020-03-04 00:35:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:35:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-04 00:35:20 --> Final output sent to browser
DEBUG - 2020-03-04 00:35:20 --> Total execution time: 0.0061
INFO - 2020-03-04 00:35:35 --> Config Class Initialized
INFO - 2020-03-04 00:35:35 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:35:35 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:35:35 --> Utf8 Class Initialized
INFO - 2020-03-04 00:35:35 --> URI Class Initialized
INFO - 2020-03-04 00:35:35 --> Router Class Initialized
INFO - 2020-03-04 00:35:35 --> Output Class Initialized
INFO - 2020-03-04 00:35:35 --> Security Class Initialized
DEBUG - 2020-03-04 00:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:35:35 --> Input Class Initialized
INFO - 2020-03-04 00:35:35 --> Language Class Initialized
INFO - 2020-03-04 00:35:35 --> Loader Class Initialized
INFO - 2020-03-04 00:35:35 --> Helper loaded: url_helper
INFO - 2020-03-04 00:35:35 --> Helper loaded: string_helper
INFO - 2020-03-04 00:35:35 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:35:35 --> Controller Class Initialized
INFO - 2020-03-04 00:35:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:35:35 --> Pagination Class Initialized
INFO - 2020-03-04 00:35:35 --> Model "M_show" initialized
INFO - 2020-03-04 00:35:35 --> Helper loaded: form_helper
INFO - 2020-03-04 00:35:35 --> Form Validation Class Initialized
INFO - 2020-03-04 00:35:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:35:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 00:35:35 --> Final output sent to browser
DEBUG - 2020-03-04 00:35:35 --> Total execution time: 0.0067
INFO - 2020-03-04 00:35:38 --> Config Class Initialized
INFO - 2020-03-04 00:35:38 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:35:38 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:35:38 --> Utf8 Class Initialized
INFO - 2020-03-04 00:35:38 --> URI Class Initialized
INFO - 2020-03-04 00:35:38 --> Router Class Initialized
INFO - 2020-03-04 00:35:38 --> Output Class Initialized
INFO - 2020-03-04 00:35:38 --> Security Class Initialized
DEBUG - 2020-03-04 00:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:35:38 --> Input Class Initialized
INFO - 2020-03-04 00:35:38 --> Language Class Initialized
INFO - 2020-03-04 00:35:38 --> Loader Class Initialized
INFO - 2020-03-04 00:35:38 --> Helper loaded: url_helper
INFO - 2020-03-04 00:35:38 --> Helper loaded: string_helper
INFO - 2020-03-04 00:35:38 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:35:38 --> Controller Class Initialized
INFO - 2020-03-04 00:35:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:35:38 --> Pagination Class Initialized
INFO - 2020-03-04 00:35:38 --> Model "M_show" initialized
INFO - 2020-03-04 00:35:38 --> Helper loaded: form_helper
INFO - 2020-03-04 00:35:38 --> Form Validation Class Initialized
INFO - 2020-03-04 00:35:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:35:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 00:35:38 --> Final output sent to browser
DEBUG - 2020-03-04 00:35:38 --> Total execution time: 0.0064
INFO - 2020-03-04 00:35:40 --> Config Class Initialized
INFO - 2020-03-04 00:35:40 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:35:40 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:35:40 --> Utf8 Class Initialized
INFO - 2020-03-04 00:35:40 --> URI Class Initialized
INFO - 2020-03-04 00:35:40 --> Router Class Initialized
INFO - 2020-03-04 00:35:40 --> Output Class Initialized
INFO - 2020-03-04 00:35:40 --> Security Class Initialized
DEBUG - 2020-03-04 00:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:35:40 --> Input Class Initialized
INFO - 2020-03-04 00:35:40 --> Language Class Initialized
INFO - 2020-03-04 00:35:40 --> Loader Class Initialized
INFO - 2020-03-04 00:35:40 --> Helper loaded: url_helper
INFO - 2020-03-04 00:35:40 --> Helper loaded: string_helper
INFO - 2020-03-04 00:35:40 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:35:40 --> Controller Class Initialized
INFO - 2020-03-04 00:35:40 --> Model "M_tiket" initialized
INFO - 2020-03-04 00:35:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 00:35:40 --> Model "M_pesan" initialized
INFO - 2020-03-04 00:35:40 --> Helper loaded: form_helper
INFO - 2020-03-04 00:35:40 --> Form Validation Class Initialized
INFO - 2020-03-04 00:35:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 00:35:40 --> Final output sent to browser
DEBUG - 2020-03-04 00:35:40 --> Total execution time: 0.0083
INFO - 2020-03-04 00:51:03 --> Config Class Initialized
INFO - 2020-03-04 00:51:03 --> Hooks Class Initialized
DEBUG - 2020-03-04 00:51:03 --> UTF-8 Support Enabled
INFO - 2020-03-04 00:51:03 --> Utf8 Class Initialized
INFO - 2020-03-04 00:51:03 --> URI Class Initialized
DEBUG - 2020-03-04 00:51:03 --> No URI present. Default controller set.
INFO - 2020-03-04 00:51:03 --> Router Class Initialized
INFO - 2020-03-04 00:51:03 --> Output Class Initialized
INFO - 2020-03-04 00:51:03 --> Security Class Initialized
DEBUG - 2020-03-04 00:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 00:51:03 --> Input Class Initialized
INFO - 2020-03-04 00:51:03 --> Language Class Initialized
INFO - 2020-03-04 00:51:03 --> Loader Class Initialized
INFO - 2020-03-04 00:51:03 --> Helper loaded: url_helper
INFO - 2020-03-04 00:51:03 --> Helper loaded: string_helper
INFO - 2020-03-04 00:51:03 --> Database Driver Class Initialized
DEBUG - 2020-03-04 00:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 00:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 00:51:03 --> Controller Class Initialized
INFO - 2020-03-04 00:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 00:51:03 --> Pagination Class Initialized
INFO - 2020-03-04 00:51:03 --> Model "M_show" initialized
INFO - 2020-03-04 00:51:03 --> Helper loaded: form_helper
INFO - 2020-03-04 00:51:03 --> Form Validation Class Initialized
INFO - 2020-03-04 00:51:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 00:51:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 00:51:03 --> Final output sent to browser
DEBUG - 2020-03-04 00:51:03 --> Total execution time: 0.0294
INFO - 2020-03-04 01:01:05 --> Config Class Initialized
INFO - 2020-03-04 01:01:05 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:01:05 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:01:05 --> Utf8 Class Initialized
INFO - 2020-03-04 01:01:05 --> URI Class Initialized
DEBUG - 2020-03-04 01:01:05 --> No URI present. Default controller set.
INFO - 2020-03-04 01:01:05 --> Router Class Initialized
INFO - 2020-03-04 01:01:05 --> Output Class Initialized
INFO - 2020-03-04 01:01:05 --> Security Class Initialized
DEBUG - 2020-03-04 01:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:01:05 --> Input Class Initialized
INFO - 2020-03-04 01:01:05 --> Language Class Initialized
INFO - 2020-03-04 01:01:05 --> Loader Class Initialized
INFO - 2020-03-04 01:01:05 --> Helper loaded: url_helper
INFO - 2020-03-04 01:01:05 --> Helper loaded: string_helper
INFO - 2020-03-04 01:01:05 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:01:05 --> Controller Class Initialized
INFO - 2020-03-04 01:01:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:01:05 --> Pagination Class Initialized
INFO - 2020-03-04 01:01:05 --> Model "M_show" initialized
INFO - 2020-03-04 01:01:05 --> Helper loaded: form_helper
INFO - 2020-03-04 01:01:05 --> Form Validation Class Initialized
INFO - 2020-03-04 01:01:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:01:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 01:01:05 --> Final output sent to browser
DEBUG - 2020-03-04 01:01:05 --> Total execution time: 0.0299
INFO - 2020-03-04 01:01:15 --> Config Class Initialized
INFO - 2020-03-04 01:01:15 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:01:15 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:01:15 --> Utf8 Class Initialized
INFO - 2020-03-04 01:01:15 --> URI Class Initialized
INFO - 2020-03-04 01:01:15 --> Router Class Initialized
INFO - 2020-03-04 01:01:15 --> Output Class Initialized
INFO - 2020-03-04 01:01:15 --> Security Class Initialized
DEBUG - 2020-03-04 01:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:01:15 --> Input Class Initialized
INFO - 2020-03-04 01:01:15 --> Language Class Initialized
INFO - 2020-03-04 01:01:15 --> Loader Class Initialized
INFO - 2020-03-04 01:01:15 --> Helper loaded: url_helper
INFO - 2020-03-04 01:01:15 --> Helper loaded: string_helper
INFO - 2020-03-04 01:01:15 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:01:15 --> Controller Class Initialized
INFO - 2020-03-04 01:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:01:15 --> Pagination Class Initialized
INFO - 2020-03-04 01:01:15 --> Model "M_show" initialized
INFO - 2020-03-04 01:01:15 --> Helper loaded: form_helper
INFO - 2020-03-04 01:01:15 --> Form Validation Class Initialized
INFO - 2020-03-04 01:01:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:01:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 01:01:15 --> Final output sent to browser
DEBUG - 2020-03-04 01:01:15 --> Total execution time: 0.0090
INFO - 2020-03-04 01:01:21 --> Config Class Initialized
INFO - 2020-03-04 01:01:21 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:01:21 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:01:21 --> Utf8 Class Initialized
INFO - 2020-03-04 01:01:21 --> URI Class Initialized
INFO - 2020-03-04 01:01:21 --> Router Class Initialized
INFO - 2020-03-04 01:01:21 --> Output Class Initialized
INFO - 2020-03-04 01:01:21 --> Security Class Initialized
DEBUG - 2020-03-04 01:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:01:21 --> Input Class Initialized
INFO - 2020-03-04 01:01:21 --> Language Class Initialized
INFO - 2020-03-04 01:01:21 --> Loader Class Initialized
INFO - 2020-03-04 01:01:21 --> Helper loaded: url_helper
INFO - 2020-03-04 01:01:21 --> Helper loaded: string_helper
INFO - 2020-03-04 01:01:21 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:01:21 --> Controller Class Initialized
INFO - 2020-03-04 01:01:21 --> Model "M_tiket" initialized
INFO - 2020-03-04 01:01:21 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 01:01:21 --> Model "M_pesan" initialized
INFO - 2020-03-04 01:01:21 --> Helper loaded: form_helper
INFO - 2020-03-04 01:01:21 --> Form Validation Class Initialized
INFO - 2020-03-04 01:01:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 01:01:21 --> Final output sent to browser
DEBUG - 2020-03-04 01:01:21 --> Total execution time: 0.0095
INFO - 2020-03-04 01:01:56 --> Config Class Initialized
INFO - 2020-03-04 01:01:56 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:01:56 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:01:56 --> Utf8 Class Initialized
INFO - 2020-03-04 01:01:56 --> URI Class Initialized
INFO - 2020-03-04 01:01:56 --> Router Class Initialized
INFO - 2020-03-04 01:01:56 --> Output Class Initialized
INFO - 2020-03-04 01:01:56 --> Security Class Initialized
DEBUG - 2020-03-04 01:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:01:56 --> Input Class Initialized
INFO - 2020-03-04 01:01:56 --> Language Class Initialized
INFO - 2020-03-04 01:01:56 --> Loader Class Initialized
INFO - 2020-03-04 01:01:56 --> Helper loaded: url_helper
INFO - 2020-03-04 01:01:56 --> Helper loaded: string_helper
INFO - 2020-03-04 01:01:56 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:01:56 --> Controller Class Initialized
INFO - 2020-03-04 01:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:01:56 --> Pagination Class Initialized
INFO - 2020-03-04 01:01:56 --> Model "M_show" initialized
INFO - 2020-03-04 01:01:56 --> Helper loaded: form_helper
INFO - 2020-03-04 01:01:56 --> Form Validation Class Initialized
INFO - 2020-03-04 01:01:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:01:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 01:01:56 --> Final output sent to browser
DEBUG - 2020-03-04 01:01:56 --> Total execution time: 0.0059
INFO - 2020-03-04 01:01:58 --> Config Class Initialized
INFO - 2020-03-04 01:01:58 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:01:58 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:01:58 --> Utf8 Class Initialized
INFO - 2020-03-04 01:01:58 --> URI Class Initialized
DEBUG - 2020-03-04 01:01:58 --> No URI present. Default controller set.
INFO - 2020-03-04 01:01:58 --> Router Class Initialized
INFO - 2020-03-04 01:01:58 --> Output Class Initialized
INFO - 2020-03-04 01:01:58 --> Security Class Initialized
DEBUG - 2020-03-04 01:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:01:58 --> Input Class Initialized
INFO - 2020-03-04 01:01:58 --> Language Class Initialized
INFO - 2020-03-04 01:01:58 --> Loader Class Initialized
INFO - 2020-03-04 01:01:58 --> Helper loaded: url_helper
INFO - 2020-03-04 01:01:58 --> Helper loaded: string_helper
INFO - 2020-03-04 01:01:58 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:01:58 --> Controller Class Initialized
INFO - 2020-03-04 01:01:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:01:58 --> Pagination Class Initialized
INFO - 2020-03-04 01:01:58 --> Model "M_show" initialized
INFO - 2020-03-04 01:01:58 --> Helper loaded: form_helper
INFO - 2020-03-04 01:01:58 --> Form Validation Class Initialized
INFO - 2020-03-04 01:01:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:01:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 01:01:58 --> Final output sent to browser
DEBUG - 2020-03-04 01:01:58 --> Total execution time: 0.0052
INFO - 2020-03-04 01:12:09 --> Config Class Initialized
INFO - 2020-03-04 01:12:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:12:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:12:09 --> Utf8 Class Initialized
INFO - 2020-03-04 01:12:09 --> URI Class Initialized
DEBUG - 2020-03-04 01:12:09 --> No URI present. Default controller set.
INFO - 2020-03-04 01:12:09 --> Router Class Initialized
INFO - 2020-03-04 01:12:09 --> Output Class Initialized
INFO - 2020-03-04 01:12:09 --> Security Class Initialized
DEBUG - 2020-03-04 01:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:12:09 --> Input Class Initialized
INFO - 2020-03-04 01:12:09 --> Language Class Initialized
INFO - 2020-03-04 01:12:09 --> Loader Class Initialized
INFO - 2020-03-04 01:12:09 --> Helper loaded: url_helper
INFO - 2020-03-04 01:12:09 --> Helper loaded: string_helper
INFO - 2020-03-04 01:12:09 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:12:09 --> Controller Class Initialized
INFO - 2020-03-04 01:12:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:12:09 --> Pagination Class Initialized
INFO - 2020-03-04 01:12:09 --> Model "M_show" initialized
INFO - 2020-03-04 01:12:09 --> Helper loaded: form_helper
INFO - 2020-03-04 01:12:09 --> Form Validation Class Initialized
INFO - 2020-03-04 01:12:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:12:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 01:12:09 --> Final output sent to browser
DEBUG - 2020-03-04 01:12:09 --> Total execution time: 0.0409
INFO - 2020-03-04 01:12:17 --> Config Class Initialized
INFO - 2020-03-04 01:12:17 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:12:17 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:12:17 --> Utf8 Class Initialized
INFO - 2020-03-04 01:12:17 --> URI Class Initialized
INFO - 2020-03-04 01:12:17 --> Router Class Initialized
INFO - 2020-03-04 01:12:17 --> Output Class Initialized
INFO - 2020-03-04 01:12:17 --> Security Class Initialized
DEBUG - 2020-03-04 01:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:12:17 --> Input Class Initialized
INFO - 2020-03-04 01:12:17 --> Language Class Initialized
INFO - 2020-03-04 01:12:17 --> Loader Class Initialized
INFO - 2020-03-04 01:12:17 --> Helper loaded: url_helper
INFO - 2020-03-04 01:12:17 --> Helper loaded: string_helper
INFO - 2020-03-04 01:12:17 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:12:17 --> Controller Class Initialized
INFO - 2020-03-04 01:12:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:12:17 --> Pagination Class Initialized
INFO - 2020-03-04 01:12:17 --> Model "M_show" initialized
INFO - 2020-03-04 01:12:17 --> Helper loaded: form_helper
INFO - 2020-03-04 01:12:17 --> Form Validation Class Initialized
INFO - 2020-03-04 01:12:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:12:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 01:12:17 --> Final output sent to browser
DEBUG - 2020-03-04 01:12:17 --> Total execution time: 0.0100
INFO - 2020-03-04 01:12:17 --> Config Class Initialized
INFO - 2020-03-04 01:12:17 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:12:17 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:12:17 --> Utf8 Class Initialized
INFO - 2020-03-04 01:12:17 --> URI Class Initialized
INFO - 2020-03-04 01:12:17 --> Router Class Initialized
INFO - 2020-03-04 01:12:17 --> Output Class Initialized
INFO - 2020-03-04 01:12:17 --> Security Class Initialized
DEBUG - 2020-03-04 01:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:12:17 --> Input Class Initialized
INFO - 2020-03-04 01:12:17 --> Language Class Initialized
ERROR - 2020-03-04 01:12:17 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 01:12:20 --> Config Class Initialized
INFO - 2020-03-04 01:12:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:12:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:12:20 --> Utf8 Class Initialized
INFO - 2020-03-04 01:12:20 --> URI Class Initialized
INFO - 2020-03-04 01:12:20 --> Router Class Initialized
INFO - 2020-03-04 01:12:20 --> Output Class Initialized
INFO - 2020-03-04 01:12:20 --> Security Class Initialized
DEBUG - 2020-03-04 01:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:12:20 --> Input Class Initialized
INFO - 2020-03-04 01:12:20 --> Language Class Initialized
INFO - 2020-03-04 01:12:20 --> Loader Class Initialized
INFO - 2020-03-04 01:12:20 --> Helper loaded: url_helper
INFO - 2020-03-04 01:12:20 --> Helper loaded: string_helper
INFO - 2020-03-04 01:12:20 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:12:20 --> Controller Class Initialized
INFO - 2020-03-04 01:12:20 --> Model "M_tiket" initialized
INFO - 2020-03-04 01:12:20 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 01:12:20 --> Model "M_pesan" initialized
INFO - 2020-03-04 01:12:20 --> Helper loaded: form_helper
INFO - 2020-03-04 01:12:20 --> Form Validation Class Initialized
INFO - 2020-03-04 01:12:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 01:12:20 --> Final output sent to browser
DEBUG - 2020-03-04 01:12:20 --> Total execution time: 0.0099
INFO - 2020-03-04 01:13:25 --> Config Class Initialized
INFO - 2020-03-04 01:13:25 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:13:25 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:13:25 --> Utf8 Class Initialized
INFO - 2020-03-04 01:13:25 --> URI Class Initialized
DEBUG - 2020-03-04 01:13:25 --> No URI present. Default controller set.
INFO - 2020-03-04 01:13:25 --> Router Class Initialized
INFO - 2020-03-04 01:13:25 --> Output Class Initialized
INFO - 2020-03-04 01:13:25 --> Security Class Initialized
DEBUG - 2020-03-04 01:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:13:25 --> Input Class Initialized
INFO - 2020-03-04 01:13:25 --> Language Class Initialized
INFO - 2020-03-04 01:13:25 --> Loader Class Initialized
INFO - 2020-03-04 01:13:25 --> Helper loaded: url_helper
INFO - 2020-03-04 01:13:25 --> Helper loaded: string_helper
INFO - 2020-03-04 01:13:25 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:13:25 --> Controller Class Initialized
INFO - 2020-03-04 01:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:13:25 --> Pagination Class Initialized
INFO - 2020-03-04 01:13:25 --> Model "M_show" initialized
INFO - 2020-03-04 01:13:25 --> Helper loaded: form_helper
INFO - 2020-03-04 01:13:25 --> Form Validation Class Initialized
INFO - 2020-03-04 01:13:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:13:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 01:13:25 --> Final output sent to browser
DEBUG - 2020-03-04 01:13:25 --> Total execution time: 0.0196
INFO - 2020-03-04 01:32:19 --> Config Class Initialized
INFO - 2020-03-04 01:32:19 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:32:19 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:32:19 --> Utf8 Class Initialized
INFO - 2020-03-04 01:32:19 --> URI Class Initialized
DEBUG - 2020-03-04 01:32:19 --> No URI present. Default controller set.
INFO - 2020-03-04 01:32:19 --> Router Class Initialized
INFO - 2020-03-04 01:32:19 --> Output Class Initialized
INFO - 2020-03-04 01:32:19 --> Security Class Initialized
DEBUG - 2020-03-04 01:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:32:19 --> Input Class Initialized
INFO - 2020-03-04 01:32:19 --> Language Class Initialized
INFO - 2020-03-04 01:32:19 --> Loader Class Initialized
INFO - 2020-03-04 01:32:19 --> Helper loaded: url_helper
INFO - 2020-03-04 01:32:19 --> Helper loaded: string_helper
INFO - 2020-03-04 01:32:19 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:32:19 --> Controller Class Initialized
INFO - 2020-03-04 01:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:32:19 --> Pagination Class Initialized
INFO - 2020-03-04 01:32:19 --> Model "M_show" initialized
INFO - 2020-03-04 01:32:19 --> Helper loaded: form_helper
INFO - 2020-03-04 01:32:19 --> Form Validation Class Initialized
INFO - 2020-03-04 01:32:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:32:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 01:32:19 --> Final output sent to browser
DEBUG - 2020-03-04 01:32:19 --> Total execution time: 0.0316
INFO - 2020-03-04 01:32:50 --> Config Class Initialized
INFO - 2020-03-04 01:32:50 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:32:50 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:32:50 --> Utf8 Class Initialized
INFO - 2020-03-04 01:32:50 --> URI Class Initialized
INFO - 2020-03-04 01:32:50 --> Router Class Initialized
INFO - 2020-03-04 01:32:50 --> Output Class Initialized
INFO - 2020-03-04 01:32:50 --> Security Class Initialized
DEBUG - 2020-03-04 01:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:32:50 --> Input Class Initialized
INFO - 2020-03-04 01:32:50 --> Language Class Initialized
INFO - 2020-03-04 01:32:50 --> Loader Class Initialized
INFO - 2020-03-04 01:32:50 --> Helper loaded: url_helper
INFO - 2020-03-04 01:32:50 --> Helper loaded: string_helper
INFO - 2020-03-04 01:32:50 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:32:50 --> Controller Class Initialized
INFO - 2020-03-04 01:32:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:32:50 --> Pagination Class Initialized
INFO - 2020-03-04 01:32:50 --> Model "M_show" initialized
INFO - 2020-03-04 01:32:50 --> Helper loaded: form_helper
INFO - 2020-03-04 01:32:50 --> Form Validation Class Initialized
INFO - 2020-03-04 01:32:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:32:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 01:32:50 --> Final output sent to browser
DEBUG - 2020-03-04 01:32:50 --> Total execution time: 0.0076
INFO - 2020-03-04 01:32:55 --> Config Class Initialized
INFO - 2020-03-04 01:32:55 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:32:55 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:32:55 --> Utf8 Class Initialized
INFO - 2020-03-04 01:32:55 --> URI Class Initialized
INFO - 2020-03-04 01:32:55 --> Router Class Initialized
INFO - 2020-03-04 01:32:55 --> Output Class Initialized
INFO - 2020-03-04 01:32:55 --> Security Class Initialized
DEBUG - 2020-03-04 01:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:32:55 --> Input Class Initialized
INFO - 2020-03-04 01:32:55 --> Language Class Initialized
INFO - 2020-03-04 01:32:55 --> Loader Class Initialized
INFO - 2020-03-04 01:32:55 --> Helper loaded: url_helper
INFO - 2020-03-04 01:32:55 --> Helper loaded: string_helper
INFO - 2020-03-04 01:32:55 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:32:55 --> Controller Class Initialized
INFO - 2020-03-04 01:32:55 --> Model "M_tiket" initialized
INFO - 2020-03-04 01:32:55 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 01:32:55 --> Model "M_pesan" initialized
INFO - 2020-03-04 01:32:55 --> Helper loaded: form_helper
INFO - 2020-03-04 01:32:55 --> Form Validation Class Initialized
INFO - 2020-03-04 01:32:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 01:32:55 --> Final output sent to browser
DEBUG - 2020-03-04 01:32:55 --> Total execution time: 0.0096
INFO - 2020-03-04 01:33:17 --> Config Class Initialized
INFO - 2020-03-04 01:33:17 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:33:17 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:33:17 --> Utf8 Class Initialized
INFO - 2020-03-04 01:33:17 --> URI Class Initialized
INFO - 2020-03-04 01:33:17 --> Router Class Initialized
INFO - 2020-03-04 01:33:17 --> Output Class Initialized
INFO - 2020-03-04 01:33:17 --> Security Class Initialized
DEBUG - 2020-03-04 01:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:33:17 --> Input Class Initialized
INFO - 2020-03-04 01:33:17 --> Language Class Initialized
INFO - 2020-03-04 01:33:17 --> Loader Class Initialized
INFO - 2020-03-04 01:33:17 --> Helper loaded: url_helper
INFO - 2020-03-04 01:33:17 --> Helper loaded: string_helper
INFO - 2020-03-04 01:33:17 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:33:17 --> Controller Class Initialized
INFO - 2020-03-04 01:33:17 --> Model "M_tiket" initialized
INFO - 2020-03-04 01:33:17 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 01:33:17 --> Model "M_pesan" initialized
INFO - 2020-03-04 01:33:17 --> Helper loaded: form_helper
INFO - 2020-03-04 01:33:17 --> Form Validation Class Initialized
INFO - 2020-03-04 01:33:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 01:33:17 --> Final output sent to browser
DEBUG - 2020-03-04 01:33:17 --> Total execution time: 0.0078
INFO - 2020-03-04 01:33:44 --> Config Class Initialized
INFO - 2020-03-04 01:33:44 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:33:44 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:33:44 --> Utf8 Class Initialized
INFO - 2020-03-04 01:33:44 --> URI Class Initialized
INFO - 2020-03-04 01:33:44 --> Router Class Initialized
INFO - 2020-03-04 01:33:44 --> Output Class Initialized
INFO - 2020-03-04 01:33:44 --> Security Class Initialized
DEBUG - 2020-03-04 01:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:33:44 --> Input Class Initialized
INFO - 2020-03-04 01:33:44 --> Language Class Initialized
INFO - 2020-03-04 01:33:44 --> Loader Class Initialized
INFO - 2020-03-04 01:33:44 --> Helper loaded: url_helper
INFO - 2020-03-04 01:33:44 --> Helper loaded: string_helper
INFO - 2020-03-04 01:33:44 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:33:44 --> Controller Class Initialized
INFO - 2020-03-04 01:33:44 --> Model "M_tiket" initialized
INFO - 2020-03-04 01:33:44 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 01:33:44 --> Model "M_pesan" initialized
INFO - 2020-03-04 01:33:44 --> Helper loaded: form_helper
INFO - 2020-03-04 01:33:44 --> Form Validation Class Initialized
INFO - 2020-03-04 01:33:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 01:33:44 --> Final output sent to browser
DEBUG - 2020-03-04 01:33:44 --> Total execution time: 0.0071
INFO - 2020-03-04 01:34:40 --> Config Class Initialized
INFO - 2020-03-04 01:34:40 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:34:40 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:34:40 --> Utf8 Class Initialized
INFO - 2020-03-04 01:34:40 --> URI Class Initialized
DEBUG - 2020-03-04 01:34:40 --> No URI present. Default controller set.
INFO - 2020-03-04 01:34:40 --> Router Class Initialized
INFO - 2020-03-04 01:34:40 --> Output Class Initialized
INFO - 2020-03-04 01:34:40 --> Security Class Initialized
DEBUG - 2020-03-04 01:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:34:40 --> Input Class Initialized
INFO - 2020-03-04 01:34:40 --> Language Class Initialized
INFO - 2020-03-04 01:34:40 --> Loader Class Initialized
INFO - 2020-03-04 01:34:40 --> Helper loaded: url_helper
INFO - 2020-03-04 01:34:40 --> Helper loaded: string_helper
INFO - 2020-03-04 01:34:40 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:34:40 --> Controller Class Initialized
INFO - 2020-03-04 01:34:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:34:40 --> Pagination Class Initialized
INFO - 2020-03-04 01:34:40 --> Model "M_show" initialized
INFO - 2020-03-04 01:34:40 --> Helper loaded: form_helper
INFO - 2020-03-04 01:34:40 --> Form Validation Class Initialized
INFO - 2020-03-04 01:34:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:34:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 01:34:40 --> Final output sent to browser
DEBUG - 2020-03-04 01:34:40 --> Total execution time: 0.0052
INFO - 2020-03-04 01:41:09 --> Config Class Initialized
INFO - 2020-03-04 01:41:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:41:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:41:09 --> Utf8 Class Initialized
INFO - 2020-03-04 01:41:09 --> URI Class Initialized
DEBUG - 2020-03-04 01:41:09 --> No URI present. Default controller set.
INFO - 2020-03-04 01:41:09 --> Router Class Initialized
INFO - 2020-03-04 01:41:09 --> Output Class Initialized
INFO - 2020-03-04 01:41:09 --> Security Class Initialized
DEBUG - 2020-03-04 01:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:41:09 --> Input Class Initialized
INFO - 2020-03-04 01:41:09 --> Language Class Initialized
INFO - 2020-03-04 01:41:09 --> Loader Class Initialized
INFO - 2020-03-04 01:41:09 --> Helper loaded: url_helper
INFO - 2020-03-04 01:41:09 --> Helper loaded: string_helper
INFO - 2020-03-04 01:41:09 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:41:09 --> Controller Class Initialized
INFO - 2020-03-04 01:41:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:41:09 --> Pagination Class Initialized
INFO - 2020-03-04 01:41:09 --> Model "M_show" initialized
INFO - 2020-03-04 01:41:09 --> Helper loaded: form_helper
INFO - 2020-03-04 01:41:09 --> Form Validation Class Initialized
INFO - 2020-03-04 01:41:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:41:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 01:41:09 --> Final output sent to browser
DEBUG - 2020-03-04 01:41:09 --> Total execution time: 0.0292
INFO - 2020-03-04 01:41:19 --> Config Class Initialized
INFO - 2020-03-04 01:41:19 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:41:19 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:41:19 --> Utf8 Class Initialized
INFO - 2020-03-04 01:41:19 --> URI Class Initialized
INFO - 2020-03-04 01:41:19 --> Router Class Initialized
INFO - 2020-03-04 01:41:19 --> Output Class Initialized
INFO - 2020-03-04 01:41:19 --> Security Class Initialized
DEBUG - 2020-03-04 01:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:41:19 --> Input Class Initialized
INFO - 2020-03-04 01:41:19 --> Language Class Initialized
INFO - 2020-03-04 01:41:19 --> Loader Class Initialized
INFO - 2020-03-04 01:41:19 --> Helper loaded: url_helper
INFO - 2020-03-04 01:41:19 --> Helper loaded: string_helper
INFO - 2020-03-04 01:41:19 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:41:19 --> Controller Class Initialized
INFO - 2020-03-04 01:41:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:41:19 --> Pagination Class Initialized
INFO - 2020-03-04 01:41:19 --> Model "M_show" initialized
INFO - 2020-03-04 01:41:19 --> Helper loaded: form_helper
INFO - 2020-03-04 01:41:19 --> Form Validation Class Initialized
INFO - 2020-03-04 01:41:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:41:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 01:41:19 --> Final output sent to browser
DEBUG - 2020-03-04 01:41:19 --> Total execution time: 0.0074
INFO - 2020-03-04 01:41:25 --> Config Class Initialized
INFO - 2020-03-04 01:41:25 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:41:25 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:41:25 --> Utf8 Class Initialized
INFO - 2020-03-04 01:41:25 --> URI Class Initialized
INFO - 2020-03-04 01:41:25 --> Router Class Initialized
INFO - 2020-03-04 01:41:25 --> Output Class Initialized
INFO - 2020-03-04 01:41:25 --> Security Class Initialized
DEBUG - 2020-03-04 01:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:41:25 --> Input Class Initialized
INFO - 2020-03-04 01:41:25 --> Language Class Initialized
INFO - 2020-03-04 01:41:25 --> Loader Class Initialized
INFO - 2020-03-04 01:41:25 --> Helper loaded: url_helper
INFO - 2020-03-04 01:41:25 --> Helper loaded: string_helper
INFO - 2020-03-04 01:41:25 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:41:25 --> Controller Class Initialized
INFO - 2020-03-04 01:41:25 --> Model "M_tiket" initialized
INFO - 2020-03-04 01:41:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 01:41:25 --> Model "M_pesan" initialized
INFO - 2020-03-04 01:41:25 --> Helper loaded: form_helper
INFO - 2020-03-04 01:41:25 --> Form Validation Class Initialized
INFO - 2020-03-04 01:41:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 01:41:25 --> Final output sent to browser
DEBUG - 2020-03-04 01:41:25 --> Total execution time: 0.0136
INFO - 2020-03-04 01:41:52 --> Config Class Initialized
INFO - 2020-03-04 01:41:52 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:41:52 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:41:52 --> Utf8 Class Initialized
INFO - 2020-03-04 01:41:52 --> URI Class Initialized
INFO - 2020-03-04 01:41:52 --> Router Class Initialized
INFO - 2020-03-04 01:41:52 --> Output Class Initialized
INFO - 2020-03-04 01:41:52 --> Security Class Initialized
DEBUG - 2020-03-04 01:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:41:52 --> Input Class Initialized
INFO - 2020-03-04 01:41:52 --> Language Class Initialized
INFO - 2020-03-04 01:41:52 --> Loader Class Initialized
INFO - 2020-03-04 01:41:52 --> Helper loaded: url_helper
INFO - 2020-03-04 01:41:52 --> Helper loaded: string_helper
INFO - 2020-03-04 01:41:52 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:41:52 --> Controller Class Initialized
INFO - 2020-03-04 01:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:41:52 --> Pagination Class Initialized
INFO - 2020-03-04 01:41:52 --> Model "M_show" initialized
INFO - 2020-03-04 01:41:52 --> Helper loaded: form_helper
INFO - 2020-03-04 01:41:52 --> Form Validation Class Initialized
INFO - 2020-03-04 01:41:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:41:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 01:41:52 --> Final output sent to browser
DEBUG - 2020-03-04 01:41:52 --> Total execution time: 0.0066
INFO - 2020-03-04 01:41:57 --> Config Class Initialized
INFO - 2020-03-04 01:41:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:41:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:41:57 --> Utf8 Class Initialized
INFO - 2020-03-04 01:41:57 --> URI Class Initialized
DEBUG - 2020-03-04 01:41:57 --> No URI present. Default controller set.
INFO - 2020-03-04 01:41:57 --> Router Class Initialized
INFO - 2020-03-04 01:41:57 --> Output Class Initialized
INFO - 2020-03-04 01:41:57 --> Security Class Initialized
DEBUG - 2020-03-04 01:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:41:57 --> Input Class Initialized
INFO - 2020-03-04 01:41:57 --> Language Class Initialized
INFO - 2020-03-04 01:41:57 --> Loader Class Initialized
INFO - 2020-03-04 01:41:57 --> Helper loaded: url_helper
INFO - 2020-03-04 01:41:57 --> Helper loaded: string_helper
INFO - 2020-03-04 01:41:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:41:57 --> Controller Class Initialized
INFO - 2020-03-04 01:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:41:57 --> Pagination Class Initialized
INFO - 2020-03-04 01:41:57 --> Model "M_show" initialized
INFO - 2020-03-04 01:41:57 --> Helper loaded: form_helper
INFO - 2020-03-04 01:41:57 --> Form Validation Class Initialized
INFO - 2020-03-04 01:41:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:41:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 01:41:57 --> Final output sent to browser
DEBUG - 2020-03-04 01:41:57 --> Total execution time: 0.0057
INFO - 2020-03-04 01:41:59 --> Config Class Initialized
INFO - 2020-03-04 01:41:59 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:41:59 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:41:59 --> Utf8 Class Initialized
INFO - 2020-03-04 01:41:59 --> URI Class Initialized
INFO - 2020-03-04 01:41:59 --> Router Class Initialized
INFO - 2020-03-04 01:41:59 --> Output Class Initialized
INFO - 2020-03-04 01:41:59 --> Security Class Initialized
DEBUG - 2020-03-04 01:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:41:59 --> Input Class Initialized
INFO - 2020-03-04 01:41:59 --> Language Class Initialized
INFO - 2020-03-04 01:41:59 --> Loader Class Initialized
INFO - 2020-03-04 01:41:59 --> Helper loaded: url_helper
INFO - 2020-03-04 01:41:59 --> Helper loaded: string_helper
INFO - 2020-03-04 01:41:59 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:41:59 --> Controller Class Initialized
INFO - 2020-03-04 01:41:59 --> Model "M_tiket" initialized
INFO - 2020-03-04 01:41:59 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 01:41:59 --> Model "M_pesan" initialized
INFO - 2020-03-04 01:41:59 --> Helper loaded: form_helper
INFO - 2020-03-04 01:41:59 --> Form Validation Class Initialized
INFO - 2020-03-04 01:41:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 01:41:59 --> Final output sent to browser
DEBUG - 2020-03-04 01:41:59 --> Total execution time: 0.0066
INFO - 2020-03-04 01:42:10 --> Config Class Initialized
INFO - 2020-03-04 01:42:10 --> Hooks Class Initialized
DEBUG - 2020-03-04 01:42:10 --> UTF-8 Support Enabled
INFO - 2020-03-04 01:42:10 --> Utf8 Class Initialized
INFO - 2020-03-04 01:42:10 --> URI Class Initialized
INFO - 2020-03-04 01:42:10 --> Router Class Initialized
INFO - 2020-03-04 01:42:10 --> Output Class Initialized
INFO - 2020-03-04 01:42:10 --> Security Class Initialized
DEBUG - 2020-03-04 01:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 01:42:10 --> Input Class Initialized
INFO - 2020-03-04 01:42:10 --> Language Class Initialized
INFO - 2020-03-04 01:42:10 --> Loader Class Initialized
INFO - 2020-03-04 01:42:10 --> Helper loaded: url_helper
INFO - 2020-03-04 01:42:10 --> Helper loaded: string_helper
INFO - 2020-03-04 01:42:10 --> Database Driver Class Initialized
DEBUG - 2020-03-04 01:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 01:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 01:42:10 --> Controller Class Initialized
INFO - 2020-03-04 01:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 01:42:10 --> Pagination Class Initialized
INFO - 2020-03-04 01:42:10 --> Model "M_show" initialized
INFO - 2020-03-04 01:42:10 --> Helper loaded: form_helper
INFO - 2020-03-04 01:42:10 --> Form Validation Class Initialized
INFO - 2020-03-04 01:42:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 01:42:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 01:42:10 --> Final output sent to browser
DEBUG - 2020-03-04 01:42:10 --> Total execution time: 0.0061
INFO - 2020-03-04 02:02:50 --> Config Class Initialized
INFO - 2020-03-04 02:02:50 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:02:50 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:02:50 --> Utf8 Class Initialized
INFO - 2020-03-04 02:02:50 --> URI Class Initialized
INFO - 2020-03-04 02:02:50 --> Router Class Initialized
INFO - 2020-03-04 02:02:50 --> Output Class Initialized
INFO - 2020-03-04 02:02:50 --> Security Class Initialized
DEBUG - 2020-03-04 02:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:02:50 --> Input Class Initialized
INFO - 2020-03-04 02:02:50 --> Language Class Initialized
INFO - 2020-03-04 02:02:50 --> Loader Class Initialized
INFO - 2020-03-04 02:02:50 --> Helper loaded: url_helper
INFO - 2020-03-04 02:02:50 --> Helper loaded: string_helper
INFO - 2020-03-04 02:02:50 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:02:50 --> Controller Class Initialized
INFO - 2020-03-04 02:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:02:50 --> Pagination Class Initialized
INFO - 2020-03-04 02:02:50 --> Model "M_show" initialized
INFO - 2020-03-04 02:02:50 --> Helper loaded: form_helper
INFO - 2020-03-04 02:02:50 --> Form Validation Class Initialized
INFO - 2020-03-04 02:02:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:02:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 02:02:50 --> Final output sent to browser
DEBUG - 2020-03-04 02:02:50 --> Total execution time: 0.0345
INFO - 2020-03-04 02:03:23 --> Config Class Initialized
INFO - 2020-03-04 02:03:23 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:03:23 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:03:23 --> Utf8 Class Initialized
INFO - 2020-03-04 02:03:23 --> URI Class Initialized
INFO - 2020-03-04 02:03:23 --> Router Class Initialized
INFO - 2020-03-04 02:03:23 --> Output Class Initialized
INFO - 2020-03-04 02:03:23 --> Security Class Initialized
DEBUG - 2020-03-04 02:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:03:23 --> Input Class Initialized
INFO - 2020-03-04 02:03:23 --> Language Class Initialized
INFO - 2020-03-04 02:03:23 --> Loader Class Initialized
INFO - 2020-03-04 02:03:23 --> Helper loaded: url_helper
INFO - 2020-03-04 02:03:23 --> Helper loaded: string_helper
INFO - 2020-03-04 02:03:23 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:03:23 --> Controller Class Initialized
INFO - 2020-03-04 02:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:03:23 --> Pagination Class Initialized
INFO - 2020-03-04 02:03:23 --> Model "M_show" initialized
INFO - 2020-03-04 02:03:23 --> Helper loaded: form_helper
INFO - 2020-03-04 02:03:23 --> Form Validation Class Initialized
INFO - 2020-03-04 02:03:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:03:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 02:03:23 --> Final output sent to browser
DEBUG - 2020-03-04 02:03:23 --> Total execution time: 0.0054
INFO - 2020-03-04 02:05:10 --> Config Class Initialized
INFO - 2020-03-04 02:05:10 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:05:10 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:05:10 --> Utf8 Class Initialized
INFO - 2020-03-04 02:05:10 --> URI Class Initialized
DEBUG - 2020-03-04 02:05:10 --> No URI present. Default controller set.
INFO - 2020-03-04 02:05:10 --> Router Class Initialized
INFO - 2020-03-04 02:05:10 --> Output Class Initialized
INFO - 2020-03-04 02:05:10 --> Security Class Initialized
DEBUG - 2020-03-04 02:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:05:10 --> Input Class Initialized
INFO - 2020-03-04 02:05:10 --> Language Class Initialized
INFO - 2020-03-04 02:05:10 --> Loader Class Initialized
INFO - 2020-03-04 02:05:10 --> Helper loaded: url_helper
INFO - 2020-03-04 02:05:10 --> Helper loaded: string_helper
INFO - 2020-03-04 02:05:10 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:05:10 --> Controller Class Initialized
INFO - 2020-03-04 02:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:05:10 --> Pagination Class Initialized
INFO - 2020-03-04 02:05:10 --> Model "M_show" initialized
INFO - 2020-03-04 02:05:10 --> Helper loaded: form_helper
INFO - 2020-03-04 02:05:10 --> Form Validation Class Initialized
INFO - 2020-03-04 02:05:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:05:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 02:05:10 --> Final output sent to browser
DEBUG - 2020-03-04 02:05:10 --> Total execution time: 0.0459
INFO - 2020-03-04 02:05:12 --> Config Class Initialized
INFO - 2020-03-04 02:05:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:05:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:05:12 --> Utf8 Class Initialized
INFO - 2020-03-04 02:05:12 --> URI Class Initialized
DEBUG - 2020-03-04 02:05:12 --> No URI present. Default controller set.
INFO - 2020-03-04 02:05:12 --> Router Class Initialized
INFO - 2020-03-04 02:05:12 --> Output Class Initialized
INFO - 2020-03-04 02:05:12 --> Security Class Initialized
DEBUG - 2020-03-04 02:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:05:12 --> Input Class Initialized
INFO - 2020-03-04 02:05:12 --> Language Class Initialized
INFO - 2020-03-04 02:05:12 --> Loader Class Initialized
INFO - 2020-03-04 02:05:12 --> Helper loaded: url_helper
INFO - 2020-03-04 02:05:12 --> Helper loaded: string_helper
INFO - 2020-03-04 02:05:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:05:12 --> Controller Class Initialized
INFO - 2020-03-04 02:05:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:05:12 --> Pagination Class Initialized
INFO - 2020-03-04 02:05:12 --> Model "M_show" initialized
INFO - 2020-03-04 02:05:12 --> Helper loaded: form_helper
INFO - 2020-03-04 02:05:12 --> Form Validation Class Initialized
INFO - 2020-03-04 02:05:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:05:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 02:05:12 --> Final output sent to browser
DEBUG - 2020-03-04 02:05:12 --> Total execution time: 0.0053
INFO - 2020-03-04 02:05:20 --> Config Class Initialized
INFO - 2020-03-04 02:05:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:05:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:05:20 --> Utf8 Class Initialized
INFO - 2020-03-04 02:05:20 --> URI Class Initialized
INFO - 2020-03-04 02:05:20 --> Router Class Initialized
INFO - 2020-03-04 02:05:20 --> Output Class Initialized
INFO - 2020-03-04 02:05:20 --> Security Class Initialized
DEBUG - 2020-03-04 02:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:05:20 --> Input Class Initialized
INFO - 2020-03-04 02:05:20 --> Language Class Initialized
INFO - 2020-03-04 02:05:20 --> Loader Class Initialized
INFO - 2020-03-04 02:05:20 --> Helper loaded: url_helper
INFO - 2020-03-04 02:05:20 --> Helper loaded: string_helper
INFO - 2020-03-04 02:05:20 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:05:20 --> Controller Class Initialized
INFO - 2020-03-04 02:05:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:05:20 --> Pagination Class Initialized
INFO - 2020-03-04 02:05:20 --> Model "M_show" initialized
INFO - 2020-03-04 02:05:20 --> Helper loaded: form_helper
INFO - 2020-03-04 02:05:20 --> Form Validation Class Initialized
INFO - 2020-03-04 02:05:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:05:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 02:05:20 --> Final output sent to browser
DEBUG - 2020-03-04 02:05:20 --> Total execution time: 0.0083
INFO - 2020-03-04 02:05:20 --> Config Class Initialized
INFO - 2020-03-04 02:05:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:05:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:05:20 --> Utf8 Class Initialized
INFO - 2020-03-04 02:05:20 --> URI Class Initialized
INFO - 2020-03-04 02:05:20 --> Router Class Initialized
INFO - 2020-03-04 02:05:20 --> Output Class Initialized
INFO - 2020-03-04 02:05:20 --> Security Class Initialized
DEBUG - 2020-03-04 02:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:05:20 --> Input Class Initialized
INFO - 2020-03-04 02:05:20 --> Language Class Initialized
ERROR - 2020-03-04 02:05:20 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 02:05:24 --> Config Class Initialized
INFO - 2020-03-04 02:05:24 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:05:24 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:05:24 --> Utf8 Class Initialized
INFO - 2020-03-04 02:05:24 --> URI Class Initialized
INFO - 2020-03-04 02:05:24 --> Router Class Initialized
INFO - 2020-03-04 02:05:24 --> Output Class Initialized
INFO - 2020-03-04 02:05:24 --> Security Class Initialized
DEBUG - 2020-03-04 02:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:05:24 --> Input Class Initialized
INFO - 2020-03-04 02:05:24 --> Language Class Initialized
INFO - 2020-03-04 02:05:24 --> Loader Class Initialized
INFO - 2020-03-04 02:05:24 --> Helper loaded: url_helper
INFO - 2020-03-04 02:05:24 --> Helper loaded: string_helper
INFO - 2020-03-04 02:05:24 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:05:24 --> Controller Class Initialized
INFO - 2020-03-04 02:05:24 --> Model "M_tiket" initialized
INFO - 2020-03-04 02:05:24 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 02:05:24 --> Model "M_pesan" initialized
INFO - 2020-03-04 02:05:24 --> Helper loaded: form_helper
INFO - 2020-03-04 02:05:24 --> Form Validation Class Initialized
INFO - 2020-03-04 02:05:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 02:05:24 --> Final output sent to browser
DEBUG - 2020-03-04 02:05:24 --> Total execution time: 0.0109
INFO - 2020-03-04 02:05:40 --> Config Class Initialized
INFO - 2020-03-04 02:05:40 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:05:40 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:05:40 --> Utf8 Class Initialized
INFO - 2020-03-04 02:05:40 --> URI Class Initialized
INFO - 2020-03-04 02:05:40 --> Router Class Initialized
INFO - 2020-03-04 02:05:40 --> Output Class Initialized
INFO - 2020-03-04 02:05:40 --> Security Class Initialized
DEBUG - 2020-03-04 02:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:05:40 --> Input Class Initialized
INFO - 2020-03-04 02:05:40 --> Language Class Initialized
INFO - 2020-03-04 02:05:40 --> Loader Class Initialized
INFO - 2020-03-04 02:05:40 --> Helper loaded: url_helper
INFO - 2020-03-04 02:05:40 --> Helper loaded: string_helper
INFO - 2020-03-04 02:05:40 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:05:40 --> Controller Class Initialized
INFO - 2020-03-04 02:05:40 --> Model "M_tiket" initialized
INFO - 2020-03-04 02:05:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 02:05:40 --> Model "M_pesan" initialized
INFO - 2020-03-04 02:05:40 --> Helper loaded: form_helper
INFO - 2020-03-04 02:05:40 --> Form Validation Class Initialized
INFO - 2020-03-04 02:05:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 02:05:40 --> Final output sent to browser
DEBUG - 2020-03-04 02:05:40 --> Total execution time: 0.0072
INFO - 2020-03-04 02:07:00 --> Config Class Initialized
INFO - 2020-03-04 02:07:00 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:07:00 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:07:00 --> Utf8 Class Initialized
INFO - 2020-03-04 02:07:00 --> URI Class Initialized
DEBUG - 2020-03-04 02:07:00 --> No URI present. Default controller set.
INFO - 2020-03-04 02:07:00 --> Router Class Initialized
INFO - 2020-03-04 02:07:00 --> Output Class Initialized
INFO - 2020-03-04 02:07:00 --> Security Class Initialized
DEBUG - 2020-03-04 02:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:07:00 --> Input Class Initialized
INFO - 2020-03-04 02:07:00 --> Language Class Initialized
INFO - 2020-03-04 02:07:00 --> Loader Class Initialized
INFO - 2020-03-04 02:07:00 --> Helper loaded: url_helper
INFO - 2020-03-04 02:07:00 --> Helper loaded: string_helper
INFO - 2020-03-04 02:07:00 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:07:00 --> Controller Class Initialized
INFO - 2020-03-04 02:07:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:07:00 --> Pagination Class Initialized
INFO - 2020-03-04 02:07:00 --> Model "M_show" initialized
INFO - 2020-03-04 02:07:00 --> Helper loaded: form_helper
INFO - 2020-03-04 02:07:00 --> Form Validation Class Initialized
INFO - 2020-03-04 02:07:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:07:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 02:07:00 --> Final output sent to browser
DEBUG - 2020-03-04 02:07:00 --> Total execution time: 0.0304
INFO - 2020-03-04 02:15:56 --> Config Class Initialized
INFO - 2020-03-04 02:15:56 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:15:56 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:15:56 --> Utf8 Class Initialized
INFO - 2020-03-04 02:15:56 --> URI Class Initialized
DEBUG - 2020-03-04 02:15:56 --> No URI present. Default controller set.
INFO - 2020-03-04 02:15:56 --> Router Class Initialized
INFO - 2020-03-04 02:15:56 --> Output Class Initialized
INFO - 2020-03-04 02:15:56 --> Security Class Initialized
DEBUG - 2020-03-04 02:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:15:56 --> Input Class Initialized
INFO - 2020-03-04 02:15:56 --> Language Class Initialized
INFO - 2020-03-04 02:15:56 --> Loader Class Initialized
INFO - 2020-03-04 02:15:56 --> Helper loaded: url_helper
INFO - 2020-03-04 02:15:56 --> Helper loaded: string_helper
INFO - 2020-03-04 02:15:56 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:15:56 --> Controller Class Initialized
INFO - 2020-03-04 02:15:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:15:56 --> Pagination Class Initialized
INFO - 2020-03-04 02:15:56 --> Model "M_show" initialized
INFO - 2020-03-04 02:15:56 --> Helper loaded: form_helper
INFO - 2020-03-04 02:15:56 --> Form Validation Class Initialized
INFO - 2020-03-04 02:15:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:15:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 02:15:56 --> Final output sent to browser
DEBUG - 2020-03-04 02:15:56 --> Total execution time: 0.0344
INFO - 2020-03-04 02:16:13 --> Config Class Initialized
INFO - 2020-03-04 02:16:13 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:16:13 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:16:13 --> Utf8 Class Initialized
INFO - 2020-03-04 02:16:13 --> URI Class Initialized
INFO - 2020-03-04 02:16:13 --> Router Class Initialized
INFO - 2020-03-04 02:16:13 --> Output Class Initialized
INFO - 2020-03-04 02:16:13 --> Security Class Initialized
DEBUG - 2020-03-04 02:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:16:13 --> Input Class Initialized
INFO - 2020-03-04 02:16:13 --> Language Class Initialized
INFO - 2020-03-04 02:16:13 --> Loader Class Initialized
INFO - 2020-03-04 02:16:13 --> Helper loaded: url_helper
INFO - 2020-03-04 02:16:13 --> Helper loaded: string_helper
INFO - 2020-03-04 02:16:13 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:16:13 --> Controller Class Initialized
INFO - 2020-03-04 02:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:16:13 --> Pagination Class Initialized
INFO - 2020-03-04 02:16:13 --> Model "M_show" initialized
INFO - 2020-03-04 02:16:13 --> Helper loaded: form_helper
INFO - 2020-03-04 02:16:13 --> Form Validation Class Initialized
INFO - 2020-03-04 02:16:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:16:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 02:16:13 --> Final output sent to browser
DEBUG - 2020-03-04 02:16:13 --> Total execution time: 0.0079
INFO - 2020-03-04 02:16:18 --> Config Class Initialized
INFO - 2020-03-04 02:16:18 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:16:18 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:16:18 --> Utf8 Class Initialized
INFO - 2020-03-04 02:16:18 --> URI Class Initialized
INFO - 2020-03-04 02:16:18 --> Router Class Initialized
INFO - 2020-03-04 02:16:18 --> Output Class Initialized
INFO - 2020-03-04 02:16:18 --> Security Class Initialized
DEBUG - 2020-03-04 02:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:16:18 --> Input Class Initialized
INFO - 2020-03-04 02:16:18 --> Language Class Initialized
INFO - 2020-03-04 02:16:18 --> Loader Class Initialized
INFO - 2020-03-04 02:16:18 --> Helper loaded: url_helper
INFO - 2020-03-04 02:16:18 --> Helper loaded: string_helper
INFO - 2020-03-04 02:16:18 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:16:18 --> Controller Class Initialized
INFO - 2020-03-04 02:16:18 --> Model "M_tiket" initialized
INFO - 2020-03-04 02:16:18 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 02:16:18 --> Model "M_pesan" initialized
INFO - 2020-03-04 02:16:18 --> Helper loaded: form_helper
INFO - 2020-03-04 02:16:18 --> Form Validation Class Initialized
INFO - 2020-03-04 02:16:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 02:16:18 --> Final output sent to browser
DEBUG - 2020-03-04 02:16:18 --> Total execution time: 0.0103
INFO - 2020-03-04 02:20:29 --> Config Class Initialized
INFO - 2020-03-04 02:20:29 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:20:29 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:20:29 --> Utf8 Class Initialized
INFO - 2020-03-04 02:20:29 --> URI Class Initialized
DEBUG - 2020-03-04 02:20:29 --> No URI present. Default controller set.
INFO - 2020-03-04 02:20:29 --> Router Class Initialized
INFO - 2020-03-04 02:20:29 --> Output Class Initialized
INFO - 2020-03-04 02:20:29 --> Security Class Initialized
DEBUG - 2020-03-04 02:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:20:29 --> Input Class Initialized
INFO - 2020-03-04 02:20:29 --> Language Class Initialized
INFO - 2020-03-04 02:20:29 --> Loader Class Initialized
INFO - 2020-03-04 02:20:29 --> Helper loaded: url_helper
INFO - 2020-03-04 02:20:29 --> Helper loaded: string_helper
INFO - 2020-03-04 02:20:29 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:20:29 --> Controller Class Initialized
INFO - 2020-03-04 02:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:20:29 --> Pagination Class Initialized
INFO - 2020-03-04 02:20:29 --> Model "M_show" initialized
INFO - 2020-03-04 02:20:29 --> Helper loaded: form_helper
INFO - 2020-03-04 02:20:29 --> Form Validation Class Initialized
INFO - 2020-03-04 02:20:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:20:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 02:20:29 --> Final output sent to browser
DEBUG - 2020-03-04 02:20:29 --> Total execution time: 0.0357
INFO - 2020-03-04 02:23:00 --> Config Class Initialized
INFO - 2020-03-04 02:23:00 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:23:00 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:23:00 --> Utf8 Class Initialized
INFO - 2020-03-04 02:23:00 --> URI Class Initialized
INFO - 2020-03-04 02:23:00 --> Router Class Initialized
INFO - 2020-03-04 02:23:00 --> Output Class Initialized
INFO - 2020-03-04 02:23:00 --> Security Class Initialized
DEBUG - 2020-03-04 02:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:23:00 --> Input Class Initialized
INFO - 2020-03-04 02:23:00 --> Language Class Initialized
INFO - 2020-03-04 02:23:00 --> Loader Class Initialized
INFO - 2020-03-04 02:23:00 --> Helper loaded: url_helper
INFO - 2020-03-04 02:23:00 --> Helper loaded: string_helper
INFO - 2020-03-04 02:23:00 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:23:00 --> Controller Class Initialized
INFO - 2020-03-04 02:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:23:00 --> Pagination Class Initialized
INFO - 2020-03-04 02:23:00 --> Model "M_show" initialized
INFO - 2020-03-04 02:23:00 --> Helper loaded: form_helper
INFO - 2020-03-04 02:23:00 --> Form Validation Class Initialized
INFO - 2020-03-04 02:23:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:23:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 02:23:00 --> Final output sent to browser
DEBUG - 2020-03-04 02:23:00 --> Total execution time: 0.0364
INFO - 2020-03-04 02:23:00 --> Config Class Initialized
INFO - 2020-03-04 02:23:00 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:23:00 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:23:00 --> Utf8 Class Initialized
INFO - 2020-03-04 02:23:00 --> URI Class Initialized
INFO - 2020-03-04 02:23:00 --> Router Class Initialized
INFO - 2020-03-04 02:23:00 --> Output Class Initialized
INFO - 2020-03-04 02:23:00 --> Security Class Initialized
DEBUG - 2020-03-04 02:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:23:00 --> Input Class Initialized
INFO - 2020-03-04 02:23:00 --> Language Class Initialized
ERROR - 2020-03-04 02:23:00 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 02:29:27 --> Config Class Initialized
INFO - 2020-03-04 02:29:27 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:29:27 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:29:27 --> Utf8 Class Initialized
INFO - 2020-03-04 02:29:27 --> URI Class Initialized
DEBUG - 2020-03-04 02:29:27 --> No URI present. Default controller set.
INFO - 2020-03-04 02:29:27 --> Router Class Initialized
INFO - 2020-03-04 02:29:27 --> Output Class Initialized
INFO - 2020-03-04 02:29:27 --> Security Class Initialized
DEBUG - 2020-03-04 02:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:29:27 --> Input Class Initialized
INFO - 2020-03-04 02:29:27 --> Language Class Initialized
INFO - 2020-03-04 02:29:27 --> Loader Class Initialized
INFO - 2020-03-04 02:29:27 --> Helper loaded: url_helper
INFO - 2020-03-04 02:29:27 --> Helper loaded: string_helper
INFO - 2020-03-04 02:29:27 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:29:27 --> Controller Class Initialized
INFO - 2020-03-04 02:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:29:27 --> Pagination Class Initialized
INFO - 2020-03-04 02:29:27 --> Model "M_show" initialized
INFO - 2020-03-04 02:29:27 --> Helper loaded: form_helper
INFO - 2020-03-04 02:29:27 --> Form Validation Class Initialized
INFO - 2020-03-04 02:29:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:29:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 02:29:27 --> Final output sent to browser
DEBUG - 2020-03-04 02:29:27 --> Total execution time: 0.2223
INFO - 2020-03-04 02:29:31 --> Config Class Initialized
INFO - 2020-03-04 02:29:31 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:29:31 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:29:31 --> Utf8 Class Initialized
INFO - 2020-03-04 02:29:31 --> URI Class Initialized
INFO - 2020-03-04 02:29:31 --> Router Class Initialized
INFO - 2020-03-04 02:29:31 --> Output Class Initialized
INFO - 2020-03-04 02:29:31 --> Security Class Initialized
DEBUG - 2020-03-04 02:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:29:31 --> Input Class Initialized
INFO - 2020-03-04 02:29:31 --> Language Class Initialized
INFO - 2020-03-04 02:29:31 --> Loader Class Initialized
INFO - 2020-03-04 02:29:31 --> Helper loaded: url_helper
INFO - 2020-03-04 02:29:31 --> Helper loaded: string_helper
INFO - 2020-03-04 02:29:31 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:29:31 --> Controller Class Initialized
INFO - 2020-03-04 02:29:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:29:31 --> Pagination Class Initialized
INFO - 2020-03-04 02:29:31 --> Model "M_show" initialized
INFO - 2020-03-04 02:29:31 --> Helper loaded: form_helper
INFO - 2020-03-04 02:29:31 --> Form Validation Class Initialized
INFO - 2020-03-04 02:29:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:29:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-04 02:29:31 --> Final output sent to browser
DEBUG - 2020-03-04 02:29:31 --> Total execution time: 0.0060
INFO - 2020-03-04 02:29:31 --> Config Class Initialized
INFO - 2020-03-04 02:29:31 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:29:31 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:29:31 --> Utf8 Class Initialized
INFO - 2020-03-04 02:29:31 --> URI Class Initialized
INFO - 2020-03-04 02:29:31 --> Router Class Initialized
INFO - 2020-03-04 02:29:31 --> Output Class Initialized
INFO - 2020-03-04 02:29:31 --> Security Class Initialized
DEBUG - 2020-03-04 02:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:29:31 --> Input Class Initialized
INFO - 2020-03-04 02:29:31 --> Language Class Initialized
ERROR - 2020-03-04 02:29:31 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 02:47:00 --> Config Class Initialized
INFO - 2020-03-04 02:47:00 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:47:00 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:47:00 --> Utf8 Class Initialized
INFO - 2020-03-04 02:47:00 --> URI Class Initialized
DEBUG - 2020-03-04 02:47:00 --> No URI present. Default controller set.
INFO - 2020-03-04 02:47:00 --> Router Class Initialized
INFO - 2020-03-04 02:47:00 --> Output Class Initialized
INFO - 2020-03-04 02:47:00 --> Security Class Initialized
DEBUG - 2020-03-04 02:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:47:00 --> Input Class Initialized
INFO - 2020-03-04 02:47:00 --> Language Class Initialized
INFO - 2020-03-04 02:47:00 --> Loader Class Initialized
INFO - 2020-03-04 02:47:00 --> Helper loaded: url_helper
INFO - 2020-03-04 02:47:00 --> Helper loaded: string_helper
INFO - 2020-03-04 02:47:00 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:47:00 --> Controller Class Initialized
INFO - 2020-03-04 02:47:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:47:00 --> Pagination Class Initialized
INFO - 2020-03-04 02:47:00 --> Model "M_show" initialized
INFO - 2020-03-04 02:47:00 --> Helper loaded: form_helper
INFO - 2020-03-04 02:47:00 --> Form Validation Class Initialized
INFO - 2020-03-04 02:47:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:47:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 02:47:00 --> Final output sent to browser
DEBUG - 2020-03-04 02:47:00 --> Total execution time: 0.0305
INFO - 2020-03-04 02:47:04 --> Config Class Initialized
INFO - 2020-03-04 02:47:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:47:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:47:04 --> Utf8 Class Initialized
INFO - 2020-03-04 02:47:04 --> URI Class Initialized
INFO - 2020-03-04 02:47:04 --> Router Class Initialized
INFO - 2020-03-04 02:47:04 --> Output Class Initialized
INFO - 2020-03-04 02:47:04 --> Security Class Initialized
DEBUG - 2020-03-04 02:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:47:04 --> Input Class Initialized
INFO - 2020-03-04 02:47:04 --> Language Class Initialized
INFO - 2020-03-04 02:47:04 --> Loader Class Initialized
INFO - 2020-03-04 02:47:04 --> Helper loaded: url_helper
INFO - 2020-03-04 02:47:04 --> Helper loaded: string_helper
INFO - 2020-03-04 02:47:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:47:04 --> Controller Class Initialized
INFO - 2020-03-04 02:47:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:47:04 --> Pagination Class Initialized
INFO - 2020-03-04 02:47:04 --> Model "M_show" initialized
INFO - 2020-03-04 02:47:04 --> Helper loaded: form_helper
INFO - 2020-03-04 02:47:04 --> Form Validation Class Initialized
INFO - 2020-03-04 02:47:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:47:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 02:47:04 --> Final output sent to browser
DEBUG - 2020-03-04 02:47:04 --> Total execution time: 0.0117
INFO - 2020-03-04 02:49:46 --> Config Class Initialized
INFO - 2020-03-04 02:49:46 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:49:46 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:49:46 --> Utf8 Class Initialized
INFO - 2020-03-04 02:49:46 --> URI Class Initialized
DEBUG - 2020-03-04 02:49:46 --> No URI present. Default controller set.
INFO - 2020-03-04 02:49:46 --> Router Class Initialized
INFO - 2020-03-04 02:49:46 --> Output Class Initialized
INFO - 2020-03-04 02:49:46 --> Security Class Initialized
DEBUG - 2020-03-04 02:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:49:46 --> Input Class Initialized
INFO - 2020-03-04 02:49:46 --> Language Class Initialized
INFO - 2020-03-04 02:49:46 --> Loader Class Initialized
INFO - 2020-03-04 02:49:46 --> Helper loaded: url_helper
INFO - 2020-03-04 02:49:46 --> Helper loaded: string_helper
INFO - 2020-03-04 02:49:46 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:49:46 --> Controller Class Initialized
INFO - 2020-03-04 02:49:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:49:46 --> Pagination Class Initialized
INFO - 2020-03-04 02:49:46 --> Model "M_show" initialized
INFO - 2020-03-04 02:49:46 --> Helper loaded: form_helper
INFO - 2020-03-04 02:49:46 --> Form Validation Class Initialized
INFO - 2020-03-04 02:49:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:49:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 02:49:46 --> Final output sent to browser
DEBUG - 2020-03-04 02:49:46 --> Total execution time: 0.0470
INFO - 2020-03-04 02:52:25 --> Config Class Initialized
INFO - 2020-03-04 02:52:25 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:52:25 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:52:25 --> Utf8 Class Initialized
INFO - 2020-03-04 02:52:25 --> URI Class Initialized
DEBUG - 2020-03-04 02:52:25 --> No URI present. Default controller set.
INFO - 2020-03-04 02:52:25 --> Router Class Initialized
INFO - 2020-03-04 02:52:25 --> Output Class Initialized
INFO - 2020-03-04 02:52:25 --> Security Class Initialized
DEBUG - 2020-03-04 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:52:25 --> Input Class Initialized
INFO - 2020-03-04 02:52:25 --> Language Class Initialized
INFO - 2020-03-04 02:52:25 --> Loader Class Initialized
INFO - 2020-03-04 02:52:25 --> Helper loaded: url_helper
INFO - 2020-03-04 02:52:25 --> Helper loaded: string_helper
INFO - 2020-03-04 02:52:25 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:52:25 --> Controller Class Initialized
INFO - 2020-03-04 02:52:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:52:25 --> Pagination Class Initialized
INFO - 2020-03-04 02:52:25 --> Model "M_show" initialized
INFO - 2020-03-04 02:52:25 --> Helper loaded: form_helper
INFO - 2020-03-04 02:52:25 --> Form Validation Class Initialized
INFO - 2020-03-04 02:52:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:52:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 02:52:25 --> Final output sent to browser
DEBUG - 2020-03-04 02:52:25 --> Total execution time: 0.0324
INFO - 2020-03-04 02:53:06 --> Config Class Initialized
INFO - 2020-03-04 02:53:06 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:53:06 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:53:06 --> Utf8 Class Initialized
INFO - 2020-03-04 02:53:06 --> URI Class Initialized
INFO - 2020-03-04 02:53:06 --> Router Class Initialized
INFO - 2020-03-04 02:53:06 --> Output Class Initialized
INFO - 2020-03-04 02:53:06 --> Security Class Initialized
DEBUG - 2020-03-04 02:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:53:06 --> Input Class Initialized
INFO - 2020-03-04 02:53:06 --> Language Class Initialized
INFO - 2020-03-04 02:53:06 --> Loader Class Initialized
INFO - 2020-03-04 02:53:06 --> Helper loaded: url_helper
INFO - 2020-03-04 02:53:06 --> Helper loaded: string_helper
INFO - 2020-03-04 02:53:06 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:53:06 --> Controller Class Initialized
INFO - 2020-03-04 02:53:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:53:06 --> Pagination Class Initialized
INFO - 2020-03-04 02:53:06 --> Model "M_show" initialized
INFO - 2020-03-04 02:53:06 --> Helper loaded: form_helper
INFO - 2020-03-04 02:53:06 --> Form Validation Class Initialized
INFO - 2020-03-04 02:53:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:53:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 02:53:06 --> Final output sent to browser
DEBUG - 2020-03-04 02:53:06 --> Total execution time: 0.0086
INFO - 2020-03-04 02:53:14 --> Config Class Initialized
INFO - 2020-03-04 02:53:14 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:53:14 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:53:14 --> Utf8 Class Initialized
INFO - 2020-03-04 02:53:14 --> URI Class Initialized
INFO - 2020-03-04 02:53:14 --> Router Class Initialized
INFO - 2020-03-04 02:53:14 --> Output Class Initialized
INFO - 2020-03-04 02:53:14 --> Security Class Initialized
DEBUG - 2020-03-04 02:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:53:14 --> Input Class Initialized
INFO - 2020-03-04 02:53:14 --> Language Class Initialized
INFO - 2020-03-04 02:53:14 --> Loader Class Initialized
INFO - 2020-03-04 02:53:14 --> Helper loaded: url_helper
INFO - 2020-03-04 02:53:14 --> Helper loaded: string_helper
INFO - 2020-03-04 02:53:14 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:53:14 --> Controller Class Initialized
INFO - 2020-03-04 02:53:14 --> Model "M_tiket" initialized
INFO - 2020-03-04 02:53:14 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 02:53:14 --> Model "M_pesan" initialized
INFO - 2020-03-04 02:53:14 --> Helper loaded: form_helper
INFO - 2020-03-04 02:53:14 --> Form Validation Class Initialized
INFO - 2020-03-04 02:53:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 02:53:14 --> Final output sent to browser
DEBUG - 2020-03-04 02:53:14 --> Total execution time: 0.0111
INFO - 2020-03-04 02:54:11 --> Config Class Initialized
INFO - 2020-03-04 02:54:11 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:54:11 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:54:11 --> Utf8 Class Initialized
INFO - 2020-03-04 02:54:11 --> URI Class Initialized
INFO - 2020-03-04 02:54:11 --> Router Class Initialized
INFO - 2020-03-04 02:54:11 --> Output Class Initialized
INFO - 2020-03-04 02:54:11 --> Security Class Initialized
DEBUG - 2020-03-04 02:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:54:11 --> Input Class Initialized
INFO - 2020-03-04 02:54:11 --> Language Class Initialized
INFO - 2020-03-04 02:54:11 --> Loader Class Initialized
INFO - 2020-03-04 02:54:11 --> Helper loaded: url_helper
INFO - 2020-03-04 02:54:11 --> Helper loaded: string_helper
INFO - 2020-03-04 02:54:11 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:54:11 --> Controller Class Initialized
INFO - 2020-03-04 02:54:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 02:54:11 --> Pagination Class Initialized
INFO - 2020-03-04 02:54:11 --> Model "M_show" initialized
INFO - 2020-03-04 02:54:11 --> Helper loaded: form_helper
INFO - 2020-03-04 02:54:11 --> Form Validation Class Initialized
INFO - 2020-03-04 02:54:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 02:54:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 02:54:11 --> Final output sent to browser
DEBUG - 2020-03-04 02:54:11 --> Total execution time: 0.0066
INFO - 2020-03-04 02:54:16 --> Config Class Initialized
INFO - 2020-03-04 02:54:16 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:54:16 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:54:16 --> Utf8 Class Initialized
INFO - 2020-03-04 02:54:16 --> URI Class Initialized
INFO - 2020-03-04 02:54:16 --> Router Class Initialized
INFO - 2020-03-04 02:54:16 --> Output Class Initialized
INFO - 2020-03-04 02:54:16 --> Security Class Initialized
DEBUG - 2020-03-04 02:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:54:16 --> Input Class Initialized
INFO - 2020-03-04 02:54:16 --> Language Class Initialized
INFO - 2020-03-04 02:54:16 --> Loader Class Initialized
INFO - 2020-03-04 02:54:16 --> Helper loaded: url_helper
INFO - 2020-03-04 02:54:16 --> Helper loaded: string_helper
INFO - 2020-03-04 02:54:16 --> Database Driver Class Initialized
DEBUG - 2020-03-04 02:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 02:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 02:54:16 --> Controller Class Initialized
INFO - 2020-03-04 02:54:16 --> Model "M_tiket" initialized
INFO - 2020-03-04 02:54:16 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 02:54:16 --> Model "M_pesan" initialized
INFO - 2020-03-04 02:54:16 --> Helper loaded: form_helper
INFO - 2020-03-04 02:54:16 --> Form Validation Class Initialized
INFO - 2020-03-04 02:54:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 02:54:16 --> Final output sent to browser
DEBUG - 2020-03-04 02:54:16 --> Total execution time: 0.0071
INFO - 2020-03-04 02:54:40 --> Config Class Initialized
INFO - 2020-03-04 02:54:40 --> Hooks Class Initialized
DEBUG - 2020-03-04 02:54:40 --> UTF-8 Support Enabled
INFO - 2020-03-04 02:54:40 --> Utf8 Class Initialized
INFO - 2020-03-04 02:54:40 --> URI Class Initialized
INFO - 2020-03-04 02:54:40 --> Router Class Initialized
INFO - 2020-03-04 02:54:40 --> Output Class Initialized
INFO - 2020-03-04 02:54:40 --> Security Class Initialized
DEBUG - 2020-03-04 02:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 02:54:40 --> Input Class Initialized
INFO - 2020-03-04 02:54:40 --> Language Class Initialized
ERROR - 2020-03-04 02:54:40 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 03:02:56 --> Config Class Initialized
INFO - 2020-03-04 03:02:56 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:02:56 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:02:56 --> Utf8 Class Initialized
INFO - 2020-03-04 03:02:56 --> URI Class Initialized
DEBUG - 2020-03-04 03:02:56 --> No URI present. Default controller set.
INFO - 2020-03-04 03:02:56 --> Router Class Initialized
INFO - 2020-03-04 03:02:56 --> Output Class Initialized
INFO - 2020-03-04 03:02:56 --> Security Class Initialized
DEBUG - 2020-03-04 03:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:02:56 --> Input Class Initialized
INFO - 2020-03-04 03:02:56 --> Language Class Initialized
INFO - 2020-03-04 03:02:56 --> Loader Class Initialized
INFO - 2020-03-04 03:02:56 --> Helper loaded: url_helper
INFO - 2020-03-04 03:02:56 --> Helper loaded: string_helper
INFO - 2020-03-04 03:02:56 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:02:56 --> Controller Class Initialized
INFO - 2020-03-04 03:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:02:56 --> Pagination Class Initialized
INFO - 2020-03-04 03:02:56 --> Model "M_show" initialized
INFO - 2020-03-04 03:02:56 --> Helper loaded: form_helper
INFO - 2020-03-04 03:02:56 --> Form Validation Class Initialized
INFO - 2020-03-04 03:02:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:02:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 03:02:56 --> Final output sent to browser
DEBUG - 2020-03-04 03:02:56 --> Total execution time: 0.0337
INFO - 2020-03-04 03:03:20 --> Config Class Initialized
INFO - 2020-03-04 03:03:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:03:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:03:20 --> Utf8 Class Initialized
INFO - 2020-03-04 03:03:20 --> URI Class Initialized
DEBUG - 2020-03-04 03:03:20 --> No URI present. Default controller set.
INFO - 2020-03-04 03:03:20 --> Router Class Initialized
INFO - 2020-03-04 03:03:20 --> Output Class Initialized
INFO - 2020-03-04 03:03:20 --> Security Class Initialized
DEBUG - 2020-03-04 03:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:03:20 --> Input Class Initialized
INFO - 2020-03-04 03:03:20 --> Language Class Initialized
INFO - 2020-03-04 03:03:20 --> Loader Class Initialized
INFO - 2020-03-04 03:03:20 --> Helper loaded: url_helper
INFO - 2020-03-04 03:03:20 --> Helper loaded: string_helper
INFO - 2020-03-04 03:03:20 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:03:20 --> Controller Class Initialized
INFO - 2020-03-04 03:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:03:20 --> Pagination Class Initialized
INFO - 2020-03-04 03:03:20 --> Model "M_show" initialized
INFO - 2020-03-04 03:03:20 --> Helper loaded: form_helper
INFO - 2020-03-04 03:03:20 --> Form Validation Class Initialized
INFO - 2020-03-04 03:03:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:03:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 03:03:20 --> Final output sent to browser
DEBUG - 2020-03-04 03:03:20 --> Total execution time: 0.0058
INFO - 2020-03-04 03:03:26 --> Config Class Initialized
INFO - 2020-03-04 03:03:26 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:03:26 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:03:26 --> Utf8 Class Initialized
INFO - 2020-03-04 03:03:26 --> URI Class Initialized
INFO - 2020-03-04 03:03:26 --> Router Class Initialized
INFO - 2020-03-04 03:03:26 --> Output Class Initialized
INFO - 2020-03-04 03:03:26 --> Security Class Initialized
DEBUG - 2020-03-04 03:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:03:26 --> Input Class Initialized
INFO - 2020-03-04 03:03:26 --> Language Class Initialized
INFO - 2020-03-04 03:03:26 --> Loader Class Initialized
INFO - 2020-03-04 03:03:26 --> Helper loaded: url_helper
INFO - 2020-03-04 03:03:26 --> Helper loaded: string_helper
INFO - 2020-03-04 03:03:26 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:03:26 --> Controller Class Initialized
INFO - 2020-03-04 03:03:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:03:26 --> Pagination Class Initialized
INFO - 2020-03-04 03:03:26 --> Model "M_show" initialized
INFO - 2020-03-04 03:03:26 --> Helper loaded: form_helper
INFO - 2020-03-04 03:03:26 --> Form Validation Class Initialized
INFO - 2020-03-04 03:03:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:03:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 03:03:26 --> Final output sent to browser
DEBUG - 2020-03-04 03:03:26 --> Total execution time: 0.0079
INFO - 2020-03-04 03:03:34 --> Config Class Initialized
INFO - 2020-03-04 03:03:34 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:03:34 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:03:34 --> Utf8 Class Initialized
INFO - 2020-03-04 03:03:34 --> URI Class Initialized
INFO - 2020-03-04 03:03:34 --> Router Class Initialized
INFO - 2020-03-04 03:03:34 --> Output Class Initialized
INFO - 2020-03-04 03:03:34 --> Security Class Initialized
DEBUG - 2020-03-04 03:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:03:34 --> Input Class Initialized
INFO - 2020-03-04 03:03:34 --> Language Class Initialized
INFO - 2020-03-04 03:03:34 --> Loader Class Initialized
INFO - 2020-03-04 03:03:34 --> Helper loaded: url_helper
INFO - 2020-03-04 03:03:34 --> Helper loaded: string_helper
INFO - 2020-03-04 03:03:34 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:03:34 --> Controller Class Initialized
INFO - 2020-03-04 03:03:34 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:03:34 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:03:34 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:03:34 --> Helper loaded: form_helper
INFO - 2020-03-04 03:03:34 --> Form Validation Class Initialized
INFO - 2020-03-04 03:03:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 03:03:34 --> Final output sent to browser
DEBUG - 2020-03-04 03:03:34 --> Total execution time: 0.0109
INFO - 2020-03-04 03:03:44 --> Config Class Initialized
INFO - 2020-03-04 03:03:44 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:03:44 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:03:44 --> Utf8 Class Initialized
INFO - 2020-03-04 03:03:44 --> URI Class Initialized
INFO - 2020-03-04 03:03:44 --> Router Class Initialized
INFO - 2020-03-04 03:03:44 --> Output Class Initialized
INFO - 2020-03-04 03:03:44 --> Security Class Initialized
DEBUG - 2020-03-04 03:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:03:44 --> Input Class Initialized
INFO - 2020-03-04 03:03:44 --> Language Class Initialized
INFO - 2020-03-04 03:03:44 --> Loader Class Initialized
INFO - 2020-03-04 03:03:44 --> Helper loaded: url_helper
INFO - 2020-03-04 03:03:44 --> Helper loaded: string_helper
INFO - 2020-03-04 03:03:44 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:03:44 --> Controller Class Initialized
INFO - 2020-03-04 03:03:44 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:03:44 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:03:44 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:03:44 --> Helper loaded: form_helper
INFO - 2020-03-04 03:03:44 --> Form Validation Class Initialized
INFO - 2020-03-04 03:03:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 03:03:44 --> Final output sent to browser
DEBUG - 2020-03-04 03:03:44 --> Total execution time: 0.3338
INFO - 2020-03-04 03:07:56 --> Config Class Initialized
INFO - 2020-03-04 03:07:56 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:07:56 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:07:56 --> Utf8 Class Initialized
INFO - 2020-03-04 03:07:56 --> URI Class Initialized
DEBUG - 2020-03-04 03:07:56 --> No URI present. Default controller set.
INFO - 2020-03-04 03:07:56 --> Router Class Initialized
INFO - 2020-03-04 03:07:56 --> Output Class Initialized
INFO - 2020-03-04 03:07:56 --> Security Class Initialized
DEBUG - 2020-03-04 03:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:07:56 --> Input Class Initialized
INFO - 2020-03-04 03:07:56 --> Language Class Initialized
INFO - 2020-03-04 03:07:56 --> Loader Class Initialized
INFO - 2020-03-04 03:07:56 --> Helper loaded: url_helper
INFO - 2020-03-04 03:07:56 --> Helper loaded: string_helper
INFO - 2020-03-04 03:07:56 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:07:57 --> Controller Class Initialized
INFO - 2020-03-04 03:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:07:57 --> Pagination Class Initialized
INFO - 2020-03-04 03:07:57 --> Model "M_show" initialized
INFO - 2020-03-04 03:07:57 --> Helper loaded: form_helper
INFO - 2020-03-04 03:07:57 --> Form Validation Class Initialized
INFO - 2020-03-04 03:07:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:07:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 03:07:57 --> Final output sent to browser
DEBUG - 2020-03-04 03:07:57 --> Total execution time: 0.6818
INFO - 2020-03-04 03:08:18 --> Config Class Initialized
INFO - 2020-03-04 03:08:18 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:08:18 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:08:18 --> Utf8 Class Initialized
INFO - 2020-03-04 03:08:18 --> URI Class Initialized
INFO - 2020-03-04 03:08:18 --> Router Class Initialized
INFO - 2020-03-04 03:08:18 --> Output Class Initialized
INFO - 2020-03-04 03:08:18 --> Security Class Initialized
DEBUG - 2020-03-04 03:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:08:18 --> Input Class Initialized
INFO - 2020-03-04 03:08:18 --> Language Class Initialized
INFO - 2020-03-04 03:08:18 --> Loader Class Initialized
INFO - 2020-03-04 03:08:18 --> Helper loaded: url_helper
INFO - 2020-03-04 03:08:18 --> Helper loaded: string_helper
INFO - 2020-03-04 03:08:18 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:08:18 --> Controller Class Initialized
INFO - 2020-03-04 03:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:08:18 --> Pagination Class Initialized
INFO - 2020-03-04 03:08:18 --> Model "M_show" initialized
INFO - 2020-03-04 03:08:18 --> Helper loaded: form_helper
INFO - 2020-03-04 03:08:18 --> Form Validation Class Initialized
INFO - 2020-03-04 03:08:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:08:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 03:08:18 --> Final output sent to browser
DEBUG - 2020-03-04 03:08:18 --> Total execution time: 0.0058
INFO - 2020-03-04 03:08:23 --> Config Class Initialized
INFO - 2020-03-04 03:08:23 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:08:23 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:08:23 --> Utf8 Class Initialized
INFO - 2020-03-04 03:08:23 --> URI Class Initialized
INFO - 2020-03-04 03:08:23 --> Router Class Initialized
INFO - 2020-03-04 03:08:23 --> Output Class Initialized
INFO - 2020-03-04 03:08:23 --> Security Class Initialized
DEBUG - 2020-03-04 03:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:08:23 --> Input Class Initialized
INFO - 2020-03-04 03:08:23 --> Language Class Initialized
INFO - 2020-03-04 03:08:23 --> Loader Class Initialized
INFO - 2020-03-04 03:08:23 --> Helper loaded: url_helper
INFO - 2020-03-04 03:08:23 --> Helper loaded: string_helper
INFO - 2020-03-04 03:08:23 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:08:23 --> Controller Class Initialized
INFO - 2020-03-04 03:08:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:08:23 --> Pagination Class Initialized
INFO - 2020-03-04 03:08:23 --> Model "M_show" initialized
INFO - 2020-03-04 03:08:23 --> Helper loaded: form_helper
INFO - 2020-03-04 03:08:23 --> Form Validation Class Initialized
INFO - 2020-03-04 03:08:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:08:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 03:08:23 --> Final output sent to browser
DEBUG - 2020-03-04 03:08:23 --> Total execution time: 0.0115
INFO - 2020-03-04 03:08:27 --> Config Class Initialized
INFO - 2020-03-04 03:08:27 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:08:27 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:08:27 --> Utf8 Class Initialized
INFO - 2020-03-04 03:08:27 --> URI Class Initialized
INFO - 2020-03-04 03:08:27 --> Router Class Initialized
INFO - 2020-03-04 03:08:27 --> Output Class Initialized
INFO - 2020-03-04 03:08:27 --> Security Class Initialized
DEBUG - 2020-03-04 03:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:08:27 --> Input Class Initialized
INFO - 2020-03-04 03:08:27 --> Language Class Initialized
INFO - 2020-03-04 03:08:27 --> Loader Class Initialized
INFO - 2020-03-04 03:08:27 --> Helper loaded: url_helper
INFO - 2020-03-04 03:08:27 --> Helper loaded: string_helper
INFO - 2020-03-04 03:08:27 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:08:27 --> Controller Class Initialized
INFO - 2020-03-04 03:08:27 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:08:27 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:08:27 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:08:27 --> Helper loaded: form_helper
INFO - 2020-03-04 03:08:27 --> Form Validation Class Initialized
INFO - 2020-03-04 03:08:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 03:08:27 --> Final output sent to browser
DEBUG - 2020-03-04 03:08:27 --> Total execution time: 0.0097
INFO - 2020-03-04 03:11:38 --> Config Class Initialized
INFO - 2020-03-04 03:11:38 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:11:38 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:11:38 --> Utf8 Class Initialized
INFO - 2020-03-04 03:11:38 --> URI Class Initialized
INFO - 2020-03-04 03:11:38 --> Router Class Initialized
INFO - 2020-03-04 03:11:38 --> Output Class Initialized
INFO - 2020-03-04 03:11:38 --> Security Class Initialized
DEBUG - 2020-03-04 03:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:11:38 --> Input Class Initialized
INFO - 2020-03-04 03:11:38 --> Language Class Initialized
INFO - 2020-03-04 03:11:38 --> Loader Class Initialized
INFO - 2020-03-04 03:11:38 --> Helper loaded: url_helper
INFO - 2020-03-04 03:11:38 --> Helper loaded: string_helper
INFO - 2020-03-04 03:11:38 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:11:38 --> Controller Class Initialized
INFO - 2020-03-04 03:11:38 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:11:38 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:11:38 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:11:38 --> Helper loaded: form_helper
INFO - 2020-03-04 03:11:38 --> Form Validation Class Initialized
INFO - 2020-03-04 03:11:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 03:11:38 --> Final output sent to browser
DEBUG - 2020-03-04 03:11:38 --> Total execution time: 0.0536
INFO - 2020-03-04 03:12:50 --> Config Class Initialized
INFO - 2020-03-04 03:12:50 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:12:50 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:12:50 --> Utf8 Class Initialized
INFO - 2020-03-04 03:12:50 --> URI Class Initialized
INFO - 2020-03-04 03:12:50 --> Router Class Initialized
INFO - 2020-03-04 03:12:50 --> Output Class Initialized
INFO - 2020-03-04 03:12:50 --> Security Class Initialized
DEBUG - 2020-03-04 03:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:12:50 --> Input Class Initialized
INFO - 2020-03-04 03:12:50 --> Language Class Initialized
INFO - 2020-03-04 03:12:50 --> Loader Class Initialized
INFO - 2020-03-04 03:12:50 --> Helper loaded: url_helper
INFO - 2020-03-04 03:12:50 --> Helper loaded: string_helper
INFO - 2020-03-04 03:12:50 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:12:50 --> Controller Class Initialized
INFO - 2020-03-04 03:12:50 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:12:50 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:12:50 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:12:50 --> Helper loaded: form_helper
INFO - 2020-03-04 03:12:50 --> Form Validation Class Initialized
INFO - 2020-03-04 03:12:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 03:12:50 --> Final output sent to browser
DEBUG - 2020-03-04 03:12:50 --> Total execution time: 0.0319
INFO - 2020-03-04 03:12:53 --> Config Class Initialized
INFO - 2020-03-04 03:12:53 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:12:53 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:12:53 --> Utf8 Class Initialized
INFO - 2020-03-04 03:12:53 --> URI Class Initialized
INFO - 2020-03-04 03:12:53 --> Router Class Initialized
INFO - 2020-03-04 03:12:53 --> Output Class Initialized
INFO - 2020-03-04 03:12:53 --> Security Class Initialized
DEBUG - 2020-03-04 03:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:12:53 --> Input Class Initialized
INFO - 2020-03-04 03:12:53 --> Language Class Initialized
INFO - 2020-03-04 03:12:53 --> Loader Class Initialized
INFO - 2020-03-04 03:12:53 --> Helper loaded: url_helper
INFO - 2020-03-04 03:12:53 --> Helper loaded: string_helper
INFO - 2020-03-04 03:12:53 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:12:53 --> Controller Class Initialized
INFO - 2020-03-04 03:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:12:53 --> Pagination Class Initialized
INFO - 2020-03-04 03:12:53 --> Model "M_show" initialized
INFO - 2020-03-04 03:12:53 --> Helper loaded: form_helper
INFO - 2020-03-04 03:12:53 --> Form Validation Class Initialized
INFO - 2020-03-04 03:12:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:12:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 03:12:53 --> Final output sent to browser
DEBUG - 2020-03-04 03:12:53 --> Total execution time: 0.0084
INFO - 2020-03-04 03:13:16 --> Config Class Initialized
INFO - 2020-03-04 03:13:16 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:13:16 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:13:16 --> Utf8 Class Initialized
INFO - 2020-03-04 03:13:16 --> URI Class Initialized
INFO - 2020-03-04 03:13:16 --> Router Class Initialized
INFO - 2020-03-04 03:13:16 --> Output Class Initialized
INFO - 2020-03-04 03:13:16 --> Security Class Initialized
DEBUG - 2020-03-04 03:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:13:16 --> Input Class Initialized
INFO - 2020-03-04 03:13:16 --> Language Class Initialized
INFO - 2020-03-04 03:13:16 --> Loader Class Initialized
INFO - 2020-03-04 03:13:16 --> Helper loaded: url_helper
INFO - 2020-03-04 03:13:16 --> Helper loaded: string_helper
INFO - 2020-03-04 03:13:16 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:13:16 --> Controller Class Initialized
INFO - 2020-03-04 03:13:16 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:13:16 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:13:16 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:13:16 --> Helper loaded: form_helper
INFO - 2020-03-04 03:13:16 --> Form Validation Class Initialized
INFO - 2020-03-04 03:13:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 03:13:16 --> Final output sent to browser
DEBUG - 2020-03-04 03:13:16 --> Total execution time: 0.0084
INFO - 2020-03-04 03:13:29 --> Config Class Initialized
INFO - 2020-03-04 03:13:29 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:13:29 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:13:29 --> Utf8 Class Initialized
INFO - 2020-03-04 03:13:29 --> URI Class Initialized
DEBUG - 2020-03-04 03:13:29 --> No URI present. Default controller set.
INFO - 2020-03-04 03:13:29 --> Router Class Initialized
INFO - 2020-03-04 03:13:29 --> Output Class Initialized
INFO - 2020-03-04 03:13:29 --> Security Class Initialized
DEBUG - 2020-03-04 03:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:13:29 --> Input Class Initialized
INFO - 2020-03-04 03:13:29 --> Language Class Initialized
INFO - 2020-03-04 03:13:29 --> Loader Class Initialized
INFO - 2020-03-04 03:13:29 --> Helper loaded: url_helper
INFO - 2020-03-04 03:13:29 --> Helper loaded: string_helper
INFO - 2020-03-04 03:13:29 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:13:29 --> Controller Class Initialized
INFO - 2020-03-04 03:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:13:29 --> Pagination Class Initialized
INFO - 2020-03-04 03:13:29 --> Model "M_show" initialized
INFO - 2020-03-04 03:13:29 --> Helper loaded: form_helper
INFO - 2020-03-04 03:13:29 --> Form Validation Class Initialized
INFO - 2020-03-04 03:13:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:13:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 03:13:29 --> Final output sent to browser
DEBUG - 2020-03-04 03:13:29 --> Total execution time: 0.0065
INFO - 2020-03-04 03:13:44 --> Config Class Initialized
INFO - 2020-03-04 03:13:44 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:13:44 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:13:44 --> Utf8 Class Initialized
INFO - 2020-03-04 03:13:44 --> URI Class Initialized
INFO - 2020-03-04 03:13:44 --> Router Class Initialized
INFO - 2020-03-04 03:13:44 --> Output Class Initialized
INFO - 2020-03-04 03:13:44 --> Security Class Initialized
DEBUG - 2020-03-04 03:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:13:44 --> Input Class Initialized
INFO - 2020-03-04 03:13:44 --> Language Class Initialized
INFO - 2020-03-04 03:13:44 --> Loader Class Initialized
INFO - 2020-03-04 03:13:44 --> Helper loaded: url_helper
INFO - 2020-03-04 03:13:44 --> Helper loaded: string_helper
INFO - 2020-03-04 03:13:44 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:13:44 --> Controller Class Initialized
INFO - 2020-03-04 03:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:13:44 --> Pagination Class Initialized
INFO - 2020-03-04 03:13:44 --> Model "M_show" initialized
INFO - 2020-03-04 03:13:44 --> Helper loaded: form_helper
INFO - 2020-03-04 03:13:44 --> Form Validation Class Initialized
INFO - 2020-03-04 03:13:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:13:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 03:13:44 --> Final output sent to browser
DEBUG - 2020-03-04 03:13:44 --> Total execution time: 0.0064
INFO - 2020-03-04 03:13:48 --> Config Class Initialized
INFO - 2020-03-04 03:13:48 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:13:48 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:13:48 --> Utf8 Class Initialized
INFO - 2020-03-04 03:13:48 --> URI Class Initialized
INFO - 2020-03-04 03:13:48 --> Router Class Initialized
INFO - 2020-03-04 03:13:48 --> Output Class Initialized
INFO - 2020-03-04 03:13:48 --> Security Class Initialized
DEBUG - 2020-03-04 03:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:13:48 --> Input Class Initialized
INFO - 2020-03-04 03:13:48 --> Language Class Initialized
INFO - 2020-03-04 03:13:48 --> Loader Class Initialized
INFO - 2020-03-04 03:13:48 --> Helper loaded: url_helper
INFO - 2020-03-04 03:13:48 --> Helper loaded: string_helper
INFO - 2020-03-04 03:13:48 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:13:48 --> Controller Class Initialized
INFO - 2020-03-04 03:13:48 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:13:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:13:48 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:13:48 --> Helper loaded: form_helper
INFO - 2020-03-04 03:13:48 --> Form Validation Class Initialized
INFO - 2020-03-04 03:13:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 03:13:48 --> Final output sent to browser
DEBUG - 2020-03-04 03:13:48 --> Total execution time: 0.0067
INFO - 2020-03-04 03:33:46 --> Config Class Initialized
INFO - 2020-03-04 03:33:46 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:33:46 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:33:46 --> Utf8 Class Initialized
INFO - 2020-03-04 03:33:46 --> URI Class Initialized
DEBUG - 2020-03-04 03:33:46 --> No URI present. Default controller set.
INFO - 2020-03-04 03:33:46 --> Router Class Initialized
INFO - 2020-03-04 03:33:46 --> Output Class Initialized
INFO - 2020-03-04 03:33:46 --> Security Class Initialized
DEBUG - 2020-03-04 03:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:33:46 --> Input Class Initialized
INFO - 2020-03-04 03:33:46 --> Language Class Initialized
INFO - 2020-03-04 03:33:46 --> Loader Class Initialized
INFO - 2020-03-04 03:33:46 --> Helper loaded: url_helper
INFO - 2020-03-04 03:33:46 --> Helper loaded: string_helper
INFO - 2020-03-04 03:33:46 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:33:46 --> Controller Class Initialized
INFO - 2020-03-04 03:33:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:33:46 --> Pagination Class Initialized
INFO - 2020-03-04 03:33:46 --> Model "M_show" initialized
INFO - 2020-03-04 03:33:46 --> Helper loaded: form_helper
INFO - 2020-03-04 03:33:46 --> Form Validation Class Initialized
INFO - 2020-03-04 03:33:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:33:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 03:33:46 --> Final output sent to browser
DEBUG - 2020-03-04 03:33:46 --> Total execution time: 0.0288
INFO - 2020-03-04 03:34:01 --> Config Class Initialized
INFO - 2020-03-04 03:34:01 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:34:01 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:34:01 --> Utf8 Class Initialized
INFO - 2020-03-04 03:34:01 --> URI Class Initialized
INFO - 2020-03-04 03:34:01 --> Router Class Initialized
INFO - 2020-03-04 03:34:01 --> Output Class Initialized
INFO - 2020-03-04 03:34:01 --> Security Class Initialized
DEBUG - 2020-03-04 03:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:34:01 --> Input Class Initialized
INFO - 2020-03-04 03:34:01 --> Language Class Initialized
INFO - 2020-03-04 03:34:01 --> Loader Class Initialized
INFO - 2020-03-04 03:34:01 --> Helper loaded: url_helper
INFO - 2020-03-04 03:34:01 --> Helper loaded: string_helper
INFO - 2020-03-04 03:34:01 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:34:01 --> Controller Class Initialized
INFO - 2020-03-04 03:34:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:34:01 --> Pagination Class Initialized
INFO - 2020-03-04 03:34:01 --> Model "M_show" initialized
INFO - 2020-03-04 03:34:01 --> Helper loaded: form_helper
INFO - 2020-03-04 03:34:01 --> Form Validation Class Initialized
INFO - 2020-03-04 03:34:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:34:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 03:34:01 --> Final output sent to browser
DEBUG - 2020-03-04 03:34:01 --> Total execution time: 0.0079
INFO - 2020-03-04 03:34:05 --> Config Class Initialized
INFO - 2020-03-04 03:34:05 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:34:05 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:34:05 --> Utf8 Class Initialized
INFO - 2020-03-04 03:34:05 --> URI Class Initialized
INFO - 2020-03-04 03:34:05 --> Router Class Initialized
INFO - 2020-03-04 03:34:05 --> Output Class Initialized
INFO - 2020-03-04 03:34:05 --> Security Class Initialized
DEBUG - 2020-03-04 03:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:34:05 --> Input Class Initialized
INFO - 2020-03-04 03:34:05 --> Language Class Initialized
INFO - 2020-03-04 03:34:05 --> Loader Class Initialized
INFO - 2020-03-04 03:34:05 --> Helper loaded: url_helper
INFO - 2020-03-04 03:34:05 --> Helper loaded: string_helper
INFO - 2020-03-04 03:34:05 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:34:05 --> Controller Class Initialized
INFO - 2020-03-04 03:34:05 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:34:05 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:34:05 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:34:05 --> Helper loaded: form_helper
INFO - 2020-03-04 03:34:05 --> Form Validation Class Initialized
INFO - 2020-03-04 03:34:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 03:34:05 --> Final output sent to browser
DEBUG - 2020-03-04 03:34:05 --> Total execution time: 0.0105
INFO - 2020-03-04 03:34:25 --> Config Class Initialized
INFO - 2020-03-04 03:34:25 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:34:25 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:34:25 --> Utf8 Class Initialized
INFO - 2020-03-04 03:34:25 --> URI Class Initialized
INFO - 2020-03-04 03:34:25 --> Router Class Initialized
INFO - 2020-03-04 03:34:25 --> Output Class Initialized
INFO - 2020-03-04 03:34:25 --> Security Class Initialized
DEBUG - 2020-03-04 03:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:34:25 --> Input Class Initialized
INFO - 2020-03-04 03:34:25 --> Language Class Initialized
INFO - 2020-03-04 03:34:25 --> Loader Class Initialized
INFO - 2020-03-04 03:34:25 --> Helper loaded: url_helper
INFO - 2020-03-04 03:34:25 --> Helper loaded: string_helper
INFO - 2020-03-04 03:34:25 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:34:25 --> Controller Class Initialized
INFO - 2020-03-04 03:34:25 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:34:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:34:25 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:34:25 --> Helper loaded: form_helper
INFO - 2020-03-04 03:34:25 --> Form Validation Class Initialized
INFO - 2020-03-04 03:34:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 03:34:25 --> Final output sent to browser
DEBUG - 2020-03-04 03:34:25 --> Total execution time: 0.0075
INFO - 2020-03-04 03:34:42 --> Config Class Initialized
INFO - 2020-03-04 03:34:42 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:34:42 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:34:42 --> Utf8 Class Initialized
INFO - 2020-03-04 03:34:42 --> URI Class Initialized
INFO - 2020-03-04 03:34:42 --> Router Class Initialized
INFO - 2020-03-04 03:34:42 --> Output Class Initialized
INFO - 2020-03-04 03:34:42 --> Security Class Initialized
DEBUG - 2020-03-04 03:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:34:42 --> Input Class Initialized
INFO - 2020-03-04 03:34:42 --> Language Class Initialized
INFO - 2020-03-04 03:34:42 --> Loader Class Initialized
INFO - 2020-03-04 03:34:42 --> Helper loaded: url_helper
INFO - 2020-03-04 03:34:42 --> Helper loaded: string_helper
INFO - 2020-03-04 03:34:42 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:34:42 --> Controller Class Initialized
INFO - 2020-03-04 03:34:42 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:34:42 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:34:42 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:34:42 --> Helper loaded: form_helper
INFO - 2020-03-04 03:34:42 --> Form Validation Class Initialized
INFO - 2020-03-04 03:34:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 03:34:42 --> Final output sent to browser
DEBUG - 2020-03-04 03:34:42 --> Total execution time: 0.0084
INFO - 2020-03-04 03:36:33 --> Config Class Initialized
INFO - 2020-03-04 03:36:33 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:36:33 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:36:33 --> Utf8 Class Initialized
INFO - 2020-03-04 03:36:33 --> URI Class Initialized
INFO - 2020-03-04 03:36:33 --> Router Class Initialized
INFO - 2020-03-04 03:36:33 --> Output Class Initialized
INFO - 2020-03-04 03:36:33 --> Security Class Initialized
DEBUG - 2020-03-04 03:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:36:33 --> Input Class Initialized
INFO - 2020-03-04 03:36:33 --> Language Class Initialized
INFO - 2020-03-04 03:36:33 --> Loader Class Initialized
INFO - 2020-03-04 03:36:33 --> Helper loaded: url_helper
INFO - 2020-03-04 03:36:33 --> Helper loaded: string_helper
INFO - 2020-03-04 03:36:33 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:36:33 --> Controller Class Initialized
INFO - 2020-03-04 03:36:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:36:33 --> Pagination Class Initialized
INFO - 2020-03-04 03:36:33 --> Model "M_show" initialized
INFO - 2020-03-04 03:36:33 --> Helper loaded: form_helper
INFO - 2020-03-04 03:36:33 --> Form Validation Class Initialized
INFO - 2020-03-04 03:36:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:36:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 03:36:33 --> Final output sent to browser
DEBUG - 2020-03-04 03:36:33 --> Total execution time: 0.0307
INFO - 2020-03-04 03:49:00 --> Config Class Initialized
INFO - 2020-03-04 03:49:00 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:49:00 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:49:00 --> Utf8 Class Initialized
INFO - 2020-03-04 03:49:00 --> URI Class Initialized
DEBUG - 2020-03-04 03:49:00 --> No URI present. Default controller set.
INFO - 2020-03-04 03:49:00 --> Router Class Initialized
INFO - 2020-03-04 03:49:00 --> Output Class Initialized
INFO - 2020-03-04 03:49:00 --> Security Class Initialized
DEBUG - 2020-03-04 03:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:49:00 --> Input Class Initialized
INFO - 2020-03-04 03:49:00 --> Language Class Initialized
INFO - 2020-03-04 03:49:00 --> Loader Class Initialized
INFO - 2020-03-04 03:49:00 --> Helper loaded: url_helper
INFO - 2020-03-04 03:49:00 --> Helper loaded: string_helper
INFO - 2020-03-04 03:49:00 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:49:00 --> Controller Class Initialized
INFO - 2020-03-04 03:49:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:49:00 --> Pagination Class Initialized
INFO - 2020-03-04 03:49:00 --> Model "M_show" initialized
INFO - 2020-03-04 03:49:00 --> Helper loaded: form_helper
INFO - 2020-03-04 03:49:00 --> Form Validation Class Initialized
INFO - 2020-03-04 03:49:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:49:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 03:49:00 --> Final output sent to browser
DEBUG - 2020-03-04 03:49:00 --> Total execution time: 0.0309
INFO - 2020-03-04 03:49:07 --> Config Class Initialized
INFO - 2020-03-04 03:49:07 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:49:07 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:49:07 --> Utf8 Class Initialized
INFO - 2020-03-04 03:49:07 --> URI Class Initialized
INFO - 2020-03-04 03:49:07 --> Router Class Initialized
INFO - 2020-03-04 03:49:07 --> Output Class Initialized
INFO - 2020-03-04 03:49:07 --> Security Class Initialized
DEBUG - 2020-03-04 03:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:49:07 --> Input Class Initialized
INFO - 2020-03-04 03:49:07 --> Language Class Initialized
INFO - 2020-03-04 03:49:07 --> Loader Class Initialized
INFO - 2020-03-04 03:49:07 --> Helper loaded: url_helper
INFO - 2020-03-04 03:49:07 --> Helper loaded: string_helper
INFO - 2020-03-04 03:49:07 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:49:07 --> Controller Class Initialized
INFO - 2020-03-04 03:49:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:49:07 --> Pagination Class Initialized
INFO - 2020-03-04 03:49:07 --> Model "M_show" initialized
INFO - 2020-03-04 03:49:07 --> Helper loaded: form_helper
INFO - 2020-03-04 03:49:07 --> Form Validation Class Initialized
INFO - 2020-03-04 03:49:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:49:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 03:49:07 --> Final output sent to browser
DEBUG - 2020-03-04 03:49:07 --> Total execution time: 0.0097
INFO - 2020-03-04 03:49:12 --> Config Class Initialized
INFO - 2020-03-04 03:49:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:49:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:49:12 --> Utf8 Class Initialized
INFO - 2020-03-04 03:49:12 --> URI Class Initialized
INFO - 2020-03-04 03:49:12 --> Router Class Initialized
INFO - 2020-03-04 03:49:12 --> Output Class Initialized
INFO - 2020-03-04 03:49:12 --> Security Class Initialized
DEBUG - 2020-03-04 03:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:49:12 --> Input Class Initialized
INFO - 2020-03-04 03:49:12 --> Language Class Initialized
INFO - 2020-03-04 03:49:12 --> Loader Class Initialized
INFO - 2020-03-04 03:49:12 --> Helper loaded: url_helper
INFO - 2020-03-04 03:49:12 --> Helper loaded: string_helper
INFO - 2020-03-04 03:49:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:49:12 --> Controller Class Initialized
INFO - 2020-03-04 03:49:12 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:49:12 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:49:12 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:49:12 --> Helper loaded: form_helper
INFO - 2020-03-04 03:49:12 --> Form Validation Class Initialized
INFO - 2020-03-04 03:49:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 03:49:12 --> Final output sent to browser
DEBUG - 2020-03-04 03:49:12 --> Total execution time: 0.0105
INFO - 2020-03-04 03:49:41 --> Config Class Initialized
INFO - 2020-03-04 03:49:41 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:49:41 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:49:41 --> Utf8 Class Initialized
INFO - 2020-03-04 03:49:41 --> URI Class Initialized
INFO - 2020-03-04 03:49:41 --> Router Class Initialized
INFO - 2020-03-04 03:49:41 --> Output Class Initialized
INFO - 2020-03-04 03:49:41 --> Security Class Initialized
DEBUG - 2020-03-04 03:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:49:41 --> Input Class Initialized
INFO - 2020-03-04 03:49:41 --> Language Class Initialized
INFO - 2020-03-04 03:49:41 --> Loader Class Initialized
INFO - 2020-03-04 03:49:41 --> Helper loaded: url_helper
INFO - 2020-03-04 03:49:41 --> Helper loaded: string_helper
INFO - 2020-03-04 03:49:41 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:49:41 --> Controller Class Initialized
INFO - 2020-03-04 03:49:41 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:49:41 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:49:41 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:49:41 --> Helper loaded: form_helper
INFO - 2020-03-04 03:49:41 --> Form Validation Class Initialized
INFO - 2020-03-04 03:49:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 03:49:41 --> Final output sent to browser
DEBUG - 2020-03-04 03:49:41 --> Total execution time: 0.0086
INFO - 2020-03-04 03:49:48 --> Config Class Initialized
INFO - 2020-03-04 03:49:48 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:49:48 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:49:48 --> Utf8 Class Initialized
INFO - 2020-03-04 03:49:48 --> URI Class Initialized
INFO - 2020-03-04 03:49:48 --> Router Class Initialized
INFO - 2020-03-04 03:49:48 --> Output Class Initialized
INFO - 2020-03-04 03:49:48 --> Security Class Initialized
DEBUG - 2020-03-04 03:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:49:48 --> Input Class Initialized
INFO - 2020-03-04 03:49:48 --> Language Class Initialized
INFO - 2020-03-04 03:49:48 --> Loader Class Initialized
INFO - 2020-03-04 03:49:48 --> Helper loaded: url_helper
INFO - 2020-03-04 03:49:48 --> Helper loaded: string_helper
INFO - 2020-03-04 03:49:48 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:49:48 --> Controller Class Initialized
INFO - 2020-03-04 03:49:48 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:49:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:49:48 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:49:48 --> Helper loaded: form_helper
INFO - 2020-03-04 03:49:48 --> Form Validation Class Initialized
INFO - 2020-03-04 03:49:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 03:49:48 --> Final output sent to browser
DEBUG - 2020-03-04 03:49:48 --> Total execution time: 0.0063
INFO - 2020-03-04 03:49:56 --> Config Class Initialized
INFO - 2020-03-04 03:49:56 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:49:56 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:49:56 --> Utf8 Class Initialized
INFO - 2020-03-04 03:49:56 --> URI Class Initialized
INFO - 2020-03-04 03:49:56 --> Router Class Initialized
INFO - 2020-03-04 03:49:56 --> Output Class Initialized
INFO - 2020-03-04 03:49:56 --> Security Class Initialized
DEBUG - 2020-03-04 03:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:49:56 --> Input Class Initialized
INFO - 2020-03-04 03:49:56 --> Language Class Initialized
INFO - 2020-03-04 03:49:56 --> Loader Class Initialized
INFO - 2020-03-04 03:49:56 --> Helper loaded: url_helper
INFO - 2020-03-04 03:49:56 --> Helper loaded: string_helper
INFO - 2020-03-04 03:49:56 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:49:56 --> Controller Class Initialized
INFO - 2020-03-04 03:49:56 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:49:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:49:56 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:49:56 --> Helper loaded: form_helper
INFO - 2020-03-04 03:49:56 --> Form Validation Class Initialized
INFO - 2020-03-04 03:49:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 03:49:56 --> Final output sent to browser
DEBUG - 2020-03-04 03:49:56 --> Total execution time: 0.0089
INFO - 2020-03-04 03:49:57 --> Config Class Initialized
INFO - 2020-03-04 03:49:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:49:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:49:57 --> Utf8 Class Initialized
INFO - 2020-03-04 03:49:57 --> URI Class Initialized
INFO - 2020-03-04 03:49:57 --> Router Class Initialized
INFO - 2020-03-04 03:49:57 --> Output Class Initialized
INFO - 2020-03-04 03:49:57 --> Security Class Initialized
DEBUG - 2020-03-04 03:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:49:57 --> Input Class Initialized
INFO - 2020-03-04 03:49:57 --> Language Class Initialized
INFO - 2020-03-04 03:49:57 --> Loader Class Initialized
INFO - 2020-03-04 03:49:57 --> Helper loaded: url_helper
INFO - 2020-03-04 03:49:57 --> Helper loaded: string_helper
INFO - 2020-03-04 03:49:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:49:57 --> Controller Class Initialized
INFO - 2020-03-04 03:49:57 --> Model "M_tiket" initialized
INFO - 2020-03-04 03:49:57 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 03:49:57 --> Model "M_pesan" initialized
INFO - 2020-03-04 03:49:57 --> Helper loaded: form_helper
INFO - 2020-03-04 03:49:57 --> Form Validation Class Initialized
INFO - 2020-03-04 03:49:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 03:49:57 --> Final output sent to browser
DEBUG - 2020-03-04 03:49:57 --> Total execution time: 0.0071
INFO - 2020-03-04 03:56:59 --> Config Class Initialized
INFO - 2020-03-04 03:56:59 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:56:59 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:56:59 --> Utf8 Class Initialized
INFO - 2020-03-04 03:56:59 --> URI Class Initialized
DEBUG - 2020-03-04 03:56:59 --> No URI present. Default controller set.
INFO - 2020-03-04 03:56:59 --> Router Class Initialized
INFO - 2020-03-04 03:56:59 --> Output Class Initialized
INFO - 2020-03-04 03:56:59 --> Security Class Initialized
DEBUG - 2020-03-04 03:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:56:59 --> Input Class Initialized
INFO - 2020-03-04 03:56:59 --> Language Class Initialized
INFO - 2020-03-04 03:56:59 --> Loader Class Initialized
INFO - 2020-03-04 03:56:59 --> Helper loaded: url_helper
INFO - 2020-03-04 03:56:59 --> Helper loaded: string_helper
INFO - 2020-03-04 03:56:59 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:56:59 --> Controller Class Initialized
INFO - 2020-03-04 03:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:56:59 --> Pagination Class Initialized
INFO - 2020-03-04 03:56:59 --> Model "M_show" initialized
INFO - 2020-03-04 03:56:59 --> Helper loaded: form_helper
INFO - 2020-03-04 03:56:59 --> Form Validation Class Initialized
INFO - 2020-03-04 03:56:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:56:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 03:56:59 --> Final output sent to browser
DEBUG - 2020-03-04 03:56:59 --> Total execution time: 0.0339
INFO - 2020-03-04 03:57:49 --> Config Class Initialized
INFO - 2020-03-04 03:57:49 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:57:49 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:57:49 --> Utf8 Class Initialized
INFO - 2020-03-04 03:57:49 --> URI Class Initialized
INFO - 2020-03-04 03:57:49 --> Router Class Initialized
INFO - 2020-03-04 03:57:49 --> Output Class Initialized
INFO - 2020-03-04 03:57:49 --> Security Class Initialized
DEBUG - 2020-03-04 03:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:57:49 --> Input Class Initialized
INFO - 2020-03-04 03:57:49 --> Language Class Initialized
INFO - 2020-03-04 03:57:49 --> Loader Class Initialized
INFO - 2020-03-04 03:57:49 --> Helper loaded: url_helper
INFO - 2020-03-04 03:57:49 --> Helper loaded: string_helper
INFO - 2020-03-04 03:57:49 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:57:49 --> Controller Class Initialized
INFO - 2020-03-04 03:57:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:57:49 --> Pagination Class Initialized
INFO - 2020-03-04 03:57:49 --> Model "M_show" initialized
INFO - 2020-03-04 03:57:49 --> Helper loaded: form_helper
INFO - 2020-03-04 03:57:49 --> Form Validation Class Initialized
INFO - 2020-03-04 03:57:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:57:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 03:57:49 --> Final output sent to browser
DEBUG - 2020-03-04 03:57:49 --> Total execution time: 0.0057
INFO - 2020-03-04 03:58:03 --> Config Class Initialized
INFO - 2020-03-04 03:58:03 --> Hooks Class Initialized
DEBUG - 2020-03-04 03:58:03 --> UTF-8 Support Enabled
INFO - 2020-03-04 03:58:03 --> Utf8 Class Initialized
INFO - 2020-03-04 03:58:03 --> URI Class Initialized
DEBUG - 2020-03-04 03:58:03 --> No URI present. Default controller set.
INFO - 2020-03-04 03:58:03 --> Router Class Initialized
INFO - 2020-03-04 03:58:03 --> Output Class Initialized
INFO - 2020-03-04 03:58:03 --> Security Class Initialized
DEBUG - 2020-03-04 03:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 03:58:03 --> Input Class Initialized
INFO - 2020-03-04 03:58:03 --> Language Class Initialized
INFO - 2020-03-04 03:58:03 --> Loader Class Initialized
INFO - 2020-03-04 03:58:03 --> Helper loaded: url_helper
INFO - 2020-03-04 03:58:03 --> Helper loaded: string_helper
INFO - 2020-03-04 03:58:03 --> Database Driver Class Initialized
DEBUG - 2020-03-04 03:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 03:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 03:58:03 --> Controller Class Initialized
INFO - 2020-03-04 03:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 03:58:03 --> Pagination Class Initialized
INFO - 2020-03-04 03:58:03 --> Model "M_show" initialized
INFO - 2020-03-04 03:58:03 --> Helper loaded: form_helper
INFO - 2020-03-04 03:58:03 --> Form Validation Class Initialized
INFO - 2020-03-04 03:58:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 03:58:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 03:58:03 --> Final output sent to browser
DEBUG - 2020-03-04 03:58:03 --> Total execution time: 0.0105
INFO - 2020-03-04 04:07:57 --> Config Class Initialized
INFO - 2020-03-04 04:07:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:07:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:07:57 --> Utf8 Class Initialized
INFO - 2020-03-04 04:07:57 --> URI Class Initialized
DEBUG - 2020-03-04 04:07:57 --> No URI present. Default controller set.
INFO - 2020-03-04 04:07:57 --> Router Class Initialized
INFO - 2020-03-04 04:07:57 --> Output Class Initialized
INFO - 2020-03-04 04:07:57 --> Security Class Initialized
DEBUG - 2020-03-04 04:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:07:57 --> Input Class Initialized
INFO - 2020-03-04 04:07:57 --> Language Class Initialized
INFO - 2020-03-04 04:07:57 --> Loader Class Initialized
INFO - 2020-03-04 04:07:57 --> Helper loaded: url_helper
INFO - 2020-03-04 04:07:57 --> Helper loaded: string_helper
INFO - 2020-03-04 04:07:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:07:57 --> Controller Class Initialized
INFO - 2020-03-04 04:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:07:57 --> Pagination Class Initialized
INFO - 2020-03-04 04:07:57 --> Model "M_show" initialized
INFO - 2020-03-04 04:07:57 --> Helper loaded: form_helper
INFO - 2020-03-04 04:07:57 --> Form Validation Class Initialized
INFO - 2020-03-04 04:07:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:07:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 04:07:57 --> Final output sent to browser
DEBUG - 2020-03-04 04:07:57 --> Total execution time: 0.0341
INFO - 2020-03-04 04:10:43 --> Config Class Initialized
INFO - 2020-03-04 04:10:43 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:10:43 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:10:43 --> Utf8 Class Initialized
INFO - 2020-03-04 04:10:43 --> URI Class Initialized
INFO - 2020-03-04 04:10:43 --> Router Class Initialized
INFO - 2020-03-04 04:10:43 --> Output Class Initialized
INFO - 2020-03-04 04:10:43 --> Security Class Initialized
DEBUG - 2020-03-04 04:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:10:43 --> Input Class Initialized
INFO - 2020-03-04 04:10:43 --> Language Class Initialized
INFO - 2020-03-04 04:10:43 --> Loader Class Initialized
INFO - 2020-03-04 04:10:43 --> Helper loaded: url_helper
INFO - 2020-03-04 04:10:43 --> Helper loaded: string_helper
INFO - 2020-03-04 04:10:43 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:10:43 --> Controller Class Initialized
INFO - 2020-03-04 04:10:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:10:43 --> Pagination Class Initialized
INFO - 2020-03-04 04:10:43 --> Model "M_show" initialized
INFO - 2020-03-04 04:10:43 --> Helper loaded: form_helper
INFO - 2020-03-04 04:10:43 --> Form Validation Class Initialized
INFO - 2020-03-04 04:10:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:10:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 04:10:43 --> Final output sent to browser
DEBUG - 2020-03-04 04:10:43 --> Total execution time: 0.0329
INFO - 2020-03-04 04:10:56 --> Config Class Initialized
INFO - 2020-03-04 04:10:56 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:10:56 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:10:56 --> Utf8 Class Initialized
INFO - 2020-03-04 04:10:56 --> URI Class Initialized
INFO - 2020-03-04 04:10:56 --> Router Class Initialized
INFO - 2020-03-04 04:10:56 --> Output Class Initialized
INFO - 2020-03-04 04:10:56 --> Security Class Initialized
DEBUG - 2020-03-04 04:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:10:56 --> Input Class Initialized
INFO - 2020-03-04 04:10:56 --> Language Class Initialized
INFO - 2020-03-04 04:10:56 --> Loader Class Initialized
INFO - 2020-03-04 04:10:56 --> Helper loaded: url_helper
INFO - 2020-03-04 04:10:56 --> Helper loaded: string_helper
INFO - 2020-03-04 04:10:56 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:10:56 --> Controller Class Initialized
INFO - 2020-03-04 04:10:56 --> Model "M_tiket" initialized
INFO - 2020-03-04 04:10:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 04:10:56 --> Model "M_pesan" initialized
INFO - 2020-03-04 04:10:56 --> Helper loaded: form_helper
INFO - 2020-03-04 04:10:56 --> Form Validation Class Initialized
INFO - 2020-03-04 04:10:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 04:10:56 --> Final output sent to browser
DEBUG - 2020-03-04 04:10:56 --> Total execution time: 0.0152
INFO - 2020-03-04 04:11:16 --> Config Class Initialized
INFO - 2020-03-04 04:11:16 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:11:16 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:11:16 --> Utf8 Class Initialized
INFO - 2020-03-04 04:11:16 --> URI Class Initialized
DEBUG - 2020-03-04 04:11:16 --> No URI present. Default controller set.
INFO - 2020-03-04 04:11:16 --> Router Class Initialized
INFO - 2020-03-04 04:11:16 --> Output Class Initialized
INFO - 2020-03-04 04:11:16 --> Security Class Initialized
DEBUG - 2020-03-04 04:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:11:16 --> Input Class Initialized
INFO - 2020-03-04 04:11:16 --> Language Class Initialized
INFO - 2020-03-04 04:11:16 --> Loader Class Initialized
INFO - 2020-03-04 04:11:16 --> Helper loaded: url_helper
INFO - 2020-03-04 04:11:16 --> Helper loaded: string_helper
INFO - 2020-03-04 04:11:16 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:11:16 --> Controller Class Initialized
INFO - 2020-03-04 04:11:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:11:16 --> Pagination Class Initialized
INFO - 2020-03-04 04:11:16 --> Model "M_show" initialized
INFO - 2020-03-04 04:11:16 --> Helper loaded: form_helper
INFO - 2020-03-04 04:11:16 --> Form Validation Class Initialized
INFO - 2020-03-04 04:11:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:11:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 04:11:16 --> Final output sent to browser
DEBUG - 2020-03-04 04:11:16 --> Total execution time: 0.0058
INFO - 2020-03-04 04:14:45 --> Config Class Initialized
INFO - 2020-03-04 04:14:45 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:14:45 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:14:45 --> Utf8 Class Initialized
INFO - 2020-03-04 04:14:45 --> URI Class Initialized
INFO - 2020-03-04 04:14:45 --> Router Class Initialized
INFO - 2020-03-04 04:14:45 --> Output Class Initialized
INFO - 2020-03-04 04:14:45 --> Security Class Initialized
DEBUG - 2020-03-04 04:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:14:45 --> Input Class Initialized
INFO - 2020-03-04 04:14:45 --> Language Class Initialized
INFO - 2020-03-04 04:14:45 --> Loader Class Initialized
INFO - 2020-03-04 04:14:45 --> Helper loaded: url_helper
INFO - 2020-03-04 04:14:45 --> Helper loaded: string_helper
INFO - 2020-03-04 04:14:45 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:14:45 --> Controller Class Initialized
INFO - 2020-03-04 04:14:45 --> Model "M_tiket" initialized
INFO - 2020-03-04 04:14:45 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 04:14:45 --> Model "M_pesan" initialized
INFO - 2020-03-04 04:14:45 --> Helper loaded: form_helper
INFO - 2020-03-04 04:14:45 --> Form Validation Class Initialized
INFO - 2020-03-04 04:14:46 --> Config Class Initialized
INFO - 2020-03-04 04:14:46 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:14:46 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:14:46 --> Utf8 Class Initialized
INFO - 2020-03-04 04:14:46 --> URI Class Initialized
INFO - 2020-03-04 04:14:46 --> Router Class Initialized
INFO - 2020-03-04 04:14:46 --> Output Class Initialized
INFO - 2020-03-04 04:14:46 --> Security Class Initialized
DEBUG - 2020-03-04 04:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:14:46 --> Input Class Initialized
INFO - 2020-03-04 04:14:46 --> Language Class Initialized
INFO - 2020-03-04 04:14:46 --> Loader Class Initialized
INFO - 2020-03-04 04:14:46 --> Helper loaded: url_helper
INFO - 2020-03-04 04:14:46 --> Helper loaded: string_helper
INFO - 2020-03-04 04:14:46 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:14:46 --> Controller Class Initialized
INFO - 2020-03-04 04:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:14:46 --> Pagination Class Initialized
INFO - 2020-03-04 04:14:46 --> Model "M_show" initialized
INFO - 2020-03-04 04:14:46 --> Helper loaded: form_helper
INFO - 2020-03-04 04:14:46 --> Form Validation Class Initialized
INFO - 2020-03-04 04:14:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:14:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 04:14:46 --> Final output sent to browser
DEBUG - 2020-03-04 04:14:46 --> Total execution time: 0.0097
INFO - 2020-03-04 04:14:46 --> Config Class Initialized
INFO - 2020-03-04 04:14:46 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:14:46 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:14:46 --> Utf8 Class Initialized
INFO - 2020-03-04 04:14:46 --> URI Class Initialized
INFO - 2020-03-04 04:14:46 --> Router Class Initialized
INFO - 2020-03-04 04:14:46 --> Output Class Initialized
INFO - 2020-03-04 04:14:46 --> Security Class Initialized
DEBUG - 2020-03-04 04:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:14:46 --> Input Class Initialized
INFO - 2020-03-04 04:14:46 --> Language Class Initialized
ERROR - 2020-03-04 04:14:46 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 04:19:11 --> Config Class Initialized
INFO - 2020-03-04 04:19:11 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:19:11 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:19:11 --> Utf8 Class Initialized
INFO - 2020-03-04 04:19:11 --> URI Class Initialized
INFO - 2020-03-04 04:19:11 --> Router Class Initialized
INFO - 2020-03-04 04:19:11 --> Output Class Initialized
INFO - 2020-03-04 04:19:11 --> Security Class Initialized
DEBUG - 2020-03-04 04:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:19:11 --> Input Class Initialized
INFO - 2020-03-04 04:19:11 --> Language Class Initialized
INFO - 2020-03-04 04:19:11 --> Loader Class Initialized
INFO - 2020-03-04 04:19:11 --> Helper loaded: url_helper
INFO - 2020-03-04 04:19:11 --> Helper loaded: string_helper
INFO - 2020-03-04 04:19:11 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:19:11 --> Controller Class Initialized
INFO - 2020-03-04 04:19:11 --> Model "M_tiket" initialized
INFO - 2020-03-04 04:19:11 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 04:19:11 --> Model "M_pesan" initialized
INFO - 2020-03-04 04:19:11 --> Helper loaded: form_helper
INFO - 2020-03-04 04:19:11 --> Form Validation Class Initialized
INFO - 2020-03-04 04:19:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 04:19:11 --> Final output sent to browser
DEBUG - 2020-03-04 04:19:11 --> Total execution time: 0.0317
INFO - 2020-03-04 04:23:07 --> Config Class Initialized
INFO - 2020-03-04 04:23:07 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:23:07 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:23:07 --> Utf8 Class Initialized
INFO - 2020-03-04 04:23:07 --> URI Class Initialized
INFO - 2020-03-04 04:23:07 --> Router Class Initialized
INFO - 2020-03-04 04:23:07 --> Output Class Initialized
INFO - 2020-03-04 04:23:07 --> Security Class Initialized
DEBUG - 2020-03-04 04:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:23:07 --> Input Class Initialized
INFO - 2020-03-04 04:23:07 --> Language Class Initialized
INFO - 2020-03-04 04:23:07 --> Loader Class Initialized
INFO - 2020-03-04 04:23:07 --> Helper loaded: url_helper
INFO - 2020-03-04 04:23:07 --> Helper loaded: string_helper
INFO - 2020-03-04 04:23:07 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:23:07 --> Controller Class Initialized
INFO - 2020-03-04 04:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:23:07 --> Pagination Class Initialized
INFO - 2020-03-04 04:23:07 --> Model "M_show" initialized
INFO - 2020-03-04 04:23:07 --> Helper loaded: form_helper
INFO - 2020-03-04 04:23:07 --> Form Validation Class Initialized
INFO - 2020-03-04 04:23:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:23:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 04:23:07 --> Final output sent to browser
DEBUG - 2020-03-04 04:23:07 --> Total execution time: 0.0319
INFO - 2020-03-04 04:23:10 --> Config Class Initialized
INFO - 2020-03-04 04:23:10 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:23:10 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:23:10 --> Utf8 Class Initialized
INFO - 2020-03-04 04:23:10 --> URI Class Initialized
DEBUG - 2020-03-04 04:23:10 --> No URI present. Default controller set.
INFO - 2020-03-04 04:23:10 --> Router Class Initialized
INFO - 2020-03-04 04:23:10 --> Output Class Initialized
INFO - 2020-03-04 04:23:10 --> Security Class Initialized
DEBUG - 2020-03-04 04:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:23:10 --> Input Class Initialized
INFO - 2020-03-04 04:23:10 --> Language Class Initialized
INFO - 2020-03-04 04:23:10 --> Loader Class Initialized
INFO - 2020-03-04 04:23:10 --> Helper loaded: url_helper
INFO - 2020-03-04 04:23:10 --> Helper loaded: string_helper
INFO - 2020-03-04 04:23:10 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:23:10 --> Controller Class Initialized
INFO - 2020-03-04 04:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:23:10 --> Pagination Class Initialized
INFO - 2020-03-04 04:23:10 --> Model "M_show" initialized
INFO - 2020-03-04 04:23:10 --> Helper loaded: form_helper
INFO - 2020-03-04 04:23:10 --> Form Validation Class Initialized
INFO - 2020-03-04 04:23:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:23:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 04:23:10 --> Final output sent to browser
DEBUG - 2020-03-04 04:23:10 --> Total execution time: 0.0058
INFO - 2020-03-04 04:23:39 --> Config Class Initialized
INFO - 2020-03-04 04:23:39 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:23:39 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:23:39 --> Utf8 Class Initialized
INFO - 2020-03-04 04:23:39 --> URI Class Initialized
INFO - 2020-03-04 04:23:39 --> Router Class Initialized
INFO - 2020-03-04 04:23:39 --> Output Class Initialized
INFO - 2020-03-04 04:23:39 --> Security Class Initialized
DEBUG - 2020-03-04 04:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:23:39 --> Input Class Initialized
INFO - 2020-03-04 04:23:39 --> Language Class Initialized
INFO - 2020-03-04 04:23:39 --> Loader Class Initialized
INFO - 2020-03-04 04:23:39 --> Helper loaded: url_helper
INFO - 2020-03-04 04:23:39 --> Helper loaded: string_helper
INFO - 2020-03-04 04:23:39 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:23:39 --> Controller Class Initialized
INFO - 2020-03-04 04:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:23:39 --> Pagination Class Initialized
INFO - 2020-03-04 04:23:39 --> Model "M_show" initialized
INFO - 2020-03-04 04:23:39 --> Helper loaded: form_helper
INFO - 2020-03-04 04:23:39 --> Form Validation Class Initialized
INFO - 2020-03-04 04:23:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:23:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 04:23:39 --> Final output sent to browser
DEBUG - 2020-03-04 04:23:39 --> Total execution time: 0.0068
INFO - 2020-03-04 04:23:45 --> Config Class Initialized
INFO - 2020-03-04 04:23:45 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:23:45 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:23:45 --> Utf8 Class Initialized
INFO - 2020-03-04 04:23:45 --> URI Class Initialized
INFO - 2020-03-04 04:23:45 --> Router Class Initialized
INFO - 2020-03-04 04:23:45 --> Output Class Initialized
INFO - 2020-03-04 04:23:45 --> Security Class Initialized
DEBUG - 2020-03-04 04:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:23:45 --> Input Class Initialized
INFO - 2020-03-04 04:23:45 --> Language Class Initialized
INFO - 2020-03-04 04:23:45 --> Loader Class Initialized
INFO - 2020-03-04 04:23:45 --> Helper loaded: url_helper
INFO - 2020-03-04 04:23:45 --> Helper loaded: string_helper
INFO - 2020-03-04 04:23:45 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:23:45 --> Controller Class Initialized
INFO - 2020-03-04 04:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:23:45 --> Pagination Class Initialized
INFO - 2020-03-04 04:23:45 --> Model "M_show" initialized
INFO - 2020-03-04 04:23:45 --> Helper loaded: form_helper
INFO - 2020-03-04 04:23:45 --> Form Validation Class Initialized
INFO - 2020-03-04 04:23:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:23:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-04 04:23:45 --> Final output sent to browser
DEBUG - 2020-03-04 04:23:45 --> Total execution time: 0.0360
INFO - 2020-03-04 04:24:09 --> Config Class Initialized
INFO - 2020-03-04 04:24:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:24:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:24:09 --> Utf8 Class Initialized
INFO - 2020-03-04 04:24:09 --> URI Class Initialized
INFO - 2020-03-04 04:24:09 --> Router Class Initialized
INFO - 2020-03-04 04:24:09 --> Output Class Initialized
INFO - 2020-03-04 04:24:09 --> Security Class Initialized
DEBUG - 2020-03-04 04:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:24:09 --> Input Class Initialized
INFO - 2020-03-04 04:24:09 --> Language Class Initialized
INFO - 2020-03-04 04:24:09 --> Loader Class Initialized
INFO - 2020-03-04 04:24:09 --> Helper loaded: url_helper
INFO - 2020-03-04 04:24:09 --> Helper loaded: string_helper
INFO - 2020-03-04 04:24:09 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:24:09 --> Controller Class Initialized
INFO - 2020-03-04 04:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:24:09 --> Pagination Class Initialized
INFO - 2020-03-04 04:24:09 --> Model "M_show" initialized
INFO - 2020-03-04 04:24:09 --> Helper loaded: form_helper
INFO - 2020-03-04 04:24:09 --> Form Validation Class Initialized
INFO - 2020-03-04 04:24:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:24:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 04:24:09 --> Final output sent to browser
DEBUG - 2020-03-04 04:24:09 --> Total execution time: 0.0084
INFO - 2020-03-04 04:24:16 --> Config Class Initialized
INFO - 2020-03-04 04:24:16 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:24:16 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:24:16 --> Utf8 Class Initialized
INFO - 2020-03-04 04:24:16 --> URI Class Initialized
INFO - 2020-03-04 04:24:16 --> Router Class Initialized
INFO - 2020-03-04 04:24:16 --> Output Class Initialized
INFO - 2020-03-04 04:24:16 --> Security Class Initialized
DEBUG - 2020-03-04 04:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:24:16 --> Input Class Initialized
INFO - 2020-03-04 04:24:16 --> Language Class Initialized
INFO - 2020-03-04 04:24:16 --> Loader Class Initialized
INFO - 2020-03-04 04:24:16 --> Helper loaded: url_helper
INFO - 2020-03-04 04:24:16 --> Helper loaded: string_helper
INFO - 2020-03-04 04:24:16 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:24:16 --> Controller Class Initialized
INFO - 2020-03-04 04:24:16 --> Model "M_tiket" initialized
INFO - 2020-03-04 04:24:16 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 04:24:16 --> Model "M_pesan" initialized
INFO - 2020-03-04 04:24:16 --> Helper loaded: form_helper
INFO - 2020-03-04 04:24:16 --> Form Validation Class Initialized
INFO - 2020-03-04 04:24:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 04:24:16 --> Final output sent to browser
DEBUG - 2020-03-04 04:24:16 --> Total execution time: 0.0112
INFO - 2020-03-04 04:24:47 --> Config Class Initialized
INFO - 2020-03-04 04:24:47 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:24:47 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:24:47 --> Utf8 Class Initialized
INFO - 2020-03-04 04:24:47 --> URI Class Initialized
INFO - 2020-03-04 04:24:47 --> Router Class Initialized
INFO - 2020-03-04 04:24:47 --> Output Class Initialized
INFO - 2020-03-04 04:24:47 --> Security Class Initialized
DEBUG - 2020-03-04 04:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:24:47 --> Input Class Initialized
INFO - 2020-03-04 04:24:47 --> Language Class Initialized
INFO - 2020-03-04 04:24:47 --> Loader Class Initialized
INFO - 2020-03-04 04:24:47 --> Helper loaded: url_helper
INFO - 2020-03-04 04:24:47 --> Helper loaded: string_helper
INFO - 2020-03-04 04:24:47 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:24:47 --> Controller Class Initialized
INFO - 2020-03-04 04:24:47 --> Model "M_tiket" initialized
INFO - 2020-03-04 04:24:47 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 04:24:47 --> Model "M_pesan" initialized
INFO - 2020-03-04 04:24:47 --> Helper loaded: form_helper
INFO - 2020-03-04 04:24:47 --> Form Validation Class Initialized
INFO - 2020-03-04 04:24:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 04:24:47 --> Final output sent to browser
DEBUG - 2020-03-04 04:24:47 --> Total execution time: 0.0088
INFO - 2020-03-04 04:34:20 --> Config Class Initialized
INFO - 2020-03-04 04:34:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:34:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:34:20 --> Utf8 Class Initialized
INFO - 2020-03-04 04:34:20 --> URI Class Initialized
DEBUG - 2020-03-04 04:34:20 --> No URI present. Default controller set.
INFO - 2020-03-04 04:34:20 --> Router Class Initialized
INFO - 2020-03-04 04:34:20 --> Output Class Initialized
INFO - 2020-03-04 04:34:20 --> Security Class Initialized
DEBUG - 2020-03-04 04:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:34:20 --> Input Class Initialized
INFO - 2020-03-04 04:34:20 --> Language Class Initialized
INFO - 2020-03-04 04:34:20 --> Loader Class Initialized
INFO - 2020-03-04 04:34:20 --> Helper loaded: url_helper
INFO - 2020-03-04 04:34:20 --> Helper loaded: string_helper
INFO - 2020-03-04 04:34:20 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:34:20 --> Controller Class Initialized
INFO - 2020-03-04 04:34:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:34:20 --> Pagination Class Initialized
INFO - 2020-03-04 04:34:20 --> Model "M_show" initialized
INFO - 2020-03-04 04:34:20 --> Helper loaded: form_helper
INFO - 2020-03-04 04:34:20 --> Form Validation Class Initialized
INFO - 2020-03-04 04:34:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:34:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 04:34:20 --> Final output sent to browser
DEBUG - 2020-03-04 04:34:20 --> Total execution time: 0.0365
INFO - 2020-03-04 04:34:39 --> Config Class Initialized
INFO - 2020-03-04 04:34:39 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:34:39 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:34:39 --> Utf8 Class Initialized
INFO - 2020-03-04 04:34:39 --> URI Class Initialized
INFO - 2020-03-04 04:34:39 --> Router Class Initialized
INFO - 2020-03-04 04:34:39 --> Output Class Initialized
INFO - 2020-03-04 04:34:39 --> Security Class Initialized
DEBUG - 2020-03-04 04:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:34:39 --> Input Class Initialized
INFO - 2020-03-04 04:34:39 --> Language Class Initialized
INFO - 2020-03-04 04:34:39 --> Loader Class Initialized
INFO - 2020-03-04 04:34:39 --> Helper loaded: url_helper
INFO - 2020-03-04 04:34:39 --> Helper loaded: string_helper
INFO - 2020-03-04 04:34:39 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:34:39 --> Controller Class Initialized
INFO - 2020-03-04 04:34:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:34:39 --> Pagination Class Initialized
INFO - 2020-03-04 04:34:39 --> Model "M_show" initialized
INFO - 2020-03-04 04:34:39 --> Helper loaded: form_helper
INFO - 2020-03-04 04:34:39 --> Form Validation Class Initialized
INFO - 2020-03-04 04:34:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:34:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 04:34:39 --> Final output sent to browser
DEBUG - 2020-03-04 04:34:39 --> Total execution time: 0.0090
INFO - 2020-03-04 04:34:41 --> Config Class Initialized
INFO - 2020-03-04 04:34:41 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:34:41 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:34:41 --> Utf8 Class Initialized
INFO - 2020-03-04 04:34:41 --> URI Class Initialized
INFO - 2020-03-04 04:34:41 --> Router Class Initialized
INFO - 2020-03-04 04:34:41 --> Output Class Initialized
INFO - 2020-03-04 04:34:41 --> Security Class Initialized
DEBUG - 2020-03-04 04:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:34:41 --> Input Class Initialized
INFO - 2020-03-04 04:34:41 --> Language Class Initialized
INFO - 2020-03-04 04:34:41 --> Loader Class Initialized
INFO - 2020-03-04 04:34:41 --> Helper loaded: url_helper
INFO - 2020-03-04 04:34:41 --> Helper loaded: string_helper
INFO - 2020-03-04 04:34:41 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:34:42 --> Controller Class Initialized
INFO - 2020-03-04 04:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:34:42 --> Pagination Class Initialized
INFO - 2020-03-04 04:34:42 --> Model "M_show" initialized
INFO - 2020-03-04 04:34:42 --> Helper loaded: form_helper
INFO - 2020-03-04 04:34:42 --> Form Validation Class Initialized
INFO - 2020-03-04 04:34:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:34:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-04 04:34:42 --> Final output sent to browser
DEBUG - 2020-03-04 04:34:42 --> Total execution time: 0.0718
INFO - 2020-03-04 04:34:47 --> Config Class Initialized
INFO - 2020-03-04 04:34:47 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:34:47 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:34:47 --> Utf8 Class Initialized
INFO - 2020-03-04 04:34:47 --> URI Class Initialized
INFO - 2020-03-04 04:34:47 --> Router Class Initialized
INFO - 2020-03-04 04:34:47 --> Output Class Initialized
INFO - 2020-03-04 04:34:47 --> Security Class Initialized
DEBUG - 2020-03-04 04:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:34:47 --> Input Class Initialized
INFO - 2020-03-04 04:34:47 --> Language Class Initialized
INFO - 2020-03-04 04:34:47 --> Loader Class Initialized
INFO - 2020-03-04 04:34:47 --> Helper loaded: url_helper
INFO - 2020-03-04 04:34:47 --> Helper loaded: string_helper
INFO - 2020-03-04 04:34:47 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:34:47 --> Controller Class Initialized
INFO - 2020-03-04 04:34:47 --> Model "M_tiket" initialized
INFO - 2020-03-04 04:34:47 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 04:34:47 --> Model "M_pesan" initialized
INFO - 2020-03-04 04:34:47 --> Helper loaded: form_helper
INFO - 2020-03-04 04:34:47 --> Form Validation Class Initialized
INFO - 2020-03-04 04:34:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 04:34:47 --> Final output sent to browser
DEBUG - 2020-03-04 04:34:47 --> Total execution time: 0.0134
INFO - 2020-03-04 04:34:54 --> Config Class Initialized
INFO - 2020-03-04 04:34:54 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:34:54 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:34:54 --> Utf8 Class Initialized
INFO - 2020-03-04 04:34:54 --> URI Class Initialized
DEBUG - 2020-03-04 04:34:54 --> No URI present. Default controller set.
INFO - 2020-03-04 04:34:54 --> Router Class Initialized
INFO - 2020-03-04 04:34:54 --> Output Class Initialized
INFO - 2020-03-04 04:34:54 --> Security Class Initialized
DEBUG - 2020-03-04 04:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:34:54 --> Input Class Initialized
INFO - 2020-03-04 04:34:54 --> Language Class Initialized
INFO - 2020-03-04 04:34:54 --> Loader Class Initialized
INFO - 2020-03-04 04:34:54 --> Helper loaded: url_helper
INFO - 2020-03-04 04:34:54 --> Helper loaded: string_helper
INFO - 2020-03-04 04:34:54 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:34:54 --> Controller Class Initialized
INFO - 2020-03-04 04:34:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:34:54 --> Pagination Class Initialized
INFO - 2020-03-04 04:34:54 --> Model "M_show" initialized
INFO - 2020-03-04 04:34:54 --> Helper loaded: form_helper
INFO - 2020-03-04 04:34:54 --> Form Validation Class Initialized
INFO - 2020-03-04 04:34:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:34:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 04:34:54 --> Final output sent to browser
DEBUG - 2020-03-04 04:34:54 --> Total execution time: 0.0062
INFO - 2020-03-04 04:35:03 --> Config Class Initialized
INFO - 2020-03-04 04:35:03 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:35:03 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:35:03 --> Utf8 Class Initialized
INFO - 2020-03-04 04:35:03 --> URI Class Initialized
INFO - 2020-03-04 04:35:03 --> Router Class Initialized
INFO - 2020-03-04 04:35:03 --> Output Class Initialized
INFO - 2020-03-04 04:35:03 --> Security Class Initialized
DEBUG - 2020-03-04 04:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:35:03 --> Input Class Initialized
INFO - 2020-03-04 04:35:03 --> Language Class Initialized
INFO - 2020-03-04 04:35:03 --> Loader Class Initialized
INFO - 2020-03-04 04:35:03 --> Helper loaded: url_helper
INFO - 2020-03-04 04:35:03 --> Helper loaded: string_helper
INFO - 2020-03-04 04:35:03 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:35:03 --> Controller Class Initialized
INFO - 2020-03-04 04:35:03 --> Model "M_tiket" initialized
INFO - 2020-03-04 04:35:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 04:35:03 --> Model "M_pesan" initialized
INFO - 2020-03-04 04:35:03 --> Helper loaded: form_helper
INFO - 2020-03-04 04:35:03 --> Form Validation Class Initialized
INFO - 2020-03-04 04:35:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 04:35:03 --> Final output sent to browser
DEBUG - 2020-03-04 04:35:03 --> Total execution time: 0.0094
INFO - 2020-03-04 04:35:28 --> Config Class Initialized
INFO - 2020-03-04 04:35:28 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:35:28 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:35:28 --> Utf8 Class Initialized
INFO - 2020-03-04 04:35:28 --> URI Class Initialized
INFO - 2020-03-04 04:35:28 --> Router Class Initialized
INFO - 2020-03-04 04:35:28 --> Output Class Initialized
INFO - 2020-03-04 04:35:28 --> Security Class Initialized
DEBUG - 2020-03-04 04:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:35:28 --> Input Class Initialized
INFO - 2020-03-04 04:35:28 --> Language Class Initialized
INFO - 2020-03-04 04:35:28 --> Loader Class Initialized
INFO - 2020-03-04 04:35:28 --> Helper loaded: url_helper
INFO - 2020-03-04 04:35:28 --> Helper loaded: string_helper
INFO - 2020-03-04 04:35:28 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:35:28 --> Controller Class Initialized
INFO - 2020-03-04 04:35:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:35:28 --> Pagination Class Initialized
INFO - 2020-03-04 04:35:28 --> Model "M_show" initialized
INFO - 2020-03-04 04:35:28 --> Helper loaded: form_helper
INFO - 2020-03-04 04:35:28 --> Form Validation Class Initialized
INFO - 2020-03-04 04:35:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:35:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 04:35:28 --> Final output sent to browser
DEBUG - 2020-03-04 04:35:28 --> Total execution time: 0.0063
INFO - 2020-03-04 04:36:01 --> Config Class Initialized
INFO - 2020-03-04 04:36:01 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:36:01 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:36:01 --> Utf8 Class Initialized
INFO - 2020-03-04 04:36:01 --> URI Class Initialized
INFO - 2020-03-04 04:36:01 --> Router Class Initialized
INFO - 2020-03-04 04:36:01 --> Output Class Initialized
INFO - 2020-03-04 04:36:01 --> Security Class Initialized
DEBUG - 2020-03-04 04:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:36:01 --> Input Class Initialized
INFO - 2020-03-04 04:36:01 --> Language Class Initialized
INFO - 2020-03-04 04:36:01 --> Loader Class Initialized
INFO - 2020-03-04 04:36:01 --> Helper loaded: url_helper
INFO - 2020-03-04 04:36:01 --> Helper loaded: string_helper
INFO - 2020-03-04 04:36:01 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:36:01 --> Controller Class Initialized
INFO - 2020-03-04 04:36:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:36:01 --> Pagination Class Initialized
INFO - 2020-03-04 04:36:01 --> Model "M_show" initialized
INFO - 2020-03-04 04:36:01 --> Helper loaded: form_helper
INFO - 2020-03-04 04:36:01 --> Form Validation Class Initialized
INFO - 2020-03-04 04:36:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:36:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 04:36:01 --> Final output sent to browser
DEBUG - 2020-03-04 04:36:01 --> Total execution time: 0.0073
INFO - 2020-03-04 04:36:10 --> Config Class Initialized
INFO - 2020-03-04 04:36:10 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:36:10 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:36:10 --> Utf8 Class Initialized
INFO - 2020-03-04 04:36:10 --> URI Class Initialized
INFO - 2020-03-04 04:36:10 --> Router Class Initialized
INFO - 2020-03-04 04:36:10 --> Output Class Initialized
INFO - 2020-03-04 04:36:10 --> Security Class Initialized
DEBUG - 2020-03-04 04:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:36:10 --> Input Class Initialized
INFO - 2020-03-04 04:36:10 --> Language Class Initialized
INFO - 2020-03-04 04:36:10 --> Loader Class Initialized
INFO - 2020-03-04 04:36:10 --> Helper loaded: url_helper
INFO - 2020-03-04 04:36:10 --> Helper loaded: string_helper
INFO - 2020-03-04 04:36:10 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:36:10 --> Controller Class Initialized
INFO - 2020-03-04 04:36:10 --> Model "M_tiket" initialized
INFO - 2020-03-04 04:36:10 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 04:36:10 --> Model "M_pesan" initialized
INFO - 2020-03-04 04:36:10 --> Helper loaded: form_helper
INFO - 2020-03-04 04:36:10 --> Form Validation Class Initialized
INFO - 2020-03-04 04:36:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 04:36:10 --> Final output sent to browser
DEBUG - 2020-03-04 04:36:10 --> Total execution time: 0.0081
INFO - 2020-03-04 04:41:45 --> Config Class Initialized
INFO - 2020-03-04 04:41:45 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:41:45 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:41:45 --> Utf8 Class Initialized
INFO - 2020-03-04 04:41:45 --> URI Class Initialized
DEBUG - 2020-03-04 04:41:45 --> No URI present. Default controller set.
INFO - 2020-03-04 04:41:45 --> Router Class Initialized
INFO - 2020-03-04 04:41:45 --> Output Class Initialized
INFO - 2020-03-04 04:41:45 --> Security Class Initialized
DEBUG - 2020-03-04 04:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:41:45 --> Input Class Initialized
INFO - 2020-03-04 04:41:45 --> Language Class Initialized
INFO - 2020-03-04 04:41:45 --> Loader Class Initialized
INFO - 2020-03-04 04:41:45 --> Helper loaded: url_helper
INFO - 2020-03-04 04:41:45 --> Helper loaded: string_helper
INFO - 2020-03-04 04:41:45 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:41:45 --> Controller Class Initialized
INFO - 2020-03-04 04:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:41:45 --> Pagination Class Initialized
INFO - 2020-03-04 04:41:45 --> Model "M_show" initialized
INFO - 2020-03-04 04:41:45 --> Helper loaded: form_helper
INFO - 2020-03-04 04:41:45 --> Form Validation Class Initialized
INFO - 2020-03-04 04:41:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:41:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 04:41:45 --> Final output sent to browser
DEBUG - 2020-03-04 04:41:45 --> Total execution time: 0.0320
INFO - 2020-03-04 04:42:08 --> Config Class Initialized
INFO - 2020-03-04 04:42:08 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:42:08 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:42:08 --> Utf8 Class Initialized
INFO - 2020-03-04 04:42:08 --> URI Class Initialized
INFO - 2020-03-04 04:42:08 --> Router Class Initialized
INFO - 2020-03-04 04:42:08 --> Output Class Initialized
INFO - 2020-03-04 04:42:08 --> Security Class Initialized
DEBUG - 2020-03-04 04:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:42:08 --> Input Class Initialized
INFO - 2020-03-04 04:42:08 --> Language Class Initialized
INFO - 2020-03-04 04:42:08 --> Loader Class Initialized
INFO - 2020-03-04 04:42:08 --> Helper loaded: url_helper
INFO - 2020-03-04 04:42:08 --> Helper loaded: string_helper
INFO - 2020-03-04 04:42:08 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:42:08 --> Controller Class Initialized
INFO - 2020-03-04 04:42:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:42:08 --> Pagination Class Initialized
INFO - 2020-03-04 04:42:08 --> Model "M_show" initialized
INFO - 2020-03-04 04:42:08 --> Helper loaded: form_helper
INFO - 2020-03-04 04:42:08 --> Form Validation Class Initialized
INFO - 2020-03-04 04:42:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:42:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 04:42:08 --> Final output sent to browser
DEBUG - 2020-03-04 04:42:08 --> Total execution time: 0.0076
INFO - 2020-03-04 04:42:09 --> Config Class Initialized
INFO - 2020-03-04 04:42:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:42:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:42:09 --> Utf8 Class Initialized
INFO - 2020-03-04 04:42:09 --> URI Class Initialized
INFO - 2020-03-04 04:42:09 --> Router Class Initialized
INFO - 2020-03-04 04:42:09 --> Output Class Initialized
INFO - 2020-03-04 04:42:09 --> Security Class Initialized
DEBUG - 2020-03-04 04:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:42:09 --> Input Class Initialized
INFO - 2020-03-04 04:42:09 --> Language Class Initialized
ERROR - 2020-03-04 04:42:09 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 04:42:12 --> Config Class Initialized
INFO - 2020-03-04 04:42:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:42:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:42:12 --> Utf8 Class Initialized
INFO - 2020-03-04 04:42:12 --> URI Class Initialized
INFO - 2020-03-04 04:42:12 --> Router Class Initialized
INFO - 2020-03-04 04:42:12 --> Output Class Initialized
INFO - 2020-03-04 04:42:12 --> Security Class Initialized
DEBUG - 2020-03-04 04:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:42:12 --> Input Class Initialized
INFO - 2020-03-04 04:42:12 --> Language Class Initialized
INFO - 2020-03-04 04:42:12 --> Loader Class Initialized
INFO - 2020-03-04 04:42:12 --> Helper loaded: url_helper
INFO - 2020-03-04 04:42:12 --> Helper loaded: string_helper
INFO - 2020-03-04 04:42:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:42:12 --> Controller Class Initialized
INFO - 2020-03-04 04:42:12 --> Model "M_tiket" initialized
INFO - 2020-03-04 04:42:12 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 04:42:12 --> Model "M_pesan" initialized
INFO - 2020-03-04 04:42:12 --> Helper loaded: form_helper
INFO - 2020-03-04 04:42:12 --> Form Validation Class Initialized
INFO - 2020-03-04 04:42:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 04:42:12 --> Final output sent to browser
DEBUG - 2020-03-04 04:42:12 --> Total execution time: 0.0099
INFO - 2020-03-04 04:58:28 --> Config Class Initialized
INFO - 2020-03-04 04:58:28 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:58:28 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:58:28 --> Utf8 Class Initialized
INFO - 2020-03-04 04:58:28 --> URI Class Initialized
DEBUG - 2020-03-04 04:58:28 --> No URI present. Default controller set.
INFO - 2020-03-04 04:58:28 --> Router Class Initialized
INFO - 2020-03-04 04:58:28 --> Output Class Initialized
INFO - 2020-03-04 04:58:28 --> Security Class Initialized
DEBUG - 2020-03-04 04:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:58:28 --> Input Class Initialized
INFO - 2020-03-04 04:58:28 --> Language Class Initialized
INFO - 2020-03-04 04:58:28 --> Loader Class Initialized
INFO - 2020-03-04 04:58:28 --> Helper loaded: url_helper
INFO - 2020-03-04 04:58:28 --> Helper loaded: string_helper
INFO - 2020-03-04 04:58:28 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:58:28 --> Controller Class Initialized
INFO - 2020-03-04 04:58:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:58:28 --> Pagination Class Initialized
INFO - 2020-03-04 04:58:28 --> Model "M_show" initialized
INFO - 2020-03-04 04:58:28 --> Helper loaded: form_helper
INFO - 2020-03-04 04:58:28 --> Form Validation Class Initialized
INFO - 2020-03-04 04:58:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:58:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 04:58:28 --> Final output sent to browser
DEBUG - 2020-03-04 04:58:28 --> Total execution time: 0.0359
INFO - 2020-03-04 04:58:53 --> Config Class Initialized
INFO - 2020-03-04 04:58:53 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:58:53 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:58:53 --> Utf8 Class Initialized
INFO - 2020-03-04 04:58:53 --> URI Class Initialized
INFO - 2020-03-04 04:58:53 --> Router Class Initialized
INFO - 2020-03-04 04:58:53 --> Output Class Initialized
INFO - 2020-03-04 04:58:53 --> Security Class Initialized
DEBUG - 2020-03-04 04:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:58:53 --> Input Class Initialized
INFO - 2020-03-04 04:58:53 --> Language Class Initialized
INFO - 2020-03-04 04:58:53 --> Loader Class Initialized
INFO - 2020-03-04 04:58:53 --> Helper loaded: url_helper
INFO - 2020-03-04 04:58:53 --> Helper loaded: string_helper
INFO - 2020-03-04 04:58:53 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:58:53 --> Controller Class Initialized
INFO - 2020-03-04 04:58:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 04:58:53 --> Pagination Class Initialized
INFO - 2020-03-04 04:58:53 --> Model "M_show" initialized
INFO - 2020-03-04 04:58:53 --> Helper loaded: form_helper
INFO - 2020-03-04 04:58:53 --> Form Validation Class Initialized
INFO - 2020-03-04 04:58:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 04:58:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 04:58:53 --> Final output sent to browser
DEBUG - 2020-03-04 04:58:53 --> Total execution time: 0.0083
INFO - 2020-03-04 04:58:57 --> Config Class Initialized
INFO - 2020-03-04 04:58:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:58:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:58:57 --> Utf8 Class Initialized
INFO - 2020-03-04 04:58:57 --> URI Class Initialized
INFO - 2020-03-04 04:58:57 --> Router Class Initialized
INFO - 2020-03-04 04:58:57 --> Output Class Initialized
INFO - 2020-03-04 04:58:57 --> Security Class Initialized
DEBUG - 2020-03-04 04:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:58:57 --> Input Class Initialized
INFO - 2020-03-04 04:58:57 --> Language Class Initialized
INFO - 2020-03-04 04:58:57 --> Loader Class Initialized
INFO - 2020-03-04 04:58:57 --> Helper loaded: url_helper
INFO - 2020-03-04 04:58:57 --> Helper loaded: string_helper
INFO - 2020-03-04 04:58:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:58:57 --> Controller Class Initialized
INFO - 2020-03-04 04:58:57 --> Model "M_tiket" initialized
INFO - 2020-03-04 04:58:57 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 04:58:57 --> Model "M_pesan" initialized
INFO - 2020-03-04 04:58:57 --> Helper loaded: form_helper
INFO - 2020-03-04 04:58:57 --> Form Validation Class Initialized
INFO - 2020-03-04 04:58:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 04:58:57 --> Final output sent to browser
DEBUG - 2020-03-04 04:58:57 --> Total execution time: 0.0094
INFO - 2020-03-04 04:59:03 --> Config Class Initialized
INFO - 2020-03-04 04:59:03 --> Hooks Class Initialized
DEBUG - 2020-03-04 04:59:03 --> UTF-8 Support Enabled
INFO - 2020-03-04 04:59:03 --> Utf8 Class Initialized
INFO - 2020-03-04 04:59:03 --> URI Class Initialized
INFO - 2020-03-04 04:59:03 --> Router Class Initialized
INFO - 2020-03-04 04:59:03 --> Output Class Initialized
INFO - 2020-03-04 04:59:03 --> Security Class Initialized
DEBUG - 2020-03-04 04:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 04:59:03 --> Input Class Initialized
INFO - 2020-03-04 04:59:03 --> Language Class Initialized
INFO - 2020-03-04 04:59:03 --> Loader Class Initialized
INFO - 2020-03-04 04:59:03 --> Helper loaded: url_helper
INFO - 2020-03-04 04:59:03 --> Helper loaded: string_helper
INFO - 2020-03-04 04:59:03 --> Database Driver Class Initialized
DEBUG - 2020-03-04 04:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 04:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 04:59:03 --> Controller Class Initialized
INFO - 2020-03-04 04:59:03 --> Model "M_tiket" initialized
INFO - 2020-03-04 04:59:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 04:59:03 --> Model "M_pesan" initialized
INFO - 2020-03-04 04:59:03 --> Helper loaded: form_helper
INFO - 2020-03-04 04:59:03 --> Form Validation Class Initialized
INFO - 2020-03-04 04:59:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 04:59:03 --> Final output sent to browser
DEBUG - 2020-03-04 04:59:03 --> Total execution time: 0.0087
INFO - 2020-03-04 05:00:12 --> Config Class Initialized
INFO - 2020-03-04 05:00:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:00:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:00:12 --> Utf8 Class Initialized
INFO - 2020-03-04 05:00:12 --> URI Class Initialized
INFO - 2020-03-04 05:00:12 --> Router Class Initialized
INFO - 2020-03-04 05:00:12 --> Output Class Initialized
INFO - 2020-03-04 05:00:12 --> Security Class Initialized
DEBUG - 2020-03-04 05:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:00:12 --> Input Class Initialized
INFO - 2020-03-04 05:00:12 --> Language Class Initialized
INFO - 2020-03-04 05:00:12 --> Loader Class Initialized
INFO - 2020-03-04 05:00:12 --> Helper loaded: url_helper
INFO - 2020-03-04 05:00:12 --> Helper loaded: string_helper
INFO - 2020-03-04 05:00:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:00:12 --> Controller Class Initialized
INFO - 2020-03-04 05:00:12 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:00:12 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:00:12 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:00:12 --> Helper loaded: form_helper
INFO - 2020-03-04 05:00:12 --> Form Validation Class Initialized
DEBUG - 2020-03-04 05:00:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-04 05:00:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-04 12:00:12 --> Final output sent to browser
DEBUG - 2020-03-04 12:00:12 --> Total execution time: 0.3676
INFO - 2020-03-04 05:00:16 --> Config Class Initialized
INFO - 2020-03-04 05:00:16 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:00:16 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:00:16 --> Utf8 Class Initialized
INFO - 2020-03-04 05:00:16 --> URI Class Initialized
INFO - 2020-03-04 05:00:16 --> Router Class Initialized
INFO - 2020-03-04 05:00:16 --> Output Class Initialized
INFO - 2020-03-04 05:00:16 --> Security Class Initialized
DEBUG - 2020-03-04 05:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:00:16 --> Input Class Initialized
INFO - 2020-03-04 05:00:16 --> Language Class Initialized
INFO - 2020-03-04 05:00:16 --> Loader Class Initialized
INFO - 2020-03-04 05:00:16 --> Helper loaded: url_helper
INFO - 2020-03-04 05:00:16 --> Helper loaded: string_helper
INFO - 2020-03-04 05:00:16 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:00:16 --> Controller Class Initialized
INFO - 2020-03-04 05:00:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:00:16 --> Pagination Class Initialized
INFO - 2020-03-04 05:00:16 --> Model "M_show" initialized
INFO - 2020-03-04 05:00:16 --> Helper loaded: form_helper
INFO - 2020-03-04 05:00:16 --> Form Validation Class Initialized
INFO - 2020-03-04 05:00:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:00:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:00:16 --> Final output sent to browser
DEBUG - 2020-03-04 05:00:16 --> Total execution time: 0.0069
INFO - 2020-03-04 05:01:11 --> Config Class Initialized
INFO - 2020-03-04 05:01:11 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:01:11 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:01:11 --> Utf8 Class Initialized
INFO - 2020-03-04 05:01:11 --> URI Class Initialized
INFO - 2020-03-04 05:01:11 --> Router Class Initialized
INFO - 2020-03-04 05:01:11 --> Output Class Initialized
INFO - 2020-03-04 05:01:11 --> Security Class Initialized
DEBUG - 2020-03-04 05:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:01:11 --> Input Class Initialized
INFO - 2020-03-04 05:01:11 --> Language Class Initialized
INFO - 2020-03-04 05:01:11 --> Loader Class Initialized
INFO - 2020-03-04 05:01:11 --> Helper loaded: url_helper
INFO - 2020-03-04 05:01:11 --> Helper loaded: string_helper
INFO - 2020-03-04 05:01:11 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:01:11 --> Controller Class Initialized
INFO - 2020-03-04 05:01:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:01:11 --> Pagination Class Initialized
INFO - 2020-03-04 05:01:11 --> Model "M_show" initialized
INFO - 2020-03-04 05:01:11 --> Helper loaded: form_helper
INFO - 2020-03-04 05:01:11 --> Form Validation Class Initialized
INFO - 2020-03-04 05:01:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:01:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-04 05:01:11 --> Final output sent to browser
DEBUG - 2020-03-04 05:01:11 --> Total execution time: 0.0265
INFO - 2020-03-04 05:12:12 --> Config Class Initialized
INFO - 2020-03-04 05:12:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:12:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:12:12 --> Utf8 Class Initialized
INFO - 2020-03-04 05:12:12 --> URI Class Initialized
DEBUG - 2020-03-04 05:12:12 --> No URI present. Default controller set.
INFO - 2020-03-04 05:12:12 --> Router Class Initialized
INFO - 2020-03-04 05:12:12 --> Output Class Initialized
INFO - 2020-03-04 05:12:12 --> Security Class Initialized
DEBUG - 2020-03-04 05:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:12:12 --> Input Class Initialized
INFO - 2020-03-04 05:12:12 --> Language Class Initialized
INFO - 2020-03-04 05:12:12 --> Loader Class Initialized
INFO - 2020-03-04 05:12:12 --> Helper loaded: url_helper
INFO - 2020-03-04 05:12:12 --> Helper loaded: string_helper
INFO - 2020-03-04 05:12:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:12:12 --> Controller Class Initialized
INFO - 2020-03-04 05:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:12:12 --> Pagination Class Initialized
INFO - 2020-03-04 05:12:12 --> Model "M_show" initialized
INFO - 2020-03-04 05:12:12 --> Helper loaded: form_helper
INFO - 2020-03-04 05:12:12 --> Form Validation Class Initialized
INFO - 2020-03-04 05:12:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:12:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:12:12 --> Final output sent to browser
DEBUG - 2020-03-04 05:12:12 --> Total execution time: 0.0302
INFO - 2020-03-04 05:13:04 --> Config Class Initialized
INFO - 2020-03-04 05:13:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:13:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:13:04 --> Utf8 Class Initialized
INFO - 2020-03-04 05:13:04 --> URI Class Initialized
INFO - 2020-03-04 05:13:04 --> Router Class Initialized
INFO - 2020-03-04 05:13:04 --> Output Class Initialized
INFO - 2020-03-04 05:13:04 --> Security Class Initialized
DEBUG - 2020-03-04 05:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:13:04 --> Input Class Initialized
INFO - 2020-03-04 05:13:04 --> Language Class Initialized
INFO - 2020-03-04 05:13:04 --> Loader Class Initialized
INFO - 2020-03-04 05:13:04 --> Helper loaded: url_helper
INFO - 2020-03-04 05:13:04 --> Helper loaded: string_helper
INFO - 2020-03-04 05:13:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:13:04 --> Controller Class Initialized
INFO - 2020-03-04 05:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:13:04 --> Pagination Class Initialized
INFO - 2020-03-04 05:13:04 --> Model "M_show" initialized
INFO - 2020-03-04 05:13:04 --> Helper loaded: form_helper
INFO - 2020-03-04 05:13:04 --> Form Validation Class Initialized
INFO - 2020-03-04 05:13:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:13:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 05:13:04 --> Final output sent to browser
DEBUG - 2020-03-04 05:13:04 --> Total execution time: 0.0084
INFO - 2020-03-04 05:13:09 --> Config Class Initialized
INFO - 2020-03-04 05:13:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:13:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:13:09 --> Utf8 Class Initialized
INFO - 2020-03-04 05:13:09 --> URI Class Initialized
INFO - 2020-03-04 05:13:09 --> Router Class Initialized
INFO - 2020-03-04 05:13:09 --> Output Class Initialized
INFO - 2020-03-04 05:13:09 --> Security Class Initialized
DEBUG - 2020-03-04 05:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:13:09 --> Input Class Initialized
INFO - 2020-03-04 05:13:09 --> Language Class Initialized
INFO - 2020-03-04 05:13:09 --> Loader Class Initialized
INFO - 2020-03-04 05:13:09 --> Helper loaded: url_helper
INFO - 2020-03-04 05:13:09 --> Helper loaded: string_helper
INFO - 2020-03-04 05:13:09 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:13:09 --> Controller Class Initialized
INFO - 2020-03-04 05:13:09 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:13:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:13:09 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:13:09 --> Helper loaded: form_helper
INFO - 2020-03-04 05:13:09 --> Form Validation Class Initialized
INFO - 2020-03-04 05:13:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 05:13:09 --> Final output sent to browser
DEBUG - 2020-03-04 05:13:09 --> Total execution time: 0.0096
INFO - 2020-03-04 05:13:23 --> Config Class Initialized
INFO - 2020-03-04 05:13:23 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:13:23 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:13:23 --> Utf8 Class Initialized
INFO - 2020-03-04 05:13:23 --> URI Class Initialized
INFO - 2020-03-04 05:13:23 --> Router Class Initialized
INFO - 2020-03-04 05:13:23 --> Output Class Initialized
INFO - 2020-03-04 05:13:23 --> Security Class Initialized
DEBUG - 2020-03-04 05:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:13:23 --> Input Class Initialized
INFO - 2020-03-04 05:13:23 --> Language Class Initialized
INFO - 2020-03-04 05:13:23 --> Loader Class Initialized
INFO - 2020-03-04 05:13:23 --> Helper loaded: url_helper
INFO - 2020-03-04 05:13:23 --> Helper loaded: string_helper
INFO - 2020-03-04 05:13:23 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:13:23 --> Controller Class Initialized
INFO - 2020-03-04 05:13:23 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:13:23 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:13:23 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:13:23 --> Helper loaded: form_helper
INFO - 2020-03-04 05:13:23 --> Form Validation Class Initialized
INFO - 2020-03-04 05:13:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 05:13:23 --> Final output sent to browser
DEBUG - 2020-03-04 05:13:23 --> Total execution time: 0.0072
INFO - 2020-03-04 05:13:57 --> Config Class Initialized
INFO - 2020-03-04 05:13:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:13:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:13:57 --> Utf8 Class Initialized
INFO - 2020-03-04 05:13:57 --> URI Class Initialized
DEBUG - 2020-03-04 05:13:57 --> No URI present. Default controller set.
INFO - 2020-03-04 05:13:57 --> Router Class Initialized
INFO - 2020-03-04 05:13:57 --> Output Class Initialized
INFO - 2020-03-04 05:13:57 --> Security Class Initialized
DEBUG - 2020-03-04 05:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:13:57 --> Input Class Initialized
INFO - 2020-03-04 05:13:57 --> Language Class Initialized
INFO - 2020-03-04 05:13:57 --> Loader Class Initialized
INFO - 2020-03-04 05:13:57 --> Helper loaded: url_helper
INFO - 2020-03-04 05:13:57 --> Helper loaded: string_helper
INFO - 2020-03-04 05:13:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:13:57 --> Controller Class Initialized
INFO - 2020-03-04 05:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:13:57 --> Pagination Class Initialized
INFO - 2020-03-04 05:13:57 --> Model "M_show" initialized
INFO - 2020-03-04 05:13:57 --> Helper loaded: form_helper
INFO - 2020-03-04 05:13:57 --> Form Validation Class Initialized
INFO - 2020-03-04 05:13:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:13:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:13:57 --> Final output sent to browser
DEBUG - 2020-03-04 05:13:57 --> Total execution time: 0.0063
INFO - 2020-03-04 05:14:08 --> Config Class Initialized
INFO - 2020-03-04 05:14:08 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:14:08 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:14:08 --> Utf8 Class Initialized
INFO - 2020-03-04 05:14:08 --> URI Class Initialized
DEBUG - 2020-03-04 05:14:08 --> No URI present. Default controller set.
INFO - 2020-03-04 05:14:08 --> Router Class Initialized
INFO - 2020-03-04 05:14:08 --> Output Class Initialized
INFO - 2020-03-04 05:14:08 --> Security Class Initialized
DEBUG - 2020-03-04 05:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:14:08 --> Input Class Initialized
INFO - 2020-03-04 05:14:08 --> Language Class Initialized
INFO - 2020-03-04 05:14:08 --> Loader Class Initialized
INFO - 2020-03-04 05:14:08 --> Helper loaded: url_helper
INFO - 2020-03-04 05:14:08 --> Helper loaded: string_helper
INFO - 2020-03-04 05:14:08 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:14:08 --> Controller Class Initialized
INFO - 2020-03-04 05:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:14:08 --> Pagination Class Initialized
INFO - 2020-03-04 05:14:08 --> Model "M_show" initialized
INFO - 2020-03-04 05:14:08 --> Helper loaded: form_helper
INFO - 2020-03-04 05:14:08 --> Form Validation Class Initialized
INFO - 2020-03-04 05:14:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:14:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:14:08 --> Final output sent to browser
DEBUG - 2020-03-04 05:14:08 --> Total execution time: 0.0064
INFO - 2020-03-04 05:14:14 --> Config Class Initialized
INFO - 2020-03-04 05:14:14 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:14:14 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:14:14 --> Utf8 Class Initialized
INFO - 2020-03-04 05:14:14 --> URI Class Initialized
DEBUG - 2020-03-04 05:14:14 --> No URI present. Default controller set.
INFO - 2020-03-04 05:14:14 --> Router Class Initialized
INFO - 2020-03-04 05:14:14 --> Output Class Initialized
INFO - 2020-03-04 05:14:14 --> Security Class Initialized
DEBUG - 2020-03-04 05:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:14:14 --> Input Class Initialized
INFO - 2020-03-04 05:14:14 --> Language Class Initialized
INFO - 2020-03-04 05:14:14 --> Loader Class Initialized
INFO - 2020-03-04 05:14:14 --> Helper loaded: url_helper
INFO - 2020-03-04 05:14:14 --> Helper loaded: string_helper
INFO - 2020-03-04 05:14:14 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:14:14 --> Controller Class Initialized
INFO - 2020-03-04 05:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:14:14 --> Pagination Class Initialized
INFO - 2020-03-04 05:14:14 --> Model "M_show" initialized
INFO - 2020-03-04 05:14:14 --> Helper loaded: form_helper
INFO - 2020-03-04 05:14:14 --> Form Validation Class Initialized
INFO - 2020-03-04 05:14:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:14:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:14:14 --> Final output sent to browser
DEBUG - 2020-03-04 05:14:14 --> Total execution time: 0.0053
INFO - 2020-03-04 05:14:19 --> Config Class Initialized
INFO - 2020-03-04 05:14:19 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:14:19 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:14:19 --> Utf8 Class Initialized
INFO - 2020-03-04 05:14:19 --> URI Class Initialized
INFO - 2020-03-04 05:14:19 --> Router Class Initialized
INFO - 2020-03-04 05:14:19 --> Output Class Initialized
INFO - 2020-03-04 05:14:19 --> Security Class Initialized
DEBUG - 2020-03-04 05:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:14:19 --> Input Class Initialized
INFO - 2020-03-04 05:14:19 --> Language Class Initialized
INFO - 2020-03-04 05:14:19 --> Loader Class Initialized
INFO - 2020-03-04 05:14:19 --> Helper loaded: url_helper
INFO - 2020-03-04 05:14:19 --> Helper loaded: string_helper
INFO - 2020-03-04 05:14:19 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:14:19 --> Controller Class Initialized
INFO - 2020-03-04 05:14:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:14:19 --> Pagination Class Initialized
INFO - 2020-03-04 05:14:19 --> Model "M_show" initialized
INFO - 2020-03-04 05:14:19 --> Helper loaded: form_helper
INFO - 2020-03-04 05:14:19 --> Form Validation Class Initialized
INFO - 2020-03-04 05:14:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:14:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 05:14:19 --> Final output sent to browser
DEBUG - 2020-03-04 05:14:19 --> Total execution time: 0.0065
INFO - 2020-03-04 05:14:25 --> Config Class Initialized
INFO - 2020-03-04 05:14:25 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:14:25 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:14:25 --> Utf8 Class Initialized
INFO - 2020-03-04 05:14:25 --> URI Class Initialized
INFO - 2020-03-04 05:14:25 --> Router Class Initialized
INFO - 2020-03-04 05:14:25 --> Output Class Initialized
INFO - 2020-03-04 05:14:25 --> Security Class Initialized
DEBUG - 2020-03-04 05:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:14:25 --> Input Class Initialized
INFO - 2020-03-04 05:14:25 --> Language Class Initialized
INFO - 2020-03-04 05:14:25 --> Loader Class Initialized
INFO - 2020-03-04 05:14:25 --> Helper loaded: url_helper
INFO - 2020-03-04 05:14:25 --> Helper loaded: string_helper
INFO - 2020-03-04 05:14:25 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:14:25 --> Controller Class Initialized
INFO - 2020-03-04 05:14:25 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:14:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:14:25 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:14:25 --> Helper loaded: form_helper
INFO - 2020-03-04 05:14:25 --> Form Validation Class Initialized
INFO - 2020-03-04 05:14:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 05:14:25 --> Final output sent to browser
DEBUG - 2020-03-04 05:14:25 --> Total execution time: 0.0082
INFO - 2020-03-04 05:14:54 --> Config Class Initialized
INFO - 2020-03-04 05:14:54 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:14:54 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:14:54 --> Utf8 Class Initialized
INFO - 2020-03-04 05:14:54 --> URI Class Initialized
DEBUG - 2020-03-04 05:14:54 --> No URI present. Default controller set.
INFO - 2020-03-04 05:14:54 --> Router Class Initialized
INFO - 2020-03-04 05:14:54 --> Output Class Initialized
INFO - 2020-03-04 05:14:54 --> Security Class Initialized
DEBUG - 2020-03-04 05:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:14:54 --> Input Class Initialized
INFO - 2020-03-04 05:14:54 --> Language Class Initialized
INFO - 2020-03-04 05:14:54 --> Loader Class Initialized
INFO - 2020-03-04 05:14:54 --> Helper loaded: url_helper
INFO - 2020-03-04 05:14:54 --> Helper loaded: string_helper
INFO - 2020-03-04 05:14:54 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:14:54 --> Controller Class Initialized
INFO - 2020-03-04 05:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:14:54 --> Pagination Class Initialized
INFO - 2020-03-04 05:14:54 --> Model "M_show" initialized
INFO - 2020-03-04 05:14:54 --> Helper loaded: form_helper
INFO - 2020-03-04 05:14:54 --> Form Validation Class Initialized
INFO - 2020-03-04 05:14:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:14:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:14:54 --> Final output sent to browser
DEBUG - 2020-03-04 05:14:54 --> Total execution time: 0.0068
INFO - 2020-03-04 05:17:46 --> Config Class Initialized
INFO - 2020-03-04 05:17:46 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:17:46 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:17:46 --> Utf8 Class Initialized
INFO - 2020-03-04 05:17:46 --> URI Class Initialized
INFO - 2020-03-04 05:17:46 --> Router Class Initialized
INFO - 2020-03-04 05:17:47 --> Output Class Initialized
INFO - 2020-03-04 05:17:47 --> Security Class Initialized
DEBUG - 2020-03-04 05:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:17:47 --> Input Class Initialized
INFO - 2020-03-04 05:17:47 --> Language Class Initialized
INFO - 2020-03-04 05:17:47 --> Loader Class Initialized
INFO - 2020-03-04 05:17:47 --> Helper loaded: url_helper
INFO - 2020-03-04 05:17:47 --> Helper loaded: string_helper
INFO - 2020-03-04 05:17:47 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:17:47 --> Controller Class Initialized
INFO - 2020-03-04 05:17:47 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:17:47 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:17:47 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:17:47 --> Helper loaded: form_helper
INFO - 2020-03-04 05:17:47 --> Form Validation Class Initialized
DEBUG - 2020-03-04 05:17:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-04 05:17:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-04 12:17:47 --> Final output sent to browser
DEBUG - 2020-03-04 12:17:47 --> Total execution time: 0.4243
INFO - 2020-03-04 05:17:52 --> Config Class Initialized
INFO - 2020-03-04 05:17:52 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:17:52 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:17:52 --> Utf8 Class Initialized
INFO - 2020-03-04 05:17:52 --> URI Class Initialized
INFO - 2020-03-04 05:17:52 --> Router Class Initialized
INFO - 2020-03-04 05:17:52 --> Output Class Initialized
INFO - 2020-03-04 05:17:52 --> Security Class Initialized
DEBUG - 2020-03-04 05:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:17:52 --> Input Class Initialized
INFO - 2020-03-04 05:17:52 --> Language Class Initialized
INFO - 2020-03-04 05:17:52 --> Loader Class Initialized
INFO - 2020-03-04 05:17:52 --> Helper loaded: url_helper
INFO - 2020-03-04 05:17:52 --> Helper loaded: string_helper
INFO - 2020-03-04 05:17:52 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:17:52 --> Controller Class Initialized
INFO - 2020-03-04 05:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:17:52 --> Pagination Class Initialized
INFO - 2020-03-04 05:17:52 --> Model "M_show" initialized
INFO - 2020-03-04 05:17:52 --> Helper loaded: form_helper
INFO - 2020-03-04 05:17:52 --> Form Validation Class Initialized
INFO - 2020-03-04 05:17:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:17:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:17:52 --> Final output sent to browser
DEBUG - 2020-03-04 05:17:52 --> Total execution time: 0.0096
INFO - 2020-03-04 05:29:58 --> Config Class Initialized
INFO - 2020-03-04 05:29:58 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:29:58 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:29:58 --> Utf8 Class Initialized
INFO - 2020-03-04 05:29:58 --> URI Class Initialized
DEBUG - 2020-03-04 05:29:58 --> No URI present. Default controller set.
INFO - 2020-03-04 05:29:58 --> Router Class Initialized
INFO - 2020-03-04 05:29:58 --> Output Class Initialized
INFO - 2020-03-04 05:29:58 --> Security Class Initialized
DEBUG - 2020-03-04 05:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:29:58 --> Input Class Initialized
INFO - 2020-03-04 05:29:58 --> Language Class Initialized
INFO - 2020-03-04 05:29:58 --> Loader Class Initialized
INFO - 2020-03-04 05:29:58 --> Helper loaded: url_helper
INFO - 2020-03-04 05:29:58 --> Helper loaded: string_helper
INFO - 2020-03-04 05:29:58 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:29:58 --> Controller Class Initialized
INFO - 2020-03-04 05:29:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:29:58 --> Pagination Class Initialized
INFO - 2020-03-04 05:29:58 --> Model "M_show" initialized
INFO - 2020-03-04 05:29:58 --> Helper loaded: form_helper
INFO - 2020-03-04 05:29:58 --> Form Validation Class Initialized
INFO - 2020-03-04 05:29:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:29:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:29:58 --> Final output sent to browser
DEBUG - 2020-03-04 05:29:58 --> Total execution time: 0.0560
INFO - 2020-03-04 05:30:32 --> Config Class Initialized
INFO - 2020-03-04 05:30:32 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:30:32 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:30:32 --> Utf8 Class Initialized
INFO - 2020-03-04 05:30:32 --> URI Class Initialized
DEBUG - 2020-03-04 05:30:32 --> No URI present. Default controller set.
INFO - 2020-03-04 05:30:32 --> Router Class Initialized
INFO - 2020-03-04 05:30:32 --> Output Class Initialized
INFO - 2020-03-04 05:30:32 --> Security Class Initialized
DEBUG - 2020-03-04 05:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:30:32 --> Input Class Initialized
INFO - 2020-03-04 05:30:32 --> Language Class Initialized
INFO - 2020-03-04 05:30:32 --> Loader Class Initialized
INFO - 2020-03-04 05:30:32 --> Helper loaded: url_helper
INFO - 2020-03-04 05:30:32 --> Helper loaded: string_helper
INFO - 2020-03-04 05:30:32 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:30:32 --> Controller Class Initialized
INFO - 2020-03-04 05:30:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:30:32 --> Pagination Class Initialized
INFO - 2020-03-04 05:30:32 --> Model "M_show" initialized
INFO - 2020-03-04 05:30:32 --> Helper loaded: form_helper
INFO - 2020-03-04 05:30:32 --> Form Validation Class Initialized
INFO - 2020-03-04 05:30:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:30:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:30:32 --> Final output sent to browser
DEBUG - 2020-03-04 05:30:32 --> Total execution time: 0.0058
INFO - 2020-03-04 05:30:41 --> Config Class Initialized
INFO - 2020-03-04 05:30:41 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:30:41 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:30:41 --> Utf8 Class Initialized
INFO - 2020-03-04 05:30:41 --> URI Class Initialized
INFO - 2020-03-04 05:30:41 --> Router Class Initialized
INFO - 2020-03-04 05:30:41 --> Output Class Initialized
INFO - 2020-03-04 05:30:41 --> Security Class Initialized
DEBUG - 2020-03-04 05:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:30:41 --> Input Class Initialized
INFO - 2020-03-04 05:30:41 --> Language Class Initialized
INFO - 2020-03-04 05:30:41 --> Loader Class Initialized
INFO - 2020-03-04 05:30:41 --> Helper loaded: url_helper
INFO - 2020-03-04 05:30:41 --> Helper loaded: string_helper
INFO - 2020-03-04 05:30:41 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:30:41 --> Controller Class Initialized
INFO - 2020-03-04 05:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:30:41 --> Pagination Class Initialized
INFO - 2020-03-04 05:30:41 --> Model "M_show" initialized
INFO - 2020-03-04 05:30:41 --> Helper loaded: form_helper
INFO - 2020-03-04 05:30:41 --> Form Validation Class Initialized
INFO - 2020-03-04 05:30:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:30:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 05:30:41 --> Final output sent to browser
DEBUG - 2020-03-04 05:30:41 --> Total execution time: 0.0103
INFO - 2020-03-04 05:30:45 --> Config Class Initialized
INFO - 2020-03-04 05:30:45 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:30:45 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:30:45 --> Utf8 Class Initialized
INFO - 2020-03-04 05:30:45 --> URI Class Initialized
INFO - 2020-03-04 05:30:45 --> Router Class Initialized
INFO - 2020-03-04 05:30:45 --> Output Class Initialized
INFO - 2020-03-04 05:30:45 --> Security Class Initialized
DEBUG - 2020-03-04 05:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:30:45 --> Input Class Initialized
INFO - 2020-03-04 05:30:45 --> Language Class Initialized
INFO - 2020-03-04 05:30:45 --> Loader Class Initialized
INFO - 2020-03-04 05:30:45 --> Helper loaded: url_helper
INFO - 2020-03-04 05:30:45 --> Helper loaded: string_helper
INFO - 2020-03-04 05:30:45 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:30:45 --> Controller Class Initialized
INFO - 2020-03-04 05:30:45 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:30:45 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:30:45 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:30:45 --> Helper loaded: form_helper
INFO - 2020-03-04 05:30:45 --> Form Validation Class Initialized
INFO - 2020-03-04 05:30:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 05:30:45 --> Final output sent to browser
DEBUG - 2020-03-04 05:30:45 --> Total execution time: 0.0105
INFO - 2020-03-04 05:30:52 --> Config Class Initialized
INFO - 2020-03-04 05:30:52 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:30:52 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:30:52 --> Utf8 Class Initialized
INFO - 2020-03-04 05:30:52 --> URI Class Initialized
INFO - 2020-03-04 05:30:52 --> Router Class Initialized
INFO - 2020-03-04 05:30:52 --> Output Class Initialized
INFO - 2020-03-04 05:30:52 --> Security Class Initialized
DEBUG - 2020-03-04 05:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:30:52 --> Input Class Initialized
INFO - 2020-03-04 05:30:52 --> Language Class Initialized
INFO - 2020-03-04 05:30:52 --> Loader Class Initialized
INFO - 2020-03-04 05:30:52 --> Helper loaded: url_helper
INFO - 2020-03-04 05:30:52 --> Helper loaded: string_helper
INFO - 2020-03-04 05:30:52 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:30:52 --> Controller Class Initialized
INFO - 2020-03-04 05:30:52 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:30:52 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:30:52 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:30:52 --> Helper loaded: form_helper
INFO - 2020-03-04 05:30:52 --> Form Validation Class Initialized
INFO - 2020-03-04 05:30:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 05:30:52 --> Final output sent to browser
DEBUG - 2020-03-04 05:30:52 --> Total execution time: 0.0076
INFO - 2020-03-04 05:32:30 --> Config Class Initialized
INFO - 2020-03-04 05:32:30 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:32:30 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:32:30 --> Utf8 Class Initialized
INFO - 2020-03-04 05:32:30 --> URI Class Initialized
INFO - 2020-03-04 05:32:30 --> Router Class Initialized
INFO - 2020-03-04 05:32:30 --> Output Class Initialized
INFO - 2020-03-04 05:32:30 --> Security Class Initialized
DEBUG - 2020-03-04 05:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:32:30 --> Input Class Initialized
INFO - 2020-03-04 05:32:30 --> Language Class Initialized
INFO - 2020-03-04 05:32:30 --> Loader Class Initialized
INFO - 2020-03-04 05:32:30 --> Helper loaded: url_helper
INFO - 2020-03-04 05:32:30 --> Helper loaded: string_helper
INFO - 2020-03-04 05:32:30 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:32:30 --> Controller Class Initialized
INFO - 2020-03-04 05:32:30 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:32:30 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:32:30 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:32:30 --> Helper loaded: form_helper
INFO - 2020-03-04 05:32:30 --> Form Validation Class Initialized
DEBUG - 2020-03-04 05:32:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-04 05:32:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-04 12:32:30 --> Final output sent to browser
DEBUG - 2020-03-04 12:32:30 --> Total execution time: 0.1665
INFO - 2020-03-04 05:32:33 --> Config Class Initialized
INFO - 2020-03-04 05:32:33 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:32:33 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:32:33 --> Utf8 Class Initialized
INFO - 2020-03-04 05:32:33 --> URI Class Initialized
INFO - 2020-03-04 05:32:33 --> Router Class Initialized
INFO - 2020-03-04 05:32:33 --> Output Class Initialized
INFO - 2020-03-04 05:32:33 --> Security Class Initialized
DEBUG - 2020-03-04 05:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:32:33 --> Input Class Initialized
INFO - 2020-03-04 05:32:33 --> Language Class Initialized
INFO - 2020-03-04 05:32:33 --> Loader Class Initialized
INFO - 2020-03-04 05:32:33 --> Helper loaded: url_helper
INFO - 2020-03-04 05:32:33 --> Helper loaded: string_helper
INFO - 2020-03-04 05:32:33 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:32:33 --> Controller Class Initialized
INFO - 2020-03-04 05:32:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:32:33 --> Pagination Class Initialized
INFO - 2020-03-04 05:32:33 --> Model "M_show" initialized
INFO - 2020-03-04 05:32:33 --> Helper loaded: form_helper
INFO - 2020-03-04 05:32:33 --> Form Validation Class Initialized
INFO - 2020-03-04 05:32:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:32:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:32:33 --> Final output sent to browser
DEBUG - 2020-03-04 05:32:33 --> Total execution time: 0.0111
INFO - 2020-03-04 05:34:11 --> Config Class Initialized
INFO - 2020-03-04 05:34:11 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:34:11 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:34:11 --> Utf8 Class Initialized
INFO - 2020-03-04 05:34:11 --> URI Class Initialized
DEBUG - 2020-03-04 05:34:11 --> No URI present. Default controller set.
INFO - 2020-03-04 05:34:11 --> Router Class Initialized
INFO - 2020-03-04 05:34:11 --> Output Class Initialized
INFO - 2020-03-04 05:34:11 --> Security Class Initialized
DEBUG - 2020-03-04 05:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:34:11 --> Input Class Initialized
INFO - 2020-03-04 05:34:11 --> Language Class Initialized
INFO - 2020-03-04 05:34:11 --> Loader Class Initialized
INFO - 2020-03-04 05:34:11 --> Helper loaded: url_helper
INFO - 2020-03-04 05:34:11 --> Helper loaded: string_helper
INFO - 2020-03-04 05:34:11 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:34:11 --> Controller Class Initialized
INFO - 2020-03-04 05:34:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:34:11 --> Pagination Class Initialized
INFO - 2020-03-04 05:34:11 --> Model "M_show" initialized
INFO - 2020-03-04 05:34:11 --> Helper loaded: form_helper
INFO - 2020-03-04 05:34:11 --> Form Validation Class Initialized
INFO - 2020-03-04 05:34:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:34:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:34:11 --> Final output sent to browser
DEBUG - 2020-03-04 05:34:11 --> Total execution time: 0.2305
INFO - 2020-03-04 05:34:19 --> Config Class Initialized
INFO - 2020-03-04 05:34:19 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:34:19 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:34:19 --> Utf8 Class Initialized
INFO - 2020-03-04 05:34:19 --> URI Class Initialized
INFO - 2020-03-04 05:34:19 --> Router Class Initialized
INFO - 2020-03-04 05:34:19 --> Output Class Initialized
INFO - 2020-03-04 05:34:19 --> Security Class Initialized
DEBUG - 2020-03-04 05:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:34:19 --> Input Class Initialized
INFO - 2020-03-04 05:34:19 --> Language Class Initialized
INFO - 2020-03-04 05:34:19 --> Loader Class Initialized
INFO - 2020-03-04 05:34:19 --> Helper loaded: url_helper
INFO - 2020-03-04 05:34:19 --> Helper loaded: string_helper
INFO - 2020-03-04 05:34:19 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:34:19 --> Controller Class Initialized
INFO - 2020-03-04 05:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:34:19 --> Pagination Class Initialized
INFO - 2020-03-04 05:34:19 --> Model "M_show" initialized
INFO - 2020-03-04 05:34:19 --> Helper loaded: form_helper
INFO - 2020-03-04 05:34:19 --> Form Validation Class Initialized
INFO - 2020-03-04 05:34:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:34:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 05:34:19 --> Final output sent to browser
DEBUG - 2020-03-04 05:34:19 --> Total execution time: 0.1151
INFO - 2020-03-04 05:34:20 --> Config Class Initialized
INFO - 2020-03-04 05:34:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:34:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:34:20 --> Utf8 Class Initialized
INFO - 2020-03-04 05:34:20 --> URI Class Initialized
INFO - 2020-03-04 05:34:20 --> Router Class Initialized
INFO - 2020-03-04 05:34:20 --> Output Class Initialized
INFO - 2020-03-04 05:34:20 --> Security Class Initialized
DEBUG - 2020-03-04 05:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:34:20 --> Input Class Initialized
INFO - 2020-03-04 05:34:20 --> Language Class Initialized
ERROR - 2020-03-04 05:34:20 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 05:34:24 --> Config Class Initialized
INFO - 2020-03-04 05:34:24 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:34:24 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:34:24 --> Utf8 Class Initialized
INFO - 2020-03-04 05:34:24 --> URI Class Initialized
INFO - 2020-03-04 05:34:24 --> Router Class Initialized
INFO - 2020-03-04 05:34:24 --> Output Class Initialized
INFO - 2020-03-04 05:34:24 --> Security Class Initialized
DEBUG - 2020-03-04 05:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:34:24 --> Input Class Initialized
INFO - 2020-03-04 05:34:24 --> Language Class Initialized
INFO - 2020-03-04 05:34:24 --> Loader Class Initialized
INFO - 2020-03-04 05:34:24 --> Helper loaded: url_helper
INFO - 2020-03-04 05:34:24 --> Helper loaded: string_helper
INFO - 2020-03-04 05:34:24 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:34:24 --> Controller Class Initialized
INFO - 2020-03-04 05:34:24 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:34:24 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:34:24 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:34:24 --> Helper loaded: form_helper
INFO - 2020-03-04 05:34:24 --> Form Validation Class Initialized
INFO - 2020-03-04 05:34:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 05:34:24 --> Final output sent to browser
DEBUG - 2020-03-04 05:34:24 --> Total execution time: 0.0122
INFO - 2020-03-04 05:34:28 --> Config Class Initialized
INFO - 2020-03-04 05:34:28 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:34:28 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:34:28 --> Utf8 Class Initialized
INFO - 2020-03-04 05:34:28 --> URI Class Initialized
INFO - 2020-03-04 05:34:28 --> Router Class Initialized
INFO - 2020-03-04 05:34:28 --> Output Class Initialized
INFO - 2020-03-04 05:34:28 --> Security Class Initialized
DEBUG - 2020-03-04 05:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:34:28 --> Input Class Initialized
INFO - 2020-03-04 05:34:28 --> Language Class Initialized
INFO - 2020-03-04 05:34:28 --> Loader Class Initialized
INFO - 2020-03-04 05:34:28 --> Helper loaded: url_helper
INFO - 2020-03-04 05:34:28 --> Helper loaded: string_helper
INFO - 2020-03-04 05:34:28 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:34:28 --> Controller Class Initialized
INFO - 2020-03-04 05:34:28 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:34:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:34:28 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:34:28 --> Helper loaded: form_helper
INFO - 2020-03-04 05:34:28 --> Form Validation Class Initialized
INFO - 2020-03-04 05:34:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 05:34:28 --> Final output sent to browser
DEBUG - 2020-03-04 05:34:28 --> Total execution time: 0.0085
INFO - 2020-03-04 05:35:17 --> Config Class Initialized
INFO - 2020-03-04 05:35:17 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:35:17 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:35:17 --> Utf8 Class Initialized
INFO - 2020-03-04 05:35:17 --> URI Class Initialized
DEBUG - 2020-03-04 05:35:17 --> No URI present. Default controller set.
INFO - 2020-03-04 05:35:17 --> Router Class Initialized
INFO - 2020-03-04 05:35:17 --> Output Class Initialized
INFO - 2020-03-04 05:35:17 --> Security Class Initialized
DEBUG - 2020-03-04 05:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:35:17 --> Input Class Initialized
INFO - 2020-03-04 05:35:17 --> Language Class Initialized
INFO - 2020-03-04 05:35:17 --> Loader Class Initialized
INFO - 2020-03-04 05:35:17 --> Helper loaded: url_helper
INFO - 2020-03-04 05:35:17 --> Helper loaded: string_helper
INFO - 2020-03-04 05:35:17 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:35:17 --> Controller Class Initialized
INFO - 2020-03-04 05:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:35:17 --> Pagination Class Initialized
INFO - 2020-03-04 05:35:17 --> Model "M_show" initialized
INFO - 2020-03-04 05:35:17 --> Helper loaded: form_helper
INFO - 2020-03-04 05:35:17 --> Form Validation Class Initialized
INFO - 2020-03-04 05:35:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:35:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:35:17 --> Final output sent to browser
DEBUG - 2020-03-04 05:35:17 --> Total execution time: 0.0213
INFO - 2020-03-04 05:35:20 --> Config Class Initialized
INFO - 2020-03-04 05:35:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:35:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:35:20 --> Utf8 Class Initialized
INFO - 2020-03-04 05:35:20 --> URI Class Initialized
INFO - 2020-03-04 05:35:20 --> Router Class Initialized
INFO - 2020-03-04 05:35:20 --> Output Class Initialized
INFO - 2020-03-04 05:35:20 --> Security Class Initialized
DEBUG - 2020-03-04 05:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:35:20 --> Input Class Initialized
INFO - 2020-03-04 05:35:20 --> Language Class Initialized
INFO - 2020-03-04 05:35:20 --> Loader Class Initialized
INFO - 2020-03-04 05:35:20 --> Helper loaded: url_helper
INFO - 2020-03-04 05:35:20 --> Helper loaded: string_helper
INFO - 2020-03-04 05:35:20 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:35:20 --> Controller Class Initialized
INFO - 2020-03-04 05:35:20 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:35:20 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:35:20 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:35:20 --> Helper loaded: form_helper
INFO - 2020-03-04 05:35:20 --> Form Validation Class Initialized
DEBUG - 2020-03-04 05:35:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-04 05:35:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-04 05:35:20 --> Final output sent to browser
DEBUG - 2020-03-04 05:35:20 --> Total execution time: 0.0073
INFO - 2020-03-04 05:35:25 --> Config Class Initialized
INFO - 2020-03-04 05:35:25 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:35:25 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:35:25 --> Utf8 Class Initialized
INFO - 2020-03-04 05:35:25 --> URI Class Initialized
INFO - 2020-03-04 05:35:25 --> Router Class Initialized
INFO - 2020-03-04 05:35:25 --> Output Class Initialized
INFO - 2020-03-04 05:35:25 --> Security Class Initialized
DEBUG - 2020-03-04 05:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:35:25 --> Input Class Initialized
INFO - 2020-03-04 05:35:25 --> Language Class Initialized
INFO - 2020-03-04 05:35:25 --> Loader Class Initialized
INFO - 2020-03-04 05:35:25 --> Helper loaded: url_helper
INFO - 2020-03-04 05:35:25 --> Helper loaded: string_helper
INFO - 2020-03-04 05:35:25 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:35:25 --> Controller Class Initialized
INFO - 2020-03-04 05:35:25 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:35:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:35:25 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:35:25 --> Helper loaded: form_helper
INFO - 2020-03-04 05:35:25 --> Form Validation Class Initialized
INFO - 2020-03-04 05:35:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 05:35:25 --> Final output sent to browser
DEBUG - 2020-03-04 05:35:25 --> Total execution time: 0.0070
INFO - 2020-03-04 05:40:30 --> Config Class Initialized
INFO - 2020-03-04 05:40:30 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:40:30 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:40:30 --> Utf8 Class Initialized
INFO - 2020-03-04 05:40:30 --> URI Class Initialized
DEBUG - 2020-03-04 05:40:30 --> No URI present. Default controller set.
INFO - 2020-03-04 05:40:30 --> Router Class Initialized
INFO - 2020-03-04 05:40:30 --> Output Class Initialized
INFO - 2020-03-04 05:40:30 --> Security Class Initialized
DEBUG - 2020-03-04 05:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:40:30 --> Input Class Initialized
INFO - 2020-03-04 05:40:30 --> Language Class Initialized
INFO - 2020-03-04 05:40:30 --> Loader Class Initialized
INFO - 2020-03-04 05:40:30 --> Helper loaded: url_helper
INFO - 2020-03-04 05:40:30 --> Helper loaded: string_helper
INFO - 2020-03-04 05:40:30 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:40:30 --> Controller Class Initialized
INFO - 2020-03-04 05:40:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:40:30 --> Pagination Class Initialized
INFO - 2020-03-04 05:40:30 --> Model "M_show" initialized
INFO - 2020-03-04 05:40:30 --> Helper loaded: form_helper
INFO - 2020-03-04 05:40:30 --> Form Validation Class Initialized
INFO - 2020-03-04 05:40:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:40:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:40:30 --> Final output sent to browser
DEBUG - 2020-03-04 05:40:30 --> Total execution time: 0.0304
INFO - 2020-03-04 05:40:51 --> Config Class Initialized
INFO - 2020-03-04 05:40:51 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:40:51 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:40:51 --> Utf8 Class Initialized
INFO - 2020-03-04 05:40:51 --> URI Class Initialized
INFO - 2020-03-04 05:40:51 --> Router Class Initialized
INFO - 2020-03-04 05:40:51 --> Output Class Initialized
INFO - 2020-03-04 05:40:51 --> Security Class Initialized
DEBUG - 2020-03-04 05:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:40:51 --> Input Class Initialized
INFO - 2020-03-04 05:40:51 --> Language Class Initialized
INFO - 2020-03-04 05:40:51 --> Loader Class Initialized
INFO - 2020-03-04 05:40:51 --> Helper loaded: url_helper
INFO - 2020-03-04 05:40:51 --> Helper loaded: string_helper
INFO - 2020-03-04 05:40:51 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:40:51 --> Controller Class Initialized
INFO - 2020-03-04 05:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:40:51 --> Pagination Class Initialized
INFO - 2020-03-04 05:40:51 --> Model "M_show" initialized
INFO - 2020-03-04 05:40:51 --> Helper loaded: form_helper
INFO - 2020-03-04 05:40:51 --> Form Validation Class Initialized
INFO - 2020-03-04 05:40:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:40:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 05:40:51 --> Final output sent to browser
DEBUG - 2020-03-04 05:40:51 --> Total execution time: 0.0094
INFO - 2020-03-04 05:40:58 --> Config Class Initialized
INFO - 2020-03-04 05:40:58 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:40:58 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:40:58 --> Utf8 Class Initialized
INFO - 2020-03-04 05:40:58 --> URI Class Initialized
INFO - 2020-03-04 05:40:58 --> Router Class Initialized
INFO - 2020-03-04 05:40:58 --> Output Class Initialized
INFO - 2020-03-04 05:40:58 --> Security Class Initialized
DEBUG - 2020-03-04 05:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:40:58 --> Input Class Initialized
INFO - 2020-03-04 05:40:58 --> Language Class Initialized
INFO - 2020-03-04 05:40:58 --> Loader Class Initialized
INFO - 2020-03-04 05:40:58 --> Helper loaded: url_helper
INFO - 2020-03-04 05:40:58 --> Helper loaded: string_helper
INFO - 2020-03-04 05:40:58 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:40:58 --> Controller Class Initialized
INFO - 2020-03-04 05:40:58 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:40:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:40:58 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:40:58 --> Helper loaded: form_helper
INFO - 2020-03-04 05:40:58 --> Form Validation Class Initialized
INFO - 2020-03-04 05:40:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 05:40:58 --> Final output sent to browser
DEBUG - 2020-03-04 05:40:58 --> Total execution time: 0.0164
INFO - 2020-03-04 05:41:28 --> Config Class Initialized
INFO - 2020-03-04 05:41:28 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:41:28 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:41:28 --> Utf8 Class Initialized
INFO - 2020-03-04 05:41:28 --> URI Class Initialized
DEBUG - 2020-03-04 05:41:28 --> No URI present. Default controller set.
INFO - 2020-03-04 05:41:28 --> Router Class Initialized
INFO - 2020-03-04 05:41:28 --> Output Class Initialized
INFO - 2020-03-04 05:41:28 --> Security Class Initialized
DEBUG - 2020-03-04 05:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:41:28 --> Input Class Initialized
INFO - 2020-03-04 05:41:28 --> Language Class Initialized
INFO - 2020-03-04 05:41:28 --> Loader Class Initialized
INFO - 2020-03-04 05:41:28 --> Helper loaded: url_helper
INFO - 2020-03-04 05:41:28 --> Helper loaded: string_helper
INFO - 2020-03-04 05:41:28 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:41:28 --> Controller Class Initialized
INFO - 2020-03-04 05:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:41:28 --> Pagination Class Initialized
INFO - 2020-03-04 05:41:28 --> Model "M_show" initialized
INFO - 2020-03-04 05:41:28 --> Helper loaded: form_helper
INFO - 2020-03-04 05:41:28 --> Form Validation Class Initialized
INFO - 2020-03-04 05:41:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:41:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:41:28 --> Final output sent to browser
DEBUG - 2020-03-04 05:41:28 --> Total execution time: 0.0054
INFO - 2020-03-04 05:45:40 --> Config Class Initialized
INFO - 2020-03-04 05:45:40 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:45:40 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:45:40 --> Utf8 Class Initialized
INFO - 2020-03-04 05:45:40 --> URI Class Initialized
DEBUG - 2020-03-04 05:45:40 --> No URI present. Default controller set.
INFO - 2020-03-04 05:45:40 --> Router Class Initialized
INFO - 2020-03-04 05:45:40 --> Output Class Initialized
INFO - 2020-03-04 05:45:40 --> Security Class Initialized
DEBUG - 2020-03-04 05:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:45:40 --> Input Class Initialized
INFO - 2020-03-04 05:45:40 --> Language Class Initialized
INFO - 2020-03-04 05:45:40 --> Loader Class Initialized
INFO - 2020-03-04 05:45:40 --> Helper loaded: url_helper
INFO - 2020-03-04 05:45:40 --> Helper loaded: string_helper
INFO - 2020-03-04 05:45:40 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:45:40 --> Controller Class Initialized
INFO - 2020-03-04 05:45:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:45:40 --> Pagination Class Initialized
INFO - 2020-03-04 05:45:40 --> Model "M_show" initialized
INFO - 2020-03-04 05:45:40 --> Helper loaded: form_helper
INFO - 2020-03-04 05:45:40 --> Form Validation Class Initialized
INFO - 2020-03-04 05:45:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:45:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:45:40 --> Final output sent to browser
DEBUG - 2020-03-04 05:45:40 --> Total execution time: 0.0400
INFO - 2020-03-04 05:45:50 --> Config Class Initialized
INFO - 2020-03-04 05:45:50 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:45:50 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:45:50 --> Utf8 Class Initialized
INFO - 2020-03-04 05:45:50 --> URI Class Initialized
INFO - 2020-03-04 05:45:50 --> Router Class Initialized
INFO - 2020-03-04 05:45:50 --> Output Class Initialized
INFO - 2020-03-04 05:45:50 --> Security Class Initialized
DEBUG - 2020-03-04 05:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:45:50 --> Input Class Initialized
INFO - 2020-03-04 05:45:50 --> Language Class Initialized
INFO - 2020-03-04 05:45:50 --> Loader Class Initialized
INFO - 2020-03-04 05:45:50 --> Helper loaded: url_helper
INFO - 2020-03-04 05:45:50 --> Helper loaded: string_helper
INFO - 2020-03-04 05:45:50 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:45:50 --> Controller Class Initialized
INFO - 2020-03-04 05:45:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:45:50 --> Pagination Class Initialized
INFO - 2020-03-04 05:45:50 --> Model "M_show" initialized
INFO - 2020-03-04 05:45:50 --> Helper loaded: form_helper
INFO - 2020-03-04 05:45:50 --> Form Validation Class Initialized
INFO - 2020-03-04 05:45:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:45:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 05:45:50 --> Final output sent to browser
DEBUG - 2020-03-04 05:45:50 --> Total execution time: 0.0095
INFO - 2020-03-04 05:45:53 --> Config Class Initialized
INFO - 2020-03-04 05:45:53 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:45:53 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:45:53 --> Utf8 Class Initialized
INFO - 2020-03-04 05:45:53 --> URI Class Initialized
INFO - 2020-03-04 05:45:53 --> Router Class Initialized
INFO - 2020-03-04 05:45:53 --> Output Class Initialized
INFO - 2020-03-04 05:45:53 --> Security Class Initialized
DEBUG - 2020-03-04 05:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:45:53 --> Input Class Initialized
INFO - 2020-03-04 05:45:53 --> Language Class Initialized
INFO - 2020-03-04 05:45:53 --> Loader Class Initialized
INFO - 2020-03-04 05:45:53 --> Helper loaded: url_helper
INFO - 2020-03-04 05:45:53 --> Helper loaded: string_helper
INFO - 2020-03-04 05:45:53 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:45:53 --> Controller Class Initialized
INFO - 2020-03-04 05:45:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:45:53 --> Pagination Class Initialized
INFO - 2020-03-04 05:45:53 --> Model "M_show" initialized
INFO - 2020-03-04 05:45:53 --> Helper loaded: form_helper
INFO - 2020-03-04 05:45:53 --> Form Validation Class Initialized
INFO - 2020-03-04 05:45:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:45:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-04 05:45:53 --> Final output sent to browser
DEBUG - 2020-03-04 05:45:53 --> Total execution time: 0.0061
INFO - 2020-03-04 05:52:22 --> Config Class Initialized
INFO - 2020-03-04 05:52:22 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:52:22 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:52:22 --> Utf8 Class Initialized
INFO - 2020-03-04 05:52:22 --> URI Class Initialized
INFO - 2020-03-04 05:52:22 --> Router Class Initialized
INFO - 2020-03-04 05:52:22 --> Output Class Initialized
INFO - 2020-03-04 05:52:22 --> Security Class Initialized
DEBUG - 2020-03-04 05:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:52:22 --> Input Class Initialized
INFO - 2020-03-04 05:52:22 --> Language Class Initialized
INFO - 2020-03-04 05:52:22 --> Loader Class Initialized
INFO - 2020-03-04 05:52:22 --> Helper loaded: url_helper
INFO - 2020-03-04 05:52:22 --> Helper loaded: string_helper
INFO - 2020-03-04 05:52:22 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:52:22 --> Controller Class Initialized
INFO - 2020-03-04 05:52:22 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:52:22 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:52:22 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:52:22 --> Helper loaded: form_helper
INFO - 2020-03-04 05:52:22 --> Form Validation Class Initialized
INFO - 2020-03-04 05:52:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 05:52:22 --> Final output sent to browser
DEBUG - 2020-03-04 05:52:22 --> Total execution time: 0.0585
INFO - 2020-03-04 05:53:25 --> Config Class Initialized
INFO - 2020-03-04 05:53:25 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:53:25 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:53:25 --> Utf8 Class Initialized
INFO - 2020-03-04 05:53:25 --> URI Class Initialized
INFO - 2020-03-04 05:53:25 --> Router Class Initialized
INFO - 2020-03-04 05:53:25 --> Output Class Initialized
INFO - 2020-03-04 05:53:25 --> Security Class Initialized
DEBUG - 2020-03-04 05:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:53:25 --> Input Class Initialized
INFO - 2020-03-04 05:53:25 --> Language Class Initialized
INFO - 2020-03-04 05:53:25 --> Loader Class Initialized
INFO - 2020-03-04 05:53:25 --> Helper loaded: url_helper
INFO - 2020-03-04 05:53:25 --> Helper loaded: string_helper
INFO - 2020-03-04 05:53:25 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:53:25 --> Controller Class Initialized
INFO - 2020-03-04 05:53:25 --> Model "M_tiket" initialized
INFO - 2020-03-04 05:53:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 05:53:25 --> Model "M_pesan" initialized
INFO - 2020-03-04 05:53:25 --> Helper loaded: form_helper
INFO - 2020-03-04 05:53:25 --> Form Validation Class Initialized
INFO - 2020-03-04 12:53:25 --> Upload Class Initialized
INFO - 2020-03-04 05:53:26 --> Config Class Initialized
INFO - 2020-03-04 05:53:26 --> Hooks Class Initialized
DEBUG - 2020-03-04 05:53:26 --> UTF-8 Support Enabled
INFO - 2020-03-04 05:53:26 --> Utf8 Class Initialized
INFO - 2020-03-04 05:53:26 --> URI Class Initialized
INFO - 2020-03-04 05:53:26 --> Router Class Initialized
INFO - 2020-03-04 05:53:26 --> Output Class Initialized
INFO - 2020-03-04 05:53:26 --> Security Class Initialized
DEBUG - 2020-03-04 05:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 05:53:26 --> Input Class Initialized
INFO - 2020-03-04 05:53:26 --> Language Class Initialized
INFO - 2020-03-04 05:53:26 --> Loader Class Initialized
INFO - 2020-03-04 05:53:26 --> Helper loaded: url_helper
INFO - 2020-03-04 05:53:26 --> Helper loaded: string_helper
INFO - 2020-03-04 05:53:26 --> Database Driver Class Initialized
DEBUG - 2020-03-04 05:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 05:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 05:53:26 --> Controller Class Initialized
INFO - 2020-03-04 05:53:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 05:53:26 --> Pagination Class Initialized
INFO - 2020-03-04 05:53:26 --> Model "M_show" initialized
INFO - 2020-03-04 05:53:26 --> Helper loaded: form_helper
INFO - 2020-03-04 05:53:26 --> Form Validation Class Initialized
INFO - 2020-03-04 05:53:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 05:53:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 05:53:26 --> Final output sent to browser
DEBUG - 2020-03-04 05:53:26 --> Total execution time: 0.0097
INFO - 2020-03-04 06:04:32 --> Config Class Initialized
INFO - 2020-03-04 06:04:32 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:04:32 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:04:32 --> Utf8 Class Initialized
INFO - 2020-03-04 06:04:32 --> URI Class Initialized
DEBUG - 2020-03-04 06:04:32 --> No URI present. Default controller set.
INFO - 2020-03-04 06:04:32 --> Router Class Initialized
INFO - 2020-03-04 06:04:32 --> Output Class Initialized
INFO - 2020-03-04 06:04:32 --> Security Class Initialized
DEBUG - 2020-03-04 06:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:04:32 --> Input Class Initialized
INFO - 2020-03-04 06:04:32 --> Language Class Initialized
INFO - 2020-03-04 06:04:32 --> Loader Class Initialized
INFO - 2020-03-04 06:04:32 --> Helper loaded: url_helper
INFO - 2020-03-04 06:04:32 --> Helper loaded: string_helper
INFO - 2020-03-04 06:04:32 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:04:32 --> Controller Class Initialized
INFO - 2020-03-04 06:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:04:32 --> Pagination Class Initialized
INFO - 2020-03-04 06:04:32 --> Model "M_show" initialized
INFO - 2020-03-04 06:04:32 --> Helper loaded: form_helper
INFO - 2020-03-04 06:04:32 --> Form Validation Class Initialized
INFO - 2020-03-04 06:04:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:04:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 06:04:32 --> Final output sent to browser
DEBUG - 2020-03-04 06:04:32 --> Total execution time: 0.0760
INFO - 2020-03-04 06:04:32 --> Config Class Initialized
INFO - 2020-03-04 06:04:32 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:04:32 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:04:32 --> Utf8 Class Initialized
INFO - 2020-03-04 06:04:32 --> URI Class Initialized
DEBUG - 2020-03-04 06:04:32 --> No URI present. Default controller set.
INFO - 2020-03-04 06:04:32 --> Router Class Initialized
INFO - 2020-03-04 06:04:32 --> Output Class Initialized
INFO - 2020-03-04 06:04:32 --> Security Class Initialized
DEBUG - 2020-03-04 06:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:04:32 --> Input Class Initialized
INFO - 2020-03-04 06:04:32 --> Language Class Initialized
INFO - 2020-03-04 06:04:32 --> Loader Class Initialized
INFO - 2020-03-04 06:04:32 --> Helper loaded: url_helper
INFO - 2020-03-04 06:04:32 --> Helper loaded: string_helper
INFO - 2020-03-04 06:04:32 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:04:32 --> Controller Class Initialized
INFO - 2020-03-04 06:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:04:32 --> Pagination Class Initialized
INFO - 2020-03-04 06:04:32 --> Model "M_show" initialized
INFO - 2020-03-04 06:04:32 --> Helper loaded: form_helper
INFO - 2020-03-04 06:04:32 --> Form Validation Class Initialized
INFO - 2020-03-04 06:04:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:04:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 06:04:32 --> Final output sent to browser
DEBUG - 2020-03-04 06:04:32 --> Total execution time: 0.1319
INFO - 2020-03-04 06:04:36 --> Config Class Initialized
INFO - 2020-03-04 06:04:36 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:04:36 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:04:36 --> Utf8 Class Initialized
INFO - 2020-03-04 06:04:36 --> URI Class Initialized
DEBUG - 2020-03-04 06:04:36 --> No URI present. Default controller set.
INFO - 2020-03-04 06:04:36 --> Router Class Initialized
INFO - 2020-03-04 06:04:36 --> Output Class Initialized
INFO - 2020-03-04 06:04:36 --> Security Class Initialized
DEBUG - 2020-03-04 06:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:04:36 --> Input Class Initialized
INFO - 2020-03-04 06:04:36 --> Language Class Initialized
INFO - 2020-03-04 06:04:36 --> Loader Class Initialized
INFO - 2020-03-04 06:04:36 --> Helper loaded: url_helper
INFO - 2020-03-04 06:04:36 --> Helper loaded: string_helper
INFO - 2020-03-04 06:04:36 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:04:36 --> Controller Class Initialized
INFO - 2020-03-04 06:04:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:04:36 --> Pagination Class Initialized
INFO - 2020-03-04 06:04:36 --> Model "M_show" initialized
INFO - 2020-03-04 06:04:36 --> Helper loaded: form_helper
INFO - 2020-03-04 06:04:36 --> Form Validation Class Initialized
INFO - 2020-03-04 06:04:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:04:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 06:04:36 --> Final output sent to browser
DEBUG - 2020-03-04 06:04:36 --> Total execution time: 0.2001
INFO - 2020-03-04 06:04:42 --> Config Class Initialized
INFO - 2020-03-04 06:04:42 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:04:42 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:04:42 --> Utf8 Class Initialized
INFO - 2020-03-04 06:04:42 --> URI Class Initialized
INFO - 2020-03-04 06:04:42 --> Router Class Initialized
INFO - 2020-03-04 06:04:42 --> Output Class Initialized
INFO - 2020-03-04 06:04:42 --> Security Class Initialized
DEBUG - 2020-03-04 06:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:04:42 --> Input Class Initialized
INFO - 2020-03-04 06:04:42 --> Language Class Initialized
INFO - 2020-03-04 06:04:42 --> Loader Class Initialized
INFO - 2020-03-04 06:04:42 --> Helper loaded: url_helper
INFO - 2020-03-04 06:04:42 --> Helper loaded: string_helper
INFO - 2020-03-04 06:04:42 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:04:43 --> Controller Class Initialized
INFO - 2020-03-04 06:04:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:04:43 --> Pagination Class Initialized
INFO - 2020-03-04 06:04:43 --> Model "M_show" initialized
INFO - 2020-03-04 06:04:43 --> Helper loaded: form_helper
INFO - 2020-03-04 06:04:43 --> Form Validation Class Initialized
INFO - 2020-03-04 06:04:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:04:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 06:04:43 --> Final output sent to browser
DEBUG - 2020-03-04 06:04:43 --> Total execution time: 0.2236
INFO - 2020-03-04 06:04:48 --> Config Class Initialized
INFO - 2020-03-04 06:04:48 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:04:48 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:04:48 --> Utf8 Class Initialized
INFO - 2020-03-04 06:04:48 --> URI Class Initialized
INFO - 2020-03-04 06:04:48 --> Router Class Initialized
INFO - 2020-03-04 06:04:48 --> Output Class Initialized
INFO - 2020-03-04 06:04:48 --> Security Class Initialized
DEBUG - 2020-03-04 06:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:04:48 --> Input Class Initialized
INFO - 2020-03-04 06:04:48 --> Language Class Initialized
INFO - 2020-03-04 06:04:48 --> Loader Class Initialized
INFO - 2020-03-04 06:04:48 --> Helper loaded: url_helper
INFO - 2020-03-04 06:04:48 --> Helper loaded: string_helper
INFO - 2020-03-04 06:04:48 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:04:48 --> Controller Class Initialized
INFO - 2020-03-04 06:04:48 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:04:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:04:48 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:04:48 --> Helper loaded: form_helper
INFO - 2020-03-04 06:04:48 --> Form Validation Class Initialized
INFO - 2020-03-04 06:04:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 06:04:48 --> Final output sent to browser
DEBUG - 2020-03-04 06:04:48 --> Total execution time: 0.0131
INFO - 2020-03-04 06:04:57 --> Config Class Initialized
INFO - 2020-03-04 06:04:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:04:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:04:57 --> Utf8 Class Initialized
INFO - 2020-03-04 06:04:57 --> URI Class Initialized
INFO - 2020-03-04 06:04:57 --> Router Class Initialized
INFO - 2020-03-04 06:04:57 --> Output Class Initialized
INFO - 2020-03-04 06:04:57 --> Security Class Initialized
DEBUG - 2020-03-04 06:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:04:57 --> Input Class Initialized
INFO - 2020-03-04 06:04:57 --> Language Class Initialized
INFO - 2020-03-04 06:04:57 --> Loader Class Initialized
INFO - 2020-03-04 06:04:57 --> Helper loaded: url_helper
INFO - 2020-03-04 06:04:57 --> Helper loaded: string_helper
INFO - 2020-03-04 06:04:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:04:57 --> Controller Class Initialized
INFO - 2020-03-04 06:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:04:57 --> Pagination Class Initialized
INFO - 2020-03-04 06:04:57 --> Model "M_show" initialized
INFO - 2020-03-04 06:04:57 --> Helper loaded: form_helper
INFO - 2020-03-04 06:04:57 --> Form Validation Class Initialized
INFO - 2020-03-04 06:04:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:04:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 06:04:57 --> Final output sent to browser
DEBUG - 2020-03-04 06:04:57 --> Total execution time: 0.4195
INFO - 2020-03-04 06:07:56 --> Config Class Initialized
INFO - 2020-03-04 06:07:56 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:07:56 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:07:56 --> Utf8 Class Initialized
INFO - 2020-03-04 06:07:56 --> URI Class Initialized
INFO - 2020-03-04 06:07:56 --> Router Class Initialized
INFO - 2020-03-04 06:07:56 --> Output Class Initialized
INFO - 2020-03-04 06:07:56 --> Security Class Initialized
DEBUG - 2020-03-04 06:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:07:56 --> Input Class Initialized
INFO - 2020-03-04 06:07:56 --> Language Class Initialized
INFO - 2020-03-04 06:07:56 --> Loader Class Initialized
INFO - 2020-03-04 06:07:56 --> Helper loaded: url_helper
INFO - 2020-03-04 06:07:56 --> Helper loaded: string_helper
INFO - 2020-03-04 06:07:56 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:07:56 --> Controller Class Initialized
INFO - 2020-03-04 06:07:56 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:07:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:07:56 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:07:56 --> Helper loaded: form_helper
INFO - 2020-03-04 06:07:56 --> Form Validation Class Initialized
INFO - 2020-03-04 06:07:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 06:07:56 --> Final output sent to browser
DEBUG - 2020-03-04 06:07:56 --> Total execution time: 0.1012
INFO - 2020-03-04 06:11:58 --> Config Class Initialized
INFO - 2020-03-04 06:11:58 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:11:58 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:11:58 --> Utf8 Class Initialized
INFO - 2020-03-04 06:11:58 --> URI Class Initialized
INFO - 2020-03-04 06:11:58 --> Router Class Initialized
INFO - 2020-03-04 06:11:58 --> Output Class Initialized
INFO - 2020-03-04 06:11:58 --> Security Class Initialized
DEBUG - 2020-03-04 06:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:11:58 --> Input Class Initialized
INFO - 2020-03-04 06:11:58 --> Language Class Initialized
INFO - 2020-03-04 06:11:58 --> Loader Class Initialized
INFO - 2020-03-04 06:11:58 --> Helper loaded: url_helper
INFO - 2020-03-04 06:11:58 --> Helper loaded: string_helper
INFO - 2020-03-04 06:11:58 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:11:58 --> Controller Class Initialized
INFO - 2020-03-04 06:11:58 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:11:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:11:58 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:11:58 --> Helper loaded: form_helper
INFO - 2020-03-04 06:11:58 --> Form Validation Class Initialized
INFO - 2020-03-04 06:11:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 06:11:58 --> Final output sent to browser
DEBUG - 2020-03-04 06:11:58 --> Total execution time: 0.1000
INFO - 2020-03-04 06:17:17 --> Config Class Initialized
INFO - 2020-03-04 06:17:17 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:17:17 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:17:17 --> Utf8 Class Initialized
INFO - 2020-03-04 06:17:17 --> URI Class Initialized
INFO - 2020-03-04 06:17:17 --> Router Class Initialized
INFO - 2020-03-04 06:17:17 --> Output Class Initialized
INFO - 2020-03-04 06:17:17 --> Security Class Initialized
DEBUG - 2020-03-04 06:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:17:17 --> Input Class Initialized
INFO - 2020-03-04 06:17:17 --> Language Class Initialized
INFO - 2020-03-04 06:17:17 --> Loader Class Initialized
INFO - 2020-03-04 06:17:17 --> Helper loaded: url_helper
INFO - 2020-03-04 06:17:17 --> Helper loaded: string_helper
INFO - 2020-03-04 06:17:17 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:17:17 --> Controller Class Initialized
INFO - 2020-03-04 06:17:17 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:17:17 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:17:17 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:17:17 --> Helper loaded: form_helper
INFO - 2020-03-04 06:17:17 --> Form Validation Class Initialized
INFO - 2020-03-04 06:17:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 06:17:17 --> Final output sent to browser
DEBUG - 2020-03-04 06:17:17 --> Total execution time: 0.0528
INFO - 2020-03-04 06:24:14 --> Config Class Initialized
INFO - 2020-03-04 06:24:14 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:24:14 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:24:14 --> Utf8 Class Initialized
INFO - 2020-03-04 06:24:14 --> URI Class Initialized
INFO - 2020-03-04 06:24:14 --> Router Class Initialized
INFO - 2020-03-04 06:24:14 --> Output Class Initialized
INFO - 2020-03-04 06:24:14 --> Security Class Initialized
DEBUG - 2020-03-04 06:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:24:14 --> Input Class Initialized
INFO - 2020-03-04 06:24:14 --> Language Class Initialized
INFO - 2020-03-04 06:24:14 --> Loader Class Initialized
INFO - 2020-03-04 06:24:14 --> Helper loaded: url_helper
INFO - 2020-03-04 06:24:14 --> Helper loaded: string_helper
INFO - 2020-03-04 06:24:14 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:24:14 --> Controller Class Initialized
INFO - 2020-03-04 06:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:24:14 --> Pagination Class Initialized
INFO - 2020-03-04 06:24:14 --> Model "M_show" initialized
INFO - 2020-03-04 06:24:14 --> Helper loaded: form_helper
INFO - 2020-03-04 06:24:14 --> Form Validation Class Initialized
INFO - 2020-03-04 06:24:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:24:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 06:24:14 --> Final output sent to browser
DEBUG - 2020-03-04 06:24:14 --> Total execution time: 0.0309
INFO - 2020-03-04 06:45:19 --> Config Class Initialized
INFO - 2020-03-04 06:45:19 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:45:19 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:45:19 --> Utf8 Class Initialized
INFO - 2020-03-04 06:45:19 --> URI Class Initialized
INFO - 2020-03-04 06:45:19 --> Router Class Initialized
INFO - 2020-03-04 06:45:19 --> Output Class Initialized
INFO - 2020-03-04 06:45:19 --> Security Class Initialized
DEBUG - 2020-03-04 06:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:45:19 --> Input Class Initialized
INFO - 2020-03-04 06:45:19 --> Language Class Initialized
INFO - 2020-03-04 06:45:19 --> Loader Class Initialized
INFO - 2020-03-04 06:45:19 --> Helper loaded: url_helper
INFO - 2020-03-04 06:45:19 --> Helper loaded: string_helper
INFO - 2020-03-04 06:45:19 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:45:19 --> Controller Class Initialized
INFO - 2020-03-04 06:45:19 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:45:19 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:45:19 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:45:19 --> Helper loaded: form_helper
INFO - 2020-03-04 06:45:19 --> Form Validation Class Initialized
INFO - 2020-03-04 06:45:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 06:45:19 --> Final output sent to browser
DEBUG - 2020-03-04 06:45:19 --> Total execution time: 0.0372
INFO - 2020-03-04 06:45:37 --> Config Class Initialized
INFO - 2020-03-04 06:45:37 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:45:37 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:45:37 --> Utf8 Class Initialized
INFO - 2020-03-04 06:45:37 --> URI Class Initialized
INFO - 2020-03-04 06:45:37 --> Router Class Initialized
INFO - 2020-03-04 06:45:37 --> Output Class Initialized
INFO - 2020-03-04 06:45:37 --> Security Class Initialized
DEBUG - 2020-03-04 06:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:45:37 --> Input Class Initialized
INFO - 2020-03-04 06:45:37 --> Language Class Initialized
INFO - 2020-03-04 06:45:37 --> Loader Class Initialized
INFO - 2020-03-04 06:45:37 --> Helper loaded: url_helper
INFO - 2020-03-04 06:45:37 --> Helper loaded: string_helper
INFO - 2020-03-04 06:45:37 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:45:37 --> Controller Class Initialized
INFO - 2020-03-04 06:45:37 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:45:37 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:45:37 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:45:37 --> Helper loaded: form_helper
INFO - 2020-03-04 06:45:37 --> Form Validation Class Initialized
INFO - 2020-03-04 06:45:42 --> Config Class Initialized
INFO - 2020-03-04 06:45:42 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:45:42 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:45:42 --> Utf8 Class Initialized
INFO - 2020-03-04 06:45:42 --> URI Class Initialized
INFO - 2020-03-04 06:45:42 --> Router Class Initialized
INFO - 2020-03-04 06:45:42 --> Output Class Initialized
INFO - 2020-03-04 06:45:42 --> Security Class Initialized
DEBUG - 2020-03-04 06:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:45:42 --> Input Class Initialized
INFO - 2020-03-04 06:45:42 --> Language Class Initialized
INFO - 2020-03-04 06:45:42 --> Loader Class Initialized
INFO - 2020-03-04 06:45:42 --> Helper loaded: url_helper
INFO - 2020-03-04 06:45:42 --> Helper loaded: string_helper
INFO - 2020-03-04 06:45:42 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:45:42 --> Controller Class Initialized
INFO - 2020-03-04 06:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:45:42 --> Pagination Class Initialized
INFO - 2020-03-04 06:45:42 --> Model "M_show" initialized
INFO - 2020-03-04 06:45:42 --> Helper loaded: form_helper
INFO - 2020-03-04 06:45:42 --> Form Validation Class Initialized
INFO - 2020-03-04 06:45:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:45:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 06:45:42 --> Final output sent to browser
DEBUG - 2020-03-04 06:45:42 --> Total execution time: 0.0112
INFO - 2020-03-04 06:45:54 --> Config Class Initialized
INFO - 2020-03-04 06:45:54 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:45:54 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:45:54 --> Utf8 Class Initialized
INFO - 2020-03-04 06:45:54 --> URI Class Initialized
INFO - 2020-03-04 06:45:54 --> Router Class Initialized
INFO - 2020-03-04 06:45:54 --> Output Class Initialized
INFO - 2020-03-04 06:45:54 --> Security Class Initialized
DEBUG - 2020-03-04 06:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:45:54 --> Input Class Initialized
INFO - 2020-03-04 06:45:54 --> Language Class Initialized
INFO - 2020-03-04 06:45:54 --> Loader Class Initialized
INFO - 2020-03-04 06:45:54 --> Helper loaded: url_helper
INFO - 2020-03-04 06:45:54 --> Helper loaded: string_helper
INFO - 2020-03-04 06:45:54 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:45:54 --> Controller Class Initialized
INFO - 2020-03-04 06:45:54 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:45:54 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:45:54 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:45:54 --> Helper loaded: form_helper
INFO - 2020-03-04 06:45:54 --> Form Validation Class Initialized
INFO - 2020-03-04 06:45:55 --> Config Class Initialized
INFO - 2020-03-04 06:45:55 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:45:55 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:45:55 --> Utf8 Class Initialized
INFO - 2020-03-04 06:45:55 --> URI Class Initialized
INFO - 2020-03-04 06:45:55 --> Router Class Initialized
INFO - 2020-03-04 06:45:55 --> Output Class Initialized
INFO - 2020-03-04 06:45:55 --> Security Class Initialized
DEBUG - 2020-03-04 06:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:45:55 --> Input Class Initialized
INFO - 2020-03-04 06:45:55 --> Language Class Initialized
INFO - 2020-03-04 06:45:55 --> Loader Class Initialized
INFO - 2020-03-04 06:45:55 --> Helper loaded: url_helper
INFO - 2020-03-04 06:45:55 --> Helper loaded: string_helper
INFO - 2020-03-04 06:45:55 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:45:55 --> Controller Class Initialized
INFO - 2020-03-04 06:45:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:45:55 --> Pagination Class Initialized
INFO - 2020-03-04 06:45:55 --> Model "M_show" initialized
INFO - 2020-03-04 06:45:55 --> Helper loaded: form_helper
INFO - 2020-03-04 06:45:55 --> Form Validation Class Initialized
INFO - 2020-03-04 06:45:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:45:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 06:45:55 --> Final output sent to browser
DEBUG - 2020-03-04 06:45:55 --> Total execution time: 0.0054
INFO - 2020-03-04 06:46:26 --> Config Class Initialized
INFO - 2020-03-04 06:46:26 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:46:26 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:46:26 --> Utf8 Class Initialized
INFO - 2020-03-04 06:46:26 --> URI Class Initialized
INFO - 2020-03-04 06:46:26 --> Router Class Initialized
INFO - 2020-03-04 06:46:26 --> Output Class Initialized
INFO - 2020-03-04 06:46:26 --> Security Class Initialized
DEBUG - 2020-03-04 06:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:46:26 --> Input Class Initialized
INFO - 2020-03-04 06:46:26 --> Language Class Initialized
INFO - 2020-03-04 06:46:26 --> Loader Class Initialized
INFO - 2020-03-04 06:46:26 --> Helper loaded: url_helper
INFO - 2020-03-04 06:46:26 --> Helper loaded: string_helper
INFO - 2020-03-04 06:46:26 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:46:26 --> Controller Class Initialized
INFO - 2020-03-04 06:46:26 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:46:26 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:46:26 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:46:26 --> Helper loaded: form_helper
INFO - 2020-03-04 06:46:26 --> Form Validation Class Initialized
INFO - 2020-03-04 06:46:27 --> Config Class Initialized
INFO - 2020-03-04 06:46:27 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:46:27 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:46:27 --> Utf8 Class Initialized
INFO - 2020-03-04 06:46:27 --> URI Class Initialized
INFO - 2020-03-04 06:46:27 --> Router Class Initialized
INFO - 2020-03-04 06:46:27 --> Output Class Initialized
INFO - 2020-03-04 06:46:27 --> Security Class Initialized
DEBUG - 2020-03-04 06:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:46:27 --> Input Class Initialized
INFO - 2020-03-04 06:46:27 --> Language Class Initialized
INFO - 2020-03-04 06:46:27 --> Loader Class Initialized
INFO - 2020-03-04 06:46:27 --> Helper loaded: url_helper
INFO - 2020-03-04 06:46:27 --> Helper loaded: string_helper
INFO - 2020-03-04 06:46:27 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:46:27 --> Controller Class Initialized
INFO - 2020-03-04 06:46:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:46:27 --> Pagination Class Initialized
INFO - 2020-03-04 06:46:27 --> Model "M_show" initialized
INFO - 2020-03-04 06:46:27 --> Helper loaded: form_helper
INFO - 2020-03-04 06:46:27 --> Form Validation Class Initialized
INFO - 2020-03-04 06:46:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:46:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 06:46:27 --> Final output sent to browser
DEBUG - 2020-03-04 06:46:27 --> Total execution time: 0.0073
INFO - 2020-03-04 06:47:21 --> Config Class Initialized
INFO - 2020-03-04 06:47:21 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:47:21 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:47:21 --> Utf8 Class Initialized
INFO - 2020-03-04 06:47:21 --> URI Class Initialized
INFO - 2020-03-04 06:47:21 --> Router Class Initialized
INFO - 2020-03-04 06:47:21 --> Output Class Initialized
INFO - 2020-03-04 06:47:21 --> Security Class Initialized
DEBUG - 2020-03-04 06:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:47:21 --> Input Class Initialized
INFO - 2020-03-04 06:47:21 --> Language Class Initialized
INFO - 2020-03-04 06:47:21 --> Loader Class Initialized
INFO - 2020-03-04 06:47:21 --> Helper loaded: url_helper
INFO - 2020-03-04 06:47:21 --> Helper loaded: string_helper
INFO - 2020-03-04 06:47:21 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:47:21 --> Controller Class Initialized
INFO - 2020-03-04 06:47:21 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:47:21 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:47:21 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:47:21 --> Helper loaded: form_helper
INFO - 2020-03-04 06:47:21 --> Form Validation Class Initialized
INFO - 2020-03-04 06:47:22 --> Config Class Initialized
INFO - 2020-03-04 06:47:22 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:47:22 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:47:22 --> Utf8 Class Initialized
INFO - 2020-03-04 06:47:22 --> URI Class Initialized
INFO - 2020-03-04 06:47:22 --> Router Class Initialized
INFO - 2020-03-04 06:47:22 --> Output Class Initialized
INFO - 2020-03-04 06:47:22 --> Security Class Initialized
DEBUG - 2020-03-04 06:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:47:22 --> Input Class Initialized
INFO - 2020-03-04 06:47:22 --> Language Class Initialized
INFO - 2020-03-04 06:47:22 --> Loader Class Initialized
INFO - 2020-03-04 06:47:22 --> Helper loaded: url_helper
INFO - 2020-03-04 06:47:22 --> Helper loaded: string_helper
INFO - 2020-03-04 06:47:22 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:47:22 --> Controller Class Initialized
INFO - 2020-03-04 06:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:47:22 --> Pagination Class Initialized
INFO - 2020-03-04 06:47:22 --> Model "M_show" initialized
INFO - 2020-03-04 06:47:22 --> Helper loaded: form_helper
INFO - 2020-03-04 06:47:22 --> Form Validation Class Initialized
INFO - 2020-03-04 06:47:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:47:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 06:47:22 --> Final output sent to browser
DEBUG - 2020-03-04 06:47:22 --> Total execution time: 0.0057
INFO - 2020-03-04 06:48:28 --> Config Class Initialized
INFO - 2020-03-04 06:48:28 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:48:28 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:48:28 --> Utf8 Class Initialized
INFO - 2020-03-04 06:48:28 --> URI Class Initialized
INFO - 2020-03-04 06:48:28 --> Router Class Initialized
INFO - 2020-03-04 06:48:28 --> Output Class Initialized
INFO - 2020-03-04 06:48:28 --> Security Class Initialized
DEBUG - 2020-03-04 06:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:48:28 --> Input Class Initialized
INFO - 2020-03-04 06:48:28 --> Language Class Initialized
INFO - 2020-03-04 06:48:28 --> Loader Class Initialized
INFO - 2020-03-04 06:48:28 --> Helper loaded: url_helper
INFO - 2020-03-04 06:48:28 --> Helper loaded: string_helper
INFO - 2020-03-04 06:48:28 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:48:28 --> Controller Class Initialized
INFO - 2020-03-04 06:48:28 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:48:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:48:28 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:48:28 --> Helper loaded: form_helper
INFO - 2020-03-04 06:48:28 --> Form Validation Class Initialized
INFO - 2020-03-04 06:48:29 --> Config Class Initialized
INFO - 2020-03-04 06:48:29 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:48:29 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:48:29 --> Utf8 Class Initialized
INFO - 2020-03-04 06:48:29 --> URI Class Initialized
INFO - 2020-03-04 06:48:29 --> Router Class Initialized
INFO - 2020-03-04 06:48:29 --> Output Class Initialized
INFO - 2020-03-04 06:48:29 --> Security Class Initialized
DEBUG - 2020-03-04 06:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:48:29 --> Input Class Initialized
INFO - 2020-03-04 06:48:29 --> Language Class Initialized
INFO - 2020-03-04 06:48:29 --> Loader Class Initialized
INFO - 2020-03-04 06:48:29 --> Helper loaded: url_helper
INFO - 2020-03-04 06:48:29 --> Helper loaded: string_helper
INFO - 2020-03-04 06:48:29 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:48:29 --> Controller Class Initialized
INFO - 2020-03-04 06:48:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:48:29 --> Pagination Class Initialized
INFO - 2020-03-04 06:48:29 --> Model "M_show" initialized
INFO - 2020-03-04 06:48:29 --> Helper loaded: form_helper
INFO - 2020-03-04 06:48:29 --> Form Validation Class Initialized
INFO - 2020-03-04 06:48:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:48:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 06:48:29 --> Final output sent to browser
DEBUG - 2020-03-04 06:48:29 --> Total execution time: 0.0052
INFO - 2020-03-04 06:48:29 --> Config Class Initialized
INFO - 2020-03-04 06:48:29 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:48:29 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:48:29 --> Utf8 Class Initialized
INFO - 2020-03-04 06:48:29 --> URI Class Initialized
INFO - 2020-03-04 06:48:29 --> Router Class Initialized
INFO - 2020-03-04 06:48:29 --> Output Class Initialized
INFO - 2020-03-04 06:48:29 --> Security Class Initialized
DEBUG - 2020-03-04 06:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:48:29 --> Input Class Initialized
INFO - 2020-03-04 06:48:29 --> Language Class Initialized
ERROR - 2020-03-04 06:48:29 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 06:49:11 --> Config Class Initialized
INFO - 2020-03-04 06:49:11 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:49:11 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:49:11 --> Utf8 Class Initialized
INFO - 2020-03-04 06:49:11 --> URI Class Initialized
INFO - 2020-03-04 06:49:11 --> Router Class Initialized
INFO - 2020-03-04 06:49:11 --> Output Class Initialized
INFO - 2020-03-04 06:49:11 --> Security Class Initialized
DEBUG - 2020-03-04 06:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:49:11 --> Input Class Initialized
INFO - 2020-03-04 06:49:11 --> Language Class Initialized
INFO - 2020-03-04 06:49:11 --> Loader Class Initialized
INFO - 2020-03-04 06:49:11 --> Helper loaded: url_helper
INFO - 2020-03-04 06:49:11 --> Helper loaded: string_helper
INFO - 2020-03-04 06:49:11 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:49:11 --> Controller Class Initialized
INFO - 2020-03-04 06:49:11 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:49:11 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:49:11 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:49:11 --> Helper loaded: form_helper
INFO - 2020-03-04 06:49:11 --> Form Validation Class Initialized
INFO - 2020-03-04 06:49:13 --> Config Class Initialized
INFO - 2020-03-04 06:49:13 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:49:13 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:49:13 --> Utf8 Class Initialized
INFO - 2020-03-04 06:49:13 --> URI Class Initialized
INFO - 2020-03-04 06:49:13 --> Router Class Initialized
INFO - 2020-03-04 06:49:13 --> Output Class Initialized
INFO - 2020-03-04 06:49:13 --> Security Class Initialized
DEBUG - 2020-03-04 06:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:49:13 --> Input Class Initialized
INFO - 2020-03-04 06:49:13 --> Language Class Initialized
INFO - 2020-03-04 06:49:13 --> Loader Class Initialized
INFO - 2020-03-04 06:49:13 --> Helper loaded: url_helper
INFO - 2020-03-04 06:49:13 --> Helper loaded: string_helper
INFO - 2020-03-04 06:49:13 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:49:13 --> Controller Class Initialized
INFO - 2020-03-04 06:49:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:49:13 --> Pagination Class Initialized
INFO - 2020-03-04 06:49:13 --> Model "M_show" initialized
INFO - 2020-03-04 06:49:13 --> Helper loaded: form_helper
INFO - 2020-03-04 06:49:13 --> Form Validation Class Initialized
INFO - 2020-03-04 06:49:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:49:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 06:49:13 --> Final output sent to browser
DEBUG - 2020-03-04 06:49:13 --> Total execution time: 0.0058
INFO - 2020-03-04 06:49:24 --> Config Class Initialized
INFO - 2020-03-04 06:49:24 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:49:24 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:49:24 --> Utf8 Class Initialized
INFO - 2020-03-04 06:49:24 --> URI Class Initialized
INFO - 2020-03-04 06:49:24 --> Router Class Initialized
INFO - 2020-03-04 06:49:24 --> Output Class Initialized
INFO - 2020-03-04 06:49:24 --> Security Class Initialized
DEBUG - 2020-03-04 06:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:49:24 --> Input Class Initialized
INFO - 2020-03-04 06:49:24 --> Language Class Initialized
INFO - 2020-03-04 06:49:24 --> Loader Class Initialized
INFO - 2020-03-04 06:49:24 --> Helper loaded: url_helper
INFO - 2020-03-04 06:49:24 --> Helper loaded: string_helper
INFO - 2020-03-04 06:49:24 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:49:24 --> Controller Class Initialized
INFO - 2020-03-04 06:49:24 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:49:24 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:49:24 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:49:24 --> Helper loaded: form_helper
INFO - 2020-03-04 06:49:24 --> Form Validation Class Initialized
INFO - 2020-03-04 06:49:25 --> Config Class Initialized
INFO - 2020-03-04 06:49:25 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:49:25 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:49:25 --> Utf8 Class Initialized
INFO - 2020-03-04 06:49:25 --> URI Class Initialized
INFO - 2020-03-04 06:49:25 --> Router Class Initialized
INFO - 2020-03-04 06:49:25 --> Output Class Initialized
INFO - 2020-03-04 06:49:25 --> Security Class Initialized
DEBUG - 2020-03-04 06:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:49:25 --> Input Class Initialized
INFO - 2020-03-04 06:49:25 --> Language Class Initialized
INFO - 2020-03-04 06:49:25 --> Loader Class Initialized
INFO - 2020-03-04 06:49:25 --> Helper loaded: url_helper
INFO - 2020-03-04 06:49:25 --> Helper loaded: string_helper
INFO - 2020-03-04 06:49:25 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:49:25 --> Controller Class Initialized
INFO - 2020-03-04 06:49:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:49:25 --> Pagination Class Initialized
INFO - 2020-03-04 06:49:25 --> Model "M_show" initialized
INFO - 2020-03-04 06:49:25 --> Helper loaded: form_helper
INFO - 2020-03-04 06:49:25 --> Form Validation Class Initialized
INFO - 2020-03-04 06:49:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:49:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 06:49:25 --> Final output sent to browser
DEBUG - 2020-03-04 06:49:25 --> Total execution time: 0.0065
INFO - 2020-03-04 06:55:53 --> Config Class Initialized
INFO - 2020-03-04 06:55:53 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:55:53 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:55:53 --> Utf8 Class Initialized
INFO - 2020-03-04 06:55:53 --> URI Class Initialized
INFO - 2020-03-04 06:55:53 --> Router Class Initialized
INFO - 2020-03-04 06:55:53 --> Output Class Initialized
INFO - 2020-03-04 06:55:53 --> Security Class Initialized
DEBUG - 2020-03-04 06:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:55:53 --> Input Class Initialized
INFO - 2020-03-04 06:55:53 --> Language Class Initialized
INFO - 2020-03-04 06:55:53 --> Loader Class Initialized
INFO - 2020-03-04 06:55:53 --> Helper loaded: url_helper
INFO - 2020-03-04 06:55:53 --> Helper loaded: string_helper
INFO - 2020-03-04 06:55:53 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:55:53 --> Controller Class Initialized
INFO - 2020-03-04 06:55:53 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:55:53 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:55:53 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:55:53 --> Helper loaded: form_helper
INFO - 2020-03-04 06:55:53 --> Form Validation Class Initialized
INFO - 2020-03-04 06:55:53 --> Config Class Initialized
INFO - 2020-03-04 06:55:53 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:55:53 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:55:53 --> Utf8 Class Initialized
INFO - 2020-03-04 06:55:53 --> URI Class Initialized
INFO - 2020-03-04 06:55:53 --> Router Class Initialized
INFO - 2020-03-04 06:55:53 --> Output Class Initialized
INFO - 2020-03-04 06:55:53 --> Security Class Initialized
DEBUG - 2020-03-04 06:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:55:53 --> Input Class Initialized
INFO - 2020-03-04 06:55:53 --> Language Class Initialized
INFO - 2020-03-04 06:55:53 --> Loader Class Initialized
INFO - 2020-03-04 06:55:53 --> Helper loaded: url_helper
INFO - 2020-03-04 06:55:53 --> Helper loaded: string_helper
INFO - 2020-03-04 06:55:53 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:55:53 --> Controller Class Initialized
INFO - 2020-03-04 06:55:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:55:53 --> Pagination Class Initialized
INFO - 2020-03-04 06:55:53 --> Model "M_show" initialized
INFO - 2020-03-04 06:55:53 --> Helper loaded: form_helper
INFO - 2020-03-04 06:55:53 --> Form Validation Class Initialized
INFO - 2020-03-04 06:55:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:55:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 06:55:53 --> Final output sent to browser
DEBUG - 2020-03-04 06:55:53 --> Total execution time: 0.0058
INFO - 2020-03-04 06:55:54 --> Config Class Initialized
INFO - 2020-03-04 06:55:54 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:55:54 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:55:54 --> Utf8 Class Initialized
INFO - 2020-03-04 06:55:54 --> URI Class Initialized
INFO - 2020-03-04 06:55:54 --> Router Class Initialized
INFO - 2020-03-04 06:55:54 --> Output Class Initialized
INFO - 2020-03-04 06:55:54 --> Security Class Initialized
DEBUG - 2020-03-04 06:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:55:54 --> Input Class Initialized
INFO - 2020-03-04 06:55:54 --> Language Class Initialized
ERROR - 2020-03-04 06:55:54 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 06:56:34 --> Config Class Initialized
INFO - 2020-03-04 06:56:34 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:56:34 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:56:34 --> Utf8 Class Initialized
INFO - 2020-03-04 06:56:34 --> URI Class Initialized
INFO - 2020-03-04 06:56:34 --> Router Class Initialized
INFO - 2020-03-04 06:56:34 --> Output Class Initialized
INFO - 2020-03-04 06:56:34 --> Security Class Initialized
DEBUG - 2020-03-04 06:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:56:34 --> Input Class Initialized
INFO - 2020-03-04 06:56:34 --> Language Class Initialized
INFO - 2020-03-04 06:56:34 --> Loader Class Initialized
INFO - 2020-03-04 06:56:34 --> Helper loaded: url_helper
INFO - 2020-03-04 06:56:34 --> Helper loaded: string_helper
INFO - 2020-03-04 06:56:34 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:56:34 --> Controller Class Initialized
INFO - 2020-03-04 06:56:34 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:56:34 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:56:34 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:56:34 --> Helper loaded: form_helper
INFO - 2020-03-04 06:56:34 --> Form Validation Class Initialized
INFO - 2020-03-04 06:56:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 06:56:34 --> Final output sent to browser
DEBUG - 2020-03-04 06:56:34 --> Total execution time: 0.0097
INFO - 2020-03-04 06:56:59 --> Config Class Initialized
INFO - 2020-03-04 06:56:59 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:56:59 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:56:59 --> Utf8 Class Initialized
INFO - 2020-03-04 06:56:59 --> URI Class Initialized
INFO - 2020-03-04 06:56:59 --> Router Class Initialized
INFO - 2020-03-04 06:56:59 --> Output Class Initialized
INFO - 2020-03-04 06:56:59 --> Security Class Initialized
DEBUG - 2020-03-04 06:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:56:59 --> Input Class Initialized
INFO - 2020-03-04 06:56:59 --> Language Class Initialized
INFO - 2020-03-04 06:56:59 --> Loader Class Initialized
INFO - 2020-03-04 06:56:59 --> Helper loaded: url_helper
INFO - 2020-03-04 06:56:59 --> Helper loaded: string_helper
INFO - 2020-03-04 06:56:59 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:56:59 --> Controller Class Initialized
INFO - 2020-03-04 06:56:59 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:56:59 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:56:59 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:56:59 --> Helper loaded: form_helper
INFO - 2020-03-04 06:56:59 --> Form Validation Class Initialized
INFO - 2020-03-04 06:57:01 --> Config Class Initialized
INFO - 2020-03-04 06:57:01 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:57:01 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:57:01 --> Utf8 Class Initialized
INFO - 2020-03-04 06:57:01 --> URI Class Initialized
INFO - 2020-03-04 06:57:01 --> Router Class Initialized
INFO - 2020-03-04 06:57:01 --> Output Class Initialized
INFO - 2020-03-04 06:57:01 --> Security Class Initialized
DEBUG - 2020-03-04 06:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:57:01 --> Input Class Initialized
INFO - 2020-03-04 06:57:01 --> Language Class Initialized
INFO - 2020-03-04 06:57:01 --> Loader Class Initialized
INFO - 2020-03-04 06:57:01 --> Helper loaded: url_helper
INFO - 2020-03-04 06:57:01 --> Helper loaded: string_helper
INFO - 2020-03-04 06:57:01 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:57:01 --> Controller Class Initialized
INFO - 2020-03-04 06:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 06:57:01 --> Pagination Class Initialized
INFO - 2020-03-04 06:57:01 --> Model "M_show" initialized
INFO - 2020-03-04 06:57:01 --> Helper loaded: form_helper
INFO - 2020-03-04 06:57:01 --> Form Validation Class Initialized
INFO - 2020-03-04 06:57:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 06:57:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 06:57:01 --> Final output sent to browser
DEBUG - 2020-03-04 06:57:01 --> Total execution time: 0.0058
INFO - 2020-03-04 06:57:35 --> Config Class Initialized
INFO - 2020-03-04 06:57:35 --> Hooks Class Initialized
DEBUG - 2020-03-04 06:57:35 --> UTF-8 Support Enabled
INFO - 2020-03-04 06:57:35 --> Utf8 Class Initialized
INFO - 2020-03-04 06:57:35 --> URI Class Initialized
INFO - 2020-03-04 06:57:35 --> Router Class Initialized
INFO - 2020-03-04 06:57:35 --> Output Class Initialized
INFO - 2020-03-04 06:57:35 --> Security Class Initialized
DEBUG - 2020-03-04 06:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 06:57:35 --> Input Class Initialized
INFO - 2020-03-04 06:57:35 --> Language Class Initialized
INFO - 2020-03-04 06:57:35 --> Loader Class Initialized
INFO - 2020-03-04 06:57:35 --> Helper loaded: url_helper
INFO - 2020-03-04 06:57:35 --> Helper loaded: string_helper
INFO - 2020-03-04 06:57:35 --> Database Driver Class Initialized
DEBUG - 2020-03-04 06:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 06:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 06:57:35 --> Controller Class Initialized
INFO - 2020-03-04 06:57:35 --> Model "M_tiket" initialized
INFO - 2020-03-04 06:57:35 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 06:57:35 --> Model "M_pesan" initialized
INFO - 2020-03-04 06:57:35 --> Helper loaded: form_helper
INFO - 2020-03-04 06:57:35 --> Form Validation Class Initialized
INFO - 2020-03-04 06:57:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 06:57:35 --> Final output sent to browser
DEBUG - 2020-03-04 06:57:35 --> Total execution time: 0.0120
INFO - 2020-03-04 07:00:03 --> Config Class Initialized
INFO - 2020-03-04 07:00:03 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:00:03 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:00:03 --> Utf8 Class Initialized
INFO - 2020-03-04 07:00:03 --> URI Class Initialized
INFO - 2020-03-04 07:00:03 --> Router Class Initialized
INFO - 2020-03-04 07:00:03 --> Output Class Initialized
INFO - 2020-03-04 07:00:03 --> Security Class Initialized
DEBUG - 2020-03-04 07:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:00:03 --> Input Class Initialized
INFO - 2020-03-04 07:00:03 --> Language Class Initialized
INFO - 2020-03-04 07:00:03 --> Loader Class Initialized
INFO - 2020-03-04 07:00:03 --> Helper loaded: url_helper
INFO - 2020-03-04 07:00:03 --> Helper loaded: string_helper
INFO - 2020-03-04 07:00:03 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:00:03 --> Controller Class Initialized
INFO - 2020-03-04 07:00:03 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:00:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:00:03 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:00:03 --> Helper loaded: form_helper
INFO - 2020-03-04 07:00:03 --> Form Validation Class Initialized
INFO - 2020-03-04 07:00:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 07:00:03 --> Final output sent to browser
DEBUG - 2020-03-04 07:00:03 --> Total execution time: 0.0582
INFO - 2020-03-04 07:00:59 --> Config Class Initialized
INFO - 2020-03-04 07:00:59 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:00:59 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:00:59 --> Utf8 Class Initialized
INFO - 2020-03-04 07:00:59 --> URI Class Initialized
INFO - 2020-03-04 07:00:59 --> Router Class Initialized
INFO - 2020-03-04 07:00:59 --> Output Class Initialized
INFO - 2020-03-04 07:00:59 --> Security Class Initialized
DEBUG - 2020-03-04 07:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:00:59 --> Input Class Initialized
INFO - 2020-03-04 07:00:59 --> Language Class Initialized
INFO - 2020-03-04 07:00:59 --> Loader Class Initialized
INFO - 2020-03-04 07:00:59 --> Helper loaded: url_helper
INFO - 2020-03-04 07:00:59 --> Helper loaded: string_helper
INFO - 2020-03-04 07:00:59 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:00:59 --> Controller Class Initialized
INFO - 2020-03-04 07:00:59 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:00:59 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:00:59 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:00:59 --> Helper loaded: form_helper
INFO - 2020-03-04 07:00:59 --> Form Validation Class Initialized
INFO - 2020-03-04 07:00:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 07:00:59 --> Final output sent to browser
DEBUG - 2020-03-04 07:00:59 --> Total execution time: 0.0139
INFO - 2020-03-04 07:01:14 --> Config Class Initialized
INFO - 2020-03-04 07:01:14 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:01:14 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:01:14 --> Utf8 Class Initialized
INFO - 2020-03-04 07:01:14 --> URI Class Initialized
INFO - 2020-03-04 07:01:14 --> Router Class Initialized
INFO - 2020-03-04 07:01:14 --> Output Class Initialized
INFO - 2020-03-04 07:01:14 --> Security Class Initialized
DEBUG - 2020-03-04 07:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:01:14 --> Input Class Initialized
INFO - 2020-03-04 07:01:14 --> Language Class Initialized
INFO - 2020-03-04 07:01:14 --> Loader Class Initialized
INFO - 2020-03-04 07:01:14 --> Helper loaded: url_helper
INFO - 2020-03-04 07:01:14 --> Helper loaded: string_helper
INFO - 2020-03-04 07:01:14 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:01:14 --> Controller Class Initialized
INFO - 2020-03-04 07:01:14 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:01:14 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:01:14 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:01:14 --> Helper loaded: form_helper
INFO - 2020-03-04 07:01:14 --> Form Validation Class Initialized
INFO - 2020-03-04 07:01:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 07:01:14 --> Final output sent to browser
DEBUG - 2020-03-04 07:01:14 --> Total execution time: 0.0191
INFO - 2020-03-04 07:01:36 --> Config Class Initialized
INFO - 2020-03-04 07:01:36 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:01:36 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:01:36 --> Utf8 Class Initialized
INFO - 2020-03-04 07:01:36 --> URI Class Initialized
INFO - 2020-03-04 07:01:36 --> Router Class Initialized
INFO - 2020-03-04 07:01:36 --> Output Class Initialized
INFO - 2020-03-04 07:01:36 --> Security Class Initialized
DEBUG - 2020-03-04 07:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:01:36 --> Input Class Initialized
INFO - 2020-03-04 07:01:36 --> Language Class Initialized
INFO - 2020-03-04 07:01:36 --> Loader Class Initialized
INFO - 2020-03-04 07:01:36 --> Helper loaded: url_helper
INFO - 2020-03-04 07:01:36 --> Helper loaded: string_helper
INFO - 2020-03-04 07:01:36 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:01:36 --> Controller Class Initialized
INFO - 2020-03-04 07:01:36 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:01:36 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:01:36 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:01:36 --> Helper loaded: form_helper
INFO - 2020-03-04 07:01:36 --> Form Validation Class Initialized
INFO - 2020-03-04 14:01:36 --> Upload Class Initialized
INFO - 2020-03-04 07:01:37 --> Config Class Initialized
INFO - 2020-03-04 07:01:37 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:01:37 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:01:37 --> Utf8 Class Initialized
INFO - 2020-03-04 07:01:37 --> URI Class Initialized
INFO - 2020-03-04 07:01:37 --> Router Class Initialized
INFO - 2020-03-04 07:01:37 --> Output Class Initialized
INFO - 2020-03-04 07:01:37 --> Security Class Initialized
DEBUG - 2020-03-04 07:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:01:37 --> Input Class Initialized
INFO - 2020-03-04 07:01:37 --> Language Class Initialized
INFO - 2020-03-04 07:01:37 --> Loader Class Initialized
INFO - 2020-03-04 07:01:37 --> Helper loaded: url_helper
INFO - 2020-03-04 07:01:37 --> Helper loaded: string_helper
INFO - 2020-03-04 07:01:37 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:01:37 --> Controller Class Initialized
INFO - 2020-03-04 07:01:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:01:37 --> Pagination Class Initialized
INFO - 2020-03-04 07:01:37 --> Model "M_show" initialized
INFO - 2020-03-04 07:01:37 --> Helper loaded: form_helper
INFO - 2020-03-04 07:01:37 --> Form Validation Class Initialized
INFO - 2020-03-04 07:01:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:01:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:01:37 --> Final output sent to browser
DEBUG - 2020-03-04 07:01:37 --> Total execution time: 0.0071
INFO - 2020-03-04 07:03:06 --> Config Class Initialized
INFO - 2020-03-04 07:03:06 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:03:06 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:03:06 --> Utf8 Class Initialized
INFO - 2020-03-04 07:03:06 --> URI Class Initialized
INFO - 2020-03-04 07:03:06 --> Router Class Initialized
INFO - 2020-03-04 07:03:06 --> Output Class Initialized
INFO - 2020-03-04 07:03:06 --> Security Class Initialized
DEBUG - 2020-03-04 07:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:03:07 --> Input Class Initialized
INFO - 2020-03-04 07:03:07 --> Language Class Initialized
INFO - 2020-03-04 07:03:07 --> Loader Class Initialized
INFO - 2020-03-04 07:03:07 --> Helper loaded: url_helper
INFO - 2020-03-04 07:03:07 --> Helper loaded: string_helper
INFO - 2020-03-04 07:03:07 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:03:07 --> Controller Class Initialized
INFO - 2020-03-04 07:03:07 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:03:07 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:03:07 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:03:07 --> Helper loaded: form_helper
INFO - 2020-03-04 07:03:07 --> Form Validation Class Initialized
INFO - 2020-03-04 07:03:07 --> Config Class Initialized
INFO - 2020-03-04 07:03:07 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:03:07 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:03:07 --> Utf8 Class Initialized
INFO - 2020-03-04 07:03:07 --> URI Class Initialized
INFO - 2020-03-04 07:03:07 --> Router Class Initialized
INFO - 2020-03-04 07:03:07 --> Output Class Initialized
INFO - 2020-03-04 07:03:07 --> Security Class Initialized
DEBUG - 2020-03-04 07:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:03:07 --> Input Class Initialized
INFO - 2020-03-04 07:03:07 --> Language Class Initialized
INFO - 2020-03-04 07:03:07 --> Loader Class Initialized
INFO - 2020-03-04 07:03:07 --> Helper loaded: url_helper
INFO - 2020-03-04 07:03:07 --> Helper loaded: string_helper
INFO - 2020-03-04 07:03:07 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:03:07 --> Controller Class Initialized
INFO - 2020-03-04 07:03:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:03:07 --> Pagination Class Initialized
INFO - 2020-03-04 07:03:07 --> Model "M_show" initialized
INFO - 2020-03-04 07:03:07 --> Helper loaded: form_helper
INFO - 2020-03-04 07:03:07 --> Form Validation Class Initialized
INFO - 2020-03-04 07:03:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:03:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:03:07 --> Final output sent to browser
DEBUG - 2020-03-04 07:03:07 --> Total execution time: 0.0076
INFO - 2020-03-04 07:03:08 --> Config Class Initialized
INFO - 2020-03-04 07:03:08 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:03:08 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:03:08 --> Utf8 Class Initialized
INFO - 2020-03-04 07:03:08 --> URI Class Initialized
INFO - 2020-03-04 07:03:08 --> Router Class Initialized
INFO - 2020-03-04 07:03:08 --> Output Class Initialized
INFO - 2020-03-04 07:03:08 --> Security Class Initialized
DEBUG - 2020-03-04 07:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:03:08 --> Input Class Initialized
INFO - 2020-03-04 07:03:08 --> Language Class Initialized
ERROR - 2020-03-04 07:03:08 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 07:04:11 --> Config Class Initialized
INFO - 2020-03-04 07:04:11 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:04:11 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:04:11 --> Utf8 Class Initialized
INFO - 2020-03-04 07:04:11 --> URI Class Initialized
DEBUG - 2020-03-04 07:04:11 --> No URI present. Default controller set.
INFO - 2020-03-04 07:04:11 --> Router Class Initialized
INFO - 2020-03-04 07:04:11 --> Output Class Initialized
INFO - 2020-03-04 07:04:11 --> Security Class Initialized
DEBUG - 2020-03-04 07:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:04:11 --> Input Class Initialized
INFO - 2020-03-04 07:04:11 --> Language Class Initialized
INFO - 2020-03-04 07:04:11 --> Loader Class Initialized
INFO - 2020-03-04 07:04:11 --> Helper loaded: url_helper
INFO - 2020-03-04 07:04:11 --> Helper loaded: string_helper
INFO - 2020-03-04 07:04:11 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:04:11 --> Controller Class Initialized
INFO - 2020-03-04 07:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:04:11 --> Pagination Class Initialized
INFO - 2020-03-04 07:04:11 --> Model "M_show" initialized
INFO - 2020-03-04 07:04:11 --> Helper loaded: form_helper
INFO - 2020-03-04 07:04:11 --> Form Validation Class Initialized
INFO - 2020-03-04 07:04:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:04:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:04:11 --> Final output sent to browser
DEBUG - 2020-03-04 07:04:11 --> Total execution time: 0.0075
INFO - 2020-03-04 07:04:35 --> Config Class Initialized
INFO - 2020-03-04 07:04:35 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:04:35 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:04:35 --> Utf8 Class Initialized
INFO - 2020-03-04 07:04:35 --> URI Class Initialized
INFO - 2020-03-04 07:04:35 --> Router Class Initialized
INFO - 2020-03-04 07:04:35 --> Output Class Initialized
INFO - 2020-03-04 07:04:35 --> Security Class Initialized
DEBUG - 2020-03-04 07:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:04:35 --> Input Class Initialized
INFO - 2020-03-04 07:04:35 --> Language Class Initialized
INFO - 2020-03-04 07:04:35 --> Loader Class Initialized
INFO - 2020-03-04 07:04:35 --> Helper loaded: url_helper
INFO - 2020-03-04 07:04:35 --> Helper loaded: string_helper
INFO - 2020-03-04 07:04:35 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:04:35 --> Controller Class Initialized
INFO - 2020-03-04 07:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:04:35 --> Pagination Class Initialized
INFO - 2020-03-04 07:04:35 --> Model "M_show" initialized
INFO - 2020-03-04 07:04:35 --> Helper loaded: form_helper
INFO - 2020-03-04 07:04:35 --> Form Validation Class Initialized
INFO - 2020-03-04 07:04:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:04:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 07:04:35 --> Final output sent to browser
DEBUG - 2020-03-04 07:04:35 --> Total execution time: 0.0096
INFO - 2020-03-04 07:04:36 --> Config Class Initialized
INFO - 2020-03-04 07:04:36 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:04:36 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:04:36 --> Utf8 Class Initialized
INFO - 2020-03-04 07:04:36 --> URI Class Initialized
INFO - 2020-03-04 07:04:36 --> Router Class Initialized
INFO - 2020-03-04 07:04:36 --> Output Class Initialized
INFO - 2020-03-04 07:04:36 --> Security Class Initialized
DEBUG - 2020-03-04 07:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:04:36 --> Input Class Initialized
INFO - 2020-03-04 07:04:36 --> Language Class Initialized
ERROR - 2020-03-04 07:04:36 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 07:04:37 --> Config Class Initialized
INFO - 2020-03-04 07:04:37 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:04:37 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:04:37 --> Utf8 Class Initialized
INFO - 2020-03-04 07:04:37 --> URI Class Initialized
INFO - 2020-03-04 07:04:37 --> Router Class Initialized
INFO - 2020-03-04 07:04:37 --> Output Class Initialized
INFO - 2020-03-04 07:04:37 --> Security Class Initialized
DEBUG - 2020-03-04 07:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:04:37 --> Input Class Initialized
INFO - 2020-03-04 07:04:37 --> Language Class Initialized
INFO - 2020-03-04 07:04:37 --> Loader Class Initialized
INFO - 2020-03-04 07:04:37 --> Helper loaded: url_helper
INFO - 2020-03-04 07:04:37 --> Helper loaded: string_helper
INFO - 2020-03-04 07:04:37 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:04:37 --> Controller Class Initialized
INFO - 2020-03-04 07:04:37 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:04:37 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:04:37 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:04:37 --> Helper loaded: form_helper
INFO - 2020-03-04 07:04:37 --> Form Validation Class Initialized
INFO - 2020-03-04 07:04:37 --> Config Class Initialized
INFO - 2020-03-04 07:04:37 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:04:37 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:04:37 --> Utf8 Class Initialized
INFO - 2020-03-04 07:04:37 --> URI Class Initialized
INFO - 2020-03-04 07:04:37 --> Router Class Initialized
INFO - 2020-03-04 07:04:37 --> Output Class Initialized
INFO - 2020-03-04 07:04:37 --> Security Class Initialized
DEBUG - 2020-03-04 07:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:04:37 --> Input Class Initialized
INFO - 2020-03-04 07:04:37 --> Language Class Initialized
INFO - 2020-03-04 07:04:37 --> Loader Class Initialized
INFO - 2020-03-04 07:04:37 --> Helper loaded: url_helper
INFO - 2020-03-04 07:04:37 --> Helper loaded: string_helper
INFO - 2020-03-04 07:04:37 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:04:37 --> Controller Class Initialized
INFO - 2020-03-04 07:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:04:37 --> Pagination Class Initialized
INFO - 2020-03-04 07:04:37 --> Model "M_show" initialized
INFO - 2020-03-04 07:04:37 --> Helper loaded: form_helper
INFO - 2020-03-04 07:04:37 --> Form Validation Class Initialized
INFO - 2020-03-04 07:04:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:04:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:04:37 --> Final output sent to browser
DEBUG - 2020-03-04 07:04:37 --> Total execution time: 0.0056
INFO - 2020-03-04 07:04:40 --> Config Class Initialized
INFO - 2020-03-04 07:04:40 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:04:40 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:04:40 --> Utf8 Class Initialized
INFO - 2020-03-04 07:04:40 --> URI Class Initialized
INFO - 2020-03-04 07:04:40 --> Router Class Initialized
INFO - 2020-03-04 07:04:40 --> Output Class Initialized
INFO - 2020-03-04 07:04:40 --> Security Class Initialized
DEBUG - 2020-03-04 07:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:04:40 --> Input Class Initialized
INFO - 2020-03-04 07:04:40 --> Language Class Initialized
INFO - 2020-03-04 07:04:40 --> Loader Class Initialized
INFO - 2020-03-04 07:04:40 --> Helper loaded: url_helper
INFO - 2020-03-04 07:04:40 --> Helper loaded: string_helper
INFO - 2020-03-04 07:04:40 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:04:40 --> Controller Class Initialized
INFO - 2020-03-04 07:04:40 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:04:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:04:40 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:04:40 --> Helper loaded: form_helper
INFO - 2020-03-04 07:04:40 --> Form Validation Class Initialized
INFO - 2020-03-04 07:04:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 07:04:40 --> Final output sent to browser
DEBUG - 2020-03-04 07:04:40 --> Total execution time: 0.0082
INFO - 2020-03-04 07:05:04 --> Config Class Initialized
INFO - 2020-03-04 07:05:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:05:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:05:04 --> Utf8 Class Initialized
INFO - 2020-03-04 07:05:04 --> URI Class Initialized
INFO - 2020-03-04 07:05:04 --> Router Class Initialized
INFO - 2020-03-04 07:05:04 --> Output Class Initialized
INFO - 2020-03-04 07:05:04 --> Security Class Initialized
DEBUG - 2020-03-04 07:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:05:04 --> Input Class Initialized
INFO - 2020-03-04 07:05:04 --> Language Class Initialized
INFO - 2020-03-04 07:05:04 --> Loader Class Initialized
INFO - 2020-03-04 07:05:04 --> Helper loaded: url_helper
INFO - 2020-03-04 07:05:04 --> Helper loaded: string_helper
INFO - 2020-03-04 07:05:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:05:04 --> Controller Class Initialized
INFO - 2020-03-04 07:05:04 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:05:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:05:04 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:05:04 --> Helper loaded: form_helper
INFO - 2020-03-04 07:05:04 --> Form Validation Class Initialized
INFO - 2020-03-04 07:05:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 07:05:04 --> Final output sent to browser
DEBUG - 2020-03-04 07:05:04 --> Total execution time: 0.0137
INFO - 2020-03-04 07:06:08 --> Config Class Initialized
INFO - 2020-03-04 07:06:08 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:06:08 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:06:08 --> Utf8 Class Initialized
INFO - 2020-03-04 07:06:08 --> URI Class Initialized
DEBUG - 2020-03-04 07:06:08 --> No URI present. Default controller set.
INFO - 2020-03-04 07:06:08 --> Router Class Initialized
INFO - 2020-03-04 07:06:08 --> Output Class Initialized
INFO - 2020-03-04 07:06:08 --> Security Class Initialized
DEBUG - 2020-03-04 07:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:06:08 --> Input Class Initialized
INFO - 2020-03-04 07:06:08 --> Language Class Initialized
INFO - 2020-03-04 07:06:08 --> Loader Class Initialized
INFO - 2020-03-04 07:06:08 --> Helper loaded: url_helper
INFO - 2020-03-04 07:06:08 --> Helper loaded: string_helper
INFO - 2020-03-04 07:06:08 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:06:08 --> Controller Class Initialized
INFO - 2020-03-04 07:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:06:08 --> Pagination Class Initialized
INFO - 2020-03-04 07:06:08 --> Model "M_show" initialized
INFO - 2020-03-04 07:06:08 --> Helper loaded: form_helper
INFO - 2020-03-04 07:06:08 --> Form Validation Class Initialized
INFO - 2020-03-04 07:06:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:06:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:06:08 --> Final output sent to browser
DEBUG - 2020-03-04 07:06:08 --> Total execution time: 0.0055
INFO - 2020-03-04 07:08:17 --> Config Class Initialized
INFO - 2020-03-04 07:08:17 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:08:17 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:08:17 --> Utf8 Class Initialized
INFO - 2020-03-04 07:08:17 --> URI Class Initialized
INFO - 2020-03-04 07:08:17 --> Router Class Initialized
INFO - 2020-03-04 07:08:17 --> Output Class Initialized
INFO - 2020-03-04 07:08:17 --> Security Class Initialized
DEBUG - 2020-03-04 07:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:08:17 --> Input Class Initialized
INFO - 2020-03-04 07:08:17 --> Language Class Initialized
INFO - 2020-03-04 07:08:17 --> Loader Class Initialized
INFO - 2020-03-04 07:08:17 --> Helper loaded: url_helper
INFO - 2020-03-04 07:08:17 --> Helper loaded: string_helper
INFO - 2020-03-04 07:08:17 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:08:17 --> Controller Class Initialized
INFO - 2020-03-04 07:08:17 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:08:17 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:08:17 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:08:17 --> Helper loaded: form_helper
INFO - 2020-03-04 07:08:17 --> Form Validation Class Initialized
DEBUG - 2020-03-04 07:08:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-04 07:08:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-04 14:08:17 --> Final output sent to browser
DEBUG - 2020-03-04 14:08:17 --> Total execution time: 0.1745
INFO - 2020-03-04 07:08:21 --> Config Class Initialized
INFO - 2020-03-04 07:08:21 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:08:21 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:08:21 --> Utf8 Class Initialized
INFO - 2020-03-04 07:08:21 --> URI Class Initialized
INFO - 2020-03-04 07:08:21 --> Router Class Initialized
INFO - 2020-03-04 07:08:21 --> Output Class Initialized
INFO - 2020-03-04 07:08:21 --> Security Class Initialized
DEBUG - 2020-03-04 07:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:08:21 --> Input Class Initialized
INFO - 2020-03-04 07:08:21 --> Language Class Initialized
INFO - 2020-03-04 07:08:21 --> Loader Class Initialized
INFO - 2020-03-04 07:08:21 --> Helper loaded: url_helper
INFO - 2020-03-04 07:08:21 --> Helper loaded: string_helper
INFO - 2020-03-04 07:08:21 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:08:21 --> Controller Class Initialized
INFO - 2020-03-04 07:08:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:08:21 --> Pagination Class Initialized
INFO - 2020-03-04 07:08:21 --> Model "M_show" initialized
INFO - 2020-03-04 07:08:21 --> Helper loaded: form_helper
INFO - 2020-03-04 07:08:21 --> Form Validation Class Initialized
INFO - 2020-03-04 07:08:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:08:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:08:21 --> Final output sent to browser
DEBUG - 2020-03-04 07:08:21 --> Total execution time: 0.0095
INFO - 2020-03-04 07:08:22 --> Config Class Initialized
INFO - 2020-03-04 07:08:22 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:08:22 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:08:22 --> Utf8 Class Initialized
INFO - 2020-03-04 07:08:22 --> URI Class Initialized
INFO - 2020-03-04 07:08:22 --> Router Class Initialized
INFO - 2020-03-04 07:08:22 --> Output Class Initialized
INFO - 2020-03-04 07:08:22 --> Security Class Initialized
DEBUG - 2020-03-04 07:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:08:22 --> Input Class Initialized
INFO - 2020-03-04 07:08:22 --> Language Class Initialized
ERROR - 2020-03-04 07:08:22 --> 404 Page Not Found: Engine0/jquery.js
INFO - 2020-03-04 07:09:59 --> Config Class Initialized
INFO - 2020-03-04 07:09:59 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:09:59 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:09:59 --> Utf8 Class Initialized
INFO - 2020-03-04 07:09:59 --> URI Class Initialized
INFO - 2020-03-04 07:09:59 --> Router Class Initialized
INFO - 2020-03-04 07:09:59 --> Output Class Initialized
INFO - 2020-03-04 07:09:59 --> Security Class Initialized
DEBUG - 2020-03-04 07:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:09:59 --> Input Class Initialized
INFO - 2020-03-04 07:09:59 --> Language Class Initialized
INFO - 2020-03-04 07:09:59 --> Loader Class Initialized
INFO - 2020-03-04 07:09:59 --> Helper loaded: url_helper
INFO - 2020-03-04 07:09:59 --> Helper loaded: string_helper
INFO - 2020-03-04 07:09:59 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:09:59 --> Controller Class Initialized
INFO - 2020-03-04 07:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:09:59 --> Pagination Class Initialized
INFO - 2020-03-04 07:09:59 --> Model "M_show" initialized
INFO - 2020-03-04 07:09:59 --> Helper loaded: form_helper
INFO - 2020-03-04 07:09:59 --> Form Validation Class Initialized
INFO - 2020-03-04 07:09:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:09:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:09:59 --> Final output sent to browser
DEBUG - 2020-03-04 07:09:59 --> Total execution time: 0.0297
INFO - 2020-03-04 07:10:13 --> Config Class Initialized
INFO - 2020-03-04 07:10:13 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:10:13 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:10:13 --> Utf8 Class Initialized
INFO - 2020-03-04 07:10:13 --> URI Class Initialized
INFO - 2020-03-04 07:10:13 --> Router Class Initialized
INFO - 2020-03-04 07:10:13 --> Output Class Initialized
INFO - 2020-03-04 07:10:13 --> Security Class Initialized
DEBUG - 2020-03-04 07:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:10:13 --> Input Class Initialized
INFO - 2020-03-04 07:10:13 --> Language Class Initialized
INFO - 2020-03-04 07:10:13 --> Loader Class Initialized
INFO - 2020-03-04 07:10:13 --> Helper loaded: url_helper
INFO - 2020-03-04 07:10:13 --> Helper loaded: string_helper
INFO - 2020-03-04 07:10:13 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:10:13 --> Controller Class Initialized
INFO - 2020-03-04 07:10:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:10:13 --> Pagination Class Initialized
INFO - 2020-03-04 07:10:13 --> Model "M_show" initialized
INFO - 2020-03-04 07:10:13 --> Helper loaded: form_helper
INFO - 2020-03-04 07:10:13 --> Form Validation Class Initialized
INFO - 2020-03-04 07:10:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:10:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 07:10:13 --> Final output sent to browser
DEBUG - 2020-03-04 07:10:13 --> Total execution time: 0.0081
INFO - 2020-03-04 07:10:14 --> Config Class Initialized
INFO - 2020-03-04 07:10:14 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:10:14 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:10:14 --> Utf8 Class Initialized
INFO - 2020-03-04 07:10:14 --> URI Class Initialized
INFO - 2020-03-04 07:10:14 --> Router Class Initialized
INFO - 2020-03-04 07:10:14 --> Output Class Initialized
INFO - 2020-03-04 07:10:14 --> Security Class Initialized
DEBUG - 2020-03-04 07:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:10:14 --> Input Class Initialized
INFO - 2020-03-04 07:10:14 --> Language Class Initialized
ERROR - 2020-03-04 07:10:14 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 07:10:37 --> Config Class Initialized
INFO - 2020-03-04 07:10:37 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:10:37 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:10:37 --> Utf8 Class Initialized
INFO - 2020-03-04 07:10:37 --> URI Class Initialized
INFO - 2020-03-04 07:10:37 --> Router Class Initialized
INFO - 2020-03-04 07:10:37 --> Output Class Initialized
INFO - 2020-03-04 07:10:37 --> Security Class Initialized
DEBUG - 2020-03-04 07:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:10:37 --> Input Class Initialized
INFO - 2020-03-04 07:10:37 --> Language Class Initialized
INFO - 2020-03-04 07:10:37 --> Loader Class Initialized
INFO - 2020-03-04 07:10:37 --> Helper loaded: url_helper
INFO - 2020-03-04 07:10:37 --> Helper loaded: string_helper
INFO - 2020-03-04 07:10:37 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:10:37 --> Controller Class Initialized
INFO - 2020-03-04 07:10:37 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:10:37 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:10:37 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:10:37 --> Helper loaded: form_helper
INFO - 2020-03-04 07:10:37 --> Form Validation Class Initialized
INFO - 2020-03-04 07:10:38 --> Config Class Initialized
INFO - 2020-03-04 07:10:38 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:10:38 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:10:38 --> Utf8 Class Initialized
INFO - 2020-03-04 07:10:38 --> URI Class Initialized
INFO - 2020-03-04 07:10:38 --> Router Class Initialized
INFO - 2020-03-04 07:10:38 --> Output Class Initialized
INFO - 2020-03-04 07:10:38 --> Security Class Initialized
DEBUG - 2020-03-04 07:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:10:38 --> Input Class Initialized
INFO - 2020-03-04 07:10:38 --> Language Class Initialized
INFO - 2020-03-04 07:10:38 --> Loader Class Initialized
INFO - 2020-03-04 07:10:38 --> Helper loaded: url_helper
INFO - 2020-03-04 07:10:38 --> Helper loaded: string_helper
INFO - 2020-03-04 07:10:38 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:10:38 --> Controller Class Initialized
INFO - 2020-03-04 07:10:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:10:38 --> Pagination Class Initialized
INFO - 2020-03-04 07:10:38 --> Model "M_show" initialized
INFO - 2020-03-04 07:10:38 --> Helper loaded: form_helper
INFO - 2020-03-04 07:10:38 --> Form Validation Class Initialized
INFO - 2020-03-04 07:10:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:10:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:10:38 --> Final output sent to browser
DEBUG - 2020-03-04 07:10:38 --> Total execution time: 0.0086
INFO - 2020-03-04 07:10:38 --> Config Class Initialized
INFO - 2020-03-04 07:10:38 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:10:38 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:10:38 --> Utf8 Class Initialized
INFO - 2020-03-04 07:10:38 --> URI Class Initialized
INFO - 2020-03-04 07:10:38 --> Router Class Initialized
INFO - 2020-03-04 07:10:38 --> Output Class Initialized
INFO - 2020-03-04 07:10:38 --> Security Class Initialized
DEBUG - 2020-03-04 07:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:10:38 --> Input Class Initialized
INFO - 2020-03-04 07:10:38 --> Language Class Initialized
ERROR - 2020-03-04 07:10:38 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 07:12:33 --> Config Class Initialized
INFO - 2020-03-04 07:12:33 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:12:33 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:12:33 --> Utf8 Class Initialized
INFO - 2020-03-04 07:12:33 --> URI Class Initialized
DEBUG - 2020-03-04 07:12:33 --> No URI present. Default controller set.
INFO - 2020-03-04 07:12:33 --> Router Class Initialized
INFO - 2020-03-04 07:12:33 --> Output Class Initialized
INFO - 2020-03-04 07:12:33 --> Security Class Initialized
DEBUG - 2020-03-04 07:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:12:33 --> Input Class Initialized
INFO - 2020-03-04 07:12:33 --> Language Class Initialized
INFO - 2020-03-04 07:12:33 --> Loader Class Initialized
INFO - 2020-03-04 07:12:33 --> Helper loaded: url_helper
INFO - 2020-03-04 07:12:33 --> Helper loaded: string_helper
INFO - 2020-03-04 07:12:33 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:12:33 --> Controller Class Initialized
INFO - 2020-03-04 07:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:12:33 --> Pagination Class Initialized
INFO - 2020-03-04 07:12:33 --> Model "M_show" initialized
INFO - 2020-03-04 07:12:33 --> Helper loaded: form_helper
INFO - 2020-03-04 07:12:33 --> Form Validation Class Initialized
INFO - 2020-03-04 07:12:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:12:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:12:33 --> Final output sent to browser
DEBUG - 2020-03-04 07:12:33 --> Total execution time: 0.0357
INFO - 2020-03-04 07:12:40 --> Config Class Initialized
INFO - 2020-03-04 07:12:40 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:12:40 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:12:40 --> Utf8 Class Initialized
INFO - 2020-03-04 07:12:40 --> URI Class Initialized
INFO - 2020-03-04 07:12:40 --> Router Class Initialized
INFO - 2020-03-04 07:12:40 --> Output Class Initialized
INFO - 2020-03-04 07:12:40 --> Security Class Initialized
DEBUG - 2020-03-04 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:12:40 --> Input Class Initialized
INFO - 2020-03-04 07:12:40 --> Language Class Initialized
INFO - 2020-03-04 07:12:40 --> Loader Class Initialized
INFO - 2020-03-04 07:12:40 --> Helper loaded: url_helper
INFO - 2020-03-04 07:12:40 --> Helper loaded: string_helper
INFO - 2020-03-04 07:12:40 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:12:40 --> Controller Class Initialized
INFO - 2020-03-04 07:12:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:12:40 --> Pagination Class Initialized
INFO - 2020-03-04 07:12:40 --> Model "M_show" initialized
INFO - 2020-03-04 07:12:40 --> Helper loaded: form_helper
INFO - 2020-03-04 07:12:40 --> Form Validation Class Initialized
INFO - 2020-03-04 07:12:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:12:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 07:12:40 --> Final output sent to browser
DEBUG - 2020-03-04 07:12:40 --> Total execution time: 0.0078
INFO - 2020-03-04 07:12:45 --> Config Class Initialized
INFO - 2020-03-04 07:12:45 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:12:45 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:12:45 --> Utf8 Class Initialized
INFO - 2020-03-04 07:12:45 --> URI Class Initialized
INFO - 2020-03-04 07:12:45 --> Router Class Initialized
INFO - 2020-03-04 07:12:45 --> Output Class Initialized
INFO - 2020-03-04 07:12:45 --> Security Class Initialized
DEBUG - 2020-03-04 07:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:12:45 --> Input Class Initialized
INFO - 2020-03-04 07:12:45 --> Language Class Initialized
INFO - 2020-03-04 07:12:45 --> Loader Class Initialized
INFO - 2020-03-04 07:12:45 --> Helper loaded: url_helper
INFO - 2020-03-04 07:12:45 --> Helper loaded: string_helper
INFO - 2020-03-04 07:12:45 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:12:45 --> Controller Class Initialized
INFO - 2020-03-04 07:12:45 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:12:45 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:12:45 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:12:45 --> Helper loaded: form_helper
INFO - 2020-03-04 07:12:45 --> Form Validation Class Initialized
INFO - 2020-03-04 07:12:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 07:12:45 --> Final output sent to browser
DEBUG - 2020-03-04 07:12:45 --> Total execution time: 0.0143
INFO - 2020-03-04 07:12:56 --> Config Class Initialized
INFO - 2020-03-04 07:12:56 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:12:56 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:12:56 --> Utf8 Class Initialized
INFO - 2020-03-04 07:12:56 --> URI Class Initialized
INFO - 2020-03-04 07:12:56 --> Router Class Initialized
INFO - 2020-03-04 07:12:56 --> Output Class Initialized
INFO - 2020-03-04 07:12:56 --> Security Class Initialized
DEBUG - 2020-03-04 07:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:12:56 --> Input Class Initialized
INFO - 2020-03-04 07:12:56 --> Language Class Initialized
INFO - 2020-03-04 07:12:56 --> Loader Class Initialized
INFO - 2020-03-04 07:12:56 --> Helper loaded: url_helper
INFO - 2020-03-04 07:12:56 --> Helper loaded: string_helper
INFO - 2020-03-04 07:12:56 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:12:56 --> Controller Class Initialized
INFO - 2020-03-04 07:12:56 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:12:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:12:56 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:12:56 --> Helper loaded: form_helper
INFO - 2020-03-04 07:12:56 --> Form Validation Class Initialized
INFO - 2020-03-04 07:12:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 07:12:56 --> Final output sent to browser
DEBUG - 2020-03-04 07:12:56 --> Total execution time: 0.0073
INFO - 2020-03-04 07:14:09 --> Config Class Initialized
INFO - 2020-03-04 07:14:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:14:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:14:09 --> Utf8 Class Initialized
INFO - 2020-03-04 07:14:09 --> URI Class Initialized
INFO - 2020-03-04 07:14:09 --> Router Class Initialized
INFO - 2020-03-04 07:14:09 --> Output Class Initialized
INFO - 2020-03-04 07:14:09 --> Security Class Initialized
DEBUG - 2020-03-04 07:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:14:09 --> Input Class Initialized
INFO - 2020-03-04 07:14:09 --> Language Class Initialized
INFO - 2020-03-04 07:14:09 --> Loader Class Initialized
INFO - 2020-03-04 07:14:09 --> Helper loaded: url_helper
INFO - 2020-03-04 07:14:09 --> Helper loaded: string_helper
INFO - 2020-03-04 07:14:09 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:14:09 --> Controller Class Initialized
INFO - 2020-03-04 07:14:09 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:14:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:14:09 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:14:09 --> Helper loaded: form_helper
INFO - 2020-03-04 07:14:09 --> Form Validation Class Initialized
DEBUG - 2020-03-04 07:14:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-04 07:14:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-04 07:14:09 --> Final output sent to browser
DEBUG - 2020-03-04 07:14:09 --> Total execution time: 0.0405
INFO - 2020-03-04 07:15:43 --> Config Class Initialized
INFO - 2020-03-04 07:15:43 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:15:43 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:15:43 --> Utf8 Class Initialized
INFO - 2020-03-04 07:15:43 --> URI Class Initialized
DEBUG - 2020-03-04 07:15:43 --> No URI present. Default controller set.
INFO - 2020-03-04 07:15:43 --> Router Class Initialized
INFO - 2020-03-04 07:15:43 --> Output Class Initialized
INFO - 2020-03-04 07:15:43 --> Security Class Initialized
DEBUG - 2020-03-04 07:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:15:43 --> Input Class Initialized
INFO - 2020-03-04 07:15:43 --> Language Class Initialized
INFO - 2020-03-04 07:15:43 --> Loader Class Initialized
INFO - 2020-03-04 07:15:43 --> Helper loaded: url_helper
INFO - 2020-03-04 07:15:43 --> Helper loaded: string_helper
INFO - 2020-03-04 07:15:43 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:15:43 --> Controller Class Initialized
INFO - 2020-03-04 07:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:15:43 --> Pagination Class Initialized
INFO - 2020-03-04 07:15:43 --> Model "M_show" initialized
INFO - 2020-03-04 07:15:43 --> Helper loaded: form_helper
INFO - 2020-03-04 07:15:43 --> Form Validation Class Initialized
INFO - 2020-03-04 07:15:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:15:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:15:43 --> Final output sent to browser
DEBUG - 2020-03-04 07:15:43 --> Total execution time: 0.0448
INFO - 2020-03-04 07:19:51 --> Config Class Initialized
INFO - 2020-03-04 07:19:51 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:19:51 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:19:51 --> Utf8 Class Initialized
INFO - 2020-03-04 07:19:51 --> URI Class Initialized
INFO - 2020-03-04 07:19:51 --> Router Class Initialized
INFO - 2020-03-04 07:19:51 --> Output Class Initialized
INFO - 2020-03-04 07:19:51 --> Security Class Initialized
DEBUG - 2020-03-04 07:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:19:51 --> Input Class Initialized
INFO - 2020-03-04 07:19:51 --> Language Class Initialized
INFO - 2020-03-04 07:19:51 --> Loader Class Initialized
INFO - 2020-03-04 07:19:51 --> Helper loaded: url_helper
INFO - 2020-03-04 07:19:51 --> Helper loaded: string_helper
INFO - 2020-03-04 07:19:51 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:19:51 --> Controller Class Initialized
INFO - 2020-03-04 07:19:51 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:19:51 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:19:51 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:19:51 --> Helper loaded: form_helper
INFO - 2020-03-04 07:19:51 --> Form Validation Class Initialized
INFO - 2020-03-04 07:19:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 07:19:51 --> Final output sent to browser
DEBUG - 2020-03-04 07:19:51 --> Total execution time: 0.0524
INFO - 2020-03-04 07:28:44 --> Config Class Initialized
INFO - 2020-03-04 07:28:44 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:28:44 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:28:44 --> Utf8 Class Initialized
INFO - 2020-03-04 07:28:44 --> URI Class Initialized
INFO - 2020-03-04 07:28:44 --> Router Class Initialized
INFO - 2020-03-04 07:28:44 --> Output Class Initialized
INFO - 2020-03-04 07:28:44 --> Security Class Initialized
DEBUG - 2020-03-04 07:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:28:44 --> Input Class Initialized
INFO - 2020-03-04 07:28:44 --> Language Class Initialized
INFO - 2020-03-04 07:28:44 --> Loader Class Initialized
INFO - 2020-03-04 07:28:44 --> Helper loaded: url_helper
INFO - 2020-03-04 07:28:44 --> Helper loaded: string_helper
INFO - 2020-03-04 07:28:44 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:28:44 --> Controller Class Initialized
INFO - 2020-03-04 07:28:44 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:28:44 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:28:44 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:28:44 --> Helper loaded: form_helper
INFO - 2020-03-04 07:28:44 --> Form Validation Class Initialized
INFO - 2020-03-04 07:28:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 07:28:44 --> Final output sent to browser
DEBUG - 2020-03-04 07:28:44 --> Total execution time: 0.0414
INFO - 2020-03-04 07:43:09 --> Config Class Initialized
INFO - 2020-03-04 07:43:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:43:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:43:09 --> Utf8 Class Initialized
INFO - 2020-03-04 07:43:09 --> URI Class Initialized
DEBUG - 2020-03-04 07:43:09 --> No URI present. Default controller set.
INFO - 2020-03-04 07:43:09 --> Router Class Initialized
INFO - 2020-03-04 07:43:09 --> Output Class Initialized
INFO - 2020-03-04 07:43:09 --> Security Class Initialized
DEBUG - 2020-03-04 07:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:43:09 --> Input Class Initialized
INFO - 2020-03-04 07:43:09 --> Language Class Initialized
INFO - 2020-03-04 07:43:09 --> Loader Class Initialized
INFO - 2020-03-04 07:43:09 --> Helper loaded: url_helper
INFO - 2020-03-04 07:43:09 --> Helper loaded: string_helper
INFO - 2020-03-04 07:43:09 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:43:09 --> Controller Class Initialized
INFO - 2020-03-04 07:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:43:09 --> Pagination Class Initialized
INFO - 2020-03-04 07:43:09 --> Model "M_show" initialized
INFO - 2020-03-04 07:43:09 --> Helper loaded: form_helper
INFO - 2020-03-04 07:43:09 --> Form Validation Class Initialized
INFO - 2020-03-04 07:43:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:43:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:43:09 --> Final output sent to browser
DEBUG - 2020-03-04 07:43:09 --> Total execution time: 0.0350
INFO - 2020-03-04 07:43:17 --> Config Class Initialized
INFO - 2020-03-04 07:43:17 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:43:17 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:43:17 --> Utf8 Class Initialized
INFO - 2020-03-04 07:43:17 --> URI Class Initialized
INFO - 2020-03-04 07:43:17 --> Router Class Initialized
INFO - 2020-03-04 07:43:17 --> Output Class Initialized
INFO - 2020-03-04 07:43:17 --> Security Class Initialized
DEBUG - 2020-03-04 07:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:43:17 --> Input Class Initialized
INFO - 2020-03-04 07:43:17 --> Language Class Initialized
INFO - 2020-03-04 07:43:17 --> Loader Class Initialized
INFO - 2020-03-04 07:43:17 --> Helper loaded: url_helper
INFO - 2020-03-04 07:43:17 --> Helper loaded: string_helper
INFO - 2020-03-04 07:43:17 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:43:17 --> Controller Class Initialized
INFO - 2020-03-04 07:43:17 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:43:17 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:43:17 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:43:17 --> Helper loaded: form_helper
INFO - 2020-03-04 07:43:17 --> Form Validation Class Initialized
INFO - 2020-03-04 07:43:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 07:43:17 --> Final output sent to browser
DEBUG - 2020-03-04 07:43:17 --> Total execution time: 0.0131
INFO - 2020-03-04 07:43:20 --> Config Class Initialized
INFO - 2020-03-04 07:43:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:43:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:43:20 --> Utf8 Class Initialized
INFO - 2020-03-04 07:43:20 --> URI Class Initialized
INFO - 2020-03-04 07:43:20 --> Router Class Initialized
INFO - 2020-03-04 07:43:20 --> Output Class Initialized
INFO - 2020-03-04 07:43:20 --> Security Class Initialized
DEBUG - 2020-03-04 07:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:43:20 --> Input Class Initialized
INFO - 2020-03-04 07:43:20 --> Language Class Initialized
INFO - 2020-03-04 07:43:20 --> Loader Class Initialized
INFO - 2020-03-04 07:43:20 --> Helper loaded: url_helper
INFO - 2020-03-04 07:43:20 --> Helper loaded: string_helper
INFO - 2020-03-04 07:43:20 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:43:20 --> Controller Class Initialized
INFO - 2020-03-04 07:43:20 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:43:20 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:43:20 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:43:20 --> Helper loaded: form_helper
INFO - 2020-03-04 07:43:20 --> Form Validation Class Initialized
INFO - 2020-03-04 07:43:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 07:43:20 --> Final output sent to browser
DEBUG - 2020-03-04 07:43:20 --> Total execution time: 0.0092
INFO - 2020-03-04 07:44:43 --> Config Class Initialized
INFO - 2020-03-04 07:44:43 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:44:43 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:44:43 --> Utf8 Class Initialized
INFO - 2020-03-04 07:44:43 --> URI Class Initialized
INFO - 2020-03-04 07:44:43 --> Router Class Initialized
INFO - 2020-03-04 07:44:43 --> Output Class Initialized
INFO - 2020-03-04 07:44:43 --> Security Class Initialized
DEBUG - 2020-03-04 07:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:44:43 --> Input Class Initialized
INFO - 2020-03-04 07:44:43 --> Language Class Initialized
INFO - 2020-03-04 07:44:43 --> Loader Class Initialized
INFO - 2020-03-04 07:44:43 --> Helper loaded: url_helper
INFO - 2020-03-04 07:44:43 --> Helper loaded: string_helper
INFO - 2020-03-04 07:44:43 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:44:43 --> Controller Class Initialized
INFO - 2020-03-04 07:44:43 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:44:43 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:44:43 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:44:43 --> Helper loaded: form_helper
INFO - 2020-03-04 07:44:43 --> Form Validation Class Initialized
INFO - 2020-03-04 14:44:43 --> Upload Class Initialized
INFO - 2020-03-04 07:44:44 --> Config Class Initialized
INFO - 2020-03-04 07:44:44 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:44:44 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:44:44 --> Utf8 Class Initialized
INFO - 2020-03-04 07:44:44 --> URI Class Initialized
INFO - 2020-03-04 07:44:44 --> Router Class Initialized
INFO - 2020-03-04 07:44:44 --> Output Class Initialized
INFO - 2020-03-04 07:44:44 --> Security Class Initialized
DEBUG - 2020-03-04 07:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:44:44 --> Input Class Initialized
INFO - 2020-03-04 07:44:44 --> Language Class Initialized
INFO - 2020-03-04 07:44:44 --> Loader Class Initialized
INFO - 2020-03-04 07:44:44 --> Helper loaded: url_helper
INFO - 2020-03-04 07:44:44 --> Helper loaded: string_helper
INFO - 2020-03-04 07:44:44 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:44:44 --> Controller Class Initialized
INFO - 2020-03-04 07:44:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:44:44 --> Pagination Class Initialized
INFO - 2020-03-04 07:44:44 --> Model "M_show" initialized
INFO - 2020-03-04 07:44:44 --> Helper loaded: form_helper
INFO - 2020-03-04 07:44:44 --> Form Validation Class Initialized
INFO - 2020-03-04 07:44:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:44:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:44:44 --> Final output sent to browser
DEBUG - 2020-03-04 07:44:44 --> Total execution time: 0.0096
INFO - 2020-03-04 07:44:46 --> Config Class Initialized
INFO - 2020-03-04 07:44:46 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:44:46 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:44:46 --> Utf8 Class Initialized
INFO - 2020-03-04 07:44:46 --> URI Class Initialized
INFO - 2020-03-04 07:44:46 --> Router Class Initialized
INFO - 2020-03-04 07:44:46 --> Output Class Initialized
INFO - 2020-03-04 07:44:46 --> Security Class Initialized
DEBUG - 2020-03-04 07:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:44:46 --> Input Class Initialized
INFO - 2020-03-04 07:44:46 --> Language Class Initialized
ERROR - 2020-03-04 07:44:46 --> 404 Page Not Found: Engine0/jquery.js
INFO - 2020-03-04 07:46:33 --> Config Class Initialized
INFO - 2020-03-04 07:46:33 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:46:33 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:46:33 --> Utf8 Class Initialized
INFO - 2020-03-04 07:46:33 --> URI Class Initialized
INFO - 2020-03-04 07:46:33 --> Router Class Initialized
INFO - 2020-03-04 07:46:33 --> Output Class Initialized
INFO - 2020-03-04 07:46:33 --> Security Class Initialized
DEBUG - 2020-03-04 07:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:46:33 --> Input Class Initialized
INFO - 2020-03-04 07:46:33 --> Language Class Initialized
INFO - 2020-03-04 07:46:33 --> Loader Class Initialized
INFO - 2020-03-04 07:46:33 --> Helper loaded: url_helper
INFO - 2020-03-04 07:46:33 --> Helper loaded: string_helper
INFO - 2020-03-04 07:46:33 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:46:33 --> Controller Class Initialized
INFO - 2020-03-04 07:46:33 --> Model "M_tiket" initialized
INFO - 2020-03-04 07:46:33 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 07:46:33 --> Model "M_pesan" initialized
INFO - 2020-03-04 07:46:33 --> Helper loaded: form_helper
INFO - 2020-03-04 07:46:33 --> Form Validation Class Initialized
INFO - 2020-03-04 07:46:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 07:46:33 --> Final output sent to browser
DEBUG - 2020-03-04 07:46:33 --> Total execution time: 0.0353
INFO - 2020-03-04 07:51:02 --> Config Class Initialized
INFO - 2020-03-04 07:51:02 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:51:02 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:51:02 --> Utf8 Class Initialized
INFO - 2020-03-04 07:51:02 --> URI Class Initialized
DEBUG - 2020-03-04 07:51:02 --> No URI present. Default controller set.
INFO - 2020-03-04 07:51:02 --> Router Class Initialized
INFO - 2020-03-04 07:51:02 --> Output Class Initialized
INFO - 2020-03-04 07:51:02 --> Security Class Initialized
DEBUG - 2020-03-04 07:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:51:02 --> Input Class Initialized
INFO - 2020-03-04 07:51:02 --> Language Class Initialized
INFO - 2020-03-04 07:51:02 --> Loader Class Initialized
INFO - 2020-03-04 07:51:02 --> Helper loaded: url_helper
INFO - 2020-03-04 07:51:02 --> Helper loaded: string_helper
INFO - 2020-03-04 07:51:02 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:51:02 --> Controller Class Initialized
INFO - 2020-03-04 07:51:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:51:02 --> Pagination Class Initialized
INFO - 2020-03-04 07:51:02 --> Model "M_show" initialized
INFO - 2020-03-04 07:51:02 --> Helper loaded: form_helper
INFO - 2020-03-04 07:51:02 --> Form Validation Class Initialized
INFO - 2020-03-04 07:51:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:51:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:51:02 --> Final output sent to browser
DEBUG - 2020-03-04 07:51:02 --> Total execution time: 0.0313
INFO - 2020-03-04 07:51:20 --> Config Class Initialized
INFO - 2020-03-04 07:51:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:51:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:51:20 --> Utf8 Class Initialized
INFO - 2020-03-04 07:51:20 --> URI Class Initialized
INFO - 2020-03-04 07:51:20 --> Router Class Initialized
INFO - 2020-03-04 07:51:20 --> Output Class Initialized
INFO - 2020-03-04 07:51:20 --> Security Class Initialized
DEBUG - 2020-03-04 07:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:51:20 --> Input Class Initialized
INFO - 2020-03-04 07:51:20 --> Language Class Initialized
INFO - 2020-03-04 07:51:20 --> Loader Class Initialized
INFO - 2020-03-04 07:51:20 --> Helper loaded: url_helper
INFO - 2020-03-04 07:51:20 --> Helper loaded: string_helper
INFO - 2020-03-04 07:51:20 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:51:20 --> Controller Class Initialized
INFO - 2020-03-04 07:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:51:20 --> Pagination Class Initialized
INFO - 2020-03-04 07:51:20 --> Model "M_show" initialized
INFO - 2020-03-04 07:51:20 --> Helper loaded: form_helper
INFO - 2020-03-04 07:51:20 --> Form Validation Class Initialized
INFO - 2020-03-04 07:51:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:51:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-04 07:51:20 --> Final output sent to browser
DEBUG - 2020-03-04 07:51:20 --> Total execution time: 0.0244
INFO - 2020-03-04 07:51:43 --> Config Class Initialized
INFO - 2020-03-04 07:51:43 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:51:43 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:51:43 --> Utf8 Class Initialized
INFO - 2020-03-04 07:51:43 --> URI Class Initialized
DEBUG - 2020-03-04 07:51:43 --> No URI present. Default controller set.
INFO - 2020-03-04 07:51:43 --> Router Class Initialized
INFO - 2020-03-04 07:51:43 --> Output Class Initialized
INFO - 2020-03-04 07:51:43 --> Security Class Initialized
DEBUG - 2020-03-04 07:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:51:43 --> Input Class Initialized
INFO - 2020-03-04 07:51:43 --> Language Class Initialized
INFO - 2020-03-04 07:51:43 --> Loader Class Initialized
INFO - 2020-03-04 07:51:43 --> Helper loaded: url_helper
INFO - 2020-03-04 07:51:43 --> Helper loaded: string_helper
INFO - 2020-03-04 07:51:43 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:51:43 --> Controller Class Initialized
INFO - 2020-03-04 07:51:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:51:43 --> Pagination Class Initialized
INFO - 2020-03-04 07:51:43 --> Model "M_show" initialized
INFO - 2020-03-04 07:51:43 --> Helper loaded: form_helper
INFO - 2020-03-04 07:51:43 --> Form Validation Class Initialized
INFO - 2020-03-04 07:51:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:51:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:51:43 --> Final output sent to browser
DEBUG - 2020-03-04 07:51:43 --> Total execution time: 0.0051
INFO - 2020-03-04 07:51:49 --> Config Class Initialized
INFO - 2020-03-04 07:51:49 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:51:49 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:51:49 --> Utf8 Class Initialized
INFO - 2020-03-04 07:51:49 --> URI Class Initialized
INFO - 2020-03-04 07:51:49 --> Router Class Initialized
INFO - 2020-03-04 07:51:49 --> Output Class Initialized
INFO - 2020-03-04 07:51:49 --> Security Class Initialized
DEBUG - 2020-03-04 07:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:51:49 --> Input Class Initialized
INFO - 2020-03-04 07:51:49 --> Language Class Initialized
INFO - 2020-03-04 07:51:49 --> Loader Class Initialized
INFO - 2020-03-04 07:51:49 --> Helper loaded: url_helper
INFO - 2020-03-04 07:51:49 --> Helper loaded: string_helper
INFO - 2020-03-04 07:51:49 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:51:49 --> Controller Class Initialized
INFO - 2020-03-04 07:51:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:51:49 --> Pagination Class Initialized
INFO - 2020-03-04 07:51:49 --> Model "M_show" initialized
INFO - 2020-03-04 07:51:49 --> Helper loaded: form_helper
INFO - 2020-03-04 07:51:49 --> Form Validation Class Initialized
INFO - 2020-03-04 07:51:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:51:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-04 07:51:49 --> Final output sent to browser
DEBUG - 2020-03-04 07:51:49 --> Total execution time: 0.0130
INFO - 2020-03-04 07:52:27 --> Config Class Initialized
INFO - 2020-03-04 07:52:27 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:52:27 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:52:27 --> Utf8 Class Initialized
INFO - 2020-03-04 07:52:27 --> URI Class Initialized
INFO - 2020-03-04 07:52:27 --> Router Class Initialized
INFO - 2020-03-04 07:52:27 --> Output Class Initialized
INFO - 2020-03-04 07:52:27 --> Security Class Initialized
DEBUG - 2020-03-04 07:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:52:27 --> Input Class Initialized
INFO - 2020-03-04 07:52:27 --> Language Class Initialized
INFO - 2020-03-04 07:52:27 --> Loader Class Initialized
INFO - 2020-03-04 07:52:27 --> Helper loaded: url_helper
INFO - 2020-03-04 07:52:27 --> Helper loaded: string_helper
INFO - 2020-03-04 07:52:27 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:52:27 --> Controller Class Initialized
INFO - 2020-03-04 07:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:52:27 --> Pagination Class Initialized
INFO - 2020-03-04 07:52:27 --> Model "M_show" initialized
INFO - 2020-03-04 07:52:27 --> Helper loaded: form_helper
INFO - 2020-03-04 07:52:27 --> Form Validation Class Initialized
INFO - 2020-03-04 07:52:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:52:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-04 07:52:27 --> Final output sent to browser
DEBUG - 2020-03-04 07:52:27 --> Total execution time: 0.0060
INFO - 2020-03-04 07:52:44 --> Config Class Initialized
INFO - 2020-03-04 07:52:44 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:52:44 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:52:44 --> Utf8 Class Initialized
INFO - 2020-03-04 07:52:44 --> URI Class Initialized
INFO - 2020-03-04 07:52:44 --> Router Class Initialized
INFO - 2020-03-04 07:52:44 --> Output Class Initialized
INFO - 2020-03-04 07:52:44 --> Security Class Initialized
DEBUG - 2020-03-04 07:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:52:44 --> Input Class Initialized
INFO - 2020-03-04 07:52:44 --> Language Class Initialized
INFO - 2020-03-04 07:52:44 --> Loader Class Initialized
INFO - 2020-03-04 07:52:44 --> Helper loaded: url_helper
INFO - 2020-03-04 07:52:44 --> Helper loaded: string_helper
INFO - 2020-03-04 07:52:44 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:52:44 --> Controller Class Initialized
INFO - 2020-03-04 07:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:52:44 --> Pagination Class Initialized
INFO - 2020-03-04 07:52:44 --> Model "M_show" initialized
INFO - 2020-03-04 07:52:44 --> Helper loaded: form_helper
INFO - 2020-03-04 07:52:44 --> Form Validation Class Initialized
INFO - 2020-03-04 07:52:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:52:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-04 07:52:44 --> Final output sent to browser
DEBUG - 2020-03-04 07:52:44 --> Total execution time: 0.0117
INFO - 2020-03-04 07:53:09 --> Config Class Initialized
INFO - 2020-03-04 07:53:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:53:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:53:09 --> Utf8 Class Initialized
INFO - 2020-03-04 07:53:09 --> URI Class Initialized
INFO - 2020-03-04 07:53:09 --> Router Class Initialized
INFO - 2020-03-04 07:53:09 --> Output Class Initialized
INFO - 2020-03-04 07:53:09 --> Security Class Initialized
DEBUG - 2020-03-04 07:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:53:09 --> Input Class Initialized
INFO - 2020-03-04 07:53:09 --> Language Class Initialized
INFO - 2020-03-04 07:53:09 --> Loader Class Initialized
INFO - 2020-03-04 07:53:09 --> Helper loaded: url_helper
INFO - 2020-03-04 07:53:09 --> Helper loaded: string_helper
INFO - 2020-03-04 07:53:09 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:53:09 --> Controller Class Initialized
INFO - 2020-03-04 07:53:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:53:09 --> Pagination Class Initialized
INFO - 2020-03-04 07:53:09 --> Model "M_show" initialized
INFO - 2020-03-04 07:53:09 --> Helper loaded: form_helper
INFO - 2020-03-04 07:53:09 --> Form Validation Class Initialized
INFO - 2020-03-04 07:53:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:53:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:53:09 --> Final output sent to browser
DEBUG - 2020-03-04 07:53:09 --> Total execution time: 0.0052
INFO - 2020-03-04 07:53:18 --> Config Class Initialized
INFO - 2020-03-04 07:53:18 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:53:18 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:53:18 --> Utf8 Class Initialized
INFO - 2020-03-04 07:53:18 --> URI Class Initialized
INFO - 2020-03-04 07:53:18 --> Router Class Initialized
INFO - 2020-03-04 07:53:18 --> Output Class Initialized
INFO - 2020-03-04 07:53:18 --> Security Class Initialized
DEBUG - 2020-03-04 07:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:53:18 --> Input Class Initialized
INFO - 2020-03-04 07:53:18 --> Language Class Initialized
INFO - 2020-03-04 07:53:18 --> Loader Class Initialized
INFO - 2020-03-04 07:53:18 --> Helper loaded: url_helper
INFO - 2020-03-04 07:53:18 --> Helper loaded: string_helper
INFO - 2020-03-04 07:53:18 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:53:18 --> Controller Class Initialized
INFO - 2020-03-04 07:53:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:53:18 --> Pagination Class Initialized
INFO - 2020-03-04 07:53:18 --> Model "M_show" initialized
INFO - 2020-03-04 07:53:18 --> Helper loaded: form_helper
INFO - 2020-03-04 07:53:18 --> Form Validation Class Initialized
INFO - 2020-03-04 07:53:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:53:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 07:53:18 --> Final output sent to browser
DEBUG - 2020-03-04 07:53:18 --> Total execution time: 0.0090
INFO - 2020-03-04 07:53:29 --> Config Class Initialized
INFO - 2020-03-04 07:53:29 --> Hooks Class Initialized
DEBUG - 2020-03-04 07:53:29 --> UTF-8 Support Enabled
INFO - 2020-03-04 07:53:29 --> Utf8 Class Initialized
INFO - 2020-03-04 07:53:29 --> URI Class Initialized
INFO - 2020-03-04 07:53:29 --> Router Class Initialized
INFO - 2020-03-04 07:53:29 --> Output Class Initialized
INFO - 2020-03-04 07:53:29 --> Security Class Initialized
DEBUG - 2020-03-04 07:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 07:53:29 --> Input Class Initialized
INFO - 2020-03-04 07:53:29 --> Language Class Initialized
INFO - 2020-03-04 07:53:29 --> Loader Class Initialized
INFO - 2020-03-04 07:53:29 --> Helper loaded: url_helper
INFO - 2020-03-04 07:53:29 --> Helper loaded: string_helper
INFO - 2020-03-04 07:53:29 --> Database Driver Class Initialized
DEBUG - 2020-03-04 07:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 07:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 07:53:29 --> Controller Class Initialized
INFO - 2020-03-04 07:53:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 07:53:29 --> Pagination Class Initialized
INFO - 2020-03-04 07:53:29 --> Model "M_show" initialized
INFO - 2020-03-04 07:53:29 --> Helper loaded: form_helper
INFO - 2020-03-04 07:53:29 --> Form Validation Class Initialized
INFO - 2020-03-04 07:53:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 07:53:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 07:53:29 --> Final output sent to browser
DEBUG - 2020-03-04 07:53:29 --> Total execution time: 0.0832
INFO - 2020-03-04 08:25:41 --> Config Class Initialized
INFO - 2020-03-04 08:25:41 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:25:41 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:25:41 --> Utf8 Class Initialized
INFO - 2020-03-04 08:25:41 --> URI Class Initialized
INFO - 2020-03-04 08:25:41 --> Router Class Initialized
INFO - 2020-03-04 08:25:41 --> Output Class Initialized
INFO - 2020-03-04 08:25:41 --> Security Class Initialized
DEBUG - 2020-03-04 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:25:41 --> Input Class Initialized
INFO - 2020-03-04 08:25:41 --> Language Class Initialized
INFO - 2020-03-04 08:25:41 --> Loader Class Initialized
INFO - 2020-03-04 08:25:41 --> Helper loaded: url_helper
INFO - 2020-03-04 08:25:41 --> Helper loaded: string_helper
INFO - 2020-03-04 08:25:41 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:25:41 --> Controller Class Initialized
INFO - 2020-03-04 08:25:41 --> Model "M_tiket" initialized
INFO - 2020-03-04 08:25:41 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 08:25:41 --> Model "M_pesan" initialized
INFO - 2020-03-04 08:25:41 --> Helper loaded: form_helper
INFO - 2020-03-04 08:25:41 --> Form Validation Class Initialized
INFO - 2020-03-04 08:25:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 08:25:41 --> Final output sent to browser
DEBUG - 2020-03-04 08:25:41 --> Total execution time: 0.0790
INFO - 2020-03-04 08:25:51 --> Config Class Initialized
INFO - 2020-03-04 08:25:51 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:25:51 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:25:51 --> Utf8 Class Initialized
INFO - 2020-03-04 08:25:51 --> URI Class Initialized
INFO - 2020-03-04 08:25:51 --> Router Class Initialized
INFO - 2020-03-04 08:25:51 --> Output Class Initialized
INFO - 2020-03-04 08:25:51 --> Security Class Initialized
DEBUG - 2020-03-04 08:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:25:51 --> Input Class Initialized
INFO - 2020-03-04 08:25:51 --> Language Class Initialized
INFO - 2020-03-04 08:25:51 --> Loader Class Initialized
INFO - 2020-03-04 08:25:51 --> Helper loaded: url_helper
INFO - 2020-03-04 08:25:51 --> Helper loaded: string_helper
INFO - 2020-03-04 08:25:51 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:25:51 --> Controller Class Initialized
INFO - 2020-03-04 08:25:51 --> Model "M_tiket" initialized
INFO - 2020-03-04 08:25:51 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 08:25:51 --> Model "M_pesan" initialized
INFO - 2020-03-04 08:25:51 --> Helper loaded: form_helper
INFO - 2020-03-04 08:25:51 --> Form Validation Class Initialized
INFO - 2020-03-04 08:25:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 08:25:51 --> Final output sent to browser
DEBUG - 2020-03-04 08:25:51 --> Total execution time: 0.0066
INFO - 2020-03-04 08:25:53 --> Config Class Initialized
INFO - 2020-03-04 08:25:53 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:25:53 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:25:53 --> Utf8 Class Initialized
INFO - 2020-03-04 08:25:53 --> URI Class Initialized
INFO - 2020-03-04 08:25:53 --> Router Class Initialized
INFO - 2020-03-04 08:25:53 --> Output Class Initialized
INFO - 2020-03-04 08:25:53 --> Security Class Initialized
DEBUG - 2020-03-04 08:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:25:53 --> Input Class Initialized
INFO - 2020-03-04 08:25:53 --> Language Class Initialized
INFO - 2020-03-04 08:25:53 --> Loader Class Initialized
INFO - 2020-03-04 08:25:53 --> Helper loaded: url_helper
INFO - 2020-03-04 08:25:53 --> Helper loaded: string_helper
INFO - 2020-03-04 08:25:53 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:25:53 --> Controller Class Initialized
INFO - 2020-03-04 08:25:53 --> Model "M_tiket" initialized
INFO - 2020-03-04 08:25:53 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 08:25:53 --> Model "M_pesan" initialized
INFO - 2020-03-04 08:25:53 --> Helper loaded: form_helper
INFO - 2020-03-04 08:25:53 --> Form Validation Class Initialized
INFO - 2020-03-04 08:25:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 08:25:53 --> Final output sent to browser
DEBUG - 2020-03-04 08:25:53 --> Total execution time: 0.0107
INFO - 2020-03-04 08:26:02 --> Config Class Initialized
INFO - 2020-03-04 08:26:02 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:26:02 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:26:02 --> Utf8 Class Initialized
INFO - 2020-03-04 08:26:02 --> URI Class Initialized
DEBUG - 2020-03-04 08:26:02 --> No URI present. Default controller set.
INFO - 2020-03-04 08:26:02 --> Router Class Initialized
INFO - 2020-03-04 08:26:02 --> Output Class Initialized
INFO - 2020-03-04 08:26:02 --> Security Class Initialized
DEBUG - 2020-03-04 08:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:26:02 --> Input Class Initialized
INFO - 2020-03-04 08:26:02 --> Language Class Initialized
INFO - 2020-03-04 08:26:02 --> Loader Class Initialized
INFO - 2020-03-04 08:26:02 --> Helper loaded: url_helper
INFO - 2020-03-04 08:26:02 --> Helper loaded: string_helper
INFO - 2020-03-04 08:26:02 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:26:02 --> Controller Class Initialized
INFO - 2020-03-04 08:26:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 08:26:02 --> Pagination Class Initialized
INFO - 2020-03-04 08:26:02 --> Model "M_show" initialized
INFO - 2020-03-04 08:26:02 --> Helper loaded: form_helper
INFO - 2020-03-04 08:26:02 --> Form Validation Class Initialized
INFO - 2020-03-04 08:26:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 08:26:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 08:26:02 --> Final output sent to browser
DEBUG - 2020-03-04 08:26:02 --> Total execution time: 0.0096
INFO - 2020-03-04 08:26:12 --> Config Class Initialized
INFO - 2020-03-04 08:26:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:26:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:26:12 --> Utf8 Class Initialized
INFO - 2020-03-04 08:26:12 --> URI Class Initialized
INFO - 2020-03-04 08:26:12 --> Router Class Initialized
INFO - 2020-03-04 08:26:12 --> Output Class Initialized
INFO - 2020-03-04 08:26:12 --> Security Class Initialized
DEBUG - 2020-03-04 08:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:26:12 --> Input Class Initialized
INFO - 2020-03-04 08:26:12 --> Language Class Initialized
INFO - 2020-03-04 08:26:12 --> Loader Class Initialized
INFO - 2020-03-04 08:26:12 --> Helper loaded: url_helper
INFO - 2020-03-04 08:26:12 --> Helper loaded: string_helper
INFO - 2020-03-04 08:26:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:26:12 --> Controller Class Initialized
INFO - 2020-03-04 08:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 08:26:12 --> Pagination Class Initialized
INFO - 2020-03-04 08:26:12 --> Model "M_show" initialized
INFO - 2020-03-04 08:26:12 --> Helper loaded: form_helper
INFO - 2020-03-04 08:26:12 --> Form Validation Class Initialized
INFO - 2020-03-04 08:26:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 08:26:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 08:26:12 --> Final output sent to browser
DEBUG - 2020-03-04 08:26:12 --> Total execution time: 0.0074
INFO - 2020-03-04 08:26:15 --> Config Class Initialized
INFO - 2020-03-04 08:26:15 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:26:15 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:26:15 --> Utf8 Class Initialized
INFO - 2020-03-04 08:26:15 --> URI Class Initialized
INFO - 2020-03-04 08:26:15 --> Router Class Initialized
INFO - 2020-03-04 08:26:15 --> Output Class Initialized
INFO - 2020-03-04 08:26:15 --> Security Class Initialized
DEBUG - 2020-03-04 08:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:26:15 --> Input Class Initialized
INFO - 2020-03-04 08:26:15 --> Language Class Initialized
INFO - 2020-03-04 08:26:15 --> Loader Class Initialized
INFO - 2020-03-04 08:26:15 --> Helper loaded: url_helper
INFO - 2020-03-04 08:26:15 --> Helper loaded: string_helper
INFO - 2020-03-04 08:26:15 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:26:15 --> Controller Class Initialized
INFO - 2020-03-04 08:26:15 --> Model "M_tiket" initialized
INFO - 2020-03-04 08:26:15 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 08:26:15 --> Model "M_pesan" initialized
INFO - 2020-03-04 08:26:15 --> Helper loaded: form_helper
INFO - 2020-03-04 08:26:15 --> Form Validation Class Initialized
INFO - 2020-03-04 08:26:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 08:26:15 --> Final output sent to browser
DEBUG - 2020-03-04 08:26:15 --> Total execution time: 0.0078
INFO - 2020-03-04 08:27:10 --> Config Class Initialized
INFO - 2020-03-04 08:27:10 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:27:10 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:27:10 --> Utf8 Class Initialized
INFO - 2020-03-04 08:27:10 --> URI Class Initialized
DEBUG - 2020-03-04 08:27:10 --> No URI present. Default controller set.
INFO - 2020-03-04 08:27:10 --> Router Class Initialized
INFO - 2020-03-04 08:27:10 --> Output Class Initialized
INFO - 2020-03-04 08:27:10 --> Security Class Initialized
DEBUG - 2020-03-04 08:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:27:10 --> Input Class Initialized
INFO - 2020-03-04 08:27:10 --> Language Class Initialized
INFO - 2020-03-04 08:27:10 --> Loader Class Initialized
INFO - 2020-03-04 08:27:10 --> Helper loaded: url_helper
INFO - 2020-03-04 08:27:10 --> Helper loaded: string_helper
INFO - 2020-03-04 08:27:10 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:27:10 --> Controller Class Initialized
INFO - 2020-03-04 08:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 08:27:10 --> Pagination Class Initialized
INFO - 2020-03-04 08:27:10 --> Model "M_show" initialized
INFO - 2020-03-04 08:27:10 --> Helper loaded: form_helper
INFO - 2020-03-04 08:27:10 --> Form Validation Class Initialized
INFO - 2020-03-04 08:27:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 08:27:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 08:27:10 --> Final output sent to browser
DEBUG - 2020-03-04 08:27:10 --> Total execution time: 0.0146
INFO - 2020-03-04 08:27:12 --> Config Class Initialized
INFO - 2020-03-04 08:27:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:27:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:27:12 --> Utf8 Class Initialized
INFO - 2020-03-04 08:27:12 --> URI Class Initialized
DEBUG - 2020-03-04 08:27:12 --> No URI present. Default controller set.
INFO - 2020-03-04 08:27:12 --> Router Class Initialized
INFO - 2020-03-04 08:27:12 --> Output Class Initialized
INFO - 2020-03-04 08:27:12 --> Security Class Initialized
DEBUG - 2020-03-04 08:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:27:12 --> Input Class Initialized
INFO - 2020-03-04 08:27:12 --> Language Class Initialized
INFO - 2020-03-04 08:27:12 --> Loader Class Initialized
INFO - 2020-03-04 08:27:12 --> Helper loaded: url_helper
INFO - 2020-03-04 08:27:12 --> Helper loaded: string_helper
INFO - 2020-03-04 08:27:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:27:12 --> Controller Class Initialized
INFO - 2020-03-04 08:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 08:27:12 --> Pagination Class Initialized
INFO - 2020-03-04 08:27:12 --> Model "M_show" initialized
INFO - 2020-03-04 08:27:12 --> Helper loaded: form_helper
INFO - 2020-03-04 08:27:12 --> Form Validation Class Initialized
INFO - 2020-03-04 08:27:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 08:27:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 08:27:12 --> Final output sent to browser
DEBUG - 2020-03-04 08:27:12 --> Total execution time: 0.0132
INFO - 2020-03-04 08:27:24 --> Config Class Initialized
INFO - 2020-03-04 08:27:24 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:27:24 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:27:24 --> Utf8 Class Initialized
INFO - 2020-03-04 08:27:24 --> URI Class Initialized
INFO - 2020-03-04 08:27:24 --> Router Class Initialized
INFO - 2020-03-04 08:27:24 --> Output Class Initialized
INFO - 2020-03-04 08:27:24 --> Security Class Initialized
DEBUG - 2020-03-04 08:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:27:24 --> Input Class Initialized
INFO - 2020-03-04 08:27:24 --> Language Class Initialized
INFO - 2020-03-04 08:27:24 --> Loader Class Initialized
INFO - 2020-03-04 08:27:24 --> Helper loaded: url_helper
INFO - 2020-03-04 08:27:24 --> Helper loaded: string_helper
INFO - 2020-03-04 08:27:24 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:27:24 --> Controller Class Initialized
INFO - 2020-03-04 08:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 08:27:24 --> Pagination Class Initialized
INFO - 2020-03-04 08:27:24 --> Model "M_show" initialized
INFO - 2020-03-04 08:27:24 --> Helper loaded: form_helper
INFO - 2020-03-04 08:27:24 --> Form Validation Class Initialized
INFO - 2020-03-04 08:27:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 08:27:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 08:27:24 --> Final output sent to browser
DEBUG - 2020-03-04 08:27:24 --> Total execution time: 0.0157
INFO - 2020-03-04 08:27:28 --> Config Class Initialized
INFO - 2020-03-04 08:27:28 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:27:28 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:27:28 --> Utf8 Class Initialized
INFO - 2020-03-04 08:27:28 --> URI Class Initialized
INFO - 2020-03-04 08:27:28 --> Router Class Initialized
INFO - 2020-03-04 08:27:28 --> Output Class Initialized
INFO - 2020-03-04 08:27:28 --> Security Class Initialized
DEBUG - 2020-03-04 08:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:27:28 --> Input Class Initialized
INFO - 2020-03-04 08:27:28 --> Language Class Initialized
INFO - 2020-03-04 08:27:28 --> Loader Class Initialized
INFO - 2020-03-04 08:27:28 --> Helper loaded: url_helper
INFO - 2020-03-04 08:27:28 --> Helper loaded: string_helper
INFO - 2020-03-04 08:27:28 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:27:28 --> Controller Class Initialized
INFO - 2020-03-04 08:27:28 --> Model "M_tiket" initialized
INFO - 2020-03-04 08:27:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 08:27:28 --> Model "M_pesan" initialized
INFO - 2020-03-04 08:27:28 --> Helper loaded: form_helper
INFO - 2020-03-04 08:27:28 --> Form Validation Class Initialized
INFO - 2020-03-04 08:27:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 08:27:28 --> Final output sent to browser
DEBUG - 2020-03-04 08:27:28 --> Total execution time: 0.0075
INFO - 2020-03-04 08:28:07 --> Config Class Initialized
INFO - 2020-03-04 08:28:07 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:28:07 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:28:07 --> Utf8 Class Initialized
INFO - 2020-03-04 08:28:07 --> URI Class Initialized
INFO - 2020-03-04 08:28:07 --> Router Class Initialized
INFO - 2020-03-04 08:28:07 --> Output Class Initialized
INFO - 2020-03-04 08:28:07 --> Security Class Initialized
DEBUG - 2020-03-04 08:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:28:07 --> Input Class Initialized
INFO - 2020-03-04 08:28:07 --> Language Class Initialized
INFO - 2020-03-04 08:28:07 --> Loader Class Initialized
INFO - 2020-03-04 08:28:07 --> Helper loaded: url_helper
INFO - 2020-03-04 08:28:07 --> Helper loaded: string_helper
INFO - 2020-03-04 08:28:07 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:28:07 --> Controller Class Initialized
INFO - 2020-03-04 08:28:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 08:28:07 --> Pagination Class Initialized
INFO - 2020-03-04 08:28:07 --> Model "M_show" initialized
INFO - 2020-03-04 08:28:07 --> Helper loaded: form_helper
INFO - 2020-03-04 08:28:07 --> Form Validation Class Initialized
INFO - 2020-03-04 08:28:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 08:28:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 08:28:07 --> Final output sent to browser
DEBUG - 2020-03-04 08:28:07 --> Total execution time: 0.0068
INFO - 2020-03-04 08:28:08 --> Config Class Initialized
INFO - 2020-03-04 08:28:08 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:28:08 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:28:08 --> Utf8 Class Initialized
INFO - 2020-03-04 08:28:08 --> URI Class Initialized
DEBUG - 2020-03-04 08:28:08 --> No URI present. Default controller set.
INFO - 2020-03-04 08:28:08 --> Router Class Initialized
INFO - 2020-03-04 08:28:08 --> Output Class Initialized
INFO - 2020-03-04 08:28:08 --> Security Class Initialized
DEBUG - 2020-03-04 08:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:28:08 --> Input Class Initialized
INFO - 2020-03-04 08:28:08 --> Language Class Initialized
INFO - 2020-03-04 08:28:08 --> Loader Class Initialized
INFO - 2020-03-04 08:28:08 --> Helper loaded: url_helper
INFO - 2020-03-04 08:28:08 --> Helper loaded: string_helper
INFO - 2020-03-04 08:28:08 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:28:08 --> Controller Class Initialized
INFO - 2020-03-04 08:28:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 08:28:08 --> Pagination Class Initialized
INFO - 2020-03-04 08:28:08 --> Model "M_show" initialized
INFO - 2020-03-04 08:28:08 --> Helper loaded: form_helper
INFO - 2020-03-04 08:28:08 --> Form Validation Class Initialized
INFO - 2020-03-04 08:28:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 08:28:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 08:28:08 --> Final output sent to browser
DEBUG - 2020-03-04 08:28:08 --> Total execution time: 0.0057
INFO - 2020-03-04 09:05:56 --> Config Class Initialized
INFO - 2020-03-04 09:05:56 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:05:56 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:05:56 --> Utf8 Class Initialized
INFO - 2020-03-04 09:05:56 --> URI Class Initialized
DEBUG - 2020-03-04 09:05:56 --> No URI present. Default controller set.
INFO - 2020-03-04 09:05:56 --> Router Class Initialized
INFO - 2020-03-04 09:05:56 --> Output Class Initialized
INFO - 2020-03-04 09:05:56 --> Security Class Initialized
DEBUG - 2020-03-04 09:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:05:56 --> Input Class Initialized
INFO - 2020-03-04 09:05:56 --> Language Class Initialized
INFO - 2020-03-04 09:05:56 --> Loader Class Initialized
INFO - 2020-03-04 09:05:56 --> Helper loaded: url_helper
INFO - 2020-03-04 09:05:56 --> Helper loaded: string_helper
INFO - 2020-03-04 09:05:56 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:05:56 --> Controller Class Initialized
INFO - 2020-03-04 09:05:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:05:56 --> Pagination Class Initialized
INFO - 2020-03-04 09:05:56 --> Model "M_show" initialized
INFO - 2020-03-04 09:05:56 --> Helper loaded: form_helper
INFO - 2020-03-04 09:05:56 --> Form Validation Class Initialized
INFO - 2020-03-04 09:05:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:05:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 09:05:56 --> Final output sent to browser
DEBUG - 2020-03-04 09:05:56 --> Total execution time: 0.0377
INFO - 2020-03-04 09:06:24 --> Config Class Initialized
INFO - 2020-03-04 09:06:24 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:06:24 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:06:24 --> Utf8 Class Initialized
INFO - 2020-03-04 09:06:24 --> URI Class Initialized
DEBUG - 2020-03-04 09:06:24 --> No URI present. Default controller set.
INFO - 2020-03-04 09:06:24 --> Router Class Initialized
INFO - 2020-03-04 09:06:24 --> Output Class Initialized
INFO - 2020-03-04 09:06:24 --> Security Class Initialized
DEBUG - 2020-03-04 09:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:06:24 --> Input Class Initialized
INFO - 2020-03-04 09:06:24 --> Language Class Initialized
INFO - 2020-03-04 09:06:24 --> Loader Class Initialized
INFO - 2020-03-04 09:06:24 --> Helper loaded: url_helper
INFO - 2020-03-04 09:06:24 --> Helper loaded: string_helper
INFO - 2020-03-04 09:06:24 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:06:24 --> Controller Class Initialized
INFO - 2020-03-04 09:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:06:24 --> Pagination Class Initialized
INFO - 2020-03-04 09:06:24 --> Model "M_show" initialized
INFO - 2020-03-04 09:06:24 --> Helper loaded: form_helper
INFO - 2020-03-04 09:06:24 --> Form Validation Class Initialized
INFO - 2020-03-04 09:06:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:06:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 09:06:24 --> Final output sent to browser
DEBUG - 2020-03-04 09:06:24 --> Total execution time: 0.0178
INFO - 2020-03-04 09:09:00 --> Config Class Initialized
INFO - 2020-03-04 09:09:00 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:09:00 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:09:00 --> Utf8 Class Initialized
INFO - 2020-03-04 09:09:00 --> URI Class Initialized
INFO - 2020-03-04 09:09:00 --> Router Class Initialized
INFO - 2020-03-04 09:09:00 --> Output Class Initialized
INFO - 2020-03-04 09:09:00 --> Security Class Initialized
DEBUG - 2020-03-04 09:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:09:00 --> Input Class Initialized
INFO - 2020-03-04 09:09:00 --> Language Class Initialized
INFO - 2020-03-04 09:09:00 --> Loader Class Initialized
INFO - 2020-03-04 09:09:00 --> Helper loaded: url_helper
INFO - 2020-03-04 09:09:00 --> Helper loaded: string_helper
INFO - 2020-03-04 09:09:00 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:09:00 --> Controller Class Initialized
INFO - 2020-03-04 09:09:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:09:00 --> Pagination Class Initialized
INFO - 2020-03-04 09:09:00 --> Model "M_show" initialized
INFO - 2020-03-04 09:09:00 --> Helper loaded: form_helper
INFO - 2020-03-04 09:09:00 --> Form Validation Class Initialized
INFO - 2020-03-04 09:09:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:09:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 09:09:00 --> Final output sent to browser
DEBUG - 2020-03-04 09:09:00 --> Total execution time: 0.0341
INFO - 2020-03-04 09:09:52 --> Config Class Initialized
INFO - 2020-03-04 09:09:52 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:09:52 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:09:52 --> Utf8 Class Initialized
INFO - 2020-03-04 09:09:52 --> URI Class Initialized
INFO - 2020-03-04 09:09:52 --> Router Class Initialized
INFO - 2020-03-04 09:09:52 --> Output Class Initialized
INFO - 2020-03-04 09:09:52 --> Security Class Initialized
DEBUG - 2020-03-04 09:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:09:52 --> Input Class Initialized
INFO - 2020-03-04 09:09:52 --> Language Class Initialized
INFO - 2020-03-04 09:09:52 --> Loader Class Initialized
INFO - 2020-03-04 09:09:52 --> Helper loaded: url_helper
INFO - 2020-03-04 09:09:52 --> Helper loaded: string_helper
INFO - 2020-03-04 09:09:52 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:09:52 --> Controller Class Initialized
INFO - 2020-03-04 09:09:52 --> Model "M_tiket" initialized
INFO - 2020-03-04 09:09:52 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 09:09:52 --> Model "M_pesan" initialized
INFO - 2020-03-04 09:09:52 --> Helper loaded: form_helper
INFO - 2020-03-04 09:09:52 --> Form Validation Class Initialized
INFO - 2020-03-04 09:09:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 09:09:52 --> Final output sent to browser
DEBUG - 2020-03-04 09:09:52 --> Total execution time: 0.0134
INFO - 2020-03-04 09:10:57 --> Config Class Initialized
INFO - 2020-03-04 09:10:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:10:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:10:57 --> Utf8 Class Initialized
INFO - 2020-03-04 09:10:57 --> URI Class Initialized
INFO - 2020-03-04 09:10:57 --> Router Class Initialized
INFO - 2020-03-04 09:10:57 --> Output Class Initialized
INFO - 2020-03-04 09:10:57 --> Security Class Initialized
DEBUG - 2020-03-04 09:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:10:57 --> Input Class Initialized
INFO - 2020-03-04 09:10:57 --> Language Class Initialized
INFO - 2020-03-04 09:10:57 --> Loader Class Initialized
INFO - 2020-03-04 09:10:57 --> Helper loaded: url_helper
INFO - 2020-03-04 09:10:57 --> Helper loaded: string_helper
INFO - 2020-03-04 09:10:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:10:57 --> Controller Class Initialized
INFO - 2020-03-04 09:10:57 --> Model "M_tiket" initialized
INFO - 2020-03-04 09:10:57 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 09:10:57 --> Model "M_pesan" initialized
INFO - 2020-03-04 09:10:57 --> Helper loaded: form_helper
INFO - 2020-03-04 09:10:57 --> Form Validation Class Initialized
INFO - 2020-03-04 09:10:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 09:10:57 --> Final output sent to browser
DEBUG - 2020-03-04 09:10:57 --> Total execution time: 0.0077
INFO - 2020-03-04 09:16:49 --> Config Class Initialized
INFO - 2020-03-04 09:16:49 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:16:49 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:16:49 --> Utf8 Class Initialized
INFO - 2020-03-04 09:16:49 --> URI Class Initialized
DEBUG - 2020-03-04 09:16:49 --> No URI present. Default controller set.
INFO - 2020-03-04 09:16:49 --> Router Class Initialized
INFO - 2020-03-04 09:16:49 --> Output Class Initialized
INFO - 2020-03-04 09:16:49 --> Security Class Initialized
DEBUG - 2020-03-04 09:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:16:49 --> Input Class Initialized
INFO - 2020-03-04 09:16:49 --> Language Class Initialized
INFO - 2020-03-04 09:16:49 --> Loader Class Initialized
INFO - 2020-03-04 09:16:49 --> Helper loaded: url_helper
INFO - 2020-03-04 09:16:49 --> Helper loaded: string_helper
INFO - 2020-03-04 09:16:49 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:16:49 --> Controller Class Initialized
INFO - 2020-03-04 09:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:16:49 --> Pagination Class Initialized
INFO - 2020-03-04 09:16:49 --> Model "M_show" initialized
INFO - 2020-03-04 09:16:49 --> Helper loaded: form_helper
INFO - 2020-03-04 09:16:49 --> Form Validation Class Initialized
INFO - 2020-03-04 09:16:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:16:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 09:16:49 --> Final output sent to browser
DEBUG - 2020-03-04 09:16:49 --> Total execution time: 0.0935
INFO - 2020-03-04 09:38:00 --> Config Class Initialized
INFO - 2020-03-04 09:38:00 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:38:00 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:38:00 --> Utf8 Class Initialized
INFO - 2020-03-04 09:38:00 --> URI Class Initialized
INFO - 2020-03-04 09:38:00 --> Router Class Initialized
INFO - 2020-03-04 09:38:00 --> Output Class Initialized
INFO - 2020-03-04 09:38:00 --> Security Class Initialized
DEBUG - 2020-03-04 09:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:38:00 --> Input Class Initialized
INFO - 2020-03-04 09:38:00 --> Language Class Initialized
INFO - 2020-03-04 09:38:00 --> Loader Class Initialized
INFO - 2020-03-04 09:38:00 --> Helper loaded: url_helper
INFO - 2020-03-04 09:38:00 --> Helper loaded: string_helper
INFO - 2020-03-04 09:38:00 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:38:00 --> Controller Class Initialized
INFO - 2020-03-04 09:38:00 --> Model "M_tiket" initialized
INFO - 2020-03-04 09:38:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 09:38:00 --> Model "M_pesan" initialized
INFO - 2020-03-04 09:38:00 --> Helper loaded: form_helper
INFO - 2020-03-04 09:38:00 --> Form Validation Class Initialized
DEBUG - 2020-03-04 09:38:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-04 09:38:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-04 16:38:00 --> Final output sent to browser
DEBUG - 2020-03-04 16:38:00 --> Total execution time: 0.1649
INFO - 2020-03-04 09:38:06 --> Config Class Initialized
INFO - 2020-03-04 09:38:06 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:38:06 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:38:06 --> Utf8 Class Initialized
INFO - 2020-03-04 09:38:06 --> URI Class Initialized
INFO - 2020-03-04 09:38:06 --> Router Class Initialized
INFO - 2020-03-04 09:38:06 --> Output Class Initialized
INFO - 2020-03-04 09:38:06 --> Security Class Initialized
DEBUG - 2020-03-04 09:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:38:06 --> Input Class Initialized
INFO - 2020-03-04 09:38:06 --> Language Class Initialized
INFO - 2020-03-04 09:38:06 --> Loader Class Initialized
INFO - 2020-03-04 09:38:06 --> Helper loaded: url_helper
INFO - 2020-03-04 09:38:06 --> Helper loaded: string_helper
INFO - 2020-03-04 09:38:06 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:38:06 --> Controller Class Initialized
INFO - 2020-03-04 09:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:38:06 --> Pagination Class Initialized
INFO - 2020-03-04 09:38:06 --> Model "M_show" initialized
INFO - 2020-03-04 09:38:06 --> Helper loaded: form_helper
INFO - 2020-03-04 09:38:06 --> Form Validation Class Initialized
INFO - 2020-03-04 09:38:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:38:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 09:38:06 --> Final output sent to browser
DEBUG - 2020-03-04 09:38:06 --> Total execution time: 0.0083
INFO - 2020-03-04 09:38:19 --> Config Class Initialized
INFO - 2020-03-04 09:38:19 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:38:19 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:38:19 --> Utf8 Class Initialized
INFO - 2020-03-04 09:38:19 --> URI Class Initialized
INFO - 2020-03-04 09:38:19 --> Router Class Initialized
INFO - 2020-03-04 09:38:19 --> Output Class Initialized
INFO - 2020-03-04 09:38:19 --> Security Class Initialized
DEBUG - 2020-03-04 09:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:38:19 --> Input Class Initialized
INFO - 2020-03-04 09:38:19 --> Language Class Initialized
INFO - 2020-03-04 09:38:19 --> Loader Class Initialized
INFO - 2020-03-04 09:38:19 --> Helper loaded: url_helper
INFO - 2020-03-04 09:38:19 --> Helper loaded: string_helper
INFO - 2020-03-04 09:38:19 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:38:19 --> Controller Class Initialized
INFO - 2020-03-04 09:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:38:19 --> Pagination Class Initialized
INFO - 2020-03-04 09:38:19 --> Model "M_show" initialized
INFO - 2020-03-04 09:38:19 --> Helper loaded: form_helper
INFO - 2020-03-04 09:38:19 --> Form Validation Class Initialized
INFO - 2020-03-04 09:38:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:38:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 09:38:19 --> Final output sent to browser
DEBUG - 2020-03-04 09:38:19 --> Total execution time: 0.0061
INFO - 2020-03-04 09:38:27 --> Config Class Initialized
INFO - 2020-03-04 09:38:27 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:38:27 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:38:27 --> Utf8 Class Initialized
INFO - 2020-03-04 09:38:27 --> URI Class Initialized
INFO - 2020-03-04 09:38:27 --> Router Class Initialized
INFO - 2020-03-04 09:38:27 --> Output Class Initialized
INFO - 2020-03-04 09:38:27 --> Security Class Initialized
DEBUG - 2020-03-04 09:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:38:27 --> Input Class Initialized
INFO - 2020-03-04 09:38:27 --> Language Class Initialized
INFO - 2020-03-04 09:38:27 --> Loader Class Initialized
INFO - 2020-03-04 09:38:27 --> Helper loaded: url_helper
INFO - 2020-03-04 09:38:27 --> Helper loaded: string_helper
INFO - 2020-03-04 09:38:27 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:38:27 --> Controller Class Initialized
INFO - 2020-03-04 09:38:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:38:27 --> Pagination Class Initialized
INFO - 2020-03-04 09:38:27 --> Model "M_show" initialized
INFO - 2020-03-04 09:38:27 --> Helper loaded: form_helper
INFO - 2020-03-04 09:38:27 --> Form Validation Class Initialized
INFO - 2020-03-04 09:38:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:38:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-04 09:38:27 --> Final output sent to browser
DEBUG - 2020-03-04 09:38:27 --> Total execution time: 0.0062
INFO - 2020-03-04 09:38:54 --> Config Class Initialized
INFO - 2020-03-04 09:38:54 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:38:54 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:38:54 --> Utf8 Class Initialized
INFO - 2020-03-04 09:38:54 --> URI Class Initialized
INFO - 2020-03-04 09:38:54 --> Router Class Initialized
INFO - 2020-03-04 09:38:54 --> Output Class Initialized
INFO - 2020-03-04 09:38:54 --> Security Class Initialized
DEBUG - 2020-03-04 09:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:38:54 --> Input Class Initialized
INFO - 2020-03-04 09:38:54 --> Language Class Initialized
INFO - 2020-03-04 09:38:54 --> Loader Class Initialized
INFO - 2020-03-04 09:38:54 --> Helper loaded: url_helper
INFO - 2020-03-04 09:38:54 --> Helper loaded: string_helper
INFO - 2020-03-04 09:38:54 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:38:54 --> Controller Class Initialized
INFO - 2020-03-04 09:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:38:54 --> Pagination Class Initialized
INFO - 2020-03-04 09:38:54 --> Model "M_show" initialized
INFO - 2020-03-04 09:38:54 --> Helper loaded: form_helper
INFO - 2020-03-04 09:38:54 --> Form Validation Class Initialized
INFO - 2020-03-04 09:38:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:38:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-04 09:38:54 --> Final output sent to browser
DEBUG - 2020-03-04 09:38:54 --> Total execution time: 0.0121
INFO - 2020-03-04 09:39:14 --> Config Class Initialized
INFO - 2020-03-04 09:39:14 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:39:14 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:39:14 --> Utf8 Class Initialized
INFO - 2020-03-04 09:39:14 --> URI Class Initialized
INFO - 2020-03-04 09:39:14 --> Router Class Initialized
INFO - 2020-03-04 09:39:14 --> Output Class Initialized
INFO - 2020-03-04 09:39:14 --> Security Class Initialized
DEBUG - 2020-03-04 09:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:39:14 --> Input Class Initialized
INFO - 2020-03-04 09:39:14 --> Language Class Initialized
INFO - 2020-03-04 09:39:14 --> Loader Class Initialized
INFO - 2020-03-04 09:39:14 --> Helper loaded: url_helper
INFO - 2020-03-04 09:39:14 --> Helper loaded: string_helper
INFO - 2020-03-04 09:39:14 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:39:14 --> Controller Class Initialized
INFO - 2020-03-04 09:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:39:14 --> Pagination Class Initialized
INFO - 2020-03-04 09:39:14 --> Model "M_show" initialized
INFO - 2020-03-04 09:39:14 --> Helper loaded: form_helper
INFO - 2020-03-04 09:39:14 --> Form Validation Class Initialized
INFO - 2020-03-04 09:39:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:39:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-04 09:39:14 --> Final output sent to browser
DEBUG - 2020-03-04 09:39:14 --> Total execution time: 0.0274
INFO - 2020-03-04 09:39:34 --> Config Class Initialized
INFO - 2020-03-04 09:39:34 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:39:34 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:39:34 --> Utf8 Class Initialized
INFO - 2020-03-04 09:39:34 --> URI Class Initialized
INFO - 2020-03-04 09:39:34 --> Router Class Initialized
INFO - 2020-03-04 09:39:34 --> Output Class Initialized
INFO - 2020-03-04 09:39:34 --> Security Class Initialized
DEBUG - 2020-03-04 09:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:39:34 --> Input Class Initialized
INFO - 2020-03-04 09:39:34 --> Language Class Initialized
INFO - 2020-03-04 09:39:34 --> Loader Class Initialized
INFO - 2020-03-04 09:39:34 --> Helper loaded: url_helper
INFO - 2020-03-04 09:39:34 --> Helper loaded: string_helper
INFO - 2020-03-04 09:39:34 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:39:34 --> Controller Class Initialized
INFO - 2020-03-04 09:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:39:34 --> Pagination Class Initialized
INFO - 2020-03-04 09:39:34 --> Model "M_show" initialized
INFO - 2020-03-04 09:39:34 --> Helper loaded: form_helper
INFO - 2020-03-04 09:39:34 --> Form Validation Class Initialized
INFO - 2020-03-04 09:39:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:39:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-04 09:39:34 --> Final output sent to browser
DEBUG - 2020-03-04 09:39:34 --> Total execution time: 0.0056
INFO - 2020-03-04 09:40:12 --> Config Class Initialized
INFO - 2020-03-04 09:40:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:40:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:40:12 --> Utf8 Class Initialized
INFO - 2020-03-04 09:40:12 --> URI Class Initialized
INFO - 2020-03-04 09:40:12 --> Router Class Initialized
INFO - 2020-03-04 09:40:12 --> Output Class Initialized
INFO - 2020-03-04 09:40:12 --> Security Class Initialized
DEBUG - 2020-03-04 09:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:40:12 --> Input Class Initialized
INFO - 2020-03-04 09:40:12 --> Language Class Initialized
INFO - 2020-03-04 09:40:12 --> Loader Class Initialized
INFO - 2020-03-04 09:40:12 --> Helper loaded: url_helper
INFO - 2020-03-04 09:40:12 --> Helper loaded: string_helper
INFO - 2020-03-04 09:40:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:40:12 --> Controller Class Initialized
INFO - 2020-03-04 09:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:40:12 --> Pagination Class Initialized
INFO - 2020-03-04 09:40:12 --> Model "M_show" initialized
INFO - 2020-03-04 09:40:12 --> Helper loaded: form_helper
INFO - 2020-03-04 09:40:12 --> Form Validation Class Initialized
INFO - 2020-03-04 09:40:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:40:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-04 09:40:12 --> Final output sent to browser
DEBUG - 2020-03-04 09:40:12 --> Total execution time: 0.0055
INFO - 2020-03-04 09:40:22 --> Config Class Initialized
INFO - 2020-03-04 09:40:22 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:40:22 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:40:22 --> Utf8 Class Initialized
INFO - 2020-03-04 09:40:22 --> URI Class Initialized
INFO - 2020-03-04 09:40:22 --> Router Class Initialized
INFO - 2020-03-04 09:40:22 --> Output Class Initialized
INFO - 2020-03-04 09:40:22 --> Security Class Initialized
DEBUG - 2020-03-04 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:40:22 --> Input Class Initialized
INFO - 2020-03-04 09:40:22 --> Language Class Initialized
INFO - 2020-03-04 09:40:22 --> Loader Class Initialized
INFO - 2020-03-04 09:40:22 --> Helper loaded: url_helper
INFO - 2020-03-04 09:40:22 --> Helper loaded: string_helper
INFO - 2020-03-04 09:40:22 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:40:22 --> Controller Class Initialized
INFO - 2020-03-04 09:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:40:22 --> Pagination Class Initialized
INFO - 2020-03-04 09:40:22 --> Model "M_show" initialized
INFO - 2020-03-04 09:40:22 --> Helper loaded: form_helper
INFO - 2020-03-04 09:40:22 --> Form Validation Class Initialized
INFO - 2020-03-04 09:40:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:40:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 09:40:22 --> Final output sent to browser
DEBUG - 2020-03-04 09:40:22 --> Total execution time: 0.0070
INFO - 2020-03-04 09:40:29 --> Config Class Initialized
INFO - 2020-03-04 09:40:29 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:40:29 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:40:29 --> Utf8 Class Initialized
INFO - 2020-03-04 09:40:29 --> URI Class Initialized
INFO - 2020-03-04 09:40:29 --> Router Class Initialized
INFO - 2020-03-04 09:40:29 --> Output Class Initialized
INFO - 2020-03-04 09:40:29 --> Security Class Initialized
DEBUG - 2020-03-04 09:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:40:29 --> Input Class Initialized
INFO - 2020-03-04 09:40:29 --> Language Class Initialized
INFO - 2020-03-04 09:40:29 --> Loader Class Initialized
INFO - 2020-03-04 09:40:29 --> Helper loaded: url_helper
INFO - 2020-03-04 09:40:29 --> Helper loaded: string_helper
INFO - 2020-03-04 09:40:29 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:40:30 --> Controller Class Initialized
INFO - 2020-03-04 09:40:30 --> Model "M_tiket" initialized
INFO - 2020-03-04 09:40:30 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 09:40:30 --> Model "M_pesan" initialized
INFO - 2020-03-04 09:40:30 --> Helper loaded: form_helper
INFO - 2020-03-04 09:40:30 --> Form Validation Class Initialized
INFO - 2020-03-04 09:40:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 09:40:30 --> Final output sent to browser
DEBUG - 2020-03-04 09:40:30 --> Total execution time: 0.5333
INFO - 2020-03-04 09:42:24 --> Config Class Initialized
INFO - 2020-03-04 09:42:24 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:42:24 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:42:24 --> Utf8 Class Initialized
INFO - 2020-03-04 09:42:24 --> URI Class Initialized
INFO - 2020-03-04 09:42:24 --> Router Class Initialized
INFO - 2020-03-04 09:42:24 --> Output Class Initialized
INFO - 2020-03-04 09:42:24 --> Security Class Initialized
DEBUG - 2020-03-04 09:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:42:24 --> Input Class Initialized
INFO - 2020-03-04 09:42:24 --> Language Class Initialized
INFO - 2020-03-04 09:42:24 --> Loader Class Initialized
INFO - 2020-03-04 09:42:24 --> Helper loaded: url_helper
INFO - 2020-03-04 09:42:24 --> Helper loaded: string_helper
INFO - 2020-03-04 09:42:24 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:42:24 --> Controller Class Initialized
INFO - 2020-03-04 09:42:24 --> Model "M_tiket" initialized
INFO - 2020-03-04 09:42:24 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 09:42:24 --> Model "M_pesan" initialized
INFO - 2020-03-04 09:42:24 --> Helper loaded: form_helper
INFO - 2020-03-04 09:42:24 --> Form Validation Class Initialized
INFO - 2020-03-04 09:42:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 09:42:24 --> Final output sent to browser
DEBUG - 2020-03-04 09:42:24 --> Total execution time: 0.0420
INFO - 2020-03-04 09:42:38 --> Config Class Initialized
INFO - 2020-03-04 09:42:38 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:42:38 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:42:38 --> Utf8 Class Initialized
INFO - 2020-03-04 09:42:38 --> URI Class Initialized
INFO - 2020-03-04 09:42:38 --> Router Class Initialized
INFO - 2020-03-04 09:42:38 --> Output Class Initialized
INFO - 2020-03-04 09:42:38 --> Security Class Initialized
DEBUG - 2020-03-04 09:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:42:38 --> Input Class Initialized
INFO - 2020-03-04 09:42:38 --> Language Class Initialized
INFO - 2020-03-04 09:42:38 --> Loader Class Initialized
INFO - 2020-03-04 09:42:38 --> Helper loaded: url_helper
INFO - 2020-03-04 09:42:38 --> Helper loaded: string_helper
INFO - 2020-03-04 09:42:38 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:42:38 --> Controller Class Initialized
INFO - 2020-03-04 09:42:38 --> Model "M_tiket" initialized
INFO - 2020-03-04 09:42:38 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 09:42:38 --> Model "M_pesan" initialized
INFO - 2020-03-04 09:42:38 --> Helper loaded: form_helper
INFO - 2020-03-04 09:42:38 --> Form Validation Class Initialized
INFO - 2020-03-04 09:42:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 09:42:38 --> Final output sent to browser
DEBUG - 2020-03-04 09:42:38 --> Total execution time: 0.0089
INFO - 2020-03-04 09:44:05 --> Config Class Initialized
INFO - 2020-03-04 09:44:05 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:44:05 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:44:05 --> Utf8 Class Initialized
INFO - 2020-03-04 09:44:05 --> URI Class Initialized
INFO - 2020-03-04 09:44:05 --> Router Class Initialized
INFO - 2020-03-04 09:44:05 --> Output Class Initialized
INFO - 2020-03-04 09:44:05 --> Security Class Initialized
DEBUG - 2020-03-04 09:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:44:05 --> Input Class Initialized
INFO - 2020-03-04 09:44:05 --> Language Class Initialized
INFO - 2020-03-04 09:44:05 --> Loader Class Initialized
INFO - 2020-03-04 09:44:05 --> Helper loaded: url_helper
INFO - 2020-03-04 09:44:05 --> Helper loaded: string_helper
INFO - 2020-03-04 09:44:05 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:44:05 --> Controller Class Initialized
INFO - 2020-03-04 09:44:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:44:05 --> Pagination Class Initialized
INFO - 2020-03-04 09:44:05 --> Model "M_show" initialized
INFO - 2020-03-04 09:44:05 --> Helper loaded: form_helper
INFO - 2020-03-04 09:44:05 --> Form Validation Class Initialized
INFO - 2020-03-04 09:44:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:44:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 09:44:05 --> Final output sent to browser
DEBUG - 2020-03-04 09:44:05 --> Total execution time: 0.0369
INFO - 2020-03-04 09:44:06 --> Config Class Initialized
INFO - 2020-03-04 09:44:06 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:44:06 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:44:06 --> Utf8 Class Initialized
INFO - 2020-03-04 09:44:06 --> URI Class Initialized
INFO - 2020-03-04 09:44:06 --> Router Class Initialized
INFO - 2020-03-04 09:44:06 --> Output Class Initialized
INFO - 2020-03-04 09:44:06 --> Security Class Initialized
DEBUG - 2020-03-04 09:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:44:06 --> Input Class Initialized
INFO - 2020-03-04 09:44:06 --> Language Class Initialized
ERROR - 2020-03-04 09:44:06 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 09:44:08 --> Config Class Initialized
INFO - 2020-03-04 09:44:08 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:44:08 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:44:08 --> Utf8 Class Initialized
INFO - 2020-03-04 09:44:08 --> URI Class Initialized
INFO - 2020-03-04 09:44:08 --> Router Class Initialized
INFO - 2020-03-04 09:44:08 --> Output Class Initialized
INFO - 2020-03-04 09:44:08 --> Security Class Initialized
DEBUG - 2020-03-04 09:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:44:08 --> Input Class Initialized
INFO - 2020-03-04 09:44:08 --> Language Class Initialized
INFO - 2020-03-04 09:44:08 --> Loader Class Initialized
INFO - 2020-03-04 09:44:08 --> Helper loaded: url_helper
INFO - 2020-03-04 09:44:08 --> Helper loaded: string_helper
INFO - 2020-03-04 09:44:08 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:44:08 --> Controller Class Initialized
INFO - 2020-03-04 09:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:44:08 --> Pagination Class Initialized
INFO - 2020-03-04 09:44:08 --> Model "M_show" initialized
INFO - 2020-03-04 09:44:08 --> Helper loaded: form_helper
INFO - 2020-03-04 09:44:08 --> Form Validation Class Initialized
INFO - 2020-03-04 09:44:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:44:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 09:44:08 --> Final output sent to browser
DEBUG - 2020-03-04 09:44:08 --> Total execution time: 0.0215
INFO - 2020-03-04 09:46:58 --> Config Class Initialized
INFO - 2020-03-04 09:46:58 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:46:58 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:46:58 --> Utf8 Class Initialized
INFO - 2020-03-04 09:46:58 --> URI Class Initialized
INFO - 2020-03-04 09:46:58 --> Router Class Initialized
INFO - 2020-03-04 09:46:58 --> Output Class Initialized
INFO - 2020-03-04 09:46:58 --> Security Class Initialized
DEBUG - 2020-03-04 09:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:46:58 --> Input Class Initialized
INFO - 2020-03-04 09:46:58 --> Language Class Initialized
INFO - 2020-03-04 09:46:58 --> Loader Class Initialized
INFO - 2020-03-04 09:46:58 --> Helper loaded: url_helper
INFO - 2020-03-04 09:46:58 --> Helper loaded: string_helper
INFO - 2020-03-04 09:46:58 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:46:58 --> Controller Class Initialized
INFO - 2020-03-04 09:46:58 --> Model "M_tiket" initialized
INFO - 2020-03-04 09:46:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 09:46:58 --> Model "M_pesan" initialized
INFO - 2020-03-04 09:46:58 --> Helper loaded: form_helper
INFO - 2020-03-04 09:46:58 --> Form Validation Class Initialized
DEBUG - 2020-03-04 09:46:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-04 09:46:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-04 09:46:58 --> Final output sent to browser
DEBUG - 2020-03-04 09:46:58 --> Total execution time: 0.0374
INFO - 2020-03-04 09:47:09 --> Config Class Initialized
INFO - 2020-03-04 09:47:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:47:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:47:09 --> Utf8 Class Initialized
INFO - 2020-03-04 09:47:09 --> URI Class Initialized
INFO - 2020-03-04 09:47:09 --> Router Class Initialized
INFO - 2020-03-04 09:47:09 --> Output Class Initialized
INFO - 2020-03-04 09:47:09 --> Security Class Initialized
DEBUG - 2020-03-04 09:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:47:09 --> Input Class Initialized
INFO - 2020-03-04 09:47:09 --> Language Class Initialized
INFO - 2020-03-04 09:47:09 --> Loader Class Initialized
INFO - 2020-03-04 09:47:09 --> Helper loaded: url_helper
INFO - 2020-03-04 09:47:09 --> Helper loaded: string_helper
INFO - 2020-03-04 09:47:09 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:47:09 --> Controller Class Initialized
INFO - 2020-03-04 09:47:09 --> Model "M_tiket" initialized
INFO - 2020-03-04 09:47:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 09:47:09 --> Model "M_pesan" initialized
INFO - 2020-03-04 09:47:09 --> Helper loaded: form_helper
INFO - 2020-03-04 09:47:09 --> Form Validation Class Initialized
INFO - 2020-03-04 09:47:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 09:47:09 --> Final output sent to browser
DEBUG - 2020-03-04 09:47:09 --> Total execution time: 0.0108
INFO - 2020-03-04 09:52:21 --> Config Class Initialized
INFO - 2020-03-04 09:52:21 --> Hooks Class Initialized
DEBUG - 2020-03-04 09:52:21 --> UTF-8 Support Enabled
INFO - 2020-03-04 09:52:21 --> Utf8 Class Initialized
INFO - 2020-03-04 09:52:21 --> URI Class Initialized
INFO - 2020-03-04 09:52:21 --> Router Class Initialized
INFO - 2020-03-04 09:52:21 --> Output Class Initialized
INFO - 2020-03-04 09:52:21 --> Security Class Initialized
DEBUG - 2020-03-04 09:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 09:52:21 --> Input Class Initialized
INFO - 2020-03-04 09:52:21 --> Language Class Initialized
INFO - 2020-03-04 09:52:21 --> Loader Class Initialized
INFO - 2020-03-04 09:52:21 --> Helper loaded: url_helper
INFO - 2020-03-04 09:52:21 --> Helper loaded: string_helper
INFO - 2020-03-04 09:52:21 --> Database Driver Class Initialized
DEBUG - 2020-03-04 09:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 09:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 09:52:21 --> Controller Class Initialized
INFO - 2020-03-04 09:52:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 09:52:21 --> Pagination Class Initialized
INFO - 2020-03-04 09:52:21 --> Model "M_show" initialized
INFO - 2020-03-04 09:52:21 --> Helper loaded: form_helper
INFO - 2020-03-04 09:52:21 --> Form Validation Class Initialized
INFO - 2020-03-04 09:52:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 09:52:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 09:52:21 --> Final output sent to browser
DEBUG - 2020-03-04 09:52:21 --> Total execution time: 0.0367
INFO - 2020-03-04 10:24:40 --> Config Class Initialized
INFO - 2020-03-04 10:24:40 --> Hooks Class Initialized
DEBUG - 2020-03-04 10:24:40 --> UTF-8 Support Enabled
INFO - 2020-03-04 10:24:40 --> Utf8 Class Initialized
INFO - 2020-03-04 10:24:40 --> URI Class Initialized
DEBUG - 2020-03-04 10:24:40 --> No URI present. Default controller set.
INFO - 2020-03-04 10:24:40 --> Router Class Initialized
INFO - 2020-03-04 10:24:40 --> Output Class Initialized
INFO - 2020-03-04 10:24:40 --> Security Class Initialized
DEBUG - 2020-03-04 10:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 10:24:40 --> Input Class Initialized
INFO - 2020-03-04 10:24:40 --> Language Class Initialized
INFO - 2020-03-04 10:24:40 --> Loader Class Initialized
INFO - 2020-03-04 10:24:40 --> Helper loaded: url_helper
INFO - 2020-03-04 10:24:40 --> Helper loaded: string_helper
INFO - 2020-03-04 10:24:40 --> Database Driver Class Initialized
DEBUG - 2020-03-04 10:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 10:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 10:24:40 --> Controller Class Initialized
INFO - 2020-03-04 10:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 10:24:40 --> Pagination Class Initialized
INFO - 2020-03-04 10:24:40 --> Model "M_show" initialized
INFO - 2020-03-04 10:24:40 --> Helper loaded: form_helper
INFO - 2020-03-04 10:24:40 --> Form Validation Class Initialized
INFO - 2020-03-04 10:24:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 10:24:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 10:24:40 --> Final output sent to browser
DEBUG - 2020-03-04 10:24:40 --> Total execution time: 0.0601
INFO - 2020-03-04 10:34:06 --> Config Class Initialized
INFO - 2020-03-04 10:34:06 --> Hooks Class Initialized
DEBUG - 2020-03-04 10:34:06 --> UTF-8 Support Enabled
INFO - 2020-03-04 10:34:06 --> Utf8 Class Initialized
INFO - 2020-03-04 10:34:06 --> URI Class Initialized
DEBUG - 2020-03-04 10:34:06 --> No URI present. Default controller set.
INFO - 2020-03-04 10:34:06 --> Router Class Initialized
INFO - 2020-03-04 10:34:06 --> Output Class Initialized
INFO - 2020-03-04 10:34:06 --> Security Class Initialized
DEBUG - 2020-03-04 10:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 10:34:06 --> Input Class Initialized
INFO - 2020-03-04 10:34:06 --> Language Class Initialized
INFO - 2020-03-04 10:34:06 --> Loader Class Initialized
INFO - 2020-03-04 10:34:06 --> Helper loaded: url_helper
INFO - 2020-03-04 10:34:06 --> Helper loaded: string_helper
INFO - 2020-03-04 10:34:06 --> Database Driver Class Initialized
DEBUG - 2020-03-04 10:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 10:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 10:34:06 --> Controller Class Initialized
INFO - 2020-03-04 10:34:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 10:34:06 --> Pagination Class Initialized
INFO - 2020-03-04 10:34:06 --> Model "M_show" initialized
INFO - 2020-03-04 10:34:06 --> Helper loaded: form_helper
INFO - 2020-03-04 10:34:06 --> Form Validation Class Initialized
INFO - 2020-03-04 10:34:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 10:34:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 10:34:06 --> Final output sent to browser
DEBUG - 2020-03-04 10:34:06 --> Total execution time: 0.0295
INFO - 2020-03-04 10:59:59 --> Config Class Initialized
INFO - 2020-03-04 10:59:59 --> Hooks Class Initialized
DEBUG - 2020-03-04 10:59:59 --> UTF-8 Support Enabled
INFO - 2020-03-04 10:59:59 --> Utf8 Class Initialized
INFO - 2020-03-04 10:59:59 --> URI Class Initialized
INFO - 2020-03-04 10:59:59 --> Router Class Initialized
INFO - 2020-03-04 10:59:59 --> Output Class Initialized
INFO - 2020-03-04 10:59:59 --> Security Class Initialized
DEBUG - 2020-03-04 10:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 10:59:59 --> Input Class Initialized
INFO - 2020-03-04 10:59:59 --> Language Class Initialized
INFO - 2020-03-04 10:59:59 --> Loader Class Initialized
INFO - 2020-03-04 10:59:59 --> Helper loaded: url_helper
INFO - 2020-03-04 10:59:59 --> Helper loaded: string_helper
INFO - 2020-03-04 10:59:59 --> Database Driver Class Initialized
DEBUG - 2020-03-04 11:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 11:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 11:00:00 --> Controller Class Initialized
INFO - 2020-03-04 11:00:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 11:00:00 --> Pagination Class Initialized
INFO - 2020-03-04 11:00:00 --> Model "M_show" initialized
INFO - 2020-03-04 11:00:00 --> Helper loaded: form_helper
INFO - 2020-03-04 11:00:00 --> Form Validation Class Initialized
INFO - 2020-03-04 11:00:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 11:00:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 11:00:00 --> Final output sent to browser
DEBUG - 2020-03-04 11:00:00 --> Total execution time: 0.3139
INFO - 2020-03-04 11:15:37 --> Config Class Initialized
INFO - 2020-03-04 11:15:37 --> Hooks Class Initialized
DEBUG - 2020-03-04 11:15:37 --> UTF-8 Support Enabled
INFO - 2020-03-04 11:15:37 --> Utf8 Class Initialized
INFO - 2020-03-04 11:15:37 --> URI Class Initialized
DEBUG - 2020-03-04 11:15:37 --> No URI present. Default controller set.
INFO - 2020-03-04 11:15:37 --> Router Class Initialized
INFO - 2020-03-04 11:15:37 --> Output Class Initialized
INFO - 2020-03-04 11:15:37 --> Security Class Initialized
DEBUG - 2020-03-04 11:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 11:15:37 --> Input Class Initialized
INFO - 2020-03-04 11:15:37 --> Language Class Initialized
INFO - 2020-03-04 11:15:37 --> Loader Class Initialized
INFO - 2020-03-04 11:15:37 --> Helper loaded: url_helper
INFO - 2020-03-04 11:15:37 --> Helper loaded: string_helper
INFO - 2020-03-04 11:15:37 --> Database Driver Class Initialized
DEBUG - 2020-03-04 11:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 11:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 11:15:37 --> Controller Class Initialized
INFO - 2020-03-04 11:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 11:15:37 --> Pagination Class Initialized
INFO - 2020-03-04 11:15:37 --> Model "M_show" initialized
INFO - 2020-03-04 11:15:37 --> Helper loaded: form_helper
INFO - 2020-03-04 11:15:37 --> Form Validation Class Initialized
INFO - 2020-03-04 11:15:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 11:15:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 11:15:37 --> Final output sent to browser
DEBUG - 2020-03-04 11:15:37 --> Total execution time: 0.0300
INFO - 2020-03-04 11:15:49 --> Config Class Initialized
INFO - 2020-03-04 11:15:49 --> Hooks Class Initialized
DEBUG - 2020-03-04 11:15:49 --> UTF-8 Support Enabled
INFO - 2020-03-04 11:15:49 --> Utf8 Class Initialized
INFO - 2020-03-04 11:15:49 --> URI Class Initialized
INFO - 2020-03-04 11:15:49 --> Router Class Initialized
INFO - 2020-03-04 11:15:49 --> Output Class Initialized
INFO - 2020-03-04 11:15:49 --> Security Class Initialized
DEBUG - 2020-03-04 11:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 11:15:49 --> Input Class Initialized
INFO - 2020-03-04 11:15:49 --> Language Class Initialized
INFO - 2020-03-04 11:15:49 --> Loader Class Initialized
INFO - 2020-03-04 11:15:49 --> Helper loaded: url_helper
INFO - 2020-03-04 11:15:49 --> Helper loaded: string_helper
INFO - 2020-03-04 11:15:49 --> Database Driver Class Initialized
DEBUG - 2020-03-04 11:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 11:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 11:15:49 --> Controller Class Initialized
INFO - 2020-03-04 11:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 11:15:49 --> Pagination Class Initialized
INFO - 2020-03-04 11:15:49 --> Model "M_show" initialized
INFO - 2020-03-04 11:15:49 --> Helper loaded: form_helper
INFO - 2020-03-04 11:15:49 --> Form Validation Class Initialized
INFO - 2020-03-04 11:15:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 11:15:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 11:15:49 --> Final output sent to browser
DEBUG - 2020-03-04 11:15:49 --> Total execution time: 0.0091
INFO - 2020-03-04 11:15:50 --> Config Class Initialized
INFO - 2020-03-04 11:15:50 --> Hooks Class Initialized
DEBUG - 2020-03-04 11:15:50 --> UTF-8 Support Enabled
INFO - 2020-03-04 11:15:50 --> Utf8 Class Initialized
INFO - 2020-03-04 11:15:50 --> URI Class Initialized
INFO - 2020-03-04 11:15:50 --> Router Class Initialized
INFO - 2020-03-04 11:15:50 --> Output Class Initialized
INFO - 2020-03-04 11:15:50 --> Security Class Initialized
DEBUG - 2020-03-04 11:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 11:15:50 --> Input Class Initialized
INFO - 2020-03-04 11:15:50 --> Language Class Initialized
ERROR - 2020-03-04 11:15:50 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 11:15:53 --> Config Class Initialized
INFO - 2020-03-04 11:15:53 --> Hooks Class Initialized
DEBUG - 2020-03-04 11:15:53 --> UTF-8 Support Enabled
INFO - 2020-03-04 11:15:53 --> Utf8 Class Initialized
INFO - 2020-03-04 11:15:53 --> URI Class Initialized
INFO - 2020-03-04 11:15:53 --> Router Class Initialized
INFO - 2020-03-04 11:15:53 --> Output Class Initialized
INFO - 2020-03-04 11:15:53 --> Security Class Initialized
DEBUG - 2020-03-04 11:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 11:15:53 --> Input Class Initialized
INFO - 2020-03-04 11:15:53 --> Language Class Initialized
INFO - 2020-03-04 11:15:53 --> Loader Class Initialized
INFO - 2020-03-04 11:15:53 --> Helper loaded: url_helper
INFO - 2020-03-04 11:15:53 --> Helper loaded: string_helper
INFO - 2020-03-04 11:15:53 --> Database Driver Class Initialized
DEBUG - 2020-03-04 11:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 11:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 11:15:53 --> Controller Class Initialized
INFO - 2020-03-04 11:15:53 --> Model "M_tiket" initialized
INFO - 2020-03-04 11:15:53 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 11:15:53 --> Model "M_pesan" initialized
INFO - 2020-03-04 11:15:53 --> Helper loaded: form_helper
INFO - 2020-03-04 11:15:53 --> Form Validation Class Initialized
INFO - 2020-03-04 11:15:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 11:15:53 --> Final output sent to browser
DEBUG - 2020-03-04 11:15:53 --> Total execution time: 0.0786
INFO - 2020-03-04 11:16:15 --> Config Class Initialized
INFO - 2020-03-04 11:16:15 --> Hooks Class Initialized
DEBUG - 2020-03-04 11:16:15 --> UTF-8 Support Enabled
INFO - 2020-03-04 11:16:15 --> Utf8 Class Initialized
INFO - 2020-03-04 11:16:15 --> URI Class Initialized
DEBUG - 2020-03-04 11:16:15 --> No URI present. Default controller set.
INFO - 2020-03-04 11:16:15 --> Router Class Initialized
INFO - 2020-03-04 11:16:15 --> Output Class Initialized
INFO - 2020-03-04 11:16:15 --> Security Class Initialized
DEBUG - 2020-03-04 11:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 11:16:15 --> Input Class Initialized
INFO - 2020-03-04 11:16:15 --> Language Class Initialized
INFO - 2020-03-04 11:16:15 --> Loader Class Initialized
INFO - 2020-03-04 11:16:15 --> Helper loaded: url_helper
INFO - 2020-03-04 11:16:15 --> Helper loaded: string_helper
INFO - 2020-03-04 11:16:15 --> Database Driver Class Initialized
DEBUG - 2020-03-04 11:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 11:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 11:16:15 --> Controller Class Initialized
INFO - 2020-03-04 11:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 11:16:15 --> Pagination Class Initialized
INFO - 2020-03-04 11:16:15 --> Model "M_show" initialized
INFO - 2020-03-04 11:16:15 --> Helper loaded: form_helper
INFO - 2020-03-04 11:16:15 --> Form Validation Class Initialized
INFO - 2020-03-04 11:16:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 11:16:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 11:16:15 --> Final output sent to browser
DEBUG - 2020-03-04 11:16:15 --> Total execution time: 0.0066
INFO - 2020-03-04 11:45:39 --> Config Class Initialized
INFO - 2020-03-04 11:45:39 --> Hooks Class Initialized
DEBUG - 2020-03-04 11:45:39 --> UTF-8 Support Enabled
INFO - 2020-03-04 11:45:39 --> Utf8 Class Initialized
INFO - 2020-03-04 11:45:39 --> URI Class Initialized
INFO - 2020-03-04 11:45:39 --> Router Class Initialized
INFO - 2020-03-04 11:45:39 --> Output Class Initialized
INFO - 2020-03-04 11:45:39 --> Security Class Initialized
DEBUG - 2020-03-04 11:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 11:45:39 --> Input Class Initialized
INFO - 2020-03-04 11:45:39 --> Language Class Initialized
INFO - 2020-03-04 11:45:39 --> Loader Class Initialized
INFO - 2020-03-04 11:45:39 --> Helper loaded: url_helper
INFO - 2020-03-04 11:45:39 --> Helper loaded: string_helper
INFO - 2020-03-04 11:45:39 --> Database Driver Class Initialized
DEBUG - 2020-03-04 11:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 11:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 11:45:39 --> Controller Class Initialized
INFO - 2020-03-04 11:45:39 --> Model "M_tiket" initialized
INFO - 2020-03-04 11:45:39 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 11:45:39 --> Model "M_pesan" initialized
INFO - 2020-03-04 11:45:39 --> Helper loaded: form_helper
INFO - 2020-03-04 11:45:39 --> Form Validation Class Initialized
INFO - 2020-03-04 11:45:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 11:45:39 --> Final output sent to browser
DEBUG - 2020-03-04 11:45:39 --> Total execution time: 0.0648
INFO - 2020-03-04 12:03:16 --> Config Class Initialized
INFO - 2020-03-04 12:03:16 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:03:16 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:03:16 --> Utf8 Class Initialized
INFO - 2020-03-04 12:03:16 --> URI Class Initialized
INFO - 2020-03-04 12:03:16 --> Router Class Initialized
INFO - 2020-03-04 12:03:16 --> Output Class Initialized
INFO - 2020-03-04 12:03:16 --> Security Class Initialized
DEBUG - 2020-03-04 12:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:03:16 --> Input Class Initialized
INFO - 2020-03-04 12:03:16 --> Language Class Initialized
INFO - 2020-03-04 12:03:16 --> Loader Class Initialized
INFO - 2020-03-04 12:03:16 --> Helper loaded: url_helper
INFO - 2020-03-04 12:03:16 --> Helper loaded: string_helper
INFO - 2020-03-04 12:03:16 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:03:16 --> Controller Class Initialized
INFO - 2020-03-04 12:03:16 --> Model "M_tiket" initialized
INFO - 2020-03-04 12:03:16 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 12:03:16 --> Model "M_pesan" initialized
INFO - 2020-03-04 12:03:16 --> Helper loaded: form_helper
INFO - 2020-03-04 12:03:16 --> Form Validation Class Initialized
INFO - 2020-03-04 12:03:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 12:03:16 --> Final output sent to browser
DEBUG - 2020-03-04 12:03:16 --> Total execution time: 0.0327
INFO - 2020-03-04 12:10:38 --> Config Class Initialized
INFO - 2020-03-04 12:10:38 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:10:38 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:10:38 --> Utf8 Class Initialized
INFO - 2020-03-04 12:10:38 --> URI Class Initialized
DEBUG - 2020-03-04 12:10:38 --> No URI present. Default controller set.
INFO - 2020-03-04 12:10:38 --> Router Class Initialized
INFO - 2020-03-04 12:10:38 --> Output Class Initialized
INFO - 2020-03-04 12:10:38 --> Security Class Initialized
DEBUG - 2020-03-04 12:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:10:38 --> Input Class Initialized
INFO - 2020-03-04 12:10:38 --> Language Class Initialized
INFO - 2020-03-04 12:10:38 --> Loader Class Initialized
INFO - 2020-03-04 12:10:38 --> Helper loaded: url_helper
INFO - 2020-03-04 12:10:38 --> Helper loaded: string_helper
INFO - 2020-03-04 12:10:38 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:10:38 --> Controller Class Initialized
INFO - 2020-03-04 12:10:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 12:10:38 --> Pagination Class Initialized
INFO - 2020-03-04 12:10:38 --> Model "M_show" initialized
INFO - 2020-03-04 12:10:38 --> Helper loaded: form_helper
INFO - 2020-03-04 12:10:38 --> Form Validation Class Initialized
INFO - 2020-03-04 12:10:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 12:10:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 12:10:38 --> Final output sent to browser
DEBUG - 2020-03-04 12:10:38 --> Total execution time: 0.0916
INFO - 2020-03-04 12:10:48 --> Config Class Initialized
INFO - 2020-03-04 12:10:48 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:10:48 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:10:48 --> Utf8 Class Initialized
INFO - 2020-03-04 12:10:48 --> URI Class Initialized
INFO - 2020-03-04 12:10:48 --> Router Class Initialized
INFO - 2020-03-04 12:10:48 --> Output Class Initialized
INFO - 2020-03-04 12:10:48 --> Security Class Initialized
DEBUG - 2020-03-04 12:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:10:48 --> Input Class Initialized
INFO - 2020-03-04 12:10:48 --> Language Class Initialized
INFO - 2020-03-04 12:10:48 --> Loader Class Initialized
INFO - 2020-03-04 12:10:48 --> Helper loaded: url_helper
INFO - 2020-03-04 12:10:48 --> Helper loaded: string_helper
INFO - 2020-03-04 12:10:48 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:10:48 --> Controller Class Initialized
INFO - 2020-03-04 12:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 12:10:48 --> Pagination Class Initialized
INFO - 2020-03-04 12:10:48 --> Model "M_show" initialized
INFO - 2020-03-04 12:10:48 --> Helper loaded: form_helper
INFO - 2020-03-04 12:10:48 --> Form Validation Class Initialized
INFO - 2020-03-04 12:10:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 12:10:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 12:10:48 --> Final output sent to browser
DEBUG - 2020-03-04 12:10:48 --> Total execution time: 0.0117
INFO - 2020-03-04 12:10:53 --> Config Class Initialized
INFO - 2020-03-04 12:10:53 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:10:53 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:10:53 --> Utf8 Class Initialized
INFO - 2020-03-04 12:10:53 --> URI Class Initialized
INFO - 2020-03-04 12:10:53 --> Router Class Initialized
INFO - 2020-03-04 12:10:53 --> Output Class Initialized
INFO - 2020-03-04 12:10:53 --> Security Class Initialized
DEBUG - 2020-03-04 12:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:10:53 --> Input Class Initialized
INFO - 2020-03-04 12:10:53 --> Language Class Initialized
INFO - 2020-03-04 12:10:53 --> Loader Class Initialized
INFO - 2020-03-04 12:10:53 --> Helper loaded: url_helper
INFO - 2020-03-04 12:10:53 --> Helper loaded: string_helper
INFO - 2020-03-04 12:10:53 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:10:53 --> Controller Class Initialized
INFO - 2020-03-04 12:10:53 --> Model "M_tiket" initialized
INFO - 2020-03-04 12:10:53 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 12:10:53 --> Model "M_pesan" initialized
INFO - 2020-03-04 12:10:53 --> Helper loaded: form_helper
INFO - 2020-03-04 12:10:53 --> Form Validation Class Initialized
INFO - 2020-03-04 12:10:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 12:10:53 --> Final output sent to browser
DEBUG - 2020-03-04 12:10:53 --> Total execution time: 0.0234
INFO - 2020-03-04 12:11:35 --> Config Class Initialized
INFO - 2020-03-04 12:11:35 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:11:35 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:11:35 --> Utf8 Class Initialized
INFO - 2020-03-04 12:11:35 --> URI Class Initialized
INFO - 2020-03-04 12:11:35 --> Router Class Initialized
INFO - 2020-03-04 12:11:35 --> Output Class Initialized
INFO - 2020-03-04 12:11:35 --> Security Class Initialized
DEBUG - 2020-03-04 12:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:11:35 --> Input Class Initialized
INFO - 2020-03-04 12:11:35 --> Language Class Initialized
INFO - 2020-03-04 12:11:35 --> Loader Class Initialized
INFO - 2020-03-04 12:11:35 --> Helper loaded: url_helper
INFO - 2020-03-04 12:11:35 --> Helper loaded: string_helper
INFO - 2020-03-04 12:11:35 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:11:35 --> Controller Class Initialized
INFO - 2020-03-04 12:11:35 --> Model "M_tiket" initialized
INFO - 2020-03-04 12:11:35 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 12:11:35 --> Model "M_pesan" initialized
INFO - 2020-03-04 12:11:35 --> Helper loaded: form_helper
INFO - 2020-03-04 12:11:35 --> Form Validation Class Initialized
INFO - 2020-03-04 12:11:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 12:11:35 --> Final output sent to browser
DEBUG - 2020-03-04 12:11:35 --> Total execution time: 0.0077
INFO - 2020-03-04 12:26:29 --> Config Class Initialized
INFO - 2020-03-04 12:26:29 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:26:29 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:26:29 --> Utf8 Class Initialized
INFO - 2020-03-04 12:26:29 --> URI Class Initialized
INFO - 2020-03-04 12:26:29 --> Router Class Initialized
INFO - 2020-03-04 12:26:29 --> Output Class Initialized
INFO - 2020-03-04 12:26:30 --> Security Class Initialized
DEBUG - 2020-03-04 12:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:26:30 --> Input Class Initialized
INFO - 2020-03-04 12:26:30 --> Language Class Initialized
INFO - 2020-03-04 12:26:30 --> Loader Class Initialized
INFO - 2020-03-04 12:26:30 --> Helper loaded: url_helper
INFO - 2020-03-04 12:26:30 --> Helper loaded: string_helper
INFO - 2020-03-04 12:26:30 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:26:30 --> Controller Class Initialized
INFO - 2020-03-04 12:26:30 --> Model "M_tiket" initialized
INFO - 2020-03-04 12:26:30 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 12:26:30 --> Model "M_pesan" initialized
INFO - 2020-03-04 12:26:30 --> Helper loaded: form_helper
INFO - 2020-03-04 12:26:30 --> Form Validation Class Initialized
DEBUG - 2020-03-04 12:26:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-04 12:26:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-04 19:26:30 --> Final output sent to browser
DEBUG - 2020-03-04 19:26:30 --> Total execution time: 0.2090
INFO - 2020-03-04 12:26:49 --> Config Class Initialized
INFO - 2020-03-04 12:26:49 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:26:49 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:26:49 --> Utf8 Class Initialized
INFO - 2020-03-04 12:26:49 --> URI Class Initialized
INFO - 2020-03-04 12:26:49 --> Router Class Initialized
INFO - 2020-03-04 12:26:49 --> Output Class Initialized
INFO - 2020-03-04 12:26:49 --> Security Class Initialized
DEBUG - 2020-03-04 12:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:26:49 --> Input Class Initialized
INFO - 2020-03-04 12:26:49 --> Language Class Initialized
INFO - 2020-03-04 12:26:49 --> Loader Class Initialized
INFO - 2020-03-04 12:26:49 --> Helper loaded: url_helper
INFO - 2020-03-04 12:26:49 --> Helper loaded: string_helper
INFO - 2020-03-04 12:26:49 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:26:49 --> Controller Class Initialized
INFO - 2020-03-04 12:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 12:26:49 --> Pagination Class Initialized
INFO - 2020-03-04 12:26:49 --> Model "M_show" initialized
INFO - 2020-03-04 12:26:49 --> Helper loaded: form_helper
INFO - 2020-03-04 12:26:49 --> Form Validation Class Initialized
INFO - 2020-03-04 12:26:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 12:26:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 12:26:49 --> Final output sent to browser
DEBUG - 2020-03-04 12:26:49 --> Total execution time: 0.0080
INFO - 2020-03-04 12:27:17 --> Config Class Initialized
INFO - 2020-03-04 12:27:17 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:27:17 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:27:17 --> Utf8 Class Initialized
INFO - 2020-03-04 12:27:17 --> URI Class Initialized
INFO - 2020-03-04 12:27:17 --> Router Class Initialized
INFO - 2020-03-04 12:27:17 --> Output Class Initialized
INFO - 2020-03-04 12:27:17 --> Security Class Initialized
DEBUG - 2020-03-04 12:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:27:17 --> Input Class Initialized
INFO - 2020-03-04 12:27:17 --> Language Class Initialized
INFO - 2020-03-04 12:27:17 --> Loader Class Initialized
INFO - 2020-03-04 12:27:17 --> Helper loaded: url_helper
INFO - 2020-03-04 12:27:17 --> Helper loaded: string_helper
INFO - 2020-03-04 12:27:17 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:27:17 --> Controller Class Initialized
INFO - 2020-03-04 12:27:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 12:27:17 --> Pagination Class Initialized
INFO - 2020-03-04 12:27:17 --> Model "M_show" initialized
INFO - 2020-03-04 12:27:17 --> Helper loaded: form_helper
INFO - 2020-03-04 12:27:17 --> Form Validation Class Initialized
INFO - 2020-03-04 12:27:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 12:27:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-04 12:27:17 --> Final output sent to browser
DEBUG - 2020-03-04 12:27:17 --> Total execution time: 0.0207
INFO - 2020-03-04 12:27:38 --> Config Class Initialized
INFO - 2020-03-04 12:27:38 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:27:38 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:27:38 --> Utf8 Class Initialized
INFO - 2020-03-04 12:27:38 --> URI Class Initialized
INFO - 2020-03-04 12:27:38 --> Router Class Initialized
INFO - 2020-03-04 12:27:38 --> Output Class Initialized
INFO - 2020-03-04 12:27:38 --> Security Class Initialized
DEBUG - 2020-03-04 12:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:27:38 --> Input Class Initialized
INFO - 2020-03-04 12:27:38 --> Language Class Initialized
INFO - 2020-03-04 12:27:38 --> Loader Class Initialized
INFO - 2020-03-04 12:27:38 --> Helper loaded: url_helper
INFO - 2020-03-04 12:27:38 --> Helper loaded: string_helper
INFO - 2020-03-04 12:27:38 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:27:38 --> Controller Class Initialized
INFO - 2020-03-04 12:27:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 12:27:38 --> Pagination Class Initialized
INFO - 2020-03-04 12:27:38 --> Model "M_show" initialized
INFO - 2020-03-04 12:27:38 --> Helper loaded: form_helper
INFO - 2020-03-04 12:27:38 --> Form Validation Class Initialized
INFO - 2020-03-04 12:27:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 12:27:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 12:27:38 --> Final output sent to browser
DEBUG - 2020-03-04 12:27:38 --> Total execution time: 0.0068
INFO - 2020-03-04 12:27:52 --> Config Class Initialized
INFO - 2020-03-04 12:27:52 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:27:52 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:27:52 --> Utf8 Class Initialized
INFO - 2020-03-04 12:27:52 --> URI Class Initialized
DEBUG - 2020-03-04 12:27:52 --> No URI present. Default controller set.
INFO - 2020-03-04 12:27:52 --> Router Class Initialized
INFO - 2020-03-04 12:27:52 --> Output Class Initialized
INFO - 2020-03-04 12:27:52 --> Security Class Initialized
DEBUG - 2020-03-04 12:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:27:52 --> Input Class Initialized
INFO - 2020-03-04 12:27:52 --> Language Class Initialized
INFO - 2020-03-04 12:27:52 --> Loader Class Initialized
INFO - 2020-03-04 12:27:52 --> Helper loaded: url_helper
INFO - 2020-03-04 12:27:52 --> Helper loaded: string_helper
INFO - 2020-03-04 12:27:52 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:27:52 --> Controller Class Initialized
INFO - 2020-03-04 12:27:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 12:27:52 --> Pagination Class Initialized
INFO - 2020-03-04 12:27:52 --> Model "M_show" initialized
INFO - 2020-03-04 12:27:52 --> Helper loaded: form_helper
INFO - 2020-03-04 12:27:52 --> Form Validation Class Initialized
INFO - 2020-03-04 12:27:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 12:27:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 12:27:52 --> Final output sent to browser
DEBUG - 2020-03-04 12:27:52 --> Total execution time: 0.0872
INFO - 2020-03-04 12:27:59 --> Config Class Initialized
INFO - 2020-03-04 12:27:59 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:27:59 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:27:59 --> Utf8 Class Initialized
INFO - 2020-03-04 12:27:59 --> URI Class Initialized
INFO - 2020-03-04 12:27:59 --> Router Class Initialized
INFO - 2020-03-04 12:27:59 --> Output Class Initialized
INFO - 2020-03-04 12:27:59 --> Security Class Initialized
DEBUG - 2020-03-04 12:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:27:59 --> Input Class Initialized
INFO - 2020-03-04 12:27:59 --> Language Class Initialized
INFO - 2020-03-04 12:27:59 --> Loader Class Initialized
INFO - 2020-03-04 12:27:59 --> Helper loaded: url_helper
INFO - 2020-03-04 12:27:59 --> Helper loaded: string_helper
INFO - 2020-03-04 12:27:59 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:27:59 --> Controller Class Initialized
INFO - 2020-03-04 12:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 12:27:59 --> Pagination Class Initialized
INFO - 2020-03-04 12:27:59 --> Model "M_show" initialized
INFO - 2020-03-04 12:27:59 --> Helper loaded: form_helper
INFO - 2020-03-04 12:27:59 --> Form Validation Class Initialized
INFO - 2020-03-04 12:27:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 12:27:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 12:27:59 --> Final output sent to browser
DEBUG - 2020-03-04 12:27:59 --> Total execution time: 0.0070
INFO - 2020-03-04 12:28:01 --> Config Class Initialized
INFO - 2020-03-04 12:28:01 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:28:01 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:28:01 --> Utf8 Class Initialized
INFO - 2020-03-04 12:28:01 --> URI Class Initialized
INFO - 2020-03-04 12:28:01 --> Router Class Initialized
INFO - 2020-03-04 12:28:01 --> Output Class Initialized
INFO - 2020-03-04 12:28:01 --> Security Class Initialized
DEBUG - 2020-03-04 12:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:28:01 --> Input Class Initialized
INFO - 2020-03-04 12:28:01 --> Language Class Initialized
INFO - 2020-03-04 12:28:01 --> Loader Class Initialized
INFO - 2020-03-04 12:28:01 --> Helper loaded: url_helper
INFO - 2020-03-04 12:28:01 --> Helper loaded: string_helper
INFO - 2020-03-04 12:28:01 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:28:01 --> Controller Class Initialized
INFO - 2020-03-04 12:28:01 --> Model "M_tiket" initialized
INFO - 2020-03-04 12:28:01 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 12:28:01 --> Model "M_pesan" initialized
INFO - 2020-03-04 12:28:01 --> Helper loaded: form_helper
INFO - 2020-03-04 12:28:01 --> Form Validation Class Initialized
INFO - 2020-03-04 12:28:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 12:28:01 --> Final output sent to browser
DEBUG - 2020-03-04 12:28:01 --> Total execution time: 0.0081
INFO - 2020-03-04 12:28:08 --> Config Class Initialized
INFO - 2020-03-04 12:28:08 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:28:08 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:28:08 --> Utf8 Class Initialized
INFO - 2020-03-04 12:28:08 --> URI Class Initialized
INFO - 2020-03-04 12:28:08 --> Router Class Initialized
INFO - 2020-03-04 12:28:08 --> Output Class Initialized
INFO - 2020-03-04 12:28:08 --> Security Class Initialized
DEBUG - 2020-03-04 12:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:28:08 --> Input Class Initialized
INFO - 2020-03-04 12:28:08 --> Language Class Initialized
INFO - 2020-03-04 12:28:08 --> Loader Class Initialized
INFO - 2020-03-04 12:28:08 --> Helper loaded: url_helper
INFO - 2020-03-04 12:28:08 --> Helper loaded: string_helper
INFO - 2020-03-04 12:28:08 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:28:08 --> Controller Class Initialized
INFO - 2020-03-04 12:28:08 --> Model "M_tiket" initialized
INFO - 2020-03-04 12:28:08 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 12:28:08 --> Model "M_pesan" initialized
INFO - 2020-03-04 12:28:08 --> Helper loaded: form_helper
INFO - 2020-03-04 12:28:08 --> Form Validation Class Initialized
INFO - 2020-03-04 12:28:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 12:28:08 --> Final output sent to browser
DEBUG - 2020-03-04 12:28:08 --> Total execution time: 0.0103
INFO - 2020-03-04 12:28:24 --> Config Class Initialized
INFO - 2020-03-04 12:28:24 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:28:24 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:28:24 --> Utf8 Class Initialized
INFO - 2020-03-04 12:28:24 --> URI Class Initialized
INFO - 2020-03-04 12:28:24 --> Router Class Initialized
INFO - 2020-03-04 12:28:24 --> Output Class Initialized
INFO - 2020-03-04 12:28:24 --> Security Class Initialized
DEBUG - 2020-03-04 12:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:28:24 --> Input Class Initialized
INFO - 2020-03-04 12:28:24 --> Language Class Initialized
INFO - 2020-03-04 12:28:24 --> Loader Class Initialized
INFO - 2020-03-04 12:28:24 --> Helper loaded: url_helper
INFO - 2020-03-04 12:28:24 --> Helper loaded: string_helper
INFO - 2020-03-04 12:28:24 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:28:24 --> Controller Class Initialized
INFO - 2020-03-04 12:28:24 --> Model "M_tiket" initialized
INFO - 2020-03-04 12:28:24 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 12:28:24 --> Model "M_pesan" initialized
INFO - 2020-03-04 12:28:24 --> Helper loaded: form_helper
INFO - 2020-03-04 12:28:24 --> Form Validation Class Initialized
INFO - 2020-03-04 12:28:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 12:28:24 --> Final output sent to browser
DEBUG - 2020-03-04 12:28:24 --> Total execution time: 0.0088
INFO - 2020-03-04 12:30:41 --> Config Class Initialized
INFO - 2020-03-04 12:30:41 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:30:41 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:30:41 --> Utf8 Class Initialized
INFO - 2020-03-04 12:30:41 --> URI Class Initialized
DEBUG - 2020-03-04 12:30:41 --> No URI present. Default controller set.
INFO - 2020-03-04 12:30:41 --> Router Class Initialized
INFO - 2020-03-04 12:30:41 --> Output Class Initialized
INFO - 2020-03-04 12:30:41 --> Security Class Initialized
DEBUG - 2020-03-04 12:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:30:41 --> Input Class Initialized
INFO - 2020-03-04 12:30:41 --> Language Class Initialized
INFO - 2020-03-04 12:30:41 --> Loader Class Initialized
INFO - 2020-03-04 12:30:41 --> Helper loaded: url_helper
INFO - 2020-03-04 12:30:41 --> Helper loaded: string_helper
INFO - 2020-03-04 12:30:41 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:30:41 --> Controller Class Initialized
INFO - 2020-03-04 12:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 12:30:41 --> Pagination Class Initialized
INFO - 2020-03-04 12:30:41 --> Model "M_show" initialized
INFO - 2020-03-04 12:30:41 --> Helper loaded: form_helper
INFO - 2020-03-04 12:30:41 --> Form Validation Class Initialized
INFO - 2020-03-04 12:30:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 12:30:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 12:30:41 --> Final output sent to browser
DEBUG - 2020-03-04 12:30:41 --> Total execution time: 0.0297
INFO - 2020-03-04 12:30:47 --> Config Class Initialized
INFO - 2020-03-04 12:30:47 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:30:47 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:30:47 --> Utf8 Class Initialized
INFO - 2020-03-04 12:30:47 --> URI Class Initialized
INFO - 2020-03-04 12:30:47 --> Router Class Initialized
INFO - 2020-03-04 12:30:47 --> Output Class Initialized
INFO - 2020-03-04 12:30:47 --> Security Class Initialized
DEBUG - 2020-03-04 12:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:30:47 --> Input Class Initialized
INFO - 2020-03-04 12:30:47 --> Language Class Initialized
INFO - 2020-03-04 12:30:47 --> Loader Class Initialized
INFO - 2020-03-04 12:30:47 --> Helper loaded: url_helper
INFO - 2020-03-04 12:30:47 --> Helper loaded: string_helper
INFO - 2020-03-04 12:30:47 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:30:47 --> Controller Class Initialized
INFO - 2020-03-04 12:30:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 12:30:47 --> Pagination Class Initialized
INFO - 2020-03-04 12:30:47 --> Model "M_show" initialized
INFO - 2020-03-04 12:30:47 --> Helper loaded: form_helper
INFO - 2020-03-04 12:30:47 --> Form Validation Class Initialized
INFO - 2020-03-04 12:30:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 12:30:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 12:30:47 --> Final output sent to browser
DEBUG - 2020-03-04 12:30:47 --> Total execution time: 0.0085
INFO - 2020-03-04 12:30:51 --> Config Class Initialized
INFO - 2020-03-04 12:30:51 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:30:51 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:30:51 --> Utf8 Class Initialized
INFO - 2020-03-04 12:30:51 --> URI Class Initialized
INFO - 2020-03-04 12:30:51 --> Router Class Initialized
INFO - 2020-03-04 12:30:51 --> Output Class Initialized
INFO - 2020-03-04 12:30:51 --> Security Class Initialized
DEBUG - 2020-03-04 12:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:30:51 --> Input Class Initialized
INFO - 2020-03-04 12:30:51 --> Language Class Initialized
INFO - 2020-03-04 12:30:51 --> Loader Class Initialized
INFO - 2020-03-04 12:30:51 --> Helper loaded: url_helper
INFO - 2020-03-04 12:30:51 --> Helper loaded: string_helper
INFO - 2020-03-04 12:30:51 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:30:51 --> Controller Class Initialized
INFO - 2020-03-04 12:30:51 --> Model "M_tiket" initialized
INFO - 2020-03-04 12:30:51 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 12:30:51 --> Model "M_pesan" initialized
INFO - 2020-03-04 12:30:51 --> Helper loaded: form_helper
INFO - 2020-03-04 12:30:51 --> Form Validation Class Initialized
INFO - 2020-03-04 12:30:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 12:30:51 --> Final output sent to browser
DEBUG - 2020-03-04 12:30:51 --> Total execution time: 0.0118
INFO - 2020-03-04 12:31:03 --> Config Class Initialized
INFO - 2020-03-04 12:31:03 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:31:03 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:31:03 --> Utf8 Class Initialized
INFO - 2020-03-04 12:31:03 --> URI Class Initialized
INFO - 2020-03-04 12:31:03 --> Router Class Initialized
INFO - 2020-03-04 12:31:03 --> Output Class Initialized
INFO - 2020-03-04 12:31:03 --> Security Class Initialized
DEBUG - 2020-03-04 12:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:31:03 --> Input Class Initialized
INFO - 2020-03-04 12:31:03 --> Language Class Initialized
INFO - 2020-03-04 12:31:03 --> Loader Class Initialized
INFO - 2020-03-04 12:31:03 --> Helper loaded: url_helper
INFO - 2020-03-04 12:31:03 --> Helper loaded: string_helper
INFO - 2020-03-04 12:31:03 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:31:03 --> Controller Class Initialized
INFO - 2020-03-04 12:31:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 12:31:03 --> Pagination Class Initialized
INFO - 2020-03-04 12:31:03 --> Model "M_show" initialized
INFO - 2020-03-04 12:31:03 --> Helper loaded: form_helper
INFO - 2020-03-04 12:31:03 --> Form Validation Class Initialized
INFO - 2020-03-04 12:31:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 12:31:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 12:31:03 --> Final output sent to browser
DEBUG - 2020-03-04 12:31:03 --> Total execution time: 0.0068
INFO - 2020-03-04 12:31:05 --> Config Class Initialized
INFO - 2020-03-04 12:31:05 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:31:05 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:31:05 --> Utf8 Class Initialized
INFO - 2020-03-04 12:31:05 --> URI Class Initialized
DEBUG - 2020-03-04 12:31:05 --> No URI present. Default controller set.
INFO - 2020-03-04 12:31:05 --> Router Class Initialized
INFO - 2020-03-04 12:31:05 --> Output Class Initialized
INFO - 2020-03-04 12:31:05 --> Security Class Initialized
DEBUG - 2020-03-04 12:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:31:05 --> Input Class Initialized
INFO - 2020-03-04 12:31:05 --> Language Class Initialized
INFO - 2020-03-04 12:31:05 --> Loader Class Initialized
INFO - 2020-03-04 12:31:05 --> Helper loaded: url_helper
INFO - 2020-03-04 12:31:05 --> Helper loaded: string_helper
INFO - 2020-03-04 12:31:05 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:31:05 --> Controller Class Initialized
INFO - 2020-03-04 12:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 12:31:05 --> Pagination Class Initialized
INFO - 2020-03-04 12:31:05 --> Model "M_show" initialized
INFO - 2020-03-04 12:31:05 --> Helper loaded: form_helper
INFO - 2020-03-04 12:31:05 --> Form Validation Class Initialized
INFO - 2020-03-04 12:31:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 12:31:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 12:31:05 --> Final output sent to browser
DEBUG - 2020-03-04 12:31:05 --> Total execution time: 0.0071
INFO - 2020-03-04 12:39:10 --> Config Class Initialized
INFO - 2020-03-04 12:39:10 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:39:10 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:39:10 --> Utf8 Class Initialized
INFO - 2020-03-04 12:39:10 --> URI Class Initialized
DEBUG - 2020-03-04 12:39:10 --> No URI present. Default controller set.
INFO - 2020-03-04 12:39:10 --> Router Class Initialized
INFO - 2020-03-04 12:39:10 --> Output Class Initialized
INFO - 2020-03-04 12:39:10 --> Security Class Initialized
DEBUG - 2020-03-04 12:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:39:11 --> Input Class Initialized
INFO - 2020-03-04 12:39:11 --> Language Class Initialized
INFO - 2020-03-04 12:39:11 --> Loader Class Initialized
INFO - 2020-03-04 12:39:11 --> Helper loaded: url_helper
INFO - 2020-03-04 12:39:11 --> Helper loaded: string_helper
INFO - 2020-03-04 12:39:11 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:39:11 --> Controller Class Initialized
INFO - 2020-03-04 12:39:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 12:39:11 --> Pagination Class Initialized
INFO - 2020-03-04 12:39:11 --> Model "M_show" initialized
INFO - 2020-03-04 12:39:11 --> Helper loaded: form_helper
INFO - 2020-03-04 12:39:11 --> Form Validation Class Initialized
INFO - 2020-03-04 12:39:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 12:39:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 12:39:11 --> Final output sent to browser
DEBUG - 2020-03-04 12:39:11 --> Total execution time: 0.0410
INFO - 2020-03-04 12:53:30 --> Config Class Initialized
INFO - 2020-03-04 12:53:30 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:53:30 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:53:30 --> Utf8 Class Initialized
INFO - 2020-03-04 12:53:30 --> URI Class Initialized
INFO - 2020-03-04 12:53:30 --> Router Class Initialized
INFO - 2020-03-04 12:53:30 --> Output Class Initialized
INFO - 2020-03-04 12:53:30 --> Security Class Initialized
DEBUG - 2020-03-04 12:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:53:30 --> Input Class Initialized
INFO - 2020-03-04 12:53:30 --> Language Class Initialized
INFO - 2020-03-04 12:53:30 --> Loader Class Initialized
INFO - 2020-03-04 12:53:30 --> Helper loaded: url_helper
INFO - 2020-03-04 12:53:30 --> Helper loaded: string_helper
INFO - 2020-03-04 12:53:30 --> Database Driver Class Initialized
DEBUG - 2020-03-04 12:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 12:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 12:53:30 --> Controller Class Initialized
INFO - 2020-03-04 12:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 12:53:30 --> Pagination Class Initialized
INFO - 2020-03-04 12:53:30 --> Model "M_show" initialized
INFO - 2020-03-04 12:53:30 --> Helper loaded: form_helper
INFO - 2020-03-04 12:53:30 --> Form Validation Class Initialized
INFO - 2020-03-04 12:53:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 12:53:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 12:53:30 --> Final output sent to browser
DEBUG - 2020-03-04 12:53:30 --> Total execution time: 0.0501
INFO - 2020-03-04 12:53:30 --> Config Class Initialized
INFO - 2020-03-04 12:53:30 --> Hooks Class Initialized
DEBUG - 2020-03-04 12:53:30 --> UTF-8 Support Enabled
INFO - 2020-03-04 12:53:30 --> Utf8 Class Initialized
INFO - 2020-03-04 12:53:30 --> URI Class Initialized
INFO - 2020-03-04 12:53:30 --> Router Class Initialized
INFO - 2020-03-04 12:53:30 --> Output Class Initialized
INFO - 2020-03-04 12:53:30 --> Security Class Initialized
DEBUG - 2020-03-04 12:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 12:53:30 --> Input Class Initialized
INFO - 2020-03-04 12:53:30 --> Language Class Initialized
ERROR - 2020-03-04 12:53:30 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 13:37:48 --> Config Class Initialized
INFO - 2020-03-04 13:37:48 --> Hooks Class Initialized
DEBUG - 2020-03-04 13:37:48 --> UTF-8 Support Enabled
INFO - 2020-03-04 13:37:48 --> Utf8 Class Initialized
INFO - 2020-03-04 13:37:48 --> URI Class Initialized
DEBUG - 2020-03-04 13:37:48 --> No URI present. Default controller set.
INFO - 2020-03-04 13:37:48 --> Router Class Initialized
INFO - 2020-03-04 13:37:48 --> Output Class Initialized
INFO - 2020-03-04 13:37:48 --> Security Class Initialized
DEBUG - 2020-03-04 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 13:37:48 --> Input Class Initialized
INFO - 2020-03-04 13:37:48 --> Language Class Initialized
INFO - 2020-03-04 13:37:48 --> Loader Class Initialized
INFO - 2020-03-04 13:37:48 --> Helper loaded: url_helper
INFO - 2020-03-04 13:37:48 --> Helper loaded: string_helper
INFO - 2020-03-04 13:37:48 --> Database Driver Class Initialized
DEBUG - 2020-03-04 13:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 13:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 13:37:48 --> Controller Class Initialized
INFO - 2020-03-04 13:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 13:37:48 --> Pagination Class Initialized
INFO - 2020-03-04 13:37:48 --> Model "M_show" initialized
INFO - 2020-03-04 13:37:48 --> Helper loaded: form_helper
INFO - 2020-03-04 13:37:48 --> Form Validation Class Initialized
INFO - 2020-03-04 13:37:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 13:37:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 13:37:48 --> Final output sent to browser
DEBUG - 2020-03-04 13:37:48 --> Total execution time: 0.0539
INFO - 2020-03-04 13:38:13 --> Config Class Initialized
INFO - 2020-03-04 13:38:13 --> Hooks Class Initialized
DEBUG - 2020-03-04 13:38:13 --> UTF-8 Support Enabled
INFO - 2020-03-04 13:38:13 --> Utf8 Class Initialized
INFO - 2020-03-04 13:38:13 --> URI Class Initialized
INFO - 2020-03-04 13:38:13 --> Router Class Initialized
INFO - 2020-03-04 13:38:13 --> Output Class Initialized
INFO - 2020-03-04 13:38:13 --> Security Class Initialized
DEBUG - 2020-03-04 13:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 13:38:13 --> Input Class Initialized
INFO - 2020-03-04 13:38:13 --> Language Class Initialized
INFO - 2020-03-04 13:38:13 --> Loader Class Initialized
INFO - 2020-03-04 13:38:13 --> Helper loaded: url_helper
INFO - 2020-03-04 13:38:13 --> Helper loaded: string_helper
INFO - 2020-03-04 13:38:13 --> Database Driver Class Initialized
DEBUG - 2020-03-04 13:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 13:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 13:38:13 --> Controller Class Initialized
INFO - 2020-03-04 13:38:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 13:38:13 --> Pagination Class Initialized
INFO - 2020-03-04 13:38:13 --> Model "M_show" initialized
INFO - 2020-03-04 13:38:13 --> Helper loaded: form_helper
INFO - 2020-03-04 13:38:13 --> Form Validation Class Initialized
INFO - 2020-03-04 13:38:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 13:38:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 13:38:13 --> Final output sent to browser
DEBUG - 2020-03-04 13:38:13 --> Total execution time: 0.0143
INFO - 2020-03-04 13:38:14 --> Config Class Initialized
INFO - 2020-03-04 13:38:14 --> Hooks Class Initialized
DEBUG - 2020-03-04 13:38:14 --> UTF-8 Support Enabled
INFO - 2020-03-04 13:38:14 --> Utf8 Class Initialized
INFO - 2020-03-04 13:38:14 --> URI Class Initialized
INFO - 2020-03-04 13:38:14 --> Router Class Initialized
INFO - 2020-03-04 13:38:14 --> Output Class Initialized
INFO - 2020-03-04 13:38:14 --> Security Class Initialized
DEBUG - 2020-03-04 13:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 13:38:14 --> Input Class Initialized
INFO - 2020-03-04 13:38:14 --> Language Class Initialized
ERROR - 2020-03-04 13:38:14 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 13:38:18 --> Config Class Initialized
INFO - 2020-03-04 13:38:18 --> Hooks Class Initialized
DEBUG - 2020-03-04 13:38:18 --> UTF-8 Support Enabled
INFO - 2020-03-04 13:38:18 --> Utf8 Class Initialized
INFO - 2020-03-04 13:38:18 --> URI Class Initialized
INFO - 2020-03-04 13:38:18 --> Router Class Initialized
INFO - 2020-03-04 13:38:18 --> Output Class Initialized
INFO - 2020-03-04 13:38:18 --> Security Class Initialized
DEBUG - 2020-03-04 13:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 13:38:18 --> Input Class Initialized
INFO - 2020-03-04 13:38:18 --> Language Class Initialized
INFO - 2020-03-04 13:38:18 --> Loader Class Initialized
INFO - 2020-03-04 13:38:18 --> Helper loaded: url_helper
INFO - 2020-03-04 13:38:18 --> Helper loaded: string_helper
INFO - 2020-03-04 13:38:18 --> Database Driver Class Initialized
DEBUG - 2020-03-04 13:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 13:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 13:38:18 --> Controller Class Initialized
INFO - 2020-03-04 13:38:18 --> Model "M_tiket" initialized
INFO - 2020-03-04 13:38:18 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 13:38:18 --> Model "M_pesan" initialized
INFO - 2020-03-04 13:38:18 --> Helper loaded: form_helper
INFO - 2020-03-04 13:38:18 --> Form Validation Class Initialized
INFO - 2020-03-04 13:38:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 13:38:18 --> Final output sent to browser
DEBUG - 2020-03-04 13:38:18 --> Total execution time: 0.0112
INFO - 2020-03-04 13:39:04 --> Config Class Initialized
INFO - 2020-03-04 13:39:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 13:39:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 13:39:04 --> Utf8 Class Initialized
INFO - 2020-03-04 13:39:04 --> URI Class Initialized
DEBUG - 2020-03-04 13:39:04 --> No URI present. Default controller set.
INFO - 2020-03-04 13:39:04 --> Router Class Initialized
INFO - 2020-03-04 13:39:04 --> Output Class Initialized
INFO - 2020-03-04 13:39:04 --> Security Class Initialized
DEBUG - 2020-03-04 13:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 13:39:04 --> Input Class Initialized
INFO - 2020-03-04 13:39:04 --> Language Class Initialized
INFO - 2020-03-04 13:39:04 --> Loader Class Initialized
INFO - 2020-03-04 13:39:04 --> Helper loaded: url_helper
INFO - 2020-03-04 13:39:04 --> Helper loaded: string_helper
INFO - 2020-03-04 13:39:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 13:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 13:39:06 --> Config Class Initialized
INFO - 2020-03-04 13:39:06 --> Hooks Class Initialized
DEBUG - 2020-03-04 13:39:06 --> UTF-8 Support Enabled
INFO - 2020-03-04 13:39:06 --> Utf8 Class Initialized
INFO - 2020-03-04 13:39:06 --> URI Class Initialized
DEBUG - 2020-03-04 13:39:06 --> No URI present. Default controller set.
INFO - 2020-03-04 13:39:06 --> Router Class Initialized
INFO - 2020-03-04 13:39:06 --> Output Class Initialized
INFO - 2020-03-04 13:39:06 --> Security Class Initialized
DEBUG - 2020-03-04 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 13:39:06 --> Input Class Initialized
INFO - 2020-03-04 13:39:06 --> Language Class Initialized
INFO - 2020-03-04 13:39:06 --> Loader Class Initialized
INFO - 2020-03-04 13:39:06 --> Helper loaded: url_helper
INFO - 2020-03-04 13:39:06 --> Helper loaded: string_helper
INFO - 2020-03-04 13:39:06 --> Database Driver Class Initialized
DEBUG - 2020-03-04 13:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 13:39:06 --> Controller Class Initialized
INFO - 2020-03-04 13:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 13:39:06 --> Pagination Class Initialized
INFO - 2020-03-04 13:39:06 --> Model "M_show" initialized
INFO - 2020-03-04 13:39:06 --> Config Class Initialized
INFO - 2020-03-04 13:39:06 --> Helper loaded: form_helper
INFO - 2020-03-04 13:39:06 --> Hooks Class Initialized
INFO - 2020-03-04 13:39:06 --> Form Validation Class Initialized
INFO - 2020-03-04 13:39:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 13:39:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
DEBUG - 2020-03-04 13:39:06 --> UTF-8 Support Enabled
INFO - 2020-03-04 13:39:06 --> Final output sent to browser
INFO - 2020-03-04 13:39:06 --> Utf8 Class Initialized
DEBUG - 2020-03-04 13:39:06 --> Total execution time: 0.7280
INFO - 2020-03-04 13:39:06 --> URI Class Initialized
DEBUG - 2020-03-04 13:39:06 --> No URI present. Default controller set.
INFO - 2020-03-04 13:39:06 --> Router Class Initialized
INFO - 2020-03-04 13:39:06 --> Output Class Initialized
INFO - 2020-03-04 13:39:06 --> Security Class Initialized
DEBUG - 2020-03-04 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 13:39:06 --> Input Class Initialized
INFO - 2020-03-04 13:39:06 --> Language Class Initialized
INFO - 2020-03-04 13:39:06 --> Loader Class Initialized
INFO - 2020-03-04 13:39:06 --> Helper loaded: url_helper
INFO - 2020-03-04 13:39:06 --> Helper loaded: string_helper
INFO - 2020-03-04 13:39:06 --> Database Driver Class Initialized
DEBUG - 2020-03-04 13:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 13:39:06 --> Controller Class Initialized
INFO - 2020-03-04 13:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 13:39:06 --> Pagination Class Initialized
INFO - 2020-03-04 13:39:06 --> Model "M_show" initialized
INFO - 2020-03-04 13:39:06 --> Helper loaded: form_helper
INFO - 2020-03-04 13:39:06 --> Form Validation Class Initialized
INFO - 2020-03-04 13:39:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 13:39:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 13:39:06 --> Final output sent to browser
DEBUG - 2020-03-04 13:39:06 --> Total execution time: 0.0283
INFO - 2020-03-04 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 13:39:06 --> Controller Class Initialized
INFO - 2020-03-04 13:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 13:39:06 --> Pagination Class Initialized
INFO - 2020-03-04 13:39:06 --> Model "M_show" initialized
INFO - 2020-03-04 13:39:06 --> Helper loaded: form_helper
INFO - 2020-03-04 13:39:06 --> Form Validation Class Initialized
INFO - 2020-03-04 13:39:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 13:39:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 13:39:06 --> Final output sent to browser
DEBUG - 2020-03-04 13:39:06 --> Total execution time: 2.1912
INFO - 2020-03-04 13:56:21 --> Config Class Initialized
INFO - 2020-03-04 13:56:21 --> Hooks Class Initialized
DEBUG - 2020-03-04 13:56:21 --> UTF-8 Support Enabled
INFO - 2020-03-04 13:56:21 --> Utf8 Class Initialized
INFO - 2020-03-04 13:56:21 --> URI Class Initialized
INFO - 2020-03-04 13:56:21 --> Router Class Initialized
INFO - 2020-03-04 13:56:21 --> Output Class Initialized
INFO - 2020-03-04 13:56:21 --> Security Class Initialized
DEBUG - 2020-03-04 13:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 13:56:21 --> Input Class Initialized
INFO - 2020-03-04 13:56:21 --> Language Class Initialized
INFO - 2020-03-04 13:56:21 --> Loader Class Initialized
INFO - 2020-03-04 13:56:21 --> Helper loaded: url_helper
INFO - 2020-03-04 13:56:21 --> Helper loaded: string_helper
INFO - 2020-03-04 13:56:21 --> Database Driver Class Initialized
DEBUG - 2020-03-04 13:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 13:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 13:56:21 --> Controller Class Initialized
INFO - 2020-03-04 13:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 13:56:21 --> Pagination Class Initialized
INFO - 2020-03-04 13:56:21 --> Model "M_show" initialized
INFO - 2020-03-04 13:56:21 --> Helper loaded: form_helper
INFO - 2020-03-04 13:56:21 --> Form Validation Class Initialized
INFO - 2020-03-04 13:56:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 13:56:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 13:56:21 --> Final output sent to browser
DEBUG - 2020-03-04 13:56:21 --> Total execution time: 0.0404
INFO - 2020-03-04 13:56:34 --> Config Class Initialized
INFO - 2020-03-04 13:56:34 --> Hooks Class Initialized
DEBUG - 2020-03-04 13:56:34 --> UTF-8 Support Enabled
INFO - 2020-03-04 13:56:34 --> Utf8 Class Initialized
INFO - 2020-03-04 13:56:34 --> URI Class Initialized
INFO - 2020-03-04 13:56:34 --> Router Class Initialized
INFO - 2020-03-04 13:56:34 --> Output Class Initialized
INFO - 2020-03-04 13:56:34 --> Security Class Initialized
DEBUG - 2020-03-04 13:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 13:56:34 --> Input Class Initialized
INFO - 2020-03-04 13:56:34 --> Language Class Initialized
INFO - 2020-03-04 13:56:34 --> Loader Class Initialized
INFO - 2020-03-04 13:56:34 --> Helper loaded: url_helper
INFO - 2020-03-04 13:56:34 --> Helper loaded: string_helper
INFO - 2020-03-04 13:56:34 --> Database Driver Class Initialized
DEBUG - 2020-03-04 13:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 13:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 13:56:34 --> Controller Class Initialized
INFO - 2020-03-04 13:56:34 --> Model "M_tiket" initialized
INFO - 2020-03-04 13:56:34 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 13:56:34 --> Model "M_pesan" initialized
INFO - 2020-03-04 13:56:34 --> Helper loaded: form_helper
INFO - 2020-03-04 13:56:34 --> Form Validation Class Initialized
INFO - 2020-03-04 13:56:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 13:56:34 --> Final output sent to browser
DEBUG - 2020-03-04 13:56:34 --> Total execution time: 0.0104
INFO - 2020-03-04 13:58:41 --> Config Class Initialized
INFO - 2020-03-04 13:58:41 --> Hooks Class Initialized
DEBUG - 2020-03-04 13:58:41 --> UTF-8 Support Enabled
INFO - 2020-03-04 13:58:41 --> Utf8 Class Initialized
INFO - 2020-03-04 13:58:41 --> URI Class Initialized
INFO - 2020-03-04 13:58:41 --> Router Class Initialized
INFO - 2020-03-04 13:58:41 --> Output Class Initialized
INFO - 2020-03-04 13:58:41 --> Security Class Initialized
DEBUG - 2020-03-04 13:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 13:58:41 --> Input Class Initialized
INFO - 2020-03-04 13:58:41 --> Language Class Initialized
INFO - 2020-03-04 13:58:41 --> Loader Class Initialized
INFO - 2020-03-04 13:58:41 --> Helper loaded: url_helper
INFO - 2020-03-04 13:58:41 --> Helper loaded: string_helper
INFO - 2020-03-04 13:58:41 --> Database Driver Class Initialized
DEBUG - 2020-03-04 13:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 13:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 13:58:41 --> Controller Class Initialized
INFO - 2020-03-04 13:58:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 13:58:41 --> Pagination Class Initialized
INFO - 2020-03-04 13:58:41 --> Model "M_show" initialized
INFO - 2020-03-04 13:58:41 --> Helper loaded: form_helper
INFO - 2020-03-04 13:58:41 --> Form Validation Class Initialized
INFO - 2020-03-04 13:58:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 13:58:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 13:58:41 --> Final output sent to browser
DEBUG - 2020-03-04 13:58:41 --> Total execution time: 0.0690
INFO - 2020-03-04 13:58:42 --> Config Class Initialized
INFO - 2020-03-04 13:58:42 --> Hooks Class Initialized
DEBUG - 2020-03-04 13:58:42 --> UTF-8 Support Enabled
INFO - 2020-03-04 13:58:42 --> Utf8 Class Initialized
INFO - 2020-03-04 13:58:42 --> URI Class Initialized
INFO - 2020-03-04 13:58:42 --> Router Class Initialized
INFO - 2020-03-04 13:58:42 --> Output Class Initialized
INFO - 2020-03-04 13:58:42 --> Security Class Initialized
DEBUG - 2020-03-04 13:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 13:58:42 --> Input Class Initialized
INFO - 2020-03-04 13:58:42 --> Language Class Initialized
ERROR - 2020-03-04 13:58:42 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 14:01:07 --> Config Class Initialized
INFO - 2020-03-04 14:01:07 --> Hooks Class Initialized
DEBUG - 2020-03-04 14:01:07 --> UTF-8 Support Enabled
INFO - 2020-03-04 14:01:07 --> Utf8 Class Initialized
INFO - 2020-03-04 14:01:07 --> URI Class Initialized
INFO - 2020-03-04 14:01:07 --> Router Class Initialized
INFO - 2020-03-04 14:01:07 --> Output Class Initialized
INFO - 2020-03-04 14:01:07 --> Security Class Initialized
DEBUG - 2020-03-04 14:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 14:01:07 --> Input Class Initialized
INFO - 2020-03-04 14:01:07 --> Language Class Initialized
INFO - 2020-03-04 14:01:07 --> Loader Class Initialized
INFO - 2020-03-04 14:01:07 --> Helper loaded: url_helper
INFO - 2020-03-04 14:01:07 --> Helper loaded: string_helper
INFO - 2020-03-04 14:01:07 --> Database Driver Class Initialized
DEBUG - 2020-03-04 14:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 14:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 14:01:07 --> Controller Class Initialized
INFO - 2020-03-04 14:01:07 --> Model "M_tiket" initialized
INFO - 2020-03-04 14:01:07 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 14:01:07 --> Model "M_pesan" initialized
INFO - 2020-03-04 14:01:07 --> Helper loaded: form_helper
INFO - 2020-03-04 14:01:07 --> Form Validation Class Initialized
INFO - 2020-03-04 14:01:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 14:01:07 --> Final output sent to browser
DEBUG - 2020-03-04 14:01:07 --> Total execution time: 0.0436
INFO - 2020-03-04 14:07:27 --> Config Class Initialized
INFO - 2020-03-04 14:07:27 --> Hooks Class Initialized
DEBUG - 2020-03-04 14:07:27 --> UTF-8 Support Enabled
INFO - 2020-03-04 14:07:27 --> Utf8 Class Initialized
INFO - 2020-03-04 14:07:27 --> URI Class Initialized
DEBUG - 2020-03-04 14:07:27 --> No URI present. Default controller set.
INFO - 2020-03-04 14:07:27 --> Router Class Initialized
INFO - 2020-03-04 14:07:27 --> Output Class Initialized
INFO - 2020-03-04 14:07:27 --> Security Class Initialized
DEBUG - 2020-03-04 14:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 14:07:27 --> Input Class Initialized
INFO - 2020-03-04 14:07:27 --> Language Class Initialized
INFO - 2020-03-04 14:07:27 --> Loader Class Initialized
INFO - 2020-03-04 14:07:27 --> Helper loaded: url_helper
INFO - 2020-03-04 14:07:27 --> Helper loaded: string_helper
INFO - 2020-03-04 14:07:27 --> Database Driver Class Initialized
DEBUG - 2020-03-04 14:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 14:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 14:07:27 --> Controller Class Initialized
INFO - 2020-03-04 14:07:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 14:07:27 --> Pagination Class Initialized
INFO - 2020-03-04 14:07:27 --> Model "M_show" initialized
INFO - 2020-03-04 14:07:27 --> Helper loaded: form_helper
INFO - 2020-03-04 14:07:27 --> Form Validation Class Initialized
INFO - 2020-03-04 14:07:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 14:07:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 14:07:27 --> Final output sent to browser
DEBUG - 2020-03-04 14:07:27 --> Total execution time: 0.0369
INFO - 2020-03-04 14:07:37 --> Config Class Initialized
INFO - 2020-03-04 14:07:37 --> Hooks Class Initialized
DEBUG - 2020-03-04 14:07:37 --> UTF-8 Support Enabled
INFO - 2020-03-04 14:07:37 --> Utf8 Class Initialized
INFO - 2020-03-04 14:07:37 --> URI Class Initialized
INFO - 2020-03-04 14:07:37 --> Router Class Initialized
INFO - 2020-03-04 14:07:37 --> Output Class Initialized
INFO - 2020-03-04 14:07:37 --> Security Class Initialized
DEBUG - 2020-03-04 14:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 14:07:37 --> Input Class Initialized
INFO - 2020-03-04 14:07:37 --> Language Class Initialized
INFO - 2020-03-04 14:07:37 --> Loader Class Initialized
INFO - 2020-03-04 14:07:37 --> Helper loaded: url_helper
INFO - 2020-03-04 14:07:37 --> Helper loaded: string_helper
INFO - 2020-03-04 14:07:37 --> Database Driver Class Initialized
DEBUG - 2020-03-04 14:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 14:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 14:07:37 --> Controller Class Initialized
INFO - 2020-03-04 14:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 14:07:37 --> Pagination Class Initialized
INFO - 2020-03-04 14:07:37 --> Model "M_show" initialized
INFO - 2020-03-04 14:07:37 --> Helper loaded: form_helper
INFO - 2020-03-04 14:07:37 --> Form Validation Class Initialized
INFO - 2020-03-04 14:07:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 14:07:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 14:07:37 --> Final output sent to browser
DEBUG - 2020-03-04 14:07:37 --> Total execution time: 0.0079
INFO - 2020-03-04 14:07:38 --> Config Class Initialized
INFO - 2020-03-04 14:07:38 --> Hooks Class Initialized
DEBUG - 2020-03-04 14:07:38 --> UTF-8 Support Enabled
INFO - 2020-03-04 14:07:38 --> Utf8 Class Initialized
INFO - 2020-03-04 14:07:38 --> URI Class Initialized
INFO - 2020-03-04 14:07:38 --> Router Class Initialized
INFO - 2020-03-04 14:07:38 --> Output Class Initialized
INFO - 2020-03-04 14:07:38 --> Security Class Initialized
DEBUG - 2020-03-04 14:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 14:07:38 --> Input Class Initialized
INFO - 2020-03-04 14:07:38 --> Language Class Initialized
ERROR - 2020-03-04 14:07:38 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 14:07:40 --> Config Class Initialized
INFO - 2020-03-04 14:07:40 --> Hooks Class Initialized
DEBUG - 2020-03-04 14:07:40 --> UTF-8 Support Enabled
INFO - 2020-03-04 14:07:40 --> Utf8 Class Initialized
INFO - 2020-03-04 14:07:40 --> URI Class Initialized
INFO - 2020-03-04 14:07:40 --> Router Class Initialized
INFO - 2020-03-04 14:07:40 --> Output Class Initialized
INFO - 2020-03-04 14:07:40 --> Security Class Initialized
DEBUG - 2020-03-04 14:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 14:07:40 --> Input Class Initialized
INFO - 2020-03-04 14:07:40 --> Language Class Initialized
INFO - 2020-03-04 14:07:40 --> Loader Class Initialized
INFO - 2020-03-04 14:07:40 --> Helper loaded: url_helper
INFO - 2020-03-04 14:07:40 --> Helper loaded: string_helper
INFO - 2020-03-04 14:07:40 --> Database Driver Class Initialized
DEBUG - 2020-03-04 14:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 14:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 14:07:40 --> Controller Class Initialized
INFO - 2020-03-04 14:07:40 --> Model "M_tiket" initialized
INFO - 2020-03-04 14:07:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 14:07:40 --> Model "M_pesan" initialized
INFO - 2020-03-04 14:07:40 --> Helper loaded: form_helper
INFO - 2020-03-04 14:07:40 --> Form Validation Class Initialized
INFO - 2020-03-04 14:07:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 14:07:40 --> Final output sent to browser
DEBUG - 2020-03-04 14:07:40 --> Total execution time: 0.0109
INFO - 2020-03-04 14:07:52 --> Config Class Initialized
INFO - 2020-03-04 14:07:52 --> Hooks Class Initialized
DEBUG - 2020-03-04 14:07:52 --> UTF-8 Support Enabled
INFO - 2020-03-04 14:07:52 --> Utf8 Class Initialized
INFO - 2020-03-04 14:07:52 --> URI Class Initialized
INFO - 2020-03-04 14:07:52 --> Router Class Initialized
INFO - 2020-03-04 14:07:52 --> Output Class Initialized
INFO - 2020-03-04 14:07:52 --> Security Class Initialized
DEBUG - 2020-03-04 14:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 14:07:52 --> Input Class Initialized
INFO - 2020-03-04 14:07:52 --> Language Class Initialized
INFO - 2020-03-04 14:07:52 --> Loader Class Initialized
INFO - 2020-03-04 14:07:52 --> Helper loaded: url_helper
INFO - 2020-03-04 14:07:52 --> Helper loaded: string_helper
INFO - 2020-03-04 14:07:52 --> Database Driver Class Initialized
DEBUG - 2020-03-04 14:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 14:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 14:07:52 --> Controller Class Initialized
INFO - 2020-03-04 14:07:52 --> Model "M_tiket" initialized
INFO - 2020-03-04 14:07:52 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 14:07:52 --> Model "M_pesan" initialized
INFO - 2020-03-04 14:07:52 --> Helper loaded: form_helper
INFO - 2020-03-04 14:07:52 --> Form Validation Class Initialized
INFO - 2020-03-04 14:07:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 14:07:52 --> Final output sent to browser
DEBUG - 2020-03-04 14:07:52 --> Total execution time: 0.0090
INFO - 2020-03-04 14:26:06 --> Config Class Initialized
INFO - 2020-03-04 14:26:06 --> Hooks Class Initialized
DEBUG - 2020-03-04 14:26:06 --> UTF-8 Support Enabled
INFO - 2020-03-04 14:26:06 --> Utf8 Class Initialized
INFO - 2020-03-04 14:26:06 --> URI Class Initialized
INFO - 2020-03-04 14:26:06 --> Router Class Initialized
INFO - 2020-03-04 14:26:06 --> Output Class Initialized
INFO - 2020-03-04 14:26:06 --> Security Class Initialized
DEBUG - 2020-03-04 14:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 14:26:06 --> Input Class Initialized
INFO - 2020-03-04 14:26:06 --> Language Class Initialized
INFO - 2020-03-04 14:26:06 --> Loader Class Initialized
INFO - 2020-03-04 14:26:06 --> Helper loaded: url_helper
INFO - 2020-03-04 14:26:06 --> Helper loaded: string_helper
INFO - 2020-03-04 14:26:06 --> Database Driver Class Initialized
DEBUG - 2020-03-04 14:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 14:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 14:26:06 --> Controller Class Initialized
INFO - 2020-03-04 14:26:06 --> Model "M_tiket" initialized
INFO - 2020-03-04 14:26:06 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 14:26:06 --> Model "M_pesan" initialized
INFO - 2020-03-04 14:26:06 --> Helper loaded: form_helper
INFO - 2020-03-04 14:26:06 --> Form Validation Class Initialized
INFO - 2020-03-04 14:26:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 14:26:06 --> Final output sent to browser
DEBUG - 2020-03-04 14:26:06 --> Total execution time: 0.0362
INFO - 2020-03-04 14:26:07 --> Config Class Initialized
INFO - 2020-03-04 14:26:07 --> Hooks Class Initialized
DEBUG - 2020-03-04 14:26:07 --> UTF-8 Support Enabled
INFO - 2020-03-04 14:26:07 --> Utf8 Class Initialized
INFO - 2020-03-04 14:26:07 --> URI Class Initialized
INFO - 2020-03-04 14:26:07 --> Router Class Initialized
INFO - 2020-03-04 14:26:07 --> Output Class Initialized
INFO - 2020-03-04 14:26:07 --> Security Class Initialized
DEBUG - 2020-03-04 14:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 14:26:07 --> Input Class Initialized
INFO - 2020-03-04 14:26:07 --> Language Class Initialized
INFO - 2020-03-04 14:26:07 --> Loader Class Initialized
INFO - 2020-03-04 14:26:07 --> Helper loaded: url_helper
INFO - 2020-03-04 14:26:07 --> Helper loaded: string_helper
INFO - 2020-03-04 14:26:07 --> Database Driver Class Initialized
DEBUG - 2020-03-04 14:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 14:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 14:26:07 --> Controller Class Initialized
INFO - 2020-03-04 14:26:07 --> Model "M_tiket" initialized
INFO - 2020-03-04 14:26:07 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 14:26:07 --> Model "M_pesan" initialized
INFO - 2020-03-04 14:26:07 --> Helper loaded: form_helper
INFO - 2020-03-04 14:26:07 --> Form Validation Class Initialized
INFO - 2020-03-04 14:26:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 14:26:07 --> Final output sent to browser
DEBUG - 2020-03-04 14:26:07 --> Total execution time: 0.1665
INFO - 2020-03-04 14:47:20 --> Config Class Initialized
INFO - 2020-03-04 14:47:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 14:47:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 14:47:20 --> Utf8 Class Initialized
INFO - 2020-03-04 14:47:20 --> URI Class Initialized
INFO - 2020-03-04 14:47:20 --> Router Class Initialized
INFO - 2020-03-04 14:47:20 --> Output Class Initialized
INFO - 2020-03-04 14:47:20 --> Security Class Initialized
DEBUG - 2020-03-04 14:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 14:47:20 --> Input Class Initialized
INFO - 2020-03-04 14:47:20 --> Language Class Initialized
INFO - 2020-03-04 14:47:20 --> Loader Class Initialized
INFO - 2020-03-04 14:47:20 --> Helper loaded: url_helper
INFO - 2020-03-04 14:47:20 --> Helper loaded: string_helper
INFO - 2020-03-04 14:47:20 --> Database Driver Class Initialized
DEBUG - 2020-03-04 14:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 14:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 14:47:20 --> Controller Class Initialized
INFO - 2020-03-04 14:47:20 --> Model "M_tiket" initialized
INFO - 2020-03-04 14:47:20 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 14:47:20 --> Model "M_pesan" initialized
INFO - 2020-03-04 14:47:20 --> Helper loaded: form_helper
INFO - 2020-03-04 14:47:20 --> Form Validation Class Initialized
INFO - 2020-03-04 14:47:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 14:47:20 --> Final output sent to browser
DEBUG - 2020-03-04 14:47:20 --> Total execution time: 0.0323
INFO - 2020-03-04 14:47:21 --> Config Class Initialized
INFO - 2020-03-04 14:47:21 --> Hooks Class Initialized
DEBUG - 2020-03-04 14:47:21 --> UTF-8 Support Enabled
INFO - 2020-03-04 14:47:21 --> Utf8 Class Initialized
INFO - 2020-03-04 14:47:21 --> URI Class Initialized
INFO - 2020-03-04 14:47:21 --> Router Class Initialized
INFO - 2020-03-04 14:47:21 --> Output Class Initialized
INFO - 2020-03-04 14:47:21 --> Security Class Initialized
DEBUG - 2020-03-04 14:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 14:47:21 --> Input Class Initialized
INFO - 2020-03-04 14:47:21 --> Language Class Initialized
INFO - 2020-03-04 14:47:21 --> Loader Class Initialized
INFO - 2020-03-04 14:47:21 --> Helper loaded: url_helper
INFO - 2020-03-04 14:47:21 --> Helper loaded: string_helper
INFO - 2020-03-04 14:47:21 --> Database Driver Class Initialized
DEBUG - 2020-03-04 14:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 14:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 14:47:21 --> Controller Class Initialized
INFO - 2020-03-04 14:47:21 --> Model "M_tiket" initialized
INFO - 2020-03-04 14:47:21 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 14:47:21 --> Model "M_pesan" initialized
INFO - 2020-03-04 14:47:21 --> Helper loaded: form_helper
INFO - 2020-03-04 14:47:21 --> Form Validation Class Initialized
INFO - 2020-03-04 14:47:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 14:47:21 --> Final output sent to browser
DEBUG - 2020-03-04 14:47:21 --> Total execution time: 0.0069
INFO - 2020-03-04 15:06:51 --> Config Class Initialized
INFO - 2020-03-04 15:06:51 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:06:51 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:06:51 --> Utf8 Class Initialized
INFO - 2020-03-04 15:06:51 --> URI Class Initialized
INFO - 2020-03-04 15:06:51 --> Router Class Initialized
INFO - 2020-03-04 15:06:51 --> Output Class Initialized
INFO - 2020-03-04 15:06:51 --> Security Class Initialized
DEBUG - 2020-03-04 15:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:06:51 --> Input Class Initialized
INFO - 2020-03-04 15:06:51 --> Language Class Initialized
INFO - 2020-03-04 15:06:51 --> Loader Class Initialized
INFO - 2020-03-04 15:06:51 --> Helper loaded: url_helper
INFO - 2020-03-04 15:06:51 --> Helper loaded: string_helper
INFO - 2020-03-04 15:06:51 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:06:51 --> Controller Class Initialized
INFO - 2020-03-04 15:06:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:06:51 --> Pagination Class Initialized
INFO - 2020-03-04 15:06:51 --> Model "M_show" initialized
INFO - 2020-03-04 15:06:51 --> Helper loaded: form_helper
INFO - 2020-03-04 15:06:51 --> Form Validation Class Initialized
INFO - 2020-03-04 15:06:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:06:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:06:51 --> Final output sent to browser
DEBUG - 2020-03-04 15:06:51 --> Total execution time: 0.0465
INFO - 2020-03-04 15:07:26 --> Config Class Initialized
INFO - 2020-03-04 15:07:26 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:07:26 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:07:26 --> Utf8 Class Initialized
INFO - 2020-03-04 15:07:26 --> URI Class Initialized
INFO - 2020-03-04 15:07:26 --> Router Class Initialized
INFO - 2020-03-04 15:07:26 --> Output Class Initialized
INFO - 2020-03-04 15:07:26 --> Security Class Initialized
DEBUG - 2020-03-04 15:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:07:26 --> Input Class Initialized
INFO - 2020-03-04 15:07:26 --> Language Class Initialized
INFO - 2020-03-04 15:07:26 --> Loader Class Initialized
INFO - 2020-03-04 15:07:26 --> Helper loaded: url_helper
INFO - 2020-03-04 15:07:26 --> Helper loaded: string_helper
INFO - 2020-03-04 15:07:26 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:07:26 --> Controller Class Initialized
INFO - 2020-03-04 15:07:26 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:07:26 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:07:26 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:07:26 --> Helper loaded: form_helper
INFO - 2020-03-04 15:07:26 --> Form Validation Class Initialized
INFO - 2020-03-04 15:07:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 15:07:26 --> Final output sent to browser
DEBUG - 2020-03-04 15:07:26 --> Total execution time: 0.0119
INFO - 2020-03-04 15:08:23 --> Config Class Initialized
INFO - 2020-03-04 15:08:23 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:08:23 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:08:23 --> Utf8 Class Initialized
INFO - 2020-03-04 15:08:23 --> URI Class Initialized
INFO - 2020-03-04 15:08:23 --> Router Class Initialized
INFO - 2020-03-04 15:08:23 --> Output Class Initialized
INFO - 2020-03-04 15:08:23 --> Security Class Initialized
DEBUG - 2020-03-04 15:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:08:23 --> Input Class Initialized
INFO - 2020-03-04 15:08:23 --> Language Class Initialized
INFO - 2020-03-04 15:08:23 --> Loader Class Initialized
INFO - 2020-03-04 15:08:23 --> Helper loaded: url_helper
INFO - 2020-03-04 15:08:23 --> Helper loaded: string_helper
INFO - 2020-03-04 15:08:23 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:08:23 --> Controller Class Initialized
INFO - 2020-03-04 15:08:23 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:08:23 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:08:23 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:08:23 --> Helper loaded: form_helper
INFO - 2020-03-04 15:08:23 --> Form Validation Class Initialized
INFO - 2020-03-04 15:08:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 15:08:23 --> Final output sent to browser
DEBUG - 2020-03-04 15:08:23 --> Total execution time: 0.0322
INFO - 2020-03-04 15:12:12 --> Config Class Initialized
INFO - 2020-03-04 15:12:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:12:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:12:12 --> Utf8 Class Initialized
INFO - 2020-03-04 15:12:12 --> URI Class Initialized
INFO - 2020-03-04 15:12:12 --> Router Class Initialized
INFO - 2020-03-04 15:12:12 --> Output Class Initialized
INFO - 2020-03-04 15:12:12 --> Security Class Initialized
DEBUG - 2020-03-04 15:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:12:12 --> Input Class Initialized
INFO - 2020-03-04 15:12:12 --> Language Class Initialized
INFO - 2020-03-04 15:12:12 --> Loader Class Initialized
INFO - 2020-03-04 15:12:12 --> Helper loaded: url_helper
INFO - 2020-03-04 15:12:12 --> Helper loaded: string_helper
INFO - 2020-03-04 15:12:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:12:12 --> Controller Class Initialized
INFO - 2020-03-04 15:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:12:12 --> Pagination Class Initialized
INFO - 2020-03-04 15:12:12 --> Model "M_show" initialized
INFO - 2020-03-04 15:12:12 --> Helper loaded: form_helper
INFO - 2020-03-04 15:12:12 --> Form Validation Class Initialized
INFO - 2020-03-04 15:12:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:12:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:12:12 --> Final output sent to browser
DEBUG - 2020-03-04 15:12:12 --> Total execution time: 0.0318
INFO - 2020-03-04 15:12:15 --> Config Class Initialized
INFO - 2020-03-04 15:12:15 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:12:15 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:12:15 --> Utf8 Class Initialized
INFO - 2020-03-04 15:12:15 --> URI Class Initialized
INFO - 2020-03-04 15:12:15 --> Router Class Initialized
INFO - 2020-03-04 15:12:15 --> Output Class Initialized
INFO - 2020-03-04 15:12:15 --> Security Class Initialized
DEBUG - 2020-03-04 15:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:12:15 --> Input Class Initialized
INFO - 2020-03-04 15:12:15 --> Language Class Initialized
ERROR - 2020-03-04 15:12:15 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 15:12:24 --> Config Class Initialized
INFO - 2020-03-04 15:12:24 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:12:24 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:12:24 --> Utf8 Class Initialized
INFO - 2020-03-04 15:12:24 --> URI Class Initialized
INFO - 2020-03-04 15:12:24 --> Router Class Initialized
INFO - 2020-03-04 15:12:24 --> Output Class Initialized
INFO - 2020-03-04 15:12:24 --> Security Class Initialized
DEBUG - 2020-03-04 15:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:12:24 --> Input Class Initialized
INFO - 2020-03-04 15:12:24 --> Language Class Initialized
INFO - 2020-03-04 15:12:24 --> Loader Class Initialized
INFO - 2020-03-04 15:12:24 --> Helper loaded: url_helper
INFO - 2020-03-04 15:12:24 --> Helper loaded: string_helper
INFO - 2020-03-04 15:12:24 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:12:24 --> Controller Class Initialized
INFO - 2020-03-04 15:12:24 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:12:24 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:12:24 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:12:24 --> Helper loaded: form_helper
INFO - 2020-03-04 15:12:24 --> Form Validation Class Initialized
INFO - 2020-03-04 15:12:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 15:12:24 --> Final output sent to browser
DEBUG - 2020-03-04 15:12:24 --> Total execution time: 0.0115
INFO - 2020-03-04 15:13:42 --> Config Class Initialized
INFO - 2020-03-04 15:13:42 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:13:42 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:13:42 --> Utf8 Class Initialized
INFO - 2020-03-04 15:13:42 --> URI Class Initialized
INFO - 2020-03-04 15:13:42 --> Router Class Initialized
INFO - 2020-03-04 15:13:42 --> Output Class Initialized
INFO - 2020-03-04 15:13:42 --> Security Class Initialized
DEBUG - 2020-03-04 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:13:42 --> Input Class Initialized
INFO - 2020-03-04 15:13:42 --> Language Class Initialized
INFO - 2020-03-04 15:13:42 --> Loader Class Initialized
INFO - 2020-03-04 15:13:42 --> Helper loaded: url_helper
INFO - 2020-03-04 15:13:42 --> Helper loaded: string_helper
INFO - 2020-03-04 15:13:42 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:13:42 --> Controller Class Initialized
INFO - 2020-03-04 15:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:13:42 --> Pagination Class Initialized
INFO - 2020-03-04 15:13:42 --> Model "M_show" initialized
INFO - 2020-03-04 15:13:42 --> Helper loaded: form_helper
INFO - 2020-03-04 15:13:42 --> Form Validation Class Initialized
INFO - 2020-03-04 15:13:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:13:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:13:42 --> Final output sent to browser
DEBUG - 2020-03-04 15:13:42 --> Total execution time: 0.0370
INFO - 2020-03-04 15:13:43 --> Config Class Initialized
INFO - 2020-03-04 15:13:43 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:13:43 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:13:43 --> Utf8 Class Initialized
INFO - 2020-03-04 15:13:43 --> URI Class Initialized
INFO - 2020-03-04 15:13:43 --> Router Class Initialized
INFO - 2020-03-04 15:13:43 --> Output Class Initialized
INFO - 2020-03-04 15:13:43 --> Security Class Initialized
DEBUG - 2020-03-04 15:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:13:43 --> Input Class Initialized
INFO - 2020-03-04 15:13:43 --> Language Class Initialized
INFO - 2020-03-04 15:13:43 --> Loader Class Initialized
INFO - 2020-03-04 15:13:43 --> Helper loaded: url_helper
INFO - 2020-03-04 15:13:43 --> Helper loaded: string_helper
INFO - 2020-03-04 15:13:43 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:13:43 --> Controller Class Initialized
INFO - 2020-03-04 15:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:13:43 --> Pagination Class Initialized
INFO - 2020-03-04 15:13:43 --> Model "M_show" initialized
INFO - 2020-03-04 15:13:43 --> Helper loaded: form_helper
INFO - 2020-03-04 15:13:43 --> Form Validation Class Initialized
INFO - 2020-03-04 15:13:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:13:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:13:43 --> Final output sent to browser
DEBUG - 2020-03-04 15:13:43 --> Total execution time: 0.0065
INFO - 2020-03-04 15:13:55 --> Config Class Initialized
INFO - 2020-03-04 15:13:55 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:13:55 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:13:55 --> Utf8 Class Initialized
INFO - 2020-03-04 15:13:55 --> URI Class Initialized
INFO - 2020-03-04 15:13:55 --> Router Class Initialized
INFO - 2020-03-04 15:13:55 --> Output Class Initialized
INFO - 2020-03-04 15:13:55 --> Security Class Initialized
DEBUG - 2020-03-04 15:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:13:55 --> Input Class Initialized
INFO - 2020-03-04 15:13:55 --> Language Class Initialized
INFO - 2020-03-04 15:13:55 --> Loader Class Initialized
INFO - 2020-03-04 15:13:55 --> Helper loaded: url_helper
INFO - 2020-03-04 15:13:55 --> Helper loaded: string_helper
INFO - 2020-03-04 15:13:55 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:13:55 --> Controller Class Initialized
INFO - 2020-03-04 15:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:13:55 --> Pagination Class Initialized
INFO - 2020-03-04 15:13:55 --> Model "M_show" initialized
INFO - 2020-03-04 15:13:55 --> Helper loaded: form_helper
INFO - 2020-03-04 15:13:55 --> Form Validation Class Initialized
INFO - 2020-03-04 15:13:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:13:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:13:55 --> Final output sent to browser
DEBUG - 2020-03-04 15:13:55 --> Total execution time: 0.0064
INFO - 2020-03-04 15:14:57 --> Config Class Initialized
INFO - 2020-03-04 15:14:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:14:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:14:57 --> Utf8 Class Initialized
INFO - 2020-03-04 15:14:57 --> URI Class Initialized
INFO - 2020-03-04 15:14:57 --> Router Class Initialized
INFO - 2020-03-04 15:14:57 --> Output Class Initialized
INFO - 2020-03-04 15:14:57 --> Security Class Initialized
DEBUG - 2020-03-04 15:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:14:57 --> Input Class Initialized
INFO - 2020-03-04 15:14:57 --> Language Class Initialized
INFO - 2020-03-04 15:14:57 --> Loader Class Initialized
INFO - 2020-03-04 15:14:57 --> Helper loaded: url_helper
INFO - 2020-03-04 15:14:57 --> Helper loaded: string_helper
INFO - 2020-03-04 15:14:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:14:57 --> Controller Class Initialized
INFO - 2020-03-04 15:14:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:14:57 --> Pagination Class Initialized
INFO - 2020-03-04 15:14:57 --> Model "M_show" initialized
INFO - 2020-03-04 15:14:57 --> Helper loaded: form_helper
INFO - 2020-03-04 15:14:57 --> Form Validation Class Initialized
INFO - 2020-03-04 15:14:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:14:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:14:57 --> Final output sent to browser
DEBUG - 2020-03-04 15:14:57 --> Total execution time: 0.0074
INFO - 2020-03-04 15:15:32 --> Config Class Initialized
INFO - 2020-03-04 15:15:32 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:15:32 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:15:32 --> Utf8 Class Initialized
INFO - 2020-03-04 15:15:32 --> URI Class Initialized
INFO - 2020-03-04 15:15:32 --> Router Class Initialized
INFO - 2020-03-04 15:15:32 --> Output Class Initialized
INFO - 2020-03-04 15:15:32 --> Security Class Initialized
DEBUG - 2020-03-04 15:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:15:32 --> Input Class Initialized
INFO - 2020-03-04 15:15:32 --> Language Class Initialized
INFO - 2020-03-04 15:15:32 --> Loader Class Initialized
INFO - 2020-03-04 15:15:32 --> Helper loaded: url_helper
INFO - 2020-03-04 15:15:32 --> Helper loaded: string_helper
INFO - 2020-03-04 15:15:32 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:15:33 --> Controller Class Initialized
INFO - 2020-03-04 15:15:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:15:33 --> Pagination Class Initialized
INFO - 2020-03-04 15:15:33 --> Model "M_show" initialized
INFO - 2020-03-04 15:15:33 --> Helper loaded: form_helper
INFO - 2020-03-04 15:15:33 --> Form Validation Class Initialized
INFO - 2020-03-04 15:15:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:15:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:15:33 --> Final output sent to browser
DEBUG - 2020-03-04 15:15:33 --> Total execution time: 0.1968
INFO - 2020-03-04 15:18:15 --> Config Class Initialized
INFO - 2020-03-04 15:18:15 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:18:15 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:18:15 --> Utf8 Class Initialized
INFO - 2020-03-04 15:18:15 --> URI Class Initialized
INFO - 2020-03-04 15:18:15 --> Router Class Initialized
INFO - 2020-03-04 15:18:15 --> Output Class Initialized
INFO - 2020-03-04 15:18:15 --> Security Class Initialized
DEBUG - 2020-03-04 15:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:18:15 --> Input Class Initialized
INFO - 2020-03-04 15:18:15 --> Language Class Initialized
INFO - 2020-03-04 15:18:15 --> Loader Class Initialized
INFO - 2020-03-04 15:18:15 --> Helper loaded: url_helper
INFO - 2020-03-04 15:18:15 --> Helper loaded: string_helper
INFO - 2020-03-04 15:18:15 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:18:15 --> Controller Class Initialized
INFO - 2020-03-04 15:18:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:18:15 --> Pagination Class Initialized
INFO - 2020-03-04 15:18:15 --> Model "M_show" initialized
INFO - 2020-03-04 15:18:15 --> Helper loaded: form_helper
INFO - 2020-03-04 15:18:15 --> Form Validation Class Initialized
INFO - 2020-03-04 15:18:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:18:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:18:15 --> Final output sent to browser
DEBUG - 2020-03-04 15:18:15 --> Total execution time: 0.0566
INFO - 2020-03-04 15:18:52 --> Config Class Initialized
INFO - 2020-03-04 15:18:52 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:18:52 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:18:52 --> Utf8 Class Initialized
INFO - 2020-03-04 15:18:52 --> URI Class Initialized
INFO - 2020-03-04 15:18:52 --> Router Class Initialized
INFO - 2020-03-04 15:18:52 --> Output Class Initialized
INFO - 2020-03-04 15:18:52 --> Security Class Initialized
DEBUG - 2020-03-04 15:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:18:52 --> Input Class Initialized
INFO - 2020-03-04 15:18:52 --> Language Class Initialized
INFO - 2020-03-04 15:18:52 --> Loader Class Initialized
INFO - 2020-03-04 15:18:52 --> Helper loaded: url_helper
INFO - 2020-03-04 15:18:52 --> Helper loaded: string_helper
INFO - 2020-03-04 15:18:52 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:18:52 --> Controller Class Initialized
INFO - 2020-03-04 15:18:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:18:52 --> Pagination Class Initialized
INFO - 2020-03-04 15:18:52 --> Model "M_show" initialized
INFO - 2020-03-04 15:18:52 --> Helper loaded: form_helper
INFO - 2020-03-04 15:18:52 --> Form Validation Class Initialized
INFO - 2020-03-04 15:18:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:18:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:18:52 --> Final output sent to browser
DEBUG - 2020-03-04 15:18:52 --> Total execution time: 0.0077
INFO - 2020-03-04 15:19:04 --> Config Class Initialized
INFO - 2020-03-04 15:19:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:19:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:19:04 --> Utf8 Class Initialized
INFO - 2020-03-04 15:19:04 --> URI Class Initialized
INFO - 2020-03-04 15:19:04 --> Router Class Initialized
INFO - 2020-03-04 15:19:04 --> Output Class Initialized
INFO - 2020-03-04 15:19:04 --> Security Class Initialized
DEBUG - 2020-03-04 15:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:19:04 --> Input Class Initialized
INFO - 2020-03-04 15:19:04 --> Language Class Initialized
INFO - 2020-03-04 15:19:04 --> Loader Class Initialized
INFO - 2020-03-04 15:19:04 --> Helper loaded: url_helper
INFO - 2020-03-04 15:19:04 --> Helper loaded: string_helper
INFO - 2020-03-04 15:19:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:19:05 --> Controller Class Initialized
INFO - 2020-03-04 15:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:19:05 --> Pagination Class Initialized
INFO - 2020-03-04 15:19:05 --> Model "M_show" initialized
INFO - 2020-03-04 15:19:05 --> Helper loaded: form_helper
INFO - 2020-03-04 15:19:05 --> Form Validation Class Initialized
INFO - 2020-03-04 15:19:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:19:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:19:05 --> Final output sent to browser
DEBUG - 2020-03-04 15:19:05 --> Total execution time: 0.2991
INFO - 2020-03-04 15:19:14 --> Config Class Initialized
INFO - 2020-03-04 15:19:14 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:19:14 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:19:14 --> Utf8 Class Initialized
INFO - 2020-03-04 15:19:14 --> URI Class Initialized
INFO - 2020-03-04 15:19:14 --> Router Class Initialized
INFO - 2020-03-04 15:19:14 --> Output Class Initialized
INFO - 2020-03-04 15:19:14 --> Security Class Initialized
DEBUG - 2020-03-04 15:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:19:14 --> Input Class Initialized
INFO - 2020-03-04 15:19:14 --> Language Class Initialized
INFO - 2020-03-04 15:19:14 --> Loader Class Initialized
INFO - 2020-03-04 15:19:14 --> Helper loaded: url_helper
INFO - 2020-03-04 15:19:14 --> Helper loaded: string_helper
INFO - 2020-03-04 15:19:14 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:19:14 --> Controller Class Initialized
INFO - 2020-03-04 15:19:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:19:14 --> Pagination Class Initialized
INFO - 2020-03-04 15:19:14 --> Model "M_show" initialized
INFO - 2020-03-04 15:19:14 --> Helper loaded: form_helper
INFO - 2020-03-04 15:19:14 --> Form Validation Class Initialized
INFO - 2020-03-04 15:19:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:19:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:19:14 --> Final output sent to browser
DEBUG - 2020-03-04 15:19:14 --> Total execution time: 0.0063
INFO - 2020-03-04 15:19:32 --> Config Class Initialized
INFO - 2020-03-04 15:19:32 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:19:32 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:19:32 --> Utf8 Class Initialized
INFO - 2020-03-04 15:19:32 --> URI Class Initialized
INFO - 2020-03-04 15:19:32 --> Router Class Initialized
INFO - 2020-03-04 15:19:32 --> Output Class Initialized
INFO - 2020-03-04 15:19:32 --> Security Class Initialized
DEBUG - 2020-03-04 15:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:19:32 --> Input Class Initialized
INFO - 2020-03-04 15:19:32 --> Language Class Initialized
INFO - 2020-03-04 15:19:32 --> Loader Class Initialized
INFO - 2020-03-04 15:19:32 --> Helper loaded: url_helper
INFO - 2020-03-04 15:19:32 --> Helper loaded: string_helper
INFO - 2020-03-04 15:19:32 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:19:32 --> Controller Class Initialized
INFO - 2020-03-04 15:19:32 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:19:32 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:19:32 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:19:32 --> Helper loaded: form_helper
INFO - 2020-03-04 15:19:32 --> Form Validation Class Initialized
INFO - 2020-03-04 15:19:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 15:19:32 --> Final output sent to browser
DEBUG - 2020-03-04 15:19:32 --> Total execution time: 0.0135
INFO - 2020-03-04 15:20:06 --> Config Class Initialized
INFO - 2020-03-04 15:20:06 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:20:06 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:20:06 --> Utf8 Class Initialized
INFO - 2020-03-04 15:20:06 --> URI Class Initialized
INFO - 2020-03-04 15:20:06 --> Router Class Initialized
INFO - 2020-03-04 15:20:06 --> Output Class Initialized
INFO - 2020-03-04 15:20:06 --> Security Class Initialized
DEBUG - 2020-03-04 15:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:20:06 --> Input Class Initialized
INFO - 2020-03-04 15:20:06 --> Language Class Initialized
INFO - 2020-03-04 15:20:06 --> Loader Class Initialized
INFO - 2020-03-04 15:20:06 --> Helper loaded: url_helper
INFO - 2020-03-04 15:20:06 --> Helper loaded: string_helper
INFO - 2020-03-04 15:20:06 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:20:06 --> Controller Class Initialized
INFO - 2020-03-04 15:20:06 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:20:06 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:20:06 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:20:06 --> Helper loaded: form_helper
INFO - 2020-03-04 15:20:06 --> Form Validation Class Initialized
INFO - 2020-03-04 15:20:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 15:20:06 --> Final output sent to browser
DEBUG - 2020-03-04 15:20:06 --> Total execution time: 0.0141
INFO - 2020-03-04 15:20:43 --> Config Class Initialized
INFO - 2020-03-04 15:20:43 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:20:43 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:20:43 --> Utf8 Class Initialized
INFO - 2020-03-04 15:20:43 --> URI Class Initialized
INFO - 2020-03-04 15:20:43 --> Router Class Initialized
INFO - 2020-03-04 15:20:43 --> Output Class Initialized
INFO - 2020-03-04 15:20:43 --> Security Class Initialized
DEBUG - 2020-03-04 15:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:20:43 --> Input Class Initialized
INFO - 2020-03-04 15:20:43 --> Language Class Initialized
INFO - 2020-03-04 15:20:43 --> Loader Class Initialized
INFO - 2020-03-04 15:20:43 --> Helper loaded: url_helper
INFO - 2020-03-04 15:20:43 --> Helper loaded: string_helper
INFO - 2020-03-04 15:20:43 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:20:43 --> Controller Class Initialized
INFO - 2020-03-04 15:20:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:20:43 --> Pagination Class Initialized
INFO - 2020-03-04 15:20:43 --> Model "M_show" initialized
INFO - 2020-03-04 15:20:43 --> Helper loaded: form_helper
INFO - 2020-03-04 15:20:43 --> Form Validation Class Initialized
INFO - 2020-03-04 15:20:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:20:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:20:43 --> Final output sent to browser
DEBUG - 2020-03-04 15:20:43 --> Total execution time: 0.0450
INFO - 2020-03-04 15:21:26 --> Config Class Initialized
INFO - 2020-03-04 15:21:26 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:21:26 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:21:26 --> Utf8 Class Initialized
INFO - 2020-03-04 15:21:26 --> URI Class Initialized
INFO - 2020-03-04 15:21:26 --> Router Class Initialized
INFO - 2020-03-04 15:21:26 --> Output Class Initialized
INFO - 2020-03-04 15:21:26 --> Security Class Initialized
DEBUG - 2020-03-04 15:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:21:26 --> Input Class Initialized
INFO - 2020-03-04 15:21:26 --> Language Class Initialized
INFO - 2020-03-04 15:21:26 --> Loader Class Initialized
INFO - 2020-03-04 15:21:26 --> Helper loaded: url_helper
INFO - 2020-03-04 15:21:26 --> Helper loaded: string_helper
INFO - 2020-03-04 15:21:26 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:21:26 --> Controller Class Initialized
INFO - 2020-03-04 15:21:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:21:26 --> Pagination Class Initialized
INFO - 2020-03-04 15:21:26 --> Model "M_show" initialized
INFO - 2020-03-04 15:21:26 --> Helper loaded: form_helper
INFO - 2020-03-04 15:21:26 --> Form Validation Class Initialized
INFO - 2020-03-04 15:21:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:21:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:21:26 --> Final output sent to browser
DEBUG - 2020-03-04 15:21:26 --> Total execution time: 0.2549
INFO - 2020-03-04 15:21:27 --> Config Class Initialized
INFO - 2020-03-04 15:21:27 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:21:27 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:21:27 --> Utf8 Class Initialized
INFO - 2020-03-04 15:21:27 --> URI Class Initialized
INFO - 2020-03-04 15:21:27 --> Router Class Initialized
INFO - 2020-03-04 15:21:27 --> Output Class Initialized
INFO - 2020-03-04 15:21:27 --> Security Class Initialized
DEBUG - 2020-03-04 15:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:21:27 --> Input Class Initialized
INFO - 2020-03-04 15:21:27 --> Language Class Initialized
ERROR - 2020-03-04 15:21:27 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 15:21:52 --> Config Class Initialized
INFO - 2020-03-04 15:21:52 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:21:52 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:21:52 --> Utf8 Class Initialized
INFO - 2020-03-04 15:21:52 --> URI Class Initialized
INFO - 2020-03-04 15:21:52 --> Router Class Initialized
INFO - 2020-03-04 15:21:52 --> Output Class Initialized
INFO - 2020-03-04 15:21:52 --> Security Class Initialized
DEBUG - 2020-03-04 15:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:21:52 --> Input Class Initialized
INFO - 2020-03-04 15:21:52 --> Language Class Initialized
INFO - 2020-03-04 15:21:52 --> Loader Class Initialized
INFO - 2020-03-04 15:21:52 --> Helper loaded: url_helper
INFO - 2020-03-04 15:21:52 --> Helper loaded: string_helper
INFO - 2020-03-04 15:21:52 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:21:53 --> Controller Class Initialized
INFO - 2020-03-04 15:21:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:21:53 --> Pagination Class Initialized
INFO - 2020-03-04 15:21:53 --> Model "M_show" initialized
INFO - 2020-03-04 15:21:53 --> Helper loaded: form_helper
INFO - 2020-03-04 15:21:53 --> Form Validation Class Initialized
INFO - 2020-03-04 15:21:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:21:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:21:53 --> Final output sent to browser
DEBUG - 2020-03-04 15:21:53 --> Total execution time: 0.1752
INFO - 2020-03-04 15:22:18 --> Config Class Initialized
INFO - 2020-03-04 15:22:18 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:22:18 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:22:18 --> Utf8 Class Initialized
INFO - 2020-03-04 15:22:18 --> URI Class Initialized
INFO - 2020-03-04 15:22:18 --> Router Class Initialized
INFO - 2020-03-04 15:22:18 --> Output Class Initialized
INFO - 2020-03-04 15:22:18 --> Security Class Initialized
DEBUG - 2020-03-04 15:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:22:18 --> Input Class Initialized
INFO - 2020-03-04 15:22:18 --> Language Class Initialized
INFO - 2020-03-04 15:22:18 --> Loader Class Initialized
INFO - 2020-03-04 15:22:18 --> Helper loaded: url_helper
INFO - 2020-03-04 15:22:18 --> Helper loaded: string_helper
INFO - 2020-03-04 15:22:18 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:22:18 --> Controller Class Initialized
INFO - 2020-03-04 15:22:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:22:18 --> Pagination Class Initialized
INFO - 2020-03-04 15:22:18 --> Model "M_show" initialized
INFO - 2020-03-04 15:22:18 --> Helper loaded: form_helper
INFO - 2020-03-04 15:22:18 --> Form Validation Class Initialized
INFO - 2020-03-04 15:22:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:22:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 15:22:18 --> Final output sent to browser
DEBUG - 2020-03-04 15:22:18 --> Total execution time: 0.0076
INFO - 2020-03-04 15:22:35 --> Config Class Initialized
INFO - 2020-03-04 15:22:35 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:22:35 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:22:35 --> Utf8 Class Initialized
INFO - 2020-03-04 15:22:35 --> URI Class Initialized
INFO - 2020-03-04 15:22:35 --> Router Class Initialized
INFO - 2020-03-04 15:22:35 --> Output Class Initialized
INFO - 2020-03-04 15:22:35 --> Security Class Initialized
DEBUG - 2020-03-04 15:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:22:35 --> Input Class Initialized
INFO - 2020-03-04 15:22:35 --> Language Class Initialized
INFO - 2020-03-04 15:22:35 --> Loader Class Initialized
INFO - 2020-03-04 15:22:35 --> Helper loaded: url_helper
INFO - 2020-03-04 15:22:35 --> Helper loaded: string_helper
INFO - 2020-03-04 15:22:35 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:22:35 --> Controller Class Initialized
INFO - 2020-03-04 15:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:22:35 --> Pagination Class Initialized
INFO - 2020-03-04 15:22:35 --> Model "M_show" initialized
INFO - 2020-03-04 15:22:35 --> Helper loaded: form_helper
INFO - 2020-03-04 15:22:35 --> Form Validation Class Initialized
INFO - 2020-03-04 15:22:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:22:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:22:35 --> Final output sent to browser
DEBUG - 2020-03-04 15:22:35 --> Total execution time: 0.0068
INFO - 2020-03-04 15:22:41 --> Config Class Initialized
INFO - 2020-03-04 15:22:41 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:22:41 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:22:41 --> Utf8 Class Initialized
INFO - 2020-03-04 15:22:41 --> URI Class Initialized
INFO - 2020-03-04 15:22:41 --> Router Class Initialized
INFO - 2020-03-04 15:22:41 --> Output Class Initialized
INFO - 2020-03-04 15:22:41 --> Security Class Initialized
DEBUG - 2020-03-04 15:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:22:41 --> Input Class Initialized
INFO - 2020-03-04 15:22:41 --> Language Class Initialized
INFO - 2020-03-04 15:22:41 --> Loader Class Initialized
INFO - 2020-03-04 15:22:41 --> Helper loaded: url_helper
INFO - 2020-03-04 15:22:41 --> Helper loaded: string_helper
INFO - 2020-03-04 15:22:41 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:22:41 --> Controller Class Initialized
INFO - 2020-03-04 15:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:22:41 --> Pagination Class Initialized
INFO - 2020-03-04 15:22:41 --> Model "M_show" initialized
INFO - 2020-03-04 15:22:41 --> Helper loaded: form_helper
INFO - 2020-03-04 15:22:41 --> Form Validation Class Initialized
INFO - 2020-03-04 15:22:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:22:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 15:22:41 --> Final output sent to browser
DEBUG - 2020-03-04 15:22:41 --> Total execution time: 0.0054
INFO - 2020-03-04 15:22:55 --> Config Class Initialized
INFO - 2020-03-04 15:22:55 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:22:55 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:22:55 --> Utf8 Class Initialized
INFO - 2020-03-04 15:22:55 --> URI Class Initialized
INFO - 2020-03-04 15:22:55 --> Router Class Initialized
INFO - 2020-03-04 15:22:55 --> Output Class Initialized
INFO - 2020-03-04 15:22:55 --> Security Class Initialized
DEBUG - 2020-03-04 15:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:22:55 --> Input Class Initialized
INFO - 2020-03-04 15:22:55 --> Language Class Initialized
INFO - 2020-03-04 15:22:55 --> Loader Class Initialized
INFO - 2020-03-04 15:22:55 --> Helper loaded: url_helper
INFO - 2020-03-04 15:22:55 --> Helper loaded: string_helper
INFO - 2020-03-04 15:22:55 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:22:55 --> Controller Class Initialized
INFO - 2020-03-04 15:22:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:22:55 --> Pagination Class Initialized
INFO - 2020-03-04 15:22:55 --> Model "M_show" initialized
INFO - 2020-03-04 15:22:55 --> Helper loaded: form_helper
INFO - 2020-03-04 15:22:55 --> Form Validation Class Initialized
INFO - 2020-03-04 15:22:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:22:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 15:22:55 --> Final output sent to browser
DEBUG - 2020-03-04 15:22:55 --> Total execution time: 0.0076
INFO - 2020-03-04 15:22:57 --> Config Class Initialized
INFO - 2020-03-04 15:22:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:22:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:22:57 --> Utf8 Class Initialized
INFO - 2020-03-04 15:22:57 --> URI Class Initialized
INFO - 2020-03-04 15:22:57 --> Router Class Initialized
INFO - 2020-03-04 15:22:57 --> Output Class Initialized
INFO - 2020-03-04 15:22:57 --> Security Class Initialized
DEBUG - 2020-03-04 15:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:22:57 --> Input Class Initialized
INFO - 2020-03-04 15:22:57 --> Language Class Initialized
ERROR - 2020-03-04 15:22:57 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 15:23:11 --> Config Class Initialized
INFO - 2020-03-04 15:23:11 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:23:11 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:23:11 --> Utf8 Class Initialized
INFO - 2020-03-04 15:23:11 --> URI Class Initialized
INFO - 2020-03-04 15:23:11 --> Router Class Initialized
INFO - 2020-03-04 15:23:11 --> Output Class Initialized
INFO - 2020-03-04 15:23:11 --> Security Class Initialized
DEBUG - 2020-03-04 15:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:23:11 --> Input Class Initialized
INFO - 2020-03-04 15:23:11 --> Language Class Initialized
INFO - 2020-03-04 15:23:11 --> Loader Class Initialized
INFO - 2020-03-04 15:23:11 --> Helper loaded: url_helper
INFO - 2020-03-04 15:23:11 --> Helper loaded: string_helper
INFO - 2020-03-04 15:23:11 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:23:11 --> Controller Class Initialized
INFO - 2020-03-04 15:23:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:23:11 --> Pagination Class Initialized
INFO - 2020-03-04 15:23:11 --> Model "M_show" initialized
INFO - 2020-03-04 15:23:11 --> Helper loaded: form_helper
INFO - 2020-03-04 15:23:11 --> Form Validation Class Initialized
INFO - 2020-03-04 15:23:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:23:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:23:11 --> Final output sent to browser
DEBUG - 2020-03-04 15:23:11 --> Total execution time: 0.0078
INFO - 2020-03-04 15:23:14 --> Config Class Initialized
INFO - 2020-03-04 15:23:14 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:23:14 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:23:14 --> Utf8 Class Initialized
INFO - 2020-03-04 15:23:14 --> URI Class Initialized
INFO - 2020-03-04 15:23:14 --> Router Class Initialized
INFO - 2020-03-04 15:23:14 --> Output Class Initialized
INFO - 2020-03-04 15:23:14 --> Security Class Initialized
DEBUG - 2020-03-04 15:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:23:14 --> Input Class Initialized
INFO - 2020-03-04 15:23:14 --> Language Class Initialized
INFO - 2020-03-04 15:23:14 --> Loader Class Initialized
INFO - 2020-03-04 15:23:14 --> Helper loaded: url_helper
INFO - 2020-03-04 15:23:14 --> Helper loaded: string_helper
INFO - 2020-03-04 15:23:14 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:23:14 --> Controller Class Initialized
INFO - 2020-03-04 15:23:14 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:23:14 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:23:14 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:23:14 --> Helper loaded: form_helper
INFO - 2020-03-04 15:23:14 --> Form Validation Class Initialized
INFO - 2020-03-04 15:23:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 15:23:14 --> Final output sent to browser
DEBUG - 2020-03-04 15:23:14 --> Total execution time: 0.0073
INFO - 2020-03-04 15:23:27 --> Config Class Initialized
INFO - 2020-03-04 15:23:27 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:23:27 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:23:27 --> Utf8 Class Initialized
INFO - 2020-03-04 15:23:27 --> URI Class Initialized
INFO - 2020-03-04 15:23:27 --> Router Class Initialized
INFO - 2020-03-04 15:23:27 --> Output Class Initialized
INFO - 2020-03-04 15:23:27 --> Security Class Initialized
DEBUG - 2020-03-04 15:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:23:27 --> Input Class Initialized
INFO - 2020-03-04 15:23:27 --> Language Class Initialized
INFO - 2020-03-04 15:23:27 --> Loader Class Initialized
INFO - 2020-03-04 15:23:27 --> Helper loaded: url_helper
INFO - 2020-03-04 15:23:27 --> Helper loaded: string_helper
INFO - 2020-03-04 15:23:27 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:23:27 --> Controller Class Initialized
INFO - 2020-03-04 15:23:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:23:27 --> Pagination Class Initialized
INFO - 2020-03-04 15:23:27 --> Model "M_show" initialized
INFO - 2020-03-04 15:23:27 --> Helper loaded: form_helper
INFO - 2020-03-04 15:23:27 --> Form Validation Class Initialized
INFO - 2020-03-04 15:23:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:23:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 15:23:27 --> Final output sent to browser
DEBUG - 2020-03-04 15:23:27 --> Total execution time: 0.0064
INFO - 2020-03-04 15:23:32 --> Config Class Initialized
INFO - 2020-03-04 15:23:32 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:23:32 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:23:32 --> Utf8 Class Initialized
INFO - 2020-03-04 15:23:32 --> URI Class Initialized
INFO - 2020-03-04 15:23:32 --> Router Class Initialized
INFO - 2020-03-04 15:23:32 --> Output Class Initialized
INFO - 2020-03-04 15:23:32 --> Security Class Initialized
DEBUG - 2020-03-04 15:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:23:32 --> Input Class Initialized
INFO - 2020-03-04 15:23:32 --> Language Class Initialized
INFO - 2020-03-04 15:23:32 --> Loader Class Initialized
INFO - 2020-03-04 15:23:32 --> Helper loaded: url_helper
INFO - 2020-03-04 15:23:32 --> Helper loaded: string_helper
INFO - 2020-03-04 15:23:32 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:23:32 --> Controller Class Initialized
INFO - 2020-03-04 15:23:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:23:32 --> Pagination Class Initialized
INFO - 2020-03-04 15:23:32 --> Model "M_show" initialized
INFO - 2020-03-04 15:23:32 --> Helper loaded: form_helper
INFO - 2020-03-04 15:23:32 --> Form Validation Class Initialized
INFO - 2020-03-04 15:23:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:23:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:23:32 --> Final output sent to browser
DEBUG - 2020-03-04 15:23:32 --> Total execution time: 0.0073
INFO - 2020-03-04 15:23:37 --> Config Class Initialized
INFO - 2020-03-04 15:23:37 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:23:37 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:23:37 --> Utf8 Class Initialized
INFO - 2020-03-04 15:23:37 --> URI Class Initialized
DEBUG - 2020-03-04 15:23:37 --> No URI present. Default controller set.
INFO - 2020-03-04 15:23:37 --> Router Class Initialized
INFO - 2020-03-04 15:23:37 --> Output Class Initialized
INFO - 2020-03-04 15:23:37 --> Security Class Initialized
DEBUG - 2020-03-04 15:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:23:37 --> Input Class Initialized
INFO - 2020-03-04 15:23:37 --> Language Class Initialized
INFO - 2020-03-04 15:23:37 --> Loader Class Initialized
INFO - 2020-03-04 15:23:37 --> Helper loaded: url_helper
INFO - 2020-03-04 15:23:37 --> Helper loaded: string_helper
INFO - 2020-03-04 15:23:37 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:23:37 --> Controller Class Initialized
INFO - 2020-03-04 15:23:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:23:37 --> Pagination Class Initialized
INFO - 2020-03-04 15:23:37 --> Model "M_show" initialized
INFO - 2020-03-04 15:23:37 --> Helper loaded: form_helper
INFO - 2020-03-04 15:23:37 --> Form Validation Class Initialized
INFO - 2020-03-04 15:23:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:23:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 15:23:37 --> Final output sent to browser
DEBUG - 2020-03-04 15:23:37 --> Total execution time: 0.0087
INFO - 2020-03-04 15:23:44 --> Config Class Initialized
INFO - 2020-03-04 15:23:44 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:23:44 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:23:44 --> Utf8 Class Initialized
INFO - 2020-03-04 15:23:44 --> URI Class Initialized
INFO - 2020-03-04 15:23:44 --> Router Class Initialized
INFO - 2020-03-04 15:23:44 --> Output Class Initialized
INFO - 2020-03-04 15:23:44 --> Security Class Initialized
DEBUG - 2020-03-04 15:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:23:44 --> Input Class Initialized
INFO - 2020-03-04 15:23:44 --> Language Class Initialized
INFO - 2020-03-04 15:23:44 --> Loader Class Initialized
INFO - 2020-03-04 15:23:44 --> Helper loaded: url_helper
INFO - 2020-03-04 15:23:44 --> Helper loaded: string_helper
INFO - 2020-03-04 15:23:44 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:23:44 --> Controller Class Initialized
INFO - 2020-03-04 15:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:23:44 --> Pagination Class Initialized
INFO - 2020-03-04 15:23:44 --> Model "M_show" initialized
INFO - 2020-03-04 15:23:44 --> Helper loaded: form_helper
INFO - 2020-03-04 15:23:44 --> Form Validation Class Initialized
INFO - 2020-03-04 15:23:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:23:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:23:44 --> Final output sent to browser
DEBUG - 2020-03-04 15:23:44 --> Total execution time: 0.0079
INFO - 2020-03-04 15:23:49 --> Config Class Initialized
INFO - 2020-03-04 15:23:49 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:23:49 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:23:49 --> Utf8 Class Initialized
INFO - 2020-03-04 15:23:49 --> URI Class Initialized
INFO - 2020-03-04 15:23:49 --> Router Class Initialized
INFO - 2020-03-04 15:23:49 --> Output Class Initialized
INFO - 2020-03-04 15:23:49 --> Security Class Initialized
DEBUG - 2020-03-04 15:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:23:49 --> Input Class Initialized
INFO - 2020-03-04 15:23:49 --> Language Class Initialized
INFO - 2020-03-04 15:23:49 --> Loader Class Initialized
INFO - 2020-03-04 15:23:49 --> Helper loaded: url_helper
INFO - 2020-03-04 15:23:49 --> Helper loaded: string_helper
INFO - 2020-03-04 15:23:49 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:23:49 --> Controller Class Initialized
INFO - 2020-03-04 15:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:23:49 --> Pagination Class Initialized
INFO - 2020-03-04 15:23:49 --> Model "M_show" initialized
INFO - 2020-03-04 15:23:49 --> Helper loaded: form_helper
INFO - 2020-03-04 15:23:49 --> Form Validation Class Initialized
INFO - 2020-03-04 15:23:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:23:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 15:23:49 --> Final output sent to browser
DEBUG - 2020-03-04 15:23:49 --> Total execution time: 0.0068
INFO - 2020-03-04 15:23:51 --> Config Class Initialized
INFO - 2020-03-04 15:23:51 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:23:51 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:23:51 --> Utf8 Class Initialized
INFO - 2020-03-04 15:23:51 --> URI Class Initialized
INFO - 2020-03-04 15:23:51 --> Router Class Initialized
INFO - 2020-03-04 15:23:51 --> Output Class Initialized
INFO - 2020-03-04 15:23:51 --> Security Class Initialized
DEBUG - 2020-03-04 15:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:23:51 --> Input Class Initialized
INFO - 2020-03-04 15:23:51 --> Language Class Initialized
INFO - 2020-03-04 15:23:51 --> Loader Class Initialized
INFO - 2020-03-04 15:23:51 --> Helper loaded: url_helper
INFO - 2020-03-04 15:23:51 --> Helper loaded: string_helper
INFO - 2020-03-04 15:23:51 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:23:51 --> Controller Class Initialized
INFO - 2020-03-04 15:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:23:51 --> Pagination Class Initialized
INFO - 2020-03-04 15:23:51 --> Model "M_show" initialized
INFO - 2020-03-04 15:23:51 --> Helper loaded: form_helper
INFO - 2020-03-04 15:23:51 --> Form Validation Class Initialized
INFO - 2020-03-04 15:23:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:23:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:23:51 --> Final output sent to browser
DEBUG - 2020-03-04 15:23:51 --> Total execution time: 0.0061
INFO - 2020-03-04 15:23:52 --> Config Class Initialized
INFO - 2020-03-04 15:23:52 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:23:52 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:23:52 --> Utf8 Class Initialized
INFO - 2020-03-04 15:23:52 --> URI Class Initialized
INFO - 2020-03-04 15:23:52 --> Router Class Initialized
INFO - 2020-03-04 15:23:52 --> Output Class Initialized
INFO - 2020-03-04 15:23:52 --> Security Class Initialized
DEBUG - 2020-03-04 15:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:23:52 --> Input Class Initialized
INFO - 2020-03-04 15:23:52 --> Language Class Initialized
INFO - 2020-03-04 15:23:52 --> Loader Class Initialized
INFO - 2020-03-04 15:23:52 --> Helper loaded: url_helper
INFO - 2020-03-04 15:23:52 --> Helper loaded: string_helper
INFO - 2020-03-04 15:23:52 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:23:52 --> Controller Class Initialized
INFO - 2020-03-04 15:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:23:52 --> Pagination Class Initialized
INFO - 2020-03-04 15:23:52 --> Model "M_show" initialized
INFO - 2020-03-04 15:23:52 --> Helper loaded: form_helper
INFO - 2020-03-04 15:23:52 --> Form Validation Class Initialized
INFO - 2020-03-04 15:23:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:23:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:23:52 --> Final output sent to browser
DEBUG - 2020-03-04 15:23:52 --> Total execution time: 0.0081
INFO - 2020-03-04 15:23:55 --> Config Class Initialized
INFO - 2020-03-04 15:23:55 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:23:55 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:23:55 --> Utf8 Class Initialized
INFO - 2020-03-04 15:23:55 --> URI Class Initialized
INFO - 2020-03-04 15:23:55 --> Router Class Initialized
INFO - 2020-03-04 15:23:55 --> Output Class Initialized
INFO - 2020-03-04 15:23:55 --> Security Class Initialized
DEBUG - 2020-03-04 15:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:23:55 --> Input Class Initialized
INFO - 2020-03-04 15:23:55 --> Language Class Initialized
INFO - 2020-03-04 15:23:55 --> Loader Class Initialized
INFO - 2020-03-04 15:23:55 --> Helper loaded: url_helper
INFO - 2020-03-04 15:23:55 --> Helper loaded: string_helper
INFO - 2020-03-04 15:23:55 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:23:55 --> Controller Class Initialized
INFO - 2020-03-04 15:23:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:23:55 --> Pagination Class Initialized
INFO - 2020-03-04 15:23:55 --> Model "M_show" initialized
INFO - 2020-03-04 15:23:55 --> Helper loaded: form_helper
INFO - 2020-03-04 15:23:55 --> Form Validation Class Initialized
INFO - 2020-03-04 15:23:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:23:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-04 15:23:55 --> Final output sent to browser
DEBUG - 2020-03-04 15:23:55 --> Total execution time: 0.0204
INFO - 2020-03-04 15:23:57 --> Config Class Initialized
INFO - 2020-03-04 15:23:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:23:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:23:57 --> Utf8 Class Initialized
INFO - 2020-03-04 15:23:57 --> URI Class Initialized
INFO - 2020-03-04 15:23:57 --> Router Class Initialized
INFO - 2020-03-04 15:23:57 --> Output Class Initialized
INFO - 2020-03-04 15:23:57 --> Security Class Initialized
DEBUG - 2020-03-04 15:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:23:57 --> Input Class Initialized
INFO - 2020-03-04 15:23:57 --> Language Class Initialized
INFO - 2020-03-04 15:23:57 --> Loader Class Initialized
INFO - 2020-03-04 15:23:57 --> Helper loaded: url_helper
INFO - 2020-03-04 15:23:57 --> Helper loaded: string_helper
INFO - 2020-03-04 15:23:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:23:57 --> Controller Class Initialized
INFO - 2020-03-04 15:23:57 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:23:57 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:23:57 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:23:57 --> Helper loaded: form_helper
INFO - 2020-03-04 15:23:57 --> Form Validation Class Initialized
INFO - 2020-03-04 15:23:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 15:23:57 --> Final output sent to browser
DEBUG - 2020-03-04 15:23:57 --> Total execution time: 0.0079
INFO - 2020-03-04 15:23:58 --> Config Class Initialized
INFO - 2020-03-04 15:23:58 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:23:58 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:23:58 --> Utf8 Class Initialized
INFO - 2020-03-04 15:23:58 --> URI Class Initialized
INFO - 2020-03-04 15:23:58 --> Router Class Initialized
INFO - 2020-03-04 15:23:58 --> Output Class Initialized
INFO - 2020-03-04 15:23:58 --> Security Class Initialized
DEBUG - 2020-03-04 15:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:23:58 --> Input Class Initialized
INFO - 2020-03-04 15:23:58 --> Language Class Initialized
ERROR - 2020-03-04 15:23:58 --> 404 Page Not Found: Engine0/jquery.js
INFO - 2020-03-04 15:24:16 --> Config Class Initialized
INFO - 2020-03-04 15:24:16 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:24:16 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:24:16 --> Utf8 Class Initialized
INFO - 2020-03-04 15:24:16 --> URI Class Initialized
INFO - 2020-03-04 15:24:16 --> Router Class Initialized
INFO - 2020-03-04 15:24:16 --> Output Class Initialized
INFO - 2020-03-04 15:24:16 --> Security Class Initialized
DEBUG - 2020-03-04 15:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:24:16 --> Input Class Initialized
INFO - 2020-03-04 15:24:16 --> Language Class Initialized
INFO - 2020-03-04 15:24:16 --> Loader Class Initialized
INFO - 2020-03-04 15:24:16 --> Helper loaded: url_helper
INFO - 2020-03-04 15:24:16 --> Helper loaded: string_helper
INFO - 2020-03-04 15:24:16 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:24:16 --> Controller Class Initialized
INFO - 2020-03-04 15:24:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:24:16 --> Pagination Class Initialized
INFO - 2020-03-04 15:24:16 --> Model "M_show" initialized
INFO - 2020-03-04 15:24:16 --> Helper loaded: form_helper
INFO - 2020-03-04 15:24:16 --> Form Validation Class Initialized
INFO - 2020-03-04 15:24:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:24:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-04 15:24:16 --> Final output sent to browser
DEBUG - 2020-03-04 15:24:16 --> Total execution time: 0.2403
INFO - 2020-03-04 15:24:36 --> Config Class Initialized
INFO - 2020-03-04 15:24:36 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:24:36 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:24:36 --> Utf8 Class Initialized
INFO - 2020-03-04 15:24:36 --> URI Class Initialized
INFO - 2020-03-04 15:24:36 --> Router Class Initialized
INFO - 2020-03-04 15:24:36 --> Output Class Initialized
INFO - 2020-03-04 15:24:36 --> Security Class Initialized
DEBUG - 2020-03-04 15:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:24:36 --> Input Class Initialized
INFO - 2020-03-04 15:24:36 --> Language Class Initialized
INFO - 2020-03-04 15:24:36 --> Loader Class Initialized
INFO - 2020-03-04 15:24:36 --> Helper loaded: url_helper
INFO - 2020-03-04 15:24:36 --> Helper loaded: string_helper
INFO - 2020-03-04 15:24:36 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:24:36 --> Controller Class Initialized
INFO - 2020-03-04 15:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:24:36 --> Pagination Class Initialized
INFO - 2020-03-04 15:24:36 --> Model "M_show" initialized
INFO - 2020-03-04 15:24:36 --> Helper loaded: form_helper
INFO - 2020-03-04 15:24:36 --> Form Validation Class Initialized
INFO - 2020-03-04 15:24:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:24:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-04 15:24:36 --> Final output sent to browser
DEBUG - 2020-03-04 15:24:36 --> Total execution time: 0.0069
INFO - 2020-03-04 15:24:44 --> Config Class Initialized
INFO - 2020-03-04 15:24:44 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:24:44 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:24:44 --> Utf8 Class Initialized
INFO - 2020-03-04 15:24:44 --> URI Class Initialized
INFO - 2020-03-04 15:24:44 --> Router Class Initialized
INFO - 2020-03-04 15:24:44 --> Output Class Initialized
INFO - 2020-03-04 15:24:44 --> Security Class Initialized
DEBUG - 2020-03-04 15:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:24:44 --> Input Class Initialized
INFO - 2020-03-04 15:24:44 --> Language Class Initialized
INFO - 2020-03-04 15:24:44 --> Loader Class Initialized
INFO - 2020-03-04 15:24:44 --> Helper loaded: url_helper
INFO - 2020-03-04 15:24:44 --> Helper loaded: string_helper
INFO - 2020-03-04 15:24:44 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:24:45 --> Controller Class Initialized
INFO - 2020-03-04 15:24:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:24:45 --> Pagination Class Initialized
INFO - 2020-03-04 15:24:45 --> Model "M_show" initialized
INFO - 2020-03-04 15:24:45 --> Helper loaded: form_helper
INFO - 2020-03-04 15:24:45 --> Form Validation Class Initialized
INFO - 2020-03-04 15:24:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:24:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:24:45 --> Final output sent to browser
DEBUG - 2020-03-04 15:24:45 --> Total execution time: 0.2304
INFO - 2020-03-04 15:24:45 --> Config Class Initialized
INFO - 2020-03-04 15:24:45 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:24:45 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:24:45 --> Utf8 Class Initialized
INFO - 2020-03-04 15:24:45 --> URI Class Initialized
INFO - 2020-03-04 15:24:45 --> Router Class Initialized
INFO - 2020-03-04 15:24:45 --> Output Class Initialized
INFO - 2020-03-04 15:24:45 --> Security Class Initialized
DEBUG - 2020-03-04 15:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:24:45 --> Input Class Initialized
INFO - 2020-03-04 15:24:45 --> Language Class Initialized
INFO - 2020-03-04 15:24:45 --> Loader Class Initialized
INFO - 2020-03-04 15:24:45 --> Helper loaded: url_helper
INFO - 2020-03-04 15:24:45 --> Helper loaded: string_helper
INFO - 2020-03-04 15:24:45 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:24:45 --> Controller Class Initialized
INFO - 2020-03-04 15:24:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:24:45 --> Pagination Class Initialized
INFO - 2020-03-04 15:24:45 --> Model "M_show" initialized
INFO - 2020-03-04 15:24:45 --> Helper loaded: form_helper
INFO - 2020-03-04 15:24:45 --> Form Validation Class Initialized
INFO - 2020-03-04 15:24:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:24:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:24:45 --> Final output sent to browser
DEBUG - 2020-03-04 15:24:45 --> Total execution time: 0.0064
INFO - 2020-03-04 15:24:50 --> Config Class Initialized
INFO - 2020-03-04 15:24:50 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:24:50 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:24:50 --> Utf8 Class Initialized
INFO - 2020-03-04 15:24:50 --> URI Class Initialized
INFO - 2020-03-04 15:24:50 --> Router Class Initialized
INFO - 2020-03-04 15:24:50 --> Output Class Initialized
INFO - 2020-03-04 15:24:50 --> Security Class Initialized
DEBUG - 2020-03-04 15:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:24:50 --> Input Class Initialized
INFO - 2020-03-04 15:24:50 --> Language Class Initialized
INFO - 2020-03-04 15:24:50 --> Loader Class Initialized
INFO - 2020-03-04 15:24:50 --> Helper loaded: url_helper
INFO - 2020-03-04 15:24:50 --> Helper loaded: string_helper
INFO - 2020-03-04 15:24:50 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:24:50 --> Controller Class Initialized
INFO - 2020-03-04 15:24:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:24:50 --> Pagination Class Initialized
INFO - 2020-03-04 15:24:50 --> Model "M_show" initialized
INFO - 2020-03-04 15:24:50 --> Helper loaded: form_helper
INFO - 2020-03-04 15:24:50 --> Form Validation Class Initialized
INFO - 2020-03-04 15:24:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:24:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:24:50 --> Final output sent to browser
DEBUG - 2020-03-04 15:24:50 --> Total execution time: 0.0069
INFO - 2020-03-04 15:24:53 --> Config Class Initialized
INFO - 2020-03-04 15:24:53 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:24:53 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:24:53 --> Utf8 Class Initialized
INFO - 2020-03-04 15:24:53 --> URI Class Initialized
INFO - 2020-03-04 15:24:53 --> Router Class Initialized
INFO - 2020-03-04 15:24:53 --> Output Class Initialized
INFO - 2020-03-04 15:24:53 --> Security Class Initialized
DEBUG - 2020-03-04 15:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:24:53 --> Input Class Initialized
INFO - 2020-03-04 15:24:53 --> Language Class Initialized
INFO - 2020-03-04 15:24:53 --> Loader Class Initialized
INFO - 2020-03-04 15:24:53 --> Helper loaded: url_helper
INFO - 2020-03-04 15:24:53 --> Helper loaded: string_helper
INFO - 2020-03-04 15:24:53 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:24:53 --> Controller Class Initialized
INFO - 2020-03-04 15:24:53 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:24:53 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:24:53 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:24:53 --> Helper loaded: form_helper
INFO - 2020-03-04 15:24:53 --> Form Validation Class Initialized
INFO - 2020-03-04 15:24:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 15:24:53 --> Final output sent to browser
DEBUG - 2020-03-04 15:24:53 --> Total execution time: 0.0081
INFO - 2020-03-04 15:25:03 --> Config Class Initialized
INFO - 2020-03-04 15:25:03 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:25:03 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:25:03 --> Utf8 Class Initialized
INFO - 2020-03-04 15:25:03 --> URI Class Initialized
INFO - 2020-03-04 15:25:03 --> Router Class Initialized
INFO - 2020-03-04 15:25:03 --> Output Class Initialized
INFO - 2020-03-04 15:25:03 --> Security Class Initialized
DEBUG - 2020-03-04 15:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:25:03 --> Input Class Initialized
INFO - 2020-03-04 15:25:03 --> Language Class Initialized
INFO - 2020-03-04 15:25:03 --> Loader Class Initialized
INFO - 2020-03-04 15:25:03 --> Helper loaded: url_helper
INFO - 2020-03-04 15:25:03 --> Helper loaded: string_helper
INFO - 2020-03-04 15:25:03 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:25:03 --> Controller Class Initialized
INFO - 2020-03-04 15:25:03 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:25:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:25:03 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:25:03 --> Helper loaded: form_helper
INFO - 2020-03-04 15:25:03 --> Form Validation Class Initialized
INFO - 2020-03-04 15:25:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 15:25:03 --> Final output sent to browser
DEBUG - 2020-03-04 15:25:03 --> Total execution time: 0.0079
INFO - 2020-03-04 15:25:18 --> Config Class Initialized
INFO - 2020-03-04 15:25:18 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:25:18 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:25:18 --> Utf8 Class Initialized
INFO - 2020-03-04 15:25:18 --> URI Class Initialized
INFO - 2020-03-04 15:25:18 --> Router Class Initialized
INFO - 2020-03-04 15:25:18 --> Output Class Initialized
INFO - 2020-03-04 15:25:18 --> Security Class Initialized
DEBUG - 2020-03-04 15:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:25:18 --> Input Class Initialized
INFO - 2020-03-04 15:25:18 --> Language Class Initialized
INFO - 2020-03-04 15:25:18 --> Loader Class Initialized
INFO - 2020-03-04 15:25:18 --> Helper loaded: url_helper
INFO - 2020-03-04 15:25:18 --> Helper loaded: string_helper
INFO - 2020-03-04 15:25:18 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:25:18 --> Controller Class Initialized
INFO - 2020-03-04 15:25:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:25:18 --> Pagination Class Initialized
INFO - 2020-03-04 15:25:18 --> Model "M_show" initialized
INFO - 2020-03-04 15:25:18 --> Helper loaded: form_helper
INFO - 2020-03-04 15:25:18 --> Form Validation Class Initialized
INFO - 2020-03-04 15:25:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:25:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:25:18 --> Final output sent to browser
DEBUG - 2020-03-04 15:25:18 --> Total execution time: 0.0068
INFO - 2020-03-04 15:25:21 --> Config Class Initialized
INFO - 2020-03-04 15:25:21 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:25:21 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:25:21 --> Utf8 Class Initialized
INFO - 2020-03-04 15:25:21 --> URI Class Initialized
INFO - 2020-03-04 15:25:21 --> Router Class Initialized
INFO - 2020-03-04 15:25:21 --> Output Class Initialized
INFO - 2020-03-04 15:25:21 --> Security Class Initialized
DEBUG - 2020-03-04 15:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:25:21 --> Input Class Initialized
INFO - 2020-03-04 15:25:21 --> Language Class Initialized
INFO - 2020-03-04 15:25:21 --> Loader Class Initialized
INFO - 2020-03-04 15:25:21 --> Helper loaded: url_helper
INFO - 2020-03-04 15:25:21 --> Helper loaded: string_helper
INFO - 2020-03-04 15:25:21 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:25:21 --> Controller Class Initialized
INFO - 2020-03-04 15:25:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:25:21 --> Pagination Class Initialized
INFO - 2020-03-04 15:25:21 --> Model "M_show" initialized
INFO - 2020-03-04 15:25:21 --> Helper loaded: form_helper
INFO - 2020-03-04 15:25:21 --> Form Validation Class Initialized
INFO - 2020-03-04 15:25:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:25:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:25:21 --> Final output sent to browser
DEBUG - 2020-03-04 15:25:21 --> Total execution time: 0.1489
INFO - 2020-03-04 15:25:33 --> Config Class Initialized
INFO - 2020-03-04 15:25:33 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:25:33 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:25:33 --> Utf8 Class Initialized
INFO - 2020-03-04 15:25:33 --> URI Class Initialized
INFO - 2020-03-04 15:25:33 --> Router Class Initialized
INFO - 2020-03-04 15:25:33 --> Output Class Initialized
INFO - 2020-03-04 15:25:33 --> Security Class Initialized
DEBUG - 2020-03-04 15:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:25:33 --> Input Class Initialized
INFO - 2020-03-04 15:25:33 --> Language Class Initialized
INFO - 2020-03-04 15:25:33 --> Loader Class Initialized
INFO - 2020-03-04 15:25:33 --> Helper loaded: url_helper
INFO - 2020-03-04 15:25:33 --> Helper loaded: string_helper
INFO - 2020-03-04 15:25:33 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:25:33 --> Controller Class Initialized
INFO - 2020-03-04 15:25:33 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:25:33 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:25:33 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:25:33 --> Helper loaded: form_helper
INFO - 2020-03-04 15:25:33 --> Form Validation Class Initialized
DEBUG - 2020-03-04 15:25:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-04 15:25:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-04 22:25:33 --> Final output sent to browser
DEBUG - 2020-03-04 22:25:33 --> Total execution time: 0.1716
INFO - 2020-03-04 15:25:37 --> Config Class Initialized
INFO - 2020-03-04 15:25:37 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:25:37 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:25:37 --> Utf8 Class Initialized
INFO - 2020-03-04 15:25:37 --> URI Class Initialized
INFO - 2020-03-04 15:25:37 --> Router Class Initialized
INFO - 2020-03-04 15:25:37 --> Output Class Initialized
INFO - 2020-03-04 15:25:37 --> Security Class Initialized
DEBUG - 2020-03-04 15:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:25:37 --> Input Class Initialized
INFO - 2020-03-04 15:25:37 --> Language Class Initialized
INFO - 2020-03-04 15:25:37 --> Loader Class Initialized
INFO - 2020-03-04 15:25:37 --> Helper loaded: url_helper
INFO - 2020-03-04 15:25:37 --> Helper loaded: string_helper
INFO - 2020-03-04 15:25:37 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:25:37 --> Controller Class Initialized
INFO - 2020-03-04 15:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:25:37 --> Pagination Class Initialized
INFO - 2020-03-04 15:25:37 --> Model "M_show" initialized
INFO - 2020-03-04 15:25:37 --> Helper loaded: form_helper
INFO - 2020-03-04 15:25:37 --> Form Validation Class Initialized
INFO - 2020-03-04 15:25:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:25:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 15:25:37 --> Final output sent to browser
DEBUG - 2020-03-04 15:25:37 --> Total execution time: 0.0061
INFO - 2020-03-04 15:25:38 --> Config Class Initialized
INFO - 2020-03-04 15:25:38 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:25:38 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:25:38 --> Utf8 Class Initialized
INFO - 2020-03-04 15:25:38 --> URI Class Initialized
INFO - 2020-03-04 15:25:38 --> Router Class Initialized
INFO - 2020-03-04 15:25:38 --> Output Class Initialized
INFO - 2020-03-04 15:25:38 --> Security Class Initialized
DEBUG - 2020-03-04 15:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:25:38 --> Input Class Initialized
INFO - 2020-03-04 15:25:38 --> Language Class Initialized
INFO - 2020-03-04 15:25:38 --> Loader Class Initialized
INFO - 2020-03-04 15:25:38 --> Helper loaded: url_helper
INFO - 2020-03-04 15:25:38 --> Helper loaded: string_helper
INFO - 2020-03-04 15:25:38 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:25:38 --> Controller Class Initialized
INFO - 2020-03-04 15:25:38 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:25:38 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:25:38 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:25:38 --> Helper loaded: form_helper
INFO - 2020-03-04 15:25:38 --> Form Validation Class Initialized
INFO - 2020-03-04 15:25:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 15:25:38 --> Final output sent to browser
DEBUG - 2020-03-04 15:25:38 --> Total execution time: 0.0069
INFO - 2020-03-04 15:26:04 --> Config Class Initialized
INFO - 2020-03-04 15:26:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:26:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:26:04 --> Utf8 Class Initialized
INFO - 2020-03-04 15:26:04 --> URI Class Initialized
INFO - 2020-03-04 15:26:04 --> Router Class Initialized
INFO - 2020-03-04 15:26:04 --> Output Class Initialized
INFO - 2020-03-04 15:26:04 --> Security Class Initialized
DEBUG - 2020-03-04 15:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:26:04 --> Input Class Initialized
INFO - 2020-03-04 15:26:04 --> Language Class Initialized
INFO - 2020-03-04 15:26:04 --> Loader Class Initialized
INFO - 2020-03-04 15:26:04 --> Helper loaded: url_helper
INFO - 2020-03-04 15:26:04 --> Helper loaded: string_helper
INFO - 2020-03-04 15:26:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:26:04 --> Controller Class Initialized
INFO - 2020-03-04 15:26:04 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:26:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:26:04 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:26:04 --> Helper loaded: form_helper
INFO - 2020-03-04 15:26:04 --> Form Validation Class Initialized
INFO - 2020-03-04 15:26:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 15:26:04 --> Final output sent to browser
DEBUG - 2020-03-04 15:26:04 --> Total execution time: 0.0078
INFO - 2020-03-04 15:26:24 --> Config Class Initialized
INFO - 2020-03-04 15:26:24 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:26:24 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:26:24 --> Utf8 Class Initialized
INFO - 2020-03-04 15:26:24 --> URI Class Initialized
INFO - 2020-03-04 15:26:24 --> Router Class Initialized
INFO - 2020-03-04 15:26:24 --> Output Class Initialized
INFO - 2020-03-04 15:26:24 --> Security Class Initialized
DEBUG - 2020-03-04 15:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:26:24 --> Input Class Initialized
INFO - 2020-03-04 15:26:24 --> Language Class Initialized
INFO - 2020-03-04 15:26:24 --> Loader Class Initialized
INFO - 2020-03-04 15:26:24 --> Helper loaded: url_helper
INFO - 2020-03-04 15:26:24 --> Helper loaded: string_helper
INFO - 2020-03-04 15:26:24 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:26:24 --> Controller Class Initialized
INFO - 2020-03-04 15:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:26:24 --> Pagination Class Initialized
INFO - 2020-03-04 15:26:24 --> Model "M_show" initialized
INFO - 2020-03-04 15:26:24 --> Helper loaded: form_helper
INFO - 2020-03-04 15:26:24 --> Form Validation Class Initialized
INFO - 2020-03-04 15:26:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:26:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:26:24 --> Final output sent to browser
DEBUG - 2020-03-04 15:26:24 --> Total execution time: 0.0076
INFO - 2020-03-04 15:27:38 --> Config Class Initialized
INFO - 2020-03-04 15:27:38 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:27:38 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:27:38 --> Utf8 Class Initialized
INFO - 2020-03-04 15:27:38 --> URI Class Initialized
INFO - 2020-03-04 15:27:38 --> Router Class Initialized
INFO - 2020-03-04 15:27:38 --> Output Class Initialized
INFO - 2020-03-04 15:27:38 --> Security Class Initialized
DEBUG - 2020-03-04 15:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:27:38 --> Input Class Initialized
INFO - 2020-03-04 15:27:38 --> Language Class Initialized
INFO - 2020-03-04 15:27:38 --> Loader Class Initialized
INFO - 2020-03-04 15:27:38 --> Helper loaded: url_helper
INFO - 2020-03-04 15:27:38 --> Helper loaded: string_helper
INFO - 2020-03-04 15:27:38 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:27:38 --> Controller Class Initialized
INFO - 2020-03-04 15:27:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:27:38 --> Pagination Class Initialized
INFO - 2020-03-04 15:27:38 --> Model "M_show" initialized
INFO - 2020-03-04 15:27:38 --> Helper loaded: form_helper
INFO - 2020-03-04 15:27:38 --> Form Validation Class Initialized
INFO - 2020-03-04 15:27:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:27:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:27:38 --> Final output sent to browser
DEBUG - 2020-03-04 15:27:38 --> Total execution time: 0.0335
INFO - 2020-03-04 15:27:47 --> Config Class Initialized
INFO - 2020-03-04 15:27:47 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:27:47 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:27:47 --> Utf8 Class Initialized
INFO - 2020-03-04 15:27:47 --> URI Class Initialized
INFO - 2020-03-04 15:27:47 --> Router Class Initialized
INFO - 2020-03-04 15:27:47 --> Output Class Initialized
INFO - 2020-03-04 15:27:47 --> Security Class Initialized
DEBUG - 2020-03-04 15:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:27:47 --> Input Class Initialized
INFO - 2020-03-04 15:27:47 --> Language Class Initialized
INFO - 2020-03-04 15:27:47 --> Loader Class Initialized
INFO - 2020-03-04 15:27:47 --> Helper loaded: url_helper
INFO - 2020-03-04 15:27:47 --> Helper loaded: string_helper
INFO - 2020-03-04 15:27:47 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:27:47 --> Controller Class Initialized
INFO - 2020-03-04 15:27:47 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:27:47 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:27:47 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:27:47 --> Helper loaded: form_helper
INFO - 2020-03-04 15:27:47 --> Form Validation Class Initialized
INFO - 2020-03-04 15:27:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 15:27:47 --> Final output sent to browser
DEBUG - 2020-03-04 15:27:47 --> Total execution time: 0.4413
INFO - 2020-03-04 15:28:13 --> Config Class Initialized
INFO - 2020-03-04 15:28:13 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:28:13 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:28:13 --> Utf8 Class Initialized
INFO - 2020-03-04 15:28:13 --> URI Class Initialized
INFO - 2020-03-04 15:28:13 --> Router Class Initialized
INFO - 2020-03-04 15:28:13 --> Output Class Initialized
INFO - 2020-03-04 15:28:13 --> Security Class Initialized
DEBUG - 2020-03-04 15:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:28:13 --> Input Class Initialized
INFO - 2020-03-04 15:28:13 --> Language Class Initialized
INFO - 2020-03-04 15:28:13 --> Loader Class Initialized
INFO - 2020-03-04 15:28:13 --> Helper loaded: url_helper
INFO - 2020-03-04 15:28:13 --> Helper loaded: string_helper
INFO - 2020-03-04 15:28:13 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:28:13 --> Controller Class Initialized
INFO - 2020-03-04 15:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:28:13 --> Pagination Class Initialized
INFO - 2020-03-04 15:28:13 --> Model "M_show" initialized
INFO - 2020-03-04 15:28:13 --> Helper loaded: form_helper
INFO - 2020-03-04 15:28:13 --> Form Validation Class Initialized
INFO - 2020-03-04 15:28:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:28:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:28:13 --> Final output sent to browser
DEBUG - 2020-03-04 15:28:13 --> Total execution time: 0.3570
INFO - 2020-03-04 15:30:27 --> Config Class Initialized
INFO - 2020-03-04 15:30:27 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:30:27 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:30:27 --> Utf8 Class Initialized
INFO - 2020-03-04 15:30:27 --> URI Class Initialized
INFO - 2020-03-04 15:30:27 --> Router Class Initialized
INFO - 2020-03-04 15:30:27 --> Output Class Initialized
INFO - 2020-03-04 15:30:27 --> Security Class Initialized
DEBUG - 2020-03-04 15:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:30:27 --> Input Class Initialized
INFO - 2020-03-04 15:30:27 --> Language Class Initialized
INFO - 2020-03-04 15:30:27 --> Loader Class Initialized
INFO - 2020-03-04 15:30:27 --> Helper loaded: url_helper
INFO - 2020-03-04 15:30:27 --> Helper loaded: string_helper
INFO - 2020-03-04 15:30:27 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:30:27 --> Controller Class Initialized
INFO - 2020-03-04 15:30:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:30:27 --> Pagination Class Initialized
INFO - 2020-03-04 15:30:27 --> Model "M_show" initialized
INFO - 2020-03-04 15:30:27 --> Helper loaded: form_helper
INFO - 2020-03-04 15:30:27 --> Form Validation Class Initialized
INFO - 2020-03-04 15:30:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:30:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:30:27 --> Final output sent to browser
DEBUG - 2020-03-04 15:30:27 --> Total execution time: 0.0369
INFO - 2020-03-04 15:30:27 --> Config Class Initialized
INFO - 2020-03-04 15:30:27 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:30:27 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:30:27 --> Utf8 Class Initialized
INFO - 2020-03-04 15:30:27 --> URI Class Initialized
INFO - 2020-03-04 15:30:27 --> Router Class Initialized
INFO - 2020-03-04 15:30:27 --> Output Class Initialized
INFO - 2020-03-04 15:30:27 --> Security Class Initialized
DEBUG - 2020-03-04 15:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:30:27 --> Input Class Initialized
INFO - 2020-03-04 15:30:27 --> Language Class Initialized
INFO - 2020-03-04 15:30:27 --> Loader Class Initialized
INFO - 2020-03-04 15:30:27 --> Helper loaded: url_helper
INFO - 2020-03-04 15:30:27 --> Helper loaded: string_helper
INFO - 2020-03-04 15:30:27 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:30:27 --> Controller Class Initialized
INFO - 2020-03-04 15:30:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:30:27 --> Pagination Class Initialized
INFO - 2020-03-04 15:30:27 --> Model "M_show" initialized
INFO - 2020-03-04 15:30:27 --> Helper loaded: form_helper
INFO - 2020-03-04 15:30:27 --> Form Validation Class Initialized
INFO - 2020-03-04 15:30:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:30:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:30:27 --> Final output sent to browser
DEBUG - 2020-03-04 15:30:27 --> Total execution time: 0.0046
INFO - 2020-03-04 15:32:43 --> Config Class Initialized
INFO - 2020-03-04 15:32:43 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:32:43 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:32:43 --> Utf8 Class Initialized
INFO - 2020-03-04 15:32:43 --> URI Class Initialized
INFO - 2020-03-04 15:32:43 --> Router Class Initialized
INFO - 2020-03-04 15:32:43 --> Output Class Initialized
INFO - 2020-03-04 15:32:43 --> Security Class Initialized
DEBUG - 2020-03-04 15:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:32:43 --> Input Class Initialized
INFO - 2020-03-04 15:32:43 --> Language Class Initialized
INFO - 2020-03-04 15:32:43 --> Loader Class Initialized
INFO - 2020-03-04 15:32:43 --> Helper loaded: url_helper
INFO - 2020-03-04 15:32:43 --> Helper loaded: string_helper
INFO - 2020-03-04 15:32:43 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:32:44 --> Controller Class Initialized
INFO - 2020-03-04 15:32:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:32:44 --> Pagination Class Initialized
INFO - 2020-03-04 15:32:44 --> Model "M_show" initialized
INFO - 2020-03-04 15:32:44 --> Helper loaded: form_helper
INFO - 2020-03-04 15:32:44 --> Form Validation Class Initialized
INFO - 2020-03-04 15:32:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:32:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:32:44 --> Final output sent to browser
DEBUG - 2020-03-04 15:32:44 --> Total execution time: 0.0810
INFO - 2020-03-04 15:34:09 --> Config Class Initialized
INFO - 2020-03-04 15:34:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:34:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:34:09 --> Utf8 Class Initialized
INFO - 2020-03-04 15:34:09 --> URI Class Initialized
INFO - 2020-03-04 15:34:09 --> Router Class Initialized
INFO - 2020-03-04 15:34:09 --> Output Class Initialized
INFO - 2020-03-04 15:34:09 --> Security Class Initialized
DEBUG - 2020-03-04 15:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:34:09 --> Input Class Initialized
INFO - 2020-03-04 15:34:09 --> Language Class Initialized
INFO - 2020-03-04 15:34:09 --> Loader Class Initialized
INFO - 2020-03-04 15:34:09 --> Helper loaded: url_helper
INFO - 2020-03-04 15:34:09 --> Helper loaded: string_helper
INFO - 2020-03-04 15:34:09 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:34:09 --> Controller Class Initialized
INFO - 2020-03-04 15:34:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:34:09 --> Pagination Class Initialized
INFO - 2020-03-04 15:34:09 --> Model "M_show" initialized
INFO - 2020-03-04 15:34:09 --> Helper loaded: form_helper
INFO - 2020-03-04 15:34:09 --> Form Validation Class Initialized
INFO - 2020-03-04 15:34:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:34:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:34:09 --> Final output sent to browser
DEBUG - 2020-03-04 15:34:09 --> Total execution time: 0.0331
INFO - 2020-03-04 15:34:15 --> Config Class Initialized
INFO - 2020-03-04 15:34:15 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:34:15 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:34:15 --> Utf8 Class Initialized
INFO - 2020-03-04 15:34:15 --> URI Class Initialized
INFO - 2020-03-04 15:34:15 --> Router Class Initialized
INFO - 2020-03-04 15:34:15 --> Output Class Initialized
INFO - 2020-03-04 15:34:15 --> Security Class Initialized
DEBUG - 2020-03-04 15:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:34:15 --> Input Class Initialized
INFO - 2020-03-04 15:34:15 --> Language Class Initialized
INFO - 2020-03-04 15:34:15 --> Loader Class Initialized
INFO - 2020-03-04 15:34:15 --> Helper loaded: url_helper
INFO - 2020-03-04 15:34:15 --> Helper loaded: string_helper
INFO - 2020-03-04 15:34:15 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:34:15 --> Controller Class Initialized
INFO - 2020-03-04 15:34:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:34:15 --> Pagination Class Initialized
INFO - 2020-03-04 15:34:15 --> Model "M_show" initialized
INFO - 2020-03-04 15:34:15 --> Helper loaded: form_helper
INFO - 2020-03-04 15:34:15 --> Form Validation Class Initialized
INFO - 2020-03-04 15:34:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:34:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:34:15 --> Final output sent to browser
DEBUG - 2020-03-04 15:34:15 --> Total execution time: 0.0083
INFO - 2020-03-04 15:34:35 --> Config Class Initialized
INFO - 2020-03-04 15:34:35 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:34:35 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:34:35 --> Utf8 Class Initialized
INFO - 2020-03-04 15:34:35 --> URI Class Initialized
INFO - 2020-03-04 15:34:35 --> Router Class Initialized
INFO - 2020-03-04 15:34:35 --> Output Class Initialized
INFO - 2020-03-04 15:34:35 --> Security Class Initialized
DEBUG - 2020-03-04 15:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:34:35 --> Input Class Initialized
INFO - 2020-03-04 15:34:35 --> Language Class Initialized
INFO - 2020-03-04 15:34:35 --> Loader Class Initialized
INFO - 2020-03-04 15:34:35 --> Helper loaded: url_helper
INFO - 2020-03-04 15:34:35 --> Helper loaded: string_helper
INFO - 2020-03-04 15:34:35 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:34:35 --> Controller Class Initialized
INFO - 2020-03-04 15:34:35 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:34:35 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:34:35 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:34:35 --> Helper loaded: form_helper
INFO - 2020-03-04 15:34:35 --> Form Validation Class Initialized
INFO - 2020-03-04 15:34:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 15:34:35 --> Final output sent to browser
DEBUG - 2020-03-04 15:34:35 --> Total execution time: 0.0109
INFO - 2020-03-04 15:34:52 --> Config Class Initialized
INFO - 2020-03-04 15:34:52 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:34:52 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:34:52 --> Utf8 Class Initialized
INFO - 2020-03-04 15:34:52 --> URI Class Initialized
INFO - 2020-03-04 15:34:52 --> Router Class Initialized
INFO - 2020-03-04 15:34:52 --> Output Class Initialized
INFO - 2020-03-04 15:34:52 --> Security Class Initialized
DEBUG - 2020-03-04 15:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:34:52 --> Input Class Initialized
INFO - 2020-03-04 15:34:52 --> Language Class Initialized
ERROR - 2020-03-04 15:34:52 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 15:35:12 --> Config Class Initialized
INFO - 2020-03-04 15:35:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:35:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:35:12 --> Utf8 Class Initialized
INFO - 2020-03-04 15:35:12 --> URI Class Initialized
INFO - 2020-03-04 15:35:12 --> Router Class Initialized
INFO - 2020-03-04 15:35:12 --> Output Class Initialized
INFO - 2020-03-04 15:35:12 --> Security Class Initialized
DEBUG - 2020-03-04 15:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:35:12 --> Input Class Initialized
INFO - 2020-03-04 15:35:12 --> Language Class Initialized
INFO - 2020-03-04 15:35:12 --> Loader Class Initialized
INFO - 2020-03-04 15:35:12 --> Helper loaded: url_helper
INFO - 2020-03-04 15:35:12 --> Helper loaded: string_helper
INFO - 2020-03-04 15:35:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:35:12 --> Controller Class Initialized
INFO - 2020-03-04 15:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:35:12 --> Pagination Class Initialized
INFO - 2020-03-04 15:35:12 --> Model "M_show" initialized
INFO - 2020-03-04 15:35:12 --> Helper loaded: form_helper
INFO - 2020-03-04 15:35:12 --> Form Validation Class Initialized
INFO - 2020-03-04 15:35:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:35:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:35:12 --> Final output sent to browser
DEBUG - 2020-03-04 15:35:12 --> Total execution time: 0.0093
INFO - 2020-03-04 15:35:32 --> Config Class Initialized
INFO - 2020-03-04 15:35:32 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:35:32 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:35:32 --> Utf8 Class Initialized
INFO - 2020-03-04 15:35:32 --> URI Class Initialized
INFO - 2020-03-04 15:35:32 --> Router Class Initialized
INFO - 2020-03-04 15:35:32 --> Output Class Initialized
INFO - 2020-03-04 15:35:32 --> Security Class Initialized
DEBUG - 2020-03-04 15:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:35:32 --> Input Class Initialized
INFO - 2020-03-04 15:35:32 --> Language Class Initialized
INFO - 2020-03-04 15:35:32 --> Loader Class Initialized
INFO - 2020-03-04 15:35:32 --> Helper loaded: url_helper
INFO - 2020-03-04 15:35:32 --> Helper loaded: string_helper
INFO - 2020-03-04 15:35:32 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:35:32 --> Controller Class Initialized
INFO - 2020-03-04 15:35:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:35:32 --> Pagination Class Initialized
INFO - 2020-03-04 15:35:32 --> Model "M_show" initialized
INFO - 2020-03-04 15:35:32 --> Helper loaded: form_helper
INFO - 2020-03-04 15:35:32 --> Form Validation Class Initialized
INFO - 2020-03-04 15:35:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:35:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-04 15:35:32 --> Final output sent to browser
DEBUG - 2020-03-04 15:35:32 --> Total execution time: 0.0174
INFO - 2020-03-04 15:35:46 --> Config Class Initialized
INFO - 2020-03-04 15:35:46 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:35:46 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:35:46 --> Utf8 Class Initialized
INFO - 2020-03-04 15:35:46 --> URI Class Initialized
INFO - 2020-03-04 15:35:46 --> Router Class Initialized
INFO - 2020-03-04 15:35:46 --> Output Class Initialized
INFO - 2020-03-04 15:35:46 --> Security Class Initialized
DEBUG - 2020-03-04 15:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:35:46 --> Input Class Initialized
INFO - 2020-03-04 15:35:46 --> Language Class Initialized
INFO - 2020-03-04 15:35:46 --> Loader Class Initialized
INFO - 2020-03-04 15:35:46 --> Helper loaded: url_helper
INFO - 2020-03-04 15:35:46 --> Helper loaded: string_helper
INFO - 2020-03-04 15:35:46 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:35:46 --> Controller Class Initialized
INFO - 2020-03-04 15:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:35:46 --> Pagination Class Initialized
INFO - 2020-03-04 15:35:46 --> Model "M_show" initialized
INFO - 2020-03-04 15:35:46 --> Helper loaded: form_helper
INFO - 2020-03-04 15:35:46 --> Form Validation Class Initialized
INFO - 2020-03-04 15:35:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:35:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 15:35:46 --> Final output sent to browser
DEBUG - 2020-03-04 15:35:46 --> Total execution time: 0.0059
INFO - 2020-03-04 15:35:54 --> Config Class Initialized
INFO - 2020-03-04 15:35:54 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:35:54 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:35:54 --> Utf8 Class Initialized
INFO - 2020-03-04 15:35:54 --> URI Class Initialized
INFO - 2020-03-04 15:35:54 --> Router Class Initialized
INFO - 2020-03-04 15:35:54 --> Output Class Initialized
INFO - 2020-03-04 15:35:54 --> Security Class Initialized
DEBUG - 2020-03-04 15:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:35:54 --> Input Class Initialized
INFO - 2020-03-04 15:35:54 --> Language Class Initialized
INFO - 2020-03-04 15:35:54 --> Loader Class Initialized
INFO - 2020-03-04 15:35:54 --> Helper loaded: url_helper
INFO - 2020-03-04 15:35:54 --> Helper loaded: string_helper
INFO - 2020-03-04 15:35:54 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:35:54 --> Controller Class Initialized
INFO - 2020-03-04 15:35:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:35:54 --> Pagination Class Initialized
INFO - 2020-03-04 15:35:54 --> Model "M_show" initialized
INFO - 2020-03-04 15:35:54 --> Helper loaded: form_helper
INFO - 2020-03-04 15:35:54 --> Form Validation Class Initialized
INFO - 2020-03-04 15:35:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:35:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:35:54 --> Final output sent to browser
DEBUG - 2020-03-04 15:35:54 --> Total execution time: 0.0068
INFO - 2020-03-04 15:36:00 --> Config Class Initialized
INFO - 2020-03-04 15:36:00 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:36:00 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:36:00 --> Utf8 Class Initialized
INFO - 2020-03-04 15:36:00 --> URI Class Initialized
INFO - 2020-03-04 15:36:00 --> Router Class Initialized
INFO - 2020-03-04 15:36:00 --> Output Class Initialized
INFO - 2020-03-04 15:36:00 --> Security Class Initialized
DEBUG - 2020-03-04 15:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:36:00 --> Input Class Initialized
INFO - 2020-03-04 15:36:00 --> Language Class Initialized
INFO - 2020-03-04 15:36:00 --> Loader Class Initialized
INFO - 2020-03-04 15:36:00 --> Helper loaded: url_helper
INFO - 2020-03-04 15:36:00 --> Helper loaded: string_helper
INFO - 2020-03-04 15:36:00 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:36:00 --> Controller Class Initialized
INFO - 2020-03-04 15:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:36:00 --> Pagination Class Initialized
INFO - 2020-03-04 15:36:00 --> Model "M_show" initialized
INFO - 2020-03-04 15:36:00 --> Helper loaded: form_helper
INFO - 2020-03-04 15:36:00 --> Form Validation Class Initialized
INFO - 2020-03-04 15:36:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:36:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-04 15:36:00 --> Final output sent to browser
DEBUG - 2020-03-04 15:36:00 --> Total execution time: 0.0053
INFO - 2020-03-04 15:36:12 --> Config Class Initialized
INFO - 2020-03-04 15:36:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:36:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:36:12 --> Utf8 Class Initialized
INFO - 2020-03-04 15:36:12 --> URI Class Initialized
INFO - 2020-03-04 15:36:12 --> Router Class Initialized
INFO - 2020-03-04 15:36:12 --> Output Class Initialized
INFO - 2020-03-04 15:36:12 --> Security Class Initialized
DEBUG - 2020-03-04 15:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:36:12 --> Input Class Initialized
INFO - 2020-03-04 15:36:12 --> Language Class Initialized
INFO - 2020-03-04 15:36:12 --> Loader Class Initialized
INFO - 2020-03-04 15:36:12 --> Helper loaded: url_helper
INFO - 2020-03-04 15:36:12 --> Helper loaded: string_helper
INFO - 2020-03-04 15:36:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:36:12 --> Controller Class Initialized
INFO - 2020-03-04 15:36:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:36:12 --> Pagination Class Initialized
INFO - 2020-03-04 15:36:12 --> Model "M_show" initialized
INFO - 2020-03-04 15:36:12 --> Helper loaded: form_helper
INFO - 2020-03-04 15:36:12 --> Form Validation Class Initialized
INFO - 2020-03-04 15:36:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:36:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:36:12 --> Final output sent to browser
DEBUG - 2020-03-04 15:36:12 --> Total execution time: 0.0084
INFO - 2020-03-04 15:37:04 --> Config Class Initialized
INFO - 2020-03-04 15:37:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:37:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:37:04 --> Utf8 Class Initialized
INFO - 2020-03-04 15:37:04 --> URI Class Initialized
INFO - 2020-03-04 15:37:04 --> Router Class Initialized
INFO - 2020-03-04 15:37:04 --> Output Class Initialized
INFO - 2020-03-04 15:37:04 --> Security Class Initialized
DEBUG - 2020-03-04 15:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:37:04 --> Input Class Initialized
INFO - 2020-03-04 15:37:04 --> Language Class Initialized
INFO - 2020-03-04 15:37:04 --> Loader Class Initialized
INFO - 2020-03-04 15:37:04 --> Helper loaded: url_helper
INFO - 2020-03-04 15:37:04 --> Helper loaded: string_helper
INFO - 2020-03-04 15:37:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:37:04 --> Controller Class Initialized
INFO - 2020-03-04 15:37:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:37:04 --> Pagination Class Initialized
INFO - 2020-03-04 15:37:04 --> Model "M_show" initialized
INFO - 2020-03-04 15:37:04 --> Helper loaded: form_helper
INFO - 2020-03-04 15:37:04 --> Form Validation Class Initialized
INFO - 2020-03-04 15:37:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:37:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-04 15:37:04 --> Final output sent to browser
DEBUG - 2020-03-04 15:37:04 --> Total execution time: 0.0067
INFO - 2020-03-04 15:37:09 --> Config Class Initialized
INFO - 2020-03-04 15:37:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:37:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:37:09 --> Utf8 Class Initialized
INFO - 2020-03-04 15:37:09 --> URI Class Initialized
INFO - 2020-03-04 15:37:09 --> Router Class Initialized
INFO - 2020-03-04 15:37:09 --> Output Class Initialized
INFO - 2020-03-04 15:37:09 --> Security Class Initialized
DEBUG - 2020-03-04 15:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:37:09 --> Input Class Initialized
INFO - 2020-03-04 15:37:09 --> Language Class Initialized
INFO - 2020-03-04 15:37:09 --> Loader Class Initialized
INFO - 2020-03-04 15:37:09 --> Helper loaded: url_helper
INFO - 2020-03-04 15:37:09 --> Helper loaded: string_helper
INFO - 2020-03-04 15:37:09 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:37:09 --> Controller Class Initialized
INFO - 2020-03-04 15:37:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:37:09 --> Pagination Class Initialized
INFO - 2020-03-04 15:37:09 --> Model "M_show" initialized
INFO - 2020-03-04 15:37:09 --> Helper loaded: form_helper
INFO - 2020-03-04 15:37:09 --> Form Validation Class Initialized
INFO - 2020-03-04 15:37:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:37:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:37:09 --> Final output sent to browser
DEBUG - 2020-03-04 15:37:09 --> Total execution time: 0.0077
INFO - 2020-03-04 15:37:15 --> Config Class Initialized
INFO - 2020-03-04 15:37:15 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:37:15 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:37:15 --> Utf8 Class Initialized
INFO - 2020-03-04 15:37:15 --> URI Class Initialized
INFO - 2020-03-04 15:37:15 --> Router Class Initialized
INFO - 2020-03-04 15:37:15 --> Output Class Initialized
INFO - 2020-03-04 15:37:15 --> Security Class Initialized
DEBUG - 2020-03-04 15:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:37:15 --> Input Class Initialized
INFO - 2020-03-04 15:37:15 --> Language Class Initialized
ERROR - 2020-03-04 15:37:15 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 15:42:23 --> Config Class Initialized
INFO - 2020-03-04 15:42:23 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:42:23 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:42:23 --> Utf8 Class Initialized
INFO - 2020-03-04 15:42:23 --> URI Class Initialized
INFO - 2020-03-04 15:42:23 --> Router Class Initialized
INFO - 2020-03-04 15:42:23 --> Output Class Initialized
INFO - 2020-03-04 15:42:23 --> Security Class Initialized
DEBUG - 2020-03-04 15:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:42:23 --> Input Class Initialized
INFO - 2020-03-04 15:42:23 --> Language Class Initialized
INFO - 2020-03-04 15:42:23 --> Loader Class Initialized
INFO - 2020-03-04 15:42:23 --> Helper loaded: url_helper
INFO - 2020-03-04 15:42:23 --> Helper loaded: string_helper
INFO - 2020-03-04 15:42:23 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:42:23 --> Controller Class Initialized
INFO - 2020-03-04 15:42:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:42:23 --> Pagination Class Initialized
INFO - 2020-03-04 15:42:23 --> Model "M_show" initialized
INFO - 2020-03-04 15:42:23 --> Helper loaded: form_helper
INFO - 2020-03-04 15:42:23 --> Form Validation Class Initialized
INFO - 2020-03-04 15:42:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:42:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:42:23 --> Final output sent to browser
DEBUG - 2020-03-04 15:42:23 --> Total execution time: 0.0414
INFO - 2020-03-04 15:47:44 --> Config Class Initialized
INFO - 2020-03-04 15:47:44 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:47:44 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:47:44 --> Utf8 Class Initialized
INFO - 2020-03-04 15:47:44 --> URI Class Initialized
INFO - 2020-03-04 15:47:44 --> Router Class Initialized
INFO - 2020-03-04 15:47:44 --> Output Class Initialized
INFO - 2020-03-04 15:47:44 --> Security Class Initialized
DEBUG - 2020-03-04 15:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:47:44 --> Input Class Initialized
INFO - 2020-03-04 15:47:44 --> Language Class Initialized
INFO - 2020-03-04 15:47:44 --> Loader Class Initialized
INFO - 2020-03-04 15:47:44 --> Helper loaded: url_helper
INFO - 2020-03-04 15:47:44 --> Helper loaded: string_helper
INFO - 2020-03-04 15:47:44 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:47:44 --> Controller Class Initialized
INFO - 2020-03-04 15:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:47:44 --> Pagination Class Initialized
INFO - 2020-03-04 15:47:44 --> Model "M_show" initialized
INFO - 2020-03-04 15:47:44 --> Helper loaded: form_helper
INFO - 2020-03-04 15:47:44 --> Form Validation Class Initialized
INFO - 2020-03-04 15:47:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:47:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:47:44 --> Final output sent to browser
DEBUG - 2020-03-04 15:47:44 --> Total execution time: 0.0349
INFO - 2020-03-04 15:49:10 --> Config Class Initialized
INFO - 2020-03-04 15:49:10 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:49:10 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:49:10 --> Utf8 Class Initialized
INFO - 2020-03-04 15:49:10 --> URI Class Initialized
INFO - 2020-03-04 15:49:10 --> Router Class Initialized
INFO - 2020-03-04 15:49:10 --> Output Class Initialized
INFO - 2020-03-04 15:49:10 --> Security Class Initialized
DEBUG - 2020-03-04 15:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:49:10 --> Input Class Initialized
INFO - 2020-03-04 15:49:10 --> Language Class Initialized
INFO - 2020-03-04 15:49:10 --> Loader Class Initialized
INFO - 2020-03-04 15:49:10 --> Helper loaded: url_helper
INFO - 2020-03-04 15:49:10 --> Helper loaded: string_helper
INFO - 2020-03-04 15:49:10 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:49:10 --> Controller Class Initialized
INFO - 2020-03-04 15:49:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:49:10 --> Pagination Class Initialized
INFO - 2020-03-04 15:49:10 --> Model "M_show" initialized
INFO - 2020-03-04 15:49:10 --> Helper loaded: form_helper
INFO - 2020-03-04 15:49:10 --> Form Validation Class Initialized
INFO - 2020-03-04 15:49:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:49:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:49:10 --> Final output sent to browser
DEBUG - 2020-03-04 15:49:10 --> Total execution time: 0.0407
INFO - 2020-03-04 15:51:36 --> Config Class Initialized
INFO - 2020-03-04 15:51:36 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:51:36 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:51:36 --> Utf8 Class Initialized
INFO - 2020-03-04 15:51:36 --> URI Class Initialized
INFO - 2020-03-04 15:51:36 --> Router Class Initialized
INFO - 2020-03-04 15:51:36 --> Output Class Initialized
INFO - 2020-03-04 15:51:36 --> Security Class Initialized
DEBUG - 2020-03-04 15:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:51:36 --> Input Class Initialized
INFO - 2020-03-04 15:51:36 --> Language Class Initialized
INFO - 2020-03-04 15:51:36 --> Loader Class Initialized
INFO - 2020-03-04 15:51:36 --> Helper loaded: url_helper
INFO - 2020-03-04 15:51:36 --> Helper loaded: string_helper
INFO - 2020-03-04 15:51:36 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:51:36 --> Controller Class Initialized
INFO - 2020-03-04 15:51:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:51:36 --> Pagination Class Initialized
INFO - 2020-03-04 15:51:36 --> Model "M_show" initialized
INFO - 2020-03-04 15:51:36 --> Helper loaded: form_helper
INFO - 2020-03-04 15:51:36 --> Form Validation Class Initialized
INFO - 2020-03-04 15:51:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:51:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:51:36 --> Final output sent to browser
DEBUG - 2020-03-04 15:51:36 --> Total execution time: 0.0336
INFO - 2020-03-04 15:51:57 --> Config Class Initialized
INFO - 2020-03-04 15:51:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:51:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:51:57 --> Utf8 Class Initialized
INFO - 2020-03-04 15:51:57 --> URI Class Initialized
INFO - 2020-03-04 15:51:57 --> Router Class Initialized
INFO - 2020-03-04 15:51:57 --> Output Class Initialized
INFO - 2020-03-04 15:51:57 --> Security Class Initialized
DEBUG - 2020-03-04 15:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:51:57 --> Input Class Initialized
INFO - 2020-03-04 15:51:57 --> Language Class Initialized
INFO - 2020-03-04 15:51:57 --> Loader Class Initialized
INFO - 2020-03-04 15:51:57 --> Helper loaded: url_helper
INFO - 2020-03-04 15:51:57 --> Helper loaded: string_helper
INFO - 2020-03-04 15:51:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:51:57 --> Controller Class Initialized
INFO - 2020-03-04 15:51:57 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:51:57 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:51:57 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:51:57 --> Helper loaded: form_helper
INFO - 2020-03-04 15:51:57 --> Form Validation Class Initialized
INFO - 2020-03-04 15:51:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 15:51:57 --> Final output sent to browser
DEBUG - 2020-03-04 15:51:57 --> Total execution time: 0.0248
INFO - 2020-03-04 15:52:23 --> Config Class Initialized
INFO - 2020-03-04 15:52:23 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:52:23 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:52:23 --> Utf8 Class Initialized
INFO - 2020-03-04 15:52:23 --> URI Class Initialized
INFO - 2020-03-04 15:52:23 --> Router Class Initialized
INFO - 2020-03-04 15:52:23 --> Output Class Initialized
INFO - 2020-03-04 15:52:23 --> Security Class Initialized
DEBUG - 2020-03-04 15:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:52:23 --> Input Class Initialized
INFO - 2020-03-04 15:52:23 --> Language Class Initialized
INFO - 2020-03-04 15:52:23 --> Loader Class Initialized
INFO - 2020-03-04 15:52:23 --> Helper loaded: url_helper
INFO - 2020-03-04 15:52:23 --> Helper loaded: string_helper
INFO - 2020-03-04 15:52:23 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:52:23 --> Controller Class Initialized
INFO - 2020-03-04 15:52:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:52:23 --> Pagination Class Initialized
INFO - 2020-03-04 15:52:23 --> Model "M_show" initialized
INFO - 2020-03-04 15:52:23 --> Helper loaded: form_helper
INFO - 2020-03-04 15:52:23 --> Form Validation Class Initialized
INFO - 2020-03-04 15:52:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:52:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 15:52:23 --> Final output sent to browser
DEBUG - 2020-03-04 15:52:23 --> Total execution time: 0.0062
INFO - 2020-03-04 15:52:37 --> Config Class Initialized
INFO - 2020-03-04 15:52:37 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:52:37 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:52:37 --> Utf8 Class Initialized
INFO - 2020-03-04 15:52:37 --> URI Class Initialized
INFO - 2020-03-04 15:52:37 --> Router Class Initialized
INFO - 2020-03-04 15:52:37 --> Output Class Initialized
INFO - 2020-03-04 15:52:37 --> Security Class Initialized
DEBUG - 2020-03-04 15:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:52:37 --> Input Class Initialized
INFO - 2020-03-04 15:52:37 --> Language Class Initialized
INFO - 2020-03-04 15:52:37 --> Loader Class Initialized
INFO - 2020-03-04 15:52:37 --> Helper loaded: url_helper
INFO - 2020-03-04 15:52:37 --> Helper loaded: string_helper
INFO - 2020-03-04 15:52:37 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:52:37 --> Controller Class Initialized
INFO - 2020-03-04 15:52:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:52:37 --> Pagination Class Initialized
INFO - 2020-03-04 15:52:37 --> Model "M_show" initialized
INFO - 2020-03-04 15:52:37 --> Helper loaded: form_helper
INFO - 2020-03-04 15:52:37 --> Form Validation Class Initialized
INFO - 2020-03-04 15:52:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:52:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:52:37 --> Final output sent to browser
DEBUG - 2020-03-04 15:52:37 --> Total execution time: 0.0070
INFO - 2020-03-04 15:52:41 --> Config Class Initialized
INFO - 2020-03-04 15:52:41 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:52:41 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:52:41 --> Utf8 Class Initialized
INFO - 2020-03-04 15:52:41 --> URI Class Initialized
INFO - 2020-03-04 15:52:41 --> Router Class Initialized
INFO - 2020-03-04 15:52:41 --> Output Class Initialized
INFO - 2020-03-04 15:52:41 --> Security Class Initialized
DEBUG - 2020-03-04 15:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:52:41 --> Input Class Initialized
INFO - 2020-03-04 15:52:41 --> Language Class Initialized
INFO - 2020-03-04 15:52:41 --> Loader Class Initialized
INFO - 2020-03-04 15:52:41 --> Helper loaded: url_helper
INFO - 2020-03-04 15:52:41 --> Helper loaded: string_helper
INFO - 2020-03-04 15:52:41 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:52:41 --> Controller Class Initialized
INFO - 2020-03-04 15:52:41 --> Model "M_tiket" initialized
INFO - 2020-03-04 15:52:41 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 15:52:41 --> Model "M_pesan" initialized
INFO - 2020-03-04 15:52:41 --> Helper loaded: form_helper
INFO - 2020-03-04 15:52:41 --> Form Validation Class Initialized
INFO - 2020-03-04 15:52:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 15:52:41 --> Final output sent to browser
DEBUG - 2020-03-04 15:52:41 --> Total execution time: 0.0078
INFO - 2020-03-04 15:52:57 --> Config Class Initialized
INFO - 2020-03-04 15:52:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:52:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:52:57 --> Utf8 Class Initialized
INFO - 2020-03-04 15:52:57 --> URI Class Initialized
INFO - 2020-03-04 15:52:57 --> Router Class Initialized
INFO - 2020-03-04 15:52:57 --> Output Class Initialized
INFO - 2020-03-04 15:52:57 --> Security Class Initialized
DEBUG - 2020-03-04 15:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:52:57 --> Input Class Initialized
INFO - 2020-03-04 15:52:57 --> Language Class Initialized
INFO - 2020-03-04 15:52:57 --> Loader Class Initialized
INFO - 2020-03-04 15:52:57 --> Helper loaded: url_helper
INFO - 2020-03-04 15:52:57 --> Helper loaded: string_helper
INFO - 2020-03-04 15:52:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:52:57 --> Controller Class Initialized
INFO - 2020-03-04 15:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:52:57 --> Pagination Class Initialized
INFO - 2020-03-04 15:52:57 --> Model "M_show" initialized
INFO - 2020-03-04 15:52:57 --> Helper loaded: form_helper
INFO - 2020-03-04 15:52:57 --> Form Validation Class Initialized
INFO - 2020-03-04 15:52:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:52:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 15:52:57 --> Final output sent to browser
DEBUG - 2020-03-04 15:52:57 --> Total execution time: 0.0062
INFO - 2020-03-04 15:53:02 --> Config Class Initialized
INFO - 2020-03-04 15:53:02 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:53:02 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:53:02 --> Utf8 Class Initialized
INFO - 2020-03-04 15:53:02 --> URI Class Initialized
INFO - 2020-03-04 15:53:02 --> Router Class Initialized
INFO - 2020-03-04 15:53:02 --> Output Class Initialized
INFO - 2020-03-04 15:53:02 --> Security Class Initialized
DEBUG - 2020-03-04 15:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:53:02 --> Input Class Initialized
INFO - 2020-03-04 15:53:02 --> Language Class Initialized
INFO - 2020-03-04 15:53:02 --> Loader Class Initialized
INFO - 2020-03-04 15:53:02 --> Helper loaded: url_helper
INFO - 2020-03-04 15:53:02 --> Helper loaded: string_helper
INFO - 2020-03-04 15:53:02 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:53:02 --> Controller Class Initialized
INFO - 2020-03-04 15:53:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:53:02 --> Pagination Class Initialized
INFO - 2020-03-04 15:53:02 --> Model "M_show" initialized
INFO - 2020-03-04 15:53:02 --> Helper loaded: form_helper
INFO - 2020-03-04 15:53:02 --> Form Validation Class Initialized
INFO - 2020-03-04 15:53:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:53:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:53:02 --> Final output sent to browser
DEBUG - 2020-03-04 15:53:02 --> Total execution time: 0.0074
INFO - 2020-03-04 15:53:08 --> Config Class Initialized
INFO - 2020-03-04 15:53:08 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:53:08 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:53:08 --> Utf8 Class Initialized
INFO - 2020-03-04 15:53:08 --> URI Class Initialized
INFO - 2020-03-04 15:53:08 --> Router Class Initialized
INFO - 2020-03-04 15:53:08 --> Output Class Initialized
INFO - 2020-03-04 15:53:08 --> Security Class Initialized
DEBUG - 2020-03-04 15:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:53:08 --> Input Class Initialized
INFO - 2020-03-04 15:53:08 --> Language Class Initialized
INFO - 2020-03-04 15:53:08 --> Loader Class Initialized
INFO - 2020-03-04 15:53:08 --> Helper loaded: url_helper
INFO - 2020-03-04 15:53:08 --> Helper loaded: string_helper
INFO - 2020-03-04 15:53:08 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:53:08 --> Controller Class Initialized
INFO - 2020-03-04 15:53:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:53:08 --> Pagination Class Initialized
INFO - 2020-03-04 15:53:08 --> Model "M_show" initialized
INFO - 2020-03-04 15:53:08 --> Helper loaded: form_helper
INFO - 2020-03-04 15:53:08 --> Form Validation Class Initialized
INFO - 2020-03-04 15:53:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:53:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-04 15:53:08 --> Final output sent to browser
DEBUG - 2020-03-04 15:53:08 --> Total execution time: 0.0066
INFO - 2020-03-04 15:53:25 --> Config Class Initialized
INFO - 2020-03-04 15:53:25 --> Hooks Class Initialized
DEBUG - 2020-03-04 15:53:25 --> UTF-8 Support Enabled
INFO - 2020-03-04 15:53:25 --> Utf8 Class Initialized
INFO - 2020-03-04 15:53:25 --> URI Class Initialized
INFO - 2020-03-04 15:53:25 --> Router Class Initialized
INFO - 2020-03-04 15:53:25 --> Output Class Initialized
INFO - 2020-03-04 15:53:25 --> Security Class Initialized
DEBUG - 2020-03-04 15:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 15:53:25 --> Input Class Initialized
INFO - 2020-03-04 15:53:25 --> Language Class Initialized
INFO - 2020-03-04 15:53:25 --> Loader Class Initialized
INFO - 2020-03-04 15:53:25 --> Helper loaded: url_helper
INFO - 2020-03-04 15:53:25 --> Helper loaded: string_helper
INFO - 2020-03-04 15:53:25 --> Database Driver Class Initialized
DEBUG - 2020-03-04 15:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 15:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 15:53:25 --> Controller Class Initialized
INFO - 2020-03-04 15:53:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 15:53:25 --> Pagination Class Initialized
INFO - 2020-03-04 15:53:25 --> Model "M_show" initialized
INFO - 2020-03-04 15:53:25 --> Helper loaded: form_helper
INFO - 2020-03-04 15:53:25 --> Form Validation Class Initialized
INFO - 2020-03-04 15:53:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 15:53:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 15:53:25 --> Final output sent to browser
DEBUG - 2020-03-04 15:53:25 --> Total execution time: 0.0069
INFO - 2020-03-04 16:03:56 --> Config Class Initialized
INFO - 2020-03-04 16:03:56 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:03:56 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:03:56 --> Utf8 Class Initialized
INFO - 2020-03-04 16:03:56 --> URI Class Initialized
INFO - 2020-03-04 16:03:56 --> Router Class Initialized
INFO - 2020-03-04 16:03:56 --> Output Class Initialized
INFO - 2020-03-04 16:03:56 --> Security Class Initialized
DEBUG - 2020-03-04 16:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:03:56 --> Input Class Initialized
INFO - 2020-03-04 16:03:56 --> Language Class Initialized
INFO - 2020-03-04 16:03:56 --> Loader Class Initialized
INFO - 2020-03-04 16:03:56 --> Helper loaded: url_helper
INFO - 2020-03-04 16:03:56 --> Helper loaded: string_helper
INFO - 2020-03-04 16:03:56 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:03:56 --> Controller Class Initialized
INFO - 2020-03-04 16:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:03:56 --> Pagination Class Initialized
INFO - 2020-03-04 16:03:56 --> Model "M_show" initialized
INFO - 2020-03-04 16:03:56 --> Helper loaded: form_helper
INFO - 2020-03-04 16:03:56 --> Form Validation Class Initialized
INFO - 2020-03-04 16:03:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:03:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 16:03:56 --> Final output sent to browser
DEBUG - 2020-03-04 16:03:56 --> Total execution time: 0.2091
INFO - 2020-03-04 16:04:17 --> Config Class Initialized
INFO - 2020-03-04 16:04:17 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:04:17 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:04:17 --> Utf8 Class Initialized
INFO - 2020-03-04 16:04:17 --> URI Class Initialized
INFO - 2020-03-04 16:04:17 --> Router Class Initialized
INFO - 2020-03-04 16:04:17 --> Output Class Initialized
INFO - 2020-03-04 16:04:17 --> Security Class Initialized
DEBUG - 2020-03-04 16:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:04:17 --> Input Class Initialized
INFO - 2020-03-04 16:04:17 --> Language Class Initialized
INFO - 2020-03-04 16:04:17 --> Loader Class Initialized
INFO - 2020-03-04 16:04:17 --> Helper loaded: url_helper
INFO - 2020-03-04 16:04:17 --> Helper loaded: string_helper
INFO - 2020-03-04 16:04:17 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:04:17 --> Controller Class Initialized
INFO - 2020-03-04 16:04:17 --> Model "M_tiket" initialized
INFO - 2020-03-04 16:04:17 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 16:04:17 --> Model "M_pesan" initialized
INFO - 2020-03-04 16:04:17 --> Helper loaded: form_helper
INFO - 2020-03-04 16:04:17 --> Form Validation Class Initialized
INFO - 2020-03-04 16:04:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 16:04:17 --> Final output sent to browser
DEBUG - 2020-03-04 16:04:17 --> Total execution time: 0.0102
INFO - 2020-03-04 16:07:05 --> Config Class Initialized
INFO - 2020-03-04 16:07:05 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:07:05 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:07:05 --> Utf8 Class Initialized
INFO - 2020-03-04 16:07:05 --> URI Class Initialized
DEBUG - 2020-03-04 16:07:05 --> No URI present. Default controller set.
INFO - 2020-03-04 16:07:05 --> Router Class Initialized
INFO - 2020-03-04 16:07:05 --> Output Class Initialized
INFO - 2020-03-04 16:07:05 --> Security Class Initialized
DEBUG - 2020-03-04 16:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:07:05 --> Input Class Initialized
INFO - 2020-03-04 16:07:05 --> Language Class Initialized
INFO - 2020-03-04 16:07:05 --> Loader Class Initialized
INFO - 2020-03-04 16:07:05 --> Helper loaded: url_helper
INFO - 2020-03-04 16:07:05 --> Helper loaded: string_helper
INFO - 2020-03-04 16:07:05 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:07:05 --> Controller Class Initialized
INFO - 2020-03-04 16:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:07:05 --> Pagination Class Initialized
INFO - 2020-03-04 16:07:05 --> Model "M_show" initialized
INFO - 2020-03-04 16:07:05 --> Helper loaded: form_helper
INFO - 2020-03-04 16:07:05 --> Form Validation Class Initialized
INFO - 2020-03-04 16:07:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:07:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 16:07:05 --> Final output sent to browser
DEBUG - 2020-03-04 16:07:05 --> Total execution time: 0.0438
INFO - 2020-03-04 16:07:11 --> Config Class Initialized
INFO - 2020-03-04 16:07:11 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:07:11 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:07:11 --> Utf8 Class Initialized
INFO - 2020-03-04 16:07:11 --> URI Class Initialized
INFO - 2020-03-04 16:07:11 --> Router Class Initialized
INFO - 2020-03-04 16:07:11 --> Output Class Initialized
INFO - 2020-03-04 16:07:11 --> Security Class Initialized
DEBUG - 2020-03-04 16:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:07:11 --> Input Class Initialized
INFO - 2020-03-04 16:07:11 --> Language Class Initialized
INFO - 2020-03-04 16:07:11 --> Loader Class Initialized
INFO - 2020-03-04 16:07:11 --> Helper loaded: url_helper
INFO - 2020-03-04 16:07:11 --> Helper loaded: string_helper
INFO - 2020-03-04 16:07:11 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:07:11 --> Controller Class Initialized
INFO - 2020-03-04 16:07:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:07:11 --> Pagination Class Initialized
INFO - 2020-03-04 16:07:11 --> Model "M_show" initialized
INFO - 2020-03-04 16:07:11 --> Helper loaded: form_helper
INFO - 2020-03-04 16:07:11 --> Form Validation Class Initialized
INFO - 2020-03-04 16:07:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:07:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 16:07:11 --> Final output sent to browser
DEBUG - 2020-03-04 16:07:11 --> Total execution time: 0.0135
INFO - 2020-03-04 16:07:12 --> Config Class Initialized
INFO - 2020-03-04 16:07:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:07:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:07:12 --> Utf8 Class Initialized
INFO - 2020-03-04 16:07:12 --> URI Class Initialized
INFO - 2020-03-04 16:07:12 --> Router Class Initialized
INFO - 2020-03-04 16:07:12 --> Output Class Initialized
INFO - 2020-03-04 16:07:12 --> Security Class Initialized
DEBUG - 2020-03-04 16:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:07:12 --> Input Class Initialized
INFO - 2020-03-04 16:07:12 --> Language Class Initialized
ERROR - 2020-03-04 16:07:12 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 16:07:15 --> Config Class Initialized
INFO - 2020-03-04 16:07:15 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:07:15 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:07:15 --> Utf8 Class Initialized
INFO - 2020-03-04 16:07:15 --> URI Class Initialized
INFO - 2020-03-04 16:07:15 --> Router Class Initialized
INFO - 2020-03-04 16:07:15 --> Output Class Initialized
INFO - 2020-03-04 16:07:15 --> Security Class Initialized
DEBUG - 2020-03-04 16:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:07:15 --> Input Class Initialized
INFO - 2020-03-04 16:07:15 --> Language Class Initialized
INFO - 2020-03-04 16:07:15 --> Loader Class Initialized
INFO - 2020-03-04 16:07:15 --> Helper loaded: url_helper
INFO - 2020-03-04 16:07:15 --> Helper loaded: string_helper
INFO - 2020-03-04 16:07:15 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:07:15 --> Controller Class Initialized
INFO - 2020-03-04 16:07:15 --> Model "M_tiket" initialized
INFO - 2020-03-04 16:07:15 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 16:07:15 --> Model "M_pesan" initialized
INFO - 2020-03-04 16:07:15 --> Helper loaded: form_helper
INFO - 2020-03-04 16:07:15 --> Form Validation Class Initialized
INFO - 2020-03-04 16:07:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 16:07:15 --> Final output sent to browser
DEBUG - 2020-03-04 16:07:15 --> Total execution time: 0.0102
INFO - 2020-03-04 16:07:28 --> Config Class Initialized
INFO - 2020-03-04 16:07:28 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:07:28 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:07:28 --> Utf8 Class Initialized
INFO - 2020-03-04 16:07:28 --> URI Class Initialized
INFO - 2020-03-04 16:07:28 --> Router Class Initialized
INFO - 2020-03-04 16:07:28 --> Output Class Initialized
INFO - 2020-03-04 16:07:28 --> Security Class Initialized
DEBUG - 2020-03-04 16:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:07:28 --> Input Class Initialized
INFO - 2020-03-04 16:07:28 --> Language Class Initialized
INFO - 2020-03-04 16:07:28 --> Loader Class Initialized
INFO - 2020-03-04 16:07:28 --> Helper loaded: url_helper
INFO - 2020-03-04 16:07:28 --> Helper loaded: string_helper
INFO - 2020-03-04 16:07:28 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:07:28 --> Controller Class Initialized
INFO - 2020-03-04 16:07:28 --> Model "M_tiket" initialized
INFO - 2020-03-04 16:07:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 16:07:28 --> Model "M_pesan" initialized
INFO - 2020-03-04 16:07:28 --> Helper loaded: form_helper
INFO - 2020-03-04 16:07:28 --> Form Validation Class Initialized
INFO - 2020-03-04 16:07:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 16:07:28 --> Final output sent to browser
DEBUG - 2020-03-04 16:07:28 --> Total execution time: 0.0093
INFO - 2020-03-04 16:07:35 --> Config Class Initialized
INFO - 2020-03-04 16:07:35 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:07:35 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:07:35 --> Utf8 Class Initialized
INFO - 2020-03-04 16:07:35 --> URI Class Initialized
INFO - 2020-03-04 16:07:35 --> Router Class Initialized
INFO - 2020-03-04 16:07:35 --> Output Class Initialized
INFO - 2020-03-04 16:07:35 --> Security Class Initialized
DEBUG - 2020-03-04 16:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:07:35 --> Input Class Initialized
INFO - 2020-03-04 16:07:35 --> Language Class Initialized
INFO - 2020-03-04 16:07:35 --> Loader Class Initialized
INFO - 2020-03-04 16:07:35 --> Helper loaded: url_helper
INFO - 2020-03-04 16:07:35 --> Helper loaded: string_helper
INFO - 2020-03-04 16:07:35 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:07:35 --> Controller Class Initialized
INFO - 2020-03-04 16:07:35 --> Model "M_tiket" initialized
INFO - 2020-03-04 16:07:35 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 16:07:35 --> Model "M_pesan" initialized
INFO - 2020-03-04 16:07:35 --> Helper loaded: form_helper
INFO - 2020-03-04 16:07:35 --> Form Validation Class Initialized
INFO - 2020-03-04 16:07:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 16:07:35 --> Final output sent to browser
DEBUG - 2020-03-04 16:07:35 --> Total execution time: 0.0088
INFO - 2020-03-04 16:10:56 --> Config Class Initialized
INFO - 2020-03-04 16:10:56 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:10:56 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:10:56 --> Utf8 Class Initialized
INFO - 2020-03-04 16:10:56 --> URI Class Initialized
INFO - 2020-03-04 16:10:56 --> Router Class Initialized
INFO - 2020-03-04 16:10:56 --> Output Class Initialized
INFO - 2020-03-04 16:10:56 --> Security Class Initialized
DEBUG - 2020-03-04 16:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:10:56 --> Input Class Initialized
INFO - 2020-03-04 16:10:56 --> Language Class Initialized
INFO - 2020-03-04 16:10:56 --> Loader Class Initialized
INFO - 2020-03-04 16:10:56 --> Helper loaded: url_helper
INFO - 2020-03-04 16:10:56 --> Helper loaded: string_helper
INFO - 2020-03-04 16:10:56 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:10:56 --> Controller Class Initialized
INFO - 2020-03-04 16:10:56 --> Model "M_tiket" initialized
INFO - 2020-03-04 16:10:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 16:10:56 --> Model "M_pesan" initialized
INFO - 2020-03-04 16:10:56 --> Helper loaded: form_helper
INFO - 2020-03-04 16:10:56 --> Form Validation Class Initialized
DEBUG - 2020-03-04 16:10:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-04 16:10:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-04 16:10:56 --> Final output sent to browser
DEBUG - 2020-03-04 16:10:56 --> Total execution time: 0.0433
INFO - 2020-03-04 16:11:03 --> Config Class Initialized
INFO - 2020-03-04 16:11:03 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:11:03 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:11:03 --> Utf8 Class Initialized
INFO - 2020-03-04 16:11:03 --> URI Class Initialized
INFO - 2020-03-04 16:11:03 --> Router Class Initialized
INFO - 2020-03-04 16:11:03 --> Output Class Initialized
INFO - 2020-03-04 16:11:03 --> Security Class Initialized
DEBUG - 2020-03-04 16:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:11:03 --> Input Class Initialized
INFO - 2020-03-04 16:11:03 --> Language Class Initialized
INFO - 2020-03-04 16:11:03 --> Loader Class Initialized
INFO - 2020-03-04 16:11:03 --> Helper loaded: url_helper
INFO - 2020-03-04 16:11:03 --> Helper loaded: string_helper
INFO - 2020-03-04 16:11:03 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:11:03 --> Controller Class Initialized
INFO - 2020-03-04 16:11:03 --> Model "M_tiket" initialized
INFO - 2020-03-04 16:11:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 16:11:03 --> Model "M_pesan" initialized
INFO - 2020-03-04 16:11:03 --> Helper loaded: form_helper
INFO - 2020-03-04 16:11:03 --> Form Validation Class Initialized
INFO - 2020-03-04 16:11:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 16:11:03 --> Final output sent to browser
DEBUG - 2020-03-04 16:11:03 --> Total execution time: 0.0087
INFO - 2020-03-04 16:23:37 --> Config Class Initialized
INFO - 2020-03-04 16:23:37 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:23:37 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:23:37 --> Utf8 Class Initialized
INFO - 2020-03-04 16:23:37 --> URI Class Initialized
INFO - 2020-03-04 16:23:37 --> Router Class Initialized
INFO - 2020-03-04 16:23:37 --> Output Class Initialized
INFO - 2020-03-04 16:23:37 --> Security Class Initialized
DEBUG - 2020-03-04 16:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:23:37 --> Input Class Initialized
INFO - 2020-03-04 16:23:37 --> Language Class Initialized
INFO - 2020-03-04 16:23:37 --> Loader Class Initialized
INFO - 2020-03-04 16:23:37 --> Helper loaded: url_helper
INFO - 2020-03-04 16:23:37 --> Helper loaded: string_helper
INFO - 2020-03-04 16:23:37 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:23:37 --> Controller Class Initialized
INFO - 2020-03-04 16:23:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:23:37 --> Pagination Class Initialized
INFO - 2020-03-04 16:23:37 --> Model "M_show" initialized
INFO - 2020-03-04 16:23:37 --> Helper loaded: form_helper
INFO - 2020-03-04 16:23:37 --> Form Validation Class Initialized
INFO - 2020-03-04 16:23:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:23:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 16:23:37 --> Final output sent to browser
DEBUG - 2020-03-04 16:23:37 --> Total execution time: 0.0306
INFO - 2020-03-04 16:26:04 --> Config Class Initialized
INFO - 2020-03-04 16:26:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:26:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:26:04 --> Utf8 Class Initialized
INFO - 2020-03-04 16:26:04 --> URI Class Initialized
INFO - 2020-03-04 16:26:04 --> Router Class Initialized
INFO - 2020-03-04 16:26:04 --> Output Class Initialized
INFO - 2020-03-04 16:26:04 --> Security Class Initialized
DEBUG - 2020-03-04 16:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:26:04 --> Input Class Initialized
INFO - 2020-03-04 16:26:04 --> Language Class Initialized
INFO - 2020-03-04 16:26:04 --> Loader Class Initialized
INFO - 2020-03-04 16:26:04 --> Helper loaded: url_helper
INFO - 2020-03-04 16:26:04 --> Helper loaded: string_helper
INFO - 2020-03-04 16:26:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:26:04 --> Controller Class Initialized
INFO - 2020-03-04 16:26:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:26:04 --> Pagination Class Initialized
INFO - 2020-03-04 16:26:04 --> Model "M_show" initialized
INFO - 2020-03-04 16:26:04 --> Helper loaded: form_helper
INFO - 2020-03-04 16:26:04 --> Form Validation Class Initialized
INFO - 2020-03-04 16:26:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:26:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 16:26:04 --> Final output sent to browser
DEBUG - 2020-03-04 16:26:04 --> Total execution time: 0.0338
INFO - 2020-03-04 16:26:19 --> Config Class Initialized
INFO - 2020-03-04 16:26:19 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:26:19 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:26:19 --> Utf8 Class Initialized
INFO - 2020-03-04 16:26:19 --> URI Class Initialized
INFO - 2020-03-04 16:26:19 --> Router Class Initialized
INFO - 2020-03-04 16:26:19 --> Output Class Initialized
INFO - 2020-03-04 16:26:19 --> Security Class Initialized
DEBUG - 2020-03-04 16:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:26:19 --> Input Class Initialized
INFO - 2020-03-04 16:26:19 --> Language Class Initialized
INFO - 2020-03-04 16:26:19 --> Loader Class Initialized
INFO - 2020-03-04 16:26:19 --> Helper loaded: url_helper
INFO - 2020-03-04 16:26:19 --> Helper loaded: string_helper
INFO - 2020-03-04 16:26:19 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:26:19 --> Controller Class Initialized
INFO - 2020-03-04 16:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:26:19 --> Pagination Class Initialized
INFO - 2020-03-04 16:26:19 --> Model "M_show" initialized
INFO - 2020-03-04 16:26:19 --> Helper loaded: form_helper
INFO - 2020-03-04 16:26:19 --> Form Validation Class Initialized
INFO - 2020-03-04 16:26:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:26:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 16:26:19 --> Final output sent to browser
DEBUG - 2020-03-04 16:26:19 --> Total execution time: 0.3552
INFO - 2020-03-04 16:26:36 --> Config Class Initialized
INFO - 2020-03-04 16:26:36 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:26:36 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:26:36 --> Utf8 Class Initialized
INFO - 2020-03-04 16:26:36 --> URI Class Initialized
INFO - 2020-03-04 16:26:36 --> Router Class Initialized
INFO - 2020-03-04 16:26:36 --> Output Class Initialized
INFO - 2020-03-04 16:26:36 --> Security Class Initialized
DEBUG - 2020-03-04 16:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:26:36 --> Input Class Initialized
INFO - 2020-03-04 16:26:36 --> Language Class Initialized
INFO - 2020-03-04 16:26:36 --> Loader Class Initialized
INFO - 2020-03-04 16:26:36 --> Helper loaded: url_helper
INFO - 2020-03-04 16:26:36 --> Helper loaded: string_helper
INFO - 2020-03-04 16:26:36 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:26:36 --> Controller Class Initialized
INFO - 2020-03-04 16:26:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:26:36 --> Pagination Class Initialized
INFO - 2020-03-04 16:26:36 --> Model "M_show" initialized
INFO - 2020-03-04 16:26:36 --> Helper loaded: form_helper
INFO - 2020-03-04 16:26:36 --> Form Validation Class Initialized
INFO - 2020-03-04 16:26:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:26:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-04 16:26:36 --> Final output sent to browser
DEBUG - 2020-03-04 16:26:36 --> Total execution time: 0.0067
INFO - 2020-03-04 16:26:39 --> Config Class Initialized
INFO - 2020-03-04 16:26:39 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:26:39 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:26:39 --> Utf8 Class Initialized
INFO - 2020-03-04 16:26:39 --> URI Class Initialized
INFO - 2020-03-04 16:26:39 --> Router Class Initialized
INFO - 2020-03-04 16:26:39 --> Output Class Initialized
INFO - 2020-03-04 16:26:39 --> Security Class Initialized
DEBUG - 2020-03-04 16:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:26:39 --> Input Class Initialized
INFO - 2020-03-04 16:26:39 --> Language Class Initialized
INFO - 2020-03-04 16:26:39 --> Loader Class Initialized
INFO - 2020-03-04 16:26:39 --> Helper loaded: url_helper
INFO - 2020-03-04 16:26:39 --> Helper loaded: string_helper
INFO - 2020-03-04 16:26:39 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:26:39 --> Controller Class Initialized
INFO - 2020-03-04 16:26:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:26:39 --> Pagination Class Initialized
INFO - 2020-03-04 16:26:39 --> Model "M_show" initialized
INFO - 2020-03-04 16:26:39 --> Helper loaded: form_helper
INFO - 2020-03-04 16:26:39 --> Form Validation Class Initialized
INFO - 2020-03-04 16:26:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:26:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-04 16:26:39 --> Final output sent to browser
DEBUG - 2020-03-04 16:26:39 --> Total execution time: 0.0055
INFO - 2020-03-04 16:27:24 --> Config Class Initialized
INFO - 2020-03-04 16:27:24 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:27:24 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:27:24 --> Utf8 Class Initialized
INFO - 2020-03-04 16:27:24 --> URI Class Initialized
INFO - 2020-03-04 16:27:24 --> Router Class Initialized
INFO - 2020-03-04 16:27:24 --> Output Class Initialized
INFO - 2020-03-04 16:27:24 --> Security Class Initialized
DEBUG - 2020-03-04 16:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:27:24 --> Input Class Initialized
INFO - 2020-03-04 16:27:24 --> Language Class Initialized
INFO - 2020-03-04 16:27:24 --> Loader Class Initialized
INFO - 2020-03-04 16:27:24 --> Helper loaded: url_helper
INFO - 2020-03-04 16:27:24 --> Helper loaded: string_helper
INFO - 2020-03-04 16:27:24 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:27:25 --> Controller Class Initialized
INFO - 2020-03-04 16:27:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:27:25 --> Pagination Class Initialized
INFO - 2020-03-04 16:27:25 --> Model "M_show" initialized
INFO - 2020-03-04 16:27:25 --> Helper loaded: form_helper
INFO - 2020-03-04 16:27:25 --> Form Validation Class Initialized
INFO - 2020-03-04 16:27:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:27:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 16:27:25 --> Final output sent to browser
DEBUG - 2020-03-04 16:27:25 --> Total execution time: 0.3370
INFO - 2020-03-04 16:30:24 --> Config Class Initialized
INFO - 2020-03-04 16:30:24 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:30:24 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:30:24 --> Utf8 Class Initialized
INFO - 2020-03-04 16:30:24 --> URI Class Initialized
INFO - 2020-03-04 16:30:24 --> Router Class Initialized
INFO - 2020-03-04 16:30:24 --> Output Class Initialized
INFO - 2020-03-04 16:30:24 --> Security Class Initialized
DEBUG - 2020-03-04 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:30:24 --> Input Class Initialized
INFO - 2020-03-04 16:30:24 --> Language Class Initialized
INFO - 2020-03-04 16:30:24 --> Loader Class Initialized
INFO - 2020-03-04 16:30:24 --> Helper loaded: url_helper
INFO - 2020-03-04 16:30:24 --> Helper loaded: string_helper
INFO - 2020-03-04 16:30:24 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:30:24 --> Controller Class Initialized
INFO - 2020-03-04 16:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:30:24 --> Pagination Class Initialized
INFO - 2020-03-04 16:30:24 --> Model "M_show" initialized
INFO - 2020-03-04 16:30:24 --> Helper loaded: form_helper
INFO - 2020-03-04 16:30:24 --> Form Validation Class Initialized
INFO - 2020-03-04 16:30:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:30:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 16:30:24 --> Final output sent to browser
DEBUG - 2020-03-04 16:30:24 --> Total execution time: 0.0340
INFO - 2020-03-04 16:30:25 --> Config Class Initialized
INFO - 2020-03-04 16:30:25 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:30:25 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:30:25 --> Utf8 Class Initialized
INFO - 2020-03-04 16:30:25 --> URI Class Initialized
INFO - 2020-03-04 16:30:25 --> Router Class Initialized
INFO - 2020-03-04 16:30:25 --> Output Class Initialized
INFO - 2020-03-04 16:30:25 --> Security Class Initialized
DEBUG - 2020-03-04 16:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:30:25 --> Input Class Initialized
INFO - 2020-03-04 16:30:25 --> Language Class Initialized
INFO - 2020-03-04 16:30:25 --> Loader Class Initialized
INFO - 2020-03-04 16:30:25 --> Helper loaded: url_helper
INFO - 2020-03-04 16:30:25 --> Helper loaded: string_helper
INFO - 2020-03-04 16:30:25 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:30:25 --> Controller Class Initialized
INFO - 2020-03-04 16:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:30:25 --> Pagination Class Initialized
INFO - 2020-03-04 16:30:25 --> Model "M_show" initialized
INFO - 2020-03-04 16:30:25 --> Helper loaded: form_helper
INFO - 2020-03-04 16:30:25 --> Form Validation Class Initialized
INFO - 2020-03-04 16:30:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:30:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 16:30:25 --> Final output sent to browser
DEBUG - 2020-03-04 16:30:25 --> Total execution time: 0.0064
INFO - 2020-03-04 16:35:01 --> Config Class Initialized
INFO - 2020-03-04 16:35:01 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:35:01 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:35:01 --> Utf8 Class Initialized
INFO - 2020-03-04 16:35:01 --> URI Class Initialized
INFO - 2020-03-04 16:35:01 --> Router Class Initialized
INFO - 2020-03-04 16:35:01 --> Output Class Initialized
INFO - 2020-03-04 16:35:01 --> Security Class Initialized
DEBUG - 2020-03-04 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:35:01 --> Input Class Initialized
INFO - 2020-03-04 16:35:01 --> Language Class Initialized
INFO - 2020-03-04 16:35:01 --> Loader Class Initialized
INFO - 2020-03-04 16:35:01 --> Helper loaded: url_helper
INFO - 2020-03-04 16:35:01 --> Helper loaded: string_helper
INFO - 2020-03-04 16:35:01 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:35:01 --> Controller Class Initialized
INFO - 2020-03-04 16:35:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:35:01 --> Pagination Class Initialized
INFO - 2020-03-04 16:35:01 --> Model "M_show" initialized
INFO - 2020-03-04 16:35:01 --> Helper loaded: form_helper
INFO - 2020-03-04 16:35:01 --> Form Validation Class Initialized
INFO - 2020-03-04 16:35:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:35:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 16:35:01 --> Final output sent to browser
DEBUG - 2020-03-04 16:35:01 --> Total execution time: 0.0343
INFO - 2020-03-04 16:35:03 --> Config Class Initialized
INFO - 2020-03-04 16:35:03 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:35:03 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:35:03 --> Utf8 Class Initialized
INFO - 2020-03-04 16:35:03 --> URI Class Initialized
INFO - 2020-03-04 16:35:03 --> Router Class Initialized
INFO - 2020-03-04 16:35:03 --> Output Class Initialized
INFO - 2020-03-04 16:35:03 --> Security Class Initialized
DEBUG - 2020-03-04 16:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:35:03 --> Input Class Initialized
INFO - 2020-03-04 16:35:03 --> Language Class Initialized
INFO - 2020-03-04 16:35:03 --> Loader Class Initialized
INFO - 2020-03-04 16:35:03 --> Helper loaded: url_helper
INFO - 2020-03-04 16:35:03 --> Helper loaded: string_helper
INFO - 2020-03-04 16:35:03 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:35:03 --> Controller Class Initialized
INFO - 2020-03-04 16:35:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:35:03 --> Pagination Class Initialized
INFO - 2020-03-04 16:35:03 --> Model "M_show" initialized
INFO - 2020-03-04 16:35:03 --> Helper loaded: form_helper
INFO - 2020-03-04 16:35:03 --> Form Validation Class Initialized
INFO - 2020-03-04 16:35:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:35:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 16:35:03 --> Final output sent to browser
DEBUG - 2020-03-04 16:35:03 --> Total execution time: 0.0137
INFO - 2020-03-04 16:35:26 --> Config Class Initialized
INFO - 2020-03-04 16:35:26 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:35:26 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:35:26 --> Utf8 Class Initialized
INFO - 2020-03-04 16:35:26 --> URI Class Initialized
INFO - 2020-03-04 16:35:26 --> Router Class Initialized
INFO - 2020-03-04 16:35:26 --> Output Class Initialized
INFO - 2020-03-04 16:35:26 --> Security Class Initialized
DEBUG - 2020-03-04 16:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:35:26 --> Input Class Initialized
INFO - 2020-03-04 16:35:26 --> Language Class Initialized
INFO - 2020-03-04 16:35:26 --> Loader Class Initialized
INFO - 2020-03-04 16:35:26 --> Helper loaded: url_helper
INFO - 2020-03-04 16:35:26 --> Helper loaded: string_helper
INFO - 2020-03-04 16:35:26 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:35:26 --> Controller Class Initialized
INFO - 2020-03-04 16:35:26 --> Model "M_tiket" initialized
INFO - 2020-03-04 16:35:26 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 16:35:26 --> Model "M_pesan" initialized
INFO - 2020-03-04 16:35:26 --> Helper loaded: form_helper
INFO - 2020-03-04 16:35:26 --> Form Validation Class Initialized
INFO - 2020-03-04 16:35:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 16:35:26 --> Final output sent to browser
DEBUG - 2020-03-04 16:35:26 --> Total execution time: 0.0092
INFO - 2020-03-04 16:37:40 --> Config Class Initialized
INFO - 2020-03-04 16:37:40 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:37:40 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:37:40 --> Utf8 Class Initialized
INFO - 2020-03-04 16:37:40 --> URI Class Initialized
INFO - 2020-03-04 16:37:40 --> Router Class Initialized
INFO - 2020-03-04 16:37:40 --> Output Class Initialized
INFO - 2020-03-04 16:37:40 --> Security Class Initialized
DEBUG - 2020-03-04 16:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:37:40 --> Input Class Initialized
INFO - 2020-03-04 16:37:40 --> Language Class Initialized
INFO - 2020-03-04 16:37:40 --> Loader Class Initialized
INFO - 2020-03-04 16:37:40 --> Helper loaded: url_helper
INFO - 2020-03-04 16:37:40 --> Helper loaded: string_helper
INFO - 2020-03-04 16:37:40 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:37:40 --> Controller Class Initialized
INFO - 2020-03-04 16:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:37:40 --> Pagination Class Initialized
INFO - 2020-03-04 16:37:40 --> Model "M_show" initialized
INFO - 2020-03-04 16:37:40 --> Helper loaded: form_helper
INFO - 2020-03-04 16:37:40 --> Form Validation Class Initialized
INFO - 2020-03-04 16:37:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:37:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 16:37:40 --> Final output sent to browser
DEBUG - 2020-03-04 16:37:40 --> Total execution time: 0.0327
INFO - 2020-03-04 16:56:38 --> Config Class Initialized
INFO - 2020-03-04 16:56:38 --> Hooks Class Initialized
DEBUG - 2020-03-04 16:56:38 --> UTF-8 Support Enabled
INFO - 2020-03-04 16:56:38 --> Utf8 Class Initialized
INFO - 2020-03-04 16:56:38 --> URI Class Initialized
DEBUG - 2020-03-04 16:56:38 --> No URI present. Default controller set.
INFO - 2020-03-04 16:56:38 --> Router Class Initialized
INFO - 2020-03-04 16:56:38 --> Output Class Initialized
INFO - 2020-03-04 16:56:38 --> Security Class Initialized
DEBUG - 2020-03-04 16:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 16:56:38 --> Input Class Initialized
INFO - 2020-03-04 16:56:38 --> Language Class Initialized
INFO - 2020-03-04 16:56:38 --> Loader Class Initialized
INFO - 2020-03-04 16:56:38 --> Helper loaded: url_helper
INFO - 2020-03-04 16:56:38 --> Helper loaded: string_helper
INFO - 2020-03-04 16:56:38 --> Database Driver Class Initialized
DEBUG - 2020-03-04 16:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 16:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 16:56:38 --> Controller Class Initialized
INFO - 2020-03-04 16:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 16:56:38 --> Pagination Class Initialized
INFO - 2020-03-04 16:56:38 --> Model "M_show" initialized
INFO - 2020-03-04 16:56:38 --> Helper loaded: form_helper
INFO - 2020-03-04 16:56:38 --> Form Validation Class Initialized
INFO - 2020-03-04 16:56:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 16:56:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 16:56:38 --> Final output sent to browser
DEBUG - 2020-03-04 16:56:38 --> Total execution time: 0.0297
INFO - 2020-03-04 17:07:35 --> Config Class Initialized
INFO - 2020-03-04 17:07:35 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:07:35 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:07:35 --> Utf8 Class Initialized
INFO - 2020-03-04 17:07:35 --> URI Class Initialized
INFO - 2020-03-04 17:07:35 --> Router Class Initialized
INFO - 2020-03-04 17:07:35 --> Output Class Initialized
INFO - 2020-03-04 17:07:35 --> Security Class Initialized
DEBUG - 2020-03-04 17:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:07:35 --> Input Class Initialized
INFO - 2020-03-04 17:07:35 --> Language Class Initialized
INFO - 2020-03-04 17:07:35 --> Loader Class Initialized
INFO - 2020-03-04 17:07:35 --> Helper loaded: url_helper
INFO - 2020-03-04 17:07:35 --> Helper loaded: string_helper
INFO - 2020-03-04 17:07:35 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:07:35 --> Controller Class Initialized
INFO - 2020-03-04 17:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 17:07:35 --> Pagination Class Initialized
INFO - 2020-03-04 17:07:35 --> Model "M_show" initialized
INFO - 2020-03-04 17:07:35 --> Helper loaded: form_helper
INFO - 2020-03-04 17:07:35 --> Form Validation Class Initialized
INFO - 2020-03-04 17:07:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 17:07:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 17:07:35 --> Final output sent to browser
DEBUG - 2020-03-04 17:07:35 --> Total execution time: 0.1968
INFO - 2020-03-04 17:07:36 --> Config Class Initialized
INFO - 2020-03-04 17:07:36 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:07:36 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:07:36 --> Utf8 Class Initialized
INFO - 2020-03-04 17:07:36 --> URI Class Initialized
INFO - 2020-03-04 17:07:36 --> Router Class Initialized
INFO - 2020-03-04 17:07:36 --> Output Class Initialized
INFO - 2020-03-04 17:07:36 --> Security Class Initialized
DEBUG - 2020-03-04 17:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:07:36 --> Input Class Initialized
INFO - 2020-03-04 17:07:36 --> Language Class Initialized
INFO - 2020-03-04 17:07:36 --> Loader Class Initialized
INFO - 2020-03-04 17:07:36 --> Helper loaded: url_helper
INFO - 2020-03-04 17:07:36 --> Helper loaded: string_helper
INFO - 2020-03-04 17:07:36 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:07:36 --> Controller Class Initialized
INFO - 2020-03-04 17:07:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 17:07:36 --> Pagination Class Initialized
INFO - 2020-03-04 17:07:36 --> Model "M_show" initialized
INFO - 2020-03-04 17:07:36 --> Helper loaded: form_helper
INFO - 2020-03-04 17:07:36 --> Form Validation Class Initialized
INFO - 2020-03-04 17:07:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 17:07:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 17:07:36 --> Final output sent to browser
DEBUG - 2020-03-04 17:07:36 --> Total execution time: 0.0728
INFO - 2020-03-04 17:07:45 --> Config Class Initialized
INFO - 2020-03-04 17:07:45 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:07:45 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:07:45 --> Utf8 Class Initialized
INFO - 2020-03-04 17:07:45 --> URI Class Initialized
INFO - 2020-03-04 17:07:45 --> Router Class Initialized
INFO - 2020-03-04 17:07:45 --> Output Class Initialized
INFO - 2020-03-04 17:07:45 --> Security Class Initialized
DEBUG - 2020-03-04 17:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:07:45 --> Input Class Initialized
INFO - 2020-03-04 17:07:45 --> Language Class Initialized
INFO - 2020-03-04 17:07:45 --> Loader Class Initialized
INFO - 2020-03-04 17:07:45 --> Helper loaded: url_helper
INFO - 2020-03-04 17:07:45 --> Helper loaded: string_helper
INFO - 2020-03-04 17:07:45 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:07:45 --> Controller Class Initialized
INFO - 2020-03-04 17:07:45 --> Model "M_tiket" initialized
INFO - 2020-03-04 17:07:45 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 17:07:45 --> Model "M_pesan" initialized
INFO - 2020-03-04 17:07:45 --> Helper loaded: form_helper
INFO - 2020-03-04 17:07:45 --> Form Validation Class Initialized
INFO - 2020-03-04 17:07:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 17:07:45 --> Final output sent to browser
DEBUG - 2020-03-04 17:07:45 --> Total execution time: 0.0124
INFO - 2020-03-04 17:08:14 --> Config Class Initialized
INFO - 2020-03-04 17:08:14 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:08:14 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:08:14 --> Utf8 Class Initialized
INFO - 2020-03-04 17:08:14 --> URI Class Initialized
INFO - 2020-03-04 17:08:14 --> Router Class Initialized
INFO - 2020-03-04 17:08:14 --> Output Class Initialized
INFO - 2020-03-04 17:08:14 --> Security Class Initialized
DEBUG - 2020-03-04 17:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:08:14 --> Input Class Initialized
INFO - 2020-03-04 17:08:14 --> Language Class Initialized
INFO - 2020-03-04 17:08:14 --> Loader Class Initialized
INFO - 2020-03-04 17:08:14 --> Helper loaded: url_helper
INFO - 2020-03-04 17:08:14 --> Helper loaded: string_helper
INFO - 2020-03-04 17:08:14 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:08:14 --> Controller Class Initialized
INFO - 2020-03-04 17:08:14 --> Model "M_tiket" initialized
INFO - 2020-03-04 17:08:14 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 17:08:14 --> Model "M_pesan" initialized
INFO - 2020-03-04 17:08:14 --> Helper loaded: form_helper
INFO - 2020-03-04 17:08:14 --> Form Validation Class Initialized
INFO - 2020-03-04 17:08:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 17:08:14 --> Final output sent to browser
DEBUG - 2020-03-04 17:08:14 --> Total execution time: 0.0080
INFO - 2020-03-04 17:08:28 --> Config Class Initialized
INFO - 2020-03-04 17:08:28 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:08:28 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:08:28 --> Utf8 Class Initialized
INFO - 2020-03-04 17:08:28 --> URI Class Initialized
INFO - 2020-03-04 17:08:28 --> Router Class Initialized
INFO - 2020-03-04 17:08:28 --> Output Class Initialized
INFO - 2020-03-04 17:08:28 --> Security Class Initialized
DEBUG - 2020-03-04 17:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:08:28 --> Input Class Initialized
INFO - 2020-03-04 17:08:28 --> Language Class Initialized
INFO - 2020-03-04 17:08:28 --> Loader Class Initialized
INFO - 2020-03-04 17:08:28 --> Helper loaded: url_helper
INFO - 2020-03-04 17:08:28 --> Helper loaded: string_helper
INFO - 2020-03-04 17:08:28 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:08:28 --> Controller Class Initialized
INFO - 2020-03-04 17:08:28 --> Model "M_tiket" initialized
INFO - 2020-03-04 17:08:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 17:08:28 --> Model "M_pesan" initialized
INFO - 2020-03-04 17:08:28 --> Helper loaded: form_helper
INFO - 2020-03-04 17:08:28 --> Form Validation Class Initialized
INFO - 2020-03-04 17:08:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 17:08:28 --> Final output sent to browser
DEBUG - 2020-03-04 17:08:28 --> Total execution time: 0.0075
INFO - 2020-03-04 17:08:37 --> Config Class Initialized
INFO - 2020-03-04 17:08:37 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:08:37 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:08:37 --> Utf8 Class Initialized
INFO - 2020-03-04 17:08:37 --> URI Class Initialized
INFO - 2020-03-04 17:08:37 --> Router Class Initialized
INFO - 2020-03-04 17:08:37 --> Output Class Initialized
INFO - 2020-03-04 17:08:37 --> Security Class Initialized
DEBUG - 2020-03-04 17:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:08:37 --> Input Class Initialized
INFO - 2020-03-04 17:08:37 --> Language Class Initialized
INFO - 2020-03-04 17:08:37 --> Loader Class Initialized
INFO - 2020-03-04 17:08:37 --> Helper loaded: url_helper
INFO - 2020-03-04 17:08:37 --> Helper loaded: string_helper
INFO - 2020-03-04 17:08:37 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:08:37 --> Controller Class Initialized
INFO - 2020-03-04 17:08:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 17:08:37 --> Pagination Class Initialized
INFO - 2020-03-04 17:08:37 --> Model "M_show" initialized
INFO - 2020-03-04 17:08:37 --> Helper loaded: form_helper
INFO - 2020-03-04 17:08:37 --> Form Validation Class Initialized
INFO - 2020-03-04 17:08:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 17:08:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 17:08:37 --> Final output sent to browser
DEBUG - 2020-03-04 17:08:37 --> Total execution time: 0.0063
INFO - 2020-03-04 17:08:39 --> Config Class Initialized
INFO - 2020-03-04 17:08:39 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:08:39 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:08:39 --> Utf8 Class Initialized
INFO - 2020-03-04 17:08:39 --> URI Class Initialized
INFO - 2020-03-04 17:08:39 --> Router Class Initialized
INFO - 2020-03-04 17:08:39 --> Output Class Initialized
INFO - 2020-03-04 17:08:39 --> Security Class Initialized
DEBUG - 2020-03-04 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:08:39 --> Input Class Initialized
INFO - 2020-03-04 17:08:39 --> Language Class Initialized
INFO - 2020-03-04 17:08:39 --> Loader Class Initialized
INFO - 2020-03-04 17:08:39 --> Helper loaded: url_helper
INFO - 2020-03-04 17:08:39 --> Helper loaded: string_helper
INFO - 2020-03-04 17:08:39 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:08:39 --> Controller Class Initialized
INFO - 2020-03-04 17:08:39 --> Model "M_tiket" initialized
INFO - 2020-03-04 17:08:39 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 17:08:39 --> Model "M_pesan" initialized
INFO - 2020-03-04 17:08:39 --> Helper loaded: form_helper
INFO - 2020-03-04 17:08:39 --> Form Validation Class Initialized
INFO - 2020-03-04 17:08:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 17:08:39 --> Final output sent to browser
DEBUG - 2020-03-04 17:08:39 --> Total execution time: 0.0090
INFO - 2020-03-04 17:08:46 --> Config Class Initialized
INFO - 2020-03-04 17:08:46 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:08:46 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:08:46 --> Utf8 Class Initialized
INFO - 2020-03-04 17:08:46 --> URI Class Initialized
INFO - 2020-03-04 17:08:46 --> Router Class Initialized
INFO - 2020-03-04 17:08:46 --> Output Class Initialized
INFO - 2020-03-04 17:08:46 --> Security Class Initialized
DEBUG - 2020-03-04 17:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:08:46 --> Input Class Initialized
INFO - 2020-03-04 17:08:46 --> Language Class Initialized
INFO - 2020-03-04 17:08:46 --> Loader Class Initialized
INFO - 2020-03-04 17:08:46 --> Helper loaded: url_helper
INFO - 2020-03-04 17:08:46 --> Helper loaded: string_helper
INFO - 2020-03-04 17:08:46 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:08:46 --> Controller Class Initialized
INFO - 2020-03-04 17:08:46 --> Model "M_tiket" initialized
INFO - 2020-03-04 17:08:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 17:08:46 --> Model "M_pesan" initialized
INFO - 2020-03-04 17:08:46 --> Helper loaded: form_helper
INFO - 2020-03-04 17:08:46 --> Form Validation Class Initialized
INFO - 2020-03-04 17:08:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 17:08:46 --> Final output sent to browser
DEBUG - 2020-03-04 17:08:46 --> Total execution time: 0.0067
INFO - 2020-03-04 17:08:51 --> Config Class Initialized
INFO - 2020-03-04 17:08:51 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:08:51 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:08:51 --> Utf8 Class Initialized
INFO - 2020-03-04 17:08:51 --> URI Class Initialized
INFO - 2020-03-04 17:08:51 --> Router Class Initialized
INFO - 2020-03-04 17:08:51 --> Output Class Initialized
INFO - 2020-03-04 17:08:51 --> Security Class Initialized
DEBUG - 2020-03-04 17:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:08:51 --> Input Class Initialized
INFO - 2020-03-04 17:08:51 --> Language Class Initialized
ERROR - 2020-03-04 17:08:51 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 17:09:06 --> Config Class Initialized
INFO - 2020-03-04 17:09:06 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:09:06 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:09:06 --> Utf8 Class Initialized
INFO - 2020-03-04 17:09:06 --> URI Class Initialized
INFO - 2020-03-04 17:09:06 --> Router Class Initialized
INFO - 2020-03-04 17:09:06 --> Output Class Initialized
INFO - 2020-03-04 17:09:06 --> Security Class Initialized
DEBUG - 2020-03-04 17:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:09:06 --> Input Class Initialized
INFO - 2020-03-04 17:09:06 --> Language Class Initialized
INFO - 2020-03-04 17:09:06 --> Loader Class Initialized
INFO - 2020-03-04 17:09:06 --> Helper loaded: url_helper
INFO - 2020-03-04 17:09:06 --> Helper loaded: string_helper
INFO - 2020-03-04 17:09:06 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:09:06 --> Controller Class Initialized
INFO - 2020-03-04 17:09:06 --> Model "M_tiket" initialized
INFO - 2020-03-04 17:09:06 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 17:09:06 --> Model "M_pesan" initialized
INFO - 2020-03-04 17:09:06 --> Helper loaded: form_helper
INFO - 2020-03-04 17:09:06 --> Form Validation Class Initialized
INFO - 2020-03-04 17:09:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 17:09:06 --> Final output sent to browser
DEBUG - 2020-03-04 17:09:06 --> Total execution time: 0.0076
INFO - 2020-03-04 17:09:44 --> Config Class Initialized
INFO - 2020-03-04 17:09:44 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:09:44 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:09:44 --> Utf8 Class Initialized
INFO - 2020-03-04 17:09:44 --> URI Class Initialized
INFO - 2020-03-04 17:09:44 --> Router Class Initialized
INFO - 2020-03-04 17:09:44 --> Output Class Initialized
INFO - 2020-03-04 17:09:44 --> Security Class Initialized
DEBUG - 2020-03-04 17:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:09:44 --> Input Class Initialized
INFO - 2020-03-04 17:09:44 --> Language Class Initialized
INFO - 2020-03-04 17:09:44 --> Loader Class Initialized
INFO - 2020-03-04 17:09:44 --> Helper loaded: url_helper
INFO - 2020-03-04 17:09:44 --> Helper loaded: string_helper
INFO - 2020-03-04 17:09:44 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:09:44 --> Controller Class Initialized
INFO - 2020-03-04 17:09:44 --> Model "M_tiket" initialized
INFO - 2020-03-04 17:09:44 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 17:09:44 --> Model "M_pesan" initialized
INFO - 2020-03-04 17:09:44 --> Helper loaded: form_helper
INFO - 2020-03-04 17:09:44 --> Form Validation Class Initialized
INFO - 2020-03-04 17:09:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 17:09:44 --> Final output sent to browser
DEBUG - 2020-03-04 17:09:44 --> Total execution time: 0.0072
INFO - 2020-03-04 17:10:01 --> Config Class Initialized
INFO - 2020-03-04 17:10:01 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:10:01 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:10:01 --> Utf8 Class Initialized
INFO - 2020-03-04 17:10:01 --> URI Class Initialized
DEBUG - 2020-03-04 17:10:01 --> No URI present. Default controller set.
INFO - 2020-03-04 17:10:01 --> Router Class Initialized
INFO - 2020-03-04 17:10:01 --> Output Class Initialized
INFO - 2020-03-04 17:10:01 --> Security Class Initialized
DEBUG - 2020-03-04 17:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:10:01 --> Input Class Initialized
INFO - 2020-03-04 17:10:01 --> Language Class Initialized
INFO - 2020-03-04 17:10:01 --> Loader Class Initialized
INFO - 2020-03-04 17:10:01 --> Helper loaded: url_helper
INFO - 2020-03-04 17:10:01 --> Helper loaded: string_helper
INFO - 2020-03-04 17:10:01 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:10:01 --> Controller Class Initialized
INFO - 2020-03-04 17:10:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 17:10:01 --> Pagination Class Initialized
INFO - 2020-03-04 17:10:01 --> Model "M_show" initialized
INFO - 2020-03-04 17:10:01 --> Helper loaded: form_helper
INFO - 2020-03-04 17:10:01 --> Form Validation Class Initialized
INFO - 2020-03-04 17:10:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 17:10:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 17:10:01 --> Final output sent to browser
DEBUG - 2020-03-04 17:10:01 --> Total execution time: 0.0064
INFO - 2020-03-04 17:19:52 --> Config Class Initialized
INFO - 2020-03-04 17:19:52 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:19:52 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:19:52 --> Utf8 Class Initialized
INFO - 2020-03-04 17:19:52 --> URI Class Initialized
INFO - 2020-03-04 17:19:52 --> Router Class Initialized
INFO - 2020-03-04 17:19:52 --> Output Class Initialized
INFO - 2020-03-04 17:19:52 --> Security Class Initialized
DEBUG - 2020-03-04 17:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:19:52 --> Input Class Initialized
INFO - 2020-03-04 17:19:52 --> Language Class Initialized
INFO - 2020-03-04 17:19:52 --> Loader Class Initialized
INFO - 2020-03-04 17:19:52 --> Helper loaded: url_helper
INFO - 2020-03-04 17:19:52 --> Helper loaded: string_helper
INFO - 2020-03-04 17:19:52 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:19:52 --> Controller Class Initialized
INFO - 2020-03-04 17:19:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 17:19:52 --> Pagination Class Initialized
INFO - 2020-03-04 17:19:52 --> Model "M_show" initialized
INFO - 2020-03-04 17:19:52 --> Helper loaded: form_helper
INFO - 2020-03-04 17:19:52 --> Form Validation Class Initialized
INFO - 2020-03-04 17:19:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 17:19:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 17:19:52 --> Final output sent to browser
DEBUG - 2020-03-04 17:19:52 --> Total execution time: 0.0342
INFO - 2020-03-04 17:19:55 --> Config Class Initialized
INFO - 2020-03-04 17:19:55 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:19:55 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:19:55 --> Utf8 Class Initialized
INFO - 2020-03-04 17:19:55 --> URI Class Initialized
INFO - 2020-03-04 17:19:55 --> Router Class Initialized
INFO - 2020-03-04 17:19:55 --> Output Class Initialized
INFO - 2020-03-04 17:19:55 --> Security Class Initialized
DEBUG - 2020-03-04 17:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:19:55 --> Input Class Initialized
INFO - 2020-03-04 17:19:55 --> Language Class Initialized
ERROR - 2020-03-04 17:19:55 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 17:20:03 --> Config Class Initialized
INFO - 2020-03-04 17:20:03 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:20:03 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:20:03 --> Utf8 Class Initialized
INFO - 2020-03-04 17:20:03 --> URI Class Initialized
INFO - 2020-03-04 17:20:03 --> Router Class Initialized
INFO - 2020-03-04 17:20:03 --> Output Class Initialized
INFO - 2020-03-04 17:20:03 --> Security Class Initialized
DEBUG - 2020-03-04 17:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:20:03 --> Input Class Initialized
INFO - 2020-03-04 17:20:03 --> Language Class Initialized
INFO - 2020-03-04 17:20:03 --> Loader Class Initialized
INFO - 2020-03-04 17:20:03 --> Helper loaded: url_helper
INFO - 2020-03-04 17:20:03 --> Helper loaded: string_helper
INFO - 2020-03-04 17:20:03 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:20:03 --> Controller Class Initialized
INFO - 2020-03-04 17:20:03 --> Model "M_tiket" initialized
INFO - 2020-03-04 17:20:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 17:20:03 --> Model "M_pesan" initialized
INFO - 2020-03-04 17:20:03 --> Helper loaded: form_helper
INFO - 2020-03-04 17:20:03 --> Form Validation Class Initialized
INFO - 2020-03-04 17:20:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 17:20:03 --> Final output sent to browser
DEBUG - 2020-03-04 17:20:03 --> Total execution time: 0.0354
INFO - 2020-03-04 17:20:27 --> Config Class Initialized
INFO - 2020-03-04 17:20:27 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:20:27 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:20:27 --> Utf8 Class Initialized
INFO - 2020-03-04 17:20:27 --> URI Class Initialized
INFO - 2020-03-04 17:20:27 --> Router Class Initialized
INFO - 2020-03-04 17:20:27 --> Output Class Initialized
INFO - 2020-03-04 17:20:27 --> Security Class Initialized
DEBUG - 2020-03-04 17:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:20:27 --> Input Class Initialized
INFO - 2020-03-04 17:20:27 --> Language Class Initialized
INFO - 2020-03-04 17:20:27 --> Loader Class Initialized
INFO - 2020-03-04 17:20:27 --> Helper loaded: url_helper
INFO - 2020-03-04 17:20:27 --> Helper loaded: string_helper
INFO - 2020-03-04 17:20:27 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:20:27 --> Controller Class Initialized
INFO - 2020-03-04 17:20:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 17:20:27 --> Pagination Class Initialized
INFO - 2020-03-04 17:20:27 --> Model "M_show" initialized
INFO - 2020-03-04 17:20:27 --> Helper loaded: form_helper
INFO - 2020-03-04 17:20:27 --> Form Validation Class Initialized
INFO - 2020-03-04 17:20:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 17:20:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-04 17:20:27 --> Final output sent to browser
DEBUG - 2020-03-04 17:20:27 --> Total execution time: 0.1246
INFO - 2020-03-04 17:43:33 --> Config Class Initialized
INFO - 2020-03-04 17:43:33 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:43:33 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:43:33 --> Utf8 Class Initialized
INFO - 2020-03-04 17:43:33 --> URI Class Initialized
DEBUG - 2020-03-04 17:43:33 --> No URI present. Default controller set.
INFO - 2020-03-04 17:43:33 --> Router Class Initialized
INFO - 2020-03-04 17:43:33 --> Output Class Initialized
INFO - 2020-03-04 17:43:33 --> Security Class Initialized
DEBUG - 2020-03-04 17:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:43:33 --> Input Class Initialized
INFO - 2020-03-04 17:43:33 --> Language Class Initialized
INFO - 2020-03-04 17:43:33 --> Loader Class Initialized
INFO - 2020-03-04 17:43:33 --> Helper loaded: url_helper
INFO - 2020-03-04 17:43:33 --> Helper loaded: string_helper
INFO - 2020-03-04 17:43:33 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:43:33 --> Controller Class Initialized
INFO - 2020-03-04 17:43:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 17:43:33 --> Pagination Class Initialized
INFO - 2020-03-04 17:43:33 --> Model "M_show" initialized
INFO - 2020-03-04 17:43:33 --> Helper loaded: form_helper
INFO - 2020-03-04 17:43:33 --> Form Validation Class Initialized
INFO - 2020-03-04 17:43:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 17:43:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 17:43:33 --> Final output sent to browser
DEBUG - 2020-03-04 17:43:33 --> Total execution time: 0.0547
INFO - 2020-03-04 17:43:49 --> Config Class Initialized
INFO - 2020-03-04 17:43:49 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:43:49 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:43:49 --> Utf8 Class Initialized
INFO - 2020-03-04 17:43:49 --> URI Class Initialized
INFO - 2020-03-04 17:43:49 --> Router Class Initialized
INFO - 2020-03-04 17:43:49 --> Output Class Initialized
INFO - 2020-03-04 17:43:49 --> Security Class Initialized
DEBUG - 2020-03-04 17:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:43:49 --> Input Class Initialized
INFO - 2020-03-04 17:43:49 --> Language Class Initialized
INFO - 2020-03-04 17:43:49 --> Loader Class Initialized
INFO - 2020-03-04 17:43:49 --> Helper loaded: url_helper
INFO - 2020-03-04 17:43:49 --> Helper loaded: string_helper
INFO - 2020-03-04 17:43:49 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:43:49 --> Controller Class Initialized
INFO - 2020-03-04 17:43:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 17:43:49 --> Pagination Class Initialized
INFO - 2020-03-04 17:43:49 --> Model "M_show" initialized
INFO - 2020-03-04 17:43:49 --> Helper loaded: form_helper
INFO - 2020-03-04 17:43:49 --> Form Validation Class Initialized
INFO - 2020-03-04 17:43:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 17:43:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 17:43:49 --> Final output sent to browser
DEBUG - 2020-03-04 17:43:49 --> Total execution time: 0.0140
INFO - 2020-03-04 17:43:54 --> Config Class Initialized
INFO - 2020-03-04 17:43:54 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:43:54 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:43:54 --> Utf8 Class Initialized
INFO - 2020-03-04 17:43:54 --> URI Class Initialized
INFO - 2020-03-04 17:43:54 --> Router Class Initialized
INFO - 2020-03-04 17:43:54 --> Output Class Initialized
INFO - 2020-03-04 17:43:54 --> Security Class Initialized
DEBUG - 2020-03-04 17:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:43:55 --> Input Class Initialized
INFO - 2020-03-04 17:43:55 --> Language Class Initialized
INFO - 2020-03-04 17:43:55 --> Loader Class Initialized
INFO - 2020-03-04 17:43:55 --> Helper loaded: url_helper
INFO - 2020-03-04 17:43:55 --> Helper loaded: string_helper
INFO - 2020-03-04 17:43:55 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:43:55 --> Controller Class Initialized
INFO - 2020-03-04 17:43:55 --> Model "M_tiket" initialized
INFO - 2020-03-04 17:43:55 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 17:43:55 --> Model "M_pesan" initialized
INFO - 2020-03-04 17:43:55 --> Helper loaded: form_helper
INFO - 2020-03-04 17:43:55 --> Form Validation Class Initialized
INFO - 2020-03-04 17:43:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 17:43:55 --> Final output sent to browser
DEBUG - 2020-03-04 17:43:55 --> Total execution time: 0.0140
INFO - 2020-03-04 17:44:05 --> Config Class Initialized
INFO - 2020-03-04 17:44:05 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:44:05 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:44:05 --> Utf8 Class Initialized
INFO - 2020-03-04 17:44:05 --> URI Class Initialized
INFO - 2020-03-04 17:44:05 --> Router Class Initialized
INFO - 2020-03-04 17:44:05 --> Output Class Initialized
INFO - 2020-03-04 17:44:05 --> Security Class Initialized
DEBUG - 2020-03-04 17:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:44:05 --> Input Class Initialized
INFO - 2020-03-04 17:44:05 --> Language Class Initialized
INFO - 2020-03-04 17:44:05 --> Loader Class Initialized
INFO - 2020-03-04 17:44:05 --> Helper loaded: url_helper
INFO - 2020-03-04 17:44:05 --> Helper loaded: string_helper
INFO - 2020-03-04 17:44:05 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:44:05 --> Controller Class Initialized
INFO - 2020-03-04 17:44:05 --> Model "M_tiket" initialized
INFO - 2020-03-04 17:44:05 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 17:44:05 --> Model "M_pesan" initialized
INFO - 2020-03-04 17:44:05 --> Helper loaded: form_helper
INFO - 2020-03-04 17:44:05 --> Form Validation Class Initialized
INFO - 2020-03-04 17:44:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-04 17:44:05 --> Final output sent to browser
DEBUG - 2020-03-04 17:44:05 --> Total execution time: 0.0077
INFO - 2020-03-04 17:44:48 --> Config Class Initialized
INFO - 2020-03-04 17:44:48 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:44:48 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:44:48 --> Utf8 Class Initialized
INFO - 2020-03-04 17:44:48 --> URI Class Initialized
DEBUG - 2020-03-04 17:44:48 --> No URI present. Default controller set.
INFO - 2020-03-04 17:44:48 --> Router Class Initialized
INFO - 2020-03-04 17:44:48 --> Output Class Initialized
INFO - 2020-03-04 17:44:48 --> Security Class Initialized
DEBUG - 2020-03-04 17:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:44:48 --> Input Class Initialized
INFO - 2020-03-04 17:44:48 --> Language Class Initialized
INFO - 2020-03-04 17:44:48 --> Loader Class Initialized
INFO - 2020-03-04 17:44:48 --> Helper loaded: url_helper
INFO - 2020-03-04 17:44:48 --> Helper loaded: string_helper
INFO - 2020-03-04 17:44:48 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:44:48 --> Controller Class Initialized
INFO - 2020-03-04 17:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 17:44:48 --> Pagination Class Initialized
INFO - 2020-03-04 17:44:48 --> Model "M_show" initialized
INFO - 2020-03-04 17:44:48 --> Helper loaded: form_helper
INFO - 2020-03-04 17:44:48 --> Form Validation Class Initialized
INFO - 2020-03-04 17:44:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 17:44:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 17:44:48 --> Final output sent to browser
DEBUG - 2020-03-04 17:44:48 --> Total execution time: 0.0065
INFO - 2020-03-04 17:46:15 --> Config Class Initialized
INFO - 2020-03-04 17:46:15 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:46:15 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:46:15 --> Utf8 Class Initialized
INFO - 2020-03-04 17:46:15 --> URI Class Initialized
INFO - 2020-03-04 17:46:15 --> Router Class Initialized
INFO - 2020-03-04 17:46:15 --> Output Class Initialized
INFO - 2020-03-04 17:46:15 --> Security Class Initialized
DEBUG - 2020-03-04 17:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:46:15 --> Input Class Initialized
INFO - 2020-03-04 17:46:15 --> Language Class Initialized
INFO - 2020-03-04 17:46:15 --> Loader Class Initialized
INFO - 2020-03-04 17:46:15 --> Helper loaded: url_helper
INFO - 2020-03-04 17:46:15 --> Helper loaded: string_helper
INFO - 2020-03-04 17:46:15 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:46:15 --> Controller Class Initialized
INFO - 2020-03-04 17:46:15 --> Model "M_tiket" initialized
INFO - 2020-03-04 17:46:15 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 17:46:15 --> Model "M_pesan" initialized
INFO - 2020-03-04 17:46:15 --> Helper loaded: form_helper
INFO - 2020-03-04 17:46:15 --> Form Validation Class Initialized
DEBUG - 2020-03-04 17:46:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-04 17:46:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-04 17:46:20 --> Config Class Initialized
INFO - 2020-03-04 17:46:20 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:46:20 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:46:20 --> Utf8 Class Initialized
INFO - 2020-03-04 17:46:20 --> URI Class Initialized
INFO - 2020-03-04 17:46:20 --> Router Class Initialized
INFO - 2020-03-04 17:46:20 --> Output Class Initialized
INFO - 2020-03-04 17:46:20 --> Security Class Initialized
DEBUG - 2020-03-04 17:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:46:20 --> Input Class Initialized
INFO - 2020-03-04 17:46:20 --> Language Class Initialized
INFO - 2020-03-04 17:46:20 --> Loader Class Initialized
INFO - 2020-03-04 17:46:20 --> Helper loaded: url_helper
INFO - 2020-03-04 17:46:20 --> Helper loaded: string_helper
INFO - 2020-03-04 17:46:20 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:46:20 --> Controller Class Initialized
INFO - 2020-03-04 17:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 17:46:20 --> Pagination Class Initialized
INFO - 2020-03-04 17:46:20 --> Model "M_show" initialized
INFO - 2020-03-04 17:46:20 --> Helper loaded: form_helper
INFO - 2020-03-04 17:46:20 --> Form Validation Class Initialized
INFO - 2020-03-04 17:46:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 17:46:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 17:46:20 --> Final output sent to browser
DEBUG - 2020-03-04 17:46:20 --> Total execution time: 0.0090
INFO - 2020-03-04 17:56:38 --> Config Class Initialized
INFO - 2020-03-04 17:56:38 --> Hooks Class Initialized
DEBUG - 2020-03-04 17:56:38 --> UTF-8 Support Enabled
INFO - 2020-03-04 17:56:38 --> Utf8 Class Initialized
INFO - 2020-03-04 17:56:38 --> URI Class Initialized
DEBUG - 2020-03-04 17:56:38 --> No URI present. Default controller set.
INFO - 2020-03-04 17:56:38 --> Router Class Initialized
INFO - 2020-03-04 17:56:38 --> Output Class Initialized
INFO - 2020-03-04 17:56:38 --> Security Class Initialized
DEBUG - 2020-03-04 17:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 17:56:38 --> Input Class Initialized
INFO - 2020-03-04 17:56:38 --> Language Class Initialized
INFO - 2020-03-04 17:56:38 --> Loader Class Initialized
INFO - 2020-03-04 17:56:38 --> Helper loaded: url_helper
INFO - 2020-03-04 17:56:38 --> Helper loaded: string_helper
INFO - 2020-03-04 17:56:38 --> Database Driver Class Initialized
DEBUG - 2020-03-04 17:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 17:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 17:56:38 --> Controller Class Initialized
INFO - 2020-03-04 17:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 17:56:38 --> Pagination Class Initialized
INFO - 2020-03-04 17:56:38 --> Model "M_show" initialized
INFO - 2020-03-04 17:56:38 --> Helper loaded: form_helper
INFO - 2020-03-04 17:56:38 --> Form Validation Class Initialized
INFO - 2020-03-04 17:56:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 17:56:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 17:56:38 --> Final output sent to browser
DEBUG - 2020-03-04 17:56:38 --> Total execution time: 0.0304
INFO - 2020-03-04 18:02:26 --> Config Class Initialized
INFO - 2020-03-04 18:02:26 --> Hooks Class Initialized
DEBUG - 2020-03-04 18:02:26 --> UTF-8 Support Enabled
INFO - 2020-03-04 18:02:26 --> Utf8 Class Initialized
INFO - 2020-03-04 18:02:26 --> URI Class Initialized
INFO - 2020-03-04 18:02:26 --> Router Class Initialized
INFO - 2020-03-04 18:02:26 --> Output Class Initialized
INFO - 2020-03-04 18:02:26 --> Security Class Initialized
DEBUG - 2020-03-04 18:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 18:02:26 --> Input Class Initialized
INFO - 2020-03-04 18:02:26 --> Language Class Initialized
INFO - 2020-03-04 18:02:26 --> Loader Class Initialized
INFO - 2020-03-04 18:02:26 --> Helper loaded: url_helper
INFO - 2020-03-04 18:02:26 --> Helper loaded: string_helper
INFO - 2020-03-04 18:02:26 --> Database Driver Class Initialized
DEBUG - 2020-03-04 18:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 18:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 18:02:26 --> Controller Class Initialized
INFO - 2020-03-04 18:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 18:02:26 --> Pagination Class Initialized
INFO - 2020-03-04 18:02:26 --> Model "M_show" initialized
INFO - 2020-03-04 18:02:26 --> Helper loaded: form_helper
INFO - 2020-03-04 18:02:26 --> Form Validation Class Initialized
INFO - 2020-03-04 18:02:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 18:02:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 18:02:26 --> Final output sent to browser
DEBUG - 2020-03-04 18:02:26 --> Total execution time: 0.0331
INFO - 2020-03-04 18:02:28 --> Config Class Initialized
INFO - 2020-03-04 18:02:28 --> Hooks Class Initialized
DEBUG - 2020-03-04 18:02:28 --> UTF-8 Support Enabled
INFO - 2020-03-04 18:02:28 --> Utf8 Class Initialized
INFO - 2020-03-04 18:02:28 --> URI Class Initialized
INFO - 2020-03-04 18:02:28 --> Router Class Initialized
INFO - 2020-03-04 18:02:28 --> Output Class Initialized
INFO - 2020-03-04 18:02:28 --> Security Class Initialized
DEBUG - 2020-03-04 18:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 18:02:28 --> Input Class Initialized
INFO - 2020-03-04 18:02:28 --> Language Class Initialized
INFO - 2020-03-04 18:02:28 --> Loader Class Initialized
INFO - 2020-03-04 18:02:28 --> Helper loaded: url_helper
INFO - 2020-03-04 18:02:28 --> Helper loaded: string_helper
INFO - 2020-03-04 18:02:28 --> Database Driver Class Initialized
DEBUG - 2020-03-04 18:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 18:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 18:02:28 --> Controller Class Initialized
INFO - 2020-03-04 18:02:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 18:02:28 --> Pagination Class Initialized
INFO - 2020-03-04 18:02:28 --> Model "M_show" initialized
INFO - 2020-03-04 18:02:28 --> Helper loaded: form_helper
INFO - 2020-03-04 18:02:28 --> Form Validation Class Initialized
INFO - 2020-03-04 18:02:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 18:02:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 18:02:28 --> Final output sent to browser
DEBUG - 2020-03-04 18:02:28 --> Total execution time: 0.0063
INFO - 2020-03-04 18:06:12 --> Config Class Initialized
INFO - 2020-03-04 18:06:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 18:06:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 18:06:12 --> Utf8 Class Initialized
INFO - 2020-03-04 18:06:12 --> URI Class Initialized
INFO - 2020-03-04 18:06:12 --> Router Class Initialized
INFO - 2020-03-04 18:06:12 --> Output Class Initialized
INFO - 2020-03-04 18:06:12 --> Security Class Initialized
DEBUG - 2020-03-04 18:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 18:06:12 --> Input Class Initialized
INFO - 2020-03-04 18:06:12 --> Language Class Initialized
INFO - 2020-03-04 18:06:12 --> Loader Class Initialized
INFO - 2020-03-04 18:06:12 --> Helper loaded: url_helper
INFO - 2020-03-04 18:06:12 --> Helper loaded: string_helper
INFO - 2020-03-04 18:06:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 18:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 18:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 18:06:12 --> Controller Class Initialized
INFO - 2020-03-04 18:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 18:06:12 --> Pagination Class Initialized
INFO - 2020-03-04 18:06:12 --> Model "M_show" initialized
INFO - 2020-03-04 18:06:12 --> Helper loaded: form_helper
INFO - 2020-03-04 18:06:12 --> Form Validation Class Initialized
INFO - 2020-03-04 18:06:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 18:06:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 18:06:12 --> Final output sent to browser
DEBUG - 2020-03-04 18:06:12 --> Total execution time: 0.0315
INFO - 2020-03-04 18:46:57 --> Config Class Initialized
INFO - 2020-03-04 18:46:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 18:46:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 18:46:57 --> Utf8 Class Initialized
INFO - 2020-03-04 18:46:57 --> URI Class Initialized
INFO - 2020-03-04 18:46:57 --> Router Class Initialized
INFO - 2020-03-04 18:46:57 --> Output Class Initialized
INFO - 2020-03-04 18:46:57 --> Security Class Initialized
DEBUG - 2020-03-04 18:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 18:46:57 --> Input Class Initialized
INFO - 2020-03-04 18:46:57 --> Language Class Initialized
INFO - 2020-03-04 18:46:57 --> Loader Class Initialized
INFO - 2020-03-04 18:46:57 --> Helper loaded: url_helper
INFO - 2020-03-04 18:46:57 --> Helper loaded: string_helper
INFO - 2020-03-04 18:46:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 18:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 18:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 18:46:57 --> Controller Class Initialized
INFO - 2020-03-04 18:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 18:46:57 --> Pagination Class Initialized
INFO - 2020-03-04 18:46:57 --> Model "M_show" initialized
INFO - 2020-03-04 18:46:57 --> Helper loaded: form_helper
INFO - 2020-03-04 18:46:57 --> Form Validation Class Initialized
INFO - 2020-03-04 18:46:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 18:46:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 18:46:57 --> Final output sent to browser
DEBUG - 2020-03-04 18:46:57 --> Total execution time: 0.0318
INFO - 2020-03-04 18:47:00 --> Config Class Initialized
INFO - 2020-03-04 18:47:00 --> Hooks Class Initialized
DEBUG - 2020-03-04 18:47:00 --> UTF-8 Support Enabled
INFO - 2020-03-04 18:47:00 --> Utf8 Class Initialized
INFO - 2020-03-04 18:47:00 --> URI Class Initialized
INFO - 2020-03-04 18:47:00 --> Router Class Initialized
INFO - 2020-03-04 18:47:00 --> Output Class Initialized
INFO - 2020-03-04 18:47:00 --> Security Class Initialized
DEBUG - 2020-03-04 18:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 18:47:00 --> Input Class Initialized
INFO - 2020-03-04 18:47:00 --> Language Class Initialized
ERROR - 2020-03-04 18:47:00 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 18:47:50 --> Config Class Initialized
INFO - 2020-03-04 18:47:50 --> Hooks Class Initialized
DEBUG - 2020-03-04 18:47:50 --> UTF-8 Support Enabled
INFO - 2020-03-04 18:47:50 --> Utf8 Class Initialized
INFO - 2020-03-04 18:47:50 --> URI Class Initialized
INFO - 2020-03-04 18:47:50 --> Router Class Initialized
INFO - 2020-03-04 18:47:50 --> Output Class Initialized
INFO - 2020-03-04 18:47:50 --> Security Class Initialized
DEBUG - 2020-03-04 18:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 18:47:50 --> Input Class Initialized
INFO - 2020-03-04 18:47:50 --> Language Class Initialized
INFO - 2020-03-04 18:47:50 --> Loader Class Initialized
INFO - 2020-03-04 18:47:50 --> Helper loaded: url_helper
INFO - 2020-03-04 18:47:50 --> Helper loaded: string_helper
INFO - 2020-03-04 18:47:50 --> Database Driver Class Initialized
DEBUG - 2020-03-04 18:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 18:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 18:47:50 --> Controller Class Initialized
INFO - 2020-03-04 18:47:50 --> Model "M_tiket" initialized
INFO - 2020-03-04 18:47:50 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 18:47:50 --> Model "M_pesan" initialized
INFO - 2020-03-04 18:47:50 --> Helper loaded: form_helper
INFO - 2020-03-04 18:47:50 --> Form Validation Class Initialized
INFO - 2020-03-04 18:47:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 18:47:50 --> Final output sent to browser
DEBUG - 2020-03-04 18:47:50 --> Total execution time: 0.0668
INFO - 2020-03-04 18:47:51 --> Config Class Initialized
INFO - 2020-03-04 18:47:51 --> Hooks Class Initialized
DEBUG - 2020-03-04 18:47:51 --> UTF-8 Support Enabled
INFO - 2020-03-04 18:47:51 --> Utf8 Class Initialized
INFO - 2020-03-04 18:47:51 --> URI Class Initialized
INFO - 2020-03-04 18:47:51 --> Router Class Initialized
INFO - 2020-03-04 18:47:51 --> Output Class Initialized
INFO - 2020-03-04 18:47:51 --> Security Class Initialized
DEBUG - 2020-03-04 18:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 18:47:51 --> Input Class Initialized
INFO - 2020-03-04 18:47:51 --> Language Class Initialized
INFO - 2020-03-04 18:47:51 --> Loader Class Initialized
INFO - 2020-03-04 18:47:51 --> Helper loaded: url_helper
INFO - 2020-03-04 18:47:51 --> Helper loaded: string_helper
INFO - 2020-03-04 18:47:51 --> Database Driver Class Initialized
DEBUG - 2020-03-04 18:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 18:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 18:47:51 --> Controller Class Initialized
INFO - 2020-03-04 18:47:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 18:47:51 --> Pagination Class Initialized
INFO - 2020-03-04 18:47:51 --> Model "M_show" initialized
INFO - 2020-03-04 18:47:51 --> Helper loaded: form_helper
INFO - 2020-03-04 18:47:51 --> Form Validation Class Initialized
INFO - 2020-03-04 18:47:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 18:47:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 18:47:51 --> Final output sent to browser
DEBUG - 2020-03-04 18:47:51 --> Total execution time: 0.0064
INFO - 2020-03-04 18:51:14 --> Config Class Initialized
INFO - 2020-03-04 18:51:14 --> Hooks Class Initialized
DEBUG - 2020-03-04 18:51:14 --> UTF-8 Support Enabled
INFO - 2020-03-04 18:51:14 --> Utf8 Class Initialized
INFO - 2020-03-04 18:51:14 --> URI Class Initialized
INFO - 2020-03-04 18:51:14 --> Router Class Initialized
INFO - 2020-03-04 18:51:14 --> Output Class Initialized
INFO - 2020-03-04 18:51:14 --> Security Class Initialized
DEBUG - 2020-03-04 18:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 18:51:14 --> Input Class Initialized
INFO - 2020-03-04 18:51:14 --> Language Class Initialized
INFO - 2020-03-04 18:51:14 --> Loader Class Initialized
INFO - 2020-03-04 18:51:14 --> Helper loaded: url_helper
INFO - 2020-03-04 18:51:14 --> Helper loaded: string_helper
INFO - 2020-03-04 18:51:14 --> Database Driver Class Initialized
DEBUG - 2020-03-04 18:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 18:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 18:51:14 --> Controller Class Initialized
INFO - 2020-03-04 18:51:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 18:51:14 --> Pagination Class Initialized
INFO - 2020-03-04 18:51:14 --> Model "M_show" initialized
INFO - 2020-03-04 18:51:14 --> Helper loaded: form_helper
INFO - 2020-03-04 18:51:14 --> Form Validation Class Initialized
INFO - 2020-03-04 18:51:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 18:51:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 18:51:14 --> Final output sent to browser
DEBUG - 2020-03-04 18:51:14 --> Total execution time: 0.0330
INFO - 2020-03-04 18:57:24 --> Config Class Initialized
INFO - 2020-03-04 18:57:24 --> Hooks Class Initialized
DEBUG - 2020-03-04 18:57:24 --> UTF-8 Support Enabled
INFO - 2020-03-04 18:57:24 --> Utf8 Class Initialized
INFO - 2020-03-04 18:57:24 --> URI Class Initialized
DEBUG - 2020-03-04 18:57:24 --> No URI present. Default controller set.
INFO - 2020-03-04 18:57:24 --> Router Class Initialized
INFO - 2020-03-04 18:57:24 --> Output Class Initialized
INFO - 2020-03-04 18:57:24 --> Security Class Initialized
DEBUG - 2020-03-04 18:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 18:57:24 --> Input Class Initialized
INFO - 2020-03-04 18:57:24 --> Language Class Initialized
INFO - 2020-03-04 18:57:24 --> Loader Class Initialized
INFO - 2020-03-04 18:57:24 --> Helper loaded: url_helper
INFO - 2020-03-04 18:57:24 --> Helper loaded: string_helper
INFO - 2020-03-04 18:57:24 --> Database Driver Class Initialized
DEBUG - 2020-03-04 18:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 18:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 18:57:24 --> Controller Class Initialized
INFO - 2020-03-04 18:57:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 18:57:24 --> Pagination Class Initialized
INFO - 2020-03-04 18:57:24 --> Model "M_show" initialized
INFO - 2020-03-04 18:57:24 --> Helper loaded: form_helper
INFO - 2020-03-04 18:57:24 --> Form Validation Class Initialized
INFO - 2020-03-04 18:57:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 18:57:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 18:57:24 --> Final output sent to browser
DEBUG - 2020-03-04 18:57:24 --> Total execution time: 0.0488
INFO - 2020-03-04 19:11:12 --> Config Class Initialized
INFO - 2020-03-04 19:11:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 19:11:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 19:11:12 --> Utf8 Class Initialized
INFO - 2020-03-04 19:11:12 --> URI Class Initialized
DEBUG - 2020-03-04 19:11:12 --> No URI present. Default controller set.
INFO - 2020-03-04 19:11:12 --> Router Class Initialized
INFO - 2020-03-04 19:11:12 --> Output Class Initialized
INFO - 2020-03-04 19:11:12 --> Security Class Initialized
DEBUG - 2020-03-04 19:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 19:11:12 --> Input Class Initialized
INFO - 2020-03-04 19:11:12 --> Language Class Initialized
INFO - 2020-03-04 19:11:12 --> Loader Class Initialized
INFO - 2020-03-04 19:11:12 --> Helper loaded: url_helper
INFO - 2020-03-04 19:11:12 --> Helper loaded: string_helper
INFO - 2020-03-04 19:11:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 19:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 19:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 19:11:12 --> Controller Class Initialized
INFO - 2020-03-04 19:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 19:11:12 --> Pagination Class Initialized
INFO - 2020-03-04 19:11:12 --> Model "M_show" initialized
INFO - 2020-03-04 19:11:12 --> Helper loaded: form_helper
INFO - 2020-03-04 19:11:12 --> Form Validation Class Initialized
INFO - 2020-03-04 19:11:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 19:11:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 19:11:12 --> Final output sent to browser
DEBUG - 2020-03-04 19:11:12 --> Total execution time: 0.0460
INFO - 2020-03-04 19:47:48 --> Config Class Initialized
INFO - 2020-03-04 19:47:48 --> Hooks Class Initialized
DEBUG - 2020-03-04 19:47:48 --> UTF-8 Support Enabled
INFO - 2020-03-04 19:47:48 --> Utf8 Class Initialized
INFO - 2020-03-04 19:47:48 --> URI Class Initialized
DEBUG - 2020-03-04 19:47:48 --> No URI present. Default controller set.
INFO - 2020-03-04 19:47:48 --> Router Class Initialized
INFO - 2020-03-04 19:47:48 --> Output Class Initialized
INFO - 2020-03-04 19:47:48 --> Security Class Initialized
DEBUG - 2020-03-04 19:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 19:47:48 --> Input Class Initialized
INFO - 2020-03-04 19:47:48 --> Language Class Initialized
INFO - 2020-03-04 19:47:48 --> Loader Class Initialized
INFO - 2020-03-04 19:47:48 --> Helper loaded: url_helper
INFO - 2020-03-04 19:47:48 --> Helper loaded: string_helper
INFO - 2020-03-04 19:47:48 --> Database Driver Class Initialized
DEBUG - 2020-03-04 19:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 19:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 19:47:48 --> Controller Class Initialized
INFO - 2020-03-04 19:47:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 19:47:48 --> Pagination Class Initialized
INFO - 2020-03-04 19:47:48 --> Model "M_show" initialized
INFO - 2020-03-04 19:47:48 --> Helper loaded: form_helper
INFO - 2020-03-04 19:47:48 --> Form Validation Class Initialized
INFO - 2020-03-04 19:47:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 19:47:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 19:47:48 --> Final output sent to browser
DEBUG - 2020-03-04 19:47:48 --> Total execution time: 0.0313
INFO - 2020-03-04 20:55:54 --> Config Class Initialized
INFO - 2020-03-04 20:55:54 --> Hooks Class Initialized
DEBUG - 2020-03-04 20:55:54 --> UTF-8 Support Enabled
INFO - 2020-03-04 20:55:54 --> Utf8 Class Initialized
INFO - 2020-03-04 20:55:54 --> URI Class Initialized
INFO - 2020-03-04 20:55:54 --> Router Class Initialized
INFO - 2020-03-04 20:55:54 --> Output Class Initialized
INFO - 2020-03-04 20:55:54 --> Security Class Initialized
DEBUG - 2020-03-04 20:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 20:55:54 --> Input Class Initialized
INFO - 2020-03-04 20:55:54 --> Language Class Initialized
INFO - 2020-03-04 20:55:54 --> Loader Class Initialized
INFO - 2020-03-04 20:55:54 --> Helper loaded: url_helper
INFO - 2020-03-04 20:55:54 --> Helper loaded: string_helper
INFO - 2020-03-04 20:55:54 --> Database Driver Class Initialized
DEBUG - 2020-03-04 20:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 20:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 20:55:54 --> Controller Class Initialized
INFO - 2020-03-04 20:55:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 20:55:54 --> Pagination Class Initialized
INFO - 2020-03-04 20:55:54 --> Model "M_show" initialized
INFO - 2020-03-04 20:55:54 --> Helper loaded: form_helper
INFO - 2020-03-04 20:55:54 --> Form Validation Class Initialized
INFO - 2020-03-04 20:55:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 20:55:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-04 20:55:54 --> Final output sent to browser
DEBUG - 2020-03-04 20:55:54 --> Total execution time: 0.0493
INFO - 2020-03-04 21:03:12 --> Config Class Initialized
INFO - 2020-03-04 21:03:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:03:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:03:12 --> Utf8 Class Initialized
INFO - 2020-03-04 21:03:12 --> URI Class Initialized
INFO - 2020-03-04 21:03:12 --> Router Class Initialized
INFO - 2020-03-04 21:03:12 --> Output Class Initialized
INFO - 2020-03-04 21:03:12 --> Security Class Initialized
DEBUG - 2020-03-04 21:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:03:12 --> Input Class Initialized
INFO - 2020-03-04 21:03:12 --> Language Class Initialized
INFO - 2020-03-04 21:03:12 --> Loader Class Initialized
INFO - 2020-03-04 21:03:13 --> Helper loaded: url_helper
INFO - 2020-03-04 21:03:13 --> Helper loaded: string_helper
INFO - 2020-03-04 21:03:13 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:03:13 --> Controller Class Initialized
INFO - 2020-03-04 21:03:13 --> Model "M_tiket" initialized
INFO - 2020-03-04 21:03:13 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 21:03:13 --> Model "M_pesan" initialized
INFO - 2020-03-04 21:03:13 --> Helper loaded: form_helper
INFO - 2020-03-04 21:03:13 --> Form Validation Class Initialized
INFO - 2020-03-04 21:03:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 21:03:13 --> Final output sent to browser
DEBUG - 2020-03-04 21:03:13 --> Total execution time: 0.0605
INFO - 2020-03-04 21:04:04 --> Config Class Initialized
INFO - 2020-03-04 21:04:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:04:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:04:04 --> Utf8 Class Initialized
INFO - 2020-03-04 21:04:04 --> URI Class Initialized
INFO - 2020-03-04 21:04:04 --> Router Class Initialized
INFO - 2020-03-04 21:04:04 --> Output Class Initialized
INFO - 2020-03-04 21:04:04 --> Security Class Initialized
DEBUG - 2020-03-04 21:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:04:04 --> Input Class Initialized
INFO - 2020-03-04 21:04:04 --> Language Class Initialized
INFO - 2020-03-04 21:04:04 --> Loader Class Initialized
INFO - 2020-03-04 21:04:04 --> Helper loaded: url_helper
INFO - 2020-03-04 21:04:04 --> Helper loaded: string_helper
INFO - 2020-03-04 21:04:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:04:04 --> Controller Class Initialized
INFO - 2020-03-04 21:04:04 --> Model "M_tiket" initialized
INFO - 2020-03-04 21:04:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 21:04:04 --> Model "M_pesan" initialized
INFO - 2020-03-04 21:04:04 --> Helper loaded: form_helper
INFO - 2020-03-04 21:04:04 --> Form Validation Class Initialized
INFO - 2020-03-04 21:04:06 --> Config Class Initialized
INFO - 2020-03-04 21:04:06 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:04:06 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:04:06 --> Utf8 Class Initialized
INFO - 2020-03-04 21:04:06 --> URI Class Initialized
INFO - 2020-03-04 21:04:06 --> Router Class Initialized
INFO - 2020-03-04 21:04:06 --> Output Class Initialized
INFO - 2020-03-04 21:04:06 --> Security Class Initialized
DEBUG - 2020-03-04 21:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:04:06 --> Input Class Initialized
INFO - 2020-03-04 21:04:06 --> Language Class Initialized
INFO - 2020-03-04 21:04:06 --> Loader Class Initialized
INFO - 2020-03-04 21:04:06 --> Helper loaded: url_helper
INFO - 2020-03-04 21:04:06 --> Helper loaded: string_helper
INFO - 2020-03-04 21:04:06 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:04:06 --> Controller Class Initialized
INFO - 2020-03-04 21:04:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:04:06 --> Pagination Class Initialized
INFO - 2020-03-04 21:04:06 --> Model "M_show" initialized
INFO - 2020-03-04 21:04:06 --> Helper loaded: form_helper
INFO - 2020-03-04 21:04:06 --> Form Validation Class Initialized
INFO - 2020-03-04 21:04:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:04:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 21:04:06 --> Final output sent to browser
DEBUG - 2020-03-04 21:04:06 --> Total execution time: 0.0077
INFO - 2020-03-04 21:04:17 --> Config Class Initialized
INFO - 2020-03-04 21:04:17 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:04:17 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:04:17 --> Utf8 Class Initialized
INFO - 2020-03-04 21:04:17 --> URI Class Initialized
INFO - 2020-03-04 21:04:17 --> Router Class Initialized
INFO - 2020-03-04 21:04:17 --> Output Class Initialized
INFO - 2020-03-04 21:04:17 --> Security Class Initialized
DEBUG - 2020-03-04 21:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:04:17 --> Input Class Initialized
INFO - 2020-03-04 21:04:17 --> Language Class Initialized
INFO - 2020-03-04 21:04:17 --> Loader Class Initialized
INFO - 2020-03-04 21:04:17 --> Helper loaded: url_helper
INFO - 2020-03-04 21:04:17 --> Helper loaded: string_helper
INFO - 2020-03-04 21:04:17 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:04:17 --> Controller Class Initialized
INFO - 2020-03-04 21:04:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:04:17 --> Pagination Class Initialized
INFO - 2020-03-04 21:04:17 --> Model "M_show" initialized
INFO - 2020-03-04 21:04:17 --> Helper loaded: form_helper
INFO - 2020-03-04 21:04:17 --> Form Validation Class Initialized
INFO - 2020-03-04 21:04:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:04:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-04 21:04:17 --> Final output sent to browser
DEBUG - 2020-03-04 21:04:17 --> Total execution time: 0.0142
INFO - 2020-03-04 21:17:58 --> Config Class Initialized
INFO - 2020-03-04 21:17:58 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:17:58 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:17:58 --> Utf8 Class Initialized
INFO - 2020-03-04 21:17:58 --> URI Class Initialized
INFO - 2020-03-04 21:17:58 --> Router Class Initialized
INFO - 2020-03-04 21:17:58 --> Output Class Initialized
INFO - 2020-03-04 21:17:58 --> Security Class Initialized
DEBUG - 2020-03-04 21:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:17:58 --> Input Class Initialized
INFO - 2020-03-04 21:17:58 --> Language Class Initialized
INFO - 2020-03-04 21:17:58 --> Loader Class Initialized
INFO - 2020-03-04 21:17:58 --> Helper loaded: url_helper
INFO - 2020-03-04 21:17:58 --> Helper loaded: string_helper
INFO - 2020-03-04 21:17:58 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:17:58 --> Controller Class Initialized
INFO - 2020-03-04 21:17:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:17:58 --> Pagination Class Initialized
INFO - 2020-03-04 21:17:58 --> Model "M_show" initialized
INFO - 2020-03-04 21:17:58 --> Helper loaded: form_helper
INFO - 2020-03-04 21:17:58 --> Form Validation Class Initialized
INFO - 2020-03-04 21:17:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:17:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 21:17:58 --> Final output sent to browser
DEBUG - 2020-03-04 21:17:58 --> Total execution time: 0.0310
INFO - 2020-03-04 21:18:02 --> Config Class Initialized
INFO - 2020-03-04 21:18:02 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:18:02 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:18:02 --> Utf8 Class Initialized
INFO - 2020-03-04 21:18:02 --> URI Class Initialized
INFO - 2020-03-04 21:18:02 --> Router Class Initialized
INFO - 2020-03-04 21:18:02 --> Output Class Initialized
INFO - 2020-03-04 21:18:02 --> Security Class Initialized
DEBUG - 2020-03-04 21:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:18:02 --> Input Class Initialized
INFO - 2020-03-04 21:18:02 --> Language Class Initialized
INFO - 2020-03-04 21:18:02 --> Loader Class Initialized
INFO - 2020-03-04 21:18:02 --> Helper loaded: url_helper
INFO - 2020-03-04 21:18:02 --> Helper loaded: string_helper
INFO - 2020-03-04 21:18:02 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:18:02 --> Controller Class Initialized
INFO - 2020-03-04 21:18:02 --> Model "M_tiket" initialized
INFO - 2020-03-04 21:18:02 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 21:18:02 --> Model "M_pesan" initialized
INFO - 2020-03-04 21:18:02 --> Helper loaded: form_helper
INFO - 2020-03-04 21:18:02 --> Form Validation Class Initialized
INFO - 2020-03-04 21:18:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 21:18:02 --> Final output sent to browser
DEBUG - 2020-03-04 21:18:02 --> Total execution time: 0.0126
INFO - 2020-03-04 21:27:16 --> Config Class Initialized
INFO - 2020-03-04 21:27:16 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:27:16 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:27:16 --> Utf8 Class Initialized
INFO - 2020-03-04 21:27:16 --> URI Class Initialized
DEBUG - 2020-03-04 21:27:16 --> No URI present. Default controller set.
INFO - 2020-03-04 21:27:16 --> Router Class Initialized
INFO - 2020-03-04 21:27:16 --> Output Class Initialized
INFO - 2020-03-04 21:27:16 --> Security Class Initialized
DEBUG - 2020-03-04 21:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:27:16 --> Input Class Initialized
INFO - 2020-03-04 21:27:16 --> Language Class Initialized
INFO - 2020-03-04 21:27:16 --> Loader Class Initialized
INFO - 2020-03-04 21:27:16 --> Helper loaded: url_helper
INFO - 2020-03-04 21:27:16 --> Helper loaded: string_helper
INFO - 2020-03-04 21:27:16 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:27:16 --> Controller Class Initialized
INFO - 2020-03-04 21:27:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:27:16 --> Pagination Class Initialized
INFO - 2020-03-04 21:27:16 --> Model "M_show" initialized
INFO - 2020-03-04 21:27:16 --> Helper loaded: form_helper
INFO - 2020-03-04 21:27:16 --> Form Validation Class Initialized
INFO - 2020-03-04 21:27:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:27:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 21:27:16 --> Final output sent to browser
DEBUG - 2020-03-04 21:27:16 --> Total execution time: 0.0317
INFO - 2020-03-04 21:44:59 --> Config Class Initialized
INFO - 2020-03-04 21:44:59 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:44:59 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:44:59 --> Utf8 Class Initialized
INFO - 2020-03-04 21:44:59 --> URI Class Initialized
INFO - 2020-03-04 21:44:59 --> Router Class Initialized
INFO - 2020-03-04 21:44:59 --> Output Class Initialized
INFO - 2020-03-04 21:44:59 --> Security Class Initialized
DEBUG - 2020-03-04 21:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:44:59 --> Input Class Initialized
INFO - 2020-03-04 21:44:59 --> Language Class Initialized
INFO - 2020-03-04 21:44:59 --> Loader Class Initialized
INFO - 2020-03-04 21:44:59 --> Helper loaded: url_helper
INFO - 2020-03-04 21:44:59 --> Helper loaded: string_helper
INFO - 2020-03-04 21:44:59 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:44:59 --> Controller Class Initialized
INFO - 2020-03-04 21:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:44:59 --> Pagination Class Initialized
INFO - 2020-03-04 21:44:59 --> Model "M_show" initialized
INFO - 2020-03-04 21:44:59 --> Helper loaded: form_helper
INFO - 2020-03-04 21:44:59 --> Form Validation Class Initialized
INFO - 2020-03-04 21:44:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:44:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 21:44:59 --> Final output sent to browser
DEBUG - 2020-03-04 21:44:59 --> Total execution time: 0.0385
INFO - 2020-03-04 21:45:09 --> Config Class Initialized
INFO - 2020-03-04 21:45:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:45:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:45:09 --> Utf8 Class Initialized
INFO - 2020-03-04 21:45:09 --> URI Class Initialized
INFO - 2020-03-04 21:45:09 --> Router Class Initialized
INFO - 2020-03-04 21:45:09 --> Output Class Initialized
INFO - 2020-03-04 21:45:09 --> Security Class Initialized
DEBUG - 2020-03-04 21:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:45:09 --> Input Class Initialized
INFO - 2020-03-04 21:45:09 --> Language Class Initialized
INFO - 2020-03-04 21:45:09 --> Loader Class Initialized
INFO - 2020-03-04 21:45:09 --> Helper loaded: url_helper
INFO - 2020-03-04 21:45:09 --> Helper loaded: string_helper
INFO - 2020-03-04 21:45:09 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:45:09 --> Controller Class Initialized
INFO - 2020-03-04 21:45:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:45:09 --> Pagination Class Initialized
INFO - 2020-03-04 21:45:09 --> Model "M_show" initialized
INFO - 2020-03-04 21:45:09 --> Helper loaded: form_helper
INFO - 2020-03-04 21:45:09 --> Form Validation Class Initialized
INFO - 2020-03-04 21:45:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:45:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 21:45:09 --> Final output sent to browser
DEBUG - 2020-03-04 21:45:09 --> Total execution time: 0.0074
INFO - 2020-03-04 21:45:19 --> Config Class Initialized
INFO - 2020-03-04 21:45:19 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:45:19 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:45:19 --> Utf8 Class Initialized
INFO - 2020-03-04 21:45:19 --> URI Class Initialized
INFO - 2020-03-04 21:45:19 --> Router Class Initialized
INFO - 2020-03-04 21:45:19 --> Output Class Initialized
INFO - 2020-03-04 21:45:19 --> Security Class Initialized
DEBUG - 2020-03-04 21:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:45:19 --> Input Class Initialized
INFO - 2020-03-04 21:45:19 --> Language Class Initialized
INFO - 2020-03-04 21:45:19 --> Loader Class Initialized
INFO - 2020-03-04 21:45:19 --> Helper loaded: url_helper
INFO - 2020-03-04 21:45:19 --> Helper loaded: string_helper
INFO - 2020-03-04 21:45:19 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:45:19 --> Controller Class Initialized
INFO - 2020-03-04 21:45:19 --> Model "M_tiket" initialized
INFO - 2020-03-04 21:45:19 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 21:45:19 --> Model "M_pesan" initialized
INFO - 2020-03-04 21:45:19 --> Helper loaded: form_helper
INFO - 2020-03-04 21:45:19 --> Form Validation Class Initialized
INFO - 2020-03-04 21:45:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 21:45:19 --> Final output sent to browser
DEBUG - 2020-03-04 21:45:19 --> Total execution time: 0.0099
INFO - 2020-03-04 21:57:00 --> Config Class Initialized
INFO - 2020-03-04 21:57:00 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:57:00 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:57:00 --> Utf8 Class Initialized
INFO - 2020-03-04 21:57:00 --> URI Class Initialized
INFO - 2020-03-04 21:57:00 --> Router Class Initialized
INFO - 2020-03-04 21:57:00 --> Output Class Initialized
INFO - 2020-03-04 21:57:00 --> Security Class Initialized
DEBUG - 2020-03-04 21:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:57:00 --> Input Class Initialized
INFO - 2020-03-04 21:57:00 --> Language Class Initialized
INFO - 2020-03-04 21:57:00 --> Loader Class Initialized
INFO - 2020-03-04 21:57:00 --> Helper loaded: url_helper
INFO - 2020-03-04 21:57:00 --> Helper loaded: string_helper
INFO - 2020-03-04 21:57:00 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:57:00 --> Controller Class Initialized
INFO - 2020-03-04 21:57:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:57:00 --> Pagination Class Initialized
INFO - 2020-03-04 21:57:00 --> Model "M_show" initialized
INFO - 2020-03-04 21:57:00 --> Helper loaded: form_helper
INFO - 2020-03-04 21:57:00 --> Form Validation Class Initialized
INFO - 2020-03-04 21:57:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:57:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 21:57:00 --> Final output sent to browser
DEBUG - 2020-03-04 21:57:00 --> Total execution time: 0.0327
INFO - 2020-03-04 21:57:09 --> Config Class Initialized
INFO - 2020-03-04 21:57:09 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:57:09 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:57:09 --> Utf8 Class Initialized
INFO - 2020-03-04 21:57:09 --> URI Class Initialized
INFO - 2020-03-04 21:57:09 --> Router Class Initialized
INFO - 2020-03-04 21:57:09 --> Output Class Initialized
INFO - 2020-03-04 21:57:09 --> Security Class Initialized
DEBUG - 2020-03-04 21:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:57:09 --> Input Class Initialized
INFO - 2020-03-04 21:57:09 --> Language Class Initialized
INFO - 2020-03-04 21:57:09 --> Loader Class Initialized
INFO - 2020-03-04 21:57:09 --> Helper loaded: url_helper
INFO - 2020-03-04 21:57:09 --> Helper loaded: string_helper
INFO - 2020-03-04 21:57:09 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:57:09 --> Controller Class Initialized
INFO - 2020-03-04 21:57:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:57:09 --> Pagination Class Initialized
INFO - 2020-03-04 21:57:09 --> Model "M_show" initialized
INFO - 2020-03-04 21:57:09 --> Helper loaded: form_helper
INFO - 2020-03-04 21:57:09 --> Form Validation Class Initialized
INFO - 2020-03-04 21:57:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:57:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 21:57:09 --> Final output sent to browser
DEBUG - 2020-03-04 21:57:09 --> Total execution time: 0.0119
INFO - 2020-03-04 21:57:12 --> Config Class Initialized
INFO - 2020-03-04 21:57:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:57:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:57:12 --> Utf8 Class Initialized
INFO - 2020-03-04 21:57:12 --> URI Class Initialized
INFO - 2020-03-04 21:57:12 --> Router Class Initialized
INFO - 2020-03-04 21:57:12 --> Output Class Initialized
INFO - 2020-03-04 21:57:12 --> Security Class Initialized
DEBUG - 2020-03-04 21:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:57:12 --> Input Class Initialized
INFO - 2020-03-04 21:57:12 --> Language Class Initialized
INFO - 2020-03-04 21:57:12 --> Loader Class Initialized
INFO - 2020-03-04 21:57:12 --> Helper loaded: url_helper
INFO - 2020-03-04 21:57:12 --> Helper loaded: string_helper
INFO - 2020-03-04 21:57:12 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:57:12 --> Controller Class Initialized
INFO - 2020-03-04 21:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:57:12 --> Pagination Class Initialized
INFO - 2020-03-04 21:57:12 --> Model "M_show" initialized
INFO - 2020-03-04 21:57:12 --> Helper loaded: form_helper
INFO - 2020-03-04 21:57:12 --> Form Validation Class Initialized
INFO - 2020-03-04 21:57:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:57:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 21:57:12 --> Final output sent to browser
DEBUG - 2020-03-04 21:57:12 --> Total execution time: 0.0193
INFO - 2020-03-04 21:57:12 --> Config Class Initialized
INFO - 2020-03-04 21:57:12 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:57:12 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:57:12 --> Utf8 Class Initialized
INFO - 2020-03-04 21:57:12 --> URI Class Initialized
INFO - 2020-03-04 21:57:12 --> Router Class Initialized
INFO - 2020-03-04 21:57:12 --> Output Class Initialized
INFO - 2020-03-04 21:57:12 --> Security Class Initialized
DEBUG - 2020-03-04 21:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:57:12 --> Input Class Initialized
INFO - 2020-03-04 21:57:12 --> Language Class Initialized
ERROR - 2020-03-04 21:57:12 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-04 21:57:45 --> Config Class Initialized
INFO - 2020-03-04 21:57:45 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:57:45 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:57:45 --> Utf8 Class Initialized
INFO - 2020-03-04 21:57:45 --> URI Class Initialized
INFO - 2020-03-04 21:57:45 --> Router Class Initialized
INFO - 2020-03-04 21:57:45 --> Output Class Initialized
INFO - 2020-03-04 21:57:45 --> Security Class Initialized
DEBUG - 2020-03-04 21:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:57:45 --> Input Class Initialized
INFO - 2020-03-04 21:57:45 --> Language Class Initialized
INFO - 2020-03-04 21:57:45 --> Loader Class Initialized
INFO - 2020-03-04 21:57:45 --> Helper loaded: url_helper
INFO - 2020-03-04 21:57:45 --> Helper loaded: string_helper
INFO - 2020-03-04 21:57:45 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:57:45 --> Controller Class Initialized
INFO - 2020-03-04 21:57:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:57:45 --> Pagination Class Initialized
INFO - 2020-03-04 21:57:45 --> Model "M_show" initialized
INFO - 2020-03-04 21:57:45 --> Helper loaded: form_helper
INFO - 2020-03-04 21:57:45 --> Form Validation Class Initialized
INFO - 2020-03-04 21:57:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:57:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 21:57:45 --> Final output sent to browser
DEBUG - 2020-03-04 21:57:45 --> Total execution time: 0.0069
INFO - 2020-03-04 21:57:45 --> Config Class Initialized
INFO - 2020-03-04 21:57:45 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:57:45 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:57:45 --> Utf8 Class Initialized
INFO - 2020-03-04 21:57:45 --> URI Class Initialized
INFO - 2020-03-04 21:57:45 --> Router Class Initialized
INFO - 2020-03-04 21:57:45 --> Output Class Initialized
INFO - 2020-03-04 21:57:45 --> Security Class Initialized
DEBUG - 2020-03-04 21:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:57:45 --> Input Class Initialized
INFO - 2020-03-04 21:57:45 --> Language Class Initialized
INFO - 2020-03-04 21:57:45 --> Loader Class Initialized
INFO - 2020-03-04 21:57:45 --> Helper loaded: url_helper
INFO - 2020-03-04 21:57:45 --> Helper loaded: string_helper
INFO - 2020-03-04 21:57:45 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:57:45 --> Controller Class Initialized
INFO - 2020-03-04 21:57:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:57:45 --> Pagination Class Initialized
INFO - 2020-03-04 21:57:45 --> Model "M_show" initialized
INFO - 2020-03-04 21:57:45 --> Helper loaded: form_helper
INFO - 2020-03-04 21:57:45 --> Form Validation Class Initialized
INFO - 2020-03-04 21:57:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:57:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 21:57:45 --> Final output sent to browser
DEBUG - 2020-03-04 21:57:45 --> Total execution time: 0.0039
INFO - 2020-03-04 21:58:29 --> Config Class Initialized
INFO - 2020-03-04 21:58:29 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:58:29 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:58:29 --> Utf8 Class Initialized
INFO - 2020-03-04 21:58:29 --> URI Class Initialized
INFO - 2020-03-04 21:58:29 --> Router Class Initialized
INFO - 2020-03-04 21:58:29 --> Output Class Initialized
INFO - 2020-03-04 21:58:29 --> Security Class Initialized
DEBUG - 2020-03-04 21:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:58:29 --> Input Class Initialized
INFO - 2020-03-04 21:58:29 --> Language Class Initialized
INFO - 2020-03-04 21:58:29 --> Loader Class Initialized
INFO - 2020-03-04 21:58:29 --> Helper loaded: url_helper
INFO - 2020-03-04 21:58:29 --> Helper loaded: string_helper
INFO - 2020-03-04 21:58:29 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:58:29 --> Controller Class Initialized
INFO - 2020-03-04 21:58:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:58:29 --> Pagination Class Initialized
INFO - 2020-03-04 21:58:29 --> Model "M_show" initialized
INFO - 2020-03-04 21:58:29 --> Helper loaded: form_helper
INFO - 2020-03-04 21:58:29 --> Form Validation Class Initialized
INFO - 2020-03-04 21:58:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:58:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-04 21:58:29 --> Final output sent to browser
DEBUG - 2020-03-04 21:58:29 --> Total execution time: 0.0054
INFO - 2020-03-04 21:58:29 --> Config Class Initialized
INFO - 2020-03-04 21:58:29 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:58:29 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:58:29 --> Utf8 Class Initialized
INFO - 2020-03-04 21:58:29 --> URI Class Initialized
INFO - 2020-03-04 21:58:29 --> Router Class Initialized
INFO - 2020-03-04 21:58:29 --> Output Class Initialized
INFO - 2020-03-04 21:58:29 --> Security Class Initialized
DEBUG - 2020-03-04 21:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:58:29 --> Input Class Initialized
INFO - 2020-03-04 21:58:29 --> Language Class Initialized
INFO - 2020-03-04 21:58:29 --> Loader Class Initialized
INFO - 2020-03-04 21:58:29 --> Helper loaded: url_helper
INFO - 2020-03-04 21:58:29 --> Helper loaded: string_helper
INFO - 2020-03-04 21:58:29 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:58:29 --> Controller Class Initialized
INFO - 2020-03-04 21:58:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:58:29 --> Pagination Class Initialized
INFO - 2020-03-04 21:58:29 --> Model "M_show" initialized
INFO - 2020-03-04 21:58:29 --> Helper loaded: form_helper
INFO - 2020-03-04 21:58:29 --> Form Validation Class Initialized
INFO - 2020-03-04 21:58:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:58:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-04 21:58:29 --> Final output sent to browser
DEBUG - 2020-03-04 21:58:29 --> Total execution time: 0.0054
INFO - 2020-03-04 21:59:04 --> Config Class Initialized
INFO - 2020-03-04 21:59:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:59:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:59:04 --> Utf8 Class Initialized
INFO - 2020-03-04 21:59:04 --> URI Class Initialized
INFO - 2020-03-04 21:59:04 --> Router Class Initialized
INFO - 2020-03-04 21:59:04 --> Output Class Initialized
INFO - 2020-03-04 21:59:04 --> Security Class Initialized
DEBUG - 2020-03-04 21:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:59:04 --> Input Class Initialized
INFO - 2020-03-04 21:59:04 --> Language Class Initialized
INFO - 2020-03-04 21:59:04 --> Loader Class Initialized
INFO - 2020-03-04 21:59:04 --> Helper loaded: url_helper
INFO - 2020-03-04 21:59:04 --> Helper loaded: string_helper
INFO - 2020-03-04 21:59:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:59:04 --> Controller Class Initialized
INFO - 2020-03-04 21:59:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:59:04 --> Pagination Class Initialized
INFO - 2020-03-04 21:59:04 --> Model "M_show" initialized
INFO - 2020-03-04 21:59:04 --> Helper loaded: form_helper
INFO - 2020-03-04 21:59:04 --> Form Validation Class Initialized
INFO - 2020-03-04 21:59:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:59:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 21:59:04 --> Final output sent to browser
DEBUG - 2020-03-04 21:59:04 --> Total execution time: 0.0062
INFO - 2020-03-04 21:59:04 --> Config Class Initialized
INFO - 2020-03-04 21:59:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:59:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:59:04 --> Utf8 Class Initialized
INFO - 2020-03-04 21:59:04 --> URI Class Initialized
INFO - 2020-03-04 21:59:04 --> Router Class Initialized
INFO - 2020-03-04 21:59:04 --> Output Class Initialized
INFO - 2020-03-04 21:59:04 --> Security Class Initialized
DEBUG - 2020-03-04 21:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:59:04 --> Input Class Initialized
INFO - 2020-03-04 21:59:04 --> Language Class Initialized
INFO - 2020-03-04 21:59:04 --> Loader Class Initialized
INFO - 2020-03-04 21:59:04 --> Helper loaded: url_helper
INFO - 2020-03-04 21:59:04 --> Helper loaded: string_helper
INFO - 2020-03-04 21:59:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:59:04 --> Controller Class Initialized
INFO - 2020-03-04 21:59:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:59:04 --> Pagination Class Initialized
INFO - 2020-03-04 21:59:04 --> Model "M_show" initialized
INFO - 2020-03-04 21:59:04 --> Helper loaded: form_helper
INFO - 2020-03-04 21:59:04 --> Form Validation Class Initialized
INFO - 2020-03-04 21:59:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:59:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 21:59:04 --> Final output sent to browser
DEBUG - 2020-03-04 21:59:04 --> Total execution time: 0.0048
INFO - 2020-03-04 21:59:04 --> Config Class Initialized
INFO - 2020-03-04 21:59:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 21:59:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 21:59:04 --> Utf8 Class Initialized
INFO - 2020-03-04 21:59:04 --> URI Class Initialized
INFO - 2020-03-04 21:59:04 --> Router Class Initialized
INFO - 2020-03-04 21:59:04 --> Output Class Initialized
INFO - 2020-03-04 21:59:04 --> Security Class Initialized
DEBUG - 2020-03-04 21:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 21:59:04 --> Input Class Initialized
INFO - 2020-03-04 21:59:04 --> Language Class Initialized
INFO - 2020-03-04 21:59:04 --> Loader Class Initialized
INFO - 2020-03-04 21:59:04 --> Helper loaded: url_helper
INFO - 2020-03-04 21:59:04 --> Helper loaded: string_helper
INFO - 2020-03-04 21:59:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 21:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 21:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 21:59:04 --> Controller Class Initialized
INFO - 2020-03-04 21:59:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 21:59:04 --> Pagination Class Initialized
INFO - 2020-03-04 21:59:04 --> Model "M_show" initialized
INFO - 2020-03-04 21:59:04 --> Helper loaded: form_helper
INFO - 2020-03-04 21:59:04 --> Form Validation Class Initialized
INFO - 2020-03-04 21:59:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 21:59:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 21:59:04 --> Final output sent to browser
DEBUG - 2020-03-04 21:59:04 --> Total execution time: 0.0048
INFO - 2020-03-04 22:06:57 --> Config Class Initialized
INFO - 2020-03-04 22:06:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:06:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:06:57 --> Utf8 Class Initialized
INFO - 2020-03-04 22:06:57 --> URI Class Initialized
INFO - 2020-03-04 22:06:57 --> Router Class Initialized
INFO - 2020-03-04 22:06:57 --> Output Class Initialized
INFO - 2020-03-04 22:06:57 --> Security Class Initialized
DEBUG - 2020-03-04 22:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:06:57 --> Input Class Initialized
INFO - 2020-03-04 22:06:57 --> Language Class Initialized
INFO - 2020-03-04 22:06:57 --> Loader Class Initialized
INFO - 2020-03-04 22:06:57 --> Helper loaded: url_helper
INFO - 2020-03-04 22:06:57 --> Helper loaded: string_helper
INFO - 2020-03-04 22:06:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:06:57 --> Controller Class Initialized
INFO - 2020-03-04 22:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:06:57 --> Pagination Class Initialized
INFO - 2020-03-04 22:06:57 --> Model "M_show" initialized
INFO - 2020-03-04 22:06:57 --> Helper loaded: form_helper
INFO - 2020-03-04 22:06:57 --> Form Validation Class Initialized
INFO - 2020-03-04 22:06:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:06:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 22:06:57 --> Final output sent to browser
DEBUG - 2020-03-04 22:06:57 --> Total execution time: 0.0325
INFO - 2020-03-04 22:09:02 --> Config Class Initialized
INFO - 2020-03-04 22:09:02 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:09:02 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:09:02 --> Utf8 Class Initialized
INFO - 2020-03-04 22:09:02 --> URI Class Initialized
DEBUG - 2020-03-04 22:09:02 --> No URI present. Default controller set.
INFO - 2020-03-04 22:09:02 --> Router Class Initialized
INFO - 2020-03-04 22:09:02 --> Output Class Initialized
INFO - 2020-03-04 22:09:02 --> Security Class Initialized
DEBUG - 2020-03-04 22:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:09:02 --> Input Class Initialized
INFO - 2020-03-04 22:09:02 --> Language Class Initialized
INFO - 2020-03-04 22:09:02 --> Loader Class Initialized
INFO - 2020-03-04 22:09:02 --> Helper loaded: url_helper
INFO - 2020-03-04 22:09:02 --> Helper loaded: string_helper
INFO - 2020-03-04 22:09:02 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:09:02 --> Controller Class Initialized
INFO - 2020-03-04 22:09:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:09:02 --> Pagination Class Initialized
INFO - 2020-03-04 22:09:02 --> Model "M_show" initialized
INFO - 2020-03-04 22:09:02 --> Helper loaded: form_helper
INFO - 2020-03-04 22:09:02 --> Form Validation Class Initialized
INFO - 2020-03-04 22:09:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:09:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 22:09:02 --> Final output sent to browser
DEBUG - 2020-03-04 22:09:02 --> Total execution time: 0.0298
INFO - 2020-03-04 22:38:04 --> Config Class Initialized
INFO - 2020-03-04 22:38:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:38:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:38:04 --> Utf8 Class Initialized
INFO - 2020-03-04 22:38:04 --> URI Class Initialized
INFO - 2020-03-04 22:38:04 --> Router Class Initialized
INFO - 2020-03-04 22:38:04 --> Output Class Initialized
INFO - 2020-03-04 22:38:04 --> Security Class Initialized
DEBUG - 2020-03-04 22:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:38:04 --> Input Class Initialized
INFO - 2020-03-04 22:38:04 --> Language Class Initialized
INFO - 2020-03-04 22:38:04 --> Loader Class Initialized
INFO - 2020-03-04 22:38:04 --> Helper loaded: url_helper
INFO - 2020-03-04 22:38:04 --> Helper loaded: string_helper
INFO - 2020-03-04 22:38:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:38:04 --> Controller Class Initialized
INFO - 2020-03-04 22:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:38:04 --> Pagination Class Initialized
INFO - 2020-03-04 22:38:04 --> Model "M_show" initialized
INFO - 2020-03-04 22:38:04 --> Helper loaded: form_helper
INFO - 2020-03-04 22:38:04 --> Form Validation Class Initialized
INFO - 2020-03-04 22:38:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:38:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 22:38:04 --> Final output sent to browser
DEBUG - 2020-03-04 22:38:04 --> Total execution time: 0.0364
INFO - 2020-03-04 22:38:27 --> Config Class Initialized
INFO - 2020-03-04 22:38:27 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:38:27 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:38:27 --> Utf8 Class Initialized
INFO - 2020-03-04 22:38:27 --> URI Class Initialized
INFO - 2020-03-04 22:38:27 --> Router Class Initialized
INFO - 2020-03-04 22:38:27 --> Output Class Initialized
INFO - 2020-03-04 22:38:27 --> Security Class Initialized
DEBUG - 2020-03-04 22:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:38:27 --> Input Class Initialized
INFO - 2020-03-04 22:38:27 --> Language Class Initialized
INFO - 2020-03-04 22:38:27 --> Loader Class Initialized
INFO - 2020-03-04 22:38:27 --> Helper loaded: url_helper
INFO - 2020-03-04 22:38:27 --> Helper loaded: string_helper
INFO - 2020-03-04 22:38:27 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:38:27 --> Controller Class Initialized
INFO - 2020-03-04 22:38:27 --> Model "M_tiket" initialized
INFO - 2020-03-04 22:38:27 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 22:38:27 --> Model "M_pesan" initialized
INFO - 2020-03-04 22:38:27 --> Helper loaded: form_helper
INFO - 2020-03-04 22:38:27 --> Form Validation Class Initialized
INFO - 2020-03-04 22:38:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 22:38:27 --> Final output sent to browser
DEBUG - 2020-03-04 22:38:27 --> Total execution time: 0.0096
INFO - 2020-03-04 22:38:28 --> Config Class Initialized
INFO - 2020-03-04 22:38:28 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:38:28 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:38:28 --> Utf8 Class Initialized
INFO - 2020-03-04 22:38:28 --> URI Class Initialized
INFO - 2020-03-04 22:38:28 --> Router Class Initialized
INFO - 2020-03-04 22:38:28 --> Output Class Initialized
INFO - 2020-03-04 22:38:28 --> Security Class Initialized
DEBUG - 2020-03-04 22:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:38:28 --> Input Class Initialized
INFO - 2020-03-04 22:38:28 --> Language Class Initialized
INFO - 2020-03-04 22:38:28 --> Loader Class Initialized
INFO - 2020-03-04 22:38:28 --> Helper loaded: url_helper
INFO - 2020-03-04 22:38:28 --> Helper loaded: string_helper
INFO - 2020-03-04 22:38:28 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:38:28 --> Controller Class Initialized
INFO - 2020-03-04 22:38:28 --> Model "M_tiket" initialized
INFO - 2020-03-04 22:38:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 22:38:28 --> Model "M_pesan" initialized
INFO - 2020-03-04 22:38:28 --> Helper loaded: form_helper
INFO - 2020-03-04 22:38:28 --> Form Validation Class Initialized
INFO - 2020-03-04 22:38:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 22:38:28 --> Final output sent to browser
DEBUG - 2020-03-04 22:38:28 --> Total execution time: 0.0072
INFO - 2020-03-04 22:39:05 --> Config Class Initialized
INFO - 2020-03-04 22:39:05 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:39:05 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:39:05 --> Utf8 Class Initialized
INFO - 2020-03-04 22:39:05 --> URI Class Initialized
INFO - 2020-03-04 22:39:05 --> Router Class Initialized
INFO - 2020-03-04 22:39:05 --> Output Class Initialized
INFO - 2020-03-04 22:39:05 --> Security Class Initialized
DEBUG - 2020-03-04 22:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:39:05 --> Input Class Initialized
INFO - 2020-03-04 22:39:05 --> Language Class Initialized
INFO - 2020-03-04 22:39:05 --> Loader Class Initialized
INFO - 2020-03-04 22:39:05 --> Helper loaded: url_helper
INFO - 2020-03-04 22:39:05 --> Helper loaded: string_helper
INFO - 2020-03-04 22:39:05 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:39:05 --> Controller Class Initialized
INFO - 2020-03-04 22:39:05 --> Model "M_tiket" initialized
INFO - 2020-03-04 22:39:05 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 22:39:05 --> Model "M_pesan" initialized
INFO - 2020-03-04 22:39:05 --> Helper loaded: form_helper
INFO - 2020-03-04 22:39:05 --> Form Validation Class Initialized
INFO - 2020-03-04 22:39:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 22:39:05 --> Final output sent to browser
DEBUG - 2020-03-04 22:39:05 --> Total execution time: 0.0084
INFO - 2020-03-04 22:39:36 --> Config Class Initialized
INFO - 2020-03-04 22:39:36 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:39:36 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:39:36 --> Utf8 Class Initialized
INFO - 2020-03-04 22:39:36 --> URI Class Initialized
INFO - 2020-03-04 22:39:36 --> Router Class Initialized
INFO - 2020-03-04 22:39:36 --> Output Class Initialized
INFO - 2020-03-04 22:39:36 --> Security Class Initialized
DEBUG - 2020-03-04 22:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:39:36 --> Input Class Initialized
INFO - 2020-03-04 22:39:36 --> Language Class Initialized
INFO - 2020-03-04 22:39:36 --> Loader Class Initialized
INFO - 2020-03-04 22:39:36 --> Helper loaded: url_helper
INFO - 2020-03-04 22:39:36 --> Helper loaded: string_helper
INFO - 2020-03-04 22:39:36 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:39:36 --> Controller Class Initialized
INFO - 2020-03-04 22:39:36 --> Model "M_tiket" initialized
INFO - 2020-03-04 22:39:36 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 22:39:36 --> Model "M_pesan" initialized
INFO - 2020-03-04 22:39:36 --> Helper loaded: form_helper
INFO - 2020-03-04 22:39:36 --> Form Validation Class Initialized
INFO - 2020-03-04 22:39:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 22:39:36 --> Final output sent to browser
DEBUG - 2020-03-04 22:39:36 --> Total execution time: 0.0074
INFO - 2020-03-04 22:39:51 --> Config Class Initialized
INFO - 2020-03-04 22:39:51 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:39:51 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:39:51 --> Utf8 Class Initialized
INFO - 2020-03-04 22:39:51 --> URI Class Initialized
INFO - 2020-03-04 22:39:51 --> Router Class Initialized
INFO - 2020-03-04 22:39:51 --> Output Class Initialized
INFO - 2020-03-04 22:39:51 --> Security Class Initialized
DEBUG - 2020-03-04 22:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:39:51 --> Input Class Initialized
INFO - 2020-03-04 22:39:51 --> Language Class Initialized
INFO - 2020-03-04 22:39:51 --> Loader Class Initialized
INFO - 2020-03-04 22:39:51 --> Helper loaded: url_helper
INFO - 2020-03-04 22:39:51 --> Helper loaded: string_helper
INFO - 2020-03-04 22:39:51 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:39:51 --> Controller Class Initialized
INFO - 2020-03-04 22:39:51 --> Model "M_tiket" initialized
INFO - 2020-03-04 22:39:51 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 22:39:51 --> Model "M_pesan" initialized
INFO - 2020-03-04 22:39:51 --> Helper loaded: form_helper
INFO - 2020-03-04 22:39:51 --> Form Validation Class Initialized
INFO - 2020-03-04 22:39:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 22:39:51 --> Final output sent to browser
DEBUG - 2020-03-04 22:39:51 --> Total execution time: 0.0070
INFO - 2020-03-04 22:40:18 --> Config Class Initialized
INFO - 2020-03-04 22:40:18 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:40:18 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:40:18 --> Utf8 Class Initialized
INFO - 2020-03-04 22:40:18 --> URI Class Initialized
INFO - 2020-03-04 22:40:18 --> Router Class Initialized
INFO - 2020-03-04 22:40:18 --> Output Class Initialized
INFO - 2020-03-04 22:40:18 --> Security Class Initialized
DEBUG - 2020-03-04 22:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:40:18 --> Input Class Initialized
INFO - 2020-03-04 22:40:18 --> Language Class Initialized
INFO - 2020-03-04 22:40:18 --> Loader Class Initialized
INFO - 2020-03-04 22:40:18 --> Helper loaded: url_helper
INFO - 2020-03-04 22:40:18 --> Helper loaded: string_helper
INFO - 2020-03-04 22:40:18 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:40:18 --> Controller Class Initialized
INFO - 2020-03-04 22:40:18 --> Model "M_tiket" initialized
INFO - 2020-03-04 22:40:18 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 22:40:18 --> Model "M_pesan" initialized
INFO - 2020-03-04 22:40:18 --> Helper loaded: form_helper
INFO - 2020-03-04 22:40:18 --> Form Validation Class Initialized
INFO - 2020-03-04 22:40:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 22:40:18 --> Final output sent to browser
DEBUG - 2020-03-04 22:40:18 --> Total execution time: 0.0071
INFO - 2020-03-04 22:41:19 --> Config Class Initialized
INFO - 2020-03-04 22:41:19 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:41:19 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:41:19 --> Utf8 Class Initialized
INFO - 2020-03-04 22:41:19 --> URI Class Initialized
INFO - 2020-03-04 22:41:19 --> Router Class Initialized
INFO - 2020-03-04 22:41:19 --> Output Class Initialized
INFO - 2020-03-04 22:41:19 --> Security Class Initialized
DEBUG - 2020-03-04 22:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:41:19 --> Input Class Initialized
INFO - 2020-03-04 22:41:19 --> Language Class Initialized
INFO - 2020-03-04 22:41:19 --> Loader Class Initialized
INFO - 2020-03-04 22:41:19 --> Helper loaded: url_helper
INFO - 2020-03-04 22:41:19 --> Helper loaded: string_helper
INFO - 2020-03-04 22:41:19 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:41:19 --> Controller Class Initialized
INFO - 2020-03-04 22:41:19 --> Model "M_tiket" initialized
INFO - 2020-03-04 22:41:19 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 22:41:19 --> Model "M_pesan" initialized
INFO - 2020-03-04 22:41:19 --> Helper loaded: form_helper
INFO - 2020-03-04 22:41:19 --> Form Validation Class Initialized
INFO - 2020-03-04 22:41:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 22:41:19 --> Final output sent to browser
DEBUG - 2020-03-04 22:41:19 --> Total execution time: 0.0201
INFO - 2020-03-04 22:44:25 --> Config Class Initialized
INFO - 2020-03-04 22:44:25 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:44:25 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:44:25 --> Utf8 Class Initialized
INFO - 2020-03-04 22:44:25 --> URI Class Initialized
INFO - 2020-03-04 22:44:25 --> Router Class Initialized
INFO - 2020-03-04 22:44:25 --> Output Class Initialized
INFO - 2020-03-04 22:44:25 --> Security Class Initialized
DEBUG - 2020-03-04 22:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:44:25 --> Input Class Initialized
INFO - 2020-03-04 22:44:25 --> Language Class Initialized
INFO - 2020-03-04 22:44:25 --> Loader Class Initialized
INFO - 2020-03-04 22:44:25 --> Helper loaded: url_helper
INFO - 2020-03-04 22:44:25 --> Helper loaded: string_helper
INFO - 2020-03-04 22:44:25 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:44:25 --> Controller Class Initialized
INFO - 2020-03-04 22:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:44:25 --> Pagination Class Initialized
INFO - 2020-03-04 22:44:25 --> Model "M_show" initialized
INFO - 2020-03-04 22:44:25 --> Helper loaded: form_helper
INFO - 2020-03-04 22:44:25 --> Form Validation Class Initialized
INFO - 2020-03-04 22:44:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:44:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 22:44:25 --> Final output sent to browser
DEBUG - 2020-03-04 22:44:25 --> Total execution time: 0.0484
INFO - 2020-03-04 22:44:48 --> Config Class Initialized
INFO - 2020-03-04 22:44:48 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:44:48 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:44:48 --> Utf8 Class Initialized
INFO - 2020-03-04 22:44:48 --> URI Class Initialized
INFO - 2020-03-04 22:44:48 --> Router Class Initialized
INFO - 2020-03-04 22:44:48 --> Output Class Initialized
INFO - 2020-03-04 22:44:48 --> Security Class Initialized
DEBUG - 2020-03-04 22:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:44:48 --> Input Class Initialized
INFO - 2020-03-04 22:44:48 --> Language Class Initialized
INFO - 2020-03-04 22:44:48 --> Loader Class Initialized
INFO - 2020-03-04 22:44:48 --> Helper loaded: url_helper
INFO - 2020-03-04 22:44:48 --> Helper loaded: string_helper
INFO - 2020-03-04 22:44:48 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:44:48 --> Controller Class Initialized
INFO - 2020-03-04 22:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:44:48 --> Pagination Class Initialized
INFO - 2020-03-04 22:44:48 --> Model "M_show" initialized
INFO - 2020-03-04 22:44:48 --> Helper loaded: form_helper
INFO - 2020-03-04 22:44:48 --> Form Validation Class Initialized
INFO - 2020-03-04 22:44:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:44:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-04 22:44:48 --> Final output sent to browser
DEBUG - 2020-03-04 22:44:48 --> Total execution time: 0.0054
INFO - 2020-03-04 22:45:04 --> Config Class Initialized
INFO - 2020-03-04 22:45:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:45:04 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:45:04 --> Utf8 Class Initialized
INFO - 2020-03-04 22:45:04 --> URI Class Initialized
INFO - 2020-03-04 22:45:04 --> Router Class Initialized
INFO - 2020-03-04 22:45:04 --> Output Class Initialized
INFO - 2020-03-04 22:45:04 --> Security Class Initialized
DEBUG - 2020-03-04 22:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:45:04 --> Input Class Initialized
INFO - 2020-03-04 22:45:04 --> Language Class Initialized
INFO - 2020-03-04 22:45:04 --> Loader Class Initialized
INFO - 2020-03-04 22:45:04 --> Helper loaded: url_helper
INFO - 2020-03-04 22:45:04 --> Helper loaded: string_helper
INFO - 2020-03-04 22:45:04 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:45:04 --> Controller Class Initialized
INFO - 2020-03-04 22:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:45:04 --> Pagination Class Initialized
INFO - 2020-03-04 22:45:04 --> Model "M_show" initialized
INFO - 2020-03-04 22:45:04 --> Helper loaded: form_helper
INFO - 2020-03-04 22:45:04 --> Form Validation Class Initialized
INFO - 2020-03-04 22:45:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:45:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 22:45:04 --> Final output sent to browser
DEBUG - 2020-03-04 22:45:04 --> Total execution time: 0.0064
INFO - 2020-03-04 22:47:21 --> Config Class Initialized
INFO - 2020-03-04 22:47:21 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:47:21 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:47:21 --> Utf8 Class Initialized
INFO - 2020-03-04 22:47:21 --> URI Class Initialized
INFO - 2020-03-04 22:47:21 --> Router Class Initialized
INFO - 2020-03-04 22:47:21 --> Output Class Initialized
INFO - 2020-03-04 22:47:21 --> Security Class Initialized
DEBUG - 2020-03-04 22:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:47:21 --> Input Class Initialized
INFO - 2020-03-04 22:47:21 --> Language Class Initialized
INFO - 2020-03-04 22:47:21 --> Loader Class Initialized
INFO - 2020-03-04 22:47:21 --> Helper loaded: url_helper
INFO - 2020-03-04 22:47:21 --> Helper loaded: string_helper
INFO - 2020-03-04 22:47:21 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:47:21 --> Controller Class Initialized
INFO - 2020-03-04 22:47:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:47:21 --> Pagination Class Initialized
INFO - 2020-03-04 22:47:21 --> Model "M_show" initialized
INFO - 2020-03-04 22:47:21 --> Helper loaded: form_helper
INFO - 2020-03-04 22:47:21 --> Form Validation Class Initialized
INFO - 2020-03-04 22:47:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:47:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 22:47:21 --> Final output sent to browser
DEBUG - 2020-03-04 22:47:21 --> Total execution time: 0.0490
INFO - 2020-03-04 22:47:22 --> Config Class Initialized
INFO - 2020-03-04 22:47:22 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:47:22 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:47:22 --> Utf8 Class Initialized
INFO - 2020-03-04 22:47:22 --> URI Class Initialized
INFO - 2020-03-04 22:47:22 --> Router Class Initialized
INFO - 2020-03-04 22:47:22 --> Output Class Initialized
INFO - 2020-03-04 22:47:22 --> Security Class Initialized
DEBUG - 2020-03-04 22:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:47:22 --> Input Class Initialized
INFO - 2020-03-04 22:47:22 --> Language Class Initialized
INFO - 2020-03-04 22:47:22 --> Loader Class Initialized
INFO - 2020-03-04 22:47:22 --> Helper loaded: url_helper
INFO - 2020-03-04 22:47:22 --> Helper loaded: string_helper
INFO - 2020-03-04 22:47:22 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:47:22 --> Controller Class Initialized
INFO - 2020-03-04 22:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:47:22 --> Pagination Class Initialized
INFO - 2020-03-04 22:47:22 --> Model "M_show" initialized
INFO - 2020-03-04 22:47:22 --> Helper loaded: form_helper
INFO - 2020-03-04 22:47:22 --> Form Validation Class Initialized
INFO - 2020-03-04 22:47:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:47:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 22:47:22 --> Final output sent to browser
DEBUG - 2020-03-04 22:47:22 --> Total execution time: 0.0080
INFO - 2020-03-04 22:48:07 --> Config Class Initialized
INFO - 2020-03-04 22:48:07 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:48:07 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:48:07 --> Utf8 Class Initialized
INFO - 2020-03-04 22:48:07 --> URI Class Initialized
DEBUG - 2020-03-04 22:48:07 --> No URI present. Default controller set.
INFO - 2020-03-04 22:48:07 --> Router Class Initialized
INFO - 2020-03-04 22:48:07 --> Output Class Initialized
INFO - 2020-03-04 22:48:07 --> Security Class Initialized
DEBUG - 2020-03-04 22:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:48:07 --> Input Class Initialized
INFO - 2020-03-04 22:48:07 --> Language Class Initialized
INFO - 2020-03-04 22:48:07 --> Loader Class Initialized
INFO - 2020-03-04 22:48:07 --> Helper loaded: url_helper
INFO - 2020-03-04 22:48:07 --> Helper loaded: string_helper
INFO - 2020-03-04 22:48:07 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:48:07 --> Controller Class Initialized
INFO - 2020-03-04 22:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:48:07 --> Pagination Class Initialized
INFO - 2020-03-04 22:48:07 --> Model "M_show" initialized
INFO - 2020-03-04 22:48:07 --> Helper loaded: form_helper
INFO - 2020-03-04 22:48:07 --> Form Validation Class Initialized
INFO - 2020-03-04 22:48:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:48:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 22:48:07 --> Final output sent to browser
DEBUG - 2020-03-04 22:48:07 --> Total execution time: 0.0055
INFO - 2020-03-04 22:48:21 --> Config Class Initialized
INFO - 2020-03-04 22:48:21 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:48:21 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:48:21 --> Utf8 Class Initialized
INFO - 2020-03-04 22:48:21 --> URI Class Initialized
DEBUG - 2020-03-04 22:48:21 --> No URI present. Default controller set.
INFO - 2020-03-04 22:48:21 --> Router Class Initialized
INFO - 2020-03-04 22:48:21 --> Output Class Initialized
INFO - 2020-03-04 22:48:21 --> Security Class Initialized
DEBUG - 2020-03-04 22:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:48:21 --> Input Class Initialized
INFO - 2020-03-04 22:48:21 --> Language Class Initialized
INFO - 2020-03-04 22:48:21 --> Loader Class Initialized
INFO - 2020-03-04 22:48:21 --> Helper loaded: url_helper
INFO - 2020-03-04 22:48:21 --> Helper loaded: string_helper
INFO - 2020-03-04 22:48:21 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:48:21 --> Controller Class Initialized
INFO - 2020-03-04 22:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:48:21 --> Pagination Class Initialized
INFO - 2020-03-04 22:48:21 --> Model "M_show" initialized
INFO - 2020-03-04 22:48:21 --> Helper loaded: form_helper
INFO - 2020-03-04 22:48:21 --> Form Validation Class Initialized
INFO - 2020-03-04 22:48:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:48:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 22:48:21 --> Final output sent to browser
DEBUG - 2020-03-04 22:48:21 --> Total execution time: 0.0063
INFO - 2020-03-04 22:48:31 --> Config Class Initialized
INFO - 2020-03-04 22:48:31 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:48:31 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:48:31 --> Utf8 Class Initialized
INFO - 2020-03-04 22:48:31 --> URI Class Initialized
DEBUG - 2020-03-04 22:48:31 --> No URI present. Default controller set.
INFO - 2020-03-04 22:48:31 --> Router Class Initialized
INFO - 2020-03-04 22:48:31 --> Output Class Initialized
INFO - 2020-03-04 22:48:31 --> Security Class Initialized
DEBUG - 2020-03-04 22:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:48:31 --> Input Class Initialized
INFO - 2020-03-04 22:48:31 --> Language Class Initialized
INFO - 2020-03-04 22:48:31 --> Loader Class Initialized
INFO - 2020-03-04 22:48:31 --> Helper loaded: url_helper
INFO - 2020-03-04 22:48:31 --> Helper loaded: string_helper
INFO - 2020-03-04 22:48:31 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:48:31 --> Controller Class Initialized
INFO - 2020-03-04 22:48:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:48:31 --> Pagination Class Initialized
INFO - 2020-03-04 22:48:31 --> Model "M_show" initialized
INFO - 2020-03-04 22:48:31 --> Helper loaded: form_helper
INFO - 2020-03-04 22:48:31 --> Form Validation Class Initialized
INFO - 2020-03-04 22:48:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:48:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 22:48:31 --> Final output sent to browser
DEBUG - 2020-03-04 22:48:31 --> Total execution time: 0.0192
INFO - 2020-03-04 22:48:31 --> Config Class Initialized
INFO - 2020-03-04 22:48:31 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:48:31 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:48:31 --> Utf8 Class Initialized
INFO - 2020-03-04 22:48:31 --> URI Class Initialized
DEBUG - 2020-03-04 22:48:31 --> No URI present. Default controller set.
INFO - 2020-03-04 22:48:31 --> Router Class Initialized
INFO - 2020-03-04 22:48:31 --> Output Class Initialized
INFO - 2020-03-04 22:48:31 --> Security Class Initialized
DEBUG - 2020-03-04 22:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:48:31 --> Input Class Initialized
INFO - 2020-03-04 22:48:31 --> Language Class Initialized
INFO - 2020-03-04 22:48:31 --> Loader Class Initialized
INFO - 2020-03-04 22:48:31 --> Helper loaded: url_helper
INFO - 2020-03-04 22:48:31 --> Helper loaded: string_helper
INFO - 2020-03-04 22:48:31 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:48:31 --> Controller Class Initialized
INFO - 2020-03-04 22:48:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:48:31 --> Pagination Class Initialized
INFO - 2020-03-04 22:48:31 --> Model "M_show" initialized
INFO - 2020-03-04 22:48:31 --> Helper loaded: form_helper
INFO - 2020-03-04 22:48:31 --> Form Validation Class Initialized
INFO - 2020-03-04 22:48:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:48:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 22:48:31 --> Final output sent to browser
DEBUG - 2020-03-04 22:48:31 --> Total execution time: 0.0038
INFO - 2020-03-04 22:48:32 --> Config Class Initialized
INFO - 2020-03-04 22:48:32 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:48:32 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:48:32 --> Utf8 Class Initialized
INFO - 2020-03-04 22:48:32 --> URI Class Initialized
INFO - 2020-03-04 22:48:32 --> Router Class Initialized
INFO - 2020-03-04 22:48:32 --> Output Class Initialized
INFO - 2020-03-04 22:48:32 --> Security Class Initialized
DEBUG - 2020-03-04 22:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:48:32 --> Input Class Initialized
INFO - 2020-03-04 22:48:32 --> Language Class Initialized
INFO - 2020-03-04 22:48:32 --> Loader Class Initialized
INFO - 2020-03-04 22:48:32 --> Helper loaded: url_helper
INFO - 2020-03-04 22:48:32 --> Helper loaded: string_helper
INFO - 2020-03-04 22:48:32 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:48:32 --> Controller Class Initialized
INFO - 2020-03-04 22:48:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:48:32 --> Pagination Class Initialized
INFO - 2020-03-04 22:48:32 --> Model "M_show" initialized
INFO - 2020-03-04 22:48:32 --> Helper loaded: form_helper
INFO - 2020-03-04 22:48:32 --> Form Validation Class Initialized
INFO - 2020-03-04 22:48:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:48:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 22:48:32 --> Final output sent to browser
DEBUG - 2020-03-04 22:48:32 --> Total execution time: 0.0057
INFO - 2020-03-04 22:48:32 --> Config Class Initialized
INFO - 2020-03-04 22:48:32 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:48:32 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:48:32 --> Utf8 Class Initialized
INFO - 2020-03-04 22:48:32 --> URI Class Initialized
DEBUG - 2020-03-04 22:48:32 --> No URI present. Default controller set.
INFO - 2020-03-04 22:48:32 --> Router Class Initialized
INFO - 2020-03-04 22:48:32 --> Output Class Initialized
INFO - 2020-03-04 22:48:32 --> Security Class Initialized
DEBUG - 2020-03-04 22:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:48:32 --> Input Class Initialized
INFO - 2020-03-04 22:48:32 --> Language Class Initialized
INFO - 2020-03-04 22:48:32 --> Loader Class Initialized
INFO - 2020-03-04 22:48:32 --> Helper loaded: url_helper
INFO - 2020-03-04 22:48:32 --> Helper loaded: string_helper
INFO - 2020-03-04 22:48:32 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:48:32 --> Controller Class Initialized
INFO - 2020-03-04 22:48:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:48:32 --> Pagination Class Initialized
INFO - 2020-03-04 22:48:32 --> Model "M_show" initialized
INFO - 2020-03-04 22:48:32 --> Helper loaded: form_helper
INFO - 2020-03-04 22:48:32 --> Form Validation Class Initialized
INFO - 2020-03-04 22:48:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:48:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 22:48:32 --> Final output sent to browser
DEBUG - 2020-03-04 22:48:32 --> Total execution time: 0.0051
INFO - 2020-03-04 22:48:33 --> Config Class Initialized
INFO - 2020-03-04 22:48:33 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:48:33 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:48:33 --> Utf8 Class Initialized
INFO - 2020-03-04 22:48:33 --> URI Class Initialized
DEBUG - 2020-03-04 22:48:33 --> No URI present. Default controller set.
INFO - 2020-03-04 22:48:33 --> Router Class Initialized
INFO - 2020-03-04 22:48:33 --> Output Class Initialized
INFO - 2020-03-04 22:48:33 --> Security Class Initialized
DEBUG - 2020-03-04 22:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:48:33 --> Input Class Initialized
INFO - 2020-03-04 22:48:33 --> Language Class Initialized
INFO - 2020-03-04 22:48:33 --> Loader Class Initialized
INFO - 2020-03-04 22:48:33 --> Helper loaded: url_helper
INFO - 2020-03-04 22:48:33 --> Helper loaded: string_helper
INFO - 2020-03-04 22:48:33 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:48:33 --> Controller Class Initialized
INFO - 2020-03-04 22:48:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:48:33 --> Pagination Class Initialized
INFO - 2020-03-04 22:48:33 --> Model "M_show" initialized
INFO - 2020-03-04 22:48:33 --> Helper loaded: form_helper
INFO - 2020-03-04 22:48:33 --> Form Validation Class Initialized
INFO - 2020-03-04 22:48:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:48:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 22:48:33 --> Final output sent to browser
DEBUG - 2020-03-04 22:48:33 --> Total execution time: 0.0064
INFO - 2020-03-04 22:48:42 --> Config Class Initialized
INFO - 2020-03-04 22:48:42 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:48:42 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:48:42 --> Utf8 Class Initialized
INFO - 2020-03-04 22:48:42 --> URI Class Initialized
INFO - 2020-03-04 22:48:42 --> Router Class Initialized
INFO - 2020-03-04 22:48:42 --> Output Class Initialized
INFO - 2020-03-04 22:48:42 --> Security Class Initialized
DEBUG - 2020-03-04 22:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:48:42 --> Input Class Initialized
INFO - 2020-03-04 22:48:42 --> Language Class Initialized
INFO - 2020-03-04 22:48:42 --> Loader Class Initialized
INFO - 2020-03-04 22:48:42 --> Helper loaded: url_helper
INFO - 2020-03-04 22:48:42 --> Helper loaded: string_helper
INFO - 2020-03-04 22:48:42 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:48:42 --> Controller Class Initialized
INFO - 2020-03-04 22:48:42 --> Model "M_tiket" initialized
INFO - 2020-03-04 22:48:42 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 22:48:42 --> Model "M_pesan" initialized
INFO - 2020-03-04 22:48:42 --> Helper loaded: form_helper
INFO - 2020-03-04 22:48:42 --> Form Validation Class Initialized
INFO - 2020-03-04 22:48:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 22:48:42 --> Final output sent to browser
DEBUG - 2020-03-04 22:48:42 --> Total execution time: 0.0097
INFO - 2020-03-04 22:59:23 --> Config Class Initialized
INFO - 2020-03-04 22:59:23 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:59:23 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:59:23 --> Utf8 Class Initialized
INFO - 2020-03-04 22:59:23 --> URI Class Initialized
INFO - 2020-03-04 22:59:23 --> Router Class Initialized
INFO - 2020-03-04 22:59:23 --> Output Class Initialized
INFO - 2020-03-04 22:59:23 --> Security Class Initialized
DEBUG - 2020-03-04 22:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:59:23 --> Input Class Initialized
INFO - 2020-03-04 22:59:23 --> Language Class Initialized
INFO - 2020-03-04 22:59:23 --> Loader Class Initialized
INFO - 2020-03-04 22:59:23 --> Helper loaded: url_helper
INFO - 2020-03-04 22:59:23 --> Helper loaded: string_helper
INFO - 2020-03-04 22:59:23 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:59:23 --> Controller Class Initialized
INFO - 2020-03-04 22:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 22:59:23 --> Pagination Class Initialized
INFO - 2020-03-04 22:59:23 --> Model "M_show" initialized
INFO - 2020-03-04 22:59:23 --> Helper loaded: form_helper
INFO - 2020-03-04 22:59:23 --> Form Validation Class Initialized
INFO - 2020-03-04 22:59:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 22:59:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 22:59:23 --> Final output sent to browser
DEBUG - 2020-03-04 22:59:23 --> Total execution time: 0.0310
INFO - 2020-03-04 22:59:38 --> Config Class Initialized
INFO - 2020-03-04 22:59:38 --> Hooks Class Initialized
DEBUG - 2020-03-04 22:59:38 --> UTF-8 Support Enabled
INFO - 2020-03-04 22:59:38 --> Utf8 Class Initialized
INFO - 2020-03-04 22:59:38 --> URI Class Initialized
INFO - 2020-03-04 22:59:38 --> Router Class Initialized
INFO - 2020-03-04 22:59:38 --> Output Class Initialized
INFO - 2020-03-04 22:59:38 --> Security Class Initialized
DEBUG - 2020-03-04 22:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 22:59:38 --> Input Class Initialized
INFO - 2020-03-04 22:59:38 --> Language Class Initialized
INFO - 2020-03-04 22:59:38 --> Loader Class Initialized
INFO - 2020-03-04 22:59:38 --> Helper loaded: url_helper
INFO - 2020-03-04 22:59:38 --> Helper loaded: string_helper
INFO - 2020-03-04 22:59:38 --> Database Driver Class Initialized
DEBUG - 2020-03-04 22:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 22:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 22:59:38 --> Controller Class Initialized
INFO - 2020-03-04 22:59:38 --> Model "M_tiket" initialized
INFO - 2020-03-04 22:59:38 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 22:59:38 --> Model "M_pesan" initialized
INFO - 2020-03-04 22:59:38 --> Helper loaded: form_helper
INFO - 2020-03-04 22:59:38 --> Form Validation Class Initialized
INFO - 2020-03-04 22:59:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 22:59:38 --> Final output sent to browser
DEBUG - 2020-03-04 22:59:38 --> Total execution time: 0.0104
INFO - 2020-03-04 23:02:01 --> Config Class Initialized
INFO - 2020-03-04 23:02:01 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:02:01 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:02:01 --> Utf8 Class Initialized
INFO - 2020-03-04 23:02:01 --> URI Class Initialized
INFO - 2020-03-04 23:02:01 --> Router Class Initialized
INFO - 2020-03-04 23:02:01 --> Output Class Initialized
INFO - 2020-03-04 23:02:01 --> Security Class Initialized
DEBUG - 2020-03-04 23:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:02:01 --> Input Class Initialized
INFO - 2020-03-04 23:02:01 --> Language Class Initialized
INFO - 2020-03-04 23:02:01 --> Loader Class Initialized
INFO - 2020-03-04 23:02:01 --> Helper loaded: url_helper
INFO - 2020-03-04 23:02:01 --> Helper loaded: string_helper
INFO - 2020-03-04 23:02:01 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:02:01 --> Controller Class Initialized
INFO - 2020-03-04 23:02:01 --> Model "M_tiket" initialized
INFO - 2020-03-04 23:02:01 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 23:02:01 --> Model "M_pesan" initialized
INFO - 2020-03-04 23:02:01 --> Helper loaded: form_helper
INFO - 2020-03-04 23:02:01 --> Form Validation Class Initialized
INFO - 2020-03-04 23:02:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-04 23:02:01 --> Final output sent to browser
DEBUG - 2020-03-04 23:02:01 --> Total execution time: 0.0391
INFO - 2020-03-04 23:12:06 --> Config Class Initialized
INFO - 2020-03-04 23:12:06 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:12:06 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:12:06 --> Utf8 Class Initialized
INFO - 2020-03-04 23:12:06 --> URI Class Initialized
INFO - 2020-03-04 23:12:06 --> Router Class Initialized
INFO - 2020-03-04 23:12:06 --> Output Class Initialized
INFO - 2020-03-04 23:12:06 --> Security Class Initialized
DEBUG - 2020-03-04 23:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:12:06 --> Input Class Initialized
INFO - 2020-03-04 23:12:06 --> Language Class Initialized
INFO - 2020-03-04 23:12:06 --> Loader Class Initialized
INFO - 2020-03-04 23:12:06 --> Helper loaded: url_helper
INFO - 2020-03-04 23:12:06 --> Helper loaded: string_helper
INFO - 2020-03-04 23:12:06 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:12:06 --> Controller Class Initialized
INFO - 2020-03-04 23:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 23:12:06 --> Pagination Class Initialized
INFO - 2020-03-04 23:12:06 --> Model "M_show" initialized
INFO - 2020-03-04 23:12:06 --> Helper loaded: form_helper
INFO - 2020-03-04 23:12:06 --> Form Validation Class Initialized
INFO - 2020-03-04 23:12:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 23:12:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 23:12:06 --> Final output sent to browser
DEBUG - 2020-03-04 23:12:06 --> Total execution time: 0.0325
INFO - 2020-03-04 23:15:06 --> Config Class Initialized
INFO - 2020-03-04 23:15:06 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:15:06 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:15:06 --> Utf8 Class Initialized
INFO - 2020-03-04 23:15:06 --> URI Class Initialized
INFO - 2020-03-04 23:15:06 --> Router Class Initialized
INFO - 2020-03-04 23:15:06 --> Output Class Initialized
INFO - 2020-03-04 23:15:06 --> Security Class Initialized
DEBUG - 2020-03-04 23:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:15:06 --> Input Class Initialized
INFO - 2020-03-04 23:15:06 --> Language Class Initialized
INFO - 2020-03-04 23:15:06 --> Loader Class Initialized
INFO - 2020-03-04 23:15:06 --> Helper loaded: url_helper
INFO - 2020-03-04 23:15:06 --> Helper loaded: string_helper
INFO - 2020-03-04 23:15:06 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:15:06 --> Controller Class Initialized
INFO - 2020-03-04 23:15:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 23:15:06 --> Pagination Class Initialized
INFO - 2020-03-04 23:15:06 --> Model "M_show" initialized
INFO - 2020-03-04 23:15:06 --> Helper loaded: form_helper
INFO - 2020-03-04 23:15:06 --> Form Validation Class Initialized
INFO - 2020-03-04 23:15:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 23:15:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 23:15:06 --> Final output sent to browser
DEBUG - 2020-03-04 23:15:06 --> Total execution time: 0.0346
INFO - 2020-03-04 23:15:10 --> Config Class Initialized
INFO - 2020-03-04 23:15:10 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:15:10 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:15:10 --> Utf8 Class Initialized
INFO - 2020-03-04 23:15:10 --> URI Class Initialized
INFO - 2020-03-04 23:15:10 --> Router Class Initialized
INFO - 2020-03-04 23:15:10 --> Output Class Initialized
INFO - 2020-03-04 23:15:10 --> Security Class Initialized
DEBUG - 2020-03-04 23:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:15:10 --> Input Class Initialized
INFO - 2020-03-04 23:15:10 --> Language Class Initialized
INFO - 2020-03-04 23:15:10 --> Loader Class Initialized
INFO - 2020-03-04 23:15:10 --> Helper loaded: url_helper
INFO - 2020-03-04 23:15:10 --> Helper loaded: string_helper
INFO - 2020-03-04 23:15:10 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:15:10 --> Controller Class Initialized
INFO - 2020-03-04 23:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 23:15:10 --> Pagination Class Initialized
INFO - 2020-03-04 23:15:10 --> Model "M_show" initialized
INFO - 2020-03-04 23:15:10 --> Helper loaded: form_helper
INFO - 2020-03-04 23:15:10 --> Form Validation Class Initialized
INFO - 2020-03-04 23:15:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 23:15:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 23:15:10 --> Final output sent to browser
DEBUG - 2020-03-04 23:15:10 --> Total execution time: 0.0071
INFO - 2020-03-04 23:15:15 --> Config Class Initialized
INFO - 2020-03-04 23:15:15 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:15:15 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:15:15 --> Utf8 Class Initialized
INFO - 2020-03-04 23:15:15 --> URI Class Initialized
INFO - 2020-03-04 23:15:15 --> Router Class Initialized
INFO - 2020-03-04 23:15:15 --> Output Class Initialized
INFO - 2020-03-04 23:15:15 --> Security Class Initialized
DEBUG - 2020-03-04 23:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:15:15 --> Input Class Initialized
INFO - 2020-03-04 23:15:15 --> Language Class Initialized
INFO - 2020-03-04 23:15:15 --> Loader Class Initialized
INFO - 2020-03-04 23:15:15 --> Helper loaded: url_helper
INFO - 2020-03-04 23:15:15 --> Helper loaded: string_helper
INFO - 2020-03-04 23:15:15 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:15:15 --> Controller Class Initialized
INFO - 2020-03-04 23:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 23:15:15 --> Pagination Class Initialized
INFO - 2020-03-04 23:15:15 --> Model "M_show" initialized
INFO - 2020-03-04 23:15:15 --> Helper loaded: form_helper
INFO - 2020-03-04 23:15:15 --> Form Validation Class Initialized
INFO - 2020-03-04 23:15:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 23:15:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 23:15:15 --> Final output sent to browser
DEBUG - 2020-03-04 23:15:15 --> Total execution time: 0.0064
INFO - 2020-03-04 23:16:49 --> Config Class Initialized
INFO - 2020-03-04 23:16:49 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:16:49 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:16:49 --> Utf8 Class Initialized
INFO - 2020-03-04 23:16:49 --> URI Class Initialized
INFO - 2020-03-04 23:16:49 --> Router Class Initialized
INFO - 2020-03-04 23:16:49 --> Output Class Initialized
INFO - 2020-03-04 23:16:49 --> Security Class Initialized
DEBUG - 2020-03-04 23:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:16:49 --> Input Class Initialized
INFO - 2020-03-04 23:16:49 --> Language Class Initialized
INFO - 2020-03-04 23:16:49 --> Loader Class Initialized
INFO - 2020-03-04 23:16:49 --> Helper loaded: url_helper
INFO - 2020-03-04 23:16:49 --> Helper loaded: string_helper
INFO - 2020-03-04 23:16:49 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:16:49 --> Controller Class Initialized
INFO - 2020-03-04 23:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 23:16:49 --> Pagination Class Initialized
INFO - 2020-03-04 23:16:49 --> Model "M_show" initialized
INFO - 2020-03-04 23:16:49 --> Helper loaded: form_helper
INFO - 2020-03-04 23:16:49 --> Form Validation Class Initialized
INFO - 2020-03-04 23:16:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 23:16:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 23:16:49 --> Final output sent to browser
DEBUG - 2020-03-04 23:16:49 --> Total execution time: 0.0308
INFO - 2020-03-04 23:16:50 --> Config Class Initialized
INFO - 2020-03-04 23:16:50 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:16:50 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:16:50 --> Utf8 Class Initialized
INFO - 2020-03-04 23:16:50 --> URI Class Initialized
INFO - 2020-03-04 23:16:50 --> Router Class Initialized
INFO - 2020-03-04 23:16:50 --> Output Class Initialized
INFO - 2020-03-04 23:16:50 --> Security Class Initialized
DEBUG - 2020-03-04 23:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:16:50 --> Input Class Initialized
INFO - 2020-03-04 23:16:50 --> Language Class Initialized
INFO - 2020-03-04 23:16:50 --> Loader Class Initialized
INFO - 2020-03-04 23:16:50 --> Helper loaded: url_helper
INFO - 2020-03-04 23:16:50 --> Helper loaded: string_helper
INFO - 2020-03-04 23:16:50 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:16:50 --> Controller Class Initialized
INFO - 2020-03-04 23:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 23:16:50 --> Pagination Class Initialized
INFO - 2020-03-04 23:16:50 --> Model "M_show" initialized
INFO - 2020-03-04 23:16:50 --> Helper loaded: form_helper
INFO - 2020-03-04 23:16:50 --> Form Validation Class Initialized
INFO - 2020-03-04 23:16:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 23:16:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 23:16:50 --> Final output sent to browser
DEBUG - 2020-03-04 23:16:50 --> Total execution time: 0.0056
INFO - 2020-03-04 23:37:57 --> Config Class Initialized
INFO - 2020-03-04 23:37:57 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:37:57 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:37:57 --> Utf8 Class Initialized
INFO - 2020-03-04 23:37:57 --> URI Class Initialized
DEBUG - 2020-03-04 23:37:57 --> No URI present. Default controller set.
INFO - 2020-03-04 23:37:57 --> Router Class Initialized
INFO - 2020-03-04 23:37:57 --> Output Class Initialized
INFO - 2020-03-04 23:37:57 --> Security Class Initialized
DEBUG - 2020-03-04 23:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:37:57 --> Input Class Initialized
INFO - 2020-03-04 23:37:57 --> Language Class Initialized
INFO - 2020-03-04 23:37:57 --> Loader Class Initialized
INFO - 2020-03-04 23:37:57 --> Helper loaded: url_helper
INFO - 2020-03-04 23:37:57 --> Helper loaded: string_helper
INFO - 2020-03-04 23:37:57 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:37:57 --> Controller Class Initialized
INFO - 2020-03-04 23:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 23:37:57 --> Pagination Class Initialized
INFO - 2020-03-04 23:37:57 --> Model "M_show" initialized
INFO - 2020-03-04 23:37:57 --> Helper loaded: form_helper
INFO - 2020-03-04 23:37:57 --> Form Validation Class Initialized
INFO - 2020-03-04 23:37:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 23:37:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 23:37:57 --> Final output sent to browser
DEBUG - 2020-03-04 23:37:57 --> Total execution time: 0.0332
INFO - 2020-03-04 23:39:02 --> Config Class Initialized
INFO - 2020-03-04 23:39:02 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:39:02 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:39:02 --> Utf8 Class Initialized
INFO - 2020-03-04 23:39:02 --> URI Class Initialized
DEBUG - 2020-03-04 23:39:02 --> No URI present. Default controller set.
INFO - 2020-03-04 23:39:02 --> Router Class Initialized
INFO - 2020-03-04 23:39:02 --> Output Class Initialized
INFO - 2020-03-04 23:39:02 --> Security Class Initialized
DEBUG - 2020-03-04 23:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:39:02 --> Input Class Initialized
INFO - 2020-03-04 23:39:02 --> Language Class Initialized
INFO - 2020-03-04 23:39:02 --> Loader Class Initialized
INFO - 2020-03-04 23:39:02 --> Helper loaded: url_helper
INFO - 2020-03-04 23:39:02 --> Helper loaded: string_helper
INFO - 2020-03-04 23:39:02 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:39:02 --> Controller Class Initialized
INFO - 2020-03-04 23:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 23:39:02 --> Pagination Class Initialized
INFO - 2020-03-04 23:39:02 --> Model "M_show" initialized
INFO - 2020-03-04 23:39:02 --> Helper loaded: form_helper
INFO - 2020-03-04 23:39:02 --> Form Validation Class Initialized
INFO - 2020-03-04 23:39:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 23:39:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-04 23:39:02 --> Final output sent to browser
DEBUG - 2020-03-04 23:39:02 --> Total execution time: 0.0070
INFO - 2020-03-04 23:55:29 --> Config Class Initialized
INFO - 2020-03-04 23:55:29 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:55:29 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:55:29 --> Utf8 Class Initialized
INFO - 2020-03-04 23:55:29 --> URI Class Initialized
INFO - 2020-03-04 23:55:29 --> Router Class Initialized
INFO - 2020-03-04 23:55:29 --> Output Class Initialized
INFO - 2020-03-04 23:55:29 --> Security Class Initialized
DEBUG - 2020-03-04 23:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:55:29 --> Input Class Initialized
INFO - 2020-03-04 23:55:29 --> Language Class Initialized
INFO - 2020-03-04 23:55:29 --> Loader Class Initialized
INFO - 2020-03-04 23:55:29 --> Helper loaded: url_helper
INFO - 2020-03-04 23:55:29 --> Helper loaded: string_helper
INFO - 2020-03-04 23:55:29 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:55:29 --> Controller Class Initialized
INFO - 2020-03-04 23:55:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 23:55:29 --> Pagination Class Initialized
INFO - 2020-03-04 23:55:29 --> Model "M_show" initialized
INFO - 2020-03-04 23:55:29 --> Helper loaded: form_helper
INFO - 2020-03-04 23:55:29 --> Form Validation Class Initialized
INFO - 2020-03-04 23:55:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 23:55:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 23:55:29 --> Final output sent to browser
DEBUG - 2020-03-04 23:55:29 --> Total execution time: 0.0314
INFO - 2020-03-04 23:55:39 --> Config Class Initialized
INFO - 2020-03-04 23:55:39 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:55:39 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:55:39 --> Utf8 Class Initialized
INFO - 2020-03-04 23:55:39 --> URI Class Initialized
INFO - 2020-03-04 23:55:39 --> Router Class Initialized
INFO - 2020-03-04 23:55:39 --> Output Class Initialized
INFO - 2020-03-04 23:55:39 --> Security Class Initialized
DEBUG - 2020-03-04 23:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:55:39 --> Input Class Initialized
INFO - 2020-03-04 23:55:39 --> Language Class Initialized
INFO - 2020-03-04 23:55:39 --> Loader Class Initialized
INFO - 2020-03-04 23:55:39 --> Helper loaded: url_helper
INFO - 2020-03-04 23:55:39 --> Helper loaded: string_helper
INFO - 2020-03-04 23:55:39 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:55:39 --> Controller Class Initialized
INFO - 2020-03-04 23:55:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 23:55:39 --> Pagination Class Initialized
INFO - 2020-03-04 23:55:39 --> Model "M_show" initialized
INFO - 2020-03-04 23:55:39 --> Helper loaded: form_helper
INFO - 2020-03-04 23:55:39 --> Form Validation Class Initialized
INFO - 2020-03-04 23:55:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 23:55:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 23:55:39 --> Final output sent to browser
DEBUG - 2020-03-04 23:55:39 --> Total execution time: 0.0072
INFO - 2020-03-04 23:55:40 --> Config Class Initialized
INFO - 2020-03-04 23:55:40 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:55:40 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:55:40 --> Utf8 Class Initialized
INFO - 2020-03-04 23:55:40 --> URI Class Initialized
INFO - 2020-03-04 23:55:40 --> Router Class Initialized
INFO - 2020-03-04 23:55:40 --> Output Class Initialized
INFO - 2020-03-04 23:55:40 --> Security Class Initialized
DEBUG - 2020-03-04 23:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:55:40 --> Input Class Initialized
INFO - 2020-03-04 23:55:40 --> Language Class Initialized
INFO - 2020-03-04 23:55:40 --> Loader Class Initialized
INFO - 2020-03-04 23:55:40 --> Helper loaded: url_helper
INFO - 2020-03-04 23:55:40 --> Helper loaded: string_helper
INFO - 2020-03-04 23:55:40 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:55:40 --> Controller Class Initialized
INFO - 2020-03-04 23:55:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 23:55:40 --> Pagination Class Initialized
INFO - 2020-03-04 23:55:40 --> Model "M_show" initialized
INFO - 2020-03-04 23:55:40 --> Helper loaded: form_helper
INFO - 2020-03-04 23:55:40 --> Form Validation Class Initialized
INFO - 2020-03-04 23:55:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 23:55:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 23:55:40 --> Final output sent to browser
DEBUG - 2020-03-04 23:55:40 --> Total execution time: 0.0062
INFO - 2020-03-04 23:58:41 --> Config Class Initialized
INFO - 2020-03-04 23:58:41 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:58:41 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:58:41 --> Utf8 Class Initialized
INFO - 2020-03-04 23:58:41 --> URI Class Initialized
INFO - 2020-03-04 23:58:41 --> Router Class Initialized
INFO - 2020-03-04 23:58:41 --> Output Class Initialized
INFO - 2020-03-04 23:58:41 --> Security Class Initialized
DEBUG - 2020-03-04 23:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:58:41 --> Input Class Initialized
INFO - 2020-03-04 23:58:41 --> Language Class Initialized
INFO - 2020-03-04 23:58:41 --> Loader Class Initialized
INFO - 2020-03-04 23:58:41 --> Helper loaded: url_helper
INFO - 2020-03-04 23:58:41 --> Helper loaded: string_helper
INFO - 2020-03-04 23:58:41 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:58:41 --> Controller Class Initialized
INFO - 2020-03-04 23:58:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-04 23:58:41 --> Pagination Class Initialized
INFO - 2020-03-04 23:58:41 --> Model "M_show" initialized
INFO - 2020-03-04 23:58:41 --> Helper loaded: form_helper
INFO - 2020-03-04 23:58:41 --> Form Validation Class Initialized
INFO - 2020-03-04 23:58:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-04 23:58:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-04 23:58:41 --> Final output sent to browser
DEBUG - 2020-03-04 23:58:41 --> Total execution time: 0.0304
INFO - 2020-03-04 23:58:46 --> Config Class Initialized
INFO - 2020-03-04 23:58:46 --> Hooks Class Initialized
DEBUG - 2020-03-04 23:58:46 --> UTF-8 Support Enabled
INFO - 2020-03-04 23:58:46 --> Utf8 Class Initialized
INFO - 2020-03-04 23:58:46 --> URI Class Initialized
INFO - 2020-03-04 23:58:46 --> Router Class Initialized
INFO - 2020-03-04 23:58:46 --> Output Class Initialized
INFO - 2020-03-04 23:58:46 --> Security Class Initialized
DEBUG - 2020-03-04 23:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 23:58:46 --> Input Class Initialized
INFO - 2020-03-04 23:58:46 --> Language Class Initialized
INFO - 2020-03-04 23:58:46 --> Loader Class Initialized
INFO - 2020-03-04 23:58:46 --> Helper loaded: url_helper
INFO - 2020-03-04 23:58:46 --> Helper loaded: string_helper
INFO - 2020-03-04 23:58:46 --> Database Driver Class Initialized
DEBUG - 2020-03-04 23:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 23:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 23:58:46 --> Controller Class Initialized
INFO - 2020-03-04 23:58:46 --> Model "M_tiket" initialized
INFO - 2020-03-04 23:58:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-04 23:58:46 --> Model "M_pesan" initialized
INFO - 2020-03-04 23:58:46 --> Helper loaded: form_helper
INFO - 2020-03-04 23:58:46 --> Form Validation Class Initialized
INFO - 2020-03-04 23:58:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-04 23:58:46 --> Final output sent to browser
DEBUG - 2020-03-04 23:58:46 --> Total execution time: 0.0094
