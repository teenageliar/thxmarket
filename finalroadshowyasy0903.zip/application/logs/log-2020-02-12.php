<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-12 03:03:03 --> Config Class Initialized
INFO - 2020-02-12 03:03:03 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:03:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:03:03 --> Utf8 Class Initialized
INFO - 2020-02-12 03:03:04 --> URI Class Initialized
INFO - 2020-02-12 03:03:04 --> Router Class Initialized
INFO - 2020-02-12 03:03:04 --> Output Class Initialized
INFO - 2020-02-12 03:03:04 --> Security Class Initialized
DEBUG - 2020-02-12 03:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:03:04 --> Input Class Initialized
INFO - 2020-02-12 03:03:04 --> Language Class Initialized
INFO - 2020-02-12 03:03:04 --> Loader Class Initialized
INFO - 2020-02-12 03:03:04 --> Helper loaded: url_helper
INFO - 2020-02-12 03:03:04 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:03:05 --> Controller Class Initialized
INFO - 2020-02-12 03:03:05 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:03:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:03:05 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:03:05 --> Helper loaded: form_helper
INFO - 2020-02-12 03:03:05 --> Form Validation Class Initialized
INFO - 2020-02-12 03:03:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 03:03:05 --> Final output sent to browser
DEBUG - 2020-02-12 03:03:05 --> Total execution time: 2.2515
INFO - 2020-02-12 03:03:25 --> Config Class Initialized
INFO - 2020-02-12 03:03:25 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:03:25 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:03:25 --> Utf8 Class Initialized
INFO - 2020-02-12 03:03:25 --> URI Class Initialized
INFO - 2020-02-12 03:03:25 --> Router Class Initialized
INFO - 2020-02-12 03:03:25 --> Output Class Initialized
INFO - 2020-02-12 03:03:25 --> Security Class Initialized
DEBUG - 2020-02-12 03:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:03:25 --> Input Class Initialized
INFO - 2020-02-12 03:03:25 --> Language Class Initialized
INFO - 2020-02-12 03:03:25 --> Loader Class Initialized
INFO - 2020-02-12 03:03:25 --> Helper loaded: url_helper
INFO - 2020-02-12 03:03:25 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:03:25 --> Controller Class Initialized
INFO - 2020-02-12 03:03:25 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:03:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:03:26 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:03:26 --> Helper loaded: form_helper
INFO - 2020-02-12 03:03:26 --> Form Validation Class Initialized
INFO - 2020-02-12 03:03:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 03:03:26 --> Final output sent to browser
DEBUG - 2020-02-12 03:03:26 --> Total execution time: 0.4235
INFO - 2020-02-12 03:03:50 --> Config Class Initialized
INFO - 2020-02-12 03:03:51 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:03:51 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:03:51 --> Utf8 Class Initialized
INFO - 2020-02-12 03:03:51 --> URI Class Initialized
INFO - 2020-02-12 03:03:51 --> Router Class Initialized
INFO - 2020-02-12 03:03:51 --> Output Class Initialized
INFO - 2020-02-12 03:03:51 --> Security Class Initialized
DEBUG - 2020-02-12 03:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:03:51 --> Input Class Initialized
INFO - 2020-02-12 03:03:51 --> Language Class Initialized
INFO - 2020-02-12 03:03:51 --> Loader Class Initialized
INFO - 2020-02-12 03:03:51 --> Helper loaded: url_helper
INFO - 2020-02-12 03:03:51 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:03:51 --> Controller Class Initialized
INFO - 2020-02-12 03:03:51 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:03:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:03:51 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:03:51 --> Helper loaded: form_helper
INFO - 2020-02-12 03:03:51 --> Form Validation Class Initialized
INFO - 2020-02-12 03:03:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 03:03:51 --> Final output sent to browser
DEBUG - 2020-02-12 03:03:51 --> Total execution time: 0.5775
INFO - 2020-02-12 03:04:11 --> Config Class Initialized
INFO - 2020-02-12 03:04:11 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:04:11 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:04:11 --> Utf8 Class Initialized
INFO - 2020-02-12 03:04:11 --> URI Class Initialized
INFO - 2020-02-12 03:04:11 --> Router Class Initialized
INFO - 2020-02-12 03:04:11 --> Output Class Initialized
INFO - 2020-02-12 03:04:11 --> Security Class Initialized
DEBUG - 2020-02-12 03:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:04:11 --> Input Class Initialized
INFO - 2020-02-12 03:04:11 --> Language Class Initialized
INFO - 2020-02-12 03:04:11 --> Loader Class Initialized
INFO - 2020-02-12 03:04:11 --> Helper loaded: url_helper
INFO - 2020-02-12 03:04:11 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:04:11 --> Controller Class Initialized
INFO - 2020-02-12 03:04:11 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:04:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:04:11 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:04:11 --> Helper loaded: form_helper
INFO - 2020-02-12 03:04:11 --> Form Validation Class Initialized
INFO - 2020-02-12 03:04:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 03:04:11 --> Final output sent to browser
DEBUG - 2020-02-12 03:04:11 --> Total execution time: 0.4517
INFO - 2020-02-12 03:08:47 --> Config Class Initialized
INFO - 2020-02-12 03:08:47 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:08:47 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:08:47 --> Utf8 Class Initialized
INFO - 2020-02-12 03:08:47 --> URI Class Initialized
INFO - 2020-02-12 03:08:47 --> Router Class Initialized
INFO - 2020-02-12 03:08:47 --> Output Class Initialized
INFO - 2020-02-12 03:08:47 --> Security Class Initialized
DEBUG - 2020-02-12 03:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:08:47 --> Input Class Initialized
INFO - 2020-02-12 03:08:47 --> Language Class Initialized
INFO - 2020-02-12 03:08:47 --> Loader Class Initialized
INFO - 2020-02-12 03:08:47 --> Helper loaded: url_helper
INFO - 2020-02-12 03:08:47 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:08:47 --> Controller Class Initialized
INFO - 2020-02-12 03:08:47 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:08:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:08:47 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:08:47 --> Helper loaded: form_helper
INFO - 2020-02-12 03:08:47 --> Form Validation Class Initialized
INFO - 2020-02-12 03:08:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:08:47 --> Final output sent to browser
DEBUG - 2020-02-12 03:08:47 --> Total execution time: 0.5452
INFO - 2020-02-12 03:08:47 --> Config Class Initialized
INFO - 2020-02-12 03:08:47 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:08:47 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:08:47 --> Utf8 Class Initialized
INFO - 2020-02-12 03:08:47 --> URI Class Initialized
INFO - 2020-02-12 03:08:47 --> Router Class Initialized
INFO - 2020-02-12 03:08:47 --> Output Class Initialized
INFO - 2020-02-12 03:08:47 --> Security Class Initialized
DEBUG - 2020-02-12 03:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:08:47 --> Input Class Initialized
INFO - 2020-02-12 03:08:48 --> Language Class Initialized
ERROR - 2020-02-12 03:08:48 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-12 03:08:51 --> Config Class Initialized
INFO - 2020-02-12 03:08:51 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:08:51 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:08:51 --> Utf8 Class Initialized
INFO - 2020-02-12 03:08:51 --> URI Class Initialized
DEBUG - 2020-02-12 03:08:51 --> No URI present. Default controller set.
INFO - 2020-02-12 03:08:51 --> Router Class Initialized
INFO - 2020-02-12 03:08:51 --> Output Class Initialized
INFO - 2020-02-12 03:08:51 --> Security Class Initialized
DEBUG - 2020-02-12 03:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:08:51 --> Input Class Initialized
INFO - 2020-02-12 03:08:51 --> Language Class Initialized
INFO - 2020-02-12 03:08:51 --> Loader Class Initialized
INFO - 2020-02-12 03:08:51 --> Helper loaded: url_helper
INFO - 2020-02-12 03:08:51 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:08:51 --> Controller Class Initialized
INFO - 2020-02-12 03:08:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-12 03:08:52 --> Pagination Class Initialized
INFO - 2020-02-12 03:08:52 --> Model "M_show" initialized
INFO - 2020-02-12 03:08:52 --> Helper loaded: form_helper
INFO - 2020-02-12 03:08:52 --> Form Validation Class Initialized
INFO - 2020-02-12 03:08:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-12 03:08:52 --> Final output sent to browser
DEBUG - 2020-02-12 03:08:52 --> Total execution time: 0.6984
INFO - 2020-02-12 03:09:00 --> Config Class Initialized
INFO - 2020-02-12 03:09:00 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:09:01 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:01 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:01 --> URI Class Initialized
INFO - 2020-02-12 03:09:01 --> Router Class Initialized
INFO - 2020-02-12 03:09:01 --> Output Class Initialized
INFO - 2020-02-12 03:09:01 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:01 --> Input Class Initialized
INFO - 2020-02-12 03:09:01 --> Language Class Initialized
INFO - 2020-02-12 03:09:01 --> Loader Class Initialized
INFO - 2020-02-12 03:09:01 --> Helper loaded: url_helper
INFO - 2020-02-12 03:09:01 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:09:01 --> Controller Class Initialized
INFO - 2020-02-12 03:09:01 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:09:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:09:01 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:09:01 --> Helper loaded: form_helper
INFO - 2020-02-12 03:09:01 --> Form Validation Class Initialized
INFO - 2020-02-12 03:09:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:09:01 --> Final output sent to browser
DEBUG - 2020-02-12 03:09:02 --> Total execution time: 1.1288
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
ERROR - 2020-02-12 03:09:02 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
ERROR - 2020-02-12 03:09:02 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-12 03:09:02 --> Loader Class Initialized
INFO - 2020-02-12 03:09:02 --> Helper loaded: url_helper
ERROR - 2020-02-12 03:09:02 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-12 03:09:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-12 03:09:02 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
INFO - 2020-02-12 03:09:02 --> Database Driver Class Initialized
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
DEBUG - 2020-02-12 03:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:09:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:02 --> Controller Class Initialized
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:02 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
INFO - 2020-02-12 03:09:02 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
INFO - 2020-02-12 03:09:02 --> Helper loaded: form_helper
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:02 --> Form Validation Class Initialized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-12 03:09:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
ERROR - 2020-02-12 03:09:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
INFO - 2020-02-12 03:09:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
ERROR - 2020-02-12 03:09:02 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-12 03:09:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-12 03:09:02 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-12 03:09:02 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-12 03:09:02 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-12 03:09:02 --> Final output sent to browser
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
INFO - 2020-02-12 03:09:02 --> Config Class Initialized
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:09:02 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:09:02 --> Total execution time: 0.6178
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:09:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> URI Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> Router Class Initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
INFO - 2020-02-12 03:09:02 --> Output Class Initialized
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
INFO - 2020-02-12 03:09:02 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
INFO - 2020-02-12 03:09:02 --> Input Class Initialized
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
INFO - 2020-02-12 03:09:02 --> Language Class Initialized
ERROR - 2020-02-12 03:09:02 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-12 03:09:02 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-12 03:09:02 --> Loader Class Initialized
INFO - 2020-02-12 03:09:02 --> Helper loaded: url_helper
INFO - 2020-02-12 03:09:03 --> Config Class Initialized
INFO - 2020-02-12 03:09:03 --> Database Driver Class Initialized
INFO - 2020-02-12 03:09:03 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-12 03:09:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:03 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:09:03 --> Controller Class Initialized
INFO - 2020-02-12 03:09:03 --> URI Class Initialized
INFO - 2020-02-12 03:09:03 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:09:03 --> Router Class Initialized
INFO - 2020-02-12 03:09:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:09:03 --> Output Class Initialized
INFO - 2020-02-12 03:09:03 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:09:03 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:03 --> Helper loaded: form_helper
INFO - 2020-02-12 03:09:03 --> Form Validation Class Initialized
INFO - 2020-02-12 03:09:03 --> Input Class Initialized
INFO - 2020-02-12 03:09:03 --> Language Class Initialized
ERROR - 2020-02-12 03:09:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 03:09:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-12 03:09:03 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-12 03:09:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:09:03 --> Config Class Initialized
INFO - 2020-02-12 03:09:03 --> Final output sent to browser
INFO - 2020-02-12 03:09:03 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:09:03 --> Total execution time: 0.5473
DEBUG - 2020-02-12 03:09:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:03 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:03 --> URI Class Initialized
INFO - 2020-02-12 03:09:03 --> Router Class Initialized
INFO - 2020-02-12 03:09:03 --> Output Class Initialized
INFO - 2020-02-12 03:09:03 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:03 --> Input Class Initialized
INFO - 2020-02-12 03:09:03 --> Language Class Initialized
ERROR - 2020-02-12 03:09:03 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-12 03:09:03 --> Config Class Initialized
INFO - 2020-02-12 03:09:03 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:09:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:03 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:03 --> URI Class Initialized
INFO - 2020-02-12 03:09:03 --> Router Class Initialized
INFO - 2020-02-12 03:09:03 --> Output Class Initialized
INFO - 2020-02-12 03:09:03 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:03 --> Input Class Initialized
INFO - 2020-02-12 03:09:03 --> Language Class Initialized
ERROR - 2020-02-12 03:09:03 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-12 03:09:03 --> Config Class Initialized
INFO - 2020-02-12 03:09:03 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:09:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:03 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:03 --> URI Class Initialized
INFO - 2020-02-12 03:09:03 --> Router Class Initialized
INFO - 2020-02-12 03:09:03 --> Output Class Initialized
INFO - 2020-02-12 03:09:03 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:03 --> Input Class Initialized
INFO - 2020-02-12 03:09:03 --> Language Class Initialized
ERROR - 2020-02-12 03:09:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:09:04 --> Config Class Initialized
INFO - 2020-02-12 03:09:04 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:09:04 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:04 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:04 --> URI Class Initialized
INFO - 2020-02-12 03:09:04 --> Router Class Initialized
INFO - 2020-02-12 03:09:04 --> Output Class Initialized
INFO - 2020-02-12 03:09:04 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:04 --> Input Class Initialized
INFO - 2020-02-12 03:09:04 --> Language Class Initialized
ERROR - 2020-02-12 03:09:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:09:04 --> Config Class Initialized
INFO - 2020-02-12 03:09:04 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:09:04 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:04 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:04 --> URI Class Initialized
INFO - 2020-02-12 03:09:04 --> Router Class Initialized
INFO - 2020-02-12 03:09:04 --> Output Class Initialized
INFO - 2020-02-12 03:09:04 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:04 --> Input Class Initialized
INFO - 2020-02-12 03:09:04 --> Language Class Initialized
ERROR - 2020-02-12 03:09:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-12 03:09:04 --> Config Class Initialized
INFO - 2020-02-12 03:09:04 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:09:04 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:04 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:04 --> URI Class Initialized
INFO - 2020-02-12 03:09:04 --> Router Class Initialized
INFO - 2020-02-12 03:09:04 --> Output Class Initialized
INFO - 2020-02-12 03:09:04 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:04 --> Input Class Initialized
INFO - 2020-02-12 03:09:04 --> Language Class Initialized
ERROR - 2020-02-12 03:09:04 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-12 03:09:04 --> Config Class Initialized
INFO - 2020-02-12 03:09:04 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:09:04 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:04 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:04 --> URI Class Initialized
INFO - 2020-02-12 03:09:04 --> Router Class Initialized
INFO - 2020-02-12 03:09:04 --> Output Class Initialized
INFO - 2020-02-12 03:09:04 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:04 --> Input Class Initialized
INFO - 2020-02-12 03:09:05 --> Language Class Initialized
ERROR - 2020-02-12 03:09:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-12 03:09:05 --> Config Class Initialized
INFO - 2020-02-12 03:09:05 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:09:05 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:09:05 --> Utf8 Class Initialized
INFO - 2020-02-12 03:09:05 --> URI Class Initialized
INFO - 2020-02-12 03:09:05 --> Router Class Initialized
INFO - 2020-02-12 03:09:05 --> Output Class Initialized
INFO - 2020-02-12 03:09:05 --> Security Class Initialized
DEBUG - 2020-02-12 03:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:09:05 --> Input Class Initialized
INFO - 2020-02-12 03:09:05 --> Language Class Initialized
ERROR - 2020-02-12 03:09:05 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-12 03:13:06 --> Config Class Initialized
INFO - 2020-02-12 03:13:06 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:06 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:06 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:06 --> URI Class Initialized
DEBUG - 2020-02-12 03:13:06 --> No URI present. Default controller set.
INFO - 2020-02-12 03:13:06 --> Router Class Initialized
INFO - 2020-02-12 03:13:06 --> Output Class Initialized
INFO - 2020-02-12 03:13:06 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:06 --> Input Class Initialized
INFO - 2020-02-12 03:13:06 --> Language Class Initialized
INFO - 2020-02-12 03:13:06 --> Loader Class Initialized
INFO - 2020-02-12 03:13:06 --> Helper loaded: url_helper
INFO - 2020-02-12 03:13:06 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:13:06 --> Controller Class Initialized
INFO - 2020-02-12 03:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-12 03:13:06 --> Pagination Class Initialized
INFO - 2020-02-12 03:13:06 --> Model "M_show" initialized
INFO - 2020-02-12 03:13:06 --> Helper loaded: form_helper
INFO - 2020-02-12 03:13:06 --> Form Validation Class Initialized
INFO - 2020-02-12 03:13:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-12 03:13:06 --> Final output sent to browser
DEBUG - 2020-02-12 03:13:06 --> Total execution time: 0.7466
INFO - 2020-02-12 03:13:08 --> Config Class Initialized
INFO - 2020-02-12 03:13:08 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:08 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:09 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:09 --> URI Class Initialized
INFO - 2020-02-12 03:13:09 --> Router Class Initialized
INFO - 2020-02-12 03:13:09 --> Output Class Initialized
INFO - 2020-02-12 03:13:09 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:09 --> Input Class Initialized
INFO - 2020-02-12 03:13:09 --> Language Class Initialized
INFO - 2020-02-12 03:13:09 --> Loader Class Initialized
INFO - 2020-02-12 03:13:09 --> Helper loaded: url_helper
INFO - 2020-02-12 03:13:09 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:13:09 --> Controller Class Initialized
INFO - 2020-02-12 03:13:09 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:13:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:13:09 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:13:09 --> Helper loaded: form_helper
INFO - 2020-02-12 03:13:09 --> Form Validation Class Initialized
INFO - 2020-02-12 03:13:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:13:09 --> Final output sent to browser
DEBUG - 2020-02-12 03:13:09 --> Total execution time: 0.5069
INFO - 2020-02-12 03:13:09 --> Config Class Initialized
INFO - 2020-02-12 03:13:09 --> Config Class Initialized
INFO - 2020-02-12 03:13:09 --> Config Class Initialized
INFO - 2020-02-12 03:13:09 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:09 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:09 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:09 --> Config Class Initialized
INFO - 2020-02-12 03:13:09 --> Config Class Initialized
INFO - 2020-02-12 03:13:09 --> Config Class Initialized
INFO - 2020-02-12 03:13:09 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:09 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:09 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:09 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:09 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:09 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:09 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:13:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:09 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:09 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:09 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:09 --> URI Class Initialized
INFO - 2020-02-12 03:13:09 --> URI Class Initialized
INFO - 2020-02-12 03:13:09 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:09 --> URI Class Initialized
INFO - 2020-02-12 03:13:09 --> URI Class Initialized
INFO - 2020-02-12 03:13:09 --> URI Class Initialized
INFO - 2020-02-12 03:13:09 --> URI Class Initialized
INFO - 2020-02-12 03:13:09 --> Router Class Initialized
INFO - 2020-02-12 03:13:09 --> Router Class Initialized
INFO - 2020-02-12 03:13:09 --> Router Class Initialized
INFO - 2020-02-12 03:13:09 --> Router Class Initialized
INFO - 2020-02-12 03:13:09 --> Output Class Initialized
INFO - 2020-02-12 03:13:09 --> Router Class Initialized
INFO - 2020-02-12 03:13:09 --> Output Class Initialized
INFO - 2020-02-12 03:13:09 --> Router Class Initialized
INFO - 2020-02-12 03:13:09 --> Output Class Initialized
INFO - 2020-02-12 03:13:09 --> Security Class Initialized
INFO - 2020-02-12 03:13:09 --> Security Class Initialized
INFO - 2020-02-12 03:13:09 --> Output Class Initialized
INFO - 2020-02-12 03:13:09 --> Output Class Initialized
INFO - 2020-02-12 03:13:09 --> Security Class Initialized
INFO - 2020-02-12 03:13:09 --> Output Class Initialized
DEBUG - 2020-02-12 03:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:09 --> Security Class Initialized
INFO - 2020-02-12 03:13:09 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:09 --> Security Class Initialized
INFO - 2020-02-12 03:13:09 --> Input Class Initialized
INFO - 2020-02-12 03:13:09 --> Input Class Initialized
INFO - 2020-02-12 03:13:09 --> Input Class Initialized
DEBUG - 2020-02-12 03:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:09 --> Input Class Initialized
INFO - 2020-02-12 03:13:09 --> Input Class Initialized
INFO - 2020-02-12 03:13:09 --> Input Class Initialized
INFO - 2020-02-12 03:13:09 --> Language Class Initialized
INFO - 2020-02-12 03:13:09 --> Language Class Initialized
INFO - 2020-02-12 03:13:09 --> Language Class Initialized
ERROR - 2020-02-12 03:13:09 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-12 03:13:09 --> Language Class Initialized
INFO - 2020-02-12 03:13:09 --> Language Class Initialized
INFO - 2020-02-12 03:13:09 --> Language Class Initialized
ERROR - 2020-02-12 03:13:09 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-12 03:13:09 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-12 03:13:09 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-12 03:13:09 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-12 03:13:09 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:13:09 --> Config Class Initialized
INFO - 2020-02-12 03:13:09 --> Config Class Initialized
INFO - 2020-02-12 03:13:09 --> Config Class Initialized
INFO - 2020-02-12 03:13:09 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:09 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:09 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:09 --> Config Class Initialized
INFO - 2020-02-12 03:13:09 --> Config Class Initialized
INFO - 2020-02-12 03:13:09 --> Config Class Initialized
INFO - 2020-02-12 03:13:09 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:09 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:09 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:10 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:10 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:13:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:10 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:10 --> URI Class Initialized
INFO - 2020-02-12 03:13:10 --> URI Class Initialized
INFO - 2020-02-12 03:13:10 --> URI Class Initialized
INFO - 2020-02-12 03:13:10 --> URI Class Initialized
INFO - 2020-02-12 03:13:10 --> Router Class Initialized
INFO - 2020-02-12 03:13:10 --> Router Class Initialized
INFO - 2020-02-12 03:13:10 --> URI Class Initialized
INFO - 2020-02-12 03:13:10 --> URI Class Initialized
INFO - 2020-02-12 03:13:10 --> Router Class Initialized
INFO - 2020-02-12 03:13:10 --> Router Class Initialized
INFO - 2020-02-12 03:13:10 --> Router Class Initialized
INFO - 2020-02-12 03:13:10 --> Output Class Initialized
INFO - 2020-02-12 03:13:10 --> Router Class Initialized
INFO - 2020-02-12 03:13:10 --> Output Class Initialized
INFO - 2020-02-12 03:13:10 --> Output Class Initialized
INFO - 2020-02-12 03:13:10 --> Output Class Initialized
INFO - 2020-02-12 03:13:10 --> Output Class Initialized
INFO - 2020-02-12 03:13:10 --> Output Class Initialized
INFO - 2020-02-12 03:13:10 --> Security Class Initialized
INFO - 2020-02-12 03:13:10 --> Security Class Initialized
INFO - 2020-02-12 03:13:10 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:10 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:10 --> Security Class Initialized
INFO - 2020-02-12 03:13:10 --> Security Class Initialized
INFO - 2020-02-12 03:13:10 --> Input Class Initialized
INFO - 2020-02-12 03:13:10 --> Input Class Initialized
INFO - 2020-02-12 03:13:10 --> Input Class Initialized
DEBUG - 2020-02-12 03:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:10 --> Input Class Initialized
INFO - 2020-02-12 03:13:10 --> Input Class Initialized
INFO - 2020-02-12 03:13:10 --> Input Class Initialized
INFO - 2020-02-12 03:13:10 --> Language Class Initialized
INFO - 2020-02-12 03:13:10 --> Language Class Initialized
INFO - 2020-02-12 03:13:10 --> Language Class Initialized
INFO - 2020-02-12 03:13:10 --> Language Class Initialized
INFO - 2020-02-12 03:13:10 --> Language Class Initialized
INFO - 2020-02-12 03:13:10 --> Language Class Initialized
ERROR - 2020-02-12 03:13:10 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-12 03:13:10 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-12 03:13:10 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-12 03:13:10 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-12 03:13:10 --> Loader Class Initialized
INFO - 2020-02-12 03:13:10 --> Loader Class Initialized
INFO - 2020-02-12 03:13:10 --> Config Class Initialized
INFO - 2020-02-12 03:13:10 --> Config Class Initialized
INFO - 2020-02-12 03:13:10 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:10 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:10 --> Helper loaded: url_helper
INFO - 2020-02-12 03:13:10 --> Helper loaded: url_helper
DEBUG - 2020-02-12 03:13:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:10 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:10 --> Database Driver Class Initialized
INFO - 2020-02-12 03:13:10 --> Database Driver Class Initialized
INFO - 2020-02-12 03:13:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:10 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-12 03:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:13:10 --> URI Class Initialized
INFO - 2020-02-12 03:13:10 --> URI Class Initialized
INFO - 2020-02-12 03:13:10 --> Controller Class Initialized
INFO - 2020-02-12 03:13:10 --> Router Class Initialized
INFO - 2020-02-12 03:13:10 --> Router Class Initialized
INFO - 2020-02-12 03:13:10 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:13:10 --> Output Class Initialized
INFO - 2020-02-12 03:13:10 --> Output Class Initialized
INFO - 2020-02-12 03:13:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:13:10 --> Security Class Initialized
INFO - 2020-02-12 03:13:10 --> Security Class Initialized
INFO - 2020-02-12 03:13:10 --> Model "M_pesan" initialized
DEBUG - 2020-02-12 03:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:10 --> Input Class Initialized
INFO - 2020-02-12 03:13:10 --> Input Class Initialized
INFO - 2020-02-12 03:13:10 --> Helper loaded: form_helper
INFO - 2020-02-12 03:13:10 --> Form Validation Class Initialized
INFO - 2020-02-12 03:13:10 --> Language Class Initialized
INFO - 2020-02-12 03:13:10 --> Language Class Initialized
ERROR - 2020-02-12 03:13:10 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-12 03:13:10 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-12 03:13:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 03:13:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-12 03:13:10 --> Config Class Initialized
INFO - 2020-02-12 03:13:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:13:10 --> Final output sent to browser
INFO - 2020-02-12 03:13:10 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:10 --> Total execution time: 0.6345
DEBUG - 2020-02-12 03:13:10 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:13:10 --> Controller Class Initialized
INFO - 2020-02-12 03:13:10 --> URI Class Initialized
INFO - 2020-02-12 03:13:10 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:13:10 --> Router Class Initialized
INFO - 2020-02-12 03:13:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:13:10 --> Output Class Initialized
INFO - 2020-02-12 03:13:10 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:13:10 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:10 --> Helper loaded: form_helper
INFO - 2020-02-12 03:13:10 --> Form Validation Class Initialized
INFO - 2020-02-12 03:13:10 --> Input Class Initialized
INFO - 2020-02-12 03:13:10 --> Language Class Initialized
ERROR - 2020-02-12 03:13:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 03:13:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-12 03:13:10 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-12 03:13:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:13:10 --> Config Class Initialized
INFO - 2020-02-12 03:13:10 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:10 --> Final output sent to browser
DEBUG - 2020-02-12 03:13:10 --> Total execution time: 0.9049
DEBUG - 2020-02-12 03:13:10 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:10 --> URI Class Initialized
INFO - 2020-02-12 03:13:10 --> Router Class Initialized
INFO - 2020-02-12 03:13:10 --> Output Class Initialized
INFO - 2020-02-12 03:13:11 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:11 --> Input Class Initialized
INFO - 2020-02-12 03:13:11 --> Language Class Initialized
ERROR - 2020-02-12 03:13:11 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-12 03:13:11 --> Config Class Initialized
INFO - 2020-02-12 03:13:11 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:11 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:11 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:11 --> URI Class Initialized
INFO - 2020-02-12 03:13:11 --> Router Class Initialized
INFO - 2020-02-12 03:13:11 --> Output Class Initialized
INFO - 2020-02-12 03:13:11 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:11 --> Input Class Initialized
INFO - 2020-02-12 03:13:11 --> Language Class Initialized
ERROR - 2020-02-12 03:13:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:13:11 --> Config Class Initialized
INFO - 2020-02-12 03:13:11 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:11 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:11 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:11 --> URI Class Initialized
INFO - 2020-02-12 03:13:11 --> Router Class Initialized
INFO - 2020-02-12 03:13:11 --> Output Class Initialized
INFO - 2020-02-12 03:13:11 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:11 --> Input Class Initialized
INFO - 2020-02-12 03:13:11 --> Language Class Initialized
ERROR - 2020-02-12 03:13:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:13:11 --> Config Class Initialized
INFO - 2020-02-12 03:13:11 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:11 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:11 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:11 --> URI Class Initialized
INFO - 2020-02-12 03:13:11 --> Router Class Initialized
INFO - 2020-02-12 03:13:12 --> Output Class Initialized
INFO - 2020-02-12 03:13:12 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:12 --> Input Class Initialized
INFO - 2020-02-12 03:13:12 --> Language Class Initialized
ERROR - 2020-02-12 03:13:12 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-12 03:13:12 --> Config Class Initialized
INFO - 2020-02-12 03:13:12 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:12 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:12 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:12 --> URI Class Initialized
INFO - 2020-02-12 03:13:12 --> Router Class Initialized
INFO - 2020-02-12 03:13:12 --> Output Class Initialized
INFO - 2020-02-12 03:13:12 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:12 --> Input Class Initialized
INFO - 2020-02-12 03:13:12 --> Language Class Initialized
ERROR - 2020-02-12 03:13:12 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-12 03:13:12 --> Config Class Initialized
INFO - 2020-02-12 03:13:12 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:12 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:12 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:12 --> URI Class Initialized
INFO - 2020-02-12 03:13:12 --> Router Class Initialized
INFO - 2020-02-12 03:13:12 --> Output Class Initialized
INFO - 2020-02-12 03:13:12 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:12 --> Input Class Initialized
INFO - 2020-02-12 03:13:12 --> Language Class Initialized
ERROR - 2020-02-12 03:13:12 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-12 03:13:12 --> Config Class Initialized
INFO - 2020-02-12 03:13:12 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:12 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:12 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:12 --> URI Class Initialized
INFO - 2020-02-12 03:13:12 --> Router Class Initialized
INFO - 2020-02-12 03:13:12 --> Output Class Initialized
INFO - 2020-02-12 03:13:12 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:12 --> Input Class Initialized
INFO - 2020-02-12 03:13:12 --> Language Class Initialized
ERROR - 2020-02-12 03:13:12 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-12 03:13:46 --> Config Class Initialized
INFO - 2020-02-12 03:13:46 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:46 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:46 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:46 --> URI Class Initialized
INFO - 2020-02-12 03:13:46 --> Router Class Initialized
INFO - 2020-02-12 03:13:46 --> Output Class Initialized
INFO - 2020-02-12 03:13:46 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:47 --> Input Class Initialized
INFO - 2020-02-12 03:13:47 --> Language Class Initialized
INFO - 2020-02-12 03:13:47 --> Loader Class Initialized
INFO - 2020-02-12 03:13:47 --> Helper loaded: url_helper
INFO - 2020-02-12 03:13:47 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:13:47 --> Controller Class Initialized
INFO - 2020-02-12 03:13:47 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:13:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:13:47 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:13:47 --> Helper loaded: form_helper
INFO - 2020-02-12 03:13:47 --> Form Validation Class Initialized
INFO - 2020-02-12 03:13:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:13:47 --> Final output sent to browser
DEBUG - 2020-02-12 03:13:47 --> Total execution time: 0.6257
INFO - 2020-02-12 03:13:47 --> Config Class Initialized
INFO - 2020-02-12 03:13:47 --> Config Class Initialized
INFO - 2020-02-12 03:13:47 --> Config Class Initialized
INFO - 2020-02-12 03:13:47 --> Config Class Initialized
INFO - 2020-02-12 03:13:47 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:47 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:47 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:47 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:47 --> Config Class Initialized
INFO - 2020-02-12 03:13:47 --> Config Class Initialized
INFO - 2020-02-12 03:13:47 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:47 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:47 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:47 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:47 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:47 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:47 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:47 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:13:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:47 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:47 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:47 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:47 --> URI Class Initialized
INFO - 2020-02-12 03:13:47 --> URI Class Initialized
INFO - 2020-02-12 03:13:47 --> URI Class Initialized
INFO - 2020-02-12 03:13:47 --> URI Class Initialized
INFO - 2020-02-12 03:13:47 --> URI Class Initialized
INFO - 2020-02-12 03:13:47 --> Router Class Initialized
INFO - 2020-02-12 03:13:47 --> Router Class Initialized
INFO - 2020-02-12 03:13:47 --> URI Class Initialized
INFO - 2020-02-12 03:13:47 --> Router Class Initialized
INFO - 2020-02-12 03:13:47 --> Router Class Initialized
INFO - 2020-02-12 03:13:47 --> Router Class Initialized
INFO - 2020-02-12 03:13:47 --> Output Class Initialized
INFO - 2020-02-12 03:13:47 --> Output Class Initialized
INFO - 2020-02-12 03:13:47 --> Router Class Initialized
INFO - 2020-02-12 03:13:47 --> Output Class Initialized
INFO - 2020-02-12 03:13:47 --> Output Class Initialized
INFO - 2020-02-12 03:13:47 --> Security Class Initialized
INFO - 2020-02-12 03:13:47 --> Security Class Initialized
INFO - 2020-02-12 03:13:47 --> Output Class Initialized
INFO - 2020-02-12 03:13:47 --> Security Class Initialized
INFO - 2020-02-12 03:13:47 --> Output Class Initialized
INFO - 2020-02-12 03:13:47 --> Security Class Initialized
INFO - 2020-02-12 03:13:47 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:47 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:47 --> Input Class Initialized
INFO - 2020-02-12 03:13:47 --> Input Class Initialized
INFO - 2020-02-12 03:13:47 --> Input Class Initialized
INFO - 2020-02-12 03:13:47 --> Input Class Initialized
DEBUG - 2020-02-12 03:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:47 --> Input Class Initialized
INFO - 2020-02-12 03:13:47 --> Input Class Initialized
INFO - 2020-02-12 03:13:47 --> Language Class Initialized
INFO - 2020-02-12 03:13:47 --> Language Class Initialized
INFO - 2020-02-12 03:13:47 --> Language Class Initialized
INFO - 2020-02-12 03:13:47 --> Language Class Initialized
INFO - 2020-02-12 03:13:47 --> Language Class Initialized
INFO - 2020-02-12 03:13:47 --> Language Class Initialized
ERROR - 2020-02-12 03:13:47 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-12 03:13:47 --> Loader Class Initialized
INFO - 2020-02-12 03:13:47 --> Loader Class Initialized
ERROR - 2020-02-12 03:13:47 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-12 03:13:47 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-12 03:13:47 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-12 03:13:47 --> Helper loaded: url_helper
INFO - 2020-02-12 03:13:47 --> Helper loaded: url_helper
INFO - 2020-02-12 03:13:47 --> Config Class Initialized
INFO - 2020-02-12 03:13:47 --> Config Class Initialized
INFO - 2020-02-12 03:13:47 --> Database Driver Class Initialized
INFO - 2020-02-12 03:13:47 --> Database Driver Class Initialized
INFO - 2020-02-12 03:13:47 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:47 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:47 --> Config Class Initialized
INFO - 2020-02-12 03:13:47 --> Config Class Initialized
DEBUG - 2020-02-12 03:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-12 03:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:13:48 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:48 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-12 03:13:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:48 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:48 --> Controller Class Initialized
INFO - 2020-02-12 03:13:48 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:13:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:48 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:48 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:48 --> URI Class Initialized
INFO - 2020-02-12 03:13:48 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:13:48 --> URI Class Initialized
INFO - 2020-02-12 03:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:13:48 --> Controller Class Initialized
INFO - 2020-02-12 03:13:48 --> URI Class Initialized
INFO - 2020-02-12 03:13:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:13:48 --> Router Class Initialized
INFO - 2020-02-12 03:13:48 --> URI Class Initialized
INFO - 2020-02-12 03:13:48 --> Router Class Initialized
INFO - 2020-02-12 03:13:48 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:13:48 --> Output Class Initialized
INFO - 2020-02-12 03:13:48 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:13:48 --> Router Class Initialized
INFO - 2020-02-12 03:13:48 --> Output Class Initialized
INFO - 2020-02-12 03:13:48 --> Router Class Initialized
INFO - 2020-02-12 03:13:48 --> Security Class Initialized
INFO - 2020-02-12 03:13:48 --> Output Class Initialized
INFO - 2020-02-12 03:13:48 --> Security Class Initialized
INFO - 2020-02-12 03:13:48 --> Output Class Initialized
INFO - 2020-02-12 03:13:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:13:48 --> Helper loaded: form_helper
INFO - 2020-02-12 03:13:48 --> Form Validation Class Initialized
INFO - 2020-02-12 03:13:48 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:13:48 --> Security Class Initialized
INFO - 2020-02-12 03:13:48 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:48 --> Input Class Initialized
INFO - 2020-02-12 03:13:48 --> Input Class Initialized
DEBUG - 2020-02-12 03:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:48 --> Helper loaded: form_helper
ERROR - 2020-02-12 03:13:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-12 03:13:48 --> Input Class Initialized
INFO - 2020-02-12 03:13:48 --> Language Class Initialized
INFO - 2020-02-12 03:13:48 --> Form Validation Class Initialized
INFO - 2020-02-12 03:13:48 --> Language Class Initialized
INFO - 2020-02-12 03:13:48 --> Input Class Initialized
ERROR - 2020-02-12 03:13:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-12 03:13:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-12 03:13:48 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-12 03:13:48 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-12 03:13:48 --> Language Class Initialized
INFO - 2020-02-12 03:13:48 --> Language Class Initialized
ERROR - 2020-02-12 03:13:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-12 03:13:48 --> Final output sent to browser
ERROR - 2020-02-12 03:13:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-12 03:13:48 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-12 03:13:48 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-12 03:13:48 --> Config Class Initialized
DEBUG - 2020-02-12 03:13:48 --> Total execution time: 0.6574
INFO - 2020-02-12 03:13:48 --> Config Class Initialized
INFO - 2020-02-12 03:13:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:13:48 --> Config Class Initialized
INFO - 2020-02-12 03:13:48 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:48 --> Final output sent to browser
INFO - 2020-02-12 03:13:48 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:48 --> Hooks Class Initialized
INFO - 2020-02-12 03:13:48 --> Config Class Initialized
DEBUG - 2020-02-12 03:13:48 --> Total execution time: 0.7988
INFO - 2020-02-12 03:13:48 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:13:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:48 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:48 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:48 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:13:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:48 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:48 --> URI Class Initialized
INFO - 2020-02-12 03:13:48 --> URI Class Initialized
INFO - 2020-02-12 03:13:48 --> URI Class Initialized
INFO - 2020-02-12 03:13:48 --> URI Class Initialized
INFO - 2020-02-12 03:13:48 --> Router Class Initialized
INFO - 2020-02-12 03:13:48 --> Router Class Initialized
INFO - 2020-02-12 03:13:48 --> Router Class Initialized
INFO - 2020-02-12 03:13:48 --> Router Class Initialized
INFO - 2020-02-12 03:13:48 --> Output Class Initialized
INFO - 2020-02-12 03:13:48 --> Output Class Initialized
INFO - 2020-02-12 03:13:48 --> Output Class Initialized
INFO - 2020-02-12 03:13:48 --> Security Class Initialized
INFO - 2020-02-12 03:13:48 --> Security Class Initialized
INFO - 2020-02-12 03:13:48 --> Security Class Initialized
INFO - 2020-02-12 03:13:48 --> Output Class Initialized
DEBUG - 2020-02-12 03:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:48 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:48 --> Input Class Initialized
INFO - 2020-02-12 03:13:48 --> Input Class Initialized
INFO - 2020-02-12 03:13:48 --> Input Class Initialized
DEBUG - 2020-02-12 03:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:48 --> Input Class Initialized
INFO - 2020-02-12 03:13:48 --> Language Class Initialized
INFO - 2020-02-12 03:13:48 --> Language Class Initialized
INFO - 2020-02-12 03:13:48 --> Language Class Initialized
INFO - 2020-02-12 03:13:48 --> Language Class Initialized
ERROR - 2020-02-12 03:13:48 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-12 03:13:48 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-12 03:13:48 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-12 03:13:48 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-12 03:13:48 --> Config Class Initialized
INFO - 2020-02-12 03:13:48 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:48 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:48 --> URI Class Initialized
INFO - 2020-02-12 03:13:48 --> Router Class Initialized
INFO - 2020-02-12 03:13:48 --> Output Class Initialized
INFO - 2020-02-12 03:13:48 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:48 --> Input Class Initialized
INFO - 2020-02-12 03:13:48 --> Language Class Initialized
ERROR - 2020-02-12 03:13:48 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-12 03:13:49 --> Config Class Initialized
INFO - 2020-02-12 03:13:49 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:49 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:49 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:49 --> URI Class Initialized
INFO - 2020-02-12 03:13:49 --> Router Class Initialized
INFO - 2020-02-12 03:13:49 --> Output Class Initialized
INFO - 2020-02-12 03:13:49 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:49 --> Input Class Initialized
INFO - 2020-02-12 03:13:49 --> Language Class Initialized
ERROR - 2020-02-12 03:13:49 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-12 03:13:49 --> Config Class Initialized
INFO - 2020-02-12 03:13:49 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:49 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:49 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:49 --> URI Class Initialized
INFO - 2020-02-12 03:13:49 --> Router Class Initialized
INFO - 2020-02-12 03:13:49 --> Output Class Initialized
INFO - 2020-02-12 03:13:49 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:49 --> Input Class Initialized
INFO - 2020-02-12 03:13:49 --> Language Class Initialized
ERROR - 2020-02-12 03:13:49 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-12 03:13:49 --> Config Class Initialized
INFO - 2020-02-12 03:13:49 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:49 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:49 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:49 --> URI Class Initialized
INFO - 2020-02-12 03:13:49 --> Router Class Initialized
INFO - 2020-02-12 03:13:49 --> Output Class Initialized
INFO - 2020-02-12 03:13:49 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:49 --> Input Class Initialized
INFO - 2020-02-12 03:13:49 --> Language Class Initialized
ERROR - 2020-02-12 03:13:49 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:13:49 --> Config Class Initialized
INFO - 2020-02-12 03:13:50 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:50 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:50 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:50 --> URI Class Initialized
INFO - 2020-02-12 03:13:50 --> Router Class Initialized
INFO - 2020-02-12 03:13:50 --> Output Class Initialized
INFO - 2020-02-12 03:13:50 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:50 --> Input Class Initialized
INFO - 2020-02-12 03:13:50 --> Language Class Initialized
ERROR - 2020-02-12 03:13:50 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:13:50 --> Config Class Initialized
INFO - 2020-02-12 03:13:50 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:50 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:50 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:50 --> URI Class Initialized
INFO - 2020-02-12 03:13:50 --> Router Class Initialized
INFO - 2020-02-12 03:13:50 --> Output Class Initialized
INFO - 2020-02-12 03:13:50 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:50 --> Input Class Initialized
INFO - 2020-02-12 03:13:50 --> Language Class Initialized
ERROR - 2020-02-12 03:13:50 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-12 03:13:51 --> Config Class Initialized
INFO - 2020-02-12 03:13:51 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:51 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:51 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:51 --> URI Class Initialized
INFO - 2020-02-12 03:13:51 --> Router Class Initialized
INFO - 2020-02-12 03:13:51 --> Output Class Initialized
INFO - 2020-02-12 03:13:51 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:51 --> Input Class Initialized
INFO - 2020-02-12 03:13:51 --> Language Class Initialized
ERROR - 2020-02-12 03:13:51 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-12 03:13:51 --> Config Class Initialized
INFO - 2020-02-12 03:13:51 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:51 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:51 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:51 --> URI Class Initialized
INFO - 2020-02-12 03:13:51 --> Router Class Initialized
INFO - 2020-02-12 03:13:51 --> Output Class Initialized
INFO - 2020-02-12 03:13:51 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:51 --> Input Class Initialized
INFO - 2020-02-12 03:13:51 --> Language Class Initialized
ERROR - 2020-02-12 03:13:51 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-12 03:13:51 --> Config Class Initialized
INFO - 2020-02-12 03:13:51 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:13:51 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:13:51 --> Utf8 Class Initialized
INFO - 2020-02-12 03:13:51 --> URI Class Initialized
INFO - 2020-02-12 03:13:51 --> Router Class Initialized
INFO - 2020-02-12 03:13:51 --> Output Class Initialized
INFO - 2020-02-12 03:13:51 --> Security Class Initialized
DEBUG - 2020-02-12 03:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:13:51 --> Input Class Initialized
INFO - 2020-02-12 03:13:51 --> Language Class Initialized
ERROR - 2020-02-12 03:13:51 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-12 03:17:01 --> Config Class Initialized
INFO - 2020-02-12 03:17:01 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:17:01 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:01 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:01 --> URI Class Initialized
INFO - 2020-02-12 03:17:01 --> Router Class Initialized
INFO - 2020-02-12 03:17:01 --> Output Class Initialized
INFO - 2020-02-12 03:17:01 --> Security Class Initialized
DEBUG - 2020-02-12 03:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:01 --> Input Class Initialized
INFO - 2020-02-12 03:17:01 --> Language Class Initialized
INFO - 2020-02-12 03:17:01 --> Loader Class Initialized
INFO - 2020-02-12 03:17:02 --> Helper loaded: url_helper
INFO - 2020-02-12 03:17:02 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:17:02 --> Controller Class Initialized
INFO - 2020-02-12 03:17:02 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:17:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:17:02 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:17:02 --> Helper loaded: form_helper
INFO - 2020-02-12 03:17:02 --> Form Validation Class Initialized
INFO - 2020-02-12 03:17:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:17:02 --> Final output sent to browser
DEBUG - 2020-02-12 03:17:02 --> Total execution time: 0.5571
INFO - 2020-02-12 03:17:02 --> Config Class Initialized
INFO - 2020-02-12 03:17:02 --> Config Class Initialized
INFO - 2020-02-12 03:17:02 --> Config Class Initialized
INFO - 2020-02-12 03:17:02 --> Config Class Initialized
INFO - 2020-02-12 03:17:02 --> Config Class Initialized
INFO - 2020-02-12 03:17:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:17:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:17:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:17:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:17:02 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:17:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:02 --> Config Class Initialized
INFO - 2020-02-12 03:17:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:17:02 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:17:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:17:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:17:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:17:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:02 --> URI Class Initialized
DEBUG - 2020-02-12 03:17:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:02 --> URI Class Initialized
INFO - 2020-02-12 03:17:02 --> URI Class Initialized
INFO - 2020-02-12 03:17:02 --> Router Class Initialized
INFO - 2020-02-12 03:17:02 --> URI Class Initialized
INFO - 2020-02-12 03:17:02 --> URI Class Initialized
INFO - 2020-02-12 03:17:02 --> Router Class Initialized
INFO - 2020-02-12 03:17:02 --> URI Class Initialized
INFO - 2020-02-12 03:17:02 --> Router Class Initialized
INFO - 2020-02-12 03:17:02 --> Router Class Initialized
INFO - 2020-02-12 03:17:02 --> Router Class Initialized
INFO - 2020-02-12 03:17:02 --> Output Class Initialized
INFO - 2020-02-12 03:17:02 --> Output Class Initialized
INFO - 2020-02-12 03:17:02 --> Output Class Initialized
INFO - 2020-02-12 03:17:02 --> Output Class Initialized
INFO - 2020-02-12 03:17:02 --> Output Class Initialized
INFO - 2020-02-12 03:17:02 --> Security Class Initialized
INFO - 2020-02-12 03:17:02 --> Router Class Initialized
DEBUG - 2020-02-12 03:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:02 --> Security Class Initialized
INFO - 2020-02-12 03:17:02 --> Output Class Initialized
INFO - 2020-02-12 03:17:02 --> Security Class Initialized
INFO - 2020-02-12 03:17:02 --> Security Class Initialized
INFO - 2020-02-12 03:17:02 --> Security Class Initialized
INFO - 2020-02-12 03:17:02 --> Input Class Initialized
DEBUG - 2020-02-12 03:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:02 --> Security Class Initialized
DEBUG - 2020-02-12 03:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:02 --> Input Class Initialized
INFO - 2020-02-12 03:17:02 --> Input Class Initialized
INFO - 2020-02-12 03:17:02 --> Input Class Initialized
INFO - 2020-02-12 03:17:02 --> Input Class Initialized
INFO - 2020-02-12 03:17:02 --> Language Class Initialized
DEBUG - 2020-02-12 03:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:02 --> Language Class Initialized
INFO - 2020-02-12 03:17:02 --> Language Class Initialized
INFO - 2020-02-12 03:17:02 --> Language Class Initialized
INFO - 2020-02-12 03:17:02 --> Language Class Initialized
INFO - 2020-02-12 03:17:02 --> Input Class Initialized
ERROR - 2020-02-12 03:17:02 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-12 03:17:02 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-12 03:17:02 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-12 03:17:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-12 03:17:02 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-12 03:17:02 --> Language Class Initialized
INFO - 2020-02-12 03:17:02 --> Config Class Initialized
INFO - 2020-02-12 03:17:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:17:02 --> Config Class Initialized
INFO - 2020-02-12 03:17:02 --> Config Class Initialized
INFO - 2020-02-12 03:17:02 --> Config Class Initialized
INFO - 2020-02-12 03:17:02 --> Loader Class Initialized
INFO - 2020-02-12 03:17:02 --> Config Class Initialized
INFO - 2020-02-12 03:17:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:17:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:17:02 --> Hooks Class Initialized
INFO - 2020-02-12 03:17:02 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:17:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:02 --> Helper loaded: url_helper
INFO - 2020-02-12 03:17:02 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:17:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:17:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:17:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:17:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:02 --> Database Driver Class Initialized
INFO - 2020-02-12 03:17:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:02 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:02 --> URI Class Initialized
DEBUG - 2020-02-12 03:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:17:02 --> URI Class Initialized
INFO - 2020-02-12 03:17:02 --> Router Class Initialized
INFO - 2020-02-12 03:17:02 --> URI Class Initialized
INFO - 2020-02-12 03:17:02 --> URI Class Initialized
INFO - 2020-02-12 03:17:02 --> URI Class Initialized
INFO - 2020-02-12 03:17:02 --> Controller Class Initialized
INFO - 2020-02-12 03:17:02 --> Router Class Initialized
INFO - 2020-02-12 03:17:02 --> Router Class Initialized
INFO - 2020-02-12 03:17:02 --> Output Class Initialized
INFO - 2020-02-12 03:17:02 --> Router Class Initialized
INFO - 2020-02-12 03:17:02 --> Router Class Initialized
INFO - 2020-02-12 03:17:02 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:17:02 --> Output Class Initialized
INFO - 2020-02-12 03:17:02 --> Output Class Initialized
INFO - 2020-02-12 03:17:02 --> Output Class Initialized
INFO - 2020-02-12 03:17:02 --> Output Class Initialized
INFO - 2020-02-12 03:17:02 --> Security Class Initialized
INFO - 2020-02-12 03:17:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:17:02 --> Security Class Initialized
INFO - 2020-02-12 03:17:02 --> Security Class Initialized
INFO - 2020-02-12 03:17:02 --> Security Class Initialized
DEBUG - 2020-02-12 03:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:02 --> Security Class Initialized
INFO - 2020-02-12 03:17:03 --> Input Class Initialized
INFO - 2020-02-12 03:17:03 --> Model "M_pesan" initialized
DEBUG - 2020-02-12 03:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:03 --> Input Class Initialized
INFO - 2020-02-12 03:17:03 --> Input Class Initialized
INFO - 2020-02-12 03:17:03 --> Input Class Initialized
INFO - 2020-02-12 03:17:03 --> Input Class Initialized
INFO - 2020-02-12 03:17:03 --> Language Class Initialized
INFO - 2020-02-12 03:17:03 --> Helper loaded: form_helper
INFO - 2020-02-12 03:17:03 --> Form Validation Class Initialized
INFO - 2020-02-12 03:17:03 --> Language Class Initialized
INFO - 2020-02-12 03:17:03 --> Language Class Initialized
INFO - 2020-02-12 03:17:03 --> Language Class Initialized
ERROR - 2020-02-12 03:17:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:17:03 --> Language Class Initialized
ERROR - 2020-02-12 03:17:03 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-12 03:17:03 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-12 03:17:03 --> Loader Class Initialized
ERROR - 2020-02-12 03:17:03 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-12 03:17:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-12 03:17:03 --> Config Class Initialized
INFO - 2020-02-12 03:17:03 --> Hooks Class Initialized
ERROR - 2020-02-12 03:17:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-12 03:17:03 --> Helper loaded: url_helper
INFO - 2020-02-12 03:17:03 --> Config Class Initialized
INFO - 2020-02-12 03:17:03 --> Config Class Initialized
INFO - 2020-02-12 03:17:03 --> Hooks Class Initialized
INFO - 2020-02-12 03:17:03 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:17:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:03 --> Database Driver Class Initialized
INFO - 2020-02-12 03:17:03 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:17:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-12 03:17:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:17:03 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:03 --> Final output sent to browser
INFO - 2020-02-12 03:17:03 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:03 --> URI Class Initialized
DEBUG - 2020-02-12 03:17:03 --> Total execution time: 0.8067
INFO - 2020-02-12 03:17:03 --> URI Class Initialized
INFO - 2020-02-12 03:17:03 --> URI Class Initialized
INFO - 2020-02-12 03:17:03 --> Router Class Initialized
INFO - 2020-02-12 03:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:17:03 --> Router Class Initialized
INFO - 2020-02-12 03:17:03 --> Router Class Initialized
INFO - 2020-02-12 03:17:03 --> Output Class Initialized
INFO - 2020-02-12 03:17:03 --> Controller Class Initialized
INFO - 2020-02-12 03:17:03 --> Security Class Initialized
INFO - 2020-02-12 03:17:03 --> Output Class Initialized
INFO - 2020-02-12 03:17:03 --> Output Class Initialized
INFO - 2020-02-12 03:17:03 --> Model "M_tiket" initialized
DEBUG - 2020-02-12 03:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:03 --> Security Class Initialized
INFO - 2020-02-12 03:17:03 --> Security Class Initialized
INFO - 2020-02-12 03:17:03 --> Input Class Initialized
INFO - 2020-02-12 03:17:03 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-12 03:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:03 --> Input Class Initialized
INFO - 2020-02-12 03:17:03 --> Input Class Initialized
INFO - 2020-02-12 03:17:03 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:17:03 --> Language Class Initialized
INFO - 2020-02-12 03:17:03 --> Language Class Initialized
INFO - 2020-02-12 03:17:03 --> Language Class Initialized
ERROR - 2020-02-12 03:17:03 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-12 03:17:03 --> Helper loaded: form_helper
INFO - 2020-02-12 03:17:03 --> Form Validation Class Initialized
ERROR - 2020-02-12 03:17:03 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-12 03:17:03 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-12 03:17:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-12 03:17:03 --> Config Class Initialized
INFO - 2020-02-12 03:17:03 --> Hooks Class Initialized
ERROR - 2020-02-12 03:17:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-12 03:17:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-12 03:17:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:03 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:03 --> Final output sent to browser
DEBUG - 2020-02-12 03:17:03 --> Total execution time: 0.7255
INFO - 2020-02-12 03:17:03 --> URI Class Initialized
INFO - 2020-02-12 03:17:03 --> Router Class Initialized
INFO - 2020-02-12 03:17:03 --> Output Class Initialized
INFO - 2020-02-12 03:17:03 --> Security Class Initialized
DEBUG - 2020-02-12 03:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:03 --> Input Class Initialized
INFO - 2020-02-12 03:17:03 --> Language Class Initialized
ERROR - 2020-02-12 03:17:03 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-12 03:17:03 --> Config Class Initialized
INFO - 2020-02-12 03:17:03 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:17:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:03 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:03 --> URI Class Initialized
INFO - 2020-02-12 03:17:03 --> Router Class Initialized
INFO - 2020-02-12 03:17:03 --> Output Class Initialized
INFO - 2020-02-12 03:17:03 --> Security Class Initialized
DEBUG - 2020-02-12 03:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:03 --> Input Class Initialized
INFO - 2020-02-12 03:17:03 --> Language Class Initialized
ERROR - 2020-02-12 03:17:03 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-12 03:17:04 --> Config Class Initialized
INFO - 2020-02-12 03:17:04 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:17:04 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:04 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:04 --> URI Class Initialized
INFO - 2020-02-12 03:17:04 --> Router Class Initialized
INFO - 2020-02-12 03:17:04 --> Output Class Initialized
INFO - 2020-02-12 03:17:04 --> Security Class Initialized
DEBUG - 2020-02-12 03:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:04 --> Input Class Initialized
INFO - 2020-02-12 03:17:04 --> Language Class Initialized
ERROR - 2020-02-12 03:17:04 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-12 03:17:04 --> Config Class Initialized
INFO - 2020-02-12 03:17:04 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:17:04 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:04 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:04 --> URI Class Initialized
INFO - 2020-02-12 03:17:04 --> Router Class Initialized
INFO - 2020-02-12 03:17:04 --> Output Class Initialized
INFO - 2020-02-12 03:17:04 --> Security Class Initialized
DEBUG - 2020-02-12 03:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:04 --> Input Class Initialized
INFO - 2020-02-12 03:17:04 --> Language Class Initialized
ERROR - 2020-02-12 03:17:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:17:04 --> Config Class Initialized
INFO - 2020-02-12 03:17:04 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:17:04 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:04 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:04 --> URI Class Initialized
INFO - 2020-02-12 03:17:04 --> Router Class Initialized
INFO - 2020-02-12 03:17:04 --> Output Class Initialized
INFO - 2020-02-12 03:17:04 --> Security Class Initialized
DEBUG - 2020-02-12 03:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:04 --> Input Class Initialized
INFO - 2020-02-12 03:17:04 --> Language Class Initialized
ERROR - 2020-02-12 03:17:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:17:04 --> Config Class Initialized
INFO - 2020-02-12 03:17:04 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:17:04 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:04 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:04 --> URI Class Initialized
INFO - 2020-02-12 03:17:04 --> Router Class Initialized
INFO - 2020-02-12 03:17:05 --> Output Class Initialized
INFO - 2020-02-12 03:17:05 --> Security Class Initialized
DEBUG - 2020-02-12 03:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:05 --> Input Class Initialized
INFO - 2020-02-12 03:17:05 --> Language Class Initialized
ERROR - 2020-02-12 03:17:05 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-12 03:17:05 --> Config Class Initialized
INFO - 2020-02-12 03:17:05 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:17:05 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:05 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:05 --> URI Class Initialized
INFO - 2020-02-12 03:17:05 --> Router Class Initialized
INFO - 2020-02-12 03:17:05 --> Output Class Initialized
INFO - 2020-02-12 03:17:05 --> Security Class Initialized
DEBUG - 2020-02-12 03:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:05 --> Input Class Initialized
INFO - 2020-02-12 03:17:05 --> Language Class Initialized
ERROR - 2020-02-12 03:17:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-12 03:17:05 --> Config Class Initialized
INFO - 2020-02-12 03:17:05 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:17:05 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:05 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:05 --> URI Class Initialized
INFO - 2020-02-12 03:17:05 --> Router Class Initialized
INFO - 2020-02-12 03:17:05 --> Output Class Initialized
INFO - 2020-02-12 03:17:05 --> Security Class Initialized
DEBUG - 2020-02-12 03:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:05 --> Input Class Initialized
INFO - 2020-02-12 03:17:05 --> Language Class Initialized
ERROR - 2020-02-12 03:17:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-12 03:17:05 --> Config Class Initialized
INFO - 2020-02-12 03:17:05 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:17:05 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:17:05 --> Utf8 Class Initialized
INFO - 2020-02-12 03:17:05 --> URI Class Initialized
INFO - 2020-02-12 03:17:05 --> Router Class Initialized
INFO - 2020-02-12 03:17:05 --> Output Class Initialized
INFO - 2020-02-12 03:17:05 --> Security Class Initialized
DEBUG - 2020-02-12 03:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:17:05 --> Input Class Initialized
INFO - 2020-02-12 03:17:05 --> Language Class Initialized
ERROR - 2020-02-12 03:17:05 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-12 03:22:40 --> Config Class Initialized
INFO - 2020-02-12 03:22:40 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:22:40 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:22:40 --> Utf8 Class Initialized
INFO - 2020-02-12 03:22:40 --> URI Class Initialized
INFO - 2020-02-12 03:22:40 --> Router Class Initialized
INFO - 2020-02-12 03:22:40 --> Output Class Initialized
INFO - 2020-02-12 03:22:40 --> Security Class Initialized
DEBUG - 2020-02-12 03:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:22:40 --> Input Class Initialized
INFO - 2020-02-12 03:22:40 --> Language Class Initialized
INFO - 2020-02-12 03:22:40 --> Loader Class Initialized
INFO - 2020-02-12 03:22:40 --> Helper loaded: url_helper
INFO - 2020-02-12 03:22:40 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:22:40 --> Controller Class Initialized
INFO - 2020-02-12 03:22:40 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:22:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:22:40 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:22:40 --> Helper loaded: form_helper
INFO - 2020-02-12 03:22:40 --> Form Validation Class Initialized
INFO - 2020-02-12 03:22:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 03:22:40 --> Final output sent to browser
DEBUG - 2020-02-12 03:22:40 --> Total execution time: 0.5899
INFO - 2020-02-12 03:23:34 --> Config Class Initialized
INFO - 2020-02-12 03:23:34 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:23:34 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:23:34 --> Utf8 Class Initialized
INFO - 2020-02-12 03:23:34 --> URI Class Initialized
INFO - 2020-02-12 03:23:34 --> Router Class Initialized
INFO - 2020-02-12 03:23:34 --> Output Class Initialized
INFO - 2020-02-12 03:23:34 --> Security Class Initialized
DEBUG - 2020-02-12 03:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:23:34 --> Input Class Initialized
INFO - 2020-02-12 03:23:34 --> Language Class Initialized
INFO - 2020-02-12 03:23:34 --> Loader Class Initialized
INFO - 2020-02-12 03:23:34 --> Helper loaded: url_helper
INFO - 2020-02-12 03:23:34 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:23:34 --> Controller Class Initialized
INFO - 2020-02-12 03:23:34 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:23:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:23:34 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:23:34 --> Helper loaded: form_helper
INFO - 2020-02-12 03:23:34 --> Form Validation Class Initialized
INFO - 2020-02-12 03:23:34 --> Final output sent to browser
DEBUG - 2020-02-12 03:23:34 --> Total execution time: 0.5222
INFO - 2020-02-12 03:25:04 --> Config Class Initialized
INFO - 2020-02-12 03:25:05 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:05 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:05 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:05 --> URI Class Initialized
DEBUG - 2020-02-12 03:25:05 --> No URI present. Default controller set.
INFO - 2020-02-12 03:25:05 --> Router Class Initialized
INFO - 2020-02-12 03:25:05 --> Output Class Initialized
INFO - 2020-02-12 03:25:05 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:05 --> Input Class Initialized
INFO - 2020-02-12 03:25:05 --> Language Class Initialized
INFO - 2020-02-12 03:25:05 --> Loader Class Initialized
INFO - 2020-02-12 03:25:05 --> Helper loaded: url_helper
INFO - 2020-02-12 03:25:05 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:25:05 --> Controller Class Initialized
INFO - 2020-02-12 03:25:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-12 03:25:05 --> Pagination Class Initialized
INFO - 2020-02-12 03:25:05 --> Model "M_show" initialized
INFO - 2020-02-12 03:25:05 --> Helper loaded: form_helper
INFO - 2020-02-12 03:25:05 --> Form Validation Class Initialized
INFO - 2020-02-12 03:25:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-12 03:25:05 --> Final output sent to browser
INFO - 2020-02-12 03:25:05 --> Config Class Initialized
INFO - 2020-02-12 03:25:05 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:05 --> Total execution time: 0.6057
DEBUG - 2020-02-12 03:25:05 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:05 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:05 --> URI Class Initialized
DEBUG - 2020-02-12 03:25:05 --> No URI present. Default controller set.
INFO - 2020-02-12 03:25:05 --> Router Class Initialized
INFO - 2020-02-12 03:25:05 --> Output Class Initialized
INFO - 2020-02-12 03:25:05 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:05 --> Input Class Initialized
INFO - 2020-02-12 03:25:05 --> Language Class Initialized
INFO - 2020-02-12 03:25:05 --> Loader Class Initialized
INFO - 2020-02-12 03:25:06 --> Helper loaded: url_helper
INFO - 2020-02-12 03:25:06 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:25:06 --> Controller Class Initialized
INFO - 2020-02-12 03:25:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-12 03:25:06 --> Pagination Class Initialized
INFO - 2020-02-12 03:25:06 --> Model "M_show" initialized
INFO - 2020-02-12 03:25:06 --> Helper loaded: form_helper
INFO - 2020-02-12 03:25:06 --> Form Validation Class Initialized
INFO - 2020-02-12 03:25:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-12 03:25:06 --> Final output sent to browser
DEBUG - 2020-02-12 03:25:06 --> Total execution time: 0.6985
INFO - 2020-02-12 03:25:09 --> Config Class Initialized
INFO - 2020-02-12 03:25:09 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:09 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:09 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:09 --> URI Class Initialized
INFO - 2020-02-12 03:25:09 --> Router Class Initialized
INFO - 2020-02-12 03:25:09 --> Output Class Initialized
INFO - 2020-02-12 03:25:09 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:09 --> Input Class Initialized
INFO - 2020-02-12 03:25:10 --> Language Class Initialized
INFO - 2020-02-12 03:25:10 --> Loader Class Initialized
INFO - 2020-02-12 03:25:10 --> Helper loaded: url_helper
INFO - 2020-02-12 03:25:10 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:25:10 --> Controller Class Initialized
INFO - 2020-02-12 03:25:10 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:25:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:25:10 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:25:10 --> Helper loaded: form_helper
INFO - 2020-02-12 03:25:10 --> Form Validation Class Initialized
INFO - 2020-02-12 03:25:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:25:10 --> Final output sent to browser
DEBUG - 2020-02-12 03:25:10 --> Total execution time: 0.8725
INFO - 2020-02-12 03:25:10 --> Config Class Initialized
INFO - 2020-02-12 03:25:10 --> Config Class Initialized
INFO - 2020-02-12 03:25:10 --> Config Class Initialized
INFO - 2020-02-12 03:25:10 --> Config Class Initialized
INFO - 2020-02-12 03:25:10 --> Config Class Initialized
INFO - 2020-02-12 03:25:10 --> Hooks Class Initialized
INFO - 2020-02-12 03:25:10 --> Hooks Class Initialized
INFO - 2020-02-12 03:25:10 --> Hooks Class Initialized
INFO - 2020-02-12 03:25:10 --> Hooks Class Initialized
INFO - 2020-02-12 03:25:10 --> Hooks Class Initialized
INFO - 2020-02-12 03:25:10 --> Config Class Initialized
INFO - 2020-02-12 03:25:10 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:25:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:25:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:25:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:25:10 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:10 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:25:10 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:10 --> URI Class Initialized
INFO - 2020-02-12 03:25:10 --> URI Class Initialized
INFO - 2020-02-12 03:25:10 --> URI Class Initialized
INFO - 2020-02-12 03:25:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:10 --> URI Class Initialized
INFO - 2020-02-12 03:25:10 --> URI Class Initialized
INFO - 2020-02-12 03:25:10 --> Router Class Initialized
INFO - 2020-02-12 03:25:10 --> Router Class Initialized
INFO - 2020-02-12 03:25:10 --> Router Class Initialized
INFO - 2020-02-12 03:25:10 --> Router Class Initialized
INFO - 2020-02-12 03:25:10 --> Router Class Initialized
INFO - 2020-02-12 03:25:10 --> URI Class Initialized
INFO - 2020-02-12 03:25:10 --> Output Class Initialized
INFO - 2020-02-12 03:25:10 --> Output Class Initialized
INFO - 2020-02-12 03:25:10 --> Output Class Initialized
INFO - 2020-02-12 03:25:10 --> Output Class Initialized
INFO - 2020-02-12 03:25:10 --> Output Class Initialized
INFO - 2020-02-12 03:25:10 --> Router Class Initialized
INFO - 2020-02-12 03:25:10 --> Security Class Initialized
INFO - 2020-02-12 03:25:10 --> Output Class Initialized
INFO - 2020-02-12 03:25:10 --> Security Class Initialized
INFO - 2020-02-12 03:25:10 --> Security Class Initialized
INFO - 2020-02-12 03:25:10 --> Security Class Initialized
INFO - 2020-02-12 03:25:10 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:10 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:10 --> Input Class Initialized
INFO - 2020-02-12 03:25:10 --> Input Class Initialized
INFO - 2020-02-12 03:25:10 --> Input Class Initialized
INFO - 2020-02-12 03:25:10 --> Input Class Initialized
INFO - 2020-02-12 03:25:10 --> Input Class Initialized
DEBUG - 2020-02-12 03:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:10 --> Language Class Initialized
INFO - 2020-02-12 03:25:10 --> Input Class Initialized
INFO - 2020-02-12 03:25:10 --> Language Class Initialized
INFO - 2020-02-12 03:25:10 --> Language Class Initialized
ERROR - 2020-02-12 03:25:10 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-12 03:25:10 --> Language Class Initialized
INFO - 2020-02-12 03:25:10 --> Language Class Initialized
ERROR - 2020-02-12 03:25:10 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-12 03:25:10 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-12 03:25:10 --> Loader Class Initialized
INFO - 2020-02-12 03:25:10 --> Loader Class Initialized
INFO - 2020-02-12 03:25:10 --> Language Class Initialized
INFO - 2020-02-12 03:25:10 --> Config Class Initialized
INFO - 2020-02-12 03:25:10 --> Hooks Class Initialized
ERROR - 2020-02-12 03:25:10 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-12 03:25:10 --> Helper loaded: url_helper
INFO - 2020-02-12 03:25:10 --> Helper loaded: url_helper
INFO - 2020-02-12 03:25:10 --> Config Class Initialized
INFO - 2020-02-12 03:25:10 --> Config Class Initialized
INFO - 2020-02-12 03:25:10 --> Hooks Class Initialized
INFO - 2020-02-12 03:25:10 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:10 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:10 --> Database Driver Class Initialized
INFO - 2020-02-12 03:25:10 --> Database Driver Class Initialized
INFO - 2020-02-12 03:25:10 --> Config Class Initialized
INFO - 2020-02-12 03:25:10 --> Hooks Class Initialized
INFO - 2020-02-12 03:25:10 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:25:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:25:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:25:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:10 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:25:10 --> URI Class Initialized
DEBUG - 2020-02-12 03:25:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:25:11 --> Controller Class Initialized
INFO - 2020-02-12 03:25:11 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:11 --> URI Class Initialized
INFO - 2020-02-12 03:25:11 --> URI Class Initialized
INFO - 2020-02-12 03:25:11 --> Router Class Initialized
INFO - 2020-02-12 03:25:11 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:25:11 --> URI Class Initialized
INFO - 2020-02-12 03:25:11 --> Output Class Initialized
INFO - 2020-02-12 03:25:11 --> Router Class Initialized
INFO - 2020-02-12 03:25:11 --> Router Class Initialized
INFO - 2020-02-12 03:25:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:25:11 --> Security Class Initialized
INFO - 2020-02-12 03:25:11 --> Router Class Initialized
INFO - 2020-02-12 03:25:11 --> Output Class Initialized
INFO - 2020-02-12 03:25:11 --> Output Class Initialized
INFO - 2020-02-12 03:25:11 --> Model "M_pesan" initialized
DEBUG - 2020-02-12 03:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:11 --> Security Class Initialized
INFO - 2020-02-12 03:25:11 --> Security Class Initialized
INFO - 2020-02-12 03:25:11 --> Output Class Initialized
INFO - 2020-02-12 03:25:11 --> Input Class Initialized
INFO - 2020-02-12 03:25:11 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:11 --> Helper loaded: form_helper
INFO - 2020-02-12 03:25:11 --> Input Class Initialized
INFO - 2020-02-12 03:25:11 --> Input Class Initialized
INFO - 2020-02-12 03:25:11 --> Form Validation Class Initialized
INFO - 2020-02-12 03:25:11 --> Language Class Initialized
DEBUG - 2020-02-12 03:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:11 --> Input Class Initialized
INFO - 2020-02-12 03:25:11 --> Language Class Initialized
INFO - 2020-02-12 03:25:11 --> Language Class Initialized
ERROR - 2020-02-12 03:25:11 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-12 03:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 03:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-12 03:25:11 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-12 03:25:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:25:11 --> Language Class Initialized
INFO - 2020-02-12 03:25:11 --> Config Class Initialized
INFO - 2020-02-12 03:25:11 --> Hooks Class Initialized
INFO - 2020-02-12 03:25:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-12 03:25:11 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-12 03:25:11 --> Config Class Initialized
INFO - 2020-02-12 03:25:11 --> Config Class Initialized
INFO - 2020-02-12 03:25:11 --> Hooks Class Initialized
INFO - 2020-02-12 03:25:11 --> Final output sent to browser
INFO - 2020-02-12 03:25:11 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:11 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:11 --> Config Class Initialized
INFO - 2020-02-12 03:25:11 --> Hooks Class Initialized
INFO - 2020-02-12 03:25:11 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:25:11 --> Total execution time: 0.7582
DEBUG - 2020-02-12 03:25:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:25:11 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:11 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:11 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:25:11 --> URI Class Initialized
DEBUG - 2020-02-12 03:25:11 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:11 --> Controller Class Initialized
INFO - 2020-02-12 03:25:11 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:11 --> Router Class Initialized
INFO - 2020-02-12 03:25:11 --> URI Class Initialized
INFO - 2020-02-12 03:25:11 --> URI Class Initialized
INFO - 2020-02-12 03:25:11 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:25:11 --> URI Class Initialized
INFO - 2020-02-12 03:25:11 --> Router Class Initialized
INFO - 2020-02-12 03:25:11 --> Router Class Initialized
INFO - 2020-02-12 03:25:11 --> Output Class Initialized
INFO - 2020-02-12 03:25:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:25:11 --> Security Class Initialized
INFO - 2020-02-12 03:25:11 --> Router Class Initialized
INFO - 2020-02-12 03:25:11 --> Output Class Initialized
INFO - 2020-02-12 03:25:11 --> Output Class Initialized
INFO - 2020-02-12 03:25:11 --> Security Class Initialized
INFO - 2020-02-12 03:25:11 --> Security Class Initialized
INFO - 2020-02-12 03:25:11 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:25:11 --> Output Class Initialized
DEBUG - 2020-02-12 03:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:11 --> Security Class Initialized
INFO - 2020-02-12 03:25:11 --> Input Class Initialized
DEBUG - 2020-02-12 03:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:11 --> Helper loaded: form_helper
INFO - 2020-02-12 03:25:11 --> Input Class Initialized
INFO - 2020-02-12 03:25:11 --> Input Class Initialized
INFO - 2020-02-12 03:25:11 --> Form Validation Class Initialized
INFO - 2020-02-12 03:25:11 --> Language Class Initialized
DEBUG - 2020-02-12 03:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:11 --> Input Class Initialized
INFO - 2020-02-12 03:25:11 --> Language Class Initialized
INFO - 2020-02-12 03:25:11 --> Language Class Initialized
ERROR - 2020-02-12 03:25:11 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-12 03:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 03:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-12 03:25:11 --> Language Class Initialized
ERROR - 2020-02-12 03:25:11 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-12 03:25:11 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-12 03:25:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-12 03:25:11 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-12 03:25:11 --> Final output sent to browser
INFO - 2020-02-12 03:25:11 --> Config Class Initialized
INFO - 2020-02-12 03:25:11 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:11 --> Total execution time: 1.1275
DEBUG - 2020-02-12 03:25:11 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:11 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:11 --> URI Class Initialized
INFO - 2020-02-12 03:25:11 --> Router Class Initialized
INFO - 2020-02-12 03:25:11 --> Output Class Initialized
INFO - 2020-02-12 03:25:11 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:11 --> Input Class Initialized
INFO - 2020-02-12 03:25:11 --> Language Class Initialized
ERROR - 2020-02-12 03:25:11 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-12 03:25:12 --> Config Class Initialized
INFO - 2020-02-12 03:25:12 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:12 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:12 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:12 --> URI Class Initialized
INFO - 2020-02-12 03:25:12 --> Router Class Initialized
INFO - 2020-02-12 03:25:12 --> Output Class Initialized
INFO - 2020-02-12 03:25:12 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:12 --> Input Class Initialized
INFO - 2020-02-12 03:25:12 --> Language Class Initialized
ERROR - 2020-02-12 03:25:12 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-12 03:25:12 --> Config Class Initialized
INFO - 2020-02-12 03:25:12 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:12 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:12 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:12 --> URI Class Initialized
INFO - 2020-02-12 03:25:12 --> Router Class Initialized
INFO - 2020-02-12 03:25:12 --> Output Class Initialized
INFO - 2020-02-12 03:25:12 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:12 --> Input Class Initialized
INFO - 2020-02-12 03:25:12 --> Language Class Initialized
ERROR - 2020-02-12 03:25:12 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-12 03:25:12 --> Config Class Initialized
INFO - 2020-02-12 03:25:12 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:12 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:12 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:12 --> URI Class Initialized
INFO - 2020-02-12 03:25:12 --> Router Class Initialized
INFO - 2020-02-12 03:25:12 --> Output Class Initialized
INFO - 2020-02-12 03:25:12 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:12 --> Input Class Initialized
INFO - 2020-02-12 03:25:12 --> Language Class Initialized
ERROR - 2020-02-12 03:25:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:25:12 --> Config Class Initialized
INFO - 2020-02-12 03:25:12 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:13 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:13 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:13 --> URI Class Initialized
INFO - 2020-02-12 03:25:13 --> Router Class Initialized
INFO - 2020-02-12 03:25:13 --> Output Class Initialized
INFO - 2020-02-12 03:25:13 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:13 --> Input Class Initialized
INFO - 2020-02-12 03:25:13 --> Language Class Initialized
ERROR - 2020-02-12 03:25:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:25:13 --> Config Class Initialized
INFO - 2020-02-12 03:25:13 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:13 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:13 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:13 --> URI Class Initialized
INFO - 2020-02-12 03:25:13 --> Router Class Initialized
INFO - 2020-02-12 03:25:13 --> Output Class Initialized
INFO - 2020-02-12 03:25:13 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:13 --> Input Class Initialized
INFO - 2020-02-12 03:25:13 --> Language Class Initialized
ERROR - 2020-02-12 03:25:13 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-12 03:25:13 --> Config Class Initialized
INFO - 2020-02-12 03:25:13 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:13 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:13 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:13 --> URI Class Initialized
INFO - 2020-02-12 03:25:13 --> Router Class Initialized
INFO - 2020-02-12 03:25:13 --> Output Class Initialized
INFO - 2020-02-12 03:25:13 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:13 --> Input Class Initialized
INFO - 2020-02-12 03:25:13 --> Language Class Initialized
ERROR - 2020-02-12 03:25:13 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-12 03:25:13 --> Config Class Initialized
INFO - 2020-02-12 03:25:13 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:13 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:13 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:14 --> URI Class Initialized
INFO - 2020-02-12 03:25:14 --> Router Class Initialized
INFO - 2020-02-12 03:25:14 --> Output Class Initialized
INFO - 2020-02-12 03:25:14 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:14 --> Input Class Initialized
INFO - 2020-02-12 03:25:14 --> Language Class Initialized
ERROR - 2020-02-12 03:25:14 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-12 03:25:14 --> Config Class Initialized
INFO - 2020-02-12 03:25:14 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:14 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:14 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:14 --> URI Class Initialized
INFO - 2020-02-12 03:25:14 --> Router Class Initialized
INFO - 2020-02-12 03:25:14 --> Output Class Initialized
INFO - 2020-02-12 03:25:14 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:14 --> Input Class Initialized
INFO - 2020-02-12 03:25:14 --> Language Class Initialized
ERROR - 2020-02-12 03:25:14 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-12 03:25:35 --> Config Class Initialized
INFO - 2020-02-12 03:25:35 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:35 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:35 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:35 --> URI Class Initialized
INFO - 2020-02-12 03:25:35 --> Router Class Initialized
INFO - 2020-02-12 03:25:35 --> Output Class Initialized
INFO - 2020-02-12 03:25:35 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:35 --> Input Class Initialized
INFO - 2020-02-12 03:25:35 --> Language Class Initialized
INFO - 2020-02-12 03:25:35 --> Loader Class Initialized
INFO - 2020-02-12 03:25:35 --> Helper loaded: url_helper
INFO - 2020-02-12 03:25:35 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:25:35 --> Controller Class Initialized
INFO - 2020-02-12 03:25:35 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:25:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:25:35 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:25:35 --> Helper loaded: form_helper
INFO - 2020-02-12 03:25:35 --> Form Validation Class Initialized
INFO - 2020-02-12 03:25:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 03:25:36 --> Final output sent to browser
DEBUG - 2020-02-12 03:25:36 --> Total execution time: 0.5637
INFO - 2020-02-12 03:25:39 --> Config Class Initialized
INFO - 2020-02-12 03:25:40 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:40 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:40 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:40 --> URI Class Initialized
INFO - 2020-02-12 03:25:40 --> Router Class Initialized
INFO - 2020-02-12 03:25:40 --> Output Class Initialized
INFO - 2020-02-12 03:25:40 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:40 --> Input Class Initialized
INFO - 2020-02-12 03:25:40 --> Language Class Initialized
INFO - 2020-02-12 03:25:40 --> Loader Class Initialized
INFO - 2020-02-12 03:25:40 --> Helper loaded: url_helper
INFO - 2020-02-12 03:25:40 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:25:40 --> Controller Class Initialized
INFO - 2020-02-12 03:25:40 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:25:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:25:40 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:25:40 --> Helper loaded: form_helper
INFO - 2020-02-12 03:25:40 --> Form Validation Class Initialized
ERROR - 2020-02-12 03:25:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 28
INFO - 2020-02-12 03:25:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 03:25:40 --> Final output sent to browser
DEBUG - 2020-02-12 03:25:40 --> Total execution time: 0.6619
INFO - 2020-02-12 03:25:52 --> Config Class Initialized
INFO - 2020-02-12 03:25:52 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:25:52 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:25:52 --> Utf8 Class Initialized
INFO - 2020-02-12 03:25:52 --> URI Class Initialized
INFO - 2020-02-12 03:25:52 --> Router Class Initialized
INFO - 2020-02-12 03:25:52 --> Output Class Initialized
INFO - 2020-02-12 03:25:53 --> Security Class Initialized
DEBUG - 2020-02-12 03:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:25:53 --> Input Class Initialized
INFO - 2020-02-12 03:25:53 --> Language Class Initialized
INFO - 2020-02-12 03:25:53 --> Loader Class Initialized
INFO - 2020-02-12 03:25:53 --> Helper loaded: url_helper
INFO - 2020-02-12 03:25:53 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:25:53 --> Controller Class Initialized
INFO - 2020-02-12 03:25:53 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:25:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:25:53 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:25:53 --> Helper loaded: form_helper
INFO - 2020-02-12 03:25:53 --> Form Validation Class Initialized
INFO - 2020-02-12 03:25:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 03:25:53 --> Final output sent to browser
DEBUG - 2020-02-12 03:25:53 --> Total execution time: 0.5640
INFO - 2020-02-12 03:35:48 --> Config Class Initialized
INFO - 2020-02-12 03:35:48 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:35:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:35:48 --> Utf8 Class Initialized
INFO - 2020-02-12 03:35:48 --> URI Class Initialized
INFO - 2020-02-12 03:35:48 --> Router Class Initialized
INFO - 2020-02-12 03:35:48 --> Output Class Initialized
INFO - 2020-02-12 03:35:48 --> Security Class Initialized
DEBUG - 2020-02-12 03:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:35:48 --> Input Class Initialized
INFO - 2020-02-12 03:35:48 --> Language Class Initialized
INFO - 2020-02-12 03:35:48 --> Loader Class Initialized
INFO - 2020-02-12 03:35:48 --> Helper loaded: url_helper
INFO - 2020-02-12 03:35:48 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:35:48 --> Controller Class Initialized
INFO - 2020-02-12 03:35:48 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:35:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:35:48 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:35:48 --> Helper loaded: form_helper
INFO - 2020-02-12 03:35:48 --> Form Validation Class Initialized
INFO - 2020-02-12 03:35:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 03:35:48 --> Final output sent to browser
DEBUG - 2020-02-12 03:35:48 --> Total execution time: 0.5717
INFO - 2020-02-12 03:36:27 --> Config Class Initialized
INFO - 2020-02-12 03:36:27 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:36:27 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:36:27 --> Utf8 Class Initialized
INFO - 2020-02-12 03:36:27 --> URI Class Initialized
INFO - 2020-02-12 03:36:27 --> Router Class Initialized
INFO - 2020-02-12 03:36:27 --> Output Class Initialized
INFO - 2020-02-12 03:36:27 --> Security Class Initialized
DEBUG - 2020-02-12 03:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:36:27 --> Input Class Initialized
INFO - 2020-02-12 03:36:27 --> Language Class Initialized
INFO - 2020-02-12 03:36:27 --> Loader Class Initialized
INFO - 2020-02-12 03:36:27 --> Helper loaded: url_helper
INFO - 2020-02-12 03:36:27 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:36:28 --> Controller Class Initialized
INFO - 2020-02-12 03:36:28 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:36:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:36:28 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:36:28 --> Helper loaded: form_helper
INFO - 2020-02-12 03:36:28 --> Form Validation Class Initialized
INFO - 2020-02-12 03:36:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 03:36:28 --> Final output sent to browser
DEBUG - 2020-02-12 03:36:28 --> Total execution time: 1.2373
INFO - 2020-02-12 03:37:15 --> Config Class Initialized
INFO - 2020-02-12 03:37:15 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:37:15 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:37:15 --> Utf8 Class Initialized
INFO - 2020-02-12 03:37:15 --> URI Class Initialized
INFO - 2020-02-12 03:37:15 --> Router Class Initialized
INFO - 2020-02-12 03:37:15 --> Output Class Initialized
INFO - 2020-02-12 03:37:15 --> Security Class Initialized
DEBUG - 2020-02-12 03:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:37:15 --> Input Class Initialized
INFO - 2020-02-12 03:37:15 --> Language Class Initialized
INFO - 2020-02-12 03:37:15 --> Loader Class Initialized
INFO - 2020-02-12 03:37:15 --> Helper loaded: url_helper
INFO - 2020-02-12 03:37:15 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:37:15 --> Controller Class Initialized
INFO - 2020-02-12 03:37:15 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:37:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:37:15 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:37:15 --> Helper loaded: form_helper
INFO - 2020-02-12 03:37:15 --> Form Validation Class Initialized
INFO - 2020-02-12 03:37:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 03:37:15 --> Final output sent to browser
DEBUG - 2020-02-12 03:37:15 --> Total execution time: 0.5431
INFO - 2020-02-12 03:37:50 --> Config Class Initialized
INFO - 2020-02-12 03:37:50 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:37:50 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:37:50 --> Utf8 Class Initialized
INFO - 2020-02-12 03:37:50 --> URI Class Initialized
INFO - 2020-02-12 03:37:50 --> Router Class Initialized
INFO - 2020-02-12 03:37:50 --> Output Class Initialized
INFO - 2020-02-12 03:37:50 --> Security Class Initialized
DEBUG - 2020-02-12 03:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:37:50 --> Input Class Initialized
INFO - 2020-02-12 03:37:50 --> Language Class Initialized
INFO - 2020-02-12 03:37:50 --> Loader Class Initialized
INFO - 2020-02-12 03:37:50 --> Helper loaded: url_helper
INFO - 2020-02-12 03:37:50 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:37:50 --> Controller Class Initialized
INFO - 2020-02-12 03:37:50 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:37:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:37:50 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:37:50 --> Helper loaded: form_helper
INFO - 2020-02-12 03:37:50 --> Form Validation Class Initialized
INFO - 2020-02-12 03:37:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 03:37:50 --> Final output sent to browser
DEBUG - 2020-02-12 03:37:50 --> Total execution time: 0.5409
INFO - 2020-02-12 03:38:05 --> Config Class Initialized
INFO - 2020-02-12 03:38:05 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:38:05 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:38:05 --> Utf8 Class Initialized
INFO - 2020-02-12 03:38:05 --> URI Class Initialized
INFO - 2020-02-12 03:38:05 --> Router Class Initialized
INFO - 2020-02-12 03:38:05 --> Output Class Initialized
INFO - 2020-02-12 03:38:05 --> Security Class Initialized
DEBUG - 2020-02-12 03:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:38:05 --> Input Class Initialized
INFO - 2020-02-12 03:38:05 --> Language Class Initialized
INFO - 2020-02-12 03:38:05 --> Loader Class Initialized
INFO - 2020-02-12 03:38:05 --> Helper loaded: url_helper
INFO - 2020-02-12 03:38:05 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:38:05 --> Controller Class Initialized
INFO - 2020-02-12 03:38:05 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:38:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:38:05 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:38:05 --> Helper loaded: form_helper
INFO - 2020-02-12 03:38:05 --> Form Validation Class Initialized
INFO - 2020-02-12 03:38:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 03:38:06 --> Final output sent to browser
DEBUG - 2020-02-12 03:38:06 --> Total execution time: 0.5412
INFO - 2020-02-12 03:39:13 --> Config Class Initialized
INFO - 2020-02-12 03:39:13 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:39:13 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:39:13 --> Utf8 Class Initialized
INFO - 2020-02-12 03:39:13 --> URI Class Initialized
INFO - 2020-02-12 03:39:13 --> Router Class Initialized
INFO - 2020-02-12 03:39:13 --> Output Class Initialized
INFO - 2020-02-12 03:39:13 --> Security Class Initialized
DEBUG - 2020-02-12 03:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:39:13 --> Input Class Initialized
INFO - 2020-02-12 03:39:13 --> Language Class Initialized
INFO - 2020-02-12 03:39:13 --> Loader Class Initialized
INFO - 2020-02-12 03:39:13 --> Helper loaded: url_helper
INFO - 2020-02-12 03:39:13 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:39:13 --> Controller Class Initialized
INFO - 2020-02-12 03:39:13 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:39:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:39:13 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:39:13 --> Helper loaded: form_helper
INFO - 2020-02-12 03:39:13 --> Form Validation Class Initialized
INFO - 2020-02-12 03:39:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 03:39:13 --> Final output sent to browser
DEBUG - 2020-02-12 03:39:13 --> Total execution time: 0.5517
INFO - 2020-02-12 03:42:24 --> Config Class Initialized
INFO - 2020-02-12 03:42:24 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:42:24 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:42:24 --> Utf8 Class Initialized
INFO - 2020-02-12 03:42:24 --> URI Class Initialized
INFO - 2020-02-12 03:42:24 --> Router Class Initialized
INFO - 2020-02-12 03:42:24 --> Output Class Initialized
INFO - 2020-02-12 03:42:24 --> Security Class Initialized
DEBUG - 2020-02-12 03:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:42:24 --> Input Class Initialized
INFO - 2020-02-12 03:42:24 --> Language Class Initialized
ERROR - 2020-02-12 03:42:24 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE), expecting ',' or ')' C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 32
INFO - 2020-02-12 03:42:40 --> Config Class Initialized
INFO - 2020-02-12 03:42:40 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:42:40 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:42:40 --> Utf8 Class Initialized
INFO - 2020-02-12 03:42:40 --> URI Class Initialized
INFO - 2020-02-12 03:42:40 --> Router Class Initialized
INFO - 2020-02-12 03:42:40 --> Output Class Initialized
INFO - 2020-02-12 03:42:40 --> Security Class Initialized
DEBUG - 2020-02-12 03:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:42:40 --> Input Class Initialized
INFO - 2020-02-12 03:42:40 --> Language Class Initialized
INFO - 2020-02-12 03:42:40 --> Loader Class Initialized
INFO - 2020-02-12 03:42:40 --> Helper loaded: url_helper
INFO - 2020-02-12 03:42:40 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:42:41 --> Controller Class Initialized
INFO - 2020-02-12 03:42:41 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:42:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:42:41 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:42:41 --> Helper loaded: form_helper
INFO - 2020-02-12 03:42:41 --> Form Validation Class Initialized
ERROR - 2020-02-12 03:42:41 --> Severity: Notice --> Undefined index: bank C:\xampp\htdocs\roadshow\application\models\M_tiket.php 74
ERROR - 2020-02-12 03:42:41 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 30
ERROR - 2020-02-12 03:42:41 --> Severity: Notice --> Undefined index: jumlah_pesanan C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
INFO - 2020-02-12 03:42:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 03:42:41 --> Final output sent to browser
DEBUG - 2020-02-12 03:42:41 --> Total execution time: 0.6440
INFO - 2020-02-12 03:43:36 --> Config Class Initialized
INFO - 2020-02-12 03:43:36 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:43:36 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:36 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:36 --> URI Class Initialized
INFO - 2020-02-12 03:43:36 --> Router Class Initialized
INFO - 2020-02-12 03:43:36 --> Output Class Initialized
INFO - 2020-02-12 03:43:36 --> Security Class Initialized
DEBUG - 2020-02-12 03:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:36 --> Input Class Initialized
INFO - 2020-02-12 03:43:36 --> Language Class Initialized
INFO - 2020-02-12 03:43:36 --> Loader Class Initialized
INFO - 2020-02-12 03:43:36 --> Helper loaded: url_helper
INFO - 2020-02-12 03:43:36 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:43:36 --> Controller Class Initialized
INFO - 2020-02-12 03:43:36 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:43:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:43:37 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:43:37 --> Helper loaded: form_helper
INFO - 2020-02-12 03:43:37 --> Form Validation Class Initialized
INFO - 2020-02-12 03:43:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:43:37 --> Final output sent to browser
DEBUG - 2020-02-12 03:43:37 --> Total execution time: 0.8043
INFO - 2020-02-12 03:43:37 --> Config Class Initialized
INFO - 2020-02-12 03:43:37 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:43:37 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:37 --> Config Class Initialized
INFO - 2020-02-12 03:43:37 --> Hooks Class Initialized
INFO - 2020-02-12 03:43:37 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:37 --> URI Class Initialized
DEBUG - 2020-02-12 03:43:37 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:37 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:37 --> Router Class Initialized
INFO - 2020-02-12 03:43:37 --> URI Class Initialized
INFO - 2020-02-12 03:43:37 --> Output Class Initialized
INFO - 2020-02-12 03:43:37 --> Security Class Initialized
INFO - 2020-02-12 03:43:37 --> Router Class Initialized
DEBUG - 2020-02-12 03:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:37 --> Output Class Initialized
INFO - 2020-02-12 03:43:37 --> Input Class Initialized
INFO - 2020-02-12 03:43:37 --> Security Class Initialized
INFO - 2020-02-12 03:43:37 --> Language Class Initialized
DEBUG - 2020-02-12 03:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:37 --> Input Class Initialized
INFO - 2020-02-12 03:43:37 --> Loader Class Initialized
INFO - 2020-02-12 03:43:37 --> Language Class Initialized
INFO - 2020-02-12 03:43:37 --> Helper loaded: url_helper
INFO - 2020-02-12 03:43:37 --> Loader Class Initialized
INFO - 2020-02-12 03:43:37 --> Database Driver Class Initialized
INFO - 2020-02-12 03:43:37 --> Helper loaded: url_helper
DEBUG - 2020-02-12 03:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:43:37 --> Database Driver Class Initialized
INFO - 2020-02-12 03:43:37 --> Controller Class Initialized
DEBUG - 2020-02-12 03:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:43:37 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:43:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:43:37 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:43:37 --> Helper loaded: form_helper
INFO - 2020-02-12 03:43:37 --> Form Validation Class Initialized
ERROR - 2020-02-12 03:43:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 03:43:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-12 03:43:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:43:38 --> Final output sent to browser
DEBUG - 2020-02-12 03:43:38 --> Total execution time: 0.8073
INFO - 2020-02-12 03:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:43:38 --> Controller Class Initialized
INFO - 2020-02-12 03:43:38 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:43:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:43:38 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:43:38 --> Helper loaded: form_helper
INFO - 2020-02-12 03:43:38 --> Form Validation Class Initialized
ERROR - 2020-02-12 03:43:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 03:43:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-12 03:43:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:43:38 --> Final output sent to browser
DEBUG - 2020-02-12 03:43:38 --> Total execution time: 1.2403
INFO - 2020-02-12 03:43:44 --> Config Class Initialized
INFO - 2020-02-12 03:43:44 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:43:44 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:44 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:44 --> URI Class Initialized
INFO - 2020-02-12 03:43:44 --> Router Class Initialized
INFO - 2020-02-12 03:43:44 --> Output Class Initialized
INFO - 2020-02-12 03:43:44 --> Security Class Initialized
DEBUG - 2020-02-12 03:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:44 --> Input Class Initialized
INFO - 2020-02-12 03:43:45 --> Language Class Initialized
INFO - 2020-02-12 03:43:45 --> Loader Class Initialized
INFO - 2020-02-12 03:43:45 --> Helper loaded: url_helper
INFO - 2020-02-12 03:43:45 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:43:45 --> Controller Class Initialized
INFO - 2020-02-12 03:43:45 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:43:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:43:45 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:43:45 --> Helper loaded: form_helper
INFO - 2020-02-12 03:43:45 --> Form Validation Class Initialized
INFO - 2020-02-12 03:43:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:43:45 --> Final output sent to browser
INFO - 2020-02-12 03:43:45 --> Config Class Initialized
INFO - 2020-02-12 03:43:45 --> Hooks Class Initialized
INFO - 2020-02-12 03:43:45 --> Config Class Initialized
DEBUG - 2020-02-12 03:43:45 --> Total execution time: 0.8837
INFO - 2020-02-12 03:43:45 --> Config Class Initialized
INFO - 2020-02-12 03:43:45 --> Config Class Initialized
INFO - 2020-02-12 03:43:45 --> Config Class Initialized
INFO - 2020-02-12 03:43:45 --> Hooks Class Initialized
INFO - 2020-02-12 03:43:45 --> Hooks Class Initialized
INFO - 2020-02-12 03:43:45 --> Hooks Class Initialized
INFO - 2020-02-12 03:43:45 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:43:45 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:45 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:43:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:43:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:43:45 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:45 --> Config Class Initialized
DEBUG - 2020-02-12 03:43:45 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:45 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:45 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:45 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:45 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:45 --> Hooks Class Initialized
INFO - 2020-02-12 03:43:45 --> URI Class Initialized
INFO - 2020-02-12 03:43:45 --> URI Class Initialized
INFO - 2020-02-12 03:43:45 --> URI Class Initialized
INFO - 2020-02-12 03:43:45 --> URI Class Initialized
INFO - 2020-02-12 03:43:45 --> URI Class Initialized
DEBUG - 2020-02-12 03:43:45 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:45 --> Router Class Initialized
INFO - 2020-02-12 03:43:45 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:45 --> Router Class Initialized
INFO - 2020-02-12 03:43:45 --> Router Class Initialized
INFO - 2020-02-12 03:43:45 --> Router Class Initialized
INFO - 2020-02-12 03:43:45 --> Router Class Initialized
INFO - 2020-02-12 03:43:45 --> Output Class Initialized
INFO - 2020-02-12 03:43:45 --> Output Class Initialized
INFO - 2020-02-12 03:43:45 --> Output Class Initialized
INFO - 2020-02-12 03:43:45 --> Output Class Initialized
INFO - 2020-02-12 03:43:45 --> Output Class Initialized
INFO - 2020-02-12 03:43:45 --> URI Class Initialized
INFO - 2020-02-12 03:43:45 --> Security Class Initialized
INFO - 2020-02-12 03:43:45 --> Security Class Initialized
INFO - 2020-02-12 03:43:45 --> Security Class Initialized
DEBUG - 2020-02-12 03:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:45 --> Security Class Initialized
INFO - 2020-02-12 03:43:45 --> Security Class Initialized
INFO - 2020-02-12 03:43:45 --> Router Class Initialized
INFO - 2020-02-12 03:43:45 --> Input Class Initialized
DEBUG - 2020-02-12 03:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:45 --> Output Class Initialized
INFO - 2020-02-12 03:43:45 --> Input Class Initialized
INFO - 2020-02-12 03:43:45 --> Input Class Initialized
INFO - 2020-02-12 03:43:45 --> Input Class Initialized
INFO - 2020-02-12 03:43:45 --> Input Class Initialized
INFO - 2020-02-12 03:43:45 --> Language Class Initialized
INFO - 2020-02-12 03:43:45 --> Security Class Initialized
INFO - 2020-02-12 03:43:45 --> Language Class Initialized
INFO - 2020-02-12 03:43:45 --> Language Class Initialized
INFO - 2020-02-12 03:43:45 --> Language Class Initialized
ERROR - 2020-02-12 03:43:45 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-12 03:43:45 --> Language Class Initialized
DEBUG - 2020-02-12 03:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:45 --> Input Class Initialized
ERROR - 2020-02-12 03:43:45 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-12 03:43:45 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-12 03:43:45 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-12 03:43:45 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-12 03:43:45 --> Config Class Initialized
INFO - 2020-02-12 03:43:45 --> Hooks Class Initialized
INFO - 2020-02-12 03:43:45 --> Language Class Initialized
INFO - 2020-02-12 03:43:45 --> Config Class Initialized
INFO - 2020-02-12 03:43:45 --> Config Class Initialized
INFO - 2020-02-12 03:43:45 --> Config Class Initialized
INFO - 2020-02-12 03:43:45 --> Hooks Class Initialized
INFO - 2020-02-12 03:43:45 --> Hooks Class Initialized
INFO - 2020-02-12 03:43:45 --> Hooks Class Initialized
ERROR - 2020-02-12 03:43:45 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:43:45 --> Config Class Initialized
DEBUG - 2020-02-12 03:43:45 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:45 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:45 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:43:45 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:45 --> Config Class Initialized
DEBUG - 2020-02-12 03:43:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:43:45 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:46 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:46 --> Hooks Class Initialized
INFO - 2020-02-12 03:43:46 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:46 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:46 --> URI Class Initialized
DEBUG - 2020-02-12 03:43:46 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:46 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:46 --> URI Class Initialized
INFO - 2020-02-12 03:43:46 --> URI Class Initialized
INFO - 2020-02-12 03:43:46 --> URI Class Initialized
DEBUG - 2020-02-12 03:43:46 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:46 --> Router Class Initialized
INFO - 2020-02-12 03:43:46 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:46 --> Router Class Initialized
INFO - 2020-02-12 03:43:46 --> Router Class Initialized
INFO - 2020-02-12 03:43:46 --> Router Class Initialized
INFO - 2020-02-12 03:43:46 --> URI Class Initialized
INFO - 2020-02-12 03:43:46 --> Output Class Initialized
INFO - 2020-02-12 03:43:46 --> URI Class Initialized
INFO - 2020-02-12 03:43:46 --> Security Class Initialized
INFO - 2020-02-12 03:43:46 --> Output Class Initialized
INFO - 2020-02-12 03:43:46 --> Router Class Initialized
INFO - 2020-02-12 03:43:46 --> Output Class Initialized
INFO - 2020-02-12 03:43:46 --> Output Class Initialized
INFO - 2020-02-12 03:43:46 --> Security Class Initialized
INFO - 2020-02-12 03:43:46 --> Router Class Initialized
INFO - 2020-02-12 03:43:46 --> Output Class Initialized
DEBUG - 2020-02-12 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:46 --> Security Class Initialized
INFO - 2020-02-12 03:43:46 --> Security Class Initialized
DEBUG - 2020-02-12 03:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:46 --> Input Class Initialized
DEBUG - 2020-02-12 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:46 --> Output Class Initialized
INFO - 2020-02-12 03:43:46 --> Security Class Initialized
INFO - 2020-02-12 03:43:46 --> Input Class Initialized
INFO - 2020-02-12 03:43:46 --> Input Class Initialized
INFO - 2020-02-12 03:43:46 --> Input Class Initialized
INFO - 2020-02-12 03:43:46 --> Language Class Initialized
INFO - 2020-02-12 03:43:46 --> Security Class Initialized
DEBUG - 2020-02-12 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:46 --> Input Class Initialized
INFO - 2020-02-12 03:43:46 --> Language Class Initialized
ERROR - 2020-02-12 03:43:46 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:43:46 --> Language Class Initialized
DEBUG - 2020-02-12 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:46 --> Language Class Initialized
INFO - 2020-02-12 03:43:46 --> Input Class Initialized
INFO - 2020-02-12 03:43:46 --> Language Class Initialized
ERROR - 2020-02-12 03:43:46 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-12 03:43:46 --> Loader Class Initialized
INFO - 2020-02-12 03:43:46 --> Loader Class Initialized
INFO - 2020-02-12 03:43:46 --> Config Class Initialized
INFO - 2020-02-12 03:43:46 --> Hooks Class Initialized
INFO - 2020-02-12 03:43:46 --> Helper loaded: url_helper
ERROR - 2020-02-12 03:43:46 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-12 03:43:46 --> Helper loaded: url_helper
INFO - 2020-02-12 03:43:46 --> Language Class Initialized
INFO - 2020-02-12 03:43:46 --> Config Class Initialized
INFO - 2020-02-12 03:43:46 --> Hooks Class Initialized
ERROR - 2020-02-12 03:43:46 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-12 03:43:46 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:46 --> Database Driver Class Initialized
INFO - 2020-02-12 03:43:46 --> Database Driver Class Initialized
INFO - 2020-02-12 03:43:46 --> Utf8 Class Initialized
DEBUG - 2020-02-12 03:43:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 03:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-12 03:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:43:46 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:43:46 --> URI Class Initialized
INFO - 2020-02-12 03:43:46 --> Controller Class Initialized
INFO - 2020-02-12 03:43:46 --> URI Class Initialized
INFO - 2020-02-12 03:43:46 --> Router Class Initialized
INFO - 2020-02-12 03:43:46 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:43:46 --> Router Class Initialized
INFO - 2020-02-12 03:43:46 --> Output Class Initialized
INFO - 2020-02-12 03:43:46 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:43:46 --> Security Class Initialized
INFO - 2020-02-12 03:43:46 --> Output Class Initialized
INFO - 2020-02-12 03:43:46 --> Model "M_pesan" initialized
DEBUG - 2020-02-12 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:46 --> Security Class Initialized
INFO - 2020-02-12 03:43:46 --> Input Class Initialized
DEBUG - 2020-02-12 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:46 --> Helper loaded: form_helper
INFO - 2020-02-12 03:43:47 --> Form Validation Class Initialized
INFO - 2020-02-12 03:43:47 --> Input Class Initialized
INFO - 2020-02-12 03:43:47 --> Language Class Initialized
INFO - 2020-02-12 03:43:47 --> Language Class Initialized
ERROR - 2020-02-12 03:43:47 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-12 03:43:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 03:43:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-12 03:43:47 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-12 03:43:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:43:47 --> Config Class Initialized
INFO - 2020-02-12 03:43:47 --> Hooks Class Initialized
INFO - 2020-02-12 03:43:47 --> Final output sent to browser
DEBUG - 2020-02-12 03:43:47 --> Total execution time: 1.2493
DEBUG - 2020-02-12 03:43:47 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:47 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:43:47 --> Controller Class Initialized
INFO - 2020-02-12 03:43:47 --> URI Class Initialized
INFO - 2020-02-12 03:43:47 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:43:47 --> Router Class Initialized
INFO - 2020-02-12 03:43:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:43:47 --> Output Class Initialized
INFO - 2020-02-12 03:43:47 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:43:47 --> Security Class Initialized
DEBUG - 2020-02-12 03:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:47 --> Helper loaded: form_helper
INFO - 2020-02-12 03:43:47 --> Form Validation Class Initialized
INFO - 2020-02-12 03:43:47 --> Input Class Initialized
INFO - 2020-02-12 03:43:47 --> Language Class Initialized
ERROR - 2020-02-12 03:43:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 03:43:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-12 03:43:47 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-12 03:43:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 03:43:47 --> Config Class Initialized
INFO - 2020-02-12 03:43:47 --> Hooks Class Initialized
INFO - 2020-02-12 03:43:47 --> Final output sent to browser
DEBUG - 2020-02-12 03:43:47 --> Total execution time: 1.5403
DEBUG - 2020-02-12 03:43:47 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:47 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:47 --> URI Class Initialized
INFO - 2020-02-12 03:43:47 --> Router Class Initialized
INFO - 2020-02-12 03:43:47 --> Output Class Initialized
INFO - 2020-02-12 03:43:47 --> Security Class Initialized
DEBUG - 2020-02-12 03:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:47 --> Input Class Initialized
INFO - 2020-02-12 03:43:47 --> Language Class Initialized
ERROR - 2020-02-12 03:43:47 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:43:47 --> Config Class Initialized
INFO - 2020-02-12 03:43:47 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:43:47 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:47 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:47 --> URI Class Initialized
INFO - 2020-02-12 03:43:47 --> Router Class Initialized
INFO - 2020-02-12 03:43:47 --> Output Class Initialized
INFO - 2020-02-12 03:43:47 --> Security Class Initialized
DEBUG - 2020-02-12 03:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:47 --> Input Class Initialized
INFO - 2020-02-12 03:43:47 --> Language Class Initialized
ERROR - 2020-02-12 03:43:47 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 03:43:47 --> Config Class Initialized
INFO - 2020-02-12 03:43:48 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:43:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:48 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:48 --> URI Class Initialized
INFO - 2020-02-12 03:43:48 --> Router Class Initialized
INFO - 2020-02-12 03:43:48 --> Output Class Initialized
INFO - 2020-02-12 03:43:48 --> Security Class Initialized
DEBUG - 2020-02-12 03:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:48 --> Input Class Initialized
INFO - 2020-02-12 03:43:48 --> Language Class Initialized
ERROR - 2020-02-12 03:43:48 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-12 03:43:48 --> Config Class Initialized
INFO - 2020-02-12 03:43:48 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:43:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:48 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:48 --> URI Class Initialized
INFO - 2020-02-12 03:43:48 --> Router Class Initialized
INFO - 2020-02-12 03:43:48 --> Output Class Initialized
INFO - 2020-02-12 03:43:48 --> Security Class Initialized
DEBUG - 2020-02-12 03:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:48 --> Input Class Initialized
INFO - 2020-02-12 03:43:48 --> Language Class Initialized
ERROR - 2020-02-12 03:43:48 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-12 03:43:48 --> Config Class Initialized
INFO - 2020-02-12 03:43:48 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:43:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:48 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:48 --> URI Class Initialized
INFO - 2020-02-12 03:43:48 --> Router Class Initialized
INFO - 2020-02-12 03:43:48 --> Output Class Initialized
INFO - 2020-02-12 03:43:48 --> Security Class Initialized
DEBUG - 2020-02-12 03:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:48 --> Input Class Initialized
INFO - 2020-02-12 03:43:48 --> Language Class Initialized
ERROR - 2020-02-12 03:43:48 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-12 03:43:48 --> Config Class Initialized
INFO - 2020-02-12 03:43:48 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:43:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:43:48 --> Utf8 Class Initialized
INFO - 2020-02-12 03:43:49 --> URI Class Initialized
INFO - 2020-02-12 03:43:49 --> Router Class Initialized
INFO - 2020-02-12 03:43:49 --> Output Class Initialized
INFO - 2020-02-12 03:43:49 --> Security Class Initialized
DEBUG - 2020-02-12 03:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:43:49 --> Input Class Initialized
INFO - 2020-02-12 03:43:49 --> Language Class Initialized
ERROR - 2020-02-12 03:43:49 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-12 03:44:13 --> Config Class Initialized
INFO - 2020-02-12 03:44:13 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:44:13 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:44:13 --> Utf8 Class Initialized
INFO - 2020-02-12 03:44:13 --> URI Class Initialized
INFO - 2020-02-12 03:44:13 --> Router Class Initialized
INFO - 2020-02-12 03:44:13 --> Output Class Initialized
INFO - 2020-02-12 03:44:13 --> Security Class Initialized
DEBUG - 2020-02-12 03:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:44:13 --> Input Class Initialized
INFO - 2020-02-12 03:44:13 --> Language Class Initialized
INFO - 2020-02-12 03:44:14 --> Loader Class Initialized
INFO - 2020-02-12 03:44:14 --> Helper loaded: url_helper
INFO - 2020-02-12 03:44:14 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:44:14 --> Controller Class Initialized
INFO - 2020-02-12 03:44:14 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:44:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:44:14 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:44:14 --> Helper loaded: form_helper
INFO - 2020-02-12 03:44:14 --> Form Validation Class Initialized
INFO - 2020-02-12 03:44:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 03:44:14 --> Final output sent to browser
DEBUG - 2020-02-12 03:44:14 --> Total execution time: 0.5784
INFO - 2020-02-12 03:44:40 --> Config Class Initialized
INFO - 2020-02-12 03:44:40 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:44:40 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:44:41 --> Utf8 Class Initialized
INFO - 2020-02-12 03:44:41 --> URI Class Initialized
INFO - 2020-02-12 03:44:41 --> Router Class Initialized
INFO - 2020-02-12 03:44:41 --> Output Class Initialized
INFO - 2020-02-12 03:44:41 --> Security Class Initialized
DEBUG - 2020-02-12 03:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:44:41 --> Input Class Initialized
INFO - 2020-02-12 03:44:41 --> Language Class Initialized
INFO - 2020-02-12 03:44:41 --> Loader Class Initialized
INFO - 2020-02-12 03:44:41 --> Helper loaded: url_helper
INFO - 2020-02-12 03:44:41 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:44:42 --> Controller Class Initialized
INFO - 2020-02-12 03:44:42 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:44:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:44:42 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:44:42 --> Helper loaded: form_helper
INFO - 2020-02-12 03:44:42 --> Form Validation Class Initialized
INFO - 2020-02-12 03:44:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 03:44:42 --> Final output sent to browser
DEBUG - 2020-02-12 03:44:42 --> Total execution time: 1.7072
INFO - 2020-02-12 03:44:51 --> Config Class Initialized
INFO - 2020-02-12 03:44:52 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:44:52 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:44:52 --> Utf8 Class Initialized
INFO - 2020-02-12 03:44:52 --> URI Class Initialized
INFO - 2020-02-12 03:44:52 --> Router Class Initialized
INFO - 2020-02-12 03:44:52 --> Output Class Initialized
INFO - 2020-02-12 03:44:52 --> Security Class Initialized
DEBUG - 2020-02-12 03:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:44:52 --> Input Class Initialized
INFO - 2020-02-12 03:44:52 --> Language Class Initialized
INFO - 2020-02-12 03:44:52 --> Loader Class Initialized
INFO - 2020-02-12 03:44:52 --> Helper loaded: url_helper
INFO - 2020-02-12 03:44:52 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:44:52 --> Controller Class Initialized
INFO - 2020-02-12 03:44:52 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:44:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:44:52 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:44:52 --> Helper loaded: form_helper
INFO - 2020-02-12 03:44:52 --> Form Validation Class Initialized
ERROR - 2020-02-12 03:44:52 --> Severity: Notice --> Undefined index: bank C:\xampp\htdocs\roadshow\application\models\M_tiket.php 74
ERROR - 2020-02-12 03:44:52 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 30
ERROR - 2020-02-12 03:44:52 --> Severity: Notice --> Undefined index: jumlah_pesanan C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
INFO - 2020-02-12 03:44:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 03:44:52 --> Final output sent to browser
DEBUG - 2020-02-12 03:44:52 --> Total execution time: 0.9378
INFO - 2020-02-12 03:56:04 --> Config Class Initialized
INFO - 2020-02-12 03:56:04 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:56:04 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:56:04 --> Utf8 Class Initialized
INFO - 2020-02-12 03:56:04 --> URI Class Initialized
INFO - 2020-02-12 03:56:04 --> Router Class Initialized
INFO - 2020-02-12 03:56:04 --> Output Class Initialized
INFO - 2020-02-12 03:56:04 --> Security Class Initialized
DEBUG - 2020-02-12 03:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:56:04 --> Input Class Initialized
INFO - 2020-02-12 03:56:04 --> Language Class Initialized
INFO - 2020-02-12 03:56:04 --> Loader Class Initialized
INFO - 2020-02-12 03:56:04 --> Helper loaded: url_helper
INFO - 2020-02-12 03:56:04 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:56:04 --> Controller Class Initialized
INFO - 2020-02-12 03:56:04 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:56:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:56:04 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:56:04 --> Helper loaded: form_helper
INFO - 2020-02-12 03:56:04 --> Form Validation Class Initialized
ERROR - 2020-02-12 03:56:04 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-12 03:56:04 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 30
ERROR - 2020-02-12 03:56:04 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
ERROR - 2020-02-12 03:56:04 --> Severity: Notice --> Undefined variable: nama C:\xampp\htdocs\roadshow\application\views\Pemesanan\form_bukti.php 15
ERROR - 2020-02-12 03:56:04 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\roadshow\application\views\Pemesanan\form_bukti.php 15
INFO - 2020-02-12 03:57:15 --> Config Class Initialized
INFO - 2020-02-12 03:57:15 --> Hooks Class Initialized
DEBUG - 2020-02-12 03:57:15 --> UTF-8 Support Enabled
INFO - 2020-02-12 03:57:15 --> Utf8 Class Initialized
INFO - 2020-02-12 03:57:15 --> URI Class Initialized
INFO - 2020-02-12 03:57:15 --> Router Class Initialized
INFO - 2020-02-12 03:57:15 --> Output Class Initialized
INFO - 2020-02-12 03:57:15 --> Security Class Initialized
DEBUG - 2020-02-12 03:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 03:57:15 --> Input Class Initialized
INFO - 2020-02-12 03:57:15 --> Language Class Initialized
INFO - 2020-02-12 03:57:15 --> Loader Class Initialized
INFO - 2020-02-12 03:57:15 --> Helper loaded: url_helper
INFO - 2020-02-12 03:57:15 --> Database Driver Class Initialized
DEBUG - 2020-02-12 03:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 03:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 03:57:15 --> Controller Class Initialized
INFO - 2020-02-12 03:57:15 --> Model "M_tiket" initialized
INFO - 2020-02-12 03:57:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 03:57:15 --> Model "M_pesan" initialized
INFO - 2020-02-12 03:57:15 --> Helper loaded: form_helper
INFO - 2020-02-12 03:57:15 --> Form Validation Class Initialized
ERROR - 2020-02-12 03:57:15 --> Severity: Notice --> Undefined index: total_bayar C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 29
ERROR - 2020-02-12 03:57:15 --> Severity: Notice --> Undefined index: no_rek C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 30
ERROR - 2020-02-12 03:57:15 --> Severity: Notice --> Undefined index: atas_nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 31
INFO - 2020-02-12 03:57:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 03:57:15 --> Final output sent to browser
DEBUG - 2020-02-12 03:57:16 --> Total execution time: 0.6600
INFO - 2020-02-12 11:38:28 --> Config Class Initialized
INFO - 2020-02-12 11:38:28 --> Hooks Class Initialized
DEBUG - 2020-02-12 11:38:28 --> UTF-8 Support Enabled
INFO - 2020-02-12 11:38:28 --> Utf8 Class Initialized
INFO - 2020-02-12 11:38:28 --> URI Class Initialized
INFO - 2020-02-12 11:38:29 --> Router Class Initialized
INFO - 2020-02-12 11:38:29 --> Output Class Initialized
INFO - 2020-02-12 11:38:29 --> Security Class Initialized
DEBUG - 2020-02-12 11:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 11:38:29 --> Input Class Initialized
INFO - 2020-02-12 11:38:29 --> Language Class Initialized
INFO - 2020-02-12 11:38:29 --> Loader Class Initialized
INFO - 2020-02-12 11:38:29 --> Helper loaded: url_helper
INFO - 2020-02-12 11:38:30 --> Database Driver Class Initialized
DEBUG - 2020-02-12 11:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 11:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 11:38:30 --> Controller Class Initialized
INFO - 2020-02-12 11:38:30 --> Model "M_tiket" initialized
INFO - 2020-02-12 11:38:30 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 11:38:30 --> Model "M_pesan" initialized
INFO - 2020-02-12 11:38:30 --> Helper loaded: form_helper
INFO - 2020-02-12 11:38:30 --> Form Validation Class Initialized
INFO - 2020-02-12 11:38:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 11:38:31 --> Final output sent to browser
DEBUG - 2020-02-12 11:38:31 --> Total execution time: 3.2616
INFO - 2020-02-12 11:38:31 --> Config Class Initialized
INFO - 2020-02-12 11:38:31 --> Config Class Initialized
INFO - 2020-02-12 11:38:31 --> Config Class Initialized
INFO - 2020-02-12 11:38:31 --> Config Class Initialized
INFO - 2020-02-12 11:38:31 --> Config Class Initialized
INFO - 2020-02-12 11:38:31 --> Hooks Class Initialized
INFO - 2020-02-12 11:38:31 --> Hooks Class Initialized
INFO - 2020-02-12 11:38:31 --> Hooks Class Initialized
INFO - 2020-02-12 11:38:31 --> Hooks Class Initialized
INFO - 2020-02-12 11:38:31 --> Hooks Class Initialized
DEBUG - 2020-02-12 11:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 11:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 11:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 11:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 11:38:31 --> UTF-8 Support Enabled
INFO - 2020-02-12 11:38:31 --> Utf8 Class Initialized
INFO - 2020-02-12 11:38:31 --> Utf8 Class Initialized
INFO - 2020-02-12 11:38:31 --> Utf8 Class Initialized
INFO - 2020-02-12 11:38:31 --> Utf8 Class Initialized
INFO - 2020-02-12 11:38:31 --> Utf8 Class Initialized
INFO - 2020-02-12 11:38:31 --> URI Class Initialized
INFO - 2020-02-12 11:38:31 --> URI Class Initialized
INFO - 2020-02-12 11:38:31 --> URI Class Initialized
INFO - 2020-02-12 11:38:31 --> URI Class Initialized
INFO - 2020-02-12 11:38:31 --> URI Class Initialized
INFO - 2020-02-12 11:38:31 --> Router Class Initialized
INFO - 2020-02-12 11:38:31 --> Router Class Initialized
INFO - 2020-02-12 11:38:31 --> Router Class Initialized
INFO - 2020-02-12 11:38:31 --> Router Class Initialized
INFO - 2020-02-12 11:38:31 --> Router Class Initialized
INFO - 2020-02-12 11:38:31 --> Output Class Initialized
INFO - 2020-02-12 11:38:31 --> Output Class Initialized
INFO - 2020-02-12 11:38:31 --> Output Class Initialized
INFO - 2020-02-12 11:38:31 --> Output Class Initialized
INFO - 2020-02-12 11:38:31 --> Output Class Initialized
INFO - 2020-02-12 11:38:31 --> Security Class Initialized
INFO - 2020-02-12 11:38:31 --> Security Class Initialized
INFO - 2020-02-12 11:38:31 --> Security Class Initialized
INFO - 2020-02-12 11:38:31 --> Security Class Initialized
INFO - 2020-02-12 11:38:31 --> Security Class Initialized
DEBUG - 2020-02-12 11:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 11:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 11:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 11:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 11:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 11:38:31 --> Input Class Initialized
INFO - 2020-02-12 11:38:31 --> Input Class Initialized
INFO - 2020-02-12 11:38:31 --> Input Class Initialized
INFO - 2020-02-12 11:38:31 --> Input Class Initialized
INFO - 2020-02-12 11:38:31 --> Input Class Initialized
INFO - 2020-02-12 11:38:31 --> Language Class Initialized
INFO - 2020-02-12 11:38:31 --> Language Class Initialized
INFO - 2020-02-12 11:38:31 --> Language Class Initialized
INFO - 2020-02-12 11:38:31 --> Language Class Initialized
INFO - 2020-02-12 11:38:31 --> Language Class Initialized
INFO - 2020-02-12 11:38:31 --> Loader Class Initialized
INFO - 2020-02-12 11:38:31 --> Loader Class Initialized
INFO - 2020-02-12 11:38:31 --> Helper loaded: url_helper
INFO - 2020-02-12 11:38:31 --> Helper loaded: url_helper
ERROR - 2020-02-12 11:38:31 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-12 11:38:31 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-12 11:38:31 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-12 11:38:31 --> Database Driver Class Initialized
INFO - 2020-02-12 11:38:31 --> Database Driver Class Initialized
DEBUG - 2020-02-12 11:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-12 11:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 11:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 11:38:32 --> Controller Class Initialized
INFO - 2020-02-12 11:38:32 --> Model "M_tiket" initialized
INFO - 2020-02-12 11:38:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 11:38:32 --> Model "M_pesan" initialized
INFO - 2020-02-12 11:38:32 --> Helper loaded: form_helper
INFO - 2020-02-12 11:38:32 --> Form Validation Class Initialized
ERROR - 2020-02-12 11:38:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 11:38:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-12 11:38:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 11:38:32 --> Final output sent to browser
DEBUG - 2020-02-12 11:38:32 --> Total execution time: 0.9584
INFO - 2020-02-12 11:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 11:38:32 --> Controller Class Initialized
INFO - 2020-02-12 11:38:32 --> Model "M_tiket" initialized
INFO - 2020-02-12 11:38:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 11:38:32 --> Model "M_pesan" initialized
INFO - 2020-02-12 11:38:32 --> Helper loaded: form_helper
INFO - 2020-02-12 11:38:32 --> Form Validation Class Initialized
ERROR - 2020-02-12 11:38:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 11:38:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-12 11:38:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 11:38:32 --> Final output sent to browser
DEBUG - 2020-02-12 11:38:32 --> Total execution time: 1.3169
INFO - 2020-02-12 11:38:41 --> Config Class Initialized
INFO - 2020-02-12 11:38:41 --> Hooks Class Initialized
DEBUG - 2020-02-12 11:38:41 --> UTF-8 Support Enabled
INFO - 2020-02-12 11:38:41 --> Utf8 Class Initialized
INFO - 2020-02-12 11:38:41 --> URI Class Initialized
INFO - 2020-02-12 11:38:41 --> Router Class Initialized
INFO - 2020-02-12 11:38:41 --> Output Class Initialized
INFO - 2020-02-12 11:38:41 --> Security Class Initialized
DEBUG - 2020-02-12 11:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 11:38:41 --> Input Class Initialized
INFO - 2020-02-12 11:38:41 --> Language Class Initialized
INFO - 2020-02-12 11:38:41 --> Loader Class Initialized
INFO - 2020-02-12 11:38:41 --> Helper loaded: url_helper
INFO - 2020-02-12 11:38:41 --> Database Driver Class Initialized
DEBUG - 2020-02-12 11:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 11:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 11:38:41 --> Controller Class Initialized
INFO - 2020-02-12 11:38:41 --> Model "M_tiket" initialized
INFO - 2020-02-12 11:38:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 11:38:41 --> Model "M_pesan" initialized
INFO - 2020-02-12 11:38:41 --> Helper loaded: form_helper
INFO - 2020-02-12 11:38:41 --> Form Validation Class Initialized
INFO - 2020-02-12 11:38:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 11:38:41 --> Final output sent to browser
DEBUG - 2020-02-12 11:38:42 --> Total execution time: 0.8607
INFO - 2020-02-12 11:39:05 --> Config Class Initialized
INFO - 2020-02-12 11:39:05 --> Hooks Class Initialized
DEBUG - 2020-02-12 11:39:05 --> UTF-8 Support Enabled
INFO - 2020-02-12 11:39:05 --> Utf8 Class Initialized
INFO - 2020-02-12 11:39:05 --> URI Class Initialized
INFO - 2020-02-12 11:39:05 --> Router Class Initialized
INFO - 2020-02-12 11:39:06 --> Output Class Initialized
INFO - 2020-02-12 11:39:06 --> Security Class Initialized
DEBUG - 2020-02-12 11:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 11:39:06 --> Input Class Initialized
INFO - 2020-02-12 11:39:06 --> Language Class Initialized
INFO - 2020-02-12 11:39:06 --> Loader Class Initialized
INFO - 2020-02-12 11:39:06 --> Helper loaded: url_helper
INFO - 2020-02-12 11:39:06 --> Database Driver Class Initialized
DEBUG - 2020-02-12 11:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 11:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 11:39:06 --> Controller Class Initialized
INFO - 2020-02-12 11:39:06 --> Model "M_tiket" initialized
INFO - 2020-02-12 11:39:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 11:39:06 --> Model "M_pesan" initialized
INFO - 2020-02-12 11:39:06 --> Helper loaded: form_helper
INFO - 2020-02-12 11:39:06 --> Form Validation Class Initialized
INFO - 2020-02-12 11:39:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 11:39:06 --> Final output sent to browser
DEBUG - 2020-02-12 11:39:06 --> Total execution time: 0.6547
INFO - 2020-02-12 11:39:38 --> Config Class Initialized
INFO - 2020-02-12 11:39:38 --> Hooks Class Initialized
DEBUG - 2020-02-12 11:39:38 --> UTF-8 Support Enabled
INFO - 2020-02-12 11:39:38 --> Utf8 Class Initialized
INFO - 2020-02-12 11:39:38 --> URI Class Initialized
INFO - 2020-02-12 11:39:38 --> Router Class Initialized
INFO - 2020-02-12 11:39:38 --> Output Class Initialized
INFO - 2020-02-12 11:39:38 --> Security Class Initialized
DEBUG - 2020-02-12 11:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 11:39:38 --> Input Class Initialized
INFO - 2020-02-12 11:39:38 --> Language Class Initialized
INFO - 2020-02-12 11:39:38 --> Loader Class Initialized
INFO - 2020-02-12 11:39:38 --> Helper loaded: url_helper
INFO - 2020-02-12 11:39:38 --> Database Driver Class Initialized
DEBUG - 2020-02-12 11:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 11:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 11:39:38 --> Controller Class Initialized
INFO - 2020-02-12 11:39:38 --> Model "M_tiket" initialized
INFO - 2020-02-12 11:39:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 11:39:38 --> Model "M_pesan" initialized
INFO - 2020-02-12 11:39:39 --> Helper loaded: form_helper
INFO - 2020-02-12 11:39:39 --> Form Validation Class Initialized
INFO - 2020-02-12 11:39:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 11:39:39 --> Final output sent to browser
DEBUG - 2020-02-12 11:39:39 --> Total execution time: 0.6737
INFO - 2020-02-12 11:40:13 --> Config Class Initialized
INFO - 2020-02-12 11:40:13 --> Hooks Class Initialized
DEBUG - 2020-02-12 11:40:13 --> UTF-8 Support Enabled
INFO - 2020-02-12 11:40:13 --> Utf8 Class Initialized
INFO - 2020-02-12 11:40:13 --> URI Class Initialized
INFO - 2020-02-12 11:40:13 --> Router Class Initialized
INFO - 2020-02-12 11:40:14 --> Output Class Initialized
INFO - 2020-02-12 11:40:14 --> Security Class Initialized
DEBUG - 2020-02-12 11:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 11:40:14 --> Input Class Initialized
INFO - 2020-02-12 11:40:14 --> Language Class Initialized
INFO - 2020-02-12 11:40:14 --> Loader Class Initialized
INFO - 2020-02-12 11:40:14 --> Helper loaded: url_helper
INFO - 2020-02-12 11:40:14 --> Database Driver Class Initialized
DEBUG - 2020-02-12 11:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 11:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 11:40:14 --> Controller Class Initialized
INFO - 2020-02-12 11:40:14 --> Model "M_tiket" initialized
INFO - 2020-02-12 11:40:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 11:40:14 --> Model "M_pesan" initialized
INFO - 2020-02-12 11:40:14 --> Helper loaded: form_helper
INFO - 2020-02-12 11:40:14 --> Form Validation Class Initialized
INFO - 2020-02-12 11:40:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 11:40:14 --> Final output sent to browser
DEBUG - 2020-02-12 11:40:14 --> Total execution time: 0.5808
INFO - 2020-02-12 11:43:57 --> Config Class Initialized
INFO - 2020-02-12 11:43:57 --> Hooks Class Initialized
DEBUG - 2020-02-12 11:43:57 --> UTF-8 Support Enabled
INFO - 2020-02-12 11:43:57 --> Utf8 Class Initialized
INFO - 2020-02-12 11:43:57 --> URI Class Initialized
INFO - 2020-02-12 11:43:57 --> Router Class Initialized
INFO - 2020-02-12 11:43:57 --> Output Class Initialized
INFO - 2020-02-12 11:43:57 --> Security Class Initialized
DEBUG - 2020-02-12 11:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 11:43:57 --> Input Class Initialized
INFO - 2020-02-12 11:43:57 --> Language Class Initialized
INFO - 2020-02-12 11:43:57 --> Loader Class Initialized
INFO - 2020-02-12 11:43:57 --> Helper loaded: url_helper
INFO - 2020-02-12 11:43:57 --> Database Driver Class Initialized
DEBUG - 2020-02-12 11:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 11:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 11:43:57 --> Controller Class Initialized
INFO - 2020-02-12 11:43:57 --> Model "M_tiket" initialized
INFO - 2020-02-12 11:43:57 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 11:43:57 --> Model "M_pesan" initialized
INFO - 2020-02-12 11:43:57 --> Helper loaded: form_helper
INFO - 2020-02-12 11:43:57 --> Form Validation Class Initialized
INFO - 2020-02-12 11:43:57 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 11:43:57 --> Final output sent to browser
DEBUG - 2020-02-12 11:43:57 --> Total execution time: 0.5988
INFO - 2020-02-12 11:45:51 --> Config Class Initialized
INFO - 2020-02-12 11:45:51 --> Hooks Class Initialized
DEBUG - 2020-02-12 11:45:51 --> UTF-8 Support Enabled
INFO - 2020-02-12 11:45:51 --> Utf8 Class Initialized
INFO - 2020-02-12 11:45:51 --> URI Class Initialized
INFO - 2020-02-12 11:45:51 --> Router Class Initialized
INFO - 2020-02-12 11:45:51 --> Output Class Initialized
INFO - 2020-02-12 11:45:51 --> Security Class Initialized
DEBUG - 2020-02-12 11:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 11:45:51 --> Input Class Initialized
INFO - 2020-02-12 11:45:51 --> Language Class Initialized
INFO - 2020-02-12 11:45:51 --> Loader Class Initialized
INFO - 2020-02-12 11:45:51 --> Helper loaded: url_helper
INFO - 2020-02-12 11:45:51 --> Database Driver Class Initialized
DEBUG - 2020-02-12 11:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 11:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 11:45:51 --> Controller Class Initialized
INFO - 2020-02-12 11:45:51 --> Model "M_tiket" initialized
INFO - 2020-02-12 11:45:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 11:45:51 --> Model "M_pesan" initialized
INFO - 2020-02-12 11:45:51 --> Helper loaded: form_helper
INFO - 2020-02-12 11:45:51 --> Form Validation Class Initialized
INFO - 2020-02-12 11:45:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 11:45:51 --> Final output sent to browser
DEBUG - 2020-02-12 11:45:51 --> Total execution time: 0.5931
INFO - 2020-02-12 11:59:26 --> Config Class Initialized
INFO - 2020-02-12 11:59:27 --> Hooks Class Initialized
DEBUG - 2020-02-12 11:59:27 --> UTF-8 Support Enabled
INFO - 2020-02-12 11:59:27 --> Utf8 Class Initialized
INFO - 2020-02-12 11:59:27 --> URI Class Initialized
INFO - 2020-02-12 11:59:27 --> Router Class Initialized
INFO - 2020-02-12 11:59:27 --> Output Class Initialized
INFO - 2020-02-12 11:59:27 --> Security Class Initialized
DEBUG - 2020-02-12 11:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 11:59:27 --> Input Class Initialized
INFO - 2020-02-12 11:59:27 --> Language Class Initialized
INFO - 2020-02-12 11:59:27 --> Loader Class Initialized
INFO - 2020-02-12 11:59:27 --> Helper loaded: url_helper
INFO - 2020-02-12 11:59:27 --> Database Driver Class Initialized
DEBUG - 2020-02-12 11:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 11:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 11:59:28 --> Controller Class Initialized
INFO - 2020-02-12 11:59:28 --> Model "M_tiket" initialized
INFO - 2020-02-12 11:59:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 11:59:28 --> Model "M_pesan" initialized
INFO - 2020-02-12 11:59:28 --> Helper loaded: form_helper
INFO - 2020-02-12 11:59:28 --> Form Validation Class Initialized
INFO - 2020-02-12 11:59:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 11:59:28 --> Final output sent to browser
DEBUG - 2020-02-12 11:59:28 --> Total execution time: 1.6929
INFO - 2020-02-12 11:59:58 --> Config Class Initialized
INFO - 2020-02-12 11:59:58 --> Hooks Class Initialized
DEBUG - 2020-02-12 11:59:58 --> UTF-8 Support Enabled
INFO - 2020-02-12 11:59:58 --> Utf8 Class Initialized
INFO - 2020-02-12 11:59:58 --> URI Class Initialized
INFO - 2020-02-12 11:59:58 --> Router Class Initialized
INFO - 2020-02-12 11:59:58 --> Output Class Initialized
INFO - 2020-02-12 11:59:58 --> Security Class Initialized
DEBUG - 2020-02-12 11:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 11:59:58 --> Input Class Initialized
INFO - 2020-02-12 11:59:58 --> Language Class Initialized
INFO - 2020-02-12 11:59:58 --> Loader Class Initialized
INFO - 2020-02-12 11:59:58 --> Helper loaded: url_helper
INFO - 2020-02-12 11:59:58 --> Database Driver Class Initialized
DEBUG - 2020-02-12 11:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 11:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 11:59:59 --> Controller Class Initialized
INFO - 2020-02-12 11:59:59 --> Model "M_tiket" initialized
INFO - 2020-02-12 11:59:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 11:59:59 --> Model "M_pesan" initialized
INFO - 2020-02-12 11:59:59 --> Helper loaded: form_helper
INFO - 2020-02-12 11:59:59 --> Form Validation Class Initialized
INFO - 2020-02-12 11:59:59 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 11:59:59 --> Final output sent to browser
DEBUG - 2020-02-12 11:59:59 --> Total execution time: 0.5885
INFO - 2020-02-12 12:00:24 --> Config Class Initialized
INFO - 2020-02-12 12:00:24 --> Hooks Class Initialized
DEBUG - 2020-02-12 12:00:24 --> UTF-8 Support Enabled
INFO - 2020-02-12 12:00:24 --> Utf8 Class Initialized
INFO - 2020-02-12 12:00:24 --> URI Class Initialized
INFO - 2020-02-12 12:00:24 --> Router Class Initialized
INFO - 2020-02-12 12:00:24 --> Output Class Initialized
INFO - 2020-02-12 12:00:24 --> Security Class Initialized
DEBUG - 2020-02-12 12:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 12:00:24 --> Input Class Initialized
INFO - 2020-02-12 12:00:24 --> Language Class Initialized
INFO - 2020-02-12 12:00:24 --> Loader Class Initialized
INFO - 2020-02-12 12:00:24 --> Helper loaded: url_helper
INFO - 2020-02-12 12:00:24 --> Database Driver Class Initialized
DEBUG - 2020-02-12 12:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 12:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 12:00:24 --> Controller Class Initialized
INFO - 2020-02-12 12:00:25 --> Model "M_tiket" initialized
INFO - 2020-02-12 12:00:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 12:00:25 --> Model "M_pesan" initialized
INFO - 2020-02-12 12:00:25 --> Helper loaded: form_helper
INFO - 2020-02-12 12:00:25 --> Form Validation Class Initialized
INFO - 2020-02-12 12:00:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 12:00:25 --> Final output sent to browser
DEBUG - 2020-02-12 12:00:25 --> Total execution time: 0.5859
INFO - 2020-02-12 12:01:25 --> Config Class Initialized
INFO - 2020-02-12 12:01:25 --> Hooks Class Initialized
DEBUG - 2020-02-12 12:01:25 --> UTF-8 Support Enabled
INFO - 2020-02-12 12:01:25 --> Utf8 Class Initialized
INFO - 2020-02-12 12:01:25 --> URI Class Initialized
INFO - 2020-02-12 12:01:25 --> Router Class Initialized
INFO - 2020-02-12 12:01:25 --> Output Class Initialized
INFO - 2020-02-12 12:01:25 --> Security Class Initialized
DEBUG - 2020-02-12 12:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 12:01:25 --> Input Class Initialized
INFO - 2020-02-12 12:01:25 --> Language Class Initialized
INFO - 2020-02-12 12:01:25 --> Loader Class Initialized
INFO - 2020-02-12 12:01:25 --> Helper loaded: url_helper
INFO - 2020-02-12 12:01:25 --> Database Driver Class Initialized
DEBUG - 2020-02-12 12:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 12:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 12:01:25 --> Controller Class Initialized
INFO - 2020-02-12 12:01:25 --> Model "M_tiket" initialized
INFO - 2020-02-12 12:01:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 12:01:25 --> Model "M_pesan" initialized
INFO - 2020-02-12 12:01:25 --> Helper loaded: form_helper
INFO - 2020-02-12 12:01:25 --> Form Validation Class Initialized
INFO - 2020-02-12 12:01:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 12:01:25 --> Final output sent to browser
DEBUG - 2020-02-12 12:01:25 --> Total execution time: 0.5746
INFO - 2020-02-12 12:01:50 --> Config Class Initialized
INFO - 2020-02-12 12:01:50 --> Hooks Class Initialized
DEBUG - 2020-02-12 12:01:50 --> UTF-8 Support Enabled
INFO - 2020-02-12 12:01:50 --> Utf8 Class Initialized
INFO - 2020-02-12 12:01:50 --> URI Class Initialized
INFO - 2020-02-12 12:01:50 --> Router Class Initialized
INFO - 2020-02-12 12:01:50 --> Output Class Initialized
INFO - 2020-02-12 12:01:50 --> Security Class Initialized
DEBUG - 2020-02-12 12:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 12:01:50 --> Input Class Initialized
INFO - 2020-02-12 12:01:50 --> Language Class Initialized
INFO - 2020-02-12 12:01:50 --> Loader Class Initialized
INFO - 2020-02-12 12:01:51 --> Helper loaded: url_helper
INFO - 2020-02-12 12:01:51 --> Database Driver Class Initialized
DEBUG - 2020-02-12 12:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 12:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 12:01:51 --> Controller Class Initialized
INFO - 2020-02-12 12:01:51 --> Model "M_tiket" initialized
INFO - 2020-02-12 12:01:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 12:01:51 --> Model "M_pesan" initialized
INFO - 2020-02-12 12:01:51 --> Helper loaded: form_helper
INFO - 2020-02-12 12:01:51 --> Form Validation Class Initialized
INFO - 2020-02-12 12:01:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 12:01:51 --> Final output sent to browser
DEBUG - 2020-02-12 12:01:51 --> Total execution time: 0.7307
INFO - 2020-02-12 14:12:47 --> Config Class Initialized
INFO - 2020-02-12 14:12:48 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:12:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:12:48 --> Utf8 Class Initialized
INFO - 2020-02-12 14:12:48 --> URI Class Initialized
INFO - 2020-02-12 14:12:48 --> Router Class Initialized
INFO - 2020-02-12 14:12:48 --> Output Class Initialized
INFO - 2020-02-12 14:12:48 --> Security Class Initialized
DEBUG - 2020-02-12 14:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:12:48 --> Input Class Initialized
INFO - 2020-02-12 14:12:48 --> Language Class Initialized
INFO - 2020-02-12 14:12:48 --> Loader Class Initialized
INFO - 2020-02-12 14:12:48 --> Helper loaded: url_helper
INFO - 2020-02-12 14:12:48 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:12:48 --> Controller Class Initialized
INFO - 2020-02-12 14:12:48 --> Model "M_tiket" initialized
INFO - 2020-02-12 14:12:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 14:12:48 --> Model "M_pesan" initialized
INFO - 2020-02-12 14:12:48 --> Helper loaded: form_helper
INFO - 2020-02-12 14:12:48 --> Form Validation Class Initialized
INFO - 2020-02-12 14:12:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 14:12:48 --> Final output sent to browser
DEBUG - 2020-02-12 14:12:48 --> Total execution time: 0.4736
INFO - 2020-02-12 14:12:48 --> Config Class Initialized
INFO - 2020-02-12 14:12:48 --> Hooks Class Initialized
INFO - 2020-02-12 14:12:48 --> Config Class Initialized
INFO - 2020-02-12 14:12:48 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:12:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:12:48 --> Utf8 Class Initialized
DEBUG - 2020-02-12 14:12:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:12:48 --> Utf8 Class Initialized
INFO - 2020-02-12 14:12:48 --> URI Class Initialized
INFO - 2020-02-12 14:12:48 --> URI Class Initialized
INFO - 2020-02-12 14:12:48 --> Router Class Initialized
INFO - 2020-02-12 14:12:48 --> Router Class Initialized
INFO - 2020-02-12 14:12:48 --> Output Class Initialized
INFO - 2020-02-12 14:12:48 --> Security Class Initialized
INFO - 2020-02-12 14:12:48 --> Output Class Initialized
DEBUG - 2020-02-12 14:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:12:48 --> Security Class Initialized
INFO - 2020-02-12 14:12:48 --> Input Class Initialized
DEBUG - 2020-02-12 14:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:12:48 --> Input Class Initialized
INFO - 2020-02-12 14:12:48 --> Language Class Initialized
INFO - 2020-02-12 14:12:48 --> Language Class Initialized
INFO - 2020-02-12 14:12:48 --> Loader Class Initialized
INFO - 2020-02-12 14:12:48 --> Helper loaded: url_helper
INFO - 2020-02-12 14:12:48 --> Loader Class Initialized
INFO - 2020-02-12 14:12:48 --> Helper loaded: url_helper
INFO - 2020-02-12 14:12:48 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:12:48 --> Database Driver Class Initialized
INFO - 2020-02-12 14:12:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-12 14:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:12:48 --> Controller Class Initialized
INFO - 2020-02-12 14:12:48 --> Model "M_tiket" initialized
INFO - 2020-02-12 14:12:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 14:12:48 --> Model "M_pesan" initialized
INFO - 2020-02-12 14:12:49 --> Helper loaded: form_helper
INFO - 2020-02-12 14:12:49 --> Form Validation Class Initialized
ERROR - 2020-02-12 14:12:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 14:12:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-12 14:12:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 14:12:49 --> Final output sent to browser
DEBUG - 2020-02-12 14:12:49 --> Total execution time: 0.5975
INFO - 2020-02-12 14:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:12:49 --> Controller Class Initialized
INFO - 2020-02-12 14:12:49 --> Model "M_tiket" initialized
INFO - 2020-02-12 14:12:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 14:12:49 --> Model "M_pesan" initialized
INFO - 2020-02-12 14:12:49 --> Helper loaded: form_helper
INFO - 2020-02-12 14:12:49 --> Form Validation Class Initialized
ERROR - 2020-02-12 14:12:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 14:12:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-12 14:12:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 14:12:49 --> Final output sent to browser
DEBUG - 2020-02-12 14:12:49 --> Total execution time: 0.7901
INFO - 2020-02-12 14:12:49 --> Config Class Initialized
INFO - 2020-02-12 14:12:49 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:12:49 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:12:49 --> Utf8 Class Initialized
INFO - 2020-02-12 14:12:49 --> URI Class Initialized
DEBUG - 2020-02-12 14:12:49 --> No URI present. Default controller set.
INFO - 2020-02-12 14:12:49 --> Router Class Initialized
INFO - 2020-02-12 14:12:49 --> Output Class Initialized
INFO - 2020-02-12 14:12:49 --> Security Class Initialized
DEBUG - 2020-02-12 14:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:12:49 --> Input Class Initialized
INFO - 2020-02-12 14:12:49 --> Language Class Initialized
INFO - 2020-02-12 14:12:50 --> Loader Class Initialized
INFO - 2020-02-12 14:12:50 --> Helper loaded: url_helper
INFO - 2020-02-12 14:12:50 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:12:50 --> Controller Class Initialized
INFO - 2020-02-12 14:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-12 14:12:50 --> Pagination Class Initialized
INFO - 2020-02-12 14:12:50 --> Model "M_show" initialized
INFO - 2020-02-12 14:12:50 --> Helper loaded: form_helper
INFO - 2020-02-12 14:12:50 --> Form Validation Class Initialized
INFO - 2020-02-12 14:12:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-12 14:12:50 --> Final output sent to browser
DEBUG - 2020-02-12 14:12:50 --> Total execution time: 0.9867
INFO - 2020-02-12 14:13:01 --> Config Class Initialized
INFO - 2020-02-12 14:13:01 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:13:01 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:01 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:01 --> URI Class Initialized
INFO - 2020-02-12 14:13:01 --> Router Class Initialized
INFO - 2020-02-12 14:13:01 --> Output Class Initialized
INFO - 2020-02-12 14:13:01 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:01 --> Input Class Initialized
INFO - 2020-02-12 14:13:01 --> Language Class Initialized
INFO - 2020-02-12 14:13:01 --> Loader Class Initialized
INFO - 2020-02-12 14:13:01 --> Helper loaded: url_helper
INFO - 2020-02-12 14:13:01 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:13:01 --> Controller Class Initialized
INFO - 2020-02-12 14:13:01 --> Model "M_tiket" initialized
INFO - 2020-02-12 14:13:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 14:13:01 --> Model "M_pesan" initialized
INFO - 2020-02-12 14:13:01 --> Helper loaded: form_helper
INFO - 2020-02-12 14:13:02 --> Form Validation Class Initialized
INFO - 2020-02-12 14:13:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 14:13:02 --> Final output sent to browser
DEBUG - 2020-02-12 14:13:02 --> Total execution time: 0.4683
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
ERROR - 2020-02-12 14:13:02 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
ERROR - 2020-02-12 14:13:02 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
ERROR - 2020-02-12 14:13:02 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-12 14:13:02 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-12 14:13:02 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-12 14:13:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
ERROR - 2020-02-12 14:13:02 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-12 14:13:02 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-12 14:13:02 --> Loader Class Initialized
ERROR - 2020-02-12 14:13:02 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-12 14:13:02 --> Helper loaded: url_helper
INFO - 2020-02-12 14:13:02 --> Loader Class Initialized
ERROR - 2020-02-12 14:13:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:02 --> Helper loaded: url_helper
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:02 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 14:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:13:02 --> Database Driver Class Initialized
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-12 14:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:13:02 --> Controller Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> Model "M_tiket" initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> Router Class Initialized
INFO - 2020-02-12 14:13:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
INFO - 2020-02-12 14:13:02 --> Output Class Initialized
INFO - 2020-02-12 14:13:02 --> Model "M_pesan" initialized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
INFO - 2020-02-12 14:13:02 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:02 --> Helper loaded: form_helper
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
INFO - 2020-02-12 14:13:02 --> Form Validation Class Initialized
INFO - 2020-02-12 14:13:02 --> Input Class Initialized
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
INFO - 2020-02-12 14:13:02 --> Language Class Initialized
ERROR - 2020-02-12 14:13:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 14:13:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-12 14:13:02 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-12 14:13:02 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-12 14:13:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 14:13:02 --> Config Class Initialized
INFO - 2020-02-12 14:13:02 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:02 --> Final output sent to browser
DEBUG - 2020-02-12 14:13:02 --> Total execution time: 0.5220
DEBUG - 2020-02-12 14:13:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:13:02 --> Controller Class Initialized
INFO - 2020-02-12 14:13:02 --> URI Class Initialized
INFO - 2020-02-12 14:13:02 --> Model "M_tiket" initialized
INFO - 2020-02-12 14:13:03 --> Router Class Initialized
INFO - 2020-02-12 14:13:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 14:13:03 --> Output Class Initialized
INFO - 2020-02-12 14:13:03 --> Model "M_pesan" initialized
INFO - 2020-02-12 14:13:03 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:03 --> Helper loaded: form_helper
INFO - 2020-02-12 14:13:03 --> Input Class Initialized
INFO - 2020-02-12 14:13:03 --> Form Validation Class Initialized
INFO - 2020-02-12 14:13:03 --> Language Class Initialized
ERROR - 2020-02-12 14:13:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 14:13:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-12 14:13:03 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-12 14:13:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 14:13:03 --> Config Class Initialized
INFO - 2020-02-12 14:13:03 --> Hooks Class Initialized
INFO - 2020-02-12 14:13:03 --> Final output sent to browser
DEBUG - 2020-02-12 14:13:03 --> Total execution time: 0.7128
DEBUG - 2020-02-12 14:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:03 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:03 --> URI Class Initialized
INFO - 2020-02-12 14:13:03 --> Router Class Initialized
INFO - 2020-02-12 14:13:03 --> Output Class Initialized
INFO - 2020-02-12 14:13:03 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:03 --> Input Class Initialized
INFO - 2020-02-12 14:13:03 --> Language Class Initialized
ERROR - 2020-02-12 14:13:03 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-12 14:13:03 --> Config Class Initialized
INFO - 2020-02-12 14:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:03 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:03 --> URI Class Initialized
INFO - 2020-02-12 14:13:03 --> Router Class Initialized
INFO - 2020-02-12 14:13:03 --> Output Class Initialized
INFO - 2020-02-12 14:13:03 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:03 --> Input Class Initialized
INFO - 2020-02-12 14:13:03 --> Language Class Initialized
ERROR - 2020-02-12 14:13:03 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-12 14:13:03 --> Config Class Initialized
INFO - 2020-02-12 14:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:03 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:03 --> URI Class Initialized
INFO - 2020-02-12 14:13:03 --> Router Class Initialized
INFO - 2020-02-12 14:13:03 --> Output Class Initialized
INFO - 2020-02-12 14:13:03 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:03 --> Input Class Initialized
INFO - 2020-02-12 14:13:03 --> Language Class Initialized
ERROR - 2020-02-12 14:13:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 14:13:03 --> Config Class Initialized
INFO - 2020-02-12 14:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:03 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:03 --> URI Class Initialized
INFO - 2020-02-12 14:13:03 --> Router Class Initialized
INFO - 2020-02-12 14:13:03 --> Output Class Initialized
INFO - 2020-02-12 14:13:03 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:04 --> Input Class Initialized
INFO - 2020-02-12 14:13:04 --> Language Class Initialized
ERROR - 2020-02-12 14:13:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 14:13:04 --> Config Class Initialized
INFO - 2020-02-12 14:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:04 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:04 --> URI Class Initialized
INFO - 2020-02-12 14:13:04 --> Router Class Initialized
INFO - 2020-02-12 14:13:04 --> Output Class Initialized
INFO - 2020-02-12 14:13:04 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:04 --> Input Class Initialized
INFO - 2020-02-12 14:13:04 --> Language Class Initialized
ERROR - 2020-02-12 14:13:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-12 14:13:04 --> Config Class Initialized
INFO - 2020-02-12 14:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:04 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:04 --> URI Class Initialized
INFO - 2020-02-12 14:13:04 --> Router Class Initialized
INFO - 2020-02-12 14:13:04 --> Output Class Initialized
INFO - 2020-02-12 14:13:04 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:04 --> Input Class Initialized
INFO - 2020-02-12 14:13:04 --> Language Class Initialized
ERROR - 2020-02-12 14:13:04 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-12 14:13:04 --> Config Class Initialized
INFO - 2020-02-12 14:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:04 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:04 --> URI Class Initialized
INFO - 2020-02-12 14:13:04 --> Router Class Initialized
INFO - 2020-02-12 14:13:04 --> Output Class Initialized
INFO - 2020-02-12 14:13:04 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:04 --> Input Class Initialized
INFO - 2020-02-12 14:13:04 --> Language Class Initialized
ERROR - 2020-02-12 14:13:04 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-12 14:13:04 --> Config Class Initialized
INFO - 2020-02-12 14:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:13:04 --> Utf8 Class Initialized
INFO - 2020-02-12 14:13:04 --> URI Class Initialized
INFO - 2020-02-12 14:13:04 --> Router Class Initialized
INFO - 2020-02-12 14:13:04 --> Output Class Initialized
INFO - 2020-02-12 14:13:04 --> Security Class Initialized
DEBUG - 2020-02-12 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:13:04 --> Input Class Initialized
INFO - 2020-02-12 14:13:05 --> Language Class Initialized
ERROR - 2020-02-12 14:13:05 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-12 14:14:43 --> Config Class Initialized
INFO - 2020-02-12 14:14:43 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:14:43 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:14:43 --> Utf8 Class Initialized
INFO - 2020-02-12 14:14:43 --> URI Class Initialized
INFO - 2020-02-12 14:14:43 --> Router Class Initialized
INFO - 2020-02-12 14:14:43 --> Output Class Initialized
INFO - 2020-02-12 14:14:43 --> Security Class Initialized
DEBUG - 2020-02-12 14:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:14:43 --> Input Class Initialized
INFO - 2020-02-12 14:14:43 --> Language Class Initialized
INFO - 2020-02-12 14:14:43 --> Loader Class Initialized
INFO - 2020-02-12 14:14:43 --> Helper loaded: url_helper
INFO - 2020-02-12 14:14:43 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:14:43 --> Controller Class Initialized
INFO - 2020-02-12 14:14:44 --> Model "M_tiket" initialized
INFO - 2020-02-12 14:14:44 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 14:14:44 --> Model "M_pesan" initialized
INFO - 2020-02-12 14:14:44 --> Helper loaded: form_helper
INFO - 2020-02-12 14:14:44 --> Form Validation Class Initialized
INFO - 2020-02-12 14:14:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 14:14:44 --> Final output sent to browser
DEBUG - 2020-02-12 14:14:44 --> Total execution time: 1.1759
INFO - 2020-02-12 14:15:35 --> Config Class Initialized
INFO - 2020-02-12 14:15:35 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:15:35 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:15:35 --> Utf8 Class Initialized
INFO - 2020-02-12 14:15:35 --> URI Class Initialized
INFO - 2020-02-12 14:15:35 --> Router Class Initialized
INFO - 2020-02-12 14:15:35 --> Output Class Initialized
INFO - 2020-02-12 14:15:36 --> Security Class Initialized
DEBUG - 2020-02-12 14:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:15:36 --> Input Class Initialized
INFO - 2020-02-12 14:15:36 --> Language Class Initialized
INFO - 2020-02-12 14:15:36 --> Loader Class Initialized
INFO - 2020-02-12 14:15:36 --> Helper loaded: url_helper
INFO - 2020-02-12 14:15:36 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:15:36 --> Controller Class Initialized
INFO - 2020-02-12 14:15:36 --> Model "M_tiket" initialized
INFO - 2020-02-12 14:15:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 14:15:36 --> Model "M_pesan" initialized
INFO - 2020-02-12 14:15:36 --> Helper loaded: form_helper
INFO - 2020-02-12 14:15:36 --> Form Validation Class Initialized
INFO - 2020-02-12 14:15:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 14:15:36 --> Final output sent to browser
DEBUG - 2020-02-12 14:15:36 --> Total execution time: 0.7637
INFO - 2020-02-12 17:34:30 --> Config Class Initialized
INFO - 2020-02-12 17:34:31 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:34:31 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:34:31 --> Utf8 Class Initialized
INFO - 2020-02-12 17:34:32 --> URI Class Initialized
INFO - 2020-02-12 17:34:32 --> Router Class Initialized
INFO - 2020-02-12 17:34:33 --> Output Class Initialized
INFO - 2020-02-12 17:34:33 --> Security Class Initialized
DEBUG - 2020-02-12 17:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:34:34 --> Input Class Initialized
INFO - 2020-02-12 17:34:34 --> Language Class Initialized
ERROR - 2020-02-12 17:34:34 --> Severity: error --> Exception: syntax error, unexpected '(', expecting '{' C:\xampp\htdocs\roadshow\application\controllers\random.php 2
INFO - 2020-02-12 17:35:21 --> Config Class Initialized
INFO - 2020-02-12 17:35:21 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:35:22 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:35:22 --> Utf8 Class Initialized
INFO - 2020-02-12 17:35:22 --> URI Class Initialized
INFO - 2020-02-12 17:35:22 --> Router Class Initialized
INFO - 2020-02-12 17:35:22 --> Output Class Initialized
INFO - 2020-02-12 17:35:22 --> Security Class Initialized
DEBUG - 2020-02-12 17:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:35:23 --> Input Class Initialized
INFO - 2020-02-12 17:35:23 --> Language Class Initialized
INFO - 2020-02-12 17:35:24 --> Loader Class Initialized
INFO - 2020-02-12 17:35:24 --> Helper loaded: url_helper
INFO - 2020-02-12 17:35:25 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:35:26 --> Session: Class initialized using 'files' driver.
ERROR - 2020-02-12 17:35:26 --> Unable to load the requested class: String
INFO - 2020-02-12 17:37:13 --> Config Class Initialized
INFO - 2020-02-12 17:37:13 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:37:14 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:37:14 --> Utf8 Class Initialized
INFO - 2020-02-12 17:37:14 --> URI Class Initialized
INFO - 2020-02-12 17:37:14 --> Router Class Initialized
INFO - 2020-02-12 17:37:14 --> Output Class Initialized
INFO - 2020-02-12 17:37:14 --> Security Class Initialized
DEBUG - 2020-02-12 17:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:37:14 --> Input Class Initialized
INFO - 2020-02-12 17:37:15 --> Language Class Initialized
INFO - 2020-02-12 17:37:15 --> Loader Class Initialized
INFO - 2020-02-12 17:37:15 --> Helper loaded: url_helper
INFO - 2020-02-12 17:37:15 --> Helper loaded: string_helper
INFO - 2020-02-12 17:37:15 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:37:16 --> Controller Class Initialized
INFO - 2020-02-12 17:37:16 --> Final output sent to browser
DEBUG - 2020-02-12 17:37:16 --> Total execution time: 3.2051
INFO - 2020-02-12 17:37:40 --> Config Class Initialized
INFO - 2020-02-12 17:37:41 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:37:41 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:37:41 --> Utf8 Class Initialized
INFO - 2020-02-12 17:37:41 --> URI Class Initialized
INFO - 2020-02-12 17:37:41 --> Router Class Initialized
INFO - 2020-02-12 17:37:41 --> Output Class Initialized
INFO - 2020-02-12 17:37:41 --> Security Class Initialized
DEBUG - 2020-02-12 17:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:37:42 --> Input Class Initialized
INFO - 2020-02-12 17:37:42 --> Language Class Initialized
INFO - 2020-02-12 17:37:42 --> Loader Class Initialized
INFO - 2020-02-12 17:37:42 --> Helper loaded: url_helper
INFO - 2020-02-12 17:37:42 --> Helper loaded: string_helper
INFO - 2020-02-12 17:37:42 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:37:43 --> Controller Class Initialized
INFO - 2020-02-12 17:37:43 --> Final output sent to browser
DEBUG - 2020-02-12 17:37:43 --> Total execution time: 2.3009
INFO - 2020-02-12 17:37:49 --> Config Class Initialized
INFO - 2020-02-12 17:37:49 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:37:49 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:37:50 --> Utf8 Class Initialized
INFO - 2020-02-12 17:37:50 --> URI Class Initialized
INFO - 2020-02-12 17:37:50 --> Router Class Initialized
INFO - 2020-02-12 17:37:50 --> Output Class Initialized
INFO - 2020-02-12 17:37:50 --> Security Class Initialized
DEBUG - 2020-02-12 17:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:37:51 --> Input Class Initialized
INFO - 2020-02-12 17:37:51 --> Language Class Initialized
INFO - 2020-02-12 17:37:51 --> Loader Class Initialized
INFO - 2020-02-12 17:37:51 --> Helper loaded: url_helper
INFO - 2020-02-12 17:37:51 --> Helper loaded: string_helper
INFO - 2020-02-12 17:37:51 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:37:52 --> Controller Class Initialized
INFO - 2020-02-12 17:37:52 --> Final output sent to browser
DEBUG - 2020-02-12 17:37:52 --> Total execution time: 2.6335
INFO - 2020-02-12 17:37:54 --> Config Class Initialized
INFO - 2020-02-12 17:37:54 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:37:54 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:37:54 --> Utf8 Class Initialized
INFO - 2020-02-12 17:37:54 --> URI Class Initialized
INFO - 2020-02-12 17:37:55 --> Router Class Initialized
INFO - 2020-02-12 17:37:55 --> Output Class Initialized
INFO - 2020-02-12 17:37:55 --> Security Class Initialized
DEBUG - 2020-02-12 17:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:37:55 --> Input Class Initialized
INFO - 2020-02-12 17:37:55 --> Language Class Initialized
INFO - 2020-02-12 17:37:55 --> Loader Class Initialized
INFO - 2020-02-12 17:37:56 --> Helper loaded: url_helper
INFO - 2020-02-12 17:37:56 --> Helper loaded: string_helper
INFO - 2020-02-12 17:37:56 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:37:56 --> Controller Class Initialized
INFO - 2020-02-12 17:37:57 --> Final output sent to browser
DEBUG - 2020-02-12 17:37:57 --> Total execution time: 2.7216
INFO - 2020-02-12 17:37:59 --> Config Class Initialized
INFO - 2020-02-12 17:37:59 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:37:59 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:37:59 --> Utf8 Class Initialized
INFO - 2020-02-12 17:37:59 --> URI Class Initialized
INFO - 2020-02-12 17:37:59 --> Router Class Initialized
INFO - 2020-02-12 17:37:59 --> Output Class Initialized
INFO - 2020-02-12 17:37:59 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:00 --> Input Class Initialized
INFO - 2020-02-12 17:38:00 --> Language Class Initialized
INFO - 2020-02-12 17:38:00 --> Loader Class Initialized
INFO - 2020-02-12 17:38:00 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:00 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:00 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:01 --> Controller Class Initialized
INFO - 2020-02-12 17:38:01 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:01 --> Total execution time: 2.4113
INFO - 2020-02-12 17:38:02 --> Config Class Initialized
INFO - 2020-02-12 17:38:02 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:02 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:02 --> URI Class Initialized
INFO - 2020-02-12 17:38:03 --> Router Class Initialized
INFO - 2020-02-12 17:38:03 --> Output Class Initialized
INFO - 2020-02-12 17:38:03 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:03 --> Input Class Initialized
INFO - 2020-02-12 17:38:03 --> Language Class Initialized
INFO - 2020-02-12 17:38:03 --> Loader Class Initialized
INFO - 2020-02-12 17:38:03 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:04 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:04 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:04 --> Controller Class Initialized
INFO - 2020-02-12 17:38:04 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:04 --> Total execution time: 2.2804
INFO - 2020-02-12 17:38:05 --> Config Class Initialized
INFO - 2020-02-12 17:38:05 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:05 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:06 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:06 --> URI Class Initialized
INFO - 2020-02-12 17:38:06 --> Router Class Initialized
INFO - 2020-02-12 17:38:06 --> Output Class Initialized
INFO - 2020-02-12 17:38:06 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:06 --> Input Class Initialized
INFO - 2020-02-12 17:38:07 --> Language Class Initialized
INFO - 2020-02-12 17:38:07 --> Loader Class Initialized
INFO - 2020-02-12 17:38:07 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:07 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:07 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:08 --> Controller Class Initialized
INFO - 2020-02-12 17:38:08 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:08 --> Total execution time: 2.7034
INFO - 2020-02-12 17:38:09 --> Config Class Initialized
INFO - 2020-02-12 17:38:09 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:09 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:09 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:09 --> URI Class Initialized
INFO - 2020-02-12 17:38:09 --> Router Class Initialized
INFO - 2020-02-12 17:38:10 --> Output Class Initialized
INFO - 2020-02-12 17:38:10 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:10 --> Input Class Initialized
INFO - 2020-02-12 17:38:10 --> Language Class Initialized
INFO - 2020-02-12 17:38:10 --> Loader Class Initialized
INFO - 2020-02-12 17:38:10 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:10 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:11 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:11 --> Controller Class Initialized
INFO - 2020-02-12 17:38:11 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:11 --> Total execution time: 2.3882
INFO - 2020-02-12 17:38:12 --> Config Class Initialized
INFO - 2020-02-12 17:38:12 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:12 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:12 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:13 --> URI Class Initialized
INFO - 2020-02-12 17:38:13 --> Router Class Initialized
INFO - 2020-02-12 17:38:13 --> Output Class Initialized
INFO - 2020-02-12 17:38:13 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:13 --> Input Class Initialized
INFO - 2020-02-12 17:38:13 --> Language Class Initialized
INFO - 2020-02-12 17:38:13 --> Loader Class Initialized
INFO - 2020-02-12 17:38:14 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:14 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:14 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:14 --> Controller Class Initialized
INFO - 2020-02-12 17:38:15 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:15 --> Total execution time: 2.4955
INFO - 2020-02-12 17:38:16 --> Config Class Initialized
INFO - 2020-02-12 17:38:16 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:16 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:16 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:16 --> URI Class Initialized
INFO - 2020-02-12 17:38:16 --> Router Class Initialized
INFO - 2020-02-12 17:38:16 --> Output Class Initialized
INFO - 2020-02-12 17:38:17 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:17 --> Input Class Initialized
INFO - 2020-02-12 17:38:17 --> Language Class Initialized
INFO - 2020-02-12 17:38:17 --> Loader Class Initialized
INFO - 2020-02-12 17:38:17 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:17 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:18 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:18 --> Controller Class Initialized
INFO - 2020-02-12 17:38:18 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:18 --> Total execution time: 2.5947
INFO - 2020-02-12 17:38:19 --> Config Class Initialized
INFO - 2020-02-12 17:38:19 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:19 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:19 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:19 --> URI Class Initialized
INFO - 2020-02-12 17:38:20 --> Router Class Initialized
INFO - 2020-02-12 17:38:20 --> Output Class Initialized
INFO - 2020-02-12 17:38:20 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:20 --> Input Class Initialized
INFO - 2020-02-12 17:38:20 --> Language Class Initialized
INFO - 2020-02-12 17:38:20 --> Loader Class Initialized
INFO - 2020-02-12 17:38:20 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:21 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:21 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:21 --> Controller Class Initialized
INFO - 2020-02-12 17:38:21 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:21 --> Total execution time: 2.2577
INFO - 2020-02-12 17:38:22 --> Config Class Initialized
INFO - 2020-02-12 17:38:22 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:22 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:23 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:23 --> URI Class Initialized
INFO - 2020-02-12 17:38:23 --> Router Class Initialized
INFO - 2020-02-12 17:38:23 --> Output Class Initialized
INFO - 2020-02-12 17:38:23 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:24 --> Input Class Initialized
INFO - 2020-02-12 17:38:24 --> Language Class Initialized
INFO - 2020-02-12 17:38:24 --> Loader Class Initialized
INFO - 2020-02-12 17:38:24 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:24 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:24 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:25 --> Controller Class Initialized
INFO - 2020-02-12 17:38:25 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:25 --> Total execution time: 2.8923
INFO - 2020-02-12 17:38:26 --> Config Class Initialized
INFO - 2020-02-12 17:38:26 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:26 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:26 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:26 --> URI Class Initialized
INFO - 2020-02-12 17:38:27 --> Router Class Initialized
INFO - 2020-02-12 17:38:27 --> Output Class Initialized
INFO - 2020-02-12 17:38:27 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:27 --> Input Class Initialized
INFO - 2020-02-12 17:38:27 --> Language Class Initialized
INFO - 2020-02-12 17:38:27 --> Loader Class Initialized
INFO - 2020-02-12 17:38:28 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:28 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:28 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:28 --> Controller Class Initialized
INFO - 2020-02-12 17:38:28 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:28 --> Total execution time: 2.4186
INFO - 2020-02-12 17:38:29 --> Config Class Initialized
INFO - 2020-02-12 17:38:29 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:29 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:30 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:30 --> URI Class Initialized
INFO - 2020-02-12 17:38:30 --> Router Class Initialized
INFO - 2020-02-12 17:38:30 --> Output Class Initialized
INFO - 2020-02-12 17:38:30 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:30 --> Input Class Initialized
INFO - 2020-02-12 17:38:30 --> Language Class Initialized
INFO - 2020-02-12 17:38:31 --> Loader Class Initialized
INFO - 2020-02-12 17:38:31 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:31 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:31 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:31 --> Controller Class Initialized
INFO - 2020-02-12 17:38:32 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:32 --> Total execution time: 2.3947
INFO - 2020-02-12 17:38:38 --> Config Class Initialized
INFO - 2020-02-12 17:38:38 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:38 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:38 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:38 --> URI Class Initialized
INFO - 2020-02-12 17:38:38 --> Router Class Initialized
INFO - 2020-02-12 17:38:38 --> Output Class Initialized
INFO - 2020-02-12 17:38:38 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:39 --> Input Class Initialized
INFO - 2020-02-12 17:38:39 --> Language Class Initialized
INFO - 2020-02-12 17:38:39 --> Loader Class Initialized
INFO - 2020-02-12 17:38:39 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:39 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:39 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:40 --> Controller Class Initialized
INFO - 2020-02-12 17:38:40 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:40 --> Total execution time: 2.3829
INFO - 2020-02-12 17:38:41 --> Config Class Initialized
INFO - 2020-02-12 17:38:41 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:42 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:42 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:42 --> URI Class Initialized
INFO - 2020-02-12 17:38:42 --> Router Class Initialized
INFO - 2020-02-12 17:38:42 --> Output Class Initialized
INFO - 2020-02-12 17:38:42 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:42 --> Input Class Initialized
INFO - 2020-02-12 17:38:43 --> Language Class Initialized
INFO - 2020-02-12 17:38:43 --> Loader Class Initialized
INFO - 2020-02-12 17:38:43 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:43 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:43 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:43 --> Controller Class Initialized
INFO - 2020-02-12 17:38:44 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:44 --> Total execution time: 2.3209
INFO - 2020-02-12 17:38:45 --> Config Class Initialized
INFO - 2020-02-12 17:38:45 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:45 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:45 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:45 --> URI Class Initialized
INFO - 2020-02-12 17:38:45 --> Router Class Initialized
INFO - 2020-02-12 17:38:46 --> Output Class Initialized
INFO - 2020-02-12 17:38:46 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:46 --> Input Class Initialized
INFO - 2020-02-12 17:38:46 --> Language Class Initialized
INFO - 2020-02-12 17:38:46 --> Loader Class Initialized
INFO - 2020-02-12 17:38:46 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:46 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:47 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:47 --> Controller Class Initialized
INFO - 2020-02-12 17:38:47 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:47 --> Total execution time: 2.3686
INFO - 2020-02-12 17:38:48 --> Config Class Initialized
INFO - 2020-02-12 17:38:48 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:48 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:49 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:49 --> URI Class Initialized
INFO - 2020-02-12 17:38:49 --> Router Class Initialized
INFO - 2020-02-12 17:38:49 --> Output Class Initialized
INFO - 2020-02-12 17:38:49 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:49 --> Input Class Initialized
INFO - 2020-02-12 17:38:49 --> Language Class Initialized
INFO - 2020-02-12 17:38:50 --> Loader Class Initialized
INFO - 2020-02-12 17:38:50 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:50 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:50 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:50 --> Controller Class Initialized
INFO - 2020-02-12 17:38:51 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:51 --> Total execution time: 2.3735
INFO - 2020-02-12 17:38:52 --> Config Class Initialized
INFO - 2020-02-12 17:38:52 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:52 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:52 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:52 --> URI Class Initialized
INFO - 2020-02-12 17:38:52 --> Router Class Initialized
INFO - 2020-02-12 17:38:52 --> Output Class Initialized
INFO - 2020-02-12 17:38:52 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:53 --> Input Class Initialized
INFO - 2020-02-12 17:38:53 --> Language Class Initialized
INFO - 2020-02-12 17:38:53 --> Loader Class Initialized
INFO - 2020-02-12 17:38:53 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:53 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:53 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:54 --> Controller Class Initialized
INFO - 2020-02-12 17:38:54 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:54 --> Total execution time: 2.3376
INFO - 2020-02-12 17:38:55 --> Config Class Initialized
INFO - 2020-02-12 17:38:55 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:55 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:55 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:55 --> URI Class Initialized
INFO - 2020-02-12 17:38:55 --> Router Class Initialized
INFO - 2020-02-12 17:38:56 --> Output Class Initialized
INFO - 2020-02-12 17:38:56 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:56 --> Input Class Initialized
INFO - 2020-02-12 17:38:56 --> Language Class Initialized
INFO - 2020-02-12 17:38:56 --> Loader Class Initialized
INFO - 2020-02-12 17:38:56 --> Helper loaded: url_helper
INFO - 2020-02-12 17:38:56 --> Helper loaded: string_helper
INFO - 2020-02-12 17:38:57 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:38:57 --> Controller Class Initialized
INFO - 2020-02-12 17:38:57 --> Final output sent to browser
DEBUG - 2020-02-12 17:38:57 --> Total execution time: 2.3545
INFO - 2020-02-12 17:38:58 --> Config Class Initialized
INFO - 2020-02-12 17:38:58 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:38:58 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:38:58 --> Utf8 Class Initialized
INFO - 2020-02-12 17:38:59 --> URI Class Initialized
INFO - 2020-02-12 17:38:59 --> Router Class Initialized
INFO - 2020-02-12 17:38:59 --> Output Class Initialized
INFO - 2020-02-12 17:38:59 --> Security Class Initialized
DEBUG - 2020-02-12 17:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:38:59 --> Input Class Initialized
INFO - 2020-02-12 17:38:59 --> Language Class Initialized
INFO - 2020-02-12 17:38:59 --> Loader Class Initialized
INFO - 2020-02-12 17:39:00 --> Helper loaded: url_helper
INFO - 2020-02-12 17:39:00 --> Helper loaded: string_helper
INFO - 2020-02-12 17:39:00 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:39:00 --> Controller Class Initialized
INFO - 2020-02-12 17:39:01 --> Final output sent to browser
DEBUG - 2020-02-12 17:39:01 --> Total execution time: 2.5788
INFO - 2020-02-12 17:39:02 --> Config Class Initialized
INFO - 2020-02-12 17:39:02 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:39:02 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:39:02 --> Utf8 Class Initialized
INFO - 2020-02-12 17:39:02 --> URI Class Initialized
INFO - 2020-02-12 17:39:02 --> Router Class Initialized
INFO - 2020-02-12 17:39:02 --> Output Class Initialized
INFO - 2020-02-12 17:39:03 --> Security Class Initialized
DEBUG - 2020-02-12 17:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:39:03 --> Input Class Initialized
INFO - 2020-02-12 17:39:03 --> Language Class Initialized
INFO - 2020-02-12 17:39:03 --> Loader Class Initialized
INFO - 2020-02-12 17:39:03 --> Helper loaded: url_helper
INFO - 2020-02-12 17:39:03 --> Helper loaded: string_helper
INFO - 2020-02-12 17:39:03 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:39:04 --> Controller Class Initialized
INFO - 2020-02-12 17:39:04 --> Final output sent to browser
DEBUG - 2020-02-12 17:39:04 --> Total execution time: 2.3002
INFO - 2020-02-12 17:39:05 --> Config Class Initialized
INFO - 2020-02-12 17:39:05 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:39:05 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:39:05 --> Utf8 Class Initialized
INFO - 2020-02-12 17:39:05 --> URI Class Initialized
INFO - 2020-02-12 17:39:05 --> Router Class Initialized
INFO - 2020-02-12 17:39:06 --> Output Class Initialized
INFO - 2020-02-12 17:39:06 --> Security Class Initialized
DEBUG - 2020-02-12 17:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:39:06 --> Input Class Initialized
INFO - 2020-02-12 17:39:06 --> Language Class Initialized
INFO - 2020-02-12 17:39:06 --> Loader Class Initialized
INFO - 2020-02-12 17:39:06 --> Helper loaded: url_helper
INFO - 2020-02-12 17:39:06 --> Helper loaded: string_helper
INFO - 2020-02-12 17:39:07 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:39:07 --> Controller Class Initialized
INFO - 2020-02-12 17:39:07 --> Final output sent to browser
DEBUG - 2020-02-12 17:39:07 --> Total execution time: 2.3601
INFO - 2020-02-12 17:39:08 --> Config Class Initialized
INFO - 2020-02-12 17:39:08 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:39:08 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:39:08 --> Utf8 Class Initialized
INFO - 2020-02-12 17:39:09 --> URI Class Initialized
INFO - 2020-02-12 17:39:09 --> Router Class Initialized
INFO - 2020-02-12 17:39:09 --> Output Class Initialized
INFO - 2020-02-12 17:39:09 --> Security Class Initialized
DEBUG - 2020-02-12 17:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:39:09 --> Input Class Initialized
INFO - 2020-02-12 17:39:09 --> Language Class Initialized
INFO - 2020-02-12 17:39:09 --> Loader Class Initialized
INFO - 2020-02-12 17:39:10 --> Helper loaded: url_helper
INFO - 2020-02-12 17:39:10 --> Helper loaded: string_helper
INFO - 2020-02-12 17:39:10 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:39:10 --> Controller Class Initialized
INFO - 2020-02-12 17:39:10 --> Final output sent to browser
DEBUG - 2020-02-12 17:39:11 --> Total execution time: 2.4729
INFO - 2020-02-12 17:39:11 --> Config Class Initialized
INFO - 2020-02-12 17:39:12 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:39:12 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:39:12 --> Utf8 Class Initialized
INFO - 2020-02-12 17:39:12 --> URI Class Initialized
INFO - 2020-02-12 17:39:12 --> Router Class Initialized
INFO - 2020-02-12 17:39:12 --> Output Class Initialized
INFO - 2020-02-12 17:39:12 --> Security Class Initialized
DEBUG - 2020-02-12 17:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:39:13 --> Input Class Initialized
INFO - 2020-02-12 17:39:13 --> Language Class Initialized
INFO - 2020-02-12 17:39:13 --> Loader Class Initialized
INFO - 2020-02-12 17:39:13 --> Helper loaded: url_helper
INFO - 2020-02-12 17:39:13 --> Helper loaded: string_helper
INFO - 2020-02-12 17:39:13 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:39:14 --> Controller Class Initialized
INFO - 2020-02-12 17:39:14 --> Final output sent to browser
DEBUG - 2020-02-12 17:39:14 --> Total execution time: 2.3398
INFO - 2020-02-12 17:39:15 --> Config Class Initialized
INFO - 2020-02-12 17:39:15 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:39:15 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:39:15 --> Utf8 Class Initialized
INFO - 2020-02-12 17:39:15 --> URI Class Initialized
INFO - 2020-02-12 17:39:15 --> Router Class Initialized
INFO - 2020-02-12 17:39:15 --> Output Class Initialized
INFO - 2020-02-12 17:39:16 --> Security Class Initialized
DEBUG - 2020-02-12 17:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:39:16 --> Input Class Initialized
INFO - 2020-02-12 17:39:16 --> Language Class Initialized
INFO - 2020-02-12 17:39:16 --> Loader Class Initialized
INFO - 2020-02-12 17:39:16 --> Helper loaded: url_helper
INFO - 2020-02-12 17:39:16 --> Helper loaded: string_helper
INFO - 2020-02-12 17:39:16 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:39:17 --> Controller Class Initialized
INFO - 2020-02-12 17:39:17 --> Final output sent to browser
DEBUG - 2020-02-12 17:39:17 --> Total execution time: 2.4050
INFO - 2020-02-12 17:41:06 --> Config Class Initialized
INFO - 2020-02-12 17:41:06 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:41:06 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:41:06 --> Utf8 Class Initialized
INFO - 2020-02-12 17:41:06 --> URI Class Initialized
INFO - 2020-02-12 17:41:06 --> Router Class Initialized
INFO - 2020-02-12 17:41:07 --> Output Class Initialized
INFO - 2020-02-12 17:41:07 --> Security Class Initialized
DEBUG - 2020-02-12 17:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:41:07 --> Input Class Initialized
INFO - 2020-02-12 17:41:07 --> Language Class Initialized
INFO - 2020-02-12 17:41:07 --> Loader Class Initialized
INFO - 2020-02-12 17:41:07 --> Helper loaded: url_helper
INFO - 2020-02-12 17:41:08 --> Helper loaded: string_helper
INFO - 2020-02-12 17:41:08 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:41:09 --> Controller Class Initialized
INFO - 2020-02-12 17:41:09 --> Final output sent to browser
DEBUG - 2020-02-12 17:41:09 --> Total execution time: 3.2727
INFO - 2020-02-12 17:41:25 --> Config Class Initialized
INFO - 2020-02-12 17:41:25 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:41:25 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:41:25 --> Utf8 Class Initialized
INFO - 2020-02-12 17:41:25 --> URI Class Initialized
INFO - 2020-02-12 17:41:26 --> Router Class Initialized
INFO - 2020-02-12 17:41:26 --> Output Class Initialized
INFO - 2020-02-12 17:41:26 --> Security Class Initialized
DEBUG - 2020-02-12 17:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:41:26 --> Input Class Initialized
INFO - 2020-02-12 17:41:26 --> Language Class Initialized
INFO - 2020-02-12 17:41:26 --> Loader Class Initialized
INFO - 2020-02-12 17:41:26 --> Helper loaded: url_helper
INFO - 2020-02-12 17:41:27 --> Helper loaded: string_helper
INFO - 2020-02-12 17:41:27 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:41:27 --> Controller Class Initialized
INFO - 2020-02-12 17:41:27 --> Final output sent to browser
DEBUG - 2020-02-12 17:41:27 --> Total execution time: 2.4785
INFO - 2020-02-12 17:41:30 --> Config Class Initialized
INFO - 2020-02-12 17:41:30 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:41:30 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:41:31 --> Utf8 Class Initialized
INFO - 2020-02-12 17:41:31 --> URI Class Initialized
INFO - 2020-02-12 17:41:31 --> Router Class Initialized
INFO - 2020-02-12 17:41:31 --> Output Class Initialized
INFO - 2020-02-12 17:41:31 --> Security Class Initialized
DEBUG - 2020-02-12 17:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:41:31 --> Input Class Initialized
INFO - 2020-02-12 17:41:31 --> Language Class Initialized
INFO - 2020-02-12 17:41:32 --> Loader Class Initialized
INFO - 2020-02-12 17:41:32 --> Helper loaded: url_helper
INFO - 2020-02-12 17:41:32 --> Helper loaded: string_helper
INFO - 2020-02-12 17:41:32 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:41:32 --> Controller Class Initialized
INFO - 2020-02-12 17:41:33 --> Final output sent to browser
DEBUG - 2020-02-12 17:41:33 --> Total execution time: 2.3831
INFO - 2020-02-12 17:41:35 --> Config Class Initialized
INFO - 2020-02-12 17:41:35 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:41:35 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:41:35 --> Utf8 Class Initialized
INFO - 2020-02-12 17:41:35 --> URI Class Initialized
INFO - 2020-02-12 17:41:35 --> Router Class Initialized
INFO - 2020-02-12 17:41:35 --> Output Class Initialized
INFO - 2020-02-12 17:41:36 --> Security Class Initialized
DEBUG - 2020-02-12 17:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:41:36 --> Input Class Initialized
INFO - 2020-02-12 17:41:36 --> Language Class Initialized
INFO - 2020-02-12 17:41:36 --> Loader Class Initialized
INFO - 2020-02-12 17:41:36 --> Helper loaded: url_helper
INFO - 2020-02-12 17:41:36 --> Helper loaded: string_helper
INFO - 2020-02-12 17:41:37 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:41:37 --> Controller Class Initialized
INFO - 2020-02-12 17:41:37 --> Final output sent to browser
DEBUG - 2020-02-12 17:41:37 --> Total execution time: 2.6098
INFO - 2020-02-12 17:41:38 --> Config Class Initialized
INFO - 2020-02-12 17:41:38 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:41:38 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:41:39 --> Utf8 Class Initialized
INFO - 2020-02-12 17:41:39 --> URI Class Initialized
INFO - 2020-02-12 17:41:39 --> Router Class Initialized
INFO - 2020-02-12 17:41:39 --> Output Class Initialized
INFO - 2020-02-12 17:41:39 --> Security Class Initialized
DEBUG - 2020-02-12 17:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:41:39 --> Input Class Initialized
INFO - 2020-02-12 17:41:39 --> Language Class Initialized
INFO - 2020-02-12 17:41:40 --> Loader Class Initialized
INFO - 2020-02-12 17:41:40 --> Helper loaded: url_helper
INFO - 2020-02-12 17:41:40 --> Helper loaded: string_helper
INFO - 2020-02-12 17:41:40 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:41:40 --> Controller Class Initialized
INFO - 2020-02-12 17:41:40 --> Final output sent to browser
DEBUG - 2020-02-12 17:41:41 --> Total execution time: 2.3749
INFO - 2020-02-12 17:41:41 --> Config Class Initialized
INFO - 2020-02-12 17:41:42 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:41:42 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:41:42 --> Utf8 Class Initialized
INFO - 2020-02-12 17:41:42 --> URI Class Initialized
INFO - 2020-02-12 17:41:42 --> Router Class Initialized
INFO - 2020-02-12 17:41:42 --> Output Class Initialized
INFO - 2020-02-12 17:41:42 --> Security Class Initialized
DEBUG - 2020-02-12 17:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:41:43 --> Input Class Initialized
INFO - 2020-02-12 17:41:43 --> Language Class Initialized
INFO - 2020-02-12 17:41:43 --> Loader Class Initialized
INFO - 2020-02-12 17:41:43 --> Helper loaded: url_helper
INFO - 2020-02-12 17:41:43 --> Helper loaded: string_helper
INFO - 2020-02-12 17:41:43 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:41:44 --> Controller Class Initialized
INFO - 2020-02-12 17:41:44 --> Final output sent to browser
DEBUG - 2020-02-12 17:41:44 --> Total execution time: 2.4199
INFO - 2020-02-12 17:41:45 --> Config Class Initialized
INFO - 2020-02-12 17:41:45 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:41:45 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:41:45 --> Utf8 Class Initialized
INFO - 2020-02-12 17:41:45 --> URI Class Initialized
INFO - 2020-02-12 17:41:46 --> Router Class Initialized
INFO - 2020-02-12 17:41:46 --> Output Class Initialized
INFO - 2020-02-12 17:41:46 --> Security Class Initialized
DEBUG - 2020-02-12 17:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:41:46 --> Input Class Initialized
INFO - 2020-02-12 17:41:46 --> Language Class Initialized
INFO - 2020-02-12 17:41:46 --> Loader Class Initialized
INFO - 2020-02-12 17:41:46 --> Helper loaded: url_helper
INFO - 2020-02-12 17:41:47 --> Helper loaded: string_helper
INFO - 2020-02-12 17:41:47 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:41:47 --> Controller Class Initialized
INFO - 2020-02-12 17:41:47 --> Final output sent to browser
DEBUG - 2020-02-12 17:41:47 --> Total execution time: 2.5344
INFO - 2020-02-12 17:41:48 --> Config Class Initialized
INFO - 2020-02-12 17:41:49 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:41:49 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:41:49 --> Utf8 Class Initialized
INFO - 2020-02-12 17:41:49 --> URI Class Initialized
INFO - 2020-02-12 17:41:49 --> Router Class Initialized
INFO - 2020-02-12 17:41:49 --> Output Class Initialized
INFO - 2020-02-12 17:41:49 --> Security Class Initialized
DEBUG - 2020-02-12 17:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:41:50 --> Input Class Initialized
INFO - 2020-02-12 17:41:50 --> Language Class Initialized
INFO - 2020-02-12 17:41:50 --> Loader Class Initialized
INFO - 2020-02-12 17:41:50 --> Helper loaded: url_helper
INFO - 2020-02-12 17:41:50 --> Helper loaded: string_helper
INFO - 2020-02-12 17:41:50 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:41:51 --> Controller Class Initialized
INFO - 2020-02-12 17:41:51 --> Final output sent to browser
DEBUG - 2020-02-12 17:41:51 --> Total execution time: 2.4216
INFO - 2020-02-12 17:41:52 --> Config Class Initialized
INFO - 2020-02-12 17:41:52 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:41:52 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:41:52 --> Utf8 Class Initialized
INFO - 2020-02-12 17:41:52 --> URI Class Initialized
INFO - 2020-02-12 17:41:53 --> Router Class Initialized
INFO - 2020-02-12 17:41:53 --> Output Class Initialized
INFO - 2020-02-12 17:41:53 --> Security Class Initialized
DEBUG - 2020-02-12 17:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:41:53 --> Input Class Initialized
INFO - 2020-02-12 17:41:53 --> Language Class Initialized
INFO - 2020-02-12 17:41:53 --> Loader Class Initialized
INFO - 2020-02-12 17:41:53 --> Helper loaded: url_helper
INFO - 2020-02-12 17:41:54 --> Helper loaded: string_helper
INFO - 2020-02-12 17:41:54 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:41:54 --> Controller Class Initialized
INFO - 2020-02-12 17:41:54 --> Final output sent to browser
DEBUG - 2020-02-12 17:41:54 --> Total execution time: 2.3998
INFO - 2020-02-12 17:41:55 --> Config Class Initialized
INFO - 2020-02-12 17:41:56 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:41:56 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:41:56 --> Utf8 Class Initialized
INFO - 2020-02-12 17:41:56 --> URI Class Initialized
INFO - 2020-02-12 17:41:56 --> Router Class Initialized
INFO - 2020-02-12 17:41:56 --> Output Class Initialized
INFO - 2020-02-12 17:41:56 --> Security Class Initialized
DEBUG - 2020-02-12 17:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:41:57 --> Input Class Initialized
INFO - 2020-02-12 17:41:57 --> Language Class Initialized
INFO - 2020-02-12 17:41:57 --> Loader Class Initialized
INFO - 2020-02-12 17:41:57 --> Helper loaded: url_helper
INFO - 2020-02-12 17:41:57 --> Helper loaded: string_helper
INFO - 2020-02-12 17:41:57 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:41:58 --> Controller Class Initialized
INFO - 2020-02-12 17:41:58 --> Final output sent to browser
DEBUG - 2020-02-12 17:41:58 --> Total execution time: 2.5201
INFO - 2020-02-12 17:41:59 --> Config Class Initialized
INFO - 2020-02-12 17:41:59 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:42:00 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:42:00 --> Utf8 Class Initialized
INFO - 2020-02-12 17:42:00 --> URI Class Initialized
INFO - 2020-02-12 17:42:00 --> Router Class Initialized
INFO - 2020-02-12 17:42:00 --> Output Class Initialized
INFO - 2020-02-12 17:42:00 --> Security Class Initialized
DEBUG - 2020-02-12 17:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:42:01 --> Input Class Initialized
INFO - 2020-02-12 17:42:01 --> Language Class Initialized
INFO - 2020-02-12 17:42:01 --> Loader Class Initialized
INFO - 2020-02-12 17:42:01 --> Helper loaded: url_helper
INFO - 2020-02-12 17:42:01 --> Helper loaded: string_helper
INFO - 2020-02-12 17:42:01 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:42:02 --> Controller Class Initialized
INFO - 2020-02-12 17:42:02 --> Final output sent to browser
DEBUG - 2020-02-12 17:42:02 --> Total execution time: 2.6232
INFO - 2020-02-12 17:42:03 --> Config Class Initialized
INFO - 2020-02-12 17:42:03 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:42:03 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:42:04 --> Utf8 Class Initialized
INFO - 2020-02-12 17:42:04 --> URI Class Initialized
INFO - 2020-02-12 17:42:04 --> Router Class Initialized
INFO - 2020-02-12 17:42:04 --> Output Class Initialized
INFO - 2020-02-12 17:42:04 --> Security Class Initialized
DEBUG - 2020-02-12 17:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:42:04 --> Input Class Initialized
INFO - 2020-02-12 17:42:04 --> Language Class Initialized
INFO - 2020-02-12 17:42:05 --> Loader Class Initialized
INFO - 2020-02-12 17:42:05 --> Helper loaded: url_helper
INFO - 2020-02-12 17:42:05 --> Helper loaded: string_helper
INFO - 2020-02-12 17:42:05 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:42:06 --> Controller Class Initialized
INFO - 2020-02-12 17:42:06 --> Final output sent to browser
DEBUG - 2020-02-12 17:42:07 --> Total execution time: 3.3271
INFO - 2020-02-12 17:43:57 --> Config Class Initialized
INFO - 2020-02-12 17:43:57 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:43:57 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:43:57 --> Utf8 Class Initialized
INFO - 2020-02-12 17:43:57 --> URI Class Initialized
DEBUG - 2020-02-12 17:43:58 --> No URI present. Default controller set.
INFO - 2020-02-12 17:43:58 --> Router Class Initialized
INFO - 2020-02-12 17:43:58 --> Output Class Initialized
INFO - 2020-02-12 17:43:58 --> Security Class Initialized
DEBUG - 2020-02-12 17:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:43:58 --> Input Class Initialized
INFO - 2020-02-12 17:43:58 --> Language Class Initialized
INFO - 2020-02-12 17:43:59 --> Loader Class Initialized
INFO - 2020-02-12 17:43:59 --> Helper loaded: url_helper
INFO - 2020-02-12 17:43:59 --> Helper loaded: string_helper
INFO - 2020-02-12 17:43:59 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:44:00 --> Controller Class Initialized
INFO - 2020-02-12 17:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-12 17:44:00 --> Pagination Class Initialized
INFO - 2020-02-12 17:44:00 --> Model "M_show" initialized
INFO - 2020-02-12 17:44:01 --> Config Class Initialized
INFO - 2020-02-12 17:44:01 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:01 --> Helper loaded: form_helper
INFO - 2020-02-12 17:44:01 --> Form Validation Class Initialized
DEBUG - 2020-02-12 17:44:01 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:01 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:01 --> URI Class Initialized
DEBUG - 2020-02-12 17:44:01 --> No URI present. Default controller set.
INFO - 2020-02-12 17:44:02 --> Router Class Initialized
INFO - 2020-02-12 17:44:02 --> Output Class Initialized
INFO - 2020-02-12 17:44:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-12 17:44:02 --> Final output sent to browser
INFO - 2020-02-12 17:44:02 --> Security Class Initialized
DEBUG - 2020-02-12 17:44:02 --> Total execution time: 5.1022
DEBUG - 2020-02-12 17:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:02 --> Input Class Initialized
INFO - 2020-02-12 17:44:02 --> Language Class Initialized
INFO - 2020-02-12 17:44:02 --> Loader Class Initialized
INFO - 2020-02-12 17:44:02 --> Helper loaded: url_helper
INFO - 2020-02-12 17:44:03 --> Helper loaded: string_helper
INFO - 2020-02-12 17:44:03 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:44:03 --> Controller Class Initialized
INFO - 2020-02-12 17:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-12 17:44:03 --> Pagination Class Initialized
INFO - 2020-02-12 17:44:04 --> Model "M_show" initialized
INFO - 2020-02-12 17:44:04 --> Helper loaded: form_helper
INFO - 2020-02-12 17:44:04 --> Form Validation Class Initialized
INFO - 2020-02-12 17:44:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-12 17:44:04 --> Final output sent to browser
DEBUG - 2020-02-12 17:44:05 --> Total execution time: 3.4980
INFO - 2020-02-12 17:44:11 --> Config Class Initialized
INFO - 2020-02-12 17:44:11 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:44:11 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:11 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:12 --> URI Class Initialized
INFO - 2020-02-12 17:44:12 --> Router Class Initialized
INFO - 2020-02-12 17:44:12 --> Output Class Initialized
INFO - 2020-02-12 17:44:12 --> Security Class Initialized
DEBUG - 2020-02-12 17:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:12 --> Input Class Initialized
INFO - 2020-02-12 17:44:12 --> Language Class Initialized
INFO - 2020-02-12 17:44:13 --> Loader Class Initialized
INFO - 2020-02-12 17:44:13 --> Helper loaded: url_helper
INFO - 2020-02-12 17:44:13 --> Helper loaded: string_helper
INFO - 2020-02-12 17:44:14 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:44:14 --> Controller Class Initialized
INFO - 2020-02-12 17:44:14 --> Model "M_tiket" initialized
INFO - 2020-02-12 17:44:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 17:44:15 --> Model "M_pesan" initialized
INFO - 2020-02-12 17:44:15 --> Helper loaded: form_helper
INFO - 2020-02-12 17:44:15 --> Form Validation Class Initialized
INFO - 2020-02-12 17:44:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 17:44:15 --> Final output sent to browser
DEBUG - 2020-02-12 17:44:16 --> Total execution time: 4.4618
INFO - 2020-02-12 17:44:16 --> Config Class Initialized
INFO - 2020-02-12 17:44:16 --> Config Class Initialized
INFO - 2020-02-12 17:44:16 --> Config Class Initialized
INFO - 2020-02-12 17:44:16 --> Config Class Initialized
INFO - 2020-02-12 17:44:16 --> Config Class Initialized
INFO - 2020-02-12 17:44:16 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:16 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:16 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:16 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:16 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:16 --> Config Class Initialized
INFO - 2020-02-12 17:44:16 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:44:16 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 17:44:16 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 17:44:16 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:17 --> Utf8 Class Initialized
DEBUG - 2020-02-12 17:44:17 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:17 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:17 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:17 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:17 --> URI Class Initialized
INFO - 2020-02-12 17:44:17 --> URI Class Initialized
DEBUG - 2020-02-12 17:44:17 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:17 --> URI Class Initialized
INFO - 2020-02-12 17:44:17 --> URI Class Initialized
DEBUG - 2020-02-12 17:44:17 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:17 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:17 --> Router Class Initialized
INFO - 2020-02-12 17:44:17 --> Router Class Initialized
INFO - 2020-02-12 17:44:17 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:17 --> Router Class Initialized
INFO - 2020-02-12 17:44:17 --> Router Class Initialized
INFO - 2020-02-12 17:44:17 --> Output Class Initialized
INFO - 2020-02-12 17:44:17 --> URI Class Initialized
INFO - 2020-02-12 17:44:17 --> Output Class Initialized
INFO - 2020-02-12 17:44:17 --> URI Class Initialized
INFO - 2020-02-12 17:44:17 --> Output Class Initialized
INFO - 2020-02-12 17:44:17 --> Output Class Initialized
INFO - 2020-02-12 17:44:17 --> Router Class Initialized
INFO - 2020-02-12 17:44:17 --> Security Class Initialized
INFO - 2020-02-12 17:44:17 --> Security Class Initialized
INFO - 2020-02-12 17:44:17 --> Router Class Initialized
INFO - 2020-02-12 17:44:17 --> Security Class Initialized
INFO - 2020-02-12 17:44:17 --> Security Class Initialized
INFO - 2020-02-12 17:44:18 --> Output Class Initialized
DEBUG - 2020-02-12 17:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 17:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 17:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 17:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:18 --> Input Class Initialized
INFO - 2020-02-12 17:44:18 --> Input Class Initialized
INFO - 2020-02-12 17:44:18 --> Input Class Initialized
INFO - 2020-02-12 17:44:18 --> Input Class Initialized
INFO - 2020-02-12 17:44:18 --> Security Class Initialized
INFO - 2020-02-12 17:44:18 --> Output Class Initialized
INFO - 2020-02-12 17:44:18 --> Language Class Initialized
INFO - 2020-02-12 17:44:18 --> Language Class Initialized
INFO - 2020-02-12 17:44:18 --> Language Class Initialized
INFO - 2020-02-12 17:44:18 --> Language Class Initialized
DEBUG - 2020-02-12 17:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:18 --> Input Class Initialized
ERROR - 2020-02-12 17:44:18 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-12 17:44:18 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-12 17:44:18 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-12 17:44:18 --> Security Class Initialized
INFO - 2020-02-12 17:44:18 --> Loader Class Initialized
INFO - 2020-02-12 17:44:18 --> Language Class Initialized
DEBUG - 2020-02-12 17:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:18 --> Helper loaded: url_helper
INFO - 2020-02-12 17:44:18 --> Input Class Initialized
INFO - 2020-02-12 17:44:18 --> Helper loaded: string_helper
ERROR - 2020-02-12 17:44:18 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-12 17:44:18 --> Config Class Initialized
INFO - 2020-02-12 17:44:19 --> Config Class Initialized
INFO - 2020-02-12 17:44:19 --> Config Class Initialized
INFO - 2020-02-12 17:44:19 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:19 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:19 --> Language Class Initialized
INFO - 2020-02-12 17:44:19 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:19 --> Database Driver Class Initialized
INFO - 2020-02-12 17:44:19 --> Config Class Initialized
INFO - 2020-02-12 17:44:19 --> Hooks Class Initialized
ERROR - 2020-02-12 17:44:19 --> 404 Page Not Found: Bower_components/jquery-ui
DEBUG - 2020-02-12 17:44:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 17:44:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 17:44:19 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 17:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:44:19 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:19 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:19 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-12 17:44:19 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:19 --> Config Class Initialized
INFO - 2020-02-12 17:44:19 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:19 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:19 --> URI Class Initialized
INFO - 2020-02-12 17:44:19 --> URI Class Initialized
INFO - 2020-02-12 17:44:19 --> Controller Class Initialized
INFO - 2020-02-12 17:44:19 --> URI Class Initialized
INFO - 2020-02-12 17:44:19 --> URI Class Initialized
INFO - 2020-02-12 17:44:19 --> Router Class Initialized
INFO - 2020-02-12 17:44:19 --> Router Class Initialized
INFO - 2020-02-12 17:44:19 --> Model "M_tiket" initialized
INFO - 2020-02-12 17:44:19 --> Router Class Initialized
DEBUG - 2020-02-12 17:44:19 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 17:44:20 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:20 --> Router Class Initialized
INFO - 2020-02-12 17:44:20 --> Output Class Initialized
INFO - 2020-02-12 17:44:20 --> Output Class Initialized
INFO - 2020-02-12 17:44:20 --> Output Class Initialized
INFO - 2020-02-12 17:44:20 --> Model "M_pesan" initialized
INFO - 2020-02-12 17:44:20 --> URI Class Initialized
INFO - 2020-02-12 17:44:20 --> Security Class Initialized
INFO - 2020-02-12 17:44:20 --> Security Class Initialized
INFO - 2020-02-12 17:44:20 --> Output Class Initialized
INFO - 2020-02-12 17:44:20 --> Security Class Initialized
DEBUG - 2020-02-12 17:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 17:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-12 17:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:20 --> Router Class Initialized
INFO - 2020-02-12 17:44:20 --> Security Class Initialized
INFO - 2020-02-12 17:44:20 --> Helper loaded: form_helper
INFO - 2020-02-12 17:44:20 --> Form Validation Class Initialized
INFO - 2020-02-12 17:44:20 --> Input Class Initialized
INFO - 2020-02-12 17:44:20 --> Input Class Initialized
INFO - 2020-02-12 17:44:20 --> Input Class Initialized
INFO - 2020-02-12 17:44:20 --> Output Class Initialized
DEBUG - 2020-02-12 17:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:20 --> Language Class Initialized
INFO - 2020-02-12 17:44:20 --> Language Class Initialized
INFO - 2020-02-12 17:44:20 --> Language Class Initialized
INFO - 2020-02-12 17:44:20 --> Input Class Initialized
INFO - 2020-02-12 17:44:20 --> Security Class Initialized
ERROR - 2020-02-12 17:44:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 17:44:20 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-12 17:44:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-12 17:44:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 17:44:20 --> Language Class Initialized
ERROR - 2020-02-12 17:44:20 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-12 17:44:20 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-12 17:44:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-12 17:44:21 --> Config Class Initialized
INFO - 2020-02-12 17:44:21 --> Config Class Initialized
INFO - 2020-02-12 17:44:21 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:21 --> Input Class Initialized
INFO - 2020-02-12 17:44:21 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 17:44:21 --> Config Class Initialized
INFO - 2020-02-12 17:44:21 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:21 --> Language Class Initialized
INFO - 2020-02-12 17:44:21 --> Final output sent to browser
DEBUG - 2020-02-12 17:44:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 17:44:21 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:21 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:21 --> Utf8 Class Initialized
DEBUG - 2020-02-12 17:44:21 --> Total execution time: 4.9336
ERROR - 2020-02-12 17:44:21 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-12 17:44:21 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:21 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:21 --> URI Class Initialized
INFO - 2020-02-12 17:44:21 --> URI Class Initialized
INFO - 2020-02-12 17:44:21 --> URI Class Initialized
INFO - 2020-02-12 17:44:21 --> Router Class Initialized
INFO - 2020-02-12 17:44:21 --> Router Class Initialized
INFO - 2020-02-12 17:44:21 --> Router Class Initialized
INFO - 2020-02-12 17:44:21 --> Output Class Initialized
INFO - 2020-02-12 17:44:21 --> Output Class Initialized
INFO - 2020-02-12 17:44:22 --> Security Class Initialized
INFO - 2020-02-12 17:44:22 --> Security Class Initialized
INFO - 2020-02-12 17:44:22 --> Output Class Initialized
DEBUG - 2020-02-12 17:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:22 --> Security Class Initialized
DEBUG - 2020-02-12 17:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:22 --> Input Class Initialized
INFO - 2020-02-12 17:44:22 --> Input Class Initialized
DEBUG - 2020-02-12 17:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:22 --> Input Class Initialized
INFO - 2020-02-12 17:44:22 --> Language Class Initialized
INFO - 2020-02-12 17:44:22 --> Language Class Initialized
INFO - 2020-02-12 17:44:22 --> Language Class Initialized
ERROR - 2020-02-12 17:44:22 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-12 17:44:22 --> Loader Class Initialized
ERROR - 2020-02-12 17:44:22 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-12 17:44:22 --> Helper loaded: url_helper
INFO - 2020-02-12 17:44:22 --> Helper loaded: string_helper
INFO - 2020-02-12 17:44:23 --> Config Class Initialized
INFO - 2020-02-12 17:44:23 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:23 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:44:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-12 17:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:44:23 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:44:23 --> Controller Class Initialized
INFO - 2020-02-12 17:44:23 --> URI Class Initialized
INFO - 2020-02-12 17:44:23 --> Model "M_tiket" initialized
INFO - 2020-02-12 17:44:23 --> Router Class Initialized
INFO - 2020-02-12 17:44:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 17:44:23 --> Output Class Initialized
INFO - 2020-02-12 17:44:23 --> Model "M_pesan" initialized
INFO - 2020-02-12 17:44:23 --> Security Class Initialized
DEBUG - 2020-02-12 17:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:24 --> Helper loaded: form_helper
INFO - 2020-02-12 17:44:24 --> Input Class Initialized
INFO - 2020-02-12 17:44:24 --> Form Validation Class Initialized
INFO - 2020-02-12 17:44:24 --> Language Class Initialized
ERROR - 2020-02-12 17:44:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-12 17:44:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-12 17:44:24 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-12 17:44:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-12 17:44:24 --> Config Class Initialized
INFO - 2020-02-12 17:44:24 --> Hooks Class Initialized
INFO - 2020-02-12 17:44:24 --> Final output sent to browser
DEBUG - 2020-02-12 17:44:24 --> Total execution time: 3.7464
DEBUG - 2020-02-12 17:44:24 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:25 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:25 --> URI Class Initialized
INFO - 2020-02-12 17:44:25 --> Router Class Initialized
INFO - 2020-02-12 17:44:25 --> Output Class Initialized
INFO - 2020-02-12 17:44:25 --> Security Class Initialized
DEBUG - 2020-02-12 17:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:25 --> Input Class Initialized
INFO - 2020-02-12 17:44:26 --> Language Class Initialized
ERROR - 2020-02-12 17:44:26 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-12 17:44:26 --> Config Class Initialized
INFO - 2020-02-12 17:44:26 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:44:26 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:26 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:26 --> URI Class Initialized
INFO - 2020-02-12 17:44:27 --> Router Class Initialized
INFO - 2020-02-12 17:44:27 --> Output Class Initialized
INFO - 2020-02-12 17:44:27 --> Security Class Initialized
DEBUG - 2020-02-12 17:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:27 --> Input Class Initialized
INFO - 2020-02-12 17:44:27 --> Language Class Initialized
ERROR - 2020-02-12 17:44:27 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 17:44:28 --> Config Class Initialized
INFO - 2020-02-12 17:44:28 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:44:28 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:28 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:28 --> URI Class Initialized
INFO - 2020-02-12 17:44:28 --> Router Class Initialized
INFO - 2020-02-12 17:44:28 --> Output Class Initialized
INFO - 2020-02-12 17:44:29 --> Security Class Initialized
DEBUG - 2020-02-12 17:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:29 --> Input Class Initialized
INFO - 2020-02-12 17:44:29 --> Language Class Initialized
ERROR - 2020-02-12 17:44:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-12 17:44:29 --> Config Class Initialized
INFO - 2020-02-12 17:44:29 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:44:30 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:30 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:30 --> URI Class Initialized
INFO - 2020-02-12 17:44:30 --> Router Class Initialized
INFO - 2020-02-12 17:44:30 --> Output Class Initialized
INFO - 2020-02-12 17:44:30 --> Security Class Initialized
DEBUG - 2020-02-12 17:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:30 --> Input Class Initialized
INFO - 2020-02-12 17:44:31 --> Language Class Initialized
ERROR - 2020-02-12 17:44:31 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-12 17:44:31 --> Config Class Initialized
INFO - 2020-02-12 17:44:31 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:44:31 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:31 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:31 --> URI Class Initialized
INFO - 2020-02-12 17:44:32 --> Router Class Initialized
INFO - 2020-02-12 17:44:32 --> Output Class Initialized
INFO - 2020-02-12 17:44:32 --> Security Class Initialized
DEBUG - 2020-02-12 17:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:32 --> Input Class Initialized
INFO - 2020-02-12 17:44:32 --> Language Class Initialized
ERROR - 2020-02-12 17:44:32 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-12 17:44:33 --> Config Class Initialized
INFO - 2020-02-12 17:44:33 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:44:33 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:33 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:33 --> URI Class Initialized
INFO - 2020-02-12 17:44:33 --> Router Class Initialized
INFO - 2020-02-12 17:44:33 --> Output Class Initialized
INFO - 2020-02-12 17:44:34 --> Security Class Initialized
DEBUG - 2020-02-12 17:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:34 --> Input Class Initialized
INFO - 2020-02-12 17:44:34 --> Language Class Initialized
ERROR - 2020-02-12 17:44:34 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-12 17:44:34 --> Config Class Initialized
INFO - 2020-02-12 17:44:34 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:44:35 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:44:35 --> Utf8 Class Initialized
INFO - 2020-02-12 17:44:35 --> URI Class Initialized
INFO - 2020-02-12 17:44:35 --> Router Class Initialized
INFO - 2020-02-12 17:44:35 --> Output Class Initialized
INFO - 2020-02-12 17:44:35 --> Security Class Initialized
DEBUG - 2020-02-12 17:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:44:36 --> Input Class Initialized
INFO - 2020-02-12 17:44:36 --> Language Class Initialized
ERROR - 2020-02-12 17:44:36 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-12 17:45:00 --> Config Class Initialized
INFO - 2020-02-12 17:45:00 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:45:01 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:45:01 --> Utf8 Class Initialized
INFO - 2020-02-12 17:45:01 --> URI Class Initialized
INFO - 2020-02-12 17:45:01 --> Router Class Initialized
INFO - 2020-02-12 17:45:01 --> Output Class Initialized
INFO - 2020-02-12 17:45:01 --> Security Class Initialized
DEBUG - 2020-02-12 17:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:45:01 --> Input Class Initialized
INFO - 2020-02-12 17:45:02 --> Language Class Initialized
INFO - 2020-02-12 17:45:02 --> Loader Class Initialized
INFO - 2020-02-12 17:45:02 --> Helper loaded: url_helper
INFO - 2020-02-12 17:45:02 --> Helper loaded: string_helper
INFO - 2020-02-12 17:45:02 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:45:03 --> Controller Class Initialized
INFO - 2020-02-12 17:45:03 --> Model "M_tiket" initialized
INFO - 2020-02-12 17:45:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 17:45:03 --> Model "M_pesan" initialized
INFO - 2020-02-12 17:45:03 --> Helper loaded: form_helper
INFO - 2020-02-12 17:45:04 --> Form Validation Class Initialized
INFO - 2020-02-12 17:45:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 17:45:04 --> Final output sent to browser
DEBUG - 2020-02-12 17:45:04 --> Total execution time: 3.7976
INFO - 2020-02-12 17:45:13 --> Config Class Initialized
INFO - 2020-02-12 17:45:13 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:45:14 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:45:14 --> Utf8 Class Initialized
INFO - 2020-02-12 17:45:14 --> URI Class Initialized
INFO - 2020-02-12 17:45:14 --> Router Class Initialized
INFO - 2020-02-12 17:45:14 --> Output Class Initialized
INFO - 2020-02-12 17:45:14 --> Security Class Initialized
DEBUG - 2020-02-12 17:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:45:15 --> Input Class Initialized
INFO - 2020-02-12 17:45:15 --> Language Class Initialized
INFO - 2020-02-12 17:45:15 --> Loader Class Initialized
INFO - 2020-02-12 17:45:15 --> Helper loaded: url_helper
INFO - 2020-02-12 17:45:15 --> Helper loaded: string_helper
INFO - 2020-02-12 17:45:15 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:45:16 --> Controller Class Initialized
INFO - 2020-02-12 17:45:16 --> Model "M_tiket" initialized
INFO - 2020-02-12 17:45:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 17:45:16 --> Model "M_pesan" initialized
INFO - 2020-02-12 17:45:16 --> Helper loaded: form_helper
INFO - 2020-02-12 17:45:16 --> Form Validation Class Initialized
INFO - 2020-02-12 17:45:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 17:45:17 --> Final output sent to browser
DEBUG - 2020-02-12 17:45:17 --> Total execution time: 3.4803
INFO - 2020-02-12 17:45:21 --> Config Class Initialized
INFO - 2020-02-12 17:45:22 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:45:22 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:45:22 --> Utf8 Class Initialized
INFO - 2020-02-12 17:45:22 --> URI Class Initialized
INFO - 2020-02-12 17:45:22 --> Router Class Initialized
INFO - 2020-02-12 17:45:22 --> Output Class Initialized
INFO - 2020-02-12 17:45:22 --> Security Class Initialized
DEBUG - 2020-02-12 17:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:45:23 --> Input Class Initialized
INFO - 2020-02-12 17:45:23 --> Language Class Initialized
INFO - 2020-02-12 17:45:23 --> Loader Class Initialized
INFO - 2020-02-12 17:45:23 --> Helper loaded: url_helper
INFO - 2020-02-12 17:45:23 --> Helper loaded: string_helper
INFO - 2020-02-12 17:45:24 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:45:24 --> Controller Class Initialized
INFO - 2020-02-12 17:45:24 --> Model "M_tiket" initialized
INFO - 2020-02-12 17:45:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 17:45:25 --> Model "M_pesan" initialized
INFO - 2020-02-12 17:45:25 --> Helper loaded: form_helper
INFO - 2020-02-12 17:45:25 --> Form Validation Class Initialized
INFO - 2020-02-12 17:45:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 17:45:26 --> Final output sent to browser
DEBUG - 2020-02-12 17:45:26 --> Total execution time: 4.1998
INFO - 2020-02-12 17:45:31 --> Config Class Initialized
INFO - 2020-02-12 17:45:31 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:45:31 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:45:31 --> Utf8 Class Initialized
INFO - 2020-02-12 17:45:32 --> URI Class Initialized
INFO - 2020-02-12 17:45:32 --> Router Class Initialized
INFO - 2020-02-12 17:45:32 --> Output Class Initialized
INFO - 2020-02-12 17:45:32 --> Security Class Initialized
DEBUG - 2020-02-12 17:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:45:32 --> Input Class Initialized
INFO - 2020-02-12 17:45:32 --> Language Class Initialized
INFO - 2020-02-12 17:45:32 --> Loader Class Initialized
INFO - 2020-02-12 17:45:33 --> Helper loaded: url_helper
INFO - 2020-02-12 17:45:33 --> Helper loaded: string_helper
INFO - 2020-02-12 17:45:33 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:45:33 --> Controller Class Initialized
INFO - 2020-02-12 17:45:33 --> Model "M_tiket" initialized
INFO - 2020-02-12 17:45:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 17:45:34 --> Model "M_pesan" initialized
INFO - 2020-02-12 17:45:34 --> Helper loaded: form_helper
INFO - 2020-02-12 17:45:34 --> Form Validation Class Initialized
INFO - 2020-02-12 17:45:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 17:45:34 --> Final output sent to browser
DEBUG - 2020-02-12 17:45:34 --> Total execution time: 3.3823
INFO - 2020-02-12 17:45:39 --> Config Class Initialized
INFO - 2020-02-12 17:45:39 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:45:39 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:45:39 --> Utf8 Class Initialized
INFO - 2020-02-12 17:45:39 --> URI Class Initialized
INFO - 2020-02-12 17:45:40 --> Router Class Initialized
INFO - 2020-02-12 17:45:40 --> Output Class Initialized
INFO - 2020-02-12 17:45:40 --> Security Class Initialized
DEBUG - 2020-02-12 17:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:45:40 --> Input Class Initialized
INFO - 2020-02-12 17:45:40 --> Language Class Initialized
INFO - 2020-02-12 17:45:40 --> Loader Class Initialized
INFO - 2020-02-12 17:45:41 --> Helper loaded: url_helper
INFO - 2020-02-12 17:45:41 --> Helper loaded: string_helper
INFO - 2020-02-12 17:45:41 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:45:41 --> Controller Class Initialized
INFO - 2020-02-12 17:45:41 --> Model "M_tiket" initialized
INFO - 2020-02-12 17:45:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 17:45:42 --> Model "M_pesan" initialized
INFO - 2020-02-12 17:45:42 --> Helper loaded: form_helper
INFO - 2020-02-12 17:45:42 --> Form Validation Class Initialized
INFO - 2020-02-12 17:45:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-12 17:45:42 --> Final output sent to browser
DEBUG - 2020-02-12 17:45:42 --> Total execution time: 3.2820
INFO - 2020-02-12 17:59:34 --> Config Class Initialized
INFO - 2020-02-12 17:59:34 --> Hooks Class Initialized
DEBUG - 2020-02-12 17:59:35 --> UTF-8 Support Enabled
INFO - 2020-02-12 17:59:35 --> Utf8 Class Initialized
INFO - 2020-02-12 17:59:35 --> URI Class Initialized
INFO - 2020-02-12 17:59:35 --> Router Class Initialized
INFO - 2020-02-12 17:59:35 --> Output Class Initialized
INFO - 2020-02-12 17:59:35 --> Security Class Initialized
DEBUG - 2020-02-12 17:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 17:59:36 --> Input Class Initialized
INFO - 2020-02-12 17:59:36 --> Language Class Initialized
INFO - 2020-02-12 17:59:36 --> Loader Class Initialized
INFO - 2020-02-12 17:59:36 --> Helper loaded: url_helper
INFO - 2020-02-12 17:59:36 --> Helper loaded: string_helper
INFO - 2020-02-12 17:59:37 --> Database Driver Class Initialized
DEBUG - 2020-02-12 17:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 17:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 17:59:37 --> Controller Class Initialized
INFO - 2020-02-12 17:59:37 --> Model "M_tiket" initialized
INFO - 2020-02-12 17:59:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-12 17:59:38 --> Model "M_pesan" initialized
INFO - 2020-02-12 17:59:38 --> Helper loaded: form_helper
INFO - 2020-02-12 17:59:38 --> Form Validation Class Initialized
INFO - 2020-02-12 17:59:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/form_bukti.php
INFO - 2020-02-12 17:59:39 --> Final output sent to browser
DEBUG - 2020-02-12 17:59:39 --> Total execution time: 4.3214
