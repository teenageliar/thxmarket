<div class="localP5">
            <div class="col-lg-7 col-md-12 col-sm-12" style="padding-top:20px;" >
                    <div class="col-lg-12 col-md-12 col-sm-12" >
                        <img src="<?php echo base_url()?>asset/image/kontent/pos1.png"  class="img img-responsive">
                    </div> 
                </div>
                  <div class="col-lg-5 col-md-12 col-sm-12"  style="margin-bottom: 10px; margin-top:30px;" >
                <div id="myCarousel" class="carousel slide" data-ride="carousel" >
                  <!-- Indicators -->
                  <ol class="carousel-indicators">
                    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                    <li data-target="#myCarousel" data-slide-to="2"></li>
                    <li data-target="#myCarousel" data-slide-to="3"></li>
                    <li data-target="#myCarousel" data-slide-to="4"></li>
                    <li data-target="#myCarousel" data-slide-to="5"></li>
                    <li data-target="#myCarousel" data-slide-to="6"></li>
                    <li data-target="#myCarousel" data-slide-to="7"></li>
                    <li data-target="#myCarousel" data-slide-to="8"></li>
                  </ol>

                  <!-- Wrapper for slides -->
                  <div class="carousel-inner">
                    <div class="item active">
                      <img src="<?php echo base_url()?>asset/image/kontent/gallery/c68413f0-fa58-4ad4-a72e-e3881b3306d1.jpg"  alt="Volume 1">
                    </div>
                    <div class="item">
                      <img src="<?php echo base_url()?>asset/image/kontent/gallery/e9893055-13d4-4459-8a41-062b1cd0d173.jpg"alt="Nostress">
                    </div>

                    <div class="item">
                      <img src="<?php echo base_url()?>asset/image/kontent/gallery/18546c75-8467-4211-8676-6cc1ad8915bf.jpg"  alt="Jason Ranti">
                    </div>
                    <div class="item">
                      <img src="<?php echo base_url()?>asset/image/kontent/gallery/68f35642-bb8c-493b-afbb-71744f0dd4cb.jpg"  alt="Figura renata">
                    </div>
                     <div class="item">
                      <img src="<?php echo base_url()?>asset/image/kontent/gallery/3c9207cf-e157-4bfc-8dca-b45886c0150a.jpg"  alt="Iksan skuter">
                    </div>
                     <div class="item">
                      <img src="<?php echo base_url()?>asset/image/kontent/gallery/0efb2f0e-bfb9-4846-bf5d-1a929d474ef3.jpg"  alt="Iksan skuter feat Jason Ranti">
                    </div>
                    
                    <div class="item">
                      <img src="<?php echo base_url()?>asset/image/kontent/gallery/2f32a196-230a-4183-9095-df54d0c3a1fc.jpg"  alt="Fourtwenty">
                    </div>
                    <div class="item">
                      <img src="<?php echo base_url()?>asset/image/kontent/gallery/50726d11-6e2d-4e51-a515-fa1284e1c79e.jpg"  alt="Amigdala">
                    </div>
                    <div class="item">
                      <img src="<?php echo base_url()?>asset/image/kontent/gallery/a6e9c4cc-0b64-4a4f-b1da-5a25576eb318.jpg"  alt="Volume 1">
                    </div>
                  </div>

                  <!-- Left and right controls -->
                  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="right carousel-control" href="#myCarousel" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                    <span class="sr-only">Next</span>
                  </a>

                </div>

            </div>  
                
            </div>
   