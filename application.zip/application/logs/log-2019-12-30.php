<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-30 05:36:07 --> Config Class Initialized
INFO - 2019-12-30 05:36:07 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:36:07 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:36:07 --> Utf8 Class Initialized
INFO - 2019-12-30 05:36:07 --> URI Class Initialized
DEBUG - 2019-12-30 05:36:07 --> No URI present. Default controller set.
INFO - 2019-12-30 05:36:07 --> Router Class Initialized
INFO - 2019-12-30 05:36:07 --> Output Class Initialized
INFO - 2019-12-30 05:36:07 --> Security Class Initialized
DEBUG - 2019-12-30 05:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:36:08 --> Input Class Initialized
INFO - 2019-12-30 05:36:08 --> Language Class Initialized
INFO - 2019-12-30 05:36:08 --> Loader Class Initialized
INFO - 2019-12-30 05:36:08 --> Helper loaded: url_helper
INFO - 2019-12-30 05:36:08 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:36:08 --> Controller Class Initialized
INFO - 2019-12-30 05:36:08 --> Model "M_login" initialized
INFO - 2019-12-30 05:36:08 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2019-12-30 05:36:08 --> Final output sent to browser
DEBUG - 2019-12-30 05:36:08 --> Total execution time: 0.3356
INFO - 2019-12-30 05:36:12 --> Config Class Initialized
INFO - 2019-12-30 05:36:12 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:36:12 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:36:12 --> Utf8 Class Initialized
INFO - 2019-12-30 05:36:12 --> URI Class Initialized
INFO - 2019-12-30 05:36:12 --> Router Class Initialized
INFO - 2019-12-30 05:36:12 --> Output Class Initialized
INFO - 2019-12-30 05:36:12 --> Security Class Initialized
DEBUG - 2019-12-30 05:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:36:12 --> Input Class Initialized
INFO - 2019-12-30 05:36:12 --> Language Class Initialized
INFO - 2019-12-30 05:36:12 --> Loader Class Initialized
INFO - 2019-12-30 05:36:12 --> Helper loaded: url_helper
INFO - 2019-12-30 05:36:12 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:36:12 --> Controller Class Initialized
INFO - 2019-12-30 05:36:12 --> Model "M_login" initialized
INFO - 2019-12-30 05:36:12 --> Config Class Initialized
INFO - 2019-12-30 05:36:12 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:36:12 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:36:12 --> Utf8 Class Initialized
INFO - 2019-12-30 05:36:12 --> URI Class Initialized
INFO - 2019-12-30 05:36:12 --> Router Class Initialized
INFO - 2019-12-30 05:36:12 --> Output Class Initialized
INFO - 2019-12-30 05:36:12 --> Security Class Initialized
DEBUG - 2019-12-30 05:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:36:13 --> Input Class Initialized
INFO - 2019-12-30 05:36:13 --> Language Class Initialized
INFO - 2019-12-30 05:36:13 --> Loader Class Initialized
INFO - 2019-12-30 05:36:13 --> Helper loaded: url_helper
INFO - 2019-12-30 05:36:13 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:36:13 --> Controller Class Initialized
INFO - 2019-12-30 05:36:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:36:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-30 05:36:13 --> Final output sent to browser
DEBUG - 2019-12-30 05:36:13 --> Total execution time: 0.2905
INFO - 2019-12-30 05:36:13 --> Config Class Initialized
INFO - 2019-12-30 05:36:13 --> Config Class Initialized
INFO - 2019-12-30 05:36:13 --> Hooks Class Initialized
INFO - 2019-12-30 05:36:13 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:36:13 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:36:13 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:36:13 --> Utf8 Class Initialized
INFO - 2019-12-30 05:36:13 --> Utf8 Class Initialized
INFO - 2019-12-30 05:36:13 --> URI Class Initialized
INFO - 2019-12-30 05:36:13 --> URI Class Initialized
INFO - 2019-12-30 05:36:13 --> Router Class Initialized
INFO - 2019-12-30 05:36:13 --> Router Class Initialized
INFO - 2019-12-30 05:36:13 --> Output Class Initialized
INFO - 2019-12-30 05:36:13 --> Output Class Initialized
INFO - 2019-12-30 05:36:13 --> Security Class Initialized
INFO - 2019-12-30 05:36:13 --> Security Class Initialized
DEBUG - 2019-12-30 05:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:36:13 --> Input Class Initialized
INFO - 2019-12-30 05:36:13 --> Input Class Initialized
INFO - 2019-12-30 05:36:13 --> Language Class Initialized
INFO - 2019-12-30 05:36:13 --> Language Class Initialized
ERROR - 2019-12-30 05:36:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-30 05:36:13 --> 404 Page Not Found: Assets/js
INFO - 2019-12-30 05:36:13 --> Config Class Initialized
INFO - 2019-12-30 05:36:13 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:36:13 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:36:13 --> Utf8 Class Initialized
INFO - 2019-12-30 05:36:13 --> URI Class Initialized
INFO - 2019-12-30 05:36:13 --> Router Class Initialized
INFO - 2019-12-30 05:36:13 --> Output Class Initialized
INFO - 2019-12-30 05:36:13 --> Security Class Initialized
DEBUG - 2019-12-30 05:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:36:13 --> Input Class Initialized
INFO - 2019-12-30 05:36:13 --> Language Class Initialized
ERROR - 2019-12-30 05:36:13 --> 404 Page Not Found: Assets/js
INFO - 2019-12-30 05:36:17 --> Config Class Initialized
INFO - 2019-12-30 05:36:17 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:36:17 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:36:17 --> Utf8 Class Initialized
INFO - 2019-12-30 05:36:17 --> URI Class Initialized
INFO - 2019-12-30 05:36:17 --> Router Class Initialized
INFO - 2019-12-30 05:36:17 --> Output Class Initialized
INFO - 2019-12-30 05:36:17 --> Security Class Initialized
DEBUG - 2019-12-30 05:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:36:17 --> Input Class Initialized
INFO - 2019-12-30 05:36:17 --> Language Class Initialized
INFO - 2019-12-30 05:36:17 --> Loader Class Initialized
INFO - 2019-12-30 05:36:17 --> Helper loaded: url_helper
INFO - 2019-12-30 05:36:17 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:36:17 --> Controller Class Initialized
INFO - 2019-12-30 05:36:17 --> Model "M_login" initialized
INFO - 2019-12-30 05:36:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 05:36:17 --> Pagination Class Initialized
INFO - 2019-12-30 05:36:17 --> Model "M_pesan" initialized
INFO - 2019-12-30 05:36:17 --> Helper loaded: form_helper
INFO - 2019-12-30 05:36:17 --> Form Validation Class Initialized
INFO - 2019-12-30 05:36:17 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:36:17 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-30 05:36:17 --> Final output sent to browser
DEBUG - 2019-12-30 05:36:17 --> Total execution time: 0.3617
INFO - 2019-12-30 05:36:17 --> Config Class Initialized
INFO - 2019-12-30 05:36:17 --> Config Class Initialized
INFO - 2019-12-30 05:36:17 --> Hooks Class Initialized
INFO - 2019-12-30 05:36:17 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:36:17 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:36:17 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:36:17 --> Utf8 Class Initialized
INFO - 2019-12-30 05:36:17 --> Utf8 Class Initialized
INFO - 2019-12-30 05:36:17 --> URI Class Initialized
INFO - 2019-12-30 05:36:17 --> URI Class Initialized
INFO - 2019-12-30 05:36:18 --> Router Class Initialized
INFO - 2019-12-30 05:36:18 --> Router Class Initialized
INFO - 2019-12-30 05:36:18 --> Output Class Initialized
INFO - 2019-12-30 05:36:18 --> Security Class Initialized
INFO - 2019-12-30 05:36:18 --> Output Class Initialized
DEBUG - 2019-12-30 05:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:36:18 --> Security Class Initialized
INFO - 2019-12-30 05:36:18 --> Input Class Initialized
DEBUG - 2019-12-30 05:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:36:18 --> Input Class Initialized
INFO - 2019-12-30 05:36:18 --> Language Class Initialized
INFO - 2019-12-30 05:36:18 --> Language Class Initialized
ERROR - 2019-12-30 05:36:18 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 05:36:18 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:38:48 --> Config Class Initialized
INFO - 2019-12-30 05:38:48 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:38:48 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:38:48 --> Utf8 Class Initialized
INFO - 2019-12-30 05:38:48 --> URI Class Initialized
INFO - 2019-12-30 05:38:48 --> Router Class Initialized
INFO - 2019-12-30 05:38:48 --> Output Class Initialized
INFO - 2019-12-30 05:38:48 --> Security Class Initialized
DEBUG - 2019-12-30 05:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:38:48 --> Input Class Initialized
INFO - 2019-12-30 05:38:48 --> Language Class Initialized
INFO - 2019-12-30 05:38:48 --> Loader Class Initialized
INFO - 2019-12-30 05:38:48 --> Helper loaded: url_helper
INFO - 2019-12-30 05:38:48 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:38:48 --> Controller Class Initialized
INFO - 2019-12-30 05:38:48 --> Model "M_login" initialized
INFO - 2019-12-30 05:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 05:38:48 --> Pagination Class Initialized
INFO - 2019-12-30 05:38:48 --> Model "M_pesan" initialized
INFO - 2019-12-30 05:38:48 --> Helper loaded: form_helper
INFO - 2019-12-30 05:38:48 --> Form Validation Class Initialized
INFO - 2019-12-30 05:38:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:38:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-30 05:38:48 --> Final output sent to browser
DEBUG - 2019-12-30 05:38:48 --> Total execution time: 0.6625
INFO - 2019-12-30 05:38:48 --> Config Class Initialized
INFO - 2019-12-30 05:38:48 --> Config Class Initialized
INFO - 2019-12-30 05:38:49 --> Hooks Class Initialized
INFO - 2019-12-30 05:38:49 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:38:49 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:38:49 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:38:49 --> Utf8 Class Initialized
INFO - 2019-12-30 05:38:49 --> Utf8 Class Initialized
INFO - 2019-12-30 05:38:49 --> URI Class Initialized
INFO - 2019-12-30 05:38:49 --> URI Class Initialized
INFO - 2019-12-30 05:38:49 --> Router Class Initialized
INFO - 2019-12-30 05:38:49 --> Router Class Initialized
INFO - 2019-12-30 05:38:49 --> Output Class Initialized
INFO - 2019-12-30 05:38:49 --> Output Class Initialized
INFO - 2019-12-30 05:38:49 --> Security Class Initialized
INFO - 2019-12-30 05:38:49 --> Security Class Initialized
DEBUG - 2019-12-30 05:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:38:49 --> Input Class Initialized
INFO - 2019-12-30 05:38:49 --> Input Class Initialized
INFO - 2019-12-30 05:38:49 --> Language Class Initialized
INFO - 2019-12-30 05:38:49 --> Language Class Initialized
ERROR - 2019-12-30 05:38:49 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 05:38:49 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:38:49 --> Config Class Initialized
INFO - 2019-12-30 05:38:49 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:38:49 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:38:49 --> Utf8 Class Initialized
INFO - 2019-12-30 05:38:49 --> URI Class Initialized
INFO - 2019-12-30 05:38:49 --> Router Class Initialized
INFO - 2019-12-30 05:38:49 --> Output Class Initialized
INFO - 2019-12-30 05:38:49 --> Security Class Initialized
DEBUG - 2019-12-30 05:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:38:49 --> Input Class Initialized
INFO - 2019-12-30 05:38:49 --> Language Class Initialized
ERROR - 2019-12-30 05:38:49 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:38:54 --> Config Class Initialized
INFO - 2019-12-30 05:38:54 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:38:54 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:38:54 --> Utf8 Class Initialized
INFO - 2019-12-30 05:38:54 --> URI Class Initialized
INFO - 2019-12-30 05:38:54 --> Router Class Initialized
INFO - 2019-12-30 05:38:54 --> Output Class Initialized
INFO - 2019-12-30 05:38:54 --> Security Class Initialized
DEBUG - 2019-12-30 05:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:38:54 --> Input Class Initialized
INFO - 2019-12-30 05:38:54 --> Language Class Initialized
INFO - 2019-12-30 05:38:54 --> Loader Class Initialized
INFO - 2019-12-30 05:38:54 --> Helper loaded: url_helper
INFO - 2019-12-30 05:38:54 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:38:54 --> Controller Class Initialized
INFO - 2019-12-30 05:38:54 --> Model "M_login" initialized
INFO - 2019-12-30 05:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 05:38:55 --> Pagination Class Initialized
INFO - 2019-12-30 05:38:55 --> Model "M_pesan" initialized
INFO - 2019-12-30 05:38:55 --> Helper loaded: form_helper
INFO - 2019-12-30 05:38:55 --> Form Validation Class Initialized
INFO - 2019-12-30 05:38:55 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:38:55 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-30 05:38:55 --> Final output sent to browser
DEBUG - 2019-12-30 05:38:55 --> Total execution time: 0.5831
INFO - 2019-12-30 05:38:55 --> Config Class Initialized
INFO - 2019-12-30 05:38:55 --> Config Class Initialized
INFO - 2019-12-30 05:38:55 --> Hooks Class Initialized
INFO - 2019-12-30 05:38:55 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:38:55 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:38:55 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:38:55 --> Utf8 Class Initialized
INFO - 2019-12-30 05:38:55 --> Utf8 Class Initialized
INFO - 2019-12-30 05:38:55 --> URI Class Initialized
INFO - 2019-12-30 05:38:55 --> URI Class Initialized
INFO - 2019-12-30 05:38:55 --> Router Class Initialized
INFO - 2019-12-30 05:38:55 --> Router Class Initialized
INFO - 2019-12-30 05:38:55 --> Output Class Initialized
INFO - 2019-12-30 05:38:55 --> Output Class Initialized
INFO - 2019-12-30 05:38:55 --> Security Class Initialized
INFO - 2019-12-30 05:38:55 --> Security Class Initialized
DEBUG - 2019-12-30 05:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:38:55 --> Input Class Initialized
INFO - 2019-12-30 05:38:55 --> Input Class Initialized
INFO - 2019-12-30 05:38:55 --> Language Class Initialized
INFO - 2019-12-30 05:38:55 --> Language Class Initialized
ERROR - 2019-12-30 05:38:55 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 05:38:55 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:38:55 --> Config Class Initialized
INFO - 2019-12-30 05:38:55 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:38:55 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:38:55 --> Utf8 Class Initialized
INFO - 2019-12-30 05:38:55 --> URI Class Initialized
INFO - 2019-12-30 05:38:55 --> Router Class Initialized
INFO - 2019-12-30 05:38:55 --> Output Class Initialized
INFO - 2019-12-30 05:38:55 --> Security Class Initialized
DEBUG - 2019-12-30 05:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:38:55 --> Input Class Initialized
INFO - 2019-12-30 05:38:55 --> Language Class Initialized
ERROR - 2019-12-30 05:38:55 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:48:28 --> Config Class Initialized
INFO - 2019-12-30 05:48:28 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:48:28 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:48:28 --> Utf8 Class Initialized
INFO - 2019-12-30 05:48:28 --> URI Class Initialized
INFO - 2019-12-30 05:48:29 --> Router Class Initialized
INFO - 2019-12-30 05:48:29 --> Output Class Initialized
INFO - 2019-12-30 05:48:29 --> Security Class Initialized
DEBUG - 2019-12-30 05:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:48:29 --> Input Class Initialized
INFO - 2019-12-30 05:48:29 --> Language Class Initialized
INFO - 2019-12-30 05:48:29 --> Loader Class Initialized
INFO - 2019-12-30 05:48:29 --> Helper loaded: url_helper
INFO - 2019-12-30 05:48:29 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:48:29 --> Controller Class Initialized
INFO - 2019-12-30 05:48:29 --> Model "M_login" initialized
INFO - 2019-12-30 05:48:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 05:48:29 --> Pagination Class Initialized
INFO - 2019-12-30 05:48:29 --> Model "M_pesan" initialized
INFO - 2019-12-30 05:48:29 --> Helper loaded: form_helper
INFO - 2019-12-30 05:48:29 --> Form Validation Class Initialized
INFO - 2019-12-30 05:48:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:48:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-30 05:48:30 --> Final output sent to browser
DEBUG - 2019-12-30 05:48:30 --> Total execution time: 1.4185
INFO - 2019-12-30 05:48:30 --> Config Class Initialized
INFO - 2019-12-30 05:48:30 --> Config Class Initialized
INFO - 2019-12-30 05:48:30 --> Hooks Class Initialized
INFO - 2019-12-30 05:48:30 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:48:30 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:48:30 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:48:30 --> Utf8 Class Initialized
INFO - 2019-12-30 05:48:30 --> Utf8 Class Initialized
INFO - 2019-12-30 05:48:30 --> URI Class Initialized
INFO - 2019-12-30 05:48:30 --> URI Class Initialized
INFO - 2019-12-30 05:48:30 --> Router Class Initialized
INFO - 2019-12-30 05:48:30 --> Router Class Initialized
INFO - 2019-12-30 05:48:30 --> Output Class Initialized
INFO - 2019-12-30 05:48:30 --> Output Class Initialized
INFO - 2019-12-30 05:48:30 --> Security Class Initialized
INFO - 2019-12-30 05:48:30 --> Security Class Initialized
DEBUG - 2019-12-30 05:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:48:30 --> Input Class Initialized
INFO - 2019-12-30 05:48:30 --> Input Class Initialized
INFO - 2019-12-30 05:48:30 --> Language Class Initialized
INFO - 2019-12-30 05:48:30 --> Language Class Initialized
ERROR - 2019-12-30 05:48:30 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 05:48:30 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:48:32 --> Config Class Initialized
INFO - 2019-12-30 05:48:32 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:48:32 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:48:32 --> Utf8 Class Initialized
INFO - 2019-12-30 05:48:32 --> URI Class Initialized
INFO - 2019-12-30 05:48:32 --> Router Class Initialized
INFO - 2019-12-30 05:48:32 --> Output Class Initialized
INFO - 2019-12-30 05:48:32 --> Security Class Initialized
DEBUG - 2019-12-30 05:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:48:32 --> Input Class Initialized
INFO - 2019-12-30 05:48:32 --> Language Class Initialized
ERROR - 2019-12-30 05:48:32 --> 404 Page Not Found: Pemesanan/cari_pemesanan
INFO - 2019-12-30 05:49:19 --> Config Class Initialized
INFO - 2019-12-30 05:49:19 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:19 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:19 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:19 --> URI Class Initialized
INFO - 2019-12-30 05:49:19 --> Router Class Initialized
INFO - 2019-12-30 05:49:19 --> Output Class Initialized
INFO - 2019-12-30 05:49:19 --> Security Class Initialized
DEBUG - 2019-12-30 05:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:19 --> Input Class Initialized
INFO - 2019-12-30 05:49:19 --> Language Class Initialized
ERROR - 2019-12-30 05:49:19 --> 404 Page Not Found: Pemesanan/cari_pemesanan
INFO - 2019-12-30 05:49:23 --> Config Class Initialized
INFO - 2019-12-30 05:49:23 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:23 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:23 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:23 --> URI Class Initialized
INFO - 2019-12-30 05:49:23 --> Router Class Initialized
INFO - 2019-12-30 05:49:23 --> Output Class Initialized
INFO - 2019-12-30 05:49:23 --> Security Class Initialized
DEBUG - 2019-12-30 05:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:23 --> Input Class Initialized
INFO - 2019-12-30 05:49:23 --> Language Class Initialized
INFO - 2019-12-30 05:49:23 --> Loader Class Initialized
INFO - 2019-12-30 05:49:23 --> Helper loaded: url_helper
INFO - 2019-12-30 05:49:23 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:49:23 --> Controller Class Initialized
INFO - 2019-12-30 05:49:23 --> Model "M_login" initialized
INFO - 2019-12-30 05:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 05:49:23 --> Pagination Class Initialized
INFO - 2019-12-30 05:49:23 --> Model "M_pesan" initialized
INFO - 2019-12-30 05:49:23 --> Helper loaded: form_helper
INFO - 2019-12-30 05:49:23 --> Form Validation Class Initialized
INFO - 2019-12-30 05:49:23 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:49:23 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-30 05:49:23 --> Final output sent to browser
DEBUG - 2019-12-30 05:49:23 --> Total execution time: 0.4645
INFO - 2019-12-30 05:49:26 --> Config Class Initialized
INFO - 2019-12-30 05:49:26 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:26 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:26 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:26 --> URI Class Initialized
INFO - 2019-12-30 05:49:26 --> Router Class Initialized
INFO - 2019-12-30 05:49:26 --> Output Class Initialized
INFO - 2019-12-30 05:49:26 --> Security Class Initialized
DEBUG - 2019-12-30 05:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:26 --> Input Class Initialized
INFO - 2019-12-30 05:49:26 --> Language Class Initialized
INFO - 2019-12-30 05:49:26 --> Loader Class Initialized
INFO - 2019-12-30 05:49:26 --> Helper loaded: url_helper
INFO - 2019-12-30 05:49:26 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:49:26 --> Controller Class Initialized
INFO - 2019-12-30 05:49:26 --> Model "M_login" initialized
INFO - 2019-12-30 05:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 05:49:26 --> Pagination Class Initialized
INFO - 2019-12-30 05:49:26 --> Model "M_pesan" initialized
INFO - 2019-12-30 05:49:27 --> Helper loaded: form_helper
INFO - 2019-12-30 05:49:27 --> Form Validation Class Initialized
INFO - 2019-12-30 05:49:27 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:49:27 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-30 05:49:27 --> Final output sent to browser
DEBUG - 2019-12-30 05:49:27 --> Total execution time: 0.4830
INFO - 2019-12-30 05:49:27 --> Config Class Initialized
INFO - 2019-12-30 05:49:27 --> Config Class Initialized
INFO - 2019-12-30 05:49:27 --> Hooks Class Initialized
INFO - 2019-12-30 05:49:27 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:27 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:49:27 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:27 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:27 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:27 --> URI Class Initialized
INFO - 2019-12-30 05:49:27 --> URI Class Initialized
INFO - 2019-12-30 05:49:27 --> Router Class Initialized
INFO - 2019-12-30 05:49:27 --> Router Class Initialized
INFO - 2019-12-30 05:49:27 --> Output Class Initialized
INFO - 2019-12-30 05:49:27 --> Output Class Initialized
INFO - 2019-12-30 05:49:27 --> Security Class Initialized
INFO - 2019-12-30 05:49:27 --> Security Class Initialized
DEBUG - 2019-12-30 05:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:27 --> Input Class Initialized
INFO - 2019-12-30 05:49:27 --> Input Class Initialized
INFO - 2019-12-30 05:49:27 --> Language Class Initialized
INFO - 2019-12-30 05:49:27 --> Language Class Initialized
ERROR - 2019-12-30 05:49:27 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 05:49:27 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:49:27 --> Config Class Initialized
INFO - 2019-12-30 05:49:27 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:27 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:27 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:27 --> URI Class Initialized
INFO - 2019-12-30 05:49:27 --> Router Class Initialized
INFO - 2019-12-30 05:49:27 --> Output Class Initialized
INFO - 2019-12-30 05:49:27 --> Security Class Initialized
DEBUG - 2019-12-30 05:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:27 --> Input Class Initialized
INFO - 2019-12-30 05:49:27 --> Language Class Initialized
ERROR - 2019-12-30 05:49:27 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:49:28 --> Config Class Initialized
INFO - 2019-12-30 05:49:28 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:28 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:28 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:29 --> URI Class Initialized
INFO - 2019-12-30 05:49:29 --> Router Class Initialized
INFO - 2019-12-30 05:49:29 --> Output Class Initialized
INFO - 2019-12-30 05:49:29 --> Security Class Initialized
DEBUG - 2019-12-30 05:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:29 --> Input Class Initialized
INFO - 2019-12-30 05:49:29 --> Language Class Initialized
ERROR - 2019-12-30 05:49:29 --> 404 Page Not Found: Admin/pemesanan
INFO - 2019-12-30 05:49:46 --> Config Class Initialized
INFO - 2019-12-30 05:49:46 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:46 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:46 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:46 --> URI Class Initialized
DEBUG - 2019-12-30 05:49:46 --> No URI present. Default controller set.
INFO - 2019-12-30 05:49:46 --> Router Class Initialized
INFO - 2019-12-30 05:49:46 --> Output Class Initialized
INFO - 2019-12-30 05:49:46 --> Security Class Initialized
DEBUG - 2019-12-30 05:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:46 --> Input Class Initialized
INFO - 2019-12-30 05:49:46 --> Language Class Initialized
INFO - 2019-12-30 05:49:47 --> Loader Class Initialized
INFO - 2019-12-30 05:49:47 --> Helper loaded: url_helper
INFO - 2019-12-30 05:49:47 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:49:47 --> Controller Class Initialized
INFO - 2019-12-30 05:49:47 --> Model "M_login" initialized
INFO - 2019-12-30 05:49:47 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2019-12-30 05:49:47 --> Final output sent to browser
DEBUG - 2019-12-30 05:49:47 --> Total execution time: 0.3985
INFO - 2019-12-30 05:49:47 --> Config Class Initialized
INFO - 2019-12-30 05:49:47 --> Hooks Class Initialized
INFO - 2019-12-30 05:49:47 --> Config Class Initialized
INFO - 2019-12-30 05:49:47 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:47 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:47 --> Utf8 Class Initialized
DEBUG - 2019-12-30 05:49:47 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:47 --> Config Class Initialized
INFO - 2019-12-30 05:49:47 --> Config Class Initialized
INFO - 2019-12-30 05:49:47 --> Hooks Class Initialized
INFO - 2019-12-30 05:49:47 --> Hooks Class Initialized
INFO - 2019-12-30 05:49:47 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:47 --> URI Class Initialized
INFO - 2019-12-30 05:49:47 --> URI Class Initialized
DEBUG - 2019-12-30 05:49:47 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:49:47 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:47 --> Router Class Initialized
INFO - 2019-12-30 05:49:47 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:47 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:47 --> Router Class Initialized
INFO - 2019-12-30 05:49:47 --> Output Class Initialized
INFO - 2019-12-30 05:49:47 --> URI Class Initialized
INFO - 2019-12-30 05:49:47 --> URI Class Initialized
INFO - 2019-12-30 05:49:47 --> Security Class Initialized
INFO - 2019-12-30 05:49:47 --> Output Class Initialized
DEBUG - 2019-12-30 05:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:47 --> Router Class Initialized
INFO - 2019-12-30 05:49:47 --> Router Class Initialized
INFO - 2019-12-30 05:49:47 --> Security Class Initialized
INFO - 2019-12-30 05:49:47 --> Input Class Initialized
DEBUG - 2019-12-30 05:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:47 --> Output Class Initialized
INFO - 2019-12-30 05:49:47 --> Output Class Initialized
INFO - 2019-12-30 05:49:47 --> Input Class Initialized
INFO - 2019-12-30 05:49:47 --> Language Class Initialized
INFO - 2019-12-30 05:49:47 --> Security Class Initialized
INFO - 2019-12-30 05:49:47 --> Security Class Initialized
INFO - 2019-12-30 05:49:47 --> Language Class Initialized
DEBUG - 2019-12-30 05:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:49:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-12-30 05:49:47 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-30 05:49:47 --> 404 Page Not Found: Assets/images
INFO - 2019-12-30 05:49:47 --> Input Class Initialized
INFO - 2019-12-30 05:49:47 --> Input Class Initialized
INFO - 2019-12-30 05:49:47 --> Language Class Initialized
INFO - 2019-12-30 05:49:47 --> Language Class Initialized
ERROR - 2019-12-30 05:49:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-30 05:49:47 --> 404 Page Not Found: Assets/js
INFO - 2019-12-30 05:49:47 --> Config Class Initialized
INFO - 2019-12-30 05:49:47 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:47 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:47 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:47 --> URI Class Initialized
INFO - 2019-12-30 05:49:47 --> Router Class Initialized
INFO - 2019-12-30 05:49:47 --> Output Class Initialized
INFO - 2019-12-30 05:49:47 --> Security Class Initialized
DEBUG - 2019-12-30 05:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:47 --> Input Class Initialized
INFO - 2019-12-30 05:49:47 --> Language Class Initialized
ERROR - 2019-12-30 05:49:48 --> 404 Page Not Found: Assets/js
INFO - 2019-12-30 05:49:48 --> Config Class Initialized
INFO - 2019-12-30 05:49:48 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:48 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:48 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:48 --> URI Class Initialized
INFO - 2019-12-30 05:49:48 --> Router Class Initialized
INFO - 2019-12-30 05:49:48 --> Output Class Initialized
INFO - 2019-12-30 05:49:48 --> Security Class Initialized
DEBUG - 2019-12-30 05:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:48 --> Input Class Initialized
INFO - 2019-12-30 05:49:48 --> Language Class Initialized
ERROR - 2019-12-30 05:49:48 --> 404 Page Not Found: Assets/js
INFO - 2019-12-30 05:49:53 --> Config Class Initialized
INFO - 2019-12-30 05:49:53 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:53 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:53 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:53 --> URI Class Initialized
INFO - 2019-12-30 05:49:53 --> Router Class Initialized
INFO - 2019-12-30 05:49:53 --> Output Class Initialized
INFO - 2019-12-30 05:49:53 --> Security Class Initialized
DEBUG - 2019-12-30 05:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:53 --> Input Class Initialized
INFO - 2019-12-30 05:49:53 --> Language Class Initialized
INFO - 2019-12-30 05:49:53 --> Loader Class Initialized
INFO - 2019-12-30 05:49:53 --> Helper loaded: url_helper
INFO - 2019-12-30 05:49:53 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:49:53 --> Controller Class Initialized
INFO - 2019-12-30 05:49:53 --> Model "M_login" initialized
INFO - 2019-12-30 05:49:53 --> Config Class Initialized
INFO - 2019-12-30 05:49:53 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:53 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:53 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:53 --> URI Class Initialized
INFO - 2019-12-30 05:49:53 --> Router Class Initialized
INFO - 2019-12-30 05:49:53 --> Output Class Initialized
INFO - 2019-12-30 05:49:53 --> Security Class Initialized
DEBUG - 2019-12-30 05:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:53 --> Input Class Initialized
INFO - 2019-12-30 05:49:53 --> Language Class Initialized
INFO - 2019-12-30 05:49:53 --> Loader Class Initialized
INFO - 2019-12-30 05:49:53 --> Helper loaded: url_helper
INFO - 2019-12-30 05:49:53 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:49:54 --> Controller Class Initialized
INFO - 2019-12-30 05:49:54 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:49:54 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-30 05:49:54 --> Final output sent to browser
DEBUG - 2019-12-30 05:49:54 --> Total execution time: 0.7395
INFO - 2019-12-30 05:49:54 --> Config Class Initialized
INFO - 2019-12-30 05:49:54 --> Config Class Initialized
INFO - 2019-12-30 05:49:54 --> Hooks Class Initialized
INFO - 2019-12-30 05:49:54 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:54 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:49:54 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:54 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:54 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:54 --> URI Class Initialized
INFO - 2019-12-30 05:49:54 --> URI Class Initialized
INFO - 2019-12-30 05:49:54 --> Router Class Initialized
INFO - 2019-12-30 05:49:54 --> Router Class Initialized
INFO - 2019-12-30 05:49:54 --> Output Class Initialized
INFO - 2019-12-30 05:49:54 --> Output Class Initialized
INFO - 2019-12-30 05:49:54 --> Security Class Initialized
INFO - 2019-12-30 05:49:54 --> Security Class Initialized
DEBUG - 2019-12-30 05:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:54 --> Input Class Initialized
INFO - 2019-12-30 05:49:54 --> Input Class Initialized
INFO - 2019-12-30 05:49:54 --> Language Class Initialized
INFO - 2019-12-30 05:49:54 --> Language Class Initialized
ERROR - 2019-12-30 05:49:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-30 05:49:54 --> 404 Page Not Found: Assets/js
INFO - 2019-12-30 05:49:54 --> Config Class Initialized
INFO - 2019-12-30 05:49:54 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:49:54 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:49:54 --> Utf8 Class Initialized
INFO - 2019-12-30 05:49:54 --> URI Class Initialized
INFO - 2019-12-30 05:49:54 --> Router Class Initialized
INFO - 2019-12-30 05:49:54 --> Output Class Initialized
INFO - 2019-12-30 05:49:54 --> Security Class Initialized
DEBUG - 2019-12-30 05:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:49:54 --> Input Class Initialized
INFO - 2019-12-30 05:49:54 --> Language Class Initialized
ERROR - 2019-12-30 05:49:54 --> 404 Page Not Found: Assets/js
INFO - 2019-12-30 05:50:32 --> Config Class Initialized
INFO - 2019-12-30 05:50:32 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:50:32 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:50:32 --> Utf8 Class Initialized
INFO - 2019-12-30 05:50:32 --> URI Class Initialized
INFO - 2019-12-30 05:50:32 --> Router Class Initialized
INFO - 2019-12-30 05:50:32 --> Output Class Initialized
INFO - 2019-12-30 05:50:32 --> Security Class Initialized
DEBUG - 2019-12-30 05:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:50:32 --> Input Class Initialized
INFO - 2019-12-30 05:50:32 --> Language Class Initialized
ERROR - 2019-12-30 05:50:32 --> 404 Page Not Found: Admin/pemesanan
INFO - 2019-12-30 05:50:48 --> Config Class Initialized
INFO - 2019-12-30 05:50:48 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:50:48 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:50:48 --> Utf8 Class Initialized
INFO - 2019-12-30 05:50:48 --> URI Class Initialized
INFO - 2019-12-30 05:50:48 --> Router Class Initialized
INFO - 2019-12-30 05:50:48 --> Output Class Initialized
INFO - 2019-12-30 05:50:48 --> Security Class Initialized
DEBUG - 2019-12-30 05:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:50:48 --> Input Class Initialized
INFO - 2019-12-30 05:50:48 --> Language Class Initialized
ERROR - 2019-12-30 05:50:48 --> 404 Page Not Found: Cari_pemesanan/index
INFO - 2019-12-30 05:50:55 --> Config Class Initialized
INFO - 2019-12-30 05:50:55 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:50:55 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:50:55 --> Utf8 Class Initialized
INFO - 2019-12-30 05:50:55 --> URI Class Initialized
INFO - 2019-12-30 05:50:55 --> Router Class Initialized
INFO - 2019-12-30 05:50:55 --> Output Class Initialized
INFO - 2019-12-30 05:50:55 --> Security Class Initialized
DEBUG - 2019-12-30 05:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:50:55 --> Input Class Initialized
INFO - 2019-12-30 05:50:55 --> Language Class Initialized
ERROR - 2019-12-30 05:50:55 --> 404 Page Not Found: Admin/cari_pemesanan
INFO - 2019-12-30 05:51:51 --> Config Class Initialized
INFO - 2019-12-30 05:51:51 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:51:51 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:51:51 --> Utf8 Class Initialized
INFO - 2019-12-30 05:51:51 --> URI Class Initialized
INFO - 2019-12-30 05:51:51 --> Router Class Initialized
INFO - 2019-12-30 05:51:51 --> Output Class Initialized
INFO - 2019-12-30 05:51:51 --> Security Class Initialized
DEBUG - 2019-12-30 05:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:51:51 --> Input Class Initialized
INFO - 2019-12-30 05:51:51 --> Language Class Initialized
INFO - 2019-12-30 05:51:51 --> Loader Class Initialized
INFO - 2019-12-30 05:51:51 --> Helper loaded: url_helper
INFO - 2019-12-30 05:51:51 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:51:51 --> Controller Class Initialized
INFO - 2019-12-30 05:51:51 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:51:51 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-30 05:51:51 --> Final output sent to browser
DEBUG - 2019-12-30 05:51:51 --> Total execution time: 0.3757
INFO - 2019-12-30 05:52:02 --> Config Class Initialized
INFO - 2019-12-30 05:52:02 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:52:02 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:52:02 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:02 --> URI Class Initialized
INFO - 2019-12-30 05:52:02 --> Router Class Initialized
INFO - 2019-12-30 05:52:02 --> Output Class Initialized
INFO - 2019-12-30 05:52:02 --> Security Class Initialized
DEBUG - 2019-12-30 05:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:52:02 --> Input Class Initialized
INFO - 2019-12-30 05:52:02 --> Language Class Initialized
INFO - 2019-12-30 05:52:02 --> Loader Class Initialized
INFO - 2019-12-30 05:52:02 --> Helper loaded: url_helper
INFO - 2019-12-30 05:52:02 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:52:02 --> Controller Class Initialized
INFO - 2019-12-30 05:52:02 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:52:03 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-30 05:52:03 --> Final output sent to browser
DEBUG - 2019-12-30 05:52:03 --> Total execution time: 0.3614
INFO - 2019-12-30 05:52:03 --> Config Class Initialized
INFO - 2019-12-30 05:52:03 --> Config Class Initialized
INFO - 2019-12-30 05:52:03 --> Hooks Class Initialized
INFO - 2019-12-30 05:52:03 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:52:03 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:52:03 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:52:03 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:03 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:03 --> URI Class Initialized
INFO - 2019-12-30 05:52:03 --> URI Class Initialized
INFO - 2019-12-30 05:52:03 --> Router Class Initialized
INFO - 2019-12-30 05:52:03 --> Router Class Initialized
INFO - 2019-12-30 05:52:03 --> Output Class Initialized
INFO - 2019-12-30 05:52:03 --> Output Class Initialized
INFO - 2019-12-30 05:52:03 --> Security Class Initialized
INFO - 2019-12-30 05:52:03 --> Security Class Initialized
DEBUG - 2019-12-30 05:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:52:03 --> Input Class Initialized
INFO - 2019-12-30 05:52:03 --> Input Class Initialized
INFO - 2019-12-30 05:52:03 --> Language Class Initialized
INFO - 2019-12-30 05:52:03 --> Language Class Initialized
ERROR - 2019-12-30 05:52:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-30 05:52:03 --> 404 Page Not Found: Assets/js
INFO - 2019-12-30 05:52:03 --> Config Class Initialized
INFO - 2019-12-30 05:52:03 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:52:03 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:52:03 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:03 --> URI Class Initialized
INFO - 2019-12-30 05:52:03 --> Router Class Initialized
INFO - 2019-12-30 05:52:03 --> Output Class Initialized
INFO - 2019-12-30 05:52:03 --> Security Class Initialized
DEBUG - 2019-12-30 05:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:52:03 --> Input Class Initialized
INFO - 2019-12-30 05:52:03 --> Language Class Initialized
ERROR - 2019-12-30 05:52:03 --> 404 Page Not Found: Assets/js
INFO - 2019-12-30 05:52:05 --> Config Class Initialized
INFO - 2019-12-30 05:52:05 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:52:05 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:52:05 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:05 --> URI Class Initialized
INFO - 2019-12-30 05:52:05 --> Router Class Initialized
INFO - 2019-12-30 05:52:05 --> Output Class Initialized
INFO - 2019-12-30 05:52:05 --> Security Class Initialized
DEBUG - 2019-12-30 05:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:52:05 --> Input Class Initialized
INFO - 2019-12-30 05:52:05 --> Language Class Initialized
ERROR - 2019-12-30 05:52:05 --> 404 Page Not Found: Pemesanan/cari_pemesanan
INFO - 2019-12-30 05:52:46 --> Config Class Initialized
INFO - 2019-12-30 05:52:46 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:52:46 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:52:46 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:46 --> URI Class Initialized
INFO - 2019-12-30 05:52:46 --> Router Class Initialized
INFO - 2019-12-30 05:52:46 --> Output Class Initialized
INFO - 2019-12-30 05:52:46 --> Security Class Initialized
DEBUG - 2019-12-30 05:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:52:46 --> Input Class Initialized
INFO - 2019-12-30 05:52:46 --> Language Class Initialized
INFO - 2019-12-30 05:52:46 --> Loader Class Initialized
INFO - 2019-12-30 05:52:46 --> Helper loaded: url_helper
INFO - 2019-12-30 05:52:46 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:52:46 --> Controller Class Initialized
INFO - 2019-12-30 05:52:46 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:52:46 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-30 05:52:46 --> Final output sent to browser
DEBUG - 2019-12-30 05:52:46 --> Total execution time: 0.3842
INFO - 2019-12-30 05:52:48 --> Config Class Initialized
INFO - 2019-12-30 05:52:48 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:52:48 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:52:48 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:48 --> URI Class Initialized
INFO - 2019-12-30 05:52:48 --> Router Class Initialized
INFO - 2019-12-30 05:52:48 --> Output Class Initialized
INFO - 2019-12-30 05:52:48 --> Security Class Initialized
DEBUG - 2019-12-30 05:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:52:48 --> Input Class Initialized
INFO - 2019-12-30 05:52:48 --> Language Class Initialized
INFO - 2019-12-30 05:52:48 --> Loader Class Initialized
INFO - 2019-12-30 05:52:48 --> Helper loaded: url_helper
INFO - 2019-12-30 05:52:48 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:52:48 --> Controller Class Initialized
INFO - 2019-12-30 05:52:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:52:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-30 05:52:48 --> Final output sent to browser
DEBUG - 2019-12-30 05:52:48 --> Total execution time: 0.4211
INFO - 2019-12-30 05:52:49 --> Config Class Initialized
INFO - 2019-12-30 05:52:49 --> Config Class Initialized
INFO - 2019-12-30 05:52:49 --> Hooks Class Initialized
INFO - 2019-12-30 05:52:49 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:52:49 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:52:49 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:52:49 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:49 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:49 --> URI Class Initialized
INFO - 2019-12-30 05:52:49 --> URI Class Initialized
INFO - 2019-12-30 05:52:49 --> Router Class Initialized
INFO - 2019-12-30 05:52:49 --> Router Class Initialized
INFO - 2019-12-30 05:52:49 --> Output Class Initialized
INFO - 2019-12-30 05:52:49 --> Output Class Initialized
INFO - 2019-12-30 05:52:49 --> Security Class Initialized
INFO - 2019-12-30 05:52:49 --> Security Class Initialized
DEBUG - 2019-12-30 05:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:52:49 --> Input Class Initialized
INFO - 2019-12-30 05:52:49 --> Input Class Initialized
INFO - 2019-12-30 05:52:49 --> Language Class Initialized
INFO - 2019-12-30 05:52:49 --> Language Class Initialized
ERROR - 2019-12-30 05:52:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-30 05:52:49 --> 404 Page Not Found: Assets/js
INFO - 2019-12-30 05:52:50 --> Config Class Initialized
INFO - 2019-12-30 05:52:50 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:52:50 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:52:50 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:50 --> URI Class Initialized
INFO - 2019-12-30 05:52:50 --> Router Class Initialized
INFO - 2019-12-30 05:52:50 --> Output Class Initialized
INFO - 2019-12-30 05:52:50 --> Security Class Initialized
DEBUG - 2019-12-30 05:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:52:50 --> Input Class Initialized
INFO - 2019-12-30 05:52:50 --> Language Class Initialized
INFO - 2019-12-30 05:52:50 --> Loader Class Initialized
INFO - 2019-12-30 05:52:50 --> Helper loaded: url_helper
INFO - 2019-12-30 05:52:50 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:52:50 --> Controller Class Initialized
INFO - 2019-12-30 05:52:50 --> Model "M_login" initialized
INFO - 2019-12-30 05:52:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 05:52:50 --> Pagination Class Initialized
INFO - 2019-12-30 05:52:50 --> Model "M_pesan" initialized
INFO - 2019-12-30 05:52:50 --> Helper loaded: form_helper
INFO - 2019-12-30 05:52:50 --> Form Validation Class Initialized
INFO - 2019-12-30 05:52:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:52:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:52:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-30 05:52:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 05:52:50 --> Final output sent to browser
DEBUG - 2019-12-30 05:52:50 --> Total execution time: 0.5318
INFO - 2019-12-30 05:52:50 --> Config Class Initialized
INFO - 2019-12-30 05:52:50 --> Config Class Initialized
INFO - 2019-12-30 05:52:50 --> Hooks Class Initialized
INFO - 2019-12-30 05:52:50 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:52:50 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:52:50 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:52:50 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:50 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:50 --> URI Class Initialized
INFO - 2019-12-30 05:52:50 --> URI Class Initialized
INFO - 2019-12-30 05:52:50 --> Router Class Initialized
INFO - 2019-12-30 05:52:50 --> Router Class Initialized
INFO - 2019-12-30 05:52:50 --> Output Class Initialized
INFO - 2019-12-30 05:52:50 --> Output Class Initialized
INFO - 2019-12-30 05:52:50 --> Security Class Initialized
INFO - 2019-12-30 05:52:50 --> Security Class Initialized
DEBUG - 2019-12-30 05:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:52:50 --> Input Class Initialized
INFO - 2019-12-30 05:52:50 --> Input Class Initialized
INFO - 2019-12-30 05:52:50 --> Language Class Initialized
INFO - 2019-12-30 05:52:50 --> Language Class Initialized
ERROR - 2019-12-30 05:52:50 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 05:52:50 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:52:50 --> Config Class Initialized
INFO - 2019-12-30 05:52:50 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:52:51 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:52:51 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:51 --> URI Class Initialized
INFO - 2019-12-30 05:52:51 --> Router Class Initialized
INFO - 2019-12-30 05:52:51 --> Output Class Initialized
INFO - 2019-12-30 05:52:51 --> Security Class Initialized
DEBUG - 2019-12-30 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:52:51 --> Input Class Initialized
INFO - 2019-12-30 05:52:51 --> Language Class Initialized
ERROR - 2019-12-30 05:52:51 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:52:51 --> Config Class Initialized
INFO - 2019-12-30 05:52:51 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:52:51 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:52:51 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:51 --> URI Class Initialized
INFO - 2019-12-30 05:52:51 --> Router Class Initialized
INFO - 2019-12-30 05:52:51 --> Output Class Initialized
INFO - 2019-12-30 05:52:51 --> Security Class Initialized
DEBUG - 2019-12-30 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:52:51 --> Input Class Initialized
INFO - 2019-12-30 05:52:51 --> Language Class Initialized
ERROR - 2019-12-30 05:52:51 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:52:51 --> Config Class Initialized
INFO - 2019-12-30 05:52:51 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:52:51 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:52:51 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:51 --> URI Class Initialized
INFO - 2019-12-30 05:52:51 --> Router Class Initialized
INFO - 2019-12-30 05:52:51 --> Output Class Initialized
INFO - 2019-12-30 05:52:51 --> Security Class Initialized
DEBUG - 2019-12-30 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:52:51 --> Input Class Initialized
INFO - 2019-12-30 05:52:51 --> Language Class Initialized
ERROR - 2019-12-30 05:52:51 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:52:51 --> Config Class Initialized
INFO - 2019-12-30 05:52:51 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:52:51 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:52:51 --> Utf8 Class Initialized
INFO - 2019-12-30 05:52:52 --> URI Class Initialized
INFO - 2019-12-30 05:52:52 --> Router Class Initialized
INFO - 2019-12-30 05:52:52 --> Output Class Initialized
INFO - 2019-12-30 05:52:52 --> Security Class Initialized
DEBUG - 2019-12-30 05:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:52:52 --> Input Class Initialized
INFO - 2019-12-30 05:52:52 --> Language Class Initialized
ERROR - 2019-12-30 05:52:52 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:53:47 --> Config Class Initialized
INFO - 2019-12-30 05:53:47 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:53:47 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:53:47 --> Utf8 Class Initialized
INFO - 2019-12-30 05:53:47 --> URI Class Initialized
INFO - 2019-12-30 05:53:47 --> Router Class Initialized
INFO - 2019-12-30 05:53:47 --> Output Class Initialized
INFO - 2019-12-30 05:53:47 --> Security Class Initialized
DEBUG - 2019-12-30 05:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:53:47 --> Input Class Initialized
INFO - 2019-12-30 05:53:47 --> Language Class Initialized
INFO - 2019-12-30 05:53:47 --> Loader Class Initialized
INFO - 2019-12-30 05:53:47 --> Helper loaded: url_helper
INFO - 2019-12-30 05:53:47 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:53:47 --> Controller Class Initialized
INFO - 2019-12-30 05:53:47 --> Model "M_login" initialized
INFO - 2019-12-30 05:53:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 05:53:47 --> Pagination Class Initialized
INFO - 2019-12-30 05:53:47 --> Model "M_pesan" initialized
INFO - 2019-12-30 05:53:47 --> Helper loaded: form_helper
INFO - 2019-12-30 05:53:47 --> Form Validation Class Initialized
INFO - 2019-12-30 05:53:47 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:53:47 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-30 05:53:47 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 05:53:47 --> Final output sent to browser
DEBUG - 2019-12-30 05:53:48 --> Total execution time: 0.7427
INFO - 2019-12-30 05:53:48 --> Config Class Initialized
INFO - 2019-12-30 05:53:48 --> Config Class Initialized
INFO - 2019-12-30 05:53:48 --> Hooks Class Initialized
INFO - 2019-12-30 05:53:48 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:53:48 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:53:48 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:53:48 --> Utf8 Class Initialized
INFO - 2019-12-30 05:53:48 --> Utf8 Class Initialized
INFO - 2019-12-30 05:53:48 --> URI Class Initialized
INFO - 2019-12-30 05:53:48 --> URI Class Initialized
INFO - 2019-12-30 05:53:48 --> Router Class Initialized
INFO - 2019-12-30 05:53:48 --> Router Class Initialized
INFO - 2019-12-30 05:53:48 --> Output Class Initialized
INFO - 2019-12-30 05:53:48 --> Output Class Initialized
INFO - 2019-12-30 05:53:48 --> Security Class Initialized
INFO - 2019-12-30 05:53:48 --> Security Class Initialized
DEBUG - 2019-12-30 05:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:53:48 --> Input Class Initialized
INFO - 2019-12-30 05:53:48 --> Input Class Initialized
INFO - 2019-12-30 05:53:48 --> Language Class Initialized
INFO - 2019-12-30 05:53:48 --> Language Class Initialized
ERROR - 2019-12-30 05:53:48 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 05:53:48 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:53:48 --> Config Class Initialized
INFO - 2019-12-30 05:53:48 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:53:48 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:53:48 --> Utf8 Class Initialized
INFO - 2019-12-30 05:53:48 --> URI Class Initialized
INFO - 2019-12-30 05:53:48 --> Router Class Initialized
INFO - 2019-12-30 05:53:48 --> Output Class Initialized
INFO - 2019-12-30 05:53:48 --> Security Class Initialized
DEBUG - 2019-12-30 05:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:53:48 --> Input Class Initialized
INFO - 2019-12-30 05:53:48 --> Language Class Initialized
ERROR - 2019-12-30 05:53:48 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:54:29 --> Config Class Initialized
INFO - 2019-12-30 05:54:29 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:54:29 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:54:29 --> Utf8 Class Initialized
INFO - 2019-12-30 05:54:29 --> URI Class Initialized
INFO - 2019-12-30 05:54:29 --> Router Class Initialized
INFO - 2019-12-30 05:54:29 --> Output Class Initialized
INFO - 2019-12-30 05:54:29 --> Security Class Initialized
DEBUG - 2019-12-30 05:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:54:29 --> Input Class Initialized
INFO - 2019-12-30 05:54:29 --> Language Class Initialized
INFO - 2019-12-30 05:54:29 --> Loader Class Initialized
INFO - 2019-12-30 05:54:29 --> Helper loaded: url_helper
INFO - 2019-12-30 05:54:29 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:54:29 --> Controller Class Initialized
INFO - 2019-12-30 05:54:29 --> Model "M_login" initialized
INFO - 2019-12-30 05:54:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 05:54:29 --> Pagination Class Initialized
INFO - 2019-12-30 05:54:29 --> Model "M_pesan" initialized
INFO - 2019-12-30 05:54:29 --> Helper loaded: form_helper
INFO - 2019-12-30 05:54:29 --> Form Validation Class Initialized
INFO - 2019-12-30 05:54:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:54:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 05:54:29 --> Final output sent to browser
DEBUG - 2019-12-30 05:54:30 --> Total execution time: 0.5721
INFO - 2019-12-30 05:54:30 --> Config Class Initialized
INFO - 2019-12-30 05:54:30 --> Config Class Initialized
INFO - 2019-12-30 05:54:30 --> Hooks Class Initialized
INFO - 2019-12-30 05:54:30 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:54:30 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:54:30 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:54:30 --> Utf8 Class Initialized
INFO - 2019-12-30 05:54:30 --> Utf8 Class Initialized
INFO - 2019-12-30 05:54:30 --> URI Class Initialized
INFO - 2019-12-30 05:54:30 --> URI Class Initialized
INFO - 2019-12-30 05:54:30 --> Router Class Initialized
INFO - 2019-12-30 05:54:30 --> Router Class Initialized
INFO - 2019-12-30 05:54:30 --> Output Class Initialized
INFO - 2019-12-30 05:54:30 --> Output Class Initialized
INFO - 2019-12-30 05:54:30 --> Security Class Initialized
INFO - 2019-12-30 05:54:30 --> Security Class Initialized
DEBUG - 2019-12-30 05:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:54:30 --> Input Class Initialized
INFO - 2019-12-30 05:54:30 --> Input Class Initialized
INFO - 2019-12-30 05:54:30 --> Language Class Initialized
INFO - 2019-12-30 05:54:30 --> Language Class Initialized
ERROR - 2019-12-30 05:54:30 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 05:54:30 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:57:54 --> Config Class Initialized
INFO - 2019-12-30 05:57:54 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:57:54 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:57:54 --> Utf8 Class Initialized
INFO - 2019-12-30 05:57:54 --> URI Class Initialized
INFO - 2019-12-30 05:57:54 --> Router Class Initialized
INFO - 2019-12-30 05:57:54 --> Output Class Initialized
INFO - 2019-12-30 05:57:54 --> Security Class Initialized
DEBUG - 2019-12-30 05:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:57:54 --> Input Class Initialized
INFO - 2019-12-30 05:57:54 --> Language Class Initialized
INFO - 2019-12-30 05:57:54 --> Loader Class Initialized
INFO - 2019-12-30 05:57:54 --> Helper loaded: url_helper
INFO - 2019-12-30 05:57:54 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:57:54 --> Controller Class Initialized
INFO - 2019-12-30 05:57:54 --> Model "M_login" initialized
INFO - 2019-12-30 05:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 05:57:54 --> Pagination Class Initialized
INFO - 2019-12-30 05:57:54 --> Model "M_pesan" initialized
INFO - 2019-12-30 05:57:54 --> Helper loaded: form_helper
INFO - 2019-12-30 05:57:54 --> Form Validation Class Initialized
INFO - 2019-12-30 05:57:54 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:57:54 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 05:57:54 --> Final output sent to browser
DEBUG - 2019-12-30 05:57:54 --> Total execution time: 0.6004
INFO - 2019-12-30 05:57:55 --> Config Class Initialized
INFO - 2019-12-30 05:57:55 --> Config Class Initialized
INFO - 2019-12-30 05:57:55 --> Hooks Class Initialized
INFO - 2019-12-30 05:57:55 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:57:55 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:57:55 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:57:55 --> Utf8 Class Initialized
INFO - 2019-12-30 05:57:55 --> Utf8 Class Initialized
INFO - 2019-12-30 05:57:55 --> URI Class Initialized
INFO - 2019-12-30 05:57:55 --> URI Class Initialized
INFO - 2019-12-30 05:57:55 --> Router Class Initialized
INFO - 2019-12-30 05:57:55 --> Router Class Initialized
INFO - 2019-12-30 05:57:55 --> Output Class Initialized
INFO - 2019-12-30 05:57:55 --> Output Class Initialized
INFO - 2019-12-30 05:57:55 --> Security Class Initialized
INFO - 2019-12-30 05:57:55 --> Security Class Initialized
DEBUG - 2019-12-30 05:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:57:55 --> Input Class Initialized
INFO - 2019-12-30 05:57:55 --> Input Class Initialized
INFO - 2019-12-30 05:57:55 --> Language Class Initialized
INFO - 2019-12-30 05:57:55 --> Language Class Initialized
ERROR - 2019-12-30 05:57:55 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 05:57:55 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:57:55 --> Config Class Initialized
INFO - 2019-12-30 05:57:55 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:57:55 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:57:55 --> Utf8 Class Initialized
INFO - 2019-12-30 05:57:55 --> URI Class Initialized
INFO - 2019-12-30 05:57:55 --> Router Class Initialized
INFO - 2019-12-30 05:57:55 --> Output Class Initialized
INFO - 2019-12-30 05:57:55 --> Security Class Initialized
DEBUG - 2019-12-30 05:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:57:55 --> Input Class Initialized
INFO - 2019-12-30 05:57:55 --> Language Class Initialized
ERROR - 2019-12-30 05:57:55 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:59:02 --> Config Class Initialized
INFO - 2019-12-30 05:59:02 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:59:02 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:59:02 --> Utf8 Class Initialized
INFO - 2019-12-30 05:59:02 --> URI Class Initialized
INFO - 2019-12-30 05:59:02 --> Router Class Initialized
INFO - 2019-12-30 05:59:02 --> Output Class Initialized
INFO - 2019-12-30 05:59:02 --> Security Class Initialized
DEBUG - 2019-12-30 05:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:59:02 --> Input Class Initialized
INFO - 2019-12-30 05:59:02 --> Language Class Initialized
INFO - 2019-12-30 05:59:02 --> Loader Class Initialized
INFO - 2019-12-30 05:59:02 --> Helper loaded: url_helper
INFO - 2019-12-30 05:59:02 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:59:02 --> Controller Class Initialized
INFO - 2019-12-30 05:59:02 --> Model "M_login" initialized
INFO - 2019-12-30 05:59:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 05:59:02 --> Pagination Class Initialized
INFO - 2019-12-30 05:59:02 --> Model "M_pesan" initialized
INFO - 2019-12-30 05:59:02 --> Helper loaded: form_helper
INFO - 2019-12-30 05:59:02 --> Form Validation Class Initialized
INFO - 2019-12-30 05:59:02 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:59:02 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 05:59:02 --> Final output sent to browser
DEBUG - 2019-12-30 05:59:02 --> Total execution time: 0.5594
INFO - 2019-12-30 05:59:03 --> Config Class Initialized
INFO - 2019-12-30 05:59:03 --> Config Class Initialized
INFO - 2019-12-30 05:59:03 --> Hooks Class Initialized
INFO - 2019-12-30 05:59:03 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:59:03 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:59:03 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:59:03 --> Utf8 Class Initialized
INFO - 2019-12-30 05:59:03 --> Utf8 Class Initialized
INFO - 2019-12-30 05:59:03 --> URI Class Initialized
INFO - 2019-12-30 05:59:03 --> URI Class Initialized
INFO - 2019-12-30 05:59:03 --> Router Class Initialized
INFO - 2019-12-30 05:59:03 --> Router Class Initialized
INFO - 2019-12-30 05:59:03 --> Output Class Initialized
INFO - 2019-12-30 05:59:03 --> Output Class Initialized
INFO - 2019-12-30 05:59:03 --> Security Class Initialized
INFO - 2019-12-30 05:59:03 --> Security Class Initialized
DEBUG - 2019-12-30 05:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:59:03 --> Input Class Initialized
INFO - 2019-12-30 05:59:03 --> Input Class Initialized
INFO - 2019-12-30 05:59:03 --> Language Class Initialized
INFO - 2019-12-30 05:59:03 --> Language Class Initialized
ERROR - 2019-12-30 05:59:03 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 05:59:03 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:59:03 --> Config Class Initialized
INFO - 2019-12-30 05:59:03 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:59:03 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:59:03 --> Utf8 Class Initialized
INFO - 2019-12-30 05:59:03 --> URI Class Initialized
INFO - 2019-12-30 05:59:03 --> Router Class Initialized
INFO - 2019-12-30 05:59:03 --> Output Class Initialized
INFO - 2019-12-30 05:59:03 --> Security Class Initialized
DEBUG - 2019-12-30 05:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:59:03 --> Input Class Initialized
INFO - 2019-12-30 05:59:03 --> Language Class Initialized
ERROR - 2019-12-30 05:59:03 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:59:12 --> Config Class Initialized
INFO - 2019-12-30 05:59:13 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:59:13 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:59:13 --> Utf8 Class Initialized
INFO - 2019-12-30 05:59:13 --> URI Class Initialized
INFO - 2019-12-30 05:59:13 --> Router Class Initialized
INFO - 2019-12-30 05:59:13 --> Output Class Initialized
INFO - 2019-12-30 05:59:13 --> Security Class Initialized
DEBUG - 2019-12-30 05:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:59:13 --> Input Class Initialized
INFO - 2019-12-30 05:59:13 --> Language Class Initialized
INFO - 2019-12-30 05:59:13 --> Loader Class Initialized
INFO - 2019-12-30 05:59:13 --> Helper loaded: url_helper
INFO - 2019-12-30 05:59:13 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:59:13 --> Controller Class Initialized
INFO - 2019-12-30 05:59:13 --> Model "M_login" initialized
INFO - 2019-12-30 05:59:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 05:59:13 --> Pagination Class Initialized
INFO - 2019-12-30 05:59:13 --> Model "M_pesan" initialized
INFO - 2019-12-30 05:59:13 --> Helper loaded: form_helper
INFO - 2019-12-30 05:59:13 --> Form Validation Class Initialized
INFO - 2019-12-30 05:59:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:59:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 05:59:13 --> Final output sent to browser
DEBUG - 2019-12-30 05:59:13 --> Total execution time: 0.6232
INFO - 2019-12-30 05:59:13 --> Config Class Initialized
INFO - 2019-12-30 05:59:13 --> Config Class Initialized
INFO - 2019-12-30 05:59:13 --> Hooks Class Initialized
INFO - 2019-12-30 05:59:13 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:59:13 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:59:13 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:59:13 --> Utf8 Class Initialized
INFO - 2019-12-30 05:59:13 --> Utf8 Class Initialized
INFO - 2019-12-30 05:59:13 --> URI Class Initialized
INFO - 2019-12-30 05:59:13 --> URI Class Initialized
INFO - 2019-12-30 05:59:13 --> Router Class Initialized
INFO - 2019-12-30 05:59:13 --> Router Class Initialized
INFO - 2019-12-30 05:59:13 --> Output Class Initialized
INFO - 2019-12-30 05:59:13 --> Output Class Initialized
INFO - 2019-12-30 05:59:13 --> Security Class Initialized
INFO - 2019-12-30 05:59:13 --> Security Class Initialized
DEBUG - 2019-12-30 05:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:59:13 --> Input Class Initialized
INFO - 2019-12-30 05:59:13 --> Input Class Initialized
INFO - 2019-12-30 05:59:13 --> Language Class Initialized
INFO - 2019-12-30 05:59:13 --> Language Class Initialized
ERROR - 2019-12-30 05:59:13 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 05:59:13 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:59:45 --> Config Class Initialized
INFO - 2019-12-30 05:59:45 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:59:45 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:59:45 --> Utf8 Class Initialized
INFO - 2019-12-30 05:59:45 --> URI Class Initialized
INFO - 2019-12-30 05:59:45 --> Router Class Initialized
INFO - 2019-12-30 05:59:45 --> Output Class Initialized
INFO - 2019-12-30 05:59:45 --> Security Class Initialized
DEBUG - 2019-12-30 05:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:59:45 --> Input Class Initialized
INFO - 2019-12-30 05:59:45 --> Language Class Initialized
INFO - 2019-12-30 05:59:45 --> Loader Class Initialized
INFO - 2019-12-30 05:59:45 --> Helper loaded: url_helper
INFO - 2019-12-30 05:59:45 --> Database Driver Class Initialized
DEBUG - 2019-12-30 05:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 05:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 05:59:45 --> Controller Class Initialized
INFO - 2019-12-30 05:59:45 --> Model "M_login" initialized
INFO - 2019-12-30 05:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 05:59:45 --> Pagination Class Initialized
INFO - 2019-12-30 05:59:45 --> Model "M_pesan" initialized
INFO - 2019-12-30 05:59:45 --> Helper loaded: form_helper
INFO - 2019-12-30 05:59:45 --> Form Validation Class Initialized
INFO - 2019-12-30 05:59:45 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 05:59:45 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 05:59:46 --> Final output sent to browser
DEBUG - 2019-12-30 05:59:46 --> Total execution time: 0.5349
INFO - 2019-12-30 05:59:46 --> Config Class Initialized
INFO - 2019-12-30 05:59:46 --> Config Class Initialized
INFO - 2019-12-30 05:59:46 --> Hooks Class Initialized
INFO - 2019-12-30 05:59:46 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:59:46 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 05:59:46 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:59:46 --> Utf8 Class Initialized
INFO - 2019-12-30 05:59:46 --> Utf8 Class Initialized
INFO - 2019-12-30 05:59:46 --> URI Class Initialized
INFO - 2019-12-30 05:59:46 --> URI Class Initialized
INFO - 2019-12-30 05:59:46 --> Router Class Initialized
INFO - 2019-12-30 05:59:46 --> Router Class Initialized
INFO - 2019-12-30 05:59:46 --> Output Class Initialized
INFO - 2019-12-30 05:59:46 --> Output Class Initialized
INFO - 2019-12-30 05:59:46 --> Security Class Initialized
INFO - 2019-12-30 05:59:46 --> Security Class Initialized
DEBUG - 2019-12-30 05:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 05:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:59:46 --> Input Class Initialized
INFO - 2019-12-30 05:59:46 --> Input Class Initialized
INFO - 2019-12-30 05:59:46 --> Language Class Initialized
INFO - 2019-12-30 05:59:46 --> Language Class Initialized
ERROR - 2019-12-30 05:59:46 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 05:59:46 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 05:59:46 --> Config Class Initialized
INFO - 2019-12-30 05:59:46 --> Hooks Class Initialized
DEBUG - 2019-12-30 05:59:46 --> UTF-8 Support Enabled
INFO - 2019-12-30 05:59:46 --> Utf8 Class Initialized
INFO - 2019-12-30 05:59:46 --> URI Class Initialized
INFO - 2019-12-30 05:59:46 --> Router Class Initialized
INFO - 2019-12-30 05:59:46 --> Output Class Initialized
INFO - 2019-12-30 05:59:46 --> Security Class Initialized
DEBUG - 2019-12-30 05:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 05:59:46 --> Input Class Initialized
INFO - 2019-12-30 05:59:46 --> Language Class Initialized
ERROR - 2019-12-30 05:59:46 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:00:31 --> Config Class Initialized
INFO - 2019-12-30 06:00:31 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:00:31 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:00:31 --> Utf8 Class Initialized
INFO - 2019-12-30 06:00:31 --> URI Class Initialized
INFO - 2019-12-30 06:00:31 --> Router Class Initialized
INFO - 2019-12-30 06:00:31 --> Output Class Initialized
INFO - 2019-12-30 06:00:31 --> Security Class Initialized
DEBUG - 2019-12-30 06:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:00:31 --> Input Class Initialized
INFO - 2019-12-30 06:00:31 --> Language Class Initialized
INFO - 2019-12-30 06:00:31 --> Loader Class Initialized
INFO - 2019-12-30 06:00:31 --> Helper loaded: url_helper
INFO - 2019-12-30 06:00:31 --> Database Driver Class Initialized
DEBUG - 2019-12-30 06:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 06:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 06:00:31 --> Controller Class Initialized
INFO - 2019-12-30 06:00:31 --> Model "M_login" initialized
INFO - 2019-12-30 06:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 06:00:31 --> Pagination Class Initialized
INFO - 2019-12-30 06:00:31 --> Model "M_pesan" initialized
INFO - 2019-12-30 06:00:31 --> Helper loaded: form_helper
INFO - 2019-12-30 06:00:31 --> Form Validation Class Initialized
INFO - 2019-12-30 06:00:31 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 06:00:31 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 06:00:32 --> Final output sent to browser
DEBUG - 2019-12-30 06:00:32 --> Total execution time: 0.5031
INFO - 2019-12-30 06:00:32 --> Config Class Initialized
INFO - 2019-12-30 06:00:32 --> Config Class Initialized
INFO - 2019-12-30 06:00:32 --> Hooks Class Initialized
INFO - 2019-12-30 06:00:32 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:00:32 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 06:00:32 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:00:32 --> Utf8 Class Initialized
INFO - 2019-12-30 06:00:32 --> Utf8 Class Initialized
INFO - 2019-12-30 06:00:32 --> URI Class Initialized
INFO - 2019-12-30 06:00:32 --> URI Class Initialized
INFO - 2019-12-30 06:00:32 --> Router Class Initialized
INFO - 2019-12-30 06:00:32 --> Router Class Initialized
INFO - 2019-12-30 06:00:32 --> Output Class Initialized
INFO - 2019-12-30 06:00:32 --> Output Class Initialized
INFO - 2019-12-30 06:00:32 --> Security Class Initialized
INFO - 2019-12-30 06:00:32 --> Security Class Initialized
DEBUG - 2019-12-30 06:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 06:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:00:32 --> Input Class Initialized
INFO - 2019-12-30 06:00:32 --> Input Class Initialized
INFO - 2019-12-30 06:00:32 --> Language Class Initialized
INFO - 2019-12-30 06:00:32 --> Language Class Initialized
ERROR - 2019-12-30 06:00:32 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 06:00:32 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:01:07 --> Config Class Initialized
INFO - 2019-12-30 06:01:07 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:01:07 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:01:07 --> Utf8 Class Initialized
INFO - 2019-12-30 06:01:07 --> URI Class Initialized
INFO - 2019-12-30 06:01:07 --> Router Class Initialized
INFO - 2019-12-30 06:01:07 --> Output Class Initialized
INFO - 2019-12-30 06:01:07 --> Security Class Initialized
DEBUG - 2019-12-30 06:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:01:07 --> Input Class Initialized
INFO - 2019-12-30 06:01:07 --> Language Class Initialized
INFO - 2019-12-30 06:01:07 --> Loader Class Initialized
INFO - 2019-12-30 06:01:07 --> Helper loaded: url_helper
INFO - 2019-12-30 06:01:07 --> Database Driver Class Initialized
DEBUG - 2019-12-30 06:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 06:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 06:01:07 --> Controller Class Initialized
INFO - 2019-12-30 06:01:07 --> Model "M_login" initialized
INFO - 2019-12-30 06:01:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 06:01:07 --> Pagination Class Initialized
INFO - 2019-12-30 06:01:07 --> Model "M_pesan" initialized
INFO - 2019-12-30 06:01:07 --> Helper loaded: form_helper
INFO - 2019-12-30 06:01:07 --> Form Validation Class Initialized
INFO - 2019-12-30 06:01:07 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 06:01:07 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 06:01:08 --> Final output sent to browser
DEBUG - 2019-12-30 06:01:08 --> Total execution time: 0.5791
INFO - 2019-12-30 06:01:08 --> Config Class Initialized
INFO - 2019-12-30 06:01:08 --> Config Class Initialized
INFO - 2019-12-30 06:01:08 --> Hooks Class Initialized
INFO - 2019-12-30 06:01:08 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:01:08 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 06:01:08 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:01:08 --> Utf8 Class Initialized
INFO - 2019-12-30 06:01:08 --> Utf8 Class Initialized
INFO - 2019-12-30 06:01:08 --> URI Class Initialized
INFO - 2019-12-30 06:01:08 --> URI Class Initialized
INFO - 2019-12-30 06:01:08 --> Router Class Initialized
INFO - 2019-12-30 06:01:08 --> Router Class Initialized
INFO - 2019-12-30 06:01:08 --> Output Class Initialized
INFO - 2019-12-30 06:01:08 --> Output Class Initialized
INFO - 2019-12-30 06:01:08 --> Security Class Initialized
INFO - 2019-12-30 06:01:08 --> Security Class Initialized
DEBUG - 2019-12-30 06:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 06:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:01:08 --> Input Class Initialized
INFO - 2019-12-30 06:01:08 --> Input Class Initialized
INFO - 2019-12-30 06:01:08 --> Language Class Initialized
INFO - 2019-12-30 06:01:08 --> Language Class Initialized
ERROR - 2019-12-30 06:01:08 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 06:01:08 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:01:08 --> Config Class Initialized
INFO - 2019-12-30 06:01:08 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:01:08 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:01:08 --> Utf8 Class Initialized
INFO - 2019-12-30 06:01:08 --> URI Class Initialized
INFO - 2019-12-30 06:01:08 --> Router Class Initialized
INFO - 2019-12-30 06:01:08 --> Output Class Initialized
INFO - 2019-12-30 06:01:08 --> Security Class Initialized
DEBUG - 2019-12-30 06:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:01:08 --> Input Class Initialized
INFO - 2019-12-30 06:01:08 --> Language Class Initialized
ERROR - 2019-12-30 06:01:08 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:01:30 --> Config Class Initialized
INFO - 2019-12-30 06:01:30 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:01:30 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:01:30 --> Utf8 Class Initialized
INFO - 2019-12-30 06:01:30 --> URI Class Initialized
INFO - 2019-12-30 06:01:30 --> Router Class Initialized
INFO - 2019-12-30 06:01:30 --> Output Class Initialized
INFO - 2019-12-30 06:01:30 --> Security Class Initialized
DEBUG - 2019-12-30 06:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:01:30 --> Input Class Initialized
INFO - 2019-12-30 06:01:30 --> Language Class Initialized
INFO - 2019-12-30 06:01:30 --> Loader Class Initialized
INFO - 2019-12-30 06:01:30 --> Helper loaded: url_helper
INFO - 2019-12-30 06:01:30 --> Database Driver Class Initialized
DEBUG - 2019-12-30 06:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 06:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 06:01:30 --> Controller Class Initialized
INFO - 2019-12-30 06:01:30 --> Model "M_login" initialized
INFO - 2019-12-30 06:01:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 06:01:30 --> Pagination Class Initialized
INFO - 2019-12-30 06:01:30 --> Model "M_pesan" initialized
INFO - 2019-12-30 06:01:30 --> Helper loaded: form_helper
INFO - 2019-12-30 06:01:30 --> Form Validation Class Initialized
INFO - 2019-12-30 06:01:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 06:01:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 06:01:31 --> Final output sent to browser
DEBUG - 2019-12-30 06:01:31 --> Total execution time: 0.5621
INFO - 2019-12-30 06:01:31 --> Config Class Initialized
INFO - 2019-12-30 06:01:31 --> Config Class Initialized
INFO - 2019-12-30 06:01:31 --> Hooks Class Initialized
INFO - 2019-12-30 06:01:31 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:01:31 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 06:01:31 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:01:31 --> Utf8 Class Initialized
INFO - 2019-12-30 06:01:31 --> Utf8 Class Initialized
INFO - 2019-12-30 06:01:31 --> URI Class Initialized
INFO - 2019-12-30 06:01:31 --> URI Class Initialized
INFO - 2019-12-30 06:01:31 --> Router Class Initialized
INFO - 2019-12-30 06:01:31 --> Router Class Initialized
INFO - 2019-12-30 06:01:31 --> Output Class Initialized
INFO - 2019-12-30 06:01:31 --> Output Class Initialized
INFO - 2019-12-30 06:01:31 --> Security Class Initialized
INFO - 2019-12-30 06:01:31 --> Security Class Initialized
DEBUG - 2019-12-30 06:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 06:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:01:31 --> Input Class Initialized
INFO - 2019-12-30 06:01:31 --> Input Class Initialized
INFO - 2019-12-30 06:01:31 --> Language Class Initialized
INFO - 2019-12-30 06:01:31 --> Language Class Initialized
ERROR - 2019-12-30 06:01:31 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 06:01:31 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:02:04 --> Config Class Initialized
INFO - 2019-12-30 06:02:04 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:02:04 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:02:04 --> Utf8 Class Initialized
INFO - 2019-12-30 06:02:04 --> URI Class Initialized
INFO - 2019-12-30 06:02:04 --> Router Class Initialized
INFO - 2019-12-30 06:02:04 --> Output Class Initialized
INFO - 2019-12-30 06:02:04 --> Security Class Initialized
DEBUG - 2019-12-30 06:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:02:04 --> Input Class Initialized
INFO - 2019-12-30 06:02:04 --> Language Class Initialized
INFO - 2019-12-30 06:02:04 --> Loader Class Initialized
INFO - 2019-12-30 06:02:04 --> Helper loaded: url_helper
INFO - 2019-12-30 06:02:04 --> Database Driver Class Initialized
DEBUG - 2019-12-30 06:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 06:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 06:02:04 --> Controller Class Initialized
INFO - 2019-12-30 06:02:04 --> Model "M_login" initialized
INFO - 2019-12-30 06:02:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 06:02:04 --> Pagination Class Initialized
INFO - 2019-12-30 06:02:04 --> Model "M_pesan" initialized
INFO - 2019-12-30 06:02:04 --> Helper loaded: form_helper
INFO - 2019-12-30 06:02:04 --> Form Validation Class Initialized
INFO - 2019-12-30 06:02:04 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 06:02:04 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 06:02:04 --> Final output sent to browser
DEBUG - 2019-12-30 06:02:04 --> Total execution time: 0.4997
INFO - 2019-12-30 06:02:04 --> Config Class Initialized
INFO - 2019-12-30 06:02:04 --> Config Class Initialized
INFO - 2019-12-30 06:02:04 --> Hooks Class Initialized
INFO - 2019-12-30 06:02:04 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:02:04 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 06:02:04 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:02:04 --> Utf8 Class Initialized
INFO - 2019-12-30 06:02:04 --> Utf8 Class Initialized
INFO - 2019-12-30 06:02:04 --> URI Class Initialized
INFO - 2019-12-30 06:02:04 --> URI Class Initialized
INFO - 2019-12-30 06:02:04 --> Router Class Initialized
INFO - 2019-12-30 06:02:04 --> Router Class Initialized
INFO - 2019-12-30 06:02:04 --> Output Class Initialized
INFO - 2019-12-30 06:02:04 --> Output Class Initialized
INFO - 2019-12-30 06:02:04 --> Security Class Initialized
INFO - 2019-12-30 06:02:04 --> Security Class Initialized
DEBUG - 2019-12-30 06:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 06:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:02:04 --> Input Class Initialized
INFO - 2019-12-30 06:02:04 --> Input Class Initialized
INFO - 2019-12-30 06:02:04 --> Language Class Initialized
INFO - 2019-12-30 06:02:04 --> Language Class Initialized
ERROR - 2019-12-30 06:02:04 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 06:02:04 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:02:04 --> Config Class Initialized
INFO - 2019-12-30 06:02:04 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:02:04 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:02:05 --> Utf8 Class Initialized
INFO - 2019-12-30 06:02:05 --> URI Class Initialized
INFO - 2019-12-30 06:02:05 --> Router Class Initialized
INFO - 2019-12-30 06:02:05 --> Output Class Initialized
INFO - 2019-12-30 06:02:05 --> Security Class Initialized
DEBUG - 2019-12-30 06:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:02:05 --> Input Class Initialized
INFO - 2019-12-30 06:02:05 --> Language Class Initialized
ERROR - 2019-12-30 06:02:05 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:03:16 --> Config Class Initialized
INFO - 2019-12-30 06:03:16 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:03:16 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:03:16 --> Utf8 Class Initialized
INFO - 2019-12-30 06:03:16 --> URI Class Initialized
INFO - 2019-12-30 06:03:16 --> Router Class Initialized
INFO - 2019-12-30 06:03:16 --> Output Class Initialized
INFO - 2019-12-30 06:03:17 --> Security Class Initialized
DEBUG - 2019-12-30 06:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:03:17 --> Input Class Initialized
INFO - 2019-12-30 06:03:17 --> Language Class Initialized
INFO - 2019-12-30 06:03:17 --> Loader Class Initialized
INFO - 2019-12-30 06:03:17 --> Helper loaded: url_helper
INFO - 2019-12-30 06:03:17 --> Database Driver Class Initialized
DEBUG - 2019-12-30 06:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 06:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 06:03:17 --> Controller Class Initialized
INFO - 2019-12-30 06:03:17 --> Model "M_login" initialized
INFO - 2019-12-30 06:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 06:03:17 --> Pagination Class Initialized
INFO - 2019-12-30 06:03:17 --> Model "M_pesan" initialized
INFO - 2019-12-30 06:03:17 --> Helper loaded: form_helper
INFO - 2019-12-30 06:03:17 --> Form Validation Class Initialized
INFO - 2019-12-30 06:03:17 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 06:03:17 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 06:03:17 --> Final output sent to browser
DEBUG - 2019-12-30 06:03:17 --> Total execution time: 0.5331
INFO - 2019-12-30 06:03:17 --> Config Class Initialized
INFO - 2019-12-30 06:03:17 --> Config Class Initialized
INFO - 2019-12-30 06:03:17 --> Hooks Class Initialized
INFO - 2019-12-30 06:03:17 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:03:17 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 06:03:17 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:03:17 --> Utf8 Class Initialized
INFO - 2019-12-30 06:03:17 --> Utf8 Class Initialized
INFO - 2019-12-30 06:03:17 --> URI Class Initialized
INFO - 2019-12-30 06:03:17 --> URI Class Initialized
INFO - 2019-12-30 06:03:17 --> Router Class Initialized
INFO - 2019-12-30 06:03:17 --> Router Class Initialized
INFO - 2019-12-30 06:03:17 --> Output Class Initialized
INFO - 2019-12-30 06:03:17 --> Output Class Initialized
INFO - 2019-12-30 06:03:17 --> Security Class Initialized
INFO - 2019-12-30 06:03:17 --> Security Class Initialized
DEBUG - 2019-12-30 06:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 06:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:03:17 --> Input Class Initialized
INFO - 2019-12-30 06:03:17 --> Input Class Initialized
INFO - 2019-12-30 06:03:17 --> Language Class Initialized
INFO - 2019-12-30 06:03:17 --> Language Class Initialized
ERROR - 2019-12-30 06:03:17 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 06:03:17 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:05:12 --> Config Class Initialized
INFO - 2019-12-30 06:05:12 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:05:12 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:05:12 --> Utf8 Class Initialized
INFO - 2019-12-30 06:05:12 --> URI Class Initialized
INFO - 2019-12-30 06:05:12 --> Router Class Initialized
INFO - 2019-12-30 06:05:12 --> Output Class Initialized
INFO - 2019-12-30 06:05:12 --> Security Class Initialized
DEBUG - 2019-12-30 06:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:05:12 --> Input Class Initialized
INFO - 2019-12-30 06:05:12 --> Language Class Initialized
INFO - 2019-12-30 06:05:12 --> Loader Class Initialized
INFO - 2019-12-30 06:05:12 --> Helper loaded: url_helper
INFO - 2019-12-30 06:05:13 --> Database Driver Class Initialized
DEBUG - 2019-12-30 06:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 06:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 06:05:13 --> Controller Class Initialized
INFO - 2019-12-30 06:05:13 --> Model "M_login" initialized
INFO - 2019-12-30 06:05:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 06:05:13 --> Pagination Class Initialized
INFO - 2019-12-30 06:05:13 --> Model "M_pesan" initialized
INFO - 2019-12-30 06:05:13 --> Helper loaded: form_helper
INFO - 2019-12-30 06:05:13 --> Form Validation Class Initialized
INFO - 2019-12-30 06:05:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 06:05:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 06:05:13 --> Final output sent to browser
DEBUG - 2019-12-30 06:05:13 --> Total execution time: 0.5726
INFO - 2019-12-30 06:05:13 --> Config Class Initialized
INFO - 2019-12-30 06:05:13 --> Config Class Initialized
INFO - 2019-12-30 06:05:13 --> Hooks Class Initialized
INFO - 2019-12-30 06:05:13 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:05:13 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 06:05:13 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:05:13 --> Utf8 Class Initialized
INFO - 2019-12-30 06:05:13 --> Utf8 Class Initialized
INFO - 2019-12-30 06:05:13 --> URI Class Initialized
INFO - 2019-12-30 06:05:13 --> URI Class Initialized
INFO - 2019-12-30 06:05:13 --> Router Class Initialized
INFO - 2019-12-30 06:05:13 --> Router Class Initialized
INFO - 2019-12-30 06:05:13 --> Output Class Initialized
INFO - 2019-12-30 06:05:13 --> Output Class Initialized
INFO - 2019-12-30 06:05:13 --> Security Class Initialized
INFO - 2019-12-30 06:05:13 --> Security Class Initialized
DEBUG - 2019-12-30 06:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 06:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:05:13 --> Input Class Initialized
INFO - 2019-12-30 06:05:13 --> Input Class Initialized
INFO - 2019-12-30 06:05:13 --> Language Class Initialized
INFO - 2019-12-30 06:05:13 --> Language Class Initialized
ERROR - 2019-12-30 06:05:13 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 06:05:13 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:05:42 --> Config Class Initialized
INFO - 2019-12-30 06:05:42 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:05:42 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:05:42 --> Utf8 Class Initialized
INFO - 2019-12-30 06:05:42 --> URI Class Initialized
INFO - 2019-12-30 06:05:42 --> Router Class Initialized
INFO - 2019-12-30 06:05:42 --> Output Class Initialized
INFO - 2019-12-30 06:05:42 --> Security Class Initialized
DEBUG - 2019-12-30 06:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:05:42 --> Input Class Initialized
INFO - 2019-12-30 06:05:42 --> Language Class Initialized
INFO - 2019-12-30 06:05:42 --> Loader Class Initialized
INFO - 2019-12-30 06:05:42 --> Helper loaded: url_helper
INFO - 2019-12-30 06:05:42 --> Database Driver Class Initialized
DEBUG - 2019-12-30 06:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 06:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 06:05:42 --> Controller Class Initialized
INFO - 2019-12-30 06:05:42 --> Model "M_login" initialized
INFO - 2019-12-30 06:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 06:05:42 --> Pagination Class Initialized
INFO - 2019-12-30 06:05:42 --> Model "M_pesan" initialized
INFO - 2019-12-30 06:05:42 --> Helper loaded: form_helper
INFO - 2019-12-30 06:05:42 --> Form Validation Class Initialized
INFO - 2019-12-30 06:05:42 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 06:05:42 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 06:05:42 --> Final output sent to browser
DEBUG - 2019-12-30 06:05:42 --> Total execution time: 0.6335
INFO - 2019-12-30 06:05:42 --> Config Class Initialized
INFO - 2019-12-30 06:05:42 --> Config Class Initialized
INFO - 2019-12-30 06:05:42 --> Hooks Class Initialized
INFO - 2019-12-30 06:05:42 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:05:43 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 06:05:43 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:05:43 --> Utf8 Class Initialized
INFO - 2019-12-30 06:05:43 --> Utf8 Class Initialized
INFO - 2019-12-30 06:05:43 --> URI Class Initialized
INFO - 2019-12-30 06:05:43 --> URI Class Initialized
INFO - 2019-12-30 06:05:43 --> Router Class Initialized
INFO - 2019-12-30 06:05:43 --> Router Class Initialized
INFO - 2019-12-30 06:05:43 --> Output Class Initialized
INFO - 2019-12-30 06:05:43 --> Output Class Initialized
INFO - 2019-12-30 06:05:43 --> Security Class Initialized
INFO - 2019-12-30 06:05:43 --> Security Class Initialized
DEBUG - 2019-12-30 06:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 06:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:05:43 --> Input Class Initialized
INFO - 2019-12-30 06:05:43 --> Input Class Initialized
INFO - 2019-12-30 06:05:43 --> Language Class Initialized
INFO - 2019-12-30 06:05:43 --> Language Class Initialized
ERROR - 2019-12-30 06:05:43 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 06:05:43 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:05:43 --> Config Class Initialized
INFO - 2019-12-30 06:05:43 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:05:43 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:05:43 --> Utf8 Class Initialized
INFO - 2019-12-30 06:05:43 --> URI Class Initialized
INFO - 2019-12-30 06:05:43 --> Router Class Initialized
INFO - 2019-12-30 06:05:43 --> Output Class Initialized
INFO - 2019-12-30 06:05:43 --> Security Class Initialized
DEBUG - 2019-12-30 06:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:05:43 --> Input Class Initialized
INFO - 2019-12-30 06:05:43 --> Language Class Initialized
ERROR - 2019-12-30 06:05:43 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:06:04 --> Config Class Initialized
INFO - 2019-12-30 06:06:04 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:06:04 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:06:04 --> Utf8 Class Initialized
INFO - 2019-12-30 06:06:04 --> URI Class Initialized
INFO - 2019-12-30 06:06:04 --> Router Class Initialized
INFO - 2019-12-30 06:06:04 --> Output Class Initialized
INFO - 2019-12-30 06:06:04 --> Security Class Initialized
DEBUG - 2019-12-30 06:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:06:04 --> Input Class Initialized
INFO - 2019-12-30 06:06:04 --> Language Class Initialized
INFO - 2019-12-30 06:06:04 --> Loader Class Initialized
INFO - 2019-12-30 06:06:04 --> Helper loaded: url_helper
INFO - 2019-12-30 06:06:04 --> Database Driver Class Initialized
DEBUG - 2019-12-30 06:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 06:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 06:06:04 --> Controller Class Initialized
INFO - 2019-12-30 06:06:04 --> Model "M_login" initialized
INFO - 2019-12-30 06:06:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 06:06:04 --> Pagination Class Initialized
INFO - 2019-12-30 06:06:04 --> Model "M_pesan" initialized
INFO - 2019-12-30 06:06:05 --> Helper loaded: form_helper
INFO - 2019-12-30 06:06:05 --> Form Validation Class Initialized
INFO - 2019-12-30 06:06:05 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 06:06:05 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 06:06:05 --> Final output sent to browser
DEBUG - 2019-12-30 06:06:05 --> Total execution time: 0.5346
INFO - 2019-12-30 06:06:05 --> Config Class Initialized
INFO - 2019-12-30 06:06:05 --> Config Class Initialized
INFO - 2019-12-30 06:06:05 --> Hooks Class Initialized
INFO - 2019-12-30 06:06:05 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:06:05 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 06:06:05 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:06:05 --> Utf8 Class Initialized
INFO - 2019-12-30 06:06:05 --> Utf8 Class Initialized
INFO - 2019-12-30 06:06:05 --> URI Class Initialized
INFO - 2019-12-30 06:06:05 --> URI Class Initialized
INFO - 2019-12-30 06:06:05 --> Router Class Initialized
INFO - 2019-12-30 06:06:05 --> Router Class Initialized
INFO - 2019-12-30 06:06:05 --> Output Class Initialized
INFO - 2019-12-30 06:06:05 --> Output Class Initialized
INFO - 2019-12-30 06:06:05 --> Security Class Initialized
INFO - 2019-12-30 06:06:05 --> Security Class Initialized
DEBUG - 2019-12-30 06:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 06:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:06:05 --> Input Class Initialized
INFO - 2019-12-30 06:06:05 --> Input Class Initialized
INFO - 2019-12-30 06:06:05 --> Language Class Initialized
INFO - 2019-12-30 06:06:05 --> Language Class Initialized
ERROR - 2019-12-30 06:06:05 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 06:06:05 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:06:05 --> Config Class Initialized
INFO - 2019-12-30 06:06:05 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:06:05 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:06:05 --> Utf8 Class Initialized
INFO - 2019-12-30 06:06:05 --> URI Class Initialized
INFO - 2019-12-30 06:06:05 --> Router Class Initialized
INFO - 2019-12-30 06:06:05 --> Output Class Initialized
INFO - 2019-12-30 06:06:05 --> Security Class Initialized
DEBUG - 2019-12-30 06:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:06:05 --> Input Class Initialized
INFO - 2019-12-30 06:06:05 --> Language Class Initialized
ERROR - 2019-12-30 06:06:05 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:07:26 --> Config Class Initialized
INFO - 2019-12-30 06:07:26 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:07:26 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:07:26 --> Utf8 Class Initialized
INFO - 2019-12-30 06:07:26 --> URI Class Initialized
INFO - 2019-12-30 06:07:26 --> Router Class Initialized
INFO - 2019-12-30 06:07:26 --> Output Class Initialized
INFO - 2019-12-30 06:07:26 --> Security Class Initialized
DEBUG - 2019-12-30 06:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:07:26 --> Input Class Initialized
INFO - 2019-12-30 06:07:26 --> Language Class Initialized
INFO - 2019-12-30 06:07:26 --> Loader Class Initialized
INFO - 2019-12-30 06:07:26 --> Helper loaded: url_helper
INFO - 2019-12-30 06:07:26 --> Database Driver Class Initialized
DEBUG - 2019-12-30 06:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 06:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 06:07:26 --> Controller Class Initialized
INFO - 2019-12-30 06:07:26 --> Model "M_login" initialized
INFO - 2019-12-30 06:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 06:07:26 --> Pagination Class Initialized
INFO - 2019-12-30 06:07:26 --> Model "M_pesan" initialized
INFO - 2019-12-30 06:07:27 --> Helper loaded: form_helper
INFO - 2019-12-30 06:07:27 --> Form Validation Class Initialized
INFO - 2019-12-30 06:07:27 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 06:07:27 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-30 06:07:27 --> Final output sent to browser
DEBUG - 2019-12-30 06:07:27 --> Total execution time: 0.5312
INFO - 2019-12-30 06:07:27 --> Config Class Initialized
INFO - 2019-12-30 06:07:27 --> Config Class Initialized
INFO - 2019-12-30 06:07:27 --> Hooks Class Initialized
INFO - 2019-12-30 06:07:27 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:07:27 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 06:07:27 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:07:27 --> Utf8 Class Initialized
INFO - 2019-12-30 06:07:27 --> Utf8 Class Initialized
INFO - 2019-12-30 06:07:27 --> URI Class Initialized
INFO - 2019-12-30 06:07:27 --> URI Class Initialized
INFO - 2019-12-30 06:07:27 --> Router Class Initialized
INFO - 2019-12-30 06:07:27 --> Router Class Initialized
INFO - 2019-12-30 06:07:27 --> Output Class Initialized
INFO - 2019-12-30 06:07:27 --> Output Class Initialized
INFO - 2019-12-30 06:07:27 --> Security Class Initialized
INFO - 2019-12-30 06:07:27 --> Security Class Initialized
DEBUG - 2019-12-30 06:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 06:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:07:27 --> Input Class Initialized
INFO - 2019-12-30 06:07:27 --> Input Class Initialized
INFO - 2019-12-30 06:07:27 --> Language Class Initialized
INFO - 2019-12-30 06:07:27 --> Language Class Initialized
ERROR - 2019-12-30 06:07:27 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-30 06:07:27 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 06:07:27 --> Config Class Initialized
INFO - 2019-12-30 06:07:27 --> Hooks Class Initialized
DEBUG - 2019-12-30 06:07:27 --> UTF-8 Support Enabled
INFO - 2019-12-30 06:07:27 --> Utf8 Class Initialized
INFO - 2019-12-30 06:07:27 --> URI Class Initialized
INFO - 2019-12-30 06:07:27 --> Router Class Initialized
INFO - 2019-12-30 06:07:27 --> Output Class Initialized
INFO - 2019-12-30 06:07:27 --> Security Class Initialized
DEBUG - 2019-12-30 06:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 06:07:27 --> Input Class Initialized
INFO - 2019-12-30 06:07:27 --> Language Class Initialized
ERROR - 2019-12-30 06:07:27 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-30 11:45:47 --> Config Class Initialized
INFO - 2019-12-30 11:45:47 --> Hooks Class Initialized
DEBUG - 2019-12-30 11:45:47 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:45:47 --> Utf8 Class Initialized
INFO - 2019-12-30 11:45:47 --> URI Class Initialized
DEBUG - 2019-12-30 11:45:47 --> No URI present. Default controller set.
INFO - 2019-12-30 11:45:47 --> Router Class Initialized
INFO - 2019-12-30 11:45:48 --> Output Class Initialized
INFO - 2019-12-30 11:45:48 --> Security Class Initialized
DEBUG - 2019-12-30 11:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:45:48 --> Input Class Initialized
INFO - 2019-12-30 11:45:48 --> Language Class Initialized
INFO - 2019-12-30 11:45:48 --> Loader Class Initialized
INFO - 2019-12-30 11:45:48 --> Helper loaded: url_helper
INFO - 2019-12-30 11:45:48 --> Database Driver Class Initialized
DEBUG - 2019-12-30 11:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 11:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 11:45:48 --> Controller Class Initialized
INFO - 2019-12-30 11:45:48 --> Model "M_login" initialized
INFO - 2019-12-30 11:45:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2019-12-30 11:45:48 --> Final output sent to browser
DEBUG - 2019-12-30 11:45:48 --> Total execution time: 1.9130
INFO - 2019-12-30 11:45:58 --> Config Class Initialized
INFO - 2019-12-30 11:45:58 --> Hooks Class Initialized
DEBUG - 2019-12-30 11:45:58 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:45:58 --> Utf8 Class Initialized
INFO - 2019-12-30 11:45:58 --> URI Class Initialized
INFO - 2019-12-30 11:45:58 --> Router Class Initialized
INFO - 2019-12-30 11:45:58 --> Output Class Initialized
INFO - 2019-12-30 11:45:58 --> Security Class Initialized
DEBUG - 2019-12-30 11:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:45:58 --> Input Class Initialized
INFO - 2019-12-30 11:45:58 --> Language Class Initialized
INFO - 2019-12-30 11:45:58 --> Loader Class Initialized
INFO - 2019-12-30 11:45:58 --> Helper loaded: url_helper
INFO - 2019-12-30 11:45:58 --> Database Driver Class Initialized
DEBUG - 2019-12-30 11:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 11:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 11:45:58 --> Controller Class Initialized
INFO - 2019-12-30 11:45:58 --> Model "M_login" initialized
INFO - 2019-12-30 11:45:58 --> Config Class Initialized
INFO - 2019-12-30 11:45:58 --> Hooks Class Initialized
DEBUG - 2019-12-30 11:45:58 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:45:58 --> Utf8 Class Initialized
INFO - 2019-12-30 11:45:58 --> URI Class Initialized
INFO - 2019-12-30 11:45:58 --> Router Class Initialized
INFO - 2019-12-30 11:45:58 --> Output Class Initialized
INFO - 2019-12-30 11:45:58 --> Security Class Initialized
DEBUG - 2019-12-30 11:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:45:58 --> Input Class Initialized
INFO - 2019-12-30 11:45:58 --> Language Class Initialized
INFO - 2019-12-30 11:45:58 --> Loader Class Initialized
INFO - 2019-12-30 11:45:58 --> Helper loaded: url_helper
INFO - 2019-12-30 11:45:58 --> Database Driver Class Initialized
DEBUG - 2019-12-30 11:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 11:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 11:45:58 --> Controller Class Initialized
INFO - 2019-12-30 11:45:58 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 11:45:58 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-30 11:45:59 --> Final output sent to browser
DEBUG - 2019-12-30 11:45:59 --> Total execution time: 0.5027
INFO - 2019-12-30 11:45:59 --> Config Class Initialized
INFO - 2019-12-30 11:45:59 --> Config Class Initialized
INFO - 2019-12-30 11:45:59 --> Hooks Class Initialized
INFO - 2019-12-30 11:45:59 --> Hooks Class Initialized
DEBUG - 2019-12-30 11:45:59 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 11:45:59 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:45:59 --> Utf8 Class Initialized
INFO - 2019-12-30 11:45:59 --> Utf8 Class Initialized
INFO - 2019-12-30 11:45:59 --> URI Class Initialized
INFO - 2019-12-30 11:45:59 --> URI Class Initialized
INFO - 2019-12-30 11:45:59 --> Router Class Initialized
INFO - 2019-12-30 11:45:59 --> Router Class Initialized
INFO - 2019-12-30 11:45:59 --> Output Class Initialized
INFO - 2019-12-30 11:45:59 --> Output Class Initialized
INFO - 2019-12-30 11:45:59 --> Security Class Initialized
INFO - 2019-12-30 11:45:59 --> Security Class Initialized
DEBUG - 2019-12-30 11:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 11:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:45:59 --> Input Class Initialized
INFO - 2019-12-30 11:45:59 --> Input Class Initialized
INFO - 2019-12-30 11:45:59 --> Language Class Initialized
INFO - 2019-12-30 11:45:59 --> Language Class Initialized
ERROR - 2019-12-30 11:45:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-30 11:45:59 --> 404 Page Not Found: Assets/js
INFO - 2019-12-30 11:46:02 --> Config Class Initialized
INFO - 2019-12-30 11:46:02 --> Hooks Class Initialized
DEBUG - 2019-12-30 11:46:02 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:02 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:02 --> URI Class Initialized
INFO - 2019-12-30 11:46:02 --> Router Class Initialized
INFO - 2019-12-30 11:46:02 --> Output Class Initialized
INFO - 2019-12-30 11:46:02 --> Security Class Initialized
DEBUG - 2019-12-30 11:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:02 --> Input Class Initialized
INFO - 2019-12-30 11:46:02 --> Language Class Initialized
INFO - 2019-12-30 11:46:02 --> Loader Class Initialized
INFO - 2019-12-30 11:46:02 --> Helper loaded: url_helper
INFO - 2019-12-30 11:46:02 --> Database Driver Class Initialized
DEBUG - 2019-12-30 11:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 11:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 11:46:02 --> Controller Class Initialized
INFO - 2019-12-30 11:46:02 --> Model "M_login" initialized
INFO - 2019-12-30 11:46:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-30 11:46:02 --> Pagination Class Initialized
INFO - 2019-12-30 11:46:02 --> Model "M_show" initialized
INFO - 2019-12-30 11:46:03 --> Helper loaded: form_helper
INFO - 2019-12-30 11:46:03 --> Form Validation Class Initialized
INFO - 2019-12-30 11:46:03 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 11:46:03 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2019-12-30 11:46:03 --> Final output sent to browser
DEBUG - 2019-12-30 11:46:03 --> Total execution time: 0.9746
INFO - 2019-12-30 11:46:03 --> Config Class Initialized
INFO - 2019-12-30 11:46:03 --> Config Class Initialized
INFO - 2019-12-30 11:46:03 --> Hooks Class Initialized
INFO - 2019-12-30 11:46:03 --> Hooks Class Initialized
DEBUG - 2019-12-30 11:46:03 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 11:46:03 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:03 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:03 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:03 --> URI Class Initialized
INFO - 2019-12-30 11:46:03 --> URI Class Initialized
INFO - 2019-12-30 11:46:03 --> Router Class Initialized
INFO - 2019-12-30 11:46:03 --> Router Class Initialized
INFO - 2019-12-30 11:46:03 --> Output Class Initialized
INFO - 2019-12-30 11:46:03 --> Output Class Initialized
INFO - 2019-12-30 11:46:03 --> Security Class Initialized
INFO - 2019-12-30 11:46:03 --> Security Class Initialized
DEBUG - 2019-12-30 11:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 11:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:03 --> Input Class Initialized
INFO - 2019-12-30 11:46:03 --> Input Class Initialized
INFO - 2019-12-30 11:46:03 --> Language Class Initialized
INFO - 2019-12-30 11:46:03 --> Language Class Initialized
ERROR - 2019-12-30 11:46:03 --> 404 Page Not Found: Show/assets
ERROR - 2019-12-30 11:46:03 --> 404 Page Not Found: Show/assets
INFO - 2019-12-30 11:46:03 --> Config Class Initialized
INFO - 2019-12-30 11:46:03 --> Hooks Class Initialized
DEBUG - 2019-12-30 11:46:03 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:03 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:03 --> URI Class Initialized
INFO - 2019-12-30 11:46:03 --> Router Class Initialized
INFO - 2019-12-30 11:46:03 --> Output Class Initialized
INFO - 2019-12-30 11:46:03 --> Security Class Initialized
DEBUG - 2019-12-30 11:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:03 --> Input Class Initialized
INFO - 2019-12-30 11:46:03 --> Language Class Initialized
ERROR - 2019-12-30 11:46:03 --> 404 Page Not Found: Show/assets
INFO - 2019-12-30 11:46:10 --> Config Class Initialized
INFO - 2019-12-30 11:46:10 --> Hooks Class Initialized
DEBUG - 2019-12-30 11:46:10 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:10 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:10 --> URI Class Initialized
INFO - 2019-12-30 11:46:10 --> Router Class Initialized
INFO - 2019-12-30 11:46:10 --> Output Class Initialized
INFO - 2019-12-30 11:46:11 --> Security Class Initialized
DEBUG - 2019-12-30 11:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:11 --> Input Class Initialized
INFO - 2019-12-30 11:46:11 --> Language Class Initialized
INFO - 2019-12-30 11:46:11 --> Loader Class Initialized
INFO - 2019-12-30 11:46:11 --> Helper loaded: url_helper
INFO - 2019-12-30 11:46:11 --> Database Driver Class Initialized
DEBUG - 2019-12-30 11:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 11:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 11:46:11 --> Controller Class Initialized
INFO - 2019-12-30 11:46:11 --> Model "M_login" initialized
INFO - 2019-12-30 11:46:11 --> Model "M_tiket" initialized
INFO - 2019-12-30 11:46:11 --> Helper loaded: form_helper
INFO - 2019-12-30 11:46:11 --> Form Validation Class Initialized
INFO - 2019-12-30 11:46:12 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 11:46:12 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-30 11:46:12 --> Final output sent to browser
DEBUG - 2019-12-30 11:46:12 --> Total execution time: 1.2270
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
DEBUG - 2019-12-30 11:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
INFO - 2019-12-30 11:46:12 --> Input Class Initialized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
DEBUG - 2019-12-30 11:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
INFO - 2019-12-30 11:46:12 --> Input Class Initialized
INFO - 2019-12-30 11:46:12 --> Language Class Initialized
DEBUG - 2019-12-30 11:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 11:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
DEBUG - 2019-12-30 11:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:12 --> Input Class Initialized
INFO - 2019-12-30 11:46:12 --> Input Class Initialized
INFO - 2019-12-30 11:46:12 --> Language Class Initialized
INFO - 2019-12-30 11:46:12 --> Input Class Initialized
ERROR - 2019-12-30 11:46:12 --> 404 Page Not Found: Bower_components/jquery
DEBUG - 2019-12-30 11:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:12 --> Input Class Initialized
INFO - 2019-12-30 11:46:12 --> Language Class Initialized
INFO - 2019-12-30 11:46:12 --> Language Class Initialized
ERROR - 2019-12-30 11:46:12 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2019-12-30 11:46:12 --> Language Class Initialized
INFO - 2019-12-30 11:46:12 --> Language Class Initialized
ERROR - 2019-12-30 11:46:12 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2019-12-30 11:46:12 --> 404 Page Not Found: Bower_components/tether
ERROR - 2019-12-30 11:46:12 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
ERROR - 2019-12-30 11:46:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
DEBUG - 2019-12-30 11:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
DEBUG - 2019-12-30 11:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 11:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-30 11:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
INFO - 2019-12-30 11:46:12 --> Input Class Initialized
DEBUG - 2019-12-30 11:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:12 --> Input Class Initialized
INFO - 2019-12-30 11:46:12 --> Input Class Initialized
INFO - 2019-12-30 11:46:12 --> Input Class Initialized
INFO - 2019-12-30 11:46:12 --> Language Class Initialized
DEBUG - 2019-12-30 11:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:12 --> Input Class Initialized
INFO - 2019-12-30 11:46:12 --> Language Class Initialized
INFO - 2019-12-30 11:46:12 --> Language Class Initialized
INFO - 2019-12-30 11:46:12 --> Language Class Initialized
INFO - 2019-12-30 11:46:12 --> Input Class Initialized
ERROR - 2019-12-30 11:46:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-30 11:46:12 --> Language Class Initialized
INFO - 2019-12-30 11:46:12 --> Language Class Initialized
ERROR - 2019-12-30 11:46:12 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2019-12-30 11:46:12 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2019-12-30 11:46:12 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2019-12-30 11:46:12 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
INFO - 2019-12-30 11:46:12 --> Loader Class Initialized
INFO - 2019-12-30 11:46:12 --> Helper loaded: url_helper
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:12 --> Config Class Initialized
INFO - 2019-12-30 11:46:12 --> Database Driver Class Initialized
INFO - 2019-12-30 11:46:12 --> Hooks Class Initialized
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
DEBUG - 2019-12-30 11:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 11:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
DEBUG - 2019-12-30 11:46:12 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:12 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:12 --> Controller Class Initialized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
INFO - 2019-12-30 11:46:12 --> Model "M_login" initialized
INFO - 2019-12-30 11:46:12 --> URI Class Initialized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
INFO - 2019-12-30 11:46:12 --> Model "M_tiket" initialized
DEBUG - 2019-12-30 11:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:12 --> Router Class Initialized
INFO - 2019-12-30 11:46:12 --> Input Class Initialized
INFO - 2019-12-30 11:46:12 --> Output Class Initialized
INFO - 2019-12-30 11:46:12 --> Helper loaded: form_helper
INFO - 2019-12-30 11:46:12 --> Form Validation Class Initialized
INFO - 2019-12-30 11:46:12 --> Language Class Initialized
INFO - 2019-12-30 11:46:12 --> Security Class Initialized
DEBUG - 2019-12-30 11:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:13 --> Loader Class Initialized
INFO - 2019-12-30 11:46:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 11:46:13 --> Input Class Initialized
ERROR - 2019-12-30 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2019-12-30 11:46:13 --> Helper loaded: url_helper
INFO - 2019-12-30 11:46:13 --> Language Class Initialized
INFO - 2019-12-30 11:46:13 --> Database Driver Class Initialized
ERROR - 2019-12-30 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2019-12-30 11:46:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
ERROR - 2019-12-30 11:46:13 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2019-12-30 11:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-30 11:46:13 --> Final output sent to browser
INFO - 2019-12-30 11:46:13 --> Config Class Initialized
INFO - 2019-12-30 11:46:13 --> Hooks Class Initialized
DEBUG - 2019-12-30 11:46:13 --> Total execution time: 0.5554
INFO - 2019-12-30 11:46:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-12-30 11:46:13 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:13 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:13 --> Controller Class Initialized
INFO - 2019-12-30 11:46:13 --> Model "M_login" initialized
INFO - 2019-12-30 11:46:13 --> URI Class Initialized
INFO - 2019-12-30 11:46:13 --> Model "M_tiket" initialized
INFO - 2019-12-30 11:46:13 --> Router Class Initialized
INFO - 2019-12-30 11:46:13 --> Output Class Initialized
INFO - 2019-12-30 11:46:13 --> Helper loaded: form_helper
INFO - 2019-12-30 11:46:13 --> Form Validation Class Initialized
INFO - 2019-12-30 11:46:13 --> Security Class Initialized
DEBUG - 2019-12-30 11:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-30 11:46:13 --> Input Class Initialized
ERROR - 2019-12-30 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2019-12-30 11:46:13 --> Language Class Initialized
ERROR - 2019-12-30 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2019-12-30 11:46:13 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
ERROR - 2019-12-30 11:46:13 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-30 11:46:13 --> Final output sent to browser
INFO - 2019-12-30 11:46:13 --> Config Class Initialized
INFO - 2019-12-30 11:46:13 --> Hooks Class Initialized
DEBUG - 2019-12-30 11:46:13 --> Total execution time: 0.5740
DEBUG - 2019-12-30 11:46:13 --> UTF-8 Support Enabled
INFO - 2019-12-30 11:46:13 --> Utf8 Class Initialized
INFO - 2019-12-30 11:46:13 --> URI Class Initialized
INFO - 2019-12-30 11:46:13 --> Router Class Initialized
INFO - 2019-12-30 11:46:13 --> Output Class Initialized
INFO - 2019-12-30 11:46:13 --> Security Class Initialized
DEBUG - 2019-12-30 11:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-30 11:46:13 --> Input Class Initialized
INFO - 2019-12-30 11:46:13 --> Language Class Initialized
ERROR - 2019-12-30 11:46:13 --> 404 Page Not Found: Bower_components/jquery-i18next
