<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-06 00:33:50 --> Config Class Initialized
INFO - 2020-03-06 00:33:50 --> Hooks Class Initialized
DEBUG - 2020-03-06 00:33:50 --> UTF-8 Support Enabled
INFO - 2020-03-06 00:33:50 --> Utf8 Class Initialized
INFO - 2020-03-06 00:33:50 --> URI Class Initialized
DEBUG - 2020-03-06 00:33:50 --> No URI present. Default controller set.
INFO - 2020-03-06 00:33:50 --> Router Class Initialized
INFO - 2020-03-06 00:33:50 --> Output Class Initialized
INFO - 2020-03-06 00:33:50 --> Security Class Initialized
DEBUG - 2020-03-06 00:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 00:33:50 --> Input Class Initialized
INFO - 2020-03-06 00:33:50 --> Language Class Initialized
INFO - 2020-03-06 00:33:50 --> Loader Class Initialized
INFO - 2020-03-06 00:33:50 --> Helper loaded: url_helper
INFO - 2020-03-06 00:33:50 --> Helper loaded: string_helper
INFO - 2020-03-06 00:33:50 --> Database Driver Class Initialized
DEBUG - 2020-03-06 00:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 00:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 00:33:50 --> Controller Class Initialized
INFO - 2020-03-06 00:33:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 00:33:50 --> Pagination Class Initialized
INFO - 2020-03-06 00:33:50 --> Model "M_show" initialized
INFO - 2020-03-06 00:33:50 --> Helper loaded: form_helper
INFO - 2020-03-06 00:33:50 --> Form Validation Class Initialized
INFO - 2020-03-06 00:33:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 00:33:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 00:33:50 --> Final output sent to browser
DEBUG - 2020-03-06 00:33:50 --> Total execution time: 0.0659
INFO - 2020-03-06 00:34:08 --> Config Class Initialized
INFO - 2020-03-06 00:34:08 --> Hooks Class Initialized
DEBUG - 2020-03-06 00:34:08 --> UTF-8 Support Enabled
INFO - 2020-03-06 00:34:08 --> Utf8 Class Initialized
INFO - 2020-03-06 00:34:08 --> URI Class Initialized
DEBUG - 2020-03-06 00:34:08 --> No URI present. Default controller set.
INFO - 2020-03-06 00:34:08 --> Router Class Initialized
INFO - 2020-03-06 00:34:08 --> Output Class Initialized
INFO - 2020-03-06 00:34:08 --> Security Class Initialized
DEBUG - 2020-03-06 00:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 00:34:08 --> Input Class Initialized
INFO - 2020-03-06 00:34:08 --> Language Class Initialized
INFO - 2020-03-06 00:34:08 --> Loader Class Initialized
INFO - 2020-03-06 00:34:08 --> Helper loaded: url_helper
INFO - 2020-03-06 00:34:08 --> Helper loaded: string_helper
INFO - 2020-03-06 00:34:08 --> Database Driver Class Initialized
DEBUG - 2020-03-06 00:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 00:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 00:34:08 --> Controller Class Initialized
INFO - 2020-03-06 00:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 00:34:08 --> Pagination Class Initialized
INFO - 2020-03-06 00:34:08 --> Model "M_show" initialized
INFO - 2020-03-06 00:34:08 --> Helper loaded: form_helper
INFO - 2020-03-06 00:34:08 --> Form Validation Class Initialized
INFO - 2020-03-06 00:34:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 00:34:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 00:34:08 --> Final output sent to browser
DEBUG - 2020-03-06 00:34:08 --> Total execution time: 0.0358
INFO - 2020-03-06 00:35:11 --> Config Class Initialized
INFO - 2020-03-06 00:35:11 --> Hooks Class Initialized
DEBUG - 2020-03-06 00:35:11 --> UTF-8 Support Enabled
INFO - 2020-03-06 00:35:11 --> Utf8 Class Initialized
INFO - 2020-03-06 00:35:11 --> URI Class Initialized
DEBUG - 2020-03-06 00:35:11 --> No URI present. Default controller set.
INFO - 2020-03-06 00:35:11 --> Router Class Initialized
INFO - 2020-03-06 00:35:11 --> Output Class Initialized
INFO - 2020-03-06 00:35:11 --> Security Class Initialized
DEBUG - 2020-03-06 00:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 00:35:11 --> Input Class Initialized
INFO - 2020-03-06 00:35:11 --> Language Class Initialized
INFO - 2020-03-06 00:35:11 --> Loader Class Initialized
INFO - 2020-03-06 00:35:11 --> Helper loaded: url_helper
INFO - 2020-03-06 00:35:11 --> Helper loaded: string_helper
INFO - 2020-03-06 00:35:11 --> Database Driver Class Initialized
DEBUG - 2020-03-06 00:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 00:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 00:35:11 --> Controller Class Initialized
INFO - 2020-03-06 00:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 00:35:11 --> Pagination Class Initialized
INFO - 2020-03-06 00:35:11 --> Model "M_show" initialized
INFO - 2020-03-06 00:35:11 --> Helper loaded: form_helper
INFO - 2020-03-06 00:35:11 --> Form Validation Class Initialized
INFO - 2020-03-06 00:35:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 00:35:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 00:35:11 --> Final output sent to browser
DEBUG - 2020-03-06 00:35:11 --> Total execution time: 0.0054
INFO - 2020-03-06 00:35:14 --> Config Class Initialized
INFO - 2020-03-06 00:35:14 --> Hooks Class Initialized
DEBUG - 2020-03-06 00:35:14 --> UTF-8 Support Enabled
INFO - 2020-03-06 00:35:14 --> Utf8 Class Initialized
INFO - 2020-03-06 00:35:14 --> URI Class Initialized
DEBUG - 2020-03-06 00:35:14 --> No URI present. Default controller set.
INFO - 2020-03-06 00:35:14 --> Router Class Initialized
INFO - 2020-03-06 00:35:14 --> Output Class Initialized
INFO - 2020-03-06 00:35:14 --> Security Class Initialized
DEBUG - 2020-03-06 00:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 00:35:14 --> Input Class Initialized
INFO - 2020-03-06 00:35:14 --> Language Class Initialized
INFO - 2020-03-06 00:35:14 --> Loader Class Initialized
INFO - 2020-03-06 00:35:14 --> Helper loaded: url_helper
INFO - 2020-03-06 00:35:14 --> Helper loaded: string_helper
INFO - 2020-03-06 00:35:14 --> Database Driver Class Initialized
DEBUG - 2020-03-06 00:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 00:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 00:35:14 --> Controller Class Initialized
INFO - 2020-03-06 00:35:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 00:35:14 --> Pagination Class Initialized
INFO - 2020-03-06 00:35:14 --> Model "M_show" initialized
INFO - 2020-03-06 00:35:14 --> Helper loaded: form_helper
INFO - 2020-03-06 00:35:14 --> Form Validation Class Initialized
INFO - 2020-03-06 00:35:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 00:35:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 00:35:14 --> Final output sent to browser
DEBUG - 2020-03-06 00:35:14 --> Total execution time: 0.0049
INFO - 2020-03-06 01:28:37 --> Config Class Initialized
INFO - 2020-03-06 01:28:37 --> Hooks Class Initialized
DEBUG - 2020-03-06 01:28:37 --> UTF-8 Support Enabled
INFO - 2020-03-06 01:28:37 --> Utf8 Class Initialized
INFO - 2020-03-06 01:28:37 --> URI Class Initialized
DEBUG - 2020-03-06 01:28:37 --> No URI present. Default controller set.
INFO - 2020-03-06 01:28:37 --> Router Class Initialized
INFO - 2020-03-06 01:28:37 --> Output Class Initialized
INFO - 2020-03-06 01:28:37 --> Security Class Initialized
DEBUG - 2020-03-06 01:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 01:28:37 --> Input Class Initialized
INFO - 2020-03-06 01:28:37 --> Language Class Initialized
INFO - 2020-03-06 01:28:37 --> Loader Class Initialized
INFO - 2020-03-06 01:28:37 --> Helper loaded: url_helper
INFO - 2020-03-06 01:28:37 --> Helper loaded: string_helper
INFO - 2020-03-06 01:28:37 --> Database Driver Class Initialized
DEBUG - 2020-03-06 01:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 01:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 01:28:37 --> Controller Class Initialized
INFO - 2020-03-06 01:28:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 01:28:37 --> Pagination Class Initialized
INFO - 2020-03-06 01:28:37 --> Model "M_show" initialized
INFO - 2020-03-06 01:28:37 --> Helper loaded: form_helper
INFO - 2020-03-06 01:28:37 --> Form Validation Class Initialized
INFO - 2020-03-06 01:28:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 01:28:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 01:28:37 --> Final output sent to browser
DEBUG - 2020-03-06 01:28:37 --> Total execution time: 0.0711
INFO - 2020-03-06 01:28:39 --> Config Class Initialized
INFO - 2020-03-06 01:28:39 --> Hooks Class Initialized
DEBUG - 2020-03-06 01:28:39 --> UTF-8 Support Enabled
INFO - 2020-03-06 01:28:39 --> Utf8 Class Initialized
INFO - 2020-03-06 01:28:39 --> URI Class Initialized
DEBUG - 2020-03-06 01:28:39 --> No URI present. Default controller set.
INFO - 2020-03-06 01:28:39 --> Router Class Initialized
INFO - 2020-03-06 01:28:39 --> Output Class Initialized
INFO - 2020-03-06 01:28:39 --> Security Class Initialized
DEBUG - 2020-03-06 01:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 01:28:39 --> Input Class Initialized
INFO - 2020-03-06 01:28:39 --> Language Class Initialized
INFO - 2020-03-06 01:28:39 --> Loader Class Initialized
INFO - 2020-03-06 01:28:39 --> Helper loaded: url_helper
INFO - 2020-03-06 01:28:39 --> Helper loaded: string_helper
INFO - 2020-03-06 01:28:39 --> Database Driver Class Initialized
DEBUG - 2020-03-06 01:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 01:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 01:28:39 --> Controller Class Initialized
INFO - 2020-03-06 01:28:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 01:28:39 --> Pagination Class Initialized
INFO - 2020-03-06 01:28:39 --> Model "M_show" initialized
INFO - 2020-03-06 01:28:39 --> Helper loaded: form_helper
INFO - 2020-03-06 01:28:39 --> Form Validation Class Initialized
INFO - 2020-03-06 01:28:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 01:28:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 01:28:39 --> Final output sent to browser
DEBUG - 2020-03-06 01:28:39 --> Total execution time: 0.0055
INFO - 2020-03-06 01:35:30 --> Config Class Initialized
INFO - 2020-03-06 01:35:30 --> Hooks Class Initialized
DEBUG - 2020-03-06 01:35:30 --> UTF-8 Support Enabled
INFO - 2020-03-06 01:35:30 --> Utf8 Class Initialized
INFO - 2020-03-06 01:35:30 --> URI Class Initialized
INFO - 2020-03-06 01:35:30 --> Router Class Initialized
INFO - 2020-03-06 01:35:30 --> Output Class Initialized
INFO - 2020-03-06 01:35:30 --> Security Class Initialized
DEBUG - 2020-03-06 01:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 01:35:30 --> Input Class Initialized
INFO - 2020-03-06 01:35:30 --> Language Class Initialized
INFO - 2020-03-06 01:35:30 --> Loader Class Initialized
INFO - 2020-03-06 01:35:30 --> Helper loaded: url_helper
INFO - 2020-03-06 01:35:30 --> Helper loaded: string_helper
INFO - 2020-03-06 01:35:30 --> Database Driver Class Initialized
DEBUG - 2020-03-06 01:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 01:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 01:35:30 --> Controller Class Initialized
INFO - 2020-03-06 01:35:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 01:35:30 --> Pagination Class Initialized
INFO - 2020-03-06 01:35:30 --> Model "M_show" initialized
INFO - 2020-03-06 01:35:30 --> Helper loaded: form_helper
INFO - 2020-03-06 01:35:30 --> Form Validation Class Initialized
INFO - 2020-03-06 01:35:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 01:35:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 01:35:30 --> Final output sent to browser
DEBUG - 2020-03-06 01:35:30 --> Total execution time: 0.3017
INFO - 2020-03-06 03:39:08 --> Config Class Initialized
INFO - 2020-03-06 03:39:08 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:39:08 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:39:08 --> Utf8 Class Initialized
INFO - 2020-03-06 03:39:08 --> URI Class Initialized
DEBUG - 2020-03-06 03:39:08 --> No URI present. Default controller set.
INFO - 2020-03-06 03:39:08 --> Router Class Initialized
INFO - 2020-03-06 03:39:08 --> Output Class Initialized
INFO - 2020-03-06 03:39:08 --> Security Class Initialized
DEBUG - 2020-03-06 03:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:39:08 --> Input Class Initialized
INFO - 2020-03-06 03:39:08 --> Language Class Initialized
INFO - 2020-03-06 03:39:08 --> Loader Class Initialized
INFO - 2020-03-06 03:39:08 --> Helper loaded: url_helper
INFO - 2020-03-06 03:39:08 --> Helper loaded: string_helper
INFO - 2020-03-06 03:39:08 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:39:08 --> Controller Class Initialized
INFO - 2020-03-06 03:39:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 03:39:08 --> Pagination Class Initialized
INFO - 2020-03-06 03:39:08 --> Model "M_show" initialized
INFO - 2020-03-06 03:39:08 --> Helper loaded: form_helper
INFO - 2020-03-06 03:39:08 --> Form Validation Class Initialized
INFO - 2020-03-06 03:39:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 03:39:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 03:39:08 --> Final output sent to browser
DEBUG - 2020-03-06 03:39:08 --> Total execution time: 0.2976
INFO - 2020-03-06 03:41:20 --> Config Class Initialized
INFO - 2020-03-06 03:41:20 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:41:20 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:41:20 --> Utf8 Class Initialized
INFO - 2020-03-06 03:41:20 --> URI Class Initialized
DEBUG - 2020-03-06 03:41:20 --> No URI present. Default controller set.
INFO - 2020-03-06 03:41:20 --> Router Class Initialized
INFO - 2020-03-06 03:41:20 --> Output Class Initialized
INFO - 2020-03-06 03:41:20 --> Security Class Initialized
DEBUG - 2020-03-06 03:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:41:20 --> Input Class Initialized
INFO - 2020-03-06 03:41:20 --> Language Class Initialized
INFO - 2020-03-06 03:41:20 --> Loader Class Initialized
INFO - 2020-03-06 03:41:20 --> Helper loaded: url_helper
INFO - 2020-03-06 03:41:20 --> Helper loaded: string_helper
INFO - 2020-03-06 03:41:20 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:41:20 --> Controller Class Initialized
INFO - 2020-03-06 03:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 03:41:20 --> Pagination Class Initialized
INFO - 2020-03-06 03:41:20 --> Model "M_show" initialized
INFO - 2020-03-06 03:41:20 --> Helper loaded: form_helper
INFO - 2020-03-06 03:41:20 --> Form Validation Class Initialized
INFO - 2020-03-06 03:41:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 03:41:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 03:41:20 --> Final output sent to browser
DEBUG - 2020-03-06 03:41:20 --> Total execution time: 0.0367
INFO - 2020-03-06 03:41:29 --> Config Class Initialized
INFO - 2020-03-06 03:41:29 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:41:29 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:41:29 --> Utf8 Class Initialized
INFO - 2020-03-06 03:41:29 --> URI Class Initialized
INFO - 2020-03-06 03:41:29 --> Router Class Initialized
INFO - 2020-03-06 03:41:29 --> Output Class Initialized
INFO - 2020-03-06 03:41:29 --> Security Class Initialized
DEBUG - 2020-03-06 03:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:41:29 --> Input Class Initialized
INFO - 2020-03-06 03:41:29 --> Language Class Initialized
INFO - 2020-03-06 03:41:29 --> Loader Class Initialized
INFO - 2020-03-06 03:41:29 --> Helper loaded: url_helper
INFO - 2020-03-06 03:41:29 --> Helper loaded: string_helper
INFO - 2020-03-06 03:41:29 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:41:29 --> Controller Class Initialized
INFO - 2020-03-06 03:41:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 03:41:29 --> Pagination Class Initialized
INFO - 2020-03-06 03:41:29 --> Model "M_show" initialized
INFO - 2020-03-06 03:41:29 --> Helper loaded: form_helper
INFO - 2020-03-06 03:41:29 --> Form Validation Class Initialized
INFO - 2020-03-06 03:41:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 03:41:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 03:41:29 --> Final output sent to browser
DEBUG - 2020-03-06 03:41:29 --> Total execution time: 0.0629
INFO - 2020-03-06 03:41:29 --> Config Class Initialized
INFO - 2020-03-06 03:41:29 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:41:29 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:41:29 --> Utf8 Class Initialized
INFO - 2020-03-06 03:41:29 --> URI Class Initialized
INFO - 2020-03-06 03:41:29 --> Router Class Initialized
INFO - 2020-03-06 03:41:29 --> Output Class Initialized
INFO - 2020-03-06 03:41:29 --> Security Class Initialized
DEBUG - 2020-03-06 03:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:41:29 --> Input Class Initialized
INFO - 2020-03-06 03:41:29 --> Language Class Initialized
ERROR - 2020-03-06 03:41:29 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-06 03:41:35 --> Config Class Initialized
INFO - 2020-03-06 03:41:35 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:41:35 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:41:35 --> Utf8 Class Initialized
INFO - 2020-03-06 03:41:35 --> URI Class Initialized
INFO - 2020-03-06 03:41:35 --> Router Class Initialized
INFO - 2020-03-06 03:41:35 --> Output Class Initialized
INFO - 2020-03-06 03:41:35 --> Security Class Initialized
DEBUG - 2020-03-06 03:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:41:35 --> Input Class Initialized
INFO - 2020-03-06 03:41:35 --> Language Class Initialized
INFO - 2020-03-06 03:41:35 --> Loader Class Initialized
INFO - 2020-03-06 03:41:35 --> Helper loaded: url_helper
INFO - 2020-03-06 03:41:35 --> Helper loaded: string_helper
INFO - 2020-03-06 03:41:35 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:41:35 --> Controller Class Initialized
INFO - 2020-03-06 03:41:35 --> Model "M_tiket" initialized
INFO - 2020-03-06 03:41:35 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 03:41:35 --> Model "M_pesan" initialized
INFO - 2020-03-06 03:41:35 --> Helper loaded: form_helper
INFO - 2020-03-06 03:41:35 --> Form Validation Class Initialized
INFO - 2020-03-06 03:41:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 03:41:35 --> Final output sent to browser
DEBUG - 2020-03-06 03:41:35 --> Total execution time: 0.5033
INFO - 2020-03-06 03:41:59 --> Config Class Initialized
INFO - 2020-03-06 03:41:59 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:41:59 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:41:59 --> Utf8 Class Initialized
INFO - 2020-03-06 03:41:59 --> URI Class Initialized
INFO - 2020-03-06 03:41:59 --> Router Class Initialized
INFO - 2020-03-06 03:41:59 --> Output Class Initialized
INFO - 2020-03-06 03:41:59 --> Security Class Initialized
DEBUG - 2020-03-06 03:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:41:59 --> Input Class Initialized
INFO - 2020-03-06 03:41:59 --> Language Class Initialized
INFO - 2020-03-06 03:41:59 --> Loader Class Initialized
INFO - 2020-03-06 03:41:59 --> Helper loaded: url_helper
INFO - 2020-03-06 03:41:59 --> Helper loaded: string_helper
INFO - 2020-03-06 03:41:59 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:41:59 --> Controller Class Initialized
INFO - 2020-03-06 03:41:59 --> Model "M_tiket" initialized
INFO - 2020-03-06 03:41:59 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 03:41:59 --> Model "M_pesan" initialized
INFO - 2020-03-06 03:41:59 --> Helper loaded: form_helper
INFO - 2020-03-06 03:41:59 --> Form Validation Class Initialized
INFO - 2020-03-06 03:41:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 03:41:59 --> Final output sent to browser
DEBUG - 2020-03-06 03:41:59 --> Total execution time: 0.0201
INFO - 2020-03-06 03:44:13 --> Config Class Initialized
INFO - 2020-03-06 03:44:13 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:44:13 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:44:13 --> Utf8 Class Initialized
INFO - 2020-03-06 03:44:13 --> URI Class Initialized
INFO - 2020-03-06 03:44:13 --> Router Class Initialized
INFO - 2020-03-06 03:44:13 --> Output Class Initialized
INFO - 2020-03-06 03:44:13 --> Security Class Initialized
DEBUG - 2020-03-06 03:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:44:13 --> Input Class Initialized
INFO - 2020-03-06 03:44:13 --> Language Class Initialized
INFO - 2020-03-06 03:44:13 --> Loader Class Initialized
INFO - 2020-03-06 03:44:13 --> Helper loaded: url_helper
INFO - 2020-03-06 03:44:13 --> Helper loaded: string_helper
INFO - 2020-03-06 03:44:13 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:44:13 --> Controller Class Initialized
INFO - 2020-03-06 03:44:13 --> Model "M_tiket" initialized
INFO - 2020-03-06 03:44:13 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 03:44:13 --> Model "M_pesan" initialized
INFO - 2020-03-06 03:44:13 --> Helper loaded: form_helper
INFO - 2020-03-06 03:44:13 --> Form Validation Class Initialized
DEBUG - 2020-03-06 03:44:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-06 03:44:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-06 10:44:13 --> Final output sent to browser
DEBUG - 2020-03-06 10:44:13 --> Total execution time: 0.3378
INFO - 2020-03-06 03:44:19 --> Config Class Initialized
INFO - 2020-03-06 03:44:19 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:44:19 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:44:19 --> Utf8 Class Initialized
INFO - 2020-03-06 03:44:19 --> URI Class Initialized
INFO - 2020-03-06 03:44:19 --> Router Class Initialized
INFO - 2020-03-06 03:44:19 --> Output Class Initialized
INFO - 2020-03-06 03:44:19 --> Security Class Initialized
DEBUG - 2020-03-06 03:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:44:19 --> Input Class Initialized
INFO - 2020-03-06 03:44:19 --> Language Class Initialized
INFO - 2020-03-06 03:44:19 --> Loader Class Initialized
INFO - 2020-03-06 03:44:19 --> Helper loaded: url_helper
INFO - 2020-03-06 03:44:19 --> Helper loaded: string_helper
INFO - 2020-03-06 03:44:19 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:44:19 --> Controller Class Initialized
INFO - 2020-03-06 03:44:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 03:44:19 --> Pagination Class Initialized
INFO - 2020-03-06 03:44:19 --> Model "M_show" initialized
INFO - 2020-03-06 03:44:19 --> Helper loaded: form_helper
INFO - 2020-03-06 03:44:19 --> Form Validation Class Initialized
INFO - 2020-03-06 03:44:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 03:44:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 03:44:19 --> Final output sent to browser
DEBUG - 2020-03-06 03:44:19 --> Total execution time: 0.0084
INFO - 2020-03-06 03:44:19 --> Config Class Initialized
INFO - 2020-03-06 03:44:19 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:44:19 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:44:19 --> Utf8 Class Initialized
INFO - 2020-03-06 03:44:19 --> URI Class Initialized
INFO - 2020-03-06 03:44:19 --> Router Class Initialized
INFO - 2020-03-06 03:44:19 --> Output Class Initialized
INFO - 2020-03-06 03:44:19 --> Security Class Initialized
DEBUG - 2020-03-06 03:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:44:19 --> Input Class Initialized
INFO - 2020-03-06 03:44:19 --> Language Class Initialized
ERROR - 2020-03-06 03:44:19 --> 404 Page Not Found: Engine0/jquery.js
INFO - 2020-03-06 03:44:26 --> Config Class Initialized
INFO - 2020-03-06 03:44:26 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:44:26 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:44:26 --> Utf8 Class Initialized
INFO - 2020-03-06 03:44:26 --> URI Class Initialized
DEBUG - 2020-03-06 03:44:26 --> No URI present. Default controller set.
INFO - 2020-03-06 03:44:26 --> Router Class Initialized
INFO - 2020-03-06 03:44:26 --> Output Class Initialized
INFO - 2020-03-06 03:44:26 --> Security Class Initialized
DEBUG - 2020-03-06 03:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:44:26 --> Input Class Initialized
INFO - 2020-03-06 03:44:26 --> Language Class Initialized
INFO - 2020-03-06 03:44:26 --> Loader Class Initialized
INFO - 2020-03-06 03:44:26 --> Helper loaded: url_helper
INFO - 2020-03-06 03:44:26 --> Helper loaded: string_helper
INFO - 2020-03-06 03:44:26 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:44:26 --> Controller Class Initialized
INFO - 2020-03-06 03:44:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 03:44:26 --> Pagination Class Initialized
INFO - 2020-03-06 03:44:26 --> Model "M_show" initialized
INFO - 2020-03-06 03:44:26 --> Helper loaded: form_helper
INFO - 2020-03-06 03:44:26 --> Form Validation Class Initialized
INFO - 2020-03-06 03:44:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 03:44:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 03:44:26 --> Final output sent to browser
DEBUG - 2020-03-06 03:44:26 --> Total execution time: 0.0183
INFO - 2020-03-06 03:45:33 --> Config Class Initialized
INFO - 2020-03-06 03:45:33 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:45:33 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:45:33 --> Utf8 Class Initialized
INFO - 2020-03-06 03:45:33 --> URI Class Initialized
DEBUG - 2020-03-06 03:45:33 --> No URI present. Default controller set.
INFO - 2020-03-06 03:45:33 --> Router Class Initialized
INFO - 2020-03-06 03:45:33 --> Output Class Initialized
INFO - 2020-03-06 03:45:33 --> Security Class Initialized
DEBUG - 2020-03-06 03:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:45:33 --> Input Class Initialized
INFO - 2020-03-06 03:45:33 --> Language Class Initialized
INFO - 2020-03-06 03:45:33 --> Loader Class Initialized
INFO - 2020-03-06 03:45:33 --> Helper loaded: url_helper
INFO - 2020-03-06 03:45:33 --> Helper loaded: string_helper
INFO - 2020-03-06 03:45:33 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:45:33 --> Controller Class Initialized
INFO - 2020-03-06 03:45:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 03:45:33 --> Pagination Class Initialized
INFO - 2020-03-06 03:45:33 --> Model "M_show" initialized
INFO - 2020-03-06 03:45:33 --> Helper loaded: form_helper
INFO - 2020-03-06 03:45:33 --> Form Validation Class Initialized
INFO - 2020-03-06 03:45:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 03:45:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 03:45:33 --> Final output sent to browser
DEBUG - 2020-03-06 03:45:33 --> Total execution time: 0.0794
INFO - 2020-03-06 03:45:37 --> Config Class Initialized
INFO - 2020-03-06 03:45:37 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:45:37 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:45:37 --> Utf8 Class Initialized
INFO - 2020-03-06 03:45:37 --> URI Class Initialized
INFO - 2020-03-06 03:45:37 --> Router Class Initialized
INFO - 2020-03-06 03:45:37 --> Output Class Initialized
INFO - 2020-03-06 03:45:37 --> Security Class Initialized
DEBUG - 2020-03-06 03:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:45:37 --> Input Class Initialized
INFO - 2020-03-06 03:45:37 --> Language Class Initialized
INFO - 2020-03-06 03:45:37 --> Loader Class Initialized
INFO - 2020-03-06 03:45:37 --> Helper loaded: url_helper
INFO - 2020-03-06 03:45:37 --> Helper loaded: string_helper
INFO - 2020-03-06 03:45:37 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:45:37 --> Controller Class Initialized
INFO - 2020-03-06 03:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 03:45:37 --> Pagination Class Initialized
INFO - 2020-03-06 03:45:37 --> Model "M_show" initialized
INFO - 2020-03-06 03:45:37 --> Helper loaded: form_helper
INFO - 2020-03-06 03:45:37 --> Form Validation Class Initialized
INFO - 2020-03-06 03:45:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 03:45:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 03:45:37 --> Final output sent to browser
DEBUG - 2020-03-06 03:45:37 --> Total execution time: 0.0591
INFO - 2020-03-06 03:45:39 --> Config Class Initialized
INFO - 2020-03-06 03:45:39 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:45:39 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:45:39 --> Utf8 Class Initialized
INFO - 2020-03-06 03:45:39 --> URI Class Initialized
DEBUG - 2020-03-06 03:45:39 --> No URI present. Default controller set.
INFO - 2020-03-06 03:45:39 --> Router Class Initialized
INFO - 2020-03-06 03:45:39 --> Output Class Initialized
INFO - 2020-03-06 03:45:39 --> Security Class Initialized
DEBUG - 2020-03-06 03:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:45:39 --> Input Class Initialized
INFO - 2020-03-06 03:45:39 --> Language Class Initialized
INFO - 2020-03-06 03:45:39 --> Loader Class Initialized
INFO - 2020-03-06 03:45:39 --> Helper loaded: url_helper
INFO - 2020-03-06 03:45:39 --> Helper loaded: string_helper
INFO - 2020-03-06 03:45:39 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:45:39 --> Controller Class Initialized
INFO - 2020-03-06 03:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 03:45:39 --> Pagination Class Initialized
INFO - 2020-03-06 03:45:39 --> Model "M_show" initialized
INFO - 2020-03-06 03:45:39 --> Helper loaded: form_helper
INFO - 2020-03-06 03:45:39 --> Form Validation Class Initialized
INFO - 2020-03-06 03:45:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 03:45:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 03:45:39 --> Final output sent to browser
DEBUG - 2020-03-06 03:45:39 --> Total execution time: 0.0077
INFO - 2020-03-06 03:45:41 --> Config Class Initialized
INFO - 2020-03-06 03:45:41 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:45:41 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:45:41 --> Utf8 Class Initialized
INFO - 2020-03-06 03:45:41 --> URI Class Initialized
INFO - 2020-03-06 03:45:41 --> Router Class Initialized
INFO - 2020-03-06 03:45:41 --> Output Class Initialized
INFO - 2020-03-06 03:45:41 --> Security Class Initialized
DEBUG - 2020-03-06 03:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:45:41 --> Input Class Initialized
INFO - 2020-03-06 03:45:41 --> Language Class Initialized
INFO - 2020-03-06 03:45:41 --> Loader Class Initialized
INFO - 2020-03-06 03:45:41 --> Helper loaded: url_helper
INFO - 2020-03-06 03:45:41 --> Helper loaded: string_helper
INFO - 2020-03-06 03:45:41 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:45:41 --> Controller Class Initialized
INFO - 2020-03-06 03:45:41 --> Model "M_tiket" initialized
INFO - 2020-03-06 03:45:41 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 03:45:41 --> Model "M_pesan" initialized
INFO - 2020-03-06 03:45:41 --> Helper loaded: form_helper
INFO - 2020-03-06 03:45:41 --> Form Validation Class Initialized
INFO - 2020-03-06 03:45:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 03:45:41 --> Final output sent to browser
DEBUG - 2020-03-06 03:45:41 --> Total execution time: 0.0656
INFO - 2020-03-06 03:45:45 --> Config Class Initialized
INFO - 2020-03-06 03:45:45 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:45:45 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:45:45 --> Utf8 Class Initialized
INFO - 2020-03-06 03:45:45 --> URI Class Initialized
INFO - 2020-03-06 03:45:45 --> Router Class Initialized
INFO - 2020-03-06 03:45:45 --> Output Class Initialized
INFO - 2020-03-06 03:45:45 --> Security Class Initialized
DEBUG - 2020-03-06 03:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:45:45 --> Input Class Initialized
INFO - 2020-03-06 03:45:45 --> Language Class Initialized
INFO - 2020-03-06 03:45:45 --> Loader Class Initialized
INFO - 2020-03-06 03:45:45 --> Helper loaded: url_helper
INFO - 2020-03-06 03:45:45 --> Helper loaded: string_helper
INFO - 2020-03-06 03:45:45 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:45:45 --> Controller Class Initialized
INFO - 2020-03-06 03:45:45 --> Model "M_tiket" initialized
INFO - 2020-03-06 03:45:45 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 03:45:45 --> Model "M_pesan" initialized
INFO - 2020-03-06 03:45:45 --> Helper loaded: form_helper
INFO - 2020-03-06 03:45:45 --> Form Validation Class Initialized
INFO - 2020-03-06 03:45:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 03:45:45 --> Final output sent to browser
DEBUG - 2020-03-06 03:45:45 --> Total execution time: 0.0077
INFO - 2020-03-06 03:46:16 --> Config Class Initialized
INFO - 2020-03-06 03:46:16 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:46:16 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:46:16 --> Utf8 Class Initialized
INFO - 2020-03-06 03:46:16 --> URI Class Initialized
INFO - 2020-03-06 03:46:16 --> Router Class Initialized
INFO - 2020-03-06 03:46:16 --> Output Class Initialized
INFO - 2020-03-06 03:46:16 --> Security Class Initialized
DEBUG - 2020-03-06 03:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:46:16 --> Input Class Initialized
INFO - 2020-03-06 03:46:16 --> Language Class Initialized
INFO - 2020-03-06 03:46:16 --> Loader Class Initialized
INFO - 2020-03-06 03:46:16 --> Helper loaded: url_helper
INFO - 2020-03-06 03:46:16 --> Helper loaded: string_helper
INFO - 2020-03-06 03:46:16 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:46:16 --> Controller Class Initialized
INFO - 2020-03-06 03:46:16 --> Model "M_tiket" initialized
INFO - 2020-03-06 03:46:16 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 03:46:16 --> Model "M_pesan" initialized
INFO - 2020-03-06 03:46:16 --> Helper loaded: form_helper
INFO - 2020-03-06 03:46:16 --> Form Validation Class Initialized
DEBUG - 2020-03-06 03:46:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-06 03:46:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-06 03:46:16 --> Final output sent to browser
DEBUG - 2020-03-06 03:46:16 --> Total execution time: 0.0072
INFO - 2020-03-06 03:46:23 --> Config Class Initialized
INFO - 2020-03-06 03:46:23 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:46:23 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:46:23 --> Utf8 Class Initialized
INFO - 2020-03-06 03:46:23 --> URI Class Initialized
INFO - 2020-03-06 03:46:23 --> Router Class Initialized
INFO - 2020-03-06 03:46:23 --> Output Class Initialized
INFO - 2020-03-06 03:46:23 --> Security Class Initialized
DEBUG - 2020-03-06 03:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:46:23 --> Input Class Initialized
INFO - 2020-03-06 03:46:23 --> Language Class Initialized
INFO - 2020-03-06 03:46:23 --> Loader Class Initialized
INFO - 2020-03-06 03:46:23 --> Helper loaded: url_helper
INFO - 2020-03-06 03:46:23 --> Helper loaded: string_helper
INFO - 2020-03-06 03:46:23 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:46:23 --> Controller Class Initialized
INFO - 2020-03-06 03:46:23 --> Model "M_tiket" initialized
INFO - 2020-03-06 03:46:23 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 03:46:23 --> Model "M_pesan" initialized
INFO - 2020-03-06 03:46:23 --> Helper loaded: form_helper
INFO - 2020-03-06 03:46:23 --> Form Validation Class Initialized
INFO - 2020-03-06 03:46:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 03:46:23 --> Final output sent to browser
DEBUG - 2020-03-06 03:46:23 --> Total execution time: 0.0080
INFO - 2020-03-06 03:46:31 --> Config Class Initialized
INFO - 2020-03-06 03:46:31 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:46:31 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:46:31 --> Utf8 Class Initialized
INFO - 2020-03-06 03:46:31 --> URI Class Initialized
INFO - 2020-03-06 03:46:31 --> Router Class Initialized
INFO - 2020-03-06 03:46:31 --> Output Class Initialized
INFO - 2020-03-06 03:46:31 --> Security Class Initialized
DEBUG - 2020-03-06 03:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:46:31 --> Input Class Initialized
INFO - 2020-03-06 03:46:31 --> Language Class Initialized
INFO - 2020-03-06 03:46:31 --> Loader Class Initialized
INFO - 2020-03-06 03:46:31 --> Helper loaded: url_helper
INFO - 2020-03-06 03:46:31 --> Helper loaded: string_helper
INFO - 2020-03-06 03:46:31 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:46:31 --> Controller Class Initialized
INFO - 2020-03-06 03:46:31 --> Model "M_tiket" initialized
INFO - 2020-03-06 03:46:31 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 03:46:31 --> Model "M_pesan" initialized
INFO - 2020-03-06 03:46:31 --> Helper loaded: form_helper
INFO - 2020-03-06 03:46:31 --> Form Validation Class Initialized
DEBUG - 2020-03-06 03:46:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-06 03:46:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-06 03:46:31 --> Final output sent to browser
DEBUG - 2020-03-06 03:46:31 --> Total execution time: 0.0072
INFO - 2020-03-06 03:46:36 --> Config Class Initialized
INFO - 2020-03-06 03:46:36 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:46:36 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:46:36 --> Utf8 Class Initialized
INFO - 2020-03-06 03:46:36 --> URI Class Initialized
INFO - 2020-03-06 03:46:36 --> Router Class Initialized
INFO - 2020-03-06 03:46:36 --> Output Class Initialized
INFO - 2020-03-06 03:46:36 --> Security Class Initialized
DEBUG - 2020-03-06 03:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:46:36 --> Input Class Initialized
INFO - 2020-03-06 03:46:36 --> Language Class Initialized
INFO - 2020-03-06 03:46:36 --> Loader Class Initialized
INFO - 2020-03-06 03:46:36 --> Helper loaded: url_helper
INFO - 2020-03-06 03:46:36 --> Helper loaded: string_helper
INFO - 2020-03-06 03:46:36 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:46:36 --> Controller Class Initialized
INFO - 2020-03-06 03:46:36 --> Model "M_tiket" initialized
INFO - 2020-03-06 03:46:36 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 03:46:36 --> Model "M_pesan" initialized
INFO - 2020-03-06 03:46:36 --> Helper loaded: form_helper
INFO - 2020-03-06 03:46:36 --> Form Validation Class Initialized
INFO - 2020-03-06 03:46:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 03:46:36 --> Final output sent to browser
DEBUG - 2020-03-06 03:46:36 --> Total execution time: 0.1798
INFO - 2020-03-06 03:47:04 --> Config Class Initialized
INFO - 2020-03-06 03:47:04 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:47:04 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:47:04 --> Utf8 Class Initialized
INFO - 2020-03-06 03:47:04 --> URI Class Initialized
INFO - 2020-03-06 03:47:04 --> Router Class Initialized
INFO - 2020-03-06 03:47:04 --> Output Class Initialized
INFO - 2020-03-06 03:47:04 --> Security Class Initialized
DEBUG - 2020-03-06 03:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:47:04 --> Input Class Initialized
INFO - 2020-03-06 03:47:04 --> Language Class Initialized
INFO - 2020-03-06 03:47:04 --> Loader Class Initialized
INFO - 2020-03-06 03:47:04 --> Helper loaded: url_helper
INFO - 2020-03-06 03:47:04 --> Helper loaded: string_helper
INFO - 2020-03-06 03:47:04 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:47:04 --> Controller Class Initialized
INFO - 2020-03-06 03:47:04 --> Model "M_tiket" initialized
INFO - 2020-03-06 03:47:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 03:47:04 --> Model "M_pesan" initialized
INFO - 2020-03-06 03:47:04 --> Helper loaded: form_helper
INFO - 2020-03-06 03:47:04 --> Form Validation Class Initialized
DEBUG - 2020-03-06 03:47:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-06 03:47:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-06 10:47:05 --> Final output sent to browser
DEBUG - 2020-03-06 10:47:05 --> Total execution time: 0.1628
INFO - 2020-03-06 03:47:06 --> Config Class Initialized
INFO - 2020-03-06 03:47:06 --> Hooks Class Initialized
DEBUG - 2020-03-06 03:47:06 --> UTF-8 Support Enabled
INFO - 2020-03-06 03:47:06 --> Utf8 Class Initialized
INFO - 2020-03-06 03:47:06 --> URI Class Initialized
INFO - 2020-03-06 03:47:06 --> Router Class Initialized
INFO - 2020-03-06 03:47:06 --> Output Class Initialized
INFO - 2020-03-06 03:47:06 --> Security Class Initialized
DEBUG - 2020-03-06 03:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 03:47:06 --> Input Class Initialized
INFO - 2020-03-06 03:47:06 --> Language Class Initialized
INFO - 2020-03-06 03:47:06 --> Loader Class Initialized
INFO - 2020-03-06 03:47:06 --> Helper loaded: url_helper
INFO - 2020-03-06 03:47:06 --> Helper loaded: string_helper
INFO - 2020-03-06 03:47:06 --> Database Driver Class Initialized
DEBUG - 2020-03-06 03:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 03:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 03:47:06 --> Controller Class Initialized
INFO - 2020-03-06 03:47:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 03:47:06 --> Pagination Class Initialized
INFO - 2020-03-06 03:47:06 --> Model "M_show" initialized
INFO - 2020-03-06 03:47:06 --> Helper loaded: form_helper
INFO - 2020-03-06 03:47:06 --> Form Validation Class Initialized
INFO - 2020-03-06 03:47:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 03:47:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 03:47:06 --> Final output sent to browser
DEBUG - 2020-03-06 03:47:06 --> Total execution time: 0.1277
INFO - 2020-03-06 04:22:10 --> Config Class Initialized
INFO - 2020-03-06 04:22:10 --> Hooks Class Initialized
DEBUG - 2020-03-06 04:22:10 --> UTF-8 Support Enabled
INFO - 2020-03-06 04:22:10 --> Utf8 Class Initialized
INFO - 2020-03-06 04:22:10 --> URI Class Initialized
DEBUG - 2020-03-06 04:22:10 --> No URI present. Default controller set.
INFO - 2020-03-06 04:22:10 --> Router Class Initialized
INFO - 2020-03-06 04:22:10 --> Output Class Initialized
INFO - 2020-03-06 04:22:10 --> Security Class Initialized
DEBUG - 2020-03-06 04:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 04:22:10 --> Input Class Initialized
INFO - 2020-03-06 04:22:10 --> Language Class Initialized
INFO - 2020-03-06 04:22:10 --> Loader Class Initialized
INFO - 2020-03-06 04:22:10 --> Helper loaded: url_helper
INFO - 2020-03-06 04:22:10 --> Helper loaded: string_helper
INFO - 2020-03-06 04:22:10 --> Database Driver Class Initialized
DEBUG - 2020-03-06 04:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 04:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 04:22:10 --> Controller Class Initialized
INFO - 2020-03-06 04:22:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 04:22:10 --> Pagination Class Initialized
INFO - 2020-03-06 04:22:10 --> Model "M_show" initialized
INFO - 2020-03-06 04:22:10 --> Helper loaded: form_helper
INFO - 2020-03-06 04:22:10 --> Form Validation Class Initialized
INFO - 2020-03-06 04:22:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 04:22:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 04:22:10 --> Final output sent to browser
DEBUG - 2020-03-06 04:22:10 --> Total execution time: 0.0352
INFO - 2020-03-06 04:22:19 --> Config Class Initialized
INFO - 2020-03-06 04:22:19 --> Hooks Class Initialized
DEBUG - 2020-03-06 04:22:19 --> UTF-8 Support Enabled
INFO - 2020-03-06 04:22:19 --> Utf8 Class Initialized
INFO - 2020-03-06 04:22:19 --> URI Class Initialized
INFO - 2020-03-06 04:22:19 --> Router Class Initialized
INFO - 2020-03-06 04:22:19 --> Output Class Initialized
INFO - 2020-03-06 04:22:19 --> Security Class Initialized
DEBUG - 2020-03-06 04:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 04:22:19 --> Input Class Initialized
INFO - 2020-03-06 04:22:19 --> Language Class Initialized
INFO - 2020-03-06 04:22:19 --> Loader Class Initialized
INFO - 2020-03-06 04:22:19 --> Helper loaded: url_helper
INFO - 2020-03-06 04:22:19 --> Helper loaded: string_helper
INFO - 2020-03-06 04:22:19 --> Database Driver Class Initialized
DEBUG - 2020-03-06 04:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 04:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 04:22:19 --> Controller Class Initialized
INFO - 2020-03-06 04:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 04:22:19 --> Pagination Class Initialized
INFO - 2020-03-06 04:22:19 --> Model "M_show" initialized
INFO - 2020-03-06 04:22:19 --> Helper loaded: form_helper
INFO - 2020-03-06 04:22:19 --> Form Validation Class Initialized
INFO - 2020-03-06 04:22:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 04:22:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 04:22:19 --> Final output sent to browser
DEBUG - 2020-03-06 04:22:19 --> Total execution time: 0.0083
INFO - 2020-03-06 04:22:24 --> Config Class Initialized
INFO - 2020-03-06 04:22:24 --> Hooks Class Initialized
DEBUG - 2020-03-06 04:22:24 --> UTF-8 Support Enabled
INFO - 2020-03-06 04:22:24 --> Utf8 Class Initialized
INFO - 2020-03-06 04:22:24 --> URI Class Initialized
INFO - 2020-03-06 04:22:24 --> Router Class Initialized
INFO - 2020-03-06 04:22:24 --> Output Class Initialized
INFO - 2020-03-06 04:22:24 --> Security Class Initialized
DEBUG - 2020-03-06 04:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 04:22:24 --> Input Class Initialized
INFO - 2020-03-06 04:22:24 --> Language Class Initialized
INFO - 2020-03-06 04:22:24 --> Loader Class Initialized
INFO - 2020-03-06 04:22:24 --> Helper loaded: url_helper
INFO - 2020-03-06 04:22:24 --> Helper loaded: string_helper
INFO - 2020-03-06 04:22:24 --> Database Driver Class Initialized
DEBUG - 2020-03-06 04:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 04:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 04:22:24 --> Controller Class Initialized
INFO - 2020-03-06 04:22:24 --> Model "M_tiket" initialized
INFO - 2020-03-06 04:22:24 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 04:22:24 --> Model "M_pesan" initialized
INFO - 2020-03-06 04:22:24 --> Helper loaded: form_helper
INFO - 2020-03-06 04:22:24 --> Form Validation Class Initialized
INFO - 2020-03-06 04:22:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 04:22:24 --> Final output sent to browser
DEBUG - 2020-03-06 04:22:24 --> Total execution time: 0.0184
INFO - 2020-03-06 04:22:44 --> Config Class Initialized
INFO - 2020-03-06 04:22:44 --> Hooks Class Initialized
DEBUG - 2020-03-06 04:22:44 --> UTF-8 Support Enabled
INFO - 2020-03-06 04:22:44 --> Utf8 Class Initialized
INFO - 2020-03-06 04:22:44 --> URI Class Initialized
INFO - 2020-03-06 04:22:44 --> Router Class Initialized
INFO - 2020-03-06 04:22:44 --> Output Class Initialized
INFO - 2020-03-06 04:22:44 --> Security Class Initialized
DEBUG - 2020-03-06 04:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 04:22:44 --> Input Class Initialized
INFO - 2020-03-06 04:22:44 --> Language Class Initialized
INFO - 2020-03-06 04:22:44 --> Loader Class Initialized
INFO - 2020-03-06 04:22:44 --> Helper loaded: url_helper
INFO - 2020-03-06 04:22:44 --> Helper loaded: string_helper
INFO - 2020-03-06 04:22:44 --> Database Driver Class Initialized
DEBUG - 2020-03-06 04:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 04:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 04:22:44 --> Controller Class Initialized
INFO - 2020-03-06 04:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 04:22:44 --> Pagination Class Initialized
INFO - 2020-03-06 04:22:44 --> Model "M_show" initialized
INFO - 2020-03-06 04:22:44 --> Helper loaded: form_helper
INFO - 2020-03-06 04:22:44 --> Form Validation Class Initialized
INFO - 2020-03-06 04:22:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 04:22:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 04:22:44 --> Final output sent to browser
DEBUG - 2020-03-06 04:22:44 --> Total execution time: 0.0069
INFO - 2020-03-06 04:22:47 --> Config Class Initialized
INFO - 2020-03-06 04:22:47 --> Hooks Class Initialized
DEBUG - 2020-03-06 04:22:47 --> UTF-8 Support Enabled
INFO - 2020-03-06 04:22:47 --> Utf8 Class Initialized
INFO - 2020-03-06 04:22:47 --> URI Class Initialized
DEBUG - 2020-03-06 04:22:47 --> No URI present. Default controller set.
INFO - 2020-03-06 04:22:47 --> Router Class Initialized
INFO - 2020-03-06 04:22:47 --> Output Class Initialized
INFO - 2020-03-06 04:22:47 --> Security Class Initialized
DEBUG - 2020-03-06 04:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 04:22:47 --> Input Class Initialized
INFO - 2020-03-06 04:22:47 --> Language Class Initialized
INFO - 2020-03-06 04:22:47 --> Loader Class Initialized
INFO - 2020-03-06 04:22:47 --> Helper loaded: url_helper
INFO - 2020-03-06 04:22:47 --> Helper loaded: string_helper
INFO - 2020-03-06 04:22:47 --> Database Driver Class Initialized
DEBUG - 2020-03-06 04:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 04:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 04:22:47 --> Controller Class Initialized
INFO - 2020-03-06 04:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 04:22:47 --> Pagination Class Initialized
INFO - 2020-03-06 04:22:47 --> Model "M_show" initialized
INFO - 2020-03-06 04:22:47 --> Helper loaded: form_helper
INFO - 2020-03-06 04:22:47 --> Form Validation Class Initialized
INFO - 2020-03-06 04:22:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 04:22:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 04:22:47 --> Final output sent to browser
DEBUG - 2020-03-06 04:22:47 --> Total execution time: 0.0054
INFO - 2020-03-06 05:06:30 --> Config Class Initialized
INFO - 2020-03-06 05:06:30 --> Hooks Class Initialized
DEBUG - 2020-03-06 05:06:30 --> UTF-8 Support Enabled
INFO - 2020-03-06 05:06:30 --> Utf8 Class Initialized
INFO - 2020-03-06 05:06:30 --> URI Class Initialized
DEBUG - 2020-03-06 05:06:30 --> No URI present. Default controller set.
INFO - 2020-03-06 05:06:30 --> Router Class Initialized
INFO - 2020-03-06 05:06:30 --> Output Class Initialized
INFO - 2020-03-06 05:06:30 --> Security Class Initialized
DEBUG - 2020-03-06 05:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 05:06:30 --> Input Class Initialized
INFO - 2020-03-06 05:06:30 --> Language Class Initialized
INFO - 2020-03-06 05:06:30 --> Loader Class Initialized
INFO - 2020-03-06 05:06:30 --> Helper loaded: url_helper
INFO - 2020-03-06 05:06:30 --> Helper loaded: string_helper
INFO - 2020-03-06 05:06:30 --> Database Driver Class Initialized
DEBUG - 2020-03-06 05:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 05:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 05:06:30 --> Controller Class Initialized
INFO - 2020-03-06 05:06:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 05:06:30 --> Pagination Class Initialized
INFO - 2020-03-06 05:06:30 --> Model "M_show" initialized
INFO - 2020-03-06 05:06:30 --> Helper loaded: form_helper
INFO - 2020-03-06 05:06:30 --> Form Validation Class Initialized
INFO - 2020-03-06 05:06:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 05:06:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 05:06:30 --> Final output sent to browser
DEBUG - 2020-03-06 05:06:30 --> Total execution time: 0.1795
INFO - 2020-03-06 05:07:41 --> Config Class Initialized
INFO - 2020-03-06 05:07:41 --> Hooks Class Initialized
DEBUG - 2020-03-06 05:07:41 --> UTF-8 Support Enabled
INFO - 2020-03-06 05:07:41 --> Utf8 Class Initialized
INFO - 2020-03-06 05:07:41 --> URI Class Initialized
INFO - 2020-03-06 05:07:41 --> Router Class Initialized
INFO - 2020-03-06 05:07:41 --> Output Class Initialized
INFO - 2020-03-06 05:07:41 --> Security Class Initialized
DEBUG - 2020-03-06 05:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 05:07:41 --> Input Class Initialized
INFO - 2020-03-06 05:07:41 --> Language Class Initialized
INFO - 2020-03-06 05:07:41 --> Loader Class Initialized
INFO - 2020-03-06 05:07:41 --> Helper loaded: url_helper
INFO - 2020-03-06 05:07:41 --> Helper loaded: string_helper
INFO - 2020-03-06 05:07:41 --> Database Driver Class Initialized
DEBUG - 2020-03-06 05:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 05:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 05:07:41 --> Controller Class Initialized
INFO - 2020-03-06 05:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 05:07:41 --> Pagination Class Initialized
INFO - 2020-03-06 05:07:41 --> Model "M_show" initialized
INFO - 2020-03-06 05:07:41 --> Helper loaded: form_helper
INFO - 2020-03-06 05:07:41 --> Form Validation Class Initialized
INFO - 2020-03-06 05:07:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 05:07:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-06 05:07:41 --> Final output sent to browser
DEBUG - 2020-03-06 05:07:41 --> Total execution time: 0.0527
INFO - 2020-03-06 05:07:54 --> Config Class Initialized
INFO - 2020-03-06 05:07:54 --> Hooks Class Initialized
DEBUG - 2020-03-06 05:07:54 --> UTF-8 Support Enabled
INFO - 2020-03-06 05:07:54 --> Utf8 Class Initialized
INFO - 2020-03-06 05:07:54 --> URI Class Initialized
INFO - 2020-03-06 05:07:54 --> Router Class Initialized
INFO - 2020-03-06 05:07:54 --> Output Class Initialized
INFO - 2020-03-06 05:07:54 --> Security Class Initialized
DEBUG - 2020-03-06 05:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 05:07:54 --> Input Class Initialized
INFO - 2020-03-06 05:07:54 --> Language Class Initialized
INFO - 2020-03-06 05:07:54 --> Loader Class Initialized
INFO - 2020-03-06 05:07:54 --> Helper loaded: url_helper
INFO - 2020-03-06 05:07:54 --> Helper loaded: string_helper
INFO - 2020-03-06 05:07:54 --> Database Driver Class Initialized
DEBUG - 2020-03-06 05:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 05:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 05:07:54 --> Controller Class Initialized
INFO - 2020-03-06 05:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 05:07:54 --> Pagination Class Initialized
INFO - 2020-03-06 05:07:54 --> Model "M_show" initialized
INFO - 2020-03-06 05:07:54 --> Helper loaded: form_helper
INFO - 2020-03-06 05:07:54 --> Form Validation Class Initialized
INFO - 2020-03-06 05:07:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 05:07:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 05:07:54 --> Final output sent to browser
DEBUG - 2020-03-06 05:07:54 --> Total execution time: 0.0159
INFO - 2020-03-06 05:08:42 --> Config Class Initialized
INFO - 2020-03-06 05:08:42 --> Hooks Class Initialized
DEBUG - 2020-03-06 05:08:42 --> UTF-8 Support Enabled
INFO - 2020-03-06 05:08:42 --> Utf8 Class Initialized
INFO - 2020-03-06 05:08:42 --> URI Class Initialized
INFO - 2020-03-06 05:08:42 --> Router Class Initialized
INFO - 2020-03-06 05:08:42 --> Output Class Initialized
INFO - 2020-03-06 05:08:42 --> Security Class Initialized
DEBUG - 2020-03-06 05:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 05:08:42 --> Input Class Initialized
INFO - 2020-03-06 05:08:42 --> Language Class Initialized
INFO - 2020-03-06 05:08:42 --> Loader Class Initialized
INFO - 2020-03-06 05:08:42 --> Helper loaded: url_helper
INFO - 2020-03-06 05:08:42 --> Helper loaded: string_helper
INFO - 2020-03-06 05:08:42 --> Database Driver Class Initialized
DEBUG - 2020-03-06 05:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 05:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 05:08:43 --> Controller Class Initialized
INFO - 2020-03-06 05:08:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 05:08:43 --> Pagination Class Initialized
INFO - 2020-03-06 05:08:43 --> Model "M_show" initialized
INFO - 2020-03-06 05:08:43 --> Helper loaded: form_helper
INFO - 2020-03-06 05:08:43 --> Form Validation Class Initialized
INFO - 2020-03-06 05:08:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 05:08:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 05:08:43 --> Final output sent to browser
DEBUG - 2020-03-06 05:08:43 --> Total execution time: 0.0444
INFO - 2020-03-06 05:08:46 --> Config Class Initialized
INFO - 2020-03-06 05:08:46 --> Hooks Class Initialized
DEBUG - 2020-03-06 05:08:46 --> UTF-8 Support Enabled
INFO - 2020-03-06 05:08:46 --> Utf8 Class Initialized
INFO - 2020-03-06 05:08:46 --> URI Class Initialized
INFO - 2020-03-06 05:08:46 --> Router Class Initialized
INFO - 2020-03-06 05:08:46 --> Output Class Initialized
INFO - 2020-03-06 05:08:46 --> Security Class Initialized
DEBUG - 2020-03-06 05:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 05:08:46 --> Input Class Initialized
INFO - 2020-03-06 05:08:46 --> Language Class Initialized
INFO - 2020-03-06 05:08:46 --> Loader Class Initialized
INFO - 2020-03-06 05:08:46 --> Helper loaded: url_helper
INFO - 2020-03-06 05:08:46 --> Helper loaded: string_helper
INFO - 2020-03-06 05:08:46 --> Database Driver Class Initialized
DEBUG - 2020-03-06 05:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 05:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 05:08:46 --> Controller Class Initialized
INFO - 2020-03-06 05:08:46 --> Model "M_tiket" initialized
INFO - 2020-03-06 05:08:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 05:08:46 --> Model "M_pesan" initialized
INFO - 2020-03-06 05:08:46 --> Helper loaded: form_helper
INFO - 2020-03-06 05:08:46 --> Form Validation Class Initialized
INFO - 2020-03-06 05:08:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 05:08:46 --> Final output sent to browser
DEBUG - 2020-03-06 05:08:46 --> Total execution time: 0.0592
INFO - 2020-03-06 05:12:58 --> Config Class Initialized
INFO - 2020-03-06 05:12:58 --> Hooks Class Initialized
DEBUG - 2020-03-06 05:12:58 --> UTF-8 Support Enabled
INFO - 2020-03-06 05:12:58 --> Utf8 Class Initialized
INFO - 2020-03-06 05:12:58 --> URI Class Initialized
INFO - 2020-03-06 05:12:58 --> Router Class Initialized
INFO - 2020-03-06 05:12:58 --> Output Class Initialized
INFO - 2020-03-06 05:12:58 --> Security Class Initialized
DEBUG - 2020-03-06 05:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 05:12:58 --> Input Class Initialized
INFO - 2020-03-06 05:12:58 --> Language Class Initialized
INFO - 2020-03-06 05:12:58 --> Loader Class Initialized
INFO - 2020-03-06 05:12:58 --> Helper loaded: url_helper
INFO - 2020-03-06 05:12:58 --> Helper loaded: string_helper
INFO - 2020-03-06 05:12:58 --> Database Driver Class Initialized
DEBUG - 2020-03-06 05:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 05:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 05:12:58 --> Controller Class Initialized
INFO - 2020-03-06 05:12:58 --> Model "M_tiket" initialized
INFO - 2020-03-06 05:12:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 05:12:58 --> Model "M_pesan" initialized
INFO - 2020-03-06 05:12:58 --> Helper loaded: form_helper
INFO - 2020-03-06 05:12:58 --> Form Validation Class Initialized
INFO - 2020-03-06 05:12:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 05:12:58 --> Final output sent to browser
DEBUG - 2020-03-06 05:12:58 --> Total execution time: 0.0494
INFO - 2020-03-06 05:33:59 --> Config Class Initialized
INFO - 2020-03-06 05:33:59 --> Hooks Class Initialized
DEBUG - 2020-03-06 05:33:59 --> UTF-8 Support Enabled
INFO - 2020-03-06 05:33:59 --> Utf8 Class Initialized
INFO - 2020-03-06 05:33:59 --> URI Class Initialized
INFO - 2020-03-06 05:33:59 --> Router Class Initialized
INFO - 2020-03-06 05:33:59 --> Output Class Initialized
INFO - 2020-03-06 05:33:59 --> Security Class Initialized
DEBUG - 2020-03-06 05:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 05:33:59 --> Input Class Initialized
INFO - 2020-03-06 05:33:59 --> Language Class Initialized
INFO - 2020-03-06 05:33:59 --> Loader Class Initialized
INFO - 2020-03-06 05:33:59 --> Helper loaded: url_helper
INFO - 2020-03-06 05:33:59 --> Helper loaded: string_helper
INFO - 2020-03-06 05:33:59 --> Database Driver Class Initialized
DEBUG - 2020-03-06 05:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 05:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 05:33:59 --> Controller Class Initialized
INFO - 2020-03-06 05:33:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 05:33:59 --> Pagination Class Initialized
INFO - 2020-03-06 05:33:59 --> Model "M_show" initialized
INFO - 2020-03-06 05:33:59 --> Helper loaded: form_helper
INFO - 2020-03-06 05:33:59 --> Form Validation Class Initialized
INFO - 2020-03-06 05:33:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 05:33:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 05:33:59 --> Final output sent to browser
DEBUG - 2020-03-06 05:33:59 --> Total execution time: 0.0437
INFO - 2020-03-06 06:06:25 --> Config Class Initialized
INFO - 2020-03-06 06:06:25 --> Hooks Class Initialized
DEBUG - 2020-03-06 06:06:25 --> UTF-8 Support Enabled
INFO - 2020-03-06 06:06:25 --> Utf8 Class Initialized
INFO - 2020-03-06 06:06:25 --> URI Class Initialized
INFO - 2020-03-06 06:06:25 --> Router Class Initialized
INFO - 2020-03-06 06:06:25 --> Output Class Initialized
INFO - 2020-03-06 06:06:25 --> Security Class Initialized
DEBUG - 2020-03-06 06:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 06:06:25 --> Input Class Initialized
INFO - 2020-03-06 06:06:25 --> Language Class Initialized
INFO - 2020-03-06 06:06:25 --> Loader Class Initialized
INFO - 2020-03-06 06:06:25 --> Helper loaded: url_helper
INFO - 2020-03-06 06:06:25 --> Helper loaded: string_helper
INFO - 2020-03-06 06:06:25 --> Database Driver Class Initialized
DEBUG - 2020-03-06 06:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 06:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 06:06:25 --> Controller Class Initialized
INFO - 2020-03-06 06:06:25 --> Model "M_tiket" initialized
INFO - 2020-03-06 06:06:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 06:06:25 --> Model "M_pesan" initialized
INFO - 2020-03-06 06:06:25 --> Helper loaded: form_helper
INFO - 2020-03-06 06:06:25 --> Form Validation Class Initialized
INFO - 2020-03-06 06:06:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 06:06:25 --> Final output sent to browser
DEBUG - 2020-03-06 06:06:25 --> Total execution time: 0.0605
INFO - 2020-03-06 06:21:20 --> Config Class Initialized
INFO - 2020-03-06 06:21:20 --> Hooks Class Initialized
DEBUG - 2020-03-06 06:21:20 --> UTF-8 Support Enabled
INFO - 2020-03-06 06:21:20 --> Utf8 Class Initialized
INFO - 2020-03-06 06:21:20 --> URI Class Initialized
INFO - 2020-03-06 06:21:20 --> Router Class Initialized
INFO - 2020-03-06 06:21:20 --> Output Class Initialized
INFO - 2020-03-06 06:21:20 --> Security Class Initialized
DEBUG - 2020-03-06 06:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 06:21:20 --> Input Class Initialized
INFO - 2020-03-06 06:21:20 --> Language Class Initialized
INFO - 2020-03-06 06:21:20 --> Loader Class Initialized
INFO - 2020-03-06 06:21:20 --> Helper loaded: url_helper
INFO - 2020-03-06 06:21:20 --> Helper loaded: string_helper
INFO - 2020-03-06 06:21:20 --> Database Driver Class Initialized
DEBUG - 2020-03-06 06:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 06:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 06:21:20 --> Controller Class Initialized
INFO - 2020-03-06 06:21:20 --> Model "M_tiket" initialized
INFO - 2020-03-06 06:21:20 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 06:21:20 --> Model "M_pesan" initialized
INFO - 2020-03-06 06:21:20 --> Helper loaded: form_helper
INFO - 2020-03-06 06:21:20 --> Form Validation Class Initialized
INFO - 2020-03-06 06:21:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 06:21:20 --> Final output sent to browser
DEBUG - 2020-03-06 06:21:20 --> Total execution time: 0.0467
INFO - 2020-03-06 06:42:21 --> Config Class Initialized
INFO - 2020-03-06 06:42:21 --> Hooks Class Initialized
DEBUG - 2020-03-06 06:42:21 --> UTF-8 Support Enabled
INFO - 2020-03-06 06:42:21 --> Utf8 Class Initialized
INFO - 2020-03-06 06:42:21 --> URI Class Initialized
DEBUG - 2020-03-06 06:42:21 --> No URI present. Default controller set.
INFO - 2020-03-06 06:42:21 --> Router Class Initialized
INFO - 2020-03-06 06:42:21 --> Output Class Initialized
INFO - 2020-03-06 06:42:21 --> Security Class Initialized
DEBUG - 2020-03-06 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 06:42:21 --> Input Class Initialized
INFO - 2020-03-06 06:42:21 --> Language Class Initialized
INFO - 2020-03-06 06:42:21 --> Loader Class Initialized
INFO - 2020-03-06 06:42:21 --> Helper loaded: url_helper
INFO - 2020-03-06 06:42:21 --> Helper loaded: string_helper
INFO - 2020-03-06 06:42:21 --> Database Driver Class Initialized
DEBUG - 2020-03-06 06:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 06:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 06:42:21 --> Controller Class Initialized
INFO - 2020-03-06 06:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 06:42:21 --> Pagination Class Initialized
INFO - 2020-03-06 06:42:21 --> Model "M_show" initialized
INFO - 2020-03-06 06:42:21 --> Helper loaded: form_helper
INFO - 2020-03-06 06:42:21 --> Form Validation Class Initialized
INFO - 2020-03-06 06:42:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 06:42:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 06:42:21 --> Final output sent to browser
DEBUG - 2020-03-06 06:42:21 --> Total execution time: 0.1071
INFO - 2020-03-06 06:42:46 --> Config Class Initialized
INFO - 2020-03-06 06:42:46 --> Hooks Class Initialized
DEBUG - 2020-03-06 06:42:46 --> UTF-8 Support Enabled
INFO - 2020-03-06 06:42:46 --> Utf8 Class Initialized
INFO - 2020-03-06 06:42:46 --> URI Class Initialized
DEBUG - 2020-03-06 06:42:46 --> No URI present. Default controller set.
INFO - 2020-03-06 06:42:46 --> Router Class Initialized
INFO - 2020-03-06 06:42:46 --> Output Class Initialized
INFO - 2020-03-06 06:42:46 --> Security Class Initialized
DEBUG - 2020-03-06 06:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 06:42:46 --> Input Class Initialized
INFO - 2020-03-06 06:42:46 --> Language Class Initialized
INFO - 2020-03-06 06:42:46 --> Loader Class Initialized
INFO - 2020-03-06 06:42:46 --> Helper loaded: url_helper
INFO - 2020-03-06 06:42:46 --> Helper loaded: string_helper
INFO - 2020-03-06 06:42:46 --> Database Driver Class Initialized
DEBUG - 2020-03-06 06:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 06:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 06:42:46 --> Controller Class Initialized
INFO - 2020-03-06 06:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 06:42:46 --> Pagination Class Initialized
INFO - 2020-03-06 06:42:46 --> Model "M_show" initialized
INFO - 2020-03-06 06:42:46 --> Helper loaded: form_helper
INFO - 2020-03-06 06:42:46 --> Form Validation Class Initialized
INFO - 2020-03-06 06:42:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 06:42:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 06:42:46 --> Final output sent to browser
DEBUG - 2020-03-06 06:42:46 --> Total execution time: 0.0055
INFO - 2020-03-06 07:15:33 --> Config Class Initialized
INFO - 2020-03-06 07:15:33 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:15:33 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:15:33 --> Utf8 Class Initialized
INFO - 2020-03-06 07:15:33 --> URI Class Initialized
DEBUG - 2020-03-06 07:15:33 --> No URI present. Default controller set.
INFO - 2020-03-06 07:15:33 --> Router Class Initialized
INFO - 2020-03-06 07:15:33 --> Output Class Initialized
INFO - 2020-03-06 07:15:33 --> Security Class Initialized
DEBUG - 2020-03-06 07:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:15:33 --> Input Class Initialized
INFO - 2020-03-06 07:15:33 --> Language Class Initialized
INFO - 2020-03-06 07:15:33 --> Loader Class Initialized
INFO - 2020-03-06 07:15:33 --> Helper loaded: url_helper
INFO - 2020-03-06 07:15:33 --> Helper loaded: string_helper
INFO - 2020-03-06 07:15:33 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:15:33 --> Controller Class Initialized
INFO - 2020-03-06 07:15:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 07:15:33 --> Pagination Class Initialized
INFO - 2020-03-06 07:15:33 --> Model "M_show" initialized
INFO - 2020-03-06 07:15:33 --> Helper loaded: form_helper
INFO - 2020-03-06 07:15:33 --> Form Validation Class Initialized
INFO - 2020-03-06 07:15:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 07:15:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 07:15:33 --> Final output sent to browser
DEBUG - 2020-03-06 07:15:33 --> Total execution time: 0.0469
INFO - 2020-03-06 07:15:41 --> Config Class Initialized
INFO - 2020-03-06 07:15:41 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:15:41 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:15:41 --> Utf8 Class Initialized
INFO - 2020-03-06 07:15:41 --> URI Class Initialized
INFO - 2020-03-06 07:15:41 --> Router Class Initialized
INFO - 2020-03-06 07:15:41 --> Output Class Initialized
INFO - 2020-03-06 07:15:41 --> Security Class Initialized
DEBUG - 2020-03-06 07:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:15:41 --> Input Class Initialized
INFO - 2020-03-06 07:15:41 --> Language Class Initialized
INFO - 2020-03-06 07:15:41 --> Loader Class Initialized
INFO - 2020-03-06 07:15:41 --> Helper loaded: url_helper
INFO - 2020-03-06 07:15:41 --> Helper loaded: string_helper
INFO - 2020-03-06 07:15:41 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:15:41 --> Controller Class Initialized
INFO - 2020-03-06 07:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 07:15:41 --> Pagination Class Initialized
INFO - 2020-03-06 07:15:41 --> Model "M_show" initialized
INFO - 2020-03-06 07:15:41 --> Helper loaded: form_helper
INFO - 2020-03-06 07:15:41 --> Form Validation Class Initialized
INFO - 2020-03-06 07:15:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 07:15:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 07:15:41 --> Final output sent to browser
DEBUG - 2020-03-06 07:15:41 --> Total execution time: 0.0074
INFO - 2020-03-06 07:15:46 --> Config Class Initialized
INFO - 2020-03-06 07:15:46 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:15:46 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:15:46 --> Utf8 Class Initialized
INFO - 2020-03-06 07:15:46 --> URI Class Initialized
INFO - 2020-03-06 07:15:46 --> Router Class Initialized
INFO - 2020-03-06 07:15:46 --> Output Class Initialized
INFO - 2020-03-06 07:15:46 --> Security Class Initialized
DEBUG - 2020-03-06 07:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:15:46 --> Input Class Initialized
INFO - 2020-03-06 07:15:46 --> Language Class Initialized
INFO - 2020-03-06 07:15:46 --> Loader Class Initialized
INFO - 2020-03-06 07:15:46 --> Helper loaded: url_helper
INFO - 2020-03-06 07:15:46 --> Helper loaded: string_helper
INFO - 2020-03-06 07:15:46 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:15:46 --> Controller Class Initialized
INFO - 2020-03-06 07:15:46 --> Model "M_tiket" initialized
INFO - 2020-03-06 07:15:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 07:15:46 --> Model "M_pesan" initialized
INFO - 2020-03-06 07:15:46 --> Helper loaded: form_helper
INFO - 2020-03-06 07:15:46 --> Form Validation Class Initialized
INFO - 2020-03-06 07:15:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 07:15:46 --> Final output sent to browser
DEBUG - 2020-03-06 07:15:46 --> Total execution time: 0.0217
INFO - 2020-03-06 07:31:35 --> Config Class Initialized
INFO - 2020-03-06 07:31:35 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:31:35 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:31:35 --> Utf8 Class Initialized
INFO - 2020-03-06 07:31:35 --> URI Class Initialized
DEBUG - 2020-03-06 07:31:35 --> No URI present. Default controller set.
INFO - 2020-03-06 07:31:35 --> Router Class Initialized
INFO - 2020-03-06 07:31:35 --> Output Class Initialized
INFO - 2020-03-06 07:31:35 --> Security Class Initialized
DEBUG - 2020-03-06 07:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:31:35 --> Input Class Initialized
INFO - 2020-03-06 07:31:35 --> Language Class Initialized
INFO - 2020-03-06 07:31:35 --> Loader Class Initialized
INFO - 2020-03-06 07:31:35 --> Helper loaded: url_helper
INFO - 2020-03-06 07:31:35 --> Helper loaded: string_helper
INFO - 2020-03-06 07:31:35 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:31:35 --> Controller Class Initialized
INFO - 2020-03-06 07:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 07:31:35 --> Pagination Class Initialized
INFO - 2020-03-06 07:31:35 --> Model "M_show" initialized
INFO - 2020-03-06 07:31:35 --> Helper loaded: form_helper
INFO - 2020-03-06 07:31:35 --> Form Validation Class Initialized
INFO - 2020-03-06 07:31:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 07:31:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 07:31:35 --> Final output sent to browser
DEBUG - 2020-03-06 07:31:35 --> Total execution time: 0.0298
INFO - 2020-03-06 07:31:44 --> Config Class Initialized
INFO - 2020-03-06 07:31:44 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:31:44 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:31:44 --> Utf8 Class Initialized
INFO - 2020-03-06 07:31:44 --> URI Class Initialized
INFO - 2020-03-06 07:31:44 --> Router Class Initialized
INFO - 2020-03-06 07:31:44 --> Output Class Initialized
INFO - 2020-03-06 07:31:44 --> Security Class Initialized
DEBUG - 2020-03-06 07:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:31:44 --> Input Class Initialized
INFO - 2020-03-06 07:31:44 --> Language Class Initialized
INFO - 2020-03-06 07:31:44 --> Loader Class Initialized
INFO - 2020-03-06 07:31:44 --> Helper loaded: url_helper
INFO - 2020-03-06 07:31:44 --> Helper loaded: string_helper
INFO - 2020-03-06 07:31:44 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:31:44 --> Controller Class Initialized
INFO - 2020-03-06 07:31:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 07:31:44 --> Pagination Class Initialized
INFO - 2020-03-06 07:31:44 --> Model "M_show" initialized
INFO - 2020-03-06 07:31:44 --> Helper loaded: form_helper
INFO - 2020-03-06 07:31:44 --> Form Validation Class Initialized
INFO - 2020-03-06 07:31:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 07:31:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 07:31:44 --> Final output sent to browser
DEBUG - 2020-03-06 07:31:44 --> Total execution time: 0.0089
INFO - 2020-03-06 07:31:47 --> Config Class Initialized
INFO - 2020-03-06 07:31:47 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:31:47 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:31:47 --> Utf8 Class Initialized
INFO - 2020-03-06 07:31:47 --> URI Class Initialized
INFO - 2020-03-06 07:31:47 --> Router Class Initialized
INFO - 2020-03-06 07:31:47 --> Output Class Initialized
INFO - 2020-03-06 07:31:47 --> Security Class Initialized
DEBUG - 2020-03-06 07:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:31:47 --> Input Class Initialized
INFO - 2020-03-06 07:31:47 --> Language Class Initialized
INFO - 2020-03-06 07:31:47 --> Loader Class Initialized
INFO - 2020-03-06 07:31:47 --> Helper loaded: url_helper
INFO - 2020-03-06 07:31:47 --> Helper loaded: string_helper
INFO - 2020-03-06 07:31:47 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:31:47 --> Controller Class Initialized
INFO - 2020-03-06 07:31:47 --> Model "M_tiket" initialized
INFO - 2020-03-06 07:31:47 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 07:31:47 --> Model "M_pesan" initialized
INFO - 2020-03-06 07:31:47 --> Helper loaded: form_helper
INFO - 2020-03-06 07:31:47 --> Form Validation Class Initialized
INFO - 2020-03-06 07:31:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 07:31:47 --> Final output sent to browser
DEBUG - 2020-03-06 07:31:47 --> Total execution time: 0.0098
INFO - 2020-03-06 07:33:00 --> Config Class Initialized
INFO - 2020-03-06 07:33:00 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:33:00 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:33:00 --> Utf8 Class Initialized
INFO - 2020-03-06 07:33:00 --> URI Class Initialized
INFO - 2020-03-06 07:33:00 --> Router Class Initialized
INFO - 2020-03-06 07:33:00 --> Output Class Initialized
INFO - 2020-03-06 07:33:00 --> Security Class Initialized
DEBUG - 2020-03-06 07:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:33:00 --> Input Class Initialized
INFO - 2020-03-06 07:33:00 --> Language Class Initialized
INFO - 2020-03-06 07:33:00 --> Loader Class Initialized
INFO - 2020-03-06 07:33:00 --> Helper loaded: url_helper
INFO - 2020-03-06 07:33:00 --> Helper loaded: string_helper
INFO - 2020-03-06 07:33:00 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:33:00 --> Controller Class Initialized
INFO - 2020-03-06 07:33:00 --> Model "M_tiket" initialized
INFO - 2020-03-06 07:33:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 07:33:00 --> Model "M_pesan" initialized
INFO - 2020-03-06 07:33:00 --> Helper loaded: form_helper
INFO - 2020-03-06 07:33:00 --> Form Validation Class Initialized
INFO - 2020-03-06 07:33:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 07:33:00 --> Final output sent to browser
DEBUG - 2020-03-06 07:33:00 --> Total execution time: 0.0518
INFO - 2020-03-06 07:53:25 --> Config Class Initialized
INFO - 2020-03-06 07:53:25 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:53:25 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:53:25 --> Utf8 Class Initialized
INFO - 2020-03-06 07:53:25 --> URI Class Initialized
DEBUG - 2020-03-06 07:53:25 --> No URI present. Default controller set.
INFO - 2020-03-06 07:53:25 --> Router Class Initialized
INFO - 2020-03-06 07:53:25 --> Output Class Initialized
INFO - 2020-03-06 07:53:25 --> Security Class Initialized
DEBUG - 2020-03-06 07:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:53:25 --> Input Class Initialized
INFO - 2020-03-06 07:53:25 --> Language Class Initialized
INFO - 2020-03-06 07:53:25 --> Loader Class Initialized
INFO - 2020-03-06 07:53:25 --> Helper loaded: url_helper
INFO - 2020-03-06 07:53:25 --> Helper loaded: string_helper
INFO - 2020-03-06 07:53:25 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:53:25 --> Controller Class Initialized
INFO - 2020-03-06 07:53:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 07:53:25 --> Pagination Class Initialized
INFO - 2020-03-06 07:53:25 --> Model "M_show" initialized
INFO - 2020-03-06 07:53:25 --> Helper loaded: form_helper
INFO - 2020-03-06 07:53:25 --> Form Validation Class Initialized
INFO - 2020-03-06 07:53:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 07:53:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 07:53:25 --> Final output sent to browser
DEBUG - 2020-03-06 07:53:25 --> Total execution time: 0.0865
INFO - 2020-03-06 07:53:43 --> Config Class Initialized
INFO - 2020-03-06 07:53:43 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:53:43 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:53:43 --> Utf8 Class Initialized
INFO - 2020-03-06 07:53:43 --> URI Class Initialized
INFO - 2020-03-06 07:53:43 --> Router Class Initialized
INFO - 2020-03-06 07:53:43 --> Output Class Initialized
INFO - 2020-03-06 07:53:43 --> Security Class Initialized
DEBUG - 2020-03-06 07:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:53:43 --> Input Class Initialized
INFO - 2020-03-06 07:53:43 --> Language Class Initialized
INFO - 2020-03-06 07:53:43 --> Loader Class Initialized
INFO - 2020-03-06 07:53:43 --> Helper loaded: url_helper
INFO - 2020-03-06 07:53:43 --> Helper loaded: string_helper
INFO - 2020-03-06 07:53:43 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:53:43 --> Controller Class Initialized
INFO - 2020-03-06 07:53:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 07:53:43 --> Pagination Class Initialized
INFO - 2020-03-06 07:53:43 --> Model "M_show" initialized
INFO - 2020-03-06 07:53:43 --> Helper loaded: form_helper
INFO - 2020-03-06 07:53:43 --> Form Validation Class Initialized
INFO - 2020-03-06 07:53:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 07:53:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-06 07:53:43 --> Final output sent to browser
DEBUG - 2020-03-06 07:53:43 --> Total execution time: 0.0297
INFO - 2020-03-06 07:53:44 --> Config Class Initialized
INFO - 2020-03-06 07:53:44 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:53:44 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:53:44 --> Utf8 Class Initialized
INFO - 2020-03-06 07:53:44 --> URI Class Initialized
INFO - 2020-03-06 07:53:44 --> Router Class Initialized
INFO - 2020-03-06 07:53:44 --> Output Class Initialized
INFO - 2020-03-06 07:53:44 --> Security Class Initialized
DEBUG - 2020-03-06 07:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:53:44 --> Input Class Initialized
INFO - 2020-03-06 07:53:44 --> Language Class Initialized
ERROR - 2020-03-06 07:53:44 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-06 07:54:04 --> Config Class Initialized
INFO - 2020-03-06 07:54:04 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:54:04 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:54:04 --> Utf8 Class Initialized
INFO - 2020-03-06 07:54:04 --> URI Class Initialized
INFO - 2020-03-06 07:54:04 --> Router Class Initialized
INFO - 2020-03-06 07:54:04 --> Output Class Initialized
INFO - 2020-03-06 07:54:04 --> Security Class Initialized
DEBUG - 2020-03-06 07:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:54:04 --> Input Class Initialized
INFO - 2020-03-06 07:54:04 --> Language Class Initialized
INFO - 2020-03-06 07:54:04 --> Loader Class Initialized
INFO - 2020-03-06 07:54:04 --> Helper loaded: url_helper
INFO - 2020-03-06 07:54:04 --> Helper loaded: string_helper
INFO - 2020-03-06 07:54:04 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:54:04 --> Controller Class Initialized
INFO - 2020-03-06 07:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 07:54:04 --> Pagination Class Initialized
INFO - 2020-03-06 07:54:04 --> Model "M_show" initialized
INFO - 2020-03-06 07:54:04 --> Helper loaded: form_helper
INFO - 2020-03-06 07:54:04 --> Form Validation Class Initialized
INFO - 2020-03-06 07:54:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 07:54:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 07:54:04 --> Final output sent to browser
DEBUG - 2020-03-06 07:54:04 --> Total execution time: 0.0094
INFO - 2020-03-06 07:54:09 --> Config Class Initialized
INFO - 2020-03-06 07:54:09 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:54:09 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:54:09 --> Utf8 Class Initialized
INFO - 2020-03-06 07:54:09 --> URI Class Initialized
INFO - 2020-03-06 07:54:09 --> Router Class Initialized
INFO - 2020-03-06 07:54:09 --> Output Class Initialized
INFO - 2020-03-06 07:54:09 --> Security Class Initialized
DEBUG - 2020-03-06 07:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:54:09 --> Input Class Initialized
INFO - 2020-03-06 07:54:09 --> Language Class Initialized
INFO - 2020-03-06 07:54:09 --> Loader Class Initialized
INFO - 2020-03-06 07:54:09 --> Helper loaded: url_helper
INFO - 2020-03-06 07:54:09 --> Helper loaded: string_helper
INFO - 2020-03-06 07:54:09 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:54:09 --> Controller Class Initialized
INFO - 2020-03-06 07:54:09 --> Model "M_tiket" initialized
INFO - 2020-03-06 07:54:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 07:54:09 --> Model "M_pesan" initialized
INFO - 2020-03-06 07:54:09 --> Helper loaded: form_helper
INFO - 2020-03-06 07:54:09 --> Form Validation Class Initialized
INFO - 2020-03-06 07:54:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 07:54:09 --> Final output sent to browser
DEBUG - 2020-03-06 07:54:09 --> Total execution time: 0.0105
INFO - 2020-03-06 07:54:30 --> Config Class Initialized
INFO - 2020-03-06 07:54:30 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:54:30 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:54:30 --> Utf8 Class Initialized
INFO - 2020-03-06 07:54:30 --> URI Class Initialized
INFO - 2020-03-06 07:54:30 --> Router Class Initialized
INFO - 2020-03-06 07:54:30 --> Output Class Initialized
INFO - 2020-03-06 07:54:30 --> Security Class Initialized
DEBUG - 2020-03-06 07:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:54:30 --> Input Class Initialized
INFO - 2020-03-06 07:54:30 --> Language Class Initialized
INFO - 2020-03-06 07:54:30 --> Loader Class Initialized
INFO - 2020-03-06 07:54:30 --> Helper loaded: url_helper
INFO - 2020-03-06 07:54:30 --> Helper loaded: string_helper
INFO - 2020-03-06 07:54:30 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:54:30 --> Controller Class Initialized
INFO - 2020-03-06 07:54:30 --> Model "M_tiket" initialized
INFO - 2020-03-06 07:54:30 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 07:54:30 --> Model "M_pesan" initialized
INFO - 2020-03-06 07:54:30 --> Helper loaded: form_helper
INFO - 2020-03-06 07:54:30 --> Form Validation Class Initialized
INFO - 2020-03-06 07:54:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 07:54:30 --> Final output sent to browser
DEBUG - 2020-03-06 07:54:30 --> Total execution time: 0.0085
INFO - 2020-03-06 07:55:37 --> Config Class Initialized
INFO - 2020-03-06 07:55:37 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:55:37 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:55:37 --> Utf8 Class Initialized
INFO - 2020-03-06 07:55:37 --> URI Class Initialized
INFO - 2020-03-06 07:55:37 --> Router Class Initialized
INFO - 2020-03-06 07:55:37 --> Output Class Initialized
INFO - 2020-03-06 07:55:37 --> Security Class Initialized
DEBUG - 2020-03-06 07:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:55:37 --> Input Class Initialized
INFO - 2020-03-06 07:55:37 --> Language Class Initialized
INFO - 2020-03-06 07:55:37 --> Loader Class Initialized
INFO - 2020-03-06 07:55:37 --> Helper loaded: url_helper
INFO - 2020-03-06 07:55:37 --> Helper loaded: string_helper
INFO - 2020-03-06 07:55:37 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:55:37 --> Controller Class Initialized
INFO - 2020-03-06 07:55:37 --> Model "M_tiket" initialized
INFO - 2020-03-06 07:55:37 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 07:55:37 --> Model "M_pesan" initialized
INFO - 2020-03-06 07:55:37 --> Helper loaded: form_helper
INFO - 2020-03-06 07:55:37 --> Form Validation Class Initialized
DEBUG - 2020-03-06 07:55:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-06 07:55:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-06 14:55:37 --> Final output sent to browser
DEBUG - 2020-03-06 14:55:37 --> Total execution time: 0.1862
INFO - 2020-03-06 07:55:41 --> Config Class Initialized
INFO - 2020-03-06 07:55:41 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:55:41 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:55:41 --> Utf8 Class Initialized
INFO - 2020-03-06 07:55:41 --> URI Class Initialized
INFO - 2020-03-06 07:55:41 --> Router Class Initialized
INFO - 2020-03-06 07:55:41 --> Output Class Initialized
INFO - 2020-03-06 07:55:41 --> Security Class Initialized
DEBUG - 2020-03-06 07:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:55:41 --> Input Class Initialized
INFO - 2020-03-06 07:55:41 --> Language Class Initialized
INFO - 2020-03-06 07:55:41 --> Loader Class Initialized
INFO - 2020-03-06 07:55:41 --> Helper loaded: url_helper
INFO - 2020-03-06 07:55:41 --> Helper loaded: string_helper
INFO - 2020-03-06 07:55:41 --> Database Driver Class Initialized
DEBUG - 2020-03-06 07:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 07:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 07:55:41 --> Controller Class Initialized
INFO - 2020-03-06 07:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 07:55:41 --> Pagination Class Initialized
INFO - 2020-03-06 07:55:41 --> Model "M_show" initialized
INFO - 2020-03-06 07:55:41 --> Helper loaded: form_helper
INFO - 2020-03-06 07:55:41 --> Form Validation Class Initialized
INFO - 2020-03-06 07:55:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 07:55:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 07:55:41 --> Final output sent to browser
DEBUG - 2020-03-06 07:55:41 --> Total execution time: 0.0052
INFO - 2020-03-06 07:55:42 --> Config Class Initialized
INFO - 2020-03-06 07:55:42 --> Hooks Class Initialized
DEBUG - 2020-03-06 07:55:42 --> UTF-8 Support Enabled
INFO - 2020-03-06 07:55:42 --> Utf8 Class Initialized
INFO - 2020-03-06 07:55:42 --> URI Class Initialized
INFO - 2020-03-06 07:55:42 --> Router Class Initialized
INFO - 2020-03-06 07:55:42 --> Output Class Initialized
INFO - 2020-03-06 07:55:42 --> Security Class Initialized
DEBUG - 2020-03-06 07:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 07:55:42 --> Input Class Initialized
INFO - 2020-03-06 07:55:42 --> Language Class Initialized
ERROR - 2020-03-06 07:55:42 --> 404 Page Not Found: Engine0/jquery.js
INFO - 2020-03-06 08:12:06 --> Config Class Initialized
INFO - 2020-03-06 08:12:06 --> Hooks Class Initialized
DEBUG - 2020-03-06 08:12:06 --> UTF-8 Support Enabled
INFO - 2020-03-06 08:12:06 --> Utf8 Class Initialized
INFO - 2020-03-06 08:12:06 --> URI Class Initialized
DEBUG - 2020-03-06 08:12:06 --> No URI present. Default controller set.
INFO - 2020-03-06 08:12:06 --> Router Class Initialized
INFO - 2020-03-06 08:12:06 --> Output Class Initialized
INFO - 2020-03-06 08:12:06 --> Security Class Initialized
DEBUG - 2020-03-06 08:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 08:12:06 --> Input Class Initialized
INFO - 2020-03-06 08:12:06 --> Language Class Initialized
INFO - 2020-03-06 08:12:06 --> Loader Class Initialized
INFO - 2020-03-06 08:12:06 --> Helper loaded: url_helper
INFO - 2020-03-06 08:12:06 --> Helper loaded: string_helper
INFO - 2020-03-06 08:12:06 --> Database Driver Class Initialized
DEBUG - 2020-03-06 08:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 08:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 08:12:06 --> Controller Class Initialized
INFO - 2020-03-06 08:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 08:12:06 --> Pagination Class Initialized
INFO - 2020-03-06 08:12:06 --> Model "M_show" initialized
INFO - 2020-03-06 08:12:06 --> Helper loaded: form_helper
INFO - 2020-03-06 08:12:06 --> Form Validation Class Initialized
INFO - 2020-03-06 08:12:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 08:12:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 08:12:06 --> Final output sent to browser
DEBUG - 2020-03-06 08:12:06 --> Total execution time: 0.1930
INFO - 2020-03-06 08:34:48 --> Config Class Initialized
INFO - 2020-03-06 08:34:48 --> Hooks Class Initialized
DEBUG - 2020-03-06 08:34:48 --> UTF-8 Support Enabled
INFO - 2020-03-06 08:34:48 --> Utf8 Class Initialized
INFO - 2020-03-06 08:34:48 --> URI Class Initialized
DEBUG - 2020-03-06 08:34:48 --> No URI present. Default controller set.
INFO - 2020-03-06 08:34:48 --> Router Class Initialized
INFO - 2020-03-06 08:34:48 --> Output Class Initialized
INFO - 2020-03-06 08:34:48 --> Security Class Initialized
DEBUG - 2020-03-06 08:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 08:34:48 --> Input Class Initialized
INFO - 2020-03-06 08:34:48 --> Language Class Initialized
INFO - 2020-03-06 08:34:48 --> Loader Class Initialized
INFO - 2020-03-06 08:34:48 --> Helper loaded: url_helper
INFO - 2020-03-06 08:34:48 --> Helper loaded: string_helper
INFO - 2020-03-06 08:34:48 --> Database Driver Class Initialized
DEBUG - 2020-03-06 08:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 08:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 08:34:48 --> Controller Class Initialized
INFO - 2020-03-06 08:34:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 08:34:48 --> Pagination Class Initialized
INFO - 2020-03-06 08:34:48 --> Model "M_show" initialized
INFO - 2020-03-06 08:34:48 --> Helper loaded: form_helper
INFO - 2020-03-06 08:34:48 --> Form Validation Class Initialized
INFO - 2020-03-06 08:34:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 08:34:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 08:34:48 --> Final output sent to browser
DEBUG - 2020-03-06 08:34:48 --> Total execution time: 0.0458
INFO - 2020-03-06 08:40:11 --> Config Class Initialized
INFO - 2020-03-06 08:40:11 --> Hooks Class Initialized
DEBUG - 2020-03-06 08:40:11 --> UTF-8 Support Enabled
INFO - 2020-03-06 08:40:11 --> Utf8 Class Initialized
INFO - 2020-03-06 08:40:11 --> URI Class Initialized
DEBUG - 2020-03-06 08:40:11 --> No URI present. Default controller set.
INFO - 2020-03-06 08:40:11 --> Router Class Initialized
INFO - 2020-03-06 08:40:11 --> Output Class Initialized
INFO - 2020-03-06 08:40:11 --> Security Class Initialized
DEBUG - 2020-03-06 08:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 08:40:11 --> Input Class Initialized
INFO - 2020-03-06 08:40:11 --> Language Class Initialized
INFO - 2020-03-06 08:40:11 --> Loader Class Initialized
INFO - 2020-03-06 08:40:11 --> Helper loaded: url_helper
INFO - 2020-03-06 08:40:11 --> Helper loaded: string_helper
INFO - 2020-03-06 08:40:11 --> Database Driver Class Initialized
DEBUG - 2020-03-06 08:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 08:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 08:40:11 --> Controller Class Initialized
INFO - 2020-03-06 08:40:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 08:40:11 --> Pagination Class Initialized
INFO - 2020-03-06 08:40:11 --> Model "M_show" initialized
INFO - 2020-03-06 08:40:12 --> Helper loaded: form_helper
INFO - 2020-03-06 08:40:12 --> Form Validation Class Initialized
INFO - 2020-03-06 08:40:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 08:40:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 08:40:12 --> Final output sent to browser
DEBUG - 2020-03-06 08:40:12 --> Total execution time: 0.0686
INFO - 2020-03-06 08:40:38 --> Config Class Initialized
INFO - 2020-03-06 08:40:38 --> Hooks Class Initialized
DEBUG - 2020-03-06 08:40:38 --> UTF-8 Support Enabled
INFO - 2020-03-06 08:40:38 --> Utf8 Class Initialized
INFO - 2020-03-06 08:40:38 --> URI Class Initialized
INFO - 2020-03-06 08:40:38 --> Router Class Initialized
INFO - 2020-03-06 08:40:38 --> Output Class Initialized
INFO - 2020-03-06 08:40:38 --> Security Class Initialized
DEBUG - 2020-03-06 08:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 08:40:38 --> Input Class Initialized
INFO - 2020-03-06 08:40:38 --> Language Class Initialized
INFO - 2020-03-06 08:40:38 --> Loader Class Initialized
INFO - 2020-03-06 08:40:38 --> Helper loaded: url_helper
INFO - 2020-03-06 08:40:38 --> Helper loaded: string_helper
INFO - 2020-03-06 08:40:38 --> Database Driver Class Initialized
DEBUG - 2020-03-06 08:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 08:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 08:40:38 --> Controller Class Initialized
INFO - 2020-03-06 08:40:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 08:40:38 --> Pagination Class Initialized
INFO - 2020-03-06 08:40:38 --> Model "M_show" initialized
INFO - 2020-03-06 08:40:38 --> Helper loaded: form_helper
INFO - 2020-03-06 08:40:38 --> Form Validation Class Initialized
INFO - 2020-03-06 08:40:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 08:40:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 08:40:38 --> Final output sent to browser
DEBUG - 2020-03-06 08:40:38 --> Total execution time: 0.0106
INFO - 2020-03-06 08:40:39 --> Config Class Initialized
INFO - 2020-03-06 08:40:39 --> Hooks Class Initialized
DEBUG - 2020-03-06 08:40:39 --> UTF-8 Support Enabled
INFO - 2020-03-06 08:40:39 --> Utf8 Class Initialized
INFO - 2020-03-06 08:40:39 --> URI Class Initialized
INFO - 2020-03-06 08:40:39 --> Router Class Initialized
INFO - 2020-03-06 08:40:39 --> Output Class Initialized
INFO - 2020-03-06 08:40:39 --> Security Class Initialized
DEBUG - 2020-03-06 08:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 08:40:39 --> Input Class Initialized
INFO - 2020-03-06 08:40:39 --> Language Class Initialized
ERROR - 2020-03-06 08:40:39 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-06 08:40:43 --> Config Class Initialized
INFO - 2020-03-06 08:40:43 --> Hooks Class Initialized
DEBUG - 2020-03-06 08:40:43 --> UTF-8 Support Enabled
INFO - 2020-03-06 08:40:43 --> Utf8 Class Initialized
INFO - 2020-03-06 08:40:43 --> URI Class Initialized
INFO - 2020-03-06 08:40:43 --> Router Class Initialized
INFO - 2020-03-06 08:40:43 --> Output Class Initialized
INFO - 2020-03-06 08:40:43 --> Security Class Initialized
DEBUG - 2020-03-06 08:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 08:40:43 --> Input Class Initialized
INFO - 2020-03-06 08:40:43 --> Language Class Initialized
INFO - 2020-03-06 08:40:43 --> Loader Class Initialized
INFO - 2020-03-06 08:40:43 --> Helper loaded: url_helper
INFO - 2020-03-06 08:40:43 --> Helper loaded: string_helper
INFO - 2020-03-06 08:40:43 --> Database Driver Class Initialized
DEBUG - 2020-03-06 08:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 08:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 08:40:43 --> Controller Class Initialized
INFO - 2020-03-06 08:40:43 --> Model "M_tiket" initialized
INFO - 2020-03-06 08:40:43 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 08:40:43 --> Model "M_pesan" initialized
INFO - 2020-03-06 08:40:43 --> Helper loaded: form_helper
INFO - 2020-03-06 08:40:43 --> Form Validation Class Initialized
INFO - 2020-03-06 08:40:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 08:40:43 --> Final output sent to browser
DEBUG - 2020-03-06 08:40:43 --> Total execution time: 0.0118
INFO - 2020-03-06 08:47:44 --> Config Class Initialized
INFO - 2020-03-06 08:47:44 --> Hooks Class Initialized
DEBUG - 2020-03-06 08:47:44 --> UTF-8 Support Enabled
INFO - 2020-03-06 08:47:44 --> Utf8 Class Initialized
INFO - 2020-03-06 08:47:44 --> URI Class Initialized
DEBUG - 2020-03-06 08:47:44 --> No URI present. Default controller set.
INFO - 2020-03-06 08:47:44 --> Router Class Initialized
INFO - 2020-03-06 08:47:44 --> Output Class Initialized
INFO - 2020-03-06 08:47:44 --> Security Class Initialized
DEBUG - 2020-03-06 08:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 08:47:44 --> Input Class Initialized
INFO - 2020-03-06 08:47:44 --> Language Class Initialized
INFO - 2020-03-06 08:47:44 --> Loader Class Initialized
INFO - 2020-03-06 08:47:44 --> Helper loaded: url_helper
INFO - 2020-03-06 08:47:44 --> Helper loaded: string_helper
INFO - 2020-03-06 08:47:44 --> Database Driver Class Initialized
DEBUG - 2020-03-06 08:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 08:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 08:47:44 --> Controller Class Initialized
INFO - 2020-03-06 08:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 08:47:44 --> Pagination Class Initialized
INFO - 2020-03-06 08:47:44 --> Model "M_show" initialized
INFO - 2020-03-06 08:47:44 --> Helper loaded: form_helper
INFO - 2020-03-06 08:47:44 --> Form Validation Class Initialized
INFO - 2020-03-06 08:47:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 08:47:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 08:47:44 --> Final output sent to browser
DEBUG - 2020-03-06 08:47:44 --> Total execution time: 0.0520
INFO - 2020-03-06 08:52:16 --> Config Class Initialized
INFO - 2020-03-06 08:52:16 --> Hooks Class Initialized
DEBUG - 2020-03-06 08:52:16 --> UTF-8 Support Enabled
INFO - 2020-03-06 08:52:16 --> Utf8 Class Initialized
INFO - 2020-03-06 08:52:16 --> URI Class Initialized
DEBUG - 2020-03-06 08:52:16 --> No URI present. Default controller set.
INFO - 2020-03-06 08:52:16 --> Router Class Initialized
INFO - 2020-03-06 08:52:16 --> Output Class Initialized
INFO - 2020-03-06 08:52:16 --> Security Class Initialized
DEBUG - 2020-03-06 08:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 08:52:16 --> Input Class Initialized
INFO - 2020-03-06 08:52:16 --> Language Class Initialized
INFO - 2020-03-06 08:52:16 --> Loader Class Initialized
INFO - 2020-03-06 08:52:16 --> Helper loaded: url_helper
INFO - 2020-03-06 08:52:16 --> Helper loaded: string_helper
INFO - 2020-03-06 08:52:16 --> Database Driver Class Initialized
DEBUG - 2020-03-06 08:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 08:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 08:52:16 --> Controller Class Initialized
INFO - 2020-03-06 08:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 08:52:16 --> Pagination Class Initialized
INFO - 2020-03-06 08:52:16 --> Model "M_show" initialized
INFO - 2020-03-06 08:52:16 --> Helper loaded: form_helper
INFO - 2020-03-06 08:52:16 --> Form Validation Class Initialized
INFO - 2020-03-06 08:52:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 08:52:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 08:52:16 --> Final output sent to browser
DEBUG - 2020-03-06 08:52:16 --> Total execution time: 0.0350
INFO - 2020-03-06 08:52:22 --> Config Class Initialized
INFO - 2020-03-06 08:52:22 --> Hooks Class Initialized
DEBUG - 2020-03-06 08:52:22 --> UTF-8 Support Enabled
INFO - 2020-03-06 08:52:22 --> Utf8 Class Initialized
INFO - 2020-03-06 08:52:22 --> URI Class Initialized
INFO - 2020-03-06 08:52:22 --> Router Class Initialized
INFO - 2020-03-06 08:52:22 --> Output Class Initialized
INFO - 2020-03-06 08:52:22 --> Security Class Initialized
DEBUG - 2020-03-06 08:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 08:52:22 --> Input Class Initialized
INFO - 2020-03-06 08:52:22 --> Language Class Initialized
INFO - 2020-03-06 08:52:22 --> Loader Class Initialized
INFO - 2020-03-06 08:52:22 --> Helper loaded: url_helper
INFO - 2020-03-06 08:52:22 --> Helper loaded: string_helper
INFO - 2020-03-06 08:52:22 --> Database Driver Class Initialized
DEBUG - 2020-03-06 08:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 08:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 08:52:22 --> Controller Class Initialized
INFO - 2020-03-06 08:52:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 08:52:22 --> Pagination Class Initialized
INFO - 2020-03-06 08:52:22 --> Model "M_show" initialized
INFO - 2020-03-06 08:52:22 --> Helper loaded: form_helper
INFO - 2020-03-06 08:52:22 --> Form Validation Class Initialized
INFO - 2020-03-06 08:52:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 08:52:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 08:52:22 --> Final output sent to browser
DEBUG - 2020-03-06 08:52:22 --> Total execution time: 0.0083
INFO - 2020-03-06 08:52:28 --> Config Class Initialized
INFO - 2020-03-06 08:52:28 --> Hooks Class Initialized
DEBUG - 2020-03-06 08:52:28 --> UTF-8 Support Enabled
INFO - 2020-03-06 08:52:28 --> Utf8 Class Initialized
INFO - 2020-03-06 08:52:28 --> URI Class Initialized
INFO - 2020-03-06 08:52:28 --> Router Class Initialized
INFO - 2020-03-06 08:52:28 --> Output Class Initialized
INFO - 2020-03-06 08:52:28 --> Security Class Initialized
DEBUG - 2020-03-06 08:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 08:52:28 --> Input Class Initialized
INFO - 2020-03-06 08:52:28 --> Language Class Initialized
INFO - 2020-03-06 08:52:28 --> Loader Class Initialized
INFO - 2020-03-06 08:52:28 --> Helper loaded: url_helper
INFO - 2020-03-06 08:52:28 --> Helper loaded: string_helper
INFO - 2020-03-06 08:52:28 --> Database Driver Class Initialized
DEBUG - 2020-03-06 08:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 08:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 08:52:28 --> Controller Class Initialized
INFO - 2020-03-06 08:52:28 --> Model "M_tiket" initialized
INFO - 2020-03-06 08:52:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 08:52:28 --> Model "M_pesan" initialized
INFO - 2020-03-06 08:52:28 --> Helper loaded: form_helper
INFO - 2020-03-06 08:52:28 --> Form Validation Class Initialized
INFO - 2020-03-06 08:52:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 08:52:28 --> Final output sent to browser
DEBUG - 2020-03-06 08:52:28 --> Total execution time: 0.0110
INFO - 2020-03-06 08:53:27 --> Config Class Initialized
INFO - 2020-03-06 08:53:27 --> Hooks Class Initialized
DEBUG - 2020-03-06 08:53:27 --> UTF-8 Support Enabled
INFO - 2020-03-06 08:53:27 --> Utf8 Class Initialized
INFO - 2020-03-06 08:53:27 --> URI Class Initialized
DEBUG - 2020-03-06 08:53:27 --> No URI present. Default controller set.
INFO - 2020-03-06 08:53:27 --> Router Class Initialized
INFO - 2020-03-06 08:53:27 --> Output Class Initialized
INFO - 2020-03-06 08:53:27 --> Security Class Initialized
DEBUG - 2020-03-06 08:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 08:53:27 --> Input Class Initialized
INFO - 2020-03-06 08:53:27 --> Language Class Initialized
INFO - 2020-03-06 08:53:27 --> Loader Class Initialized
INFO - 2020-03-06 08:53:27 --> Helper loaded: url_helper
INFO - 2020-03-06 08:53:27 --> Helper loaded: string_helper
INFO - 2020-03-06 08:53:27 --> Database Driver Class Initialized
DEBUG - 2020-03-06 08:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 08:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 08:53:27 --> Controller Class Initialized
INFO - 2020-03-06 08:53:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 08:53:27 --> Pagination Class Initialized
INFO - 2020-03-06 08:53:27 --> Model "M_show" initialized
INFO - 2020-03-06 08:53:27 --> Helper loaded: form_helper
INFO - 2020-03-06 08:53:27 --> Form Validation Class Initialized
INFO - 2020-03-06 08:53:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 08:53:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 08:53:27 --> Final output sent to browser
DEBUG - 2020-03-06 08:53:27 --> Total execution time: 0.0055
INFO - 2020-03-06 09:15:08 --> Config Class Initialized
INFO - 2020-03-06 09:15:08 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:15:08 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:15:08 --> Utf8 Class Initialized
INFO - 2020-03-06 09:15:08 --> URI Class Initialized
DEBUG - 2020-03-06 09:15:08 --> No URI present. Default controller set.
INFO - 2020-03-06 09:15:08 --> Router Class Initialized
INFO - 2020-03-06 09:15:08 --> Output Class Initialized
INFO - 2020-03-06 09:15:08 --> Security Class Initialized
DEBUG - 2020-03-06 09:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:15:08 --> Input Class Initialized
INFO - 2020-03-06 09:15:08 --> Language Class Initialized
INFO - 2020-03-06 09:15:08 --> Loader Class Initialized
INFO - 2020-03-06 09:15:08 --> Helper loaded: url_helper
INFO - 2020-03-06 09:15:08 --> Helper loaded: string_helper
INFO - 2020-03-06 09:15:08 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:15:08 --> Controller Class Initialized
INFO - 2020-03-06 09:15:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:15:08 --> Pagination Class Initialized
INFO - 2020-03-06 09:15:08 --> Model "M_show" initialized
INFO - 2020-03-06 09:15:08 --> Helper loaded: form_helper
INFO - 2020-03-06 09:15:08 --> Form Validation Class Initialized
INFO - 2020-03-06 09:15:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:15:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:15:08 --> Final output sent to browser
DEBUG - 2020-03-06 09:15:08 --> Total execution time: 0.0711
INFO - 2020-03-06 09:15:19 --> Config Class Initialized
INFO - 2020-03-06 09:15:19 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:15:19 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:15:19 --> Utf8 Class Initialized
INFO - 2020-03-06 09:15:19 --> URI Class Initialized
DEBUG - 2020-03-06 09:15:19 --> No URI present. Default controller set.
INFO - 2020-03-06 09:15:19 --> Router Class Initialized
INFO - 2020-03-06 09:15:19 --> Output Class Initialized
INFO - 2020-03-06 09:15:19 --> Security Class Initialized
DEBUG - 2020-03-06 09:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:15:19 --> Input Class Initialized
INFO - 2020-03-06 09:15:19 --> Language Class Initialized
INFO - 2020-03-06 09:15:19 --> Loader Class Initialized
INFO - 2020-03-06 09:15:19 --> Helper loaded: url_helper
INFO - 2020-03-06 09:15:19 --> Helper loaded: string_helper
INFO - 2020-03-06 09:15:19 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:15:19 --> Controller Class Initialized
INFO - 2020-03-06 09:15:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:15:19 --> Pagination Class Initialized
INFO - 2020-03-06 09:15:19 --> Model "M_show" initialized
INFO - 2020-03-06 09:15:19 --> Helper loaded: form_helper
INFO - 2020-03-06 09:15:19 --> Form Validation Class Initialized
INFO - 2020-03-06 09:15:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:15:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:15:19 --> Final output sent to browser
DEBUG - 2020-03-06 09:15:19 --> Total execution time: 0.0056
INFO - 2020-03-06 09:15:29 --> Config Class Initialized
INFO - 2020-03-06 09:15:29 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:15:29 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:15:29 --> Utf8 Class Initialized
INFO - 2020-03-06 09:15:29 --> URI Class Initialized
INFO - 2020-03-06 09:15:29 --> Router Class Initialized
INFO - 2020-03-06 09:15:29 --> Output Class Initialized
INFO - 2020-03-06 09:15:29 --> Security Class Initialized
DEBUG - 2020-03-06 09:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:15:29 --> Input Class Initialized
INFO - 2020-03-06 09:15:29 --> Language Class Initialized
INFO - 2020-03-06 09:15:29 --> Loader Class Initialized
INFO - 2020-03-06 09:15:29 --> Helper loaded: url_helper
INFO - 2020-03-06 09:15:29 --> Helper loaded: string_helper
INFO - 2020-03-06 09:15:29 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:15:29 --> Controller Class Initialized
INFO - 2020-03-06 09:15:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:15:29 --> Pagination Class Initialized
INFO - 2020-03-06 09:15:29 --> Model "M_show" initialized
INFO - 2020-03-06 09:15:29 --> Helper loaded: form_helper
INFO - 2020-03-06 09:15:29 --> Form Validation Class Initialized
INFO - 2020-03-06 09:15:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:15:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 09:15:29 --> Final output sent to browser
DEBUG - 2020-03-06 09:15:29 --> Total execution time: 0.0100
INFO - 2020-03-06 09:15:30 --> Config Class Initialized
INFO - 2020-03-06 09:15:30 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:15:30 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:15:30 --> Utf8 Class Initialized
INFO - 2020-03-06 09:15:30 --> URI Class Initialized
INFO - 2020-03-06 09:15:30 --> Router Class Initialized
INFO - 2020-03-06 09:15:30 --> Output Class Initialized
INFO - 2020-03-06 09:15:30 --> Security Class Initialized
DEBUG - 2020-03-06 09:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:15:30 --> Input Class Initialized
INFO - 2020-03-06 09:15:30 --> Language Class Initialized
ERROR - 2020-03-06 09:15:30 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-06 09:15:36 --> Config Class Initialized
INFO - 2020-03-06 09:15:36 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:15:36 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:15:36 --> Utf8 Class Initialized
INFO - 2020-03-06 09:15:36 --> URI Class Initialized
INFO - 2020-03-06 09:15:36 --> Router Class Initialized
INFO - 2020-03-06 09:15:36 --> Output Class Initialized
INFO - 2020-03-06 09:15:36 --> Security Class Initialized
DEBUG - 2020-03-06 09:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:15:36 --> Input Class Initialized
INFO - 2020-03-06 09:15:36 --> Language Class Initialized
INFO - 2020-03-06 09:15:36 --> Loader Class Initialized
INFO - 2020-03-06 09:15:36 --> Helper loaded: url_helper
INFO - 2020-03-06 09:15:36 --> Helper loaded: string_helper
INFO - 2020-03-06 09:15:36 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:15:36 --> Controller Class Initialized
INFO - 2020-03-06 09:15:36 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:15:36 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:15:36 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:15:36 --> Helper loaded: form_helper
INFO - 2020-03-06 09:15:36 --> Form Validation Class Initialized
INFO - 2020-03-06 09:15:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 09:15:36 --> Final output sent to browser
DEBUG - 2020-03-06 09:15:36 --> Total execution time: 0.0103
INFO - 2020-03-06 09:15:58 --> Config Class Initialized
INFO - 2020-03-06 09:15:58 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:15:58 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:15:58 --> Utf8 Class Initialized
INFO - 2020-03-06 09:15:58 --> URI Class Initialized
DEBUG - 2020-03-06 09:15:58 --> No URI present. Default controller set.
INFO - 2020-03-06 09:15:58 --> Router Class Initialized
INFO - 2020-03-06 09:15:58 --> Output Class Initialized
INFO - 2020-03-06 09:15:58 --> Security Class Initialized
DEBUG - 2020-03-06 09:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:15:58 --> Input Class Initialized
INFO - 2020-03-06 09:15:58 --> Language Class Initialized
INFO - 2020-03-06 09:15:58 --> Loader Class Initialized
INFO - 2020-03-06 09:15:58 --> Helper loaded: url_helper
INFO - 2020-03-06 09:15:58 --> Helper loaded: string_helper
INFO - 2020-03-06 09:15:58 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:15:58 --> Controller Class Initialized
INFO - 2020-03-06 09:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:15:58 --> Pagination Class Initialized
INFO - 2020-03-06 09:15:58 --> Model "M_show" initialized
INFO - 2020-03-06 09:15:58 --> Helper loaded: form_helper
INFO - 2020-03-06 09:15:58 --> Form Validation Class Initialized
INFO - 2020-03-06 09:15:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:15:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:15:58 --> Final output sent to browser
DEBUG - 2020-03-06 09:15:58 --> Total execution time: 0.0294
INFO - 2020-03-06 09:16:00 --> Config Class Initialized
INFO - 2020-03-06 09:16:00 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:16:00 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:16:00 --> Utf8 Class Initialized
INFO - 2020-03-06 09:16:00 --> URI Class Initialized
DEBUG - 2020-03-06 09:16:00 --> No URI present. Default controller set.
INFO - 2020-03-06 09:16:00 --> Router Class Initialized
INFO - 2020-03-06 09:16:00 --> Output Class Initialized
INFO - 2020-03-06 09:16:00 --> Security Class Initialized
DEBUG - 2020-03-06 09:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:16:00 --> Input Class Initialized
INFO - 2020-03-06 09:16:00 --> Language Class Initialized
INFO - 2020-03-06 09:16:00 --> Loader Class Initialized
INFO - 2020-03-06 09:16:00 --> Helper loaded: url_helper
INFO - 2020-03-06 09:16:00 --> Helper loaded: string_helper
INFO - 2020-03-06 09:16:00 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:16:00 --> Controller Class Initialized
INFO - 2020-03-06 09:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:16:00 --> Pagination Class Initialized
INFO - 2020-03-06 09:16:00 --> Model "M_show" initialized
INFO - 2020-03-06 09:16:00 --> Helper loaded: form_helper
INFO - 2020-03-06 09:16:00 --> Form Validation Class Initialized
INFO - 2020-03-06 09:16:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:16:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:16:00 --> Final output sent to browser
DEBUG - 2020-03-06 09:16:00 --> Total execution time: 0.0080
INFO - 2020-03-06 09:16:01 --> Config Class Initialized
INFO - 2020-03-06 09:16:01 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:16:01 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:16:01 --> Utf8 Class Initialized
INFO - 2020-03-06 09:16:01 --> URI Class Initialized
DEBUG - 2020-03-06 09:16:01 --> No URI present. Default controller set.
INFO - 2020-03-06 09:16:01 --> Router Class Initialized
INFO - 2020-03-06 09:16:01 --> Output Class Initialized
INFO - 2020-03-06 09:16:01 --> Security Class Initialized
DEBUG - 2020-03-06 09:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:16:01 --> Input Class Initialized
INFO - 2020-03-06 09:16:01 --> Language Class Initialized
INFO - 2020-03-06 09:16:01 --> Loader Class Initialized
INFO - 2020-03-06 09:16:01 --> Helper loaded: url_helper
INFO - 2020-03-06 09:16:01 --> Helper loaded: string_helper
INFO - 2020-03-06 09:16:01 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:16:01 --> Controller Class Initialized
INFO - 2020-03-06 09:16:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:16:01 --> Pagination Class Initialized
INFO - 2020-03-06 09:16:01 --> Model "M_show" initialized
INFO - 2020-03-06 09:16:01 --> Helper loaded: form_helper
INFO - 2020-03-06 09:16:01 --> Form Validation Class Initialized
INFO - 2020-03-06 09:16:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:16:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:16:01 --> Final output sent to browser
DEBUG - 2020-03-06 09:16:01 --> Total execution time: 0.0223
INFO - 2020-03-06 09:16:51 --> Config Class Initialized
INFO - 2020-03-06 09:16:51 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:16:51 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:16:51 --> Utf8 Class Initialized
INFO - 2020-03-06 09:16:51 --> URI Class Initialized
DEBUG - 2020-03-06 09:16:51 --> No URI present. Default controller set.
INFO - 2020-03-06 09:16:51 --> Router Class Initialized
INFO - 2020-03-06 09:16:51 --> Output Class Initialized
INFO - 2020-03-06 09:16:51 --> Security Class Initialized
DEBUG - 2020-03-06 09:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:16:51 --> Input Class Initialized
INFO - 2020-03-06 09:16:51 --> Language Class Initialized
INFO - 2020-03-06 09:16:51 --> Loader Class Initialized
INFO - 2020-03-06 09:16:51 --> Helper loaded: url_helper
INFO - 2020-03-06 09:16:51 --> Helper loaded: string_helper
INFO - 2020-03-06 09:16:51 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:16:51 --> Controller Class Initialized
INFO - 2020-03-06 09:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:16:51 --> Pagination Class Initialized
INFO - 2020-03-06 09:16:51 --> Model "M_show" initialized
INFO - 2020-03-06 09:16:51 --> Helper loaded: form_helper
INFO - 2020-03-06 09:16:51 --> Form Validation Class Initialized
INFO - 2020-03-06 09:16:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:16:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:16:51 --> Final output sent to browser
DEBUG - 2020-03-06 09:16:51 --> Total execution time: 0.0052
INFO - 2020-03-06 09:17:18 --> Config Class Initialized
INFO - 2020-03-06 09:17:18 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:17:18 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:17:18 --> Utf8 Class Initialized
INFO - 2020-03-06 09:17:18 --> URI Class Initialized
DEBUG - 2020-03-06 09:17:18 --> No URI present. Default controller set.
INFO - 2020-03-06 09:17:18 --> Router Class Initialized
INFO - 2020-03-06 09:17:18 --> Output Class Initialized
INFO - 2020-03-06 09:17:18 --> Security Class Initialized
DEBUG - 2020-03-06 09:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:17:18 --> Input Class Initialized
INFO - 2020-03-06 09:17:18 --> Language Class Initialized
INFO - 2020-03-06 09:17:18 --> Loader Class Initialized
INFO - 2020-03-06 09:17:18 --> Helper loaded: url_helper
INFO - 2020-03-06 09:17:18 --> Helper loaded: string_helper
INFO - 2020-03-06 09:17:18 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:17:18 --> Controller Class Initialized
INFO - 2020-03-06 09:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:17:18 --> Pagination Class Initialized
INFO - 2020-03-06 09:17:18 --> Model "M_show" initialized
INFO - 2020-03-06 09:17:18 --> Helper loaded: form_helper
INFO - 2020-03-06 09:17:18 --> Form Validation Class Initialized
INFO - 2020-03-06 09:17:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:17:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:17:18 --> Final output sent to browser
DEBUG - 2020-03-06 09:17:18 --> Total execution time: 0.0070
INFO - 2020-03-06 09:17:27 --> Config Class Initialized
INFO - 2020-03-06 09:17:27 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:17:27 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:17:27 --> Utf8 Class Initialized
INFO - 2020-03-06 09:17:27 --> URI Class Initialized
DEBUG - 2020-03-06 09:17:27 --> No URI present. Default controller set.
INFO - 2020-03-06 09:17:27 --> Router Class Initialized
INFO - 2020-03-06 09:17:27 --> Output Class Initialized
INFO - 2020-03-06 09:17:27 --> Security Class Initialized
DEBUG - 2020-03-06 09:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:17:27 --> Input Class Initialized
INFO - 2020-03-06 09:17:27 --> Language Class Initialized
INFO - 2020-03-06 09:17:27 --> Loader Class Initialized
INFO - 2020-03-06 09:17:27 --> Helper loaded: url_helper
INFO - 2020-03-06 09:17:27 --> Helper loaded: string_helper
INFO - 2020-03-06 09:17:27 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:17:27 --> Controller Class Initialized
INFO - 2020-03-06 09:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:17:27 --> Pagination Class Initialized
INFO - 2020-03-06 09:17:27 --> Model "M_show" initialized
INFO - 2020-03-06 09:17:27 --> Helper loaded: form_helper
INFO - 2020-03-06 09:17:27 --> Form Validation Class Initialized
INFO - 2020-03-06 09:17:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:17:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:17:27 --> Final output sent to browser
DEBUG - 2020-03-06 09:17:27 --> Total execution time: 0.0247
INFO - 2020-03-06 09:17:29 --> Config Class Initialized
INFO - 2020-03-06 09:17:29 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:17:29 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:17:29 --> Utf8 Class Initialized
INFO - 2020-03-06 09:17:29 --> URI Class Initialized
DEBUG - 2020-03-06 09:17:29 --> No URI present. Default controller set.
INFO - 2020-03-06 09:17:29 --> Router Class Initialized
INFO - 2020-03-06 09:17:29 --> Output Class Initialized
INFO - 2020-03-06 09:17:29 --> Security Class Initialized
DEBUG - 2020-03-06 09:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:17:29 --> Input Class Initialized
INFO - 2020-03-06 09:17:29 --> Language Class Initialized
INFO - 2020-03-06 09:17:29 --> Loader Class Initialized
INFO - 2020-03-06 09:17:29 --> Helper loaded: url_helper
INFO - 2020-03-06 09:17:29 --> Helper loaded: string_helper
INFO - 2020-03-06 09:17:29 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:17:29 --> Controller Class Initialized
INFO - 2020-03-06 09:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:17:29 --> Pagination Class Initialized
INFO - 2020-03-06 09:17:29 --> Model "M_show" initialized
INFO - 2020-03-06 09:17:29 --> Helper loaded: form_helper
INFO - 2020-03-06 09:17:29 --> Form Validation Class Initialized
INFO - 2020-03-06 09:17:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:17:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:17:29 --> Final output sent to browser
DEBUG - 2020-03-06 09:17:29 --> Total execution time: 0.0055
INFO - 2020-03-06 09:17:44 --> Config Class Initialized
INFO - 2020-03-06 09:17:44 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:17:44 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:17:44 --> Utf8 Class Initialized
INFO - 2020-03-06 09:17:44 --> URI Class Initialized
INFO - 2020-03-06 09:17:44 --> Router Class Initialized
INFO - 2020-03-06 09:17:44 --> Output Class Initialized
INFO - 2020-03-06 09:17:44 --> Security Class Initialized
DEBUG - 2020-03-06 09:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:17:44 --> Input Class Initialized
INFO - 2020-03-06 09:17:44 --> Language Class Initialized
INFO - 2020-03-06 09:17:44 --> Loader Class Initialized
INFO - 2020-03-06 09:17:44 --> Helper loaded: url_helper
INFO - 2020-03-06 09:17:44 --> Helper loaded: string_helper
INFO - 2020-03-06 09:17:44 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:17:44 --> Controller Class Initialized
INFO - 2020-03-06 09:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:17:44 --> Pagination Class Initialized
INFO - 2020-03-06 09:17:44 --> Model "M_show" initialized
INFO - 2020-03-06 09:17:44 --> Helper loaded: form_helper
INFO - 2020-03-06 09:17:44 --> Form Validation Class Initialized
INFO - 2020-03-06 09:17:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:17:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 09:17:44 --> Final output sent to browser
DEBUG - 2020-03-06 09:17:44 --> Total execution time: 0.0066
INFO - 2020-03-06 09:17:48 --> Config Class Initialized
INFO - 2020-03-06 09:17:48 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:17:48 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:17:48 --> Utf8 Class Initialized
INFO - 2020-03-06 09:17:48 --> URI Class Initialized
INFO - 2020-03-06 09:17:48 --> Router Class Initialized
INFO - 2020-03-06 09:17:48 --> Output Class Initialized
INFO - 2020-03-06 09:17:48 --> Security Class Initialized
DEBUG - 2020-03-06 09:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:17:48 --> Input Class Initialized
INFO - 2020-03-06 09:17:48 --> Language Class Initialized
INFO - 2020-03-06 09:17:48 --> Loader Class Initialized
INFO - 2020-03-06 09:17:48 --> Helper loaded: url_helper
INFO - 2020-03-06 09:17:48 --> Helper loaded: string_helper
INFO - 2020-03-06 09:17:48 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:17:48 --> Controller Class Initialized
INFO - 2020-03-06 09:17:48 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:17:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:17:48 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:17:48 --> Helper loaded: form_helper
INFO - 2020-03-06 09:17:48 --> Form Validation Class Initialized
INFO - 2020-03-06 09:17:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 09:17:48 --> Final output sent to browser
DEBUG - 2020-03-06 09:17:48 --> Total execution time: 0.0112
INFO - 2020-03-06 09:17:52 --> Config Class Initialized
INFO - 2020-03-06 09:17:52 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:17:52 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:17:52 --> Utf8 Class Initialized
INFO - 2020-03-06 09:17:52 --> URI Class Initialized
DEBUG - 2020-03-06 09:17:52 --> No URI present. Default controller set.
INFO - 2020-03-06 09:17:52 --> Router Class Initialized
INFO - 2020-03-06 09:17:52 --> Output Class Initialized
INFO - 2020-03-06 09:17:52 --> Security Class Initialized
DEBUG - 2020-03-06 09:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:17:52 --> Input Class Initialized
INFO - 2020-03-06 09:17:52 --> Language Class Initialized
INFO - 2020-03-06 09:17:52 --> Loader Class Initialized
INFO - 2020-03-06 09:17:52 --> Helper loaded: url_helper
INFO - 2020-03-06 09:17:52 --> Helper loaded: string_helper
INFO - 2020-03-06 09:17:52 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:17:52 --> Controller Class Initialized
INFO - 2020-03-06 09:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:17:52 --> Pagination Class Initialized
INFO - 2020-03-06 09:17:52 --> Model "M_show" initialized
INFO - 2020-03-06 09:17:52 --> Helper loaded: form_helper
INFO - 2020-03-06 09:17:52 --> Form Validation Class Initialized
INFO - 2020-03-06 09:17:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:17:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:17:52 --> Final output sent to browser
DEBUG - 2020-03-06 09:17:52 --> Total execution time: 0.0054
INFO - 2020-03-06 09:18:08 --> Config Class Initialized
INFO - 2020-03-06 09:18:08 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:18:08 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:18:08 --> Utf8 Class Initialized
INFO - 2020-03-06 09:18:08 --> URI Class Initialized
INFO - 2020-03-06 09:18:08 --> Router Class Initialized
INFO - 2020-03-06 09:18:08 --> Output Class Initialized
INFO - 2020-03-06 09:18:08 --> Security Class Initialized
DEBUG - 2020-03-06 09:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:18:08 --> Input Class Initialized
INFO - 2020-03-06 09:18:08 --> Language Class Initialized
INFO - 2020-03-06 09:18:08 --> Loader Class Initialized
INFO - 2020-03-06 09:18:08 --> Helper loaded: url_helper
INFO - 2020-03-06 09:18:08 --> Helper loaded: string_helper
INFO - 2020-03-06 09:18:08 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:18:08 --> Controller Class Initialized
INFO - 2020-03-06 09:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:18:08 --> Pagination Class Initialized
INFO - 2020-03-06 09:18:08 --> Model "M_show" initialized
INFO - 2020-03-06 09:18:08 --> Helper loaded: form_helper
INFO - 2020-03-06 09:18:08 --> Form Validation Class Initialized
INFO - 2020-03-06 09:18:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:18:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-06 09:18:08 --> Final output sent to browser
DEBUG - 2020-03-06 09:18:08 --> Total execution time: 0.0217
INFO - 2020-03-06 09:18:14 --> Config Class Initialized
INFO - 2020-03-06 09:18:14 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:18:14 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:18:14 --> Utf8 Class Initialized
INFO - 2020-03-06 09:18:14 --> URI Class Initialized
INFO - 2020-03-06 09:18:14 --> Router Class Initialized
INFO - 2020-03-06 09:18:14 --> Output Class Initialized
INFO - 2020-03-06 09:18:14 --> Security Class Initialized
DEBUG - 2020-03-06 09:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:18:14 --> Input Class Initialized
INFO - 2020-03-06 09:18:14 --> Language Class Initialized
INFO - 2020-03-06 09:18:14 --> Loader Class Initialized
INFO - 2020-03-06 09:18:14 --> Helper loaded: url_helper
INFO - 2020-03-06 09:18:14 --> Helper loaded: string_helper
INFO - 2020-03-06 09:18:14 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:18:14 --> Controller Class Initialized
INFO - 2020-03-06 09:18:14 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:18:14 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:18:14 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:18:14 --> Helper loaded: form_helper
INFO - 2020-03-06 09:18:14 --> Form Validation Class Initialized
INFO - 2020-03-06 09:18:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 09:18:14 --> Final output sent to browser
DEBUG - 2020-03-06 09:18:14 --> Total execution time: 0.0070
INFO - 2020-03-06 09:18:30 --> Config Class Initialized
INFO - 2020-03-06 09:18:30 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:18:30 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:18:30 --> Utf8 Class Initialized
INFO - 2020-03-06 09:18:30 --> URI Class Initialized
INFO - 2020-03-06 09:18:30 --> Router Class Initialized
INFO - 2020-03-06 09:18:30 --> Output Class Initialized
INFO - 2020-03-06 09:18:30 --> Security Class Initialized
DEBUG - 2020-03-06 09:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:18:30 --> Input Class Initialized
INFO - 2020-03-06 09:18:30 --> Language Class Initialized
INFO - 2020-03-06 09:18:30 --> Loader Class Initialized
INFO - 2020-03-06 09:18:30 --> Helper loaded: url_helper
INFO - 2020-03-06 09:18:30 --> Helper loaded: string_helper
INFO - 2020-03-06 09:18:30 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:18:30 --> Controller Class Initialized
INFO - 2020-03-06 09:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:18:30 --> Pagination Class Initialized
INFO - 2020-03-06 09:18:30 --> Model "M_show" initialized
INFO - 2020-03-06 09:18:30 --> Helper loaded: form_helper
INFO - 2020-03-06 09:18:30 --> Form Validation Class Initialized
INFO - 2020-03-06 09:18:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:18:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 09:18:30 --> Final output sent to browser
DEBUG - 2020-03-06 09:18:30 --> Total execution time: 0.0997
INFO - 2020-03-06 09:18:41 --> Config Class Initialized
INFO - 2020-03-06 09:18:41 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:18:41 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:18:41 --> Utf8 Class Initialized
INFO - 2020-03-06 09:18:41 --> URI Class Initialized
INFO - 2020-03-06 09:18:41 --> Router Class Initialized
INFO - 2020-03-06 09:18:41 --> Output Class Initialized
INFO - 2020-03-06 09:18:41 --> Security Class Initialized
DEBUG - 2020-03-06 09:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:18:41 --> Input Class Initialized
INFO - 2020-03-06 09:18:41 --> Language Class Initialized
INFO - 2020-03-06 09:18:41 --> Loader Class Initialized
INFO - 2020-03-06 09:18:41 --> Helper loaded: url_helper
INFO - 2020-03-06 09:18:41 --> Helper loaded: string_helper
INFO - 2020-03-06 09:18:41 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:18:41 --> Controller Class Initialized
INFO - 2020-03-06 09:18:41 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:18:41 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:18:41 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:18:41 --> Helper loaded: form_helper
INFO - 2020-03-06 09:18:41 --> Form Validation Class Initialized
INFO - 2020-03-06 09:18:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 09:18:41 --> Final output sent to browser
DEBUG - 2020-03-06 09:18:41 --> Total execution time: 0.0290
INFO - 2020-03-06 09:18:57 --> Config Class Initialized
INFO - 2020-03-06 09:18:57 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:18:57 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:18:57 --> Utf8 Class Initialized
INFO - 2020-03-06 09:18:57 --> URI Class Initialized
INFO - 2020-03-06 09:18:57 --> Router Class Initialized
INFO - 2020-03-06 09:18:57 --> Output Class Initialized
INFO - 2020-03-06 09:18:57 --> Security Class Initialized
DEBUG - 2020-03-06 09:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:18:57 --> Input Class Initialized
INFO - 2020-03-06 09:18:57 --> Language Class Initialized
INFO - 2020-03-06 09:18:57 --> Loader Class Initialized
INFO - 2020-03-06 09:18:57 --> Helper loaded: url_helper
INFO - 2020-03-06 09:18:57 --> Helper loaded: string_helper
INFO - 2020-03-06 09:18:57 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:18:57 --> Controller Class Initialized
INFO - 2020-03-06 09:18:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:18:57 --> Pagination Class Initialized
INFO - 2020-03-06 09:18:57 --> Model "M_show" initialized
INFO - 2020-03-06 09:18:57 --> Helper loaded: form_helper
INFO - 2020-03-06 09:18:57 --> Form Validation Class Initialized
INFO - 2020-03-06 09:18:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:18:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 09:18:57 --> Final output sent to browser
DEBUG - 2020-03-06 09:18:57 --> Total execution time: 0.0060
INFO - 2020-03-06 09:18:58 --> Config Class Initialized
INFO - 2020-03-06 09:18:58 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:18:58 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:18:58 --> Utf8 Class Initialized
INFO - 2020-03-06 09:18:58 --> URI Class Initialized
INFO - 2020-03-06 09:18:58 --> Router Class Initialized
INFO - 2020-03-06 09:18:58 --> Output Class Initialized
INFO - 2020-03-06 09:18:58 --> Security Class Initialized
DEBUG - 2020-03-06 09:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:18:58 --> Input Class Initialized
INFO - 2020-03-06 09:18:58 --> Language Class Initialized
INFO - 2020-03-06 09:18:58 --> Loader Class Initialized
INFO - 2020-03-06 09:18:58 --> Helper loaded: url_helper
INFO - 2020-03-06 09:18:58 --> Helper loaded: string_helper
INFO - 2020-03-06 09:18:58 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:18:58 --> Controller Class Initialized
INFO - 2020-03-06 09:18:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:18:58 --> Pagination Class Initialized
INFO - 2020-03-06 09:18:58 --> Model "M_show" initialized
INFO - 2020-03-06 09:18:58 --> Helper loaded: form_helper
INFO - 2020-03-06 09:18:58 --> Form Validation Class Initialized
INFO - 2020-03-06 09:18:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:18:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-06 09:18:58 --> Final output sent to browser
DEBUG - 2020-03-06 09:18:58 --> Total execution time: 0.0063
INFO - 2020-03-06 09:19:01 --> Config Class Initialized
INFO - 2020-03-06 09:19:01 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:19:01 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:19:01 --> Utf8 Class Initialized
INFO - 2020-03-06 09:19:01 --> URI Class Initialized
INFO - 2020-03-06 09:19:01 --> Router Class Initialized
INFO - 2020-03-06 09:19:01 --> Output Class Initialized
INFO - 2020-03-06 09:19:01 --> Security Class Initialized
DEBUG - 2020-03-06 09:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:19:01 --> Input Class Initialized
INFO - 2020-03-06 09:19:01 --> Language Class Initialized
INFO - 2020-03-06 09:19:01 --> Loader Class Initialized
INFO - 2020-03-06 09:19:01 --> Helper loaded: url_helper
INFO - 2020-03-06 09:19:01 --> Helper loaded: string_helper
INFO - 2020-03-06 09:19:01 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:19:01 --> Controller Class Initialized
INFO - 2020-03-06 09:19:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:19:01 --> Pagination Class Initialized
INFO - 2020-03-06 09:19:01 --> Model "M_show" initialized
INFO - 2020-03-06 09:19:01 --> Helper loaded: form_helper
INFO - 2020-03-06 09:19:01 --> Form Validation Class Initialized
INFO - 2020-03-06 09:19:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:19:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 09:19:01 --> Final output sent to browser
DEBUG - 2020-03-06 09:19:01 --> Total execution time: 0.0297
INFO - 2020-03-06 09:19:17 --> Config Class Initialized
INFO - 2020-03-06 09:19:17 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:19:17 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:19:17 --> Utf8 Class Initialized
INFO - 2020-03-06 09:19:17 --> URI Class Initialized
INFO - 2020-03-06 09:19:17 --> Router Class Initialized
INFO - 2020-03-06 09:19:17 --> Output Class Initialized
INFO - 2020-03-06 09:19:17 --> Security Class Initialized
DEBUG - 2020-03-06 09:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:19:17 --> Input Class Initialized
INFO - 2020-03-06 09:19:17 --> Language Class Initialized
INFO - 2020-03-06 09:19:17 --> Loader Class Initialized
INFO - 2020-03-06 09:19:17 --> Helper loaded: url_helper
INFO - 2020-03-06 09:19:17 --> Helper loaded: string_helper
INFO - 2020-03-06 09:19:17 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:19:17 --> Controller Class Initialized
INFO - 2020-03-06 09:19:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:19:17 --> Pagination Class Initialized
INFO - 2020-03-06 09:19:17 --> Model "M_show" initialized
INFO - 2020-03-06 09:19:17 --> Helper loaded: form_helper
INFO - 2020-03-06 09:19:17 --> Form Validation Class Initialized
INFO - 2020-03-06 09:19:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:19:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-06 09:19:17 --> Final output sent to browser
DEBUG - 2020-03-06 09:19:17 --> Total execution time: 0.0056
INFO - 2020-03-06 09:19:36 --> Config Class Initialized
INFO - 2020-03-06 09:19:36 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:19:36 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:19:36 --> Utf8 Class Initialized
INFO - 2020-03-06 09:19:36 --> URI Class Initialized
DEBUG - 2020-03-06 09:19:36 --> No URI present. Default controller set.
INFO - 2020-03-06 09:19:36 --> Router Class Initialized
INFO - 2020-03-06 09:19:36 --> Output Class Initialized
INFO - 2020-03-06 09:19:36 --> Security Class Initialized
DEBUG - 2020-03-06 09:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:19:36 --> Input Class Initialized
INFO - 2020-03-06 09:19:36 --> Language Class Initialized
INFO - 2020-03-06 09:19:36 --> Loader Class Initialized
INFO - 2020-03-06 09:19:36 --> Helper loaded: url_helper
INFO - 2020-03-06 09:19:36 --> Helper loaded: string_helper
INFO - 2020-03-06 09:19:36 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:19:36 --> Controller Class Initialized
INFO - 2020-03-06 09:19:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:19:36 --> Pagination Class Initialized
INFO - 2020-03-06 09:19:36 --> Model "M_show" initialized
INFO - 2020-03-06 09:19:36 --> Helper loaded: form_helper
INFO - 2020-03-06 09:19:36 --> Form Validation Class Initialized
INFO - 2020-03-06 09:19:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:19:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:19:36 --> Final output sent to browser
DEBUG - 2020-03-06 09:19:36 --> Total execution time: 0.0430
INFO - 2020-03-06 09:19:41 --> Config Class Initialized
INFO - 2020-03-06 09:19:41 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:19:41 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:19:41 --> Utf8 Class Initialized
INFO - 2020-03-06 09:19:41 --> URI Class Initialized
INFO - 2020-03-06 09:19:41 --> Router Class Initialized
INFO - 2020-03-06 09:19:41 --> Output Class Initialized
INFO - 2020-03-06 09:19:41 --> Security Class Initialized
DEBUG - 2020-03-06 09:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:19:41 --> Input Class Initialized
INFO - 2020-03-06 09:19:41 --> Language Class Initialized
INFO - 2020-03-06 09:19:41 --> Loader Class Initialized
INFO - 2020-03-06 09:19:41 --> Helper loaded: url_helper
INFO - 2020-03-06 09:19:41 --> Helper loaded: string_helper
INFO - 2020-03-06 09:19:41 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:19:41 --> Controller Class Initialized
INFO - 2020-03-06 09:19:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:19:41 --> Pagination Class Initialized
INFO - 2020-03-06 09:19:41 --> Model "M_show" initialized
INFO - 2020-03-06 09:19:41 --> Helper loaded: form_helper
INFO - 2020-03-06 09:19:41 --> Form Validation Class Initialized
INFO - 2020-03-06 09:19:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:19:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-06 09:19:41 --> Final output sent to browser
DEBUG - 2020-03-06 09:19:41 --> Total execution time: 0.1758
INFO - 2020-03-06 09:19:47 --> Config Class Initialized
INFO - 2020-03-06 09:19:47 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:19:47 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:19:47 --> Utf8 Class Initialized
INFO - 2020-03-06 09:19:47 --> URI Class Initialized
INFO - 2020-03-06 09:19:47 --> Router Class Initialized
INFO - 2020-03-06 09:19:47 --> Output Class Initialized
INFO - 2020-03-06 09:19:47 --> Security Class Initialized
DEBUG - 2020-03-06 09:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:19:47 --> Input Class Initialized
INFO - 2020-03-06 09:19:47 --> Language Class Initialized
INFO - 2020-03-06 09:19:47 --> Loader Class Initialized
INFO - 2020-03-06 09:19:47 --> Helper loaded: url_helper
INFO - 2020-03-06 09:19:47 --> Helper loaded: string_helper
INFO - 2020-03-06 09:19:47 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:19:47 --> Controller Class Initialized
INFO - 2020-03-06 09:19:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:19:47 --> Pagination Class Initialized
INFO - 2020-03-06 09:19:47 --> Model "M_show" initialized
INFO - 2020-03-06 09:19:47 --> Helper loaded: form_helper
INFO - 2020-03-06 09:19:47 --> Form Validation Class Initialized
INFO - 2020-03-06 09:19:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:19:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 09:19:47 --> Final output sent to browser
DEBUG - 2020-03-06 09:19:47 --> Total execution time: 0.0345
INFO - 2020-03-06 09:19:53 --> Config Class Initialized
INFO - 2020-03-06 09:19:53 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:19:53 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:19:53 --> Utf8 Class Initialized
INFO - 2020-03-06 09:19:53 --> URI Class Initialized
INFO - 2020-03-06 09:19:53 --> Router Class Initialized
INFO - 2020-03-06 09:19:53 --> Output Class Initialized
INFO - 2020-03-06 09:19:53 --> Security Class Initialized
DEBUG - 2020-03-06 09:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:19:53 --> Input Class Initialized
INFO - 2020-03-06 09:19:53 --> Language Class Initialized
INFO - 2020-03-06 09:19:53 --> Loader Class Initialized
INFO - 2020-03-06 09:19:53 --> Helper loaded: url_helper
INFO - 2020-03-06 09:19:53 --> Helper loaded: string_helper
INFO - 2020-03-06 09:19:53 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:19:53 --> Controller Class Initialized
INFO - 2020-03-06 09:19:53 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:19:53 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:19:53 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:19:53 --> Helper loaded: form_helper
INFO - 2020-03-06 09:19:53 --> Form Validation Class Initialized
INFO - 2020-03-06 09:19:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 09:19:53 --> Final output sent to browser
DEBUG - 2020-03-06 09:19:53 --> Total execution time: 0.0515
INFO - 2020-03-06 09:20:15 --> Config Class Initialized
INFO - 2020-03-06 09:20:15 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:20:15 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:20:15 --> Utf8 Class Initialized
INFO - 2020-03-06 09:20:15 --> URI Class Initialized
INFO - 2020-03-06 09:20:15 --> Router Class Initialized
INFO - 2020-03-06 09:20:15 --> Output Class Initialized
INFO - 2020-03-06 09:20:15 --> Security Class Initialized
DEBUG - 2020-03-06 09:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:20:15 --> Input Class Initialized
INFO - 2020-03-06 09:20:15 --> Language Class Initialized
INFO - 2020-03-06 09:20:15 --> Loader Class Initialized
INFO - 2020-03-06 09:20:15 --> Helper loaded: url_helper
INFO - 2020-03-06 09:20:15 --> Helper loaded: string_helper
INFO - 2020-03-06 09:20:15 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:20:15 --> Controller Class Initialized
INFO - 2020-03-06 09:20:15 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:20:15 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:20:15 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:20:15 --> Helper loaded: form_helper
INFO - 2020-03-06 09:20:15 --> Form Validation Class Initialized
INFO - 2020-03-06 09:20:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 09:20:15 --> Final output sent to browser
DEBUG - 2020-03-06 09:20:15 --> Total execution time: 0.0079
INFO - 2020-03-06 09:21:01 --> Config Class Initialized
INFO - 2020-03-06 09:21:01 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:21:01 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:21:01 --> Utf8 Class Initialized
INFO - 2020-03-06 09:21:01 --> URI Class Initialized
DEBUG - 2020-03-06 09:21:01 --> No URI present. Default controller set.
INFO - 2020-03-06 09:21:01 --> Router Class Initialized
INFO - 2020-03-06 09:21:01 --> Output Class Initialized
INFO - 2020-03-06 09:21:01 --> Security Class Initialized
DEBUG - 2020-03-06 09:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:21:01 --> Input Class Initialized
INFO - 2020-03-06 09:21:01 --> Language Class Initialized
INFO - 2020-03-06 09:21:01 --> Loader Class Initialized
INFO - 2020-03-06 09:21:01 --> Helper loaded: url_helper
INFO - 2020-03-06 09:21:01 --> Helper loaded: string_helper
INFO - 2020-03-06 09:21:01 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:21:01 --> Controller Class Initialized
INFO - 2020-03-06 09:21:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:21:01 --> Pagination Class Initialized
INFO - 2020-03-06 09:21:01 --> Model "M_show" initialized
INFO - 2020-03-06 09:21:01 --> Helper loaded: form_helper
INFO - 2020-03-06 09:21:01 --> Form Validation Class Initialized
INFO - 2020-03-06 09:21:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:21:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:21:01 --> Final output sent to browser
DEBUG - 2020-03-06 09:21:01 --> Total execution time: 0.0067
INFO - 2020-03-06 09:21:46 --> Config Class Initialized
INFO - 2020-03-06 09:21:46 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:21:46 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:21:46 --> Utf8 Class Initialized
INFO - 2020-03-06 09:21:46 --> URI Class Initialized
DEBUG - 2020-03-06 09:21:46 --> No URI present. Default controller set.
INFO - 2020-03-06 09:21:46 --> Router Class Initialized
INFO - 2020-03-06 09:21:46 --> Output Class Initialized
INFO - 2020-03-06 09:21:46 --> Security Class Initialized
DEBUG - 2020-03-06 09:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:21:46 --> Input Class Initialized
INFO - 2020-03-06 09:21:46 --> Language Class Initialized
INFO - 2020-03-06 09:21:46 --> Loader Class Initialized
INFO - 2020-03-06 09:21:46 --> Helper loaded: url_helper
INFO - 2020-03-06 09:21:46 --> Helper loaded: string_helper
INFO - 2020-03-06 09:21:46 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:21:46 --> Controller Class Initialized
INFO - 2020-03-06 09:21:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:21:46 --> Pagination Class Initialized
INFO - 2020-03-06 09:21:46 --> Model "M_show" initialized
INFO - 2020-03-06 09:21:46 --> Helper loaded: form_helper
INFO - 2020-03-06 09:21:46 --> Form Validation Class Initialized
INFO - 2020-03-06 09:21:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:21:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:21:46 --> Final output sent to browser
DEBUG - 2020-03-06 09:21:46 --> Total execution time: 0.0200
INFO - 2020-03-06 09:21:46 --> Config Class Initialized
INFO - 2020-03-06 09:21:46 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:21:46 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:21:46 --> Utf8 Class Initialized
INFO - 2020-03-06 09:21:46 --> URI Class Initialized
DEBUG - 2020-03-06 09:21:46 --> No URI present. Default controller set.
INFO - 2020-03-06 09:21:46 --> Router Class Initialized
INFO - 2020-03-06 09:21:46 --> Output Class Initialized
INFO - 2020-03-06 09:21:46 --> Security Class Initialized
DEBUG - 2020-03-06 09:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:21:46 --> Input Class Initialized
INFO - 2020-03-06 09:21:46 --> Language Class Initialized
INFO - 2020-03-06 09:21:46 --> Loader Class Initialized
INFO - 2020-03-06 09:21:46 --> Helper loaded: url_helper
INFO - 2020-03-06 09:21:46 --> Helper loaded: string_helper
INFO - 2020-03-06 09:21:46 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:21:46 --> Controller Class Initialized
INFO - 2020-03-06 09:21:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:21:46 --> Pagination Class Initialized
INFO - 2020-03-06 09:21:46 --> Model "M_show" initialized
INFO - 2020-03-06 09:21:46 --> Helper loaded: form_helper
INFO - 2020-03-06 09:21:46 --> Form Validation Class Initialized
INFO - 2020-03-06 09:21:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:21:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:21:46 --> Final output sent to browser
DEBUG - 2020-03-06 09:21:46 --> Total execution time: 0.0033
INFO - 2020-03-06 09:21:56 --> Config Class Initialized
INFO - 2020-03-06 09:21:56 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:21:56 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:21:56 --> Utf8 Class Initialized
INFO - 2020-03-06 09:21:56 --> URI Class Initialized
DEBUG - 2020-03-06 09:21:56 --> No URI present. Default controller set.
INFO - 2020-03-06 09:21:56 --> Router Class Initialized
INFO - 2020-03-06 09:21:56 --> Output Class Initialized
INFO - 2020-03-06 09:21:56 --> Security Class Initialized
DEBUG - 2020-03-06 09:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:21:56 --> Input Class Initialized
INFO - 2020-03-06 09:21:56 --> Language Class Initialized
INFO - 2020-03-06 09:21:56 --> Loader Class Initialized
INFO - 2020-03-06 09:21:56 --> Helper loaded: url_helper
INFO - 2020-03-06 09:21:56 --> Helper loaded: string_helper
INFO - 2020-03-06 09:21:56 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:21:56 --> Controller Class Initialized
INFO - 2020-03-06 09:21:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:21:56 --> Pagination Class Initialized
INFO - 2020-03-06 09:21:56 --> Model "M_show" initialized
INFO - 2020-03-06 09:21:56 --> Helper loaded: form_helper
INFO - 2020-03-06 09:21:56 --> Form Validation Class Initialized
INFO - 2020-03-06 09:21:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:21:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:21:56 --> Final output sent to browser
DEBUG - 2020-03-06 09:21:56 --> Total execution time: 0.0305
INFO - 2020-03-06 09:22:06 --> Config Class Initialized
INFO - 2020-03-06 09:22:06 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:22:06 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:22:06 --> Utf8 Class Initialized
INFO - 2020-03-06 09:22:06 --> URI Class Initialized
INFO - 2020-03-06 09:22:06 --> Router Class Initialized
INFO - 2020-03-06 09:22:06 --> Output Class Initialized
INFO - 2020-03-06 09:22:06 --> Security Class Initialized
DEBUG - 2020-03-06 09:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:22:06 --> Input Class Initialized
INFO - 2020-03-06 09:22:06 --> Language Class Initialized
INFO - 2020-03-06 09:22:06 --> Loader Class Initialized
INFO - 2020-03-06 09:22:06 --> Helper loaded: url_helper
INFO - 2020-03-06 09:22:06 --> Helper loaded: string_helper
INFO - 2020-03-06 09:22:06 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:22:06 --> Controller Class Initialized
INFO - 2020-03-06 09:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:22:06 --> Pagination Class Initialized
INFO - 2020-03-06 09:22:06 --> Model "M_show" initialized
INFO - 2020-03-06 09:22:06 --> Helper loaded: form_helper
INFO - 2020-03-06 09:22:06 --> Form Validation Class Initialized
INFO - 2020-03-06 09:22:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:22:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 09:22:06 --> Final output sent to browser
DEBUG - 2020-03-06 09:22:06 --> Total execution time: 0.0065
INFO - 2020-03-06 09:22:11 --> Config Class Initialized
INFO - 2020-03-06 09:22:11 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:22:11 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:22:11 --> Utf8 Class Initialized
INFO - 2020-03-06 09:22:11 --> URI Class Initialized
INFO - 2020-03-06 09:22:11 --> Router Class Initialized
INFO - 2020-03-06 09:22:11 --> Output Class Initialized
INFO - 2020-03-06 09:22:11 --> Security Class Initialized
DEBUG - 2020-03-06 09:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:22:11 --> Input Class Initialized
INFO - 2020-03-06 09:22:11 --> Language Class Initialized
INFO - 2020-03-06 09:22:11 --> Loader Class Initialized
INFO - 2020-03-06 09:22:11 --> Helper loaded: url_helper
INFO - 2020-03-06 09:22:11 --> Helper loaded: string_helper
INFO - 2020-03-06 09:22:11 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:22:11 --> Controller Class Initialized
INFO - 2020-03-06 09:22:11 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:22:11 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:22:11 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:22:11 --> Helper loaded: form_helper
INFO - 2020-03-06 09:22:11 --> Form Validation Class Initialized
INFO - 2020-03-06 09:22:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 09:22:11 --> Final output sent to browser
DEBUG - 2020-03-06 09:22:11 --> Total execution time: 0.0860
INFO - 2020-03-06 09:22:30 --> Config Class Initialized
INFO - 2020-03-06 09:22:30 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:22:30 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:22:30 --> Utf8 Class Initialized
INFO - 2020-03-06 09:22:30 --> URI Class Initialized
INFO - 2020-03-06 09:22:30 --> Router Class Initialized
INFO - 2020-03-06 09:22:30 --> Output Class Initialized
INFO - 2020-03-06 09:22:30 --> Security Class Initialized
DEBUG - 2020-03-06 09:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:22:30 --> Input Class Initialized
INFO - 2020-03-06 09:22:30 --> Language Class Initialized
INFO - 2020-03-06 09:22:30 --> Loader Class Initialized
INFO - 2020-03-06 09:22:30 --> Helper loaded: url_helper
INFO - 2020-03-06 09:22:30 --> Helper loaded: string_helper
INFO - 2020-03-06 09:22:30 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:22:30 --> Controller Class Initialized
INFO - 2020-03-06 09:22:30 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:22:30 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:22:30 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:22:30 --> Helper loaded: form_helper
INFO - 2020-03-06 09:22:30 --> Form Validation Class Initialized
INFO - 2020-03-06 09:22:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 09:22:30 --> Final output sent to browser
DEBUG - 2020-03-06 09:22:30 --> Total execution time: 0.0079
INFO - 2020-03-06 09:22:40 --> Config Class Initialized
INFO - 2020-03-06 09:22:40 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:22:40 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:22:40 --> Utf8 Class Initialized
INFO - 2020-03-06 09:22:40 --> URI Class Initialized
INFO - 2020-03-06 09:22:40 --> Router Class Initialized
INFO - 2020-03-06 09:22:40 --> Output Class Initialized
INFO - 2020-03-06 09:22:40 --> Security Class Initialized
DEBUG - 2020-03-06 09:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:22:40 --> Input Class Initialized
INFO - 2020-03-06 09:22:40 --> Language Class Initialized
INFO - 2020-03-06 09:22:40 --> Loader Class Initialized
INFO - 2020-03-06 09:22:40 --> Helper loaded: url_helper
INFO - 2020-03-06 09:22:40 --> Helper loaded: string_helper
INFO - 2020-03-06 09:22:40 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:22:40 --> Controller Class Initialized
INFO - 2020-03-06 09:22:40 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:22:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:22:40 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:22:40 --> Helper loaded: form_helper
INFO - 2020-03-06 09:22:40 --> Form Validation Class Initialized
INFO - 2020-03-06 09:22:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 09:22:40 --> Final output sent to browser
DEBUG - 2020-03-06 09:22:40 --> Total execution time: 0.0092
INFO - 2020-03-06 09:22:47 --> Config Class Initialized
INFO - 2020-03-06 09:22:47 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:22:47 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:22:47 --> Utf8 Class Initialized
INFO - 2020-03-06 09:22:47 --> URI Class Initialized
INFO - 2020-03-06 09:22:47 --> Router Class Initialized
INFO - 2020-03-06 09:22:47 --> Output Class Initialized
INFO - 2020-03-06 09:22:47 --> Security Class Initialized
DEBUG - 2020-03-06 09:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:22:47 --> Input Class Initialized
INFO - 2020-03-06 09:22:47 --> Language Class Initialized
INFO - 2020-03-06 09:22:47 --> Loader Class Initialized
INFO - 2020-03-06 09:22:47 --> Helper loaded: url_helper
INFO - 2020-03-06 09:22:47 --> Helper loaded: string_helper
INFO - 2020-03-06 09:22:47 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:22:47 --> Controller Class Initialized
INFO - 2020-03-06 09:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:22:47 --> Pagination Class Initialized
INFO - 2020-03-06 09:22:47 --> Model "M_show" initialized
INFO - 2020-03-06 09:22:47 --> Helper loaded: form_helper
INFO - 2020-03-06 09:22:47 --> Form Validation Class Initialized
INFO - 2020-03-06 09:22:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:22:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 09:22:47 --> Final output sent to browser
DEBUG - 2020-03-06 09:22:47 --> Total execution time: 0.0063
INFO - 2020-03-06 09:22:49 --> Config Class Initialized
INFO - 2020-03-06 09:22:49 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:22:49 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:22:49 --> Utf8 Class Initialized
INFO - 2020-03-06 09:22:49 --> URI Class Initialized
DEBUG - 2020-03-06 09:22:49 --> No URI present. Default controller set.
INFO - 2020-03-06 09:22:49 --> Router Class Initialized
INFO - 2020-03-06 09:22:49 --> Output Class Initialized
INFO - 2020-03-06 09:22:49 --> Security Class Initialized
DEBUG - 2020-03-06 09:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:22:49 --> Input Class Initialized
INFO - 2020-03-06 09:22:49 --> Language Class Initialized
INFO - 2020-03-06 09:22:49 --> Loader Class Initialized
INFO - 2020-03-06 09:22:49 --> Helper loaded: url_helper
INFO - 2020-03-06 09:22:49 --> Helper loaded: string_helper
INFO - 2020-03-06 09:22:49 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:22:49 --> Controller Class Initialized
INFO - 2020-03-06 09:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:22:49 --> Pagination Class Initialized
INFO - 2020-03-06 09:22:49 --> Model "M_show" initialized
INFO - 2020-03-06 09:22:49 --> Helper loaded: form_helper
INFO - 2020-03-06 09:22:49 --> Form Validation Class Initialized
INFO - 2020-03-06 09:22:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:22:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:22:49 --> Final output sent to browser
DEBUG - 2020-03-06 09:22:49 --> Total execution time: 0.0062
INFO - 2020-03-06 09:22:49 --> Config Class Initialized
INFO - 2020-03-06 09:22:49 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:22:49 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:22:49 --> Utf8 Class Initialized
INFO - 2020-03-06 09:22:49 --> URI Class Initialized
DEBUG - 2020-03-06 09:22:49 --> No URI present. Default controller set.
INFO - 2020-03-06 09:22:49 --> Router Class Initialized
INFO - 2020-03-06 09:22:49 --> Output Class Initialized
INFO - 2020-03-06 09:22:49 --> Security Class Initialized
DEBUG - 2020-03-06 09:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:22:49 --> Input Class Initialized
INFO - 2020-03-06 09:22:49 --> Language Class Initialized
INFO - 2020-03-06 09:22:49 --> Loader Class Initialized
INFO - 2020-03-06 09:22:49 --> Helper loaded: url_helper
INFO - 2020-03-06 09:22:49 --> Helper loaded: string_helper
INFO - 2020-03-06 09:22:49 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:22:49 --> Controller Class Initialized
INFO - 2020-03-06 09:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:22:49 --> Pagination Class Initialized
INFO - 2020-03-06 09:22:49 --> Model "M_show" initialized
INFO - 2020-03-06 09:22:49 --> Helper loaded: form_helper
INFO - 2020-03-06 09:22:49 --> Form Validation Class Initialized
INFO - 2020-03-06 09:22:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:22:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:22:49 --> Final output sent to browser
DEBUG - 2020-03-06 09:22:49 --> Total execution time: 0.0051
INFO - 2020-03-06 09:23:23 --> Config Class Initialized
INFO - 2020-03-06 09:23:23 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:23:23 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:23:23 --> Utf8 Class Initialized
INFO - 2020-03-06 09:23:23 --> URI Class Initialized
DEBUG - 2020-03-06 09:23:23 --> No URI present. Default controller set.
INFO - 2020-03-06 09:23:23 --> Router Class Initialized
INFO - 2020-03-06 09:23:23 --> Output Class Initialized
INFO - 2020-03-06 09:23:23 --> Security Class Initialized
DEBUG - 2020-03-06 09:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:23:23 --> Input Class Initialized
INFO - 2020-03-06 09:23:23 --> Language Class Initialized
INFO - 2020-03-06 09:23:23 --> Loader Class Initialized
INFO - 2020-03-06 09:23:23 --> Helper loaded: url_helper
INFO - 2020-03-06 09:23:23 --> Helper loaded: string_helper
INFO - 2020-03-06 09:23:23 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:23:23 --> Controller Class Initialized
INFO - 2020-03-06 09:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:23:23 --> Pagination Class Initialized
INFO - 2020-03-06 09:23:23 --> Model "M_show" initialized
INFO - 2020-03-06 09:23:23 --> Helper loaded: form_helper
INFO - 2020-03-06 09:23:23 --> Form Validation Class Initialized
INFO - 2020-03-06 09:23:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:23:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:23:23 --> Final output sent to browser
DEBUG - 2020-03-06 09:23:23 --> Total execution time: 0.0390
INFO - 2020-03-06 09:23:40 --> Config Class Initialized
INFO - 2020-03-06 09:23:40 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:23:40 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:23:40 --> Utf8 Class Initialized
INFO - 2020-03-06 09:23:40 --> URI Class Initialized
INFO - 2020-03-06 09:23:40 --> Router Class Initialized
INFO - 2020-03-06 09:23:40 --> Output Class Initialized
INFO - 2020-03-06 09:23:40 --> Security Class Initialized
DEBUG - 2020-03-06 09:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:23:40 --> Input Class Initialized
INFO - 2020-03-06 09:23:40 --> Language Class Initialized
INFO - 2020-03-06 09:23:40 --> Loader Class Initialized
INFO - 2020-03-06 09:23:40 --> Helper loaded: url_helper
INFO - 2020-03-06 09:23:40 --> Helper loaded: string_helper
INFO - 2020-03-06 09:23:40 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:23:40 --> Controller Class Initialized
INFO - 2020-03-06 09:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:23:40 --> Pagination Class Initialized
INFO - 2020-03-06 09:23:40 --> Model "M_show" initialized
INFO - 2020-03-06 09:23:40 --> Helper loaded: form_helper
INFO - 2020-03-06 09:23:40 --> Form Validation Class Initialized
INFO - 2020-03-06 09:23:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:23:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 09:23:40 --> Final output sent to browser
DEBUG - 2020-03-06 09:23:40 --> Total execution time: 0.0069
INFO - 2020-03-06 09:24:10 --> Config Class Initialized
INFO - 2020-03-06 09:24:10 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:24:10 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:24:10 --> Utf8 Class Initialized
INFO - 2020-03-06 09:24:10 --> URI Class Initialized
INFO - 2020-03-06 09:24:10 --> Router Class Initialized
INFO - 2020-03-06 09:24:10 --> Output Class Initialized
INFO - 2020-03-06 09:24:10 --> Security Class Initialized
DEBUG - 2020-03-06 09:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:24:10 --> Input Class Initialized
INFO - 2020-03-06 09:24:10 --> Language Class Initialized
INFO - 2020-03-06 09:24:10 --> Loader Class Initialized
INFO - 2020-03-06 09:24:10 --> Helper loaded: url_helper
INFO - 2020-03-06 09:24:10 --> Helper loaded: string_helper
INFO - 2020-03-06 09:24:10 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:24:10 --> Controller Class Initialized
INFO - 2020-03-06 09:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:24:10 --> Pagination Class Initialized
INFO - 2020-03-06 09:24:10 --> Model "M_show" initialized
INFO - 2020-03-06 09:24:10 --> Helper loaded: form_helper
INFO - 2020-03-06 09:24:10 --> Form Validation Class Initialized
INFO - 2020-03-06 09:24:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:24:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 09:24:10 --> Final output sent to browser
DEBUG - 2020-03-06 09:24:10 --> Total execution time: 0.0059
INFO - 2020-03-06 09:24:19 --> Config Class Initialized
INFO - 2020-03-06 09:24:19 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:24:19 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:24:19 --> Utf8 Class Initialized
INFO - 2020-03-06 09:24:19 --> URI Class Initialized
INFO - 2020-03-06 09:24:19 --> Router Class Initialized
INFO - 2020-03-06 09:24:19 --> Output Class Initialized
INFO - 2020-03-06 09:24:19 --> Security Class Initialized
DEBUG - 2020-03-06 09:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:24:19 --> Input Class Initialized
INFO - 2020-03-06 09:24:19 --> Language Class Initialized
INFO - 2020-03-06 09:24:19 --> Loader Class Initialized
INFO - 2020-03-06 09:24:19 --> Helper loaded: url_helper
INFO - 2020-03-06 09:24:19 --> Helper loaded: string_helper
INFO - 2020-03-06 09:24:19 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:24:19 --> Controller Class Initialized
INFO - 2020-03-06 09:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:24:19 --> Pagination Class Initialized
INFO - 2020-03-06 09:24:19 --> Model "M_show" initialized
INFO - 2020-03-06 09:24:19 --> Helper loaded: form_helper
INFO - 2020-03-06 09:24:19 --> Form Validation Class Initialized
INFO - 2020-03-06 09:24:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:24:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:24:19 --> Final output sent to browser
DEBUG - 2020-03-06 09:24:19 --> Total execution time: 0.0058
INFO - 2020-03-06 09:24:25 --> Config Class Initialized
INFO - 2020-03-06 09:24:25 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:24:25 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:24:25 --> Utf8 Class Initialized
INFO - 2020-03-06 09:24:25 --> URI Class Initialized
INFO - 2020-03-06 09:24:25 --> Router Class Initialized
INFO - 2020-03-06 09:24:25 --> Output Class Initialized
INFO - 2020-03-06 09:24:25 --> Security Class Initialized
DEBUG - 2020-03-06 09:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:24:25 --> Input Class Initialized
INFO - 2020-03-06 09:24:25 --> Language Class Initialized
INFO - 2020-03-06 09:24:25 --> Loader Class Initialized
INFO - 2020-03-06 09:24:25 --> Helper loaded: url_helper
INFO - 2020-03-06 09:24:25 --> Helper loaded: string_helper
INFO - 2020-03-06 09:24:25 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:24:25 --> Controller Class Initialized
INFO - 2020-03-06 09:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:24:25 --> Pagination Class Initialized
INFO - 2020-03-06 09:24:25 --> Model "M_show" initialized
INFO - 2020-03-06 09:24:25 --> Helper loaded: form_helper
INFO - 2020-03-06 09:24:25 --> Form Validation Class Initialized
INFO - 2020-03-06 09:24:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:24:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 09:24:25 --> Final output sent to browser
DEBUG - 2020-03-06 09:24:25 --> Total execution time: 0.0053
INFO - 2020-03-06 09:24:49 --> Config Class Initialized
INFO - 2020-03-06 09:24:49 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:24:49 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:24:49 --> Utf8 Class Initialized
INFO - 2020-03-06 09:24:49 --> URI Class Initialized
INFO - 2020-03-06 09:24:49 --> Router Class Initialized
INFO - 2020-03-06 09:24:49 --> Output Class Initialized
INFO - 2020-03-06 09:24:49 --> Security Class Initialized
DEBUG - 2020-03-06 09:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:24:49 --> Input Class Initialized
INFO - 2020-03-06 09:24:49 --> Language Class Initialized
INFO - 2020-03-06 09:24:49 --> Loader Class Initialized
INFO - 2020-03-06 09:24:49 --> Helper loaded: url_helper
INFO - 2020-03-06 09:24:49 --> Helper loaded: string_helper
INFO - 2020-03-06 09:24:49 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:24:49 --> Controller Class Initialized
INFO - 2020-03-06 09:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:24:49 --> Pagination Class Initialized
INFO - 2020-03-06 09:24:49 --> Model "M_show" initialized
INFO - 2020-03-06 09:24:49 --> Helper loaded: form_helper
INFO - 2020-03-06 09:24:49 --> Form Validation Class Initialized
INFO - 2020-03-06 09:24:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:24:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:24:49 --> Final output sent to browser
DEBUG - 2020-03-06 09:24:49 --> Total execution time: 0.0056
INFO - 2020-03-06 09:24:50 --> Config Class Initialized
INFO - 2020-03-06 09:24:50 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:24:50 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:24:50 --> Utf8 Class Initialized
INFO - 2020-03-06 09:24:50 --> URI Class Initialized
INFO - 2020-03-06 09:24:50 --> Router Class Initialized
INFO - 2020-03-06 09:24:50 --> Output Class Initialized
INFO - 2020-03-06 09:24:50 --> Security Class Initialized
DEBUG - 2020-03-06 09:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:24:50 --> Input Class Initialized
INFO - 2020-03-06 09:24:50 --> Language Class Initialized
INFO - 2020-03-06 09:24:50 --> Loader Class Initialized
INFO - 2020-03-06 09:24:50 --> Helper loaded: url_helper
INFO - 2020-03-06 09:24:50 --> Helper loaded: string_helper
INFO - 2020-03-06 09:24:50 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:24:50 --> Controller Class Initialized
INFO - 2020-03-06 09:24:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:24:50 --> Pagination Class Initialized
INFO - 2020-03-06 09:24:50 --> Model "M_show" initialized
INFO - 2020-03-06 09:24:50 --> Helper loaded: form_helper
INFO - 2020-03-06 09:24:50 --> Form Validation Class Initialized
INFO - 2020-03-06 09:24:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:24:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 09:24:50 --> Final output sent to browser
DEBUG - 2020-03-06 09:24:50 --> Total execution time: 0.0054
INFO - 2020-03-06 09:24:54 --> Config Class Initialized
INFO - 2020-03-06 09:24:54 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:24:54 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:24:54 --> Utf8 Class Initialized
INFO - 2020-03-06 09:24:54 --> URI Class Initialized
DEBUG - 2020-03-06 09:24:54 --> No URI present. Default controller set.
INFO - 2020-03-06 09:24:54 --> Router Class Initialized
INFO - 2020-03-06 09:24:54 --> Output Class Initialized
INFO - 2020-03-06 09:24:54 --> Security Class Initialized
DEBUG - 2020-03-06 09:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:24:54 --> Input Class Initialized
INFO - 2020-03-06 09:24:54 --> Language Class Initialized
INFO - 2020-03-06 09:24:54 --> Loader Class Initialized
INFO - 2020-03-06 09:24:54 --> Helper loaded: url_helper
INFO - 2020-03-06 09:24:54 --> Helper loaded: string_helper
INFO - 2020-03-06 09:24:54 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:24:54 --> Controller Class Initialized
INFO - 2020-03-06 09:24:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:24:54 --> Pagination Class Initialized
INFO - 2020-03-06 09:24:54 --> Model "M_show" initialized
INFO - 2020-03-06 09:24:54 --> Helper loaded: form_helper
INFO - 2020-03-06 09:24:54 --> Form Validation Class Initialized
INFO - 2020-03-06 09:24:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:24:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:24:54 --> Final output sent to browser
DEBUG - 2020-03-06 09:24:54 --> Total execution time: 0.0073
INFO - 2020-03-06 09:26:03 --> Config Class Initialized
INFO - 2020-03-06 09:26:03 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:26:03 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:26:03 --> Utf8 Class Initialized
INFO - 2020-03-06 09:26:03 --> URI Class Initialized
INFO - 2020-03-06 09:26:03 --> Router Class Initialized
INFO - 2020-03-06 09:26:03 --> Output Class Initialized
INFO - 2020-03-06 09:26:03 --> Security Class Initialized
DEBUG - 2020-03-06 09:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:26:03 --> Input Class Initialized
INFO - 2020-03-06 09:26:03 --> Language Class Initialized
INFO - 2020-03-06 09:26:03 --> Loader Class Initialized
INFO - 2020-03-06 09:26:03 --> Helper loaded: url_helper
INFO - 2020-03-06 09:26:03 --> Helper loaded: string_helper
INFO - 2020-03-06 09:26:03 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:26:03 --> Controller Class Initialized
INFO - 2020-03-06 09:26:03 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:26:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:26:03 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:26:03 --> Helper loaded: form_helper
INFO - 2020-03-06 09:26:03 --> Form Validation Class Initialized
DEBUG - 2020-03-06 09:26:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-06 09:26:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-06 16:26:03 --> Final output sent to browser
DEBUG - 2020-03-06 16:26:03 --> Total execution time: 0.1842
INFO - 2020-03-06 09:26:08 --> Config Class Initialized
INFO - 2020-03-06 09:26:08 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:26:08 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:26:08 --> Utf8 Class Initialized
INFO - 2020-03-06 09:26:08 --> URI Class Initialized
INFO - 2020-03-06 09:26:08 --> Router Class Initialized
INFO - 2020-03-06 09:26:08 --> Output Class Initialized
INFO - 2020-03-06 09:26:08 --> Security Class Initialized
DEBUG - 2020-03-06 09:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:26:08 --> Input Class Initialized
INFO - 2020-03-06 09:26:08 --> Language Class Initialized
INFO - 2020-03-06 09:26:08 --> Loader Class Initialized
INFO - 2020-03-06 09:26:08 --> Helper loaded: url_helper
INFO - 2020-03-06 09:26:08 --> Helper loaded: string_helper
INFO - 2020-03-06 09:26:08 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:26:08 --> Controller Class Initialized
INFO - 2020-03-06 09:26:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:26:08 --> Pagination Class Initialized
INFO - 2020-03-06 09:26:08 --> Model "M_show" initialized
INFO - 2020-03-06 09:26:08 --> Helper loaded: form_helper
INFO - 2020-03-06 09:26:08 --> Form Validation Class Initialized
INFO - 2020-03-06 09:26:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:26:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:26:08 --> Final output sent to browser
DEBUG - 2020-03-06 09:26:08 --> Total execution time: 0.2434
INFO - 2020-03-06 09:26:10 --> Config Class Initialized
INFO - 2020-03-06 09:26:10 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:26:10 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:26:10 --> Utf8 Class Initialized
INFO - 2020-03-06 09:26:10 --> URI Class Initialized
INFO - 2020-03-06 09:26:10 --> Router Class Initialized
INFO - 2020-03-06 09:26:10 --> Output Class Initialized
INFO - 2020-03-06 09:26:10 --> Security Class Initialized
DEBUG - 2020-03-06 09:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:26:10 --> Input Class Initialized
INFO - 2020-03-06 09:26:10 --> Language Class Initialized
INFO - 2020-03-06 09:26:10 --> Loader Class Initialized
INFO - 2020-03-06 09:26:10 --> Helper loaded: url_helper
INFO - 2020-03-06 09:26:10 --> Helper loaded: string_helper
INFO - 2020-03-06 09:26:10 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:26:10 --> Controller Class Initialized
INFO - 2020-03-06 09:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:26:10 --> Pagination Class Initialized
INFO - 2020-03-06 09:26:10 --> Model "M_show" initialized
INFO - 2020-03-06 09:26:10 --> Helper loaded: form_helper
INFO - 2020-03-06 09:26:10 --> Form Validation Class Initialized
INFO - 2020-03-06 09:26:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:26:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 09:26:10 --> Final output sent to browser
DEBUG - 2020-03-06 09:26:10 --> Total execution time: 0.0066
INFO - 2020-03-06 09:26:11 --> Config Class Initialized
INFO - 2020-03-06 09:26:11 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:26:11 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:26:11 --> Utf8 Class Initialized
INFO - 2020-03-06 09:26:11 --> URI Class Initialized
INFO - 2020-03-06 09:26:11 --> Router Class Initialized
INFO - 2020-03-06 09:26:11 --> Output Class Initialized
INFO - 2020-03-06 09:26:11 --> Security Class Initialized
DEBUG - 2020-03-06 09:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:26:11 --> Input Class Initialized
INFO - 2020-03-06 09:26:11 --> Language Class Initialized
ERROR - 2020-03-06 09:26:11 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-06 09:26:14 --> Config Class Initialized
INFO - 2020-03-06 09:26:14 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:26:14 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:26:14 --> Utf8 Class Initialized
INFO - 2020-03-06 09:26:14 --> URI Class Initialized
DEBUG - 2020-03-06 09:26:14 --> No URI present. Default controller set.
INFO - 2020-03-06 09:26:14 --> Router Class Initialized
INFO - 2020-03-06 09:26:14 --> Output Class Initialized
INFO - 2020-03-06 09:26:14 --> Security Class Initialized
DEBUG - 2020-03-06 09:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:26:14 --> Input Class Initialized
INFO - 2020-03-06 09:26:14 --> Language Class Initialized
INFO - 2020-03-06 09:26:14 --> Loader Class Initialized
INFO - 2020-03-06 09:26:14 --> Helper loaded: url_helper
INFO - 2020-03-06 09:26:14 --> Helper loaded: string_helper
INFO - 2020-03-06 09:26:14 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:26:14 --> Controller Class Initialized
INFO - 2020-03-06 09:26:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:26:14 --> Pagination Class Initialized
INFO - 2020-03-06 09:26:14 --> Model "M_show" initialized
INFO - 2020-03-06 09:26:14 --> Helper loaded: form_helper
INFO - 2020-03-06 09:26:14 --> Form Validation Class Initialized
INFO - 2020-03-06 09:26:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:26:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:26:14 --> Final output sent to browser
DEBUG - 2020-03-06 09:26:14 --> Total execution time: 0.0055
INFO - 2020-03-06 09:26:33 --> Config Class Initialized
INFO - 2020-03-06 09:26:33 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:26:33 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:26:33 --> Utf8 Class Initialized
INFO - 2020-03-06 09:26:33 --> URI Class Initialized
INFO - 2020-03-06 09:26:33 --> Router Class Initialized
INFO - 2020-03-06 09:26:33 --> Output Class Initialized
INFO - 2020-03-06 09:26:33 --> Security Class Initialized
DEBUG - 2020-03-06 09:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:26:33 --> Input Class Initialized
INFO - 2020-03-06 09:26:33 --> Language Class Initialized
INFO - 2020-03-06 09:26:33 --> Loader Class Initialized
INFO - 2020-03-06 09:26:33 --> Helper loaded: url_helper
INFO - 2020-03-06 09:26:33 --> Helper loaded: string_helper
INFO - 2020-03-06 09:26:33 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:26:33 --> Controller Class Initialized
INFO - 2020-03-06 09:26:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:26:33 --> Pagination Class Initialized
INFO - 2020-03-06 09:26:33 --> Model "M_show" initialized
INFO - 2020-03-06 09:26:33 --> Helper loaded: form_helper
INFO - 2020-03-06 09:26:33 --> Form Validation Class Initialized
INFO - 2020-03-06 09:26:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:26:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-06 09:26:33 --> Final output sent to browser
DEBUG - 2020-03-06 09:26:33 --> Total execution time: 0.0144
INFO - 2020-03-06 09:26:59 --> Config Class Initialized
INFO - 2020-03-06 09:26:59 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:26:59 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:26:59 --> Utf8 Class Initialized
INFO - 2020-03-06 09:26:59 --> URI Class Initialized
INFO - 2020-03-06 09:26:59 --> Router Class Initialized
INFO - 2020-03-06 09:26:59 --> Output Class Initialized
INFO - 2020-03-06 09:26:59 --> Security Class Initialized
DEBUG - 2020-03-06 09:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:26:59 --> Input Class Initialized
INFO - 2020-03-06 09:26:59 --> Language Class Initialized
INFO - 2020-03-06 09:26:59 --> Loader Class Initialized
INFO - 2020-03-06 09:26:59 --> Helper loaded: url_helper
INFO - 2020-03-06 09:26:59 --> Helper loaded: string_helper
INFO - 2020-03-06 09:26:59 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:26:59 --> Controller Class Initialized
INFO - 2020-03-06 09:26:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:26:59 --> Pagination Class Initialized
INFO - 2020-03-06 09:26:59 --> Model "M_show" initialized
INFO - 2020-03-06 09:26:59 --> Helper loaded: form_helper
INFO - 2020-03-06 09:26:59 --> Form Validation Class Initialized
INFO - 2020-03-06 09:26:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:26:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-06 09:26:59 --> Final output sent to browser
DEBUG - 2020-03-06 09:26:59 --> Total execution time: 0.0059
INFO - 2020-03-06 09:27:05 --> Config Class Initialized
INFO - 2020-03-06 09:27:05 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:27:05 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:27:05 --> Utf8 Class Initialized
INFO - 2020-03-06 09:27:05 --> URI Class Initialized
INFO - 2020-03-06 09:27:05 --> Router Class Initialized
INFO - 2020-03-06 09:27:05 --> Output Class Initialized
INFO - 2020-03-06 09:27:05 --> Security Class Initialized
DEBUG - 2020-03-06 09:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:27:05 --> Input Class Initialized
INFO - 2020-03-06 09:27:05 --> Language Class Initialized
INFO - 2020-03-06 09:27:05 --> Loader Class Initialized
INFO - 2020-03-06 09:27:05 --> Helper loaded: url_helper
INFO - 2020-03-06 09:27:05 --> Helper loaded: string_helper
INFO - 2020-03-06 09:27:05 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:27:05 --> Controller Class Initialized
INFO - 2020-03-06 09:27:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:27:05 --> Pagination Class Initialized
INFO - 2020-03-06 09:27:05 --> Model "M_show" initialized
INFO - 2020-03-06 09:27:05 --> Helper loaded: form_helper
INFO - 2020-03-06 09:27:05 --> Form Validation Class Initialized
INFO - 2020-03-06 09:27:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:27:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-06 09:27:05 --> Final output sent to browser
DEBUG - 2020-03-06 09:27:05 --> Total execution time: 0.0056
INFO - 2020-03-06 09:27:13 --> Config Class Initialized
INFO - 2020-03-06 09:27:13 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:27:13 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:27:13 --> Utf8 Class Initialized
INFO - 2020-03-06 09:27:13 --> URI Class Initialized
DEBUG - 2020-03-06 09:27:13 --> No URI present. Default controller set.
INFO - 2020-03-06 09:27:13 --> Router Class Initialized
INFO - 2020-03-06 09:27:13 --> Output Class Initialized
INFO - 2020-03-06 09:27:13 --> Security Class Initialized
DEBUG - 2020-03-06 09:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:27:13 --> Input Class Initialized
INFO - 2020-03-06 09:27:13 --> Language Class Initialized
INFO - 2020-03-06 09:27:13 --> Loader Class Initialized
INFO - 2020-03-06 09:27:13 --> Helper loaded: url_helper
INFO - 2020-03-06 09:27:13 --> Helper loaded: string_helper
INFO - 2020-03-06 09:27:13 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:27:13 --> Controller Class Initialized
INFO - 2020-03-06 09:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:27:13 --> Pagination Class Initialized
INFO - 2020-03-06 09:27:13 --> Model "M_show" initialized
INFO - 2020-03-06 09:27:13 --> Helper loaded: form_helper
INFO - 2020-03-06 09:27:13 --> Form Validation Class Initialized
INFO - 2020-03-06 09:27:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:27:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:27:13 --> Final output sent to browser
DEBUG - 2020-03-06 09:27:13 --> Total execution time: 0.0061
INFO - 2020-03-06 09:27:15 --> Config Class Initialized
INFO - 2020-03-06 09:27:15 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:27:15 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:27:15 --> Utf8 Class Initialized
INFO - 2020-03-06 09:27:15 --> URI Class Initialized
DEBUG - 2020-03-06 09:27:15 --> No URI present. Default controller set.
INFO - 2020-03-06 09:27:15 --> Router Class Initialized
INFO - 2020-03-06 09:27:15 --> Output Class Initialized
INFO - 2020-03-06 09:27:15 --> Security Class Initialized
DEBUG - 2020-03-06 09:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:27:15 --> Input Class Initialized
INFO - 2020-03-06 09:27:15 --> Language Class Initialized
INFO - 2020-03-06 09:27:15 --> Loader Class Initialized
INFO - 2020-03-06 09:27:15 --> Helper loaded: url_helper
INFO - 2020-03-06 09:27:15 --> Helper loaded: string_helper
INFO - 2020-03-06 09:27:15 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:27:15 --> Controller Class Initialized
INFO - 2020-03-06 09:27:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:27:15 --> Pagination Class Initialized
INFO - 2020-03-06 09:27:15 --> Model "M_show" initialized
INFO - 2020-03-06 09:27:15 --> Helper loaded: form_helper
INFO - 2020-03-06 09:27:15 --> Form Validation Class Initialized
INFO - 2020-03-06 09:27:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:27:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:27:15 --> Final output sent to browser
DEBUG - 2020-03-06 09:27:15 --> Total execution time: 0.0055
INFO - 2020-03-06 09:27:44 --> Config Class Initialized
INFO - 2020-03-06 09:27:44 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:27:44 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:27:44 --> Utf8 Class Initialized
INFO - 2020-03-06 09:27:44 --> URI Class Initialized
DEBUG - 2020-03-06 09:27:44 --> No URI present. Default controller set.
INFO - 2020-03-06 09:27:44 --> Router Class Initialized
INFO - 2020-03-06 09:27:44 --> Output Class Initialized
INFO - 2020-03-06 09:27:44 --> Security Class Initialized
DEBUG - 2020-03-06 09:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:27:44 --> Input Class Initialized
INFO - 2020-03-06 09:27:44 --> Language Class Initialized
INFO - 2020-03-06 09:27:44 --> Loader Class Initialized
INFO - 2020-03-06 09:27:44 --> Helper loaded: url_helper
INFO - 2020-03-06 09:27:44 --> Helper loaded: string_helper
INFO - 2020-03-06 09:27:44 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:27:44 --> Controller Class Initialized
INFO - 2020-03-06 09:27:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:27:44 --> Pagination Class Initialized
INFO - 2020-03-06 09:27:44 --> Model "M_show" initialized
INFO - 2020-03-06 09:27:44 --> Helper loaded: form_helper
INFO - 2020-03-06 09:27:44 --> Form Validation Class Initialized
INFO - 2020-03-06 09:27:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:27:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:27:44 --> Final output sent to browser
DEBUG - 2020-03-06 09:27:44 --> Total execution time: 0.1183
INFO - 2020-03-06 09:27:55 --> Config Class Initialized
INFO - 2020-03-06 09:27:55 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:27:55 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:27:55 --> Utf8 Class Initialized
INFO - 2020-03-06 09:27:55 --> URI Class Initialized
INFO - 2020-03-06 09:27:55 --> Router Class Initialized
INFO - 2020-03-06 09:27:55 --> Output Class Initialized
INFO - 2020-03-06 09:27:55 --> Security Class Initialized
DEBUG - 2020-03-06 09:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:27:55 --> Input Class Initialized
INFO - 2020-03-06 09:27:55 --> Language Class Initialized
INFO - 2020-03-06 09:27:55 --> Loader Class Initialized
INFO - 2020-03-06 09:27:55 --> Helper loaded: url_helper
INFO - 2020-03-06 09:27:55 --> Helper loaded: string_helper
INFO - 2020-03-06 09:27:55 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:27:55 --> Controller Class Initialized
INFO - 2020-03-06 09:27:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:27:55 --> Pagination Class Initialized
INFO - 2020-03-06 09:27:55 --> Model "M_show" initialized
INFO - 2020-03-06 09:27:55 --> Helper loaded: form_helper
INFO - 2020-03-06 09:27:55 --> Form Validation Class Initialized
INFO - 2020-03-06 09:27:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:27:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:27:55 --> Final output sent to browser
DEBUG - 2020-03-06 09:27:55 --> Total execution time: 0.0414
INFO - 2020-03-06 09:28:03 --> Config Class Initialized
INFO - 2020-03-06 09:28:03 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:28:03 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:28:03 --> Utf8 Class Initialized
INFO - 2020-03-06 09:28:03 --> URI Class Initialized
INFO - 2020-03-06 09:28:03 --> Router Class Initialized
INFO - 2020-03-06 09:28:03 --> Output Class Initialized
INFO - 2020-03-06 09:28:03 --> Security Class Initialized
DEBUG - 2020-03-06 09:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:28:03 --> Input Class Initialized
INFO - 2020-03-06 09:28:03 --> Language Class Initialized
INFO - 2020-03-06 09:28:03 --> Loader Class Initialized
INFO - 2020-03-06 09:28:03 --> Helper loaded: url_helper
INFO - 2020-03-06 09:28:03 --> Helper loaded: string_helper
INFO - 2020-03-06 09:28:03 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:28:03 --> Controller Class Initialized
INFO - 2020-03-06 09:28:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:28:03 --> Pagination Class Initialized
INFO - 2020-03-06 09:28:03 --> Model "M_show" initialized
INFO - 2020-03-06 09:28:03 --> Helper loaded: form_helper
INFO - 2020-03-06 09:28:03 --> Form Validation Class Initialized
INFO - 2020-03-06 09:28:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:28:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 09:28:03 --> Final output sent to browser
DEBUG - 2020-03-06 09:28:03 --> Total execution time: 0.0063
INFO - 2020-03-06 09:28:16 --> Config Class Initialized
INFO - 2020-03-06 09:28:16 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:28:16 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:28:16 --> Utf8 Class Initialized
INFO - 2020-03-06 09:28:16 --> URI Class Initialized
INFO - 2020-03-06 09:28:16 --> Router Class Initialized
INFO - 2020-03-06 09:28:16 --> Output Class Initialized
INFO - 2020-03-06 09:28:16 --> Security Class Initialized
DEBUG - 2020-03-06 09:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:28:16 --> Input Class Initialized
INFO - 2020-03-06 09:28:16 --> Language Class Initialized
INFO - 2020-03-06 09:28:16 --> Loader Class Initialized
INFO - 2020-03-06 09:28:16 --> Helper loaded: url_helper
INFO - 2020-03-06 09:28:16 --> Helper loaded: string_helper
INFO - 2020-03-06 09:28:16 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:28:16 --> Controller Class Initialized
INFO - 2020-03-06 09:28:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:28:16 --> Pagination Class Initialized
INFO - 2020-03-06 09:28:16 --> Model "M_show" initialized
INFO - 2020-03-06 09:28:16 --> Helper loaded: form_helper
INFO - 2020-03-06 09:28:16 --> Form Validation Class Initialized
INFO - 2020-03-06 09:28:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:28:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-06 09:28:16 --> Final output sent to browser
DEBUG - 2020-03-06 09:28:16 --> Total execution time: 0.0057
INFO - 2020-03-06 09:28:28 --> Config Class Initialized
INFO - 2020-03-06 09:28:28 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:28:28 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:28:28 --> Utf8 Class Initialized
INFO - 2020-03-06 09:28:28 --> URI Class Initialized
INFO - 2020-03-06 09:28:28 --> Router Class Initialized
INFO - 2020-03-06 09:28:28 --> Output Class Initialized
INFO - 2020-03-06 09:28:28 --> Security Class Initialized
DEBUG - 2020-03-06 09:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:28:28 --> Input Class Initialized
INFO - 2020-03-06 09:28:28 --> Language Class Initialized
INFO - 2020-03-06 09:28:28 --> Loader Class Initialized
INFO - 2020-03-06 09:28:28 --> Helper loaded: url_helper
INFO - 2020-03-06 09:28:28 --> Helper loaded: string_helper
INFO - 2020-03-06 09:28:28 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:28:28 --> Controller Class Initialized
INFO - 2020-03-06 09:28:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:28:28 --> Pagination Class Initialized
INFO - 2020-03-06 09:28:28 --> Model "M_show" initialized
INFO - 2020-03-06 09:28:28 --> Helper loaded: form_helper
INFO - 2020-03-06 09:28:28 --> Form Validation Class Initialized
INFO - 2020-03-06 09:28:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:28:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 09:28:28 --> Final output sent to browser
DEBUG - 2020-03-06 09:28:28 --> Total execution time: 0.0188
INFO - 2020-03-06 09:28:37 --> Config Class Initialized
INFO - 2020-03-06 09:28:37 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:28:37 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:28:37 --> Utf8 Class Initialized
INFO - 2020-03-06 09:28:37 --> URI Class Initialized
DEBUG - 2020-03-06 09:28:37 --> No URI present. Default controller set.
INFO - 2020-03-06 09:28:37 --> Router Class Initialized
INFO - 2020-03-06 09:28:37 --> Output Class Initialized
INFO - 2020-03-06 09:28:37 --> Security Class Initialized
DEBUG - 2020-03-06 09:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:28:37 --> Input Class Initialized
INFO - 2020-03-06 09:28:37 --> Language Class Initialized
INFO - 2020-03-06 09:28:37 --> Loader Class Initialized
INFO - 2020-03-06 09:28:37 --> Helper loaded: url_helper
INFO - 2020-03-06 09:28:37 --> Helper loaded: string_helper
INFO - 2020-03-06 09:28:37 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:28:37 --> Controller Class Initialized
INFO - 2020-03-06 09:28:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:28:37 --> Pagination Class Initialized
INFO - 2020-03-06 09:28:37 --> Model "M_show" initialized
INFO - 2020-03-06 09:28:37 --> Helper loaded: form_helper
INFO - 2020-03-06 09:28:37 --> Form Validation Class Initialized
INFO - 2020-03-06 09:28:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:28:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:28:37 --> Final output sent to browser
DEBUG - 2020-03-06 09:28:37 --> Total execution time: 0.0050
INFO - 2020-03-06 09:28:38 --> Config Class Initialized
INFO - 2020-03-06 09:28:38 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:28:38 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:28:38 --> Utf8 Class Initialized
INFO - 2020-03-06 09:28:38 --> URI Class Initialized
INFO - 2020-03-06 09:28:38 --> Router Class Initialized
INFO - 2020-03-06 09:28:38 --> Output Class Initialized
INFO - 2020-03-06 09:28:38 --> Security Class Initialized
DEBUG - 2020-03-06 09:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:28:38 --> Input Class Initialized
INFO - 2020-03-06 09:28:38 --> Language Class Initialized
INFO - 2020-03-06 09:28:38 --> Loader Class Initialized
INFO - 2020-03-06 09:28:38 --> Helper loaded: url_helper
INFO - 2020-03-06 09:28:38 --> Helper loaded: string_helper
INFO - 2020-03-06 09:28:38 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:28:38 --> Controller Class Initialized
INFO - 2020-03-06 09:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:28:38 --> Pagination Class Initialized
INFO - 2020-03-06 09:28:38 --> Model "M_show" initialized
INFO - 2020-03-06 09:28:38 --> Helper loaded: form_helper
INFO - 2020-03-06 09:28:38 --> Form Validation Class Initialized
INFO - 2020-03-06 09:28:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:28:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:28:38 --> Final output sent to browser
DEBUG - 2020-03-06 09:28:38 --> Total execution time: 0.0060
INFO - 2020-03-06 09:40:07 --> Config Class Initialized
INFO - 2020-03-06 09:40:07 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:40:07 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:40:07 --> Utf8 Class Initialized
INFO - 2020-03-06 09:40:07 --> URI Class Initialized
DEBUG - 2020-03-06 09:40:07 --> No URI present. Default controller set.
INFO - 2020-03-06 09:40:07 --> Router Class Initialized
INFO - 2020-03-06 09:40:07 --> Output Class Initialized
INFO - 2020-03-06 09:40:07 --> Security Class Initialized
DEBUG - 2020-03-06 09:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:40:07 --> Input Class Initialized
INFO - 2020-03-06 09:40:07 --> Language Class Initialized
INFO - 2020-03-06 09:40:07 --> Loader Class Initialized
INFO - 2020-03-06 09:40:07 --> Helper loaded: url_helper
INFO - 2020-03-06 09:40:07 --> Helper loaded: string_helper
INFO - 2020-03-06 09:40:07 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:40:07 --> Controller Class Initialized
INFO - 2020-03-06 09:40:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:40:07 --> Pagination Class Initialized
INFO - 2020-03-06 09:40:07 --> Model "M_show" initialized
INFO - 2020-03-06 09:40:07 --> Helper loaded: form_helper
INFO - 2020-03-06 09:40:07 --> Form Validation Class Initialized
INFO - 2020-03-06 09:40:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:40:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:40:07 --> Final output sent to browser
DEBUG - 2020-03-06 09:40:07 --> Total execution time: 0.0476
INFO - 2020-03-06 09:40:17 --> Config Class Initialized
INFO - 2020-03-06 09:40:17 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:40:17 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:40:17 --> Utf8 Class Initialized
INFO - 2020-03-06 09:40:17 --> URI Class Initialized
INFO - 2020-03-06 09:40:17 --> Router Class Initialized
INFO - 2020-03-06 09:40:17 --> Output Class Initialized
INFO - 2020-03-06 09:40:17 --> Security Class Initialized
DEBUG - 2020-03-06 09:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:40:17 --> Input Class Initialized
INFO - 2020-03-06 09:40:17 --> Language Class Initialized
INFO - 2020-03-06 09:40:17 --> Loader Class Initialized
INFO - 2020-03-06 09:40:17 --> Helper loaded: url_helper
INFO - 2020-03-06 09:40:17 --> Helper loaded: string_helper
INFO - 2020-03-06 09:40:17 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:40:17 --> Controller Class Initialized
INFO - 2020-03-06 09:40:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:40:17 --> Pagination Class Initialized
INFO - 2020-03-06 09:40:17 --> Model "M_show" initialized
INFO - 2020-03-06 09:40:17 --> Helper loaded: form_helper
INFO - 2020-03-06 09:40:17 --> Form Validation Class Initialized
INFO - 2020-03-06 09:40:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:40:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-06 09:40:17 --> Final output sent to browser
DEBUG - 2020-03-06 09:40:17 --> Total execution time: 0.0057
INFO - 2020-03-06 09:40:17 --> Config Class Initialized
INFO - 2020-03-06 09:40:17 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:40:17 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:40:17 --> Utf8 Class Initialized
INFO - 2020-03-06 09:40:17 --> URI Class Initialized
INFO - 2020-03-06 09:40:17 --> Router Class Initialized
INFO - 2020-03-06 09:40:17 --> Output Class Initialized
INFO - 2020-03-06 09:40:17 --> Security Class Initialized
DEBUG - 2020-03-06 09:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:40:17 --> Input Class Initialized
INFO - 2020-03-06 09:40:17 --> Language Class Initialized
ERROR - 2020-03-06 09:40:17 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-06 09:40:37 --> Config Class Initialized
INFO - 2020-03-06 09:40:37 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:40:37 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:40:37 --> Utf8 Class Initialized
INFO - 2020-03-06 09:40:37 --> URI Class Initialized
INFO - 2020-03-06 09:40:37 --> Router Class Initialized
INFO - 2020-03-06 09:40:37 --> Output Class Initialized
INFO - 2020-03-06 09:40:37 --> Security Class Initialized
DEBUG - 2020-03-06 09:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:40:37 --> Input Class Initialized
INFO - 2020-03-06 09:40:37 --> Language Class Initialized
INFO - 2020-03-06 09:40:37 --> Loader Class Initialized
INFO - 2020-03-06 09:40:37 --> Helper loaded: url_helper
INFO - 2020-03-06 09:40:37 --> Helper loaded: string_helper
INFO - 2020-03-06 09:40:37 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:40:37 --> Controller Class Initialized
INFO - 2020-03-06 09:40:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:40:37 --> Pagination Class Initialized
INFO - 2020-03-06 09:40:37 --> Model "M_show" initialized
INFO - 2020-03-06 09:40:37 --> Helper loaded: form_helper
INFO - 2020-03-06 09:40:37 --> Form Validation Class Initialized
INFO - 2020-03-06 09:40:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:40:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 09:40:37 --> Final output sent to browser
DEBUG - 2020-03-06 09:40:37 --> Total execution time: 0.0067
INFO - 2020-03-06 09:41:53 --> Config Class Initialized
INFO - 2020-03-06 09:41:53 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:41:53 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:41:53 --> Utf8 Class Initialized
INFO - 2020-03-06 09:41:53 --> URI Class Initialized
DEBUG - 2020-03-06 09:41:53 --> No URI present. Default controller set.
INFO - 2020-03-06 09:41:53 --> Router Class Initialized
INFO - 2020-03-06 09:41:53 --> Output Class Initialized
INFO - 2020-03-06 09:41:53 --> Security Class Initialized
DEBUG - 2020-03-06 09:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:41:53 --> Input Class Initialized
INFO - 2020-03-06 09:41:53 --> Language Class Initialized
INFO - 2020-03-06 09:41:53 --> Loader Class Initialized
INFO - 2020-03-06 09:41:53 --> Helper loaded: url_helper
INFO - 2020-03-06 09:41:53 --> Helper loaded: string_helper
INFO - 2020-03-06 09:41:53 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:41:53 --> Controller Class Initialized
INFO - 2020-03-06 09:41:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:41:53 --> Pagination Class Initialized
INFO - 2020-03-06 09:41:53 --> Model "M_show" initialized
INFO - 2020-03-06 09:41:53 --> Helper loaded: form_helper
INFO - 2020-03-06 09:41:53 --> Form Validation Class Initialized
INFO - 2020-03-06 09:41:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:41:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:41:53 --> Final output sent to browser
DEBUG - 2020-03-06 09:41:53 --> Total execution time: 0.0462
INFO - 2020-03-06 09:42:00 --> Config Class Initialized
INFO - 2020-03-06 09:42:00 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:42:00 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:42:00 --> Utf8 Class Initialized
INFO - 2020-03-06 09:42:00 --> URI Class Initialized
INFO - 2020-03-06 09:42:00 --> Router Class Initialized
INFO - 2020-03-06 09:42:00 --> Output Class Initialized
INFO - 2020-03-06 09:42:00 --> Security Class Initialized
DEBUG - 2020-03-06 09:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:42:00 --> Input Class Initialized
INFO - 2020-03-06 09:42:00 --> Language Class Initialized
INFO - 2020-03-06 09:42:00 --> Loader Class Initialized
INFO - 2020-03-06 09:42:00 --> Helper loaded: url_helper
INFO - 2020-03-06 09:42:00 --> Helper loaded: string_helper
INFO - 2020-03-06 09:42:00 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:42:00 --> Controller Class Initialized
INFO - 2020-03-06 09:42:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:42:00 --> Pagination Class Initialized
INFO - 2020-03-06 09:42:00 --> Model "M_show" initialized
INFO - 2020-03-06 09:42:00 --> Helper loaded: form_helper
INFO - 2020-03-06 09:42:00 --> Form Validation Class Initialized
INFO - 2020-03-06 09:42:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:42:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-06 09:42:00 --> Final output sent to browser
DEBUG - 2020-03-06 09:42:00 --> Total execution time: 0.0061
INFO - 2020-03-06 09:42:03 --> Config Class Initialized
INFO - 2020-03-06 09:42:03 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:42:03 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:42:03 --> Utf8 Class Initialized
INFO - 2020-03-06 09:42:03 --> URI Class Initialized
DEBUG - 2020-03-06 09:42:03 --> No URI present. Default controller set.
INFO - 2020-03-06 09:42:03 --> Router Class Initialized
INFO - 2020-03-06 09:42:03 --> Output Class Initialized
INFO - 2020-03-06 09:42:03 --> Security Class Initialized
DEBUG - 2020-03-06 09:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:42:03 --> Input Class Initialized
INFO - 2020-03-06 09:42:03 --> Language Class Initialized
INFO - 2020-03-06 09:42:03 --> Loader Class Initialized
INFO - 2020-03-06 09:42:03 --> Helper loaded: url_helper
INFO - 2020-03-06 09:42:03 --> Helper loaded: string_helper
INFO - 2020-03-06 09:42:03 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:42:03 --> Controller Class Initialized
INFO - 2020-03-06 09:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:42:03 --> Pagination Class Initialized
INFO - 2020-03-06 09:42:03 --> Model "M_show" initialized
INFO - 2020-03-06 09:42:03 --> Helper loaded: form_helper
INFO - 2020-03-06 09:42:03 --> Form Validation Class Initialized
INFO - 2020-03-06 09:42:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:42:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:42:03 --> Final output sent to browser
DEBUG - 2020-03-06 09:42:03 --> Total execution time: 0.0096
INFO - 2020-03-06 09:42:07 --> Config Class Initialized
INFO - 2020-03-06 09:42:07 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:42:07 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:42:07 --> Utf8 Class Initialized
INFO - 2020-03-06 09:42:07 --> URI Class Initialized
DEBUG - 2020-03-06 09:42:07 --> No URI present. Default controller set.
INFO - 2020-03-06 09:42:07 --> Router Class Initialized
INFO - 2020-03-06 09:42:07 --> Output Class Initialized
INFO - 2020-03-06 09:42:07 --> Security Class Initialized
DEBUG - 2020-03-06 09:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:42:07 --> Input Class Initialized
INFO - 2020-03-06 09:42:07 --> Language Class Initialized
INFO - 2020-03-06 09:42:07 --> Loader Class Initialized
INFO - 2020-03-06 09:42:07 --> Helper loaded: url_helper
INFO - 2020-03-06 09:42:07 --> Helper loaded: string_helper
INFO - 2020-03-06 09:42:07 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:42:07 --> Controller Class Initialized
INFO - 2020-03-06 09:42:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:42:07 --> Pagination Class Initialized
INFO - 2020-03-06 09:42:07 --> Model "M_show" initialized
INFO - 2020-03-06 09:42:07 --> Helper loaded: form_helper
INFO - 2020-03-06 09:42:07 --> Form Validation Class Initialized
INFO - 2020-03-06 09:42:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:42:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:42:07 --> Final output sent to browser
DEBUG - 2020-03-06 09:42:07 --> Total execution time: 0.0064
INFO - 2020-03-06 09:42:10 --> Config Class Initialized
INFO - 2020-03-06 09:42:10 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:42:10 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:42:10 --> Utf8 Class Initialized
INFO - 2020-03-06 09:42:10 --> URI Class Initialized
INFO - 2020-03-06 09:42:10 --> Router Class Initialized
INFO - 2020-03-06 09:42:10 --> Output Class Initialized
INFO - 2020-03-06 09:42:10 --> Security Class Initialized
DEBUG - 2020-03-06 09:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:42:10 --> Input Class Initialized
INFO - 2020-03-06 09:42:10 --> Language Class Initialized
INFO - 2020-03-06 09:42:10 --> Loader Class Initialized
INFO - 2020-03-06 09:42:10 --> Helper loaded: url_helper
INFO - 2020-03-06 09:42:10 --> Helper loaded: string_helper
INFO - 2020-03-06 09:42:10 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:42:10 --> Controller Class Initialized
INFO - 2020-03-06 09:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:42:10 --> Pagination Class Initialized
INFO - 2020-03-06 09:42:10 --> Model "M_show" initialized
INFO - 2020-03-06 09:42:10 --> Helper loaded: form_helper
INFO - 2020-03-06 09:42:10 --> Form Validation Class Initialized
INFO - 2020-03-06 09:42:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:42:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-06 09:42:10 --> Final output sent to browser
DEBUG - 2020-03-06 09:42:10 --> Total execution time: 0.0072
INFO - 2020-03-06 09:42:21 --> Config Class Initialized
INFO - 2020-03-06 09:42:21 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:42:21 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:42:21 --> Utf8 Class Initialized
INFO - 2020-03-06 09:42:21 --> URI Class Initialized
DEBUG - 2020-03-06 09:42:21 --> No URI present. Default controller set.
INFO - 2020-03-06 09:42:21 --> Router Class Initialized
INFO - 2020-03-06 09:42:21 --> Output Class Initialized
INFO - 2020-03-06 09:42:21 --> Security Class Initialized
DEBUG - 2020-03-06 09:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:42:21 --> Input Class Initialized
INFO - 2020-03-06 09:42:21 --> Language Class Initialized
INFO - 2020-03-06 09:42:21 --> Loader Class Initialized
INFO - 2020-03-06 09:42:21 --> Helper loaded: url_helper
INFO - 2020-03-06 09:42:21 --> Helper loaded: string_helper
INFO - 2020-03-06 09:42:21 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:42:21 --> Controller Class Initialized
INFO - 2020-03-06 09:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:42:21 --> Pagination Class Initialized
INFO - 2020-03-06 09:42:21 --> Model "M_show" initialized
INFO - 2020-03-06 09:42:21 --> Helper loaded: form_helper
INFO - 2020-03-06 09:42:21 --> Form Validation Class Initialized
INFO - 2020-03-06 09:42:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:42:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:42:21 --> Final output sent to browser
DEBUG - 2020-03-06 09:42:21 --> Total execution time: 0.0056
INFO - 2020-03-06 09:42:23 --> Config Class Initialized
INFO - 2020-03-06 09:42:23 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:42:23 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:42:23 --> Utf8 Class Initialized
INFO - 2020-03-06 09:42:23 --> URI Class Initialized
DEBUG - 2020-03-06 09:42:23 --> No URI present. Default controller set.
INFO - 2020-03-06 09:42:23 --> Router Class Initialized
INFO - 2020-03-06 09:42:23 --> Output Class Initialized
INFO - 2020-03-06 09:42:23 --> Security Class Initialized
DEBUG - 2020-03-06 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:42:23 --> Input Class Initialized
INFO - 2020-03-06 09:42:23 --> Language Class Initialized
INFO - 2020-03-06 09:42:23 --> Loader Class Initialized
INFO - 2020-03-06 09:42:23 --> Helper loaded: url_helper
INFO - 2020-03-06 09:42:23 --> Helper loaded: string_helper
INFO - 2020-03-06 09:42:23 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:42:23 --> Controller Class Initialized
INFO - 2020-03-06 09:42:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:42:23 --> Pagination Class Initialized
INFO - 2020-03-06 09:42:23 --> Model "M_show" initialized
INFO - 2020-03-06 09:42:23 --> Helper loaded: form_helper
INFO - 2020-03-06 09:42:23 --> Form Validation Class Initialized
INFO - 2020-03-06 09:42:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:42:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:42:23 --> Final output sent to browser
DEBUG - 2020-03-06 09:42:23 --> Total execution time: 0.0065
INFO - 2020-03-06 09:43:09 --> Config Class Initialized
INFO - 2020-03-06 09:43:09 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:43:09 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:43:09 --> Utf8 Class Initialized
INFO - 2020-03-06 09:43:09 --> URI Class Initialized
DEBUG - 2020-03-06 09:43:09 --> No URI present. Default controller set.
INFO - 2020-03-06 09:43:09 --> Router Class Initialized
INFO - 2020-03-06 09:43:09 --> Output Class Initialized
INFO - 2020-03-06 09:43:09 --> Security Class Initialized
DEBUG - 2020-03-06 09:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:43:09 --> Input Class Initialized
INFO - 2020-03-06 09:43:09 --> Language Class Initialized
INFO - 2020-03-06 09:43:09 --> Loader Class Initialized
INFO - 2020-03-06 09:43:09 --> Helper loaded: url_helper
INFO - 2020-03-06 09:43:09 --> Helper loaded: string_helper
INFO - 2020-03-06 09:43:09 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:43:09 --> Controller Class Initialized
INFO - 2020-03-06 09:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:43:09 --> Pagination Class Initialized
INFO - 2020-03-06 09:43:09 --> Model "M_show" initialized
INFO - 2020-03-06 09:43:09 --> Helper loaded: form_helper
INFO - 2020-03-06 09:43:09 --> Form Validation Class Initialized
INFO - 2020-03-06 09:43:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:43:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:43:09 --> Final output sent to browser
DEBUG - 2020-03-06 09:43:09 --> Total execution time: 0.0151
INFO - 2020-03-06 09:43:23 --> Config Class Initialized
INFO - 2020-03-06 09:43:23 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:43:23 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:43:23 --> Utf8 Class Initialized
INFO - 2020-03-06 09:43:23 --> URI Class Initialized
INFO - 2020-03-06 09:43:23 --> Router Class Initialized
INFO - 2020-03-06 09:43:23 --> Output Class Initialized
INFO - 2020-03-06 09:43:23 --> Security Class Initialized
DEBUG - 2020-03-06 09:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:43:23 --> Input Class Initialized
INFO - 2020-03-06 09:43:23 --> Language Class Initialized
INFO - 2020-03-06 09:43:23 --> Loader Class Initialized
INFO - 2020-03-06 09:43:23 --> Helper loaded: url_helper
INFO - 2020-03-06 09:43:23 --> Helper loaded: string_helper
INFO - 2020-03-06 09:43:23 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:43:23 --> Controller Class Initialized
INFO - 2020-03-06 09:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:43:23 --> Pagination Class Initialized
INFO - 2020-03-06 09:43:23 --> Model "M_show" initialized
INFO - 2020-03-06 09:43:23 --> Helper loaded: form_helper
INFO - 2020-03-06 09:43:23 --> Form Validation Class Initialized
INFO - 2020-03-06 09:43:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:43:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 09:43:23 --> Final output sent to browser
DEBUG - 2020-03-06 09:43:23 --> Total execution time: 0.0113
INFO - 2020-03-06 09:43:28 --> Config Class Initialized
INFO - 2020-03-06 09:43:28 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:43:28 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:43:28 --> Utf8 Class Initialized
INFO - 2020-03-06 09:43:28 --> URI Class Initialized
INFO - 2020-03-06 09:43:28 --> Router Class Initialized
INFO - 2020-03-06 09:43:28 --> Output Class Initialized
INFO - 2020-03-06 09:43:28 --> Security Class Initialized
DEBUG - 2020-03-06 09:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:43:28 --> Input Class Initialized
INFO - 2020-03-06 09:43:28 --> Language Class Initialized
INFO - 2020-03-06 09:43:28 --> Loader Class Initialized
INFO - 2020-03-06 09:43:28 --> Helper loaded: url_helper
INFO - 2020-03-06 09:43:28 --> Helper loaded: string_helper
INFO - 2020-03-06 09:43:28 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:43:28 --> Controller Class Initialized
INFO - 2020-03-06 09:43:28 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:43:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:43:28 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:43:28 --> Helper loaded: form_helper
INFO - 2020-03-06 09:43:28 --> Form Validation Class Initialized
INFO - 2020-03-06 09:43:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 09:43:28 --> Final output sent to browser
DEBUG - 2020-03-06 09:43:28 --> Total execution time: 0.0243
INFO - 2020-03-06 09:43:49 --> Config Class Initialized
INFO - 2020-03-06 09:43:49 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:43:49 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:43:49 --> Utf8 Class Initialized
INFO - 2020-03-06 09:43:49 --> URI Class Initialized
INFO - 2020-03-06 09:43:49 --> Router Class Initialized
INFO - 2020-03-06 09:43:49 --> Output Class Initialized
INFO - 2020-03-06 09:43:49 --> Security Class Initialized
DEBUG - 2020-03-06 09:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:43:49 --> Input Class Initialized
INFO - 2020-03-06 09:43:49 --> Language Class Initialized
INFO - 2020-03-06 09:43:49 --> Loader Class Initialized
INFO - 2020-03-06 09:43:49 --> Helper loaded: url_helper
INFO - 2020-03-06 09:43:49 --> Helper loaded: string_helper
INFO - 2020-03-06 09:43:49 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:43:50 --> Controller Class Initialized
INFO - 2020-03-06 09:43:50 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:43:50 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:43:50 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:43:50 --> Helper loaded: form_helper
INFO - 2020-03-06 09:43:50 --> Form Validation Class Initialized
INFO - 2020-03-06 09:43:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 09:43:50 --> Final output sent to browser
DEBUG - 2020-03-06 09:43:50 --> Total execution time: 0.5598
INFO - 2020-03-06 09:44:07 --> Config Class Initialized
INFO - 2020-03-06 09:44:07 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:44:07 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:44:07 --> Utf8 Class Initialized
INFO - 2020-03-06 09:44:07 --> URI Class Initialized
INFO - 2020-03-06 09:44:07 --> Router Class Initialized
INFO - 2020-03-06 09:44:07 --> Output Class Initialized
INFO - 2020-03-06 09:44:07 --> Security Class Initialized
DEBUG - 2020-03-06 09:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:44:07 --> Input Class Initialized
INFO - 2020-03-06 09:44:07 --> Language Class Initialized
INFO - 2020-03-06 09:44:07 --> Loader Class Initialized
INFO - 2020-03-06 09:44:07 --> Helper loaded: url_helper
INFO - 2020-03-06 09:44:07 --> Helper loaded: string_helper
INFO - 2020-03-06 09:44:07 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:44:07 --> Controller Class Initialized
INFO - 2020-03-06 09:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:44:07 --> Pagination Class Initialized
INFO - 2020-03-06 09:44:07 --> Model "M_show" initialized
INFO - 2020-03-06 09:44:07 --> Helper loaded: form_helper
INFO - 2020-03-06 09:44:07 --> Form Validation Class Initialized
INFO - 2020-03-06 09:44:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:44:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 09:44:07 --> Final output sent to browser
DEBUG - 2020-03-06 09:44:07 --> Total execution time: 0.0781
INFO - 2020-03-06 09:44:13 --> Config Class Initialized
INFO - 2020-03-06 09:44:13 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:44:13 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:44:13 --> Utf8 Class Initialized
INFO - 2020-03-06 09:44:13 --> URI Class Initialized
INFO - 2020-03-06 09:44:13 --> Router Class Initialized
INFO - 2020-03-06 09:44:13 --> Output Class Initialized
INFO - 2020-03-06 09:44:13 --> Security Class Initialized
DEBUG - 2020-03-06 09:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:44:13 --> Input Class Initialized
INFO - 2020-03-06 09:44:13 --> Language Class Initialized
INFO - 2020-03-06 09:44:13 --> Loader Class Initialized
INFO - 2020-03-06 09:44:13 --> Helper loaded: url_helper
INFO - 2020-03-06 09:44:13 --> Helper loaded: string_helper
INFO - 2020-03-06 09:44:13 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:44:13 --> Controller Class Initialized
INFO - 2020-03-06 09:44:13 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:44:13 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:44:13 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:44:13 --> Helper loaded: form_helper
INFO - 2020-03-06 09:44:13 --> Form Validation Class Initialized
INFO - 2020-03-06 09:44:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 09:44:13 --> Final output sent to browser
DEBUG - 2020-03-06 09:44:13 --> Total execution time: 0.0552
INFO - 2020-03-06 09:44:41 --> Config Class Initialized
INFO - 2020-03-06 09:44:41 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:44:41 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:44:41 --> Utf8 Class Initialized
INFO - 2020-03-06 09:44:41 --> URI Class Initialized
INFO - 2020-03-06 09:44:41 --> Router Class Initialized
INFO - 2020-03-06 09:44:41 --> Output Class Initialized
INFO - 2020-03-06 09:44:41 --> Security Class Initialized
DEBUG - 2020-03-06 09:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:44:41 --> Input Class Initialized
INFO - 2020-03-06 09:44:41 --> Language Class Initialized
INFO - 2020-03-06 09:44:41 --> Loader Class Initialized
INFO - 2020-03-06 09:44:41 --> Helper loaded: url_helper
INFO - 2020-03-06 09:44:41 --> Helper loaded: string_helper
INFO - 2020-03-06 09:44:41 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:44:41 --> Controller Class Initialized
INFO - 2020-03-06 09:44:41 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:44:41 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:44:41 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:44:41 --> Helper loaded: form_helper
INFO - 2020-03-06 09:44:41 --> Form Validation Class Initialized
INFO - 2020-03-06 09:44:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 09:44:41 --> Final output sent to browser
DEBUG - 2020-03-06 09:44:41 --> Total execution time: 0.0072
INFO - 2020-03-06 09:45:32 --> Config Class Initialized
INFO - 2020-03-06 09:45:32 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:45:32 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:45:32 --> Utf8 Class Initialized
INFO - 2020-03-06 09:45:32 --> URI Class Initialized
INFO - 2020-03-06 09:45:32 --> Router Class Initialized
INFO - 2020-03-06 09:45:32 --> Output Class Initialized
INFO - 2020-03-06 09:45:32 --> Security Class Initialized
DEBUG - 2020-03-06 09:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:45:32 --> Input Class Initialized
INFO - 2020-03-06 09:45:32 --> Language Class Initialized
INFO - 2020-03-06 09:45:32 --> Loader Class Initialized
INFO - 2020-03-06 09:45:32 --> Helper loaded: url_helper
INFO - 2020-03-06 09:45:32 --> Helper loaded: string_helper
INFO - 2020-03-06 09:45:32 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:45:32 --> Controller Class Initialized
INFO - 2020-03-06 09:45:32 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:45:32 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:45:32 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:45:32 --> Helper loaded: form_helper
INFO - 2020-03-06 09:45:32 --> Form Validation Class Initialized
INFO - 2020-03-06 09:45:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 09:45:32 --> Final output sent to browser
DEBUG - 2020-03-06 09:45:32 --> Total execution time: 0.0084
INFO - 2020-03-06 09:45:48 --> Config Class Initialized
INFO - 2020-03-06 09:45:48 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:45:48 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:45:48 --> Utf8 Class Initialized
INFO - 2020-03-06 09:45:48 --> URI Class Initialized
INFO - 2020-03-06 09:45:48 --> Router Class Initialized
INFO - 2020-03-06 09:45:48 --> Output Class Initialized
INFO - 2020-03-06 09:45:48 --> Security Class Initialized
DEBUG - 2020-03-06 09:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:45:48 --> Input Class Initialized
INFO - 2020-03-06 09:45:48 --> Language Class Initialized
INFO - 2020-03-06 09:45:48 --> Loader Class Initialized
INFO - 2020-03-06 09:45:48 --> Helper loaded: url_helper
INFO - 2020-03-06 09:45:48 --> Helper loaded: string_helper
INFO - 2020-03-06 09:45:48 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:45:48 --> Controller Class Initialized
INFO - 2020-03-06 09:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:45:48 --> Pagination Class Initialized
INFO - 2020-03-06 09:45:48 --> Model "M_show" initialized
INFO - 2020-03-06 09:45:48 --> Helper loaded: form_helper
INFO - 2020-03-06 09:45:48 --> Form Validation Class Initialized
INFO - 2020-03-06 09:45:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:45:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 09:45:48 --> Final output sent to browser
DEBUG - 2020-03-06 09:45:48 --> Total execution time: 0.0075
INFO - 2020-03-06 09:48:07 --> Config Class Initialized
INFO - 2020-03-06 09:48:07 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:48:07 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:48:07 --> Utf8 Class Initialized
INFO - 2020-03-06 09:48:07 --> URI Class Initialized
DEBUG - 2020-03-06 09:48:07 --> No URI present. Default controller set.
INFO - 2020-03-06 09:48:07 --> Router Class Initialized
INFO - 2020-03-06 09:48:07 --> Output Class Initialized
INFO - 2020-03-06 09:48:07 --> Security Class Initialized
DEBUG - 2020-03-06 09:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:48:07 --> Input Class Initialized
INFO - 2020-03-06 09:48:07 --> Language Class Initialized
INFO - 2020-03-06 09:48:07 --> Loader Class Initialized
INFO - 2020-03-06 09:48:07 --> Helper loaded: url_helper
INFO - 2020-03-06 09:48:07 --> Helper loaded: string_helper
INFO - 2020-03-06 09:48:07 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:48:07 --> Controller Class Initialized
INFO - 2020-03-06 09:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:48:07 --> Pagination Class Initialized
INFO - 2020-03-06 09:48:07 --> Model "M_show" initialized
INFO - 2020-03-06 09:48:07 --> Helper loaded: form_helper
INFO - 2020-03-06 09:48:07 --> Form Validation Class Initialized
INFO - 2020-03-06 09:48:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:48:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:48:07 --> Final output sent to browser
DEBUG - 2020-03-06 09:48:07 --> Total execution time: 0.0479
INFO - 2020-03-06 09:51:13 --> Config Class Initialized
INFO - 2020-03-06 09:51:13 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:51:13 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:51:13 --> Utf8 Class Initialized
INFO - 2020-03-06 09:51:13 --> URI Class Initialized
DEBUG - 2020-03-06 09:51:13 --> No URI present. Default controller set.
INFO - 2020-03-06 09:51:13 --> Router Class Initialized
INFO - 2020-03-06 09:51:13 --> Output Class Initialized
INFO - 2020-03-06 09:51:13 --> Security Class Initialized
DEBUG - 2020-03-06 09:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:51:13 --> Input Class Initialized
INFO - 2020-03-06 09:51:13 --> Language Class Initialized
INFO - 2020-03-06 09:51:13 --> Loader Class Initialized
INFO - 2020-03-06 09:51:13 --> Helper loaded: url_helper
INFO - 2020-03-06 09:51:13 --> Helper loaded: string_helper
INFO - 2020-03-06 09:51:13 --> Database Driver Class Initialized
INFO - 2020-03-06 09:51:13 --> Config Class Initialized
INFO - 2020-03-06 09:51:13 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:51:13 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:51:13 --> Utf8 Class Initialized
INFO - 2020-03-06 09:51:13 --> URI Class Initialized
DEBUG - 2020-03-06 09:51:13 --> No URI present. Default controller set.
INFO - 2020-03-06 09:51:13 --> Router Class Initialized
INFO - 2020-03-06 09:51:13 --> Output Class Initialized
INFO - 2020-03-06 09:51:13 --> Security Class Initialized
DEBUG - 2020-03-06 09:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:51:13 --> Input Class Initialized
INFO - 2020-03-06 09:51:13 --> Language Class Initialized
INFO - 2020-03-06 09:51:13 --> Loader Class Initialized
INFO - 2020-03-06 09:51:13 --> Helper loaded: url_helper
INFO - 2020-03-06 09:51:13 --> Helper loaded: string_helper
INFO - 2020-03-06 09:51:13 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-03-06 09:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:51:13 --> Controller Class Initialized
INFO - 2020-03-06 09:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:51:13 --> Pagination Class Initialized
INFO - 2020-03-06 09:51:13 --> Model "M_show" initialized
INFO - 2020-03-06 09:51:13 --> Helper loaded: form_helper
INFO - 2020-03-06 09:51:13 --> Form Validation Class Initialized
INFO - 2020-03-06 09:51:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:51:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:51:13 --> Final output sent to browser
DEBUG - 2020-03-06 09:51:13 --> Total execution time: 0.0537
INFO - 2020-03-06 09:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:51:13 --> Controller Class Initialized
INFO - 2020-03-06 09:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:51:13 --> Pagination Class Initialized
INFO - 2020-03-06 09:51:13 --> Model "M_show" initialized
INFO - 2020-03-06 09:51:13 --> Helper loaded: form_helper
INFO - 2020-03-06 09:51:13 --> Form Validation Class Initialized
INFO - 2020-03-06 09:51:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:51:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:51:13 --> Final output sent to browser
DEBUG - 2020-03-06 09:51:13 --> Total execution time: 0.0254
INFO - 2020-03-06 09:51:27 --> Config Class Initialized
INFO - 2020-03-06 09:51:27 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:51:27 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:51:27 --> Utf8 Class Initialized
INFO - 2020-03-06 09:51:27 --> URI Class Initialized
INFO - 2020-03-06 09:51:27 --> Router Class Initialized
INFO - 2020-03-06 09:51:27 --> Output Class Initialized
INFO - 2020-03-06 09:51:27 --> Security Class Initialized
DEBUG - 2020-03-06 09:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:51:27 --> Input Class Initialized
INFO - 2020-03-06 09:51:27 --> Language Class Initialized
INFO - 2020-03-06 09:51:27 --> Loader Class Initialized
INFO - 2020-03-06 09:51:27 --> Helper loaded: url_helper
INFO - 2020-03-06 09:51:27 --> Helper loaded: string_helper
INFO - 2020-03-06 09:51:27 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:51:27 --> Controller Class Initialized
INFO - 2020-03-06 09:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:51:27 --> Pagination Class Initialized
INFO - 2020-03-06 09:51:27 --> Model "M_show" initialized
INFO - 2020-03-06 09:51:27 --> Helper loaded: form_helper
INFO - 2020-03-06 09:51:27 --> Form Validation Class Initialized
INFO - 2020-03-06 09:51:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:51:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 09:51:27 --> Final output sent to browser
DEBUG - 2020-03-06 09:51:27 --> Total execution time: 0.0088
INFO - 2020-03-06 09:51:31 --> Config Class Initialized
INFO - 2020-03-06 09:51:31 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:51:31 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:51:31 --> Utf8 Class Initialized
INFO - 2020-03-06 09:51:31 --> URI Class Initialized
INFO - 2020-03-06 09:51:31 --> Router Class Initialized
INFO - 2020-03-06 09:51:31 --> Output Class Initialized
INFO - 2020-03-06 09:51:31 --> Security Class Initialized
DEBUG - 2020-03-06 09:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:51:31 --> Input Class Initialized
INFO - 2020-03-06 09:51:31 --> Language Class Initialized
INFO - 2020-03-06 09:51:31 --> Loader Class Initialized
INFO - 2020-03-06 09:51:31 --> Helper loaded: url_helper
INFO - 2020-03-06 09:51:31 --> Helper loaded: string_helper
INFO - 2020-03-06 09:51:31 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:51:31 --> Controller Class Initialized
INFO - 2020-03-06 09:51:31 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:51:31 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:51:31 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:51:31 --> Helper loaded: form_helper
INFO - 2020-03-06 09:51:31 --> Form Validation Class Initialized
INFO - 2020-03-06 09:51:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 09:51:31 --> Final output sent to browser
DEBUG - 2020-03-06 09:51:31 --> Total execution time: 0.0097
INFO - 2020-03-06 09:51:58 --> Config Class Initialized
INFO - 2020-03-06 09:51:58 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:51:58 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:51:58 --> Utf8 Class Initialized
INFO - 2020-03-06 09:51:58 --> URI Class Initialized
INFO - 2020-03-06 09:51:58 --> Router Class Initialized
INFO - 2020-03-06 09:51:58 --> Output Class Initialized
INFO - 2020-03-06 09:51:58 --> Security Class Initialized
DEBUG - 2020-03-06 09:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:51:58 --> Input Class Initialized
INFO - 2020-03-06 09:51:58 --> Language Class Initialized
INFO - 2020-03-06 09:51:58 --> Loader Class Initialized
INFO - 2020-03-06 09:51:58 --> Helper loaded: url_helper
INFO - 2020-03-06 09:51:58 --> Helper loaded: string_helper
INFO - 2020-03-06 09:51:58 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:51:58 --> Controller Class Initialized
INFO - 2020-03-06 09:51:58 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:51:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:51:58 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:51:58 --> Helper loaded: form_helper
INFO - 2020-03-06 09:51:58 --> Form Validation Class Initialized
INFO - 2020-03-06 09:51:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 09:51:58 --> Final output sent to browser
DEBUG - 2020-03-06 09:51:58 --> Total execution time: 0.0110
INFO - 2020-03-06 09:52:16 --> Config Class Initialized
INFO - 2020-03-06 09:52:16 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:52:16 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:52:16 --> Utf8 Class Initialized
INFO - 2020-03-06 09:52:16 --> URI Class Initialized
INFO - 2020-03-06 09:52:16 --> Router Class Initialized
INFO - 2020-03-06 09:52:16 --> Output Class Initialized
INFO - 2020-03-06 09:52:16 --> Security Class Initialized
DEBUG - 2020-03-06 09:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:52:16 --> Input Class Initialized
INFO - 2020-03-06 09:52:16 --> Language Class Initialized
INFO - 2020-03-06 09:52:16 --> Loader Class Initialized
INFO - 2020-03-06 09:52:16 --> Helper loaded: url_helper
INFO - 2020-03-06 09:52:16 --> Helper loaded: string_helper
INFO - 2020-03-06 09:52:16 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:52:16 --> Controller Class Initialized
INFO - 2020-03-06 09:52:16 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:52:16 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:52:16 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:52:16 --> Helper loaded: form_helper
INFO - 2020-03-06 09:52:16 --> Form Validation Class Initialized
INFO - 2020-03-06 09:52:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 09:52:16 --> Final output sent to browser
DEBUG - 2020-03-06 09:52:16 --> Total execution time: 0.0078
INFO - 2020-03-06 09:52:18 --> Config Class Initialized
INFO - 2020-03-06 09:52:18 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:52:18 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:52:18 --> Utf8 Class Initialized
INFO - 2020-03-06 09:52:18 --> URI Class Initialized
DEBUG - 2020-03-06 09:52:18 --> No URI present. Default controller set.
INFO - 2020-03-06 09:52:18 --> Router Class Initialized
INFO - 2020-03-06 09:52:18 --> Output Class Initialized
INFO - 2020-03-06 09:52:18 --> Security Class Initialized
DEBUG - 2020-03-06 09:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:52:18 --> Input Class Initialized
INFO - 2020-03-06 09:52:18 --> Language Class Initialized
INFO - 2020-03-06 09:52:18 --> Loader Class Initialized
INFO - 2020-03-06 09:52:18 --> Helper loaded: url_helper
INFO - 2020-03-06 09:52:18 --> Helper loaded: string_helper
INFO - 2020-03-06 09:52:18 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:52:18 --> Controller Class Initialized
INFO - 2020-03-06 09:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:52:18 --> Pagination Class Initialized
INFO - 2020-03-06 09:52:18 --> Model "M_show" initialized
INFO - 2020-03-06 09:52:18 --> Helper loaded: form_helper
INFO - 2020-03-06 09:52:18 --> Form Validation Class Initialized
INFO - 2020-03-06 09:52:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:52:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:52:18 --> Final output sent to browser
DEBUG - 2020-03-06 09:52:18 --> Total execution time: 0.0054
INFO - 2020-03-06 09:52:19 --> Config Class Initialized
INFO - 2020-03-06 09:52:19 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:52:19 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:52:19 --> Utf8 Class Initialized
INFO - 2020-03-06 09:52:19 --> URI Class Initialized
DEBUG - 2020-03-06 09:52:19 --> No URI present. Default controller set.
INFO - 2020-03-06 09:52:19 --> Router Class Initialized
INFO - 2020-03-06 09:52:19 --> Output Class Initialized
INFO - 2020-03-06 09:52:19 --> Security Class Initialized
DEBUG - 2020-03-06 09:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:52:19 --> Input Class Initialized
INFO - 2020-03-06 09:52:19 --> Language Class Initialized
INFO - 2020-03-06 09:52:19 --> Loader Class Initialized
INFO - 2020-03-06 09:52:19 --> Helper loaded: url_helper
INFO - 2020-03-06 09:52:19 --> Helper loaded: string_helper
INFO - 2020-03-06 09:52:19 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:52:19 --> Controller Class Initialized
INFO - 2020-03-06 09:52:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:52:19 --> Pagination Class Initialized
INFO - 2020-03-06 09:52:19 --> Model "M_show" initialized
INFO - 2020-03-06 09:52:19 --> Helper loaded: form_helper
INFO - 2020-03-06 09:52:19 --> Form Validation Class Initialized
INFO - 2020-03-06 09:52:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:52:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:52:19 --> Final output sent to browser
DEBUG - 2020-03-06 09:52:19 --> Total execution time: 0.0057
INFO - 2020-03-06 09:55:43 --> Config Class Initialized
INFO - 2020-03-06 09:55:43 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:55:43 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:55:43 --> Utf8 Class Initialized
INFO - 2020-03-06 09:55:43 --> URI Class Initialized
DEBUG - 2020-03-06 09:55:43 --> No URI present. Default controller set.
INFO - 2020-03-06 09:55:43 --> Router Class Initialized
INFO - 2020-03-06 09:55:43 --> Output Class Initialized
INFO - 2020-03-06 09:55:43 --> Security Class Initialized
DEBUG - 2020-03-06 09:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:55:43 --> Input Class Initialized
INFO - 2020-03-06 09:55:43 --> Language Class Initialized
INFO - 2020-03-06 09:55:43 --> Loader Class Initialized
INFO - 2020-03-06 09:55:43 --> Helper loaded: url_helper
INFO - 2020-03-06 09:55:43 --> Helper loaded: string_helper
INFO - 2020-03-06 09:55:43 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:55:43 --> Controller Class Initialized
INFO - 2020-03-06 09:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:55:43 --> Pagination Class Initialized
INFO - 2020-03-06 09:55:43 --> Model "M_show" initialized
INFO - 2020-03-06 09:55:43 --> Helper loaded: form_helper
INFO - 2020-03-06 09:55:43 --> Form Validation Class Initialized
INFO - 2020-03-06 09:55:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:55:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 09:55:43 --> Final output sent to browser
DEBUG - 2020-03-06 09:55:43 --> Total execution time: 0.0296
INFO - 2020-03-06 09:55:54 --> Config Class Initialized
INFO - 2020-03-06 09:55:54 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:55:54 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:55:54 --> Utf8 Class Initialized
INFO - 2020-03-06 09:55:54 --> URI Class Initialized
INFO - 2020-03-06 09:55:54 --> Router Class Initialized
INFO - 2020-03-06 09:55:54 --> Output Class Initialized
INFO - 2020-03-06 09:55:54 --> Security Class Initialized
DEBUG - 2020-03-06 09:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:55:54 --> Input Class Initialized
INFO - 2020-03-06 09:55:54 --> Language Class Initialized
INFO - 2020-03-06 09:55:54 --> Loader Class Initialized
INFO - 2020-03-06 09:55:54 --> Helper loaded: url_helper
INFO - 2020-03-06 09:55:54 --> Helper loaded: string_helper
INFO - 2020-03-06 09:55:54 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:55:54 --> Controller Class Initialized
INFO - 2020-03-06 09:55:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:55:54 --> Pagination Class Initialized
INFO - 2020-03-06 09:55:54 --> Model "M_show" initialized
INFO - 2020-03-06 09:55:54 --> Helper loaded: form_helper
INFO - 2020-03-06 09:55:54 --> Form Validation Class Initialized
INFO - 2020-03-06 09:55:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:55:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-06 09:55:54 --> Final output sent to browser
DEBUG - 2020-03-06 09:55:54 --> Total execution time: 0.0059
INFO - 2020-03-06 09:56:09 --> Config Class Initialized
INFO - 2020-03-06 09:56:09 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:56:09 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:56:09 --> Utf8 Class Initialized
INFO - 2020-03-06 09:56:09 --> URI Class Initialized
INFO - 2020-03-06 09:56:09 --> Router Class Initialized
INFO - 2020-03-06 09:56:09 --> Output Class Initialized
INFO - 2020-03-06 09:56:09 --> Security Class Initialized
DEBUG - 2020-03-06 09:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:56:09 --> Input Class Initialized
INFO - 2020-03-06 09:56:09 --> Language Class Initialized
INFO - 2020-03-06 09:56:09 --> Loader Class Initialized
INFO - 2020-03-06 09:56:09 --> Helper loaded: url_helper
INFO - 2020-03-06 09:56:09 --> Helper loaded: string_helper
INFO - 2020-03-06 09:56:09 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:56:09 --> Controller Class Initialized
INFO - 2020-03-06 09:56:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 09:56:09 --> Pagination Class Initialized
INFO - 2020-03-06 09:56:09 --> Model "M_show" initialized
INFO - 2020-03-06 09:56:09 --> Helper loaded: form_helper
INFO - 2020-03-06 09:56:09 --> Form Validation Class Initialized
INFO - 2020-03-06 09:56:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 09:56:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 09:56:09 --> Final output sent to browser
DEBUG - 2020-03-06 09:56:09 --> Total execution time: 0.0094
INFO - 2020-03-06 09:56:15 --> Config Class Initialized
INFO - 2020-03-06 09:56:15 --> Hooks Class Initialized
DEBUG - 2020-03-06 09:56:15 --> UTF-8 Support Enabled
INFO - 2020-03-06 09:56:15 --> Utf8 Class Initialized
INFO - 2020-03-06 09:56:15 --> URI Class Initialized
INFO - 2020-03-06 09:56:15 --> Router Class Initialized
INFO - 2020-03-06 09:56:15 --> Output Class Initialized
INFO - 2020-03-06 09:56:15 --> Security Class Initialized
DEBUG - 2020-03-06 09:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 09:56:15 --> Input Class Initialized
INFO - 2020-03-06 09:56:15 --> Language Class Initialized
INFO - 2020-03-06 09:56:15 --> Loader Class Initialized
INFO - 2020-03-06 09:56:15 --> Helper loaded: url_helper
INFO - 2020-03-06 09:56:15 --> Helper loaded: string_helper
INFO - 2020-03-06 09:56:15 --> Database Driver Class Initialized
DEBUG - 2020-03-06 09:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 09:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 09:56:15 --> Controller Class Initialized
INFO - 2020-03-06 09:56:15 --> Model "M_tiket" initialized
INFO - 2020-03-06 09:56:15 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 09:56:15 --> Model "M_pesan" initialized
INFO - 2020-03-06 09:56:15 --> Helper loaded: form_helper
INFO - 2020-03-06 09:56:15 --> Form Validation Class Initialized
INFO - 2020-03-06 09:56:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 09:56:15 --> Final output sent to browser
DEBUG - 2020-03-06 09:56:15 --> Total execution time: 0.0095
INFO - 2020-03-06 10:12:36 --> Config Class Initialized
INFO - 2020-03-06 10:12:36 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:12:36 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:12:36 --> Utf8 Class Initialized
INFO - 2020-03-06 10:12:36 --> URI Class Initialized
DEBUG - 2020-03-06 10:12:36 --> No URI present. Default controller set.
INFO - 2020-03-06 10:12:36 --> Router Class Initialized
INFO - 2020-03-06 10:12:36 --> Output Class Initialized
INFO - 2020-03-06 10:12:36 --> Security Class Initialized
DEBUG - 2020-03-06 10:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:12:36 --> Input Class Initialized
INFO - 2020-03-06 10:12:36 --> Language Class Initialized
INFO - 2020-03-06 10:12:36 --> Loader Class Initialized
INFO - 2020-03-06 10:12:36 --> Helper loaded: url_helper
INFO - 2020-03-06 10:12:36 --> Helper loaded: string_helper
INFO - 2020-03-06 10:12:36 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:12:36 --> Controller Class Initialized
INFO - 2020-03-06 10:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:12:36 --> Pagination Class Initialized
INFO - 2020-03-06 10:12:36 --> Model "M_show" initialized
INFO - 2020-03-06 10:12:36 --> Helper loaded: form_helper
INFO - 2020-03-06 10:12:36 --> Form Validation Class Initialized
INFO - 2020-03-06 10:12:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:12:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:12:36 --> Final output sent to browser
DEBUG - 2020-03-06 10:12:36 --> Total execution time: 0.0290
INFO - 2020-03-06 10:12:47 --> Config Class Initialized
INFO - 2020-03-06 10:12:47 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:12:47 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:12:47 --> Utf8 Class Initialized
INFO - 2020-03-06 10:12:47 --> URI Class Initialized
INFO - 2020-03-06 10:12:47 --> Router Class Initialized
INFO - 2020-03-06 10:12:47 --> Output Class Initialized
INFO - 2020-03-06 10:12:47 --> Security Class Initialized
DEBUG - 2020-03-06 10:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:12:47 --> Input Class Initialized
INFO - 2020-03-06 10:12:47 --> Language Class Initialized
INFO - 2020-03-06 10:12:47 --> Loader Class Initialized
INFO - 2020-03-06 10:12:47 --> Helper loaded: url_helper
INFO - 2020-03-06 10:12:47 --> Helper loaded: string_helper
INFO - 2020-03-06 10:12:47 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:12:47 --> Controller Class Initialized
INFO - 2020-03-06 10:12:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:12:47 --> Pagination Class Initialized
INFO - 2020-03-06 10:12:47 --> Model "M_show" initialized
INFO - 2020-03-06 10:12:47 --> Helper loaded: form_helper
INFO - 2020-03-06 10:12:47 --> Form Validation Class Initialized
INFO - 2020-03-06 10:12:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:12:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 10:12:47 --> Final output sent to browser
DEBUG - 2020-03-06 10:12:47 --> Total execution time: 0.0073
INFO - 2020-03-06 10:12:52 --> Config Class Initialized
INFO - 2020-03-06 10:12:52 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:12:52 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:12:52 --> Utf8 Class Initialized
INFO - 2020-03-06 10:12:52 --> URI Class Initialized
INFO - 2020-03-06 10:12:52 --> Router Class Initialized
INFO - 2020-03-06 10:12:52 --> Output Class Initialized
INFO - 2020-03-06 10:12:52 --> Security Class Initialized
DEBUG - 2020-03-06 10:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:12:52 --> Input Class Initialized
INFO - 2020-03-06 10:12:52 --> Language Class Initialized
INFO - 2020-03-06 10:12:52 --> Loader Class Initialized
INFO - 2020-03-06 10:12:52 --> Helper loaded: url_helper
INFO - 2020-03-06 10:12:52 --> Helper loaded: string_helper
INFO - 2020-03-06 10:12:52 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:12:52 --> Controller Class Initialized
INFO - 2020-03-06 10:12:52 --> Model "M_tiket" initialized
INFO - 2020-03-06 10:12:52 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 10:12:52 --> Model "M_pesan" initialized
INFO - 2020-03-06 10:12:52 --> Helper loaded: form_helper
INFO - 2020-03-06 10:12:52 --> Form Validation Class Initialized
INFO - 2020-03-06 10:12:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 10:12:52 --> Final output sent to browser
DEBUG - 2020-03-06 10:12:52 --> Total execution time: 0.0420
INFO - 2020-03-06 10:13:14 --> Config Class Initialized
INFO - 2020-03-06 10:13:14 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:13:14 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:13:14 --> Utf8 Class Initialized
INFO - 2020-03-06 10:13:14 --> URI Class Initialized
INFO - 2020-03-06 10:13:14 --> Router Class Initialized
INFO - 2020-03-06 10:13:14 --> Output Class Initialized
INFO - 2020-03-06 10:13:14 --> Security Class Initialized
DEBUG - 2020-03-06 10:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:13:14 --> Input Class Initialized
INFO - 2020-03-06 10:13:14 --> Language Class Initialized
INFO - 2020-03-06 10:13:14 --> Loader Class Initialized
INFO - 2020-03-06 10:13:14 --> Helper loaded: url_helper
INFO - 2020-03-06 10:13:14 --> Helper loaded: string_helper
INFO - 2020-03-06 10:13:14 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:13:14 --> Controller Class Initialized
INFO - 2020-03-06 10:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:13:14 --> Pagination Class Initialized
INFO - 2020-03-06 10:13:14 --> Model "M_show" initialized
INFO - 2020-03-06 10:13:14 --> Helper loaded: form_helper
INFO - 2020-03-06 10:13:14 --> Form Validation Class Initialized
INFO - 2020-03-06 10:13:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:13:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 10:13:14 --> Final output sent to browser
DEBUG - 2020-03-06 10:13:14 --> Total execution time: 0.0083
INFO - 2020-03-06 10:13:21 --> Config Class Initialized
INFO - 2020-03-06 10:13:21 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:13:21 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:13:21 --> Utf8 Class Initialized
INFO - 2020-03-06 10:13:21 --> URI Class Initialized
INFO - 2020-03-06 10:13:21 --> Router Class Initialized
INFO - 2020-03-06 10:13:21 --> Output Class Initialized
INFO - 2020-03-06 10:13:21 --> Security Class Initialized
DEBUG - 2020-03-06 10:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:13:21 --> Input Class Initialized
INFO - 2020-03-06 10:13:21 --> Language Class Initialized
INFO - 2020-03-06 10:13:21 --> Loader Class Initialized
INFO - 2020-03-06 10:13:21 --> Helper loaded: url_helper
INFO - 2020-03-06 10:13:21 --> Helper loaded: string_helper
INFO - 2020-03-06 10:13:21 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:13:21 --> Controller Class Initialized
INFO - 2020-03-06 10:13:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:13:21 --> Pagination Class Initialized
INFO - 2020-03-06 10:13:21 --> Model "M_show" initialized
INFO - 2020-03-06 10:13:21 --> Helper loaded: form_helper
INFO - 2020-03-06 10:13:21 --> Form Validation Class Initialized
INFO - 2020-03-06 10:13:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:13:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:13:21 --> Final output sent to browser
DEBUG - 2020-03-06 10:13:21 --> Total execution time: 0.0056
INFO - 2020-03-06 10:13:27 --> Config Class Initialized
INFO - 2020-03-06 10:13:27 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:13:27 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:13:27 --> Utf8 Class Initialized
INFO - 2020-03-06 10:13:27 --> URI Class Initialized
INFO - 2020-03-06 10:13:27 --> Router Class Initialized
INFO - 2020-03-06 10:13:27 --> Output Class Initialized
INFO - 2020-03-06 10:13:27 --> Security Class Initialized
DEBUG - 2020-03-06 10:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:13:27 --> Input Class Initialized
INFO - 2020-03-06 10:13:27 --> Language Class Initialized
INFO - 2020-03-06 10:13:27 --> Loader Class Initialized
INFO - 2020-03-06 10:13:27 --> Helper loaded: url_helper
INFO - 2020-03-06 10:13:27 --> Helper loaded: string_helper
INFO - 2020-03-06 10:13:27 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:13:27 --> Controller Class Initialized
INFO - 2020-03-06 10:13:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:13:27 --> Pagination Class Initialized
INFO - 2020-03-06 10:13:27 --> Model "M_show" initialized
INFO - 2020-03-06 10:13:27 --> Helper loaded: form_helper
INFO - 2020-03-06 10:13:27 --> Form Validation Class Initialized
INFO - 2020-03-06 10:13:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:13:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-06 10:13:27 --> Final output sent to browser
DEBUG - 2020-03-06 10:13:27 --> Total execution time: 0.0164
INFO - 2020-03-06 10:13:39 --> Config Class Initialized
INFO - 2020-03-06 10:13:39 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:13:39 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:13:39 --> Utf8 Class Initialized
INFO - 2020-03-06 10:13:39 --> URI Class Initialized
INFO - 2020-03-06 10:13:39 --> Router Class Initialized
INFO - 2020-03-06 10:13:39 --> Output Class Initialized
INFO - 2020-03-06 10:13:39 --> Security Class Initialized
DEBUG - 2020-03-06 10:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:13:39 --> Input Class Initialized
INFO - 2020-03-06 10:13:39 --> Language Class Initialized
INFO - 2020-03-06 10:13:39 --> Loader Class Initialized
INFO - 2020-03-06 10:13:39 --> Helper loaded: url_helper
INFO - 2020-03-06 10:13:39 --> Helper loaded: string_helper
INFO - 2020-03-06 10:13:39 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:13:39 --> Controller Class Initialized
INFO - 2020-03-06 10:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:13:39 --> Pagination Class Initialized
INFO - 2020-03-06 10:13:39 --> Model "M_show" initialized
INFO - 2020-03-06 10:13:39 --> Helper loaded: form_helper
INFO - 2020-03-06 10:13:39 --> Form Validation Class Initialized
INFO - 2020-03-06 10:13:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:13:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 10:13:39 --> Final output sent to browser
DEBUG - 2020-03-06 10:13:39 --> Total execution time: 0.0054
INFO - 2020-03-06 10:13:55 --> Config Class Initialized
INFO - 2020-03-06 10:13:55 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:13:55 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:13:55 --> Utf8 Class Initialized
INFO - 2020-03-06 10:13:55 --> URI Class Initialized
INFO - 2020-03-06 10:13:55 --> Router Class Initialized
INFO - 2020-03-06 10:13:55 --> Output Class Initialized
INFO - 2020-03-06 10:13:55 --> Security Class Initialized
DEBUG - 2020-03-06 10:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:13:55 --> Input Class Initialized
INFO - 2020-03-06 10:13:55 --> Language Class Initialized
INFO - 2020-03-06 10:13:55 --> Loader Class Initialized
INFO - 2020-03-06 10:13:55 --> Helper loaded: url_helper
INFO - 2020-03-06 10:13:55 --> Helper loaded: string_helper
INFO - 2020-03-06 10:13:55 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:13:55 --> Controller Class Initialized
INFO - 2020-03-06 10:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:13:55 --> Pagination Class Initialized
INFO - 2020-03-06 10:13:55 --> Model "M_show" initialized
INFO - 2020-03-06 10:13:55 --> Helper loaded: form_helper
INFO - 2020-03-06 10:13:55 --> Form Validation Class Initialized
INFO - 2020-03-06 10:13:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:13:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-06 10:13:55 --> Final output sent to browser
DEBUG - 2020-03-06 10:13:55 --> Total execution time: 0.0059
INFO - 2020-03-06 10:14:18 --> Config Class Initialized
INFO - 2020-03-06 10:14:18 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:14:18 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:14:18 --> Utf8 Class Initialized
INFO - 2020-03-06 10:14:18 --> URI Class Initialized
INFO - 2020-03-06 10:14:18 --> Router Class Initialized
INFO - 2020-03-06 10:14:18 --> Output Class Initialized
INFO - 2020-03-06 10:14:18 --> Security Class Initialized
DEBUG - 2020-03-06 10:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:14:18 --> Input Class Initialized
INFO - 2020-03-06 10:14:18 --> Language Class Initialized
INFO - 2020-03-06 10:14:18 --> Loader Class Initialized
INFO - 2020-03-06 10:14:18 --> Helper loaded: url_helper
INFO - 2020-03-06 10:14:18 --> Helper loaded: string_helper
INFO - 2020-03-06 10:14:18 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:14:18 --> Controller Class Initialized
INFO - 2020-03-06 10:14:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:14:18 --> Pagination Class Initialized
INFO - 2020-03-06 10:14:18 --> Model "M_show" initialized
INFO - 2020-03-06 10:14:18 --> Helper loaded: form_helper
INFO - 2020-03-06 10:14:18 --> Form Validation Class Initialized
INFO - 2020-03-06 10:14:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:14:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-06 10:14:18 --> Final output sent to browser
DEBUG - 2020-03-06 10:14:18 --> Total execution time: 0.0061
INFO - 2020-03-06 10:14:22 --> Config Class Initialized
INFO - 2020-03-06 10:14:22 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:14:22 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:14:22 --> Utf8 Class Initialized
INFO - 2020-03-06 10:14:22 --> URI Class Initialized
INFO - 2020-03-06 10:14:22 --> Router Class Initialized
INFO - 2020-03-06 10:14:22 --> Output Class Initialized
INFO - 2020-03-06 10:14:22 --> Security Class Initialized
DEBUG - 2020-03-06 10:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:14:22 --> Input Class Initialized
INFO - 2020-03-06 10:14:22 --> Language Class Initialized
INFO - 2020-03-06 10:14:22 --> Loader Class Initialized
INFO - 2020-03-06 10:14:22 --> Helper loaded: url_helper
INFO - 2020-03-06 10:14:22 --> Helper loaded: string_helper
INFO - 2020-03-06 10:14:22 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:14:22 --> Controller Class Initialized
INFO - 2020-03-06 10:14:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:14:22 --> Pagination Class Initialized
INFO - 2020-03-06 10:14:22 --> Model "M_show" initialized
INFO - 2020-03-06 10:14:22 --> Helper loaded: form_helper
INFO - 2020-03-06 10:14:22 --> Form Validation Class Initialized
INFO - 2020-03-06 10:14:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:14:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-06 10:14:22 --> Final output sent to browser
DEBUG - 2020-03-06 10:14:22 --> Total execution time: 0.0082
INFO - 2020-03-06 10:15:00 --> Config Class Initialized
INFO - 2020-03-06 10:15:00 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:15:00 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:15:00 --> Utf8 Class Initialized
INFO - 2020-03-06 10:15:00 --> URI Class Initialized
DEBUG - 2020-03-06 10:15:00 --> No URI present. Default controller set.
INFO - 2020-03-06 10:15:00 --> Router Class Initialized
INFO - 2020-03-06 10:15:00 --> Output Class Initialized
INFO - 2020-03-06 10:15:00 --> Security Class Initialized
DEBUG - 2020-03-06 10:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:15:00 --> Input Class Initialized
INFO - 2020-03-06 10:15:00 --> Language Class Initialized
INFO - 2020-03-06 10:15:00 --> Loader Class Initialized
INFO - 2020-03-06 10:15:00 --> Helper loaded: url_helper
INFO - 2020-03-06 10:15:00 --> Helper loaded: string_helper
INFO - 2020-03-06 10:15:00 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:15:00 --> Controller Class Initialized
INFO - 2020-03-06 10:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:15:00 --> Pagination Class Initialized
INFO - 2020-03-06 10:15:00 --> Model "M_show" initialized
INFO - 2020-03-06 10:15:00 --> Helper loaded: form_helper
INFO - 2020-03-06 10:15:00 --> Form Validation Class Initialized
INFO - 2020-03-06 10:15:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:15:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:15:00 --> Final output sent to browser
DEBUG - 2020-03-06 10:15:00 --> Total execution time: 0.0071
INFO - 2020-03-06 10:15:13 --> Config Class Initialized
INFO - 2020-03-06 10:15:13 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:15:13 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:15:13 --> Utf8 Class Initialized
INFO - 2020-03-06 10:15:13 --> URI Class Initialized
INFO - 2020-03-06 10:15:13 --> Router Class Initialized
INFO - 2020-03-06 10:15:13 --> Output Class Initialized
INFO - 2020-03-06 10:15:13 --> Security Class Initialized
DEBUG - 2020-03-06 10:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:15:13 --> Input Class Initialized
INFO - 2020-03-06 10:15:13 --> Language Class Initialized
INFO - 2020-03-06 10:15:13 --> Loader Class Initialized
INFO - 2020-03-06 10:15:13 --> Helper loaded: url_helper
INFO - 2020-03-06 10:15:13 --> Helper loaded: string_helper
INFO - 2020-03-06 10:15:13 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:15:13 --> Controller Class Initialized
INFO - 2020-03-06 10:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:15:13 --> Pagination Class Initialized
INFO - 2020-03-06 10:15:13 --> Model "M_show" initialized
INFO - 2020-03-06 10:15:13 --> Helper loaded: form_helper
INFO - 2020-03-06 10:15:13 --> Form Validation Class Initialized
INFO - 2020-03-06 10:15:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:15:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-06 10:15:13 --> Final output sent to browser
DEBUG - 2020-03-06 10:15:13 --> Total execution time: 0.0056
INFO - 2020-03-06 10:15:27 --> Config Class Initialized
INFO - 2020-03-06 10:15:27 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:15:27 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:15:27 --> Utf8 Class Initialized
INFO - 2020-03-06 10:15:27 --> URI Class Initialized
DEBUG - 2020-03-06 10:15:27 --> No URI present. Default controller set.
INFO - 2020-03-06 10:15:27 --> Router Class Initialized
INFO - 2020-03-06 10:15:27 --> Output Class Initialized
INFO - 2020-03-06 10:15:27 --> Security Class Initialized
DEBUG - 2020-03-06 10:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:15:27 --> Input Class Initialized
INFO - 2020-03-06 10:15:27 --> Language Class Initialized
INFO - 2020-03-06 10:15:27 --> Loader Class Initialized
INFO - 2020-03-06 10:15:27 --> Helper loaded: url_helper
INFO - 2020-03-06 10:15:27 --> Helper loaded: string_helper
INFO - 2020-03-06 10:15:27 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:15:27 --> Controller Class Initialized
INFO - 2020-03-06 10:15:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:15:27 --> Pagination Class Initialized
INFO - 2020-03-06 10:15:27 --> Model "M_show" initialized
INFO - 2020-03-06 10:15:27 --> Helper loaded: form_helper
INFO - 2020-03-06 10:15:27 --> Form Validation Class Initialized
INFO - 2020-03-06 10:15:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:15:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:15:27 --> Final output sent to browser
DEBUG - 2020-03-06 10:15:27 --> Total execution time: 0.0064
INFO - 2020-03-06 10:15:31 --> Config Class Initialized
INFO - 2020-03-06 10:15:31 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:15:31 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:15:31 --> Utf8 Class Initialized
INFO - 2020-03-06 10:15:31 --> URI Class Initialized
INFO - 2020-03-06 10:15:31 --> Router Class Initialized
INFO - 2020-03-06 10:15:31 --> Output Class Initialized
INFO - 2020-03-06 10:15:31 --> Security Class Initialized
DEBUG - 2020-03-06 10:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:15:31 --> Input Class Initialized
INFO - 2020-03-06 10:15:31 --> Language Class Initialized
INFO - 2020-03-06 10:15:31 --> Loader Class Initialized
INFO - 2020-03-06 10:15:31 --> Helper loaded: url_helper
INFO - 2020-03-06 10:15:31 --> Helper loaded: string_helper
INFO - 2020-03-06 10:15:31 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:15:31 --> Controller Class Initialized
INFO - 2020-03-06 10:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:15:31 --> Pagination Class Initialized
INFO - 2020-03-06 10:15:31 --> Model "M_show" initialized
INFO - 2020-03-06 10:15:31 --> Helper loaded: form_helper
INFO - 2020-03-06 10:15:31 --> Form Validation Class Initialized
INFO - 2020-03-06 10:15:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:15:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-06 10:15:31 --> Final output sent to browser
DEBUG - 2020-03-06 10:15:31 --> Total execution time: 0.0052
INFO - 2020-03-06 10:15:41 --> Config Class Initialized
INFO - 2020-03-06 10:15:41 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:15:41 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:15:41 --> Utf8 Class Initialized
INFO - 2020-03-06 10:15:41 --> URI Class Initialized
INFO - 2020-03-06 10:15:41 --> Router Class Initialized
INFO - 2020-03-06 10:15:41 --> Output Class Initialized
INFO - 2020-03-06 10:15:41 --> Security Class Initialized
DEBUG - 2020-03-06 10:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:15:41 --> Input Class Initialized
INFO - 2020-03-06 10:15:41 --> Language Class Initialized
INFO - 2020-03-06 10:15:41 --> Loader Class Initialized
INFO - 2020-03-06 10:15:41 --> Helper loaded: url_helper
INFO - 2020-03-06 10:15:41 --> Helper loaded: string_helper
INFO - 2020-03-06 10:15:41 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:15:41 --> Controller Class Initialized
INFO - 2020-03-06 10:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:15:41 --> Pagination Class Initialized
INFO - 2020-03-06 10:15:41 --> Model "M_show" initialized
INFO - 2020-03-06 10:15:41 --> Helper loaded: form_helper
INFO - 2020-03-06 10:15:41 --> Form Validation Class Initialized
INFO - 2020-03-06 10:15:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:15:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 10:15:41 --> Final output sent to browser
DEBUG - 2020-03-06 10:15:41 --> Total execution time: 0.0054
INFO - 2020-03-06 10:15:53 --> Config Class Initialized
INFO - 2020-03-06 10:15:53 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:15:53 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:15:53 --> Utf8 Class Initialized
INFO - 2020-03-06 10:15:53 --> URI Class Initialized
INFO - 2020-03-06 10:15:53 --> Router Class Initialized
INFO - 2020-03-06 10:15:53 --> Output Class Initialized
INFO - 2020-03-06 10:15:53 --> Security Class Initialized
DEBUG - 2020-03-06 10:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:15:53 --> Input Class Initialized
INFO - 2020-03-06 10:15:53 --> Language Class Initialized
INFO - 2020-03-06 10:15:53 --> Loader Class Initialized
INFO - 2020-03-06 10:15:53 --> Helper loaded: url_helper
INFO - 2020-03-06 10:15:53 --> Helper loaded: string_helper
INFO - 2020-03-06 10:15:53 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:15:53 --> Controller Class Initialized
INFO - 2020-03-06 10:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:15:53 --> Pagination Class Initialized
INFO - 2020-03-06 10:15:53 --> Model "M_show" initialized
INFO - 2020-03-06 10:15:53 --> Helper loaded: form_helper
INFO - 2020-03-06 10:15:53 --> Form Validation Class Initialized
INFO - 2020-03-06 10:15:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:15:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:15:53 --> Final output sent to browser
DEBUG - 2020-03-06 10:15:53 --> Total execution time: 0.0061
INFO - 2020-03-06 10:16:00 --> Config Class Initialized
INFO - 2020-03-06 10:16:00 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:16:00 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:16:00 --> Utf8 Class Initialized
INFO - 2020-03-06 10:16:00 --> URI Class Initialized
INFO - 2020-03-06 10:16:00 --> Router Class Initialized
INFO - 2020-03-06 10:16:00 --> Output Class Initialized
INFO - 2020-03-06 10:16:00 --> Security Class Initialized
DEBUG - 2020-03-06 10:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:16:00 --> Input Class Initialized
INFO - 2020-03-06 10:16:00 --> Language Class Initialized
INFO - 2020-03-06 10:16:00 --> Loader Class Initialized
INFO - 2020-03-06 10:16:00 --> Helper loaded: url_helper
INFO - 2020-03-06 10:16:00 --> Helper loaded: string_helper
INFO - 2020-03-06 10:16:00 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:16:00 --> Controller Class Initialized
INFO - 2020-03-06 10:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:16:00 --> Pagination Class Initialized
INFO - 2020-03-06 10:16:00 --> Model "M_show" initialized
INFO - 2020-03-06 10:16:00 --> Helper loaded: form_helper
INFO - 2020-03-06 10:16:00 --> Form Validation Class Initialized
INFO - 2020-03-06 10:16:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:16:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 10:16:00 --> Final output sent to browser
DEBUG - 2020-03-06 10:16:00 --> Total execution time: 0.0061
INFO - 2020-03-06 10:16:04 --> Config Class Initialized
INFO - 2020-03-06 10:16:04 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:16:04 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:16:04 --> Utf8 Class Initialized
INFO - 2020-03-06 10:16:04 --> URI Class Initialized
INFO - 2020-03-06 10:16:04 --> Router Class Initialized
INFO - 2020-03-06 10:16:04 --> Output Class Initialized
INFO - 2020-03-06 10:16:04 --> Security Class Initialized
DEBUG - 2020-03-06 10:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:16:04 --> Input Class Initialized
INFO - 2020-03-06 10:16:04 --> Language Class Initialized
INFO - 2020-03-06 10:16:04 --> Loader Class Initialized
INFO - 2020-03-06 10:16:04 --> Helper loaded: url_helper
INFO - 2020-03-06 10:16:04 --> Helper loaded: string_helper
INFO - 2020-03-06 10:16:04 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:16:04 --> Controller Class Initialized
INFO - 2020-03-06 10:16:04 --> Model "M_tiket" initialized
INFO - 2020-03-06 10:16:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 10:16:04 --> Model "M_pesan" initialized
INFO - 2020-03-06 10:16:04 --> Helper loaded: form_helper
INFO - 2020-03-06 10:16:04 --> Form Validation Class Initialized
INFO - 2020-03-06 10:16:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 10:16:04 --> Final output sent to browser
DEBUG - 2020-03-06 10:16:04 --> Total execution time: 0.0075
INFO - 2020-03-06 10:16:23 --> Config Class Initialized
INFO - 2020-03-06 10:16:23 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:16:23 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:16:23 --> Utf8 Class Initialized
INFO - 2020-03-06 10:16:23 --> URI Class Initialized
DEBUG - 2020-03-06 10:16:23 --> No URI present. Default controller set.
INFO - 2020-03-06 10:16:23 --> Router Class Initialized
INFO - 2020-03-06 10:16:23 --> Output Class Initialized
INFO - 2020-03-06 10:16:23 --> Security Class Initialized
DEBUG - 2020-03-06 10:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:16:23 --> Input Class Initialized
INFO - 2020-03-06 10:16:23 --> Language Class Initialized
INFO - 2020-03-06 10:16:23 --> Loader Class Initialized
INFO - 2020-03-06 10:16:23 --> Helper loaded: url_helper
INFO - 2020-03-06 10:16:23 --> Helper loaded: string_helper
INFO - 2020-03-06 10:16:23 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:16:23 --> Controller Class Initialized
INFO - 2020-03-06 10:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:16:23 --> Pagination Class Initialized
INFO - 2020-03-06 10:16:23 --> Model "M_show" initialized
INFO - 2020-03-06 10:16:23 --> Helper loaded: form_helper
INFO - 2020-03-06 10:16:23 --> Form Validation Class Initialized
INFO - 2020-03-06 10:16:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:16:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:16:23 --> Final output sent to browser
DEBUG - 2020-03-06 10:16:23 --> Total execution time: 0.0069
INFO - 2020-03-06 10:16:53 --> Config Class Initialized
INFO - 2020-03-06 10:16:53 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:16:53 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:16:53 --> Utf8 Class Initialized
INFO - 2020-03-06 10:16:53 --> URI Class Initialized
INFO - 2020-03-06 10:16:53 --> Router Class Initialized
INFO - 2020-03-06 10:16:53 --> Output Class Initialized
INFO - 2020-03-06 10:16:53 --> Security Class Initialized
DEBUG - 2020-03-06 10:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:16:53 --> Input Class Initialized
INFO - 2020-03-06 10:16:53 --> Language Class Initialized
INFO - 2020-03-06 10:16:53 --> Loader Class Initialized
INFO - 2020-03-06 10:16:53 --> Helper loaded: url_helper
INFO - 2020-03-06 10:16:53 --> Helper loaded: string_helper
INFO - 2020-03-06 10:16:53 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:16:53 --> Controller Class Initialized
INFO - 2020-03-06 10:16:53 --> Model "M_tiket" initialized
INFO - 2020-03-06 10:16:53 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 10:16:53 --> Model "M_pesan" initialized
INFO - 2020-03-06 10:16:53 --> Helper loaded: form_helper
INFO - 2020-03-06 10:16:53 --> Form Validation Class Initialized
INFO - 2020-03-06 10:16:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 10:16:53 --> Final output sent to browser
DEBUG - 2020-03-06 10:16:53 --> Total execution time: 0.0220
INFO - 2020-03-06 10:16:55 --> Config Class Initialized
INFO - 2020-03-06 10:16:55 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:16:55 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:16:55 --> Utf8 Class Initialized
INFO - 2020-03-06 10:16:55 --> URI Class Initialized
INFO - 2020-03-06 10:16:55 --> Router Class Initialized
INFO - 2020-03-06 10:16:55 --> Output Class Initialized
INFO - 2020-03-06 10:16:55 --> Security Class Initialized
DEBUG - 2020-03-06 10:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:16:55 --> Input Class Initialized
INFO - 2020-03-06 10:16:55 --> Language Class Initialized
INFO - 2020-03-06 10:16:55 --> Loader Class Initialized
INFO - 2020-03-06 10:16:55 --> Helper loaded: url_helper
INFO - 2020-03-06 10:16:55 --> Helper loaded: string_helper
INFO - 2020-03-06 10:16:55 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:16:55 --> Controller Class Initialized
INFO - 2020-03-06 10:16:55 --> Model "M_tiket" initialized
INFO - 2020-03-06 10:16:55 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 10:16:55 --> Model "M_pesan" initialized
INFO - 2020-03-06 10:16:55 --> Helper loaded: form_helper
INFO - 2020-03-06 10:16:55 --> Form Validation Class Initialized
INFO - 2020-03-06 10:16:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 10:16:55 --> Final output sent to browser
DEBUG - 2020-03-06 10:16:55 --> Total execution time: 0.0065
INFO - 2020-03-06 10:34:06 --> Config Class Initialized
INFO - 2020-03-06 10:34:06 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:34:06 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:34:06 --> Utf8 Class Initialized
INFO - 2020-03-06 10:34:06 --> URI Class Initialized
INFO - 2020-03-06 10:34:06 --> Router Class Initialized
INFO - 2020-03-06 10:34:06 --> Output Class Initialized
INFO - 2020-03-06 10:34:06 --> Security Class Initialized
DEBUG - 2020-03-06 10:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:34:06 --> Input Class Initialized
INFO - 2020-03-06 10:34:06 --> Language Class Initialized
INFO - 2020-03-06 10:34:06 --> Loader Class Initialized
INFO - 2020-03-06 10:34:06 --> Helper loaded: url_helper
INFO - 2020-03-06 10:34:06 --> Helper loaded: string_helper
INFO - 2020-03-06 10:34:06 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:34:06 --> Controller Class Initialized
INFO - 2020-03-06 10:34:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:34:06 --> Pagination Class Initialized
INFO - 2020-03-06 10:34:06 --> Model "M_show" initialized
INFO - 2020-03-06 10:34:07 --> Helper loaded: form_helper
INFO - 2020-03-06 10:34:07 --> Form Validation Class Initialized
INFO - 2020-03-06 10:34:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:34:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 10:34:07 --> Final output sent to browser
DEBUG - 2020-03-06 10:34:07 --> Total execution time: 0.0451
INFO - 2020-03-06 10:38:48 --> Config Class Initialized
INFO - 2020-03-06 10:38:48 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:38:48 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:38:48 --> Utf8 Class Initialized
INFO - 2020-03-06 10:38:48 --> URI Class Initialized
DEBUG - 2020-03-06 10:38:48 --> No URI present. Default controller set.
INFO - 2020-03-06 10:38:48 --> Router Class Initialized
INFO - 2020-03-06 10:38:48 --> Output Class Initialized
INFO - 2020-03-06 10:38:48 --> Security Class Initialized
DEBUG - 2020-03-06 10:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:38:48 --> Input Class Initialized
INFO - 2020-03-06 10:38:48 --> Language Class Initialized
INFO - 2020-03-06 10:38:48 --> Loader Class Initialized
INFO - 2020-03-06 10:38:48 --> Helper loaded: url_helper
INFO - 2020-03-06 10:38:48 --> Helper loaded: string_helper
INFO - 2020-03-06 10:38:48 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:38:48 --> Controller Class Initialized
INFO - 2020-03-06 10:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:38:48 --> Pagination Class Initialized
INFO - 2020-03-06 10:38:48 --> Model "M_show" initialized
INFO - 2020-03-06 10:38:48 --> Helper loaded: form_helper
INFO - 2020-03-06 10:38:48 --> Form Validation Class Initialized
INFO - 2020-03-06 10:38:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:38:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:38:48 --> Final output sent to browser
DEBUG - 2020-03-06 10:38:48 --> Total execution time: 0.0497
INFO - 2020-03-06 10:39:05 --> Config Class Initialized
INFO - 2020-03-06 10:39:05 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:39:05 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:39:05 --> Utf8 Class Initialized
INFO - 2020-03-06 10:39:05 --> URI Class Initialized
DEBUG - 2020-03-06 10:39:05 --> No URI present. Default controller set.
INFO - 2020-03-06 10:39:05 --> Router Class Initialized
INFO - 2020-03-06 10:39:05 --> Output Class Initialized
INFO - 2020-03-06 10:39:05 --> Security Class Initialized
DEBUG - 2020-03-06 10:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:39:05 --> Input Class Initialized
INFO - 2020-03-06 10:39:05 --> Language Class Initialized
INFO - 2020-03-06 10:39:05 --> Loader Class Initialized
INFO - 2020-03-06 10:39:05 --> Helper loaded: url_helper
INFO - 2020-03-06 10:39:05 --> Helper loaded: string_helper
INFO - 2020-03-06 10:39:05 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:39:05 --> Controller Class Initialized
INFO - 2020-03-06 10:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:39:05 --> Pagination Class Initialized
INFO - 2020-03-06 10:39:05 --> Model "M_show" initialized
INFO - 2020-03-06 10:39:05 --> Helper loaded: form_helper
INFO - 2020-03-06 10:39:05 --> Form Validation Class Initialized
INFO - 2020-03-06 10:39:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:39:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:39:05 --> Final output sent to browser
DEBUG - 2020-03-06 10:39:05 --> Total execution time: 0.1604
INFO - 2020-03-06 10:39:07 --> Config Class Initialized
INFO - 2020-03-06 10:39:07 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:39:07 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:39:07 --> Utf8 Class Initialized
INFO - 2020-03-06 10:39:07 --> URI Class Initialized
DEBUG - 2020-03-06 10:39:07 --> No URI present. Default controller set.
INFO - 2020-03-06 10:39:07 --> Router Class Initialized
INFO - 2020-03-06 10:39:07 --> Output Class Initialized
INFO - 2020-03-06 10:39:07 --> Security Class Initialized
DEBUG - 2020-03-06 10:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:39:07 --> Input Class Initialized
INFO - 2020-03-06 10:39:07 --> Language Class Initialized
INFO - 2020-03-06 10:39:07 --> Loader Class Initialized
INFO - 2020-03-06 10:39:07 --> Helper loaded: url_helper
INFO - 2020-03-06 10:39:07 --> Helper loaded: string_helper
INFO - 2020-03-06 10:39:07 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:39:07 --> Controller Class Initialized
INFO - 2020-03-06 10:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:39:07 --> Pagination Class Initialized
INFO - 2020-03-06 10:39:07 --> Model "M_show" initialized
INFO - 2020-03-06 10:39:07 --> Helper loaded: form_helper
INFO - 2020-03-06 10:39:07 --> Form Validation Class Initialized
INFO - 2020-03-06 10:39:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:39:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:39:07 --> Final output sent to browser
DEBUG - 2020-03-06 10:39:07 --> Total execution time: 0.3124
INFO - 2020-03-06 10:39:15 --> Config Class Initialized
INFO - 2020-03-06 10:39:15 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:39:15 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:39:15 --> Utf8 Class Initialized
INFO - 2020-03-06 10:39:15 --> URI Class Initialized
INFO - 2020-03-06 10:39:15 --> Router Class Initialized
INFO - 2020-03-06 10:39:15 --> Output Class Initialized
INFO - 2020-03-06 10:39:15 --> Security Class Initialized
DEBUG - 2020-03-06 10:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:39:15 --> Input Class Initialized
INFO - 2020-03-06 10:39:15 --> Language Class Initialized
INFO - 2020-03-06 10:39:15 --> Loader Class Initialized
INFO - 2020-03-06 10:39:15 --> Helper loaded: url_helper
INFO - 2020-03-06 10:39:15 --> Helper loaded: string_helper
INFO - 2020-03-06 10:39:15 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:39:15 --> Controller Class Initialized
INFO - 2020-03-06 10:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:39:15 --> Pagination Class Initialized
INFO - 2020-03-06 10:39:15 --> Model "M_show" initialized
INFO - 2020-03-06 10:39:15 --> Helper loaded: form_helper
INFO - 2020-03-06 10:39:15 --> Form Validation Class Initialized
INFO - 2020-03-06 10:39:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:39:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 10:39:15 --> Final output sent to browser
DEBUG - 2020-03-06 10:39:15 --> Total execution time: 0.0740
INFO - 2020-03-06 10:41:15 --> Config Class Initialized
INFO - 2020-03-06 10:41:15 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:41:15 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:41:15 --> Utf8 Class Initialized
INFO - 2020-03-06 10:41:15 --> URI Class Initialized
INFO - 2020-03-06 10:41:15 --> Router Class Initialized
INFO - 2020-03-06 10:41:15 --> Output Class Initialized
INFO - 2020-03-06 10:41:15 --> Security Class Initialized
DEBUG - 2020-03-06 10:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:41:15 --> Input Class Initialized
INFO - 2020-03-06 10:41:15 --> Language Class Initialized
INFO - 2020-03-06 10:41:15 --> Loader Class Initialized
INFO - 2020-03-06 10:41:15 --> Helper loaded: url_helper
INFO - 2020-03-06 10:41:15 --> Helper loaded: string_helper
INFO - 2020-03-06 10:41:15 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:41:15 --> Controller Class Initialized
INFO - 2020-03-06 10:41:15 --> Model "M_tiket" initialized
INFO - 2020-03-06 10:41:15 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 10:41:15 --> Model "M_pesan" initialized
INFO - 2020-03-06 10:41:15 --> Helper loaded: form_helper
INFO - 2020-03-06 10:41:15 --> Form Validation Class Initialized
INFO - 2020-03-06 10:41:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 10:41:15 --> Final output sent to browser
DEBUG - 2020-03-06 10:41:15 --> Total execution time: 0.0433
INFO - 2020-03-06 10:41:21 --> Config Class Initialized
INFO - 2020-03-06 10:41:21 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:41:21 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:41:21 --> Utf8 Class Initialized
INFO - 2020-03-06 10:41:21 --> URI Class Initialized
INFO - 2020-03-06 10:41:21 --> Router Class Initialized
INFO - 2020-03-06 10:41:21 --> Output Class Initialized
INFO - 2020-03-06 10:41:21 --> Security Class Initialized
DEBUG - 2020-03-06 10:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:41:21 --> Input Class Initialized
INFO - 2020-03-06 10:41:21 --> Language Class Initialized
INFO - 2020-03-06 10:41:21 --> Loader Class Initialized
INFO - 2020-03-06 10:41:21 --> Helper loaded: url_helper
INFO - 2020-03-06 10:41:21 --> Helper loaded: string_helper
INFO - 2020-03-06 10:41:21 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:41:21 --> Controller Class Initialized
INFO - 2020-03-06 10:41:21 --> Model "M_tiket" initialized
INFO - 2020-03-06 10:41:21 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 10:41:21 --> Model "M_pesan" initialized
INFO - 2020-03-06 10:41:21 --> Helper loaded: form_helper
INFO - 2020-03-06 10:41:21 --> Form Validation Class Initialized
INFO - 2020-03-06 10:41:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 10:41:21 --> Final output sent to browser
DEBUG - 2020-03-06 10:41:21 --> Total execution time: 0.0074
INFO - 2020-03-06 10:44:38 --> Config Class Initialized
INFO - 2020-03-06 10:44:38 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:44:38 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:44:38 --> Utf8 Class Initialized
INFO - 2020-03-06 10:44:38 --> URI Class Initialized
INFO - 2020-03-06 10:44:38 --> Router Class Initialized
INFO - 2020-03-06 10:44:38 --> Output Class Initialized
INFO - 2020-03-06 10:44:38 --> Security Class Initialized
DEBUG - 2020-03-06 10:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:44:38 --> Input Class Initialized
INFO - 2020-03-06 10:44:38 --> Language Class Initialized
INFO - 2020-03-06 10:44:38 --> Loader Class Initialized
INFO - 2020-03-06 10:44:38 --> Helper loaded: url_helper
INFO - 2020-03-06 10:44:38 --> Helper loaded: string_helper
INFO - 2020-03-06 10:44:38 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:44:38 --> Controller Class Initialized
INFO - 2020-03-06 10:44:38 --> Model "M_tiket" initialized
INFO - 2020-03-06 10:44:38 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 10:44:38 --> Model "M_pesan" initialized
INFO - 2020-03-06 10:44:38 --> Helper loaded: form_helper
INFO - 2020-03-06 10:44:38 --> Form Validation Class Initialized
DEBUG - 2020-03-06 10:44:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-06 10:44:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-06 17:44:38 --> Final output sent to browser
DEBUG - 2020-03-06 17:44:38 --> Total execution time: 0.4721
INFO - 2020-03-06 10:44:41 --> Config Class Initialized
INFO - 2020-03-06 10:44:41 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:44:41 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:44:41 --> Utf8 Class Initialized
INFO - 2020-03-06 10:44:41 --> URI Class Initialized
INFO - 2020-03-06 10:44:41 --> Router Class Initialized
INFO - 2020-03-06 10:44:41 --> Output Class Initialized
INFO - 2020-03-06 10:44:41 --> Security Class Initialized
DEBUG - 2020-03-06 10:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:44:41 --> Input Class Initialized
INFO - 2020-03-06 10:44:41 --> Language Class Initialized
INFO - 2020-03-06 10:44:41 --> Loader Class Initialized
INFO - 2020-03-06 10:44:41 --> Helper loaded: url_helper
INFO - 2020-03-06 10:44:41 --> Helper loaded: string_helper
INFO - 2020-03-06 10:44:41 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:44:41 --> Controller Class Initialized
INFO - 2020-03-06 10:44:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:44:41 --> Pagination Class Initialized
INFO - 2020-03-06 10:44:41 --> Model "M_show" initialized
INFO - 2020-03-06 10:44:41 --> Helper loaded: form_helper
INFO - 2020-03-06 10:44:41 --> Form Validation Class Initialized
INFO - 2020-03-06 10:44:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:44:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:44:41 --> Final output sent to browser
DEBUG - 2020-03-06 10:44:41 --> Total execution time: 0.0082
INFO - 2020-03-06 10:49:19 --> Config Class Initialized
INFO - 2020-03-06 10:49:19 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:49:19 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:49:19 --> Utf8 Class Initialized
INFO - 2020-03-06 10:49:19 --> URI Class Initialized
DEBUG - 2020-03-06 10:49:19 --> No URI present. Default controller set.
INFO - 2020-03-06 10:49:19 --> Router Class Initialized
INFO - 2020-03-06 10:49:19 --> Output Class Initialized
INFO - 2020-03-06 10:49:19 --> Security Class Initialized
DEBUG - 2020-03-06 10:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:49:19 --> Input Class Initialized
INFO - 2020-03-06 10:49:19 --> Language Class Initialized
INFO - 2020-03-06 10:49:19 --> Loader Class Initialized
INFO - 2020-03-06 10:49:19 --> Helper loaded: url_helper
INFO - 2020-03-06 10:49:19 --> Helper loaded: string_helper
INFO - 2020-03-06 10:49:19 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:49:19 --> Controller Class Initialized
INFO - 2020-03-06 10:49:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:49:19 --> Pagination Class Initialized
INFO - 2020-03-06 10:49:19 --> Model "M_show" initialized
INFO - 2020-03-06 10:49:19 --> Helper loaded: form_helper
INFO - 2020-03-06 10:49:19 --> Form Validation Class Initialized
INFO - 2020-03-06 10:49:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:49:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:49:19 --> Final output sent to browser
DEBUG - 2020-03-06 10:49:19 --> Total execution time: 0.0313
INFO - 2020-03-06 10:49:31 --> Config Class Initialized
INFO - 2020-03-06 10:49:31 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:49:31 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:49:31 --> Utf8 Class Initialized
INFO - 2020-03-06 10:49:31 --> URI Class Initialized
DEBUG - 2020-03-06 10:49:31 --> No URI present. Default controller set.
INFO - 2020-03-06 10:49:31 --> Router Class Initialized
INFO - 2020-03-06 10:49:31 --> Output Class Initialized
INFO - 2020-03-06 10:49:31 --> Security Class Initialized
DEBUG - 2020-03-06 10:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:49:31 --> Input Class Initialized
INFO - 2020-03-06 10:49:31 --> Language Class Initialized
INFO - 2020-03-06 10:49:31 --> Loader Class Initialized
INFO - 2020-03-06 10:49:31 --> Helper loaded: url_helper
INFO - 2020-03-06 10:49:31 --> Helper loaded: string_helper
INFO - 2020-03-06 10:49:31 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:49:31 --> Controller Class Initialized
INFO - 2020-03-06 10:49:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:49:31 --> Pagination Class Initialized
INFO - 2020-03-06 10:49:31 --> Model "M_show" initialized
INFO - 2020-03-06 10:49:31 --> Helper loaded: form_helper
INFO - 2020-03-06 10:49:31 --> Form Validation Class Initialized
INFO - 2020-03-06 10:49:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:49:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:49:31 --> Final output sent to browser
DEBUG - 2020-03-06 10:49:31 --> Total execution time: 0.0313
INFO - 2020-03-06 10:49:38 --> Config Class Initialized
INFO - 2020-03-06 10:49:38 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:49:38 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:49:38 --> Utf8 Class Initialized
INFO - 2020-03-06 10:49:38 --> URI Class Initialized
INFO - 2020-03-06 10:49:38 --> Router Class Initialized
INFO - 2020-03-06 10:49:38 --> Output Class Initialized
INFO - 2020-03-06 10:49:38 --> Security Class Initialized
DEBUG - 2020-03-06 10:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:49:38 --> Input Class Initialized
INFO - 2020-03-06 10:49:38 --> Language Class Initialized
INFO - 2020-03-06 10:49:38 --> Loader Class Initialized
INFO - 2020-03-06 10:49:38 --> Helper loaded: url_helper
INFO - 2020-03-06 10:49:38 --> Helper loaded: string_helper
INFO - 2020-03-06 10:49:38 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:49:38 --> Controller Class Initialized
INFO - 2020-03-06 10:49:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:49:38 --> Pagination Class Initialized
INFO - 2020-03-06 10:49:38 --> Model "M_show" initialized
INFO - 2020-03-06 10:49:38 --> Helper loaded: form_helper
INFO - 2020-03-06 10:49:38 --> Form Validation Class Initialized
INFO - 2020-03-06 10:49:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:49:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 10:49:38 --> Final output sent to browser
DEBUG - 2020-03-06 10:49:38 --> Total execution time: 0.0086
INFO - 2020-03-06 10:49:45 --> Config Class Initialized
INFO - 2020-03-06 10:49:45 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:49:45 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:49:45 --> Utf8 Class Initialized
INFO - 2020-03-06 10:49:45 --> URI Class Initialized
INFO - 2020-03-06 10:49:45 --> Router Class Initialized
INFO - 2020-03-06 10:49:45 --> Output Class Initialized
INFO - 2020-03-06 10:49:45 --> Security Class Initialized
DEBUG - 2020-03-06 10:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:49:45 --> Input Class Initialized
INFO - 2020-03-06 10:49:45 --> Language Class Initialized
INFO - 2020-03-06 10:49:45 --> Loader Class Initialized
INFO - 2020-03-06 10:49:45 --> Helper loaded: url_helper
INFO - 2020-03-06 10:49:45 --> Helper loaded: string_helper
INFO - 2020-03-06 10:49:45 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:49:45 --> Controller Class Initialized
INFO - 2020-03-06 10:49:45 --> Model "M_tiket" initialized
INFO - 2020-03-06 10:49:45 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 10:49:45 --> Model "M_pesan" initialized
INFO - 2020-03-06 10:49:45 --> Helper loaded: form_helper
INFO - 2020-03-06 10:49:45 --> Form Validation Class Initialized
INFO - 2020-03-06 10:49:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 10:49:45 --> Final output sent to browser
DEBUG - 2020-03-06 10:49:45 --> Total execution time: 0.0121
INFO - 2020-03-06 10:50:08 --> Config Class Initialized
INFO - 2020-03-06 10:50:08 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:50:08 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:50:08 --> Utf8 Class Initialized
INFO - 2020-03-06 10:50:08 --> URI Class Initialized
INFO - 2020-03-06 10:50:08 --> Router Class Initialized
INFO - 2020-03-06 10:50:08 --> Output Class Initialized
INFO - 2020-03-06 10:50:08 --> Security Class Initialized
DEBUG - 2020-03-06 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:50:08 --> Input Class Initialized
INFO - 2020-03-06 10:50:08 --> Language Class Initialized
INFO - 2020-03-06 10:50:08 --> Loader Class Initialized
INFO - 2020-03-06 10:50:08 --> Helper loaded: url_helper
INFO - 2020-03-06 10:50:08 --> Helper loaded: string_helper
INFO - 2020-03-06 10:50:08 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:50:08 --> Controller Class Initialized
INFO - 2020-03-06 10:50:08 --> Model "M_tiket" initialized
INFO - 2020-03-06 10:50:08 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 10:50:08 --> Model "M_pesan" initialized
INFO - 2020-03-06 10:50:08 --> Helper loaded: form_helper
INFO - 2020-03-06 10:50:08 --> Form Validation Class Initialized
INFO - 2020-03-06 10:50:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 10:50:08 --> Final output sent to browser
DEBUG - 2020-03-06 10:50:08 --> Total execution time: 0.0115
INFO - 2020-03-06 10:50:21 --> Config Class Initialized
INFO - 2020-03-06 10:50:21 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:50:21 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:50:21 --> Utf8 Class Initialized
INFO - 2020-03-06 10:50:21 --> URI Class Initialized
INFO - 2020-03-06 10:50:21 --> Router Class Initialized
INFO - 2020-03-06 10:50:21 --> Output Class Initialized
INFO - 2020-03-06 10:50:21 --> Security Class Initialized
DEBUG - 2020-03-06 10:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:50:21 --> Input Class Initialized
INFO - 2020-03-06 10:50:21 --> Language Class Initialized
INFO - 2020-03-06 10:50:21 --> Loader Class Initialized
INFO - 2020-03-06 10:50:21 --> Helper loaded: url_helper
INFO - 2020-03-06 10:50:21 --> Helper loaded: string_helper
INFO - 2020-03-06 10:50:21 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:50:21 --> Controller Class Initialized
INFO - 2020-03-06 10:50:21 --> Model "M_tiket" initialized
INFO - 2020-03-06 10:50:21 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 10:50:21 --> Model "M_pesan" initialized
INFO - 2020-03-06 10:50:21 --> Helper loaded: form_helper
INFO - 2020-03-06 10:50:21 --> Form Validation Class Initialized
INFO - 2020-03-06 10:50:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 10:50:21 --> Final output sent to browser
DEBUG - 2020-03-06 10:50:21 --> Total execution time: 0.0082
INFO - 2020-03-06 10:52:00 --> Config Class Initialized
INFO - 2020-03-06 10:52:00 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:52:00 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:52:00 --> Utf8 Class Initialized
INFO - 2020-03-06 10:52:00 --> URI Class Initialized
DEBUG - 2020-03-06 10:52:00 --> No URI present. Default controller set.
INFO - 2020-03-06 10:52:00 --> Router Class Initialized
INFO - 2020-03-06 10:52:00 --> Output Class Initialized
INFO - 2020-03-06 10:52:00 --> Security Class Initialized
DEBUG - 2020-03-06 10:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:52:00 --> Input Class Initialized
INFO - 2020-03-06 10:52:00 --> Language Class Initialized
INFO - 2020-03-06 10:52:00 --> Loader Class Initialized
INFO - 2020-03-06 10:52:00 --> Helper loaded: url_helper
INFO - 2020-03-06 10:52:00 --> Helper loaded: string_helper
INFO - 2020-03-06 10:52:00 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:52:00 --> Controller Class Initialized
INFO - 2020-03-06 10:52:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:52:00 --> Pagination Class Initialized
INFO - 2020-03-06 10:52:00 --> Model "M_show" initialized
INFO - 2020-03-06 10:52:00 --> Helper loaded: form_helper
INFO - 2020-03-06 10:52:00 --> Form Validation Class Initialized
INFO - 2020-03-06 10:52:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:52:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:52:00 --> Final output sent to browser
DEBUG - 2020-03-06 10:52:00 --> Total execution time: 0.0478
INFO - 2020-03-06 10:52:01 --> Config Class Initialized
INFO - 2020-03-06 10:52:01 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:52:01 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:52:01 --> Utf8 Class Initialized
INFO - 2020-03-06 10:52:01 --> URI Class Initialized
DEBUG - 2020-03-06 10:52:01 --> No URI present. Default controller set.
INFO - 2020-03-06 10:52:01 --> Router Class Initialized
INFO - 2020-03-06 10:52:01 --> Output Class Initialized
INFO - 2020-03-06 10:52:01 --> Security Class Initialized
DEBUG - 2020-03-06 10:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:52:01 --> Input Class Initialized
INFO - 2020-03-06 10:52:01 --> Language Class Initialized
INFO - 2020-03-06 10:52:01 --> Loader Class Initialized
INFO - 2020-03-06 10:52:01 --> Helper loaded: url_helper
INFO - 2020-03-06 10:52:01 --> Helper loaded: string_helper
INFO - 2020-03-06 10:52:01 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:52:01 --> Controller Class Initialized
INFO - 2020-03-06 10:52:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:52:01 --> Pagination Class Initialized
INFO - 2020-03-06 10:52:01 --> Model "M_show" initialized
INFO - 2020-03-06 10:52:01 --> Helper loaded: form_helper
INFO - 2020-03-06 10:52:01 --> Form Validation Class Initialized
INFO - 2020-03-06 10:52:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:52:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:52:01 --> Final output sent to browser
DEBUG - 2020-03-06 10:52:01 --> Total execution time: 0.0187
INFO - 2020-03-06 10:52:01 --> Config Class Initialized
INFO - 2020-03-06 10:52:01 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:52:01 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:52:01 --> Utf8 Class Initialized
INFO - 2020-03-06 10:52:01 --> URI Class Initialized
DEBUG - 2020-03-06 10:52:01 --> No URI present. Default controller set.
INFO - 2020-03-06 10:52:01 --> Router Class Initialized
INFO - 2020-03-06 10:52:01 --> Output Class Initialized
INFO - 2020-03-06 10:52:01 --> Security Class Initialized
DEBUG - 2020-03-06 10:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:52:01 --> Input Class Initialized
INFO - 2020-03-06 10:52:01 --> Language Class Initialized
INFO - 2020-03-06 10:52:01 --> Loader Class Initialized
INFO - 2020-03-06 10:52:01 --> Helper loaded: url_helper
INFO - 2020-03-06 10:52:01 --> Helper loaded: string_helper
INFO - 2020-03-06 10:52:01 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:52:01 --> Controller Class Initialized
INFO - 2020-03-06 10:52:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:52:01 --> Pagination Class Initialized
INFO - 2020-03-06 10:52:01 --> Model "M_show" initialized
INFO - 2020-03-06 10:52:01 --> Helper loaded: form_helper
INFO - 2020-03-06 10:52:01 --> Form Validation Class Initialized
INFO - 2020-03-06 10:52:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:52:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:52:01 --> Final output sent to browser
DEBUG - 2020-03-06 10:52:01 --> Total execution time: 0.0061
INFO - 2020-03-06 10:52:21 --> Config Class Initialized
INFO - 2020-03-06 10:52:21 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:52:21 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:52:21 --> Utf8 Class Initialized
INFO - 2020-03-06 10:52:21 --> URI Class Initialized
INFO - 2020-03-06 10:52:21 --> Router Class Initialized
INFO - 2020-03-06 10:52:21 --> Output Class Initialized
INFO - 2020-03-06 10:52:21 --> Security Class Initialized
DEBUG - 2020-03-06 10:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:52:21 --> Input Class Initialized
INFO - 2020-03-06 10:52:21 --> Language Class Initialized
INFO - 2020-03-06 10:52:21 --> Loader Class Initialized
INFO - 2020-03-06 10:52:21 --> Helper loaded: url_helper
INFO - 2020-03-06 10:52:21 --> Helper loaded: string_helper
INFO - 2020-03-06 10:52:21 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:52:21 --> Controller Class Initialized
INFO - 2020-03-06 10:52:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:52:21 --> Pagination Class Initialized
INFO - 2020-03-06 10:52:21 --> Model "M_show" initialized
INFO - 2020-03-06 10:52:21 --> Helper loaded: form_helper
INFO - 2020-03-06 10:52:21 --> Form Validation Class Initialized
INFO - 2020-03-06 10:52:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:52:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 10:52:21 --> Final output sent to browser
DEBUG - 2020-03-06 10:52:21 --> Total execution time: 0.0105
INFO - 2020-03-06 10:52:34 --> Config Class Initialized
INFO - 2020-03-06 10:52:34 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:52:34 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:52:34 --> Utf8 Class Initialized
INFO - 2020-03-06 10:52:34 --> URI Class Initialized
INFO - 2020-03-06 10:52:34 --> Router Class Initialized
INFO - 2020-03-06 10:52:34 --> Output Class Initialized
INFO - 2020-03-06 10:52:34 --> Security Class Initialized
DEBUG - 2020-03-06 10:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:52:34 --> Input Class Initialized
INFO - 2020-03-06 10:52:34 --> Language Class Initialized
INFO - 2020-03-06 10:52:34 --> Loader Class Initialized
INFO - 2020-03-06 10:52:34 --> Helper loaded: url_helper
INFO - 2020-03-06 10:52:34 --> Helper loaded: string_helper
INFO - 2020-03-06 10:52:34 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:52:34 --> Controller Class Initialized
INFO - 2020-03-06 10:52:34 --> Model "M_tiket" initialized
INFO - 2020-03-06 10:52:34 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 10:52:34 --> Model "M_pesan" initialized
INFO - 2020-03-06 10:52:34 --> Helper loaded: form_helper
INFO - 2020-03-06 10:52:34 --> Form Validation Class Initialized
INFO - 2020-03-06 10:52:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 10:52:34 --> Final output sent to browser
DEBUG - 2020-03-06 10:52:34 --> Total execution time: 0.0099
INFO - 2020-03-06 10:52:39 --> Config Class Initialized
INFO - 2020-03-06 10:52:39 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:52:39 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:52:39 --> Utf8 Class Initialized
INFO - 2020-03-06 10:52:39 --> URI Class Initialized
INFO - 2020-03-06 10:52:39 --> Router Class Initialized
INFO - 2020-03-06 10:52:39 --> Output Class Initialized
INFO - 2020-03-06 10:52:39 --> Security Class Initialized
DEBUG - 2020-03-06 10:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:52:39 --> Input Class Initialized
INFO - 2020-03-06 10:52:39 --> Language Class Initialized
INFO - 2020-03-06 10:52:39 --> Loader Class Initialized
INFO - 2020-03-06 10:52:39 --> Helper loaded: url_helper
INFO - 2020-03-06 10:52:39 --> Helper loaded: string_helper
INFO - 2020-03-06 10:52:39 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:52:39 --> Controller Class Initialized
INFO - 2020-03-06 10:52:39 --> Model "M_tiket" initialized
INFO - 2020-03-06 10:52:39 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 10:52:39 --> Model "M_pesan" initialized
INFO - 2020-03-06 10:52:39 --> Helper loaded: form_helper
INFO - 2020-03-06 10:52:39 --> Form Validation Class Initialized
INFO - 2020-03-06 10:52:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 10:52:39 --> Final output sent to browser
DEBUG - 2020-03-06 10:52:39 --> Total execution time: 0.0145
INFO - 2020-03-06 10:54:43 --> Config Class Initialized
INFO - 2020-03-06 10:54:43 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:54:43 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:54:43 --> Utf8 Class Initialized
INFO - 2020-03-06 10:54:43 --> URI Class Initialized
DEBUG - 2020-03-06 10:54:43 --> No URI present. Default controller set.
INFO - 2020-03-06 10:54:43 --> Router Class Initialized
INFO - 2020-03-06 10:54:43 --> Output Class Initialized
INFO - 2020-03-06 10:54:43 --> Security Class Initialized
DEBUG - 2020-03-06 10:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:54:43 --> Input Class Initialized
INFO - 2020-03-06 10:54:43 --> Language Class Initialized
INFO - 2020-03-06 10:54:43 --> Loader Class Initialized
INFO - 2020-03-06 10:54:43 --> Helper loaded: url_helper
INFO - 2020-03-06 10:54:43 --> Helper loaded: string_helper
INFO - 2020-03-06 10:54:43 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:54:43 --> Controller Class Initialized
INFO - 2020-03-06 10:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:54:43 --> Pagination Class Initialized
INFO - 2020-03-06 10:54:43 --> Model "M_show" initialized
INFO - 2020-03-06 10:54:43 --> Helper loaded: form_helper
INFO - 2020-03-06 10:54:43 --> Form Validation Class Initialized
INFO - 2020-03-06 10:54:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:54:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:54:43 --> Final output sent to browser
DEBUG - 2020-03-06 10:54:43 --> Total execution time: 0.0344
INFO - 2020-03-06 10:55:26 --> Config Class Initialized
INFO - 2020-03-06 10:55:26 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:55:26 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:55:26 --> Utf8 Class Initialized
INFO - 2020-03-06 10:55:26 --> URI Class Initialized
DEBUG - 2020-03-06 10:55:26 --> No URI present. Default controller set.
INFO - 2020-03-06 10:55:26 --> Router Class Initialized
INFO - 2020-03-06 10:55:26 --> Output Class Initialized
INFO - 2020-03-06 10:55:26 --> Security Class Initialized
DEBUG - 2020-03-06 10:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:55:26 --> Input Class Initialized
INFO - 2020-03-06 10:55:26 --> Language Class Initialized
INFO - 2020-03-06 10:55:26 --> Loader Class Initialized
INFO - 2020-03-06 10:55:26 --> Helper loaded: url_helper
INFO - 2020-03-06 10:55:26 --> Helper loaded: string_helper
INFO - 2020-03-06 10:55:26 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:55:26 --> Controller Class Initialized
INFO - 2020-03-06 10:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:55:26 --> Pagination Class Initialized
INFO - 2020-03-06 10:55:26 --> Model "M_show" initialized
INFO - 2020-03-06 10:55:26 --> Helper loaded: form_helper
INFO - 2020-03-06 10:55:26 --> Form Validation Class Initialized
INFO - 2020-03-06 10:55:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:55:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:55:26 --> Final output sent to browser
DEBUG - 2020-03-06 10:55:26 --> Total execution time: 0.0319
INFO - 2020-03-06 10:55:28 --> Config Class Initialized
INFO - 2020-03-06 10:55:28 --> Hooks Class Initialized
DEBUG - 2020-03-06 10:55:28 --> UTF-8 Support Enabled
INFO - 2020-03-06 10:55:28 --> Utf8 Class Initialized
INFO - 2020-03-06 10:55:28 --> URI Class Initialized
DEBUG - 2020-03-06 10:55:28 --> No URI present. Default controller set.
INFO - 2020-03-06 10:55:28 --> Router Class Initialized
INFO - 2020-03-06 10:55:28 --> Output Class Initialized
INFO - 2020-03-06 10:55:28 --> Security Class Initialized
DEBUG - 2020-03-06 10:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 10:55:28 --> Input Class Initialized
INFO - 2020-03-06 10:55:28 --> Language Class Initialized
INFO - 2020-03-06 10:55:28 --> Loader Class Initialized
INFO - 2020-03-06 10:55:28 --> Helper loaded: url_helper
INFO - 2020-03-06 10:55:28 --> Helper loaded: string_helper
INFO - 2020-03-06 10:55:28 --> Database Driver Class Initialized
DEBUG - 2020-03-06 10:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 10:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 10:55:28 --> Controller Class Initialized
INFO - 2020-03-06 10:55:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 10:55:28 --> Pagination Class Initialized
INFO - 2020-03-06 10:55:28 --> Model "M_show" initialized
INFO - 2020-03-06 10:55:28 --> Helper loaded: form_helper
INFO - 2020-03-06 10:55:28 --> Form Validation Class Initialized
INFO - 2020-03-06 10:55:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 10:55:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 10:55:28 --> Final output sent to browser
DEBUG - 2020-03-06 10:55:28 --> Total execution time: 0.1032
INFO - 2020-03-06 11:02:59 --> Config Class Initialized
INFO - 2020-03-06 11:02:59 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:02:59 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:02:59 --> Utf8 Class Initialized
INFO - 2020-03-06 11:02:59 --> URI Class Initialized
DEBUG - 2020-03-06 11:02:59 --> No URI present. Default controller set.
INFO - 2020-03-06 11:02:59 --> Router Class Initialized
INFO - 2020-03-06 11:02:59 --> Output Class Initialized
INFO - 2020-03-06 11:02:59 --> Security Class Initialized
DEBUG - 2020-03-06 11:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:02:59 --> Input Class Initialized
INFO - 2020-03-06 11:02:59 --> Language Class Initialized
INFO - 2020-03-06 11:02:59 --> Loader Class Initialized
INFO - 2020-03-06 11:02:59 --> Helper loaded: url_helper
INFO - 2020-03-06 11:02:59 --> Helper loaded: string_helper
INFO - 2020-03-06 11:02:59 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:02:59 --> Controller Class Initialized
INFO - 2020-03-06 11:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:02:59 --> Pagination Class Initialized
INFO - 2020-03-06 11:02:59 --> Model "M_show" initialized
INFO - 2020-03-06 11:02:59 --> Helper loaded: form_helper
INFO - 2020-03-06 11:02:59 --> Form Validation Class Initialized
INFO - 2020-03-06 11:02:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:02:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 11:02:59 --> Final output sent to browser
DEBUG - 2020-03-06 11:02:59 --> Total execution time: 0.1044
INFO - 2020-03-06 11:03:18 --> Config Class Initialized
INFO - 2020-03-06 11:03:18 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:03:18 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:03:18 --> Utf8 Class Initialized
INFO - 2020-03-06 11:03:18 --> URI Class Initialized
INFO - 2020-03-06 11:03:18 --> Router Class Initialized
INFO - 2020-03-06 11:03:18 --> Output Class Initialized
INFO - 2020-03-06 11:03:18 --> Security Class Initialized
DEBUG - 2020-03-06 11:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:03:18 --> Input Class Initialized
INFO - 2020-03-06 11:03:18 --> Language Class Initialized
INFO - 2020-03-06 11:03:18 --> Loader Class Initialized
INFO - 2020-03-06 11:03:18 --> Helper loaded: url_helper
INFO - 2020-03-06 11:03:18 --> Helper loaded: string_helper
INFO - 2020-03-06 11:03:18 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:03:18 --> Controller Class Initialized
INFO - 2020-03-06 11:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:03:18 --> Pagination Class Initialized
INFO - 2020-03-06 11:03:18 --> Model "M_show" initialized
INFO - 2020-03-06 11:03:18 --> Helper loaded: form_helper
INFO - 2020-03-06 11:03:18 --> Form Validation Class Initialized
INFO - 2020-03-06 11:03:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:03:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 11:03:18 --> Final output sent to browser
DEBUG - 2020-03-06 11:03:18 --> Total execution time: 0.0088
INFO - 2020-03-06 11:03:23 --> Config Class Initialized
INFO - 2020-03-06 11:03:23 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:03:23 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:03:23 --> Utf8 Class Initialized
INFO - 2020-03-06 11:03:23 --> URI Class Initialized
INFO - 2020-03-06 11:03:23 --> Router Class Initialized
INFO - 2020-03-06 11:03:23 --> Output Class Initialized
INFO - 2020-03-06 11:03:23 --> Security Class Initialized
DEBUG - 2020-03-06 11:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:03:23 --> Input Class Initialized
INFO - 2020-03-06 11:03:23 --> Language Class Initialized
INFO - 2020-03-06 11:03:23 --> Loader Class Initialized
INFO - 2020-03-06 11:03:23 --> Helper loaded: url_helper
INFO - 2020-03-06 11:03:23 --> Helper loaded: string_helper
INFO - 2020-03-06 11:03:23 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:03:23 --> Controller Class Initialized
INFO - 2020-03-06 11:03:23 --> Model "M_tiket" initialized
INFO - 2020-03-06 11:03:23 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 11:03:23 --> Model "M_pesan" initialized
INFO - 2020-03-06 11:03:23 --> Helper loaded: form_helper
INFO - 2020-03-06 11:03:23 --> Form Validation Class Initialized
INFO - 2020-03-06 11:03:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 11:03:23 --> Final output sent to browser
DEBUG - 2020-03-06 11:03:23 --> Total execution time: 0.0111
INFO - 2020-03-06 11:03:48 --> Config Class Initialized
INFO - 2020-03-06 11:03:48 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:03:48 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:03:48 --> Utf8 Class Initialized
INFO - 2020-03-06 11:03:48 --> URI Class Initialized
INFO - 2020-03-06 11:03:48 --> Router Class Initialized
INFO - 2020-03-06 11:03:48 --> Output Class Initialized
INFO - 2020-03-06 11:03:48 --> Security Class Initialized
DEBUG - 2020-03-06 11:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:03:48 --> Input Class Initialized
INFO - 2020-03-06 11:03:48 --> Language Class Initialized
INFO - 2020-03-06 11:03:48 --> Loader Class Initialized
INFO - 2020-03-06 11:03:48 --> Helper loaded: url_helper
INFO - 2020-03-06 11:03:48 --> Helper loaded: string_helper
INFO - 2020-03-06 11:03:48 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:03:48 --> Controller Class Initialized
INFO - 2020-03-06 11:03:48 --> Model "M_tiket" initialized
INFO - 2020-03-06 11:03:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 11:03:48 --> Model "M_pesan" initialized
INFO - 2020-03-06 11:03:48 --> Helper loaded: form_helper
INFO - 2020-03-06 11:03:48 --> Form Validation Class Initialized
INFO - 2020-03-06 11:03:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 11:03:48 --> Final output sent to browser
DEBUG - 2020-03-06 11:03:48 --> Total execution time: 0.0470
INFO - 2020-03-06 11:08:39 --> Config Class Initialized
INFO - 2020-03-06 11:08:39 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:08:39 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:08:39 --> Utf8 Class Initialized
INFO - 2020-03-06 11:08:39 --> URI Class Initialized
INFO - 2020-03-06 11:08:39 --> Router Class Initialized
INFO - 2020-03-06 11:08:39 --> Output Class Initialized
INFO - 2020-03-06 11:08:39 --> Security Class Initialized
DEBUG - 2020-03-06 11:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:08:39 --> Input Class Initialized
INFO - 2020-03-06 11:08:39 --> Language Class Initialized
INFO - 2020-03-06 11:08:39 --> Loader Class Initialized
INFO - 2020-03-06 11:08:39 --> Helper loaded: url_helper
INFO - 2020-03-06 11:08:39 --> Helper loaded: string_helper
INFO - 2020-03-06 11:08:39 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:08:39 --> Controller Class Initialized
INFO - 2020-03-06 11:08:39 --> Model "M_tiket" initialized
INFO - 2020-03-06 11:08:39 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 11:08:39 --> Model "M_pesan" initialized
INFO - 2020-03-06 11:08:39 --> Helper loaded: form_helper
INFO - 2020-03-06 11:08:39 --> Form Validation Class Initialized
INFO - 2020-03-06 11:08:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 11:08:39 --> Final output sent to browser
DEBUG - 2020-03-06 11:08:39 --> Total execution time: 0.0352
INFO - 2020-03-06 11:12:47 --> Config Class Initialized
INFO - 2020-03-06 11:12:47 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:12:47 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:12:47 --> Utf8 Class Initialized
INFO - 2020-03-06 11:12:47 --> URI Class Initialized
DEBUG - 2020-03-06 11:12:47 --> No URI present. Default controller set.
INFO - 2020-03-06 11:12:47 --> Router Class Initialized
INFO - 2020-03-06 11:12:47 --> Output Class Initialized
INFO - 2020-03-06 11:12:47 --> Security Class Initialized
DEBUG - 2020-03-06 11:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:12:47 --> Input Class Initialized
INFO - 2020-03-06 11:12:47 --> Language Class Initialized
INFO - 2020-03-06 11:12:47 --> Loader Class Initialized
INFO - 2020-03-06 11:12:47 --> Helper loaded: url_helper
INFO - 2020-03-06 11:12:47 --> Helper loaded: string_helper
INFO - 2020-03-06 11:12:47 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:12:47 --> Controller Class Initialized
INFO - 2020-03-06 11:12:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:12:47 --> Pagination Class Initialized
INFO - 2020-03-06 11:12:47 --> Model "M_show" initialized
INFO - 2020-03-06 11:12:47 --> Helper loaded: form_helper
INFO - 2020-03-06 11:12:47 --> Form Validation Class Initialized
INFO - 2020-03-06 11:12:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:12:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 11:12:47 --> Final output sent to browser
DEBUG - 2020-03-06 11:12:47 --> Total execution time: 0.0301
INFO - 2020-03-06 11:13:36 --> Config Class Initialized
INFO - 2020-03-06 11:13:36 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:13:36 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:13:36 --> Utf8 Class Initialized
INFO - 2020-03-06 11:13:36 --> URI Class Initialized
DEBUG - 2020-03-06 11:13:36 --> No URI present. Default controller set.
INFO - 2020-03-06 11:13:36 --> Router Class Initialized
INFO - 2020-03-06 11:13:36 --> Output Class Initialized
INFO - 2020-03-06 11:13:36 --> Security Class Initialized
DEBUG - 2020-03-06 11:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:13:36 --> Input Class Initialized
INFO - 2020-03-06 11:13:36 --> Language Class Initialized
INFO - 2020-03-06 11:13:36 --> Loader Class Initialized
INFO - 2020-03-06 11:13:36 --> Helper loaded: url_helper
INFO - 2020-03-06 11:13:36 --> Helper loaded: string_helper
INFO - 2020-03-06 11:13:36 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:13:36 --> Controller Class Initialized
INFO - 2020-03-06 11:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:13:36 --> Pagination Class Initialized
INFO - 2020-03-06 11:13:36 --> Model "M_show" initialized
INFO - 2020-03-06 11:13:36 --> Helper loaded: form_helper
INFO - 2020-03-06 11:13:36 --> Form Validation Class Initialized
INFO - 2020-03-06 11:13:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:13:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 11:13:36 --> Final output sent to browser
DEBUG - 2020-03-06 11:13:36 --> Total execution time: 0.0238
INFO - 2020-03-06 11:13:43 --> Config Class Initialized
INFO - 2020-03-06 11:13:43 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:13:43 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:13:43 --> Utf8 Class Initialized
INFO - 2020-03-06 11:13:43 --> URI Class Initialized
INFO - 2020-03-06 11:13:43 --> Router Class Initialized
INFO - 2020-03-06 11:13:43 --> Output Class Initialized
INFO - 2020-03-06 11:13:43 --> Security Class Initialized
DEBUG - 2020-03-06 11:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:13:43 --> Input Class Initialized
INFO - 2020-03-06 11:13:43 --> Language Class Initialized
INFO - 2020-03-06 11:13:43 --> Loader Class Initialized
INFO - 2020-03-06 11:13:43 --> Helper loaded: url_helper
INFO - 2020-03-06 11:13:43 --> Helper loaded: string_helper
INFO - 2020-03-06 11:13:43 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:13:43 --> Controller Class Initialized
INFO - 2020-03-06 11:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:13:43 --> Pagination Class Initialized
INFO - 2020-03-06 11:13:43 --> Model "M_show" initialized
INFO - 2020-03-06 11:13:43 --> Helper loaded: form_helper
INFO - 2020-03-06 11:13:43 --> Form Validation Class Initialized
INFO - 2020-03-06 11:13:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:13:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 11:13:43 --> Final output sent to browser
DEBUG - 2020-03-06 11:13:43 --> Total execution time: 0.0098
INFO - 2020-03-06 11:13:47 --> Config Class Initialized
INFO - 2020-03-06 11:13:47 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:13:47 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:13:47 --> Utf8 Class Initialized
INFO - 2020-03-06 11:13:47 --> URI Class Initialized
INFO - 2020-03-06 11:13:47 --> Router Class Initialized
INFO - 2020-03-06 11:13:47 --> Output Class Initialized
INFO - 2020-03-06 11:13:47 --> Security Class Initialized
DEBUG - 2020-03-06 11:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:13:47 --> Input Class Initialized
INFO - 2020-03-06 11:13:47 --> Language Class Initialized
INFO - 2020-03-06 11:13:47 --> Loader Class Initialized
INFO - 2020-03-06 11:13:47 --> Helper loaded: url_helper
INFO - 2020-03-06 11:13:47 --> Helper loaded: string_helper
INFO - 2020-03-06 11:13:47 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:13:47 --> Controller Class Initialized
INFO - 2020-03-06 11:13:47 --> Model "M_tiket" initialized
INFO - 2020-03-06 11:13:47 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 11:13:47 --> Model "M_pesan" initialized
INFO - 2020-03-06 11:13:47 --> Helper loaded: form_helper
INFO - 2020-03-06 11:13:47 --> Form Validation Class Initialized
INFO - 2020-03-06 11:13:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 11:13:47 --> Final output sent to browser
DEBUG - 2020-03-06 11:13:47 --> Total execution time: 0.0113
INFO - 2020-03-06 11:14:20 --> Config Class Initialized
INFO - 2020-03-06 11:14:20 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:14:20 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:14:20 --> Utf8 Class Initialized
INFO - 2020-03-06 11:14:20 --> URI Class Initialized
INFO - 2020-03-06 11:14:20 --> Router Class Initialized
INFO - 2020-03-06 11:14:20 --> Output Class Initialized
INFO - 2020-03-06 11:14:20 --> Security Class Initialized
DEBUG - 2020-03-06 11:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:14:20 --> Input Class Initialized
INFO - 2020-03-06 11:14:20 --> Language Class Initialized
INFO - 2020-03-06 11:14:20 --> Loader Class Initialized
INFO - 2020-03-06 11:14:20 --> Helper loaded: url_helper
INFO - 2020-03-06 11:14:20 --> Helper loaded: string_helper
INFO - 2020-03-06 11:14:20 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:14:23 --> Controller Class Initialized
INFO - 2020-03-06 11:14:23 --> Model "M_tiket" initialized
INFO - 2020-03-06 11:14:23 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 11:14:23 --> Model "M_pesan" initialized
INFO - 2020-03-06 11:14:23 --> Helper loaded: form_helper
INFO - 2020-03-06 11:14:23 --> Form Validation Class Initialized
INFO - 2020-03-06 11:14:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 11:14:23 --> Final output sent to browser
DEBUG - 2020-03-06 11:14:23 --> Total execution time: 2.6079
INFO - 2020-03-06 11:31:10 --> Config Class Initialized
INFO - 2020-03-06 11:31:10 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:31:10 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:31:10 --> Utf8 Class Initialized
INFO - 2020-03-06 11:31:10 --> URI Class Initialized
INFO - 2020-03-06 11:31:10 --> Router Class Initialized
INFO - 2020-03-06 11:31:10 --> Output Class Initialized
INFO - 2020-03-06 11:31:10 --> Security Class Initialized
DEBUG - 2020-03-06 11:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:31:10 --> Input Class Initialized
INFO - 2020-03-06 11:31:10 --> Language Class Initialized
INFO - 2020-03-06 11:31:10 --> Loader Class Initialized
INFO - 2020-03-06 11:31:10 --> Helper loaded: url_helper
INFO - 2020-03-06 11:31:10 --> Helper loaded: string_helper
INFO - 2020-03-06 11:31:10 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:31:10 --> Controller Class Initialized
INFO - 2020-03-06 11:31:10 --> Model "M_tiket" initialized
INFO - 2020-03-06 11:31:10 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 11:31:10 --> Model "M_pesan" initialized
INFO - 2020-03-06 11:31:10 --> Helper loaded: form_helper
INFO - 2020-03-06 11:31:10 --> Form Validation Class Initialized
INFO - 2020-03-06 11:31:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 11:31:10 --> Final output sent to browser
DEBUG - 2020-03-06 11:31:10 --> Total execution time: 0.0353
INFO - 2020-03-06 11:31:14 --> Config Class Initialized
INFO - 2020-03-06 11:31:14 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:31:14 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:31:14 --> Utf8 Class Initialized
INFO - 2020-03-06 11:31:14 --> URI Class Initialized
INFO - 2020-03-06 11:31:14 --> Router Class Initialized
INFO - 2020-03-06 11:31:14 --> Output Class Initialized
INFO - 2020-03-06 11:31:14 --> Security Class Initialized
DEBUG - 2020-03-06 11:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:31:14 --> Input Class Initialized
INFO - 2020-03-06 11:31:14 --> Language Class Initialized
INFO - 2020-03-06 11:31:14 --> Loader Class Initialized
INFO - 2020-03-06 11:31:14 --> Helper loaded: url_helper
INFO - 2020-03-06 11:31:14 --> Helper loaded: string_helper
INFO - 2020-03-06 11:31:14 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:31:14 --> Controller Class Initialized
INFO - 2020-03-06 11:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:31:14 --> Pagination Class Initialized
INFO - 2020-03-06 11:31:14 --> Model "M_show" initialized
INFO - 2020-03-06 11:31:14 --> Helper loaded: form_helper
INFO - 2020-03-06 11:31:14 --> Form Validation Class Initialized
INFO - 2020-03-06 11:31:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:31:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 11:31:14 --> Final output sent to browser
DEBUG - 2020-03-06 11:31:14 --> Total execution time: 0.0094
INFO - 2020-03-06 11:31:16 --> Config Class Initialized
INFO - 2020-03-06 11:31:16 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:31:16 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:31:16 --> Utf8 Class Initialized
INFO - 2020-03-06 11:31:16 --> URI Class Initialized
DEBUG - 2020-03-06 11:31:16 --> No URI present. Default controller set.
INFO - 2020-03-06 11:31:16 --> Router Class Initialized
INFO - 2020-03-06 11:31:16 --> Output Class Initialized
INFO - 2020-03-06 11:31:16 --> Security Class Initialized
DEBUG - 2020-03-06 11:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:31:16 --> Input Class Initialized
INFO - 2020-03-06 11:31:16 --> Language Class Initialized
INFO - 2020-03-06 11:31:16 --> Loader Class Initialized
INFO - 2020-03-06 11:31:16 --> Helper loaded: url_helper
INFO - 2020-03-06 11:31:16 --> Helper loaded: string_helper
INFO - 2020-03-06 11:31:16 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:31:16 --> Controller Class Initialized
INFO - 2020-03-06 11:31:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:31:16 --> Pagination Class Initialized
INFO - 2020-03-06 11:31:16 --> Model "M_show" initialized
INFO - 2020-03-06 11:31:16 --> Helper loaded: form_helper
INFO - 2020-03-06 11:31:16 --> Form Validation Class Initialized
INFO - 2020-03-06 11:31:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:31:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 11:31:16 --> Final output sent to browser
DEBUG - 2020-03-06 11:31:16 --> Total execution time: 0.0058
INFO - 2020-03-06 11:43:09 --> Config Class Initialized
INFO - 2020-03-06 11:43:09 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:43:09 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:43:09 --> Utf8 Class Initialized
INFO - 2020-03-06 11:43:09 --> URI Class Initialized
INFO - 2020-03-06 11:43:09 --> Router Class Initialized
INFO - 2020-03-06 11:43:09 --> Output Class Initialized
INFO - 2020-03-06 11:43:09 --> Security Class Initialized
DEBUG - 2020-03-06 11:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:43:09 --> Input Class Initialized
INFO - 2020-03-06 11:43:09 --> Language Class Initialized
INFO - 2020-03-06 11:43:09 --> Loader Class Initialized
INFO - 2020-03-06 11:43:09 --> Helper loaded: url_helper
INFO - 2020-03-06 11:43:09 --> Helper loaded: string_helper
INFO - 2020-03-06 11:43:09 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:43:09 --> Controller Class Initialized
INFO - 2020-03-06 11:43:09 --> Model "M_tiket" initialized
INFO - 2020-03-06 11:43:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 11:43:09 --> Model "M_pesan" initialized
INFO - 2020-03-06 11:43:09 --> Helper loaded: form_helper
INFO - 2020-03-06 11:43:09 --> Form Validation Class Initialized
INFO - 2020-03-06 11:43:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 11:43:09 --> Final output sent to browser
DEBUG - 2020-03-06 11:43:09 --> Total execution time: 0.0663
INFO - 2020-03-06 11:48:21 --> Config Class Initialized
INFO - 2020-03-06 11:48:21 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:48:21 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:48:21 --> Utf8 Class Initialized
INFO - 2020-03-06 11:48:21 --> URI Class Initialized
DEBUG - 2020-03-06 11:48:21 --> No URI present. Default controller set.
INFO - 2020-03-06 11:48:21 --> Router Class Initialized
INFO - 2020-03-06 11:48:21 --> Output Class Initialized
INFO - 2020-03-06 11:48:21 --> Security Class Initialized
DEBUG - 2020-03-06 11:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:48:21 --> Input Class Initialized
INFO - 2020-03-06 11:48:21 --> Language Class Initialized
INFO - 2020-03-06 11:48:21 --> Loader Class Initialized
INFO - 2020-03-06 11:48:21 --> Helper loaded: url_helper
INFO - 2020-03-06 11:48:21 --> Helper loaded: string_helper
INFO - 2020-03-06 11:48:21 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:48:21 --> Controller Class Initialized
INFO - 2020-03-06 11:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:48:21 --> Pagination Class Initialized
INFO - 2020-03-06 11:48:21 --> Model "M_show" initialized
INFO - 2020-03-06 11:48:21 --> Helper loaded: form_helper
INFO - 2020-03-06 11:48:21 --> Form Validation Class Initialized
INFO - 2020-03-06 11:48:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:48:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 11:48:21 --> Final output sent to browser
DEBUG - 2020-03-06 11:48:21 --> Total execution time: 0.0462
INFO - 2020-03-06 11:48:33 --> Config Class Initialized
INFO - 2020-03-06 11:48:33 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:48:33 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:48:33 --> Utf8 Class Initialized
INFO - 2020-03-06 11:48:33 --> URI Class Initialized
INFO - 2020-03-06 11:48:33 --> Router Class Initialized
INFO - 2020-03-06 11:48:33 --> Output Class Initialized
INFO - 2020-03-06 11:48:33 --> Security Class Initialized
DEBUG - 2020-03-06 11:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:48:33 --> Input Class Initialized
INFO - 2020-03-06 11:48:33 --> Language Class Initialized
INFO - 2020-03-06 11:48:33 --> Loader Class Initialized
INFO - 2020-03-06 11:48:33 --> Helper loaded: url_helper
INFO - 2020-03-06 11:48:33 --> Helper loaded: string_helper
INFO - 2020-03-06 11:48:33 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:48:33 --> Controller Class Initialized
INFO - 2020-03-06 11:48:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:48:33 --> Pagination Class Initialized
INFO - 2020-03-06 11:48:33 --> Model "M_show" initialized
INFO - 2020-03-06 11:48:33 --> Helper loaded: form_helper
INFO - 2020-03-06 11:48:33 --> Form Validation Class Initialized
INFO - 2020-03-06 11:48:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:48:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 11:48:33 --> Final output sent to browser
DEBUG - 2020-03-06 11:48:33 --> Total execution time: 0.0554
INFO - 2020-03-06 11:48:40 --> Config Class Initialized
INFO - 2020-03-06 11:48:40 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:48:40 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:48:40 --> Utf8 Class Initialized
INFO - 2020-03-06 11:48:40 --> URI Class Initialized
INFO - 2020-03-06 11:48:40 --> Router Class Initialized
INFO - 2020-03-06 11:48:40 --> Output Class Initialized
INFO - 2020-03-06 11:48:40 --> Security Class Initialized
DEBUG - 2020-03-06 11:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:48:40 --> Input Class Initialized
INFO - 2020-03-06 11:48:40 --> Language Class Initialized
INFO - 2020-03-06 11:48:40 --> Loader Class Initialized
INFO - 2020-03-06 11:48:40 --> Helper loaded: url_helper
INFO - 2020-03-06 11:48:40 --> Helper loaded: string_helper
INFO - 2020-03-06 11:48:40 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:48:40 --> Controller Class Initialized
INFO - 2020-03-06 11:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:48:40 --> Pagination Class Initialized
INFO - 2020-03-06 11:48:40 --> Model "M_show" initialized
INFO - 2020-03-06 11:48:40 --> Helper loaded: form_helper
INFO - 2020-03-06 11:48:40 --> Form Validation Class Initialized
INFO - 2020-03-06 11:48:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:48:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-06 11:48:41 --> Final output sent to browser
DEBUG - 2020-03-06 11:48:41 --> Total execution time: 0.5455
INFO - 2020-03-06 11:49:07 --> Config Class Initialized
INFO - 2020-03-06 11:49:07 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:49:07 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:49:07 --> Utf8 Class Initialized
INFO - 2020-03-06 11:49:07 --> URI Class Initialized
INFO - 2020-03-06 11:49:07 --> Router Class Initialized
INFO - 2020-03-06 11:49:07 --> Output Class Initialized
INFO - 2020-03-06 11:49:07 --> Security Class Initialized
DEBUG - 2020-03-06 11:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:49:07 --> Input Class Initialized
INFO - 2020-03-06 11:49:07 --> Language Class Initialized
INFO - 2020-03-06 11:49:07 --> Loader Class Initialized
INFO - 2020-03-06 11:49:07 --> Helper loaded: url_helper
INFO - 2020-03-06 11:49:07 --> Helper loaded: string_helper
INFO - 2020-03-06 11:49:07 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:49:07 --> Controller Class Initialized
INFO - 2020-03-06 11:49:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:49:07 --> Pagination Class Initialized
INFO - 2020-03-06 11:49:07 --> Model "M_show" initialized
INFO - 2020-03-06 11:49:07 --> Helper loaded: form_helper
INFO - 2020-03-06 11:49:07 --> Form Validation Class Initialized
INFO - 2020-03-06 11:49:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:49:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-06 11:49:07 --> Final output sent to browser
DEBUG - 2020-03-06 11:49:07 --> Total execution time: 0.0310
INFO - 2020-03-06 11:49:41 --> Config Class Initialized
INFO - 2020-03-06 11:49:41 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:49:41 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:49:41 --> Utf8 Class Initialized
INFO - 2020-03-06 11:49:41 --> URI Class Initialized
INFO - 2020-03-06 11:49:41 --> Router Class Initialized
INFO - 2020-03-06 11:49:41 --> Output Class Initialized
INFO - 2020-03-06 11:49:41 --> Security Class Initialized
DEBUG - 2020-03-06 11:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:49:41 --> Input Class Initialized
INFO - 2020-03-06 11:49:41 --> Language Class Initialized
INFO - 2020-03-06 11:49:41 --> Loader Class Initialized
INFO - 2020-03-06 11:49:41 --> Helper loaded: url_helper
INFO - 2020-03-06 11:49:41 --> Helper loaded: string_helper
INFO - 2020-03-06 11:49:41 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:49:41 --> Controller Class Initialized
INFO - 2020-03-06 11:49:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:49:41 --> Pagination Class Initialized
INFO - 2020-03-06 11:49:41 --> Model "M_show" initialized
INFO - 2020-03-06 11:49:41 --> Helper loaded: form_helper
INFO - 2020-03-06 11:49:41 --> Form Validation Class Initialized
INFO - 2020-03-06 11:49:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:49:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 11:49:41 --> Final output sent to browser
DEBUG - 2020-03-06 11:49:41 --> Total execution time: 0.0349
INFO - 2020-03-06 11:50:12 --> Config Class Initialized
INFO - 2020-03-06 11:50:12 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:50:12 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:50:12 --> Utf8 Class Initialized
INFO - 2020-03-06 11:50:12 --> URI Class Initialized
INFO - 2020-03-06 11:50:12 --> Router Class Initialized
INFO - 2020-03-06 11:50:12 --> Output Class Initialized
INFO - 2020-03-06 11:50:12 --> Security Class Initialized
DEBUG - 2020-03-06 11:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:50:12 --> Input Class Initialized
INFO - 2020-03-06 11:50:12 --> Language Class Initialized
INFO - 2020-03-06 11:50:12 --> Loader Class Initialized
INFO - 2020-03-06 11:50:12 --> Helper loaded: url_helper
INFO - 2020-03-06 11:50:12 --> Helper loaded: string_helper
INFO - 2020-03-06 11:50:12 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:50:12 --> Controller Class Initialized
INFO - 2020-03-06 11:50:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:50:12 --> Pagination Class Initialized
INFO - 2020-03-06 11:50:12 --> Model "M_show" initialized
INFO - 2020-03-06 11:50:12 --> Helper loaded: form_helper
INFO - 2020-03-06 11:50:12 --> Form Validation Class Initialized
INFO - 2020-03-06 11:50:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:50:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-06 11:50:12 --> Final output sent to browser
DEBUG - 2020-03-06 11:50:12 --> Total execution time: 0.0075
INFO - 2020-03-06 11:50:29 --> Config Class Initialized
INFO - 2020-03-06 11:50:29 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:50:29 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:50:29 --> Utf8 Class Initialized
INFO - 2020-03-06 11:50:29 --> URI Class Initialized
DEBUG - 2020-03-06 11:50:29 --> No URI present. Default controller set.
INFO - 2020-03-06 11:50:29 --> Router Class Initialized
INFO - 2020-03-06 11:50:29 --> Output Class Initialized
INFO - 2020-03-06 11:50:29 --> Security Class Initialized
DEBUG - 2020-03-06 11:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:50:29 --> Input Class Initialized
INFO - 2020-03-06 11:50:29 --> Language Class Initialized
INFO - 2020-03-06 11:50:29 --> Loader Class Initialized
INFO - 2020-03-06 11:50:29 --> Helper loaded: url_helper
INFO - 2020-03-06 11:50:29 --> Helper loaded: string_helper
INFO - 2020-03-06 11:50:29 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:50:29 --> Controller Class Initialized
INFO - 2020-03-06 11:50:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:50:29 --> Pagination Class Initialized
INFO - 2020-03-06 11:50:29 --> Model "M_show" initialized
INFO - 2020-03-06 11:50:29 --> Helper loaded: form_helper
INFO - 2020-03-06 11:50:29 --> Form Validation Class Initialized
INFO - 2020-03-06 11:50:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:50:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 11:50:29 --> Final output sent to browser
DEBUG - 2020-03-06 11:50:29 --> Total execution time: 0.0050
INFO - 2020-03-06 11:50:38 --> Config Class Initialized
INFO - 2020-03-06 11:50:38 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:50:38 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:50:38 --> Utf8 Class Initialized
INFO - 2020-03-06 11:50:38 --> URI Class Initialized
INFO - 2020-03-06 11:50:38 --> Router Class Initialized
INFO - 2020-03-06 11:50:38 --> Output Class Initialized
INFO - 2020-03-06 11:50:38 --> Security Class Initialized
DEBUG - 2020-03-06 11:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:50:38 --> Input Class Initialized
INFO - 2020-03-06 11:50:38 --> Language Class Initialized
INFO - 2020-03-06 11:50:38 --> Loader Class Initialized
INFO - 2020-03-06 11:50:38 --> Helper loaded: url_helper
INFO - 2020-03-06 11:50:38 --> Helper loaded: string_helper
INFO - 2020-03-06 11:50:38 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:50:38 --> Controller Class Initialized
INFO - 2020-03-06 11:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:50:38 --> Pagination Class Initialized
INFO - 2020-03-06 11:50:38 --> Model "M_show" initialized
INFO - 2020-03-06 11:50:38 --> Helper loaded: form_helper
INFO - 2020-03-06 11:50:38 --> Form Validation Class Initialized
INFO - 2020-03-06 11:50:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:50:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 11:50:38 --> Final output sent to browser
DEBUG - 2020-03-06 11:50:38 --> Total execution time: 0.0081
INFO - 2020-03-06 11:50:44 --> Config Class Initialized
INFO - 2020-03-06 11:50:44 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:50:44 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:50:44 --> Utf8 Class Initialized
INFO - 2020-03-06 11:50:44 --> URI Class Initialized
INFO - 2020-03-06 11:50:44 --> Router Class Initialized
INFO - 2020-03-06 11:50:44 --> Output Class Initialized
INFO - 2020-03-06 11:50:44 --> Security Class Initialized
DEBUG - 2020-03-06 11:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:50:44 --> Input Class Initialized
INFO - 2020-03-06 11:50:44 --> Language Class Initialized
INFO - 2020-03-06 11:50:44 --> Loader Class Initialized
INFO - 2020-03-06 11:50:44 --> Helper loaded: url_helper
INFO - 2020-03-06 11:50:44 --> Helper loaded: string_helper
INFO - 2020-03-06 11:50:44 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:50:44 --> Controller Class Initialized
INFO - 2020-03-06 11:50:44 --> Model "M_tiket" initialized
INFO - 2020-03-06 11:50:44 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 11:50:44 --> Model "M_pesan" initialized
INFO - 2020-03-06 11:50:44 --> Helper loaded: form_helper
INFO - 2020-03-06 11:50:44 --> Form Validation Class Initialized
INFO - 2020-03-06 11:50:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 11:50:44 --> Final output sent to browser
DEBUG - 2020-03-06 11:50:44 --> Total execution time: 0.0103
INFO - 2020-03-06 11:51:23 --> Config Class Initialized
INFO - 2020-03-06 11:51:23 --> Hooks Class Initialized
DEBUG - 2020-03-06 11:51:23 --> UTF-8 Support Enabled
INFO - 2020-03-06 11:51:23 --> Utf8 Class Initialized
INFO - 2020-03-06 11:51:23 --> URI Class Initialized
INFO - 2020-03-06 11:51:23 --> Router Class Initialized
INFO - 2020-03-06 11:51:23 --> Output Class Initialized
INFO - 2020-03-06 11:51:23 --> Security Class Initialized
DEBUG - 2020-03-06 11:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 11:51:23 --> Input Class Initialized
INFO - 2020-03-06 11:51:23 --> Language Class Initialized
INFO - 2020-03-06 11:51:23 --> Loader Class Initialized
INFO - 2020-03-06 11:51:23 --> Helper loaded: url_helper
INFO - 2020-03-06 11:51:23 --> Helper loaded: string_helper
INFO - 2020-03-06 11:51:23 --> Database Driver Class Initialized
DEBUG - 2020-03-06 11:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 11:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 11:51:23 --> Controller Class Initialized
INFO - 2020-03-06 11:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 11:51:23 --> Pagination Class Initialized
INFO - 2020-03-06 11:51:23 --> Model "M_show" initialized
INFO - 2020-03-06 11:51:23 --> Helper loaded: form_helper
INFO - 2020-03-06 11:51:23 --> Form Validation Class Initialized
INFO - 2020-03-06 11:51:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 11:51:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 11:51:23 --> Final output sent to browser
DEBUG - 2020-03-06 11:51:23 --> Total execution time: 0.0060
INFO - 2020-03-06 12:06:44 --> Config Class Initialized
INFO - 2020-03-06 12:06:44 --> Hooks Class Initialized
DEBUG - 2020-03-06 12:06:44 --> UTF-8 Support Enabled
INFO - 2020-03-06 12:06:44 --> Utf8 Class Initialized
INFO - 2020-03-06 12:06:44 --> URI Class Initialized
DEBUG - 2020-03-06 12:06:44 --> No URI present. Default controller set.
INFO - 2020-03-06 12:06:44 --> Router Class Initialized
INFO - 2020-03-06 12:06:44 --> Output Class Initialized
INFO - 2020-03-06 12:06:44 --> Security Class Initialized
DEBUG - 2020-03-06 12:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 12:06:44 --> Input Class Initialized
INFO - 2020-03-06 12:06:44 --> Language Class Initialized
INFO - 2020-03-06 12:06:44 --> Loader Class Initialized
INFO - 2020-03-06 12:06:44 --> Helper loaded: url_helper
INFO - 2020-03-06 12:06:44 --> Helper loaded: string_helper
INFO - 2020-03-06 12:06:44 --> Database Driver Class Initialized
DEBUG - 2020-03-06 12:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 12:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 12:06:44 --> Controller Class Initialized
INFO - 2020-03-06 12:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 12:06:44 --> Pagination Class Initialized
INFO - 2020-03-06 12:06:44 --> Model "M_show" initialized
INFO - 2020-03-06 12:06:44 --> Helper loaded: form_helper
INFO - 2020-03-06 12:06:44 --> Form Validation Class Initialized
INFO - 2020-03-06 12:06:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 12:06:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 12:06:44 --> Final output sent to browser
DEBUG - 2020-03-06 12:06:44 --> Total execution time: 0.0476
INFO - 2020-03-06 12:06:54 --> Config Class Initialized
INFO - 2020-03-06 12:06:54 --> Hooks Class Initialized
DEBUG - 2020-03-06 12:06:54 --> UTF-8 Support Enabled
INFO - 2020-03-06 12:06:54 --> Utf8 Class Initialized
INFO - 2020-03-06 12:06:54 --> URI Class Initialized
INFO - 2020-03-06 12:06:54 --> Router Class Initialized
INFO - 2020-03-06 12:06:54 --> Output Class Initialized
INFO - 2020-03-06 12:06:54 --> Security Class Initialized
DEBUG - 2020-03-06 12:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 12:06:54 --> Input Class Initialized
INFO - 2020-03-06 12:06:54 --> Language Class Initialized
INFO - 2020-03-06 12:06:54 --> Loader Class Initialized
INFO - 2020-03-06 12:06:54 --> Helper loaded: url_helper
INFO - 2020-03-06 12:06:54 --> Helper loaded: string_helper
INFO - 2020-03-06 12:06:54 --> Database Driver Class Initialized
DEBUG - 2020-03-06 12:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 12:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 12:06:54 --> Controller Class Initialized
INFO - 2020-03-06 12:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 12:06:54 --> Pagination Class Initialized
INFO - 2020-03-06 12:06:54 --> Model "M_show" initialized
INFO - 2020-03-06 12:06:54 --> Helper loaded: form_helper
INFO - 2020-03-06 12:06:54 --> Form Validation Class Initialized
INFO - 2020-03-06 12:06:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 12:06:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 12:06:54 --> Final output sent to browser
DEBUG - 2020-03-06 12:06:54 --> Total execution time: 0.0107
INFO - 2020-03-06 12:06:58 --> Config Class Initialized
INFO - 2020-03-06 12:06:58 --> Hooks Class Initialized
DEBUG - 2020-03-06 12:06:58 --> UTF-8 Support Enabled
INFO - 2020-03-06 12:06:58 --> Utf8 Class Initialized
INFO - 2020-03-06 12:06:58 --> URI Class Initialized
INFO - 2020-03-06 12:06:58 --> Router Class Initialized
INFO - 2020-03-06 12:06:58 --> Output Class Initialized
INFO - 2020-03-06 12:06:58 --> Security Class Initialized
DEBUG - 2020-03-06 12:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 12:06:58 --> Input Class Initialized
INFO - 2020-03-06 12:06:58 --> Language Class Initialized
INFO - 2020-03-06 12:06:58 --> Loader Class Initialized
INFO - 2020-03-06 12:06:58 --> Helper loaded: url_helper
INFO - 2020-03-06 12:06:58 --> Helper loaded: string_helper
INFO - 2020-03-06 12:06:58 --> Database Driver Class Initialized
DEBUG - 2020-03-06 12:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 12:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 12:06:58 --> Controller Class Initialized
INFO - 2020-03-06 12:06:58 --> Model "M_tiket" initialized
INFO - 2020-03-06 12:06:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 12:06:58 --> Model "M_pesan" initialized
INFO - 2020-03-06 12:06:58 --> Helper loaded: form_helper
INFO - 2020-03-06 12:06:58 --> Form Validation Class Initialized
INFO - 2020-03-06 12:06:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 12:06:58 --> Final output sent to browser
DEBUG - 2020-03-06 12:06:58 --> Total execution time: 0.0133
INFO - 2020-03-06 12:07:49 --> Config Class Initialized
INFO - 2020-03-06 12:07:49 --> Hooks Class Initialized
DEBUG - 2020-03-06 12:07:49 --> UTF-8 Support Enabled
INFO - 2020-03-06 12:07:49 --> Utf8 Class Initialized
INFO - 2020-03-06 12:07:49 --> URI Class Initialized
INFO - 2020-03-06 12:07:49 --> Router Class Initialized
INFO - 2020-03-06 12:07:49 --> Output Class Initialized
INFO - 2020-03-06 12:07:49 --> Security Class Initialized
DEBUG - 2020-03-06 12:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 12:07:49 --> Input Class Initialized
INFO - 2020-03-06 12:07:49 --> Language Class Initialized
INFO - 2020-03-06 12:07:49 --> Loader Class Initialized
INFO - 2020-03-06 12:07:49 --> Helper loaded: url_helper
INFO - 2020-03-06 12:07:49 --> Helper loaded: string_helper
INFO - 2020-03-06 12:07:49 --> Database Driver Class Initialized
DEBUG - 2020-03-06 12:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 12:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 12:07:49 --> Controller Class Initialized
INFO - 2020-03-06 12:07:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 12:07:49 --> Pagination Class Initialized
INFO - 2020-03-06 12:07:49 --> Model "M_show" initialized
INFO - 2020-03-06 12:07:49 --> Helper loaded: form_helper
INFO - 2020-03-06 12:07:49 --> Form Validation Class Initialized
INFO - 2020-03-06 12:07:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 12:07:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 12:07:49 --> Final output sent to browser
DEBUG - 2020-03-06 12:07:49 --> Total execution time: 0.0086
INFO - 2020-03-06 12:49:22 --> Config Class Initialized
INFO - 2020-03-06 12:49:22 --> Hooks Class Initialized
DEBUG - 2020-03-06 12:49:22 --> UTF-8 Support Enabled
INFO - 2020-03-06 12:49:22 --> Utf8 Class Initialized
INFO - 2020-03-06 12:49:22 --> URI Class Initialized
DEBUG - 2020-03-06 12:49:22 --> No URI present. Default controller set.
INFO - 2020-03-06 12:49:22 --> Router Class Initialized
INFO - 2020-03-06 12:49:22 --> Output Class Initialized
INFO - 2020-03-06 12:49:22 --> Security Class Initialized
DEBUG - 2020-03-06 12:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 12:49:22 --> Input Class Initialized
INFO - 2020-03-06 12:49:22 --> Language Class Initialized
INFO - 2020-03-06 12:49:22 --> Loader Class Initialized
INFO - 2020-03-06 12:49:22 --> Helper loaded: url_helper
INFO - 2020-03-06 12:49:22 --> Helper loaded: string_helper
INFO - 2020-03-06 12:49:22 --> Database Driver Class Initialized
DEBUG - 2020-03-06 12:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 12:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 12:49:22 --> Controller Class Initialized
INFO - 2020-03-06 12:49:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 12:49:22 --> Pagination Class Initialized
INFO - 2020-03-06 12:49:22 --> Model "M_show" initialized
INFO - 2020-03-06 12:49:22 --> Helper loaded: form_helper
INFO - 2020-03-06 12:49:22 --> Form Validation Class Initialized
INFO - 2020-03-06 12:49:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 12:49:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 12:49:22 --> Final output sent to browser
DEBUG - 2020-03-06 12:49:22 --> Total execution time: 0.0382
INFO - 2020-03-06 12:49:39 --> Config Class Initialized
INFO - 2020-03-06 12:49:39 --> Hooks Class Initialized
DEBUG - 2020-03-06 12:49:39 --> UTF-8 Support Enabled
INFO - 2020-03-06 12:49:39 --> Utf8 Class Initialized
INFO - 2020-03-06 12:49:39 --> URI Class Initialized
INFO - 2020-03-06 12:49:39 --> Router Class Initialized
INFO - 2020-03-06 12:49:39 --> Output Class Initialized
INFO - 2020-03-06 12:49:39 --> Security Class Initialized
DEBUG - 2020-03-06 12:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 12:49:39 --> Input Class Initialized
INFO - 2020-03-06 12:49:39 --> Language Class Initialized
INFO - 2020-03-06 12:49:39 --> Loader Class Initialized
INFO - 2020-03-06 12:49:39 --> Helper loaded: url_helper
INFO - 2020-03-06 12:49:39 --> Helper loaded: string_helper
INFO - 2020-03-06 12:49:39 --> Database Driver Class Initialized
DEBUG - 2020-03-06 12:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 12:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 12:49:39 --> Controller Class Initialized
INFO - 2020-03-06 12:49:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 12:49:39 --> Pagination Class Initialized
INFO - 2020-03-06 12:49:39 --> Model "M_show" initialized
INFO - 2020-03-06 12:49:39 --> Helper loaded: form_helper
INFO - 2020-03-06 12:49:39 --> Form Validation Class Initialized
INFO - 2020-03-06 12:49:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 12:49:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 12:49:39 --> Final output sent to browser
DEBUG - 2020-03-06 12:49:39 --> Total execution time: 0.0093
INFO - 2020-03-06 12:49:40 --> Config Class Initialized
INFO - 2020-03-06 12:49:40 --> Hooks Class Initialized
DEBUG - 2020-03-06 12:49:40 --> UTF-8 Support Enabled
INFO - 2020-03-06 12:49:40 --> Utf8 Class Initialized
INFO - 2020-03-06 12:49:40 --> URI Class Initialized
INFO - 2020-03-06 12:49:40 --> Router Class Initialized
INFO - 2020-03-06 12:49:40 --> Output Class Initialized
INFO - 2020-03-06 12:49:40 --> Security Class Initialized
DEBUG - 2020-03-06 12:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 12:49:40 --> Input Class Initialized
INFO - 2020-03-06 12:49:40 --> Language Class Initialized
ERROR - 2020-03-06 12:49:40 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-06 12:49:46 --> Config Class Initialized
INFO - 2020-03-06 12:49:46 --> Hooks Class Initialized
DEBUG - 2020-03-06 12:49:46 --> UTF-8 Support Enabled
INFO - 2020-03-06 12:49:46 --> Utf8 Class Initialized
INFO - 2020-03-06 12:49:46 --> URI Class Initialized
INFO - 2020-03-06 12:49:46 --> Router Class Initialized
INFO - 2020-03-06 12:49:46 --> Output Class Initialized
INFO - 2020-03-06 12:49:46 --> Security Class Initialized
DEBUG - 2020-03-06 12:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 12:49:46 --> Input Class Initialized
INFO - 2020-03-06 12:49:46 --> Language Class Initialized
INFO - 2020-03-06 12:49:46 --> Loader Class Initialized
INFO - 2020-03-06 12:49:46 --> Helper loaded: url_helper
INFO - 2020-03-06 12:49:46 --> Helper loaded: string_helper
INFO - 2020-03-06 12:49:46 --> Database Driver Class Initialized
DEBUG - 2020-03-06 12:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 12:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 12:49:46 --> Controller Class Initialized
INFO - 2020-03-06 12:49:46 --> Model "M_tiket" initialized
INFO - 2020-03-06 12:49:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 12:49:46 --> Model "M_pesan" initialized
INFO - 2020-03-06 12:49:46 --> Helper loaded: form_helper
INFO - 2020-03-06 12:49:46 --> Form Validation Class Initialized
INFO - 2020-03-06 12:49:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 12:49:46 --> Final output sent to browser
DEBUG - 2020-03-06 12:49:46 --> Total execution time: 0.0096
INFO - 2020-03-06 12:49:57 --> Config Class Initialized
INFO - 2020-03-06 12:49:57 --> Hooks Class Initialized
DEBUG - 2020-03-06 12:49:57 --> UTF-8 Support Enabled
INFO - 2020-03-06 12:49:57 --> Utf8 Class Initialized
INFO - 2020-03-06 12:49:57 --> URI Class Initialized
INFO - 2020-03-06 12:49:57 --> Router Class Initialized
INFO - 2020-03-06 12:49:57 --> Output Class Initialized
INFO - 2020-03-06 12:49:57 --> Security Class Initialized
DEBUG - 2020-03-06 12:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 12:49:57 --> Input Class Initialized
INFO - 2020-03-06 12:49:57 --> Language Class Initialized
INFO - 2020-03-06 12:49:57 --> Loader Class Initialized
INFO - 2020-03-06 12:49:57 --> Helper loaded: url_helper
INFO - 2020-03-06 12:49:57 --> Helper loaded: string_helper
INFO - 2020-03-06 12:49:57 --> Database Driver Class Initialized
DEBUG - 2020-03-06 12:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 12:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 12:49:57 --> Controller Class Initialized
INFO - 2020-03-06 12:49:57 --> Model "M_tiket" initialized
INFO - 2020-03-06 12:49:57 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 12:49:57 --> Model "M_pesan" initialized
INFO - 2020-03-06 12:49:57 --> Helper loaded: form_helper
INFO - 2020-03-06 12:49:57 --> Form Validation Class Initialized
INFO - 2020-03-06 12:49:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 12:49:57 --> Final output sent to browser
DEBUG - 2020-03-06 12:49:57 --> Total execution time: 0.0074
INFO - 2020-03-06 12:50:13 --> Config Class Initialized
INFO - 2020-03-06 12:50:13 --> Hooks Class Initialized
DEBUG - 2020-03-06 12:50:13 --> UTF-8 Support Enabled
INFO - 2020-03-06 12:50:13 --> Utf8 Class Initialized
INFO - 2020-03-06 12:50:13 --> URI Class Initialized
DEBUG - 2020-03-06 12:50:13 --> No URI present. Default controller set.
INFO - 2020-03-06 12:50:13 --> Router Class Initialized
INFO - 2020-03-06 12:50:13 --> Output Class Initialized
INFO - 2020-03-06 12:50:13 --> Security Class Initialized
DEBUG - 2020-03-06 12:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 12:50:13 --> Input Class Initialized
INFO - 2020-03-06 12:50:13 --> Language Class Initialized
INFO - 2020-03-06 12:50:13 --> Loader Class Initialized
INFO - 2020-03-06 12:50:13 --> Helper loaded: url_helper
INFO - 2020-03-06 12:50:13 --> Helper loaded: string_helper
INFO - 2020-03-06 12:50:13 --> Database Driver Class Initialized
DEBUG - 2020-03-06 12:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 12:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 12:50:13 --> Controller Class Initialized
INFO - 2020-03-06 12:50:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 12:50:13 --> Pagination Class Initialized
INFO - 2020-03-06 12:50:13 --> Model "M_show" initialized
INFO - 2020-03-06 12:50:13 --> Helper loaded: form_helper
INFO - 2020-03-06 12:50:13 --> Form Validation Class Initialized
INFO - 2020-03-06 12:50:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 12:50:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 12:50:13 --> Final output sent to browser
DEBUG - 2020-03-06 12:50:13 --> Total execution time: 0.0119
INFO - 2020-03-06 13:02:56 --> Config Class Initialized
INFO - 2020-03-06 13:02:56 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:02:56 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:02:56 --> Utf8 Class Initialized
INFO - 2020-03-06 13:02:56 --> URI Class Initialized
DEBUG - 2020-03-06 13:02:56 --> No URI present. Default controller set.
INFO - 2020-03-06 13:02:56 --> Router Class Initialized
INFO - 2020-03-06 13:02:56 --> Output Class Initialized
INFO - 2020-03-06 13:02:56 --> Security Class Initialized
DEBUG - 2020-03-06 13:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:02:56 --> Input Class Initialized
INFO - 2020-03-06 13:02:56 --> Language Class Initialized
INFO - 2020-03-06 13:02:56 --> Loader Class Initialized
INFO - 2020-03-06 13:02:56 --> Helper loaded: url_helper
INFO - 2020-03-06 13:02:56 --> Helper loaded: string_helper
INFO - 2020-03-06 13:02:56 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:02:56 --> Controller Class Initialized
INFO - 2020-03-06 13:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:02:56 --> Pagination Class Initialized
INFO - 2020-03-06 13:02:56 --> Model "M_show" initialized
INFO - 2020-03-06 13:02:56 --> Helper loaded: form_helper
INFO - 2020-03-06 13:02:56 --> Form Validation Class Initialized
INFO - 2020-03-06 13:02:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:02:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 13:02:56 --> Final output sent to browser
DEBUG - 2020-03-06 13:02:56 --> Total execution time: 0.0443
INFO - 2020-03-06 13:03:09 --> Config Class Initialized
INFO - 2020-03-06 13:03:09 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:03:09 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:03:09 --> Utf8 Class Initialized
INFO - 2020-03-06 13:03:09 --> URI Class Initialized
INFO - 2020-03-06 13:03:09 --> Router Class Initialized
INFO - 2020-03-06 13:03:09 --> Output Class Initialized
INFO - 2020-03-06 13:03:09 --> Security Class Initialized
DEBUG - 2020-03-06 13:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:03:09 --> Input Class Initialized
INFO - 2020-03-06 13:03:09 --> Language Class Initialized
INFO - 2020-03-06 13:03:09 --> Loader Class Initialized
INFO - 2020-03-06 13:03:09 --> Helper loaded: url_helper
INFO - 2020-03-06 13:03:09 --> Helper loaded: string_helper
INFO - 2020-03-06 13:03:09 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:03:09 --> Controller Class Initialized
INFO - 2020-03-06 13:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:03:09 --> Pagination Class Initialized
INFO - 2020-03-06 13:03:09 --> Model "M_show" initialized
INFO - 2020-03-06 13:03:09 --> Helper loaded: form_helper
INFO - 2020-03-06 13:03:09 --> Form Validation Class Initialized
INFO - 2020-03-06 13:03:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:03:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 13:03:09 --> Final output sent to browser
DEBUG - 2020-03-06 13:03:09 --> Total execution time: 0.0103
INFO - 2020-03-06 13:03:14 --> Config Class Initialized
INFO - 2020-03-06 13:03:14 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:03:14 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:03:14 --> Utf8 Class Initialized
INFO - 2020-03-06 13:03:14 --> URI Class Initialized
INFO - 2020-03-06 13:03:14 --> Router Class Initialized
INFO - 2020-03-06 13:03:14 --> Output Class Initialized
INFO - 2020-03-06 13:03:14 --> Security Class Initialized
DEBUG - 2020-03-06 13:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:03:14 --> Input Class Initialized
INFO - 2020-03-06 13:03:14 --> Language Class Initialized
INFO - 2020-03-06 13:03:14 --> Loader Class Initialized
INFO - 2020-03-06 13:03:14 --> Helper loaded: url_helper
INFO - 2020-03-06 13:03:14 --> Helper loaded: string_helper
INFO - 2020-03-06 13:03:14 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:03:14 --> Controller Class Initialized
INFO - 2020-03-06 13:03:14 --> Model "M_tiket" initialized
INFO - 2020-03-06 13:03:14 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 13:03:14 --> Model "M_pesan" initialized
INFO - 2020-03-06 13:03:14 --> Helper loaded: form_helper
INFO - 2020-03-06 13:03:14 --> Form Validation Class Initialized
INFO - 2020-03-06 13:03:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 13:03:14 --> Final output sent to browser
DEBUG - 2020-03-06 13:03:14 --> Total execution time: 0.0099
INFO - 2020-03-06 13:04:02 --> Config Class Initialized
INFO - 2020-03-06 13:04:02 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:04:02 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:04:02 --> Utf8 Class Initialized
INFO - 2020-03-06 13:04:02 --> URI Class Initialized
DEBUG - 2020-03-06 13:04:02 --> No URI present. Default controller set.
INFO - 2020-03-06 13:04:02 --> Router Class Initialized
INFO - 2020-03-06 13:04:02 --> Output Class Initialized
INFO - 2020-03-06 13:04:02 --> Security Class Initialized
DEBUG - 2020-03-06 13:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:04:02 --> Input Class Initialized
INFO - 2020-03-06 13:04:02 --> Language Class Initialized
INFO - 2020-03-06 13:04:02 --> Loader Class Initialized
INFO - 2020-03-06 13:04:02 --> Helper loaded: url_helper
INFO - 2020-03-06 13:04:02 --> Helper loaded: string_helper
INFO - 2020-03-06 13:04:02 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:04:02 --> Controller Class Initialized
INFO - 2020-03-06 13:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:04:02 --> Pagination Class Initialized
INFO - 2020-03-06 13:04:02 --> Model "M_show" initialized
INFO - 2020-03-06 13:04:02 --> Helper loaded: form_helper
INFO - 2020-03-06 13:04:02 --> Form Validation Class Initialized
INFO - 2020-03-06 13:04:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:04:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 13:04:02 --> Final output sent to browser
DEBUG - 2020-03-06 13:04:02 --> Total execution time: 0.0186
INFO - 2020-03-06 13:05:37 --> Config Class Initialized
INFO - 2020-03-06 13:05:37 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:05:37 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:05:37 --> Utf8 Class Initialized
INFO - 2020-03-06 13:05:37 --> URI Class Initialized
DEBUG - 2020-03-06 13:05:37 --> No URI present. Default controller set.
INFO - 2020-03-06 13:05:37 --> Router Class Initialized
INFO - 2020-03-06 13:05:37 --> Output Class Initialized
INFO - 2020-03-06 13:05:37 --> Security Class Initialized
DEBUG - 2020-03-06 13:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:05:37 --> Input Class Initialized
INFO - 2020-03-06 13:05:37 --> Language Class Initialized
INFO - 2020-03-06 13:05:37 --> Loader Class Initialized
INFO - 2020-03-06 13:05:37 --> Helper loaded: url_helper
INFO - 2020-03-06 13:05:37 --> Helper loaded: string_helper
INFO - 2020-03-06 13:05:37 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:05:37 --> Controller Class Initialized
INFO - 2020-03-06 13:05:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:05:37 --> Pagination Class Initialized
INFO - 2020-03-06 13:05:37 --> Model "M_show" initialized
INFO - 2020-03-06 13:05:37 --> Helper loaded: form_helper
INFO - 2020-03-06 13:05:37 --> Form Validation Class Initialized
INFO - 2020-03-06 13:05:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:05:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 13:05:37 --> Final output sent to browser
DEBUG - 2020-03-06 13:05:37 --> Total execution time: 0.0319
INFO - 2020-03-06 13:05:38 --> Config Class Initialized
INFO - 2020-03-06 13:05:38 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:05:38 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:05:38 --> Utf8 Class Initialized
INFO - 2020-03-06 13:05:38 --> URI Class Initialized
DEBUG - 2020-03-06 13:05:38 --> No URI present. Default controller set.
INFO - 2020-03-06 13:05:38 --> Router Class Initialized
INFO - 2020-03-06 13:05:38 --> Output Class Initialized
INFO - 2020-03-06 13:05:38 --> Security Class Initialized
DEBUG - 2020-03-06 13:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:05:38 --> Input Class Initialized
INFO - 2020-03-06 13:05:38 --> Language Class Initialized
INFO - 2020-03-06 13:05:38 --> Loader Class Initialized
INFO - 2020-03-06 13:05:38 --> Helper loaded: url_helper
INFO - 2020-03-06 13:05:38 --> Helper loaded: string_helper
INFO - 2020-03-06 13:05:38 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:05:38 --> Controller Class Initialized
INFO - 2020-03-06 13:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:05:38 --> Pagination Class Initialized
INFO - 2020-03-06 13:05:38 --> Model "M_show" initialized
INFO - 2020-03-06 13:05:38 --> Helper loaded: form_helper
INFO - 2020-03-06 13:05:38 --> Form Validation Class Initialized
INFO - 2020-03-06 13:05:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:05:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 13:05:38 --> Final output sent to browser
DEBUG - 2020-03-06 13:05:38 --> Total execution time: 0.0055
INFO - 2020-03-06 13:05:42 --> Config Class Initialized
INFO - 2020-03-06 13:05:42 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:05:42 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:05:42 --> Utf8 Class Initialized
INFO - 2020-03-06 13:05:42 --> URI Class Initialized
DEBUG - 2020-03-06 13:05:42 --> No URI present. Default controller set.
INFO - 2020-03-06 13:05:42 --> Router Class Initialized
INFO - 2020-03-06 13:05:42 --> Output Class Initialized
INFO - 2020-03-06 13:05:42 --> Security Class Initialized
DEBUG - 2020-03-06 13:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:05:42 --> Input Class Initialized
INFO - 2020-03-06 13:05:42 --> Language Class Initialized
INFO - 2020-03-06 13:05:42 --> Loader Class Initialized
INFO - 2020-03-06 13:05:42 --> Helper loaded: url_helper
INFO - 2020-03-06 13:05:42 --> Helper loaded: string_helper
INFO - 2020-03-06 13:05:42 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:05:42 --> Controller Class Initialized
INFO - 2020-03-06 13:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:05:42 --> Pagination Class Initialized
INFO - 2020-03-06 13:05:42 --> Model "M_show" initialized
INFO - 2020-03-06 13:05:42 --> Helper loaded: form_helper
INFO - 2020-03-06 13:05:42 --> Form Validation Class Initialized
INFO - 2020-03-06 13:05:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:05:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 13:05:42 --> Final output sent to browser
DEBUG - 2020-03-06 13:05:42 --> Total execution time: 0.0054
INFO - 2020-03-06 13:31:45 --> Config Class Initialized
INFO - 2020-03-06 13:31:45 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:31:45 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:31:45 --> Utf8 Class Initialized
INFO - 2020-03-06 13:31:45 --> URI Class Initialized
DEBUG - 2020-03-06 13:31:45 --> No URI present. Default controller set.
INFO - 2020-03-06 13:31:45 --> Router Class Initialized
INFO - 2020-03-06 13:31:45 --> Output Class Initialized
INFO - 2020-03-06 13:31:45 --> Security Class Initialized
DEBUG - 2020-03-06 13:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:31:45 --> Input Class Initialized
INFO - 2020-03-06 13:31:45 --> Language Class Initialized
INFO - 2020-03-06 13:31:45 --> Loader Class Initialized
INFO - 2020-03-06 13:31:45 --> Helper loaded: url_helper
INFO - 2020-03-06 13:31:45 --> Helper loaded: string_helper
INFO - 2020-03-06 13:31:45 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:31:45 --> Controller Class Initialized
INFO - 2020-03-06 13:31:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:31:45 --> Pagination Class Initialized
INFO - 2020-03-06 13:31:45 --> Model "M_show" initialized
INFO - 2020-03-06 13:31:45 --> Helper loaded: form_helper
INFO - 2020-03-06 13:31:45 --> Form Validation Class Initialized
INFO - 2020-03-06 13:31:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:31:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 13:31:45 --> Final output sent to browser
DEBUG - 2020-03-06 13:31:45 --> Total execution time: 0.0311
INFO - 2020-03-06 13:31:59 --> Config Class Initialized
INFO - 2020-03-06 13:31:59 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:31:59 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:31:59 --> Utf8 Class Initialized
INFO - 2020-03-06 13:31:59 --> URI Class Initialized
INFO - 2020-03-06 13:31:59 --> Router Class Initialized
INFO - 2020-03-06 13:31:59 --> Output Class Initialized
INFO - 2020-03-06 13:31:59 --> Security Class Initialized
DEBUG - 2020-03-06 13:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:31:59 --> Input Class Initialized
INFO - 2020-03-06 13:31:59 --> Language Class Initialized
INFO - 2020-03-06 13:31:59 --> Loader Class Initialized
INFO - 2020-03-06 13:31:59 --> Helper loaded: url_helper
INFO - 2020-03-06 13:31:59 --> Helper loaded: string_helper
INFO - 2020-03-06 13:31:59 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:31:59 --> Controller Class Initialized
INFO - 2020-03-06 13:31:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:31:59 --> Pagination Class Initialized
INFO - 2020-03-06 13:31:59 --> Model "M_show" initialized
INFO - 2020-03-06 13:31:59 --> Helper loaded: form_helper
INFO - 2020-03-06 13:31:59 --> Form Validation Class Initialized
INFO - 2020-03-06 13:31:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:31:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 13:31:59 --> Final output sent to browser
DEBUG - 2020-03-06 13:31:59 --> Total execution time: 0.0085
INFO - 2020-03-06 13:32:04 --> Config Class Initialized
INFO - 2020-03-06 13:32:04 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:32:04 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:32:04 --> Utf8 Class Initialized
INFO - 2020-03-06 13:32:04 --> URI Class Initialized
INFO - 2020-03-06 13:32:04 --> Router Class Initialized
INFO - 2020-03-06 13:32:04 --> Output Class Initialized
INFO - 2020-03-06 13:32:04 --> Security Class Initialized
DEBUG - 2020-03-06 13:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:32:04 --> Input Class Initialized
INFO - 2020-03-06 13:32:04 --> Language Class Initialized
INFO - 2020-03-06 13:32:04 --> Loader Class Initialized
INFO - 2020-03-06 13:32:04 --> Helper loaded: url_helper
INFO - 2020-03-06 13:32:04 --> Helper loaded: string_helper
INFO - 2020-03-06 13:32:04 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:32:04 --> Controller Class Initialized
INFO - 2020-03-06 13:32:04 --> Model "M_tiket" initialized
INFO - 2020-03-06 13:32:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 13:32:04 --> Model "M_pesan" initialized
INFO - 2020-03-06 13:32:04 --> Helper loaded: form_helper
INFO - 2020-03-06 13:32:04 --> Form Validation Class Initialized
INFO - 2020-03-06 13:32:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 13:32:04 --> Final output sent to browser
DEBUG - 2020-03-06 13:32:04 --> Total execution time: 0.0193
INFO - 2020-03-06 13:45:58 --> Config Class Initialized
INFO - 2020-03-06 13:45:58 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:45:58 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:45:58 --> Utf8 Class Initialized
INFO - 2020-03-06 13:45:58 --> URI Class Initialized
DEBUG - 2020-03-06 13:45:58 --> No URI present. Default controller set.
INFO - 2020-03-06 13:45:58 --> Router Class Initialized
INFO - 2020-03-06 13:45:58 --> Output Class Initialized
INFO - 2020-03-06 13:45:58 --> Security Class Initialized
DEBUG - 2020-03-06 13:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:45:58 --> Input Class Initialized
INFO - 2020-03-06 13:45:58 --> Language Class Initialized
INFO - 2020-03-06 13:45:58 --> Loader Class Initialized
INFO - 2020-03-06 13:45:58 --> Helper loaded: url_helper
INFO - 2020-03-06 13:45:58 --> Helper loaded: string_helper
INFO - 2020-03-06 13:45:58 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:45:58 --> Controller Class Initialized
INFO - 2020-03-06 13:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:45:58 --> Pagination Class Initialized
INFO - 2020-03-06 13:45:58 --> Model "M_show" initialized
INFO - 2020-03-06 13:45:58 --> Helper loaded: form_helper
INFO - 2020-03-06 13:45:58 --> Form Validation Class Initialized
INFO - 2020-03-06 13:45:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:45:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 13:45:58 --> Final output sent to browser
DEBUG - 2020-03-06 13:45:58 --> Total execution time: 0.0325
INFO - 2020-03-06 13:46:06 --> Config Class Initialized
INFO - 2020-03-06 13:46:06 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:46:06 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:46:06 --> Utf8 Class Initialized
INFO - 2020-03-06 13:46:06 --> URI Class Initialized
INFO - 2020-03-06 13:46:06 --> Router Class Initialized
INFO - 2020-03-06 13:46:06 --> Output Class Initialized
INFO - 2020-03-06 13:46:06 --> Security Class Initialized
DEBUG - 2020-03-06 13:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:46:06 --> Input Class Initialized
INFO - 2020-03-06 13:46:06 --> Language Class Initialized
INFO - 2020-03-06 13:46:06 --> Loader Class Initialized
INFO - 2020-03-06 13:46:06 --> Helper loaded: url_helper
INFO - 2020-03-06 13:46:06 --> Helper loaded: string_helper
INFO - 2020-03-06 13:46:06 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:46:06 --> Controller Class Initialized
INFO - 2020-03-06 13:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:46:06 --> Pagination Class Initialized
INFO - 2020-03-06 13:46:06 --> Model "M_show" initialized
INFO - 2020-03-06 13:46:06 --> Helper loaded: form_helper
INFO - 2020-03-06 13:46:06 --> Form Validation Class Initialized
INFO - 2020-03-06 13:46:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:46:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 13:46:06 --> Final output sent to browser
DEBUG - 2020-03-06 13:46:06 --> Total execution time: 0.0087
INFO - 2020-03-06 13:46:11 --> Config Class Initialized
INFO - 2020-03-06 13:46:11 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:46:11 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:46:11 --> Utf8 Class Initialized
INFO - 2020-03-06 13:46:11 --> URI Class Initialized
INFO - 2020-03-06 13:46:11 --> Router Class Initialized
INFO - 2020-03-06 13:46:11 --> Output Class Initialized
INFO - 2020-03-06 13:46:11 --> Security Class Initialized
DEBUG - 2020-03-06 13:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:46:11 --> Input Class Initialized
INFO - 2020-03-06 13:46:11 --> Language Class Initialized
INFO - 2020-03-06 13:46:11 --> Loader Class Initialized
INFO - 2020-03-06 13:46:11 --> Helper loaded: url_helper
INFO - 2020-03-06 13:46:11 --> Helper loaded: string_helper
INFO - 2020-03-06 13:46:11 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:46:11 --> Controller Class Initialized
INFO - 2020-03-06 13:46:11 --> Model "M_tiket" initialized
INFO - 2020-03-06 13:46:11 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 13:46:11 --> Model "M_pesan" initialized
INFO - 2020-03-06 13:46:11 --> Helper loaded: form_helper
INFO - 2020-03-06 13:46:11 --> Form Validation Class Initialized
INFO - 2020-03-06 13:46:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 13:46:11 --> Final output sent to browser
DEBUG - 2020-03-06 13:46:11 --> Total execution time: 0.0114
INFO - 2020-03-06 13:46:28 --> Config Class Initialized
INFO - 2020-03-06 13:46:28 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:46:28 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:46:28 --> Utf8 Class Initialized
INFO - 2020-03-06 13:46:28 --> URI Class Initialized
INFO - 2020-03-06 13:46:28 --> Router Class Initialized
INFO - 2020-03-06 13:46:28 --> Output Class Initialized
INFO - 2020-03-06 13:46:28 --> Security Class Initialized
DEBUG - 2020-03-06 13:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:46:28 --> Input Class Initialized
INFO - 2020-03-06 13:46:28 --> Language Class Initialized
INFO - 2020-03-06 13:46:28 --> Loader Class Initialized
INFO - 2020-03-06 13:46:28 --> Helper loaded: url_helper
INFO - 2020-03-06 13:46:28 --> Helper loaded: string_helper
INFO - 2020-03-06 13:46:28 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:46:28 --> Controller Class Initialized
INFO - 2020-03-06 13:46:28 --> Model "M_tiket" initialized
INFO - 2020-03-06 13:46:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 13:46:28 --> Model "M_pesan" initialized
INFO - 2020-03-06 13:46:28 --> Helper loaded: form_helper
INFO - 2020-03-06 13:46:28 --> Form Validation Class Initialized
INFO - 2020-03-06 13:46:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 13:46:28 --> Final output sent to browser
DEBUG - 2020-03-06 13:46:28 --> Total execution time: 0.0073
INFO - 2020-03-06 13:46:56 --> Config Class Initialized
INFO - 2020-03-06 13:46:56 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:46:56 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:46:56 --> Utf8 Class Initialized
INFO - 2020-03-06 13:46:56 --> URI Class Initialized
DEBUG - 2020-03-06 13:46:56 --> No URI present. Default controller set.
INFO - 2020-03-06 13:46:56 --> Router Class Initialized
INFO - 2020-03-06 13:46:56 --> Output Class Initialized
INFO - 2020-03-06 13:46:56 --> Security Class Initialized
DEBUG - 2020-03-06 13:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:46:56 --> Input Class Initialized
INFO - 2020-03-06 13:46:56 --> Language Class Initialized
INFO - 2020-03-06 13:46:56 --> Loader Class Initialized
INFO - 2020-03-06 13:46:56 --> Helper loaded: url_helper
INFO - 2020-03-06 13:46:56 --> Helper loaded: string_helper
INFO - 2020-03-06 13:46:56 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:46:56 --> Controller Class Initialized
INFO - 2020-03-06 13:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:46:56 --> Pagination Class Initialized
INFO - 2020-03-06 13:46:56 --> Model "M_show" initialized
INFO - 2020-03-06 13:46:56 --> Helper loaded: form_helper
INFO - 2020-03-06 13:46:56 --> Form Validation Class Initialized
INFO - 2020-03-06 13:46:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:46:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 13:46:56 --> Final output sent to browser
DEBUG - 2020-03-06 13:46:56 --> Total execution time: 0.0053
INFO - 2020-03-06 13:47:32 --> Config Class Initialized
INFO - 2020-03-06 13:47:32 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:47:32 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:47:32 --> Utf8 Class Initialized
INFO - 2020-03-06 13:47:33 --> URI Class Initialized
DEBUG - 2020-03-06 13:47:33 --> No URI present. Default controller set.
INFO - 2020-03-06 13:47:33 --> Router Class Initialized
INFO - 2020-03-06 13:47:33 --> Output Class Initialized
INFO - 2020-03-06 13:47:33 --> Security Class Initialized
DEBUG - 2020-03-06 13:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:47:33 --> Input Class Initialized
INFO - 2020-03-06 13:47:33 --> Language Class Initialized
INFO - 2020-03-06 13:47:33 --> Loader Class Initialized
INFO - 2020-03-06 13:47:33 --> Helper loaded: url_helper
INFO - 2020-03-06 13:47:33 --> Helper loaded: string_helper
INFO - 2020-03-06 13:47:33 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:47:33 --> Controller Class Initialized
INFO - 2020-03-06 13:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:47:33 --> Pagination Class Initialized
INFO - 2020-03-06 13:47:33 --> Model "M_show" initialized
INFO - 2020-03-06 13:47:33 --> Helper loaded: form_helper
INFO - 2020-03-06 13:47:33 --> Form Validation Class Initialized
INFO - 2020-03-06 13:47:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:47:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 13:47:33 --> Final output sent to browser
DEBUG - 2020-03-06 13:47:33 --> Total execution time: 0.0067
INFO - 2020-03-06 13:47:38 --> Config Class Initialized
INFO - 2020-03-06 13:47:38 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:47:38 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:47:38 --> Utf8 Class Initialized
INFO - 2020-03-06 13:47:38 --> URI Class Initialized
INFO - 2020-03-06 13:47:38 --> Router Class Initialized
INFO - 2020-03-06 13:47:38 --> Output Class Initialized
INFO - 2020-03-06 13:47:38 --> Security Class Initialized
DEBUG - 2020-03-06 13:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:47:38 --> Input Class Initialized
INFO - 2020-03-06 13:47:38 --> Language Class Initialized
INFO - 2020-03-06 13:47:38 --> Loader Class Initialized
INFO - 2020-03-06 13:47:38 --> Helper loaded: url_helper
INFO - 2020-03-06 13:47:38 --> Helper loaded: string_helper
INFO - 2020-03-06 13:47:38 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:47:38 --> Controller Class Initialized
INFO - 2020-03-06 13:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:47:38 --> Pagination Class Initialized
INFO - 2020-03-06 13:47:38 --> Model "M_show" initialized
INFO - 2020-03-06 13:47:38 --> Helper loaded: form_helper
INFO - 2020-03-06 13:47:38 --> Form Validation Class Initialized
INFO - 2020-03-06 13:47:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:47:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 13:47:38 --> Final output sent to browser
DEBUG - 2020-03-06 13:47:38 --> Total execution time: 0.0072
INFO - 2020-03-06 13:47:42 --> Config Class Initialized
INFO - 2020-03-06 13:47:42 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:47:42 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:47:42 --> Utf8 Class Initialized
INFO - 2020-03-06 13:47:42 --> URI Class Initialized
INFO - 2020-03-06 13:47:42 --> Router Class Initialized
INFO - 2020-03-06 13:47:42 --> Output Class Initialized
INFO - 2020-03-06 13:47:42 --> Security Class Initialized
DEBUG - 2020-03-06 13:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:47:42 --> Input Class Initialized
INFO - 2020-03-06 13:47:42 --> Language Class Initialized
INFO - 2020-03-06 13:47:42 --> Loader Class Initialized
INFO - 2020-03-06 13:47:42 --> Helper loaded: url_helper
INFO - 2020-03-06 13:47:42 --> Helper loaded: string_helper
INFO - 2020-03-06 13:47:42 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:47:42 --> Controller Class Initialized
INFO - 2020-03-06 13:47:42 --> Model "M_tiket" initialized
INFO - 2020-03-06 13:47:42 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 13:47:42 --> Model "M_pesan" initialized
INFO - 2020-03-06 13:47:42 --> Helper loaded: form_helper
INFO - 2020-03-06 13:47:42 --> Form Validation Class Initialized
INFO - 2020-03-06 13:47:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 13:47:42 --> Final output sent to browser
DEBUG - 2020-03-06 13:47:42 --> Total execution time: 0.0074
INFO - 2020-03-06 13:47:47 --> Config Class Initialized
INFO - 2020-03-06 13:47:47 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:47:47 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:47:47 --> Utf8 Class Initialized
INFO - 2020-03-06 13:47:47 --> URI Class Initialized
INFO - 2020-03-06 13:47:47 --> Router Class Initialized
INFO - 2020-03-06 13:47:47 --> Output Class Initialized
INFO - 2020-03-06 13:47:47 --> Security Class Initialized
DEBUG - 2020-03-06 13:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:47:47 --> Input Class Initialized
INFO - 2020-03-06 13:47:47 --> Language Class Initialized
INFO - 2020-03-06 13:47:47 --> Loader Class Initialized
INFO - 2020-03-06 13:47:47 --> Helper loaded: url_helper
INFO - 2020-03-06 13:47:47 --> Helper loaded: string_helper
INFO - 2020-03-06 13:47:47 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:47:47 --> Controller Class Initialized
INFO - 2020-03-06 13:47:47 --> Model "M_tiket" initialized
INFO - 2020-03-06 13:47:47 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 13:47:47 --> Model "M_pesan" initialized
INFO - 2020-03-06 13:47:47 --> Helper loaded: form_helper
INFO - 2020-03-06 13:47:47 --> Form Validation Class Initialized
INFO - 2020-03-06 13:47:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 13:47:47 --> Final output sent to browser
DEBUG - 2020-03-06 13:47:47 --> Total execution time: 0.0100
INFO - 2020-03-06 13:49:06 --> Config Class Initialized
INFO - 2020-03-06 13:49:06 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:49:06 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:49:06 --> Utf8 Class Initialized
INFO - 2020-03-06 13:49:06 --> URI Class Initialized
INFO - 2020-03-06 13:49:06 --> Router Class Initialized
INFO - 2020-03-06 13:49:06 --> Output Class Initialized
INFO - 2020-03-06 13:49:06 --> Security Class Initialized
DEBUG - 2020-03-06 13:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:49:06 --> Input Class Initialized
INFO - 2020-03-06 13:49:06 --> Language Class Initialized
INFO - 2020-03-06 13:49:06 --> Loader Class Initialized
INFO - 2020-03-06 13:49:06 --> Helper loaded: url_helper
INFO - 2020-03-06 13:49:06 --> Helper loaded: string_helper
INFO - 2020-03-06 13:49:06 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:49:06 --> Controller Class Initialized
INFO - 2020-03-06 13:49:06 --> Model "M_tiket" initialized
INFO - 2020-03-06 13:49:06 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 13:49:06 --> Model "M_pesan" initialized
INFO - 2020-03-06 13:49:06 --> Helper loaded: form_helper
INFO - 2020-03-06 13:49:06 --> Form Validation Class Initialized
DEBUG - 2020-03-06 13:49:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-06 13:49:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-06 20:49:06 --> Final output sent to browser
DEBUG - 2020-03-06 20:49:06 --> Total execution time: 0.1644
INFO - 2020-03-06 13:49:11 --> Config Class Initialized
INFO - 2020-03-06 13:49:11 --> Hooks Class Initialized
DEBUG - 2020-03-06 13:49:11 --> UTF-8 Support Enabled
INFO - 2020-03-06 13:49:11 --> Utf8 Class Initialized
INFO - 2020-03-06 13:49:11 --> URI Class Initialized
INFO - 2020-03-06 13:49:11 --> Router Class Initialized
INFO - 2020-03-06 13:49:11 --> Output Class Initialized
INFO - 2020-03-06 13:49:11 --> Security Class Initialized
DEBUG - 2020-03-06 13:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 13:49:11 --> Input Class Initialized
INFO - 2020-03-06 13:49:11 --> Language Class Initialized
INFO - 2020-03-06 13:49:11 --> Loader Class Initialized
INFO - 2020-03-06 13:49:11 --> Helper loaded: url_helper
INFO - 2020-03-06 13:49:11 --> Helper loaded: string_helper
INFO - 2020-03-06 13:49:11 --> Database Driver Class Initialized
DEBUG - 2020-03-06 13:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 13:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 13:49:11 --> Controller Class Initialized
INFO - 2020-03-06 13:49:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 13:49:11 --> Pagination Class Initialized
INFO - 2020-03-06 13:49:11 --> Model "M_show" initialized
INFO - 2020-03-06 13:49:11 --> Helper loaded: form_helper
INFO - 2020-03-06 13:49:11 --> Form Validation Class Initialized
INFO - 2020-03-06 13:49:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 13:49:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 13:49:11 --> Final output sent to browser
DEBUG - 2020-03-06 13:49:11 --> Total execution time: 0.0077
INFO - 2020-03-06 14:05:19 --> Config Class Initialized
INFO - 2020-03-06 14:05:19 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:05:19 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:05:19 --> Utf8 Class Initialized
INFO - 2020-03-06 14:05:19 --> URI Class Initialized
DEBUG - 2020-03-06 14:05:19 --> No URI present. Default controller set.
INFO - 2020-03-06 14:05:19 --> Router Class Initialized
INFO - 2020-03-06 14:05:19 --> Output Class Initialized
INFO - 2020-03-06 14:05:19 --> Security Class Initialized
DEBUG - 2020-03-06 14:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:05:19 --> Input Class Initialized
INFO - 2020-03-06 14:05:19 --> Language Class Initialized
INFO - 2020-03-06 14:05:19 --> Loader Class Initialized
INFO - 2020-03-06 14:05:19 --> Helper loaded: url_helper
INFO - 2020-03-06 14:05:19 --> Helper loaded: string_helper
INFO - 2020-03-06 14:05:19 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:05:19 --> Controller Class Initialized
INFO - 2020-03-06 14:05:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 14:05:19 --> Pagination Class Initialized
INFO - 2020-03-06 14:05:19 --> Model "M_show" initialized
INFO - 2020-03-06 14:05:19 --> Helper loaded: form_helper
INFO - 2020-03-06 14:05:19 --> Form Validation Class Initialized
INFO - 2020-03-06 14:05:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 14:05:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 14:05:19 --> Final output sent to browser
DEBUG - 2020-03-06 14:05:19 --> Total execution time: 0.0543
INFO - 2020-03-06 14:05:26 --> Config Class Initialized
INFO - 2020-03-06 14:05:26 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:05:26 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:05:26 --> Utf8 Class Initialized
INFO - 2020-03-06 14:05:26 --> URI Class Initialized
INFO - 2020-03-06 14:05:26 --> Router Class Initialized
INFO - 2020-03-06 14:05:26 --> Output Class Initialized
INFO - 2020-03-06 14:05:26 --> Security Class Initialized
DEBUG - 2020-03-06 14:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:05:26 --> Input Class Initialized
INFO - 2020-03-06 14:05:26 --> Language Class Initialized
INFO - 2020-03-06 14:05:26 --> Loader Class Initialized
INFO - 2020-03-06 14:05:26 --> Helper loaded: url_helper
INFO - 2020-03-06 14:05:26 --> Helper loaded: string_helper
INFO - 2020-03-06 14:05:26 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:05:26 --> Controller Class Initialized
INFO - 2020-03-06 14:05:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 14:05:26 --> Pagination Class Initialized
INFO - 2020-03-06 14:05:26 --> Model "M_show" initialized
INFO - 2020-03-06 14:05:26 --> Helper loaded: form_helper
INFO - 2020-03-06 14:05:26 --> Form Validation Class Initialized
INFO - 2020-03-06 14:05:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 14:05:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 14:05:26 --> Final output sent to browser
DEBUG - 2020-03-06 14:05:26 --> Total execution time: 0.0121
INFO - 2020-03-06 14:05:27 --> Config Class Initialized
INFO - 2020-03-06 14:05:27 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:05:27 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:05:27 --> Utf8 Class Initialized
INFO - 2020-03-06 14:05:27 --> URI Class Initialized
DEBUG - 2020-03-06 14:05:27 --> No URI present. Default controller set.
INFO - 2020-03-06 14:05:27 --> Router Class Initialized
INFO - 2020-03-06 14:05:27 --> Output Class Initialized
INFO - 2020-03-06 14:05:27 --> Security Class Initialized
DEBUG - 2020-03-06 14:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:05:27 --> Input Class Initialized
INFO - 2020-03-06 14:05:27 --> Language Class Initialized
INFO - 2020-03-06 14:05:27 --> Loader Class Initialized
INFO - 2020-03-06 14:05:27 --> Helper loaded: url_helper
INFO - 2020-03-06 14:05:27 --> Helper loaded: string_helper
INFO - 2020-03-06 14:05:27 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:05:27 --> Controller Class Initialized
INFO - 2020-03-06 14:05:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 14:05:27 --> Pagination Class Initialized
INFO - 2020-03-06 14:05:27 --> Model "M_show" initialized
INFO - 2020-03-06 14:05:27 --> Helper loaded: form_helper
INFO - 2020-03-06 14:05:27 --> Form Validation Class Initialized
INFO - 2020-03-06 14:05:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 14:05:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 14:05:27 --> Final output sent to browser
DEBUG - 2020-03-06 14:05:27 --> Total execution time: 0.0430
INFO - 2020-03-06 14:05:30 --> Config Class Initialized
INFO - 2020-03-06 14:05:30 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:05:30 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:05:30 --> Utf8 Class Initialized
INFO - 2020-03-06 14:05:30 --> URI Class Initialized
INFO - 2020-03-06 14:05:30 --> Router Class Initialized
INFO - 2020-03-06 14:05:30 --> Output Class Initialized
INFO - 2020-03-06 14:05:30 --> Security Class Initialized
DEBUG - 2020-03-06 14:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:05:30 --> Input Class Initialized
INFO - 2020-03-06 14:05:30 --> Language Class Initialized
INFO - 2020-03-06 14:05:30 --> Loader Class Initialized
INFO - 2020-03-06 14:05:30 --> Helper loaded: url_helper
INFO - 2020-03-06 14:05:30 --> Helper loaded: string_helper
INFO - 2020-03-06 14:05:30 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:05:30 --> Controller Class Initialized
INFO - 2020-03-06 14:05:30 --> Model "M_tiket" initialized
INFO - 2020-03-06 14:05:30 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 14:05:30 --> Model "M_pesan" initialized
INFO - 2020-03-06 14:05:30 --> Helper loaded: form_helper
INFO - 2020-03-06 14:05:30 --> Form Validation Class Initialized
INFO - 2020-03-06 14:05:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 14:05:30 --> Final output sent to browser
DEBUG - 2020-03-06 14:05:30 --> Total execution time: 0.1633
INFO - 2020-03-06 14:05:32 --> Config Class Initialized
INFO - 2020-03-06 14:05:32 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:05:32 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:05:32 --> Utf8 Class Initialized
INFO - 2020-03-06 14:05:32 --> URI Class Initialized
INFO - 2020-03-06 14:05:32 --> Router Class Initialized
INFO - 2020-03-06 14:05:32 --> Output Class Initialized
INFO - 2020-03-06 14:05:32 --> Security Class Initialized
DEBUG - 2020-03-06 14:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:05:32 --> Input Class Initialized
INFO - 2020-03-06 14:05:32 --> Language Class Initialized
INFO - 2020-03-06 14:05:32 --> Loader Class Initialized
INFO - 2020-03-06 14:05:32 --> Helper loaded: url_helper
INFO - 2020-03-06 14:05:32 --> Helper loaded: string_helper
INFO - 2020-03-06 14:05:32 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:05:32 --> Controller Class Initialized
INFO - 2020-03-06 14:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 14:05:32 --> Pagination Class Initialized
INFO - 2020-03-06 14:05:32 --> Model "M_show" initialized
INFO - 2020-03-06 14:05:32 --> Helper loaded: form_helper
INFO - 2020-03-06 14:05:32 --> Form Validation Class Initialized
INFO - 2020-03-06 14:05:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 14:05:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 14:05:32 --> Final output sent to browser
DEBUG - 2020-03-06 14:05:32 --> Total execution time: 0.0323
INFO - 2020-03-06 14:05:35 --> Config Class Initialized
INFO - 2020-03-06 14:05:35 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:05:35 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:05:35 --> Utf8 Class Initialized
INFO - 2020-03-06 14:05:35 --> URI Class Initialized
INFO - 2020-03-06 14:05:35 --> Router Class Initialized
INFO - 2020-03-06 14:05:35 --> Output Class Initialized
INFO - 2020-03-06 14:05:35 --> Security Class Initialized
DEBUG - 2020-03-06 14:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:05:35 --> Input Class Initialized
INFO - 2020-03-06 14:05:35 --> Language Class Initialized
INFO - 2020-03-06 14:05:35 --> Loader Class Initialized
INFO - 2020-03-06 14:05:35 --> Helper loaded: url_helper
INFO - 2020-03-06 14:05:35 --> Helper loaded: string_helper
INFO - 2020-03-06 14:05:35 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:05:35 --> Controller Class Initialized
INFO - 2020-03-06 14:05:35 --> Model "M_tiket" initialized
INFO - 2020-03-06 14:05:35 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 14:05:35 --> Model "M_pesan" initialized
INFO - 2020-03-06 14:05:35 --> Helper loaded: form_helper
INFO - 2020-03-06 14:05:35 --> Form Validation Class Initialized
INFO - 2020-03-06 14:05:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 14:05:35 --> Final output sent to browser
DEBUG - 2020-03-06 14:05:35 --> Total execution time: 0.2145
INFO - 2020-03-06 14:05:42 --> Config Class Initialized
INFO - 2020-03-06 14:05:42 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:05:42 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:05:42 --> Utf8 Class Initialized
INFO - 2020-03-06 14:05:42 --> URI Class Initialized
INFO - 2020-03-06 14:05:42 --> Router Class Initialized
INFO - 2020-03-06 14:05:42 --> Output Class Initialized
INFO - 2020-03-06 14:05:42 --> Security Class Initialized
DEBUG - 2020-03-06 14:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:05:42 --> Input Class Initialized
INFO - 2020-03-06 14:05:42 --> Language Class Initialized
INFO - 2020-03-06 14:05:42 --> Loader Class Initialized
INFO - 2020-03-06 14:05:42 --> Helper loaded: url_helper
INFO - 2020-03-06 14:05:42 --> Helper loaded: string_helper
INFO - 2020-03-06 14:05:42 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:05:42 --> Controller Class Initialized
INFO - 2020-03-06 14:05:42 --> Model "M_tiket" initialized
INFO - 2020-03-06 14:05:42 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 14:05:42 --> Model "M_pesan" initialized
INFO - 2020-03-06 14:05:42 --> Helper loaded: form_helper
INFO - 2020-03-06 14:05:42 --> Form Validation Class Initialized
INFO - 2020-03-06 14:05:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 14:05:42 --> Final output sent to browser
DEBUG - 2020-03-06 14:05:42 --> Total execution time: 0.0834
INFO - 2020-03-06 14:05:56 --> Config Class Initialized
INFO - 2020-03-06 14:05:56 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:05:56 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:05:56 --> Utf8 Class Initialized
INFO - 2020-03-06 14:05:56 --> URI Class Initialized
INFO - 2020-03-06 14:05:56 --> Router Class Initialized
INFO - 2020-03-06 14:05:56 --> Output Class Initialized
INFO - 2020-03-06 14:05:56 --> Security Class Initialized
DEBUG - 2020-03-06 14:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:05:56 --> Input Class Initialized
INFO - 2020-03-06 14:05:56 --> Language Class Initialized
INFO - 2020-03-06 14:05:56 --> Loader Class Initialized
INFO - 2020-03-06 14:05:56 --> Helper loaded: url_helper
INFO - 2020-03-06 14:05:56 --> Helper loaded: string_helper
INFO - 2020-03-06 14:05:56 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:05:56 --> Controller Class Initialized
INFO - 2020-03-06 14:05:56 --> Model "M_tiket" initialized
INFO - 2020-03-06 14:05:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 14:05:56 --> Model "M_pesan" initialized
INFO - 2020-03-06 14:05:56 --> Helper loaded: form_helper
INFO - 2020-03-06 14:05:56 --> Form Validation Class Initialized
INFO - 2020-03-06 14:05:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 14:05:56 --> Final output sent to browser
DEBUG - 2020-03-06 14:05:56 --> Total execution time: 0.0102
INFO - 2020-03-06 14:16:35 --> Config Class Initialized
INFO - 2020-03-06 14:16:35 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:16:35 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:16:35 --> Utf8 Class Initialized
INFO - 2020-03-06 14:16:35 --> URI Class Initialized
DEBUG - 2020-03-06 14:16:35 --> No URI present. Default controller set.
INFO - 2020-03-06 14:16:35 --> Router Class Initialized
INFO - 2020-03-06 14:16:35 --> Output Class Initialized
INFO - 2020-03-06 14:16:35 --> Security Class Initialized
DEBUG - 2020-03-06 14:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:16:35 --> Input Class Initialized
INFO - 2020-03-06 14:16:35 --> Language Class Initialized
INFO - 2020-03-06 14:16:35 --> Loader Class Initialized
INFO - 2020-03-06 14:16:35 --> Helper loaded: url_helper
INFO - 2020-03-06 14:16:35 --> Helper loaded: string_helper
INFO - 2020-03-06 14:16:35 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:16:35 --> Controller Class Initialized
INFO - 2020-03-06 14:16:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 14:16:35 --> Pagination Class Initialized
INFO - 2020-03-06 14:16:35 --> Model "M_show" initialized
INFO - 2020-03-06 14:16:35 --> Helper loaded: form_helper
INFO - 2020-03-06 14:16:35 --> Form Validation Class Initialized
INFO - 2020-03-06 14:16:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 14:16:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 14:16:35 --> Final output sent to browser
DEBUG - 2020-03-06 14:16:35 --> Total execution time: 0.0976
INFO - 2020-03-06 14:16:53 --> Config Class Initialized
INFO - 2020-03-06 14:16:53 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:16:53 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:16:53 --> Utf8 Class Initialized
INFO - 2020-03-06 14:16:53 --> URI Class Initialized
INFO - 2020-03-06 14:16:53 --> Router Class Initialized
INFO - 2020-03-06 14:16:53 --> Output Class Initialized
INFO - 2020-03-06 14:16:53 --> Security Class Initialized
DEBUG - 2020-03-06 14:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:16:53 --> Input Class Initialized
INFO - 2020-03-06 14:16:53 --> Language Class Initialized
INFO - 2020-03-06 14:16:53 --> Loader Class Initialized
INFO - 2020-03-06 14:16:53 --> Helper loaded: url_helper
INFO - 2020-03-06 14:16:53 --> Helper loaded: string_helper
INFO - 2020-03-06 14:16:53 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:16:53 --> Controller Class Initialized
INFO - 2020-03-06 14:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 14:16:53 --> Pagination Class Initialized
INFO - 2020-03-06 14:16:53 --> Model "M_show" initialized
INFO - 2020-03-06 14:16:53 --> Helper loaded: form_helper
INFO - 2020-03-06 14:16:53 --> Form Validation Class Initialized
INFO - 2020-03-06 14:16:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 14:16:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 14:16:53 --> Final output sent to browser
DEBUG - 2020-03-06 14:16:53 --> Total execution time: 0.0109
INFO - 2020-03-06 14:16:57 --> Config Class Initialized
INFO - 2020-03-06 14:16:57 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:16:57 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:16:57 --> Utf8 Class Initialized
INFO - 2020-03-06 14:16:57 --> URI Class Initialized
INFO - 2020-03-06 14:16:57 --> Router Class Initialized
INFO - 2020-03-06 14:16:57 --> Output Class Initialized
INFO - 2020-03-06 14:16:57 --> Security Class Initialized
DEBUG - 2020-03-06 14:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:16:57 --> Input Class Initialized
INFO - 2020-03-06 14:16:57 --> Language Class Initialized
INFO - 2020-03-06 14:16:57 --> Loader Class Initialized
INFO - 2020-03-06 14:16:57 --> Helper loaded: url_helper
INFO - 2020-03-06 14:16:57 --> Helper loaded: string_helper
INFO - 2020-03-06 14:16:57 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:16:57 --> Controller Class Initialized
INFO - 2020-03-06 14:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 14:16:57 --> Pagination Class Initialized
INFO - 2020-03-06 14:16:57 --> Model "M_show" initialized
INFO - 2020-03-06 14:16:57 --> Helper loaded: form_helper
INFO - 2020-03-06 14:16:57 --> Form Validation Class Initialized
INFO - 2020-03-06 14:16:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 14:16:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 14:16:57 --> Final output sent to browser
DEBUG - 2020-03-06 14:16:57 --> Total execution time: 0.0339
INFO - 2020-03-06 14:17:02 --> Config Class Initialized
INFO - 2020-03-06 14:17:02 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:17:02 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:17:02 --> Utf8 Class Initialized
INFO - 2020-03-06 14:17:02 --> URI Class Initialized
INFO - 2020-03-06 14:17:02 --> Router Class Initialized
INFO - 2020-03-06 14:17:02 --> Output Class Initialized
INFO - 2020-03-06 14:17:02 --> Security Class Initialized
DEBUG - 2020-03-06 14:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:17:02 --> Input Class Initialized
INFO - 2020-03-06 14:17:02 --> Language Class Initialized
INFO - 2020-03-06 14:17:02 --> Loader Class Initialized
INFO - 2020-03-06 14:17:02 --> Helper loaded: url_helper
INFO - 2020-03-06 14:17:02 --> Helper loaded: string_helper
INFO - 2020-03-06 14:17:02 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:17:02 --> Controller Class Initialized
INFO - 2020-03-06 14:17:02 --> Model "M_tiket" initialized
INFO - 2020-03-06 14:17:02 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 14:17:02 --> Model "M_pesan" initialized
INFO - 2020-03-06 14:17:02 --> Helper loaded: form_helper
INFO - 2020-03-06 14:17:02 --> Form Validation Class Initialized
INFO - 2020-03-06 14:17:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 14:17:02 --> Final output sent to browser
DEBUG - 2020-03-06 14:17:02 --> Total execution time: 0.0184
INFO - 2020-03-06 14:17:55 --> Config Class Initialized
INFO - 2020-03-06 14:17:55 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:17:55 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:17:55 --> Utf8 Class Initialized
INFO - 2020-03-06 14:17:55 --> URI Class Initialized
DEBUG - 2020-03-06 14:17:55 --> No URI present. Default controller set.
INFO - 2020-03-06 14:17:55 --> Router Class Initialized
INFO - 2020-03-06 14:17:55 --> Output Class Initialized
INFO - 2020-03-06 14:17:55 --> Security Class Initialized
DEBUG - 2020-03-06 14:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:17:55 --> Input Class Initialized
INFO - 2020-03-06 14:17:55 --> Language Class Initialized
INFO - 2020-03-06 14:17:55 --> Loader Class Initialized
INFO - 2020-03-06 14:17:55 --> Helper loaded: url_helper
INFO - 2020-03-06 14:17:55 --> Helper loaded: string_helper
INFO - 2020-03-06 14:17:55 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:17:55 --> Controller Class Initialized
INFO - 2020-03-06 14:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 14:17:55 --> Pagination Class Initialized
INFO - 2020-03-06 14:17:55 --> Model "M_show" initialized
INFO - 2020-03-06 14:17:55 --> Helper loaded: form_helper
INFO - 2020-03-06 14:17:55 --> Form Validation Class Initialized
INFO - 2020-03-06 14:17:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 14:17:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 14:17:55 --> Final output sent to browser
DEBUG - 2020-03-06 14:17:55 --> Total execution time: 0.0227
INFO - 2020-03-06 14:39:25 --> Config Class Initialized
INFO - 2020-03-06 14:39:25 --> Hooks Class Initialized
DEBUG - 2020-03-06 14:39:25 --> UTF-8 Support Enabled
INFO - 2020-03-06 14:39:25 --> Utf8 Class Initialized
INFO - 2020-03-06 14:39:25 --> URI Class Initialized
DEBUG - 2020-03-06 14:39:25 --> No URI present. Default controller set.
INFO - 2020-03-06 14:39:25 --> Router Class Initialized
INFO - 2020-03-06 14:39:25 --> Output Class Initialized
INFO - 2020-03-06 14:39:25 --> Security Class Initialized
DEBUG - 2020-03-06 14:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 14:39:25 --> Input Class Initialized
INFO - 2020-03-06 14:39:25 --> Language Class Initialized
INFO - 2020-03-06 14:39:25 --> Loader Class Initialized
INFO - 2020-03-06 14:39:25 --> Helper loaded: url_helper
INFO - 2020-03-06 14:39:25 --> Helper loaded: string_helper
INFO - 2020-03-06 14:39:25 --> Database Driver Class Initialized
DEBUG - 2020-03-06 14:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 14:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 14:39:25 --> Controller Class Initialized
INFO - 2020-03-06 14:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 14:39:25 --> Pagination Class Initialized
INFO - 2020-03-06 14:39:25 --> Model "M_show" initialized
INFO - 2020-03-06 14:39:25 --> Helper loaded: form_helper
INFO - 2020-03-06 14:39:25 --> Form Validation Class Initialized
INFO - 2020-03-06 14:39:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 14:39:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 14:39:25 --> Final output sent to browser
DEBUG - 2020-03-06 14:39:25 --> Total execution time: 0.0644
INFO - 2020-03-06 15:16:04 --> Config Class Initialized
INFO - 2020-03-06 15:16:04 --> Hooks Class Initialized
DEBUG - 2020-03-06 15:16:04 --> UTF-8 Support Enabled
INFO - 2020-03-06 15:16:04 --> Utf8 Class Initialized
INFO - 2020-03-06 15:16:04 --> URI Class Initialized
DEBUG - 2020-03-06 15:16:04 --> No URI present. Default controller set.
INFO - 2020-03-06 15:16:04 --> Router Class Initialized
INFO - 2020-03-06 15:16:04 --> Output Class Initialized
INFO - 2020-03-06 15:16:04 --> Security Class Initialized
DEBUG - 2020-03-06 15:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 15:16:04 --> Input Class Initialized
INFO - 2020-03-06 15:16:04 --> Language Class Initialized
INFO - 2020-03-06 15:16:04 --> Loader Class Initialized
INFO - 2020-03-06 15:16:04 --> Helper loaded: url_helper
INFO - 2020-03-06 15:16:04 --> Helper loaded: string_helper
INFO - 2020-03-06 15:16:04 --> Database Driver Class Initialized
DEBUG - 2020-03-06 15:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 15:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 15:16:04 --> Controller Class Initialized
INFO - 2020-03-06 15:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 15:16:04 --> Pagination Class Initialized
INFO - 2020-03-06 15:16:04 --> Model "M_show" initialized
INFO - 2020-03-06 15:16:04 --> Helper loaded: form_helper
INFO - 2020-03-06 15:16:04 --> Form Validation Class Initialized
INFO - 2020-03-06 15:16:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 15:16:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 15:16:04 --> Final output sent to browser
DEBUG - 2020-03-06 15:16:04 --> Total execution time: 0.0796
INFO - 2020-03-06 15:16:07 --> Config Class Initialized
INFO - 2020-03-06 15:16:07 --> Hooks Class Initialized
DEBUG - 2020-03-06 15:16:07 --> UTF-8 Support Enabled
INFO - 2020-03-06 15:16:07 --> Utf8 Class Initialized
INFO - 2020-03-06 15:16:07 --> URI Class Initialized
DEBUG - 2020-03-06 15:16:07 --> No URI present. Default controller set.
INFO - 2020-03-06 15:16:07 --> Router Class Initialized
INFO - 2020-03-06 15:16:07 --> Output Class Initialized
INFO - 2020-03-06 15:16:07 --> Security Class Initialized
DEBUG - 2020-03-06 15:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 15:16:07 --> Input Class Initialized
INFO - 2020-03-06 15:16:07 --> Language Class Initialized
INFO - 2020-03-06 15:16:07 --> Loader Class Initialized
INFO - 2020-03-06 15:16:07 --> Helper loaded: url_helper
INFO - 2020-03-06 15:16:07 --> Helper loaded: string_helper
INFO - 2020-03-06 15:16:07 --> Database Driver Class Initialized
DEBUG - 2020-03-06 15:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 15:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 15:16:07 --> Controller Class Initialized
INFO - 2020-03-06 15:16:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 15:16:07 --> Pagination Class Initialized
INFO - 2020-03-06 15:16:07 --> Model "M_show" initialized
INFO - 2020-03-06 15:16:07 --> Helper loaded: form_helper
INFO - 2020-03-06 15:16:07 --> Form Validation Class Initialized
INFO - 2020-03-06 15:16:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 15:16:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 15:16:07 --> Final output sent to browser
DEBUG - 2020-03-06 15:16:07 --> Total execution time: 0.0059
INFO - 2020-03-06 15:16:12 --> Config Class Initialized
INFO - 2020-03-06 15:16:12 --> Hooks Class Initialized
DEBUG - 2020-03-06 15:16:12 --> UTF-8 Support Enabled
INFO - 2020-03-06 15:16:12 --> Utf8 Class Initialized
INFO - 2020-03-06 15:16:12 --> URI Class Initialized
INFO - 2020-03-06 15:16:12 --> Router Class Initialized
INFO - 2020-03-06 15:16:12 --> Output Class Initialized
INFO - 2020-03-06 15:16:12 --> Security Class Initialized
DEBUG - 2020-03-06 15:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 15:16:12 --> Input Class Initialized
INFO - 2020-03-06 15:16:12 --> Language Class Initialized
INFO - 2020-03-06 15:16:12 --> Loader Class Initialized
INFO - 2020-03-06 15:16:12 --> Helper loaded: url_helper
INFO - 2020-03-06 15:16:12 --> Helper loaded: string_helper
INFO - 2020-03-06 15:16:12 --> Database Driver Class Initialized
DEBUG - 2020-03-06 15:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 15:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 15:16:12 --> Controller Class Initialized
INFO - 2020-03-06 15:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 15:16:12 --> Pagination Class Initialized
INFO - 2020-03-06 15:16:12 --> Model "M_show" initialized
INFO - 2020-03-06 15:16:12 --> Helper loaded: form_helper
INFO - 2020-03-06 15:16:12 --> Form Validation Class Initialized
INFO - 2020-03-06 15:16:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 15:16:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 15:16:12 --> Final output sent to browser
DEBUG - 2020-03-06 15:16:12 --> Total execution time: 0.0085
INFO - 2020-03-06 15:16:19 --> Config Class Initialized
INFO - 2020-03-06 15:16:19 --> Hooks Class Initialized
DEBUG - 2020-03-06 15:16:19 --> UTF-8 Support Enabled
INFO - 2020-03-06 15:16:19 --> Utf8 Class Initialized
INFO - 2020-03-06 15:16:19 --> URI Class Initialized
INFO - 2020-03-06 15:16:19 --> Router Class Initialized
INFO - 2020-03-06 15:16:20 --> Output Class Initialized
INFO - 2020-03-06 15:16:20 --> Security Class Initialized
DEBUG - 2020-03-06 15:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 15:16:20 --> Input Class Initialized
INFO - 2020-03-06 15:16:20 --> Language Class Initialized
INFO - 2020-03-06 15:16:20 --> Loader Class Initialized
INFO - 2020-03-06 15:16:20 --> Helper loaded: url_helper
INFO - 2020-03-06 15:16:20 --> Helper loaded: string_helper
INFO - 2020-03-06 15:16:20 --> Database Driver Class Initialized
DEBUG - 2020-03-06 15:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 15:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 15:16:20 --> Controller Class Initialized
INFO - 2020-03-06 15:16:20 --> Model "M_tiket" initialized
INFO - 2020-03-06 15:16:20 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 15:16:20 --> Model "M_pesan" initialized
INFO - 2020-03-06 15:16:20 --> Helper loaded: form_helper
INFO - 2020-03-06 15:16:20 --> Form Validation Class Initialized
INFO - 2020-03-06 15:16:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 15:16:20 --> Final output sent to browser
DEBUG - 2020-03-06 15:16:20 --> Total execution time: 0.3179
INFO - 2020-03-06 15:18:38 --> Config Class Initialized
INFO - 2020-03-06 15:18:38 --> Hooks Class Initialized
DEBUG - 2020-03-06 15:18:38 --> UTF-8 Support Enabled
INFO - 2020-03-06 15:18:38 --> Utf8 Class Initialized
INFO - 2020-03-06 15:18:38 --> URI Class Initialized
INFO - 2020-03-06 15:18:38 --> Router Class Initialized
INFO - 2020-03-06 15:18:38 --> Output Class Initialized
INFO - 2020-03-06 15:18:38 --> Security Class Initialized
DEBUG - 2020-03-06 15:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 15:18:38 --> Input Class Initialized
INFO - 2020-03-06 15:18:38 --> Language Class Initialized
INFO - 2020-03-06 15:18:38 --> Loader Class Initialized
INFO - 2020-03-06 15:18:38 --> Helper loaded: url_helper
INFO - 2020-03-06 15:18:38 --> Helper loaded: string_helper
INFO - 2020-03-06 15:18:38 --> Database Driver Class Initialized
DEBUG - 2020-03-06 15:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 15:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 15:18:39 --> Controller Class Initialized
INFO - 2020-03-06 15:18:39 --> Model "M_tiket" initialized
INFO - 2020-03-06 15:18:39 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 15:18:39 --> Model "M_pesan" initialized
INFO - 2020-03-06 15:18:39 --> Helper loaded: form_helper
INFO - 2020-03-06 15:18:39 --> Form Validation Class Initialized
INFO - 2020-03-06 15:18:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 15:18:39 --> Final output sent to browser
DEBUG - 2020-03-06 15:18:39 --> Total execution time: 0.5929
INFO - 2020-03-06 15:18:48 --> Config Class Initialized
INFO - 2020-03-06 15:18:48 --> Hooks Class Initialized
DEBUG - 2020-03-06 15:18:48 --> UTF-8 Support Enabled
INFO - 2020-03-06 15:18:48 --> Utf8 Class Initialized
INFO - 2020-03-06 15:18:48 --> URI Class Initialized
INFO - 2020-03-06 15:18:48 --> Router Class Initialized
INFO - 2020-03-06 15:18:48 --> Output Class Initialized
INFO - 2020-03-06 15:18:48 --> Security Class Initialized
DEBUG - 2020-03-06 15:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 15:18:48 --> Input Class Initialized
INFO - 2020-03-06 15:18:48 --> Language Class Initialized
INFO - 2020-03-06 15:18:48 --> Loader Class Initialized
INFO - 2020-03-06 15:18:48 --> Helper loaded: url_helper
INFO - 2020-03-06 15:18:48 --> Helper loaded: string_helper
INFO - 2020-03-06 15:18:48 --> Database Driver Class Initialized
DEBUG - 2020-03-06 15:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 15:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 15:18:48 --> Controller Class Initialized
INFO - 2020-03-06 15:18:48 --> Model "M_tiket" initialized
INFO - 2020-03-06 15:18:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 15:18:48 --> Model "M_pesan" initialized
INFO - 2020-03-06 15:18:48 --> Helper loaded: form_helper
INFO - 2020-03-06 15:18:48 --> Form Validation Class Initialized
INFO - 2020-03-06 15:18:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 15:18:48 --> Final output sent to browser
DEBUG - 2020-03-06 15:18:48 --> Total execution time: 0.0087
INFO - 2020-03-06 15:19:02 --> Config Class Initialized
INFO - 2020-03-06 15:19:02 --> Hooks Class Initialized
DEBUG - 2020-03-06 15:19:02 --> UTF-8 Support Enabled
INFO - 2020-03-06 15:19:02 --> Utf8 Class Initialized
INFO - 2020-03-06 15:19:02 --> URI Class Initialized
INFO - 2020-03-06 15:19:02 --> Router Class Initialized
INFO - 2020-03-06 15:19:02 --> Output Class Initialized
INFO - 2020-03-06 15:19:02 --> Security Class Initialized
DEBUG - 2020-03-06 15:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 15:19:02 --> Input Class Initialized
INFO - 2020-03-06 15:19:02 --> Language Class Initialized
INFO - 2020-03-06 15:19:02 --> Loader Class Initialized
INFO - 2020-03-06 15:19:02 --> Helper loaded: url_helper
INFO - 2020-03-06 15:19:02 --> Helper loaded: string_helper
INFO - 2020-03-06 15:19:02 --> Database Driver Class Initialized
DEBUG - 2020-03-06 15:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 15:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 15:19:02 --> Controller Class Initialized
INFO - 2020-03-06 15:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 15:19:02 --> Pagination Class Initialized
INFO - 2020-03-06 15:19:02 --> Model "M_show" initialized
INFO - 2020-03-06 15:19:02 --> Helper loaded: form_helper
INFO - 2020-03-06 15:19:02 --> Form Validation Class Initialized
INFO - 2020-03-06 15:19:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 15:19:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 15:19:02 --> Final output sent to browser
DEBUG - 2020-03-06 15:19:02 --> Total execution time: 0.0463
INFO - 2020-03-06 15:27:45 --> Config Class Initialized
INFO - 2020-03-06 15:27:45 --> Hooks Class Initialized
DEBUG - 2020-03-06 15:27:45 --> UTF-8 Support Enabled
INFO - 2020-03-06 15:27:45 --> Utf8 Class Initialized
INFO - 2020-03-06 15:27:45 --> URI Class Initialized
INFO - 2020-03-06 15:27:45 --> Router Class Initialized
INFO - 2020-03-06 15:27:45 --> Output Class Initialized
INFO - 2020-03-06 15:27:45 --> Security Class Initialized
DEBUG - 2020-03-06 15:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 15:27:45 --> Input Class Initialized
INFO - 2020-03-06 15:27:45 --> Language Class Initialized
INFO - 2020-03-06 15:27:45 --> Loader Class Initialized
INFO - 2020-03-06 15:27:45 --> Helper loaded: url_helper
INFO - 2020-03-06 15:27:45 --> Helper loaded: string_helper
INFO - 2020-03-06 15:27:45 --> Database Driver Class Initialized
DEBUG - 2020-03-06 15:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 15:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 15:27:46 --> Controller Class Initialized
INFO - 2020-03-06 15:27:46 --> Model "M_tiket" initialized
INFO - 2020-03-06 15:27:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 15:27:46 --> Model "M_pesan" initialized
INFO - 2020-03-06 15:27:46 --> Helper loaded: form_helper
INFO - 2020-03-06 15:27:46 --> Form Validation Class Initialized
INFO - 2020-03-06 15:27:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 15:27:46 --> Final output sent to browser
DEBUG - 2020-03-06 15:27:46 --> Total execution time: 0.4263
INFO - 2020-03-06 16:48:33 --> Config Class Initialized
INFO - 2020-03-06 16:48:33 --> Hooks Class Initialized
DEBUG - 2020-03-06 16:48:33 --> UTF-8 Support Enabled
INFO - 2020-03-06 16:48:33 --> Utf8 Class Initialized
INFO - 2020-03-06 16:48:33 --> URI Class Initialized
DEBUG - 2020-03-06 16:48:33 --> No URI present. Default controller set.
INFO - 2020-03-06 16:48:33 --> Router Class Initialized
INFO - 2020-03-06 16:48:33 --> Output Class Initialized
INFO - 2020-03-06 16:48:33 --> Security Class Initialized
DEBUG - 2020-03-06 16:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 16:48:33 --> Input Class Initialized
INFO - 2020-03-06 16:48:33 --> Language Class Initialized
INFO - 2020-03-06 16:48:33 --> Loader Class Initialized
INFO - 2020-03-06 16:48:33 --> Helper loaded: url_helper
INFO - 2020-03-06 16:48:33 --> Helper loaded: string_helper
INFO - 2020-03-06 16:48:33 --> Database Driver Class Initialized
DEBUG - 2020-03-06 16:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 16:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 16:48:33 --> Controller Class Initialized
INFO - 2020-03-06 16:48:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 16:48:33 --> Pagination Class Initialized
INFO - 2020-03-06 16:48:33 --> Model "M_show" initialized
INFO - 2020-03-06 16:48:33 --> Helper loaded: form_helper
INFO - 2020-03-06 16:48:33 --> Form Validation Class Initialized
INFO - 2020-03-06 16:48:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 16:48:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 16:48:33 --> Final output sent to browser
DEBUG - 2020-03-06 16:48:33 --> Total execution time: 0.0319
INFO - 2020-03-06 18:49:41 --> Config Class Initialized
INFO - 2020-03-06 18:49:41 --> Hooks Class Initialized
DEBUG - 2020-03-06 18:49:41 --> UTF-8 Support Enabled
INFO - 2020-03-06 18:49:41 --> Utf8 Class Initialized
INFO - 2020-03-06 18:49:41 --> URI Class Initialized
DEBUG - 2020-03-06 18:49:41 --> No URI present. Default controller set.
INFO - 2020-03-06 18:49:41 --> Router Class Initialized
INFO - 2020-03-06 18:49:41 --> Output Class Initialized
INFO - 2020-03-06 18:49:41 --> Security Class Initialized
DEBUG - 2020-03-06 18:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 18:49:41 --> Input Class Initialized
INFO - 2020-03-06 18:49:41 --> Language Class Initialized
INFO - 2020-03-06 18:49:41 --> Loader Class Initialized
INFO - 2020-03-06 18:49:41 --> Helper loaded: url_helper
INFO - 2020-03-06 18:49:41 --> Helper loaded: string_helper
INFO - 2020-03-06 18:49:41 --> Database Driver Class Initialized
DEBUG - 2020-03-06 18:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 18:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 18:49:41 --> Controller Class Initialized
INFO - 2020-03-06 18:49:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 18:49:41 --> Pagination Class Initialized
INFO - 2020-03-06 18:49:41 --> Model "M_show" initialized
INFO - 2020-03-06 18:49:41 --> Helper loaded: form_helper
INFO - 2020-03-06 18:49:41 --> Form Validation Class Initialized
INFO - 2020-03-06 18:49:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 18:49:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 18:49:41 --> Final output sent to browser
DEBUG - 2020-03-06 18:49:41 --> Total execution time: 0.0953
INFO - 2020-03-06 18:49:54 --> Config Class Initialized
INFO - 2020-03-06 18:49:54 --> Hooks Class Initialized
DEBUG - 2020-03-06 18:49:54 --> UTF-8 Support Enabled
INFO - 2020-03-06 18:49:54 --> Utf8 Class Initialized
INFO - 2020-03-06 18:49:54 --> URI Class Initialized
INFO - 2020-03-06 18:49:54 --> Router Class Initialized
INFO - 2020-03-06 18:49:54 --> Output Class Initialized
INFO - 2020-03-06 18:49:54 --> Security Class Initialized
DEBUG - 2020-03-06 18:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 18:49:54 --> Input Class Initialized
INFO - 2020-03-06 18:49:54 --> Language Class Initialized
INFO - 2020-03-06 18:49:54 --> Loader Class Initialized
INFO - 2020-03-06 18:49:54 --> Helper loaded: url_helper
INFO - 2020-03-06 18:49:54 --> Helper loaded: string_helper
INFO - 2020-03-06 18:49:54 --> Database Driver Class Initialized
DEBUG - 2020-03-06 18:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 18:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 18:49:54 --> Controller Class Initialized
INFO - 2020-03-06 18:49:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 18:49:54 --> Pagination Class Initialized
INFO - 2020-03-06 18:49:54 --> Model "M_show" initialized
INFO - 2020-03-06 18:49:54 --> Helper loaded: form_helper
INFO - 2020-03-06 18:49:54 --> Form Validation Class Initialized
INFO - 2020-03-06 18:49:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 18:49:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 18:49:54 --> Final output sent to browser
DEBUG - 2020-03-06 18:49:54 --> Total execution time: 0.0394
INFO - 2020-03-06 18:49:59 --> Config Class Initialized
INFO - 2020-03-06 18:49:59 --> Hooks Class Initialized
DEBUG - 2020-03-06 18:49:59 --> UTF-8 Support Enabled
INFO - 2020-03-06 18:49:59 --> Utf8 Class Initialized
INFO - 2020-03-06 18:49:59 --> URI Class Initialized
INFO - 2020-03-06 18:49:59 --> Router Class Initialized
INFO - 2020-03-06 18:49:59 --> Output Class Initialized
INFO - 2020-03-06 18:49:59 --> Security Class Initialized
DEBUG - 2020-03-06 18:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 18:49:59 --> Input Class Initialized
INFO - 2020-03-06 18:49:59 --> Language Class Initialized
INFO - 2020-03-06 18:49:59 --> Loader Class Initialized
INFO - 2020-03-06 18:49:59 --> Helper loaded: url_helper
INFO - 2020-03-06 18:49:59 --> Helper loaded: string_helper
INFO - 2020-03-06 18:49:59 --> Database Driver Class Initialized
DEBUG - 2020-03-06 18:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 18:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 18:49:59 --> Controller Class Initialized
INFO - 2020-03-06 18:49:59 --> Model "M_tiket" initialized
INFO - 2020-03-06 18:49:59 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 18:49:59 --> Model "M_pesan" initialized
INFO - 2020-03-06 18:49:59 --> Helper loaded: form_helper
INFO - 2020-03-06 18:49:59 --> Form Validation Class Initialized
INFO - 2020-03-06 18:49:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 18:49:59 --> Final output sent to browser
DEBUG - 2020-03-06 18:49:59 --> Total execution time: 0.0407
INFO - 2020-03-06 18:50:20 --> Config Class Initialized
INFO - 2020-03-06 18:50:20 --> Hooks Class Initialized
DEBUG - 2020-03-06 18:50:20 --> UTF-8 Support Enabled
INFO - 2020-03-06 18:50:20 --> Utf8 Class Initialized
INFO - 2020-03-06 18:50:20 --> URI Class Initialized
DEBUG - 2020-03-06 18:50:20 --> No URI present. Default controller set.
INFO - 2020-03-06 18:50:20 --> Router Class Initialized
INFO - 2020-03-06 18:50:20 --> Output Class Initialized
INFO - 2020-03-06 18:50:20 --> Security Class Initialized
DEBUG - 2020-03-06 18:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 18:50:20 --> Input Class Initialized
INFO - 2020-03-06 18:50:20 --> Language Class Initialized
INFO - 2020-03-06 18:50:20 --> Loader Class Initialized
INFO - 2020-03-06 18:50:20 --> Helper loaded: url_helper
INFO - 2020-03-06 18:50:20 --> Helper loaded: string_helper
INFO - 2020-03-06 18:50:20 --> Database Driver Class Initialized
DEBUG - 2020-03-06 18:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 18:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 18:50:20 --> Controller Class Initialized
INFO - 2020-03-06 18:50:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 18:50:20 --> Pagination Class Initialized
INFO - 2020-03-06 18:50:20 --> Model "M_show" initialized
INFO - 2020-03-06 18:50:20 --> Helper loaded: form_helper
INFO - 2020-03-06 18:50:20 --> Form Validation Class Initialized
INFO - 2020-03-06 18:50:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 18:50:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 18:50:20 --> Final output sent to browser
DEBUG - 2020-03-06 18:50:20 --> Total execution time: 0.0143
INFO - 2020-03-06 20:44:39 --> Config Class Initialized
INFO - 2020-03-06 20:44:39 --> Hooks Class Initialized
DEBUG - 2020-03-06 20:44:39 --> UTF-8 Support Enabled
INFO - 2020-03-06 20:44:39 --> Utf8 Class Initialized
INFO - 2020-03-06 20:44:39 --> URI Class Initialized
INFO - 2020-03-06 20:44:39 --> Router Class Initialized
INFO - 2020-03-06 20:44:39 --> Output Class Initialized
INFO - 2020-03-06 20:44:39 --> Security Class Initialized
DEBUG - 2020-03-06 20:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 20:44:39 --> Input Class Initialized
INFO - 2020-03-06 20:44:39 --> Language Class Initialized
INFO - 2020-03-06 20:44:39 --> Loader Class Initialized
INFO - 2020-03-06 20:44:39 --> Helper loaded: url_helper
INFO - 2020-03-06 20:44:39 --> Helper loaded: string_helper
INFO - 2020-03-06 20:44:39 --> Database Driver Class Initialized
DEBUG - 2020-03-06 20:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 20:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 20:44:39 --> Controller Class Initialized
INFO - 2020-03-06 20:44:39 --> Model "M_tiket" initialized
INFO - 2020-03-06 20:44:39 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 20:44:39 --> Model "M_pesan" initialized
INFO - 2020-03-06 20:44:39 --> Helper loaded: form_helper
INFO - 2020-03-06 20:44:39 --> Form Validation Class Initialized
INFO - 2020-03-06 20:44:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 20:44:39 --> Final output sent to browser
DEBUG - 2020-03-06 20:44:39 --> Total execution time: 0.0903
INFO - 2020-03-06 20:52:05 --> Config Class Initialized
INFO - 2020-03-06 20:52:05 --> Hooks Class Initialized
DEBUG - 2020-03-06 20:52:05 --> UTF-8 Support Enabled
INFO - 2020-03-06 20:52:05 --> Utf8 Class Initialized
INFO - 2020-03-06 20:52:05 --> URI Class Initialized
INFO - 2020-03-06 20:52:05 --> Router Class Initialized
INFO - 2020-03-06 20:52:05 --> Output Class Initialized
INFO - 2020-03-06 20:52:05 --> Security Class Initialized
DEBUG - 2020-03-06 20:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 20:52:05 --> Input Class Initialized
INFO - 2020-03-06 20:52:05 --> Language Class Initialized
INFO - 2020-03-06 20:52:05 --> Loader Class Initialized
INFO - 2020-03-06 20:52:05 --> Helper loaded: url_helper
INFO - 2020-03-06 20:52:05 --> Helper loaded: string_helper
INFO - 2020-03-06 20:52:05 --> Database Driver Class Initialized
DEBUG - 2020-03-06 20:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 20:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 20:52:05 --> Controller Class Initialized
INFO - 2020-03-06 20:52:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 20:52:05 --> Pagination Class Initialized
INFO - 2020-03-06 20:52:05 --> Model "M_show" initialized
INFO - 2020-03-06 20:52:05 --> Helper loaded: form_helper
INFO - 2020-03-06 20:52:05 --> Form Validation Class Initialized
INFO - 2020-03-06 20:52:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 20:52:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 20:52:05 --> Final output sent to browser
DEBUG - 2020-03-06 20:52:05 --> Total execution time: 0.0494
INFO - 2020-03-06 20:52:05 --> Config Class Initialized
INFO - 2020-03-06 20:52:05 --> Hooks Class Initialized
DEBUG - 2020-03-06 20:52:05 --> UTF-8 Support Enabled
INFO - 2020-03-06 20:52:05 --> Utf8 Class Initialized
INFO - 2020-03-06 20:52:05 --> URI Class Initialized
INFO - 2020-03-06 20:52:05 --> Router Class Initialized
INFO - 2020-03-06 20:52:05 --> Output Class Initialized
INFO - 2020-03-06 20:52:05 --> Security Class Initialized
DEBUG - 2020-03-06 20:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 20:52:05 --> Input Class Initialized
INFO - 2020-03-06 20:52:05 --> Language Class Initialized
INFO - 2020-03-06 20:52:05 --> Loader Class Initialized
INFO - 2020-03-06 20:52:05 --> Helper loaded: url_helper
INFO - 2020-03-06 20:52:05 --> Helper loaded: string_helper
INFO - 2020-03-06 20:52:05 --> Database Driver Class Initialized
DEBUG - 2020-03-06 20:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 20:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 20:52:05 --> Controller Class Initialized
INFO - 2020-03-06 20:52:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 20:52:05 --> Pagination Class Initialized
INFO - 2020-03-06 20:52:05 --> Model "M_show" initialized
INFO - 2020-03-06 20:52:05 --> Helper loaded: form_helper
INFO - 2020-03-06 20:52:05 --> Form Validation Class Initialized
INFO - 2020-03-06 20:52:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 20:52:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 20:52:05 --> Final output sent to browser
DEBUG - 2020-03-06 20:52:05 --> Total execution time: 0.0040
INFO - 2020-03-06 21:15:11 --> Config Class Initialized
INFO - 2020-03-06 21:15:11 --> Hooks Class Initialized
DEBUG - 2020-03-06 21:15:11 --> UTF-8 Support Enabled
INFO - 2020-03-06 21:15:11 --> Utf8 Class Initialized
INFO - 2020-03-06 21:15:11 --> URI Class Initialized
DEBUG - 2020-03-06 21:15:11 --> No URI present. Default controller set.
INFO - 2020-03-06 21:15:11 --> Router Class Initialized
INFO - 2020-03-06 21:15:11 --> Output Class Initialized
INFO - 2020-03-06 21:15:11 --> Security Class Initialized
DEBUG - 2020-03-06 21:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 21:15:11 --> Input Class Initialized
INFO - 2020-03-06 21:15:11 --> Language Class Initialized
INFO - 2020-03-06 21:15:11 --> Loader Class Initialized
INFO - 2020-03-06 21:15:11 --> Helper loaded: url_helper
INFO - 2020-03-06 21:15:11 --> Helper loaded: string_helper
INFO - 2020-03-06 21:15:11 --> Database Driver Class Initialized
DEBUG - 2020-03-06 21:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 21:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 21:15:11 --> Controller Class Initialized
INFO - 2020-03-06 21:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 21:15:11 --> Pagination Class Initialized
INFO - 2020-03-06 21:15:11 --> Model "M_show" initialized
INFO - 2020-03-06 21:15:11 --> Helper loaded: form_helper
INFO - 2020-03-06 21:15:11 --> Form Validation Class Initialized
INFO - 2020-03-06 21:15:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 21:15:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 21:15:11 --> Final output sent to browser
DEBUG - 2020-03-06 21:15:11 --> Total execution time: 0.0313
INFO - 2020-03-06 22:12:43 --> Config Class Initialized
INFO - 2020-03-06 22:12:43 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:12:43 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:12:43 --> Utf8 Class Initialized
INFO - 2020-03-06 22:12:43 --> URI Class Initialized
DEBUG - 2020-03-06 22:12:43 --> No URI present. Default controller set.
INFO - 2020-03-06 22:12:43 --> Router Class Initialized
INFO - 2020-03-06 22:12:43 --> Output Class Initialized
INFO - 2020-03-06 22:12:43 --> Security Class Initialized
DEBUG - 2020-03-06 22:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:12:43 --> Input Class Initialized
INFO - 2020-03-06 22:12:43 --> Language Class Initialized
INFO - 2020-03-06 22:12:43 --> Loader Class Initialized
INFO - 2020-03-06 22:12:43 --> Helper loaded: url_helper
INFO - 2020-03-06 22:12:43 --> Helper loaded: string_helper
INFO - 2020-03-06 22:12:43 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:12:43 --> Controller Class Initialized
INFO - 2020-03-06 22:12:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:12:43 --> Pagination Class Initialized
INFO - 2020-03-06 22:12:43 --> Model "M_show" initialized
INFO - 2020-03-06 22:12:43 --> Helper loaded: form_helper
INFO - 2020-03-06 22:12:43 --> Form Validation Class Initialized
INFO - 2020-03-06 22:12:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:12:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 22:12:43 --> Final output sent to browser
DEBUG - 2020-03-06 22:12:43 --> Total execution time: 0.0394
INFO - 2020-03-06 22:12:48 --> Config Class Initialized
INFO - 2020-03-06 22:12:48 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:12:48 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:12:48 --> Utf8 Class Initialized
INFO - 2020-03-06 22:12:48 --> URI Class Initialized
INFO - 2020-03-06 22:12:48 --> Router Class Initialized
INFO - 2020-03-06 22:12:48 --> Output Class Initialized
INFO - 2020-03-06 22:12:48 --> Security Class Initialized
DEBUG - 2020-03-06 22:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:12:48 --> Input Class Initialized
INFO - 2020-03-06 22:12:48 --> Language Class Initialized
INFO - 2020-03-06 22:12:48 --> Loader Class Initialized
INFO - 2020-03-06 22:12:48 --> Helper loaded: url_helper
INFO - 2020-03-06 22:12:48 --> Helper loaded: string_helper
INFO - 2020-03-06 22:12:48 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:12:48 --> Controller Class Initialized
INFO - 2020-03-06 22:12:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:12:48 --> Pagination Class Initialized
INFO - 2020-03-06 22:12:48 --> Model "M_show" initialized
INFO - 2020-03-06 22:12:48 --> Helper loaded: form_helper
INFO - 2020-03-06 22:12:48 --> Form Validation Class Initialized
INFO - 2020-03-06 22:12:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:12:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 22:12:48 --> Final output sent to browser
DEBUG - 2020-03-06 22:12:48 --> Total execution time: 0.0079
INFO - 2020-03-06 22:12:54 --> Config Class Initialized
INFO - 2020-03-06 22:12:54 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:12:54 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:12:54 --> Utf8 Class Initialized
INFO - 2020-03-06 22:12:54 --> URI Class Initialized
INFO - 2020-03-06 22:12:54 --> Router Class Initialized
INFO - 2020-03-06 22:12:54 --> Output Class Initialized
INFO - 2020-03-06 22:12:54 --> Security Class Initialized
DEBUG - 2020-03-06 22:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:12:54 --> Input Class Initialized
INFO - 2020-03-06 22:12:54 --> Language Class Initialized
INFO - 2020-03-06 22:12:54 --> Loader Class Initialized
INFO - 2020-03-06 22:12:54 --> Helper loaded: url_helper
INFO - 2020-03-06 22:12:54 --> Helper loaded: string_helper
INFO - 2020-03-06 22:12:54 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:12:54 --> Controller Class Initialized
INFO - 2020-03-06 22:12:54 --> Model "M_tiket" initialized
INFO - 2020-03-06 22:12:54 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 22:12:54 --> Model "M_pesan" initialized
INFO - 2020-03-06 22:12:54 --> Helper loaded: form_helper
INFO - 2020-03-06 22:12:54 --> Form Validation Class Initialized
INFO - 2020-03-06 22:12:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 22:12:54 --> Final output sent to browser
DEBUG - 2020-03-06 22:12:54 --> Total execution time: 0.0101
INFO - 2020-03-06 22:13:13 --> Config Class Initialized
INFO - 2020-03-06 22:13:13 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:13:13 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:13:13 --> Utf8 Class Initialized
INFO - 2020-03-06 22:13:13 --> URI Class Initialized
INFO - 2020-03-06 22:13:13 --> Router Class Initialized
INFO - 2020-03-06 22:13:13 --> Output Class Initialized
INFO - 2020-03-06 22:13:13 --> Security Class Initialized
DEBUG - 2020-03-06 22:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:13:13 --> Input Class Initialized
INFO - 2020-03-06 22:13:13 --> Language Class Initialized
INFO - 2020-03-06 22:13:13 --> Loader Class Initialized
INFO - 2020-03-06 22:13:13 --> Helper loaded: url_helper
INFO - 2020-03-06 22:13:13 --> Helper loaded: string_helper
INFO - 2020-03-06 22:13:13 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:13:13 --> Controller Class Initialized
INFO - 2020-03-06 22:13:13 --> Model "M_tiket" initialized
INFO - 2020-03-06 22:13:13 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 22:13:13 --> Model "M_pesan" initialized
INFO - 2020-03-06 22:13:13 --> Helper loaded: form_helper
INFO - 2020-03-06 22:13:13 --> Form Validation Class Initialized
INFO - 2020-03-06 22:13:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 22:13:13 --> Final output sent to browser
DEBUG - 2020-03-06 22:13:13 --> Total execution time: 0.0081
INFO - 2020-03-06 22:13:14 --> Config Class Initialized
INFO - 2020-03-06 22:13:14 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:13:14 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:13:14 --> Utf8 Class Initialized
INFO - 2020-03-06 22:13:14 --> URI Class Initialized
INFO - 2020-03-06 22:13:14 --> Router Class Initialized
INFO - 2020-03-06 22:13:14 --> Output Class Initialized
INFO - 2020-03-06 22:13:14 --> Security Class Initialized
DEBUG - 2020-03-06 22:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:13:14 --> Input Class Initialized
INFO - 2020-03-06 22:13:14 --> Language Class Initialized
INFO - 2020-03-06 22:13:14 --> Loader Class Initialized
INFO - 2020-03-06 22:13:14 --> Helper loaded: url_helper
INFO - 2020-03-06 22:13:14 --> Helper loaded: string_helper
INFO - 2020-03-06 22:13:14 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:13:14 --> Controller Class Initialized
INFO - 2020-03-06 22:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:13:14 --> Pagination Class Initialized
INFO - 2020-03-06 22:13:14 --> Model "M_show" initialized
INFO - 2020-03-06 22:13:14 --> Helper loaded: form_helper
INFO - 2020-03-06 22:13:14 --> Form Validation Class Initialized
INFO - 2020-03-06 22:13:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:13:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 22:13:14 --> Final output sent to browser
DEBUG - 2020-03-06 22:13:14 --> Total execution time: 0.0087
INFO - 2020-03-06 22:13:16 --> Config Class Initialized
INFO - 2020-03-06 22:13:16 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:13:16 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:13:16 --> Utf8 Class Initialized
INFO - 2020-03-06 22:13:16 --> URI Class Initialized
INFO - 2020-03-06 22:13:16 --> Router Class Initialized
INFO - 2020-03-06 22:13:16 --> Output Class Initialized
INFO - 2020-03-06 22:13:16 --> Security Class Initialized
DEBUG - 2020-03-06 22:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:13:16 --> Input Class Initialized
INFO - 2020-03-06 22:13:16 --> Language Class Initialized
INFO - 2020-03-06 22:13:16 --> Loader Class Initialized
INFO - 2020-03-06 22:13:16 --> Helper loaded: url_helper
INFO - 2020-03-06 22:13:16 --> Helper loaded: string_helper
INFO - 2020-03-06 22:13:16 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:13:16 --> Controller Class Initialized
INFO - 2020-03-06 22:13:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:13:16 --> Pagination Class Initialized
INFO - 2020-03-06 22:13:16 --> Model "M_show" initialized
INFO - 2020-03-06 22:13:16 --> Helper loaded: form_helper
INFO - 2020-03-06 22:13:16 --> Form Validation Class Initialized
INFO - 2020-03-06 22:13:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:13:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 22:13:16 --> Final output sent to browser
DEBUG - 2020-03-06 22:13:16 --> Total execution time: 0.0216
INFO - 2020-03-06 22:13:25 --> Config Class Initialized
INFO - 2020-03-06 22:13:25 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:13:25 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:13:25 --> Utf8 Class Initialized
INFO - 2020-03-06 22:13:25 --> URI Class Initialized
INFO - 2020-03-06 22:13:25 --> Router Class Initialized
INFO - 2020-03-06 22:13:25 --> Output Class Initialized
INFO - 2020-03-06 22:13:25 --> Security Class Initialized
DEBUG - 2020-03-06 22:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:13:25 --> Input Class Initialized
INFO - 2020-03-06 22:13:25 --> Language Class Initialized
INFO - 2020-03-06 22:13:25 --> Loader Class Initialized
INFO - 2020-03-06 22:13:25 --> Helper loaded: url_helper
INFO - 2020-03-06 22:13:25 --> Helper loaded: string_helper
INFO - 2020-03-06 22:13:25 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:13:25 --> Controller Class Initialized
INFO - 2020-03-06 22:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:13:25 --> Pagination Class Initialized
INFO - 2020-03-06 22:13:25 --> Model "M_show" initialized
INFO - 2020-03-06 22:13:25 --> Helper loaded: form_helper
INFO - 2020-03-06 22:13:25 --> Form Validation Class Initialized
INFO - 2020-03-06 22:13:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:13:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 22:13:25 --> Final output sent to browser
DEBUG - 2020-03-06 22:13:25 --> Total execution time: 0.0070
INFO - 2020-03-06 22:13:28 --> Config Class Initialized
INFO - 2020-03-06 22:13:28 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:13:28 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:13:28 --> Utf8 Class Initialized
INFO - 2020-03-06 22:13:28 --> URI Class Initialized
INFO - 2020-03-06 22:13:28 --> Router Class Initialized
INFO - 2020-03-06 22:13:28 --> Output Class Initialized
INFO - 2020-03-06 22:13:28 --> Security Class Initialized
DEBUG - 2020-03-06 22:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:13:28 --> Input Class Initialized
INFO - 2020-03-06 22:13:28 --> Language Class Initialized
INFO - 2020-03-06 22:13:28 --> Loader Class Initialized
INFO - 2020-03-06 22:13:28 --> Helper loaded: url_helper
INFO - 2020-03-06 22:13:28 --> Helper loaded: string_helper
INFO - 2020-03-06 22:13:28 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:13:28 --> Controller Class Initialized
INFO - 2020-03-06 22:13:28 --> Model "M_tiket" initialized
INFO - 2020-03-06 22:13:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 22:13:28 --> Model "M_pesan" initialized
INFO - 2020-03-06 22:13:28 --> Helper loaded: form_helper
INFO - 2020-03-06 22:13:28 --> Form Validation Class Initialized
INFO - 2020-03-06 22:13:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 22:13:28 --> Final output sent to browser
DEBUG - 2020-03-06 22:13:28 --> Total execution time: 0.0069
INFO - 2020-03-06 22:39:15 --> Config Class Initialized
INFO - 2020-03-06 22:39:15 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:39:15 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:39:15 --> Utf8 Class Initialized
INFO - 2020-03-06 22:39:15 --> URI Class Initialized
DEBUG - 2020-03-06 22:39:15 --> No URI present. Default controller set.
INFO - 2020-03-06 22:39:15 --> Router Class Initialized
INFO - 2020-03-06 22:39:15 --> Output Class Initialized
INFO - 2020-03-06 22:39:15 --> Security Class Initialized
DEBUG - 2020-03-06 22:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:39:15 --> Input Class Initialized
INFO - 2020-03-06 22:39:15 --> Language Class Initialized
INFO - 2020-03-06 22:39:15 --> Loader Class Initialized
INFO - 2020-03-06 22:39:15 --> Helper loaded: url_helper
INFO - 2020-03-06 22:39:15 --> Helper loaded: string_helper
INFO - 2020-03-06 22:39:15 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:39:15 --> Controller Class Initialized
INFO - 2020-03-06 22:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:39:15 --> Pagination Class Initialized
INFO - 2020-03-06 22:39:15 --> Model "M_show" initialized
INFO - 2020-03-06 22:39:15 --> Helper loaded: form_helper
INFO - 2020-03-06 22:39:15 --> Form Validation Class Initialized
INFO - 2020-03-06 22:39:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:39:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 22:39:15 --> Final output sent to browser
DEBUG - 2020-03-06 22:39:15 --> Total execution time: 0.0581
INFO - 2020-03-06 22:39:31 --> Config Class Initialized
INFO - 2020-03-06 22:39:31 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:39:31 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:39:31 --> Utf8 Class Initialized
INFO - 2020-03-06 22:39:31 --> URI Class Initialized
INFO - 2020-03-06 22:39:31 --> Router Class Initialized
INFO - 2020-03-06 22:39:31 --> Output Class Initialized
INFO - 2020-03-06 22:39:31 --> Security Class Initialized
DEBUG - 2020-03-06 22:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:39:31 --> Input Class Initialized
INFO - 2020-03-06 22:39:31 --> Language Class Initialized
INFO - 2020-03-06 22:39:31 --> Loader Class Initialized
INFO - 2020-03-06 22:39:31 --> Helper loaded: url_helper
INFO - 2020-03-06 22:39:31 --> Helper loaded: string_helper
INFO - 2020-03-06 22:39:31 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:39:31 --> Controller Class Initialized
INFO - 2020-03-06 22:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:39:31 --> Pagination Class Initialized
INFO - 2020-03-06 22:39:31 --> Model "M_show" initialized
INFO - 2020-03-06 22:39:31 --> Helper loaded: form_helper
INFO - 2020-03-06 22:39:31 --> Form Validation Class Initialized
INFO - 2020-03-06 22:39:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:39:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 22:39:31 --> Final output sent to browser
DEBUG - 2020-03-06 22:39:31 --> Total execution time: 0.0063
INFO - 2020-03-06 22:39:59 --> Config Class Initialized
INFO - 2020-03-06 22:39:59 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:39:59 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:39:59 --> Utf8 Class Initialized
INFO - 2020-03-06 22:39:59 --> URI Class Initialized
INFO - 2020-03-06 22:39:59 --> Router Class Initialized
INFO - 2020-03-06 22:39:59 --> Output Class Initialized
INFO - 2020-03-06 22:39:59 --> Security Class Initialized
DEBUG - 2020-03-06 22:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:39:59 --> Input Class Initialized
INFO - 2020-03-06 22:39:59 --> Language Class Initialized
INFO - 2020-03-06 22:39:59 --> Loader Class Initialized
INFO - 2020-03-06 22:39:59 --> Helper loaded: url_helper
INFO - 2020-03-06 22:39:59 --> Helper loaded: string_helper
INFO - 2020-03-06 22:39:59 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:39:59 --> Controller Class Initialized
INFO - 2020-03-06 22:39:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:39:59 --> Pagination Class Initialized
INFO - 2020-03-06 22:39:59 --> Model "M_show" initialized
INFO - 2020-03-06 22:39:59 --> Helper loaded: form_helper
INFO - 2020-03-06 22:39:59 --> Form Validation Class Initialized
INFO - 2020-03-06 22:39:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:39:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 22:39:59 --> Final output sent to browser
DEBUG - 2020-03-06 22:39:59 --> Total execution time: 0.0140
INFO - 2020-03-06 22:40:15 --> Config Class Initialized
INFO - 2020-03-06 22:40:15 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:40:15 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:40:15 --> Utf8 Class Initialized
INFO - 2020-03-06 22:40:15 --> URI Class Initialized
INFO - 2020-03-06 22:40:15 --> Router Class Initialized
INFO - 2020-03-06 22:40:15 --> Output Class Initialized
INFO - 2020-03-06 22:40:15 --> Security Class Initialized
DEBUG - 2020-03-06 22:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:40:15 --> Input Class Initialized
INFO - 2020-03-06 22:40:15 --> Language Class Initialized
INFO - 2020-03-06 22:40:15 --> Loader Class Initialized
INFO - 2020-03-06 22:40:15 --> Helper loaded: url_helper
INFO - 2020-03-06 22:40:15 --> Helper loaded: string_helper
INFO - 2020-03-06 22:40:15 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:40:15 --> Controller Class Initialized
INFO - 2020-03-06 22:40:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:40:15 --> Pagination Class Initialized
INFO - 2020-03-06 22:40:15 --> Model "M_show" initialized
INFO - 2020-03-06 22:40:15 --> Helper loaded: form_helper
INFO - 2020-03-06 22:40:15 --> Form Validation Class Initialized
INFO - 2020-03-06 22:40:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:40:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 22:40:15 --> Final output sent to browser
DEBUG - 2020-03-06 22:40:15 --> Total execution time: 0.0064
INFO - 2020-03-06 22:40:18 --> Config Class Initialized
INFO - 2020-03-06 22:40:18 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:40:18 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:40:18 --> Utf8 Class Initialized
INFO - 2020-03-06 22:40:18 --> URI Class Initialized
INFO - 2020-03-06 22:40:18 --> Router Class Initialized
INFO - 2020-03-06 22:40:18 --> Output Class Initialized
INFO - 2020-03-06 22:40:18 --> Security Class Initialized
DEBUG - 2020-03-06 22:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:40:18 --> Input Class Initialized
INFO - 2020-03-06 22:40:18 --> Language Class Initialized
INFO - 2020-03-06 22:40:18 --> Loader Class Initialized
INFO - 2020-03-06 22:40:18 --> Helper loaded: url_helper
INFO - 2020-03-06 22:40:18 --> Helper loaded: string_helper
INFO - 2020-03-06 22:40:18 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:40:18 --> Controller Class Initialized
INFO - 2020-03-06 22:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:40:18 --> Pagination Class Initialized
INFO - 2020-03-06 22:40:18 --> Model "M_show" initialized
INFO - 2020-03-06 22:40:18 --> Helper loaded: form_helper
INFO - 2020-03-06 22:40:18 --> Form Validation Class Initialized
INFO - 2020-03-06 22:40:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:40:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 22:40:18 --> Final output sent to browser
DEBUG - 2020-03-06 22:40:18 --> Total execution time: 0.0051
INFO - 2020-03-06 22:40:26 --> Config Class Initialized
INFO - 2020-03-06 22:40:26 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:40:26 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:40:26 --> Utf8 Class Initialized
INFO - 2020-03-06 22:40:26 --> URI Class Initialized
INFO - 2020-03-06 22:40:26 --> Router Class Initialized
INFO - 2020-03-06 22:40:26 --> Output Class Initialized
INFO - 2020-03-06 22:40:26 --> Security Class Initialized
DEBUG - 2020-03-06 22:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:40:26 --> Input Class Initialized
INFO - 2020-03-06 22:40:26 --> Language Class Initialized
INFO - 2020-03-06 22:40:26 --> Loader Class Initialized
INFO - 2020-03-06 22:40:26 --> Helper loaded: url_helper
INFO - 2020-03-06 22:40:26 --> Helper loaded: string_helper
INFO - 2020-03-06 22:40:26 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:40:26 --> Controller Class Initialized
INFO - 2020-03-06 22:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:40:26 --> Pagination Class Initialized
INFO - 2020-03-06 22:40:26 --> Model "M_show" initialized
INFO - 2020-03-06 22:40:26 --> Helper loaded: form_helper
INFO - 2020-03-06 22:40:26 --> Form Validation Class Initialized
INFO - 2020-03-06 22:40:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:40:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 22:40:26 --> Final output sent to browser
DEBUG - 2020-03-06 22:40:26 --> Total execution time: 0.0066
INFO - 2020-03-06 22:40:30 --> Config Class Initialized
INFO - 2020-03-06 22:40:30 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:40:30 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:40:30 --> Utf8 Class Initialized
INFO - 2020-03-06 22:40:30 --> URI Class Initialized
INFO - 2020-03-06 22:40:30 --> Router Class Initialized
INFO - 2020-03-06 22:40:30 --> Output Class Initialized
INFO - 2020-03-06 22:40:30 --> Security Class Initialized
DEBUG - 2020-03-06 22:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:40:30 --> Input Class Initialized
INFO - 2020-03-06 22:40:30 --> Language Class Initialized
INFO - 2020-03-06 22:40:30 --> Loader Class Initialized
INFO - 2020-03-06 22:40:30 --> Helper loaded: url_helper
INFO - 2020-03-06 22:40:30 --> Helper loaded: string_helper
INFO - 2020-03-06 22:40:30 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:40:30 --> Controller Class Initialized
INFO - 2020-03-06 22:40:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:40:30 --> Pagination Class Initialized
INFO - 2020-03-06 22:40:30 --> Model "M_show" initialized
INFO - 2020-03-06 22:40:30 --> Helper loaded: form_helper
INFO - 2020-03-06 22:40:30 --> Form Validation Class Initialized
INFO - 2020-03-06 22:40:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:40:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 22:40:30 --> Final output sent to browser
DEBUG - 2020-03-06 22:40:30 --> Total execution time: 0.0054
INFO - 2020-03-06 22:44:49 --> Config Class Initialized
INFO - 2020-03-06 22:44:49 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:44:49 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:44:49 --> Utf8 Class Initialized
INFO - 2020-03-06 22:44:49 --> URI Class Initialized
DEBUG - 2020-03-06 22:44:49 --> No URI present. Default controller set.
INFO - 2020-03-06 22:44:49 --> Router Class Initialized
INFO - 2020-03-06 22:44:49 --> Output Class Initialized
INFO - 2020-03-06 22:44:49 --> Security Class Initialized
DEBUG - 2020-03-06 22:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:44:49 --> Input Class Initialized
INFO - 2020-03-06 22:44:49 --> Language Class Initialized
INFO - 2020-03-06 22:44:49 --> Loader Class Initialized
INFO - 2020-03-06 22:44:49 --> Helper loaded: url_helper
INFO - 2020-03-06 22:44:49 --> Helper loaded: string_helper
INFO - 2020-03-06 22:44:49 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:44:49 --> Controller Class Initialized
INFO - 2020-03-06 22:44:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:44:49 --> Pagination Class Initialized
INFO - 2020-03-06 22:44:49 --> Model "M_show" initialized
INFO - 2020-03-06 22:44:49 --> Helper loaded: form_helper
INFO - 2020-03-06 22:44:49 --> Form Validation Class Initialized
INFO - 2020-03-06 22:44:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:44:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 22:44:49 --> Final output sent to browser
DEBUG - 2020-03-06 22:44:49 --> Total execution time: 0.0349
INFO - 2020-03-06 22:45:05 --> Config Class Initialized
INFO - 2020-03-06 22:45:05 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:45:05 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:45:05 --> Utf8 Class Initialized
INFO - 2020-03-06 22:45:05 --> URI Class Initialized
INFO - 2020-03-06 22:45:05 --> Router Class Initialized
INFO - 2020-03-06 22:45:05 --> Output Class Initialized
INFO - 2020-03-06 22:45:05 --> Security Class Initialized
DEBUG - 2020-03-06 22:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:45:05 --> Input Class Initialized
INFO - 2020-03-06 22:45:05 --> Language Class Initialized
INFO - 2020-03-06 22:45:05 --> Loader Class Initialized
INFO - 2020-03-06 22:45:05 --> Helper loaded: url_helper
INFO - 2020-03-06 22:45:05 --> Helper loaded: string_helper
INFO - 2020-03-06 22:45:05 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:45:05 --> Controller Class Initialized
INFO - 2020-03-06 22:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:45:05 --> Pagination Class Initialized
INFO - 2020-03-06 22:45:05 --> Model "M_show" initialized
INFO - 2020-03-06 22:45:05 --> Helper loaded: form_helper
INFO - 2020-03-06 22:45:05 --> Form Validation Class Initialized
INFO - 2020-03-06 22:45:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:45:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-06 22:45:05 --> Final output sent to browser
DEBUG - 2020-03-06 22:45:05 --> Total execution time: 0.0353
INFO - 2020-03-06 22:45:25 --> Config Class Initialized
INFO - 2020-03-06 22:45:25 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:45:25 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:45:25 --> Utf8 Class Initialized
INFO - 2020-03-06 22:45:25 --> URI Class Initialized
INFO - 2020-03-06 22:45:25 --> Router Class Initialized
INFO - 2020-03-06 22:45:25 --> Output Class Initialized
INFO - 2020-03-06 22:45:25 --> Security Class Initialized
DEBUG - 2020-03-06 22:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:45:25 --> Input Class Initialized
INFO - 2020-03-06 22:45:25 --> Language Class Initialized
INFO - 2020-03-06 22:45:25 --> Loader Class Initialized
INFO - 2020-03-06 22:45:25 --> Helper loaded: url_helper
INFO - 2020-03-06 22:45:25 --> Helper loaded: string_helper
INFO - 2020-03-06 22:45:25 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:45:25 --> Controller Class Initialized
INFO - 2020-03-06 22:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:45:25 --> Pagination Class Initialized
INFO - 2020-03-06 22:45:25 --> Model "M_show" initialized
INFO - 2020-03-06 22:45:25 --> Helper loaded: form_helper
INFO - 2020-03-06 22:45:25 --> Form Validation Class Initialized
INFO - 2020-03-06 22:45:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:45:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 22:45:25 --> Final output sent to browser
DEBUG - 2020-03-06 22:45:25 --> Total execution time: 0.0088
INFO - 2020-03-06 22:45:31 --> Config Class Initialized
INFO - 2020-03-06 22:45:31 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:45:31 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:45:31 --> Utf8 Class Initialized
INFO - 2020-03-06 22:45:31 --> URI Class Initialized
INFO - 2020-03-06 22:45:31 --> Router Class Initialized
INFO - 2020-03-06 22:45:31 --> Output Class Initialized
INFO - 2020-03-06 22:45:31 --> Security Class Initialized
DEBUG - 2020-03-06 22:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:45:31 --> Input Class Initialized
INFO - 2020-03-06 22:45:31 --> Language Class Initialized
INFO - 2020-03-06 22:45:31 --> Loader Class Initialized
INFO - 2020-03-06 22:45:31 --> Helper loaded: url_helper
INFO - 2020-03-06 22:45:31 --> Helper loaded: string_helper
INFO - 2020-03-06 22:45:31 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:45:31 --> Controller Class Initialized
INFO - 2020-03-06 22:45:31 --> Model "M_tiket" initialized
INFO - 2020-03-06 22:45:31 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 22:45:31 --> Model "M_pesan" initialized
INFO - 2020-03-06 22:45:31 --> Helper loaded: form_helper
INFO - 2020-03-06 22:45:31 --> Form Validation Class Initialized
INFO - 2020-03-06 22:45:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 22:45:31 --> Final output sent to browser
DEBUG - 2020-03-06 22:45:31 --> Total execution time: 0.0097
INFO - 2020-03-06 22:45:48 --> Config Class Initialized
INFO - 2020-03-06 22:45:48 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:45:48 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:45:48 --> Utf8 Class Initialized
INFO - 2020-03-06 22:45:48 --> URI Class Initialized
DEBUG - 2020-03-06 22:45:48 --> No URI present. Default controller set.
INFO - 2020-03-06 22:45:48 --> Router Class Initialized
INFO - 2020-03-06 22:45:48 --> Output Class Initialized
INFO - 2020-03-06 22:45:48 --> Security Class Initialized
DEBUG - 2020-03-06 22:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:45:48 --> Input Class Initialized
INFO - 2020-03-06 22:45:48 --> Language Class Initialized
INFO - 2020-03-06 22:45:48 --> Loader Class Initialized
INFO - 2020-03-06 22:45:48 --> Helper loaded: url_helper
INFO - 2020-03-06 22:45:48 --> Helper loaded: string_helper
INFO - 2020-03-06 22:45:48 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:45:48 --> Controller Class Initialized
INFO - 2020-03-06 22:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:45:48 --> Pagination Class Initialized
INFO - 2020-03-06 22:45:48 --> Model "M_show" initialized
INFO - 2020-03-06 22:45:48 --> Helper loaded: form_helper
INFO - 2020-03-06 22:45:48 --> Form Validation Class Initialized
INFO - 2020-03-06 22:45:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:45:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 22:45:48 --> Final output sent to browser
DEBUG - 2020-03-06 22:45:48 --> Total execution time: 0.0054
INFO - 2020-03-06 22:45:49 --> Config Class Initialized
INFO - 2020-03-06 22:45:49 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:45:49 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:45:49 --> Utf8 Class Initialized
INFO - 2020-03-06 22:45:49 --> URI Class Initialized
INFO - 2020-03-06 22:45:49 --> Router Class Initialized
INFO - 2020-03-06 22:45:49 --> Output Class Initialized
INFO - 2020-03-06 22:45:49 --> Security Class Initialized
DEBUG - 2020-03-06 22:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:45:49 --> Input Class Initialized
INFO - 2020-03-06 22:45:49 --> Language Class Initialized
INFO - 2020-03-06 22:45:49 --> Loader Class Initialized
INFO - 2020-03-06 22:45:49 --> Helper loaded: url_helper
INFO - 2020-03-06 22:45:49 --> Helper loaded: string_helper
INFO - 2020-03-06 22:45:49 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:45:49 --> Controller Class Initialized
INFO - 2020-03-06 22:45:49 --> Model "M_tiket" initialized
INFO - 2020-03-06 22:45:49 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 22:45:49 --> Model "M_pesan" initialized
INFO - 2020-03-06 22:45:49 --> Helper loaded: form_helper
INFO - 2020-03-06 22:45:49 --> Form Validation Class Initialized
INFO - 2020-03-06 22:45:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-06 22:45:49 --> Final output sent to browser
DEBUG - 2020-03-06 22:45:49 --> Total execution time: 0.0084
INFO - 2020-03-06 22:48:23 --> Config Class Initialized
INFO - 2020-03-06 22:48:23 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:48:23 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:48:23 --> Utf8 Class Initialized
INFO - 2020-03-06 22:48:23 --> URI Class Initialized
DEBUG - 2020-03-06 22:48:23 --> No URI present. Default controller set.
INFO - 2020-03-06 22:48:23 --> Router Class Initialized
INFO - 2020-03-06 22:48:23 --> Output Class Initialized
INFO - 2020-03-06 22:48:23 --> Security Class Initialized
DEBUG - 2020-03-06 22:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:48:23 --> Input Class Initialized
INFO - 2020-03-06 22:48:23 --> Language Class Initialized
INFO - 2020-03-06 22:48:23 --> Loader Class Initialized
INFO - 2020-03-06 22:48:23 --> Helper loaded: url_helper
INFO - 2020-03-06 22:48:23 --> Helper loaded: string_helper
INFO - 2020-03-06 22:48:23 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:48:23 --> Controller Class Initialized
INFO - 2020-03-06 22:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:48:23 --> Pagination Class Initialized
INFO - 2020-03-06 22:48:23 --> Model "M_show" initialized
INFO - 2020-03-06 22:48:23 --> Helper loaded: form_helper
INFO - 2020-03-06 22:48:23 --> Form Validation Class Initialized
INFO - 2020-03-06 22:48:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:48:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 22:48:23 --> Final output sent to browser
DEBUG - 2020-03-06 22:48:23 --> Total execution time: 0.0304
INFO - 2020-03-06 22:48:27 --> Config Class Initialized
INFO - 2020-03-06 22:48:27 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:48:27 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:48:27 --> Utf8 Class Initialized
INFO - 2020-03-06 22:48:27 --> URI Class Initialized
INFO - 2020-03-06 22:48:27 --> Router Class Initialized
INFO - 2020-03-06 22:48:27 --> Output Class Initialized
INFO - 2020-03-06 22:48:27 --> Security Class Initialized
DEBUG - 2020-03-06 22:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:48:27 --> Input Class Initialized
INFO - 2020-03-06 22:48:27 --> Language Class Initialized
INFO - 2020-03-06 22:48:27 --> Loader Class Initialized
INFO - 2020-03-06 22:48:27 --> Helper loaded: url_helper
INFO - 2020-03-06 22:48:27 --> Helper loaded: string_helper
INFO - 2020-03-06 22:48:27 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:48:27 --> Controller Class Initialized
INFO - 2020-03-06 22:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:48:27 --> Pagination Class Initialized
INFO - 2020-03-06 22:48:27 --> Model "M_show" initialized
INFO - 2020-03-06 22:48:27 --> Helper loaded: form_helper
INFO - 2020-03-06 22:48:27 --> Form Validation Class Initialized
INFO - 2020-03-06 22:48:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:48:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 22:48:27 --> Final output sent to browser
DEBUG - 2020-03-06 22:48:27 --> Total execution time: 0.0079
INFO - 2020-03-06 22:48:32 --> Config Class Initialized
INFO - 2020-03-06 22:48:32 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:48:32 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:48:32 --> Utf8 Class Initialized
INFO - 2020-03-06 22:48:32 --> URI Class Initialized
INFO - 2020-03-06 22:48:32 --> Router Class Initialized
INFO - 2020-03-06 22:48:32 --> Output Class Initialized
INFO - 2020-03-06 22:48:32 --> Security Class Initialized
DEBUG - 2020-03-06 22:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:48:32 --> Input Class Initialized
INFO - 2020-03-06 22:48:32 --> Language Class Initialized
INFO - 2020-03-06 22:48:32 --> Loader Class Initialized
INFO - 2020-03-06 22:48:32 --> Helper loaded: url_helper
INFO - 2020-03-06 22:48:32 --> Helper loaded: string_helper
INFO - 2020-03-06 22:48:32 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:48:32 --> Controller Class Initialized
INFO - 2020-03-06 22:48:32 --> Model "M_tiket" initialized
INFO - 2020-03-06 22:48:32 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 22:48:32 --> Model "M_pesan" initialized
INFO - 2020-03-06 22:48:32 --> Helper loaded: form_helper
INFO - 2020-03-06 22:48:32 --> Form Validation Class Initialized
INFO - 2020-03-06 22:48:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 22:48:32 --> Final output sent to browser
DEBUG - 2020-03-06 22:48:32 --> Total execution time: 0.0111
INFO - 2020-03-06 22:48:32 --> Config Class Initialized
INFO - 2020-03-06 22:48:32 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:48:32 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:48:32 --> Utf8 Class Initialized
INFO - 2020-03-06 22:48:32 --> URI Class Initialized
INFO - 2020-03-06 22:48:32 --> Router Class Initialized
INFO - 2020-03-06 22:48:32 --> Output Class Initialized
INFO - 2020-03-06 22:48:32 --> Security Class Initialized
DEBUG - 2020-03-06 22:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:48:32 --> Input Class Initialized
INFO - 2020-03-06 22:48:32 --> Language Class Initialized
INFO - 2020-03-06 22:48:32 --> Loader Class Initialized
INFO - 2020-03-06 22:48:32 --> Helper loaded: url_helper
INFO - 2020-03-06 22:48:32 --> Helper loaded: string_helper
INFO - 2020-03-06 22:48:32 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:48:32 --> Controller Class Initialized
INFO - 2020-03-06 22:48:32 --> Model "M_tiket" initialized
INFO - 2020-03-06 22:48:32 --> Model "M_pengunjung" initialized
INFO - 2020-03-06 22:48:32 --> Model "M_pesan" initialized
INFO - 2020-03-06 22:48:32 --> Helper loaded: form_helper
INFO - 2020-03-06 22:48:32 --> Form Validation Class Initialized
INFO - 2020-03-06 22:48:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-06 22:48:32 --> Final output sent to browser
DEBUG - 2020-03-06 22:48:32 --> Total execution time: 0.0079
INFO - 2020-03-06 22:48:56 --> Config Class Initialized
INFO - 2020-03-06 22:48:56 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:48:56 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:48:56 --> Utf8 Class Initialized
INFO - 2020-03-06 22:48:56 --> URI Class Initialized
INFO - 2020-03-06 22:48:56 --> Router Class Initialized
INFO - 2020-03-06 22:48:56 --> Output Class Initialized
INFO - 2020-03-06 22:48:56 --> Security Class Initialized
DEBUG - 2020-03-06 22:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:48:56 --> Input Class Initialized
INFO - 2020-03-06 22:48:56 --> Language Class Initialized
INFO - 2020-03-06 22:48:56 --> Loader Class Initialized
INFO - 2020-03-06 22:48:56 --> Helper loaded: url_helper
INFO - 2020-03-06 22:48:56 --> Helper loaded: string_helper
INFO - 2020-03-06 22:48:56 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:48:56 --> Controller Class Initialized
INFO - 2020-03-06 22:48:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:48:56 --> Pagination Class Initialized
INFO - 2020-03-06 22:48:56 --> Model "M_show" initialized
INFO - 2020-03-06 22:48:56 --> Helper loaded: form_helper
INFO - 2020-03-06 22:48:56 --> Form Validation Class Initialized
INFO - 2020-03-06 22:48:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:48:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-06 22:48:56 --> Final output sent to browser
DEBUG - 2020-03-06 22:48:56 --> Total execution time: 0.0066
INFO - 2020-03-06 22:49:20 --> Config Class Initialized
INFO - 2020-03-06 22:49:20 --> Hooks Class Initialized
DEBUG - 2020-03-06 22:49:20 --> UTF-8 Support Enabled
INFO - 2020-03-06 22:49:20 --> Utf8 Class Initialized
INFO - 2020-03-06 22:49:20 --> URI Class Initialized
INFO - 2020-03-06 22:49:20 --> Router Class Initialized
INFO - 2020-03-06 22:49:20 --> Output Class Initialized
INFO - 2020-03-06 22:49:20 --> Security Class Initialized
DEBUG - 2020-03-06 22:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 22:49:20 --> Input Class Initialized
INFO - 2020-03-06 22:49:20 --> Language Class Initialized
INFO - 2020-03-06 22:49:20 --> Loader Class Initialized
INFO - 2020-03-06 22:49:20 --> Helper loaded: url_helper
INFO - 2020-03-06 22:49:20 --> Helper loaded: string_helper
INFO - 2020-03-06 22:49:20 --> Database Driver Class Initialized
DEBUG - 2020-03-06 22:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 22:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 22:49:20 --> Controller Class Initialized
INFO - 2020-03-06 22:49:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 22:49:20 --> Pagination Class Initialized
INFO - 2020-03-06 22:49:20 --> Model "M_show" initialized
INFO - 2020-03-06 22:49:20 --> Helper loaded: form_helper
INFO - 2020-03-06 22:49:20 --> Form Validation Class Initialized
INFO - 2020-03-06 22:49:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 22:49:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-06 22:49:20 --> Final output sent to browser
DEBUG - 2020-03-06 22:49:20 --> Total execution time: 0.0065
INFO - 2020-03-06 23:53:07 --> Config Class Initialized
INFO - 2020-03-06 23:53:07 --> Hooks Class Initialized
DEBUG - 2020-03-06 23:53:07 --> UTF-8 Support Enabled
INFO - 2020-03-06 23:53:07 --> Utf8 Class Initialized
INFO - 2020-03-06 23:53:07 --> URI Class Initialized
DEBUG - 2020-03-06 23:53:07 --> No URI present. Default controller set.
INFO - 2020-03-06 23:53:07 --> Router Class Initialized
INFO - 2020-03-06 23:53:07 --> Output Class Initialized
INFO - 2020-03-06 23:53:07 --> Security Class Initialized
DEBUG - 2020-03-06 23:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 23:53:07 --> Input Class Initialized
INFO - 2020-03-06 23:53:07 --> Language Class Initialized
INFO - 2020-03-06 23:53:07 --> Loader Class Initialized
INFO - 2020-03-06 23:53:07 --> Helper loaded: url_helper
INFO - 2020-03-06 23:53:07 --> Helper loaded: string_helper
INFO - 2020-03-06 23:53:07 --> Database Driver Class Initialized
DEBUG - 2020-03-06 23:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 23:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 23:53:07 --> Controller Class Initialized
INFO - 2020-03-06 23:53:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 23:53:07 --> Pagination Class Initialized
INFO - 2020-03-06 23:53:07 --> Model "M_show" initialized
INFO - 2020-03-06 23:53:07 --> Helper loaded: form_helper
INFO - 2020-03-06 23:53:07 --> Form Validation Class Initialized
INFO - 2020-03-06 23:53:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 23:53:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 23:53:07 --> Final output sent to browser
DEBUG - 2020-03-06 23:53:07 --> Total execution time: 0.0338
INFO - 2020-03-06 23:53:07 --> Config Class Initialized
INFO - 2020-03-06 23:53:07 --> Hooks Class Initialized
DEBUG - 2020-03-06 23:53:07 --> UTF-8 Support Enabled
INFO - 2020-03-06 23:53:07 --> Utf8 Class Initialized
INFO - 2020-03-06 23:53:07 --> URI Class Initialized
DEBUG - 2020-03-06 23:53:07 --> No URI present. Default controller set.
INFO - 2020-03-06 23:53:07 --> Router Class Initialized
INFO - 2020-03-06 23:53:07 --> Output Class Initialized
INFO - 2020-03-06 23:53:07 --> Security Class Initialized
DEBUG - 2020-03-06 23:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-06 23:53:07 --> Input Class Initialized
INFO - 2020-03-06 23:53:07 --> Language Class Initialized
INFO - 2020-03-06 23:53:07 --> Loader Class Initialized
INFO - 2020-03-06 23:53:07 --> Helper loaded: url_helper
INFO - 2020-03-06 23:53:07 --> Helper loaded: string_helper
INFO - 2020-03-06 23:53:07 --> Database Driver Class Initialized
DEBUG - 2020-03-06 23:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-06 23:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-06 23:53:07 --> Controller Class Initialized
INFO - 2020-03-06 23:53:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-06 23:53:07 --> Pagination Class Initialized
INFO - 2020-03-06 23:53:07 --> Model "M_show" initialized
INFO - 2020-03-06 23:53:07 --> Helper loaded: form_helper
INFO - 2020-03-06 23:53:07 --> Form Validation Class Initialized
INFO - 2020-03-06 23:53:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-06 23:53:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-06 23:53:07 --> Final output sent to browser
DEBUG - 2020-03-06 23:53:07 --> Total execution time: 0.0302
