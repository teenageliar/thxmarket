<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-09 16:17:38 --> Config Class Initialized
INFO - 2020-02-09 16:17:38 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:17:39 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:17:39 --> Utf8 Class Initialized
INFO - 2020-02-09 16:17:39 --> URI Class Initialized
INFO - 2020-02-09 16:17:39 --> Router Class Initialized
INFO - 2020-02-09 16:17:40 --> Output Class Initialized
INFO - 2020-02-09 16:17:40 --> Security Class Initialized
DEBUG - 2020-02-09 16:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:17:40 --> Input Class Initialized
INFO - 2020-02-09 16:17:40 --> Language Class Initialized
INFO - 2020-02-09 16:17:40 --> Loader Class Initialized
INFO - 2020-02-09 16:17:40 --> Helper loaded: url_helper
INFO - 2020-02-09 16:17:41 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:17:42 --> Controller Class Initialized
INFO - 2020-02-09 16:17:42 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:17:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:17:42 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:17:42 --> Helper loaded: form_helper
INFO - 2020-02-09 16:17:42 --> Form Validation Class Initialized
INFO - 2020-02-09 16:17:43 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-09 16:17:43 --> Final output sent to browser
DEBUG - 2020-02-09 16:17:43 --> Total execution time: 5.2394
INFO - 2020-02-09 16:17:44 --> Config Class Initialized
INFO - 2020-02-09 16:17:44 --> Config Class Initialized
INFO - 2020-02-09 16:17:44 --> Hooks Class Initialized
INFO - 2020-02-09 16:17:44 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:17:44 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:17:44 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:17:44 --> Utf8 Class Initialized
INFO - 2020-02-09 16:17:44 --> Utf8 Class Initialized
INFO - 2020-02-09 16:17:44 --> URI Class Initialized
INFO - 2020-02-09 16:17:44 --> URI Class Initialized
INFO - 2020-02-09 16:17:44 --> Router Class Initialized
INFO - 2020-02-09 16:17:44 --> Router Class Initialized
INFO - 2020-02-09 16:17:44 --> Output Class Initialized
INFO - 2020-02-09 16:17:44 --> Output Class Initialized
INFO - 2020-02-09 16:17:44 --> Security Class Initialized
INFO - 2020-02-09 16:17:44 --> Security Class Initialized
DEBUG - 2020-02-09 16:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:17:44 --> Input Class Initialized
INFO - 2020-02-09 16:17:44 --> Input Class Initialized
INFO - 2020-02-09 16:17:45 --> Language Class Initialized
INFO - 2020-02-09 16:17:45 --> Language Class Initialized
INFO - 2020-02-09 16:17:45 --> Loader Class Initialized
INFO - 2020-02-09 16:17:45 --> Loader Class Initialized
INFO - 2020-02-09 16:17:45 --> Helper loaded: url_helper
INFO - 2020-02-09 16:17:45 --> Helper loaded: url_helper
INFO - 2020-02-09 16:17:45 --> Database Driver Class Initialized
INFO - 2020-02-09 16:17:45 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-09 16:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:17:45 --> Controller Class Initialized
INFO - 2020-02-09 16:17:45 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:17:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:17:45 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:17:45 --> Helper loaded: form_helper
INFO - 2020-02-09 16:17:45 --> Form Validation Class Initialized
ERROR - 2020-02-09 16:17:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-09 16:17:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-09 16:17:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-09 16:17:45 --> Final output sent to browser
DEBUG - 2020-02-09 16:17:45 --> Total execution time: 0.6731
INFO - 2020-02-09 16:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:17:45 --> Controller Class Initialized
INFO - 2020-02-09 16:17:45 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:17:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:17:45 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:17:45 --> Helper loaded: form_helper
INFO - 2020-02-09 16:17:45 --> Form Validation Class Initialized
ERROR - 2020-02-09 16:17:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-09 16:17:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-09 16:17:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-09 16:17:45 --> Final output sent to browser
DEBUG - 2020-02-09 16:17:45 --> Total execution time: 0.9672
INFO - 2020-02-09 16:23:42 --> Config Class Initialized
INFO - 2020-02-09 16:23:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:23:43 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:23:43 --> Utf8 Class Initialized
INFO - 2020-02-09 16:23:43 --> URI Class Initialized
DEBUG - 2020-02-09 16:23:43 --> No URI present. Default controller set.
INFO - 2020-02-09 16:23:43 --> Router Class Initialized
INFO - 2020-02-09 16:23:43 --> Output Class Initialized
INFO - 2020-02-09 16:23:43 --> Security Class Initialized
DEBUG - 2020-02-09 16:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:23:43 --> Input Class Initialized
INFO - 2020-02-09 16:23:43 --> Language Class Initialized
INFO - 2020-02-09 16:23:43 --> Loader Class Initialized
INFO - 2020-02-09 16:23:43 --> Helper loaded: url_helper
INFO - 2020-02-09 16:23:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:23:44 --> Controller Class Initialized
INFO - 2020-02-09 16:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-09 16:23:44 --> Pagination Class Initialized
INFO - 2020-02-09 16:23:44 --> Model "M_show" initialized
INFO - 2020-02-09 16:23:44 --> Helper loaded: form_helper
INFO - 2020-02-09 16:23:44 --> Form Validation Class Initialized
INFO - 2020-02-09 16:23:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-09 16:23:44 --> Final output sent to browser
DEBUG - 2020-02-09 16:23:44 --> Total execution time: 1.9732
INFO - 2020-02-09 16:25:01 --> Config Class Initialized
INFO - 2020-02-09 16:25:01 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:25:01 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:25:01 --> Utf8 Class Initialized
INFO - 2020-02-09 16:25:01 --> URI Class Initialized
DEBUG - 2020-02-09 16:25:01 --> No URI present. Default controller set.
INFO - 2020-02-09 16:25:01 --> Router Class Initialized
INFO - 2020-02-09 16:25:01 --> Output Class Initialized
INFO - 2020-02-09 16:25:01 --> Security Class Initialized
DEBUG - 2020-02-09 16:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:25:01 --> Input Class Initialized
INFO - 2020-02-09 16:25:01 --> Language Class Initialized
INFO - 2020-02-09 16:25:01 --> Loader Class Initialized
INFO - 2020-02-09 16:25:01 --> Helper loaded: url_helper
INFO - 2020-02-09 16:25:01 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:25:01 --> Controller Class Initialized
INFO - 2020-02-09 16:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-09 16:25:01 --> Pagination Class Initialized
INFO - 2020-02-09 16:25:01 --> Model "M_show" initialized
INFO - 2020-02-09 16:25:01 --> Helper loaded: form_helper
INFO - 2020-02-09 16:25:01 --> Form Validation Class Initialized
INFO - 2020-02-09 16:25:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-09 16:25:01 --> Final output sent to browser
DEBUG - 2020-02-09 16:25:01 --> Total execution time: 0.5298
INFO - 2020-02-09 16:26:35 --> Config Class Initialized
INFO - 2020-02-09 16:26:35 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:26:35 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:26:35 --> Utf8 Class Initialized
INFO - 2020-02-09 16:26:35 --> URI Class Initialized
DEBUG - 2020-02-09 16:26:36 --> No URI present. Default controller set.
INFO - 2020-02-09 16:26:36 --> Router Class Initialized
INFO - 2020-02-09 16:26:36 --> Output Class Initialized
INFO - 2020-02-09 16:26:36 --> Security Class Initialized
DEBUG - 2020-02-09 16:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:26:36 --> Input Class Initialized
INFO - 2020-02-09 16:26:36 --> Language Class Initialized
INFO - 2020-02-09 16:26:36 --> Loader Class Initialized
INFO - 2020-02-09 16:26:36 --> Helper loaded: url_helper
INFO - 2020-02-09 16:26:36 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:26:36 --> Controller Class Initialized
INFO - 2020-02-09 16:26:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-09 16:26:36 --> Pagination Class Initialized
INFO - 2020-02-09 16:26:36 --> Model "M_show" initialized
INFO - 2020-02-09 16:26:36 --> Helper loaded: form_helper
INFO - 2020-02-09 16:26:36 --> Form Validation Class Initialized
INFO - 2020-02-09 16:26:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-09 16:26:36 --> Final output sent to browser
DEBUG - 2020-02-09 16:26:36 --> Total execution time: 0.8724
INFO - 2020-02-09 16:27:43 --> Config Class Initialized
INFO - 2020-02-09 16:27:44 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:27:44 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:27:44 --> Utf8 Class Initialized
INFO - 2020-02-09 16:27:44 --> URI Class Initialized
DEBUG - 2020-02-09 16:27:44 --> No URI present. Default controller set.
INFO - 2020-02-09 16:27:44 --> Router Class Initialized
INFO - 2020-02-09 16:27:44 --> Output Class Initialized
INFO - 2020-02-09 16:27:44 --> Security Class Initialized
DEBUG - 2020-02-09 16:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:27:44 --> Input Class Initialized
INFO - 2020-02-09 16:27:44 --> Language Class Initialized
INFO - 2020-02-09 16:27:44 --> Loader Class Initialized
INFO - 2020-02-09 16:27:44 --> Helper loaded: url_helper
INFO - 2020-02-09 16:27:44 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:27:44 --> Controller Class Initialized
INFO - 2020-02-09 16:27:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-09 16:27:44 --> Pagination Class Initialized
INFO - 2020-02-09 16:27:44 --> Model "M_show" initialized
INFO - 2020-02-09 16:27:44 --> Helper loaded: form_helper
INFO - 2020-02-09 16:27:44 --> Form Validation Class Initialized
INFO - 2020-02-09 16:27:44 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-09 16:27:44 --> Final output sent to browser
DEBUG - 2020-02-09 16:27:44 --> Total execution time: 0.4748
INFO - 2020-02-09 16:28:14 --> Config Class Initialized
INFO - 2020-02-09 16:28:14 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:14 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:14 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:14 --> URI Class Initialized
DEBUG - 2020-02-09 16:28:14 --> No URI present. Default controller set.
INFO - 2020-02-09 16:28:14 --> Router Class Initialized
INFO - 2020-02-09 16:28:14 --> Output Class Initialized
INFO - 2020-02-09 16:28:14 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:14 --> Input Class Initialized
INFO - 2020-02-09 16:28:14 --> Language Class Initialized
INFO - 2020-02-09 16:28:14 --> Loader Class Initialized
INFO - 2020-02-09 16:28:14 --> Helper loaded: url_helper
INFO - 2020-02-09 16:28:14 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:28:14 --> Controller Class Initialized
INFO - 2020-02-09 16:28:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-09 16:28:14 --> Pagination Class Initialized
INFO - 2020-02-09 16:28:14 --> Model "M_show" initialized
INFO - 2020-02-09 16:28:14 --> Helper loaded: form_helper
INFO - 2020-02-09 16:28:14 --> Form Validation Class Initialized
INFO - 2020-02-09 16:28:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-09 16:28:14 --> Final output sent to browser
DEBUG - 2020-02-09 16:28:14 --> Total execution time: 0.3452
INFO - 2020-02-09 16:28:50 --> Config Class Initialized
INFO - 2020-02-09 16:28:50 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:50 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:50 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:50 --> URI Class Initialized
DEBUG - 2020-02-09 16:28:50 --> No URI present. Default controller set.
INFO - 2020-02-09 16:28:50 --> Router Class Initialized
INFO - 2020-02-09 16:28:50 --> Output Class Initialized
INFO - 2020-02-09 16:28:50 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:50 --> Input Class Initialized
INFO - 2020-02-09 16:28:50 --> Language Class Initialized
INFO - 2020-02-09 16:28:50 --> Loader Class Initialized
INFO - 2020-02-09 16:28:50 --> Helper loaded: url_helper
INFO - 2020-02-09 16:28:50 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:28:50 --> Controller Class Initialized
INFO - 2020-02-09 16:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-09 16:28:50 --> Pagination Class Initialized
INFO - 2020-02-09 16:28:51 --> Model "M_show" initialized
INFO - 2020-02-09 16:28:51 --> Helper loaded: form_helper
INFO - 2020-02-09 16:28:51 --> Form Validation Class Initialized
INFO - 2020-02-09 16:28:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-09 16:28:51 --> Final output sent to browser
DEBUG - 2020-02-09 16:28:51 --> Total execution time: 0.3991
INFO - 2020-02-09 16:28:52 --> Config Class Initialized
INFO - 2020-02-09 16:28:52 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:52 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:52 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:52 --> URI Class Initialized
DEBUG - 2020-02-09 16:28:52 --> No URI present. Default controller set.
INFO - 2020-02-09 16:28:52 --> Router Class Initialized
INFO - 2020-02-09 16:28:52 --> Output Class Initialized
INFO - 2020-02-09 16:28:52 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:52 --> Input Class Initialized
INFO - 2020-02-09 16:28:52 --> Language Class Initialized
INFO - 2020-02-09 16:28:52 --> Loader Class Initialized
INFO - 2020-02-09 16:28:52 --> Helper loaded: url_helper
INFO - 2020-02-09 16:28:52 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:28:52 --> Controller Class Initialized
INFO - 2020-02-09 16:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-09 16:28:52 --> Pagination Class Initialized
INFO - 2020-02-09 16:28:52 --> Model "M_show" initialized
INFO - 2020-02-09 16:28:52 --> Helper loaded: form_helper
INFO - 2020-02-09 16:28:52 --> Form Validation Class Initialized
INFO - 2020-02-09 16:28:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-09 16:28:52 --> Final output sent to browser
DEBUG - 2020-02-09 16:28:52 --> Total execution time: 0.5031
INFO - 2020-02-09 16:28:55 --> Config Class Initialized
INFO - 2020-02-09 16:28:55 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:55 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:55 --> URI Class Initialized
INFO - 2020-02-09 16:28:55 --> Router Class Initialized
INFO - 2020-02-09 16:28:55 --> Output Class Initialized
INFO - 2020-02-09 16:28:55 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:55 --> Input Class Initialized
INFO - 2020-02-09 16:28:55 --> Language Class Initialized
INFO - 2020-02-09 16:28:55 --> Loader Class Initialized
INFO - 2020-02-09 16:28:55 --> Helper loaded: url_helper
INFO - 2020-02-09 16:28:55 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:28:55 --> Controller Class Initialized
INFO - 2020-02-09 16:28:55 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:28:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:28:55 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:28:55 --> Helper loaded: form_helper
INFO - 2020-02-09 16:28:55 --> Form Validation Class Initialized
INFO - 2020-02-09 16:28:55 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-09 16:28:55 --> Final output sent to browser
DEBUG - 2020-02-09 16:28:55 --> Total execution time: 0.5875
INFO - 2020-02-09 16:28:55 --> Config Class Initialized
INFO - 2020-02-09 16:28:55 --> Config Class Initialized
INFO - 2020-02-09 16:28:55 --> Config Class Initialized
INFO - 2020-02-09 16:28:55 --> Hooks Class Initialized
INFO - 2020-02-09 16:28:55 --> Hooks Class Initialized
INFO - 2020-02-09 16:28:55 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:28:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:28:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:55 --> Config Class Initialized
INFO - 2020-02-09 16:28:55 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:55 --> Hooks Class Initialized
INFO - 2020-02-09 16:28:55 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:55 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:55 --> URI Class Initialized
INFO - 2020-02-09 16:28:55 --> URI Class Initialized
DEBUG - 2020-02-09 16:28:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:55 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:55 --> Router Class Initialized
INFO - 2020-02-09 16:28:55 --> Router Class Initialized
INFO - 2020-02-09 16:28:55 --> URI Class Initialized
INFO - 2020-02-09 16:28:55 --> URI Class Initialized
INFO - 2020-02-09 16:28:55 --> Output Class Initialized
INFO - 2020-02-09 16:28:55 --> Output Class Initialized
INFO - 2020-02-09 16:28:55 --> Router Class Initialized
INFO - 2020-02-09 16:28:55 --> Security Class Initialized
INFO - 2020-02-09 16:28:55 --> Router Class Initialized
INFO - 2020-02-09 16:28:55 --> Security Class Initialized
INFO - 2020-02-09 16:28:55 --> Output Class Initialized
DEBUG - 2020-02-09 16:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:55 --> Security Class Initialized
INFO - 2020-02-09 16:28:55 --> Output Class Initialized
INFO - 2020-02-09 16:28:55 --> Config Class Initialized
INFO - 2020-02-09 16:28:55 --> Hooks Class Initialized
INFO - 2020-02-09 16:28:55 --> Input Class Initialized
INFO - 2020-02-09 16:28:55 --> Input Class Initialized
INFO - 2020-02-09 16:28:55 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:55 --> Language Class Initialized
INFO - 2020-02-09 16:28:55 --> Language Class Initialized
INFO - 2020-02-09 16:28:55 --> Input Class Initialized
INFO - 2020-02-09 16:28:55 --> Config Class Initialized
DEBUG - 2020-02-09 16:28:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:55 --> Hooks Class Initialized
INFO - 2020-02-09 16:28:55 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:55 --> Input Class Initialized
INFO - 2020-02-09 16:28:55 --> Language Class Initialized
INFO - 2020-02-09 16:28:55 --> Loader Class Initialized
INFO - 2020-02-09 16:28:55 --> Helper loaded: url_helper
INFO - 2020-02-09 16:28:55 --> Language Class Initialized
DEBUG - 2020-02-09 16:28:55 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:55 --> URI Class Initialized
INFO - 2020-02-09 16:28:55 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:55 --> Router Class Initialized
INFO - 2020-02-09 16:28:55 --> Loader Class Initialized
INFO - 2020-02-09 16:28:55 --> Database Driver Class Initialized
INFO - 2020-02-09 16:28:55 --> Helper loaded: url_helper
INFO - 2020-02-09 16:28:55 --> URI Class Initialized
INFO - 2020-02-09 16:28:55 --> Output Class Initialized
DEBUG - 2020-02-09 16:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:28:55 --> Router Class Initialized
INFO - 2020-02-09 16:28:55 --> Security Class Initialized
INFO - 2020-02-09 16:28:55 --> Database Driver Class Initialized
INFO - 2020-02-09 16:28:55 --> Controller Class Initialized
DEBUG - 2020-02-09 16:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-02-09 16:28:55 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-09 16:28:55 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-09 16:28:56 --> Input Class Initialized
INFO - 2020-02-09 16:28:56 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:28:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:28:56 --> Language Class Initialized
INFO - 2020-02-09 16:28:56 --> Output Class Initialized
INFO - 2020-02-09 16:28:56 --> Model "M_pesan" initialized
ERROR - 2020-02-09 16:28:56 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:28:56 --> Helper loaded: form_helper
INFO - 2020-02-09 16:28:56 --> Security Class Initialized
INFO - 2020-02-09 16:28:56 --> Form Validation Class Initialized
DEBUG - 2020-02-09 16:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:56 --> Input Class Initialized
ERROR - 2020-02-09 16:28:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-09 16:28:56 --> Language Class Initialized
INFO - 2020-02-09 16:28:56 --> Config Class Initialized
INFO - 2020-02-09 16:28:56 --> Config Class Initialized
INFO - 2020-02-09 16:28:56 --> Config Class Initialized
INFO - 2020-02-09 16:28:56 --> Hooks Class Initialized
INFO - 2020-02-09 16:28:56 --> Hooks Class Initialized
INFO - 2020-02-09 16:28:56 --> Hooks Class Initialized
ERROR - 2020-02-09 16:28:56 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-09 16:28:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-02-09 16:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:28:56 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:56 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:56 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:56 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-09 16:28:56 --> URI Class Initialized
INFO - 2020-02-09 16:28:56 --> URI Class Initialized
INFO - 2020-02-09 16:28:56 --> Final output sent to browser
INFO - 2020-02-09 16:28:56 --> URI Class Initialized
INFO - 2020-02-09 16:28:56 --> Config Class Initialized
INFO - 2020-02-09 16:28:56 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:56 --> Total execution time: 0.5048
INFO - 2020-02-09 16:28:56 --> Router Class Initialized
INFO - 2020-02-09 16:28:56 --> Router Class Initialized
INFO - 2020-02-09 16:28:56 --> Router Class Initialized
INFO - 2020-02-09 16:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:28:56 --> Output Class Initialized
DEBUG - 2020-02-09 16:28:56 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:56 --> Output Class Initialized
INFO - 2020-02-09 16:28:56 --> Output Class Initialized
INFO - 2020-02-09 16:28:56 --> Config Class Initialized
INFO - 2020-02-09 16:28:56 --> Hooks Class Initialized
INFO - 2020-02-09 16:28:56 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:56 --> Controller Class Initialized
INFO - 2020-02-09 16:28:56 --> Security Class Initialized
INFO - 2020-02-09 16:28:56 --> Security Class Initialized
INFO - 2020-02-09 16:28:56 --> Security Class Initialized
INFO - 2020-02-09 16:28:56 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:28:56 --> URI Class Initialized
DEBUG - 2020-02-09 16:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:28:56 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:56 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:56 --> Input Class Initialized
INFO - 2020-02-09 16:28:56 --> Input Class Initialized
INFO - 2020-02-09 16:28:56 --> Input Class Initialized
INFO - 2020-02-09 16:28:56 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:28:56 --> Router Class Initialized
INFO - 2020-02-09 16:28:56 --> Language Class Initialized
INFO - 2020-02-09 16:28:56 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:28:56 --> Language Class Initialized
INFO - 2020-02-09 16:28:56 --> Language Class Initialized
INFO - 2020-02-09 16:28:56 --> Output Class Initialized
INFO - 2020-02-09 16:28:56 --> URI Class Initialized
ERROR - 2020-02-09 16:28:56 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-09 16:28:56 --> Router Class Initialized
INFO - 2020-02-09 16:28:56 --> Security Class Initialized
ERROR - 2020-02-09 16:28:56 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-09 16:28:56 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-09 16:28:56 --> Helper loaded: form_helper
INFO - 2020-02-09 16:28:56 --> Form Validation Class Initialized
DEBUG - 2020-02-09 16:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:56 --> Output Class Initialized
INFO - 2020-02-09 16:28:56 --> Config Class Initialized
INFO - 2020-02-09 16:28:56 --> Config Class Initialized
INFO - 2020-02-09 16:28:56 --> Hooks Class Initialized
INFO - 2020-02-09 16:28:56 --> Input Class Initialized
INFO - 2020-02-09 16:28:56 --> Hooks Class Initialized
INFO - 2020-02-09 16:28:56 --> Security Class Initialized
ERROR - 2020-02-09 16:28:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-09 16:28:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-09 16:28:56 --> Language Class Initialized
DEBUG - 2020-02-09 16:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:28:56 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:56 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:56 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:56 --> Input Class Initialized
INFO - 2020-02-09 16:28:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
ERROR - 2020-02-09 16:28:56 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-09 16:28:56 --> Final output sent to browser
INFO - 2020-02-09 16:28:56 --> URI Class Initialized
INFO - 2020-02-09 16:28:56 --> Language Class Initialized
INFO - 2020-02-09 16:28:56 --> URI Class Initialized
DEBUG - 2020-02-09 16:28:56 --> Total execution time: 0.6971
INFO - 2020-02-09 16:28:56 --> Router Class Initialized
ERROR - 2020-02-09 16:28:56 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-09 16:28:56 --> Router Class Initialized
INFO - 2020-02-09 16:28:56 --> Output Class Initialized
INFO - 2020-02-09 16:28:56 --> Output Class Initialized
INFO - 2020-02-09 16:28:56 --> Security Class Initialized
INFO - 2020-02-09 16:28:56 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:56 --> Input Class Initialized
INFO - 2020-02-09 16:28:56 --> Input Class Initialized
INFO - 2020-02-09 16:28:56 --> Language Class Initialized
INFO - 2020-02-09 16:28:56 --> Language Class Initialized
ERROR - 2020-02-09 16:28:56 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-09 16:28:56 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-09 16:28:56 --> Config Class Initialized
INFO - 2020-02-09 16:28:56 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:56 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:56 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:56 --> URI Class Initialized
INFO - 2020-02-09 16:28:56 --> Router Class Initialized
INFO - 2020-02-09 16:28:56 --> Output Class Initialized
INFO - 2020-02-09 16:28:56 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:56 --> Input Class Initialized
INFO - 2020-02-09 16:28:56 --> Language Class Initialized
ERROR - 2020-02-09 16:28:56 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-09 16:28:56 --> Config Class Initialized
INFO - 2020-02-09 16:28:56 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:56 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:56 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:56 --> URI Class Initialized
INFO - 2020-02-09 16:28:56 --> Router Class Initialized
INFO - 2020-02-09 16:28:56 --> Output Class Initialized
INFO - 2020-02-09 16:28:56 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:56 --> Input Class Initialized
INFO - 2020-02-09 16:28:56 --> Language Class Initialized
ERROR - 2020-02-09 16:28:56 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-09 16:28:56 --> Config Class Initialized
INFO - 2020-02-09 16:28:56 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:56 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:56 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:56 --> URI Class Initialized
INFO - 2020-02-09 16:28:56 --> Router Class Initialized
INFO - 2020-02-09 16:28:57 --> Output Class Initialized
INFO - 2020-02-09 16:28:57 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:57 --> Input Class Initialized
INFO - 2020-02-09 16:28:57 --> Language Class Initialized
ERROR - 2020-02-09 16:28:57 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-09 16:28:57 --> Config Class Initialized
INFO - 2020-02-09 16:28:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:57 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:57 --> URI Class Initialized
INFO - 2020-02-09 16:28:57 --> Router Class Initialized
INFO - 2020-02-09 16:28:57 --> Output Class Initialized
INFO - 2020-02-09 16:28:57 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:57 --> Input Class Initialized
INFO - 2020-02-09 16:28:57 --> Language Class Initialized
ERROR - 2020-02-09 16:28:57 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:28:57 --> Config Class Initialized
INFO - 2020-02-09 16:28:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:57 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:57 --> URI Class Initialized
INFO - 2020-02-09 16:28:57 --> Router Class Initialized
INFO - 2020-02-09 16:28:57 --> Output Class Initialized
INFO - 2020-02-09 16:28:57 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:57 --> Input Class Initialized
INFO - 2020-02-09 16:28:57 --> Language Class Initialized
ERROR - 2020-02-09 16:28:57 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:28:57 --> Config Class Initialized
INFO - 2020-02-09 16:28:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:57 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:57 --> URI Class Initialized
INFO - 2020-02-09 16:28:57 --> Router Class Initialized
INFO - 2020-02-09 16:28:57 --> Output Class Initialized
INFO - 2020-02-09 16:28:57 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:57 --> Input Class Initialized
INFO - 2020-02-09 16:28:57 --> Language Class Initialized
ERROR - 2020-02-09 16:28:57 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-09 16:28:57 --> Config Class Initialized
INFO - 2020-02-09 16:28:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:57 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:57 --> URI Class Initialized
INFO - 2020-02-09 16:28:57 --> Router Class Initialized
INFO - 2020-02-09 16:28:57 --> Output Class Initialized
INFO - 2020-02-09 16:28:57 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:57 --> Input Class Initialized
INFO - 2020-02-09 16:28:57 --> Language Class Initialized
ERROR - 2020-02-09 16:28:57 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-09 16:28:57 --> Config Class Initialized
INFO - 2020-02-09 16:28:57 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:57 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:57 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:57 --> URI Class Initialized
INFO - 2020-02-09 16:28:57 --> Router Class Initialized
INFO - 2020-02-09 16:28:57 --> Output Class Initialized
INFO - 2020-02-09 16:28:58 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:58 --> Input Class Initialized
INFO - 2020-02-09 16:28:58 --> Language Class Initialized
ERROR - 2020-02-09 16:28:58 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-09 16:28:58 --> Config Class Initialized
INFO - 2020-02-09 16:28:58 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:28:58 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:28:58 --> Utf8 Class Initialized
INFO - 2020-02-09 16:28:58 --> URI Class Initialized
INFO - 2020-02-09 16:28:58 --> Router Class Initialized
INFO - 2020-02-09 16:28:58 --> Output Class Initialized
INFO - 2020-02-09 16:28:58 --> Security Class Initialized
DEBUG - 2020-02-09 16:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:28:58 --> Input Class Initialized
INFO - 2020-02-09 16:28:58 --> Language Class Initialized
ERROR - 2020-02-09 16:28:58 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-09 16:41:11 --> Config Class Initialized
INFO - 2020-02-09 16:41:11 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:41:11 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:11 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:11 --> URI Class Initialized
INFO - 2020-02-09 16:41:12 --> Router Class Initialized
INFO - 2020-02-09 16:41:12 --> Output Class Initialized
INFO - 2020-02-09 16:41:12 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:12 --> Input Class Initialized
INFO - 2020-02-09 16:41:12 --> Language Class Initialized
INFO - 2020-02-09 16:41:12 --> Loader Class Initialized
INFO - 2020-02-09 16:41:12 --> Helper loaded: url_helper
INFO - 2020-02-09 16:41:13 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:41:16 --> Controller Class Initialized
INFO - 2020-02-09 16:41:16 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:41:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:41:17 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:41:17 --> Helper loaded: form_helper
INFO - 2020-02-09 16:41:17 --> Form Validation Class Initialized
INFO - 2020-02-09 16:41:19 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-09 16:41:19 --> Final output sent to browser
DEBUG - 2020-02-09 16:41:20 --> Total execution time: 8.0514
INFO - 2020-02-09 16:41:23 --> Config Class Initialized
INFO - 2020-02-09 16:41:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:41:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:23 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:23 --> URI Class Initialized
INFO - 2020-02-09 16:41:23 --> Router Class Initialized
INFO - 2020-02-09 16:41:23 --> Output Class Initialized
INFO - 2020-02-09 16:41:23 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:23 --> Input Class Initialized
INFO - 2020-02-09 16:41:23 --> Language Class Initialized
INFO - 2020-02-09 16:41:23 --> Config Class Initialized
INFO - 2020-02-09 16:41:23 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:41:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:23 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:23 --> URI Class Initialized
INFO - 2020-02-09 16:41:23 --> Router Class Initialized
ERROR - 2020-02-09 16:41:23 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-09 16:41:23 --> Config Class Initialized
INFO - 2020-02-09 16:41:23 --> Config Class Initialized
INFO - 2020-02-09 16:41:23 --> Config Class Initialized
INFO - 2020-02-09 16:41:23 --> Output Class Initialized
INFO - 2020-02-09 16:41:23 --> Hooks Class Initialized
INFO - 2020-02-09 16:41:23 --> Hooks Class Initialized
INFO - 2020-02-09 16:41:23 --> Hooks Class Initialized
INFO - 2020-02-09 16:41:23 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:41:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:41:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:41:23 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:23 --> Input Class Initialized
INFO - 2020-02-09 16:41:23 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:23 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:23 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:23 --> Language Class Initialized
INFO - 2020-02-09 16:41:23 --> URI Class Initialized
INFO - 2020-02-09 16:41:23 --> URI Class Initialized
INFO - 2020-02-09 16:41:23 --> URI Class Initialized
ERROR - 2020-02-09 16:41:23 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-09 16:41:23 --> Router Class Initialized
INFO - 2020-02-09 16:41:23 --> Router Class Initialized
INFO - 2020-02-09 16:41:23 --> Router Class Initialized
INFO - 2020-02-09 16:41:23 --> Output Class Initialized
INFO - 2020-02-09 16:41:23 --> Output Class Initialized
INFO - 2020-02-09 16:41:23 --> Output Class Initialized
INFO - 2020-02-09 16:41:23 --> Config Class Initialized
INFO - 2020-02-09 16:41:23 --> Config Class Initialized
INFO - 2020-02-09 16:41:23 --> Hooks Class Initialized
INFO - 2020-02-09 16:41:23 --> Hooks Class Initialized
INFO - 2020-02-09 16:41:23 --> Security Class Initialized
INFO - 2020-02-09 16:41:23 --> Security Class Initialized
INFO - 2020-02-09 16:41:23 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:41:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:24 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:24 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:24 --> Input Class Initialized
INFO - 2020-02-09 16:41:24 --> Input Class Initialized
INFO - 2020-02-09 16:41:24 --> Input Class Initialized
INFO - 2020-02-09 16:41:24 --> URI Class Initialized
INFO - 2020-02-09 16:41:24 --> URI Class Initialized
INFO - 2020-02-09 16:41:24 --> Language Class Initialized
INFO - 2020-02-09 16:41:24 --> Language Class Initialized
INFO - 2020-02-09 16:41:24 --> Language Class Initialized
ERROR - 2020-02-09 16:41:24 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-09 16:41:24 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-09 16:41:24 --> Router Class Initialized
INFO - 2020-02-09 16:41:24 --> Router Class Initialized
ERROR - 2020-02-09 16:41:24 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-09 16:41:24 --> Output Class Initialized
INFO - 2020-02-09 16:41:24 --> Output Class Initialized
INFO - 2020-02-09 16:41:24 --> Security Class Initialized
INFO - 2020-02-09 16:41:24 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:24 --> Input Class Initialized
INFO - 2020-02-09 16:41:24 --> Input Class Initialized
INFO - 2020-02-09 16:41:24 --> Config Class Initialized
INFO - 2020-02-09 16:41:24 --> Config Class Initialized
INFO - 2020-02-09 16:41:24 --> Config Class Initialized
INFO - 2020-02-09 16:41:24 --> Hooks Class Initialized
INFO - 2020-02-09 16:41:24 --> Hooks Class Initialized
INFO - 2020-02-09 16:41:24 --> Hooks Class Initialized
INFO - 2020-02-09 16:41:24 --> Language Class Initialized
INFO - 2020-02-09 16:41:24 --> Language Class Initialized
ERROR - 2020-02-09 16:41:24 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-09 16:41:24 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-02-09 16:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:41:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:24 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:24 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:24 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:24 --> Config Class Initialized
INFO - 2020-02-09 16:41:24 --> Config Class Initialized
INFO - 2020-02-09 16:41:24 --> URI Class Initialized
INFO - 2020-02-09 16:41:24 --> URI Class Initialized
INFO - 2020-02-09 16:41:24 --> URI Class Initialized
INFO - 2020-02-09 16:41:24 --> Hooks Class Initialized
INFO - 2020-02-09 16:41:24 --> Hooks Class Initialized
INFO - 2020-02-09 16:41:24 --> Router Class Initialized
INFO - 2020-02-09 16:41:24 --> Router Class Initialized
INFO - 2020-02-09 16:41:24 --> Router Class Initialized
INFO - 2020-02-09 16:41:24 --> Output Class Initialized
INFO - 2020-02-09 16:41:24 --> Output Class Initialized
DEBUG - 2020-02-09 16:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:41:24 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:24 --> Output Class Initialized
INFO - 2020-02-09 16:41:24 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:24 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:24 --> Security Class Initialized
INFO - 2020-02-09 16:41:24 --> Security Class Initialized
INFO - 2020-02-09 16:41:24 --> Security Class Initialized
INFO - 2020-02-09 16:41:24 --> URI Class Initialized
INFO - 2020-02-09 16:41:24 --> Router Class Initialized
DEBUG - 2020-02-09 16:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:24 --> URI Class Initialized
INFO - 2020-02-09 16:41:24 --> Input Class Initialized
INFO - 2020-02-09 16:41:24 --> Input Class Initialized
INFO - 2020-02-09 16:41:24 --> Router Class Initialized
INFO - 2020-02-09 16:41:24 --> Output Class Initialized
INFO - 2020-02-09 16:41:24 --> Input Class Initialized
INFO - 2020-02-09 16:41:24 --> Language Class Initialized
INFO - 2020-02-09 16:41:24 --> Language Class Initialized
INFO - 2020-02-09 16:41:24 --> Output Class Initialized
INFO - 2020-02-09 16:41:24 --> Security Class Initialized
INFO - 2020-02-09 16:41:24 --> Language Class Initialized
DEBUG - 2020-02-09 16:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-09 16:41:24 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-09 16:41:24 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-09 16:41:24 --> Security Class Initialized
ERROR - 2020-02-09 16:41:24 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
DEBUG - 2020-02-09 16:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:24 --> Input Class Initialized
INFO - 2020-02-09 16:41:25 --> Config Class Initialized
INFO - 2020-02-09 16:41:25 --> Input Class Initialized
INFO - 2020-02-09 16:41:25 --> Hooks Class Initialized
INFO - 2020-02-09 16:41:25 --> Language Class Initialized
INFO - 2020-02-09 16:41:25 --> Language Class Initialized
INFO - 2020-02-09 16:41:25 --> Loader Class Initialized
DEBUG - 2020-02-09 16:41:25 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:25 --> Utf8 Class Initialized
ERROR - 2020-02-09 16:41:25 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-09 16:41:25 --> Helper loaded: url_helper
INFO - 2020-02-09 16:41:25 --> URI Class Initialized
INFO - 2020-02-09 16:41:25 --> Router Class Initialized
INFO - 2020-02-09 16:41:25 --> Database Driver Class Initialized
INFO - 2020-02-09 16:41:25 --> Output Class Initialized
DEBUG - 2020-02-09 16:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:41:25 --> Security Class Initialized
INFO - 2020-02-09 16:41:25 --> Controller Class Initialized
DEBUG - 2020-02-09 16:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:25 --> Input Class Initialized
INFO - 2020-02-09 16:41:25 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:41:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:41:25 --> Language Class Initialized
INFO - 2020-02-09 16:41:25 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:41:25 --> Loader Class Initialized
INFO - 2020-02-09 16:41:25 --> Helper loaded: url_helper
INFO - 2020-02-09 16:41:25 --> Helper loaded: form_helper
INFO - 2020-02-09 16:41:25 --> Form Validation Class Initialized
INFO - 2020-02-09 16:41:25 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-02-09 16:41:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-09 16:41:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-09 16:41:26 --> Config Class Initialized
INFO - 2020-02-09 16:41:26 --> Hooks Class Initialized
INFO - 2020-02-09 16:41:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-09 16:41:26 --> Final output sent to browser
DEBUG - 2020-02-09 16:41:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:41:26 --> Total execution time: 2.5685
INFO - 2020-02-09 16:41:26 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:41:26 --> URI Class Initialized
INFO - 2020-02-09 16:41:26 --> Controller Class Initialized
INFO - 2020-02-09 16:41:26 --> Router Class Initialized
INFO - 2020-02-09 16:41:26 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:41:27 --> Output Class Initialized
INFO - 2020-02-09 16:41:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:41:27 --> Security Class Initialized
INFO - 2020-02-09 16:41:27 --> Model "M_pesan" initialized
DEBUG - 2020-02-09 16:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:27 --> Input Class Initialized
INFO - 2020-02-09 16:41:27 --> Helper loaded: form_helper
INFO - 2020-02-09 16:41:27 --> Form Validation Class Initialized
INFO - 2020-02-09 16:41:27 --> Language Class Initialized
ERROR - 2020-02-09 16:41:27 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-09 16:41:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-09 16:41:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-09 16:41:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-09 16:41:27 --> Final output sent to browser
DEBUG - 2020-02-09 16:41:27 --> Total execution time: 2.3560
INFO - 2020-02-09 16:41:27 --> Config Class Initialized
INFO - 2020-02-09 16:41:27 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:41:27 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:27 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:27 --> URI Class Initialized
INFO - 2020-02-09 16:41:27 --> Router Class Initialized
INFO - 2020-02-09 16:41:27 --> Output Class Initialized
INFO - 2020-02-09 16:41:27 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:27 --> Input Class Initialized
INFO - 2020-02-09 16:41:27 --> Language Class Initialized
ERROR - 2020-02-09 16:41:27 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-09 16:41:28 --> Config Class Initialized
INFO - 2020-02-09 16:41:28 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:41:28 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:28 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:28 --> URI Class Initialized
INFO - 2020-02-09 16:41:28 --> Router Class Initialized
INFO - 2020-02-09 16:41:28 --> Output Class Initialized
INFO - 2020-02-09 16:41:28 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:29 --> Input Class Initialized
INFO - 2020-02-09 16:41:29 --> Language Class Initialized
ERROR - 2020-02-09 16:41:29 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-09 16:41:29 --> Config Class Initialized
INFO - 2020-02-09 16:41:29 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:41:29 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:29 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:29 --> URI Class Initialized
INFO - 2020-02-09 16:41:29 --> Router Class Initialized
INFO - 2020-02-09 16:41:29 --> Output Class Initialized
INFO - 2020-02-09 16:41:29 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:29 --> Input Class Initialized
INFO - 2020-02-09 16:41:29 --> Language Class Initialized
ERROR - 2020-02-09 16:41:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-09 16:41:29 --> Config Class Initialized
INFO - 2020-02-09 16:41:29 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:41:29 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:29 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:29 --> URI Class Initialized
INFO - 2020-02-09 16:41:29 --> Router Class Initialized
INFO - 2020-02-09 16:41:29 --> Output Class Initialized
INFO - 2020-02-09 16:41:29 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:29 --> Input Class Initialized
INFO - 2020-02-09 16:41:29 --> Language Class Initialized
ERROR - 2020-02-09 16:41:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:41:29 --> Config Class Initialized
INFO - 2020-02-09 16:41:29 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:41:29 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:29 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:29 --> URI Class Initialized
INFO - 2020-02-09 16:41:29 --> Router Class Initialized
INFO - 2020-02-09 16:41:29 --> Output Class Initialized
INFO - 2020-02-09 16:41:29 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:30 --> Input Class Initialized
INFO - 2020-02-09 16:41:30 --> Language Class Initialized
ERROR - 2020-02-09 16:41:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:41:30 --> Config Class Initialized
INFO - 2020-02-09 16:41:30 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:41:30 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:30 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:30 --> URI Class Initialized
INFO - 2020-02-09 16:41:30 --> Router Class Initialized
INFO - 2020-02-09 16:41:30 --> Output Class Initialized
INFO - 2020-02-09 16:41:30 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:30 --> Input Class Initialized
INFO - 2020-02-09 16:41:30 --> Language Class Initialized
ERROR - 2020-02-09 16:41:30 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-09 16:41:30 --> Config Class Initialized
INFO - 2020-02-09 16:41:30 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:41:30 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:31 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:31 --> URI Class Initialized
INFO - 2020-02-09 16:41:31 --> Router Class Initialized
INFO - 2020-02-09 16:41:31 --> Output Class Initialized
INFO - 2020-02-09 16:41:31 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:31 --> Input Class Initialized
INFO - 2020-02-09 16:41:31 --> Language Class Initialized
ERROR - 2020-02-09 16:41:31 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-09 16:41:31 --> Config Class Initialized
INFO - 2020-02-09 16:41:31 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:41:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:31 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:31 --> URI Class Initialized
INFO - 2020-02-09 16:41:31 --> Router Class Initialized
INFO - 2020-02-09 16:41:31 --> Output Class Initialized
INFO - 2020-02-09 16:41:32 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:32 --> Input Class Initialized
INFO - 2020-02-09 16:41:32 --> Language Class Initialized
ERROR - 2020-02-09 16:41:32 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-09 16:41:32 --> Config Class Initialized
INFO - 2020-02-09 16:41:32 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:41:32 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:41:32 --> Utf8 Class Initialized
INFO - 2020-02-09 16:41:32 --> URI Class Initialized
INFO - 2020-02-09 16:41:32 --> Router Class Initialized
INFO - 2020-02-09 16:41:32 --> Output Class Initialized
INFO - 2020-02-09 16:41:32 --> Security Class Initialized
DEBUG - 2020-02-09 16:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:41:32 --> Input Class Initialized
INFO - 2020-02-09 16:41:32 --> Language Class Initialized
ERROR - 2020-02-09 16:41:32 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-09 16:51:30 --> Config Class Initialized
INFO - 2020-02-09 16:51:31 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:51:31 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:31 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:31 --> URI Class Initialized
DEBUG - 2020-02-09 16:51:32 --> No URI present. Default controller set.
INFO - 2020-02-09 16:51:32 --> Router Class Initialized
INFO - 2020-02-09 16:51:33 --> Output Class Initialized
INFO - 2020-02-09 16:51:33 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:33 --> Input Class Initialized
INFO - 2020-02-09 16:51:33 --> Language Class Initialized
INFO - 2020-02-09 16:51:33 --> Loader Class Initialized
INFO - 2020-02-09 16:51:34 --> Config Class Initialized
INFO - 2020-02-09 16:51:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:51:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:34 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:34 --> Helper loaded: url_helper
INFO - 2020-02-09 16:51:34 --> URI Class Initialized
DEBUG - 2020-02-09 16:51:34 --> No URI present. Default controller set.
INFO - 2020-02-09 16:51:34 --> Router Class Initialized
INFO - 2020-02-09 16:51:34 --> Output Class Initialized
INFO - 2020-02-09 16:51:34 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:34 --> Input Class Initialized
INFO - 2020-02-09 16:51:34 --> Language Class Initialized
INFO - 2020-02-09 16:51:34 --> Loader Class Initialized
INFO - 2020-02-09 16:51:34 --> Helper loaded: url_helper
INFO - 2020-02-09 16:51:34 --> Database Driver Class Initialized
INFO - 2020-02-09 16:51:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-09 16:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:51:34 --> Controller Class Initialized
INFO - 2020-02-09 16:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-09 16:51:35 --> Pagination Class Initialized
INFO - 2020-02-09 16:51:35 --> Model "M_show" initialized
INFO - 2020-02-09 16:51:35 --> Helper loaded: form_helper
INFO - 2020-02-09 16:51:35 --> Form Validation Class Initialized
INFO - 2020-02-09 16:51:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-09 16:51:35 --> Final output sent to browser
DEBUG - 2020-02-09 16:51:35 --> Total execution time: 5.4659
INFO - 2020-02-09 16:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:51:35 --> Controller Class Initialized
INFO - 2020-02-09 16:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-09 16:51:36 --> Pagination Class Initialized
INFO - 2020-02-09 16:51:36 --> Model "M_show" initialized
INFO - 2020-02-09 16:51:36 --> Helper loaded: form_helper
INFO - 2020-02-09 16:51:36 --> Form Validation Class Initialized
INFO - 2020-02-09 16:51:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/show/lihat_show.php
INFO - 2020-02-09 16:51:36 --> Final output sent to browser
DEBUG - 2020-02-09 16:51:36 --> Total execution time: 2.0251
INFO - 2020-02-09 16:51:39 --> Config Class Initialized
INFO - 2020-02-09 16:51:39 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:51:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:40 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:40 --> URI Class Initialized
INFO - 2020-02-09 16:51:40 --> Router Class Initialized
INFO - 2020-02-09 16:51:40 --> Output Class Initialized
INFO - 2020-02-09 16:51:40 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:40 --> Input Class Initialized
INFO - 2020-02-09 16:51:40 --> Language Class Initialized
INFO - 2020-02-09 16:51:40 --> Loader Class Initialized
INFO - 2020-02-09 16:51:40 --> Helper loaded: url_helper
INFO - 2020-02-09 16:51:40 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:51:40 --> Controller Class Initialized
INFO - 2020-02-09 16:51:40 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:51:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:51:40 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:51:40 --> Helper loaded: form_helper
INFO - 2020-02-09 16:51:40 --> Form Validation Class Initialized
INFO - 2020-02-09 16:51:40 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-09 16:51:40 --> Final output sent to browser
DEBUG - 2020-02-09 16:51:40 --> Total execution time: 0.8382
INFO - 2020-02-09 16:51:40 --> Config Class Initialized
INFO - 2020-02-09 16:51:40 --> Config Class Initialized
INFO - 2020-02-09 16:51:40 --> Config Class Initialized
INFO - 2020-02-09 16:51:40 --> Config Class Initialized
INFO - 2020-02-09 16:51:40 --> Hooks Class Initialized
INFO - 2020-02-09 16:51:40 --> Hooks Class Initialized
INFO - 2020-02-09 16:51:40 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:51:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:40 --> Config Class Initialized
INFO - 2020-02-09 16:51:40 --> Config Class Initialized
INFO - 2020-02-09 16:51:40 --> Hooks Class Initialized
INFO - 2020-02-09 16:51:40 --> Hooks Class Initialized
INFO - 2020-02-09 16:51:40 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:40 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:51:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:51:40 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:51:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:40 --> Utf8 Class Initialized
DEBUG - 2020-02-09 16:51:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:40 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:40 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:40 --> URI Class Initialized
DEBUG - 2020-02-09 16:51:40 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:40 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:40 --> URI Class Initialized
INFO - 2020-02-09 16:51:40 --> URI Class Initialized
INFO - 2020-02-09 16:51:40 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:40 --> Router Class Initialized
INFO - 2020-02-09 16:51:40 --> URI Class Initialized
INFO - 2020-02-09 16:51:41 --> URI Class Initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> URI Class Initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
ERROR - 2020-02-09 16:51:41 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
ERROR - 2020-02-09 16:51:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-09 16:51:41 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-09 16:51:41 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-09 16:51:41 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-09 16:51:41 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-09 16:51:41 --> Config Class Initialized
INFO - 2020-02-09 16:51:41 --> Config Class Initialized
INFO - 2020-02-09 16:51:41 --> Config Class Initialized
INFO - 2020-02-09 16:51:41 --> Config Class Initialized
INFO - 2020-02-09 16:51:41 --> Hooks Class Initialized
INFO - 2020-02-09 16:51:41 --> Hooks Class Initialized
INFO - 2020-02-09 16:51:41 --> Hooks Class Initialized
INFO - 2020-02-09 16:51:41 --> Hooks Class Initialized
INFO - 2020-02-09 16:51:41 --> Config Class Initialized
INFO - 2020-02-09 16:51:41 --> Config Class Initialized
INFO - 2020-02-09 16:51:41 --> Hooks Class Initialized
INFO - 2020-02-09 16:51:41 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:51:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:51:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:51:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:51:41 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:41 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:41 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:41 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:41 --> Utf8 Class Initialized
DEBUG - 2020-02-09 16:51:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:51:41 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:41 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:41 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:41 --> URI Class Initialized
INFO - 2020-02-09 16:51:41 --> URI Class Initialized
INFO - 2020-02-09 16:51:41 --> URI Class Initialized
INFO - 2020-02-09 16:51:41 --> URI Class Initialized
INFO - 2020-02-09 16:51:41 --> URI Class Initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> URI Class Initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
ERROR - 2020-02-09 16:51:41 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-09 16:51:41 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
INFO - 2020-02-09 16:51:41 --> Loader Class Initialized
ERROR - 2020-02-09 16:51:41 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-09 16:51:41 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-09 16:51:41 --> Helper loaded: url_helper
INFO - 2020-02-09 16:51:41 --> Loader Class Initialized
INFO - 2020-02-09 16:51:41 --> Config Class Initialized
INFO - 2020-02-09 16:51:41 --> Config Class Initialized
INFO - 2020-02-09 16:51:41 --> Hooks Class Initialized
INFO - 2020-02-09 16:51:41 --> Hooks Class Initialized
INFO - 2020-02-09 16:51:41 --> Helper loaded: url_helper
INFO - 2020-02-09 16:51:41 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:51:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:51:41 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:41 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:51:41 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-09 16:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:51:41 --> Controller Class Initialized
INFO - 2020-02-09 16:51:41 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:41 --> URI Class Initialized
INFO - 2020-02-09 16:51:41 --> URI Class Initialized
INFO - 2020-02-09 16:51:41 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
INFO - 2020-02-09 16:51:41 --> Helper loaded: form_helper
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
INFO - 2020-02-09 16:51:41 --> Form Validation Class Initialized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
ERROR - 2020-02-09 16:51:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
INFO - 2020-02-09 16:51:41 --> Language Class Initialized
ERROR - 2020-02-09 16:51:41 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-09 16:51:41 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-09 16:51:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-09 16:51:41 --> Config Class Initialized
INFO - 2020-02-09 16:51:41 --> Hooks Class Initialized
INFO - 2020-02-09 16:51:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-09 16:51:41 --> Final output sent to browser
DEBUG - 2020-02-09 16:51:41 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:41 --> Utf8 Class Initialized
DEBUG - 2020-02-09 16:51:41 --> Total execution time: 0.6051
INFO - 2020-02-09 16:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:51:41 --> URI Class Initialized
INFO - 2020-02-09 16:51:41 --> Controller Class Initialized
INFO - 2020-02-09 16:51:41 --> Router Class Initialized
INFO - 2020-02-09 16:51:41 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:51:41 --> Output Class Initialized
INFO - 2020-02-09 16:51:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:51:41 --> Security Class Initialized
INFO - 2020-02-09 16:51:41 --> Model "M_pesan" initialized
DEBUG - 2020-02-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:41 --> Input Class Initialized
INFO - 2020-02-09 16:51:42 --> Helper loaded: form_helper
INFO - 2020-02-09 16:51:42 --> Form Validation Class Initialized
INFO - 2020-02-09 16:51:42 --> Language Class Initialized
ERROR - 2020-02-09 16:51:42 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-09 16:51:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 57
ERROR - 2020-02-09 16:51:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-02-09 16:51:42 --> File loaded: C:\xampp\htdocs\roadshow\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-02-09 16:51:42 --> Config Class Initialized
INFO - 2020-02-09 16:51:42 --> Hooks Class Initialized
INFO - 2020-02-09 16:51:42 --> Final output sent to browser
DEBUG - 2020-02-09 16:51:42 --> Total execution time: 0.9107
DEBUG - 2020-02-09 16:51:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:42 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:42 --> URI Class Initialized
INFO - 2020-02-09 16:51:42 --> Router Class Initialized
INFO - 2020-02-09 16:51:42 --> Output Class Initialized
INFO - 2020-02-09 16:51:42 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:42 --> Input Class Initialized
INFO - 2020-02-09 16:51:42 --> Language Class Initialized
ERROR - 2020-02-09 16:51:42 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-09 16:51:42 --> Config Class Initialized
INFO - 2020-02-09 16:51:43 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:51:43 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:43 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:43 --> URI Class Initialized
INFO - 2020-02-09 16:51:43 --> Router Class Initialized
INFO - 2020-02-09 16:51:43 --> Output Class Initialized
INFO - 2020-02-09 16:51:43 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:43 --> Input Class Initialized
INFO - 2020-02-09 16:51:43 --> Language Class Initialized
ERROR - 2020-02-09 16:51:43 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-09 16:51:43 --> Config Class Initialized
INFO - 2020-02-09 16:51:43 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:51:43 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:43 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:43 --> URI Class Initialized
INFO - 2020-02-09 16:51:43 --> Router Class Initialized
INFO - 2020-02-09 16:51:43 --> Output Class Initialized
INFO - 2020-02-09 16:51:43 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:43 --> Input Class Initialized
INFO - 2020-02-09 16:51:43 --> Language Class Initialized
ERROR - 2020-02-09 16:51:43 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:51:43 --> Config Class Initialized
INFO - 2020-02-09 16:51:43 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:51:43 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:43 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:43 --> URI Class Initialized
INFO - 2020-02-09 16:51:43 --> Router Class Initialized
INFO - 2020-02-09 16:51:43 --> Output Class Initialized
INFO - 2020-02-09 16:51:43 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:43 --> Input Class Initialized
INFO - 2020-02-09 16:51:43 --> Language Class Initialized
ERROR - 2020-02-09 16:51:44 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:51:44 --> Config Class Initialized
INFO - 2020-02-09 16:51:44 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:51:44 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:44 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:44 --> URI Class Initialized
INFO - 2020-02-09 16:51:44 --> Router Class Initialized
INFO - 2020-02-09 16:51:44 --> Output Class Initialized
INFO - 2020-02-09 16:51:44 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:44 --> Input Class Initialized
INFO - 2020-02-09 16:51:44 --> Language Class Initialized
ERROR - 2020-02-09 16:51:44 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-09 16:51:44 --> Config Class Initialized
INFO - 2020-02-09 16:51:44 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:51:44 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:44 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:44 --> URI Class Initialized
INFO - 2020-02-09 16:51:44 --> Router Class Initialized
INFO - 2020-02-09 16:51:44 --> Output Class Initialized
INFO - 2020-02-09 16:51:44 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:44 --> Input Class Initialized
INFO - 2020-02-09 16:51:44 --> Language Class Initialized
ERROR - 2020-02-09 16:51:44 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-09 16:51:45 --> Config Class Initialized
INFO - 2020-02-09 16:51:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:51:45 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:45 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:45 --> URI Class Initialized
INFO - 2020-02-09 16:51:45 --> Router Class Initialized
INFO - 2020-02-09 16:51:45 --> Output Class Initialized
INFO - 2020-02-09 16:51:45 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:45 --> Input Class Initialized
INFO - 2020-02-09 16:51:45 --> Language Class Initialized
ERROR - 2020-02-09 16:51:45 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-09 16:51:45 --> Config Class Initialized
INFO - 2020-02-09 16:51:45 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:51:45 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:51:45 --> Utf8 Class Initialized
INFO - 2020-02-09 16:51:45 --> URI Class Initialized
INFO - 2020-02-09 16:51:45 --> Router Class Initialized
INFO - 2020-02-09 16:51:45 --> Output Class Initialized
INFO - 2020-02-09 16:51:45 --> Security Class Initialized
DEBUG - 2020-02-09 16:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:51:45 --> Input Class Initialized
INFO - 2020-02-09 16:51:45 --> Language Class Initialized
ERROR - 2020-02-09 16:51:45 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-09 16:53:34 --> Config Class Initialized
INFO - 2020-02-09 16:53:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:53:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:53:34 --> Utf8 Class Initialized
INFO - 2020-02-09 16:53:34 --> URI Class Initialized
INFO - 2020-02-09 16:53:34 --> Router Class Initialized
INFO - 2020-02-09 16:53:34 --> Output Class Initialized
INFO - 2020-02-09 16:53:34 --> Security Class Initialized
DEBUG - 2020-02-09 16:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:53:34 --> Input Class Initialized
INFO - 2020-02-09 16:53:34 --> Language Class Initialized
INFO - 2020-02-09 16:53:35 --> Loader Class Initialized
INFO - 2020-02-09 16:53:35 --> Helper loaded: url_helper
INFO - 2020-02-09 16:53:35 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:53:35 --> Controller Class Initialized
INFO - 2020-02-09 16:53:35 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:53:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:53:35 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:53:35 --> Helper loaded: form_helper
INFO - 2020-02-09 16:53:35 --> Form Validation Class Initialized
INFO - 2020-02-09 16:54:06 --> Config Class Initialized
INFO - 2020-02-09 16:54:06 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:54:06 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:54:06 --> Utf8 Class Initialized
INFO - 2020-02-09 16:54:06 --> URI Class Initialized
INFO - 2020-02-09 16:54:06 --> Router Class Initialized
INFO - 2020-02-09 16:54:06 --> Output Class Initialized
INFO - 2020-02-09 16:54:06 --> Security Class Initialized
DEBUG - 2020-02-09 16:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:54:06 --> Input Class Initialized
INFO - 2020-02-09 16:54:06 --> Language Class Initialized
INFO - 2020-02-09 16:54:06 --> Loader Class Initialized
INFO - 2020-02-09 16:54:06 --> Helper loaded: url_helper
INFO - 2020-02-09 16:54:06 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:54:06 --> Controller Class Initialized
INFO - 2020-02-09 16:54:06 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:54:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:54:06 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:54:06 --> Helper loaded: form_helper
INFO - 2020-02-09 16:54:06 --> Form Validation Class Initialized
INFO - 2020-02-09 16:54:11 --> Config Class Initialized
INFO - 2020-02-09 16:54:11 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:54:11 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:54:11 --> Utf8 Class Initialized
INFO - 2020-02-09 16:54:11 --> URI Class Initialized
DEBUG - 2020-02-09 16:54:11 --> No URI present. Default controller set.
INFO - 2020-02-09 16:54:11 --> Router Class Initialized
INFO - 2020-02-09 16:54:11 --> Output Class Initialized
INFO - 2020-02-09 16:54:11 --> Security Class Initialized
DEBUG - 2020-02-09 16:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:54:11 --> Input Class Initialized
INFO - 2020-02-09 16:54:11 --> Language Class Initialized
INFO - 2020-02-09 16:54:11 --> Loader Class Initialized
INFO - 2020-02-09 16:54:11 --> Helper loaded: url_helper
INFO - 2020-02-09 16:54:11 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:54:11 --> Controller Class Initialized
INFO - 2020-02-09 16:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-09 16:54:12 --> Pagination Class Initialized
INFO - 2020-02-09 16:54:12 --> Model "M_show" initialized
INFO - 2020-02-09 16:54:12 --> Helper loaded: form_helper
INFO - 2020-02-09 16:54:12 --> Form Validation Class Initialized
INFO - 2020-02-09 16:54:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-09 16:54:12 --> Final output sent to browser
INFO - 2020-02-09 16:54:12 --> Config Class Initialized
INFO - 2020-02-09 16:54:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:54:12 --> Total execution time: 0.6784
DEBUG - 2020-02-09 16:54:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:54:12 --> Utf8 Class Initialized
INFO - 2020-02-09 16:54:12 --> URI Class Initialized
DEBUG - 2020-02-09 16:54:12 --> No URI present. Default controller set.
INFO - 2020-02-09 16:54:12 --> Router Class Initialized
INFO - 2020-02-09 16:54:12 --> Output Class Initialized
INFO - 2020-02-09 16:54:12 --> Security Class Initialized
DEBUG - 2020-02-09 16:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:54:12 --> Input Class Initialized
INFO - 2020-02-09 16:54:12 --> Language Class Initialized
INFO - 2020-02-09 16:54:12 --> Loader Class Initialized
INFO - 2020-02-09 16:54:12 --> Helper loaded: url_helper
INFO - 2020-02-09 16:54:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:54:12 --> Controller Class Initialized
INFO - 2020-02-09 16:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-09 16:54:12 --> Pagination Class Initialized
INFO - 2020-02-09 16:54:12 --> Model "M_show" initialized
INFO - 2020-02-09 16:54:12 --> Helper loaded: form_helper
INFO - 2020-02-09 16:54:12 --> Form Validation Class Initialized
INFO - 2020-02-09 16:54:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-09 16:54:12 --> Final output sent to browser
DEBUG - 2020-02-09 16:54:13 --> Total execution time: 0.7919
INFO - 2020-02-09 16:54:19 --> Config Class Initialized
INFO - 2020-02-09 16:54:19 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:54:19 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:54:19 --> Utf8 Class Initialized
INFO - 2020-02-09 16:54:19 --> URI Class Initialized
INFO - 2020-02-09 16:54:19 --> Router Class Initialized
INFO - 2020-02-09 16:54:19 --> Output Class Initialized
INFO - 2020-02-09 16:54:19 --> Security Class Initialized
DEBUG - 2020-02-09 16:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:54:19 --> Input Class Initialized
INFO - 2020-02-09 16:54:19 --> Language Class Initialized
INFO - 2020-02-09 16:54:19 --> Loader Class Initialized
INFO - 2020-02-09 16:54:19 --> Helper loaded: url_helper
INFO - 2020-02-09 16:54:19 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:54:19 --> Controller Class Initialized
INFO - 2020-02-09 16:54:19 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:54:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:54:20 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:54:20 --> Helper loaded: form_helper
INFO - 2020-02-09 16:54:20 --> Form Validation Class Initialized
INFO - 2020-02-09 16:55:02 --> Config Class Initialized
INFO - 2020-02-09 16:55:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:55:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:02 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:02 --> URI Class Initialized
DEBUG - 2020-02-09 16:55:02 --> No URI present. Default controller set.
INFO - 2020-02-09 16:55:02 --> Router Class Initialized
INFO - 2020-02-09 16:55:02 --> Output Class Initialized
INFO - 2020-02-09 16:55:02 --> Security Class Initialized
DEBUG - 2020-02-09 16:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:02 --> Input Class Initialized
INFO - 2020-02-09 16:55:02 --> Language Class Initialized
INFO - 2020-02-09 16:55:02 --> Loader Class Initialized
INFO - 2020-02-09 16:55:02 --> Helper loaded: url_helper
INFO - 2020-02-09 16:55:02 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:55:02 --> Controller Class Initialized
INFO - 2020-02-09 16:55:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-09 16:55:02 --> Pagination Class Initialized
INFO - 2020-02-09 16:55:02 --> Model "M_show" initialized
INFO - 2020-02-09 16:55:02 --> Helper loaded: form_helper
INFO - 2020-02-09 16:55:02 --> Form Validation Class Initialized
INFO - 2020-02-09 16:55:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-09 16:55:02 --> Final output sent to browser
DEBUG - 2020-02-09 16:55:02 --> Total execution time: 0.4328
INFO - 2020-02-09 16:55:04 --> Config Class Initialized
INFO - 2020-02-09 16:55:04 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:55:04 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:04 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:04 --> URI Class Initialized
INFO - 2020-02-09 16:55:04 --> Router Class Initialized
INFO - 2020-02-09 16:55:04 --> Output Class Initialized
INFO - 2020-02-09 16:55:04 --> Security Class Initialized
DEBUG - 2020-02-09 16:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:04 --> Input Class Initialized
INFO - 2020-02-09 16:55:04 --> Language Class Initialized
INFO - 2020-02-09 16:55:04 --> Loader Class Initialized
INFO - 2020-02-09 16:55:04 --> Helper loaded: url_helper
INFO - 2020-02-09 16:55:04 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:55:04 --> Controller Class Initialized
INFO - 2020-02-09 16:55:04 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:55:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:55:04 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:55:04 --> Helper loaded: form_helper
INFO - 2020-02-09 16:55:04 --> Form Validation Class Initialized
INFO - 2020-02-09 16:55:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-09 16:55:04 --> Final output sent to browser
DEBUG - 2020-02-09 16:55:04 --> Total execution time: 0.6495
INFO - 2020-02-09 16:55:04 --> Config Class Initialized
INFO - 2020-02-09 16:55:04 --> Config Class Initialized
INFO - 2020-02-09 16:55:04 --> Config Class Initialized
INFO - 2020-02-09 16:55:04 --> Config Class Initialized
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
INFO - 2020-02-09 16:55:05 --> Config Class Initialized
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
INFO - 2020-02-09 16:55:05 --> Config Class Initialized
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
ERROR - 2020-02-09 16:55:05 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
ERROR - 2020-02-09 16:55:05 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
ERROR - 2020-02-09 16:55:05 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-09 16:55:05 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-09 16:55:05 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-09 16:55:05 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:55:05 --> Config Class Initialized
INFO - 2020-02-09 16:55:05 --> Config Class Initialized
INFO - 2020-02-09 16:55:05 --> Config Class Initialized
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
INFO - 2020-02-09 16:55:05 --> Config Class Initialized
INFO - 2020-02-09 16:55:05 --> Config Class Initialized
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:05 --> Config Class Initialized
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
ERROR - 2020-02-09 16:55:05 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-09 16:55:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-09 16:55:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
ERROR - 2020-02-09 16:55:05 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
INFO - 2020-02-09 16:55:05 --> Config Class Initialized
INFO - 2020-02-09 16:55:05 --> Config Class Initialized
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
INFO - 2020-02-09 16:55:05 --> Loader Class Initialized
INFO - 2020-02-09 16:55:05 --> Loader Class Initialized
INFO - 2020-02-09 16:55:05 --> Helper loaded: url_helper
INFO - 2020-02-09 16:55:05 --> Helper loaded: url_helper
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:05 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:05 --> Database Driver Class Initialized
INFO - 2020-02-09 16:55:05 --> Database Driver Class Initialized
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
INFO - 2020-02-09 16:55:05 --> URI Class Initialized
DEBUG - 2020-02-09 16:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-09 16:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
INFO - 2020-02-09 16:55:05 --> Router Class Initialized
INFO - 2020-02-09 16:55:05 --> Controller Class Initialized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
INFO - 2020-02-09 16:55:05 --> Output Class Initialized
INFO - 2020-02-09 16:55:05 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
INFO - 2020-02-09 16:55:05 --> Security Class Initialized
INFO - 2020-02-09 16:55:05 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
INFO - 2020-02-09 16:55:05 --> Input Class Initialized
INFO - 2020-02-09 16:55:05 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
INFO - 2020-02-09 16:55:05 --> Language Class Initialized
INFO - 2020-02-09 16:55:05 --> Helper loaded: form_helper
INFO - 2020-02-09 16:55:05 --> Form Validation Class Initialized
ERROR - 2020-02-09 16:55:05 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-09 16:55:05 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-09 16:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-09 16:55:05 --> Config Class Initialized
INFO - 2020-02-09 16:55:05 --> Hooks Class Initialized
ERROR - 2020-02-09 16:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-09 16:55:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-09 16:55:05 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:06 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:06 --> Final output sent to browser
DEBUG - 2020-02-09 16:55:06 --> Total execution time: 0.6492
INFO - 2020-02-09 16:55:06 --> URI Class Initialized
INFO - 2020-02-09 16:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:55:06 --> Router Class Initialized
INFO - 2020-02-09 16:55:06 --> Controller Class Initialized
INFO - 2020-02-09 16:55:06 --> Output Class Initialized
INFO - 2020-02-09 16:55:06 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:55:06 --> Security Class Initialized
INFO - 2020-02-09 16:55:06 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-09 16:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:06 --> Input Class Initialized
INFO - 2020-02-09 16:55:06 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:55:06 --> Language Class Initialized
INFO - 2020-02-09 16:55:06 --> Helper loaded: form_helper
INFO - 2020-02-09 16:55:06 --> Form Validation Class Initialized
ERROR - 2020-02-09 16:55:06 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-09 16:55:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-09 16:55:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-09 16:55:06 --> Config Class Initialized
INFO - 2020-02-09 16:55:06 --> Hooks Class Initialized
INFO - 2020-02-09 16:55:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-09 16:55:06 --> Final output sent to browser
DEBUG - 2020-02-09 16:55:06 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:06 --> Utf8 Class Initialized
DEBUG - 2020-02-09 16:55:06 --> Total execution time: 0.9195
INFO - 2020-02-09 16:55:06 --> URI Class Initialized
INFO - 2020-02-09 16:55:06 --> Router Class Initialized
INFO - 2020-02-09 16:55:06 --> Output Class Initialized
INFO - 2020-02-09 16:55:06 --> Security Class Initialized
DEBUG - 2020-02-09 16:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:06 --> Input Class Initialized
INFO - 2020-02-09 16:55:06 --> Language Class Initialized
ERROR - 2020-02-09 16:55:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-09 16:55:06 --> Config Class Initialized
INFO - 2020-02-09 16:55:06 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:55:06 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:06 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:06 --> URI Class Initialized
INFO - 2020-02-09 16:55:06 --> Router Class Initialized
INFO - 2020-02-09 16:55:06 --> Output Class Initialized
INFO - 2020-02-09 16:55:06 --> Security Class Initialized
DEBUG - 2020-02-09 16:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:06 --> Input Class Initialized
INFO - 2020-02-09 16:55:06 --> Language Class Initialized
ERROR - 2020-02-09 16:55:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-09 16:55:06 --> Config Class Initialized
INFO - 2020-02-09 16:55:06 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:55:06 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:06 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:06 --> URI Class Initialized
INFO - 2020-02-09 16:55:06 --> Router Class Initialized
INFO - 2020-02-09 16:55:06 --> Output Class Initialized
INFO - 2020-02-09 16:55:06 --> Security Class Initialized
DEBUG - 2020-02-09 16:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:07 --> Input Class Initialized
INFO - 2020-02-09 16:55:07 --> Language Class Initialized
ERROR - 2020-02-09 16:55:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:55:07 --> Config Class Initialized
INFO - 2020-02-09 16:55:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:55:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:07 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:07 --> URI Class Initialized
INFO - 2020-02-09 16:55:07 --> Router Class Initialized
INFO - 2020-02-09 16:55:07 --> Output Class Initialized
INFO - 2020-02-09 16:55:07 --> Security Class Initialized
DEBUG - 2020-02-09 16:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:07 --> Input Class Initialized
INFO - 2020-02-09 16:55:07 --> Language Class Initialized
ERROR - 2020-02-09 16:55:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:55:07 --> Config Class Initialized
INFO - 2020-02-09 16:55:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:55:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:07 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:07 --> URI Class Initialized
INFO - 2020-02-09 16:55:07 --> Router Class Initialized
INFO - 2020-02-09 16:55:07 --> Output Class Initialized
INFO - 2020-02-09 16:55:07 --> Security Class Initialized
DEBUG - 2020-02-09 16:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:07 --> Input Class Initialized
INFO - 2020-02-09 16:55:07 --> Language Class Initialized
ERROR - 2020-02-09 16:55:07 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-09 16:55:07 --> Config Class Initialized
INFO - 2020-02-09 16:55:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:55:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:07 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:07 --> URI Class Initialized
INFO - 2020-02-09 16:55:07 --> Router Class Initialized
INFO - 2020-02-09 16:55:07 --> Output Class Initialized
INFO - 2020-02-09 16:55:07 --> Security Class Initialized
DEBUG - 2020-02-09 16:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:07 --> Input Class Initialized
INFO - 2020-02-09 16:55:07 --> Language Class Initialized
ERROR - 2020-02-09 16:55:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-09 16:55:07 --> Config Class Initialized
INFO - 2020-02-09 16:55:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:55:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:07 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:07 --> URI Class Initialized
INFO - 2020-02-09 16:55:07 --> Router Class Initialized
INFO - 2020-02-09 16:55:07 --> Output Class Initialized
INFO - 2020-02-09 16:55:07 --> Security Class Initialized
DEBUG - 2020-02-09 16:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:07 --> Input Class Initialized
INFO - 2020-02-09 16:55:07 --> Language Class Initialized
ERROR - 2020-02-09 16:55:07 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-09 16:55:07 --> Config Class Initialized
INFO - 2020-02-09 16:55:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:55:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:55:08 --> Utf8 Class Initialized
INFO - 2020-02-09 16:55:08 --> URI Class Initialized
INFO - 2020-02-09 16:55:08 --> Router Class Initialized
INFO - 2020-02-09 16:55:08 --> Output Class Initialized
INFO - 2020-02-09 16:55:08 --> Security Class Initialized
DEBUG - 2020-02-09 16:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:55:08 --> Input Class Initialized
INFO - 2020-02-09 16:55:08 --> Language Class Initialized
ERROR - 2020-02-09 16:55:08 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-09 16:56:00 --> Config Class Initialized
INFO - 2020-02-09 16:56:01 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:56:01 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:01 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:01 --> URI Class Initialized
INFO - 2020-02-09 16:56:01 --> Router Class Initialized
INFO - 2020-02-09 16:56:01 --> Output Class Initialized
INFO - 2020-02-09 16:56:01 --> Security Class Initialized
DEBUG - 2020-02-09 16:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:01 --> Input Class Initialized
INFO - 2020-02-09 16:56:01 --> Language Class Initialized
INFO - 2020-02-09 16:56:01 --> Loader Class Initialized
INFO - 2020-02-09 16:56:01 --> Helper loaded: url_helper
INFO - 2020-02-09 16:56:01 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:56:01 --> Controller Class Initialized
INFO - 2020-02-09 16:56:01 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:56:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:56:01 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:56:01 --> Helper loaded: form_helper
INFO - 2020-02-09 16:56:01 --> Form Validation Class Initialized
INFO - 2020-02-09 16:56:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-09 16:56:01 --> Final output sent to browser
DEBUG - 2020-02-09 16:56:01 --> Total execution time: 0.5474
INFO - 2020-02-09 16:56:01 --> Config Class Initialized
INFO - 2020-02-09 16:56:01 --> Config Class Initialized
INFO - 2020-02-09 16:56:01 --> Hooks Class Initialized
INFO - 2020-02-09 16:56:01 --> Hooks Class Initialized
INFO - 2020-02-09 16:56:01 --> Config Class Initialized
INFO - 2020-02-09 16:56:01 --> Config Class Initialized
INFO - 2020-02-09 16:56:01 --> Config Class Initialized
INFO - 2020-02-09 16:56:01 --> Config Class Initialized
INFO - 2020-02-09 16:56:01 --> Hooks Class Initialized
INFO - 2020-02-09 16:56:01 --> Hooks Class Initialized
INFO - 2020-02-09 16:56:01 --> Hooks Class Initialized
INFO - 2020-02-09 16:56:01 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:56:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:56:01 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:01 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:01 --> Utf8 Class Initialized
DEBUG - 2020-02-09 16:56:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:56:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:56:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:56:01 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:01 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:01 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:01 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:01 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:01 --> URI Class Initialized
INFO - 2020-02-09 16:56:01 --> URI Class Initialized
INFO - 2020-02-09 16:56:01 --> URI Class Initialized
INFO - 2020-02-09 16:56:01 --> URI Class Initialized
INFO - 2020-02-09 16:56:01 --> URI Class Initialized
INFO - 2020-02-09 16:56:01 --> Router Class Initialized
INFO - 2020-02-09 16:56:01 --> URI Class Initialized
INFO - 2020-02-09 16:56:01 --> Router Class Initialized
INFO - 2020-02-09 16:56:01 --> Router Class Initialized
INFO - 2020-02-09 16:56:01 --> Router Class Initialized
INFO - 2020-02-09 16:56:01 --> Output Class Initialized
INFO - 2020-02-09 16:56:01 --> Router Class Initialized
INFO - 2020-02-09 16:56:01 --> Output Class Initialized
INFO - 2020-02-09 16:56:01 --> Router Class Initialized
INFO - 2020-02-09 16:56:01 --> Security Class Initialized
INFO - 2020-02-09 16:56:01 --> Output Class Initialized
INFO - 2020-02-09 16:56:01 --> Output Class Initialized
INFO - 2020-02-09 16:56:01 --> Output Class Initialized
INFO - 2020-02-09 16:56:01 --> Security Class Initialized
INFO - 2020-02-09 16:56:01 --> Output Class Initialized
DEBUG - 2020-02-09 16:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:01 --> Security Class Initialized
INFO - 2020-02-09 16:56:01 --> Security Class Initialized
INFO - 2020-02-09 16:56:01 --> Security Class Initialized
INFO - 2020-02-09 16:56:01 --> Security Class Initialized
DEBUG - 2020-02-09 16:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:01 --> Input Class Initialized
INFO - 2020-02-09 16:56:01 --> Input Class Initialized
DEBUG - 2020-02-09 16:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:01 --> Input Class Initialized
INFO - 2020-02-09 16:56:01 --> Input Class Initialized
INFO - 2020-02-09 16:56:01 --> Input Class Initialized
INFO - 2020-02-09 16:56:01 --> Input Class Initialized
INFO - 2020-02-09 16:56:01 --> Language Class Initialized
INFO - 2020-02-09 16:56:01 --> Language Class Initialized
INFO - 2020-02-09 16:56:01 --> Language Class Initialized
INFO - 2020-02-09 16:56:01 --> Language Class Initialized
ERROR - 2020-02-09 16:56:01 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-09 16:56:01 --> Language Class Initialized
INFO - 2020-02-09 16:56:01 --> Language Class Initialized
INFO - 2020-02-09 16:56:01 --> Loader Class Initialized
INFO - 2020-02-09 16:56:01 --> Helper loaded: url_helper
ERROR - 2020-02-09 16:56:01 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-09 16:56:01 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-09 16:56:01 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-09 16:56:01 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-09 16:56:01 --> Config Class Initialized
INFO - 2020-02-09 16:56:01 --> Hooks Class Initialized
INFO - 2020-02-09 16:56:01 --> Config Class Initialized
INFO - 2020-02-09 16:56:01 --> Database Driver Class Initialized
INFO - 2020-02-09 16:56:01 --> Config Class Initialized
INFO - 2020-02-09 16:56:01 --> Config Class Initialized
INFO - 2020-02-09 16:56:01 --> Hooks Class Initialized
INFO - 2020-02-09 16:56:01 --> Hooks Class Initialized
INFO - 2020-02-09 16:56:01 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-09 16:56:01 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:01 --> Config Class Initialized
INFO - 2020-02-09 16:56:01 --> Hooks Class Initialized
INFO - 2020-02-09 16:56:01 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-09 16:56:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:56:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:56:01 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:01 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:01 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:01 --> Controller Class Initialized
INFO - 2020-02-09 16:56:01 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:01 --> URI Class Initialized
DEBUG - 2020-02-09 16:56:01 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:01 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:01 --> URI Class Initialized
INFO - 2020-02-09 16:56:01 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:56:01 --> URI Class Initialized
INFO - 2020-02-09 16:56:01 --> Router Class Initialized
INFO - 2020-02-09 16:56:01 --> URI Class Initialized
INFO - 2020-02-09 16:56:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:56:01 --> URI Class Initialized
INFO - 2020-02-09 16:56:01 --> Router Class Initialized
INFO - 2020-02-09 16:56:01 --> Output Class Initialized
INFO - 2020-02-09 16:56:01 --> Router Class Initialized
INFO - 2020-02-09 16:56:01 --> Router Class Initialized
INFO - 2020-02-09 16:56:02 --> Security Class Initialized
INFO - 2020-02-09 16:56:02 --> Router Class Initialized
INFO - 2020-02-09 16:56:02 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:56:02 --> Output Class Initialized
INFO - 2020-02-09 16:56:02 --> Output Class Initialized
INFO - 2020-02-09 16:56:02 --> Output Class Initialized
DEBUG - 2020-02-09 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:02 --> Output Class Initialized
INFO - 2020-02-09 16:56:02 --> Security Class Initialized
INFO - 2020-02-09 16:56:02 --> Security Class Initialized
INFO - 2020-02-09 16:56:02 --> Helper loaded: form_helper
INFO - 2020-02-09 16:56:02 --> Security Class Initialized
INFO - 2020-02-09 16:56:02 --> Input Class Initialized
INFO - 2020-02-09 16:56:02 --> Form Validation Class Initialized
DEBUG - 2020-02-09 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:02 --> Security Class Initialized
DEBUG - 2020-02-09 16:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:02 --> Input Class Initialized
INFO - 2020-02-09 16:56:02 --> Input Class Initialized
INFO - 2020-02-09 16:56:02 --> Input Class Initialized
INFO - 2020-02-09 16:56:02 --> Language Class Initialized
DEBUG - 2020-02-09 16:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-09 16:56:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-09 16:56:02 --> Input Class Initialized
ERROR - 2020-02-09 16:56:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-09 16:56:02 --> Language Class Initialized
INFO - 2020-02-09 16:56:02 --> Language Class Initialized
ERROR - 2020-02-09 16:56:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:56:02 --> Language Class Initialized
INFO - 2020-02-09 16:56:02 --> Language Class Initialized
ERROR - 2020-02-09 16:56:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-09 16:56:02 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-09 16:56:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:56:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-09 16:56:02 --> Config Class Initialized
INFO - 2020-02-09 16:56:02 --> Final output sent to browser
INFO - 2020-02-09 16:56:02 --> Hooks Class Initialized
ERROR - 2020-02-09 16:56:02 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-09 16:56:02 --> Config Class Initialized
INFO - 2020-02-09 16:56:02 --> Config Class Initialized
INFO - 2020-02-09 16:56:02 --> Hooks Class Initialized
INFO - 2020-02-09 16:56:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:56:02 --> Total execution time: 0.5789
DEBUG - 2020-02-09 16:56:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:02 --> Utf8 Class Initialized
DEBUG - 2020-02-09 16:56:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:56:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:02 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:02 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:02 --> URI Class Initialized
INFO - 2020-02-09 16:56:02 --> URI Class Initialized
INFO - 2020-02-09 16:56:02 --> URI Class Initialized
INFO - 2020-02-09 16:56:02 --> Router Class Initialized
INFO - 2020-02-09 16:56:02 --> Router Class Initialized
INFO - 2020-02-09 16:56:02 --> Router Class Initialized
INFO - 2020-02-09 16:56:02 --> Output Class Initialized
INFO - 2020-02-09 16:56:02 --> Output Class Initialized
INFO - 2020-02-09 16:56:02 --> Security Class Initialized
INFO - 2020-02-09 16:56:02 --> Output Class Initialized
DEBUG - 2020-02-09 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:02 --> Security Class Initialized
INFO - 2020-02-09 16:56:02 --> Security Class Initialized
INFO - 2020-02-09 16:56:02 --> Input Class Initialized
DEBUG - 2020-02-09 16:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:02 --> Input Class Initialized
INFO - 2020-02-09 16:56:02 --> Input Class Initialized
INFO - 2020-02-09 16:56:02 --> Language Class Initialized
INFO - 2020-02-09 16:56:02 --> Language Class Initialized
INFO - 2020-02-09 16:56:02 --> Language Class Initialized
ERROR - 2020-02-09 16:56:02 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-09 16:56:02 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-09 16:56:02 --> Loader Class Initialized
INFO - 2020-02-09 16:56:02 --> Helper loaded: url_helper
INFO - 2020-02-09 16:56:02 --> Config Class Initialized
INFO - 2020-02-09 16:56:02 --> Hooks Class Initialized
INFO - 2020-02-09 16:56:02 --> Database Driver Class Initialized
DEBUG - 2020-02-09 16:56:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 16:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 16:56:02 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 16:56:02 --> Controller Class Initialized
INFO - 2020-02-09 16:56:02 --> URI Class Initialized
INFO - 2020-02-09 16:56:02 --> Model "M_tiket" initialized
INFO - 2020-02-09 16:56:02 --> Router Class Initialized
INFO - 2020-02-09 16:56:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 16:56:02 --> Output Class Initialized
INFO - 2020-02-09 16:56:02 --> Model "M_pesan" initialized
INFO - 2020-02-09 16:56:02 --> Security Class Initialized
DEBUG - 2020-02-09 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:02 --> Helper loaded: form_helper
INFO - 2020-02-09 16:56:02 --> Input Class Initialized
INFO - 2020-02-09 16:56:02 --> Form Validation Class Initialized
INFO - 2020-02-09 16:56:02 --> Language Class Initialized
ERROR - 2020-02-09 16:56:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-09 16:56:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-09 16:56:02 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-09 16:56:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-09 16:56:02 --> Config Class Initialized
INFO - 2020-02-09 16:56:02 --> Final output sent to browser
DEBUG - 2020-02-09 16:56:02 --> Total execution time: 0.4362
INFO - 2020-02-09 16:56:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:56:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:02 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:02 --> URI Class Initialized
INFO - 2020-02-09 16:56:02 --> Router Class Initialized
INFO - 2020-02-09 16:56:02 --> Output Class Initialized
INFO - 2020-02-09 16:56:02 --> Security Class Initialized
DEBUG - 2020-02-09 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:02 --> Input Class Initialized
INFO - 2020-02-09 16:56:02 --> Language Class Initialized
ERROR - 2020-02-09 16:56:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-09 16:56:02 --> Config Class Initialized
INFO - 2020-02-09 16:56:02 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:56:02 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:02 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:02 --> URI Class Initialized
INFO - 2020-02-09 16:56:02 --> Router Class Initialized
INFO - 2020-02-09 16:56:02 --> Output Class Initialized
INFO - 2020-02-09 16:56:02 --> Security Class Initialized
DEBUG - 2020-02-09 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:02 --> Input Class Initialized
INFO - 2020-02-09 16:56:02 --> Language Class Initialized
ERROR - 2020-02-09 16:56:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:56:03 --> Config Class Initialized
INFO - 2020-02-09 16:56:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:56:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:03 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:03 --> URI Class Initialized
INFO - 2020-02-09 16:56:03 --> Router Class Initialized
INFO - 2020-02-09 16:56:03 --> Output Class Initialized
INFO - 2020-02-09 16:56:03 --> Security Class Initialized
DEBUG - 2020-02-09 16:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:03 --> Input Class Initialized
INFO - 2020-02-09 16:56:03 --> Language Class Initialized
ERROR - 2020-02-09 16:56:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 16:56:03 --> Config Class Initialized
INFO - 2020-02-09 16:56:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:56:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:03 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:03 --> URI Class Initialized
INFO - 2020-02-09 16:56:03 --> Router Class Initialized
INFO - 2020-02-09 16:56:03 --> Output Class Initialized
INFO - 2020-02-09 16:56:03 --> Security Class Initialized
DEBUG - 2020-02-09 16:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:03 --> Input Class Initialized
INFO - 2020-02-09 16:56:03 --> Language Class Initialized
ERROR - 2020-02-09 16:56:03 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-09 16:56:03 --> Config Class Initialized
INFO - 2020-02-09 16:56:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:56:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:03 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:03 --> URI Class Initialized
INFO - 2020-02-09 16:56:03 --> Router Class Initialized
INFO - 2020-02-09 16:56:03 --> Output Class Initialized
INFO - 2020-02-09 16:56:03 --> Security Class Initialized
DEBUG - 2020-02-09 16:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:03 --> Input Class Initialized
INFO - 2020-02-09 16:56:03 --> Language Class Initialized
ERROR - 2020-02-09 16:56:03 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-09 16:56:03 --> Config Class Initialized
INFO - 2020-02-09 16:56:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:56:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:03 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:03 --> URI Class Initialized
INFO - 2020-02-09 16:56:03 --> Router Class Initialized
INFO - 2020-02-09 16:56:03 --> Output Class Initialized
INFO - 2020-02-09 16:56:03 --> Security Class Initialized
DEBUG - 2020-02-09 16:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:03 --> Input Class Initialized
INFO - 2020-02-09 16:56:03 --> Language Class Initialized
ERROR - 2020-02-09 16:56:03 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-09 16:56:03 --> Config Class Initialized
INFO - 2020-02-09 16:56:03 --> Hooks Class Initialized
DEBUG - 2020-02-09 16:56:03 --> UTF-8 Support Enabled
INFO - 2020-02-09 16:56:03 --> Utf8 Class Initialized
INFO - 2020-02-09 16:56:04 --> URI Class Initialized
INFO - 2020-02-09 16:56:04 --> Router Class Initialized
INFO - 2020-02-09 16:56:04 --> Output Class Initialized
INFO - 2020-02-09 16:56:04 --> Security Class Initialized
DEBUG - 2020-02-09 16:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 16:56:04 --> Input Class Initialized
INFO - 2020-02-09 16:56:04 --> Language Class Initialized
ERROR - 2020-02-09 16:56:04 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-09 17:00:06 --> Config Class Initialized
INFO - 2020-02-09 17:00:06 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:06 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:06 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:06 --> URI Class Initialized
INFO - 2020-02-09 17:00:06 --> Router Class Initialized
INFO - 2020-02-09 17:00:06 --> Output Class Initialized
INFO - 2020-02-09 17:00:06 --> Security Class Initialized
DEBUG - 2020-02-09 17:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:06 --> Input Class Initialized
INFO - 2020-02-09 17:00:06 --> Language Class Initialized
INFO - 2020-02-09 17:00:06 --> Loader Class Initialized
INFO - 2020-02-09 17:00:06 --> Helper loaded: url_helper
INFO - 2020-02-09 17:00:06 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:00:06 --> Controller Class Initialized
INFO - 2020-02-09 17:00:06 --> Model "M_tiket" initialized
INFO - 2020-02-09 17:00:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 17:00:06 --> Model "M_pesan" initialized
INFO - 2020-02-09 17:00:06 --> Helper loaded: form_helper
INFO - 2020-02-09 17:00:06 --> Form Validation Class Initialized
INFO - 2020-02-09 17:00:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-09 17:00:06 --> Final output sent to browser
DEBUG - 2020-02-09 17:00:06 --> Total execution time: 0.4030
INFO - 2020-02-09 17:00:06 --> Config Class Initialized
INFO - 2020-02-09 17:00:06 --> Hooks Class Initialized
INFO - 2020-02-09 17:00:06 --> Config Class Initialized
INFO - 2020-02-09 17:00:06 --> Config Class Initialized
INFO - 2020-02-09 17:00:06 --> Config Class Initialized
INFO - 2020-02-09 17:00:06 --> Config Class Initialized
INFO - 2020-02-09 17:00:06 --> Config Class Initialized
INFO - 2020-02-09 17:00:06 --> Hooks Class Initialized
INFO - 2020-02-09 17:00:06 --> Hooks Class Initialized
INFO - 2020-02-09 17:00:06 --> Hooks Class Initialized
INFO - 2020-02-09 17:00:06 --> Hooks Class Initialized
INFO - 2020-02-09 17:00:06 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:06 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:06 --> Utf8 Class Initialized
DEBUG - 2020-02-09 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 17:00:06 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:06 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:06 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:06 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:06 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:06 --> URI Class Initialized
INFO - 2020-02-09 17:00:06 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:06 --> URI Class Initialized
INFO - 2020-02-09 17:00:06 --> URI Class Initialized
INFO - 2020-02-09 17:00:06 --> URI Class Initialized
INFO - 2020-02-09 17:00:06 --> Router Class Initialized
INFO - 2020-02-09 17:00:06 --> URI Class Initialized
INFO - 2020-02-09 17:00:06 --> URI Class Initialized
INFO - 2020-02-09 17:00:06 --> Router Class Initialized
INFO - 2020-02-09 17:00:06 --> Output Class Initialized
INFO - 2020-02-09 17:00:06 --> Router Class Initialized
INFO - 2020-02-09 17:00:06 --> Router Class Initialized
INFO - 2020-02-09 17:00:06 --> Router Class Initialized
INFO - 2020-02-09 17:00:06 --> Router Class Initialized
INFO - 2020-02-09 17:00:06 --> Security Class Initialized
INFO - 2020-02-09 17:00:06 --> Output Class Initialized
INFO - 2020-02-09 17:00:06 --> Output Class Initialized
INFO - 2020-02-09 17:00:06 --> Output Class Initialized
INFO - 2020-02-09 17:00:06 --> Output Class Initialized
INFO - 2020-02-09 17:00:06 --> Output Class Initialized
INFO - 2020-02-09 17:00:06 --> Security Class Initialized
INFO - 2020-02-09 17:00:06 --> Security Class Initialized
INFO - 2020-02-09 17:00:06 --> Security Class Initialized
INFO - 2020-02-09 17:00:06 --> Security Class Initialized
INFO - 2020-02-09 17:00:06 --> Security Class Initialized
DEBUG - 2020-02-09 17:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:06 --> Input Class Initialized
DEBUG - 2020-02-09 17:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 17:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 17:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 17:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 17:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:06 --> Input Class Initialized
INFO - 2020-02-09 17:00:06 --> Input Class Initialized
INFO - 2020-02-09 17:00:06 --> Input Class Initialized
INFO - 2020-02-09 17:00:06 --> Input Class Initialized
INFO - 2020-02-09 17:00:06 --> Input Class Initialized
INFO - 2020-02-09 17:00:06 --> Language Class Initialized
INFO - 2020-02-09 17:00:06 --> Language Class Initialized
INFO - 2020-02-09 17:00:06 --> Language Class Initialized
INFO - 2020-02-09 17:00:06 --> Language Class Initialized
ERROR - 2020-02-09 17:00:06 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-09 17:00:06 --> Language Class Initialized
INFO - 2020-02-09 17:00:06 --> Language Class Initialized
ERROR - 2020-02-09 17:00:06 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-09 17:00:06 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-09 17:00:06 --> Loader Class Initialized
INFO - 2020-02-09 17:00:06 --> Loader Class Initialized
ERROR - 2020-02-09 17:00:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-09 17:00:06 --> Config Class Initialized
INFO - 2020-02-09 17:00:06 --> Hooks Class Initialized
INFO - 2020-02-09 17:00:06 --> Helper loaded: url_helper
INFO - 2020-02-09 17:00:06 --> Helper loaded: url_helper
INFO - 2020-02-09 17:00:06 --> Config Class Initialized
INFO - 2020-02-09 17:00:06 --> Config Class Initialized
INFO - 2020-02-09 17:00:06 --> Config Class Initialized
INFO - 2020-02-09 17:00:06 --> Hooks Class Initialized
INFO - 2020-02-09 17:00:06 --> Hooks Class Initialized
INFO - 2020-02-09 17:00:06 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:06 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:06 --> Database Driver Class Initialized
INFO - 2020-02-09 17:00:06 --> Database Driver Class Initialized
INFO - 2020-02-09 17:00:06 --> Utf8 Class Initialized
DEBUG - 2020-02-09 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 17:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-09 17:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:00:06 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:06 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:00:06 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:06 --> URI Class Initialized
INFO - 2020-02-09 17:00:06 --> Controller Class Initialized
INFO - 2020-02-09 17:00:06 --> URI Class Initialized
INFO - 2020-02-09 17:00:07 --> URI Class Initialized
INFO - 2020-02-09 17:00:07 --> URI Class Initialized
INFO - 2020-02-09 17:00:07 --> Router Class Initialized
INFO - 2020-02-09 17:00:07 --> Model "M_tiket" initialized
INFO - 2020-02-09 17:00:07 --> Router Class Initialized
INFO - 2020-02-09 17:00:07 --> Router Class Initialized
INFO - 2020-02-09 17:00:07 --> Output Class Initialized
INFO - 2020-02-09 17:00:07 --> Router Class Initialized
INFO - 2020-02-09 17:00:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 17:00:07 --> Security Class Initialized
INFO - 2020-02-09 17:00:07 --> Output Class Initialized
INFO - 2020-02-09 17:00:07 --> Output Class Initialized
INFO - 2020-02-09 17:00:07 --> Output Class Initialized
INFO - 2020-02-09 17:00:07 --> Model "M_pesan" initialized
DEBUG - 2020-02-09 17:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:07 --> Security Class Initialized
INFO - 2020-02-09 17:00:07 --> Security Class Initialized
INFO - 2020-02-09 17:00:07 --> Security Class Initialized
INFO - 2020-02-09 17:00:07 --> Input Class Initialized
DEBUG - 2020-02-09 17:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 17:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 17:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:07 --> Helper loaded: form_helper
INFO - 2020-02-09 17:00:07 --> Input Class Initialized
INFO - 2020-02-09 17:00:07 --> Form Validation Class Initialized
INFO - 2020-02-09 17:00:07 --> Language Class Initialized
INFO - 2020-02-09 17:00:07 --> Input Class Initialized
INFO - 2020-02-09 17:00:07 --> Input Class Initialized
INFO - 2020-02-09 17:00:07 --> Language Class Initialized
INFO - 2020-02-09 17:00:07 --> Language Class Initialized
INFO - 2020-02-09 17:00:07 --> Language Class Initialized
ERROR - 2020-02-09 17:00:07 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-09 17:00:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-09 17:00:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-09 17:00:07 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-09 17:00:07 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-09 17:00:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 17:00:07 --> Config Class Initialized
INFO - 2020-02-09 17:00:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-09 17:00:07 --> Hooks Class Initialized
INFO - 2020-02-09 17:00:07 --> Config Class Initialized
INFO - 2020-02-09 17:00:07 --> Config Class Initialized
INFO - 2020-02-09 17:00:07 --> Config Class Initialized
INFO - 2020-02-09 17:00:07 --> Hooks Class Initialized
INFO - 2020-02-09 17:00:07 --> Hooks Class Initialized
INFO - 2020-02-09 17:00:07 --> Final output sent to browser
INFO - 2020-02-09 17:00:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:07 --> Utf8 Class Initialized
DEBUG - 2020-02-09 17:00:07 --> Total execution time: 0.6467
DEBUG - 2020-02-09 17:00:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 17:00:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 17:00:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:07 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:07 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:07 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:00:07 --> URI Class Initialized
INFO - 2020-02-09 17:00:07 --> Controller Class Initialized
INFO - 2020-02-09 17:00:07 --> URI Class Initialized
INFO - 2020-02-09 17:00:07 --> URI Class Initialized
INFO - 2020-02-09 17:00:07 --> URI Class Initialized
INFO - 2020-02-09 17:00:07 --> Router Class Initialized
INFO - 2020-02-09 17:00:07 --> Model "M_tiket" initialized
INFO - 2020-02-09 17:00:07 --> Router Class Initialized
INFO - 2020-02-09 17:00:07 --> Router Class Initialized
INFO - 2020-02-09 17:00:07 --> Output Class Initialized
INFO - 2020-02-09 17:00:07 --> Router Class Initialized
INFO - 2020-02-09 17:00:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 17:00:07 --> Security Class Initialized
INFO - 2020-02-09 17:00:07 --> Output Class Initialized
INFO - 2020-02-09 17:00:07 --> Output Class Initialized
INFO - 2020-02-09 17:00:07 --> Output Class Initialized
INFO - 2020-02-09 17:00:07 --> Model "M_pesan" initialized
DEBUG - 2020-02-09 17:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:07 --> Security Class Initialized
INFO - 2020-02-09 17:00:07 --> Security Class Initialized
INFO - 2020-02-09 17:00:07 --> Security Class Initialized
INFO - 2020-02-09 17:00:07 --> Input Class Initialized
DEBUG - 2020-02-09 17:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 17:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 17:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:07 --> Helper loaded: form_helper
INFO - 2020-02-09 17:00:07 --> Input Class Initialized
INFO - 2020-02-09 17:00:07 --> Input Class Initialized
INFO - 2020-02-09 17:00:07 --> Input Class Initialized
INFO - 2020-02-09 17:00:07 --> Form Validation Class Initialized
INFO - 2020-02-09 17:00:07 --> Language Class Initialized
INFO - 2020-02-09 17:00:07 --> Language Class Initialized
INFO - 2020-02-09 17:00:07 --> Language Class Initialized
ERROR - 2020-02-09 17:00:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-09 17:00:07 --> Language Class Initialized
ERROR - 2020-02-09 17:00:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-09 17:00:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-09 17:00:07 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-09 17:00:07 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-09 17:00:07 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-09 17:00:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-09 17:00:07 --> Config Class Initialized
INFO - 2020-02-09 17:00:07 --> Final output sent to browser
DEBUG - 2020-02-09 17:00:07 --> Total execution time: 0.8778
INFO - 2020-02-09 17:00:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:07 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:07 --> URI Class Initialized
INFO - 2020-02-09 17:00:07 --> Router Class Initialized
INFO - 2020-02-09 17:00:07 --> Output Class Initialized
INFO - 2020-02-09 17:00:07 --> Security Class Initialized
DEBUG - 2020-02-09 17:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:07 --> Input Class Initialized
INFO - 2020-02-09 17:00:07 --> Language Class Initialized
ERROR - 2020-02-09 17:00:07 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-09 17:00:07 --> Config Class Initialized
INFO - 2020-02-09 17:00:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:07 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:07 --> URI Class Initialized
INFO - 2020-02-09 17:00:07 --> Router Class Initialized
INFO - 2020-02-09 17:00:07 --> Output Class Initialized
INFO - 2020-02-09 17:00:07 --> Security Class Initialized
DEBUG - 2020-02-09 17:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:07 --> Input Class Initialized
INFO - 2020-02-09 17:00:07 --> Language Class Initialized
ERROR - 2020-02-09 17:00:07 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-09 17:00:07 --> Config Class Initialized
INFO - 2020-02-09 17:00:07 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:07 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:07 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:07 --> URI Class Initialized
INFO - 2020-02-09 17:00:07 --> Router Class Initialized
INFO - 2020-02-09 17:00:08 --> Output Class Initialized
INFO - 2020-02-09 17:00:08 --> Security Class Initialized
DEBUG - 2020-02-09 17:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:08 --> Input Class Initialized
INFO - 2020-02-09 17:00:08 --> Language Class Initialized
ERROR - 2020-02-09 17:00:08 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-09 17:00:08 --> Config Class Initialized
INFO - 2020-02-09 17:00:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:08 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:08 --> URI Class Initialized
INFO - 2020-02-09 17:00:08 --> Router Class Initialized
INFO - 2020-02-09 17:00:08 --> Output Class Initialized
INFO - 2020-02-09 17:00:08 --> Security Class Initialized
DEBUG - 2020-02-09 17:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:08 --> Input Class Initialized
INFO - 2020-02-09 17:00:08 --> Language Class Initialized
ERROR - 2020-02-09 17:00:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 17:00:08 --> Config Class Initialized
INFO - 2020-02-09 17:00:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:08 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:08 --> URI Class Initialized
INFO - 2020-02-09 17:00:08 --> Router Class Initialized
INFO - 2020-02-09 17:00:08 --> Output Class Initialized
INFO - 2020-02-09 17:00:08 --> Security Class Initialized
DEBUG - 2020-02-09 17:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:08 --> Input Class Initialized
INFO - 2020-02-09 17:00:08 --> Language Class Initialized
ERROR - 2020-02-09 17:00:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-09 17:00:08 --> Config Class Initialized
INFO - 2020-02-09 17:00:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:08 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:08 --> URI Class Initialized
INFO - 2020-02-09 17:00:08 --> Router Class Initialized
INFO - 2020-02-09 17:00:08 --> Output Class Initialized
INFO - 2020-02-09 17:00:08 --> Security Class Initialized
DEBUG - 2020-02-09 17:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:08 --> Input Class Initialized
INFO - 2020-02-09 17:00:08 --> Language Class Initialized
ERROR - 2020-02-09 17:00:08 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-09 17:00:08 --> Config Class Initialized
INFO - 2020-02-09 17:00:08 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:08 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:08 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:08 --> URI Class Initialized
INFO - 2020-02-09 17:00:08 --> Router Class Initialized
INFO - 2020-02-09 17:00:08 --> Output Class Initialized
INFO - 2020-02-09 17:00:08 --> Security Class Initialized
DEBUG - 2020-02-09 17:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:08 --> Input Class Initialized
INFO - 2020-02-09 17:00:08 --> Language Class Initialized
ERROR - 2020-02-09 17:00:08 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-09 17:00:09 --> Config Class Initialized
INFO - 2020-02-09 17:00:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:09 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:09 --> URI Class Initialized
INFO - 2020-02-09 17:00:09 --> Router Class Initialized
INFO - 2020-02-09 17:00:09 --> Output Class Initialized
INFO - 2020-02-09 17:00:09 --> Security Class Initialized
DEBUG - 2020-02-09 17:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:09 --> Input Class Initialized
INFO - 2020-02-09 17:00:09 --> Language Class Initialized
ERROR - 2020-02-09 17:00:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-09 17:00:09 --> Config Class Initialized
INFO - 2020-02-09 17:00:09 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:09 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:09 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:09 --> URI Class Initialized
INFO - 2020-02-09 17:00:09 --> Router Class Initialized
INFO - 2020-02-09 17:00:09 --> Output Class Initialized
INFO - 2020-02-09 17:00:09 --> Security Class Initialized
DEBUG - 2020-02-09 17:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:09 --> Input Class Initialized
INFO - 2020-02-09 17:00:09 --> Language Class Initialized
ERROR - 2020-02-09 17:00:09 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-09 17:00:37 --> Config Class Initialized
INFO - 2020-02-09 17:00:37 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:37 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:37 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:37 --> URI Class Initialized
INFO - 2020-02-09 17:00:37 --> Router Class Initialized
INFO - 2020-02-09 17:00:37 --> Output Class Initialized
INFO - 2020-02-09 17:00:37 --> Security Class Initialized
DEBUG - 2020-02-09 17:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:37 --> Input Class Initialized
INFO - 2020-02-09 17:00:38 --> Language Class Initialized
INFO - 2020-02-09 17:00:38 --> Loader Class Initialized
INFO - 2020-02-09 17:00:38 --> Helper loaded: url_helper
INFO - 2020-02-09 17:00:38 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:00:38 --> Controller Class Initialized
INFO - 2020-02-09 17:00:38 --> Model "M_tiket" initialized
INFO - 2020-02-09 17:00:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 17:00:38 --> Model "M_pesan" initialized
INFO - 2020-02-09 17:00:38 --> Helper loaded: form_helper
INFO - 2020-02-09 17:00:38 --> Form Validation Class Initialized
INFO - 2020-02-09 17:00:38 --> Final output sent to browser
DEBUG - 2020-02-09 17:00:38 --> Total execution time: 0.6740
INFO - 2020-02-09 17:00:52 --> Config Class Initialized
INFO - 2020-02-09 17:00:52 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:00:52 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:00:52 --> Utf8 Class Initialized
INFO - 2020-02-09 17:00:52 --> URI Class Initialized
INFO - 2020-02-09 17:00:52 --> Router Class Initialized
INFO - 2020-02-09 17:00:52 --> Output Class Initialized
INFO - 2020-02-09 17:00:52 --> Security Class Initialized
DEBUG - 2020-02-09 17:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:00:52 --> Input Class Initialized
INFO - 2020-02-09 17:00:52 --> Language Class Initialized
INFO - 2020-02-09 17:00:52 --> Loader Class Initialized
INFO - 2020-02-09 17:00:52 --> Helper loaded: url_helper
INFO - 2020-02-09 17:00:52 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:00:52 --> Controller Class Initialized
INFO - 2020-02-09 17:00:52 --> Model "M_tiket" initialized
INFO - 2020-02-09 17:00:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 17:00:52 --> Model "M_pesan" initialized
INFO - 2020-02-09 17:00:52 --> Helper loaded: form_helper
INFO - 2020-02-09 17:00:52 --> Form Validation Class Initialized
INFO - 2020-02-09 17:00:52 --> Final output sent to browser
DEBUG - 2020-02-09 17:00:52 --> Total execution time: 0.5901
INFO - 2020-02-09 17:01:21 --> Config Class Initialized
INFO - 2020-02-09 17:01:21 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:01:21 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:01:22 --> Utf8 Class Initialized
INFO - 2020-02-09 17:01:22 --> URI Class Initialized
INFO - 2020-02-09 17:01:22 --> Router Class Initialized
INFO - 2020-02-09 17:01:22 --> Output Class Initialized
INFO - 2020-02-09 17:01:22 --> Security Class Initialized
DEBUG - 2020-02-09 17:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:01:22 --> Input Class Initialized
INFO - 2020-02-09 17:01:22 --> Language Class Initialized
INFO - 2020-02-09 17:01:22 --> Loader Class Initialized
INFO - 2020-02-09 17:01:22 --> Helper loaded: url_helper
INFO - 2020-02-09 17:01:22 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:01:22 --> Controller Class Initialized
INFO - 2020-02-09 17:01:22 --> Model "M_tiket" initialized
INFO - 2020-02-09 17:01:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 17:01:22 --> Model "M_pesan" initialized
INFO - 2020-02-09 17:01:22 --> Helper loaded: form_helper
INFO - 2020-02-09 17:01:22 --> Form Validation Class Initialized
INFO - 2020-02-09 17:01:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-09 17:01:22 --> Final output sent to browser
DEBUG - 2020-02-09 17:01:22 --> Total execution time: 0.4672
INFO - 2020-02-09 17:01:22 --> Config Class Initialized
INFO - 2020-02-09 17:01:22 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:01:22 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:01:22 --> Utf8 Class Initialized
INFO - 2020-02-09 17:01:22 --> Config Class Initialized
INFO - 2020-02-09 17:01:22 --> Config Class Initialized
INFO - 2020-02-09 17:01:22 --> Hooks Class Initialized
INFO - 2020-02-09 17:01:22 --> Hooks Class Initialized
INFO - 2020-02-09 17:01:22 --> URI Class Initialized
INFO - 2020-02-09 17:01:22 --> Router Class Initialized
DEBUG - 2020-02-09 17:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 17:01:22 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:01:22 --> Utf8 Class Initialized
INFO - 2020-02-09 17:01:22 --> Utf8 Class Initialized
INFO - 2020-02-09 17:01:22 --> Output Class Initialized
INFO - 2020-02-09 17:01:22 --> URI Class Initialized
INFO - 2020-02-09 17:01:22 --> URI Class Initialized
INFO - 2020-02-09 17:01:22 --> Security Class Initialized
DEBUG - 2020-02-09 17:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:01:22 --> Router Class Initialized
INFO - 2020-02-09 17:01:22 --> Router Class Initialized
INFO - 2020-02-09 17:01:22 --> Input Class Initialized
INFO - 2020-02-09 17:01:22 --> Output Class Initialized
INFO - 2020-02-09 17:01:22 --> Output Class Initialized
INFO - 2020-02-09 17:01:22 --> Language Class Initialized
INFO - 2020-02-09 17:01:22 --> Security Class Initialized
INFO - 2020-02-09 17:01:22 --> Security Class Initialized
ERROR - 2020-02-09 17:01:22 --> 404 Page Not Found: Bower_components/jquery
DEBUG - 2020-02-09 17:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-09 17:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:01:22 --> Input Class Initialized
INFO - 2020-02-09 17:01:22 --> Input Class Initialized
INFO - 2020-02-09 17:01:22 --> Language Class Initialized
INFO - 2020-02-09 17:01:22 --> Language Class Initialized
INFO - 2020-02-09 17:01:22 --> Loader Class Initialized
INFO - 2020-02-09 17:01:23 --> Helper loaded: url_helper
INFO - 2020-02-09 17:01:23 --> Loader Class Initialized
INFO - 2020-02-09 17:01:23 --> Helper loaded: url_helper
INFO - 2020-02-09 17:01:23 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:01:23 --> Database Driver Class Initialized
INFO - 2020-02-09 17:01:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-09 17:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:01:23 --> Controller Class Initialized
INFO - 2020-02-09 17:01:23 --> Model "M_tiket" initialized
INFO - 2020-02-09 17:01:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 17:01:23 --> Model "M_pesan" initialized
INFO - 2020-02-09 17:01:23 --> Helper loaded: form_helper
INFO - 2020-02-09 17:01:23 --> Form Validation Class Initialized
ERROR - 2020-02-09 17:01:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-09 17:01:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-09 17:01:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-09 17:01:23 --> Final output sent to browser
DEBUG - 2020-02-09 17:01:23 --> Total execution time: 0.6718
INFO - 2020-02-09 17:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:01:23 --> Controller Class Initialized
INFO - 2020-02-09 17:01:23 --> Model "M_tiket" initialized
INFO - 2020-02-09 17:01:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-09 17:01:23 --> Model "M_pesan" initialized
INFO - 2020-02-09 17:01:23 --> Helper loaded: form_helper
INFO - 2020-02-09 17:01:23 --> Form Validation Class Initialized
ERROR - 2020-02-09 17:01:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-09 17:01:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-09 17:01:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-09 17:01:23 --> Final output sent to browser
DEBUG - 2020-02-09 17:01:23 --> Total execution time: 0.8974
